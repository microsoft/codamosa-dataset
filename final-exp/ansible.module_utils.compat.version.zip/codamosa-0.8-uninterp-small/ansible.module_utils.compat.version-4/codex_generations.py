

# Generated at 2022-06-24 21:17:15.261008
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    assert ~version


# Generated at 2022-06-24 21:17:26.762057
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_1 = StrictVersion('0.0')
    assert str(version_1) == '0.0'
    version_1 = StrictVersion('1.0')
    assert str(version_1) == '1.0'
    version_1 = StrictVersion('1')
    assert str(version_1) == '1.0'
    version_1 = StrictVersion('1')
    version_2 = StrictVersion('1.0')
    assert str(version_1) == '1.0'
    assert str(version_2) == '1.0'
    version_1 = StrictVersion('1.1')
    version_2 = StrictVersion('1.0')
    assert str(version_1) == '1.1'
    assert str(version_2) == '1.0'


# Generated at 2022-06-24 21:17:29.048857
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    try:
        r = version_0 <= version_1
    except:
        r = "Exception"

    assert r == "Exception"


# Generated at 2022-06-24 21:17:32.055045
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    return

    version_0 = Version()
    version_1 = Version()
    try:
        version_0.__ge__(version_1)
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:17:34.085891
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse("1.2.3.4")


# Generated at 2022-06-24 21:17:44.349296
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    resultlist = []
    versionlist = ["0.0","0.01","0.01.1","0.1","1.0","1.2.3","0.01a"]
    resultlist.append(((versionlist[0]),([0.0])))
    resultlist.append(((versionlist[1]),([0.0,1])))
    resultlist.append(((versionlist[2]),([0.0,1,1])))
    resultlist.append(((versionlist[3]),([0.1])))
    resultlist.append(((versionlist[4]),([1,0])))
    resultlist.append(((versionlist[5]),([1,2,3])))
    resultlist.append(((versionlist[6]),([0.0,1,'a'])))

# Generated at 2022-06-24 21:17:44.999972
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()


# Generated at 2022-06-24 21:17:51.805307
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion(vstring='1.0.1')
    assert str(version_0) == "1.0.1"

    version_1 = StrictVersion(vstring='1.0.1a2')
    assert str(version_1) == "1.0.1a2"

    version_2 = StrictVersion(vstring='1.0.1b2')
    assert str(version_2) == "1.0.1b2"

    version_3 = StrictVersion(vstring='1.0.1a2')
    assert str(version_3) == "1.0.1a2"

    version_4 = StrictVersion(vstring='3.2')
    assert str(version_4) == "3.2"



# Generated at 2022-06-24 21:17:56.275597
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = version_0
    version_2 = Version()
    version_3 = Version()

    # Check that the method returns the expected result
    assert version_0 <= version_1

    # Check that the method returns the expected result
    assert version_0 <= version_2

    assert version_0 <= version_3



# Generated at 2022-06-24 21:17:57.939436
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 < version_1 == False


# Generated at 2022-06-24 21:18:09.757390
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    try:
        test_case_0()
    except Exception:
        return False

    return True


# Generated at 2022-06-24 21:18:12.142150
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    try:
        version.__ge__("4.4.4")
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:18:16.665329
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_0._cmp = version_1._cmp = lambda x : NotImplemented
    assert version_0.__ge__(version_1) is NotImplemented


# Generated at 2022-06-24 21:18:18.382374
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version(str(None))


# Generated at 2022-06-24 21:18:20.617406
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert (version_0.__gt__(version_1)) == False


# Generated at 2022-06-24 21:18:23.672994
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_1 = Version()
    version_1._cmp.return_value = -1
    actual = version_1.__lt__(None)
    assert actual


# Generated at 2022-06-24 21:18:31.760407
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_0._cmp = lambda self, x: 0
    version_0._cmp = lambda self, x: 0
    # Test whether a ValueError exception is raised
    try:
        version_0 > version_1
    except ValueError as e:
        assert(str(e) == 'no ordering relation is defined for unequal versions')


# Generated at 2022-06-24 21:18:35.139705
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert (version_0 == version_1)


# Generated at 2022-06-24 21:18:39.098303
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        version_0 = Version('0.18.4')
        assert version_0 > '0.1'
        assert version_0 > '0.18.3'
        assert version_0 <= '0.19.1'
    except:
        assert False


# Generated at 2022-06-24 21:18:41.485817
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    check_version_function('__lt__')


# Generated at 2022-06-24 21:18:48.593163
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()


# Generated at 2022-06-24 21:18:50.475090
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    assert version_0 <= '0'


# Generated at 2022-06-24 21:18:53.813770
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    ret = version_0.__ge__(version_1)
    return ret


# Generated at 2022-06-24 21:18:57.379572
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    eq_1 = version_0 == Version()
    le_1 = version_0 <= Version()
    assert eq_1, ('test_Version___ge__: version_0.__ge__(Version()) should '
                  'have returned True')


# Generated at 2022-06-24 21:18:57.964128
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass


# Generated at 2022-06-24 21:19:01.237573
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # check that the comparison operator works in case of the empty constructor
    version_0 = Version()
    version_1 = Version()
    if not (version_0 < version_1):
        return 0
    else:
        return 1


# Generated at 2022-06-24 21:19:03.450243
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    assert version_0 <= "3.5.5"
    assert version_0 <= "1.2.3"


# Generated at 2022-06-24 21:19:14.363476
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_2.parse("1.1.1")
    version_3 = Version()
    version_3.parse("1.1.0")
    version_4 = Version()
    version_4.parse("1.1.9")

    # Check if the condition is satisfied
    try:
        assert version_0.__le__(version_1)
        assert version_1.__le__(version_2)
        assert version_3.__le__(version_4)
        version_0._cmp(None)
        version_1._cmp(version_2)
    except AssertionError:
        raise AssertionError("One of the conditions is not satisfied")


# Generated at 2022-06-24 21:19:17.423508
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v_vstring = None
    v_vstring = "0.1"
    v = Version(v_vstring)



# Generated at 2022-06-24 21:19:18.965200
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0.__gt__(version_1) == NotImplemented


# Generated at 2022-06-24 21:19:29.203658
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_2 = version_1
    result = version_0.__ge__(version_1)
    # Error: Incompatible types: "bool" and "int"
    result = version_0.__ge__(version_2)


# Generated at 2022-06-24 21:19:31.407896
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert not version_0.__eq__(version_1)


# Generated at 2022-06-24 21:19:35.852503
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version('1.2.3')
    other_0 = '1.2.3'
    ret = version_0.__ge__(other_0)
    assert ret


# Generated at 2022-06-24 21:19:37.418552
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version_0 = LooseVersion()
    vstring_0 = ""
    version_0.parse(vstring_0)


# Generated at 2022-06-24 21:19:45.249717
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    assert (version_0 >= version_1) is False
    assert (version_0 >= version_2) is False
    assert (version_0 >= version_3) is False
    assert (version_0 >= version_4) is False


# Generated at 2022-06-24 21:19:48.723132
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    __result__ = (version_0 == version_1)
    print (__result__)
    # assert __result__ == result
    # assert result == True


# Generated at 2022-06-24 21:19:52.805249
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version('0')
    version_1 = Version('1')
    assert version_0 < version_1
    assert version_0 <= version_1
    assert version_0 != version_1
    assert version_1 > version_0
    assert version_1 >= version_0
    assert version_0 != version_1


# Generated at 2022-06-24 21:19:54.345645
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    other = Version()
    b = version.__gt__(other)
    assert b


# Generated at 2022-06-24 21:19:56.325781
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()



# Generated at 2022-06-24 21:20:00.862271
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version('5.0.0')
    assert version_0.__gt__('4.0.0'), 'AssertionError'
    assert not version_0.__gt__('5.0.0'), 'AssertionError'
    assert not version_0.__gt__('6.0.0'), 'AssertionError'


# Generated at 2022-06-24 21:20:16.462827
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    
    # Test case : Check that the comparison of Version instance to string
    #  is correct.
    # Assert that the result of the comparison of Version instance to string is
    #  correct.
    assert(version.__lt__("1.0.0") == True)
    
import sys
import unittest


# Generated at 2022-06-24 21:20:21.048522
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_1.parse('1.2.3')
    version_2 = Version()
    version_2.parse('1.1.3')
    version_3 = Version()
    version_3.parse('1.2.3.dev5')

    assert(version_2 > version_1)
    assert(not (version_1 > version_2))
    assert(not (version_1 > version_1))

    assert(version_1 > version_0)

    assert(version_3 > version_0)
    assert(not (version_0 > version_3))



# Generated at 2022-06-24 21:20:22.226442
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_0._cmp = lambda x: 0
    assert version_0 <= ''


# Generated at 2022-06-24 21:20:23.569713
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = version_0
    assert version_1 == version_2


# Generated at 2022-06-24 21:20:25.417961
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_1._cmp = lambda x:0
    version_2 = Version(vstring=version_0)
    assert version_1 >= version_2


# Generated at 2022-06-24 21:20:26.233893
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()



# Generated at 2022-06-24 21:20:29.688950
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    sample_Version = Version()
    # test_0 = getattr(version_0, "__lt__")(sample_Version)
    assert version_0.__lt__(sample_Version) == NotImplemented


# Generated at 2022-06-24 21:20:31.515787
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    var_1 = version_0 < version_1
    var_2 = version_1 < version_0
    var_3 = version_0 < version_0



# Generated at 2022-06-24 21:20:33.518301
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    print('Test for method __ge__ of class Version')
    v = Version('1')
    assert(v >= '1')


# Generated at 2022-06-24 21:20:35.178454
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = version_0.__le__(version_0)


# Generated at 2022-06-24 21:21:05.318850
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 >= version_1


# Generated at 2022-06-24 21:21:07.199445
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    assert (version_0 <  0) == False


# Generated at 2022-06-24 21:21:12.960667
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert test_case_0() is None


# Generated at 2022-06-24 21:21:15.732479
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version(None)
    result = version_0 <= None
    assert result == False


# Generated at 2022-06-24 21:21:20.094355
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 < version_1


# Generated at 2022-06-24 21:21:21.718190
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    try:
        v1.__ge__(0)
    except Exception as e:
        print(e)



# Generated at 2022-06-24 21:21:26.326050
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version("string_0")
    version_1 = Version()
    result = version_0.__le__(version_1)
    assert result is False


# Generated at 2022-06-24 21:21:31.588790
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    # The following line is expected to throw a TypeError exception.
    try:
        version_0.__eq__(None)
    except TypeError:
        pass
    else:
        raise AssertionError('ExpectedTypeError not thrown')


# Generated at 2022-06-24 21:21:35.502120
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()

    # i = 0
    # while i == 0:
    #     version_1 = Version()
    #     if version_1 > version_0:
    #         i = i


# Generated at 2022-06-24 21:21:43.282477
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    LooseVersion(None).parse('1.6a1')
    LooseVersion(None).parse('1.6pl')
    LooseVersion(None).parse('1.6.post')
    LooseVersion(None).parse('1.6.pl')
    LooseVersion(None).parse('1.6.dev')
    LooseVersion(None).parse('1.6a2pl3.4')
    LooseVersion(None).parse('1.6a2.post1.dev1')


# Generated at 2022-06-24 21:22:44.125894
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 == version_1


# Generated at 2022-06-24 21:22:46.280805
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    assert (version_0 > None) == False


# Generated at 2022-06-24 21:22:51.250665
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    assert version_0.__eq__(version_0) == True


# Generated at 2022-06-24 21:22:54.434166
# Unit test for method __le__ of class Version
def test_Version___le__():
    with pytest.raises(TypeError):
        # Verify that an integer value can't be compared with a Version
        version_0 = Version()
        version_0.__le__(5)


# Generated at 2022-06-24 21:22:55.654839
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert (Version() == 1) == False


# Generated at 2022-06-24 21:23:06.030836
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    print("@test_Version___gt__")
    v_0 = Version()
    v_1 = Version("1.0.0")
    v_2 = Version("3.0.2")
    v_3 = Version("3.1.1")
    v_4 = Version("3.2.0")
    v_5 = Version("3.2.1")
    v_6 = Version("4.0.2")
    v_7 = Version("5.1.1")
    v_8 = Version("5.2.0")
    v_9 = Version("5.2.1")

    assert(v_0 == v_0)
    assert(v_1 == v_1)
    assert(v_2 == v_2)
    assert(v_3 == v_3)

# Generated at 2022-06-24 21:23:08.292380
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert test_case_0.__doc__ == Version.__lt__.__doc__


# Generated at 2022-06-24 21:23:12.356717
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()

    # Test whether __eq__ is implemented.
    assert version_0.__eq__ == NotImplemented

    # Test whether __eq__ works correctly.
    assert version_0.__eq__(version_0)

    # Test whether __eq__ raises expected exceptions
    with pytest.raises(Exception):
        version_0.__eq__(Argument.new_with_defaults(2))


# Generated at 2022-06-24 21:23:20.603431
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Test for method __le__ of class Version"""
    version_0 = Version()
    version_0._cmp = lambda x: NotImplemented
    version_1 = Version()
    version_1._cmp = lambda x: 42
    version_2 = Version()
    version_2._cmp = lambda x: -42
    version_3 = Version()
    version_3._cmp = lambda x: 0
    # Test with various number of arguments
    assert version_0 <= version_0
    assert version_1 <= version_2
    assert version_1 <= version_3
    assert version_2 <= version_3
    assert version_3 <= version_3


# Generated at 2022-06-24 21:23:26.658335
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v0 = Version("1:2:3-alpha")
    assert v0.__lt__(Version("1.2.3")) == True
    assert v0.__lt__(Version("1.2.3-alpha")) == True
    assert v0.__lt__("2.0") == True
    assert v0.__lt__("1.3.3") == True
    assert v0.__lt__("1.2.4") == True
    assert v0.__lt__("1.2.2") == False
    assert v0.__lt__("1.2.3-beta") == False
    assert v0.__lt__("1.2.3-alpha") == False


# Generated at 2022-06-24 21:25:59.497257
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    test_value = version_0 < version_1
    assert test_value == False


# Generated at 2022-06-24 21:26:06.540445
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version();
    version_1 = Version();
    version_1.parse('0.0.0')
    version_2 = StrictVersion();
    version_2.parse('0.0.0')
    version_3 = StrictVersion();
    version_3.parse('0.0.0')
    version_4 = Version();
    version_4.parse('0.0.0')
    version_5 = StrictVersion();
    version_5.parse('0.0.0')
    version_6 = Version();
    version_6.parse('0.0.0')
    version_7 = Version();
    version_7.parse('0.0.0')
    version_8 = Version();
    version_8.parse('0.0.0')

# Generated at 2022-06-24 21:26:10.177744
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()

    # Test initial value of variable 'version_0'
    assert version_0.__ge__(version_1) == True, "expected True"


# Generated at 2022-06-24 21:26:13.996522
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_0._cmp = Version._cmp
    version_1._cmp = Version._cmp
    version_0_inst_0 = version_0.__eq__(version_1)
    assert version_0_inst_0 == False


# Generated at 2022-06-24 21:26:24.150918
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    ver0 = "0.0.0.0"
    ver1 = "0.0.1.0"
    ver2 = "0.1.0.0"
    ver3 = "1.0.0.0"

    v0 = Version(ver0)
    v1 = Version(ver1)
    v2 = Version(ver2)
    v3 = Version(ver3)

    if not(v0 < v1):
        raise RuntimeError("v0 < v1")
    if not(v0 < v2):
        raise RuntimeError("v0 < v2")
    if not(v0 < v3):
        raise RuntimeError("v0 < v3")

    if not(v0 < ver0):
        raise RuntimeError("v0 < ver0")

# Generated at 2022-06-24 21:26:26.653178
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v != 3
    class Test: pass
    x = Test()
    assert v != x


# Generated at 2022-06-24 21:26:29.688139
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    version_0 < version_1


# Generated at 2022-06-24 21:26:31.754774
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 >= version_1


# Generated at 2022-06-24 21:26:43.070206
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    result = version_0.__lt__(version_1)
    assert not result
    result = version_0.__lt__(version_2)
    assert not result
    result = version_0.__lt__(version_3)
    assert result
    result = version_0.__lt__(version_4)
    assert result
    result = version_0.__lt__(version_5)
    assert result
    result = version_0.__lt__(version_6)
    assert result
    result = version_

# Generated at 2022-06-24 21:26:46.780635
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    assert not version_0 < None
