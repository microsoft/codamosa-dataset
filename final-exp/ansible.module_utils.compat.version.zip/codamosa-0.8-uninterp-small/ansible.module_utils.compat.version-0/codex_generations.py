

# Generated at 2022-06-24 21:17:23.718871
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = re.match(r"^(([ab])\2)", "ab")
    version_0._cmp(version_1)
    version_2 = Version()
    try:
        version_2._cmp(version_1)
    except ValueError:
        pass


# Generated at 2022-06-24 21:17:25.969160
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version('1.0')
    assert version_0 > Version('1.0')



# Generated at 2022-06-24 21:17:31.398386
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.4.4') < Version('1.4.4.post24')


# Generated at 2022-06-24 21:17:34.024661
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    try:
        Version.__lt__(Version(), '1.1')
    except AttributeError:
        return
    assert False



# Generated at 2022-06-24 21:17:36.364554
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    # Test case 0
    assert version_0 >= version_1

    assert version_1 >= version_0



# Generated at 2022-06-24 21:17:38.328861
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion()
    assert version_0.__str__() == ''


# Generated at 2022-06-24 21:17:42.002156
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    try:
        version_0.__eq__(version_0)
    except UnboundLocalError as e:
        raise AssertionError(e)


# Generated at 2022-06-24 21:17:45.098703
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        v = Version()
        assert v == None, '__eq__ should return False'
    except AssertionError as e:
        raise ValueError('__eq__ should return False')


# Generated at 2022-06-24 21:17:47.796491
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0.0')
    v2 = Version('2.0.0')
    if v1 < v2:
        return 1
    else:
        return 0

# Generated at 2022-06-24 21:17:51.701641
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()

    assert version_1.__gt__(version_0) == NotImplemented


# Generated at 2022-06-24 21:18:04.636713
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    tests = (
        ('1.0', (1, 0, 0)),
        ('1.2.3', (1, 2, 3)),
        ('0.4.0', (0, 4, 0)),
        ('0.0.4', (0, 0, 4)),
        ('2.7.0b2', (2, 7, 0, ('b', 2))),
        ('2.7.0b2.dev456', (2, 7, 0, ('b', 2))),
    )
    for vstring, version_info in tests:
        v = StrictVersion(vstring)
        assert v.version == version_info


# Generated at 2022-06-24 21:18:06.032503
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    sv1 = StrictVersion("2.2.2")
    assert str(sv1) == "2.2.2"


# Generated at 2022-06-24 21:18:11.432880
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v2 = Version()
    v3 = Version(vstring="1.1.0")
    assert (v2 >= v3) is False
    assert (v2 <= v3) is True
    assert (v2 > v3) is False
    assert (v2 < v3) is True

    v2 = Version(vstring="1.1.1")
    assert (v2 >= v3) is True
    assert (v2 <= v3) is False
    assert (v2 > v3) is True
    assert (v2 < v3) is False

    v2 = Version(vstring="1.1.0")
    assert (v2 >= v3) is True
    assert (v2 <= v3) is True
    assert (v2 > v3) is False
    assert (v2 < v3) is False



# Generated at 2022-06-24 21:18:17.318303
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # implementation of test case
    version_0 = StrictVersion("1.1a1")
    version_0 = StrictVersion("1")
    version_0 = StrictVersion("1.2")
    version_0 = StrictVersion("1.2rc1")
    version_0 = StrictVersion("1.2.3.4")
    # check the results of the test
    assert(str(version_0) == "1.2.3.4"), "Test Failed"


# Generated at 2022-06-24 21:18:20.568933
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion("1.0.0.5")
    assert version_0.__str__() == "1.0.0.5"


# Generated at 2022-06-24 21:18:23.629271
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    expression_0 = version_1 <= version_0
    expression_0 = True


# Generated at 2022-06-24 21:18:26.177093
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v_list = list()
    v_list.append(Version())
    v_list.append(Version())
    v_list[0] < v_list[1]


# Generated at 2022-06-24 21:18:28.459782
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    assert version.__lt__(None) is NotImplemented


# Generated at 2022-06-24 21:18:33.165956
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_0_0 = Version()
    if (version_0 < version_0_0):
        raise RuntimeError("Test of method __lt__ of class Version failed")

test_Version___lt__()
test_case_0()


# Generated at 2022-06-24 21:18:41.965457
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    str_arg_1 = '35'
    assert version_0.__le__(str_arg_1) == NotImplemented
    str_arg_2 = '7.35'
    assert version_0.__le__(str_arg_2) == NotImplemented
    str_arg_3 = '10.4.6'
    assert version_0.__le__(str_arg_3) == NotImplemented
    str_arg_4 = '3.3.3.3.3.3'
    assert version_0.__le__(str_arg_4) == NotImplemented
    str_arg_5 = '11g'
    assert version_0.__le__(str_arg_5) == NotImplemented

# Generated at 2022-06-24 21:19:02.053403
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    result = version_0.__le__(version_1)
    assert result is True


# Generated at 2022-06-24 21:19:04.240717
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        version_1 = Version()
        version_2 = Version()
        status = version_1.__eq__(version_2)
    except:
        status = False

    return status


# Generated at 2022-06-24 21:19:07.324476
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    other_0 = version_0
    var_0 = version_0.__ge__(other_0)
    assert var_0


# Generated at 2022-06-24 21:19:10.276818
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_1 = Version()
    version_2 = Version()
    if (version_1 == version_2):
        print('tests_passed!')
    else:
        print('tests_failed')


# Generated at 2022-06-24 21:19:15.792143
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version(vstring="1.0")
    v2 = Version(vstring="1.0")
    test_eq = v1.__eq__(v2)
    assert test_eq


# Generated at 2022-06-24 21:19:18.058118
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = version_0
    assert version_0 <= version_1
    assert version_1 <= version_0
    assert version_0 <= True


# Generated at 2022-06-24 21:19:19.767318
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    assert version < "1"


# Generated at 2022-06-24 21:19:27.165344
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Create instance
    version_0 = Version()
    # Assign
    var_1 = str(version_0)
    # Assign
    var_2 = version_0
    # Call method __gt__ with arguments
    try:
        assert version_0.__gt__(var_2)
    except Exception as e:
        print("\nException raised: %s" % str(e))


# Generated at 2022-06-24 21:19:32.311382
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version("1.0.0")
    version_1 = Version("0.0.1")
    if (version_0 > version_1):
        version_0 = version_1


# Generated at 2022-06-24 21:19:38.990129
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version("RELEASE")
    o = version_0 == version_1
    print("v0 == v1:", type(o), o)
    version_2 = LooseVersion("1.0.0a1")
    o = version_1 == version_2
    print("v1 == v2:", type(o), o)


# Generated at 2022-06-24 21:19:59.150466
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = version_0._cmp(version_0)
    assert version_1 == 0


# Generated at 2022-06-24 21:20:07.724960
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_case_0()
    version_0 = Version()
    try:
        version_0.__eq__(None)
    except TypeError:
        pass
    else:
        raise TypeError('None not supported in this case')
    try:
        version_0.__eq__(1)
    except TypeError:
        pass
    else:
        raise TypeError('1 not supported in this case')
    try:
        version_0.__eq__('abc')
    except TypeError:
        pass
    else:
        raise TypeError('\'abc\' not supported in this case')


# Generated at 2022-06-24 21:20:08.997293
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert(Version.__ge__(test_case_0, None))


# Generated at 2022-06-24 21:20:10.474283
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    assert (v1 <= v2)


# Generated at 2022-06-24 21:20:12.259541
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    global version_0
    try:
        assert version_0 > None == NotImplemented
    except AssertionError:
        raise AssertionError("__gt__")


# Generated at 2022-06-24 21:20:13.453252
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    assert version_0 == None


# Generated at 2022-06-24 21:20:14.629138
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    assert version_0.__gt__(version_0) == False


# Generated at 2022-06-24 21:20:18.710922
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from ansible.compat.tests.unit.parsing.utils.distutils_version import Version
    version_0 = Version()
    version_2 = Version()
    version_1 = Version()
    int_0 = version_1._cmp(version_2)
    assert int_0 >= 0
    int_1 = version_0._cmp(version_1)
    assert int_1 >= 0


# Generated at 2022-06-24 21:20:19.704821
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2


# Generated at 2022-06-24 21:20:23.189850
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    try:
        version_1 = Version('1.0')
    except ValueError as e:
        print(f'Unit test for method __ge__ of class Version raised exception: {e}')
        return
    if version_1 >= version_1:
        print(f'Unit test for method __ge__ of class Version is passed')
    else:
        print(f'Unit test for method __ge__ of class Version failed')


# Generated at 2022-06-24 21:20:41.621029
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_1.parse("1.0.0")
    version_1._cmp(version_0)
    version_0.parse("1.0.0")
    version_0._cmp(version_1)


# Generated at 2022-06-24 21:20:43.255817
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    if(not (v1 == v2)):
        raise AssertionError


# Generated at 2022-06-24 21:20:49.127327
# Unit test for method __le__ of class Version
def test_Version___le__():
    global version_1, version_2
    version_1 = Version('1.0')
    version_2 = Version('2.0')
    assert version_1 <= version_1


# Generated at 2022-06-24 21:20:50.308954
# Unit test for method __le__ of class Version
def test_Version___le__():
    test_case_0()


# Generated at 2022-06-24 21:20:53.941506
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    assert (version_0 >= version_1)


# Generated at 2022-06-24 21:20:55.870026
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    assert (version_0 >= version_1) is False


# Generated at 2022-06-24 21:20:57.369085
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    test_case_0()

if __name__ == "__main__":
    test_Version___gt__()

# Generated at 2022-06-24 21:20:58.940083
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version()


# Generated at 2022-06-24 21:21:06.591774
# Unit test for method __le__ of class Version
def test_Version___le__():

    version_0 = Version()
    version_1 = Version()
    version_0._cmp = lambda x:'ab '
    version_1._cmp = lambda x:'ab '

    # Verify that, for any two Version objects,
    #    if version_1._cmp( version_2 ) returns NotImplemented,
    #    version_1.__le__( version_2 ) will return false.
    assert not version_0.__le__(version_1)
    assert not version_1.__le__(version_0)

    # Verify that, for any two Version objects,
    #    if version_1._cmp( version_2 ) returns a value less than 0,
    #    version_1.__le__( version_2 ) will return true.
    version_0._cmp = lambda x:'-1'
    version_1

# Generated at 2022-06-24 21:21:09.850244
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    return None


# Generated at 2022-06-24 21:21:43.507623
# Unit test for method __le__ of class Version
def test_Version___le__():
    try:
        test_case_0()
    except Exception:
        print("Failed")
        raise

test_Version___le__()

# Generated at 2022-06-24 21:21:48.455706
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    for v in [Version(), Version('2')]:
        try:
            if v > v:
                raise AssertionError
            if not v == v:
                raise AssertionError
            if not v >= v:
                raise AssertionError
        except TypeError:
            raise AssertionError


# Generated at 2022-06-24 21:21:58.203458
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import StrictVersion
    from distutils.version import LooseVersion
    from distutils.version import Version

    import re

    assert(StrictVersion("1.1.1") == StrictVersion("1.1.1"))
    assert(LooseVersion("1.1.1") == LooseVersion("1.1.1"))
    assert(Version("1.1.1") == Version("1.1.1"))

    assert not (StrictVersion("1.1.1") == StrictVersion("1.1.2"))
    assert(LooseVersion("1.1.1") == LooseVersion("1.1.2"))
    assert(Version("1.1.1") == Version("1.1.2"))


# Generated at 2022-06-24 21:22:01.585018
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    result = version_0.__lt__(version_0)


# Generated at 2022-06-24 21:22:02.803614
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()


# Generated at 2022-06-24 21:22:04.187927
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_0._cmp(1)


# Generated at 2022-06-24 21:22:05.075715
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version('1.0')
    assert version_0 >= Version('0.99')


# Generated at 2022-06-24 21:22:08.493148
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    try:
        assert type(version_0.__eq__(Version())) is bool
    except:
        assert False

    try:
        assert not version_0.__eq__(Version())
    except:
        assert False


# Generated at 2022-06-24 21:22:14.021116
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    # Test for normal case where __lt__ returns an expected result
    try:
        assert version_0.__lt__(version_1) == NotImplemented
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-24 21:22:15.600657
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v0 = Version()
    v1 = Version()
    v0.__lt__(v1)


# Generated at 2022-06-24 21:23:19.102041
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 <= version_1


# Generated at 2022-06-24 21:23:23.104703
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    V = Version

    # Should raise a TypeError
    try:
        V() > V()
    except TypeError:
        pass
    else:
        raise AssertionError("Expected a TypeError exception")

try:
    Version
except:
    pass

if __name__ == '__main__':
    test_case_0()
    test_Version___gt__()

# Generated at 2022-06-24 21:23:24.929063
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    assert version_0 >= version_0


# Generated at 2022-06-24 21:23:29.423253
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_0._cmp = Version._cmp

    str_1 = '1.2.3'
    version_1 = Version(str_1)

    str_2 = '1.2.3a'
    version_2 = Version(str_2)

    result = version_1 <= version_2

    assert result == True


# Generated at 2022-06-24 21:23:33.337040
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version("1.0")
    assert version_0 < version_1
    # The following line will raise TypeError

# Generated at 2022-06-24 21:23:36.083219
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    vstr = '1'
    version_0_obj = version_0._cmp(vstr)
    assert version_0_obj < 0


# Generated at 2022-06-24 21:23:39.952965
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()

# Generated at 2022-06-24 21:23:41.939323
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert version_1.__gt__(version_0)


# Generated at 2022-06-24 21:23:44.080230
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    ret_val_2 = version_0.__eq__(None)

    assert ret_val_2 is NotImplemented


# Generated at 2022-06-24 21:23:46.570085
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    result = version_0.__ge__(version_1)


# Generated at 2022-06-24 21:26:25.165468
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert (version_0 == version_1)


# Generated at 2022-06-24 21:26:26.170166
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_case_0()


# Generated at 2022-06-24 21:26:29.574020
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_0.__eq__(version_1)


# Generated at 2022-06-24 21:26:30.624937
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_case_0()


# Generated at 2022-06-24 21:26:36.638773
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version('1.4.10')

    try:
        version_0.__lt__('1.4.1')
    except AttributeError:
        assert False

    try:
        version_0.__lt__('1.3.10')
    except AttributeError:
        assert False

    try:
        version_0.__lt__('1.4.10')
    except AttributeError:
        assert False

    try:
        version_0.__lt__('')
    except AttributeError:
        assert False

    try:
        version_0.__lt__('1.0.2pre')
    except AttributeError:
        assert False


# Generated at 2022-06-24 21:26:40.428820
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    assert version_0 < version_0
    assert version_0 < version_0
    assert version_0 < version_0
    assert version_0 < version_0
    assert version_0 < version_0


# Generated at 2022-06-24 21:26:47.545998
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    try:
        version_0.__lt__(version_1)
    except (AttributeError, TypeError) as exceptions_0:
        print('Expected:', exceptions_0)
    version_2 = Version()
    version_1.__class__ = type
    try:
        version_2.__lt__(version_1)
    except (AttributeError, TypeError) as exceptions_1:
        print('Expected:', exceptions_1)
    version_1.__class__ = Version


# Generated at 2022-06-24 21:26:49.376453
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 21:26:55.694409
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    
    assert (version_0 == None)
    

# Generated at 2022-06-24 21:26:59.052291
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    obj = Version()
    print(obj.__ge__('test_string'))
