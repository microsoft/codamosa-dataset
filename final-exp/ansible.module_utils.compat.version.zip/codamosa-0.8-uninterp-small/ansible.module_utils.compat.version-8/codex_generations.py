

# Generated at 2022-06-24 21:17:19.265711
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    result = version_0.__le__(version_2)
    assert (result == True)


# Generated at 2022-06-24 21:17:22.301655
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    s = StrictVersion()
    s.version = (0, 1, 2)
    s.prerelease = ('a', 2)
    assert str(s) == '0.1.2a2'


# Generated at 2022-06-24 21:17:30.736444
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import sys
    import pytest
    from distutils.version import StrictVersion

    # First, test the examples from the module doc string
    from distutils.version import StrictVersion

    s = StrictVersion
    examples = ['0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5',
                '0.9.6', '1.0', '1.0.4a3', '1.0.4b1', '1.0.4']

    for example in examples:
        # Test the StrictVersion instance matches the string
        v = s(example)
        assert str(v) == example

        # Test the string matches the StrictVersion instance
        v = s(example)
        assert v == example

    # Test the examples

# Generated at 2022-06-24 21:17:41.329302
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # from https://github.com/python/cpython/blob/v3.9.5/Lib/distutils/tests/test_version.py
    # version.py:576
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion('0')
    strict_version_2 = StrictVersion('1')
    strict_version_3 = StrictVersion('1')
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion('0')
    loose_version_2 = LooseVersion('1')

    # Test that the Version class is sane
    assert strict_version_0 == strict_version_0
    assert strict_version_0 == strict_version_1
    assert strict_version_0 == loose_version_0

# Generated at 2022-06-24 21:17:51.035990
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    version_0 = Version()

    # Check that None is invalid
    with pytest.raises(TypeError) as execinfo:
        version <= None
    assert 'Invalid comparison' in str(execinfo.value)

    # Check that different class is invalid
    with pytest.raises(TypeError) as execinfo:
        version <= strict_version_0
    assert 'Invalid comparison' in str(execinfo.value)

    # Check that comparison is invalid if _cmp returns NotImplemented
    version._cmp = lambda x: NotImplemented
    with pytest.raises(TypeError) as execinfo:
        version <= version_0
    assert 'Invalid comparison' in str(execinfo.value)

    # Check that a comparison is validated
    version._cmp = lambda x: 0
    assert version <= version_

# Generated at 2022-06-24 21:17:54.527575
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.2.3")
    if str(v) != "1.2.3":
        raise RuntimeError("test failed")


# Generated at 2022-06-24 21:18:02.576793
# Unit test for method __lt__ of class Version

# Generated at 2022-06-24 21:18:08.615670
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """Test method __str__ of class StrictVersion"""
    version_re = re.compile(r'^(\d+) \. (\d+) (\. (\d+))? ([ab](\d+))?$',
                            re.VERBOSE | re.ASCII)

    # Case 1: prerelease
    vstring = "0.5b3"
    match = version_re.match(vstring)
    if not match:
        raise ValueError("invalid version number '%s'" % vstring)

    (major, minor, patch, prerelease, prerelease_num) = \
        match.group(1, 2, 4, 5, 6)

    if patch:
        version = tuple(map(int, [major, minor, patch]))

# Generated at 2022-06-24 21:18:10.939191
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    lhs = StrictVersion(1)
    rhs = StrictVersion(1)
    rtn = lhs < rhs
    assert isinstance(rtn, bool)



# Generated at 2022-06-24 21:18:15.893490
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    version2 = Version()
    bool_ = version <= version2
    assert bool_ == True

    bool_ = version <= None
    assert bool_ == False

    version = StrictVersion()
    version2 = StrictVersion()
    bool_ = version <= version2
    assert bool_ == True

    bool_ = version <= None
    assert bool_ == False


# Generated at 2022-06-24 21:18:31.642104
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_0.parse("1")
    strict_version_1.parse("2")
    assert Version.__eq__(strict_version_0, strict_version_1) == False


# Generated at 2022-06-24 21:18:33.539255
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_0.parse('0.0')
    assert strict_version_0 > '0.0'


# Generated at 2022-06-24 21:18:39.651311
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_0.parse('')
    strict_version_1.parse('')
    tmp_var_3 = (strict_version_0 >= strict_version_1)
    print(tmp_var_3)
    tmp_var_3 = (strict_version_0 >= strict_version_1)
    print(tmp_var_3)



# Generated at 2022-06-24 21:18:42.070814
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert test_case_0() == 0

# Test class method __repr__ of class StrictVersion

# Generated at 2022-06-24 21:18:45.295287
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion('1')
    assert (strict_version_0 > strict_version_1) == False


# Generated at 2022-06-24 21:18:47.722284
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version().__gt__(Version())


# Generated at 2022-06-24 21:18:48.971415
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    strict_version_0 = StrictVersion()


# Generated at 2022-06-24 21:18:58.126327
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test if valid version numbers are parsed
    if LooseVersion().parse("1.1.1"):
        if LooseVersion().parse("1.1a2"):
            if LooseVersion().parse("1g"):
                if LooseVersion().parse("2"):
                    if LooseVersion().parse("1.1.0.1"):
                        if LooseVersion().parse("1.2.3a4.5"):
                            if LooseVersion().parse("1d1"):
                                if LooseVersion().parse("1"):
                                    return True
    else:
        return False
    return False


# Generated at 2022-06-24 21:19:01.738537
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion("1.0")
    strict_version_2 = StrictVersion("2.0")
    assert (strict_version_2 <= strict_version_1) == False
    assert (strict_version_1 <= strict_version_0) == False
    assert (strict_version_2 <= strict_version_0) == False
    assert (strict_version_2 <= strict_version_2) == True
    assert (strict_version_1 <= strict_version_2) == True


# Generated at 2022-06-24 21:19:04.080517
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    global strict_version_0
    strict_version_0 = StrictVersion()
    print(strict_version_0)


# Generated at 2022-06-24 21:19:19.660912
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    print('Test Version')
    print('Test method __eq__')
    print('No test yet')
    print('Test end')


# Generated at 2022-06-24 21:19:26.086186
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = StrictVersion()
    assert strict_version_0.__le__(None) == NotImplemented
    assert strict_version_0.__le__(0) == NotImplemented
    assert strict_version_0.__le__(NotImplemented) == NotImplemented


# Generated at 2022-06-24 21:19:27.612022
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__() == NotImplemented


# Generated at 2022-06-24 21:19:29.467597
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = StrictVersion()
    x = 1
    # SUT
    if (strict_version_0 <= x):
        pass


# Generated at 2022-06-24 21:19:40.499267
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import unittest

    class StubStrictVersion(StrictVersion):

        def __init__(self, version, prerelease = None):
            self.version = version
            self.prerelease = prerelease

    class Test(unittest.TestCase):

        def test___str__(self):
            version = (0, 1, 2)
            prerelease = ('a', 3)
            strict_version = StubStrictVersion(version, prerelease)
            s = str(strict_version)
            self.assertEqual(s, "0.1.2a3")
            version = (0, 1)
            strict_version = StubStrictVersion(version)
            s = str(strict_version)
            self.assertEqual(s, "0.1.0")


# Generated at 2022-06-24 21:19:44.868459
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    cases = [
        test_case_0
    ]

    for test_case in cases:
        test_case()


# Generated at 2022-06-24 21:19:46.754958
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = StrictVersion()
    assert strict_version_0 <= '0'


# Generated at 2022-06-24 21:19:47.858717
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert(Version() == Version())


# Generated at 2022-06-24 21:19:55.707561
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert StrictVersion('1.1.1') >= '1.1.1'
    assert not StrictVersion('1.1.1') >= StrictVersion('2.1.1')
    assert not StrictVersion('9.5.5') >= '9.5.8'
    assert StrictVersion('10.0.0') >= '9.9.9'
    assert not LooseVersion('1.1.1') >= StrictVersion('2.1.1')
    assert not LooseVersion('9.5.5') >= StrictVersion('9.5.8')
    assert LooseVersion('10.0.0') >= StrictVersion('9.9.9')


# Generated at 2022-06-24 21:19:58.193578
# Unit test for method __le__ of class Version
def test_Version___le__():
    _StrictVersion = StrictVersion
    strict_version_0 = _StrictVersion("0122.000")
    version_0 = strict_version_0
    # assert version_0 <= version_0


# Generated at 2022-06-24 21:20:18.393668
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    assert not strict_version_0.__gt__(str(strict_version_0))


# Generated at 2022-06-24 21:20:22.977474
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    # TypeError is raised because 'other' is of wrong type
    try:
        other = 'a'
        strict_version_0.__gt__(other)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')
    # TypeError is raised because 'other' is of wrong type
    try:
        other = 'a'
        strict_version_0.__gt__(other)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')


# Generated at 2022-06-24 21:20:24.768963
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    try:
        instance1 = Version()
        instance2 = Version()
        result = instance1.__lt__(instance2)
        assert False, "Version.__lt__: expected an exception"
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:20:27.423674
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    v = strict_version_0.__gt__(strict_version_1)
    assert v == False


# Generated at 2022-06-24 21:20:32.622455
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion('0.0a.fsf')
    assert 0 < strict_version_0
    assert not (1 < strict_version_0)


# Generated at 2022-06-24 21:20:34.645534
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    vc = StrictVersion()
    vc.parse("1.5")
    assert str(vc) == "1.5"


# Generated at 2022-06-24 21:20:36.991751
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # case 0: no string set
    strict_version_0 = StrictVersion()
    # str(strict_version_0) == '0.0.0'


# Generated at 2022-06-24 21:20:47.359613
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.0').__eq__(Version('1.0')) == True
    assert Version('1.0').__eq__(Version('1.1')) == False
    assert Version('1.0').__eq__(Version('2.0')) == False
    assert Version('2.0').__eq__(1) == False
    assert Version('1.0').__eq__(StrictVersion('1.0')) == True
    assert Version('1.0').__eq__(StrictVersion('1.1')) == False
    assert Version('1.0').__eq__(LooseVersion('1.0')) == True
    assert Version('1.0').__eq__(LooseVersion('1.1')) == False

# Generated at 2022-06-24 21:20:48.482057
# Unit test for method __gt__ of class Version

# Generated at 2022-06-24 21:20:50.212364
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert False == (v1 > v2)


# Generated at 2022-06-24 21:21:04.479243
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    strict_version_0 = StrictVersion()

    strict_version_1 = StrictVersion()
    try:
        strict_version_0._cmp(strict_version_1)
    except (AttributeError, TypeError):
        return

    assert False


# Generated at 2022-06-24 21:21:10.232959
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    strict_version_1 = StrictVersion()
    strict_version_2 = StrictVersion()
    ret = strict_version_1 < strict_version_2
    assert ret == False


# Generated at 2022-06-24 21:21:20.282933
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from ansible.module_utils.common.version import Version, _Version
    from ansible.module_utils.common.version import StrictVersion, LooseVersion
    test_cases = (
        (
            '__lt__',
            {
                'args': [
                    {
                        'other': (
                            Version(),
                        ),
                    },
                ],
                'result': False,
            }
        ),
    )

    for test_case in test_cases:
        method_name, params = test_case[0], test_case[1]
        method = getattr(Version, method_name)
        args = params['args']
        result = params['result']

        res = method(*args)
        assert res == result


# Generated at 2022-06-24 21:21:23.036911
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_0.parse('4.9.9.1')
    version_1.parse('4.9.9.1')
    assert version_0 == version_1


# Generated at 2022-06-24 21:21:24.373467
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    print(LooseVersion('1.2a2').parse('1.2a2') == LooseVersion('1.2a2'))


# Generated at 2022-06-24 21:21:28.350494
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Set up objects used in test.
    strict_version_0 = StrictVersion()
    # Set up environment for test.
    other = 'a'
    # Execute Function under test
    result = strict_version_0 < other
    # Verify state of test environment
    assert result == False



# Generated at 2022-06-24 21:21:39.005193
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    assert StrictVersion('0.4').parse('0.4') == None
    assert StrictVersion('0.4').parse('0.4.0') == None
    assert StrictVersion('0.4').parse('0.4') == None
    assert StrictVersion('0.4').parse('0.4.0') == None
    assert StrictVersion('0.4.1').parse('0.4.1') == None
    assert StrictVersion('0.5a1').parse('0.5a1') == None
    assert StrictVersion('0.5b3').parse('0.5b3') == None
    assert StrictVersion('0.5').parse('0.5') == None
    assert StrictVersion('0.9.6').parse('0.9.6') == None

# Generated at 2022-06-24 21:21:41.780534
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    ver_0 = Version()
    ver_1 = Version()
    if (ver_0 == ver_1):
        pass
    else:
        raise RuntimeError("")


# Generated at 2022-06-24 21:21:44.519886
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    expr = 'StrictVersion() < StrictVersion()'
    expected = False
    actual = StrictVersion() < StrictVersion()
    assert actual == expected


# Generated at 2022-06-24 21:21:45.282359
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert test_case_0() == True


# Generated at 2022-06-24 21:21:56.409013
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version = StrictVersion('1.0')
    assert strict_version == StrictVersion('1.0')


# Generated at 2022-06-24 21:22:00.654763
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version_0 = StrictVersion()
    strict_version_0.parse('1.2.3a1')
    assert strict_version_0.__str__() == '1.2.3a1'


# Generated at 2022-06-24 21:22:04.919819
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """strict_version_0 = StrictVersion()
    if str(strict_version_0) == '0.0.0':
        print('Test passed')
    else:
        print('Test failed')
    """
    assert str(StrictVersion()) == '0.0.0'

# Generated at 2022-06-24 21:22:07.350835
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version_0 = StrictVersion('0.1.2')
    assert str(strict_version_0) == '0.1.2'


# Generated at 2022-06-24 21:22:10.745057
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    c = Version("1.0.0")
    d = Version("1.0.2")
    if not ((c == d) == (c._cmp(d) == 0)):
        raise AssertionError("%s" % str((c == d)))


# Generated at 2022-06-24 21:22:13.655902
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Initialize a Version instance for testing
    strict_version_0 = StrictVersion(vstring_0)

    # Test method
    string_0 = strict_version_0.__eq__(strict_version_0)


# Generated at 2022-06-24 21:22:14.954683
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    Version__eq__strict_version_0 = strict_version_0.__eq__(1)


# Generated at 2022-06-24 21:22:23.563658
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    strict_version_0 = StrictVersion()
    version_1 = Version()
    version_2 = Version()
    strict_version_3 = StrictVersion()
    try:
        version_1 < version_2
    except:
        pass
    try:
        version_1 < strict_version_0
    except:
        pass
    try:
        version_1 < strict_version_3
    except:
        pass
    try:
        strict_version_3 < version_2
    except:
        pass


# Generated at 2022-06-24 21:22:33.557949
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import random
    import sys
    import math

    # Setup
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion('1.2.3rc1')
    random_seed = random.getrandbits(64)

    for count in range(100):
        # Setup
        if count % 2:
            version_number = str(random.randint(1, 2147483647))
        else:
            version_number = str(random.random())
        strict_version_2 = StrictVersion(version_number)
        strict_version_3 = StrictVersion(version_number)
        strict_version_4 = StrictVersion()
        strict_version_5 = StrictVersion('1.2.3rc1')

        # Exercise and verify

# Generated at 2022-06-24 21:22:36.491062
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    version._cmp = lambda other: 1
    assert version.__lt__(1) == False
    assert version.__lt__(None) is NotImplemented


# Generated at 2022-06-24 21:22:50.861516
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version()


# Generated at 2022-06-24 21:22:53.957535
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    try:
        assert (strict_version_0 != strict_version_1)
    except AssertionError:
        print("AssertionError raised")


# Generated at 2022-06-24 21:22:57.180407
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    # test for method __eq__ (line 11)
    try:
        test_case_0()
    except:
        print("Test Case Failed " + "test_case_0()")



# Generated at 2022-06-24 21:22:59.787740
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ver1 = StrictVersion("1.2.3a0")
    ver2 = StrictVersion("1.2.3c0")
    succ = ver1 < ver2


# Generated at 2022-06-24 21:23:01.139902
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert StrictVersion(vstring="0.0.0") < StrictVersion(vstring="1.1.1")


# Generated at 2022-06-24 21:23:05.781980
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    strict_version_0 = StrictVersion('1.0.0')
    str_0 = str(strict_version_0)



# Generated at 2022-06-24 21:23:15.254747
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:23:22.757244
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_obj_0 = Version()
    version_obj_1 = Version()
    version_obj_2 = Version()
    version_obj_3 = Version()
    version_obj_4 = Version()
    version_obj_5 = Version()
    version_obj_6 = Version()
    version_obj_7 = Version()
    version_obj_8 = Version()
    version_obj_9 = Version()
    version_obj_10 = Version()
    version_obj_11 = Version()
    version_obj_12 = Version()
    version_obj_13 = Version()
    version_obj_14 = Version()
    version_obj_15 = Version()
    version_obj_16 = Version()
    version_obj_17 = Version()
    version_obj_18 = Version()
    version_obj_19 = Version()

# Generated at 2022-06-24 21:23:27.272623
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    if (StrictVersion().__lt__(StrictVersion())):
        raise RuntimeError("Test 0__lt__ failed")
    if (not StrictVersion().__lt__(StrictVersion())):
        raise RuntimeError("Test 1__lt__ failed")


# Generated at 2022-06-24 21:23:29.761594
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = StrictVersion('1.2.0')
    v2 = StrictVersion('1.2.1-rc2')
    v1_lt_v2 = v1.__lt__(v2)



# Generated at 2022-06-24 21:23:59.856186
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Create a version number object
    v = LooseVersion()
    # Create a version number string
    v_str = '1.0'
    # Call parse on the value of the string
    v.parse(v_str)


# Generated at 2022-06-24 21:24:02.166702
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version_string = "1.2a3"
    version_0 = LooseVersion(version_string)
    version_0.parse(version_string)


# Generated at 2022-06-24 21:24:10.193538
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion('1.2.3')
    print (v.version)
    assert v.version == ['1', '2', '3']
    assert v.vstring == '1.2.3'

    v = LooseVersion('1.2.3a')
    print (v.version)
    assert v.version == ['1', '2', '3', 'a']
    assert v.vstring == '1.2.3a'


# Generated at 2022-06-24 21:24:16.751870
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    for vstring in ['0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5', '0.9.6', '1.0',
                    '1.0.4a3', '1.0.4b1', '1.0.4', '1.0.4rc2', '1.0.4c1']:
        ver = LooseVersion(vstring)
        assert str(ver) == vstring



# Generated at 2022-06-24 21:24:20.695503
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    # Test with arg '2.2beta29'
    # Test with arg '1.5.2b2'
    # Test with arg '2.2beta2'



# Generated at 2022-06-24 21:24:22.843821
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v0 = LooseVersion()
    v0.parse('1.5.2b2')

# Generated at 2022-06-24 21:24:29.012459
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.2.1')
    assert lv.version == ['1', '2', '1']
    lv.parse('1.2.1a1')
    assert lv.version == ['1', '2', '1a1']
    lv.parse('1.2b2')
    assert lv.version == ['1', '2b2']
    lv.parse('1c3')
    assert lv.version == ['1c3']



# Generated at 2022-06-24 21:24:35.135750
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import re
    assert LooseVersion('1.13++').version == [1, '13', '+']
    assert LooseVersion('1.2.0').version == [1, 2, 0]
    assert LooseVersion('1.2.1.0').version == [1, 2, 1, 0]
    assert LooseVersion('1.2.3final').version == [1, 2, '3final']


# Generated at 2022-06-24 21:24:42.885744
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Return the version string from a string
    lv = LooseVersion
    assert str(lv("1.2.3")) == "1.2.3"
    assert str(lv("1.2")) == "1.2"
    assert str(lv("1.2b3")) == "1.2b3"
    assert str(lv("1.2.dev")) == "1.2.dev"
    # Allow - in versions
    assert str(lv("1.2a3-1")) == "1.2a3-1"
    # '0' is a valid version
    assert str(lv('0')) == "0"
    # Check for invalid versions
    raises (ValueError, lv, "Not valid")
    # Check that leading zeros are rejected
    raises (ValueError, lv, '1.02')

# Generated at 2022-06-24 21:24:50.181572
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test for method parse (p0) of class LooseVersion
    # Test with no parameters
    lv0 = LooseVersion()
    lv0.parse('1.2.3.4')
    assert lv0.version == [1, 2, 3, 4], 'returned %s instead of [1, 2, 3, 4]' % lv0.version

# Test for method parse (p1) of class LooseVersion



# Generated at 2022-06-24 21:25:21.644741
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Check that a call to parse with no arguments results in a valid
    # object
    #
    loose_version_0 = LooseVersion()
    assert(isinstance(loose_version_0, LooseVersion))


# Generated at 2022-06-24 21:25:25.903680
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv_0 = LooseVersion()
    lv_0.parse("1.2.3.4a5")
    assert lv_0.version == [1, 2, 3, 4, 'a', 5]


# Generated at 2022-06-24 21:25:36.128675
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse('1.13++')
    assert(v.vstring == '1.13++')

if __name__ == '__main__':
    test_case_0()
    test_LooseVersion_parse()
    print('running')

# Generated at 2022-06-24 21:25:43.017655
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Create version number components
    components = [0, 1, 2, 4]

    # Create version number with components
    v_1 = LooseVersion()
    v_1.parse('.'.join(map(str, components)))

    # Create version number with string
    v_2 = LooseVersion('.'.join(map(str, components)))

    # Compare version numbers
    assert v_1.version == v_2.version


# Generated at 2022-06-24 21:25:44.447364
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    strict_version_0 = StrictVersion()
    strict_version_0.parse("0")


# Generated at 2022-06-24 21:25:52.703293
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse('2.2alpha2')
    assert v.version == ['2', '2', 'alpha', '2']
    v.parse('2.2alpha2.1')
    assert v.version == ['2', '2', 'alpha', '2', '1']
    v.parse('2.2beta2')
    assert v.version == ['2', '2', 'beta', '2']
    v.parse('2.2beta2.1')
    assert v.version == ['2', '2', 'beta', '2', '1']


# Generated at 2022-06-24 21:26:02.518845
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Create the following instances of LooseVersion
    vstring_0 = '1.14'
    loose_version_0 = LooseVersion()
    loose_version_0.parse(vstring_0)
    vstring_1 = '1.15'
    loose_version_1 = LooseVersion()
    loose_version_1.parse(vstring_1)
    vstring_2 = '1.13'
    loose_version_2 = LooseVersion()
    loose_version_2.parse(vstring_2)
    vstring_3 = '1.14.0'
    loose_version_3 = LooseVersion()
    loose_version_3.parse(vstring_3)
    vstring_4 = '1.14.1'
    loose_version_4 = LooseVersion()
    loose_version

# Generated at 2022-06-24 21:26:13.607304
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion
    lv_v_strs = [
        'a.b',
        '1.2.3',
        '1.2.3.4',
        '1.2.3.4b5',
        '1.2.3.4c5',
        '1.2.3.4c15',
        '1.2.3.4rc5',
        '1.2.3.4.post5',
        '1.2.3.4.rc5',
        '1.2.3.4.dev5',
        '1.2.3.4.a5',
        '1.2.3.4.b5',
        '1.2.3.4.c5',
    ]

# Generated at 2022-06-24 21:26:18.749500
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    vnum = '1.1.2.3'
    lv = LooseVersion()
    lv.parse(vnum)
    assert lv.version == ['1', '1', '2', '3']


# Generated at 2022-06-24 21:26:30.450536
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    print('test_LooseVersion_parse')
    # Initialize the parser.
    parser = LooseVersion()
    # Capture the result.
    ver = parser.parse("1.5.1")
    # Verify the result.
    assert type(ver) == tuple, "version string should be parsed into a tuple."
    assert ver[0] == 1, "first element should be 1"
    assert ver[1] == 5, "second element should be 5"
    assert ver[2] == 1, "third element should be 1"
    # Capture the result.
    ver = parser.parse("1.5.2b2")
    # Verify the result.
    assert type(ver) == tuple, "version string should be parsed into a tuple."
    assert ver[0] == 1, "first element should be 1"

# Generated at 2022-06-24 21:27:00.961115
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    version_string = '12.65.A.43'
    lv.parse(version_string)
    assert lv.version == [12, 65, 'A', 43]
    assert lv.vstring == '12.65.A.43'


# Generated at 2022-06-24 21:27:10.778706
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test cases
    # Inputs
    #   arg1 = vstring
    # Outputs: none
    # Expected result: none
    test_cases = {
        '1.2.1' : None,
        '1.2.2a2' : None,
        '1.2.2' : None,
        '1.2.2pl3' : None,
        '2g6' : None,
        '1.13++' : None,
        '5.5.kw' : None,
        '2.0b1pl0' : None
    }

    # Perform test