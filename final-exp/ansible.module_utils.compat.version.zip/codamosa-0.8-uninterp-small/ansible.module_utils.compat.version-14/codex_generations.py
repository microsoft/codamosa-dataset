

# Generated at 2022-06-24 21:17:27.833979
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import unittest

    class Test_StrictVersion_parse(unittest.TestCase):

        def test_case_0(self):
            try:
                StrictVersion().parse(None)
            except ValueError as e:
                assert(str(e) == 'invalid version number')
            else:
                assert(False)

        def test_case_1(self):
            assert(StrictVersion().parse('2').version == (2, 0, 0))
            assert(StrictVersion().parse('1.1').version == (1, 1, 0))
            assert(StrictVersion().parse('1.1.1').version == (1, 1, 1))
            assert(StrictVersion().parse('0.0.0').version == (0, 0, 0))

# Generated at 2022-06-24 21:17:31.480986
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  strict_version_0 = StrictVersion('5.5.5a5')
  loose_version_0 = LooseVersion()
  assert loose_version_0.__lt__(strict_version_0) == False


# Generated at 2022-06-24 21:17:33.500287
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.6')
    assert str(v) == '1.6'


# Generated at 2022-06-24 21:17:37.343937
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert not strict_version_0.__str__()
    assert strict_version_0.__str__() != strict_version_1.__str__()
    assert strict_version_0.__str__() == strict_version_2.__str__()


# Generated at 2022-06-24 21:17:45.097917
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Unit test for method __ge__ of class Version

    test case for __ge__
    """

    v1 = Version('1.3')
    v2 = Version('1.3')

    try:
        if not (v1 >= v2):
            raise AssertionError("Version__ge__ test #0 failed")
    except AssertionError as e:
        e.args += ("Version__ge__ test #0 failed: %s" % str(e),)
        raise

    print("Version__ge__ test #0 passed")


# Generated at 2022-06-24 21:17:49.265362
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = LooseVersion("1.0.0")
    v2 = LooseVersion("1.0.0")
    v3 = LooseVersion("1.0.0")
    assert(v2 >= v1)
    assert(v1 >= v1)
    assert(v2 >= v2)
    assert(v3 >= v1)
    assert(v3 >= v2)
    assert(v2 >= v3)


# Generated at 2022-06-24 21:17:53.453628
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Source object
    vstring = '6.5.0'
    obj_expected = StrictVersion(vstring)

    # Check
    assert str(obj_expected) == vstring


# Generated at 2022-06-24 21:18:00.275602
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_1 = LooseVersion()
    loose_version_1._cmp = lambda another: -1
    assert(not loose_version_1 <= "1.2.3")

    loose_version_2 = LooseVersion()
    loose_version_2._cmp = lambda another: 0
    assert(loose_version_2 <= "1.2.3")

    loose_version_3 = LooseVersion()
    loose_version_3._cmp = lambda another: 1
    assert(not loose_version_3 <= "1.2.3")

    loose_version_4 = LooseVersion()
    loose_version_4._cmp = lambda another: NotImplemented
    assert(loose_version_4 <= "1.2.3")


# Generated at 2022-06-24 21:18:06.781697
# Unit test for method __le__ of class Version
def test_Version___le__():
    vs1 = LooseVersion('1.2.2.0')
    vs2 = LooseVersion('1.2.2.0')
    vs3 = LooseVersion('1.2.3.0')
    vs4 = LooseVersion('1.2.2.1')
    vs5 = LooseVersion('1.3.0.0')
    vs6 = LooseVersion('2.0.0.0')

    assert(vs1 <= vs2), '%s should be less than or equal to %s' % (vs1, vs2)
    assert(vs1 < vs3), '%s should be less than or equal to %s' % (vs1, vs3)
    assert(vs1 < vs4), '%s should be less than or equal to %s' % (vs1, vs4)

# Generated at 2022-06-24 21:18:10.515370
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    a1 = StrictVersion()
    a1.parse("1")

    try:
        a2 = StrictVersion()
        a2.parse("2.7.2.2")
    except ValueError:
        pass

    a3 = StrictVersion()
    a3.parse("1.3.a4")

    a4 = StrictVersion()
    a4.parse("1.3pl1")

    a5 = StrictVersion()
    a5.parse("1.3c4")


# Generated at 2022-06-24 21:18:20.356796
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_0 = LooseVersion("1.6.1")
    loose_version_1 = LooseVersion("2.0.0")

    if (not (loose_version_0 > loose_version_1)):
        raise RuntimeError("Test failure")


# Generated at 2022-06-24 21:18:24.112301
# Unit test for method __le__ of class Version
def test_Version___le__():
    class SubVersion(Version):
        def _cmp(self, other):
            return 1

    assert SubVersion() <= SubVersion()
    assert SubVersion() <= Version()
    assert SubVersion() <= '1'


# Generated at 2022-06-24 21:18:27.265220
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion()
    assert loose_version_0 == loose_version_1


# Generated at 2022-06-24 21:18:29.033636
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    x = version.__gt__(1)


# Generated at 2022-06-24 21:18:30.679412
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Imports
    from distutils.version import Version
    
    # Setup
    v = Version()
    
    # Testing
    v == None
    v >= None
    v <= None
    v > None
    v < None
    
    # Cleanup
    # N/A


# Generated at 2022-06-24 21:18:35.239998
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion()
    assert loose_version_0 >= loose_version_1


# Generated at 2022-06-24 21:18:37.439300
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version(vstring=None).__eq__(Version(vstring=None))


# Generated at 2022-06-24 21:18:43.412483
# Unit test for method __le__ of class Version
def test_Version___le__():

    # Set up locals
    vstring = None

    # Call the __init__ method of the class 'Version'
    v = Version(vstring)

    # Call method __le__ of class 'Version'
    return v.__le__(None)



# Generated at 2022-06-24 21:18:49.382009
# Unit test for method __le__ of class Version
def test_Version___le__():

    try:
        loose_version_0 = LooseVersion()
    except AttributeError:
        pass

    try:
        strict_version_0 = StrictVersion()
    except AttributeError:
        pass

    try:
        loose_version_1 = LooseVersion()
    except AttributeError:
        pass

    try:
        strict_version_1 = StrictVersion()
    except AttributeError:
        pass

    try:
        loose_version_2 = LooseVersion()
    except AttributeError:
        pass

    try:
        strict_version_2 = StrictVersion()
    except AttributeError:
        pass

    try:
        loose_version_3 = LooseVersion()
    except AttributeError:
        pass


# Generated at 2022-06-24 21:18:51.407182
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    loose_version_0 = LooseVersion('3.141.0')
    loose_version_1 = LooseVersion()
    loose_version_0._cmp(loose_version_1)



# Generated at 2022-06-24 21:19:09.877574
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    version._cmp = lambda x, y: 0
    assert version <= None

    version = Version()
    version._cmp = lambda x, y: 1
    assert not version <= None

    version = Version()
    version._cmp = lambda x, y: -1
    assert version <= None


# Generated at 2022-06-24 21:19:11.271003
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert(v >= v)
    assert(not (v >= 1))


# Generated at 2022-06-24 21:19:21.330516
# Unit test for method __le__ of class Version
def test_Version___le__():
    module = sys.modules['ansible.module_utils._text']
    module = imp.reload(module)

    v0 = module.Version()
    v1 = module.LooseVersion()
    v2 = module.StrictVersion()

    # v1 <= v2
    # v1 == v2
    # v2 <= v2
    result = v1 <= v2
    assert result is True
    result = v1 == v2
    assert result is True
    result = v2 <= v2
    assert result is True

    # v0 <= v1
    # v1 <= v0
    result = v0 <= v1
    assert result is True
    result = v1 <= v0
    assert result is False

    # v2 <= v1
    result = v2 <= v1
    assert result is False

    #

# Generated at 2022-06-24 21:19:30.398624
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert(LooseVersion('1.1') >= LooseVersion('1.1'))
    assert(LooseVersion('1.1') >= LooseVersion('1.1.0'))
    assert(not (LooseVersion('1.1') >= LooseVersion('1.1.0.0')))
    assert(not (LooseVersion('1.1') >= LooseVersion('1.1.1')))
    assert(not (LooseVersion('1.1') >= LooseVersion('1.2')))
    assert(LooseVersion('1.1') >= LooseVersion('1.1-0'))
    assert(not (LooseVersion('1.1') >= LooseVersion('1.1.0-0')))

# Generated at 2022-06-24 21:19:40.697571
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from pytest import raises
    # Call function and test the result. Here we only test that the result is True
    try:
        assert Version.__eq__(test_case_0(), test_case_0()) == 0
    except TypeError as e:
        raise TypeError(e)
    else:
        pass
    # Call function with other parameter types and test the result. Here we test that the result is False
    try:
        assert Version.__eq__(test_case_0(), test_case_0()) != None
    except TypeError as e:
        raise TypeError(e)
    else:
        pass
    # Call function with non standard parameter types
    with raises(TypeError):
        Version.__eq__(test_case_0(), " ", " ", " ")
    # Call function with a parameter value below the minimum accepted

# Generated at 2022-06-24 21:19:44.627742
# Unit test for method __le__ of class Version
def test_Version___le__():
    ver_0 = Version()
    str_0 = ver_0.__le__(int())


# Generated at 2022-06-24 21:19:46.945096
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version("1.2.3")
    version2 = Version("1.2.2")
    assert version > version2


# Generated at 2022-06-24 21:19:52.476248
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_0 = LooseVersion()
    loose_version_2 = LooseVersion()
    with pytest.raises(UnboundLocalError):
        if (loose_version_0 > loose_version_2):
            pass
    loose_version_1 = LooseVersion()
    loose_version_2 = LooseVersion()
    pytest.assume((loose_version_1 > loose_version_2) == False)


# Generated at 2022-06-24 21:19:57.789679
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_name = "LooseVersion___eq__"

    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion('1.2rc3')

    try:
        if (loose_version_0 == loose_version_1) != False:
            return test_name + ": Failed"
    except:
        return test_name + ": Failed"

    return test_name + ": Passed"



# Generated at 2022-06-24 21:20:05.972952
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    cases = [
        (
            (
                loose_version_0,
                0,
            ),
            True,
        ),
        (
            (
                loose_version_0,
                NotImplemented,
            ),
            False,
        ),
    ]
    for args, expected in cases:
        with testing.Trace(trace_path, trace_args=args, trace_expected=expected):
            result = loose_version_0.__ge__(*args)
            testing.assert_equal(result, expected)


# Generated at 2022-06-24 21:20:17.028142
# Unit test for method __le__ of class Version
def test_Version___le__():
    """__le__(other)"""
    from distutils.version import Version,LooseVersion

    v = Version('0.4.1')
    v1 = Version('0.4.1')
    v2 = Version('0.4.2')
    v3 = Version('0.5')
    v4 = Version('0.4.1pre')
    v5 = Version('0.4.1pre')
    v6 = Version('0.4.1pre1')
    assert v <= v1
    assert v <= v2
    assert v <= v3
    assert v <= v4
    assert v <= v5
    assert v < v6


# Generated at 2022-06-24 21:20:18.615710
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    VERSION_TESTCASE_0 = Version()
    VERSION_TESTCASE_0.__gt__(0)


# Generated at 2022-06-24 21:20:20.754150
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion()
    bool_0 = loose_version_0 <= loose_version_1
    assert bool_0 == True
    bool_1 = loose_version_0 <= '2'
    assert bool_1 == True


# Generated at 2022-06-24 21:20:21.430343
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version() == ""



# Generated at 2022-06-24 21:20:25.240200
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert LooseVersion() == '0.0.0'


# Generated at 2022-06-24 21:20:28.312309
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v0 = Version()
    v1 = Version()
    Result = v0.__gt__(v1)
    # Check that Result is a bool
    assert isinstance(Result, bool)
    # Check that Result is True or False
    assert Result == (not False) or (not True)


# Generated at 2022-06-24 21:20:29.421387
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_0 = LooseVersion()
    ExpectedException = Exception
    with pytest.raises(ExpectedException):
        assert (loose_version_0.__gt__())


# Generated at 2022-06-24 21:20:38.262436
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import pytest

    @pytest.mark.parametrize(
        ('other', 'expected'),
        [
            (NotImplemented, NotImplemented),
            ('2.0.0', 1),
            ('1.0.0', 0),
            ('0.9.9', -1),
        ]
    )
    def test_Version(other, expected):
        from ansible.module_utils.version import Version
        loose_version_0 = LooseVersion()
        with pytest.raises(NotImplementedError):
            class Version(Version):
                def _cmp(self, other):
                    raise NotImplementedError()

        # test for 'other' is NotImplemented
        if other is NotImplemented:
            with pytest.raises(ValueError):
                loose_version_

# Generated at 2022-06-24 21:20:41.357029
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_1 = LooseVersion("0.1")
    loose_version_0 = LooseVersion("0.0")

    assert(not loose_version_1 > loose_version_0)
    assert(not loose_version_1 > "0.1")


# Generated at 2022-06-24 21:20:43.330652
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    if (test_case_0.loose_version_0.__gt__("var5")):
        raise RuntimeError("test_Version___gt__ failed")


# Generated at 2022-06-24 21:20:49.241890
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_0 = LooseVersion()
    # NOTE: the following line is not a test
    # it may be used as a way to get coverage of Version.__gt__
    loose_version_0.__gt__('1.1.0')


# Generated at 2022-06-24 21:20:55.489662
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    class SubVersion(Version):
        pass

    inst_0 = SubVersion()
    inst_1 = Version()
    inst_2 = Version()
    inst_3 = SubVersion()

    for version in [inst_0, inst_1, inst_2, inst_3]:
        assert version > version

    assert inst_0 < inst_3


# Generated at 2022-06-24 21:20:57.330322
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    assert loose_version_0.__eq__(loose_version_0)


# Generated at 2022-06-24 21:21:06.275904
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # default case
    loose_version_0 = LooseVersion()
    assert loose_version_0 == "1.0"
    # decimal case
    loose_version_1 = LooseVersion()
    assert loose_version_1 == "1.2"
    # default case
    strict_version_0 = StrictVersion()
    assert strict_version_0 == "1.0"
    # decimal case
    strict_version_1 = StrictVersion()
    assert strict_version_1 == "1.2"
    # octal case
    strict_version_2 = StrictVersion()
    assert strict_version_2 == "01.2"
    # hex case
    strict_version_3 = StrictVersion()
    assert strict_version_3 == "0x1.2"
    # binary case
    strict_version_

# Generated at 2022-06-24 21:21:10.533619
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = StrictVersion()
    v2 = StrictVersion()
    v3 = v1 == v2


# Generated at 2022-06-24 21:21:12.977773
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()
    assert isinstance((loose_version_0 <= None), bool)


# Generated at 2022-06-24 21:21:19.656562
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest

    class Version___gt__TestCase(unittest.TestCase):
        def test_0(self):
            loose_version_0 = LooseVersion()
            loose_version_1 = '1.0'
            if (loose_version_0 > loose_version_1):
                raise AssertionError("loose_version_0 > loose_version_1")

    unittest.main()


# Generated at 2022-06-24 21:21:22.509599
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    if ((LooseVersion() == LooseVersion()) == True):
        if (LooseVersion('1') != LooseVersion('2')):
            return 0
    return 1


# Generated at 2022-06-24 21:21:29.396616
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_2 = LooseVersion(None)
    strict_version_2 = StrictVersion(None)
    try:
        assert loose_version_2.__gt__(strict_version_2) == False
        assert loose_version_2.__gt__(strict_version_2) == False
    except AssertionError:
        raise AssertionError(loose_version_2.__gt__(strict_version_2))



# Generated at 2022-06-24 21:21:32.580371
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()
    assert loose_version_0 <= "1"
    assert loose_version_0 <= 0


# Generated at 2022-06-24 21:21:36.955186
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """__eq__(self, other)"""
    pass


# Generated at 2022-06-24 21:21:48.693778
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    s = '3.1.1.6'
    v = LooseVersion(s)
    v.parse(s)
    # Test for 'if len(c) > 1' in method parse
    import re
    v.parse("3.1.1.6")
    v.parse("3.1.1.6a")
    v.parse("3.1.1.6b")
    v.parse("3.1.1.6c")
    v.parse("3.1.1.6d")
    v.parse("3.1.1.6e")
    v.parse("3.1.1.6f")
    v.parse("3.1.1.6g")
    v.parse("3.1.1.6h")

# Generated at 2022-06-24 21:21:50.817795
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    v1 = Version()
    v2 = Version()
    assert v1 == v2


# Generated at 2022-06-24 21:21:58.080764
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_0 = test_case_0()
    os_version_0 = LooseVersion('2.7')
    # Try to use os.version to compare against a LooseVersion
    assert(os.version < os_version_0)
    # Try to compare a StrictVersion against a LooseVersion
    assert(StrictVersion('2.7.9') > os_version_0)
    assert(StrictVersion('2.8') > os_version_0)
    assert(StrictVersion('2.7.9') < os_version_0)


# Generated at 2022-06-24 21:22:03.851477
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()
    class_0 = Version()
    loose_version_0 = LooseVersion()
    class_0 = Version()

# Generated at 2022-06-24 21:22:07.005880
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_1 = LooseVersion('1.2.3')
    loose_version_2 = LooseVersion('1.2.3')
    assert(loose_version_1 == loose_version_2)


# Generated at 2022-06-24 21:22:16.662042
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    loose_version_0 = Version()
    loose_version_0 = Version(None)
    loose_version_0 = Version('')
    loose_version_1 = StrictVersion('')
    loose_version_1 = StrictVersion(None)
    loose_version_1 = Version('hello')
    loose_version_1 = Version('/')
    loose_version_1 = Version('0.0.0')
    loose_version_1 = Version('0.0.a')
    loose_version_1 = Version('a.b.c')
    loose_version_1 = Version('1.1.1')


# Generated at 2022-06-24 21:22:21.382257
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    test_LooseVersion = LooseVersion()
    test_LooseVersion.parse('abcd')


# Generated at 2022-06-24 21:22:22.039759
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version() == Version()



# Generated at 2022-06-24 21:22:23.613696
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Test method __le__ of class Version"""
    loose_version_0 = LooseVersion()
    assert loose_version_0 <= None


# Generated at 2022-06-24 21:22:29.296722
# Unit test for method __le__ of class Version
def test_Version___le__():
    test_case_0()


# Generated at 2022-06-24 21:22:33.119415
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion(str(loose_version_0))
    if (loose_version_0 != loose_version_1):
        raise AssertionError
    if (loose_version_1 != loose_version_0):
        raise AssertionError
    if (loose_version_0 == loose_version_1):
        raise AssertionError
    if (loose_version_1 == loose_version_0):
        raise AssertionError


# Generated at 2022-06-24 21:22:36.110750
# Unit test for method __le__ of class Version
def test_Version___le__():
    try:
        test_case_0()
        test_case_1()
    except:
        print("FAILED")
        raise
    print("PASSED")


# Generated at 2022-06-24 21:22:39.581180
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()
    strict_version_0 = StrictVersion()
    loose_version_0 <= strict_version_0


# Generated at 2022-06-24 21:22:46.924626
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Imports
    import doctest

    # Define test data
    v1 = Version('1.2')
    v2 = Version('1.2')
    v3 = Version('1.2')
    v4 = Version('1.3')
    v5 = Version('1.3')
    v6 = Version('1.3')

    # Test
    # From doctests
    doctest.testmod()
    assert v1 <= v2
    assert v2 <= v3
    assert v1 <= v3
    assert not v4 <= v5
    assert v4 <= v6
    assert not v4 <= v1
    assert not v4 <= v2
    assert not v4 <= v3

    # Call main
    main()


# Generated at 2022-06-24 21:22:49.596385
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    try:
        x = v == v
    except NotImplementedError:
        x = False
    return x


# Generated at 2022-06-24 21:22:51.034905
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()


# Generated at 2022-06-24 21:22:53.820397
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    loose_version_0.parse('1.3.4a3')
    assert str(loose_version_0) == '1.3.4a3'


# Generated at 2022-06-24 21:23:01.521031
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = Version()
    strict_version_0 = StrictVersion('')
    strict_version_0 = StrictVersion()
    strict_version_0 = StrictVersion()
    strict_version_0 = StrictVersion('')
    strict_version_0 = StrictVersion()
    strict_version_0 = StrictVersion('')
    strict_version_0 = StrictVersion()
    strict_version_0 = StrictVersion('')
    strict_version_0 = StrictVersion()
    strict_version_0 = StrictVersion()
    strict_version_0 = StrictVersion()



# Generated at 2022-06-24 21:23:06.934183
# Unit test for method __le__ of class Version
def test_Version___le__():

    result = None
    try:
        method = getattr(Version, '__le__')
    except AttributeError:
        raise RuntimeError('method __le__ of class Version not found')
    else:
        args = []
        if len(args) == 1 and isinstance(args[0], str):
            other = args[0]
            result = callable(method)(other)
    return result


# Generated at 2022-06-24 21:23:20.446203
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Tests for __eq__
    version_0 = LooseVersion('0')
    version_1 = LooseVersion('1')
    version_0_0 = LooseVersion('0.0')
    version_0_1 = LooseVersion('0.1')
    version_1_0 = LooseVersion('1.0')
    version_1_1 = LooseVersion('1.1')

    #Test true cases
    assert version_0 == version_0_0
    assert version_1 == version_1_0
    assert version_0 != version_0_1
    assert version_1 != version_1_1
    #Test false cases
    assert version_0 == version_0
    assert version_1 == version_1
    assert version_0_0 == version_0_0
    assert version_1_1 == version

# Generated at 2022-06-24 21:23:30.205017
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_a = Version('a')
    version_b = Version('b')

    if not version_a.__le__(version_a):
        print('Failed test_Version___le__()')
        return

    if not version_a.__le__(version_b):
        print('Failed test_Version___le__()')
        return

    if not version_a.__le__('a'):
        print('Failed test_Version___le__()')
        return

    if version_b.__le__(version_a):
        print('Failed test_Version___le__()')
        return

    if version_b.__le__('a'):
        print('Failed test_Version___le__()')
        return



# Generated at 2022-06-24 21:23:33.166458
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert loose_version_0.__le__(loose_version_0) == True


# Generated at 2022-06-24 21:23:34.990549
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    assert loose_version_0 == '0'


# Generated at 2022-06-24 21:23:36.780706
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert (LooseVersion('1.0') <= LooseVersion('1.0')) == True


# Generated at 2022-06-24 21:23:41.454917
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        loose_version_1 = LooseVersion('1.0.0')
        assert(loose_version_1 == '1.0.0')
    except Exception as inst:
        # LooseVersion comparison to string failed in some way
        print(type(inst))
        print(inst.args)
        print(inst)
    else:
        # LooseVersion comparison to string succeeded
        print("Success")


# Generated at 2022-06-24 21:23:43.962466
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion()
    add_result = loose_version_0 <= loose_version_1

    assert add_result is False


# Generated at 2022-06-24 21:23:49.314743
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_1 = LooseVersion("1")
    loose_version_2 = LooseVersion("1")
    assert not loose_version_1 == None
    assert loose_version_1 == loose_version_2
    assert loose_version_1 == "1"
    assert not loose_version_1 == "2"


# Generated at 2022-06-24 21:23:55.631262
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():

    # Testing LooseVersion.parse w/ valid inputs
    # Test cases are taken verbatim from Greg Stein's
    # original version module.

    test_cases = (
        "1.5.1",
        "1.5.2b2",
        "161",
        "3.10a",
        "8.02",
        "3.4j",
        "1996.07.12",
        "3.2.pl0",
        "3.1.1.6",
        "2g6",
        "11g",
        "0.960923",
        "2.2beta29",
        "1.13++",
        "5.5.kw",
        "2.0b1pl0",
    )

    lv = LooseVersion()

# Generated at 2022-06-24 21:24:00.326340
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:24:20.524385
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:24:27.384921
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion('1.2.3')
    assert v.version == (1,2,3)
    v = LooseVersion('1.2.3a4')
    assert v.version == (1,2,3,'a',4)
    v = LooseVersion('1.2.3.4.5.6a.7')
    assert v.version == (1,2,3,4,5,6,'a',7)


# Generated at 2022-06-24 21:24:38.023622
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    component_0 = []
    component_1 = []
    loose_version_0.version = component_0
    component_2 = []
    component_3 = []
    component_4 = []
    component_5 = []
    component_6 = []
    component_7 = []
    component_8 = []
    component_9 = []
    component_10 = []
    component_11 = []
    component_12 = []
    component_13 = []
    component_14 = []
    component_15 = []
    component_16 = []
    component_17 = []
    component_18 = []
    component_19 = []
    component_20 = []
    component_21 = []
    component_22 = []
    component_23 = []
    component_24 = []

# Generated at 2022-06-24 21:24:46.514273
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_1 = LooseVersion()
    loose_version_2 = LooseVersion('1.1')
    assert_equal(loose_version_2.vstring, '1.1')
    loose_version_3 = LooseVersion('1.1.1')
    assert_equal(loose_version_3.vstring, '1.1.1')
    loose_version_4 = LooseVersion('1.1.0.0')
    assert_equal(loose_version_4.vstring, '1.1.0.0')


# Generated at 2022-06-24 21:24:49.658583
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    

# Generated at 2022-06-24 21:25:00.497516
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Case of no param, should raise an error
    assert(LooseVersion().parse() == ValueError)

    # Case of extra param, should raise an error
    assert(LooseVersion().parse('version_string', 'version_string') == ValueError)

    # Case of bad format, should raise an error
    assert(LooseVersion('1').parse() == ValueError)
    assert(LooseVersion('1.2a3.').parse() == ValueError)
    assert(LooseVersion('1.2a.3').parse() == ValueError)
    assert(LooseVersion('42.21o3').parse() == ValueError)
    assert(LooseVersion('1.12p0 ').parse() == ValueError)
    assert(LooseVersion('1.2.2a2a').parse() == ValueError)

    # Case of

# Generated at 2022-06-24 21:25:09.210303
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version = LooseVersion("1.5.1")
    loose_version.vstring = "1.5.1"
    assert loose_version.vstring == "1.5.1"

    loose_version = LooseVersion("1.5.2b2")
    loose_version.vstring = "1.5.2b2"
    assert loose_version.vstring == "1.5.2b2"

    loose_version = LooseVersion("161")
    loose_version.vstring = "161"
    assert loose_version.vstring == "161"

    loose_version = LooseVersion("3.10a")
    loose_version.vstring = "3.10a"
    assert loose_version.vstring == "3.10a"


# Generated at 2022-06-24 21:25:13.886802
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Create a test version string
    version_string = '0.0'
    # Construct a version object from it
    version_obj = LooseVersion(version_string)
    # Call the method under test
    version_obj.parse(version_string)


# Generated at 2022-06-24 21:25:18.069240
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion()
    l.parse('0.4.1')

    if not isinstance(l, LooseVersion):
        raise AssertionError('error: LooseVersion.parse did not return a LooseVersion object')
    if l.version != (0, 4, 1):
        raise AssertionError('error: LooseVersion.parse did not set LooseVersion.version correctly')


# Generated at 2022-06-24 21:25:21.212749
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse('1.2.3a')
    assert v.version == [1, 2, 3, 'a']
    v.parse('1.2.3a.4')
    assert v.version == [1, 2, 3, 'a', 4]


# Generated at 2022-06-24 21:25:29.676949
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from pytest import raises

    loose_version_0 = LooseVersion()
    with raises(ValueError):
        loose_version_0.parse('invalid_version_string')


# Generated at 2022-06-24 21:25:35.151154
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    test_cases = [
        ("v18.07", "v18.07"),
        ("v19.07", "v19.07"),
        ("v18.07", "v18.07"),
        ("v19.07", "v19.07"),
    ]
    for string, expected in test_cases:
        loose_version = LooseVersion(string)
        result = loose_version.parse(string)
        assert result is not None, "LooseVersion result is None"
        assert result.vstring == expected, "LooseVersion result.vstring is not correct"
    return

test_LooseVersion_parse()

NOVERSIONSTRING = "No version string found"


# Generated at 2022-06-24 21:25:40.917417
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    global loose_version_1, loose_version_2

    loose_version_1 = LooseVersion()
    loose_version_1.parse('0.4')
    loose_version_2 = LooseVersion('1.0.4a3')


# Generated at 2022-06-24 21:25:47.931170
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import sys, getopt
    def test_parse(string, result):
        v = LooseVersion(string)
        print("LooseVersion('{}') => '{}'".format(string, result))
        if result == 'error':
            if v.vstring != string:
                print("Error: result of parse does not match input string.");
        else:
            if v.version != result:
                print("Error: result of parse does not match expected result.");

    test_parse('1.5.1', (1, 5, 1))
    test_parse('1.5.2b2', (1, 5, 2, 'b', 2))
    test_parse('161', (161,))
    test_parse('3.10a', (3, 10, 'a'))

# Generated at 2022-06-24 21:25:54.080612
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # prepare the test data
    vstring = "1.2.3"
    # call the method parse of class LooseVersion with the test data
    loose_version = LooseVersion()
    loose_version.parse(vstring)
    # now compare the actual result with the expected result
    assert loose_version.version == [1, 2, 3]
    assert loose_version.vstring == vstring


# Generated at 2022-06-24 21:26:03.239305
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:26:05.883149
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version = LooseVersion()
    version.parse("1.0")
    assert version.vstring == "1.0"


# Generated at 2022-06-24 21:26:17.994150
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from pyassert import assert_that

    try:
        vstring = '1.5.1'
        loose_version_0 = LooseVersion()
        loose_version_0.parse(vstring)
        assert_that(loose_version_0.version).is_equal_to([1,5,1])
        assert_that(loose_version_0.vstring).is_equal_to(vstring)
    except:
        print('Assertion Failed')
        sys.exit(1)
    return


# Generated at 2022-06-24 21:26:21.362655
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    c = LooseVersion()
    c.parse('0.4')
    assert(str(c) == '0.4')
    

# Generated at 2022-06-24 21:26:31.346577
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test subclassing
    class LocalLooseVersion(LooseVersion):
        pass

    # Subclassing is safe
    LocalLooseVersion(0)
    # Subclassing works
    LocalLooseVersion('1.0.0')

    # Regression test for SourceForge bug #564470:
    # http://sourceforge.net/tracker/index.php?func=detail&aid=564470&group_id=5470&atid=105470
    #
    #     >>> LooseVersion('1.4.1.999').version
    #     (1, 4, 1, 999)
    #     >>> LooseVersion('1.4.1.1000').version
    #     (1, 4, 1, 1000)


# Generated at 2022-06-24 21:26:45.210809
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    try:
        loose_version_0.parse('1.1.1')
    except Exception as bad:
        raise error.TestFail("LooseVersion.parse threw: %s" % (bad,))


# Generated at 2022-06-24 21:26:46.941527
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    loose_version_0.parse('0.1')


# Generated at 2022-06-24 21:26:54.527251
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion('0')
    assert(v.version == [0])
    v = LooseVersion('1')
    assert(v.version == [1])
    v = LooseVersion('1.0')
    assert(v.version == [1, 0])
    v = LooseVersion('0.0')
    assert(v.version == [0, 0])
    v = LooseVersion('1.0.0')
    assert(v.version == [1, 0, 0])
    v = LooseVersion('2.0.0')
    assert(v.version == [2, 0, 0])
    v = LooseVersion('0.0.1')
    assert(v.version == [0, 0, 1])
    v = LooseVersion('0.1.0')

# Generated at 2022-06-24 21:27:02.840093
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version_0 = LooseVersion("0.960923")
    version_1 = LooseVersion(vstring='2g6')
    version_2 = LooseVersion(vstring='3.4j')
    version_3 = LooseVersion(vstring='1.5.2b2')
    version_4 = LooseVersion(vstring='2.2beta29')
    version_5 = LooseVersion(vstring='1.13++')
    version_6 = LooseVersion(vstring='10.3')
    version_7 = LooseVersion(vstring='1.2.pl0')
    version_8 = LooseVersion(vstring='3.0.0')
    version_9 = LooseVersion(vstring='1.2')


# Generated at 2022-06-24 21:27:07.045709
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    expect = LooseVersion()
    expect.parse("1.5.1")
    expect.version = [1, 5, 1]
    actual = LooseVersion()
    actual.parse("1.5.1")
    assert actual.version == expect.version
