

# Generated at 2022-06-24 21:17:22.458468
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_0._cmp = Version()
    strict_version_0.value = (2147483647, 0)
    strict_version_1.value = (2147483647, 2147483647)
    assert (strict_version_0 >= strict_version_1)
    assert (strict_version_1 >= strict_version_0)
    assert (strict_version_1 >= strict_version_1)


# Generated at 2022-06-24 21:17:30.811557
# Unit test for method __lt__ of class Version

# Generated at 2022-06-24 21:17:33.149506
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.0')
    assert v.__str__() == '1.0'


# Generated at 2022-06-24 21:17:39.594726
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()

# Generated at 2022-06-24 21:17:43.895861
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_1 = StrictVersion()
    assert not strict_version_1.__eq__(1)
    strict_version_1 = StrictVersion()
    assert strict_version_1.__eq__(strict_version_1)


# Generated at 2022-06-24 21:17:48.229924
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    strict_version_1 = StrictVersion()
    strict_version_1.parse("0.4.0")
    strict_version_2 = StrictVersion()
    strict_version_2.parse("0.4.0")
    assert(strict_version_1 == strict_version_2)

if __name__ == "__main__":
    test_StrictVersion_parse()

# Generated at 2022-06-24 21:17:53.984579
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Create an instance of class Version
    strict_version_0 = StrictVersion()

    # Try to call method __le__
    result = strict_version_0.__le__('0.1')
    if result:
        print('__le__ returned true')
    else:
        print('__le__ returned false')


# Generated at 2022-06-24 21:17:54.915919
# Unit test for method __le__ of class Version
def test_Version___le__():
    pass # nothing to test


# Generated at 2022-06-24 21:17:57.907063
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_1 = StrictVersion("1.0.0")
    strict_version_2 = StrictVersion("1.0.0")
    # first use case
    # assert __eq__(other)
    assert strict_version_1 == strict_version_2


# Generated at 2022-06-24 21:18:07.336898
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_2 = strict_version_1
    strict_version_3 = StrictVersion('0')
    strict_version_4 = StrictVersion('1')
    strict_version_5 = StrictVersion('0')
    strict_version_6 = StrictVersion('0.0')
    strict_version_7 = StrictVersion('0.0.0')
    strict_version_8 = StrictVersion('0.0.0.0')
    strict_version_9 = StrictVersion('0.0.0.0.0')
    strict_version_10 = StrictVersion('0.0.0.0.1')
    strict_version_11 = StrictVersion('0.0.0.0.2')


# Generated at 2022-06-24 21:18:20.739026
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    import unittest

    class TestIsInstance(unittest.TestCase):

        def test_0(self):
            strict_version_0 = StrictVersion()
            strict_version_1 = StrictVersion('0')
            strict_version_2 = StrictVersion('1')
            strict_version_3 = StrictVersion('1.0')
            strict_version_4 = StrictVersion('1.1')
            self.assertFalse(strict_version_0 >= strict_version_2)

        def test_1(self):
            strict_version_0 = StrictVersion()
            strict_version_1 = StrictVersion('0')
            strict_version_2 = StrictVersion('1')
            strict_version_3 = StrictVersion('1.0')

# Generated at 2022-06-24 21:18:23.041680
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    c = StrictVersion("0")
    assert str(c) == "0"


# Generated at 2022-06-24 21:18:29.847134
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_1 = StrictVersion("0.0.0")
    strict_version_2 = StrictVersion("0.0.0")
    strict_version_3 = StrictVersion("1.1.1")
    strict_version_4 = StrictVersion("1.0.0.0")
    strict_version_5 = StrictVersion("1.0.0.0")
    assert strict_version_1._cmp(strict_version_2) == 0
    assert strict_version_1 != strict_version_3
    assert strict_version_4._cmp(strict_version_5) == 0



# Generated at 2022-06-24 21:18:36.344983
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = StrictVersion()
    v2 = StrictVersion('1.2')
    eq_(v2 < v1, False)
    eq_(v1 < v2, True)
    eq_(v1 > v2, False)
    eq_(v2 > v1, True)


# Generated at 2022-06-24 21:18:44.128040
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    if test_case_0():
        assert (strict_version_0 > 1), "strict_version_0 > 1"
        assert (strict_version_0 > "1"), "strict_version_0 > 1"
    if test_case_1():
        assert (strict_version_1 > 1), "strict_version_1 > 1"
        assert (strict_version_1 > "1"), "strict_version_1 > 1"
    if test_case_2():
        assert (strict_version_2 > 1), "strict_version_2 > 1"
        assert (strict_version_2 > (1,)), "strict_version_2 > 1"

# Generated at 2022-06-24 21:18:46.418220
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    boolean_0 = strict_version_0 < strict_version_1


# Generated at 2022-06-24 21:18:47.966956
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    strict_version_0 = StrictVersion("0.4.1")


# Generated at 2022-06-24 21:18:53.611223
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion('0.1.0')
    strict_version_1 = StrictVersion()
    test_case_0()
    test_case_1()
    if struct_version_0 < strict_version_1:
        pass
    else:
        raise RuntimeError('Unit test failed')


# Generated at 2022-06-24 21:18:57.249033
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # The version number must be strictly increasing,
    # so we don't have to check the case where version is None.
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    assert strict_version_0 >= strict_version_1



# Generated at 2022-06-24 21:18:58.610834
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version().__gt__(0) == NotImplemented


# Generated at 2022-06-24 21:19:10.617503
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version.__lt__(test_case_0(), StrictVersion())


# Generated at 2022-06-24 21:19:20.339128
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    print(">>> strict_version_0.__gt__(3)")
    print(strict_version_0.__gt__(3))

if __name__ == "__main__":
    print(">>>")
    print(">>>")
    print(">>> ===== TEST_0 =====")
    print(">>>")
    print(">>>")
    test_case_0()
    print(">>>")
    print(">>>")
    print(">>> ===== TEST_Version___gt__ =====")
    print(">>>")
    print(">>>")
    test_Version___gt__()
    print(">>>")
    print(">>>")
    print(">>> ===== END =====")
    print(">>>")
    print(">>>")

# Generated at 2022-06-24 21:19:25.475502
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion('1.1.1')
    other_0 = strict_version_0
    strict_version_0_gt = strict_version_0.__gt__(other_0)
    assert strict_version_0_gt is False


# Generated at 2022-06-24 21:19:26.737281
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version = StrictVersion()



# Generated at 2022-06-24 21:19:31.919326
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    ans = strict_version_0.__gt__("")
    assert ans is False


# Generated at 2022-06-24 21:19:37.570129
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    strict_version_1 = StrictVersion('1.0')
    assert not strict_version_1 < strict_version_1
    strict_version_2 = StrictVersion('2.0')
    assert strict_version_1 < strict_version_2


# Generated at 2022-06-24 21:19:38.405138
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    pass


# Generated at 2022-06-24 21:19:41.545503
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0.__lt__(version_1) == 0


# Generated at 2022-06-24 21:19:44.791817
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()


# Generated at 2022-06-24 21:19:47.162463
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    strict_version_0 = StrictVersion()
    Version.__lt__(strict_version_0, None)


# Generated at 2022-06-24 21:20:03.903364
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    x = Version()
    other = Version()
    result = x.__ge__(other)
    if False:
        # We can't call the real version because it's not implemented
        assert result == Version.__ge__(x, other)


# Generated at 2022-06-24 21:20:12.653662
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import StrictVersion, LooseVersion, Version

    # Create an instance of a class
    v = StrictVersion()

    # Create an instance of Version
    vv = Version()

    # Create an instance of LooseVersion
    vvv = LooseVersion()

    # Call method __lt__ of v
    try:
        v.__lt__(StrictVersion.__name__)
    except AttributeError:
        pass

    # Call method __lt__ of vv
    #vv.__lt__(LooseVersion.__name__)
    # Call method __lt__ of vvv
    vvv.__lt__(LooseVersion.__name__)


# Generated at 2022-06-24 21:20:16.780328
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    version_0.__lt__(version_1)



# Generated at 2022-06-24 21:20:20.857465
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_2 = StrictVersion()
    strict_version_3 = StrictVersion()
    strict_version_0.parse("3.3.3")
    strict_version_1.parse("3.3.3")
    strict_version_2.parse("3.3.2")
    strict_version_3.parse("3.3.4")
    assert strict_version_0 >= strict_version_1
    assert strict_version_0 >= "3.3.3"


# Generated at 2022-06-24 21:20:25.202651
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert StrictVersion() >= StrictVersion()


# Generated at 2022-06-24 21:20:27.243145
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    assert not (strict_version_0 < strict_version_1)



# Generated at 2022-06-24 21:20:36.919540
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    assert isinstance(v.parse("1.2.1"), None)
    assert isinstance(v.parse("1.2.1-alpha"), None)
    assert isinstance(v.parse("1.2.1-alpha2"), None)
    assert isinstance(v.parse("1.2.1-alpha2"), None)
    assert isinstance(v.parse("1.2.1-alpha.2"), None)
    assert isinstance(v.parse("1.2.1-alpha.2.b1"), None)

test_LooseVersion_parse()


# Generated at 2022-06-24 21:20:42.189497
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    try:
        strict_version_1 = StrictVersion(
        )
    except TypeError:
        pass
    else:
        print_fail('StrictVersion() should raise a TypeError')


# Generated at 2022-06-24 21:20:44.308534
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version_0 = StrictVersion()
    str_0 = strict_version_0.__str__()
    assert str_0 == "0".encode('utf-8')


# Generated at 2022-06-24 21:20:51.247958
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Test __lt__ method of Version class.

    Steps:
    1. Create StrictVersion object.
    2. Convert StrictVersion object to string and compare it using __lt__.

    Expected Results:
    This should return False.
    """
    try:
        strict_version_0 = StrictVersion()
    except Exception:
        return False
    return str(strict_version_0) < str(strict_version_0) # __lt__


# Generated at 2022-06-24 21:21:18.765579
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    print("\n======test_StrictVersion___str__======\n")
    # Create an instance of StrictVersion
    strict_version = StrictVersion()
    # Call method __str__
    print(strict_version.__str__())


# Generated at 2022-06-24 21:21:27.454864
# Unit test for method __ge__ of class Version

# Generated at 2022-06-24 21:21:32.365829
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    strict_version_0_1 = StrictVersion('0')
    assert strict_version_0_1 >= strict_version_0, "strict_version_0_1 >= strict_version_0"



# Generated at 2022-06-24 21:21:36.658476
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion();
    strict_version_1 = StrictVersion();

    # Testing condition number 0, which should be True.
    assert (strict_version_0 >= "0.0.0");

    # Testing condition number 1, which should be False.
    assert (not (strict_version_1 >= "0.0.0"));


# Generated at 2022-06-24 21:21:48.516891
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version = StrictVersion()
    loose_version = LooseVersion()
    strict_version_0 = StrictVersion(0)
    loose_version_0 = LooseVersion(0)
    strict_version_1 = StrictVersion(1)
    loose_version_1 = LooseVersion(1)
    strict_version_2 = StrictVersion(2)
    loose_version_2 = LooseVersion(2)

    assert(strict_version_0 >= 0)
    assert(strict_version_0 >= loose_version_0)
    assert(not strict_version_0 >= 1)
    assert(not strict_version_0 >= loose_version_1)
    assert(not strict_version_0 >= loose_version)

    assert(loose_version_0 >= 0)

# Generated at 2022-06-24 21:21:50.635767
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    global strict_version_0
    strict_version_0.__ge__(strict_version_0)


# Generated at 2022-06-24 21:21:57.870436
# Unit test for method __ge__ of class Version

# Generated at 2022-06-24 21:22:01.020644
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v0 = Version()
    v1 = Version()
    result = v0 >= v1


# Generated at 2022-06-24 21:22:02.988405
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Verify that the following call to __ge__ is a no-op.
    Version().__ge__()


# Generated at 2022-06-24 21:22:10.824561
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    string = "0.4.0"
    strict_version = StrictVersion(string)
    if str(strict_version) == string:
        print("test_StrictVersion___str__() passed (1 of 2)")
    else:
        print("test_StrictVersion___str__() failed (1 of 2)")
    string = "0.4.0a1"
    strict_version = StrictVersion(string)
    if str(strict_version) == string:
        print("test_StrictVersion___str__() passed (2 of 2)")
    else:
        print("test_StrictVersion___str__() failed (2 of 2)")


# Generated at 2022-06-24 21:22:44.144175
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert 1 == 1
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    ret_val_0 = strict_version_0 >= strict_version_1
    strict_version_0 = StrictVersion()
    str_0 = '0'
    ret_val_1 = strict_version_0 >= str_0
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    ret_val_0 = strict_version_0 >= strict_version_1
    strict_version_0 = StrictVersion()
    str_0 = '0'
    ret_val_1 = strict_version_0 >= str_0
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()

# Generated at 2022-06-24 21:22:49.488780
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Given
    version_under_test = Version()
    version_under_test.parse("1.0.0")

    other = Version()
    other.parse("1.0.0")

    # When
    result = version_under_test.__ge__(other)

    # Then
    assert result


# Generated at 2022-06-24 21:22:55.636310
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():

    strict_version_0 = StrictVersion("0.4")
    str_0 = str(strict_version_0)
    assert str_0 == strict_version_0.__str__()
    assert str_0 == '0.4'

    strict_version_1 = StrictVersion("1.0.0")
    str_1 = str(strict_version_1)
    assert str_1 == strict_version_1.__str__()
    assert str_1 == '1.0.0'


# Generated at 2022-06-24 21:22:56.654919
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert (Version() >= Version())


# Generated at 2022-06-24 21:22:57.834901
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    test_case_0()


# Generated at 2022-06-24 21:23:00.466396
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version_0 = StrictVersion('1.0.0')
    assert strict_version_0._cmp('1.0.0') == 0


# Generated at 2022-06-24 21:23:05.894688
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion('1.2')
    assert v.version == [1, 2]
    v.parse('1.2.a1')
    assert v.version == [1, 2, 'a', 1]
    v.parse('1.2.3.4.5.6.7')
    assert v.version == [1, 2, 3, 4, 5, 6, 7]



# Generated at 2022-06-24 21:23:08.291814
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = StrictVersion()
    v2 = StrictVersion()
    assert v1 <= v2


# Generated at 2022-06-24 21:23:14.127000
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion(version_string='0')
    strict_version_1 = StrictVersion(version_string='100')
    assert strict_version_1 >= strict_version_0


# Generated at 2022-06-24 21:23:17.422347
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    pytest.raises(TypeError, strict_version_0.__ge__, 0)


# Generated at 2022-06-24 21:24:13.694741
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import sys
    from io import StringIO
    from unittest import TestCase

    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        test_case_0()
        sys.stdout.seek(0)
        out = sys.stdout.read()[:-1]
        assert out == '0.0', 'The output should equal `0.0` but it is `%s`' % out
        print('test_StrictVersion___str__: PASS')
    finally:
        sys.stdout = saved_stdout

if __name__ == '__main__':
    test_StrictVersion___str__()

# Generated at 2022-06-24 21:24:21.999278
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # test for 0 elements
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_2 = StrictVersion()
    strict_version_3 = StrictVersion()
    strict_version_4 = StrictVersion()
    assert(strict_version_0 >= strict_version_1)
    assert(strict_version_0 >= strict_version_4)
    assert(strict_version_1 >= strict_version_0)
    assert(strict_version_2 >= strict_version_3)
    assert(strict_version_3 >= strict_version_2)


# Generated at 2022-06-24 21:24:30.014004
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v0 = StrictVersion('1')
    assert v0.__str__() == '1'
    v1 = StrictVersion('1.0')
    assert v1.__str__() == '1.0'
    v2 = StrictVersion('1.0.0')
    assert v2.__str__() == '1.0.0'
    v3 = StrictVersion('1.0.0a')
    assert v3.__str__() == '1.0.0a'
    v4 = StrictVersion('1.0.0b')
    assert v4.__str__() == '1.0.0b'
    v5 = StrictVersion('1.0.0a1')
    assert v5.__str__() == '1.0.0a1'
    v6 = St

# Generated at 2022-06-24 21:24:31.324627
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert True


# Generated at 2022-06-24 21:24:32.286397
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    test_case_0()


# Generated at 2022-06-24 21:24:44.295204
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Check that an exception is raised if we do not provide any arguments
    with pytest.raises(TypeError):
        StrictVersion.__ge__()

    # Check that an exception is raised if we provide an invalid number
    # of arguments
    with pytest.raises(TypeError):
        StrictVersion.__ge__(StrictVersion(), StrictVersion(), StrictVersion())

    # Check that an exception is raised if we provide an invalid type of
    # arguments
    with pytest.raises(TypeError):
        StrictVersion.__ge__(StrictVersion(), None)
    with pytest.raises(TypeError):
        StrictVersion.__ge__(StrictVersion(), Version())
    with pytest.raises(TypeError):
        StrictVersion.__ge__(StrictVersion(), 42)

# Generated at 2022-06-24 21:24:48.177171
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion(1)
    strict_version_1 = StrictVersion(2)
    str_1 = '2'
    expected_return_value = True
    actual_return_value = strict_version_1 >= str_1
    assert(actual_return_value == expected_return_value)


# Generated at 2022-06-24 21:24:49.793477
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    test_case_0()


# Generated at 2022-06-24 21:25:00.043725
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test: new instance
    strict_version_1 = StrictVersion()
    assert strict_version_1.__str__() ==''

    # Test: parse() method called, no prerelease
    strict_version_2 = StrictVersion()
    strict_version_2.parse('1.2.3')
    assert strict_version_2.__str__() == '1.2.3'

    # Test: parse() method called, with prerelease
    strict_version_3 = StrictVersion()
    strict_version_3.parse('1.2.3a4')
    assert strict_version_3.__str__() == '1.2.3a4'


# Unit tests for method _cmp of class StrictVersion

# Generated at 2022-06-24 21:25:06.107310
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    # The __ge__ method of Version is invoked as an lvalue (see https://github.com/python/cpython/blob/3.9/Lib/distutils/version.py#L121), so we special case it
    v1 = Version()
    v2 = Version()
    cases = []
    cases.append((v1, v2, "return self._cmp(other) >= 0"))
    return cases
