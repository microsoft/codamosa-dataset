

# Generated at 2022-06-11 01:50:52.076098
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    return


# Generated at 2022-06-11 01:51:00.507906
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
  import sys, os
  from distutils.version import StrictVersion
  # All versions are valid, so this file shouldn't raise SystemExit,
  # and shouldn't write any output to stderr.
  saved_stdout = sys.stdout
  try:
    sys.stdout = open(os.devnull, 'w')
    with open(sys.argv[1]) as versions:
      for line in versions:
        StrictVersion(line.strip())
    return 0
  finally:
    sys.stdout.close()
    sys.stdout = saved_stdout

# Generated at 2022-06-11 01:51:07.569016
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.tests import support
    from distutils import version
    import sys
    import unittest



# Generated at 2022-06-11 01:51:18.953259
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    from distutils.version import StrictVersion
    assert str(StrictVersion('1.1.1')) == '1.1.1'
    assert str(StrictVersion('1.2')) == '1.2'
    assert str(StrictVersion('1.1.1a1')) == '1.1.1a1'
    assert str(StrictVersion('1.1.1a2')) == '1.1.1a2'
    assert str(StrictVersion('1.1.1b2')) == '1.1.1b2'
    assert str(StrictVersion('1.1.1c2')) == '1.1.1c2'
    assert str(StrictVersion('1.1.1rc2')) == '1.1.1rc2'
    #
   

# Generated at 2022-06-11 01:51:22.005696
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    with pytest.raises(NotImplementedError):
        v.__gt__('')



# Generated at 2022-06-11 01:51:33.254503
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import unittest

    class StrictVersion_parse_TestCase(unittest.TestCase):
        def test__init__(self):
            version = StrictVersion("1.3.0")
            self.assertEqual(version.version, (1, 3, 0))
            self.assertEqual(version.prerelease, None)

        def test__str__(self):
            version = StrictVersion("1.3.0")
            self.assertEqual(str(version), "1.3.0")

        def test_parse(self):
            version = StrictVersion("1.3.0")
            self.assertEqual(version.version, (1, 3, 0))
            self.assertEqual(version.prerelease, None)

        def test_parse_prerelease(self):
            version = St

# Generated at 2022-06-11 01:51:38.376320
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('0.5a5')
    assert str(v) == '0.5a5'
    v = StrictVersion('0.5.4')
    assert str(v) == '0.5.4'
    v = StrictVersion('1.0.4')
    assert str(v) == '1.0.4'


# Generated at 2022-06-11 01:51:40.032878
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(Version()) == True

# Generated at 2022-06-11 01:51:46.468821
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()

    other = object()
    expected = NotImplemented
    actual = v.__gt__(other)
    assert expected == actual

    other = 'abc'
    expected = NotImplemented
    actual = v.__gt__(other)
    assert expected == actual

    other = 1
    expected = NotImplemented
    actual = v.__gt__(other)
    assert expected == actual

    other = v
    expected = False
    actual = v.__gt__(other)
    assert expected == actual



# Generated at 2022-06-11 01:51:47.467298
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version("1.0") > Version("1.0.rc1")


# Generated at 2022-06-11 01:52:01.818112
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert (Version() <= Version())
    assert (Version() <= "2")
    assert ("2" <= Version())

# Generated at 2022-06-11 01:52:04.406663
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  v=Version()
  w=Version()

  assert (v==w)


# Generated at 2022-06-11 01:52:05.439859
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    print(Version() >= "a")

# Generated at 2022-06-11 01:52:16.073744
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion("1")) == "1", "str(StrictVersion(\"1\")) does not equal \"1\""
    assert str(StrictVersion("1.2")) == "1.2", "str(StrictVersion(\"1.2\")) does not equal \"1.2\""
    assert str(StrictVersion("1.2.3")) == "1.2.3", "str(StrictVersion(\"1.2.3\")) does not equal \"1.2.3\""
    assert str(StrictVersion("1.2a1")) == "1.2a1", "str(StrictVersion(\"1.2a1\")) does not equal \"1.2a1\""

# Generated at 2022-06-11 01:52:17.896325
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert (v == '')
# Unit tests for module distutils.version

# Generated at 2022-06-11 01:52:23.158127
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    class Version_TestCase(unittest.TestCase):
        def test_Version___gt__(self):
            self.assertTrue(Version('1.2.3') > Version('1.2'))
test_Version___gt__()



# Generated at 2022-06-11 01:52:25.464289
# Unit test for method __gt__ of class Version
def test_Version___gt__():
  v = Version()
  v._cmp = lambda x: 1
  assert v > 1


# Generated at 2022-06-11 01:52:27.706715
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = StrictVersion('0.1.1')
    expected = '0.1.1'
    obtained = str(version)
    assert expected == obtained


# Generated at 2022-06-11 01:52:31.679315
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    print('Test for method __lt__ of class Version')
    v1 = Version()
    v2 = Version()
    print('v1.__lt__(v2)')
    v1.__lt__(v2)
    print('v1.__lt__(v2) passed')

# Generated at 2022-06-11 01:52:33.947860
# Unit test for method __le__ of class Version
def test_Version___le__():
    # __le__ is defined in class Version
    (version, other) = (Version(), Version())
    x = version.__le__(other)



# Generated at 2022-06-11 01:53:05.298420
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    Version = Version
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert not v1 >= v2
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2
    v1 = Version('1.2.3')
    v2 = Version('1.2.2')
    assert v1 >= v2


# Generated at 2022-06-11 01:53:09.077782
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    result = v.__gt__('2.1')
    assert result == NotImplemented

test_Version___gt__()


# Generated at 2022-06-11 01:53:12.001055
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest

    class Version_TestCase(unittest.TestCase):
        def test___ge__(self):
            pass

    unittest.main()



# Generated at 2022-06-11 01:53:15.432297
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert "3.3.0" == str(StrictVersion("3.3"))
    assert "3.3" == str(StrictVersion("3.3.0"))
    assert "3.3a0" == str(StrictVersion("3.3a0"))


# Generated at 2022-06-11 01:53:19.069773
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1')
    assert (v.__class__.__name__ == "Version")
    assert (v.__class__.__bases__ == (object,))



# Generated at 2022-06-11 01:53:20.949512
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Instantiating a Version class will create an ambiguous unit test.
    # Skip this test.
    pass



# Generated at 2022-06-11 01:53:30.338362
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Tests method __ge__ of class Version
    #
    # [5 points]
    #
    # Setup:
    #     v1 = Version('1.2.3')
    #     v2 = Version('2.3.4')
    #
    # Expected Output:
    #     v1.__ge__(v2): False
    #     v2.__ge__(v1): True
    #     v1.__ge__(v1): True
    #     v2.__ge__(v2): True
    #
    v1 = Version('1.2.3')
    v2 = Version('2.3.4')

    if not v1.__ge__(v2):
        print("v1.__ge__(v2): True")

# Generated at 2022-06-11 01:53:38.566543
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    # Construct object
    try:
        a = Version()
    except Exception as e:
        raise(e)
    version = Version()
    version.parse("1")
    version2 = Version()
    version2.parse("2")

    # Test __eq__
    assert(a.__eq__("1") == NotImplemented)
    assert(a.__eq__(version) == NotImplemented)
    a = version
    assert(a == "1")
    assert(a != version2)


# Generated at 2022-06-11 01:53:43.860434
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.0')
    v2 = Version('2.0')

    assert v1 == '1.0'
    assert not v1 == '2.0'
    assert not v1 == v2
    assert not v1 == '1.0b2'
    assert not v1 == '1.0-ansible'

# Generated at 2022-06-11 01:53:50.175073
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    from distutils2.version import Version

    class VersionTestCase(unittest.TestCase):
        def test___eq__(self):
            ver1 = Version("1.2.3")
            ver2 = Version("1.2.3")
            self.assertTrue(ver1.__eq__(ver2) == True)
            ver1 = Version("1.2.3")
            ver2 = Version("1.2.4")
            self.assertFalse(ver1.__eq__(ver2) == True)
            ver1 = Version("1.2.3")
            ver2 = Version("1.2.3-1")
            self.assertFalse(ver1.__eq__(ver2) == True)
            ver1 = Version("1.2.3")

# Generated at 2022-06-11 01:54:35.170416
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    res = v1 < v2
    assert res is True


# Generated at 2022-06-11 01:54:39.061131
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v0 = Version('2.6')
    v1 = Version('2.5')
    res = v0.__gt__(v1)
    assert res == 1
    return


# Generated at 2022-06-11 01:54:47.269817
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    x = StrictVersion('0.4')
    assert x.__str__() == '0.4.0'
    x = StrictVersion('0.4.1')
    assert x.__str__() == '0.4.1'
    x = StrictVersion('600.4.2')
    assert x.__str__() == '600.4.2'

    x = StrictVersion('0.4a1')
    assert x.__str__() == '0.4a1'
    x = StrictVersion('0.4.1b1')
    assert x.__str__() == '0.4.1b1'
    x = StrictVersion('600.4.2a1')
    assert x.__str__() == '600.4.2a1'



# Generated at 2022-06-11 01:54:51.632175
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Test for method Version.__le__."""
    v1 = Version()
    v2 = Version()
    # Simple case
    assert v1.__le__(v2) == True
    # Unimplemented case
    assert v1.__le__('v') == NotImplemented


# Generated at 2022-06-11 01:55:03.144271
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    '''Test the Version.__eq__ method.
    '''

    # Using the following test data in table form:

# Generated at 2022-06-11 01:55:09.382347
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Unit test for method __gt__ of class Version."""
    import pytest
    with pytest.raises(AttributeError):  # test if method raises expected exception
        v1 = Version()
        v2 = Version()
        assert v1.__gt__(v2) == NotImplemented


# Generated at 2022-06-11 01:55:11.012170
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version("1.2") == Version("1.2")
    assert Version("1.2") != Version("1.3")


# Generated at 2022-06-11 01:55:13.105338
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    return StrictVersion('3.5.5') == '3.5.5'


# Generated at 2022-06-11 01:55:13.802247
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v._cmp(Version()) == 0

# Generated at 2022-06-11 01:55:16.737762
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version("0.0.1")
    assert v < "0.0.2"
    v = Version("0.0.2")
    assert v < "0.1.0"
    v = Version("0.1.0")
    assert v < "0.1.1"
    v = Version("0.1.1")
    assert v < "1.0.0"



# Generated at 2022-06-11 01:55:45.591425
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    if skip_ci_tests():
        return

    assert Version('1.0') < Version('1.0a4')

# Generated at 2022-06-11 01:55:47.107014
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.0')
    assert v == '1.0'


# Generated at 2022-06-11 01:55:55.663463
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from ansibullbot.utils.version_compare import Version

    assert Version("1.1") < Version("1.2")
    assert Version("1.1") < "1.2"
    assert not Version("1.2") < Version("1.1")
    assert not Version("1.2") < "1.1"
    assert Version("0.9.9") < Version(".1")
    assert Version("0.9.9") < ".1"
    assert Version("1.0dev2") < Version("1.0a2")
    assert Version("1.0dev2") < "1.0a2"
    assert Version("1.0dev2") < Version("1.0a2")
    assert Version("1.0dev2") < Version("1.0a2")

# Generated at 2022-06-11 01:55:57.473279
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    assert not v1.__eq__(None)


# Generated at 2022-06-11 01:56:01.188673
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.0')
    assert v.__lt__('2.0')
    assert not v.__lt__('1.0')
    assert not v.__lt__('0.9')

# Generated at 2022-06-11 01:56:05.704584
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("1.0")
    v2 = Version("2.0")

    if v1.__gt__(v2):
        raise RuntimeError("Version.__gt__ failed")

    if not v2.__gt__(v1):
        raise RuntimeError("Version.__gt__ failed")


# Generated at 2022-06-11 01:56:06.715279
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    v.__gt__()

# Generated at 2022-06-11 01:56:10.698283
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import os
    import pytest

    v0 = Version("0.9")
    v1 = Version("1.0")

    assert v0 < v1
    assert not (v0 < v0)
    assert not (v1 < v0)



# Generated at 2022-06-11 01:56:12.750797
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  a = Version()
  b = Version()
  c = a < b


# Generated at 2022-06-11 01:56:21.791072
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2

    v1 = Version('1.0.a2')
    v2 = Version('1.0.a3')
    assert v1 < v2

    v1 = Version('1.0.a3')
    v2 = Version('1.0.b1')
    assert v1 < v2

    v1 = Version('2.0.a1')
    v2 = Version('10.0.b1')
    assert v1 < v2

    v1 = Version('1.0a1')
    v2 = Version('1.0c2')
    assert v1 < v2

    v1 = Version('1.3.1')
    v2 = Version('1.3.2')
   

# Generated at 2022-06-11 01:57:26.239538
# Unit test for method __le__ of class Version
def test_Version___le__():
    # pylint: disable=E0611
    from distutils2.version import Version
    from distutils2.tests import unittest, support
    from distutils2.tests.support import LoggingCatcher
    from distutils2.version import StrictVersion, LooseVersion
    # pylint: enable=E0611
    import sys

    class VersionTestCase(support.TempdirManager,
                          support.LoggingSilencer,
                          unittest.TestCase):

        def __init__(self, *args):
            unittest.TestCase.__init__(self, *args)

        def setUp(self):
            super(VersionTestCase, self).setUp()
            self.old_sys_version = sys.version
            # pretend that we are Python 3.0

# Generated at 2022-06-11 01:57:33.593037
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from ansible.module_utils.pycompat24.version import Version
    from ansible.module_utils._text import to_bytes

    for a, b, c in (1, 2, -1), (2, 2, 0), (2, 1, 1):
        for cls in [StrictVersion, LooseVersion]:
            assert len([x for x in [(cls(str(a)), cls(str(b)), c)] if (cls(str(a)) >= cls(str(b))) == (c >= 0)]) == 1
            # Unit test for method __ge__ of class Version

# Generated at 2022-06-11 01:57:43.090487
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test cases for method __eq__ of class Version
    import unittest


    class method___eq___TestCase(unittest.TestCase):
        def setUp(self):
            pass


    class subclass___eq___TestCase(method___eq___TestCase):
        def runTest(self):
            # subclass of class "Version"

            class a1(Version):
                def parse(self, vstring):
                    pass


            class a2(Version):
                def parse(self, vstring):
                    pass


            self.assertEqual(0, a1('1') == a1('1'))
            self.assertEqual(1, a1('2') == a1('1'))
            self.assertEqual(0, a2('2') == a2('2'))
            self.assertEqual

# Generated at 2022-06-11 01:57:48.288512
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    from distutils.version import LooseVersion

    lv1 = LooseVersion('1.0.4')
    lv2 = LooseVersion('1.0.4.post1a')
    lv3 = LooseVersion('1.0.4.post1a.dev1')

    assert lv1 < lv2
    assert lv2 < lv3



# Generated at 2022-06-11 01:57:49.609290
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == None


# Generated at 2022-06-11 01:57:53.646696
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert not (v > '1.2.3')
    assert not (v < '1.2.3')
    assert v <= '1.2.3'



# Generated at 2022-06-11 01:57:55.176065
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version()
    version.__eq__('xyz') == NotImplemented


# Generated at 2022-06-11 01:57:57.509229
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented, "__lt__() result is not NotImplemented"


# Generated at 2022-06-11 01:57:59.922882
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__('0.0') is NotImplemented
test_Version___le__()

# Generated at 2022-06-11 01:58:03.955471
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def test_func(self, other):
        c = self._cmp(other)
        if c is NotImplemented:
            return c
        return c == 0

    v = Version()
    assert test_func(v, "1") == test_func(v, v)

# Generated at 2022-06-11 02:00:19.852965
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1') >= Version('1')
    assert not Version('1') >= Version('2')
    assert not Version('1') >= Version('1.1')


# Generated at 2022-06-11 02:00:28.442127
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from lib2to3.pygram import python_symbols as syms
    from lib2to3.pgen2 import token
    from lib2to3.pytree import Leaf
    from lib2to3.pytree import Node
    from lib2to3.fixer_util import Name
    from lib2to3.fixer_util import Number
    from lib2to3.fixer_util import String
    #
    # name1 = Name('__lt__')
    # number1 = Number('1')
    # number2 = Number('2')
    # stmt1 = Node(syms.arith_expr, [number1, number2])
    # node1 = Node(
    #     syms.test,
    #     [name1, Node(syms.trailer, [Leaf(token.LPAR), number

# Generated at 2022-06-11 02:00:36.125236
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from copy import deepcopy
    from ansible_test._internal.utils.version import Version

    v1 = Version('0.0.1')
    v2 = deepcopy(v1)

    assert v1.__gt__(v2) == v2.__lt__(v1) == v1.__ge__(v2) == v2.__le__(v1) == False
    assert v1.__lt__(v2) == v2.__gt__(v1) == v1.__le__(v2) == v2.__ge__(v1) == False

# Generated at 2022-06-11 02:00:37.776342
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1")
    v2 = Version("2")
    assert v1 < v2
