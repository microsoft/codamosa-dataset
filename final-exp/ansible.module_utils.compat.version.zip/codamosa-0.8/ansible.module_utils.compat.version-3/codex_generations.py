

# Generated at 2022-06-11 01:50:56.898275
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert repr(StrictVersion('0.4.0')) == "StrictVersion ('0.4.0')"
    assert repr(StrictVersion('0.4.1')) == "StrictVersion ('0.4.1')"
    assert repr(StrictVersion('1.0.4a3')) == "StrictVersion ('1.0.4a3')"
    assert repr(StrictVersion('1.0.4b1')) == "StrictVersion ('1.0.4b1')"
    assert repr(StrictVersion('1.0.4')) == "StrictVersion ('1.0.4')"

# Generated at 2022-06-11 01:51:02.029123
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    v._cmp = lambda x: -1
    assert not (v >= 'foo')
    v._cmp = lambda x: 1
    assert v >= 'foo'
    v._cmp = lambda x: 0
    assert v >= 'foo'
    v._cmp = lambda x: NotImplemented
    assert v >= 'foo' is NotImplemented

# Generated at 2022-06-11 01:51:03.321738
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import doctest
    doctest.testmod(StrictVersion)


# Generated at 2022-06-11 01:51:04.876121
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    Version(None)



# Generated at 2022-06-11 01:51:07.425671
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version(vstring='2.2.1')
    assert v == '2.2.1'


# Generated at 2022-06-11 01:51:09.489765
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()



# Generated at 2022-06-11 01:51:19.880468
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3')
    assert v.version == (1, 2, 3)

    v = StrictVersion('1.2')
    assert v.version == (1, 2, 0)

    v = StrictVersion('1.2a3')
    assert v.version == (1, 2)
    assert v.prerelease == ('a', 3)

    v = StrictVersion('1.2.0.0')
    assert v.version == (1, 2, 0)

    try:
        StrictVersion('1.2b')
        raise AssertionError('StrictVersion.parse should have failed')
    except ValueError:
        pass


# Generated at 2022-06-11 01:51:22.516558
# Unit test for method __le__ of class Version
def test_Version___le__():
    import pytest
    from distutils.version import Version

    version = Version('1.0')
    assert version <= '1.0'


# Generated at 2022-06-11 01:51:25.645680
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.2.3') == Version('1.2.3')
    assert Version('1.1') == Version('1.1.0')

# Generated at 2022-06-11 01:51:35.538676
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    assert StrictVersion('1.2').version == (1, 2, 0)
    assert StrictVersion('1.2.3').version == (1, 2, 3)
    assert StrictVersion('1.2').prerelease is None
    assert StrictVersion('1.2.3').prerelease is None
    assert StrictVersion('1.2a2').version == (1, 2, 0)
    assert StrictVersion('1.2b3').version == (1, 2, 0)
    assert StrictVersion('1.2a2').prerelease == ('a', 2)
    assert StrictVersion('1.2b3').prerelease == ('b', 3)
    assert StrictVersion('1.2a2').prerelease[0] == 'a'
    assert StrictVersion('1.2b3').prerelease[0]

# Generated at 2022-06-11 01:51:54.263716
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    from distutils.version import LooseVersion
    from distutils.version import StrictVersion

    # See tests below to check the behaviour of '_cmp'
    version = Version()
    version._cmp = lambda x: 0

    version_lt = Version()
    version_lt._cmp = lambda x: -1

    version_gt = Version()
    version_gt._cmp = lambda x: 1

    version_eq = Version()
    version_eq._cmp = lambda x: 0

    version_ne = Version()
    version_ne._cmp = lambda x: 1

    version_nc = Version()
    version_nc._cmp = NotImplemented

    assert True is (version > version_lt)
    assert False is (version > version_gt)
    assert False is (version > version_eq)


# Generated at 2022-06-11 01:51:54.993619
# Unit test for method __le__ of class Version
def test_Version___le__():
    pass

# Generated at 2022-06-11 01:51:57.983916
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.1') > Version('1.0')
    assert Version('1.2.15') > Version('1.0.8')



# Generated at 2022-06-11 01:52:05.388937
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Tests for method __le__ of class Version
    v = Version("0.4.0")
    assert v <= "0.4.0"
    assert v <= "0.4.0.0"
    assert v <= "0.4.0-a1"
    assert v <= "0.4.0c1"
    assert not (v <= "0.3.0")
    assert not (v <= "0.4.0-c1")
    assert not (v <= "0.4.0b1")
    assert not (v <= "0.4.1c1")

# Generated at 2022-06-11 01:52:10.147881
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Unit test for method __ge__ of class Version"""
    v1 = Version('1.2')
    v2 = Version('1.3')
    assert v1.__ge__(v1)
    assert not v1.__ge__(v2)


# Generated at 2022-06-11 01:52:14.420544
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1=Version('2.0alpha2')
    v2=Version('2.0.5b1')
    assert v1._cmp(v2)==-1 and v1.__le__(v2)==True and v1.__gt__(v2)==False

# Generated at 2022-06-11 01:52:15.916332
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    return v.__ge__(v)



# Generated at 2022-06-11 01:52:18.098040
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    ver1 = Version("1.2.3")
    ver2 = Version("1.2")
    assert ver1 >= ver2



# Generated at 2022-06-11 01:52:18.471521
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    pass

# Generated at 2022-06-11 01:52:29.485450
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """
    Method __eq__ of class Version

    Method __eq__ of class Version.
    Tests equality of two version instances.
    """
    #from distutils.version import Version
    #v1 = Version('1.1')
    #v2 = Version('2.0')
    #v3 = Version('2.0')
    #v4 = Version('1.1')
    #v5 = Version('2.0.0')
    #v6 = Version('2.0.0')
    #assert (v1 == v4) == 1
    #assert (v3 == v2) == 1
    #assert (v1 == v2) == 0
    #assert (v4 == v1) == 1
    #assert (v2 == v3) == 1
    #assert (v3 == v5) == 0
   

# Generated at 2022-06-11 01:52:40.817959
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('3.3.3')
    assert str(v) == '3.3.3'
    assert repr(v) == "Version ('3.3.3')"
    assert (v > '3.3.2') == True
    assert (v > '3.3.3') == False



# Generated at 2022-06-11 01:52:42.712964
# Unit test for method __le__ of class Version
def test_Version___le__():
    test_class = Version()
    test_class.__le__(other)


# Generated at 2022-06-11 01:52:46.124925
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    def __gt__(self, other):
        c = self._cmp(other)
        if c is NotImplemented:
            return c
        return c > 0
    assert __gt__(self, other) == c > 0

# Generated at 2022-06-11 01:52:49.728074
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v1.parse("1.0")
    v2 = Version()
    v2.parse("2.0.dev1")
    assert(v1 < v2)

# Generated at 2022-06-11 01:52:50.802500
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    Version().__lt__('')



# Generated at 2022-06-11 01:53:00.790744
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def __eq___0():
        v1 = Version(vstring='2.0')
        v2 = Version(vstring='1.3')
        v3 = Version(vstring='2.0')

        try:
            assert v1 == v2
        except AssertionError:
            return

    def __eq___1():
        v1 = Version(vstring='2.0')
        v2 = Version(vstring='1.3')
        v3 = Version(vstring='2.0')

        try:
            assert v1 == v3
        except AssertionError:
            return

    def __eq___2():
        v1 = Version(vstring='2.0')
        v2 = Version(vstring='1.3')
        v3 = Version(vstring='2.0')



# Generated at 2022-06-11 01:53:01.805459
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    return


# Generated at 2022-06-11 01:53:05.092801
# Unit test for method __le__ of class Version
def test_Version___le__():
    i = Version('1.1.1')
    j = Version('1.1.1')
    k = i <= j
    return None


# Generated at 2022-06-11 01:53:08.632102
# Unit test for method __le__ of class Version
def test_Version___le__():
    class MyVersion(Version):
        def __le__(self, other):
            return True
    v = MyVersion()
    assert v <= 42 # call __le__

# Generated at 2022-06-11 01:53:11.306941
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """
    Test method __eq__ of class Version
    """
    assert isinstance(Version().__eq__(1), bool)


# Generated at 2022-06-11 01:53:19.905395
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert(Version('1.1') >= Version('1.1'))
    assert(Version('1.1') >= '1.1')


# Generated at 2022-06-11 01:53:21.423347
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  assert(Version('1') < Version('2'))


# Generated at 2022-06-11 01:53:24.589341
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 == v2
    assert v1 != '1.0'

# Generated at 2022-06-11 01:53:28.082849
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  v1 = Version('1.0')
  v2 = Version('2.0')
  v3 = Version('1.0')
  assert (v1 != v2) == True
  assert (v1 == v3) == True


# Generated at 2022-06-11 01:53:30.281986
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version('2.0')
    assert version == '2.0'


# Generated at 2022-06-11 01:53:32.348711
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    v.__gt__(None)
    # No exception, so we're good


# Generated at 2022-06-11 01:53:41.160718
# Unit test for method __gt__ of class Version
def test_Version___gt__():
  import unittest
  import Version
  import copy
  class veq:
    def __init__(self,v):
      self.v = v
    def __eq__(self,other):
      return self.v == other
  class Test(unittest.TestCase):
    def test_eq(self):
      self.assertTrue(veq(True)==True)
      self.assertTrue(veq(False)==False)
      self.assertTrue(veq(False)!=True)
      self.assertTrue(veq(True)!=False)
    def test_lt(self):
      self.assertTrue(veq(True)<=True)
      self.assertTrue(veq(True)<=False)
      self.assertTrue(veq(False)<=True)

# Generated at 2022-06-11 01:53:46.198867
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import pytest

    v1 = Version()
    v1._version = (1, 2, 3)
    v2 = Version()
    v2._version = (1, 2, 4)

    with pytest.raises(AttributeError):
        assert v1 < v2


# Generated at 2022-06-11 01:53:56.990629
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils2.version import Version
    ver = Version()
    ver.parse = lambda x: setattr(ver, '_ver', [x])
    ver._cmp = lambda x: x._ver[0] - ver._ver[0]
    ver2 = Version()
    ver2.parse = lambda x: setattr(ver2, '_ver', [x])
    ver2._cmp = lambda x: x._ver[0] - ver2._ver[0]
    c = ver._cmp(ver2)
    # c is NotImplemented with unittest and pytest
    assert (ver > ver2) == (c > 0)
    assert (ver >= ver2) == (c >= 0)
    assert (ver < ver2) == (c < 0)
    assert (ver <= ver2) == (c <= 0)

# Generated at 2022-06-11 01:53:59.800219
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    __tracebackhide__ = True
    v = Version()
    assert v._cmp("2.5") == 1
test_Version___lt__()


# Generated at 2022-06-11 01:54:19.718968
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    __tracebackhide__ = True

    v1 = Version('1.2')

    assert v1 < v1.parse('1.3')
    assert v1 < v1.parse('2.2')
    assert v1 < v1.parse('1.1.5')
    assert v1 < v1.parse('1.2.1')

    assert not (v1 < v1.parse('1.2'))
    assert not (v1 < v1.parse('0.2'))
    assert not (v1 < v1.parse('1.1'))

# Generated at 2022-06-11 01:54:21.940863
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v1 = Version('1')
    assert v1._cmp(v) > 0



# Generated at 2022-06-11 01:54:25.195456
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2
    assert not v1 == "v1"
    assert not v1 == object()


# Generated at 2022-06-11 01:54:29.320469
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Make sure that we can create an object of class Version
    d = Version()
    # Make sure that the class has an __lt__ method
    try:
        d.__lt__
    except AttributeError:
        raise AssertionError("Version does not have the method __lt__")



# Generated at 2022-06-11 01:54:30.277799
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version() == Version()

# Generated at 2022-06-11 01:54:41.398301
# Unit test for method __le__ of class Version
def test_Version___le__():
    print('Testing Version.__le__')

    ##############################
    # Setup parameter, run case, and verify outputs
    ##############################

    # test case 1
    Version._cmp = lambda self, other: NotImplemented
    r1 = Version().__le__(None)
    assert r1 is NotImplemented, "Return type should be 'NotImplementedType'"

    # test case 2
    Version._cmp = lambda self, other: -1
    r2 = Version().__le__(None)
    assert r2 is False, "Return type should be 'bool'"

    # test case 3
    Version._cmp = lambda self, other: 0
    r3 = Version().__le__(None)
    assert r3 is True, "Return type should be 'bool'"

    # test case 4
    Version._cmp

# Generated at 2022-06-11 01:54:48.366353
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion('1.2.1')
    assert lv.version == [1,2,1], lv.version
    for vstring in ('1.2.1', '1.02.1', '1.2.001'):
        assert LooseVersion(vstring).parse(vstring).version == [1,2,1]
    for vstring in ('1.2.2a2', '1.2.2b2', '1.2.2c2',
                    '1.2.2a.2', '1.2.2a2.2'):
        assert LooseVersion(vstring).parse(vstring).version == \
               [1,2,2,'a',2]

# Generated at 2022-06-11 01:54:53.472248
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        import Version
    except ImportError:
        import __main__ as Version
    v = Version.Version('1.2.3')
    v.cmp = lambda *a: 1
    assert v > '1.0'
    assert not v > '1.2.3'
    assert not v > '1.2.4'
    assert not v > '2.0'




# Generated at 2022-06-11 01:54:56.675115
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Unit test for method __lt__ of class Version"""
    def __lt__(self, other):
        c = self._cmp(other)
        if c is NotImplemented:
            return c
        return c < 0

# Generated at 2022-06-11 01:55:04.236618
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    V = Version
    assert V('1.2') >= V('1.2')
    assert V('2.0') >= V('1.2')
    assert V('1.5') >= V('1.2')
    assert not V('1.2') >= V('1.5')
    assert not V('1.2') >= V('2.0')
    assert not V('1.2') >= V('2.0.post1')


# Generated at 2022-06-11 01:55:32.660396
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import pytest

    v1 = Version('1.1')
    v2 = Version('1.1')

    assert v1 == v2

# Generated at 2022-06-11 01:55:41.038475
# Unit test for method __gt__ of class Version

# Generated at 2022-06-11 01:55:42.737651
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= v
    assert v == v
    assert v >= v



# Generated at 2022-06-11 01:55:44.012606
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('2.0').__eq__('2.0') == True

# Generated at 2022-06-11 01:55:52.703506
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Unit test for method __lt__ of class `Version`."""
    from distutils.version import Version
    from distutils.version import LooseVersion
    from distutils.version import StrictVersion

    # The constructor of Version raises NotImplementedError, so we need to
    # mock the method __init__
    with patch('distutils.version.Version.__init__',
               side_effect=lambda *args, **kwargs: None):
        assert Version().__lt__(LooseVersion('0.0.0.dev0')) is False
        assert Version().__lt__(StrictVersion('0.0.0.dev0')) is False
        assert Version().__lt__(Version()) is False



# Generated at 2022-06-11 01:56:04.208256
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.tests import support
    from distutils.version import StrictVersion, LooseVersion

    def test_ge(a, b):
        v_a = LooseVersion(a)
        v_b = LooseVersion(b)
        # looser test for equality for loose versions
        if b == a:
            assert v_a == v_b
            assert not v_a != v_b
            assert not v_a < v_b
            assert v_a <= v_b
            assert not v_a > v_b
            assert v_a >= v_b
        elif b > a:
            assert not v_a == v_b
            assert v_a != v_b
            assert v_a < v_b
            assert v_a <= v_b
            assert not v_a > v_b

# Generated at 2022-06-11 01:56:05.233679
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented

# Generated at 2022-06-11 01:56:13.004718
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import distutils.version
    v = distutils.version.Version('1.0')
    assert(v < '2.0')
    assert(v < '1.1')
    assert(v < '1.0.1')
    assert(v < '1.0.post1')
    assert(v < '1.0b1')
    assert(not v < '1.0dev')
    assert(not v < '1.0a1')
    assert(v < '1.0rc1')
    assert(v < '1.0')
    assert(not v < '1.0.post0.dev1')

# Generated at 2022-06-11 01:56:15.247248
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(NotImplemented) is NotImplemented, 'Expected NotImplemented'



# Generated at 2022-06-11 01:56:21.844302
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('2.1') > Version('2.0')
    assert Version('2.1') > Version('2.0.0')
    assert Version('2.1') > Version('2.0.1')

    assert Version('2.0.2') > Version('2.0.1')
    assert Version('2.0.2') > Version('2.0.1.0')

    assert Version('3.0j') > Version('2.0')
    assert Version('3.2.1') > Version('3.0j')
    assert Version('11g') > Version('2.0.1')

# Generated at 2022-06-11 01:57:19.218170
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version("1.2.3")
    assert v > "1.2"


# Generated at 2022-06-11 01:57:20.528620
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  # Don't know how to unit test methods of abstract base classes
  pass

# Generated at 2022-06-11 01:57:22.170296
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version("a")
    v2 = Version("b")
    assert v1 != v2


# Generated at 2022-06-11 01:57:26.058865
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    obj = Version()
    obj.parse('1.2')
    assert obj >= Version('1.2')
    assert obj >= Version('0.9')
    assert obj >= '1.0'
    assert not (obj >= '1.3')



# Generated at 2022-06-11 01:57:27.960704
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    Version.__ge__(Version, Version)
    assert True, "Not Reached"

# Generated at 2022-06-11 01:57:30.231731
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    w = Version('1.2.3')
    assert v == w

# Generated at 2022-06-11 01:57:39.417709
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def test(ver1, ver2, expected):
        print("Testing {} {}".format(str(ver1), str(ver2)))
        if ver1 == ver2:
            if not expected:
                raise AssertionError("Unexpectedly equal")
        else:
            if expected:
                raise AssertionError("Unexpectedly not equal")

    test(Version("1.8"), Version("1.8"), True)
    test(Version("1.8"), Version("1.10"), True)
    test(Version("1.9"), Version("1.10"), True)
    test(Version("0.9"), Version("0.11"), True)
    test(Version("0.9"), Version("1.11"), True)
    test(Version("0.10"), Version("1.10"), True)


# Generated at 2022-06-11 01:57:40.695724
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version() >= Version()

# Generated at 2022-06-11 01:57:46.615618
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()

    assert v1 == v2
    assert not v1 != v2
    assert not v1 < v2
    assert v1 <= v2
    assert not v1 > v2
    assert v1 >= v2

    v1 = Version()
    v2 = Version('1.0')

    assert v1 < v2
    assert not v1 > v2
    assert v1 <= v2
    assert not v1 >= v2

    v1 = Version()
    v2 = Version(None)

    assert v1 is not None
    assert v1 == v2
    assert not v1 != v2
    assert not v1 < v2
    assert v1 <= v2
    assert not v1 > v2
    assert v1 >= v2

    v1 = Version()


# Generated at 2022-06-11 01:57:48.478354
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    assert Version('1.0') <= Version('2.0')
    

# Generated at 2022-06-11 02:00:01.165099
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Version class not testable
    assert True

# Generated at 2022-06-11 02:00:02.168835
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= ''

# Generated at 2022-06-11 02:00:03.941279
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Unit test for method __lt__ of class Version"""
    v = Version('2.0')
    assert v < '2.1'



# Generated at 2022-06-11 02:00:05.113704
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == Version('1.2.3')


# Generated at 2022-06-11 02:00:07.733999
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version('1.2.0a0')
    other = Version('1.1.5')
    result = version.__lt__(other)
    assert result == False
    assert isinstance(result, bool)

# Generated at 2022-06-11 02:00:17.215633
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    #
    # Version.__gt__
    #
    for module_version in [
            "1.0",
            "2.0",
            "2.5.5",
            "10.0",
            "1.0b1",
            "1.0c1"]:
        v = Version(module_version)
        assert v > "1.0", "%s was not greater than 1.0" % module_version

    for module_version in [
            "1.0",
            "1.0a2"]:
        v = Version(module_version)
        assert v < "2.0", "%s was not less than 2.0" % module_version


# Generated at 2022-06-11 02:00:18.481577
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1').__lt__(Version('2'))

# Generated at 2022-06-11 02:00:21.489109
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v != '4'
    assert v != '4.5'
    assert v != '4.5.6'
    assert v != '5.5'
    assert v != '5.5.6'


# Generated at 2022-06-11 02:00:29.623221
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest

    def assert_bool(self, actual):
        self.assertIs(True, actual is not NotImplemented)

    class TrueTest(unittest.TestCase):
        __qualname__ = 'TrueTest'

        def test_True(self):
            class Sub(Version):
                __qualname__ = 'TrueTest.test_True.<locals>.Sub'

                def _cmp(self, other):
                    return 1

            self.assertIs(True, Sub() <= Sub())

    class FalseTest(unittest.TestCase):
        __qualname__ = 'FalseTest'

        def test_False(self):
            class Sub(Version):
                __qualname__ = 'FalseTest.test_False.<locals>.Sub'

                def _cmp(self, other):
                    return NotImplemented



# Generated at 2022-06-11 02:00:39.245544
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test method __ge__ of class Version"""

    ENSURE(Version('1.0').__ge__(Version('1.0')) == True)
    ENSURE(Version('1.0').__ge__(Version('1.0b0')) == True)
    ENSURE(Version('1.0').__ge__(Version('1.0.dev')) == True)
    ENSURE(Version('1.0.dev').__ge__(Version('1.0.dev')) == True)
    ENSURE(Version('1.0').__ge__(Version('1.0a')) == True)
    ENSURE(Version('1.0').__ge__(Version('1.0.a')) == True)