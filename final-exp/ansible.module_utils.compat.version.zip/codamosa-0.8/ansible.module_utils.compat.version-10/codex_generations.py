

# Generated at 2022-06-11 01:50:59.038991
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """ test method Version.__gt__ """
    # Test a simple run of the method.
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1.__gt__(v1) is False
    assert v1.__gt__(v2) is False
    assert v2.__gt__(v1) is True
# Test a run with a complicated call.
    assert v1.__gt__(v1) is False
    assert v1.__gt__(v2) is False
    assert v2.__gt__(v1) is True
# Test a run with no parameters.
    assert v1.__gt__(v1) is False
    assert v1.__gt__(v2) is False
    assert v2.__gt__(v1) is True



# Generated at 2022-06-11 01:51:00.944241
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    inst = Version()
    assert inst.__lt__([]) == NotImplemented


# Generated at 2022-06-11 01:51:05.385195
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert (v >= "1.4") is NotImplemented
    assert (v >= v) is True
    assert (v >= Version("1.4.2b1")) is NotImplemented
    assert (v >= Version("1.4.2")) is NotImplemented
    assert (v >= Version("1.4")) is NotImplemented
    assert (v >= Version("1.5")) is NotImplemented


# Generated at 2022-06-11 01:51:14.760837
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1').__str__() == '1.0'
    assert StrictVersion('1.2').__str__() == '1.2'
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2a1').__str__() == '1.2a1'
    assert StrictVersion('1.2.3b2').__str__() == '1.2.3b2'
    assert StrictVersion('1.2c3').__str__() == '1.2c3'

# Generated at 2022-06-11 01:51:22.494590
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.0')
    assert( v < '1.1' )
    assert( not(v < '1.0') )
    assert( not(v < '0.9') )
    assert( not(v < '1.0.0') )
    assert( not(v < '1.0a1') )
    assert( not(v < '1.0.1') )
    v = Version('1.0.1')
    assert( v < '1.0.2' )
    assert( not(v < '1.0.1') )
    assert( not(v < '1.0') )
    assert( not(v < '0.9') )
    assert( not(v < '1.0a1') )
    assert( not(v < '1.1') )
   

# Generated at 2022-06-11 01:51:27.492413
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.1')
    v2 = Version('1.2')
    v3 = Version('1.3')
    v1_1 = Version('1.1')
    assert v1_1 < v2
    assert v1_1 < v3
    assert v2 < v3



# Generated at 2022-06-11 01:51:36.529610
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = StrictVersion("1.3.1")
    assert s.version == (1, 3, 1)
    assert s.prerelease is None

    s = StrictVersion("1.3.1.4")
    assert s.version == (1, 3, 1, 4)
    assert s.prerelease is None

    s = StrictVersion("1.3a1")
    assert s.version == (1, 3)
    assert s.prerelease == ('a', 1)

    s = StrictVersion("1.3a1.4")
    assert s.version == (1, 3)
    assert s.prerelease == ('a', 1)

    s = StrictVersion("1.3b1")
    assert s.version == (1, 3)
    assert s.prerelease == ('b', 1)

    s

# Generated at 2022-06-11 01:51:46.363012
# Unit test for method __eq__ of class Version

# Generated at 2022-06-11 01:51:48.921713
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    return v1 == v2

# Generated at 2022-06-11 01:51:50.818672
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version('1.0')


# Generated at 2022-06-11 01:52:01.379833
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version("1.3.0").__eq__("1.3.0") == True

# Generated at 2022-06-11 01:52:04.824552
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v2 = Version('1.2.3')
    assert v2 <= v2
    assert not v2 <= Version('1.2.4')


# Generated at 2022-06-11 01:52:06.250657
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert (v <= '1.0')


# Generated at 2022-06-11 01:52:07.844359
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version() == Version()



# Generated at 2022-06-11 01:52:11.177994
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    print("%s[%d]: %s" % (thisfile(), lineno()-1, sys._getframe().f_code.co_name))
    v1 = Version("2.0")
    v2 = Version("1.0")
    assert v1 > v2


# Generated at 2022-06-11 01:52:16.041215
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('4.3.3b3').__str__() == '4.3.3b3'
    assert StrictVersion('0.4').__str__() == '0.4'
    assert StrictVersion('0.4.0').__str__() == '0.4'
    assert StrictVersion('2.7.2.2').__str__() == '2.7'


# Generated at 2022-06-11 01:52:27.218945
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Version.__gt__
    # asserts
    assert Version('1.0') > Version('0.9')
    assert not Version('0.9') > Version('1.0')
    assert Version('1.1') > Version('1.0')
    assert not Version('1.0') > Version('1.1')
    assert Version('1.0.post1') > Version('1.0')
    assert not Version('1.0') > Version('1.0.post1')
    assert not Version('1.0.post1') > Version('1.0.post2')
    assert Version('1.0.post2') > Version('1.0.post1')
    assert Version('1.0.post1') > Version('1.0.dev2')

# Generated at 2022-06-11 01:52:36.020736
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert not (v == None)
    assert not (v == '')
    assert not (v == '0')
    assert not (v == None)
    assert not (v <= None)
    assert not (v <= '')
    assert not (v <= '0')
    assert not (v <= None)
    assert not (v < None)
    assert not (v < '')
    assert not (v < '0')
    assert not (v < None)
    assert not (v >= None)
    assert not (v >= '')
    assert not (v >= '0')
    assert not (v >= None)
    assert not (v > None)
    assert not (v > '')
    assert not (v > '0')
    assert not (v > None)


# Generated at 2022-06-11 01:52:45.461008
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Implementation details:
    # * self._cmp returns c
    # * c is an int
    # * if c < 0 then self._cmp(other) < 0
    # * if c = 0 then self._cmp(other) = 0
    # * if c > 0 then self._cmp(other) > 0

    # Setup
    v_1 = Version()

    # Exercise
    v_2 = Version()
    r_1 = v_1 <= v_2

    # Verify
    assert isinstance(r_1, bool)
    assert r_1

    # Exercise
    v_2 = Version()
    r_2 = v_2 <= v_1

    # Verify
    assert isinstance(r_2, bool)
    assert r_2

    # Exercise
    v_2 = Version()
    r_3 = v_

# Generated at 2022-06-11 01:52:55.132795
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('0.0.0').__str__() == '0.0'
    assert StrictVersion('0.0').__str__() == '0.0'
    assert StrictVersion('0').__str__() == '0.0'
    assert StrictVersion('1.0').__str__() == '1.0'
    assert StrictVersion('1.0.0').__str__() == '1.0'
    assert StrictVersion('1.0.1').__str__() == '1.0.1'
    assert StrictVersion('1.10.1').__str__() == '1.10.1'
    assert StrictVersion('1.10.1b1').__str__() == '1.10.1b1'

# Generated at 2022-06-11 01:53:07.405486
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2

# Generated at 2022-06-11 01:53:10.962297
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version("1.0.0")
    assert v >= "0.9"
    assert v >= v
    assert not(v >= "1.0.1")


# Generated at 2022-06-11 01:53:18.516545
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    failures = []
    lv = LooseVersion()
    lv.parse('3.2.1')
    if lv.version != [3, 2, 1]:
        failures.append('parsing "3.2.1": %s' % lv.version)

    lv = LooseVersion()
    lv.parse('3.2.pl0')
    if lv.version != [3, 2, 'pl', 0]:
        failures.append('parsing "3.2.pl0": %s' % lv.version)

    lv = LooseVersion()
    lv.parse('3.2pl0')
    if lv.version != [3, 2, 'pl', 0]:
        failures.append('parsing "3.2pl0": %s' % lv.version)



# Generated at 2022-06-11 01:53:20.418826
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ver = Version()
    result = ver.__gt__('1')
    assert result is False


# Generated at 2022-06-11 01:53:22.740784
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    k1 = Version()
    k2 = Version()
    assert k1 < k2

# Generated at 2022-06-11 01:53:24.540612
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version(vstring="1.0")
    assert v == Version(vstring="1.0")

# Generated at 2022-06-11 01:53:27.474986
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("1")
    v2 = Version("2")
    assert(v2 > v1)

test_Version___gt__()



# Generated at 2022-06-11 01:53:31.346443
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    class MockVersion:
        def _cmp(self, other):
            return 0

    assert Version().__ge__(MockVersion()) == True
    assert Version().__ge__(MockVersion()) != False



# Generated at 2022-06-11 01:53:40.518741
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest
    import sys
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.compat.distutils.version import Version

    saved_stdout = sys.stdout


# Generated at 2022-06-11 01:53:46.517558
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    expected = 0
    ret = (Version('1.1') > Version('1.0'))
    assert ret == expected, 'Version("1.1") > Version("1.0") returned %r, expected %r' % (ret, expected)
    print('Version("1.1") > Version("1.0") returned %r as expected' % (ret))



# Generated at 2022-06-11 01:54:06.119180
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    assert version.__gt__(Version())



# Generated at 2022-06-11 01:54:17.394662
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= Version()
    assert Version('0') <= Version('0')
    assert Version('1.0') <= Version('1.0')
    assert Version('2.2.2') <= Version('2.2.2')
    assert Version('1.1') <= Version('2.2.2')
    assert Version('2.2') <= Version('2.2.2')
    assert not (Version() <= Version('0'))
    assert not (Version() <= Version('1.0'))
    assert not (Version() <= Version('2.2.2'))
    assert not (Version('0') <= Version())
    assert not (Version('0') <= Version('0'))
    assert not (Version('0') <= Version('1.0'))
    assert not (Version('0') <= Version('2.2.2'))

# Generated at 2022-06-11 01:54:22.841908
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def test_Version___eq__1():
        v = Version()
        c = v._cmp(Version())
        eq = c == 0
        assert eq is True
    test_Version___eq__1()

    def test_Version___eq__2():
        v = Version()
        c = v._cmp(Version())
        assert c == 0
    test_Version___eq__2()



# Generated at 2022-06-11 01:54:25.874668
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Unit test for __gt__() method of class Version."""

    from distutils.version import Version

    class MyVersion(Version):
        """Dummy subclass of Version to allow testing of __gt__()"""

        def _cmp(self, other):
            return 42

    assert MyVersion("1.1").__gt__("1.0") == True

# Generated at 2022-06-11 01:54:31.102046
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    import sys

    class Version___gt__(unittest.TestCase):
        def test(self):

            # Query the real numbers
            v = Version()
            self.assertNotEqual(v, 0)
            self.assertNotEqual(v, 0.0)
            self.assertNotEqual(v, 0j)
            self.assertNotEqual(v, ())
            self.assertNotEqual(v, [])
            self.assertNotEqual(v, {})

    test_support.run_unittest(Version___gt__)


# Generated at 2022-06-11 01:54:33.218075
# Unit test for method __le__ of class Version
def test_Version___le__():
    with raises(NotImplementedError):
        Version().__le__(Version())

# Generated at 2022-06-11 01:54:36.889637
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    class MockVersion:
        def _cmp(self, other):
            return NotImplemented
    v = Version()
    assert v >= MockVersion()
    try:
        v >= "Not version"
        assert False
    except TypeError:
        pass
    assert v >= v

# Generated at 2022-06-11 01:54:46.595757
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  import unittest
  from distutils.version import Version
  from distutils.version import StrictVersion
  from distutils.version import LooseVersion
  from distutils.version import StringType
  from distutils.version import IntegerType

  class VersionTestCase(unittest.TestCase):
    def test_isinstance(self):
      self.assertTrue(isinstance(Version(), Version))

    def test_compare(self):
      self.assertEqual(Version('1.2.0'), StrictVersion('1.2.0'))
      self.assertEqual(Version('a.b.c'), StrictVersion('a.b.c'))
      self.assertEqual(Version('1.2.0'), LooseVersion('1.2.0a'))

# Generated at 2022-06-11 01:54:49.112791
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert not v == "1"
    assert not v == 0
    assert v == None


# Generated at 2022-06-11 01:54:50.279904
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    x = Version()

# Generated at 2022-06-11 01:55:19.904904
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    vobj = Version()
    c = vobj._cmp(0)
    if c is NotImplemented:
        return c
    return c > 0



# Generated at 2022-06-11 01:55:27.289675
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.tests.test_version import version_class

    v1 = version_class('1.0')
    v2 = version_class('1.1')
    v3 = version_class('1.0')
    for x in range(0,4):
        for y in range(0,4):
            if not x == y:
                continue
            print("Testing equal %i %i" % (x,y))
            if x == 0:
                assert v1 == v1
            elif x == 1:
                assert v1 != v2
            elif x == 2:
                assert not v1 == v2
            elif x == 3:
                assert v1 == v3

# Generated at 2022-06-11 01:55:28.910033
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    a = Version('1.0')
    b = Version('2.0')
    assert a < b


# Generated at 2022-06-11 01:55:32.775753
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.0')
    f = Version('1.0b1')
    assert v >= f
    v = Version('1.0b1')
    f = Version('1.0')
    assert not (v >= f)


    v = Version('1.0')
    f = Version('1.0')
    assert v >= f



# Generated at 2022-06-11 01:55:41.180864
# Unit test for method __le__ of class Version
def test_Version___le__():
    # version.Version.__le__
    # version.Version.__le__
    v = Version('1.2.3')
    assert v <= '1.2.3'
    assert not v < '1.2.3'
    assert v <= '1.2.4'
    assert v < '1.2.4'
    assert not v > '1.2.3'
    assert not v >= '1.2.3'
    assert not v > '1.2.2'
    assert v >= '1.2.2'
    assert not v > '1.2'
    assert v >= '1.2'
    assert not v > '1'
    assert v >= '1'
    assert not v > '1.2.3a4'
    assert v >= '1.2.3a4'


# Generated at 2022-06-11 01:55:43.253526
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    return v1 < v2



# Generated at 2022-06-11 01:55:52.930761
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Test case for method Version.__eq__"""
    v1 = Version()
    v2 = Version('2.0')
    v3 = Version('1.5.1')
    v4 = Version('1.5.2')
    v5 = Version('1.5.1.1')
    v6 = Version('1.5.2')
    v7 = Version('1.5')
    assert v2 == v2, "__eq__: Version instance doesn't equal itself, something is wrong"
    assert not v1 != v1, "__eq__: Version instance doesn't equal itself, something is wrong"
    assert v1
    assert v1 < v2
    assert v2 > v3
    assert v3 < v4
    assert v3 <= v4
    assert v4 <= v4
    assert v4 >= v4

# Generated at 2022-06-11 01:55:55.017754
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version("4.4.4") == Version("4.4.4")

# Generated at 2022-06-11 01:55:56.194565
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    Version() == Version()


# Generated at 2022-06-11 01:55:57.795220
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version().__lt__('\x00') == NotImplemented



# Generated at 2022-06-11 01:56:53.262127
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    ver = Version('2.0')
    if ver.__eq__(ver):
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-11 01:56:59.766023
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert not False <= False
    assert (not False) <= None
    assert not False <= 3
    assert not False <= 2.0
    assert None <= None
    assert not None <= 3
    assert not None <= 2.0
    assert not 3 <= False
    assert not 3 <= None
    assert not 3 <= 2
    assert not 3 <= 2.0
    assert not 2.0 <= False
    assert not 2.0 <= None
    assert not 2.0 <= 3
    assert 2.0 <= 2.0


# Generated at 2022-06-11 01:57:02.565746
# Unit test for method __le__ of class Version
def test_Version___le__():
    with pytest.raises(NotImplementedError):
        Version()._cmp('')
    with pytest.raises(NotImplementedError):
        Version().__le__(None)

# Generated at 2022-06-11 01:57:12.932380
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-11 01:57:16.489121
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    try:
        assert (Version().__ge__(__) == NotImplemented)
    except:
        return False
    else:
        return True

# Generated at 2022-06-11 01:57:26.656283
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert (Version('1') < Version('2'))
    assert (Version() < Version('2'))
    assert (Version('1.0') < Version('2'))
    assert (Version('1.0') < Version('1.1'))
    assert (Version('1.0') < Version('1.1.1'))
    assert (Version('1.1') < Version('1.2'))
    assert (Version('1.1') < Version('2'))
    assert (Version('1.1.0') < Version('1.1.1'))
    assert (Version('1.1.1') < Version('1.2.0'))
    assert (Version('1.1.2') < Version('1.2.0'))

# Generated at 2022-06-11 01:57:33.441803
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    _v = Version()
    _o = Version()
    _v._cmp = lambda other: 1
    _r = _v == _o
    assert _r is False
    _v._cmp = lambda other: 0
    _r = _v == _o
    assert _r is True
    _v._cmp = lambda other: -1
    _r = _v == _o
    assert _r is False
    _v._cmp = NotImplemented
    _r = _v == _o
    assert _r is NotImplemented

# Generated at 2022-06-11 01:57:35.334608
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version()
    version.parse('1.2.3')
    assert version.__eq__(Version()) == NotImplemented


# Generated at 2022-06-11 01:57:38.395027
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    a = Version('1.2.3')
    b = Version('1.2.3')
    assert a == b, "Versions %r and %r are not equal" % (a, b)


# Generated at 2022-06-11 01:57:41.527548
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version("1.0")
    v2 = Version("2.0")
    v3 = Version("1.0")

    assert v1 == v3
    assert v1 != v2

# Generated at 2022-06-11 01:58:53.564042
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.1')
    v2 = Version('1.2')
    assert v1 < v2

# Generated at 2022-06-11 01:58:56.877592
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Test that Version.__lt__ raises TypeError
    # if the other object is of a different type
    version_obj = Version()
    with pytest.raises(TypeError):
        version_obj.__lt__(object())



# Generated at 2022-06-11 01:59:04.623030
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.0.4')
    v3 = Version('2.0')
    v4 = Version('2.2')
    v5 = Version('1.0b2')
    v6 = Version('1.0a1')
    v7 = Version('1.0c1')
    v8 = Version('1.0.post456')
    v9 = Version('1.0.post999')
    v10 = Version('1.0rc1')
    v11 = Version('1.0.post1.dev456')
    v12 = Version('1.0.post1.dev123')
    v13 = Version('1.0+abc.5')
    v14 = Version('1.0+a.b.c.5')

# Generated at 2022-06-11 01:59:15.227692
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest
    class TestVersionGe(unittest.TestCase):
        class TestVersion(Version):
            def __init__(self, num):
                self.num = num
            def _cmp(self, other):
                if isinstance(other, TestVersion):
                    if self.num > other.num:
                        return 1
                    elif self.num == other.num:
                        return 0
                    else:
                        return -1
                if isinstance(other, int):
                    if self.num > other:
                        return 1
                    elif self.num == other:
                        return 0
                    else:
                        return -1
                return NotImplemented
        def test__ge__(self):
            self.assertFalse(TestVersion(1) >= TestVersion(2))

# Generated at 2022-06-11 01:59:20.360566
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import hypothesis.strategies as st
    import pytest

    @pytest.mark.parametrize('vstring', st.one_of(
        st.none(),
        st.text(),
    ))
    def test_f(vstring):
        version = Version(vstring=vstring)
        version.__eq__(other=None)


# Generated at 2022-06-11 01:59:30.991451
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-11 01:59:33.283554
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    exp = True
    msg = None
    obj = Version()
    res = obj.__gt__('0.0.0')
    assert res is exp, msg



# Generated at 2022-06-11 01:59:34.548503
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Unit test for method __eq__ of class Version"""
    assert True

# Generated at 2022-06-11 01:59:36.133276
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2')
    assert v >= '1.2'


# Generated at 2022-06-11 01:59:38.839955
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import pytest

    with pytest.raises(TypeError):
        Version.__gt__(None, None)

