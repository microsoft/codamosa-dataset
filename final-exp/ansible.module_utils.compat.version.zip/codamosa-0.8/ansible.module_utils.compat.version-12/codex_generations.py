

# Generated at 2022-06-11 01:51:00.857853
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Version(vstring=None) -> instance
    # tests __init__(self, vstring=None)
    vTest = Version()
    assert(not vTest)
    # Version(vstring) -> instance
    # tests __init__(self, vstring=None) and _cmp(self, other)
    vTest = Version('1.0')
    assert(vTest <= '1.0')
    assert(vTest < '1.1')
    assert(vTest == '1.0')
    assert(vTest != '1.1')
    assert(vTest > '0.9')
    assert(vTest >= '0.9')
    # tests __gt__(self, other) and __lt__(self, other)
    assert(not ( vTest > '1.0' ))

# Generated at 2022-06-11 01:51:02.460058
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert not Version('1.1') > Version('2.2')
test_Version___gt__()


# Generated at 2022-06-11 01:51:06.626029
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version(None)
    other = None
    expected = NotImplemented
    actual = version.__lt__(other)
    assert actual == expected, '%r != %r' % (actual, expected)

    return



# Generated at 2022-06-11 01:51:08.168834
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version("1.0") > Version("0.1")

# Generated at 2022-06-11 01:51:15.657946
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    v3 = Version()

    v1._cmp = lambda o: o == v2 and -1 or 0
    v2._cmp = lambda o: o == v1 and 1 or 0
    v3._cmp = lambda o: o == v1 and 1 or 0
    assert v1 <= v1
    assert v1 <= v2
    assert not v2 <= v1
    assert not v3 <= v1


# Generated at 2022-06-11 01:51:18.009182
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class Test(Version):
        pass

    assert Test('1') > Test('0')
    assert Test('1') > '0'



# Generated at 2022-06-11 01:51:28.640256
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.0").__str__() == "1.0"
    assert StrictVersion("1.0.0").__str__() == "1.0"
    assert StrictVersion("1.0a1").__str__() == "1.0a1"
    assert StrictVersion("1.0a1.1").__str__() == "1.0a1.1"
    assert StrictVersion("1.0b1.1").__str__() == "1.0b1.1"
    assert StrictVersion("1.0b1").__str__() == "1.0b1"


# Generated at 2022-06-11 01:51:37.153723
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-11 01:51:38.513128
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("1") <= Version("9")

# Generated at 2022-06-11 01:51:42.060678
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.0.4.b1")
    assert str(v) == "1.0.4b1"
    
test_StrictVersion___str__()

# Generated at 2022-06-11 01:51:51.106832
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    return Version('1') >= Version('1')

# Generated at 2022-06-11 01:52:01.512286
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Implicit setup
    version = Version.__new__(Version)
    version.parse = mock.MagicMock()
    version._cmp = mock.MagicMock()
    version._cmp.return_value = NotImplemented
    version._cmp.side_effect = TypeError
    version._cmp.return_value = -1
    version._cmp.return_value = 0
    version._cmp.return_value = 1

    # Explicit setup

    # Exercise the SUT
    # Implicit validate
    assert_equal(version.__le__(object), NotImplemented)
    assert_equal(version.__le__(object), TypeError)
    assert_equal(version.__le__(object), True)
    assert_equal(version.__le__(object), False)

# Generated at 2022-06-11 01:52:04.499636
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    version.parse = lambda *a: version
    version._cmp = lambda o: o
    assert version <= 1



# Generated at 2022-06-11 01:52:12.366276
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse('1.5.1')
    assert v.version == [1, '.', 5, '.', 1]
    assert v.vstring == '1.5.1'

    v = LooseVersion()
    v.parse('1.5.2b2')
    assert v.version == [1, '.', 5, '.', 2, 'b', 2]
    assert v.vstring == '1.5.2b2'

    v = LooseVersion()
    v.parse('161')
    assert v.version == [161]
    assert v.vstring == '161'

    v = LooseVersion()
    v.parse('3.10a')
    assert v.version == [3, '.', 10, 'a']
    assert v.vstring

# Generated at 2022-06-11 01:52:14.089070
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    result = Version()._cmp(1)
    assert result == NotImplemented   # Can't compare int and Version


# Generated at 2022-06-11 01:52:16.089638
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(Version()) == NotImplemented

# Generated at 2022-06-11 01:52:27.270632
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ve = Version()
    if ((ve != None)):
        raise IOError('Incorrect result for test #0')
    if ((ve <= None)):
        raise IOError('Incorrect result for test #1')
    if ((not (ve >= None))):
        raise IOError('Incorrect result for test #2')
    if ((not (ve > None))):
        raise IOError('Incorrect result for test #3')
    if ((ve == None)):
        raise IOError('Incorrect result for test #4')
    if ((not (ve < None))):
        raise IOError('Incorrect result for test #5')
    if ((ve.__eq__(None) != True)):
        raise IOError('Incorrect result for test #6')
    if ((ve.__lt__(None) != False)):
        raise IO

# Generated at 2022-06-11 01:52:29.790086
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2')
    assert v == v
    assert v == '1.2'
    assert not (v == '1.3')


# Generated at 2022-06-11 01:52:38.393915
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    import sys
    from distutils2.version import Version
    from distutils2.tests import support
    from distutils2.compat import StringIO

    class VersionTestCase(support.TempdirManager,
                          support.LoggingSilencer,
                          unittest.TestCase):

        def test_lt(self):
            version = Version("1.1.1")
            self.assertTrue(version < "1.1.2")
            self.assertTrue(version < "1.2")
            self.assertTrue(version < "2.0")
            self.assertTrue(version < "2.0.0")

            self.assertTrue("1.1.0" < version)
            self.assertTrue("1.0.0" < version)

# Generated at 2022-06-11 01:52:42.430764
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version("1.1")
    assert v1 >= "1.1"
    assert not v1 >= "1.2"

    assert v1 >= Version("1.1")
    assert not v1 >= Version("1.2")



# Generated at 2022-06-11 01:52:59.684404
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    pass


# Generated at 2022-06-11 01:53:05.420291
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    assert v1._cmp((1)) == 0
    assert v1._cmp((2)) == -1
    assert v1._cmp((0)) == 1
    assert v1._cmp((1, 0)) == 0
    assert v1._cmp((1, 1)) == -1
    assert v1._cmp((1, 0, 0)) == 0



# Generated at 2022-06-11 01:53:13.786003
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.0")
    assert v.__str__() == "1.0"
    v = StrictVersion("1.0a1")
    assert v.__str__() == "1.0a1"
    v = StrictVersion("1.0.1")
    assert v.__str__() == "1.0.1"
    v = StrictVersion("1.0.1b1")
    assert v.__str__() == "1.0.1b1"


# Generated at 2022-06-11 01:53:16.459512
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2')
    v2 = Version('1.2')
    test_result = (v == v2)
    expected_result = True
    assert test_result == expected_result

# Generated at 2022-06-11 01:53:19.532830
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.0a5')
    v2 = Version('1.2.0a6')
    assert v1 >= v2

# Generated at 2022-06-11 01:53:23.678211
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    from distutils.tests import support
    v = Version('3.4.0b1')
    support.assertEqual(v.__le__('3.4.0b1'), True)


# Generated at 2022-06-11 01:53:27.396159
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version(None) < '1.0.0'
    assert not Version('1.0.0') < '1.0.0'
    assert not Version('2.0.0') < '1.0.0'

# Generated at 2022-06-11 01:53:33.721048
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from ansible.module_utils._text import to_bytes, to_native

    v1 = Version("1.6.0.dev7")
    assert v1 >= "1.6.0.dev7"
    assert v1 > "1.6.0"
    assert not v1 > "1.6.0.dev8"
    assert not v1 > "1.6.1"


# Generated at 2022-06-11 01:53:35.255034
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Stub
    raise NotImplementedError()



# Generated at 2022-06-11 01:53:39.468907
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    module = sys.modules[Version.__module__]
    v1 = module.Version('1')
    v2 = module.Version('2')
    assert(v1 >= v1)
    assert(v1 < v2)
    assert(v1 <= v2)
    assert(v2 > v1)
    assert(v2 >= v1)
    assert(v2 < v2)
    assert(v1 == v1)

# Generated at 2022-06-11 01:54:00.021012
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import pytest
    v = Version()
    pytest.raises(NotImplementedError, v.__gt__)

# Generated at 2022-06-11 01:54:02.083092
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    o = Version()
    assert (v.__gt__(o) == False)

# Generated at 2022-06-11 01:54:03.669412
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('1.7.2')
    assert v > '1.7.1.999'

# end class Version



# Generated at 2022-06-11 01:54:06.660279
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    from distutils.tests import support
    v = Version("1.2")

# Generated at 2022-06-11 01:54:08.488184
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version("1.2")
    r = v.__eq__(None)
    assert r == False



# Generated at 2022-06-11 01:54:17.806422
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1') <= Version('2')
    assert Version('2') <= Version('2')
    assert not Version('3') <= Version('2')
    assert Version('a') <= Version('b')
    assert Version('b') <= Version('b')
    assert not Version('c') <= Version('b')
    v = Version('1')
    assert v <= '2'
    assert v <= '1'
    assert not v <= '0'
    v = Version('a')
    assert v <= 'b'
    assert v <= 'a'
    assert not v <= 'a+'

# Generated at 2022-06-11 01:54:23.598250
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version("1")
    assert v1 >= v1
    v2 = Version("2")
    assert not (v1 >= v2)
    assert v2 >= v1
    v1 = Version("2")
    assert v1 >= v1
    assert v2 >= v1
    v = Version("1")
    assert v >= "1"
    assert isinstance(v, Version)



# Generated at 2022-06-11 01:54:26.613396
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    #
    # Version.__gt__()
    #
    # Ensure that Version.__gt__() raises a TypeError when given a type
    # it doesn't understand.
    #

    v = Version('1.0')
    try:
        assert v > 1
        assert False, 'unknown type did not raise TypeError'
    except TypeError:
        pass




# Generated at 2022-06-11 01:54:29.619210
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('2.0.5')
    v3 = Version('0.1')
    assert v2 >= v1
    assert v2 >= '1.0'
    assert v1 <= v3

# Generated at 2022-06-11 01:54:30.880978
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import pytest, sys
    pytest.skip("No tests yet")

# Generated at 2022-06-11 01:55:14.432617
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('0')
    assert not (v == '1')
    assert not (v == '1.1')
    assert not (v == '1.0')
    assert v == '0'
    assert not (v == '0.0')
    assert not (v == '0.0.0')
    assert not (v == '0.1')
    assert not (v == '0.1.1')
    assert not (v == '0.1.0')
    assert not (v == '0a1')
    assert not (v == '0a1.1')
    assert not (v == '0a1.0')
    assert not (v == '0a0')
    assert not (v == '0a0.0')
    assert not (v == '0a0.0.0')
   

# Generated at 2022-06-11 01:55:16.170275
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v1.parse('1.2.3')
    v2 = Version()
    v2.parse('1.2.4')
    return v1 <= v2

# Generated at 2022-06-11 01:55:21.744896
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    vmin = Version("0")
    assert v >= vmin
    assert v <= vmin
    assert not v > vmin
    assert not v < vmin
    vmax = Version("1000")
    assert v <= vmax
    assert v >= vmin
    assert not v > vmax
    assert not v < vmin

# Generated at 2022-06-11 01:55:26.823117
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import sys
    import os
    import StringIO
    saved_stdout = sys.stdout
    try:
        out = StringIO.StringIO()
        sys.stdout = out
        v1 = Version('1')
        v2 = Version('2')
        v1.__eq__(v2)
        result = out.getvalue()
        answer = ''
        assert result == answer
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-11 01:55:29.367932
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    (a,b) = (Version("1.2.3"), Version("5.5.5"))
    return (a < b) and not (a > b)


# Generated at 2022-06-11 01:55:30.854523
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    Version.__ge__(Version('1.0'), '1.0')

# Generated at 2022-06-11 01:55:39.206453
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    def test_eq_str(v, s):
        return v >= s
    def test_eq_version(v, w):
        return v >= w
    test_eq_version(Version('1.2.3.4'), '1.2.3.4')
    test_eq_version(Version('1.2.3.4'), Version('1.2.3.4'))
    test_eq_str(Version('1.2.3.4'), '1.2.3.4')
    test_eq_version(Version('1.2.3.4'), '1.2.3.4')
    test_eq_version(Version('1.2.3.4'), Version('1.2.3.4'))



# Generated at 2022-06-11 01:55:40.432101
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')



# Generated at 2022-06-11 01:55:50.258348
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test method Version.__gt__"""
    v1 = Version(vstring='1.2')
    v2 = Version(vstring='1.3')
    assert (v1 < v2)
    assert (v1 <= v2)
    assert not (v1 == v2)
    assert not (v1 > v2)
    assert not (v1 >= v2)
    v1 = Version(vstring='1.2')
    v2 = Version(vstring='1.2')
    assert not (v1 < v2)
    assert (v1 <= v2)
    assert (v1 == v2)
    assert not (v1 > v2)
    assert (v1 >= v2)
    v1 = Version(vstring='1.3')
    v2 = Version(vstring='1.2')

# Generated at 2022-06-11 01:55:53.514532
# Unit test for method __le__ of class Version
def test_Version___le__():
    from lib2to3.pgen2.tokenize import detect_encoding
    import imp
    import pkg_resources
    import py_compile

    v = Version()
    assert v.__le__(None) is NotImplemented



# Generated at 2022-06-11 01:57:08.744896
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("3.3.0").__le__("3.3.0")
test_Version___le__()


# Generated at 2022-06-11 01:57:10.730882
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("1.3c1")
    v2 = Version("1.3")
    assert v1 > v2

# Generated at 2022-06-11 01:57:21.862995
# Unit test for method __le__ of class Version
def test_Version___le__():
    from . import version_class
    from . import version_error
    from . import version_string
    from . import version_bool

    # StrictVersion (1.0) <= StrictVersion(1.0)
    version_class.Version.__le__(version_class.StrictVersion('1.0'), version_class.StrictVersion('1.0'))

    # StrictVersion (1.0) <= StrictVersion(1.0)
    version_class.Version.__le__(version_class.StrictVersion('1.0'), version_class.StrictVersion('1.0'))

    # StrictVersion (1.0) <= StrictVersion(1.0)

# Generated at 2022-06-11 01:57:23.533563
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert 1 == 1


# Generated at 2022-06-11 01:57:24.784535
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version.__le__(Version(), Version()) == NotImplemented



# Generated at 2022-06-11 01:57:26.001966
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(4) == NotImplemented

# Generated at 2022-06-11 01:57:27.061696
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version().__gt__(Version()) == NotImplemented



# Generated at 2022-06-11 01:57:36.969395
# Unit test for method __le__ of class Version
def test_Version___le__():
    for obj in [Version(), Version('0.0.0')]:
        assert obj <= obj
    for (obj1, obj2) in [
            (Version(), Version()),
            (Version('0.0.0'), Version('0.0.0')),
            (Version('0.0.0'), Version('1.0.0')),
            (Version('1.0.0'), Version('2.0.0'))
    ]:
        assert obj1 <= obj2
        assert obj1 <= str(obj2)
    for (obj1, obj2) in [
            (Version('1.0.0'), Version('0.0.0')),
            (Version('2.0.0'), Version('1.0.0')),
    ]:
        assert not obj1 <= obj2

# Generated at 2022-06-11 01:57:44.004744
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils2.version import StrictVersion, LooseVersion
    # This test assumes that the two comparison methods are consistent
    for v1 in [Version("1"), StrictVersion("1"), LooseVersion("1")]:
        for v2 in [Version("2"), StrictVersion("2"), LooseVersion("2")]:
            assert (v1 < v2) is True
            assert (v2 > v1) is True
            assert (v2 <= v1) is False
            assert (v1 >= v2) is False
            assert (v1 == v2) is False
            assert (v1 != v2) is True

# Generated at 2022-06-11 01:57:54.682934
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest