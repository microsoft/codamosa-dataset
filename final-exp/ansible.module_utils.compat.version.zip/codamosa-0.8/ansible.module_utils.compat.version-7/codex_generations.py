

# Generated at 2022-06-11 01:51:05.187238
# Unit test for method __gt__ of class Version

# Generated at 2022-06-11 01:51:08.169864
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v_str = "1.2.3a4"
    v = StrictVersion(v_str)
    assert v.__str__() == v_str

# Generated at 2022-06-11 01:51:15.268786
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    def t1():
        """V 1.2, no prerelease"""
        v = StrictVersion('1.2')
        assert str(v) == '1.2'
    def t2():
        """V 1.2, prerelease"""
        v = StrictVersion('1.2.3.a3')
        assert str(v) == '1.2.3a3'
    t1()
    t2()



# Generated at 2022-06-11 01:51:22.757705
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import pytest
    from distutils.version import StrictVersion

# Generated at 2022-06-11 01:51:30.257399
# Unit test for method __le__ of class Version
def test_Version___le__():
    '''Unit test for method __le__ of class Version

    According to the official documents, this method is the same as
    __lt__ when it is used for rich comparison for this class.

    '''
    import random
    _str = random.randint(0, 100000)
    version = Version(_str)
    version.parse = lambda: None
    version.__le__ = lambda other: _str <= other

    assert version.__le__(_str) == _str <= _str

    return 

# Generated at 2022-06-11 01:51:37.935345
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.0')
    assert v.version == (1,0,0)
    assert v.prerelease is None
    v = StrictVersion('1.0.1')
    assert v.version == (1,0,1)
    assert v.prerelease is None
    v = StrictVersion('1.0a3')
    assert v.version == (1,0,0)
    assert v.prerelease == ('a', 3)
    v = StrictVersion('1.0b3')
    assert v.version == (1,0,0)
    assert v.prerelease == ('b', 3)
    assert_raises(ValueError, StrictVersion, '1')
    assert_raises(ValueError, StrictVersion, '1.0.1.1')
    assert_raises

# Generated at 2022-06-11 01:51:42.940444
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    v.parse("1.2.3")
    # This will fail if __ge__ sends the wrong comparison values to _cmp.
    assert v >= "1.2.3"
    try:
        1 >= 2
    except TypeError:
        print("ERROR: __ge__ did not return NotImplemented when appropriate")

# Generated at 2022-06-11 01:51:46.466062
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest
    # Version.__eq__(self, other)
    lv = LooseVersion("1.0")
    lv2 = LooseVersion("1.0")
    assert lv == lv2

    assert lv != None
    assert lv != "2.0"


# Generated at 2022-06-11 01:51:48.604242
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest

    class Version___lt__TestCase(unittest.TestCase):
        def test___lt__(self):
            self.assertEqual(Version().__lt__, Version._cmp)

    unittest.main()

# Generated at 2022-06-11 01:51:55.612397
# Unit test for method __ge__ of class Version

# Generated at 2022-06-11 01:52:05.823699
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = distutils.version.Version()

# Generated at 2022-06-11 01:52:06.438327
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass



# Generated at 2022-06-11 01:52:09.507486
# Unit test for method __le__ of class Version
def test_Version___le__():
    # No tests yet; I'm not even sure what the right test cases are,
    # much less how to write them.

    pass



# Generated at 2022-06-11 01:52:12.610271
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  v1 = Version('1.0')
  v2 = Version('1.0')
  v3 = Version('1.0.0')
  v4 = Version('1.0.1')
  assert (v1 == v2)
  assert not (v1 == v3)
  assert not (v1 == v4)


# Generated at 2022-06-11 01:52:17.795866
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    a = Version()
    b = Version()
    assert a == b
    assert not a != b
    c = Version('5.0.0')
    d = Version('5.0.0')
    assert c == d
    assert not c != d
    # See issue 784458
    f = Version('5.0.0.dev571')
    assert f == f



# Generated at 2022-06-11 01:52:28.992611
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-11 01:52:37.510710
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import sys
    import subprocess
    import os
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    from cStringIO import StringIO as cStringIO

    old_stdout = sys.stdout
    sys.stdout = mystdout = cStringIO()
    try:
        from distutils.version import Version
    except:
        from distutils.version import Version
    sys.stdout = old_stdout
    import os
    _path = os.path.realpath(__file__)
    _, _fname = os.path.split(_path)
    _fhandle, _ = os.path.splitext(_fname)
    _result_file = _fhandle + '.expected'
    _result_str = open(_result_file, 'r').read

# Generated at 2022-06-11 01:52:40.088365
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    other = NotImplemented
    c = version.__lt__(other)
    print(c)


# Generated at 2022-06-11 01:52:42.430525
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() >= ""
    assert Version() <= ""
    assert Version() == ""
    assert Version() != "1.0"

# Generated at 2022-06-11 01:52:47.029698
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    version = Version(vstring='1.0')
    other = Version(vstring='1.0')

    assert version._cmp(other) == 0
    assert version == other
    assert version >= other
    assert version <= other
    assert not version != other
    assert not version > other
    assert not version < other


# Generated at 2022-06-11 01:53:06.470003
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    other = Version()
    assert version.__ge__(other)
    assert version.__ge__(None) is NotImplemented
    assert version.__ge__(1) is NotImplemented


# Generated at 2022-06-11 01:53:12.259489
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from ansiblelint.utils import ansiblelint_support
    assert ansiblelint_support.Version('2.0') >= ansiblelint_support.Version('1.0')
    assert not (ansiblelint_support.Version('1.0') >= ansiblelint_support.Version('2.0'))

# Generated at 2022-06-11 01:53:16.826343
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version(vstring=None)
    other = Version(vstring=None)
    c = version._cmp(other)
    if c is NotImplemented:
        c = version._cmp(other)
    else:
        pass
    if c == 0:
        c = version._cmp(other)
    else:
        pass



# Generated at 2022-06-11 01:53:27.555516
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils2.version import Version

    v = Version('1.0')

    assert v.__ge__(v) is True, "True expected"
    assert v.__ge__(Version('1.0')) is True, "True expected"
    assert v.__ge__(Version('1.0a1')) is True, "True expected"


    assert v.__ge__(Version('1.1')) is False, "False expected"


    assert v.__ge__('1.0') is True, "True expected"
    assert v.__ge__('1.0a1') is True, "True expected"
    assert v.__ge__('1.1') is False, "False expected"


# Generated at 2022-06-11 01:53:38.328517
# Unit test for method __le__ of class Version
def test_Version___le__():
    import os
    from .test_ansible.unit.compat.mock import patch, call
    from .test_ansible.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class AnsibleModule(object):
        def __init__(self, params):
            self.params = params

    VALID_PATHS = [
        '/usr/bin/python',
        '/usr/bin/python2.7',
        '/usr/bin/python3.7'
    ]

    EXPECTED_COMMAND = [
        '/usr/bin/python',
        '--version'
    ]

    EXIT_JSON_CALL = call(changed=False, python_details={'python': '/usr/bin/python'})


# Generated at 2022-06-11 01:53:44.045688
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # ------------------------------------------------------------------------------------
    # Version instances of different types are never equal; so in test_Version___lt__,
    # we don't worry about cases where other is not a Version instance.
    # ------------------------------------------------------------------------------------
    _v = Version()
    _o = Version()
    _result = _v.__lt__(_o)
    assert _result is None
    return



# Generated at 2022-06-11 01:53:50.221896
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    test_cases = [
        ['0.1.1', '0.1.1', True],
        ['0.2.1', '0.1.1', True],
        ['0.1.1', '0.2.1', False],
        ['0.1.1.1', '0.2.1.2', False],
    ]
    for test_case in test_cases:
        v1 = StrictVersion(test_case[0])
        v2 = StrictVersion(test_case[1])
        expected = test_case[2]
        result = v1 >= v2
        if result != expected:
            print("test_Version___ge__: %r >= %r expected=%r got=%r" % (v1, v2, expected, result))



# Generated at 2022-06-11 01:53:53.010646
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    v1 = Version()
    v2 = Version()
    v3 = Version()
    v4 = Version()
    assert()

# Generated at 2022-06-11 01:53:58.813353
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    zz = Version()
    zz.parse('1.0.4')
    for xx in [Version(), Version('1.0.4'), Version('1.0.3'), Version('1.0.4'), Version('1.0.4.1')]:
        if (not (xx < zz)) or (xx == zz):
            return False
    return True

# Generated at 2022-06-11 01:54:00.245497
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert (v == "1.0")


# Generated at 2022-06-11 01:54:31.198244
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from nose.tools import assert_equal, assert_raises # type: ignore
    from ...unit.test_version import Version

    v = Version('1.5.1b3')
    assert_equal(v >= '1.5.1b2', True)
    assert_equal(v >= '1.5.1b3', True)
    assert_equal(v >= '1.5.1b4', False)
    assert_raises(ValueError, lambda: (v >= '1.5.1'))



# Generated at 2022-06-11 01:54:34.101901
# Unit test for method __le__ of class Version
def test_Version___le__():
  assert Version("1") <= Version("1")
  assert Version("a") <= Version("b")
  assert not (Version("1.1") <= Version("1"))


# Generated at 2022-06-11 01:54:39.576305
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    n = Version('1.2.3')
    assert n >= n
    assert n >= '1.2.3'
    assert n >= '1.2'
    assert n >= '1'
    assert not n >= '2.2'
    assert not n >= '2'
    assert not n >= '2.2.4'



# Generated at 2022-06-11 01:54:42.411332
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 >= v1
    assert not v1 >= v2


# Generated at 2022-06-11 01:54:44.632893
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version1 = Version('1.0')
    version2 = Version('1.1')
    assert version1 < version2


# Generated at 2022-06-11 01:54:49.562139
# Unit test for method __le__ of class Version
def test_Version___le__():
    print("test_Version___le__")
    class XYZ(Version):
        pass
    v=XYZ("99.9.9")
    w=XYZ("99.9.9.3")
    assert(v<=w)
test_Version___le__()


# Generated at 2022-06-11 01:54:56.872427
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest
    # Version, text
    # Version.__le__(text)

    class UnitTestVersion(Version):
        def parse(self, vstring):
            if vstring == 'ok':
                return
            raise ValueError(vstring)

    class VersionTestCase(unittest.TestCase):
        version_class = Version

        def test_ok_string(self):
            p = self.version_class('ok')
            self.assertTrue(p <= 'ok')
            self.assertFalse(p <= 'not ok')

        def test_bad_string(self):
            p = self.version_class('ok')
            self.assertRaises(ValueError, p.__le__, 'not ok')

        def test_bad_version(self):
            p1 = self.version_class('ok')

# Generated at 2022-06-11 01:55:07.138993
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.3.3-5a')
    assert (v >= '1.3.3-5a') == True
    assert (v >= '1.3.3-5b') == False
    assert (v >= '1.3.3-5c') == False
    assert (v >= '1.3.3-5d') == False
    assert (v >= '1.3.3-6') == False
    assert (v >= '1.3.3-6a') == False
    assert (v >= '1.3.3-6b') == False
    assert (v >= '1.3.3-6c') == False
    assert (v >= '1.3.3-6d') == False
    assert (v >= '1.3.3-7') == False

# Generated at 2022-06-11 01:55:10.228177
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from lib2to3.pgen2.tokenize import group
    group("x", "y", "z")
    group("x[1]", "y[1]", "z[1]")

# Generated at 2022-06-11 01:55:20.285385
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.2.3")
    v2 = Version("1.2.3")

    def _raise(e):
        raise e

    try:
        _raise(v1 < v2)
        raise AssertionError()
    except TypeError:
        pass

    try:
        _raise(v2 <= v2)
        raise AssertionError()
    except TypeError:
        pass

    try:
        _raise(v2 >= v2)
        raise AssertionError()
    except TypeError:
        pass

    try:
        _raise(v2 > v2)
        raise AssertionError()
    except TypeError:
        pass
    

# Generated at 2022-06-11 01:56:15.940721
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.1') > Version('1.0')

# Generated at 2022-06-11 01:56:18.376835
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert (v1 >= v2) is NotImplemented


# Generated at 2022-06-11 01:56:20.486536
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    version2 = Version()
    assert version <= version2
    version = Version()
    version2 = Version()
    assert version <= version2

# Generated at 2022-06-11 01:56:21.671775
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('a') >= 'b'



# Generated at 2022-06-11 01:56:22.847008
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version().__gt__('1.2') is NotImplemented

# Generated at 2022-06-11 01:56:26.397527
# Unit test for method __le__ of class Version
def test_Version___le__():
    t = Version()
    t._cmp = lambda s: -1
    assert t <= 1
    t._cmp = lambda s: 1
    assert not t <= 1
    t._cmp = lambda s: 0
    assert t <= 1

# Generated at 2022-06-11 01:56:30.551595
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    c = Version('0.9.9')
    d = Version('0.9.10')
    assert c < d is True
    assert c <= d is True
    assert c == d is False
    assert c != d is True
    assert c >= d is False
    assert c > d is False
test_Version___lt__()


# Generated at 2022-06-11 01:56:32.949099
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    pass # Don't know how to unit test method __lt__ of class Version



# Generated at 2022-06-11 01:56:34.785510
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert (not (Version("3.9.5") <= "3.9.5"))


# Generated at 2022-06-11 01:56:38.067439
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Unit test for method __gt__ of class Version."""
    import pytest
    a = Version('1.2.3')
    b = Version('1.2.3')
    c = Version('1.2.4')
    assert not a > b
    assert c > b

    d = '1.2.3'
    assert not a > d
    assert c > d

    with pytest.raises(NotImplementedError):
        _ = a > 3.2

    with pytest.raises(NotImplementedError):
        _ = a > []

    with pytest.raises(NotImplementedError):
        _ = a > {}

# Generated at 2022-06-11 01:58:49.900543
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) is NotImplemented
    v1 = 1
    v2 = 1
    assert v1.__gt__(v2) is NotImplemented
    v1 = Version()
    v2 = 1
    assert v1.__gt__(v2) is NotImplemented

# Generated at 2022-06-11 01:59:02.034646
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Test args are: arg1, arg2, expected
    test_cases = [
        ((Version(), Version()), False),
        ((Version(), 2), False),
        ((Version(), '2'), False),
        ((Version(), Version('2')), True),
        ((Version(), Version('1.1')), False),
        ((Version('1.1'), Version('2')), True),
        ((Version('1.1'), Version('2.3')), True),
        ((Version('1.1.1'), Version('1.1.1')), False),
    ]
    for tc in test_cases:
        actual = tc[0][0] < tc[0][1]

# Generated at 2022-06-11 01:59:12.583155
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    if not isinstance(v1,Version):
        raise TypeError("version.py: version.Version (class) __gt__: v1 ({}) is not instance of class Version".format(instance, cls, v1))
    v1_ver = getattr(v1,'ver',None)
    if not isinstance(v1_ver,tuple):
        raise TypeError("version.py: version.Version (class) __gt__: v1.ver ({}) is not instance of tuple".format(v1_ver))
    if not isinstance(other,Version):
        raise TypeError("version.py: version.Version (class) __gt__: other ({}) is not instance of class Version".format(other))
    other_ver = getattr(other,'ver',None)

# Generated at 2022-06-11 01:59:15.453735
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    version._cmp = lambda: 0
    assert version.__lt__(1) == 0
    assert version.__lt__(None) is NotImplemented

# Generated at 2022-06-11 01:59:17.707676
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert(v == '1.2.3')


# Generated at 2022-06-11 01:59:20.477715
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert not Version('1.0') == '2.0'
    assert Version('1.0') == '1.0'
    assert not Version('2.0') == '1.0'



# Generated at 2022-06-11 01:59:24.784266
# Unit test for method __le__ of class Version
def test_Version___le__():
    import lib2to3.tests.support
    v1 = lib2to3.tests.support.make_version('1.2.3')
    assert v1 <= '1.2'
    assert v1 <= '1.2.3'
    assert v1 <= '1.2.3a1'

# Generated at 2022-06-11 01:59:28.255023
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest
    assert Version('1.1') <= Version('1.2')
    assert Version('1.1') <= Version('1.1')
    assert Version('1.1') <= '1.2'
    assert Version('1.1') <= '1.1'
    assert not Version('1.2') <= Version('1.1')
    assert not Version('1.2') <= '1.1'
    assert not Version('1.1') <= '1.0'



# Generated at 2022-06-11 01:59:31.500435
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    # NOTE: This test is not complete because the class's superclass
    #       object doesn't implement the rich comparison methods, and
    #       Version's implementation of __gt__ calls them.



# Generated at 2022-06-11 01:59:38.428623
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test method distutils.version.Version.__gt__ of class Version."""

    v = Version()

    # Test that 'other' is a string, and that it is compared to a
    # string representation of the Version instance.
    class Other(object):

        def __str__(self):
            return 'x.y'

    other = Other()
    v._cmp = lambda other: (other.__class__.__name__ == 'Other'), 'answer'
    assert v > other == ('answer', 'Other')
    v._cmp = lambda other: (other == 'x.y'), 'answer'
    assert v > other == ('answer', 'Other')
    return # test_Version___gt__
