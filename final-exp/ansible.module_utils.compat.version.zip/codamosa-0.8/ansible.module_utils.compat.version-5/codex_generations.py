

# Generated at 2022-06-11 01:50:59.041774
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from copy import copy
    from unittest.mock import Mock
    from distutils.version import Version
    from pytest import raises
    v1 = Version()
    v1.parse = Mock(return_value=None)
    v2 = copy(v1)
    v2.version = '1.1'
    v1._cmp = Mock(return_value=-1)
    v1 < v2
    v1._cmp.assert_called_once_with(v2)
    v1._cmp = Mock(return_value=0)
    v1 < v2
    v1._cmp.assert_called_with(v2)
    v1._cmp = Mock(return_value=1)
    v1 < v2
    v1._cmp.assert_called_with(v2)

# Generated at 2022-06-11 01:51:00.934338
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True


# Generated at 2022-06-11 01:51:04.015488
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v1.parse("1.2")
    v2 = Version()
    v2.parse("1.2")
    #expected = False
    #computed = v1.__gt__(v2)
    #return expected ==  computed


# Generated at 2022-06-11 01:51:07.468630
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    x = Version('1')
    y = Version('2')
    r = x > y
    assert r == False
test_Version___gt__()


# Generated at 2022-06-11 01:51:10.359545
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  v1 = Version()
  v2 = Version()
  assert v1 == v2
test_Version___eq__()

# Generated at 2022-06-11 01:51:15.553524
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)
    try:
        v = StrictVersion('11.2.3a3')
        assert False
    except ValueError as e:
        assert True
# End unit test



# Generated at 2022-06-11 01:51:18.874122
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from . import version as test_class
    instance1 = test_class.Version()
    instance2 = test_class.Version()
    test_value = instance1 < instance2
    assert True == test_value


# Generated at 2022-06-11 01:51:20.862656
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    return v == v

# Generated at 2022-06-11 01:51:32.551383
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('0.0.0')
    v2 = Version('0.0.0')
    v3 = Version('0.1.0')
    assert(v1 == v2)
    assert(v1 <= v2)
    assert(v1 >= v2)
    assert(v1 <= v3)
    assert(v1 < v3)
    assert(v3 > v1)
    assert(v3 >= v1)
    assert(v1 == '0.0.0')
    assert(v1 <= '0.0.0')
    assert(v1 >= '0.0.0')
    assert(v1 <= '0.1.0')
    assert(v1 < '0.1.0')
    assert(v3 > '0.0.0')

# Generated at 2022-06-11 01:51:43.070900
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    import sys
    class VersionTestCase(unittest.TestCase):
        def test___gt__(self):
            v1 = Version('1.0')
            v2 = Version('2.0')
            self.assertTrue(v2.__gt__(v1))
            self.assertFalse(v1.__gt__(v2))
        def test___gt__upgrade(self):
            v1 = Version('1.0')
            v2 = sys.version_info
            self.assertTrue(v2.__gt__(v1))
            self.assertFalse(v1.__gt__(v2))
    suite = unittest.TestLoader().loadTestsFromTestCase(VersionTestCase)
    return suite
test_Version___gt__suite = test_Version___gt__()

# Generated at 2022-06-11 01:51:59.985619
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version() >= Version()
    assert Version() >= Version('')
    assert Version('9999') >= Version()
    assert Version('9999') >= Version('9999')
    assert Version('9999') >= Version('42')
    assert not (Version('1') >= Version('2'))


    assert Version('1') >= '0'
    assert not (Version('1') >= '1.0')
    assert not (Version('1.0') >= '1.1')


# Generated at 2022-06-11 01:52:07.939996
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class TestVersion(Version):
        def parse(self, vstring):
            pass

        def _cmp(self, other):
            return 0

    v1 = TestVersion()

    # Test that TypeError is raised for non-Version and non-string
    # parameter
    try:
        v1.__gt__(123456789)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised for non-Version and non-string parameter')

    # Test that NotImplemented is returned for a non-Version parameter
    x = 123456789
    assert v1.__gt__(x) == NotImplemented

    # Test that TypeError is raised for a string parameter
    try:
        v1.__gt__('123456789')
    except TypeError:
        pass


# Generated at 2022-06-11 01:52:09.233942
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version() > Version()==False

# Generated at 2022-06-11 01:52:10.300726
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('')



# Generated at 2022-06-11 01:52:12.730165
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Method __gt__ of class Version"""
    v = Version('1.0')
    assert (v > '0.9')



# Generated at 2022-06-11 01:52:16.391182
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Version.__le__(other)
    # Version.__le__(self, other)
    assert Version('1.2.3') <= Version('1.2.3')
# tests/test_versions.py::test_Version___le__ PASSED


# Generated at 2022-06-11 01:52:18.199084
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version.Version("0.9")
    assert v > "0.1"



# Generated at 2022-06-11 01:52:21.348581
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Test Version.__lt__"""

    v1 = Version("1.1.1")
    v2 = Version("2.2.2")

    assert v1 < v2

    v1 = Version("1.0-alpha")
    v2 = Version("1.0-beta")

    assert v1 < v2




# Generated at 2022-06-11 01:52:25.465388
# Unit test for method __ge__ of class Version
def test_Version___ge__():
#

    v = Version()
    v.parse(vstring = '1.2')
    other = 1
    c = v._cmp(other = other)
    assert c == -1
    assert c is not NotImplemented
#

# Generated at 2022-06-11 01:52:33.687685
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('') > Version('') == False
    assert Version('') > Version('1.0') == False
    assert Version('1.0') > Version('1.0') == False
    assert Version('1.0') > Version('2.0') == False
    assert Version('1.0') > Version('1.1') == False
    assert Version('1.0') > Version('1.0a1') == False
    assert Version('2.0') > Version('1.0') == True
    assert Version('1.1') > Version('1.0') == True
    assert Version('1.0a1') > Version('1.0') == True

# Generated at 2022-06-11 01:52:49.872881
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """_Version__lt__()"""

    import doctest
    doctest.testmod()


# Generated at 2022-06-11 01:52:51.313547
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-11 01:52:52.608844
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__("") == NotImplemented

# Generated at 2022-06-11 01:52:56.551519
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils2.version import Version as v
    assert v('1.2') > v('1.1')
    assert not (v('1.1') > v('1.1'))
    assert not (v('1.1') > v('1.2'))



# Generated at 2022-06-11 01:52:58.853103
# Unit test for method __le__ of class Version
def test_Version___le__():
    _v = Version()
    assert _v.__le__(0) == True

# Generated at 2022-06-11 01:53:02.872975
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version("1.0")
    assert v1 == v1
    assert v1 == "1.0"
    assert v1 != "1.1"
    assert v1 != Version("1.1")

# Generated at 2022-06-11 01:53:04.560169
# Unit test for method __le__ of class Version
def test_Version___le__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-11 01:53:12.105304
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__lt__(v2) == False
    assert v2.__lt__(v1) == False
    v1 = Version('1.2.2')
    v2 = Version('1.2.3')
    assert v1.__lt__(v2) == True
    assert v2.__lt__(v1) == False

# Generated at 2022-06-11 01:53:17.654466
# Unit test for method __gt__ of class Version

# Generated at 2022-06-11 01:53:19.766318
# Unit test for method __le__ of class Version
def test_Version___le__():
    ver1 = Version('1.0')
    ver2 = Version('2.0')
    assert ver1 <= ver2

# Generated at 2022-06-11 01:53:35.349601
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ver = Version("1.0")
    other = Version("1.1")
    assert ver < other



# Generated at 2022-06-11 01:53:38.155432
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version("1.2.3")
    v2 = Version("4.5.6")
    v3 = Version("1.2.3")
    assert v1 == v3
    assert not(v1 == v2)


# Generated at 2022-06-11 01:53:46.162527
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test method Version.__gt__."""
    v = Version()
    v.parse('1.2a.3')
    assert v > '1.2a.3'
    assert v > '1.2a'
    assert v > '1.2'
    assert v > '1'
    assert v > ''
    assert v > 'a.2'
    assert v > '2'
    assert v > '1.2a.4'
    assert v > '1.2b'
    assert v > '1.2b.3'

# Generated at 2022-06-11 01:53:50.626679
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ver = Version()
    assert ver._cmp('1') == NotImplemented
    ver = Version('1.0')
    assert ver._cmp('1.0') == 0
    assert ver._cmp('1.1') == -1
    assert ver._cmp('0.9') == 1
    assert ver._cmp('0.1') == 1

# Generated at 2022-06-11 01:53:53.926990
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        s = Version('1.2')
        t = Version('1.3')
        assert s == s
        assert s != t
    except:
        return False
    return True

# Generated at 2022-06-11 01:54:04.373674
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_number_instances = [
        StrictVersion,
        LooseVersion,
    ]

    for version_number_instance in version_number_instances:
        obj = version_number_instance()
        obj_cmp = obj._cmp(obj)
        obj_gt = obj.__gt__(obj_cmp)
        obj_cmp_gt = obj_cmp.__gt__(obj_cmp)
        obj_lt = obj.__lt__(obj_cmp)
        obj_cmp_lt = obj_cmp.__lt__(obj_cmp)
        obj_ge = obj.__ge__(obj_cmp)
        obj_cmp_ge = obj_cmp.__ge__(obj_cmp)
        obj_le = obj.__le__(obj_cmp)
        obj_cmp_le = obj_cmp.__

# Generated at 2022-06-11 01:54:06.542981
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    c = v._cmp(other)
    assert c is NotImplemented
    assert c > 0
    return

# Generated at 2022-06-11 01:54:12.485179
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('0') >= '0'
    assert not Version('0') >= '1'
    assert Version('1') >= '0'
    assert Version('0') >= Version('0')
    assert not Version('0') >= Version('1')
    assert Version('1') >= Version('0')
    assert not Version('100') >= Version('1')
    assert Version('1') >= Version('100')


# Generated at 2022-06-11 01:54:15.403093
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # version.py:36
    """Tests the method Version.__gt__ of the Version class"""
    pass



# Generated at 2022-06-11 01:54:17.886160
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("1.2")
    v2 = Version("1.2")
    expected = True
    actual = v1 <= v2
    assert actual == expected


# Generated at 2022-06-11 01:54:34.481569
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v1.parse('1.0')
    v2 = Version()
    v2.parse('2.0')
    assert v1 < v2


# Generated at 2022-06-11 01:54:36.989498
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import datetime
    x = datetime.date(2006, 11, 21)
    y = x.__gt__(x)
    return y


# Generated at 2022-06-11 01:54:37.710044
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass

# Generated at 2022-06-11 01:54:46.965386
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert (Version('1.0') >= Version('1.0')) is True
    assert (Version('1.0') >= Version('1.0.0')) is True
    assert (Version('1.0.0') >= Version('1.0')) is True
    assert (Version('1.0.4') >= Version('1.0.1')) is True
    assert (Version('1.0.0') >= Version('1.0a0')) is True
    assert (Version('1.0a0') >= Version('1.0b0')) is True
    assert (Version('1.0b0') >= Version('1.0c0')) is True
    assert (Version('1.0') >= Version('1.0.dev0')) is True

# Generated at 2022-06-11 01:54:51.356153
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version(vstring="0.9.9")
    v2 = Version(vstring="0.9.10")
    v3 = Version(vstring="1.0")
    assert v1 <= v2
    assert v2 <= v3
    assert v1 <= v3


# Generated at 2022-06-11 01:55:02.618774
# Unit test for method __le__ of class Version
def test_Version___le__():
    import os
    import tempfile
    from ansible_test.utils import create_files
    from ansible_test.utils import get_coverage_paths
    from ansible_test.utils import get_excluded_paths

    test_data = dict(
        version1 = b'1.2.3',
        version2 = b'2.3.4',
        version3 = b'1.2.4',
    )

    paths = dict(
        version1 = 'ansible/utils/version.py',
        version2 = 'ansible/utils/version.py',
        version3 = 'ansible/utils/version.py',
    )

    excluded_paths = get_excluded_paths()


# Generated at 2022-06-11 01:55:06.127752
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    assert(v1 >= v1)



# Generated at 2022-06-11 01:55:14.023128
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest
    from ansible.module_utils.six import PY2

    class TestVersionBase:
        def test_cmp_lt(self):
            if PY2:
                # In Python 3, this would return False. This is not
                # considered a bug.
                self.assertEqual(self.v1 < self.v2, True)
            self.assertEqual(self.v1 < self.v2, False)
            self.assertEqual(self.v1 < self.v3, False)
            self.assertEqual(self.v1 < self.v4, False)


# Generated at 2022-06-11 01:55:14.918445
# Unit test for method __le__ of class Version
def test_Version___le__(): assert isinstance(Version("foo").__le__(Version("bar")), bool)

# Generated at 2022-06-11 01:55:17.745961
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    v1._cmp = lambda other: 0
    assert v1 >= v2

# Generated at 2022-06-11 01:55:38.440863
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    v3 = Version()
    v1._cmp = v2._cmp = v3._cmp = lambda x: NotImplemented
    assert not (v1 > v2)
    assert not (v2 > v1)
    assert not (v1 > v1)
    assert not (v2 > v2)
    assert not (v3 > v2)
    assert not (v2 > v3)
    assert not (v1 > v3)
    assert not (v3 > v1)



# Generated at 2022-06-11 01:55:40.616932
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(Version()) == True
    assert Version().__eq__(Version('0')) == True
    assert Version().__eq__(object()) == NotImplemented

# Generated at 2022-06-11 01:55:48.898881
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    
    # :: classmethod -> No return value
    def test_Version___gt___(self): pass
    test_Version___gt___.__dict__ = dict()
    # :: classmethod -> No return value
    def test_Version___gt___(self): pass
    test_Version___gt___.__dict__ = dict()
    # :: classmethod -> No return value
    def test_Version___gt___(self): pass
    test_Version___gt___.__dict__ = dict()
    # :: classmethod -> No return value
    def test_Version___gt___(self): pass
    test_Version___gt___.__dict__ = dict()
    
    

# Generated at 2022-06-11 01:55:56.539767
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # test_Version___eq__()
    print("Testing version.Version.__eq__()")
    vers1 = Version("0.0.2")
    vers2 = Version("0.0.1")
    vers3 = Version("0.0.2")
    vers4 = Version("0.0.3")
    print("vers1 == vers2 (should be False):", vers1 == vers2)
    print("vers1 == vers3 (should be True):", vers1 == vers3)
    print("vers1 == vers4 (should be False):", vers1 == vers4)
    print("vers2 == vers3 (should be False):", vers2 == vers3)
    print("vers2 == vers4 (should be False):", vers2 == vers4)

# Generated at 2022-06-11 01:56:01.546912
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert Version('1.2.3') == Version('1.2.3')
    assert Version('1.2.3') == '1.2.3'
    assert v == v
    assert not v == ''
    assert not v == None
    assert v == v


# Generated at 2022-06-11 01:56:02.971836
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(1) == NotImplemented

# Generated at 2022-06-11 01:56:06.937585
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest
    class testcase_Version___ge__(unittest.TestCase):
        def test_Version___ge__(self):
            # Version.__ge__
            # self.assertEqual(expected, Version.__ge__(other))
            raise NotImplementedError('test failed')
    unittest.main()


# Generated at 2022-06-11 01:56:08.753622
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    c = v._cmp(Version())
    assert c == 0

# Generated at 2022-06-11 01:56:19.356240
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Method __ge__ of class Version should return True when self._cmp(other) is >= 0
    # and False otherwise.
    import unittest
    import random
    import sys
    class TestVersion___ge__(unittest.TestCase):
        def setUp(self):
            self.seeds = [random.randrange(sys.maxsize) for _ in range(10)]
            random.seed(self.seeds.pop(0))

        def tearDown(self):
            random.seed(self.seeds.pop(0))

        def test_positive_1(self):
            class MyVersion(Version):
                def _cmp(self, other):
                    return 2

            self.assertTrue(MyVersion() >= MyVersion())


# Generated at 2022-06-11 01:56:20.835353
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version();
    assert(v.__ge__("0") is NotImplemented)


# Generated at 2022-06-11 01:56:52.301486
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    try:
        raise NotImplementedError()
    except NotImplementedError:
        pass


# Generated at 2022-06-11 01:56:55.269701
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 == v2
    assert v1 == '1.2.3'

# Generated at 2022-06-11 01:56:59.285672
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  v1 = Version("1")
  v2 = Version("2")
  vn = Version("-1")
  assert v1 == v1
  assert v1 != v2
  assert v1 != vn


# Generated at 2022-06-11 01:57:04.550622
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  assert Version('0') >= Version('0') == True
  assert Version('0') >= Version('1') == False
  assert Version('0') >= Version('-1') == True



# Generated at 2022-06-11 01:57:06.103839
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert not v.__lt__(None)

# Generated at 2022-06-11 01:57:09.100303
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.1.1')
    v2 = Version('1.1.1')
    assert v1 < v2 == False



# Generated at 2022-06-11 01:57:14.567367
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    class Test_Version___lt___subclass(Version):
        def _cmp(self, other):
            return 0
    #
    # Test Case: True
    #
    assert Test_Version___lt___subclass('') < Test_Version___lt___subclass('')
    #
    # Test Case: False
    #
    assert not (Test_Version___lt___subclass('') < Test_Version___lt___subclass('a'))
    #
    # Test Case: NotImplemented
    #
    assert Test_Version___lt___subclass('')._cmp('') is NotImplemented


# Generated at 2022-06-11 01:57:17.718474
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) is True
    assert v.__le__(None) is False


# Generated at 2022-06-11 01:57:27.081825
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import LooseVersion, StrictVersion
    lv = LooseVersion
    sv = StrictVersion

    for (a, b) in [('1.0', '2.0'),
                   ('1.1', '1.2'),
                   ('1.1.1', '1.1.2'),
                   ('1.1.1', '1.1'),
                   ('1.0', '1.0.1'),
                   ('1.0.1', '1.0.2')]:
        assert lv(a) <= lv(b)
        assert sv(a) <= sv(b)
        assert not lv(b) <= lv(a)
        assert not sv(b) <= sv(a)
        assert lv(a) <= a
        assert sv(a) <= a
        assert sv

# Generated at 2022-06-11 01:57:35.459765
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ver_1 = Version()
    ver_2 = Version()

    # Test when self._cmp(other) is NotImplemented
    with pytest.raises(TypeError):
        ver_1.__gt__(object())

    # Test when c == 0
    ver_1._cmp = lambda other: 0
    assert ver_1.__gt__(ver_2) == False

    # Test when c > 0
    ver_1._cmp = lambda other: 1
    assert ver_1.__gt__(ver_2) == True

    # Test when c < 0
    ver_1._cmp = lambda other: -1
    assert ver_1.__gt__(ver_2) == False



# Generated at 2022-06-11 01:58:51.761306
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0.0')
    v2 = Version('2.0.0')
    v3 = Version('1.0.0')
    assert v1 >= v2 # __le__(self, other)
    assert v1 <= v3 # __le__(self, other)


# Generated at 2022-06-11 01:58:54.348712
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('0.1')
    v2 = Version('0.2')
    assert v1 < v2
    assert v2 > v1
    assert v1 <= v2
    assert v2 >= v1
    assert not v1 == v2


# Generated at 2022-06-11 01:58:55.045406
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert (True is True)

# Generated at 2022-06-11 01:59:03.714349
# Unit test for method __lt__ of class Version

# Generated at 2022-06-11 01:59:07.165776
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    other = Version()
    try:
        ret = v.__lt__(other)
    except Exception as e:
        assert False, f"Unhandled exception: {e}"

# Generated at 2022-06-11 01:59:08.182163
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version() == Version()

# Generated at 2022-06-11 01:59:10.324761
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    other = object()
    try:
        if version >= other:
            pass
    except TypeError:
        pass

# Generated at 2022-06-11 01:59:12.006442
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    val = Version()
    assert val > 'mystring'


# Generated at 2022-06-11 01:59:18.104964
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest
    class Test_Version___eq__(unittest.TestCase):
        def test(self):
            # version.py:949
            v = Version()
            self.assertTrue(v.__eq__('3.6.9') == NotImplemented)
            v2 = Version('3.6.9')
            self.assertTrue(v.__eq__(v2) == False)
            v.parse('3.6.9')
            self.assertTrue(v.__eq__(v2) == True)
    #
    unittest.main(exit=False, verbosity=2)


# Generated at 2022-06-11 01:59:19.792879
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import sys


    assert sys.version < '3'
    assert not (sys.version < '2')