

# Generated at 2022-06-11 01:50:49.276665
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """
    >>> Version() > 1
    False
    """



# Generated at 2022-06-11 01:50:53.243905
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    Version = distutils.version.Version
    v = Version("0.4.0")
    assert not (v < None)
    v1 = Version("0.4.0")
    v2 = Version("0.4.1")
    assert v1 < v2

# Generated at 2022-06-11 01:51:03.877080
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v = StrictVersion('0')
    assert v.version == (0,)
    assert v.prerelease is None
    v = StrictVersion('0.3.0')
    assert v.version == (0, 3, 0)
    assert v.prerelease is None
    v = StrictVersion('0.0.0')
    assert v.version == (0, 0, 0)
    assert v.prerelease is None
    v = StrictVersion('0.0.0.dev7')
    assert v.version == (0, 0, 0)
    assert v.prerelease == ('d', 7)

# Generated at 2022-06-11 01:51:09.685631
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert v >= '1.2.0'
    assert v >= '1.0.0'
    assert not v >= '1.2.4'
    assert not v >= '2.0.0'

# Generated at 2022-06-11 01:51:18.190617
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('2.1.1').__str__() == '2.1.1'
    assert StrictVersion('2.1').__str__() == '2.1.0'
    assert StrictVersion('2.1.1a3').__str__() == '2.1.1a3'
    assert StrictVersion('2.1.1b3').__str__() == '2.1.1b3'
    assert StrictVersion('2.1.1a3b3').__str__() == '2.1.1a3b3'



# Generated at 2022-06-11 01:51:25.229219
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1.__lt__(v2) == NotImplemented
    v1.parse('0.0.0')
    v2.parse('1.1.1')
    assert v1.__lt__(v2) == True
    assert v2.__lt__(v1) == False

# Generated at 2022-06-11 01:51:26.865799
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == '1.2.3'


# Generated at 2022-06-11 01:51:31.400987
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2
    assert v1 <= v2
    assert v1 >= v2
    assert not v1 != v2
    assert not v1 < v2
    assert not v1 > v2

test_Version___lt__()

# Generated at 2022-06-11 01:51:35.026740
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """Test __str___ in class StrictVersion by comparing returned string with expected value"""

    # Setup
    expected = "1.0.4a3"
    version = StrictVersion(expected)

    # Exercise
    actual = version.__str__()

    # Verify
    assert actual == expected


# Generated at 2022-06-11 01:51:45.594571
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    print("testing StrictVersion __str__...")

    def test(version, expected):
        v = StrictVersion(version)
        actual = str(v)
        assert expected == actual, \
            "'{}' expected '{}' found '{}'".format(version, expected, actual)

    test('0.4', '0.4')
    test('0.4.0', '0.4.0')
    test('0.4.1', '0.4.1')
    test('0.5a1', '0.5a1')
    test('0.5b3', '0.5b3')
    test('0.5', '0.5')
    test('0.9.6', '0.9.6')
    test('1.0', '1.0')
    test

# Generated at 2022-06-11 01:52:01.638536
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version("1.0.0")
    assert v >= "1.0.0"
    assert not (v >= "1.0.1")


    try:
        v >= None
        assert False
    except TypeError:
        pass



# Generated at 2022-06-11 01:52:04.626544
# Unit test for method __le__ of class Version
def test_Version___le__():
    cmp, v1, v2 = _common_version_tests()
    assert v1 <= v2 is cmp <= 0


# Generated at 2022-06-11 01:52:09.770222
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    example_value = 0
    expected_value = False
    actual_value = version.__le__(example_value)
    assert actual_value == expected_value, 'actual value: %s, expected value: %s' % (actual_value, expected_value)

# Generated at 2022-06-11 01:52:14.460905
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    print('(%s) %s' % (type(__name__), __name__))

    v = Version('0.0.10')
    assert v == Version('0.0.10'), 'Version.__eq__ failed'
    assert v == '0.0.10', 'Version.__eq__ failed'

# Generated at 2022-06-11 01:52:16.710406
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import sys
    v1 = Version()
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-11 01:52:27.978397
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import sys, unittest, distutils.version

    class VersionTests(unittest.TestCase):

        def test_ge(self):

            class SubVersion(distutils.version.Version):
                def _cmp(self, other):
                    return ((self.version < other.version)
                            and -1 or (self.version > other.version)
                            and 1 or 0)

                def __init__(self, vstring=None):
                    self.version = vstring

            v1 = SubVersion('1')
            v2 = SubVersion('2')
            self.assertTrue(v2 >= v1)
            self.assertFalse(v1 >= v2)

            self.assertRaises(TypeError, lambda: v1 >= '1')


# Generated at 2022-06-11 01:52:29.298081
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v < 6

# Generated at 2022-06-11 01:52:30.846341
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.1')
    return v >= '1.1'

# Generated at 2022-06-11 01:52:33.247183
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    eq = True
    v = Version()
    o = Version()
    o = '1.2'
    eq = eq and v == o
    return eq

# Generated at 2022-06-11 01:52:40.148863
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from google3.testing.pybase import googletest
    from distutils2 import version

    class DerivedVersion(version.Version):
      def __init__(self, derived_version_string):
        self.derived_version_string = derived_version_string

      def _cmp(self, other):
        return cmp(self.derived_version_string, other)

    v1 = DerivedVersion('a')
    v2 = DerivedVersion('b')
    v3 = DerivedVersion('a')

    googletest.main()



# Generated at 2022-06-11 01:52:55.502023
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Imports
    import sys
    import pkg_resources
    from pkg_resources.version import Version
    # Setup
    assert sys.version_info >= (3, 0), "Python 3 is required for this test."
    # Testing
    v1 = Version('1')
    assert v1.__le__(v1)
    assert v1 <= v1
    v2 = Version('2')
    assert v1.__le__(v2)
    assert v1 <= v2



# Generated at 2022-06-11 01:52:57.257918
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version("1.2.3") > Version("1.2.2")

# Generated at 2022-06-11 01:52:59.245360
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Test method Version().__eq__()"""
    pass


# Generated at 2022-06-11 01:53:06.246694
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import sys, os
    branch = os.getenv("ANSIBLE_TEST_BRANCH")
    if branch:
        sys.path.insert(0, "/tmp/ansible_version_test/backports/tests/unit")
    from _version_test import Version
    _version_test = sys.modules["_version_test"]
    _version_test.Version = Version
    from test_version import run
    run()
if __name__ == '__main__':
    test_Version___eq__()



# Generated at 2022-06-11 01:53:09.810568
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    other = object()
    expected = NotImplemented
    actual = version._cmp(other)
    assert actual == expected


# Generated at 2022-06-11 01:53:12.697042
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('0.0')
    assert (v == '0.0') is True
    assert (v == '0.1') is False

# Generated at 2022-06-11 01:53:14.216764
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('2.0')
    assert v > '1.0'

# Generated at 2022-06-11 01:53:18.353837
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version('1.2.3')
    assert version.__gt__('1.2.4') == False
    assert version.__gt__('1.2.2') == True
    assert version.__gt__('1.3.3') == False


# Generated at 2022-06-11 01:53:21.002045
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("1.0")
    v2 = Version("1.1")
    assert v1 < v2
    assert v1 <= v2



# Generated at 2022-06-11 01:53:25.304825
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def test(self, other):
        c = self._cmp(other)
        if c is NotImplemented:
            return c
        return c == 0

    v = Version()
    assert test(v, 1)
test_Version___eq__()

# Generated at 2022-06-11 01:53:41.867888
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version()
    version.__init__('')
    version.__init__('2.0')
    version2 = Version()
    version2.__init__('2.0')
    version3 = Version()
    version3.__init__('2.1')
    version4 = Version()
    version4.__init__('2.0.0')
    version5 = Version()
    version5.__init__('1.0')
    version6 = Version()
    version6.__init__('2.0.0')
    version7 = Version()
    version7.__init__('3.0')
    version8 = Version()
    version8.__init__('2.0')
    version9 = Version()
    version9.__init__(None)
    version10 = Version()
    version

# Generated at 2022-06-11 01:53:49.654715
# Unit test for method __ge__ of class Version
def test_Version___ge__():
        VERSION1 = 628
        VERSION2 = 628
        VERSION3 = 728
        VERSION4 = 728
        VERSION5 = 728
        VERSION6 = 738
        VERSION7 = 738
        VERSION8 = 738
        VERSION9 = 738
        VERSION10 = 738
        VERSION11 = 738
        VERSION12 = 748
        VERSION13 = 748
        VERSION14 = 748
        VERSION15 = 748
        VERSION16 = 748
        VERSION17 = 748
        VERSION18 = 748
        VERSION19 = 758
        VERSION20 = 758
        VERSION21 = 758
        VERSION22 = 758
        VERSION23 = 758
        VERSION24 = 758
        VERSION25 = 758

# Generated at 2022-06-11 01:53:58.161222
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """
    >>> Version('0.1') > Version('0.0')
    True
    >>> Version('0.0') > Version('0.1')
    False
    >>> Version('0.0') > Version('0.0')
    False
    >>> Version('0.0') > Version('0.0.0')
    False
    >>> Version('0.0') > Version('0.0.1')
    False
    >>> Version('0.0.1') > Version('0.0')
    True
    >>> Version('1.0') > Version('0.0.0')
    True
    """



# Generated at 2022-06-11 01:54:00.877264
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-11 01:54:03.092988
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Version.__gt__
    # Comparisons with non-Version instances should return NotImplemented
    assert Version() > None
test_Version___gt__()


# Generated at 2022-06-11 01:54:13.203566
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest
    import sys

    class Version___le___TestCase(unittest.TestCase):
        def test_method(self):
            v = Version("3.3")
            assert v <= "3.3"
            assert v <= Version("3.3")
            assert not v < "3.3"
            assert not v < Version("3.3")
            assert v <= "3.4"
            assert v <= Version("3.4")
            assert v < "3.4.0"
            assert v < Version("3.4.0")
            try:
                assert v <= ""
                assert False
            except TypeError:
                pass
            try:
                assert v <= object()
                assert False
            except TypeError:
                pass

# Generated at 2022-06-11 01:54:17.163918
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Create an instance of the Version class
    version_obj = Version()
    # Test with value 1
    assert version_obj.__le__(1) == NotImplemented, "__le__ method is not working properly"



# Generated at 2022-06-11 01:54:21.812915
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    #from distutils.version import Version
    v = Version('1.2.3')

    assert v == '1.2.3', (
        'version object should equal string it was constructed from'
    )
    assert not v == '1.2.4'
    assert not v == v.__class__('1.2.4')


# Generated at 2022-06-11 01:54:24.060966
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('0.0.1') < Version('0.1.0')



# Generated at 2022-06-11 01:54:31.088427
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import pytest
    from distutils.version import StrictVersion as SV

    assert SV('999.999.999') == SV('999.999.999')
    assert SV('999.999.999') == '999.999.999'
    assert SV('999.999.999') < SV('1000.0')
    assert SV('999.999.999') <= SV('1000.0')
    assert SV('1000.0') > SV('999.999.999')
    assert SV('1000.0') >= SV('999.999.999')

# Generated at 2022-06-11 01:54:46.654751
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Version.__gt__() -> int/None
# ok
    v = Version("1.5.1")
    assert v.__gt__("1.5.2dev-r2737") == 1
    w = Version("1.5.2dev-r2737")
    assert w.__gt__("1.5.1") == -1
    x = Version("1.5.1")
    assert x.__gt__("1.5.1") == 0
    y = Version("1.5.2a1")
    assert y.__gt__("1.5.1") == 1
    z = Version("1.5.2")
    assert z.__gt__("1.5.1") == 1



# Generated at 2022-06-11 01:54:55.794748
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    '''Test method __eq__ of class Version'''
    # Test case 1
    v1 = Version(None)
    v2 = Version(None)
    answer = v1.__eq__(v2)
    expected_answer = True
    print("Return value: %s" % answer)
    print("Expected return value: %s" % expected_answer)
    assert answer == expected_answer
    # Test case 2
    v1 = Version(None)
    v2 = Version(None)
    answer = v1.__eq__(v2)
    expected_answer = False
    print("Return value: %s" % answer)
    print("Expected return value: %s" % expected_answer)
    assert answer == expected_answer
    # Test case 3
    v1 = Version(None)

# Generated at 2022-06-11 01:55:03.600464
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.2.3').__eq__(Version('1.2.3')), \
    "Assert '1.2.3' == '1.2.3' in '__eq__' method of class Version"
    assert not Version('1.2.3').__eq__(Version('1.2.4')), \
    "Assert '1.2.3' != '1.2.4' in '__eq__' method of class Version"

# Generated at 2022-06-11 01:55:13.433431
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class DerivedVersion(Version):
        def __init__(self, other):
            self.other = other
            self.args = None
            super(DerivedVersion, self).__init__()

        def parse(self, arg):
            self.args = arg
            return arg

        def _cmp(self, other):
            return -cmp(self.other, other)

    assert DerivedVersion('abc') > 'def'
    assert DerivedVersion('abc') >= 'def'
    assert not DerivedVersion('abc') < 'def'
    assert not DerivedVersion('abc') <= 'def'
    assert not DerivedVersion('def') > 'abc'
    assert not DerivedVersion('def') >= 'abc'
    assert DerivedVersion('def') < 'abc'
    assert DerivedVersion('def') <= 'abc'



# Generated at 2022-06-11 01:55:15.373435
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    object1 = Version()
    object2 = object1
    assert object1.__lt__(object2) == (NotImplemented or False)
    assert object2.__lt__(object1) == (NotImplemented or False)



# Generated at 2022-06-11 01:55:22.753623
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("1.2.3")
    v2 = Version("1.2.4")

    v1_gt_v2 = v1.__gt__(v2)
    if not v1_gt_v2 == (v1 > v2):
        raise AssertionError("Expected v1.__gt__(v2) == (v1 > v2)")
# Test for method __gt__ of class Version
test_Version___gt__()


# Generated at 2022-06-11 01:55:33.667803
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Testing with a subclass of Version
    import datetime
    class __DummySubclass(Version):
        def parse(self, vstring):
            if vstring is None:
                self.date = datetime.date.today()
            else:
                self.date = datetime.datetime.strptime(vstring, "%Y%m%d").date()
            return
        def _cmp(self, other):
            return self.date.__cmp__(other.date)
    # Testing with Version
    import os
    v = Version()
    w = Version()
    w.parse(str(v))
    # Should return true
    assert v == w
    os.system("rm -f /tmp/__dummy")
    # Should return false
    assert v != __DummySubclass()
    # Should return true


# Generated at 2022-06-11 01:55:40.483430
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # version.py:116
    # The following function is a wrapper around __gt__ which encapsulates the
    # logic of checking the argument type and ordering of arguments.  This
    # wrapper is needed because __gt__ is called directly by the interpreter
    # with arguments of different types (namely, with strings and ints)
    # depending on the context.  See issue #35.
    def _do_cmp(self, other):
        if isinstance(other, basestring):
            other = self.__class__(other)
        elif not isinstance(other, self.__class__):
            return NotImplemented
        return self._cmp(other)
    pass


# Generated at 2022-06-11 01:55:50.306779
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    import re
    import sys

    class TestVersion(unittest.TestCase):
        def test___ge__(self):
            self.assertTrue(Version('1.1') >= '1.1')
            self.assertTrue(Version('1.1') >= '1.1.0')
            self.assertFalse(Version('1.1.0') >= '1.1')
            self.assertFalse(Version('1.1.0') >= '1.1.0.0')
            self.assertTrue(Version('1.1.0') >= '1.1.0.0')
            self.assertTrue(Version('1.1.1') >= '1.1.1.0')
            self.assertTrue(Version('1.1.1') >= '1.1.1')

# Generated at 2022-06-11 01:55:51.960782
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == NotImplemented

# Generated at 2022-06-11 01:56:01.335529
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        assert [Version('1.1.1').__gt__(object)] == [NotImplemented]
    except:
        assert False



# Generated at 2022-06-11 01:56:03.774371
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version("1") == Version("1.0")
    assert Version("1.2") == Version("1.2")

# Generated at 2022-06-11 01:56:09.551977
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    class TestClass:
        pass

    TestClass = TestClass()
    TestClass.__cmp__ = lambda self, other: -1
    TestClass.__gt__ = TestClass.__eq__ = TestClass.__lt__ = lambda self, other: 2
    TestClass._cmp = lambda self, other: 1

    TestInstance = Version("Test")
    assert TestInstance.__eq__("Test") == False
    assert TestInstance.__eq__(TestInstance) == True
    assert TestInstance.__eq__(TestInstance) == True
    assert TestInstance.__eq__("Test") == False

    assert TestInstance.__eq__(None) == NotImplemented

# Generated at 2022-06-11 01:56:20.060731
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    eq_ = equals = eq = lambda a, b: a == b
    ok = lambda a: a
    v = Version

    eq_(v("1.2.3") < v("1.2.4"), True)
    eq_(v("1.2.3") < v("1.3"), True)
    eq_(v("1.2.3") < v("2.0"), True)

    eq_(v("1.2.3") < v("1.2.3a"), True)
    eq_(v("1.2.3") < v("1.2.3a4"), True)
    eq_(v("1.2.3") < v("1.2.3b"), True)
    eq_(v("1.2.3") < v("1.2.3b4"), True)

# Generated at 2022-06-11 01:56:22.404565
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version("1.2.3")
    version2 = Version("1.1.1")
    assert version.__gt__(version2) == True


# Generated at 2022-06-11 01:56:27.874276
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version(1)
    v2 = Version(2)
    v3 = Version(3)
    assert v1 < v2
    assert not v1 < v1
    assert not v2 < v1
    assert v1 < v3
    assert not v3 < v1
    assert not v3 < v2
    assert v2 < v3
    assert not v2 < v2
    assert not v3 < v2


# Generated at 2022-06-11 01:56:36.566594
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version("1.2")
    result = v.__ge__("1.2")
    assert (result == True)
    result = v.__ge__("1.1")
    assert (result == True)
    result = v.__ge__("1.0")
    assert (result == True)
    result = v.__ge__("2.0")
    assert (result == False)
    result = v.__ge__("2.1")
    assert (result == False)
    result = v.__ge__("2.2")
    assert (result == False)

# Generated at 2022-06-11 01:56:44.120259
# Unit test for method __ge__ of class Version

# Generated at 2022-06-11 01:56:46.868590
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    print('Test method __lt__ of class Version')
    X1 = Version()
    X2 = Version()
    return (X1<X2)

# Generated at 2022-06-11 01:56:48.796340
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    obj, anInstance = Version(), Version()
    obj < anInstance

# Generated at 2022-06-11 01:57:04.726594
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.0')
    assert(v <= '1.0')

# Generated at 2022-06-11 01:57:13.734950
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.2.3')
    assert lv == LooseVersion('1.2.3')
    assert lv.version == [1, 2, 3]
    lv.parse('1.3a1')
    assert lv == LooseVersion('1.3a1')
    assert lv.version == [1, '3a1']
    assert list(map(type, lv.version)) == [int, str]
    lv.parse('1.3a')
    assert lv == LooseVersion('1.3a')
    assert lv.version == [1, '3a']
    lv.parse('1.3.a')
    assert lv == LooseVersion('1.3.a')

# Generated at 2022-06-11 01:57:21.617928
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.2').__lt__(Version('2.0'))
    assert Version('1.2').__lt__(Version('1.3'))
    assert Version('1.2').__lt__(Version('1.2.1'))
    assert not Version('2.0').__lt__(Version('1.2'))
    assert not Version('1.3').__lt__(Version('1.2'))
    assert not Version('1.2.1').__lt__(Version('1.2'))

# Generated at 2022-06-11 01:57:23.662269
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__(None) is NotImplemented

# Generated at 2022-06-11 01:57:29.768936
# Unit test for method __le__ of class Version
def test_Version___le__():
    # BEGIN Version.__le__
    import pytest
    v = Version(vstring="0.0.1b1-alpha2")
    assert (v == "0.0.1b1-alpha2")
    assert (v >= "0.0.1-alpha1")
    assert (v <= "0.0.1-alpha2")
    assert (v > "0.0.1-alpha")
    assert (v < "0.0.1-a")
    assert (v != "0.0.1-")
    assert not (v == "0.0.1-")
    with pytest.raises(ValueError):
        v = Version()
    # END Version.__le__


    # Unit test for method __ge__ of class Version

# Generated at 2022-06-11 01:57:31.752393
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version("5")
    o = Version("5")
    assert v.__ge__(o) is True

# Generated at 2022-06-11 01:57:36.535743
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import pytest

# Generated at 2022-06-11 01:57:42.917374
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.2a1')
    assert v >= '1.2.2'
    assert v >= '1.2.2a1'
    assert not (v >= '1.2.2a2')
    assert not (v >= '1.2.2b1')
    assert not (v >= '1.2.2')
    assert not (v >= '1.2.2c1')
    assert not (v >= '1.2c1')
    assert not (v >= '1.2')


# Generated at 2022-06-11 01:57:53.445128
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    for cls in version.StrictVersion, version.LooseVersion:
        assert not cls('1.2.0') > cls('1.2.0')
        assert cls('1.2.0') > cls('1.1.9')
        assert not cls('1.1.9') > cls('1.2.0')
        assert not cls('1.2.0') > cls('1.2')
        assert not cls('1.2') > cls('1.2.0')
        assert not cls('1.2.0') > cls('1.2.0.0')
        assert not cls('1.2.0.0') > cls('1.2.0')

# Generated at 2022-06-11 01:57:55.306204
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.1')
    v2 = Version('1.2')
    assert v1 < v2

# Generated at 2022-06-11 01:58:34.952273
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= Version()


# Generated at 2022-06-11 01:58:41.989053
# Unit test for method __le__ of class Version
def test_Version___le__():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.compat import StringIO
    import sys

    class FakeModuleDeprecationWarning(Exception):
        def __init__(self, msg):
            self.msg = msg

    def fake_deprecation(msg):
        raise FakeModuleDeprecationWarning(msg)

    class FakeModule(object):
        def __init__(self):
            import types
            self.params = types.SimpleNamespace()
            self.fail_json = lambda *args, **kwargs: sys.exit(1)
            self.warn = fake_deprecation

    module = FakeModule()

# Generated at 2022-06-11 01:58:45.009906
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    assert v1 < '1.2.4'
    assert not v1 < '1.2.3'

# Generated at 2022-06-11 01:58:50.192548
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    v3 = Version("")
    v4 = Version("")

    assert v1 <= v2
    assert v2 <= v1
    assert v3 <= v4
    assert v4 <= v3


# Generated at 2022-06-11 01:59:02.034556
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('1.2')
    assert v == '1.2'
    assert not (v > '1.2')
    assert not (v < '1.2')
    assert v >= '1.2'
    assert v <= '1.2'
    assert not (v > '1.3')
    assert not (v < '1.3')
    assert not (v >= '1.3')
    assert v <= '1.3'
    assert v == '1.2.0'
    assert not (v > '1.2.0')
    assert not (v < '1.2.0')
    assert v >= '1.2.0'
    assert v <= '1.2.0'
    assert not (v > '1.2.1')
    assert v < '1.2.1'

# Generated at 2022-06-11 01:59:02.967841
# Unit test for method __le__ of class Version
def test_Version___le__():
    Version().__le__()

# Generated at 2022-06-11 01:59:05.114660
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version('0.0.0')
    version2 = Version('0.0.0')
    assert version == version2



# Generated at 2022-06-11 01:59:07.310642
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  v = Version()
  assert(v.__eq__("hello") == False)


# Generated at 2022-06-11 01:59:11.397802
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    from distutils2.version import Version

    v = Version('abc')
    assert v == 'abc'
    assert 'abc' == v

    class SubVersion(Version):
        pass

    v = SubVersion('abc')
    assert v == 'abc'
    assert 'abc' == v

# Generated at 2022-06-11 01:59:18.774263
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    import unittest
    try:
        from unittest import mock
    except ImportError:
        import mock

    class Test___gt__(unittest.TestCase):
        @mock.patch.object(Version, '_cmp')
        def test___gt__(self, _cmp):
            v = Version()
            other = object()
            _cmp.return_value = NotImplemented
            self.assertIs(_cmp.return_value, v.__gt__(other))
            _cmp.assert_called_once_with(other)
            _cmp.reset_mock()
            _cmp.return_value = 0
            self.assertFalse(v.__gt__(other))
            _cmp.assert_called_once_with(other)
            _cmp.reset_mock()
            _cmp.return_

# Generated at 2022-06-11 02:00:31.150592
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    test = Version(vstring='1.2')
    result = test >= '1.2'
    assert result is True

# Generated at 2022-06-11 02:00:33.847702
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    return v1 < v2


# Generated at 2022-06-11 02:00:41.144661
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    ver = Version()
    assert ver.__eq__(3) == NotImplemented
    assert ver.__eq__(True) == NotImplemented
    assert ver.__eq__('hello') == NotImplemented
    assert ver.__eq__(3.14) == NotImplemented
    assert ver.__eq__(len) == NotImplemented
    assert ver.__eq__(type(None)) == NotImplemented
    assert ver.__eq__(NotImplemented) == NotImplemented
    assert ver.__eq__(Version()) == NotImplemented
    assert ver.__eq__(Ver) == NotImplemented
