

# Generated at 2022-06-11 01:50:58.234770
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    #Test valid version number
    v = StrictVersion("0.4.1")
    assert v.version == (0, 4, 1)
    assert v.prerelease is None

    v = StrictVersion("0.5a1")
    assert v.version == (0, 5, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion("0.5b3")
    assert v.version == (0, 5, 0)
    assert v.prerelease == ('b', 3)

    v = StrictVersion("0.5")
    assert v.version == (0, 5, 0)
    assert v.prerelease is None

    v = StrictVersion("0.9.6")
    assert v.version == (0, 9, 6)
    assert v.prerelease is None

   

# Generated at 2022-06-11 01:51:05.198291
# Unit test for method __le__ of class Version
def test_Version___le__():

  # Passed parameters showing value of argument 'other'
  # (Named 'other' to match the parameter name in the function.)
  other = None
  # No paramaters were passed in, so we can only test the defaults.

  # Call the function
  # Here we *prevent* the function from raising a TypeError exception by
  # passing in the correct number of parameters
  try:
    instance = Version()
    instance.__le__(other)
  except TypeError:
    assert False



# Generated at 2022-06-11 01:51:06.092975
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    pass



# Generated at 2022-06-11 01:51:12.643057
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    v.parse = lambda x: None
    v._cmp = lambda x: 0
    assert(v < 3)

    v._cmp = lambda x: -1
    assert(v < 3)

    v._cmp = lambda x: 1
    assert(not v < 3)

    v._cmp = lambda x: NotImplemented
    assert(v < 3 is NotImplemented)



# Generated at 2022-06-11 01:51:18.313586
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    v3 = Version('1.1')

    assert v1 == v2
    assert v1 != v3
    assert v1 < v3
    assert v3 > v1
    assert v1 <= v2
    assert v1 <= v3
    assert v3 >= v1
    assert v2 >= v1

# Generated at 2022-06-11 01:51:30.832242
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1')
    v2 = Version('2')
    v3 = Version('3')
    v4 = Version('4')
    v10 = Version('10')
    v11 = Version('11')
    v12 = Version('12')
    v13 = Version('13')
    assert v1 < v2
    assert v1 < v3
    assert v2 < v3
    assert v2 < v11
    assert v3 < v11
    assert v3 < v12
    assert v3 < v13
    assert v3 < v4
    assert v3 < v10
    assert v4 <= v4
    assert v10 <= v10
    assert v10 < v11
    assert v10 < v12
    assert v11 > v1
    assert v11 > v2
    assert v11 > v3

# Generated at 2022-06-11 01:51:34.220704
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import random
    for _ in range(100):
        a = random.uniform(-100, 100)
        b = random.uniform(-100, 100)
        assert (a >= b) == (Version(a) >= Version(b))


# Generated at 2022-06-11 01:51:42.404925
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Method __ge__ of class Version

    import unittest

    import sys

    if sys.version_info[:2] < (2, 7):
        # unit tests for Python 2.6 and older are located in
        # 'tests/py26/test_version.py'.
        from test.py26.test_version import TestBaseVersion
    else:
        from test.test_version import TestBaseVersion

    class TestVersion(TestBaseVersion):
        version_class = Version

    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-11 01:51:44.151033
# Unit test for method __le__ of class Version
def test_Version___le__():
    from ansible_collections.misc.nox.plugins.module_utils.version import Version
    assert Version("1.2.3") <= Version("1.2.4")

# Generated at 2022-06-11 01:51:47.064650
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version = StrictVersion()
    version.parse('1.3.3')
    assert(version.version == (1, 3, 3))



# Generated at 2022-06-11 01:52:01.423359
# Unit test for method __le__ of class Version
def test_Version___le__():
  from distutils.version import StrictVersion
  v = StrictVersion("1.0.0")
  assert v._cmp("1.0.0") == 0
  assert v._cmp("1.0.1") == -1
  assert v._cmp("2.0") == -1
  assert v._cmp("1.0") == -1
  assert v._cmp("0.9.9") == 1
  assert v._cmp("foo") == NotImplemented


# Generated at 2022-06-11 01:52:04.456181
# Unit test for method __le__ of class Version
def test_Version___le__():

    v = Version("0.0")
    assert v <= "0.0"
    assert not v <= "0.0a"


# Generated at 2022-06-11 01:52:07.636916
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.5')
    assert v1 < v2

test_Version___gt__()

# Generated at 2022-06-11 01:52:09.769756
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.2.3')
    assert v <= '1.2.4'


# Generated at 2022-06-11 01:52:13.026246
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # method = '__eq__'
    # args = (other)
    # expected = <some boolean>
    # returned = <some boolean>
    assert False # implement your test here

# Generated at 2022-06-11 01:52:17.547270
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # It's okay to keep this stuff here if we don't need to use the
    # test for anything.
    from sys import version_info
    v = Version('1.2.3')
    assert v > '1.2'
    if version_info[0] == 2:
        assert v > '1.2.3dev'

# Generated at 2022-06-11 01:52:28.767294
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils2.tests import unittest
    from distutils2.version import Version

    v = Version('1.2.4')
    # v <= '1.2.4'
    assert v <= '1.2.4'
    assert v <= Version('1.2.4')
    assert v <= Version('1.2.3.0')
    assert not v <= '1.2.3'
    assert not v <= Version('1.2.3')
    assert not v <= Version('1.2.3.0')
    assert not v <= Version('1.2.3.0')
    assert v <= Version('1.2.4.0')
    assert v <= Version('1.2.4.999')
    assert not v <= Version('1.2.4.1000')


# Generated at 2022-06-11 01:52:29.702707
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  o=Version()


# Generated at 2022-06-11 01:52:33.490112
# Unit test for method __ge__ of class Version
def test_Version___ge__():
   v = Version()
   res = v.__ge__("1.0")
   assert_equal(res, False)



# Generated at 2022-06-11 01:52:43.645663
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """
    Test that __ge__, which uses _cmp(), works with various inputs
    """
    from distutils.version import LooseVersion
    from distutils.version import StrictVersion

    class MockVersion(Version):
        def __init__(self, vstring):
            pass
        def __repr__(self):
            return "MockVersion"
        def __str__(self):
            return "1.2.3.4"

    v1 = MockVersion("1.2.3.4")
    v2 = MockVersion("1.2.3.4")
    assert v1 == v2
    assert v1 >= v2
    assert v1 <= v2

    v3 = LooseVersion("1.2.3.4")
    assert v1 >= v3
    assert v1 <= v3

    v4

# Generated at 2022-06-11 01:53:07.858325
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert (v >= '1.2.3') == (v._cmp('1.2.3') >= 0)


    v = Version('1.2.3')
    assert (v >= '1.2.3') == (v._cmp('1.2.3') >= 0)


    v = Version('1.2.3a')
    assert (v >= '1.2.3a') == (v._cmp('1.2.3a') >= 0)


    v = Version('1.2.3')
    assert (v >= '1.2.3b') == (v._cmp('1.2.3b') >= 0)


    v = Version('1.2.3')

# Generated at 2022-06-11 01:53:17.047276
# Unit test for method __gt__ of class Version
def test_Version___gt__():
  import pytest
  from lib.ansible.module_utils._text import to_bytes
  from distutils.version import Version
  from distutils.version import _LooseVersion

  # Set up some test cases for Version.__gt__()

# Generated at 2022-06-11 01:53:28.261739
# Unit test for method __le__ of class Version
def test_Version___le__():
    for x in [Version('0'), Version('0.0'), Version('1.0'), Version('1.1'), Version('2.0')]:
        assert(x <= x)

    assert(Version('0.0') <= Version('0.0'))

    assert(Version('0') <= Version('1'))
    assert(Version('0') <= Version('1.0'))
    assert(Version('0') <= Version('1.1'))
    assert(Version('0.0') <= Version('1'))
    assert(Version('0.0') <= Version('1.0'))
    assert(Version('0.0') <= Version('1.1'))
    assert(Version('0.0.0') <= Version('1'))
    assert(Version('0.0.0') <= Version('1.0'))

# Generated at 2022-06-11 01:53:34.351357
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version("1.1")
    v2 = Version("1.2")
    v3 = Version("1.1")
    assert v1 >= v2, "v1 >= v2"
    assert v2 >= v1, "v2 >= v1"
    assert v1 >= v1, "v1 >= v1"
    assert v3 >= v1, "v3 >= v1"


# Generated at 2022-06-11 01:53:36.975386
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version(1)

    assert v.__eq__(1) == NotImplemented
    assert v.__eq__(v) == True

# Generated at 2022-06-11 01:53:42.783154
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest
    import sys

    from distutils.version import Version

    class Version_TestCase(unittest.TestCase):
        def test_Version___eq___0(self):
            # Testing for bad __eq__.
            self.assertRaises(
                AttributeError,
                Version.__eq__,
                Version(),
                1
            )
        def test_Version___eq___1(self):
            # Testing for bad __eq__.
            self.assertRaises(
                AttributeError,
                Version().__eq__,
                1
            )
        def test_Version___eq___2(self):
            # Testing for bad __eq__.
            self.assertRaises(
                TypeError,
                Version().__eq__,
                Version()
            )

# Generated at 2022-06-11 01:53:44.831601
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    Version_instance = Version()
    assert Version_instance.__ge__(True) == NotImplemented

# Generated at 2022-06-11 01:53:45.969296
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.2.3') < '2.0'


# Generated at 2022-06-11 01:53:48.827820
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    n = Version()
    n.parse('1')
    p = Version()
    p.parse('1.2')
    return n < p


# Generated at 2022-06-11 01:53:50.492741
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2')
    assert v == Version('1.2')


# Generated at 2022-06-11 01:54:28.026769
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    v.parse("1.0")
    assert (v == "1.0")
    assert (v == "1.0.0")
    assert (v == "1.0.0.0")
    assert (v == Version("1.0.0.0"))
    assert (v == "1.0a1")
    assert (v == Version("1.0a1"))
    assert (v == "1.0c1")
    assert (v == Version("1.0c1"))
    assert (v != "1.0.1")
    assert (v != Version("1.0.1"))
    assert (v != "1.1")
    assert (v != Version("1.1"))
    assert (v != "2.0")
    assert (v != Version("2.0"))
#

# Generated at 2022-06-11 01:54:29.980077
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1')
    assert v1.__gt__(Version('0'))

# Generated at 2022-06-11 01:54:32.364390
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('3.0.0')
    v2 = Version('3.0.1')
    assert (v1 > v2) == False


# Generated at 2022-06-11 01:54:34.530461
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert (v <= '1.2') == True


# Generated at 2022-06-11 01:54:40.424435
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class Test:
        def _cmp(self, other):
            if isinstance(other, Test):
                return -1
            elif isinstance(other, str):
                return 1
            else:
                return NotImplemented
    assert Test() > 'a'
    assert not Test() > Test()
    assert not Test() > NotImplemented


# Generated at 2022-06-11 01:54:42.417689
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Initializes a Version instance
    version = Version()

    # Tests method __gt__ with a value greater than self
    if version.__gt__(1):
        pass


# Generated at 2022-06-11 01:54:44.989876
# Unit test for method __le__ of class Version
def test_Version___le__():
    d = Version('1.0')
    assert d <= Version('1.0')
    assert d <= Version('2.0')
    assert d <= '2.0'

# Generated at 2022-06-11 01:54:53.005677
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest

    class Test_Version___lt__(unittest.TestCase):
        def test(self):
            # Create an instance of class Version
            version = Version()
            # Call method __lt__ of version
            actual_result = version.__lt__('1.1')
            # Assert that actual_result is not NotImplementedError
            self.assertIsNot(actual_result, NotImplementedError)
    # Create an instance of class Test_Version___lt__
    unittest.main()
test_Version___lt__()


# Generated at 2022-06-11 01:54:55.826037
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("0.0.3")
    v2 = Version("0.0.2")
    if (v1 > v2):
        return True
    else:
        return False



# Generated at 2022-06-11 01:54:58.707143
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Code to test method __eq__ of class Version
    # Not implemented
    pass

# Generated at 2022-06-11 01:55:56.932348
# Unit test for method __le__ of class Version
def test_Version___le__():
    arg_str_name = 'arg_str'
    arg_str = arb(arg_str_name)
    arg_instance_name = 'arg_instance'
    arg_instance = arb(arg_instance_name)
    arg_other_name = 'arg_other'
    arg_other = arb(arg_other_name)
    arg_c_name = 'arg_c'
    arg_c = arb(arg_c_name)
    errs = []

# Generated at 2022-06-11 01:56:01.548502
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert not v.__lt__(None)
    assert v.__lt__(Version('1'))
    assert not v.__lt__(v)
    assert not v.__lt__(Version('0'))


# Generated at 2022-06-11 01:56:03.593946
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version(2)
    assert v.__eq__(3) == NotImplemented


# Generated at 2022-06-11 01:56:10.233005
# Unit test for method __le__ of class Version
def test_Version___le__():
    try:
        Version.__le__
    except:
        return
    assert Version('1.0.0') <= Version('1.0.0')
    assert Version('1.0.0') <= Version('1.0.1')
    assert Version('1.0.1') <= Version('1.0.10')
    assert Version('1.0.0') <= Version('1.1.0')
    assert Version('1.1.0') <= Version('2.0.0')
    assert not (Version('1.0.0') <= Version('1.0.0'))
    assert not (Version('1.0.1') <= Version('1.0.0'))
    assert not (Version('1.1.0') <= Version('1.0.10'))

# Generated at 2022-06-11 01:56:20.484311
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest
    class TestVersion(unittest.TestCase):
        def test_0(self):
            v1 = Version('1.0')
            v2 = Version('2.0')
            res = v1 >= v2
            self.assertFalse(res)
        def test_1(self):
            v1 = Version('1.0')
            v2 = Version('0.9')
            res = v1 >= v2
            self.assertTrue(res)
        def test_2(self):
            v1 = Version('1.0')
            v2 = Version('1.0')
            res = v1 >= v2
            self.assertTrue(res)
        def test_3(self):
            v1 = Version('0.7')
            v2 = Version('0.9')
            res

# Generated at 2022-06-11 01:56:29.951391
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    '''Test Version.__gt__()'''
    import pytest

    v = Version(r'1.2.3')
    try:
        # Self:
        v_self = Version(r'1.2.3')
        assert v > v_self == False
    except NotImplementedError:
        pass

    try:
        # String:
        assert v > r'1.2.3' == False
    except NotImplementedError:
        pass

    try:
        # Tuple:
        assert v > (1,2,3) == True
    except NotImplementedError:
        pass

    try:
        # Invalid input:
        with pytest.raises(NotImplementedError):
            # Invalid input:
            v > False
    except NotImplementedError:
        pass


# Generated at 2022-06-11 01:56:32.193753
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import doctest
    doctest.testmod()



# Generated at 2022-06-11 01:56:34.836877
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    cmp_actual = Version('3.2.2').__gt__(Version('3.1.1'))
    assert cmp_actual == True


# Generated at 2022-06-11 01:56:35.510305
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None)


# Generated at 2022-06-11 01:56:41.248988
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    class MySubclass(Version):

        def __ne__(self, other):
            return "NE() CALLED"

        def _cmp(self, other):
            return "COMPLEX() CALLED"

    a = MySubclass()
    assert a.__ge__(a) is True
    assert a.__ge__("1.0.0") == "NE() CALLED"
    assert a.__ge__(MySubclass()) == "COMPLEX() CALLED"


# Generated at 2022-06-11 01:58:54.573642
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()

    data = [
        (0, True),
        (1, False),
        (-1, True),
        (NotImplemented, NotImplemented),
    ]

    def _cmp(x, y):
        v1._cmp = lambda x: x
        v2._cmp = lambda x: x
        return v1.__ge__(v2)

    for ver, expected in data:
        v1._cmp = v2._cmp = lambda x: ver
        res = _cmp(ver, expected)
        assert res == expected

# Generated at 2022-06-11 01:58:55.963800
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    if v < None:
        pass


# Generated at 2022-06-11 01:59:00.029825
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    from distutils.tests.test_version import __version__ as VERSION
    from distutils.tests.test_version import __version__ as OTHER_VERSION
    v = Version(VERSION)
    o = Version(OTHER_VERSION)
    assert (v > o) is True

# Generated at 2022-06-11 01:59:03.670542
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    args = (None,)
    other = args[0]

    __tracebackhide__ = True

    my_Version = Version(vstring=args[0])

    try:
        my_Version.__eq__(other)
    except Exception:
        assert False

# Generated at 2022-06-11 01:59:04.699786
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert (Version() < Version())

# Generated at 2022-06-11 01:59:10.365600
# Unit test for method __le__ of class Version
def test_Version___le__():
  def __le__(self, other):
    return self._cmp(other) <= 0
  def _cmp(self, other):
      if isinstance(other, StringType):
          other = self.__class__(other)
      if self.__class__ is not other.__class__:
          return NotImplemented
      return self._cmp(other)
  return __le__

# Generated at 2022-06-11 01:59:16.587215
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils import version
    import random
    import math
    import sys

    if sys.version_info < (3, 0):
        raise Exception("Requires Python 3.x")

    inst = version.Version()
    inst._cmp = lambda x: random.random()
    assert inst >= 10.0
    inst._cmp = lambda x: random.uniform(-10.0, -2.0)
    assert inst >= -2.0 == False
    assert inst >= -3.0 == True


# Generated at 2022-06-11 01:59:19.628538
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    v1=Version('1.0.0')
    v2=Version('2.0.0')
    assert v1 == v1
    assert not v1 == v2

# Generated at 2022-06-11 01:59:22.746350
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= '1.0'
    assert Version('1.1') >= '1.0'
    assert not Version('1.0') >= '1.1'

# Generated at 2022-06-11 01:59:27.232039
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('2.0')
    assert v > '1.0'

    class LV(Version):

        def _cmp(self, other):
            return 0

    lv = LV('1.0')
    assert v is not lv
    assert not (v > lv)

