

# Generated at 2022-06-11 01:50:51.126895
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version("1.1") < Version("2.0")

# Generated at 2022-06-11 01:51:02.072837
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    for cls in vars().values():
        if isinstance(cls, type) and issubclass(cls, Version):
            class left:
                def __repr__(self):
                    return "<left>"
            class right:
                def __repr__(self):
                    return "<right>"
            class middle:
                def __repr__(self):
                    return "<middle>"
            assert not cls() < cls()
            assert not cls() <= cls()
            assert not cls() > cls()
            assert not cls() >= cls()
            assert cls() < right()
            assert cls() <= right()
            assert not cls() > right()
            assert not cls() >= right()
            assert left() < cls()
            assert not left() <= cls()
            assert left

# Generated at 2022-06-11 01:51:05.722695
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.2.3")
    assert str(v) == "1.2.3"
    # assert v.__str__() == "1.2.3"


# Generated at 2022-06-11 01:51:09.479501
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version1 = Version()
    version1.parse("1.0")
    version2 = Version()
    version2.parse("2.0")
    assert(version1 < version2)

# Generated at 2022-06-11 01:51:13.317577
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Unit test for method __gt__ of class Version"""

    v1 = Version('1.0.0')
    v2 = Version('2.0.0')

    return v2.__gt__(v1)

# Generated at 2022-06-11 01:51:15.315336
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    sv = StrictVersion()
    sv.parse('1.0.4a3')
    return



# Generated at 2022-06-11 01:51:20.907629
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    c = StrictVersion('0.9.6')
    assert str(c) == '0.9.6'

    c = StrictVersion('1.0')
    assert str(c) == '1.0'

    c = StrictVersion('1.0b3')
    assert str(c) == '1.0b3'

    c = StrictVersion('1.0.4b1')
    assert str(c) == '1.0.4b1'


# Generated at 2022-06-11 01:51:27.373705
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.0.0")
    assert v.__str__() == "1.0.0"

    v = StrictVersion("1.0")
    assert v.__str__() == "1.0.0"

    v = StrictVersion("2.7a1")
    assert v.__str__() == "2.7a1"


# Generated at 2022-06-11 01:51:30.112273
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('1.2.3')
    assert (v > '1.2.3') == False
    assert (v > '') == True


# Generated at 2022-06-11 01:51:31.700542
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    # FIXME: missing test
    return



# Generated at 2022-06-11 01:51:47.867103
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Imports
    import unittest
    # Set up test fixture
    class Version(object):
        def _cmp(self, other):
            return c
    class StrictVersion(Version):
        pass
    class LooseVersion(Version):
        pass
    # Construct data to pass to method under test
    c = 0
    # Invoke method under test and check results
    with unittest.TestCase() as t:
        t.assertFalse(StrictVersion().__gt__(c))
        t.assertFalse(LooseVersion().__gt__(c))

# Generated at 2022-06-11 01:51:53.953358
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from pickle import loads, dumps
    from distutils.version import StrictVersion

    assert StrictVersion('1.2') >= StrictVersion('1.2')
    assert not StrictVersion('1.2') >= StrictVersion('1.3')
    assert not StrictVersion('1.2') >= StrictVersion('1.2.0.0')

    v = StrictVersion('1.2')
    assert loads(dumps(v)) >= StrictVersion('1.2')



# Generated at 2022-06-11 01:51:59.280590
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    import ansible.module_utils.distutils.version as a
    class VersionTestCase(unittest.TestCase):
        """Test cases for Version.__lt__"""
        def test_basic_lt(self):
            pass
    unittest.main(exit=False)

# Generated at 2022-06-11 01:52:07.350626
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # __lt__ is implemented by making calls to _cmp, which is the
    # method that subclasses are supposed to override for their specific
    # implementation of comparison.  Currently, the only subclass is
    # StrictVersion, which is used in distutils.version; so this test
    # is really testing StrictVersion's _cmp method.  XXX This should
    # really be an explicit test of StrictVersion's _cmp method.

    class MockVersion(Version):
        def parse(self, vstring):
            pass

        def _cmp(self, other):
            return 0

    v = MockVersion()
    assert v > '2.1'
    assert v < '1.2.3'
    assert v == '2.2.2'
    assert '2.1' < v
    assert '1.2.3' > v
   

# Generated at 2022-06-11 01:52:11.140301
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    myversion = Version('1.0.dev1')
    assert myversion.__ge__(Version('1.0')) is False
    assert myversion.__ge__(Version('1.0.dev1')) is True


# Generated at 2022-06-11 01:52:13.564748
# Unit test for method __le__ of class Version
def test_Version___le__():
    from ansible_galaxy.version import Version
    assert Version('1.0') <= Version('1.1')


# Generated at 2022-06-11 01:52:16.665581
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("1.0") <= Version("1.0")
    assert Version("1.0") <= Version("2.0")
    assert not Version("2.0") <= Version("1.0")

# Generated at 2022-06-11 01:52:18.628702
# Unit test for method __le__ of class Version
def test_Version___le__():
    # This method only used for comparison.
    # Skipping unit test.
    pass


# Generated at 2022-06-11 01:52:20.368467
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test a simple case
    v = Version()
    assert Version() == v

# Generated at 2022-06-11 01:52:21.979865
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version("0.0") == Version("0.0")

# Generated at 2022-06-11 01:52:31.336273
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert (Version('0') < '0.0.1')


# Generated at 2022-06-11 01:52:38.303315
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def test_equal(self, other):
        return self == other

    def test_not_equal(self, other):
        return self != other

    for klass in [StrictVersion, LooseVersion]:
        x = klass('1.5.1')
        x.test_equal = test_equal.__get__(x, klass)
        x.test_not_equal = test_not_equal.__get__(x, klass)


# Generated at 2022-06-11 01:52:46.847378
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Unit test for method __le__ of class Version"""
    import copy
    import pickle
    v = Version("0.0.0")
    assert str(v) == "0.0.0"
    assert v <= v, "Version object not equal to itself"
    assert (v <= Version("0.0.0")) is True
    assert (v <= "0.0.0") is True
    assert (v <= "9.9.9") is True
    assert (v <= " ") is False
    assert (v <= "0") is True
    assert (v <= "0.0") is True
    assert (v <= "0.0.0") is True
    assert (v <= "0.0.0alpha") is True
    assert (v <= "0.0.0b") is True

# Generated at 2022-06-11 01:52:48.739062
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    v.__ge__(Version())

# Generated at 2022-06-11 01:52:50.949253
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    v = Version('1.0')
    assert v <= '2.0'


# Generated at 2022-06-11 01:53:01.020263
# Unit test for method __lt__ of class Version

# Generated at 2022-06-11 01:53:03.928714
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    arg0 = Version()
    ret0 = arg0.__eq__(None)
    assert ret0 == NotImplemented


# Generated at 2022-06-11 01:53:12.549426
# Unit test for method __le__ of class Version
def test_Version___le__():
    global ver
    ver = Version("1.0")
    assert ver <= "1.0"
    ver = Version("1.0")
    assert ver <= "1.0.0"
    ver = Version("1.0")
    assert ver <= "1.0b2"
    ver = Version("1.0")
    assert ver <= "1.0.0b2"
    ver = Version("1.0")
    assert ver <= "1.0c1"
    ver = Version("1.0")
    ver <= "1.0a1"

# Generated at 2022-06-11 01:53:22.897106
# Unit test for method __le__ of class Version
def test_Version___le__():
    large_number = sys.maxsize * 2

    v = Version()
    assert v.__le__(large_number) == True

    v = Version(vstring = '0.0.1')
    assert v.__le__(large_number) == True

    v = Version(vstring = '1.0')
    assert v.__le__(large_number) == True

    v = Version(vstring = '1.0.1')
    assert v.__le__(large_number) == True

    v = Version(vstring = '1.1')
    assert v.__le__(large_number) == True

    v = Version(vstring = '1.1.1')
    assert v.__le__(large_number) == True

# Generated at 2022-06-11 01:53:25.110215
# Unit test for method __le__ of class Version
def test_Version___le__():
    taken_0 = Version()
    other_1 = Version()
    assert taken_0._cmp(other_1) <= 0


# Generated at 2022-06-11 01:53:36.445686
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    assert version.__ge__('0.0.0') == NotImplemented



# Generated at 2022-06-11 01:53:37.539463
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version('2')
test_Version___lt__()


# Generated at 2022-06-11 01:53:39.674741
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__('') == NotImplemented
    assert Version().__le__('') == NotImplemented

# Generated at 2022-06-11 01:53:40.502737
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= Version()



# Generated at 2022-06-11 01:53:45.320935
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.1')
    assert v < '1.2'
    assert v < '1.1.1'
    assert v < '1.2-rc.1'
    assert v < '1.1.1-rc.1'


# Generated at 2022-06-11 01:53:48.869468
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("1.0")
    v2 = Version("1.0")
    v3 = Version("2.0")
    assert v1 <= v2
    assert v1 <= v3
    assert v2 <= v3


# Generated at 2022-06-11 01:53:59.889681
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  chk = Version()
  chk.__ge__(True)
  chk.__ge__(False)
  chk.__ge__(None)
  chk.__ge__(object)
  chk.__ge__(0.0)
  chk.__ge__(-0.0)
  chk.__ge__(0)
  chk.__ge__(-0)
  chk.__ge__(0)
  chk.__ge__(-0)
  chk.__ge__(0)
  chk.__ge__(-0)
  chk.__ge__(0)
  chk.__ge__(-0)
  chk.__ge__(0)
  chk.__ge__(-0)
  chk.__ge__(0)
 

# Generated at 2022-06-11 01:54:04.446293
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version
    v = Version("1.0.0")
    assert v.__eq__("1.0.0") == True
    assert v.__eq__("1.0.1") == False
    assert v.__eq__("1.1.0") == False
    assert v.__eq__("2.0.0") == False



# Generated at 2022-06-11 01:54:08.566959
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    b = Version()
    c = Version('2.6')
    v.parse = lambda x: None
    b.parse = lambda x: None
    c.parse = lambda x: None
    assert v == b
    assert v != c
    assert v == 1
    assert v == '1'


# Generated at 2022-06-11 01:54:09.912993
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert True


# Generated at 2022-06-11 01:54:32.493184
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version("1.0")
    v2 = Version("1.0")
    assert (v1 == v2) == True
    assert (v1 != v2) == False
    assert (v1 >= v2) == True
    assert (v1 <= v2) == True


# Generated at 2022-06-11 01:54:34.671915
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(NotImplemented) is NotImplemented

# Generated at 2022-06-11 01:54:39.778507
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version(vstring=None).__le__(None) == True
    assert Version(vstring='a').__le__('a') == True
    assert Version(vstring='b').__le__('a') == True
    assert Version(vstring='a').__le__('b') == True

# Generated at 2022-06-11 01:54:42.686198
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version("something")
    assert (v < "something else") == False
    assert (v < "something") == False
    assert (v < "something0") == False
    assert (v < "so") == True
    assert (v < "") == False

# Generated at 2022-06-11 01:54:53.357733
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    c = v.__ge__(None)
    c = v.__ge__(False)
    c = v.__ge__(0)
    c = v.__ge__(0.0)
    c = v.__ge__('')
    c = v.__ge__([])
    c = v.__ge__({})
    c = v.__ge__(())
    v1 = Version('1.0')
    v2 = Version('2.0')
    c = v1.__ge__(v2)
    c = v1.__ge__(str(v2))
    v.parse('1.0')
    c = v1.__ge__(v2)
    c = v1.__ge__(str(v2))



# Generated at 2022-06-11 01:55:04.854239
# Unit test for method __str__ of class StrictVersion

# Generated at 2022-06-11 01:55:13.025673
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('0.4.1')
    assert '0.4.1' == str(v)
    assert ('0.4.1',) == v.version
    assert None is v.prerelease

    v = StrictVersion('0.5a1')
    assert '0.5a1' == str(v)
    assert ('0.5a1',) == v.version
    assert ('a', 1) == v.prerelease

    v = StrictVersion('0.5b2')
    assert '0.5b2' == str(v)
    assert ('0.5b2',) == v.version
    assert ('b', 2) == v.prerelease


# Generated at 2022-06-11 01:55:16.992222
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.0') < Version('1.1')
    assert not (Version('1.0') < Version('1.0'))
    assert not (Version('1.1') < Version('1.0'))
    

# Generated at 2022-06-11 01:55:25.262402
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_cases = [
        ("test_Version___eq__",
         (
          ),
         {
          }
         ),
        ]

    from unittest import TextTestRunner
    from test import test_support

    for test_func_name, arglist, kwargdict in test_cases:
        test_func = eval(test_func_name)
        if arglist:
            if kwargdict:
                apply(test_func, arglist, kwargdict)
            else:
                apply(test_func, arglist)
        else:
            test_func()


# Generated at 2022-06-11 01:55:27.597281
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented

# Generated at 2022-06-11 01:56:33.780793
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    ver = Version()
    return ver.__eq__(None)

# Generated at 2022-06-11 01:56:42.688355
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Note: testing rich comparison methods is best done by directly
    # invoking them via their special names, as shown here, rather than
    # by invoking them through the usual operators.  See
    # http://docs.python.org/3/reference/datamodel.html#object.__lt__

    # some basic sanity checks
    for v in ("0.4", "1.0", "1.2a1", "1.2b3", "1.2", "1.2.0", "161"):
        assert Version(v) >= Version(v)

    # check that the methods are properly redirected to _cmp
    class TestVersion(Version):
        def _cmp(self, other):
            return NotImplemented
    v1 = TestVersion("1.0")
    v2 = TestVersion("1.1")
    assert v

# Generated at 2022-06-11 01:56:45.366060
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    return v1.__ge__(v2) == v1 >= v2

# Generated at 2022-06-11 01:56:54.714626
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    pv = LooseVersion('1.2.3.4')
    assert pv.version == [1,2,3,4], pv.version
    pv = LooseVersion('10.2.3')
    assert pv.version == [10,2,3], pv.version
    pv = LooseVersion('1.2.3')
    assert pv.version == [1,2,3], pv.version
    pv = LooseVersion('1.2.3a1')
    assert pv.version == [1,2,3,'a',1], pv.version
    pv = LooseVersion('1.2.3.a1')
    assert pv.version == [1,2,3,'a',1], pv.version

# Generated at 2022-06-11 01:56:58.295080
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.1').__eq__('1.1')
    assert not Version('1.1').__eq__('1.1a')
    assert not Version('1.1').__eq__('1.2')


# Generated at 2022-06-11 01:57:09.892505
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  import unittest

  class Version_Mock(Version):
    def _cmp(self, other):
      return self.cmp


# Generated at 2022-06-11 01:57:11.984297
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from .version import Version
    
    ver = Version('1.2.3a1')
    assert ver.__lt__(None) == NotImplemented

# Generated at 2022-06-11 01:57:15.216837
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('0.9.9')
    eq = v == '0.9.9'
    assert eq

# Generated at 2022-06-11 01:57:22.037132
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Given a Version instance
    v = Version()

    # When we compare it to another Version instance, then the correct
    # method is called
    class OtherVersion(Version):
        def _cmp(self, other):
            return NotImplemented
    v._cmp = lambda other: NotImplemented
    v <= OtherVersion()
    # And when we compare it to a string, then the correct method is called
    v._cmp = lambda other: NotImplemented
    v <= "1.0"


# Generated at 2022-06-11 01:57:24.085066
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__(Version()) == NotImplemented

# Generated at 2022-06-11 01:59:46.800159
# Unit test for method __le__ of class Version
def test_Version___le__():
    c = Version("4.0.1")
    c.__le__("4.0.2")  # == False
    c.__le__("4.0.0")  # == False
    c.__le__("4.0.1")  # == True



# Generated at 2022-06-11 01:59:49.227057
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version("1.2.3")
    assert v == "1.2.3" and v >= "1.2.3"



# Generated at 2022-06-11 01:59:52.106894
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test the method ``__ge__`` of the ``Version`` class."""
    v = Version()
    assert not v.__ge__((1,2,3))

# Generated at 2022-06-11 01:59:55.874857
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    eq = Version().__eq__
    eq_ = Version().__eq__

    ok_(eq(eq_) == 0)

    eq__ = Version().__eq__
    ok_(eq(eq__) == 0)


# Generated at 2022-06-11 02:00:04.666623
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    class VersionSubclass(Version):
        def __init__(self, vstring=None):
            self.parse_called = False
            super(VersionSubclass, self).__init__(vstring)

        def parse(self, vstring):
            self.parse_called = True
            self.vstring = vstring

        def _cmp(self, other):
            return 0

    inst = VersionSubclass('v1')
    inst._cmp = lambda other: 0
    assert inst == 'v1'
    assert inst < 'v2'
    assert inst <= 'v2'
    assert inst > 'v0'
    assert inst >= 'v0'

    # Not all types can be compared
    assert None == inst
    assert inst != None
    assert inst < None
    assert inst <= None
    assert None > inst
    assert None

# Generated at 2022-06-11 02:00:06.234008
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1.__eq__(v2) is NotImplemented


# Generated at 2022-06-11 02:00:09.630250
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    o = Version( '1.2.1' )
    o.parse = Mock()
    o.parse.return_value = o
    o._cmp = Mock( return_value=1 )
    o2 = Mock()
    o.__ge__( o2 )

# Generated at 2022-06-11 02:00:11.209904
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    obj = Version()
    print(obj.__eq__(obj))


# Generated at 2022-06-11 02:00:20.526849
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from pytest import raises, approx

    def check(self, other, expected):
        self_obj = Version(self)
        other_obj = Version(other)
        actual = self_obj < other_obj
        assert actual == expected

    #######################################################################
    ################ Tests for method __lt__ of class Version #############
    #######################################################################

    #######################################################################
    ########### Tests for class Version using StrictVersion class #########
    #######################################################################

    #######################################################################
    #################### Tests for "dev" version convention ###############
    #######################################################################

    check('1.0.dev456', '1.0', True)
    check('1.0a1.dev456', '1.0a1', True)

# Generated at 2022-06-11 02:00:21.776431
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('')
    assert v == None
