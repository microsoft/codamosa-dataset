

# Generated at 2022-06-11 01:50:53.865050
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Imports.
     
    # Setup.
    v1 = Version('1.0')
     
    # Exercise.
    result = v1 >= v1
     
    # Verify.
    assert result == True, result
     
    # Cleanup.

     

# Generated at 2022-06-11 01:51:05.034183
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('0.4').__str__() == '0.4'
    assert StrictVersion('0.4.0').__str__() == '0.4.0'
    assert StrictVersion('0.5a1').__str__() == '0.5a1'
    assert StrictVersion('0.5b3').__str__() == '0.5b3'
    assert StrictVersion('0.5').__str__() == '0.5'
    assert StrictVersion('0.9.6').__str__() == '0.9.6'
    assert StrictVersion('1.0').__str__() == '1.0'
    assert StrictVersion('1.0.4a3').__str__() == '1.0.4a3'

# Generated at 2022-06-11 01:51:06.716396
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.0') == Version('1.0')



# Generated at 2022-06-11 01:51:11.261824
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(v) is NotImplemented
    assert v.__gt__(1) == 1
    assert v.__gt__(2) == -1
# End of unit test __gt__ of class Version



# Generated at 2022-06-11 01:51:13.655969
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    assert Version("1.0") < Version("2.0")
    assert not Version("2.0") < Version("2.0")
    assert not Version("2.0") < Version("1.0")


# Generated at 2022-06-11 01:51:16.446513
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    c = v._cmp("1.0")
    if c is NotImplemented:
        return False
    return c <= 0

# Generated at 2022-06-11 01:51:18.008848
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.2') < Version('1.2.1')

# Generated at 2022-06-11 01:51:30.694738
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    sv = StrictVersion()
    sv.parse('1.0.0')
    assert sv.__str__() == '1.0.0'
    sv.version == (1, 0, 0)
    sv.prerelease == None

    sv.parse('1.0.0')
    assert sv.__str__() == '1.0.0'
    sv.version == (1, 0, 0)
    sv.prerelease == None

    sv.parse('1.0.0a0')
    assert sv.version == (1, 0, 0)
    assert sv.__str__() == '1.0.0a0'
    assert sv.prerelease == ('a',0)

    sv.parse('1.0.0b0')

# Generated at 2022-06-11 01:51:33.090138
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    d = StrictVersion('1.0.4')
    assert str(d) == '1.0.4'



# Generated at 2022-06-11 01:51:43.777975
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    fuStrictVersion = StrictVersion('1.2.3')
    assert str(fuStrictVersion) == '1.2.3'
    fuStrictVersion = StrictVersion('1.2a1')
    assert str(fuStrictVersion) == '1.2a1'
    fuStrictVersion = StrictVersion('1.2b3')
    assert str(fuStrictVersion) == '1.2b3'
    fuStrictVersion = StrictVersion('1.2')
    assert str(fuStrictVersion) == '1.2'
    fuStrictVersion = StrictVersion('1.2.0')
    assert str(fuStrictVersion) == '1.2'
    fuStrictVersion = StrictVersion('1.2')
    assert str(fuStrictVersion) == '1.2'

# Generated at 2022-06-11 01:51:51.502200
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # class Version(Version):
    instance = Version()
    assert instance == '', 'wrong result returned'

# Generated at 2022-06-11 01:51:55.910108
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("1.1")
    assert v1 <= "1.1"
    v2 = Version("1.2")
    assert v1 <= v2
    assert not v2 <= "0.1"
    try:
        v2 <= object()
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-11 01:52:05.726131
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    from distutils.version import StrictVersion
    from distutils.version import LooseVersion

    # Verifying that __lt__ doesn't raise an exception if __eq__ raises.
    # Subclass Version and override __eq__ with a lambda that raises an
    # exception and use it in a comparison.
    class NewVersion(Version):
        def __eq__(self, other):
            raise RuntimeError()

    new_version = NewVersion('1.0')
    try:
        new_version < '1.0'
    except Exception:
        raise AssertionError("NewVersion.__lt__ raised an exception. " \
          "Expected: no exception")

# Generated at 2022-06-11 01:52:10.506636
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils2.version import Version
    from distutils2.tests import unittest
    # 1 setUp
    # 2 test body
    # 3 cleanup
    # 4 assertion

    import unittest
    import sys
    import unittest
    verbose = 0



# Generated at 2022-06-11 01:52:17.982257
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    global test_Version___ge__
    Version = _test.test_Version___ge__.Version
    Version.test_Version___ge__ = test_Version___ge__
    Version.test_Version___ge__.__doc__ = test_Version___ge__.__doc__
    def test_Version___ge__():
        cls = Version
        v1 = cls('1.2a3')
        v2 = cls('1.2a2')
        assert not (v1 >= v2)
        assert v1 >= v1
        assert v1 >= '1.2a3'
        assert not (v1 >= '1.2a4')
        assert not (v1 >= '2.2b1')
    try:
        test_Version___ge__()
    except:
        pass



# Generated at 2022-06-11 01:52:28.027168
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('2.3.3')
    v2 = Version('2.3.4')
    assert not v1 == v2
    assert v1 < v2
    assert v1 <= v2

    v1 = Version('2.3.4')
    v2 = Version('2.3.3')
    assert not v1 == v2
    assert v1 > v2
    assert v1 >= v2

    v1 = Version('2.3.3')
    v2 = Version('2.3.3')
    assert v1 == v2
    assert not v1 < v2
    assert v1 <= v2
    assert not v1 > v2
    assert v1 >= v2


# Generated at 2022-06-11 01:52:31.982907
# Unit test for method __le__ of class Version

# Generated at 2022-06-11 01:52:35.418192
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    g = Version()
    h = Version()
    assert g is not h
    g._cmp = lambda other: NotImplemented
    assert g >= h is NotImplemented
    del g._cmp
    assert g >= h is True
    h._cmp = lambda other: 1
    assert g >= h is False

# Generated at 2022-06-11 01:52:37.111473
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.10').__gt__('1.9') == True


# Generated at 2022-06-11 01:52:46.158556
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    v3 = Version('1.3.3')
    assert v1 <= v1
    assert v1 >= v1
    assert not v1 < v1
    assert not v1 > v1
    assert v1 < v2
    assert v1 <= v2
    assert not v1 == v2
    assert not v1 > v2
    assert not v1 >= v2
    assert v1 < v3
    assert v1 <= v3
    assert not v1 == v3
    assert not v1 > v3
    assert not v1 >= v3
    assert v2 > v1
    assert v2 >= v1
    assert not v2 == v1
    assert not v2 < v1

# Generated at 2022-06-11 01:52:55.120876
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Tested method is accessed through a version instance
    version = Version('1.0')
    assert version.__le__('1.0.0')



# Generated at 2022-06-11 01:53:01.464796
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import StrictVersion
    a = StrictVersion('1.1')
    b = StrictVersion('1.3')
    assert a < b, "1.1 < 1.3"
    assert not a >= b, "1.1 >= 1.3"
    assert a != b, "1.1 != 1.3"
    assert not a == b, "1.1 == 1.3"



# Generated at 2022-06-11 01:53:09.522811
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    from distutils.tests import support
    from distutils.version import LooseVersion, StrictVersion

    for ver in [StrictVersion, LooseVersion]:
        v = ver('1.2.3.4')

        eq = unittest.TestCase('__eq__')
        eq.assertEqual(v.__eq__(None), False)

        gt = unittest.TestCase('__gt__')
        gt.assertEqual(v.__gt__(None), False)
        gt.assertEqual(v.__gt__(v), False)
        gt.assertEqual(v.__gt__(ver('1.2.3')), True)

# Generated at 2022-06-11 01:53:10.259745
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    v == None


# Generated at 2022-06-11 01:53:11.897656
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert (Version('1') < Version('2'))


# Generated at 2022-06-11 01:53:23.040292
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from unittest import TestCase
    from distutils.version import Version
    import ansible.module_utils.common.version as my_version
    import unittest

    class TestVersion(TestCase):
        def test_Version___eq__(self):
            version = Version('1.2.3')
            version_other = Version('1.5.5')
            my_version_other = my_version.Version('1.5.5')
            other_str = '1.5.5'
            self.assertIsInstance(version, Version)
            self.assertTrue(version == version_other)
            self.assertTrue(version == my_version_other)
            self.assertTrue(version == other_str)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestVersion)
    unittest

# Generated at 2022-06-11 01:53:25.565504
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version
    a = Version('1.1.1')
    b = Version('1.1.0')
    assert a != b

# Generated at 2022-06-11 01:53:29.317264
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert True == Version('1.0') >= '1.0'
    assert True == Version('1.0') >= Version('1.0')
    assert True == Version('1.1') >= '1.0'
    assert True == Version('1.1') >= Version('1.0')

# Generated at 2022-06-11 01:53:36.396818
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    arguments = [
        ("'1.2.3'", "'1.2.3'"),
        ("'1.2.3'", "'1.2.4'"),
        ]
    for arg1, arg2 in arguments:
        print(arg1, arg2)
        retval = Version(arg1).__eq__(Version(arg2)) # call the function
        print(retval) # print the result
        print() # print a new line

test_Version___eq__()


# Generated at 2022-06-11 01:53:43.000252
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 is not v2
    assert v1.__lt__(v2) is False
    assert v2.__lt__(v1) is False

    class TestVersion(Version):
        def _cmp(self, other):
            return NotImplemented
    v1 = TestVersion()
    v2 = TestVersion()
    assert v1.__lt__(v2) is NotImplemented
    assert v2.__lt__(v1) is NotImplemented

    class TestVersion2(Version):
        def _cmp(self, other):
            return 1
    v1 = TestVersion2()
    v2 = TestVersion2()
    assert v1.__lt__(v2) is False

# Generated at 2022-06-11 01:54:00.065354
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import version
    import version
    import version
    import version
    import version
    import version
    import version
    # Return the correct value
    assert version.Version("10.1.0") < version.Version("10.2.0")
    assert version.Version("1.0") < version.Version("1.1")
    assert version.Version("2.0.0") < version.Version("2.1")
    assert not version.Version("3.0a1") < version.Version("2.0")
    assert not version.Version("3.0a1") < version.Version("3.0a1")
    assert version.LooseVersion("10.1.0") < version.LooseVersion("10.2.0")

# Generated at 2022-06-11 01:54:02.779471
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    global v2
    v2 = LooseVersion("1.2a3")
    assert v2.version == [1, '2a', 3]



# Generated at 2022-06-11 01:54:11.129433
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test Case:
    #  test = Version()
    #  test.parse('1.0')
    #  assert test.__eq__(Version('1.0'))
    # Expected Behaviour:
    #  Returns True
    # Actual Behaviour:
    #  Returns True
    # Notes/Bugs:
    #
    # Test Case:
    #  test = Version()
    #  test.parse('1.0')
    #  assert test.__eq__(Version('1.1'))
    # Expected Behaviour:
    #  Returns False
    # Actual Behaviour:
    #  Returns False
    # Notes/Bugs:
    #
    pass


# Generated at 2022-06-11 01:54:11.876206
# Unit test for method __le__ of class Version
def test_Version___le__():
    pass

# Generated at 2022-06-11 01:54:13.631343
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert (v > 1) == NotImplemented

# Generated at 2022-06-11 01:54:20.449076
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import datetime
    from distutils.version import LooseVersion, StrictVersion
    for TestVersion in [LooseVersion, StrictVersion]:
        TestVersion("1.0").__eq__(TestVersion("1.0"))
        TestVersion("1.0").__eq__(TestVersion("1.0a"))
        TestVersion("1.0b").__eq__(TestVersion("1.0b"))
        TestVersion("1.0b").__eq__(TestVersion("1.0"))
        TestVersion("1.0").__eq__("blah")


# Generated at 2022-06-11 01:54:21.212280
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass


# Generated at 2022-06-11 01:54:23.822633
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.1.1')
    v2 = Version('1.1.2')
    assert v1 < v2


# Generated at 2022-06-11 01:54:25.808659
# Unit test for method __le__ of class Version
def test_Version___le__():
  v1, v2 = Version('1.0'), Version('1.0')
  assert v1 == v2
  assert v1 <= v2
  assert v2 <= v1
  assert not v1 < v2



# Generated at 2022-06-11 01:54:27.675149
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Unit test for method __gt__ of class Version"""
    v = Version()
    assert v.__gt__(1) == NotImplemented
    asse

# Generated at 2022-06-11 01:54:44.490637
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class B:
        def _cmp(self, other): return NotImplemented
    v1 = Version('1')
    v2 = Version('2')
    v3 = Version('3')
    assert (v1 > v2) == False
    assert (v1 > v3) == False
    assert (v2 > v1) == True
    assert (v2 > v3) == False
    assert (v3 > v1) == True
    assert (v3 > v2) == True
    assert (v1 > B()) == NotImplemented
    assert (v2 > B()) == NotImplemented
    assert (v3 > B()) == NotImplemented
    assert (B() > v1) == NotImplemented
    assert (B() > v2) == NotImplemented

# Generated at 2022-06-11 01:54:54.637681
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest
    import sys

    class TestVersion(unittest.TestCase):
        def setUp(self):
            self.version = Version()

        def test_short(self):
            self.version.parse('1')
            self.assertTrue(self.version >= '1')

        def test_long(self):
            self.version.parse('1.2.3.4')
            self.assertTrue(self.version >= '1.2.3.4')

        @unittest.skipIf(sys.platform.startswith('win'), 'crashing on Windows')
        def test_different_length_negative(self):
            self.version.parse('0.4.5')
            self.assertFalse(self.version >= '0.4.5.6')


# Generated at 2022-06-11 01:55:05.879403
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def _test(v1str, v2str, eq=True):
        v1 = Version(v1str)
        v2 = Version(v2str)
        assert (v1 == v2) is eq
        assert (v2 == v1) is eq

    _test('1.0', '1.0')
    _test('1.0', '1.0.0')
    _test('1.0', '1')
    _test('1.0.0', '1.0')
    _test('1', '1.0')
    _test('1.0', '1.0.0.0.0.0')
    _test('1.0.0.0.0.0', '1.0')

    _test('1.0', '2.0', False)

# Generated at 2022-06-11 01:55:07.406682
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    assert version > 0


# Generated at 2022-06-11 01:55:14.549683
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import LooseVersion
    from io import StringIO

    out = StringIO()

    # LooseVersion is a subclass of Version
    x = LooseVersion("1.0")
    y = LooseVersion("1.1")
    z = x > y
    z
    assert z == False, z

    # x and y are not comparable, returns NotImplemented
    x = LooseVersion("1.0.dev")
    y = LooseVersion("1.0")
    z = x > y
    z
    assert z is NotImplemented, z

    # x and y are not comparable, returns NotImplemented
    x = LooseVersion("1.0.dev")
    y = LooseVersion("1.0")
    z = x > y
    z
    assert z is NotImplemented

# Generated at 2022-06-11 01:55:15.260126
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__(Version())

# Generated at 2022-06-11 01:55:19.653614
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    '''
    Test __lt__ of class Version
    '''
    v1 = Version();
    v2 = Version();
    assert(v1 <= v2)
    assert(not(v1 < v2))
    assert(v1 >= v2)

# Generated at 2022-06-11 01:55:25.395488
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    
    class Version___gt__(unittest.TestCase):
        def test_Version___gt__(self):
            import os
            import sys
            import tempfile
            from lib2to3.main import main
            
            # Create a temporary file
            (f, fname) = tempfile.mkstemp()
            
            # Write the fixed code to the file

# Generated at 2022-06-11 01:55:35.286670
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import Version
    
    # __ge__
    
    v = Version('1')
    assert v >= '1'
    assert not(v >= '2')
    assert v >= '1.0'
    assert not(v >= '1.1')
    v1 = Version('1.1')
    assert not(v >= v1)
    
    # __ge__
    
    v = Version('1')
    assert v >= '1'
    assert not(v >= '2')
    assert v >= '1.0'
    assert not(v >= '1.1')
    v1 = Version('1.1')
    assert not(v >= v1)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


# Generated at 2022-06-11 01:55:37.656829
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1')
    v2 = Version('1')
    assert (v == v2) == True

# Generated at 2022-06-11 01:55:53.801035
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3.4')
    assert v == '1.2.3.4'
    assert v == Version('1.2.3.4')

    assert v != '1.2.3.5'
    assert v != Version('1.2.3.5')


# Generated at 2022-06-11 01:56:03.445902
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    class Test(Version):

        def __init__(self, vstring=None):
            Version.__init__(self, vstring)
            self.vstring = vstring

        def parse(self, vstring):
            self.vals = [x for x in vstring.split('.') if x.isdigit()]

        def __str__(self):
            return '.'.join(self.vals)

        def _cmp(self, other):
            return (not self.vals == other.vals)

    version = Test('1.2 3.4')
    other = Test('1.2 3.3')
    assert not version == other

# Generated at 2022-06-11 01:56:05.665348
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    assert (v1 <= v2) == v1._cmp(v2) <= 0


# Generated at 2022-06-11 01:56:07.547354
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # self
    version = distutils.version.Version()
    # other
    other = ''
    version.__gt__(other)


# Generated at 2022-06-11 01:56:18.114144
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    with pytest.raises(ValueError):
        LooseVersion(None).parse("1.5a")

    with pytest.raises(ValueError):
        LooseVersion(None).parse("1.5a")

    with pytest.raises(ValueError):
        LooseVersion(None).parse("1.5a1.5a")

    with pytest.raises(ValueError):
        LooseVersion(None).parse("1.5a1.5a1.5a")

    with pytest.raises(ValueError):
        LooseVersion(None).parse("a")

    with pytest.raises(ValueError):
        LooseVersion(None).parse("1.5p")


# Generated at 2022-06-11 01:56:20.308050
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Unit test for method __eq__ of class Version"""
    v1 = Version()
    v2 = Version()
    assert v1 == v2

# Generated at 2022-06-11 01:56:29.872551
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import distutils

    distutils.version.__dict__['__all__'] = ['some_thing']
    distutils.version.__dict__['Version'] = Version
    distutils.version.__dict__['LooseVersion'] = LooseVersion
    v = Version('1.1')
    isinstance(v, Version)
    v > '1.0'
    v > '1.1'
    v > '1.2'
    cmp(v, '1.0') == 1
    cmp(v, '1.1') == 0
    cmp(v, '1.2') == -1
    v = Version('1.0')
    v > '1.0'
    v > '1.1'
    v > '1.2'
    cmp(v, '1.0') == 0

# Generated at 2022-06-11 01:56:32.900417
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= "abcd-1"
    assert v <= Version("abcd-1")

# Generated at 2022-06-11 01:56:34.372354
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    m = Version(vstring=None)
    return m

# Generated at 2022-06-11 01:56:36.568111
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    version._cmp = lambda other: 1
    assert version.__gt__(None) is True


# Generated at 2022-06-11 01:57:06.617243
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v2 = Version()
    v3 = '2.0'
    assert v <= v2
    assert v <= v3

# Generated at 2022-06-11 01:57:14.485274
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    class SubVersion(Version):
        def __init__(self, vstring=None):
            self.parse(vstring)

        def _cmp(self, other):
            return 0

        def __str__(self):
            return "1.0"

# Construct instance
    x = SubVersion()
    x2 = SubVersion()

# Verify that x and x2 are equal
    assert x >= x2

# Generated at 2022-06-11 01:57:18.090716
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.1.1')
    assert v < '1.1.2'
    assert v < '1.2'
    assert v < '2'

# Generated at 2022-06-11 01:57:21.349708
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from pytest import raises
    from distutils.version import Version
    
    expected_value = NotImplemented
    actual_value = Version().__eq__(None)
    assert actual_value == expected_value


# Generated at 2022-06-11 01:57:23.765592
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('17.5')
    assert (v < '17.45')

# Generated at 2022-06-11 01:57:29.964930
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import tempfile

# Generated at 2022-06-11 01:57:31.584763
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__(Version())
    assert (not Version().__le__(Version()))

# Generated at 2022-06-11 01:57:34.978962
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    pkgIndex = PkgResources.PackageIndex.PackageIndex()
    pkgIndex.package_versions["name"] = ["1.2.3"]
    pkgIndex["name"] = ["URL"]
    pkgIndex.version_keywords["name"] = ["1.2.3"]
    assert pkgIndex.__getitem__("name") == ["URL"]
    assert pkgIndex.__gt__("name") == False

# Generated at 2022-06-11 01:57:38.395080
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.4')
    assert(v1.__eq__(Version('1.4'))) == True
    assert(v1.__eq__(Version('4.4'))) == False


# Generated at 2022-06-11 01:57:40.701901
# Unit test for method __le__ of class Version
def test_Version___le__():
    r = Version()
    try:
        assert r <= '0.1'
    except AttributeError:
        pass

# Generated at 2022-06-11 01:58:53.783178
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()



# Generated at 2022-06-11 01:58:55.286147
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    return v1 < v2

# Generated at 2022-06-11 01:58:56.721677
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test method Version.__eq__()
    lhs = Version()
    assert not (lhs == 'asd')


# Generated at 2022-06-11 01:58:59.861086
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    '''Unit test for method __gt__ of class Version'''
    # Construct object representing version 1.2.3
    version1 = Version('1.2.3')

    # Construct object representing version 2.3.4
    version2 = Version('2.3.4')

    # Compare version1 with version2
    assert version1 < version2


# Generated at 2022-06-11 01:59:09.912034
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    # Test for numeric version
    lv.parse('1.0')
    assert lv.version == [1, 0]
    # Test for numeric version with letter
    lv.parse('3.10a')
    assert lv.version == [3, 10, 'a']
    # Test for non-numeric version
    lv.parse('3.4j')
    assert lv.version == [3, 4, 'j']
    # Test for date version
    lv.parse('1996.07.12')
    assert lv.version == [1996, 7, 12]
    # Test for invalid version
    lv.parse('0.960923')
    assert lv.version == [0, 960923]



# Generated at 2022-06-11 01:59:10.842109
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= Version()

# Generated at 2022-06-11 01:59:14.206883
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2')
    v2 = Version('1.1')
    assert (v1 > v2) is True
    assert (v1 > '1.1') is True



# Generated at 2022-06-11 01:59:24.496538
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion('1.2.3')
    assert lv.version == [1, 2, 3]
    lv = LooseVersion('1.2.3.4')
    assert lv.version == [1, 2, 3, 4]
    lv = LooseVersion('1.2.3a')
    assert lv.version == [1, 2, 3, 'a']
    lv = LooseVersion('1.2.3.4a')
    assert lv.version == [1, 2, 3, 4, 'a']
    lv = LooseVersion('a.b.c')
    assert lv.version == ['a', 'b', 'c']
    lv = LooseVersion('1.2.3ab')

# Generated at 2022-06-11 01:59:28.900291
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= 0
    assert v >= None
    assert v >= '1'
    assert v >= Version()
    assert v >= StrictVersion()
    assert v >= LooseVersion()
    assert v >= '0'
    assert not (v >= '2')

# Generated at 2022-06-11 01:59:37.703023
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class Version(object):
        def __init__(self, vstring=None): pass
        def __repr__(self): pass
        def _cmp(self, other): return NotImplemented
        def __ge__(self, other): pass
        def __le__(self, other): pass
        def __eq__(self, other): pass
        def __lt__(self, other): pass
        def __gt__(self, other):
            c = self._cmp(other)
            if c is NotImplemented:
                return c
            return c > 0