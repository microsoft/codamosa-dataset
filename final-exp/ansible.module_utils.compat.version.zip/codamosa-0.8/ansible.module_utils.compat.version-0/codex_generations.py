

# Generated at 2022-06-11 01:51:00.551884
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test the __ge__ method of the Version class."""
    for method_name in ('__eq__', '__lt__', '__le__', '__gt__', '__ge__'):
        method = getattr(Version, method_name)
        assert method('1.9.9', '1.9.9')
        assert method('1.10', '1.9.9')
        assert not method('1.9.9', '1.10')
        assert method('1.9.9', '1.9.9a1')
        assert method('1.9.9.a2', '1.9.9a1')
        assert not method('1.9.9a1', '1.9.9.a2')
        assert not method('1.10a1', '2.0a1')
       

# Generated at 2022-06-11 01:51:07.588104
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test with a subclass
    class ExampleVersion(Version):
        def parse(self, vstring):
            self.version = vstring
        def __str__(self):
            return self.version
        def _cmp(self, other):
            if isinstance(other, str):
                other = self.__class__(other)
            return cmp(self.version, other.version)
    assert ExampleVersion('0.5') == '0.5'
    assert ExampleVersion('1.0') != '0.5'
    assert ExampleVersion('a') < 'b'
    assert ExampleVersion('a') <= 'b'
    assert ExampleVersion('a') <= 'a'
    assert ExampleVersion('a') <= ExampleVersion('a')
    assert ExampleVersion('a') != 'a '

# Generated at 2022-06-11 01:51:15.875005
# Unit test for method __le__ of class Version
def test_Version___le__():
    import os

    v = Version()
    v1 = Version('1.0')
    equal_test = v1 <= v1
    test = 'method __le__'
    assert equal_test, '{0}: {1} failed.'.format(__file__, test)

    v2 = Version('1.1')
    less_test = v1 <= v2
    test = 'method __le__'
    assert less_test, '{0}: {1} failed.'.format(__file__, test)



# Generated at 2022-06-11 01:51:18.189755
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    class Foo(Version):
        def _cmp(self, other):
            return other

    assert Foo("v1") == 1



# Generated at 2022-06-11 01:51:30.838012
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    s = StrictVersion("0.4")
    assert(str(s) == "0.4")
    s = StrictVersion("0.4.0")
    assert(str(s) == "0.4.0")
    s = StrictVersion("0.4.1")
    assert(str(s) == "0.4.1")
    s = StrictVersion("0.5a1")
    assert(str(s) == "0.5a1")
    s = StrictVersion("0.5b3")
    assert(str(s) == "0.5b3")
    s = StrictVersion("0.5")
    assert(str(s) == "0.5")
    s = StrictVersion("0.9.6")

# Generated at 2022-06-11 01:51:38.224629
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    def check(input, expected):
        actual = StrictVersion(input).__str__()
        assert actual == expected

    check("0.4", "0.4")
    check("0.4.0", "0.4.0")
    check("0.4.1", "0.4.1")
    check("0.5a1", "0.5a1")
    check("0.5b3", "0.5b3")
    check("0.5", "0.5")
    check("0.9.6", "0.9.6")
    check("1.0", "1.0")
    check("1.0.4a3", "1.0.4a3")
    check("1.0.4b1", "1.0.4b1")

# Generated at 2022-06-11 01:51:41.375279
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version(b"1.0.0")
    v2 = Version(b"2.0.0")
    assert v1 <= v2


# Generated at 2022-06-11 01:51:44.466853
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version()

    # TODO: assert Version() < Version('1.2.3')
    # TODO: assert Version('1.2.3') < Version('1.2.4')

    assert Version('') < Version('')
    assert not Version() < Version()



# Generated at 2022-06-11 01:51:47.520400
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    error_message = "Version.__eq__ is broken."
    a = Version()
    b = Version()
    assert a == b, error_message



# Generated at 2022-06-11 01:51:50.994451
# Unit test for method __ge__ of class Version
def test_Version___ge__():
                v1 = StrictVersion('1.0')
                v2 = StrictVersion('1.0')
                v1 >= v2
test_Version___ge__()


# Generated at 2022-06-11 01:52:06.573760
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    import distutils.version
    class VersionTestCase(unittest.TestCase):
        def test___lt__(self):
            self.assertIs(distutils.version.Version().__lt__(1), NotImplemented)
        def test___lt___(self):
            self.assertNot(distutils.version.Version().__lt__('1'))
        def test___lt__(self):
            self.assertTrue(distutils.version.Version('2.7a1').__lt__(distutils.version.Version('2.7a1.post1')))

    unittest.main()


# Generated at 2022-06-11 01:52:16.762947
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    ## Standard cases
    v = LooseVersion('0.4')
    assert v.version == [0,4]
    assert v.vstring == '0.4'
    v = LooseVersion('1.0')
    assert v.version == [1,0]
    assert v.vstring == '1.0'
    v = LooseVersion('1.5.1')
    assert v.version == [1,5,1]
    assert v.vstring == '1.5.1'
    v = LooseVersion('2.2beta29')
    assert v.version == [2,2,'beta',29]
    assert v.vstring == '2.2beta29'
    v = LooseVersion('3.4j')
    assert v.version == [3,4,'j']
    assert v.v

# Generated at 2022-06-11 01:52:18.196997
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1)


# Generated at 2022-06-11 01:52:19.393173
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1._cmp(v2) == 0



# Generated at 2022-06-11 01:52:25.909641
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    for argCount in range(4):
        obj = Version()
        method = getattr(obj, '__lt__')
        if argCount == 0:
            args = []
            expected = obj._cmp(0)
        if argCount == 1:
            args = [None]
            expected = obj._cmp(args[0])
        if argCount == 2:
            args = [0, 0]
            expected = obj._cmp(args[0], args[1])
        if argCount == 3:
            args = [0, 0, 0]
            expected = obj._cmp(args[0], args[1], args[2])
        method(*args)


# Generated at 2022-06-11 01:52:28.792613
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert not (Version('1.2') < '1.2b1')
    assert (Version('1.2') < '1.2.0')
    assert (Version('1.2') < '1.2.0.0')
    assert not (Version('1.2') < '1.2')


# Generated at 2022-06-11 01:52:33.810366
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert not v.__lt__(v)
    assert not v.__lt__('1.2.3')
    assert v.__lt__('1.2.3-')
    assert not v.__lt__(b'1.2.3')
    assert not v.__lt__(None)
    assert not v.__lt__(object())
    assert not v.__lt__(object)
    assert v.__lt__(2)

# Generated at 2022-06-11 01:52:44.035390
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from ansible_collections.ansible.netcommon.plugins.module_utils.version import Version
    from ansible_collections.ansible.netcommon.plugins.module_utils.version import LooseVersion
    assert LooseVersion("1.0.0") < LooseVersion("2.0.0")
    assert not (LooseVersion("1.0.0") < LooseVersion("1.0.0"))
    assert not (LooseVersion("1.0.0") < LooseVersion("0.9.9"))
    assert not (LooseVersion("1.3.0") < LooseVersion("1.2.9"))
    assert not (LooseVersion("1.0.0") < LooseVersion("1.0.0b1"))

# Generated at 2022-06-11 01:52:52.546820
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version(1) != Version(2)
    assert Version(2) != Version(1)
    assert Version(1) == Version(1)
    assert Version(1) != 1
    assert 1 != Version(1)
    assert Version(1) <= Version(2)
    assert Version(1) <= Version(1)
    assert Version(1) < Version(2)
    assert not Version(1) < Version(1)
    assert Version(1) >= Version(1)
    assert Version(2) >= Version(1)
    assert Version(2) > Version(1)
    assert not Version(1) > Version(1)



# Generated at 2022-06-11 01:52:56.060640
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    for cls in [StrictVersion, LooseVersion]:
        v = cls("1.2.3a4")
        assert (v == v) is True

# Generated at 2022-06-11 01:53:05.651530
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    try:
        v.__init__()
    except TypeError:
        pass
    else:
        assert False, "unable to test __lt__ without __init__"

# Generated at 2022-06-11 01:53:16.095911
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test the method Version.__ge__()."""

# imports
# import Version
# import StrictVersion
# import LooseVersion
    v1 = Version('5.5.5')
    v2 = Version('5.5.4')
    assert v1 >= v2, "%s.__ge__(%s)" % (v1, v2)

    v1 = Version('5.5.4')
    v2 = Version('5.5.4')
    assert v1 >= v2, "%s.__ge__(%s)" % (v1, v2)

    v1 = Version('5.5.3')
    v2 = Version('5.5.4')
    assert not v1 >= v2, "%s.__ge__(%s)" % (v1, v2)

    v1 = Version

# Generated at 2022-06-11 01:53:18.065140
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version._Version__ge__('abc', 'abc')

# Generated at 2022-06-11 01:53:28.667762
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class subVersion(Version):
        def __init__(self, vstring=None):
            Version.__init__(self, vstring)
            self.pre_version = 'alpha1'
        def __str__(self):
            return '%s.%s' % (self.pre_version, '.'.join(map(str, self.version)))

# Generated at 2022-06-11 01:53:39.055362
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    def init(self, vstring=None):
        self.value = vstring
    import types
    import sys
    import copy
    import unittest
    old_v = sys.version_info[:3]

    class VersionTestCase(unittest.TestCase):
        def test___gt__(self):
            v1 = Version("1.2.33")
            v2 = Version("1.2.33")
            v_str = "1.2.33"
            v3 = Version("1.3.31")
            v4 = Version("1.2.34")
            self.assertFalse(v1 > v2)
            self.assertFalse(v1 > v_str)
            self.assertTrue(v3 > v1)
            self.assertTrue(v4 > v1)

# Generated at 2022-06-11 01:53:39.985060
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    pass



# Generated at 2022-06-11 01:53:48.898431
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import StrictVersion

    # 
    # This method tests a regression in the __eq__ method between
    # versions 2.3.3 and 2.3.4 of the Python interpreter.  The Python bug
    # tracker [SF-841240] uses this method as a test case.

    v1 = StrictVersion('1.2.0')
    v2 = StrictVersion('1.2')

    if v1 == v2:
        print('%s == %s' % (v1, v2))
    else:
        print('%s != %s' % (v1, v2))

    if v1.__eq__(v2):
        print('%s.__eq__(%s)' % (v1, v2))

# Generated at 2022-06-11 01:53:50.186682
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v



# Generated at 2022-06-11 01:53:56.656332
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """
    If method parse of class LooseVersion accepts a string as an argument
    and if the string contains a number that is greater than sys.maxsize,
    then the returned value of method parse is None.
    """
    number_maxsize = str(sys.maxsize) + '1'
    email = ' '*number_maxsize + '@gmail.com'
    if LooseVersion(email).parse(email) is None:
        return 'ok'

# Generated at 2022-06-11 01:54:03.972664
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1')
    assert v == '1'
    assert not(v == '1.1')
    v = Version('1.1')
    assert not(v == '1')
    assert not(v == '2')
    assert v == '1.1'
    assert not(v == '1.1.1')
    v = Version('1.1-rc1')
    assert not(v == '1.1')
    assert v == '1.1-rc1'
    assert not(v == '1.1-rc2')


# Generated at 2022-06-11 01:54:12.674981
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  for i in range(3):
    if i >= 2:
      break
    else:
      print("Loop #%s" % (i))
  # Unit test for method __le__ of class Version

# Generated at 2022-06-11 01:54:16.691558
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v1 = Version("1")
    assert not v1 <= None
    assert v1 <= v1
    assert v1 <= "1"
    assert v1 <= "2"
    assert not v1 <= "0"

# Generated at 2022-06-11 01:54:19.133295
# Unit test for method __gt__ of class Version
def test_Version___gt__():
  import ansible.module_utils.six as six
  v = Version()
  assert six.PY3
  assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-11 01:54:20.884119
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("1.0") <= Version("1.0")


# Generated at 2022-06-11 01:54:27.187339
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  try:
    import test.test_version
    test.test_version.test_StrictVersion___lt__.__dict__.clear()
    test.test_version.test_LooseVersion___lt__.__dict__.clear()
  except (ImportError, AttributeError):
    pass
  # Test for method __lt__ of class Version (import test.test_version)
test_Version___lt__()


# Generated at 2022-06-11 01:54:30.272118
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest

    from distutils.tests import support

    class VersionTestCase(support.TestCase):

        def test_Version___ge__(self):
            v = Version("4.6")
            self.assertFalse( v < "4.6")

    unittest.main()

# Generated at 2022-06-11 01:54:34.971891
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert v1 <= v2
# test Main
v1 = Version()
v2 = Version()
assert v1 == v2
assert not v1 != v2
assert not v1 < v2
assert v1 <= v2
assert not v1 > v2
assert v1 >= v2



# Generated at 2022-06-11 01:54:36.288244
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert not v.__gt__(42)


# Generated at 2022-06-11 01:54:45.557829
# Unit test for method __lt__ of class Version
def test_Version___lt__(): 
    with mock.patch('setup.py.distutils.version.Version', autospec=True) as MockVersion: 
        x = MockVersion()
        x._cmp = mock.Mock()
        x._cmp.return_value = NotImplemented
        assert x.__lt__(mock.Mock()) == NotImplemented
        x._cmp.return_value = 1
        assert x.__lt__(mock.Mock()) is False
        x._cmp.return_value = 0
        assert x.__lt__(mock.Mock()) is False
        x._cmp.return_value = -1
        assert x.__lt__(mock.Mock()) is True

# Generated at 2022-06-11 01:54:55.430820
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    def check(a, b, cmp):
        lt = cmp(a, b)
        gt = cmp(b, a)
        if lt:
            assert str(lt) == 'True'
            if gt:
                assert str(gt) == 'False'
        else:
            assert str(gt) == 'False'

    class A(Version):
        def _cmp(self, other):
            return 0
        def __repr__(self):
            return 'A'

    class B(Version):
        def _cmp(self, other):
            return NotImplemented
        def __repr__(self):
            return 'B'
    class C(Version):
        def _cmp(self, other):
            return -1
        def __repr__(self):
            return 'C'

# Generated at 2022-06-11 01:55:13.137117
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from copy import deepcopy
    from distutils.version import Version
    actual = Version('1.0').__lt__('2.0')
    assert actual == True
    assert actual == Version('1.0').__lt__('2.0')
    assert actual == Version('1.0').__lt__('2.0')
    assert actual == Version('1.0').__lt__('2.0')
    assert actual == Version('1.0').__lt__('2.0')
    assert actual == Version('1.0').__lt__('2.0')
    v = Version('1.0')
    actual = v.__lt__('2.0')
    assert actual == True
    assert actual == v.__lt__('2.0')
    assert actual == v.__lt__('2.0')

# Generated at 2022-06-11 01:55:15.835520
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert not v1._cmp(v2)
    assert v1.__lt__(v2)
    assert v1.__le__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__ge__(v2)
test_Version___lt__()

# Generated at 2022-06-11 01:55:20.235833
# Unit test for method __le__ of class Version
def test_Version___le__():
    class TestVersion(Version):
        def parse(self, vstring):
            pass
        def _cmp(self, other):
            return 0
    v1 = TestVersion('1.0')
    v2 = TestVersion('2.0')
    assert v1 <= v2

# Generated at 2022-06-11 01:55:24.651154
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    version._cmp = lambda other: 1
    assert version.__gt__(0) is True
    version._cmp = lambda other: 0
    assert version.__gt__(0) is False
    version._cmp = lambda other: -1
    assert version.__gt__(0) is False



# Generated at 2022-06-11 01:55:26.245625
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__(4) == NotImplemented


# Generated at 2022-06-11 01:55:28.107168
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-11 01:55:29.177267
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert(v == None)

# Generated at 2022-06-11 01:55:35.889056
# Unit test for method __le__ of class Version
def test_Version___le__():
    for x in [(Version('1.1.1'), Version('1.1.1'), True),
        (Version('1.1.1'), Version('1.1.2'), True),
        (Version('1.1.2'), Version('1.1.1'), False),
        (Version('1.1.1'), '1.1.2', True),
        (Version('1.1.2'), '1.1.1', False)]:
        if (x[0].__le__(x[1]) != x[2]):
            return False
    return True

# Generated at 2022-06-11 01:55:39.142889
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version( "a" ) >=  Version( "a" )
    assert not (  Version( "b" ) >=  Version( "a" ) )
    assert  Version( "a" ) >=  Version( "b" )

# Generated at 2022-06-11 01:55:41.844813
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    # testing with a random number
    assert (not v.__gt__(982))
    # testing with a random string
    assert (not v.__gt__("v"))



# Generated at 2022-06-11 01:56:18.637481
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    vo1 = MyVersion("1.2.3")
    vo2 = MyVersion("1.2.4")
    c = vo1.__ge__(vo2)
    if c is NotImplemented:
        print("c is NotImplemented")
    elif c == True:
        print("c == True")
    elif c == False:
        print("c == False")
    else:
        print("c is unexpected value")
    vo1 = MyVersion("1.2.4")
    vo2 = MyVersion("1.2.4")
    c = vo1.__ge__(vo2)
    if c is NotImplemented:
        print("c is NotImplemented")
    elif c == True:
        print("c == True")

# Generated at 2022-06-11 01:56:27.557793
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """
    Unit test for method __lt__ of class Version
    """
    # Test with 0.0.0 and 0.0.1
    v1 = Version()
    v1.parse('0.0.0')
    v2 = Version()
    v2.parse('0.0.1')
    assert not v1.__lt__(v2)
    assert v1.__le__(v2)
    assert v1.__eq__(v1)
    assert v1.__ne__(v2)
    assert v1.__ge__(v1)
    assert not v1.__gt__(v1)
    # Test with 0.0.1 and 0.0.0
    assert v2.__lt__(v1)
    assert not v2.__le__(v1)

# Generated at 2022-06-11 01:56:37.183914
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    print("Test __eq__ of class Version")

    class MyVersion(Version):
        def __init__(self, label):
            Version.__init__(self, label)

        def parse(self, vstring):
            self.label = vstring

        def __str__(self):
            return self.label

        def _cmp(self, other):
            return NotImplemented

    # Run the test
    data = [
        ('one', 'two', False),
        ('one', 'one', True),
    ]

    for vstring, other, result in data:
        assert MyVersion(vstring) == other == MyVersion(other) == result


# Generated at 2022-06-11 01:56:44.361732
# Unit test for method __ge__ of class Version

# Generated at 2022-06-11 01:56:50.738224
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  o=Version("0.0.5")
  p=Version("0.0.5")
  q=Version("0.0.5")
  # True if either o is p, or p is o
  r1 = (o == p) or (p == o)
  assert r1
  # True if o is p and p is q
  r2 = (o == p) and (p == q)
  assert r2


# Generated at 2022-06-11 01:57:00.784851
# Unit test for method __le__ of class Version
def test_Version___le__():
    '''
    Unit test for method __le__ of class Version
    '''
    #
    # Create a mock up object for class Version
    #
    class MockVersion:
        def __init__(self, vstring):
            self.vstring = vstring
        def __repr__(self):
            return str(self.vstring)
        def __le__(self, other):
            return self.vstring <= other
    #
    # Create a version object for testing with
    #
    myver = Version()
    #
    # Create a mock version object for testing with
    #
    mockver = MockVersion('1.0')
    #
    # Test for equality
    #
    assert mockver <= myver
    #
    # Create another mock version object for testing with
    #
    mockver2 = Mock

# Generated at 2022-06-11 01:57:02.513658
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('0.0.0') <= Version('0.0.0')


# Generated at 2022-06-11 01:57:08.156053
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Unit test for method __lt__ of class Version
    # If a naive comparison is implemented in __lt__, and it
    # returns NotImplemented, then the interpreter will fall
    # back to __cmp__, which doesn't belong in this framework
    assert(Version() < '1')
    return



# Generated at 2022-06-11 01:57:12.061750
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.0')
    v1_dup = Version('1.0')
    v2 = Version('1.1')
    v3 = Version('2.0')

    assert not (v1 == v2)
    assert not (v1 == v3)
    assert v1 == v1_dup


# Generated at 2022-06-11 01:57:17.817185
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import types
    import unittest
    class Test(unittest.TestCase):
        def test(self):
            # Call the method via its name
            self.assertTrue(Version.__gt__(1, 2))

    # Run unit test
    unittest.main()


# Generated at 2022-06-11 01:58:26.466558
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert (v1 > v2) == False
test_Version___gt__()


# Generated at 2022-06-11 01:58:30.902880
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert not v1.__ge__(v2)
    assert v1.__ge__(v1)
    assert v2.__ge__(v1)
    assert v2.__ge__(v2)



# Generated at 2022-06-11 01:58:39.146213
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert (Version() > "") == NotImplemented
    assert (Version("1") > "1") == False
    assert (Version("1") > "1.1") == True
    assert (Version("1") > "0") == False
    assert (Version("1") > "2") == True
    assert (Version("1.1") > "1.1") == False
    assert (Version("1.1") > "1.1.1") == True
    assert (Version("1.1") > "1.0") == False
    assert (Version("1.1") > "1.2") == True

if __name__ == "__main__":
    test_Version___gt__()



# Generated at 2022-06-11 01:58:40.421888
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.0')
    return v >= '1.0'



# Generated at 2022-06-11 01:58:51.654685
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from sys import hexversion
    from types import ModuleType
    from unittest import TestCase
    import_error = False
    try:
        from distutils.version import StrictVersion
    except ImportError:
        import_error = True
    class Test___ge__(TestCase):
        @unittest.skipIf(import_error, "could not import 'StrictVersion' from 'distutils.version'")
        def test___ge__1(self):
            class TestVersion(StrictVersion):
                pass
            options = TestVersion("2.7.10") >= TestVersion("2.7.2")
            self.assertEqual(options, True)
            options = TestVersion("2.7.10") > TestVersion("2.7.9")
            self.assertEqual(options, True)
            options = TestVersion

# Generated at 2022-06-11 01:58:57.104903
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert (Version(vstring='1.0') > Version(vstring='1.1')) is False
    assert (Version(vstring='1.0') > Version(vstring='1.0')) is False
    assert (Version(vstring='1.2') > Version(vstring='1.1')) is True



# Generated at 2022-06-11 01:58:59.633169
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    this = Version()
    try:
        this._cmp(other)
    except NameError as e:
        assert True
    else:
        assert False



# Generated at 2022-06-11 01:59:10.282521
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import inspect
    import sys
    import copy

    def deepcopy(obj):
        '''
        Custom deep copy function required to preserve custom properties in objects
        '''
        if isinstance(obj, dict):
            return {k: deepcopy(v) for k, v in obj.items()}

        if isinstance(obj, (list, tuple)):
            return [deepcopy(element) for element in obj]

        if isinstance(obj, set):
            return {deepcopy(element) for element in obj}

        if hasattr(obj, '__class__'):
            new_obj = obj.__class__()
        else:
            new_obj = obj

        if isinstance(obj, Version):
            new_obj.parse(obj)
        else:
            new_obj = copy.copy(obj)


# Generated at 2022-06-11 01:59:13.745938
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version("0.0.0.0") < Version("0.0.0.1")
    assert not (Version("0.0.0.1") < Version("0.0.0.0"))


# Generated at 2022-06-11 01:59:15.160621
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.0')
    assert (v >= '1.0') is True
