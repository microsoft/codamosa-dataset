

# Generated at 2022-06-11 01:50:47.806345
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2')
    v2 = Version('1.1')
    assert v1 > v2  # Make sure that this is available


# Generated at 2022-06-11 01:50:50.369890
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version().__lt__(None) == NotImplemented
    assert Version().__lt__(Version()) == False


# Generated at 2022-06-11 01:50:52.202836
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ver = Version()
    assert ver.__lt__(1) == NotImplemented


# Generated at 2022-06-11 01:51:02.924042
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import unittest
    class Test(unittest.TestCase):
            def test_StrictVersion_parse(self):
                v = StrictVersion('1.2')
                self.assertEqual(v.version, (1, 2, 0))
                self.assertEqual(v.prerelease, None)
                v = StrictVersion('1.3rc2')
                self.assertEqual(v.version, (1, 3, 0))
                self.assertEqual(v.prerelease, ('rc', 2))
                v = StrictVersion('1.4c5')
                self.assertEqual(v.version, (1, 4, 0))
                self.assertEqual(v.prerelease, ('c', 5))
                v = StrictVersion('1.5a6')
                self.assertEqual

# Generated at 2022-06-11 01:51:10.705451
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v1._cmp = lambda x: NotImplemented
    assert v1.__le__('a') == NotImplemented
    v1._cmp = lambda x: 1
    assert v1.__le__('a') == False
    v1._cmp = lambda x: 0
    assert v1.__le__('a') == True
    v1._cmp = lambda x: -1
    assert v1.__le__('a') == True


# Generated at 2022-06-11 01:51:12.534315
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version("1.0") < Version("2.0")

# Generated at 2022-06-11 01:51:21.475907
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Unit test for method __le__ of class Version
    from copy import copy
    from distutils.version import Version
    v = Version('1.0')
    assert v <= '1.0'
    assert v <= Version('1.0')
    assert v <= '1.1'
    assert v <= Version('1.1')
    assert not v <= '0.9'
    assert not v <= Version('0.9')
    assert not v <= ''
    assert not v <= Version('')
    assert v < '1.1'
    assert v < Version('1.1')
    assert not v < '1.0'
    assert not v < Version('1.0')
    assert v < '2.0'
    assert v < Version('2.0')
    assert not v < '1.0a1'
   

# Generated at 2022-06-11 01:51:27.372714
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    assert v1.__ge__(None) == NotImplemented

    v1 = Version("1.2.3")
    assert v1.__ge__("2.0") == False


    v1 = Version("1.2.3")
    assert v1.__ge__("1.2.3") == True



# Generated at 2022-06-11 01:51:31.283141
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1").__str__() == "1"
    assert StrictVersion("1.1").__str__() == "1.1"
    assert StrictVersion("1.1.1").__str__() == "1.1.1"
    assert StrictVersion("1a1").__str__() == "1a1"
    assert StrictVersion("1b1").__str__() == "1b1"
    assert StrictVersion("1.1a1").__str__() == "1.1a1"
    assert StrictVersion("1.1b1").__str__() == "1.1b1"
    assert StrictVersion("1.1.1a1").__str__() == "1.1.1a1"
    assert StrictVersion("1.1.1b1").__

# Generated at 2022-06-11 01:51:39.088393
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # self._cmp(other) < 0
    v = Version()
    v._cmp = lambda other: -1
    assert v.__gt__(1) == 1

    # self._cmp(other) == 0
    v = Version()
    v._cmp = lambda other: 0
    assert v.__gt__(1) == 0

    # self._cmp(other) > 0
    v = Version()
    v._cmp = lambda other: 1
    assert v.__gt__(1) == 0

    # self._cmp(other) is NotImplemented
    v = Version()
    v._cmp = lambda other: NotImplemented
    assert v.__gt__(1) is NotImplemented

# Generated at 2022-06-11 01:51:52.279332
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version

    assert Version("1.0") <= "1.0"
    assert not Version("1.0") <= "1.0.dev454"



# Generated at 2022-06-11 01:52:02.967749
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils2.tests import unittest
    from distutils2.version import Version

    class TestVersion(Version):
        def parse(self, vstring):
            self.vstring = vstring

    class TestVersion2(Version):
        def parse(self, vstring):
            self.vstring = vstring

    v1 = TestVersion('1.0')
    v2 = TestVersion('2.0')

    # Testing Version __le__
    assert v1 <= v2
    assert v1 <= '2.0'
    assert not v2 <= v1
    assert v2 <= v2
    assert not v2 <= '1.0'
    assert not v2 <= '1'
    assert v2 <= '2'

    try:
        v1 <= None
    except TypeError:
        pass

# Generated at 2022-06-11 01:52:09.403580
# Unit test for method __le__ of class Version
def test_Version___le__():
  try:
    v = Version('1.1')
    u = Version('1.1')
    x = 2
    y = 2
    assert v <= u
    assert v <= '1.1'
    assert v <= 1
    assert x <= 2
    assert 2 <= y
  except:
    import traceback
    traceback.print_exc()


# Generated at 2022-06-11 01:52:14.171731
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Unit test for method __ge__ of class Version"""
    
    assert Version('1') >= '1'
    assert not Version('1') >= '2'
    assert Version('1') >= Version('1')
    assert not Version('1') >= Version('2')
    assert not Version('1.2') >= '1.2.1'

# Generated at 2022-06-11 01:52:18.679962
# Unit test for method __ge__ of class Version
def test_Version___ge__():
# when
    result = Version().__ge__(None)
# then
    assert result is False
#Unit test for method __ge__ of class Version
    def test_Version___ge__():
# when
        result = Version().__ge__(None)
# then
        assert result is False


# Generated at 2022-06-11 01:52:20.506376
# Unit test for method __le__ of class Version
def test_Version___le__():
    if __name__ == '__main__':
        assert Version(1) <= Version(2)
        assert Version(2) <= Version(2)
        assert not Version(3) <= Version(2)



# Generated at 2022-06-11 01:52:22.962859
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    if v.__eq__(None) != NotImplemented:
        raise AssertionError

# Generated at 2022-06-11 01:52:28.376464
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test a version number with no prerelease indicator.
    v = StrictVersion('1.0')
    assert str(v) == '1.0'

    # Test a version number with a prerelease indicator.
    v = StrictVersion('1.0a1')
    assert str(v) == '1.0a1'


# Generated at 2022-06-11 01:52:31.198246
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    _input = '1.0.0'
    _input2 = '2.0.0'
    _expected_output = True
    _output = Version(_input) < Version(_input2)
    assert _output == _expected_output



# Generated at 2022-06-11 01:52:32.412879
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert (v == v)

# Generated at 2022-06-11 01:52:44.913106
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version ("1.2")
    assert v < "1.3"



# Generated at 2022-06-11 01:52:45.827350
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    StrictVersion('0')


# Generated at 2022-06-11 01:52:48.692092
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Unit test for method __le__ of class Version"""
    v = Version()
    assert(v.__le__(v) == True)

# Generated at 2022-06-11 01:52:50.505093
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-11 01:52:54.299583
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.0")
    assert str(v) == "1.0", "StrictVersion should output '1.0'"
    v = StrictVersion("1.0.0")
    assert str(v) == "1.0.0", "StrictVersion should output '1.0.0'"



# Generated at 2022-06-11 01:52:55.919398
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1")
    v2 = Version("2")
    assert v1 < v2



# Generated at 2022-06-11 01:53:04.177509
# Unit test for method __le__ of class Version
def test_Version___le__():
    op = Version.__le__
    def test(a, b, exp):
        res = op(a, b)
        if res != exp:
            if res is NotImplemented:
                res = 'NotImplemented'
            print('%s <= %s == %s but expected %s'
                  % (a, b, res, exp))
    test(Version('1'), '2', True)
    test('2', Version('1'), False)
    test(None, None, NotImplemented)



# Generated at 2022-06-11 01:53:06.357222
# Unit test for method __le__ of class Version
def test_Version___le__():
  v = Version()
  # should raise
  with pytest.raises(NotImplementedError): v.__le__(set([42, 42]))

# Generated at 2022-06-11 01:53:09.082909
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('xyz')
    assert not v1.__eq__(None)


# Generated at 2022-06-11 01:53:11.013531
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    s = StrictVersion('1.0')
    assert str(s) == '1.0'


# Generated at 2022-06-11 01:53:24.540792
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v <= '1.2.3'
    assert v >= '1.2.3'
    assert v != '1.2.4'
    assert v != '1.2.2'
    assert v != '1.2.22'

# Generated at 2022-06-11 01:53:26.758915
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import types
    v = Version()
    assert v.__lt__(Version()) == False


# Generated at 2022-06-11 01:53:37.521492
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from collections import namedtuple
    from datetime import date
    from distutils.version import Version
    from sys import getrefcount as grc
    class Version(Version):
        def parse(self, vstring):
            pass
    class Other(object):
        def __init__(self, a):
            self.a = a
        def __lt__(self, other):
            raise TypeError
    class OtherR(Other):
        def __gt__(self, other):
            raise TypeError
        def __le__(self, other):
            raise TypeError
        def __ge__(self, other):
            raise TypeError
        def __eq__(self, other):
            raise TypeError
    class OtherD(Other):
        def __le__(self, other):
            raise TypeError

# Generated at 2022-06-11 01:53:45.868774
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # /home/wilbur/bills-repos/py/python-tools/setup/base.py:75: "self._cmp(other)"
    # /usr/lib/python3.7/distutils/version.py:109: "c = self._cmp(other)"
    # /usr/lib/python3.7/distutils/version.py:109: "c = self._cmp(other)"
    # /usr/lib/python3.7/distutils/version.py:109: "c = self._cmp(other)"
    assert False, "Not implemented"



# Generated at 2022-06-11 01:53:52.307230
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    v3 = Version('1.3.3')
    v4 = Version('2.1.1')
    assert not (v1 > v1)
    assert not (v2 > v2)
    assert v2 > v1
    assert v3 > v1
    assert v4 > v1
    assert v4 > v2
    assert v4 > v3


# Generated at 2022-06-11 01:53:53.823943
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("2.0").__le__("2.0.0")

# Generated at 2022-06-11 01:53:55.680829
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v

# Generated at 2022-06-11 01:53:58.501990
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.0')
    assert (v == '1.0')  # __eq__ is implemented as a direct call to _cmp


# Generated at 2022-06-11 01:54:01.427599
# Unit test for method __le__ of class Version
def test_Version___le__():
    from types import BuiltinMethodType as types_BuiltinMethodType

    v = Version()

    assert isinstance(v.__le__, types_BuiltinMethodType)

# Generated at 2022-06-11 01:54:02.659030
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v



# Generated at 2022-06-11 01:54:12.844851
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version()
    str = (1)
    other = (1)
    ret = version.__eq__(other)
    if ret is True:
        pass
    else:
        raise RuntimeError(ret)



# Generated at 2022-06-11 01:54:17.563174
# Unit test for method __le__ of class Version
def test_Version___le__():
    print("Testing Version.__le__")
    v1 = Version("0.0.0")
    assert v1 == "0.0.0"
    v2 = Version("0.0.0")
    assert not v1 < v2
    assert not v1 > v2

# Generated at 2022-06-11 01:54:18.407889
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version() >= Version()


# Generated at 2022-06-11 01:54:29.005590
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils2.version import Version
    # Test for a class whose _cmp returns NotImplemented
    class Test(Version):
        def _cmp(self, other):
            return NotImplemented
    assert Test() > None
    assert Test() > 'abc'

    # Test for a class whose _cmp returns an incompatible type
    class Test2(Version):
        def _cmp(self, other):
            return 0.1
    try:
        Test2() < 'abc'
    except TypeError:
        pass
    else:
        raise AssertionError

    # Test for a class whose _cmp returns an incompatible type
    class Test3(Version):
        def _cmp(self, other):
            return 1
    assert Test3() > 'abc'



# Generated at 2022-06-11 01:54:31.046397
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.3.0')
    v2 = Version('1.3.5')
    assert v1 < v2


# Generated at 2022-06-11 01:54:32.396588
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.1') == Version('1.1')

# Generated at 2022-06-11 01:54:34.882969
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__('') == NotImplemented


    # Unit test for method __ne__ of class Version

# Generated at 2022-06-11 01:54:45.366921
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        a = Version('0.9.6')
        b = Version('0.9.6')
        assert a == b
    except Exception as err:
        raise err
    try:
        a = Version('0.9.8')
        b = Version('0.9.6')
        assert a != b
    except Exception as err:
        raise err
    try:
        a = Version('0.9.6')
        b = Version('0.9.10')
        assert a != b
    except Exception as err:
        raise err
    try:
        a = Version('0.9.6')
        b = Version('0.10.6')
        assert a != b
    except Exception as err:
        raise err

# Generated at 2022-06-11 01:54:55.300504
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import Version
    import unittest
    v1 = Version('1.0')
    v2 = Version('1.0.0')
    v3 = Version('1.0.1')
    v4 = Version('1.0.0.0')
    v5 = Version('1.0.0.0.0')
    v6 = Version('1.0.0.0.1')
    v7 = Version('1.3')
    v8 = Version('1.10')
    v9 = Version('2.0')
    v10 = Version('2.0.0')
    v11 = Version('2.0.0.0')
    v12 = Version('2.0.0b1.dev345')
    v13 = Version('2.0.0b2.dev345')
   

# Generated at 2022-06-11 01:54:58.498499
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('')
    v2 = Version('')
    assert(not v1 < v2)

# Generated at 2022-06-11 01:55:20.823698
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.1.1').__ge__(Version('1.0.0a1')) == True


# Generated at 2022-06-11 01:55:28.196457
# Unit test for method __ge__ of class Version

# Generated at 2022-06-11 01:55:30.665832
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Unit test for method __gt__ of class Version"""
    ver1 = Version('1')
    ver2 = Version('2')

    assert ver1 < ver2
    assert ver1 <= ver2
    assert ver1 != ver2
    assert ver2 > ver1
    assert ver2 >= ver1



# Generated at 2022-06-11 01:55:32.405993
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    pass


# Generated at 2022-06-11 01:55:35.361907
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test method Version.__ge__."""
    __tracebackhide__ = True
    return test_Version___cmp__(partial="__ge__")

    # Unit test for method __gt__ of class Version

# Generated at 2022-06-11 01:55:36.262180
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version() == Version()

# Generated at 2022-06-11 01:55:43.722802
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version, LooseVersion
    basic_cases = [
        (LooseVersion("1.2.3"), LooseVersion("1.2.3"), True),
        (LooseVersion("1.2.3"), LooseVersion("1.3.3"), False),
        (Version("1.2.3"), Version("1.2.3"), True),
        (Version("1.2.3"), Version("1.3.3"), False),
        (Version("1.2.3"), LooseVersion("1.3.3"), False),
        (LooseVersion("1.2.3"), Version("1.2.3"), True),
    ]

    test_data = []
    for v, w, expected in basic_cases:
        test_data.append((v, w, expected))
        test_data

# Generated at 2022-06-11 01:55:45.672678
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('2.0').__le__(Version('2.1')) == True


# Generated at 2022-06-11 01:55:48.984076
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("0") <= Version("0")
    assert Version("0") <= Version("1")
    assert Version("1") <= Version("1")
    assert Version("0") <= "0"
    assert not (Version("0") <= "1")

# Generated at 2022-06-11 01:55:52.127061
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert (Version('1.4.4') == Version('1.4.4'))
    assert not (Version('1.4.4') == '1.4.4')



# Generated at 2022-06-11 01:56:26.805062
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2')
    assert v == Version('1.2'), "Test #1 of Version.__eq__ failed"
    assert v != Version('2.0'), "Test #2 of Version.__eq__ failed"

# Generated at 2022-06-11 01:56:27.951806
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert(Version.__gt__(Version(), Version()) == NotImplemented)


# Generated at 2022-06-11 01:56:30.813977
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    v.parse = mock_parse
    v2 = Version()
    v2.parse = mock_parse
    assert v.__ge__(v2)


# Generated at 2022-06-11 01:56:31.455817
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('0.0') <= Version('0.0')

# Generated at 2022-06-11 01:56:37.826721
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Version.__le__(Version object, object) -> bool
    # Version.__le__(Version object, Version object) -> bool
    assert not Version("1") <= "0"
    assert Version("1") <= "1"
    assert Version("1") <= "2"
    assert Version("1") <= Version("0")
    assert Version("1") <= Version("1")
    assert Version("1") <= Version("2")

# Generated at 2022-06-11 01:56:44.626238
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.tests import unittest
    from distutils.version import Version

    class VersionTestCase(unittest.TestCase):
        def test_ge(self):
            v1 = Version("1.2.3")
            v2 = Version("1.2.3")

            self.assertTrue(v1 >= v2)
            self.assertTrue(v1 <= v2)
            self.assertTrue(v1 == v2)
            self.assertTrue(not v1 > v2)
            self.assertTrue(not v1 < v2)
            self.assertTrue(not v1 != v2)

    suite = unittest.makeSuite(VersionTestCase)

    # Execute test case suite
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-11 01:56:46.961819
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    x = Version("1.0")
    y = Version("2.0")
    assert (x < y) == True


# Generated at 2022-06-11 01:56:55.602040
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version
    from distutils.tests import support
    try:
        import __builtin__
        b = __builtin__.object
    except ImportError:
        b = object
    # Trivial
    o0 = Version()
    o1 = Version()
    o2 = Version('opaque')
    o3 = Version('opaque')
    o4 = Version('foo', 1, 2, 3)
    o5 = Version('foo', 1, 2, 3)
    assert o0 == o0
    assert o2 == o2
    assert o3 == o3
    assert o4 == o4
    # b = object
    assert o0 != b
    assert o1 != b
    assert o2 != b
    assert o3 != b
    assert o4 != b
    # o0 = Version

# Generated at 2022-06-11 01:57:07.008735
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-11 01:57:11.957612
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """"""
    v = Version('1.0')
    v10a = Version('1.1')
    v10b = Version('1.10')
    v10c = Version('1.10.1')
    v.__lt__(v10a)
    v.__lt__(v10b)
    v.__lt__(v10c)



# Generated at 2022-06-11 01:58:30.854981
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    '''
    Returns true if the unit test passes, false otherwise
    '''
    class VersionSubclass(Version): pass
    v = VersionSubclass('1.2.3')
    if v.__gt__('1.2.4'):
        return False
    if v.__gt__('1.2.3'):
        return False
    if not v.__gt__('1.2.2'):
        return False
    return True


# Generated at 2022-06-11 01:58:32.548999
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    assert version.__gt__(0) == NotImplemented



# Generated at 2022-06-11 01:58:36.617987
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.3')
    v2 = Version('1.2')
    assert v1 > v2
    assert not v1 < v2
    assert not v1 == v2
    assert not v1 <= v2
    assert v1 >= v2

# Generated at 2022-06-11 01:58:38.093850
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v=Version("3.4.5")
    assert v=="3.4.5"

# Generated at 2022-06-11 01:58:40.427131
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  ver1 = '4.0a1'
  ver2 = '4.0c1'
  assert Version(ver1) >= Version(ver2)



# Generated at 2022-06-11 01:58:43.633296
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Test method __eq__ of class version_info using version instances."""
    v1 = Version('1.2')
    v2 = Version('1.2')
    assert v1 == v2



# Generated at 2022-06-11 01:58:45.782326
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.3.3')
    assert v1 < v2

# Generated at 2022-06-11 01:58:46.742896
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version(None) >= ''

# Generated at 2022-06-11 01:58:49.321860
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # version.py:934
    pass


# Generated at 2022-06-11 01:58:50.733237
# Unit test for method __le__ of class Version
def test_Version___le__(): assert (Version() <= Version()) is NotImplemented