

# Generated at 2022-06-11 01:50:58.287192
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version = StrictVersion('0.4')
    assert version.version == (0, 4, 0)
    assert version.prerelease is None

    version = StrictVersion('0.4.1')
    assert version.version == (0, 4, 1)
    assert version.prerelease is None

    version = StrictVersion('0.4a3')
    assert version.version == (0, 4, 0)
    assert version.prerelease == ('a', 3)

    version = StrictVersion('0.4b1')
    assert version.version == (0, 4, 0)
    assert version.prerelease == ('b', 1)

    version = StrictVersion('0.4.0')
    assert version.version == (0, 4, 0)
    assert version.prerelease is None


# Generated at 2022-06-11 01:51:05.240279
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.0")
    assert(str(v) == "1.0")

    v = StrictVersion("1.0.0")
    assert(str(v) == "1.0.0")

    v = StrictVersion("1.0a1")
    assert(str(v) == "1.0a1")

    v = StrictVersion("1.0.0b1")
    assert(str(v) == "1.0.0b1")


# Generated at 2022-06-11 01:51:10.060305
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = distutils.version.Version
    assert version.__le__(version("a==1"), version("a==1"))
    # Exercise the __le__ method of class Version
    assert version.__le__(version("a==1"), version("a==1"))

# Generated at 2022-06-11 01:51:20.253428
# Unit test for method __le__ of class Version
def test_Version___le__():
    # VERSION_PAT = '(\\d+.)*\\d+'
    VERSION_PAT = r'(\d+.)*\d+'
    # VERSION_RE = re.compile(VERSION_PAT, RE_FLAGS)
    VERSION_RE = re.compile(VERSION_PAT, 36)

    def parse(self, vstring):
        match = self.version_re.match(vstring)
        if not match:
            raise ValueError("invalid version number '%s'" % vstring)
        self.parse_version(vstring, match)

    def parse_version(self, vstring, match):
        self.vstring = vstring

    def _cmp(self, other):
        if isinstance(other, str):
            other = self.__class__(other)


# Generated at 2022-06-11 01:51:31.952519
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('0.0') < Version('0.1')
    assert Version('0.0') < Version('0.01')
    assert Version('0.001') < Version('0.1')
    assert Version('0.1') < Version('0.01')
    assert Version('0.1') < Version('0.001')
    assert Version('0') < Version('1')
    assert Version('0.1') < Version('1')
    assert Version('0.1') < Version('1.0')
    assert Version('1.1') < Version('2.1')
    assert Version('1.1') < Version('2.01')
    assert Version('1.1') < Version('2.001')
    assert Version('1.10') < Version('2.1')

# Generated at 2022-06-11 01:51:33.692942
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Tested to ensure proper exception thrown in each case
    v = Version("1.2")
    assert(v >= "1.0")


# Generated at 2022-06-11 01:51:36.241873
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.1.1')
    s = str(v)
    assert s == '1.1.1'


# Generated at 2022-06-11 01:51:39.344721
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2 a3').__str__() == '1.2a3'
    assert StrictVersion('1.2').__str__() == '1.2'

# Generated at 2022-06-11 01:51:40.757460
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__(0)



# Generated at 2022-06-11 01:51:42.060376
# Unit test for method __le__ of class Version
def test_Version___le__():
    pass



# Generated at 2022-06-11 01:52:02.857795
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  import unittest
  class Version___ge__(unittest.TestCase):
    def test_01(self):
      v1 = Version('1.2')
      v2 = Version('1.2')
      self.assertTrue(v1.__ge__(v2))
      self.assertTrue(v1.__ge__('1.2'))
      self.assertTrue(v1.__ge__(Version('1.2')))
    def test_02(self):
      v1 = Version('1.2')
      v2 = Version('1.3')
      self.assertFalse(v1.__ge__(v2))
      self.assertFalse(v1.__ge__('1.3'))
      self.assertFalse(v1.__ge__(Version('1.3')))

# Generated at 2022-06-11 01:52:05.625683
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2

# Generated at 2022-06-11 01:52:13.429605
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Test for method Version.__gt__ (defined in class Version)

    v1 = Version("1.2.3")
    v2 = Version("1.2.3")
    assert v1 == v2

    v1 = Version("1.2.3")
    v2 = Version("1.2.4")
    assert v1 < v2

    v1 = Version("1.2.3")
    v2 = Version("1.2.2")
    assert v1 > v2



# Generated at 2022-06-11 01:52:23.945049
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Tests method __le__ of class Version"""
    from copy import copy
    from distutils.version import StrictVersion, LooseVersion
    for version_class in [StrictVersion, LooseVersion]:
        v1 = version_class('1.2rc2')

# Generated at 2022-06-11 01:52:28.287371
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ver = Version()
    other = Version()
    try:
        assert ver.__gt__(other) is NotImplemented
    except AssertionError:
        print("Test of method __gt__ of class Version FAILED")
        raise
    else:
        print("Test of method __gt__ of class Version PASSED")



# Generated at 2022-06-11 01:52:31.162201
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version
    v = Version('0.1')
    assert v.__eq__('0.1')
    assert v.__eq__(v)
    assert not v.__eq__('1.1')


# Generated at 2022-06-11 01:52:34.408429
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import Version


    class MyVersion(Version):
        pass


    v1 = MyVersion('1')
    v2 = MyVersion('2')

    assert (v1 >= v2) == False
    assert (v2 >= v1) == True



# Generated at 2022-06-11 01:52:43.193707
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import random
    v1 = Version()
    random.seed()
    v = Version()
    assert v1.__gt__(Version('0.0.0.0')) == True
    assert v1.__gt__(Version('0.0.0.1')) == True
    assert v1.__gt__(Version()) == True
    assert v1.__gt__(Version('0.0.0.0')) == True
    assert v1.__gt__(Version('0.0.0.1')) == True
    assert v1.__gt__(Version()) == True
# tests for Version.__gt__ generated by test_Version

# Generated at 2022-06-11 01:52:46.368729
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  obj = Version()
  param = ""
  answer = NotImplemented
  result = obj.__ge__(param)
  assert result == answer, "%r != %r" % (result, answer)


# Generated at 2022-06-11 01:52:49.193833
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version("VSXYZ")
    assert v.__eq__('VSXYZ')
    assert v.__eq__(v)



# Generated at 2022-06-11 01:53:11.013901
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test the Version.__gt__() method.

    Do not use this test as a template for testing other methods.
    It is a useless test that only checks that __gt__() is implemented.
    """
    version1 = Version('1.0')
    version2 = Version('2.0')
    version3 = Version('1')
    version4 = Version('1.0.0')
    assert version1 < version2
    assert version3 < version4



# Generated at 2022-06-11 01:53:12.941674
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.0')
    assert(v < '1.1')

# Generated at 2022-06-11 01:53:15.893422
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Get the class reference
    ref = Version

    # Create an object
    obj = ref('1.0')

    # Check if the created object is equal to another object
    assert (obj == ref('1.0')) == True

# Generated at 2022-06-11 01:53:18.264139
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= Version()
    assert v >= '0'



# Generated at 2022-06-11 01:53:20.133268
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('2.0').__gt__(Version('1.1')) == True

# Generated at 2022-06-11 01:53:22.896272
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.1') >= Version('1.1')
    assert not (Version('1.1') >= Version('1.2'))

# Generated at 2022-06-11 01:53:24.728617
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    x = Version('10')
    y = Version('11')
    assert x >= y == False



# Generated at 2022-06-11 01:53:26.930508
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    s = Version()
    assert s.__ge__(s) == True


# Generated at 2022-06-11 01:53:29.174632
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    version2 = Version()
    assert version >= version2


    # Unit test for method __gt__ of class Version

# Generated at 2022-06-11 01:53:32.700229
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        ans = Version() == Version()
    except:
        ans = None
    assert ans == NotImplemented
try:
    del test_Version___eq__
except:
    pass

# Generated at 2022-06-11 01:54:03.671865
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  x = Version()
  x.parse('1.2.3')

# Generated at 2022-06-11 01:54:09.254829
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test method __gt__ of class Version"""

    # The following code will be executed, but the test will fail because it is
    # not the right version.  Change the version number to the right version,
    # and the test will pass.
    v1 = Version("0.7")
    v2 = Version("0.8")
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1


# Generated at 2022-06-11 01:54:19.931710
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("1.0.0")
    v2 = Version("1.0.1")
    if v1 > v2:
        raise AssertionError("v1 > v2")
    v1 = Version("0.0.9")
    v2 = Version("0.1.0")
    if v1 > v2:
        raise AssertionError("v1 > v2")
    v1 = Version("0.1.0")
    v2 = Version("0.1.0")
    if v1 > v2:
        raise AssertionError("v1 > v2")
    v1 = Version("1.0.0")
    v2 = Version("1.1.0")
    if v1 > v2:
        raise AssertionError("v1 > v2")
    # Test

# Generated at 2022-06-11 01:54:30.710348
# Unit test for method __eq__ of class Version
def test_Version___eq__():
	assert (Version("1.0") == "1.0") == True
	assert (Version("1.0") == "1.0.0") == True
	assert (Version("1.0.0") == Version("1.0")) == True
	assert (Version("2.1") == Version("2.1a")) == False
	assert (Version("2.1") == Version("2.1a1")) == False
	assert (Version("2.1.dev") == Version("2.1.dev1")) == True
	assert (Version("2.1.dev") == Version("2.1.dev+0")) == True
	assert (Version("2.1.dev") == Version("2.1.dev+2")) == False
	assert (Version("2.1") == Version("2.1.dev1")) == True

# Unit

# Generated at 2022-06-11 01:54:32.397780
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert (Version("1.2.3") > Version("1.2.2"))

# Generated at 2022-06-11 01:54:36.049706
# Unit test for method __eq__ of class Version
def test_Version___eq__():
#input
    version = "M"
    other = "M"
#expected output
    eq = True
#computation/actual output
    v = Version(version)
    eq = (v == other)
    eq

# Generated at 2022-06-11 01:54:40.810122
# Unit test for method __le__ of class Version
def test_Version___le__():
  version = Version('3.3.3')
  version.parse('3.3.3')
  version._cmp('3.3.3')
  version.__le__('1.1.1')
  version.__le__('3.3.3')


# Generated at 2022-06-11 01:54:51.414890
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from copy import copy, deepcopy
    from distutils.compat import StringIO
    from sys import version_info
    from xml.sax import saxutils
    from ansible.module_utils import basic
    from ansible.module_utils.six import PY3

    # __eq__ is a method
    assert callable(getattr(Version, "__eq__", None))
    # __eq__ is implemented by Version
    assert getattr(Version, "__eq__", None) is not getattr(object, "__eq__", None)
    # __eq__ takes 1 positional argument
    assert Version.__eq__.__code__.co_argcount == 2
    # __eq__ has a non-empty __doc__
    assert Version.__eq__.__doc__
    # __eq__ has no annotations

# Generated at 2022-06-11 01:54:53.263848
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert (v == v) == True, 'Method __eq__ of class Version failed.'

# Generated at 2022-06-11 01:54:59.742500
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # pylint: disable=protected-access
    v1 = Version('1.2')
    assert v1._cmp(v1) == 0
    assert v1 == v1
    v2 = Version('1.3')
    assert v1._cmp(v2) != 0
    assert v1 != v2
    assert v2._cmp(v1) != 0
    assert v2 != v1


# Generated at 2022-06-11 01:55:55.314112
# Unit test for method __le__ of class Version
def test_Version___le__():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 01:56:01.287520
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert(Version("2.2").__le__("2.2") == True)
    assert(Version("2.2").__le__("2.3") == True)
    assert(Version("2.3").__le__("2.3") == True)
    assert(Version("2.3").__le__("2.2") == False)



# Generated at 2022-06-11 01:56:09.221944
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Testing method __le__ of class Version:
    # Case 1: result = not (left > right)
    try:
        if True:
            raise RuntimeError('This should never happen')
    except RuntimeError as e:
        last_exception = e
    if True:
        last_exception = None
    # Case 2: result = (left < right) or (left == right)
    try:
        if True:
            raise RuntimeError('This should never happen')
    except RuntimeError as e:
        last_exception = e
    if True:
        last_exception = None
    # Case 3: result = not (left > right)
    try:
        if True:
            raise RuntimeError('This should never happen')
    except RuntimeError as e:
        last_exception = e

# Generated at 2022-06-11 01:56:10.324148
# Unit test for method __ge__ of class Version
def test_Version___ge__(): return True # This test is correct


# Generated at 2022-06-11 01:56:14.804334
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version("1.1.1")
    assert v.__le__("2.0") == True
    assert v.__le__("1.1.1") == True
    assert v.__le__("1.1") == False
test_Version___le__()



# Generated at 2022-06-11 01:56:15.793582
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass


# Generated at 2022-06-11 01:56:20.770944
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()

    for other in [None, True, False, "1", Version(), LooseVersion(), StrictVersion()]:
        try:
            cmp = v._cmp(other)

            if cmp is NotImplemented:
                eval(repr(cmp))
            else:
                eval(repr(cmp <= 0))
        except:
            eval(repr(cmp))

# Generated at 2022-06-11 01:56:23.665620
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert (Version('1.00') <= '1.01') == True
    assert (Version('1.10') <= '1.10') == True
    assert (Version('2.00') <= '1.99') == False


# Generated at 2022-06-11 01:56:27.476912
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest2

    class Version_TestCase(unittest2.TestCase):
        def test_TypeError(self):
            self.assertRaises(TypeError, Version().__eq__, None)

    unittest2.main()


# Generated at 2022-06-11 01:56:38.286784
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test method __ge__ of class Version"""
    
    # Setup
    v = Version()
    
    # Testing
    # assert False # TODO: implement your test here
    try:
        v.__ge__(None)
        assert False # shouldn't get here
    except TypeError:
        pass
    try:
        v.__ge__(3)
        assert False # shouldn't get here
    except TypeError:
        pass
    try:
        v.__ge__('3')
        assert False # shouldn't get here
    except TypeError:
        pass
    try:
        v.__ge__('')
        assert False # shouldn't get here
    except TypeError:
        pass
    
    return # __ge__


# Generated at 2022-06-11 01:58:46.350284
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('3.10a')
    v2 = Version('3.10')
    assert v1 == v2



# Generated at 2022-06-11 01:58:49.461255
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version(vstring='1.0')
    assert v > '1.0'


# Generated at 2022-06-11 01:58:52.002601
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  obj = Version()
  obj.parse("v2.3.0")
  obj2 = Version()
  obj2.parse("v2.3.1")
  assert obj < obj2


# Generated at 2022-06-11 01:58:55.616555
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version(vstring='1.0')
    v2 = Version(vstring='1.0')

    vv = v1 == v2
    assert vv is True


# Generated at 2022-06-11 01:59:01.425895
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Check some normal cases:
    v = LooseVersion("1.2")
    if v.version != [1, 2]:
        raise ValueError("Wanted [1, 2], got {0}".format(v.version))
    v = LooseVersion("1.2.3")
    if v.version != [1, 2, 3]:
        raise ValueError("Wanted [1, 2, 3], got {0}".format(v.version))
    v = LooseVersion("1.1.2-c")
    if v.version != [1, 1, 2, 'c']:
        raise ValueError("Wanted [1, 1, 2, 'c'], got {0}".format(v.version))

    # Check some strange cases:
    v = LooseVersion("a.b.c")

# Generated at 2022-06-11 01:59:02.651501
# Unit test for method __le__ of class Version
def test_Version___le__(): assert Version() <= Version()

# Generated at 2022-06-11 01:59:13.234746
# Unit test for method __lt__ of class Version
def test_Version___lt__():
##    """Test Version.__lt__"""
##
##    import copy
##    from distutils.version import Version
##
##    # Some tests to detect regressions in rich comparisons.
    assert not(Version("1.0") < Version("1.0"))
    assert not(Version("1.0") > Version("1.0"))

    assert Version("0.9") < Version("1.0")
    assert Version("1.0") > Version("0.9")

    assert Version("1.0a1") < Version("1.0")
    assert Version("1.0") > Version("1.0a1")

    assert Version("1.0a1") < Version("1.0p0")
    assert Version("1.0p0") > Version("1.0a1")


# Generated at 2022-06-11 01:59:17.587420
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion("0.960923")
    assert lv.version == [0, 960923]

    lv = LooseVersion("0.960923.1")
    assert lv.version == [0, 960923, 1]

    lv = LooseVersion("0.960923.1.1")
    assert lv.version == [0, 960923, 1, 1]


# Generated at 2022-06-11 01:59:20.000461
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """test_Version___ge__"""
    a = Version('0.01')
    b = Version('0.1')
    c = a.__ge__(b)

# Generated at 2022-06-11 01:59:21.742325
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.2.3') > '1.2.2'