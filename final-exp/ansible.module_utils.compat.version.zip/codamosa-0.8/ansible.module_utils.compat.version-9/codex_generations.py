

# Generated at 2022-06-11 01:50:53.467064
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import sys
    assert sys.version_info[:2] == (3, 5)
    import random
    n = random.randint(1, 10)
    assert n > 0
    assert n > 1
    assert n > 2
    assert n > 3
    assert n > 4
    assert n > 5
    assert n > 6
    assert n > 7
    assert n > 8
    assert n > 9
    assert n > 10
    assert n > 11
    assert n > 12
    assert n > 13
    assert n > 14
    assert n > 15
    assert n > 16
    assert n > 17
    assert n > 18

# Generated at 2022-06-11 01:50:57.434005
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ver0 = Version('0')
    ver1 = Version('1')
    assert ver0.__lt__(ver1)
    assert not ver1.__lt__(ver0)
    assert ver0 != ver1

# Generated at 2022-06-11 01:50:59.629562
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import doctest
    doctest.run_docstring_examples(Version.__lt__, globals())



# Generated at 2022-06-11 01:51:07.202769
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    global version
    version = Version()
    try:
        global arg
        arg = 0
        return version.__ge__(arg)
    except:
        return 0


    try:
        global arg
        arg = NotImplemented
        return version.__ge__(arg)
    except:
        return 0


    try:
        global arg
        arg = 0
        return version.__ge__(arg)
    except:
        return 0


    try:
        global arg
        arg = NotImplemented
        return version.__ge__(arg)
    except:
        return 0


    try:
        global arg
        arg = 0
        return version.__ge__(arg)
    except:
        return 0



# Generated at 2022-06-11 01:51:09.685132
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert (Version('1.0') > Version('0.9')) == True



# Generated at 2022-06-11 01:51:13.985639
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert not v == '1.2.4'
    assert not v == Version('1.2.4')

# Generated at 2022-06-11 01:51:22.169555
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    from distutils.tests import support
    with support.transient_dir() as t:
        import os
        os.chdir(t)
        with open('setup.py', 'w') as f:
            f.write('''from distutils.version import StrictVersion
from distutils.tests import support
import sys
v = sys.argv[1]
try:
    StrictVersion(v).parse(v)
except Exception as e:
    support.fail(e)
else:
    support.run_unittest(lambda: None)
''')
        support.run_setup('setup.py', ['--test-suite', 'test'])

# Generated at 2022-06-11 01:51:24.730174
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.4.5.6")
    assert(str(v)=="1.4.5.6")


# Generated at 2022-06-11 01:51:35.098847
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import pytest
    from distutils2._backport.distutils.version import Version, _compare

    class TestVersion(Version):
        def parse(self, vstring):
            self.ver = vstring
        def _cmp(self, other):
            if isinstance(other, str):
                a, b = self.ver, other
            else:
                a, b = self.ver, other.ver
            return _compare(a, b)

    v1 = TestVersion('1.0')
    v2 = TestVersion('2.0')
    v3 = TestVersion('2.0.1')
    v1_1 = TestVersion('1.1')
    v0_9 = TestVersion('0.9')

    assert not v1 < v1
    assert not v1 < v0_9
    assert v

# Generated at 2022-06-11 01:51:45.708717
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import sys, os
    import unittest
    import lib2to3.main  # ImportError: No module named lib2to3.main

    class StrictVersionTestCase(unittest.TestCase):
        def test_StrictVersion___str__(self):
            # Input params
            input_params = { "vstring" : "0.4" }
            # Output params
            output_params = {}
            # Function to call
            the_function = StrictVersion(**input_params)
            # Expected result
            expected_result = "0.4"
            # Actual result
            actual_result = str(the_function)
            self.assertEqual(expected_result, actual_result)
            print("test_StrictVersion___str__ - OK")

    test_case_class_instance = StrictVersionTest

# Generated at 2022-06-11 01:51:53.401991
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def __eq__(self, other):
        c = self._cmp(other)
        if c is NotImplemented:
            return c
        return c == 0

# Generated at 2022-06-11 01:51:56.903210
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Initialize instance
    a = Version('1.0')
    # Evaluate expression
    b = a <= a
    # Check result
    if not b:
        raise AssertionError



# Generated at 2022-06-11 01:51:58.977401
# Unit test for method __le__ of class Version
def test_Version___le__():
    import doctest

    doctest.testmod()


# Generated at 2022-06-11 01:52:00.375326
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    v.__ge__()


# Generated at 2022-06-11 01:52:11.908836
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def _test_parse(input, expected):
        s = StrictVersion(input)
        if s.version != expected.version or s.prerelease != expected.prerelease:
            raise ValueError('Got %s, expected %s' % (s, expected))
    # Note: the test_CommonTests.test_parse method tests that the
    # strings are correctly parsed to the version, so here just test
    # that specifying the version directly works
    _test_parse('1', StrictVersion('1'))
    _test_parse('1.2', StrictVersion('1.2'))
    _test_parse('1.2.3', StrictVersion('1.2.3'))
    _test_parse('1.2.3a1', StrictVersion('1.2.3a1'))
    _test_parse

# Generated at 2022-06-11 01:52:13.089008
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import doctest
    doctest.testmod()


# Generated at 2022-06-11 01:52:14.256609
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    raise NotImplementedError



# Generated at 2022-06-11 01:52:18.377437
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion( "1.2b3" )
    assert str( v ) == "1.2b3"
    v = StrictVersion( "1.2.3c4" )
    assert str( v ) == "1.2.3c4"

# Generated at 2022-06-11 01:52:22.714572
# Unit test for method __le__ of class Version
def test_Version___le__():
    # pylint: disable=protected-access
    # Setup
    v1 = Version('1.0')
    v2 = Version('2.0')
    # Exercise
    r1 = v1._cmp(v2)
    # Verify
    assert isinstance(r1, int)



# Generated at 2022-06-11 01:52:25.407440
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Version.__le__, line 50
    # TODO
    raise NotImplementedError('')



# Generated at 2022-06-11 01:52:38.861747
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from nose.tools import assert_equal, assert_raises
    from distutils.version import Version

    v = Version('1.0')
    assert_equal(v < '1.0', False)

    assert_raises(TypeError, v.__lt__, None)
    assert_raises(TypeError, v.__lt__, ())
    assert_raises(TypeError, v.__lt__, [])
    assert_raises(TypeError, v.__lt__, {})

    assert_raises(TypeError, v.__lt__, 1)
    assert_raises(TypeError, v.__lt__, 1.0)



# Generated at 2022-06-11 01:52:41.252712
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) is NotImplemented


# Generated at 2022-06-11 01:52:47.818935
# Unit test for method __le__ of class Version

# Generated at 2022-06-11 01:52:56.389788
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    from io import StringIO
    from copy import copy

    # Set up some test data
    v1 = [Version('1.2'), Version('1.1'), Version('1.1.1')]
    v2 = [Version('1.2.3'), Version('1.2'), Version('1.2.1')]

    # Run the method to be tested
    v3 = sorted(v1 + v2)

    # Check the resulting object

# Generated at 2022-06-11 01:53:07.115163
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented
    assert v.__ge__(1) is NotImplemented
    assert v.__ge__(Version()) is True
    assert v.__ge__(StrictVersion()) is True
    assert v.__ge__(LooseVersion()) is True

    v2 = Version()
    v2.parse('1.0')
    assert v.__ge__(v2) is False
    assert v2.__ge__(v) is True

    assert v2.__ge__(LooseVersion('1.0')) is True
    assert v2.__ge__(StrictVersion('1.0')) is True
    assert v2.__ge__(StrictVersion('1.1')) is False

# Generated at 2022-06-11 01:53:16.789637
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
  def check(value, prerelease, version):
    strict_version = StrictVersion(value)
    return strict_version.version == version and strict_version.prerelease == prerelease


# Generated at 2022-06-11 01:53:28.118884
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version("1.0")
    v2 = Version("1.0")
    # Test if v1 == v2 returns true
    eq_(v1 == v2, True)

    # Test if v1 == v2 returns True if v1 and v2 are of different types
    v1 = Version("1.0")
    v2 = StrictVersion("1.0")
    eq_(v1 == v2, True)

    # Test if v1 == v2 returns False if v1 and v2 are of different types
    v1 = Version("1.0")
    v2 = StrictVersion("1.0.1")
    eq_(v1 == v2, False)

    # Test if v1 == v2 returns true if v1 and v2 are of different types and
    # v1 < v2

# Generated at 2022-06-11 01:53:38.679748
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # This test will fail when your code returns NotImplemented
    # assert value == 0
    assert Version() >= Version()
    # assert value == 0
    assert Version(0) >= Version(0)
    # assert value == 0
    assert Version(0) >= Version(0.0)
    # assert value == 1
    assert Version(1) >= Version(0)
    # assert value == 1
    assert Version(0) >= Version(-1)
    # assert value == 0
    assert Version(-1) >= Version(-1)
    # assert value == 1
    assert Version(1, 0) >= Version(0)
    # assert value == 1
    assert Version(1, 0, 2) >= Version(0)
    # assert value == 1
    assert Version(0, 1) >= Version(0)
    # assert value == 1


# Generated at 2022-06-11 01:53:48.187301
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') <= Version('1.0')
    assert Version('1.1') >= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.1') >= Version('1.1-alpha')
    assert Version('1.1-alpha') <= Version('1.1')
    assert Version('1.2') >= Version('1.1')
    assert Version('1.1') <= Version('1.2')
    assert Version('1.1-alpha') >= Version('1.1-alpha')
    assert Version('1.1-alpha') <= Version('1.1-alpha')
    assert Version('1.1-alpha1') >= Version('1.1-alpha')

# Generated at 2022-06-11 01:53:51.256949
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.0')
    assert v <= '1.0'
    assert v <= Version('1.0')
    assert not (v <= Version('0.1'))
    assert not (v <= '0.1')


# Generated at 2022-06-11 01:54:23.182189
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version() >= Version()

# Generated at 2022-06-11 01:54:24.444301
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    out = v.__ge__("2")
    assert out is False


# Generated at 2022-06-11 01:54:26.830275
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) is True
    assert v.__ge__(None) is NotImplemented

# Generated at 2022-06-11 01:54:32.621195
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Test method Version.__lt__."""

    assert StrictVersion("0.3") < StrictVersion("0.4"), \
        "Version comparison failed"
    assert StrictVersion("1.2") < StrictVersion("2.2"), \
        "Version comparison failed"
    assert StrictVersion("0.4") < StrictVersion("1.4"), \
        "Version comparison failed"
    assert StrictVersion("1.3") < StrictVersion("2.2"), \
        "Version comparison failed"
    assert StrictVersion("1.4") < StrictVersion("2.4"), \
        "Version comparison failed"
    assert StrictVersion("1.4") < StrictVersion("1.5"), \
        "Version comparison failed"

# Generated at 2022-06-11 01:54:35.125451
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2

# Generated at 2022-06-11 01:54:37.883157
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert(v == '1.2.3')
    assert(not (v == '2.2.3'))


# Generated at 2022-06-11 01:54:45.680793
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    # version.py:11: error: Class 'Version' has no '__lt__' member
    # version.py:13: error: Class 'Version' has no '__gt__' member
    # version.py:15: error: Class 'Version' has no '__le__' member
    # version.py:17: error: Class 'Version' has no '__ge__' member
    # version.py:19: error: Class 'Version' has no '__eq__' member
    v = Version()
    v > 1
    v < 1
    v >= 1
    v <= 1
    v == 1

# Generated at 2022-06-11 01:54:55.554563
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    assert '0.2' == str(LooseVersion('0.2'))
    assert '0.2' == str(LooseVersion('0.2.0'))
    assert '0.2' != str(LooseVersion('0.2.0+test'))
    assert '0.2.0+test+test' == str(LooseVersion('0.2.0+test+test'))
    assert '0.2.0+test-test' == str(LooseVersion('0.2.0+test-test'))
    assert '0.2.0+test' == str(LooseVersion('0.2.0+test'))
    assert '0.2.0+test' == str(LooseVersion('0.2.0+test'))

# Generated at 2022-06-11 01:55:06.590510
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    LooseVersion.parse('1')
    LooseVersion.parse('1.2')
    LooseVersion.parse('1.2.3')
    LooseVersion.parse('1.2.3.4')
    LooseVersion.parse('a.b.c.d')
    LooseVersion.parse('1.2a3')
    LooseVersion.parse('1.2b3')
    LooseVersion.parse('1.2c3')
    LooseVersion.parse('1.2.3a')
    LooseVersion.parse('1.2.3b')
    LooseVersion.parse('1.2.3c')
    LooseVersion.parse('1.2.3.4a')
    LooseVersion.parse('1.2.3.4b')

# Generated at 2022-06-11 01:55:10.723838
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    for ExpectedResult, v1, v2 in [
        (False, Version(), Version()),
        (False, "1", Version()),
        (False, Version(), "1"),
        (True, "1", "0"),
    ]:
        assert (v1 > v2) == ExpectedResult


# Generated at 2022-06-11 01:55:52.702618
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Ensure that __ge__ behaves as expected"""
    from distutils2.compat import unittest
    from distutils2.version import Version
    from distutils2.version import StringType
    class TestVersion(Version):
        def parse(self, vstring):
            # this is an incomplete implementation
            # the point is to test the comparisons
            self.vstring = vstring
        def __str__(self):
            return self.vstring
        def __repr__(self):
            return "TestVersion ('%s')" % self.vstring

        def _cmp(self, other):
            if isinstance(other, StringType):
                other = TestVersion(other)
            return cmp(self.vstring, other.vstring)


# Generated at 2022-06-11 01:55:59.306835
# Unit test for method __eq__ of class Version
def test_Version___eq__(): 
  t1 = (["Version()",
  "Version ('0')"],0,0)
  t2 = (["",
  ""],0,0)
  t3 = ([""],0,0)
  t4 = (["",
  ""],0,0)
  t5 = ([""],0,0)
  return (t1, t2, t3, t4, t5)

# Generated at 2022-06-11 01:56:01.493929
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("1.0")
    v2 = Version("2.0")
    assert v1 <= v2


# Generated at 2022-06-11 01:56:06.208234
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.9')
    assert str(v) == '1.9'
    v = StrictVersion('1.9.a1')
    assert str(v) == '1.9.a1'
    v = StrictVersion('1.10.0')
    assert str(v) == '1.10'


# Generated at 2022-06-11 01:56:08.373732
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    object = Version('2.0')
    try:
        assert(object >= 1)
    except:
        return 0
    return 1


# Generated at 2022-06-11 01:56:09.291597
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert True

# Generated at 2022-06-11 01:56:11.505941
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Create instance
    version1 = Version()
    # Create instance
    version2 = Version()
    assert version1 == version2

# Generated at 2022-06-11 01:56:21.306314
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert (Version('1') < Version('2'))
    assert (Version('1.2') < Version('2.1'))
    assert (not (Version('1.2') < Version('1.2')))

    assert (Version('1.2') < Version('1.2.1'))
    assert (Version('1.2') < Version('1.2.0'))
    assert (Version('1.2.0') < Version('1.2.1'))
    assert (Version('1.2.0') < Version('1.2.0.1'))
    assert (Version('1.2.0.1') < Version('1.2.0.2'))

    assert (Version('1.2.0') < Version('1.2.10'))

# Generated at 2022-06-11 01:56:30.779212
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v_a = Version("a")
    v_b = Version("b")

    assert v_a < v_b
    assert not (v_a > v_b)
    assert v_b > v_a
    assert not (v_b < v_a)
    assert not (v_a == v_b)
    assert v_a <= v_b
    assert v_b >= v_a
    assert not (v_a >= v_b)
    assert not (v_b <= v_a)
    assert not (v_a != v_b)

    assert not (v_a < v_a)
    assert v_a <= v_a
    assert v_a == v_a
    assert v_a >= v_a
    assert not (v_a > v_a)

# Generated at 2022-06-11 01:56:34.784907
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert   Version('1.0') >= Version('1.0')
    assert  not Version('1.0') >= Version('1.1')
    assert   Version('1.1') >= Version('1.0')



# Generated at 2022-06-11 01:57:09.843849
# Unit test for method __le__ of class Version
def test_Version___le__():
    ver = Version()
    assert ver.__le__(' ') == NotImplemented


# Generated at 2022-06-11 01:57:10.672444
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__(Version())

# Generated at 2022-06-11 01:57:16.734643
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    class Version(Version):
        def parse(self, vstring):
            self.vstring = vstring
        def _cmp(self, other):
            return 0
    v1 = Version()
    v2 = Version()
    assert (v1 == v2)
    assert (not (v1 != v2))
    assert (not (v1 == 42))
    assert (v1 != 42)


# Generated at 2022-06-11 01:57:19.422733
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.0")
    v2 = Version("2.0")
    assert v1 < v2



# Generated at 2022-06-11 01:57:24.295461
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    class MyVersion(Version):
        def _cmp(self, other):
            return 0
    v1 = MyVersion()
    v2 = MyVersion()
    assert (v1 >= v2)
    assert not (v1 < v2)
    assert (v1 == v2)
    assert not (v1 > v2)


# Generated at 2022-06-11 01:57:25.624243
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(0) == NotImplemented


# Generated at 2022-06-11 01:57:27.960409
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Unit test for method __lt__ of class Version

        Verifies that the method __lt__ of class Version
        implements the correct comparison logic.
        """
    pass

# Generated at 2022-06-11 01:57:32.014749
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    tarball_version = StrictVersion('2.4.0')
    assert str(tarball_version) == '2.4.0'
    tarball_version = StrictVersion('2.4.0a1')
    assert str(tarball_version) == '2.4.0a1'


# Generated at 2022-06-11 01:57:33.466005
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    method = Version.__gt__
    v1 = Version()
    v2 = Version()
    assert method(v1, v2)



# Generated at 2022-06-11 01:57:34.700376
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    inst = Version()
    assert inst.__gt__(Version())

# Generated at 2022-06-11 01:58:57.728532
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    vObj = Version()
    ret_val = vObj.__eq__('1')
    assert type(ret_val) == str



# Generated at 2022-06-11 01:58:59.933219
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1.__eq__(v2)


# Generated at 2022-06-11 01:59:04.426722
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # create test data
    version1 = Version(vstring='1.0')
    version2 = Version(vstring='2.0')

    # call method to be tested
    result = version1.__gt__(version2)

    expected = False

    # compare actual result with expected result
    assert result == expected

# Generated at 2022-06-11 01:59:14.743975
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import pytest

    pytest.skip("Bare Version is never instantiated, so this test is for nothing.")

    # Test an explicit comparison of Version subclasses
    assert StrictVersion("1.2.3") < StrictVersion("1.3.3")

    # Test an implicit comparison of Version subclasses
    assert StrictVersion("1.2.3") < "1.3.3"

    # Test a comparison between a subclass and a superclass
    with pytest.raises(TypeError):
        "1.2.3" < Version("1.2.3")

    # Test a comparison between different Version subclasses
    with pytest.raises(TypeError):
        StrictVersion("1.2.3") < LooseVersion("1.2.3")

# Generated at 2022-06-11 01:59:16.146174
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) == NotImplemented

# Generated at 2022-06-11 01:59:21.405160
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('0.1')
    v2 = Version('1.1')
    v3 = Version(v2)
    assert v1.__gt__(v2) == False
    assert v2.__gt__(v3) == False
    assert v3.__gt__(v1) == True


# Generated at 2022-06-11 01:59:28.059021
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    import sys
    if sys.version_info[0]>=3:
        import io
        StringIO = io.StringIO
    else:
        import StringIO
    class TestVersion(unittest.TestCase):
        def test_Version___gt__(self):
            out=StringIO()
            sys.stdout=out
            v = Version('3')
            v2 = Version('2')
            self.assertTrue(v > v2)

# Generated at 2022-06-11 01:59:29.716358
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    assert v1 < "2.0"


# Generated at 2022-06-11 01:59:33.520911
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Create an instance of the Version class
    v = Version()
    # Create an instance of the Version class
    other = Version()
    # Call the method
    r = v.__ge__(other)
    assert False # TODO implement your test here


# Generated at 2022-06-11 01:59:40.284239
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    print('Testing __ge__ of class Version')
    v_a = LooseVersion('1.2.4')
    v_b = LooseVersion('1.2.3')
    if not (v_a >= v_b):
        raise Exception('__ge__ of class Version failed on LooseVersion objects')
    v_a = LooseVersion('1.2.4')
    v_b = LooseVersion('1.2.4')
    if not (v_a >= v_b):
        raise Exception('__ge__ of class Version failed on LooseVersion objects')
    v_a = LooseVersion('1.2.4')
    v_b = '1.2.4'
    if not (v_a >= v_b):
        raise Exception('__ge__ of class Version failed on LooseVersion and string objects')