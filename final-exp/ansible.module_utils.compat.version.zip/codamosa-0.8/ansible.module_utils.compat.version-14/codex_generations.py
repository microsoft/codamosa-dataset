

# Generated at 2022-06-11 01:50:48.339575
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    v.parse = lambda x: (1, 1)
    assert v == "1.1"
    assert "1.1" == v

# Generated at 2022-06-11 01:50:50.875760
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('0.1')
    v2 = Version('0.2')
    assert v1 < v2


# Generated at 2022-06-11 01:50:56.464129
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # !+: test needs to be rewritten

    # version instance
    v_instance = StrictVersion('3.10.2a1')
    try:
        assert v_instance.__str__() == '3.10.2a1'
    except AssertionError:
        assert v_instance.__str__() == '3.10.2a1'


# Generated at 2022-06-11 01:51:07.599387
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-11 01:51:12.480512
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    for versionString in ['4.4.4',
                          '4.4',
                          '4.4.4b44',
                          '4.4b44']:
        version = StrictVersion(versionString)
        assert str(version) == versionString

# Generated at 2022-06-11 01:51:14.719014
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    cases = (
        "0.4.0",
        "1.0.4a3",
        "1.0.4",
    )

    for case in cases:
        StrictVersion(case)


# Generated at 2022-06-11 01:51:16.534090
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('2.2.0')
    assert v >= '2.1.4'

# Generated at 2022-06-11 01:51:21.354769
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """
    Class Version with method __ge__
    """
    v1 = Version('1.2')
    v2 = Version('1.2')
    assert(v1 >= v2)
    v1 = Version('1.3')
    v2 = Version('1.2')
    assert(v1 >= v2)
    v1 = Version('1.2')
    v2 = Version('1.2.2')
    assert(not v1 >= v2)



# Generated at 2022-06-11 01:51:24.341330
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1.__lt__(v2) == NotImplemented, 'NotImplemented'



# Generated at 2022-06-11 01:51:34.921395
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """Unit test for method __str__ of class StrictVersion"""
    global StrictVersion

# Generated at 2022-06-11 01:51:52.232833
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert (v == '0') == True

# Generated at 2022-06-11 01:51:53.750288
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version('1')
    assert Version('1') < Version('2')

# Generated at 2022-06-11 01:51:57.350994
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import LooseVersion, _LooseVersion
    print('returning true')
    assert LooseVersion('1.4') >= _LooseVersion('1.4')


# Generated at 2022-06-11 01:52:00.524702
# Unit test for method __le__ of class Version
def test_Version___le__():
    for i in range(10000):
        v = Version()
        v.a = i
        assert (v <= i) == (i <= v)

# Generated at 2022-06-11 01:52:01.535028
# Unit test for method __ge__ of class Version
def test_Version___ge__(): assert Version().__ge__(Version()) # Cannot test this method - no examples of use in Python

# Generated at 2022-06-11 01:52:10.645804
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """
    I noticed that a >= b and b <= a both fail when a and b are Version instances
    if a.__gt__(b) is false (i.e. if a and b are equal). This is because the __gt__,
    __lt__, __eq__, etc. methods will have NotImplemented be returned by the _cmp method
    if the types of a and b are not identical. This should not happen as far as I can see.
    """
    a = Version()
    b = Version()
    assert a >= b
    assert b <= a

# Generated at 2022-06-11 01:52:18.034617
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    class Dummy(Version):
        def __init__(self, vstring=None):
            Version.__init__(self, vstring)
            self._cmp = lambda other: 0

    version = Dummy()
    assert version.__ge__(1) == True
    assert version.__ge__(None) == NotImplemented


    class Dummy(Version):
        def __init__(self, vstring=None):
            Version.__init__(self, vstring)
            self._cmp = lambda other: 1

    version = Dummy()
    assert version.__ge__(1) == True
    assert version.__ge__(None) == NotImplemented


    class Dummy(Version):
        def __init__(self, vstring=None):
            Version.__init__(self, vstring)


# Generated at 2022-06-11 01:52:19.626595
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.0') > Version('0.1')


# Generated at 2022-06-11 01:52:21.929509
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    version._cmp = None
    assert version.__ge__(None) == NotImplemented


# Generated at 2022-06-11 01:52:24.522436
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    w = Version('1.2.3')
    assert v == w

# Generated at 2022-06-11 01:52:34.954885
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()

    assert v1.__ge__(v2)
    assert v1.__ge__(v1)

# Generated at 2022-06-11 01:52:36.997344
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.1.1')
    v2 = Version('1.1.2')
    assert v2 >= v1


# Generated at 2022-06-11 01:52:41.082586
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version("1.2.3.a")
    v2 = Version("1.2.3.b")
    x = v1.__ge__(v2)
    expected = False
    assert x == expected
test_Version___ge__()


# Generated at 2022-06-11 01:52:47.759156
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import sys;
    x = Version();
    z = Version();
    y = Version();
    if (sys.version_info > (3, )):
        y.parse("5.5");
    else:
        y.parse(u"5.5");
    if not ((x < y) and (not (y < x))):
        return False;
    if not ((x <= y) and (y <= y) and (not (y <= x))):
        return False;
    if not ((y > x) and (not (x > y))):
        return False;
    if not ((y >= x) and (x >= x) and (not (x >= y))):
        return False;
    if not (x == z):
        return False;

# Generated at 2022-06-11 01:52:54.964187
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import mock
    import unittest

    # Mock class and object
    class Name:
        pass
    obj = Name()

    # This mock will replace the function _cmp of class Version
    def mock__cmp(self,other):
        return -1
    Version._cmp = mock.MagicMock(side_effect=mock__cmp)

    # Call the function to test
    ret = Version.__gt__(obj, other=mock.MagicMock())

    # Verify the results
    assert(ret == False)

    # Verify mock call
    Version._cmp.assert_called_once()


# Generated at 2022-06-11 01:53:06.064141
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Unit tests for method __lt__ of class Version
    from distutils.version import Version
    from distutils.version import StrictVersion
    from distutils.version import LooseVersion

    # Generate the lists of test cases
    to_test = []
    to_test_strict = []
    to_test_loose = []

# Generated at 2022-06-11 01:53:13.068499
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version("5.5.5")
    assert(v >= "5.5.5") == True
    assert(v >= "5.5") == True
    assert(v >= "5") == True
    assert(v >= "5.5.6") == False
    assert(v >= "6.1") == False
    assert(v >= 6) == False
    assert(v >= "6") == False

# Generated at 2022-06-11 01:53:17.715473
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest
    import platform

    class TestVersion(unittest.TestCase):
        def test_basic(self):
            self.assertTrue(Version('1.2.3') <= '1.2.4')

    unittest.main('distlib.tests', verbosity=2, exit=False)


# Generated at 2022-06-11 01:53:19.438280
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert (Version('0.0.0') >= Version('0.0.0'))


# Generated at 2022-06-11 01:53:26.386074
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import os
    import tempfile
    if not os.path.exists('/tmp'):
        with tempfile.TemporaryDirectory() as dir:
            os.mkdir(dir + '/tmp')
            os.environ['TMPDIR'] = dir
            os.environ['TMP'] = dir
            os.environ['TEMP'] = dir
            os.system('ansible-test sanity --test version --python 2.6')



# Generated at 2022-06-11 01:53:40.810392
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version("0.0") < Version("0.0.1")

# Generated at 2022-06-11 01:53:49.394078
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assertVersion(Version("1.0.0"), Version("0"))
    assertVersion(Version("0.0.1"), Version("0"))
    assertVersion(Version("0.0.1.dev1"), Version("0.0.1"))
    assertVersion(Version("0.0.1.post0.dev1"), Version("0.0.1.post0"))
    assertVersion(Version("0.0.1a1"), Version("0.0.1"))
    assertVersion(Version("1.0.0a1"), Version("0.0"))
    assertVersion(Version("1.0.0a1"), Version("0.0.0"))
    assertVersion(Version("1.0.0a"), Version("0.0.0"))

# Generated at 2022-06-11 01:53:52.507073
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils2.version import Version

    version = Version("1.0")
    assert version.__le__("1.0")
    assert not version.__le__("1.1")


# Generated at 2022-06-11 01:53:54.371386
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import warnings

    warnings.warn("This test is not implemented", DeprecationWarning)


# Generated at 2022-06-11 01:53:58.501264
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    class _Version(Version):
        @classmethod
        def _cmp(cls, x, y):
            return 0
    assert _Version() >= object()
    assert _Version() >= ''
    assert _Version() >= '1.2'

# Generated at 2022-06-11 01:54:00.288709
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert (Version("1.2.3") < Version("1.2.4") == False)


# Generated at 2022-06-11 01:54:07.518022
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Test that the comparison between different versions is
    # consistent with the string comparison between their
    # string representations
    import random

    class TestVersion(Version):
        def __init__(self, vstring):
            self.parse(vstring)

        def parse(self, vstring):
            self.vstring = str(vstring)

        def __str__(self):
            return self.vstring

        def _cmp(self, other):
            if isinstance(other, TestVersion):
                return cmp(self.vstring, other.vstring)

    tests = [(random.randint(1, 1000), random.randint(1, 1000))
             for i in range(100)]
    for x, y in tests:
        assert cmp(TestVersion(x), TestVersion(y)) == cmp(x, y)



# Generated at 2022-06-11 01:54:11.271966
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    v.parse = lambda x: 0
    v._cmp = lambda x: int(x > 0)
    assert v.__gt__(0) == False
    assert v.__gt__(1) == True

# Generated at 2022-06-11 01:54:14.435026
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    #assert v.__gt__(0) is False


# Generated at 2022-06-11 01:54:22.796537
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    from distutils.version import Version

    def check(v1, v2):
        assert (v1 > v2) == (Version(v1) > Version(v2))

    check('1.9.0', '1.8.0')
    check('1.10.1', '1.10.0')
    check('1.2.0', '1.1')
    check('1.1.1', '1.1')
    check('1.2a1', '1.2')
    check('1.2.r32', '1.2.1')
    check('1.2.1', '1.2.r32')
    check('1.2.1', '1.2pl3')
    check('1.2pl1', '1.2')

# Generated at 2022-06-11 01:54:39.930418
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    Version("1.2") == Version("1.2")
    Version("1.2") == "1.2"
    not (Version("1.2") == Version("1.3"))
    not (Version("1.2") == "1.3")



# Generated at 2022-06-11 01:54:45.658509
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import mooseutils
    assert(mooseutils.version.LooseVersion('3.3') < mooseutils.version.LooseVersion('3.4'))

    # The following should fail, documentation said this should not happen
    # (i.e., c is not possible to be NotImplemented)
    #  c = mooseutils.version.LooseVersion('3.3') > mooseutils.version.LooseVersion('a')
    #  assert(c is NotImplemented)


# Generated at 2022-06-11 01:54:49.461030
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version(vstring=None)
    v2 = Version(vstring=None)
    assert v1.__gt__(v2) == NotImplemented
test_Version___gt__()



# Generated at 2022-06-11 01:54:53.046133
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import Version
    v1 = Version("1.3.3a2")
    v2 = Version("1.3.3a1")
    assert (v1 >= v2)
    assert not (v1 < v2)


# Generated at 2022-06-11 01:54:55.076770
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.2') > '1.1'
    assert Version('1.2') > '1.1.1'


# Generated at 2022-06-11 01:55:00.577954
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    import functools
    v2 = functools.partial(v1._cmp, '1')
    assert v1 == v2

    import functools
    v2 = functools.partial(v1._cmp, '2')
    assert v1 != v2


# Generated at 2022-06-11 01:55:02.418064
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2



# Generated at 2022-06-11 01:55:08.082884
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    from distutils2.version import (
        Version,
    )

    v1 = Version('1')
    v2 = Version('2')
    if not v1 < v2:
      raise AssertionError

    v1 = Version('1.1')
    v2 = Version('1.2')
    if not v1 < v2:
      raise AssertionError

    v1 = Version('1.1')
    v2 = Version('1.2.3')
    if not v1 < v2:
      raise AssertionError


# Generated at 2022-06-11 01:55:09.425235
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version() >= Version()

# Generated at 2022-06-11 01:55:10.460477
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """test for method __ge__ of class Version"""
    pass


# Generated at 2022-06-11 01:55:26.390889
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Test method __eq__ of class Version"""
    version = Version()

    expected = NotImplemented
    actual = version.__eq__
    assert expected == actual


# Generated at 2022-06-11 01:55:31.633097
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.1') < '1.2'
    assert Version('1.1') < '1.1.1'
    assert not (Version('1.2') < '1.2')
    assert not (Version('1.2.1') < '1.2')
    assert not (Version('1.1.1') < '1.1')


# Generated at 2022-06-11 01:55:35.024003
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    a = Version('1.0')
    b = Version('0.9')
    assert a >= b and b < a
    # Check if the output is a boolean
    assert isinstance(b < a, bool)


# Generated at 2022-06-11 01:55:40.116071
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v_ = Version()
    v_1 = Version()
    assert (v_1 >= v_) is NotImplemented
    from ansible.module_utils.version import LooseVersion
    v_2 = LooseVersion()
    assert (v_2 >= v_1) is NotImplemented
    v_3 = LooseVersion()
    assert (v_3 >= v_1) is NotImplemented


# Generated at 2022-06-11 01:55:42.947242
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    v1.parse("1.0")
    v2.parse("1.0")
    assert (v1 == v2)



# Generated at 2022-06-11 01:55:47.729095
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    class A(Version):
        def parse(self, vstring):
            self.foo = 'bar'

        def _cmp(self, other):
            return 'NotImplemented'

    a = A()
    b = A('1')

    # Different type
    assert not a == 'bar'

    # This should not raise an exception
    assert not a == b

# Generated at 2022-06-11 01:55:55.973245
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-11 01:55:58.631543
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    v1 = Version("1.0.2")
    v2 = Version("1.0.2")
    v3 = Version("1.0.15")
    v4 = Version("1.0.15.4")
    assert (v1 <= v2)
    assert (v1 <= v3)
    assert (v1 <= v4)
    assert (v3 <= v4)



# Generated at 2022-06-11 01:56:07.350514
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import random
    import string

    for x in range(50):
        v1 = ''.join(random.choice(string.ascii_letters) for x in range(random.randint(1,4)))
        v2 = ''.join(random.choice(string.ascii_letters) for x in range(random.randint(1,4)))
        
        v1_obj = Version(v1)
        v2_obj = Version(v2)
        
        if v1_obj < v2_obj:
            pass
        elif v1_obj > v2_obj:
            pass
        elif v1_obj == v2_obj:
            pass
        else:
            pass

# Generated at 2022-06-11 01:56:17.908522
# Unit test for method __ge__ of class Version

# Generated at 2022-06-11 01:56:31.558880
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert (v < '1.2.1')



# Generated at 2022-06-11 01:56:33.697291
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("1.1.1") <= Version("1.1.2")


# Generated at 2022-06-11 01:56:35.571800
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    v.parse = lambda x: x
    assert v == 'x'

# Generated at 2022-06-11 01:56:43.600394
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  import VersionTestCase
  import unittest
  suite = unittest.TestSuite()
  suite.addTest(VersionTestCase.__eq___VersionTestCase("test_Version___eq___1"))
  suite.addTest(VersionTestCase.__eq___VersionTestCase("test_Version___eq___2"))
  suite.addTest(VersionTestCase.__eq___VersionTestCase("test_Version___eq___3"))
  suite.addTest(VersionTestCase.__eq___VersionTestCase("test_Version___eq___4"))
  suite.addTest(VersionTestCase.__eq___VersionTestCase("test_Version___eq___5"))
  suite.addTest(VersionTestCase.__eq___VersionTestCase("test_Version___eq___6"))

# Generated at 2022-06-11 01:56:53.801638
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version

    v1 = Version('1.0')
    v2 = Version('1.1')
    v3 = Version('2.0')
    v4 = Version('2.1')
    v5 = Version('3.0')
    v6 = Version('3.1')
    v7 = Version('3.2')
    v8 = Version('3.2.1')
    v9 = Version('3.2.2')
    v10 = Version('3.2.3')
    v11 = Version('3.2.1')
    v12 = Version('3.3.3')
    v13 = Version('3.2.1')

    assert v1 < v2, '%s < %s' % (v1, v2)

# Generated at 2022-06-11 01:56:56.017993
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Unit test for method __le__ of class Version"""
    method = Version.__le__
    # Insert your unit test here
    assert False, "Unit test not implemented"


# Generated at 2022-06-11 01:56:57.597679
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.2') < Version('1.3')


# Generated at 2022-06-11 01:56:58.684861
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    pass


# Generated at 2022-06-11 01:57:01.200622
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    o = Version()
    x = int(0)
    y = int(0)
    y = o.__ge__(x)
    assert y == NotImplemented

# Generated at 2022-06-11 01:57:02.989980
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    c = Version()
    b = c.__eq__(None)
    print(b)

# Generated at 2022-06-11 01:57:19.003073
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version("1.1")
    assert v == Version("1.1")
    assert v != None

# Generated at 2022-06-11 01:57:21.047432
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 == v2

# Generated at 2022-06-11 01:57:29.046636
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    __tracebackhide__ = True
    import os
    from packaging.version import Version, _BaseVersion

    v = Version("1.0")
    assert v < "1.1"
    assert v < "1.0.post1"
    assert v < "1.0.post1.dev1"
    assert v < "1.0a1"
    assert v < "2.0a1"
    assert v < "1.0a1.post1.dev1"
    assert v < "1.0a1.post1.dev2"
    assert not v < "0.9"
    assert not v < "1.0"

    v = Version("1.0c1")
    assert v < "1.0c2"
    assert v < "1.0c1.post1"

# Generated at 2022-06-11 01:57:38.551766
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    import io
    import sys
    import types

    from ansible.module_utils.six import PY2, PY3

    # Save the reference to the previous stdout and stderr
    previous_stdout , previous_stderr = sys.stdout , sys.stderr

    # Set io.StringIO as stdout and stderr
    sys.stdout = stdout = io.StringIO()
    sys.stderr = stderr = io.StringIO()

    try:
        # Call the function under test
        v1 = Version(vstring=None)
        v2 = Version(vstring=None)

        # Asserts
        assert v2 > v1 is False
        assert v1 > v2 is False

    finally:
        # Set back the previous stdout and stderr
        sys.std

# Generated at 2022-06-11 01:57:39.153798
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    pass

# Generated at 2022-06-11 01:57:42.774185
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    class Derived(Version):
        def _cmp(self, other):
            if isinstance(other, self.__class__):
                return 1
            return NotImplemented

    d = Derived()
    assert not d.__gt__(d)


# Generated at 2022-06-11 01:57:45.907372
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import pytest
    import distutils.version as version_m
    m = version_m.Version()
    with pytest.raises(NotImplementedError):
        m.__lt__(None)


# Generated at 2022-06-11 01:57:55.951322
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test case for method __ge__ of class Version"""
# Insert your test code here
    class VersionSubclass1(Version):
        def _cmp(self, other):
            return -1

    class VersionSubclass2(Version):
        def _cmp(self, other):
            return 0

    class VersionSubclass3(Version):
        def _cmp(self, other):
            return 1

    class VersionSubclass4(Version):
        def _cmp(self, other):
            return NotImplemented

    assert VersionSubclass1("0") < VersionSubclass2("0")
    assert not (VersionSubclass1("0") > VersionSubclass2("0"))
    assert VersionSubclass1("0") <= VersionSubclass2("0")
    assert not (VersionSubclass1("0") >= VersionSubclass2("0"))


# Generated at 2022-06-11 01:58:00.294426
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v.parse('1.2a')
    assert v <= '1.2a'
    assert v <= '1.2'
    assert v <= '1.2rc'
    assert v <= '1.2'
    assert not v <= '1.2b'

# Generated at 2022-06-11 01:58:01.142326
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version() == Version()

# Generated at 2022-06-11 01:58:49.900467
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    from distutils.version import Version, StrictVersion, LooseVersion


# Generated at 2022-06-11 01:58:54.577059
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2
    assert not v1 != v2

# Generated at 2022-06-11 01:58:58.143356
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import StrictVersion
    v = StrictVersion('1.2.3')
    assert v >= '1.2.3'
    assert v >= StrictVersion('1.2.3')
    assert not (v >= '1.2.3.a')
    assert not (v >= StrictVersion('1.2.3.a'))



# Generated at 2022-06-11 01:58:59.582585
# Unit test for method __le__ of class Version
def test_Version___le__():
  print('Test for __le__')
  pass


# Generated at 2022-06-11 01:59:06.303934
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Create an instance of the Version class
    ver = Version()
    # Assign '1' to 'other'
    other = 1
    # Call the __le__ method of the instance
    # This should raise a TypeError exception with message "unorderable types: Version() <= int()"
    with pytest.raises(TypeError, match=r"unorderable types: Version\(\) <= int\(\)") as excinfo:
        ver.__le__(other)

# Generated at 2022-06-11 01:59:16.204551
# Unit test for method __ge__ of class Version

# Generated at 2022-06-11 01:59:19.186703
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert v1.__ge__(v2)
    assert v2.__ge__(v1)


# Generated at 2022-06-11 01:59:22.965548
# Unit test for method __le__ of class Version
def test_Version___le__():
    print("test_Version___le__()")

    assert Version("2.2") <= Version("2.2")
    assert Version("2.1") <= Version("2.2")
    assert Version("2.2") <= Version("2.2+a1")

# Generated at 2022-06-11 01:59:32.139463
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils2.tests.support import unittest2
    import distutils2
    import distutils2.version

    class VersionTestCase(unittest2.TestCase):
        def test___ge__(self):
            v = distutils2.version.LooseVersion('1.2.3')
            v2 = distutils2.version.LooseVersion('1.2.3')
            self.assertTrue(v >= v2)

            v = distutils2.version.LooseVersion('1.2')
            v2 = distutils2.version.LooseVersion('1.2.3')
            self.assertTrue(v < v2)

    unittest2.main(__file__)


# Generated at 2022-06-11 01:59:34.389710
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    class Version__lt_(unittest.TestCase):
        def test_true(self):
            self.assertTrue(True)