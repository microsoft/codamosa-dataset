

# Generated at 2022-06-11 01:50:53.232358
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version1 = Version('1.2')
    version2 = Version('1.3')
    assert version1 < version2 or (version1 > version2) or (version1 == version2)
    return True
if __name__ == '__main__':
    test_Version___gt__()



# Generated at 2022-06-11 01:50:59.628365
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert(Version(), Version())
    assert(Version(), '1.2')
    assert(Version('1'), Version('1.2'))
    assert(Version('1.2'), Version('1.2'))
    assert(Version('1.3'), Version('1.2'))
    assert(Version('1.3'), '1.3')
    assert(Version('1.3'), '1.4')


# Generated at 2022-06-11 01:51:06.191257
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # A
    v = StrictVersion('1.2.3.4')
    assert str(v) == '1.2.3'
    # B
    v = StrictVersion('2.4.5a4')
    assert str(v) == '2.4.5a4'
    # C
    v = StrictVersion('1.2.3b1')
    assert str(v) == '1.2.3b1'


# Generated at 2022-06-11 01:51:17.885853
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    v3 = Version()
    v4 = Version()
    assert v1.__eq__(v2) == v2.__eq__(v1) == True

    v1.parse('1.0')
    v2.parse('1.0.0')
    v3.parse('2.0')
    v4.parse('1.1')

    assert v1.__eq__(v2) == v2.__eq__(v1) == True
    assert v1.__eq__(v3) == v3.__eq__(v1) == False
    assert v1.__eq__(v4) == v4.__eq__(v1) == False

# Generated at 2022-06-11 01:51:30.605275
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    return v.__gt__(1)
    return v.__gt__("1")
    return Version("1").__gt__("1")
    return Version("1").__gt__("2")
    return Version("2").__gt__("1")
    return Version("2a").__gt__("2")
    return Version("2a").__gt__("2a")
    return Version("2a").__gt__("2a.1")
    return Version("2.1a").__gt__("2a.1")
    return Version("2.1a").__gt__("2.1")
    return Version("2.1a").__gt__("2.1a.1")
    return Version("2.1a").__gt__("2.1a.1.1")

# Generated at 2022-06-11 01:51:34.622496
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.7.1')
    v2 = Version('1.7.2')
    assert not v2.__ge__(v1)
    assert v1.__ge__(v1)
    assert v2.__ge__(v2)
test_Version___ge__()


# Generated at 2022-06-11 01:51:39.734246
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from cpm.utils import versions
    assert versions.Version('0.0').__ge__('0.0') == True
    assert versions.Version('1.1.1').__ge__('0.0') == True
    assert versions.Version('0.0').__ge__('1.1.1') == False

# Generated at 2022-06-11 01:51:43.778433
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion()
    v.parse('0.5.0b1')
    assert str(v) == '0.5.0b1'
    v.parse('0.5.0')
    assert str(v) == '0.5.0'


# Generated at 2022-06-11 01:51:50.085036
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    cases = [
        ("1.2.3", (1, 2, 3)),
        ("1.2", (1, 2)),
        ("1", (1,)),
        ("1.2.3a4", (1, 2, 3), ("a", 4)),
        ("1.2.3b5", (1, 2, 3), ("b", 5)),
        ("1.2.3c6", (1, 2, 3), ("c", 6)),
        ("1.2.3rc7", (1, 2, 3), ("rc", 7)),
        ("1.2.3.4", (1, 2, 3, 4)),
        ("1.2.3.4.5.6.7", (1, 2, 3, 4, 5, 6, 7)),
    ]


# Generated at 2022-06-11 01:51:51.092639
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    StrictVersion('1').parse('0.1')

# Generated at 2022-06-11 01:52:16.799253
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version("1.1")
    assert not v == Version("1.0")
    assert v > Version("1.0")
    assert v >= Version("1.0")
    assert not v < Version("1.0")
    assert not v <= Version("1.0")
    assert not v == "1.0"
    assert v > "1.0"
    assert v >= "1.0"
    assert not v < "1.0"
    assert not v <= "1.0"
    assert not v == "1.0"
    assert v > "1.0"
    assert v >= "1.0"
    assert not v < "1.0"
    assert not v <= "1.0"

# Generated at 2022-06-11 01:52:17.986961
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1') <= Version('2')
    assert not (Version('2') <= Version('1'))
    assert not (Version('1') <= Version('1'))

# Generated at 2022-06-11 01:52:18.316193
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    pass

# Generated at 2022-06-11 01:52:20.096111
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    v2 = Version()
    assert v >= v2

# Generated at 2022-06-11 01:52:23.491253
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class TestVersion(Version):
        _ordering = 0
        def __init__(self, version=None):
            self._cmp = lambda other: self._ordering

    assert TestVersion('a') > TestVersion('b')
    assert not TestVersion('a') > TestVersion('a')
    assert not TestVersion('b') > TestVersion('a')


# Generated at 2022-06-11 01:52:25.348479
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__('1.0') == NotImplemented

# Generated at 2022-06-11 01:52:28.629812
# Unit test for method __gt__ of class Version
def test_Version___gt__():
  v = Version('1.2')
  assert(v > '1.1')
  assert(not v > '1.2')
  assert(not v > '1.3')

# Generated at 2022-06-11 01:52:36.832821
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    gv = Version('0.0')
    lv = Version('0.0')
    assert (gv > lv) is False
    assert (gv >= lv) is True
    assert (gv == lv) is True
    assert (gv < lv) is False
    assert (gv <= lv) is True

    gv = Version('1.0')
    lv = Version('0.0')
    assert (gv > lv) is True
    assert (gv >= lv) is True
    assert (gv == lv) is False
    assert (gv < lv) is False
    assert (gv <= lv) is False

    gv = Version('1.1')
    lv = Version('1.0')
    assert (gv > lv) is True
   

# Generated at 2022-06-11 01:52:38.730044
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert_equal(
        True,
        Version().__gt__(
            '0.0'
        )
    )


# Generated at 2022-06-11 01:52:42.430331
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1= mockup.version_for_devel('1.2.3')
    v2= mockup.version_for_devel('1.3.3')
    assert v1 <= v2


# Generated at 2022-06-11 01:52:53.879390
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    import random
    def t(*args):
        v = Version(*args)
        v._cmp = lambda x:random.choice((-1,1))
        return not (v < None)
    assert t("1.2.3") is False

# Generated at 2022-06-11 01:53:03.880720
# Unit test for method __le__ of class Version
def test_Version___le__():
    ver1 = StrictVersion('0.0.abc')
    ver2 = StrictVersion('0')
    if (ver1 <= ver2) == False:
        return False
    ver1 = StrictVersion('0')
    ver2 = StrictVersion('1')
    if (ver1 <= ver2) == False:
        return False
    ver1 = StrictVersion('1')
    ver2 = StrictVersion('1')
    if (ver1 <= ver2) == False:
        return False
    ver1 = StrictVersion('1')
    ver2 = StrictVersion('1')
    if (ver1 <= ver2) == False:
        return False
    return True


# Generated at 2022-06-11 01:53:05.216737
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version("5.6") == "5.6"

# Generated at 2022-06-11 01:53:06.521075
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= Version()

# Generated at 2022-06-11 01:53:16.430015
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    data = (
        (Version('1.0'), Version('2.0'), False),
        (Version('2.0'), Version('1.0'), True),
        (Version('1.1'), Version('1.0'), True),
        (Version('1.0'), Version('1.1'), False),
        (Version('1.0'), Version('1.0'), True),
        )
    for left, right, expected in data:
        assert left >= right == expected



# Generated at 2022-06-11 01:53:21.283584
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Imports
    from ansible.module_utils.compat.distutils.version import Version
    # Setup
    version = Version('')
    other = None
    # Execute
    result = version.__ge__(other)
    # Verify
    assert result is NotImplemented

# Generated at 2022-06-11 01:53:30.524942
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Tests of Version.__ge__
    assert Version('1') >= Version('1')
    assert not (Version('1') >= Version('2'))
    assert Version('2') >= Version('1')
    assert Version('1.2') >= Version('1.2')
    assert not (Version('1.2') >= Version('1.3'))
    assert Version('1.3') >= Version('1.2')
    assert Version('1.2.3') >= Version('1.2.3')
    assert not (Version('1.2.3') >= Version('1.2.4'))
    assert Version('1.2.4') >= Version('1.2.3')
    assert Version('2.3.4') >= Version('1.2.3')

# Generated at 2022-06-11 01:53:32.648966
# Unit test for method __le__ of class Version
def test_Version___le__():
  obj = Version()
  assert obj.__le__('0.0') == NotImplemented


# Generated at 2022-06-11 01:53:41.336595
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """Test parse method of class LooseVersion."""
    v = LooseVersion('  \t\n  1.2.3.a\n\n ')
    assert (v.version == [1, 2, 3, 'a'])
    v = LooseVersion('8.02 .\n')
    assert (v.version == [8, 2])
    v = LooseVersion('2g6')
    assert (v.version == ['2g6'])
    v = LooseVersion('3.1.1.6')
    assert (v.version == [3, 1, 1, 6])
    v = LooseVersion('1.13++')
    assert (v.version == [1, '13++'])
    v = LooseVersion('1.13  + +')

# Generated at 2022-06-11 01:53:46.849835
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils2.version import Version
    from distutils2.tests.support import captured_stdout
    import sys

    v = Version('42.0.0')
    ret = v == v
    assert ret is True
    ret = v == 42
    assert ret is False
    ret = v == '43.0.0'
    assert ret is False



# Generated at 2022-06-11 01:54:02.040794
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert (not v.__lt__(None))

# Generated at 2022-06-11 01:54:11.226646
# Unit test for method __ge__ of class Version

# Generated at 2022-06-11 01:54:14.435274
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert not v1.__ge__(v2)
    assert v2.__ge__(v1)



# Generated at 2022-06-11 01:54:16.310575
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1') < Version('2')



# Generated at 2022-06-11 01:54:17.258763
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert (True)

# Generated at 2022-06-11 01:54:18.849171
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.2.3') > Version('1.2.2')



# Generated at 2022-06-11 01:54:25.635285
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  import random
  a = Version(random.choice(("1.2","2.3","6.0")))
  assert isinstance(a,Version)
  assert isinstance(a,object)
  assert a < "2.1"
  assert not a < "2.2"
  assert not a < "2.3"
  assert not a < "6.0"
  assert not a < "6.1"
  return a

# Generated at 2022-06-11 01:54:35.754200
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import pytest
    _m_Version = Version
    _m_NotImplemented = NotImplemented

    class Version:

        def _cmp(self, other):
            if not isinstance(other, _m_Version):
                return _m_NotImplemented
            if self.inst_var == 'same':
                return other.inst_var == 'same'
            if self.inst_var == 'other':
                return other.inst_var == 'this'
            if self.inst_var == 'this':
                return other.inst_var == 'other'

        @property
        def inst_var(self):
            return 'same'

    v1 = Version('1')
    v2 = Version('2')

    assert v1 < v2
    assert v2 > v1


# Generated at 2022-06-11 01:54:41.257640
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version

    class DummyVersion(Version):
        def __init__(self, vstring=None):
            pass
        def parse(self, vstring):
            pass
        def _cmp(self, other):
            return NotImplemented

    dummy = DummyVersion()
    assert dummy <= None
# end unit test



# Generated at 2022-06-11 01:54:43.775086
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test method __gt__ of class Version."""
    try:
        Version().__gt__(None)
    except TypeError:
        pass

# Generated at 2022-06-11 01:55:21.787057
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest

    class _Version_TestCase(unittest.TestCase):
        # Confirm that a change to a built-in type also changes the value
        # of the corresponding class attribute.
        def test_class_attributes(self):
            self.assertEqual(int, int.__class__, msg='int is not its own class')
            self.assertEqual(Version, Version.__class__, msg='Version is not its own class')

        def test_eq(self):
            self.assertEqual(Version('1'), 1, msg='Version and int __eq__ should return correct result')
            self.assertEqual(Version('1.0'), 1, msg='Version and int __eq__ should return correct result')

# Generated at 2022-06-11 01:55:24.338416
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    e1 = Version('1.0')
    e2 = Version('2.0')
    assert e1 < e2


# Generated at 2022-06-11 01:55:28.148550
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    instance = Version()
    other = Version()
    try:
        instance.__lt__(other)
    except TypeError as e:
        print(e)
    else:
        raise AssertionError

# Generated at 2022-06-11 01:55:33.422985
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion('1.9')
    assert v.version == [1, '9']
    v = LooseVersion('1b')
    assert v.version == [1, 'b']
    v = LooseVersion('1.9.pre-1')
    assert v.version == [1, 9, 'pre-1']
    v = LooseVersion('.1')
    assert v.version == [0, '1']

# Generated at 2022-06-11 01:55:36.799507
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion("2.2beta29")
    assert lv.version == [2, 2, "beta29"]
    lv = LooseVersion("1.13++")
    assert lv.version == [1, 13, "++"]


# Generated at 2022-06-11 01:55:38.331034
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  v = Version()
  v2 = Version()
  assert v == v2

# Generated at 2022-06-11 01:55:40.901180
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Test version with version 
    v = Version('3.9.9.9')
    v2 = Version('3.9.9.9')
    assert v < v2 == False
    

# Generated at 2022-06-11 01:55:50.721823
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert 1 < 2
    assert 2 < 3
    assert 1 < 2.0
    assert 1.0 < 2
    assert 0.1 < 0.2
    assert 0.2 < 1.0

# Generated at 2022-06-11 01:55:53.836046
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = LooseVersion("1.0")
    v2 = LooseVersion("2.0")
    assert v1 < v2
    assert not v2 < v1
    try:
        assert v1 < "1.0"
    except:
        pass


# Generated at 2022-06-11 01:55:55.491598
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import doctest
    doctest.run_docstring_examples(Version.__ge__, globals())

# Generated at 2022-06-11 01:56:50.826317
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("0.0.1")
    v2 = Version("0.0.2")
    return v1 < v2

# Generated at 2022-06-11 01:57:00.868990
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1')
    v2 = Version('2')
    v1_2 = Version('1.2')
    v1_2_3 = Version('1.2.3')
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v1) == False
    assert v1.__gt__(v1_2) == False
    assert v1.__gt__(v1_2_3) == False
    assert v2.__gt__(v1) == True
    assert v2.__gt__(v1_2) == True
    assert v2.__gt__(v1_2_3) == True
    assert v1_2.__gt__(v1_2_3) == False

# Generated at 2022-06-11 01:57:03.912749
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() >= Version()
    assert Version() <= Version()
    assert False is (Version() > Version())
    assert False is (Version() < Version())



# Generated at 2022-06-11 01:57:11.957537
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest

    class VersionTest(unittest.TestCase):
        def test___le__(self):
            for args in [('1.2'), ('0.4.0b2')]:
                with self.subTest(args=args):
                    self.assertEqual(Version(*args).__ge__('1.1'), True)
                    self.assertEqual(Version(*args).__ge__('1.1'), True)
                    self.assertEqual(Version(*args).__ge__('1.3'), False)

    unittest.main(exit=False)
test_Version___le__()


# Generated at 2022-06-11 01:57:14.114622
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    Version("1.3.3").__eq__("1.3.3")


# Generated at 2022-06-11 01:57:19.119718
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test for __ge__ method of Version class"""
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v2 >= v1
    assert not (v1 >= v2)
    assert v1 >= v1


# Generated at 2022-06-11 01:57:20.442352
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert str(Version(vstring='0')) == '0'

# Generated at 2022-06-11 01:57:26.412142
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    v._cmp = lambda x: 0
    assert not v.__gt__(None)
    v._cmp = lambda x: 1
    assert v.__gt__(None)
    v._cmp = lambda x: -1
    assert not v.__gt__(None)
    v._cmp = lambda x: NotImplemented
    assert v.__gt__(None) is NotImplemented
test_Version___gt__()


# Generated at 2022-06-11 01:57:28.705504
# Unit test for method __le__ of class Version
def test_Version___le__():
    import datetime
    d = datetime.datetime.today()
    assert d <= str(d)
    assert d <= d



# Generated at 2022-06-11 01:57:30.986963
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import LooseVersion
    assert LooseVersion('1.0') > LooseVersion('0.99')



# Generated at 2022-06-11 01:59:41.329519
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    vc = Version()

# Generated at 2022-06-11 01:59:44.600099
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest

    # Tests for Version.__ge__

    class Version__ge__TestCase(unittest.TestCase):
        def test_ge(self):
            self.assertEqual(Version('1.2.3') >= Version('1.2.2'), True)

    # __main__
    unittest.main()

# Generated at 2022-06-11 01:59:53.342956
# Unit test for method __le__ of class Version
def test_Version___le__():
    test_cases = [
        [Version("1.0"), Version("1.0"), True, "same"],
        [Version("1.0"), Version("2.0"), True, "less than"],
        [Version("2.0"), Version("1.0"), False, "greater than"],
    ]

    for test_case in test_cases:
        actual = test_case[0] <= test_case[1]
        if actual != test_case[2]:
            give_up("Expected %s<=%s to be %s but was %s" % (test_case[0], test_case[1], test_case[2], actual))


# Generated at 2022-06-11 01:59:57.393954
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(Version())
    raise Exception ("Test Failed: '%s'" % repr(v.__le__))
try:
    test_Version___le__()
except Exception as exc:
    print(exc)

    # Unit test for method __ge__ of class Version

# Generated at 2022-06-11 02:00:05.508418
# Unit test for method __le__ of class Version
def test_Version___le__():
    #
    # Version.__le__
    #

    assert Version('1').__le__(Version('2'))
    assert Version('1.3').__le__(Version('1.3.0'))
    assert not Version('2').__le__(Version('1'))
    assert not Version('1.4').__le__(Version('1.3.0'))
    #
    # Invalid comparisons
    #

    try:
        Version('1.3.0').__le__([])
    except TypeError:
        pass
    else:
        raise AssertionError

    try:
        Version('1.3.0').__le__(None)
    except TypeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-11 02:00:08.208984
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1') >= ''
    assert Version('1') >= Version('1')
    assert Version('1') >= Version('0.9')
    assert Version('1') >= Version('1.0')

# Generated at 2022-06-11 02:00:14.361418
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Unit test for method __gt__ of class Version"""
    # Create a new class
    class test_Version___gt__Class(Version):
        """Class to test Version.__gt__"""
        def _cmp(self, other):
            """Compare"""
            if other == 1:
                return 0
            return 1

    # Test the __gt__ method
    t1 = test_Version___gt__Class(None)
    assert(t1.__gt__(0) is True)



# Generated at 2022-06-11 02:00:16.322938
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v
    assert not (v >= None)
    assert not (None >= v)



# Generated at 2022-06-11 02:00:17.858832
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    return v1 == v2

# Generated at 2022-06-11 02:00:21.198519
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.1').__le__(Version('1.1'))
    assert Version('1.1').__le__(Version('1.2'))
    assert not Version('1.3').__le__(Version('1.2'))

