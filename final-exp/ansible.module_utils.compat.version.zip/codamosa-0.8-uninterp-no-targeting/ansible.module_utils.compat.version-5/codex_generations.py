

# Generated at 2022-06-20 16:36:16.962832
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion("1.5.1")
    assert len(lv.version) == 3
    assert lv.version[0] == 1
    assert lv.version[1] == '5'
    assert lv.version[2] == 1
    lv = LooseVersion("161")
    assert len(lv.version) == 1
    assert lv.version[0] == 161
    lv = LooseVersion("1.5.1.4")
    assert len(lv.version) == 4
    assert lv.version[0] == 1
    assert lv.version[1] == '5'
    assert lv.version[2] == 1
    assert lv.version[3] == 4
    lv = LooseVersion("1.5.1-a.3")

# Generated at 2022-06-20 16:36:19.059812
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    v.__gt__ = lambda other: True
    v.__gt__(1)

# Generated at 2022-06-20 16:36:25.744833
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v1 = StrictVersion("1.0.4a3")
    assert v1.version == (1, 0, 4)
    assert v1.prerelease == ('a', 3)
    assert str(v1) == "1.0.4a3", str(v1)

    v2 = StrictVersion("1.0.4")
    assert v2.version == (1, 0, 4)
    assert v2.prerelease is None
    assert str(v2) == "1.0.4", str(v2)

    print("OK")


if __name__ == "__main__":
    test_StrictVersion()

# Generated at 2022-06-20 16:36:28.489808
# Unit test for constructor of class Version
def test_Version():
    for v in ('1.2.3.4', '123.456.789'):
        test = Version(v)
        assert str(test) == v



# Generated at 2022-06-20 16:36:30.477688
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    from distutils.version import StrictVersion
    v = StrictVersion('1.0')
    assert str(v) == '1.0'
    v = StrictVersion('1.0a1')
    assert str(v) == '1.0a1'



# Generated at 2022-06-20 16:36:33.429448
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # check that a LooseVersion object stringifies as we expect
    assert str(LooseVersion('1.2.3a2')) == '1.2.3a2'
    assert str(LooseVersion('1.2.0')) == '1.2'


# Generated at 2022-06-20 16:36:34.989459
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('')

    assert lv.__repr__() == "LooseVersion ('')"


# Generated at 2022-06-20 16:36:44.722366
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Try some invalid strings:
    for v in ('1.2.3.4', '1.2.3a', '1.2.3.4b', '1.2.3.4a5'):
        try:
            StrictVersion(v).parse(v)
        except ValueError:
            pass
        else:
            raise AssertionError("should have been invalid: %s" % v)

    # Try an assortment of valid version numbers:

# Generated at 2022-06-20 16:36:49.160738
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
  import unittest
  class Test(unittest.TestCase):
    def test_1(self):
      version = '1.0'
      assert LooseVersion(version).__repr__() == "LooseVersion ('%s')" % version
  unittest.main(exit=False)


# Generated at 2022-06-20 16:36:55.389816
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest

    class _Version(Version):

        def _cmp(self, other):
            return NotImplemented

    class Test__Version(unittest.TestCase):
        def test_notimplemented(self):
            v1 = _Version()
            v2 = _Version()
            self.assertTrue(v1 == v2)
            self.assertFalse(v1 != v2)
            self.assertTrue(v1 != 'str')
            self.assertFalse(v1 == 'str')

# Generated at 2022-06-20 16:37:11.280568
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import sys
    import subprocess
    # Test area
    v1 = Version('1.0.0')
    v2 = Version('1.0.0')
    assert v1 == v2
    v1 = Version('1.0.0')
    v2 = Version('2.0.0')
    assert not v1 == v2
    try:
        v1 = Version('1.0.0')
        v2 = 1
        assert v1 == v2
    except Exception as e:
        if str(e) != "unorderable types: Version() > int()":
            raise e

# Generated at 2022-06-20 16:37:12.865897
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2.3')
    assert repr(v) == "LooseVersion ('1.2.3')"

# Generated at 2022-06-20 16:37:25.005014
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    f = LooseVersion

    # check leading 0.
    assert(f("1.1").version == f("01.01").version)
    assert(f("1.1").version == f("001.001").version)
    assert(f("1.1").version == f("0.1").version)

    # check different types of components
    # XXX would be nice to check that Unicode strings get converted to ASCII
    assert(f("1.001a1").version == f("1.1a001").version)
    assert(f("1.001b1.4").version == f("1.1b001.004").version)
    assert(f("1.001c1.4.2").version == f("1.1c001.004.002").version)

    # check various separators

# Generated at 2022-06-20 16:37:32.238878
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3')
    assert str(v) == '1.2.3', str(v)
    assert repr(v) == "StrictVersion ('1.2.3')", repr(v)

    v = StrictVersion('1.2.3a1')
    assert str(v) == '1.2.3a1', str(v)
    assert repr(v) == "StrictVersion ('1.2.3a1')", repr(v)

    v = StrictVersion('1.2.3b3')
    assert str(v) == '1.2.3b3', str(v)
    assert repr(v) == "StrictVersion ('1.2.3b3')", repr(v)

    assert StrictVersion('1.2.3') == StrictVersion

# Generated at 2022-06-20 16:37:41.706174
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    print("Reinvented %s" % StrictVersion())
    print("Reinvented %s" % StrictVersion("1.0.4"))
    print("Reinvented %s" % StrictVersion("1.0.4a3"))
    print("Reinvented %s" % StrictVersion("1.0.4b1"))
    print("Reinvented %s" % StrictVersion("1.0.4b10"))
    print("Reinvented %s" % StrictVersion("1.0.4b100"))
    print("Reinvented %s" % StrictVersion("1.0.4b1000"))

# Generated at 2022-06-20 16:37:44.821809
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    '''
    This will test the __repr__ method of class Version.
    '''
    version_test = Version()
    assert version_test.__repr__() == "Version ('None')"

# Generated at 2022-06-20 16:37:48.151637
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.1')
    v2 = Version('1.1')
    v3 = Version('1.2')
    assert v1 == v2
    assert not v1 == v3

# Generated at 2022-06-20 16:37:54.930358
# Unit test for constructor of class Version
def test_Version():
    import unittest

    if type(unittest) != type(__import__("unittest")):
        import unittest

    class VersionTestCase(unittest.TestCase):
        def test_version(self):
            v = Version("1.2.3")
            self.assertEqual(str(v), "1.2.3")
            self.assertEqual(repr(v), "Version ('1.2.3')")

    unittest.main(exit=False)

# End unit test for Version



# Generated at 2022-06-20 16:38:01.772877
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    f = "abc"
    g = "abc"
    assert f == g, (f, g)

    f = "abc"
    g = "abd"
    assert f < g, (f, g)

    f = "abc"
    g = "abcd"
    assert f < g, (f, g)

    f = "2"
    g = "10"
    assert f < g, (f, g)

    f = "2.5"
    g = "2.6"
    assert f < g, (f, g)

    f = "2.5.1"
    g = "2.5.2"
    assert f < g, (f, g)

    f = "2.5.1"
    g = "2.6"

# Generated at 2022-06-20 16:38:04.218794
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    f = Version()
    f.parse('1.0')
    p = Version()
    p.parse('1.0')
    assert(f==p)

# Generated at 2022-06-20 16:38:12.836953
# Unit test for constructor of class Version
def test_Version():
    assert repr(Version()) == "Version ('0')"
    assert repr(Version('1.2.3')) == "Version ('1.2.3')"



# Generated at 2022-06-20 16:38:21.074761
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    class LV(LooseVersion):
        def __init__(self, vstring=None):
            LooseVersion.__init__(self, vstring)
            if vstring:
                self.parse(vstring)

    assert LV('1.5.1') == LooseVersion('1.5.1')
    assert LooseVersion('1.5.1') < LV('1.6.2')
    assert LV('1.5.1') < LooseVersion('3.2.4')
    assert LV('1.5.1') == '1.5.1'
    assert LooseVersion('1.5.1') < '1.6.2'
    assert '1.5.1' < LooseVersion('3.2.4')

# Generated at 2022-06-20 16:38:26.176875
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('2.0a1')
    w = Version('2.0b3')
    x = Version('2.0')
    assert v == Version(v)
    assert not v == 'foo'
    assert v != w
    assert not v == w
    assert x == x

# Generated at 2022-06-20 16:38:36.571039
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    from distutils2.tests.support import captured_stdout


# Generated at 2022-06-20 16:38:46.563918
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """__repr__ returns a string that can be evaluated to re-create the instance"""

    #
    # simple version
    #
    v = LooseVersion('1.2')
    e = eval(repr(v))
    assert e.vstring == v.vstring, 'Could not eval(repr(v)) for v=%s' % v.vstring

    #
    # complicated version
    #
    v = LooseVersion('1.2.3.4.5.6.7.8.9.10.11.12.13.14.15.16')
    e = eval(repr(v))
    assert e.vstring == v.vstring, 'Could not eval(repr(v)) for v=%s' % v.vstring


# Generated at 2022-06-20 16:38:55.088979
# Unit test for method __le__ of class Version
def test_Version___le__():
    import random
    # set seed for random number generator
    random.seed(1)
    # slot tests
    # loop over all possible combinations of slot values
    for _ in range(1):
        # randomize int values
        v1_int = random.randint(-2147483648, 2147483647)
        v2_int = random.randint(-2147483648, 2147483647)
        arg1 = Version(v1_int)
        arg2 = Version(v2_int)
        # call the method
        # (raise Exception if needed)
        try:
            result = arg1.__le__(arg2)
        except Exception:
            raise
        # check the method output against expected
        if v1_int <= v2_int:
            assert result

# Generated at 2022-06-20 16:38:56.669831
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert repr(Version('1.2.rc3')) == "Version ('1.2.rc3')"

# Generated at 2022-06-20 16:39:04.085986
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    import sys
    from_string = Version.from_string
    class VersionTest(unittest.TestCase):
        def test_lt(self):
            self.assertTrue(from_string("1.0") < from_string("2.0"))
    
    from distutils.tests import support
    from distutils.version import StrictVersion, LooseVersion
    
    def test_supports_distutils_version():
        class DistutilsVersionTest(VersionTest):
            "Test compatibility for the 'distutils.version' interface"
            def test_lt(self):
                self.assertTrue(StrictVersion("1.0") < StrictVersion("2.0"))
                self.assertTrue(LooseVersion("1.0") < LooseVersion("2.0"))
        suite = unittest.Test

# Generated at 2022-06-20 16:39:15.452703
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import unittest
    class Test(unittest.TestCase):
        def test_ok(self):
            for s, t in [
                ('1.2.3.4a1', ['1', '2', '3', '4a1']),
                ('1.2.3a1',['1', '2', '3a1']),
                ('1.2a1', ['1', '2a1']),
                ('1.2pl3', ['1', '2pl3']),
                ('1.2', ['1', '2']),
                ]:
                lv = LooseVersion(s)
                self.assertEqual(lv.version, t)


# Generated at 2022-06-20 16:39:18.653298
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test with invalid type.
    v = Version()
    r = v.__eq__(object())
    assert r is NotImplemented


# Generated at 2022-06-20 16:39:32.817347
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def test(vstring, common_version):
        cv = str(LooseVersion(vstring))

# Generated at 2022-06-20 16:39:36.742482
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.2.3') < Version('1.2.4')
    assert not Version('1.2.3') < Version('1.2.3')
    assert not Version('1.2.4') < Version('1.2.3')


# Generated at 2022-06-20 16:39:40.609131
# Unit test for method __le__ of class Version
def test_Version___le__():
    Ver = Version()
    Ver.parse('2.0')
    assert Ver.__le__('1.0') == False
    assert Ver.__le__('2.0') == True
    assert Ver.__le__('3.0') == True


# Generated at 2022-06-20 16:39:49.410528
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # This is the intended use-case.
    lv = LooseVersion("1.2.0")
    assert lv.version == [1,2,0]
    # There ought to be a way to do this in a single assert statement.
    lv.parse("3.3.3")
    assert lv.version == [3,3,3]
    # Handle strings that do not start with a number.
    lv.parse("Jython 2.2b1")
    assert lv.version == ['Jython', 2, 2, 'b', 1]
    # Handle strings that end with a non-digit.
    lv.parse("1.1.1-alpha")
    assert lv.version == [1, 1, 1, 'alpha']
    # Handle strings with letters in them.

# Generated at 2022-06-20 16:39:52.424848
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    vstring = '.'.join(map(str, ['1', '1', '1']))
    myStrictVersion = StrictVersion(vstring)
    assert vstring == str(myStrictVersion)

# Generated at 2022-06-20 16:39:54.622466
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  version = Version(1.0)
  expected = True
  actual = version < 1.12
  assert expected == actual

# Generated at 2022-06-20 16:40:00.830479
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def _mock_parse(self, vstring):
        self.vstring = vstring
    import types
    import sys
    import unittest
    if sys.version_info[:2] >= (2, 7):
        import unittest.mock as mock
    else:
        import mock
    with mock.patch('distutils.version.Version.parse', _mock_parse):
        v = Version('vstring')
        eq = v.__eq__('vstring')
        assert eq == True



# Generated at 2022-06-20 16:40:02.931336
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert repr(LooseVersion('1.0')) == 'LooseVersion (\'1.0\')'



# Generated at 2022-06-20 16:40:04.845119
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v1 = Version(vstring='1.0')
    assert repr(v1) == "Version ('1.0')"


# Generated at 2022-06-20 16:40:11.494337
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Make sure StrictVersion initializer doesn't blow up on malformed
    # string
    for malformed in ["", "hello there", "1.1.1a-123"]:
        try:
            StrictVersion(malformed)
        except ValueError:
            pass
        else:
            raise AssertionError(
                "StrictVersion() was not supposed to accept malformed string"
            )

test_StrictVersion()



# Generated at 2022-06-20 16:40:28.431524
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    try:
        StrictVersion('1')
    except ValueError:
        pass

    try:
        StrictVersion('1.2.3.4')
    except ValueError:
        pass

    try:
        StrictVersion('1.2b3.4')
    except ValueError:
        pass

    try:
        StrictVersion('1.2b3')
    except ValueError:
        pass

    try:
        StrictVersion('1.2a')
    except ValueError:
        pass

    try:
        StrictVersion('a.2')
    except ValueError:
        pass

    try:
        StrictVersion('1.a.3')
    except ValueError:
        pass

    try:
        StrictVersion('1.2a3a4')
    except ValueError:
        pass



# Generated at 2022-06-20 16:40:37.442973
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lcv = LooseVersion()
    # test that invalid strings raise exceptions
    badstrings = ["1.2.3a4a5", "1.2.3 a4",
                  "1.2.3a4a5", "1.2.3 a4",
                  "1.2.3.4.5", "myversion", " "]
    for bads in badstrings:
        try:
            lcv.parse(bads)
        except ValueError:
            pass
        else:
            raise AssertionError("should have raised ValueError for %s" % bads)

    # test string parsing

# Generated at 2022-06-20 16:40:48.151076
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    ver = StrictVersion('1.3.3')
    assert ver.version == (1,3,3)
    assert ver.prerelease == None
    ver = StrictVersion('1.3.3a1')
    assert ver.version == (1,3,3)
    assert ver.prerelease == ('a',1)
    ver = StrictVersion('1.3a1')
    assert ver.version == (1,3,0)
    assert ver.prerelease == ('a',1)
    ver = StrictVersion('1.4.4b1')
    assert ver.version == (1,4,4)
    assert ver.prerelease == ('b',1)
    ver = StrictVersion('1.4b1')
    assert ver.version == (1,4,0)

# Generated at 2022-06-20 16:40:58.822844
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v1 = StrictVersion("1.0")
    assert str(v1) == "1.0"
    assert "1.0" == str(v1)

    # Check that version instances sort correctly:
    versions = ["0.4",
                "0.4.0",
                "0.5a1",
                "0.5b3",
                "0.5",
                "0.9.6",
                "1.0",
                "1.0.4a3",
                "1.0.4b1",
                "1.0.4"]

    # case 1: sort() -- no key, reverse=false
    sorted_versions = versions[:]
    sorted_versions.sort(key=StrictVersion)

# Generated at 2022-06-20 16:41:05.473640
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # Always use a period for the decimal point.
    for version_string in ['0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5',
                           '0.9.6', '1.0', '1.0.4a3', '1.0.4b1',
                           '1.0.4']:
        version = LooseVersion(version_string)
        assert repr(version) == "LooseVersion ('%s')" % version_string

    # Test the all-integer case.
    version = LooseVersion('1')
    assert repr(version) == "LooseVersion ('1')"

    # A moderately complicated example.
    version = LooseVersion('1.2.1')

# Generated at 2022-06-20 16:41:14.579323
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import Version

    assert Version("1.0") >= "1.0"
    assert Version("2.0") >= "1.0"
    assert not Version("1.0") >= "2.0"
    assert Version("1.0") >= Version("1.0")
    assert Version("2.0") >= Version("1.0")
    assert not Version("1.0") >= Version("2.0")



# Generated at 2022-06-20 16:41:16.217756
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.3a4')
    assert str(v) == "LooseVersion ('1.3a4')"


# Generated at 2022-06-20 16:41:18.715524
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v2 > v1, "Version 1.0 is less than 2.0"


# Generated at 2022-06-20 16:41:22.520481
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    f = Version("1.0")
    f2 = Version("2.0")
    assert f2 > f
    assert not f > f2


# Generated at 2022-06-20 16:41:26.346469
# Unit test for constructor of class Version
def test_Version():
    def test():
        v = Version(3.14)
    try:
        test()
    except AttributeError:
        pass
    else:
        raise AssertionError('expected AttributeError')


# Generated at 2022-06-20 16:41:53.305763
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion("0.4.0")) == "0.4.0"
    assert str(StrictVersion("0.4")) == "0.4.0"
    assert str(StrictVersion("0.4.1")) == "0.4.1"
    assert str(StrictVersion("0.5a1")) == "0.5a1"
    assert str(StrictVersion("0.5b3")) == "0.5b3"
    assert str(StrictVersion("0.5")) == "0.5.0"
    assert str(StrictVersion("0.9.6")) == "0.9.6"
    assert str(StrictVersion("1.0")) == "1.0.0"

# Generated at 2022-06-20 16:41:54.656398
# Unit test for constructor of class Version
def test_Version():
    v = Version()


# Generated at 2022-06-20 16:41:56.217916
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion('1.1.1')
    assert lv.version == [1, 1, 1]



# Generated at 2022-06-20 16:42:06.039006
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert eval(LooseVersion("1.2.3").__repr__()) == "LooseVersion ('1.2.3')"
    assert eval(LooseVersion("1.2-pre.3").__repr__()) == "LooseVersion ('1.2-pre.3')"
    assert eval(LooseVersion("0.2").__repr__()) == "LooseVersion ('0.2')"
    assert eval(LooseVersion("0.2+").__repr__()) == "LooseVersion ('0.2+')"
    assert eval(LooseVersion("2.0dev-r666").__repr__()) == "LooseVersion ('2.0dev-r666')"

# Generated at 2022-06-20 16:42:07.972205
# Unit test for method __le__ of class Version
def test_Version___le__():
    v, w = 3, 4
    assert (v <= w)

# Generated at 2022-06-20 16:42:10.920099
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lo = LooseVersion('3.10a')
    assert repr(lo) == "LooseVersion ('3.10a')"


# Generated at 2022-06-20 16:42:12.786768
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    x = Version("1.0")
    y = Version("1.1")
    assert x.__lt__(y) is True

# Generated at 2022-06-20 16:42:19.824991
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.2.3')
    assert lv.version == [1, 2, 3]
    lv.parse('1.2')
    assert lv.version == [1, 2]
    lv.parse('1.2b3')
    assert lv.version == [1, 2, 'b', 3]
    lv.parse('1.2.3.dev')
    assert lv.version == [1, 2, 3, 'dev']
    lv.parse('1.2a1')
    assert lv.version == [1, 2, 'a', 1]
    lv.parse('1.2.dev1')
    assert lv.version == [1, 2, 'dev', 1]



# Generated at 2022-06-20 16:42:22.495516
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    from distutils.tests import support
    support.run_unittest(StrictVersionTestCase)



# Generated at 2022-06-20 16:42:29.635192
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-20 16:43:10.215953
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    d = Version(None)

    assert repr(d) == "Version ('None')"


# Generated at 2022-06-20 16:43:21.619403
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # Check the output of __str__ for different values
    v = LooseVersion("1.0")
    assert str(v) == "1.0"
    v = LooseVersion("1.2.3")
    assert str(v) == "1.2.3"
    v = LooseVersion("1.2.3a")
    assert str(v) == "1.2.3a"
    v = LooseVersion("1.2.3b")
    assert str(v) == "1.2.3b"
    v = LooseVersion("1.2.3b2")
    assert str(v) == "1.2.3b2"
    v = LooseVersion("1.2.3.4")
    assert str(v) == "1.2.3.4"
    v = Lo

# Generated at 2022-06-20 16:43:30.648252
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion("1.0")
    assert(lv.version == (1, 0))

    lv = LooseVersion("1.0.0")
    assert(lv.version == (1, 0, 0))

    lv = LooseVersion("1.2.0.0")
    assert(lv.version == (1, 2, 0, 0))

    lv = LooseVersion("1.2.0.0.0")
    assert(lv.version == (1, 2, 0, 0, 0))

    lv = LooseVersion("1.2pl0")
    assert(lv.version == (1, 2, "pl", 0))

    lv = LooseVersion("1.2pl0.0")
    assert(lv.version == (1, 2, "pl", 0, 0))

   

# Generated at 2022-06-20 16:43:32.722975
# Unit test for method __le__ of class Version
def test_Version___le__():
    # FIXME 1: test cases for method __le__ of class Version
    try:
        # setup
        # exercise
        # verify
        # cleanup
        pass
    except:
        # cleanup
        raise

# Generated at 2022-06-20 16:43:38.351559
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Some cases to get started
    v = Version("1.2.3")
    assert str(v) == "1.2.3"
    assert repr(v) == "Version ('1.2.3')"
    assert (v < "1.2.4")
    assert not (v < "1.2.3")
    assert (v <= "1.2.4")
    assert (v <= "1.2.3")
    assert (v > "1.2.2")
    assert not (v > "1.2.3")
    assert (v >= "1.2.2")
    assert (v >= "1.2.3")
    assert (v != "1.2.4")
    assert not (v != "1.2.3")
    assert (v == "1.2.3")


# Generated at 2022-06-20 16:43:41.401086
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    w = Version()
    x = Version()
    y = Version()
    z = Version()
    expr = (x < y)
    assert expr
    assert isinstance(expr, bool)
    assert not (z < y)
    assert not (w < x)
    assert not (y < z)



# Generated at 2022-06-20 16:43:50.689868
# Unit test for method __ge__ of class Version

# Generated at 2022-06-20 16:43:52.390242
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version("1.2.3.4")
    assert repr(v) == "Version ('1.2.3.4')"


# Generated at 2022-06-20 16:43:53.899683
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    Version.__gt__(Version(), Version())


# Generated at 2022-06-20 16:44:03.809317
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from ansible_test.unit.compat.mock import patch, MagicMock

    class VersionDefault(Version):
        def __init__(self, vstring=None):
            super(VersionDefault, self).__init__(vstring)

        def _cmp(self, other):
            return MagicMock(return_value=1)

    v = VersionDefault()
    v._cmp = MagicMock(return_value=NotImplemented)
    assert v > 0

    v = VersionDefault(0)
    assert v > 5

    v = VersionDefault(0)
    v._cmp = MagicMock(return_value=None)
    assert v > 0

    v = VersionDefault(vstring='0')
    v._cmp = MagicMock(return_value=NotImplemented)

# Generated at 2022-06-20 16:45:53.125970
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test that the string representation of a particular instance is
    # deterministic.
    s = StrictVersion('1.0')
    assert str(s) == '1.0.0'

    s = StrictVersion('1.0.0')
    assert str(s) == '1.0.0'

    s = StrictVersion('1.0.0.0')
    assert str(s) == '1.0.0'

    s = StrictVersion('1.0a1')
    assert str(s) == '1.0a1'

    s = StrictVersion('1.0.0a1')
    assert str(s) == '1.0a1'

    s = StrictVersion('1.0.0.0a1')
    assert str(s) == '1.0a1'



# Generated at 2022-06-20 16:45:57.676091
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
  v = StrictVersion("0.4")
  assert v.__str__() == "0.4"
  v = StrictVersion("0.4.0")
  assert v.__str__() == "0.4.0"
  v = StrictVersion("0.4.1")
  assert v.__str__() == "0.4.1"
  v = StrictVersion("0.5a1")
  assert v.__str__() == "0.5a1"
  v = StrictVersion("0.5b3")
  assert v.__str__() == "0.5b3"
  v = StrictVersion("0.5")
  assert v.__str__() == "0.5"
  v = StrictVersion("0.9.6")
  assert v.__str__