

# Generated at 2022-06-20 16:36:16.697668
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():

    assert '0.4' == str(StrictVersion('0.4'))
    assert '0.4' == str(StrictVersion('0.4.0'))
    assert '0.5a1' == str(StrictVersion('0.5a1'))
    assert '1.2.3' == str(StrictVersion('1.2.3'))
    assert '1.2.0' == str(StrictVersion('1.2'))

# Generated at 2022-06-20 16:36:20.817018
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # check valid input
    v = LooseVersion("1.4.7")
    assert str(v) == "1.4.7", "__str__ does not return a string: %s" % str(v)
    v = LooseVersion("1.4.7")
    # Unit test for method __init__ of class LooseVersion

# Generated at 2022-06-20 16:36:27.761724
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv1 = LooseVersion('1.2.3.4a1')
    lv2 = LooseVersion('1.2.3.4b1')
    assert lv1 < lv2, 'LooseVersion constructor failed'
    # This will fail if regression is introduced in LooseVersion
    # class LooseVersion: def parse(self, vstring): ...
    assert LooseVersion('1.2.3a4') < LooseVersion('1.2.3'), \
           'LooseVersion constructor failed (alphabetic prefix handling)'
    assert LooseVersion('1.2.03') == LooseVersion('1.2.3'), \
           'LooseVersion constructor failed (leading zero handling)'

test_LooseVersion()


# Generated at 2022-06-20 16:36:32.234009
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    pattern = re.compile("^Function \"__gt__\".+")
    func = getattr(Version, "__gt__", None)
    if func is not None:
        if callable(func):
            gt_test_result = func.__module__ + "." + func.__name__
        else:
            gt_test_result = func.__module__ + ".__gt__"
    else:
        gt_test_result = "Version.__gt__"
    if not pattern.match(gt_test_result):
        raise ImportError("%s from %s is not safe to use" % (func.__name__, func.__module__))
test_Version___gt__()


# Generated at 2022-06-20 16:36:42.014455
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from ..fake import Fake
    from distutils.version import Version
    s = Fake()
    s.foo = Fake()
    s.foo.Version = Version
    assert s.foo.Version().__repr__() == "Version ('0')"
    s.foo.Version = Version
    assert s.foo.Version('1.0').__repr__() == "Version ('1.0')"
    s.foo.Version = Version
    assert s.foo.Version('1').__repr__() == "Version ('1')"
    s.foo.Version = Version
    assert s.foo.Version('1.0.1').__repr__() == "Version ('1.0.1')"



# Generated at 2022-06-20 16:36:48.133348
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1').__repr__() == "LooseVersion ('1')"
    assert LooseVersion('1.2').__repr__() == "LooseVersion ('1.2')"
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"
    assert LooseVersion('1.2b2').__repr__() == "LooseVersion ('1.2b2')"


# Generated at 2022-06-20 16:36:51.386752
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    pkg = 'a'
    v = LooseVersion ('1.2.3')
    assert (str (v) == '1.2.3')


#Unit test for method __repr__ of class LooseVersion

# Generated at 2022-06-20 16:37:00.795767
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    for vstring in ['0.4',
                    '0.4.0',
                    '0.4.1',
                    '0.5a1',
                    '0.5b3',
                    '0.5',
                    '0.9.6',
                    '1.0',
                    '1.0.4a3',
                    '1.0.4b1',
                    '1.0.4']:
        StrictVersion(vstring)
    for vstring in ['1',
                    '2.7.2.2',
                    '1.3.a4',
                    '1.3pl1',
                    '1.3c4']:
        try:
            StrictVersion(vstring)
        except ValueError:
            pass

# Generated at 2022-06-20 16:37:02.318149
# Unit test for constructor of class Version
def test_Version():
    assert Version()
    assert Version('')


# Generated at 2022-06-20 16:37:08.409716
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import unittest
    import sys
    if sys.version_info[0] == 2:
        if sys.version_info[1] >= 7:
            class Test_LooseVersion___str__(unittest.TestCase):
                def test__LooseVersion___str__(self):
                    self.assertEqual(str(LooseVersion('1.13++')), '1.13++')
                    self.assertEqual(str(LooseVersion('1.5.2b2')), '1.5.2b2')
                    self.assertEqual(str(LooseVersion('1.5.2b2')), '1.5.2b2')
                    self.assertEqual(str(LooseVersion('1.5.2b2')), '1.5.2b2')
                    self.assertEqual

# Generated at 2022-06-20 16:37:27.092951
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion('1.2.3').version == (1, 2, 3)
    assert StrictVersion('1.2').version == (1, 2, 0)
    assert StrictVersion('1.2.0').version == (1, 2, 0)
    assert StrictVersion('1.2b3').version == (1, 2, 0)
    assert StrictVersion('1.2b3').prerelease == ('b', 3)
    assert StrictVersion('1.2a3').version == (1, 2, 0)
    assert StrictVersion('1.2a3').prerelease == ('a', 3)

# Tests for class StrictVersion

# Generated at 2022-06-20 16:37:29.031281
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version
    v = Version('3.3.3')
    w = Version('3.3.3')
    try:
        v == w
    except Exception as e:
        print(e)
        print(type(e))


# Generated at 2022-06-20 16:37:39.633232
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test method __ge__ of class Version."""
    from distutils.version import StrictVersion
    v = StrictVersion('1.2')
    assert v >= '1'
    assert v >= '1.2'
    assert not v >= '2' # noqa
    assert not v >= '1.2.0' # noqa
    assert not v >= '1.2.0.0' # noqa
    assert not v >= 1 # noqa
    assert not v >= 1.2 # noqa

# Generated at 2022-06-20 16:37:46.039879
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('2.5')
    v2 = Version('2.5')
    v3 = Version('1.4')
    v4 = Version('2.4')
    assert v2 < v1 == v1 == v2
    assert v2 < v3 == v3 < v2
    assert v2 < v4 == v4 < v2
test_Version___lt__()

# Generated at 2022-06-20 16:37:51.290167
# Unit test for constructor of class Version
def test_Version():
    for vstring in ['1.2.3', '1.2a4']:
        assert vstring == str(Version(vstring))
    assert '1.2a4' == str(Version('1.2a4'))
    assert '1.2a4' == str(Version(Version('1.2a4')))


# Generated at 2022-06-20 16:37:58.650765
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion('1.0') == StrictVersion('1.0.0')
    assert StrictVersion('1.0.0') == StrictVersion('1.0')

    assert StrictVersion('1.0.0') != StrictVersion('1.0.1')
    assert StrictVersion('1.0.0') != StrictVersion('1.1')

    assert StrictVersion('1.0.0a') < StrictVersion('1.0')
    assert StrictVersion('1.0.0a') < StrictVersion('1.0.0')
    assert StrictVersion('1.0.0a') == StrictVersion('1.0.0a0')
    assert StrictVersion('1.0.0a1') < StrictVersion('1.0.0a9')

# Generated at 2022-06-20 16:38:01.376539
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('1')
    assert v > 0 and v > '0' and v > '0.2' and v > '0.0.2' and v > '0.0.0.2'
    assert not v > '1'

# Generated at 2022-06-20 16:38:09.476532
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():

    cls = LooseVersion('0.2.0')
    cls.parse('1.0')
    cls.parse('1.0.0')
    cls.parse('1.0.0.0.0.0')
    assert cls.__repr__() == "LooseVersion ('1.0.0.0.0.0')"
    v1 = LooseVersion(str(cls))
    v2 = eval(repr(cls))
    assert v1 == v2


# Generated at 2022-06-20 16:38:18.602208
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion("1.2.3a0") == StrictVersion("1.2.3a0")
    assert StrictVersion("1.2.3a0") < StrictVersion("1.2.3")
    assert StrictVersion("1.2.3a0") < StrictVersion("1.2.3a1")
    assert StrictVersion("1.2.3a0") < StrictVersion("1.2.3b1")
    assert StrictVersion("1.2.3a") < StrictVersion("1.2.3a1")
    assert StrictVersion("1.2.3a") < StrictVersion("1.2.3b1")
    assert StrictVersion("1.2.3a1") < StrictVersion("1.2.3b1")

# Generated at 2022-06-20 16:38:20.735210
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion ("1.2.3.4")
    assert v.__str__() == "1.2.3.4"


# Generated at 2022-06-20 16:38:35.580503
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from sys import platform
    from copy import deepcopy
    
# Test examples from RFC
    testvstring = (
        '1.2.3.4',
        '1.2.3.4.5',
        '1.2.3.4.5.6',
        '1',
        '1.2',
        '1.2.3',
        '1.2.3.4',
    )
    testvstring_out = (
        [1,2,3,4],
        [1,2,3,4,5],
        [1,2,3,4,5,6],
        [1],
        [1,2],
        [1,2,3],
        [1,2,3,4],
    )


# Generated at 2022-06-20 16:38:46.224928
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('0.4.0')
    assert str(v) == '0.4.0'
    v = StrictVersion('0.4.1')
    assert str(v) == '0.4.1'
    v = StrictVersion('0.5a1')
    assert str(v) == '0.5a1'
    v = StrictVersion('0.5b3')
    assert str(v) == '0.5b3'
    v = StrictVersion('0.5')
    assert str(v) == '0.5'
    v = StrictVersion('0.9.6')
    assert str(v) == '0.9.6'
    v = StrictVersion('1.0')
    assert str(v) == '1.0'
    v = St

# Generated at 2022-06-20 16:38:49.497743
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest
    import pytest

    class VersionTestCase(unittest.TestCase):
        def test___eq__(self):
            assert Version("1.0") == Version("1.0")

# Generated at 2022-06-20 16:38:59.751536
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Make the minimal instance
    inst_0 = Version()
    inst_1 = Version(vstring='abc')
    inst_2 = Version(vstring='abc')
    inst_3 = Version(vstring='def')
    try:
        # Call the method
        result = inst_0.__le__(inst_0)

        # Check the results
        assert result is True
    except Exception as ex:
        fail('Unexpected exception raised: ' + str(ex))
    try:
        # Call the method
        result = inst_1.__le__(inst_2)

        # Check the results
        assert result is True
    except Exception as ex:
        fail('Unexpected exception raised: ' + str(ex))

# Generated at 2022-06-20 16:39:01.147949
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    obj = Version()
    assert obj.__ge__(obj) == NotImplemented


# Generated at 2022-06-20 16:39:06.245303
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    import unittest

    # Basic sanity tests
    v1 = LooseVersion('2.2.alpha')
    assert(str(v1) == '2.2.alpha')

    v2 = LooseVersion('2.2.beta5')
    assert(str(v2) == '2.2.beta5')

    v3 = LooseVersion('2.2.beta5')
    assert(str(v2) == str(v3))

    # Test sorting
    vlist = [LooseVersion('2.1'),
             LooseVersion('2.2.alpha'),
             LooseVersion('1.3.3'),
             LooseVersion('1.3.10'),
             ]
    vlist.sort()

# Generated at 2022-06-20 16:39:12.240915
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion('1.2.3')
    assert lv.version == (1, 2, 3)
    lv = LooseVersion('1.2a3')
    assert lv.version == (1, 2, 'a', 3)
    lv = LooseVersion('1.2b3')
    assert lv.version == (1, 2, 'b', 3)

# end class LooseVersion

__version__ = '1.0'



# Generated at 2022-06-20 16:39:15.407486
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    StrictVersion('1.2.3')
    StrictVersion('1.2')
    StrictVersion('1')
    StrictVersion('1.2.3.4')


# Generated at 2022-06-20 16:39:20.051444
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from nose.tools import ok_
    from distutils.version import Version

    ok_(repr(Version("1.2.3")) == "Version ('1.2.3')")
    ok_(repr(Version("1.2.3.4")) == "Version ('1.2.3.4')")




# Generated at 2022-06-20 16:39:23.121305
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version(1)
    w = Version(2)
    print(v.__lt__(w))
    print(v.__lt__(1))

test_Version___lt__()


# Generated at 2022-06-20 16:39:38.786311
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert str(Version("1.1")) == "1.1"

# Generated at 2022-06-20 16:39:40.803371
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """Unit test for method __str__ of class StrictVersion"""
    import distutils.version
    v = distutils.version.StrictVersion("1.0.4b1")
    assert str(v) == "1.0.4b1"


# Generated at 2022-06-20 16:39:49.532473
# Unit test for method __le__ of class Version
def test_Version___le__():
    class subclass(Version):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
            self.d = 4
            self.e = 5
            self.f = 6
            self.g = 7
            self.h = 8
            self.i = 9
    inst = subclass()
    assert inst <= 1
    assert inst <= 2
    assert inst <= 3
    assert inst <= 4
    assert inst <= 5
    assert inst <= 6
    assert inst <= 7
    assert inst <= 8
    assert inst <= 9
    assert inst <= 10
    assert inst <= 11
    assert inst <= 12
    assert inst <= 13
    assert inst <= 14
    assert inst <= 15
    assert inst <= 16
    assert inst <= 17
    assert inst <= 18
    assert inst <= 19


# Generated at 2022-06-20 16:39:52.435673
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    client = Version()
    client._cmp = lambda other: 1
    assert client.__lt__(None) == False
    client._cmp = lambda other: NotImplemented
    assert client.__lt__(None) == NotImplemented
    client._cmp = lambda other: -1
    assert client.__lt__(None) == True

# Generated at 2022-06-20 16:40:01.490759
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("1.2.3")
    assert v.version == (1,2,3)
    assert v.prerelease is None
    v = StrictVersion("1.2.3a4")
    assert v.version == (1,2,3)
    assert v.prerelease == ('a', 4)
    v = StrictVersion("1.2.3b1")
    assert v.version == (1,2,3)
    assert v.prerelease == ('b', 1)
    v = StrictVersion("1.2")
    assert v.version == (1,2,0)
    assert v.prerelease is None
    v = StrictVersion("1.2a4")
    assert v.version == (1,2,0)
    assert v.prerelease == ('a', 4)


# Generated at 2022-06-20 16:40:05.457459
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Just try to create version numbers in all ways we expect to parse:
    # by a tuple, a string, a LooseVersion instance, whatever
    try:
        LooseVersion((1, 2, 3))
        LooseVersion(1, 2, 3)
        LooseVersion("1.2.3")
        LooseVersion(LooseVersion("1.2.3"))
    except:
        raise AssertionError("error parsing LooseVersion number")


# Generated at 2022-06-20 16:40:07.263679
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    __test__["Version"] = Version
    test = Version("1.0")
    print(repr(test))
    print(test)

# Generated at 2022-06-20 16:40:13.458801
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert not Version(vstring="2.9") > Version(vstring="2.8")
    assert not Version(vstring="2.9.0") > Version(vstring="2.9")
    assert Version(vstring="2.9") > Version(vstring="2.8")
    assert Version(vstring="2.9.0") > Version(vstring="2.9")
    assert Version(vstring="2.9.9.9") > Version(vstring="2.9.9")
    assert not Version(vstring="2.9.9.9") > Version(vstring="2.9.9.9")

# Generated at 2022-06-20 16:40:23.280352
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2
    assert not v1 != v2

    assert not v1 < v2
    assert v1 <= v2
    assert not v1 > v2
    assert v1 >= v2

    assert v2 < v1
    assert v2 <= v1
    assert not v2 > v1
    assert not v2 >= v1

    assert not v1 == 2
    assert v1 != 2
    assert not v1 < 2
    assert v1 <= 2
    assert v1 > 2
    assert not v1 >= 2



# Generated at 2022-06-20 16:40:28.394987
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    # Success #1
    v1 = Version("1.0")
    v2 = Version("0.99")
    assert v1 < v2

    # Success #2
    v1 = Version("1.1")
    v2 = Version("0.99")
    assert v1 > v2

# Generated at 2022-06-20 16:40:56.359881
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert str(LooseVersion('')) == '', "invalid initialization of LooseVersion instance"


# Generated at 2022-06-20 16:40:57.695686
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('2.2')


# Generated at 2022-06-20 16:41:04.865180
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # test invalid versions
    # FIXME: need to make sure they're truly invalid according to
    # LooseVersion's rules -- perhaps test_LooseVersion needs to be
    # modified to catch some of these cases.
    INVALID_VERSIONS = [
        '1.2.3.4',
        '$Revision$',
        '1.2a3.4',
        '1.2a4b',
        '1.2b1.4'
        ]
    for ver in INVALID_VERSIONS:
        lv = LooseVersion(ver)
        assert lv.version == [], \
               "invalid version %s should match []" % ver

    # now try valid versions

# Generated at 2022-06-20 16:41:12.905245
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import sys
    v = Version('1.2.0')
    assert v >= Version('1.2.0')
    assert v >= '1.2.0'
    assert v >= 1.2
    assert v >= (1,2,0)
    assert v >= sys.version_info
    assert v >= (1,2,0,'alpha',1)


# Generated at 2022-06-20 16:41:20.799715
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-20 16:41:22.448490
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    o = Version()
    assert(v <= o)



# Generated at 2022-06-20 16:41:28.063203
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.3.3')
    assert v == Version('1.3.3')
    assert v == '1.3.3'
    assert v == '1.3.3.0'
    assert not (v == Version('1.4.4'))
    assert not (v == '1.4.4')
    assert not (v == '1.4.4.0')

# Generated at 2022-06-20 16:41:38.970458
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from ansible.module_utils._text import to_native
    import pytest

    for v in ('0.4.0', '0.4.1', '1.0.0'):
        v1 = Version(v)
        v2 = Version(v)

        assert v1 == v2
        assert not (v1 != v2)

        assert not (v1 < v2)
        assert (v1 <= v2)
        assert not (v1 > v2)
        assert (v1 >= v2)

    v1 = Version('0.4.1')
    v2 = Version('0.4')

    assert not (v1 == v2)
    assert v1 != v2

    assert not (v1 < v2)
    assert not (v1 <= v2)
    assert v1 > v2


# Generated at 2022-06-20 16:41:49.396517
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import copy
    import unittest
    try:
        import typing
    except ImportError:
        class Parent(object):
            pass
        class Preference(Parent):
            pass
    else:
        class Parent(typing.NamedTuple):
            pass
        class Preference(Parent):
            pass
    # Set up class StrictVersion and constants
    class StrictVersion(StrictVersion):
        def __init__(self, version, prerelease=None):
            super(StrictVersion, self).__init__(version)
            self.prerelease = prerelease
    class Preference(Preference):
        def __init__(self, name, version, prerelease=None):
            super(Preference, self).__init__(name, version)
            self.prerelease = prerelease

# Generated at 2022-06-20 16:42:00.159463
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:42:36.985521
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import types
    # normal version strings
    l = LooseVersion("1.1")
    assert type(l.version[0]) == types.IntType
    l = LooseVersion("2.2.2")
    assert type(l.version[0]) == types.IntType
    # odd ones like 1.3foo should be strings
    l = LooseVersion("1.3foo")
    assert type(l.version[0]) == types.IntType
    assert type(l.version[1]) == types.StringType
    l = LooseVersion("2.2.2alpha")
    assert type(l.version[0]) == types.IntType
    assert type(l.version[1]) == types.IntType
    assert type(l.version[2]) == types.StringType

# Generated at 2022-06-20 16:42:45.273380
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    test_cases = {
        'Version()': Version(),
        'Version("1")': Version("1"),
    }

    def test_success(left, right):
        if left < right:
            return True
        return False

    def test_failure(left, right):
        if left < right:
            return False
        return True

    for key in test_cases:
        for left in test_cases:
            for right in test_cases:
                if key == left == right:
                    continue
                elif test_success(test_cases[left], test_cases[right]):
                    continue
                elif test_failure(test_cases[left], test_cases[right]):
                    continue
                else:
                    return False
    return True


# Generated at 2022-06-20 16:42:57.135816
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-20 16:43:07.630397
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    t = LooseVersion("1.2")
    assert t.version == [1,2]
    t = LooseVersion("1.2.3")
    assert t.version == [1,2,3]
    t = LooseVersion("1.2a3")
    assert t.version == [1,2,'a',3]
    t = LooseVersion("1.2.3.4.5")
    assert t.version == [1,2,3,4,5]
    t = LooseVersion("1.2b3.4rc5.6")
    assert t.version == [1,2,'b',3,4,'rc',5,6]
    t = LooseVersion("0.0.0")
    assert t.version == [0,0,0]

# Generated at 2022-06-20 16:43:14.272814
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Test ``Version`` ``__lt__`` method."""
    actual = Version('1.0.0') < Version('1.1.0')
    assert actual is not None
    actual = Version('1.0.0') < '1.1.0'
    assert actual is not None

# Generated at 2022-06-20 16:43:15.465288
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.0').__eq__(Version('1.0'))


# Generated at 2022-06-20 16:43:21.077614
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion("1.1a.1")
    if lv.version != [1, '1a', 1]:
        return 0

    lv = LooseVersion("1.2.3")
    if lv.version != [1,2,3]:
        return 0


# Generated at 2022-06-20 16:43:30.615967
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    from unittest import TestCase

    class Test(TestCase):

        def test_prerelease(self):
            # Make sure that prereleases compare lower than final releases
            self.assertTrue(StrictVersion('1.2a1') < StrictVersion('1.2'))
            self.assertTrue(StrictVersion('1.2.a1') < StrictVersion('1.2'))
            self.assertTrue(StrictVersion('1.2a1') < StrictVersion('1.2.0'))
            self.assertTrue(StrictVersion('1.2.a1') < StrictVersion('1.2.0'))
            self.assertTrue(StrictVersion('1.2a1') < StrictVersion('1.2.b1'))

# Generated at 2022-06-20 16:43:33.504465
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    test = v.__ge__('1')
    assert test == NotImplemented


# Generated at 2022-06-20 16:43:37.469143
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
  ver = "1.0.0"
  try:
    StrictVersion(ver).parse(ver)
  except ValueError:
    print("StrictVersion_parse FAILED")
    return False
  return True


print("StrictVersion_parse:", test_StrictVersion_parse())

# Generated at 2022-06-20 16:44:24.259379
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # '''
    # test __str__
    pass

# Generated at 2022-06-20 16:44:24.943474
# Unit test for method __gt__ of class Version
def test_Version___gt__(): pass

# Generated at 2022-06-20 16:44:32.477382
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Ensure that LooseVersion tolerates things like spaces, leading zeroes
    # and non-alpha characters in the version string

    assert(LooseVersion(" 0.9.9") == LooseVersion("0.9.9"))
    assert(LooseVersion(" 0.9.9 ") == LooseVersion("0.9.9"))
    assert(LooseVersion("0.9.9 ") == LooseVersion("0.9.9"))
    assert(LooseVersion(" 0.9.9") == LooseVersion("0.9.9"))
    assert(LooseVersion("00.009.009") == LooseVersion("0.9.9"))
    assert(LooseVersion(" 0.9.9") > LooseVersion("0.9.8"))

# Generated at 2022-06-20 16:44:39.209179
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # proper string
    assert LooseVersion('1.0').version == [1, 0]
    assert LooseVersion('hello.42.1').version == ['hello', 42, 1]
    assert LooseVersion('foo.1.2.3.4.5.6.7').version == ['foo', 1, 2, 3, 4, 5, 6, 7]

    # garbage string
    assert LooseVersion('abcdefg').version == ['abcdefg']


# Generated at 2022-06-20 16:44:40.399380
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()

# Generated at 2022-06-20 16:44:51.042689
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Version(string) should be parsed
    assert LooseVersion("1.2.3") == (1, 2, 3)
    assert LooseVersion("1.2.0") == (1, 2)
    assert LooseVersion("1.2") == (1, 2)
    assert LooseVersion("1.2f") == (1, 2, 'f')
    assert LooseVersion("1.2.3.4") == (1, 2, 3, 4)
    assert LooseVersion("1.2.3.4.5") == (1, 2, 3, 4, 5)
    assert LooseVersion("1.2.0.4.5") == (1, 2, 0, 4, 5)

    # Version(integer) should be used as-is
    assert LooseVersion(1) == (1,)

# Generated at 2022-06-20 16:44:52.648538
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    pass


# Generated at 2022-06-20 16:44:58.353500
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Check that we can create StrictVersion instance
    StrictVersion("1.1")
    # Check that exception is raised if version number is invalid
    try:
        StrictVersion("1.2.rc2")
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")


# Generated at 2022-06-20 16:45:01.786812
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v < "1"

# Generated at 2022-06-20 16:45:12.233807
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('1.0') == LooseVersion('1.0')
    assert LooseVersion('1.0') <  LooseVersion('2.0')
    assert LooseVersion('1.0') <  LooseVersion('1.1')
    assert LooseVersion('1.0') <  LooseVersion('1.0.1')

    assert LooseVersion('1.1') <  LooseVersion('1.2.1')
    assert LooseVersion('1.2.1') > LooseVersion('1.1')
    assert LooseVersion('1.2.1') > LooseVersion('1.2')
    assert LooseVersion('1.2.1') > LooseVersion('1.2.0')

    assert LooseVersion('1.1rc1') > LooseVersion('1.1b2')

# Generated at 2022-06-20 16:45:53.126072
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    from distutils2.compat import unittest2 as unittest

    class VersionTestCase(unittest.TestCase):

        def test_operator(self):
            a = Version('1.0')
            b = Version('1.0')
            self.assertTrue(a <= b)
            self.assertTrue(a != b)
            self.assertTrue(a <= b)
            self.assertTrue(a >= b)
            self.assertFalse(a > b)
            self.assertFalse(a < b)
            self.assertFalse(a == b)

    unittest.main()
test_Version___le__()
test_Version___le__()

# Generated at 2022-06-20 16:45:57.200678
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    for test in [
        (StrictVersion('6.5'), '6.5'),
        (StrictVersion('6.5.0'), '6.5.0'),
        (StrictVersion('6.5.0a1'), '6.5.0a1'),
        (StrictVersion('6.5.0b1'), '6.5.0b1'),
        (StrictVersion('6.5.0a12'), '6.5.0a12'),
        (StrictVersion('6.5.0b12'), '6.5.0b12'),
        (StrictVersion('1'), '1.0.0'),
        (StrictVersion('1.0'), '1.0.0'),
    ]:
        assert str(test[0]) == test[1]


# Generated at 2022-06-20 16:45:58.379761
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('0.1')
    v2 = Version('0.2')
    assert v1 < v2


# Generated at 2022-06-20 16:46:01.984054
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version("1.0.0")
    assert v > "0.9"
    assert v > "0.9.0"