

# Generated at 2022-06-20 16:36:19.483978
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    sv_list = [StrictVersion("1.3a3"),
               StrictVersion("0.5.1"),
               StrictVersion("2.2b1"),
               StrictVersion("2.2"),
               StrictVersion("2.2.1a2")]

    # test that we can at least create these without errors
    sv_list = [StrictVersion("1.3a3"),
               StrictVersion("0.5.1"),
               StrictVersion("2.2b1"),
               StrictVersion("2.2"),
               StrictVersion("2.2.1a2")]

    assert len(sv_list) == 5

    # test sorting
    sv_list.sort()

# Generated at 2022-06-20 16:36:21.440471
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2.3.4')
    r = v.__repr__()
    print(r)

# Generated at 2022-06-20 16:36:24.845576
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from lib2to3.pgen2 import token

    version = Version()
    version.version = '0.9'
    token.tokenize_loop.tokens[0].filename = None
    expected = False
    actual = version.__gt__('2.0')
    assert expected == actual

# Generated at 2022-06-20 16:36:27.883177
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    version = LooseVersion("3.3")

    try:
        version.__str__()
    except NotImplementedError:
        fail("Method __str__ failed")
    except:
        raise

# Generated at 2022-06-20 16:36:33.670628
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion(1).__str__() == '1'
    assert StrictVersion(1, 2).__str__() == '1.2'
    assert StrictVersion(1, 2, 0).__str__() == '1.2'
    assert StrictVersion(1, 2, 3).__str__() == '1.2.3'
    assert StrictVersion(1, 2, 3, 'a', 4).__str__() == '1.2.3a4'
    assert StrictVersion(1, 2, 3, 'b', 4).__str__() == '1.2.3b4'


# Generated at 2022-06-20 16:36:42.938955
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3b4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 4)

    v = StrictVersion('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None

    v = StrictVersion('1.2')
    assert v.version == (1, 2, 0)
    assert v.prerelease is None

    try:
        StrictVersion('1')
    except ValueError as e:
        pass
    else:
        raise AssertionError("Did not raise ValueError on invalid StrictVersion")


# Generated at 2022-06-20 16:36:45.247548
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    other = Version()
    c = version._cmp(other)
    assert type(c) is bool
    assert c is NotImplemented


# Generated at 2022-06-20 16:36:55.021926
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test with a string of the description example
    value = "1.5.2b2"
    looseVersion = LooseVersion(value)
    assert(looseVersion.vstring == value)
    assert(looseVersion.version == [1, 5, '2b', 2])

    # Test with a string without special character
    value = "161"
    looseVersion = LooseVersion(value)
    assert(looseVersion.vstring == value)
    assert(looseVersion.version == [161])

    # Test with an empty string
    value = ""
    looseVersion = LooseVersion(value)
    assert(looseVersion.vstring == value)
    assert(looseVersion.version == [])

    # Test with a string which contains special character
    value = "11g"

# Generated at 2022-06-20 16:37:03.875486
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:37:06.507524
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    other = '2.0'
    assert v.__ge__(other) == NotImplemented



# Generated at 2022-06-20 16:37:17.752965
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from types import MethodType
    from types import MethodType
    assert isinstance(Version.__ge__, MethodType)
    pass


# Generated at 2022-06-20 16:37:20.888965
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    obj = LooseVersion('2.2.0')
    assert isinstance(obj, Version)
    assert LooseVersion('2.2.0') == '2.2.0'


# Generated at 2022-06-20 16:37:23.302375
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v1 = LooseVersion('1.5.1')
    assert str(v1) == '1.5.1'



# Generated at 2022-06-20 16:37:25.154244
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    instance = Version()
    assert not hasattr(instance, '__ge__')


# Generated at 2022-06-20 16:37:27.147422
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()
    assert v != "1.0.0"


# Generated at 2022-06-20 16:37:32.099949
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    x = Version('1.0')
    y = Version('2.0')
    z = x > y
    if not isinstance(z, bool):
        raise TypeError
    if z:
        raise Exception
    x = Version('2.0')
    y = Version('1.0')
    z = x > y
    if not isinstance(z, bool):
        raise TypeError

# Generated at 2022-06-20 16:37:39.026320
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    try:
        # Valid version numbers (should not raise an exception):
        StrictVersion("0.4.0")
        StrictVersion("0.5a1")
        StrictVersion("0.5.1")
        StrictVersion("1.0.4a3")

        # Invalid version numbers
        StrictVersion("1.0")
        StrictVersion("1.1.2.3")
        StrictVersion("1.2.a3")
    except ValueError:
        pass



# Generated at 2022-06-20 16:37:43.406849
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    class _Version(Version):
        def _cmp(self, other):
            return 1

    ver = _Version('1.0a')
    assert(ver > None)
    assert(not ver > '0.0')
    assert(not ver > ver)


# Generated at 2022-06-20 16:37:44.450203
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= ""


# Generated at 2022-06-20 16:37:46.673475
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    d = Version()
    e = Version()
    assert d == e, 'd == e'



# Generated at 2022-06-20 16:38:00.134609
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # need a better test suite, with cases to test all of the features
    # of the LooseVersion class.
    lv = LooseVersion

    assert lv("1.2") < lv("2.2"), "simple numeric < failed"
    assert lv("1.2") < lv("1.2.5"), "simple numeric < failed"
    assert lv("2.2") > lv("1.2"), "simple numeric > failed"
    assert lv("1.2") == lv("1.2"), "simple numeric == failed"
    assert lv("1.2") != lv("1.2.1"), "simple numeric != failed"

    # catch a comparison between string and numeric types
    assert lv("2.2") > lv("1.2a3"), "simple numeric > failed"
    assert l

# Generated at 2022-06-20 16:38:05.893967
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Check that interface is as expected:
    #   __init__ (string) - create and take same action as 'parse'
    #                       (string parameter is optional)
    #   parse (string)    - convert a string representation to whatever
    #                       internal representation is appropriate for
    #                       this style of version numbering
    #   __str__ (self)    - convert back to a string; should be very similar
    #                       (if not identical to) the string supplied to parse
    #   __repr__ (self)   - generate Python code to recreate
    #                       the instance
    #   _cmp (self, other) - compare two version numbers ('other' may
    #                       be an unparsed version string, or another
    #                       instance of your version class)

    # Test constructor
    #   Default construction
    v = LooseVersion()
   

# Generated at 2022-06-20 16:38:10.298603
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Test for a subclass of class Version
    from distutils.version import StrictVersion as SV
    obj = SV('2.2.0')
    # Test for an instance of Version
    obj2 = Version('2.1')
    assert repr(obj) == 'StrictVersion (\'2.2.0\')'
    assert repr(obj2) == 'Version (\'2.1\')'


# Generated at 2022-06-20 16:38:15.981592
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    s = 'test.test_version.StrictVersion'
    with open('StrictVersion.txt', 'r') as f:
        for line in f:
            (version, expected) = line.split()
            a = StrictVersion(version)
            b = str(a)
            assert b == expected, "'%s.__str__(%s) == %s', expected %s" % (s, version, b, expected)


# Generated at 2022-06-20 16:38:23.792920
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    """Test construction of class LooseVersion."""

    def test(vstring, components):
        lv = LooseVersion(vstring)
        assert (lv.version == components), \
               "'%s' -> '%s' != '%s'" % (vstring, components, lv.version)

    test('1.5.1', [1, '5', '1'])
    test('1.5.2b2', [1, '5', '2b2'])
    test('161', [161])
    test('3.10a', [3, '10a'])
    test('8.02', [8, '02'])
    test('3.4j', [3, '4j'])
    test('1996.07.12', [1996, '07', '12'])

# Generated at 2022-06-20 16:38:31.071615
# Unit test for constructor of class Version
def test_Version():
    """Make sure that class Version is properly initialized by its
    constructor."""
    v = Version()
    assert str(v) == '', 'str(Version()) should return ""'
    v = Version('1.2')
    assert str(v) == '1.2', 'str(Version("1.2")) should return "1.2"'
    assert repr(v) == "Version ('1.2')", \
           'repr(Version("1.2")) should return "Version (\'1.2\')"'
    assert v == '1.2', 'Version("1.2") should equal "1.2"'
    assert not v < '1.2', 'Version("1.2") should not be less than "1.2"'

# Generated at 2022-06-20 16:38:33.941375
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.1')
    assert v > '1'
    assert v >= '1.1'
    assert v >= '1.1.0'



# Generated at 2022-06-20 16:38:35.580712
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    a = LooseVersion("3.4b1")
    assert str(a) == "3.4b1"


# Generated at 2022-06-20 16:38:39.256519
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.2.3')
    assert lv.__str__() == '1.2.3'

# Generated at 2022-06-20 16:38:46.621061
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    test_objects = [StrictVersion("1.2"), StrictVersion("1.2.3"),
        StrictVersion("1.2.3a4")]
    expected_strings = ["1.2", "1.2.3", "1.2.3a4"]
    for (test_object, expected_string) in \
        zip(test_objects, expected_strings):
        test_string = str(test_object)
        if test_string != expected_string:
            print("test_StrictVersion___str__ failed: expected \"%s\", got "
                "\"%s\"" % (expected_string, test_string))
            return

# Generated at 2022-06-20 16:39:02.525781
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def check(self, vstring, expected_version, expected_prerelease):
        self.parse(vstring)
        assert self.version == expected_version, '{0!r} != {1!r}'.format(self.version, expected_version)
        assert self.prerelease == expected_prerelease, '{0!r} != {1!r}'.format(self.prerelease, expected_prerelease)

    # Examples from class docstring
    v = StrictVersion("0.4")
    check(v, (0, 4, 0), None)
    v = StrictVersion("0.4.1")
    check(v, (0, 4, 1), None)
    v = StrictVersion("0.5a1")
    check(v, (0, 5, 0), ('a', 1))

# Generated at 2022-06-20 16:39:05.589203
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    Version('') > Version('')



# Generated at 2022-06-20 16:39:08.087775
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3.4')
    v2 = Version('1.2.3.4')
    assert v1 >= v2



# Generated at 2022-06-20 16:39:09.785726
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert NotImplemented == Version('1.0').__le__('')

# Generated at 2022-06-20 16:39:11.387524
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    import builtins
    v = Version()
    assert repr(v) == "Version ('0')"


# Generated at 2022-06-20 16:39:12.556315
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    

# Generated at 2022-06-20 16:39:23.350633
# Unit test for constructor of class Version
def test_Version():
    assert Version()._cmp(Version('1.3.4')) < 0
    assert Version('1.3.4') == Version('1.3.4')
    assert Version('1.3.4') >= Version('1.3')
    assert Version('1.3.4') > Version('1.3.4a2')
    assert Version()._cmp(Version('1.3.4')) < 0
    assert Version('1.3.4') != Version()
    try:
        Version('no good')
    except ValueError:
        pass
    else:
        raise TestFailed('failed to raise ValueError on invalid input')
    try:
        () >= Version('1.3.4')
    except TypeError:
        pass

# Generated at 2022-06-20 16:39:25.423359
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1.__lt__(v2) == NotImplemented



# Generated at 2022-06-20 16:39:26.818996
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    assert Version('1.0') <= Version('1.0'), "'1.0' <= '1.0' is False"

# Generated at 2022-06-20 16:39:30.291817
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion
    lv('1.2.3')
    lv('a.b.c')
    lv('1.2.3a1')
    lv('a.b.c.1.2')


#######################################################################
# functions that act as interfaces to the above classes


# Generated at 2022-06-20 16:39:50.480852
# Unit test for method __le__ of class Version
def test_Version___le__():
    from copy import deepcopy

    # Testing if __le__ raises error when different type
    with pytest.raises(TypeError):
        assert Version() <= 5
    assert Version() <= Version()

    # Testing if __ge__ raises error when different type
    with pytest.raises(TypeError):
        assert Version() >= 5
    assert Version() >= Version()

    # Testing if __lt__ raises error when different type
    with pytest.raises(TypeError):
        assert Version() < 5
    assert Version() < Version()

    # Testing if __gt__ raises error when different type
    with pytest.raises(TypeError):
        assert Version() > 5
    assert Version() > Version()

    # Testing if __eq__ raises error when different type
    with pytest.raises(TypeError):
        assert Version() == 5


# Generated at 2022-06-20 16:39:51.904814
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == (type(1), NotImplemented)

# Generated at 2022-06-20 16:40:01.036853
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-20 16:40:06.393462
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    for str, result in (_spec, _parts):
        lv = LooseVersion(str)
        assert lv.version == result, \
               "failed to parse: '%s' != '%s'" % (lv.version, result)
        lv = LooseVersion(str)
        s = '%s' % lv
        assert s == str, \
               "failed to reconstruct: '%s' != '%s'" % (s, str)


# Generated at 2022-06-20 16:40:14.066361
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # The following are examples of strings that __repr__ should
    # transform into 'LooseVersion('0.4')'
    example_strings = '0.4', '0.4.1', '0.4.2b', '0.4.2b1', '1.0'
    # The following are examples of strings that __repr__ should
    # transform into 'LooseVersion('0.4.1.1')'
    example_strings_with_dots = '0.4.1.1'
    # The following are examples of strings that __repr__ should
    # transform into 'LooseVersion('0.4rc1')'
    example_strings_with_char = '0.4rc1'

# Generated at 2022-06-20 16:40:25.860652
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = StrictVersion()

    # Test invalid version numbers
    err_msg = re.escape(r"invalid version number '1'")
    with pytest.raises(ValueError, match=err_msg):
        s.parse('1')
    err_msg = re.escape(r"invalid version number '2.7.2.2'")
    with pytest.raises(ValueError, match=err_msg):
        s.parse('2.7.2.2')
    err_msg = re.escape(r"invalid version number '1.3.a4'")
    with pytest.raises(ValueError, match=err_msg):
        s.parse('1.3.a4')
    err_msg = re.escape(r"invalid version number '1.3pl1'")


# Generated at 2022-06-20 16:40:33.773537
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v = LooseVersion("1.0")
    assert str(v) == "1.0"
    assert repr(v) == "LooseVersion ('1.0')"

    v = LooseVersion("1.1.1")
    assert str(v) == "1.1.1"
    assert repr(v) == "LooseVersion ('1.1.1')"

    v = LooseVersion("1.1a1")
    assert str(v) == "1.1a1"
    assert repr(v) == "LooseVersion ('1.1a1')"



# Generated at 2022-06-20 16:40:35.197424
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = version.Version('100')
    assert v == '100'


# Generated at 2022-06-20 16:40:37.606395
# Unit test for constructor of class Version
def test_Version():
    try:
        Version()
        Version("2.2.1")
    except:
        return 'Fail'
    else:
        return 'Pass'



# Generated at 2022-06-20 16:40:38.913598
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.0') == Version('1.0')


# Generated at 2022-06-20 16:40:57.822111
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("1.0")
    v2 = Version("2.0")
    if not v1 <= v2:
        print("test_Version___le__: FAILED")
        return
    if not v1 <= "2.0":
        print("test_Version___le__: FAILED")
        return
    print("test_Version___le__: PASSED")


# Generated at 2022-06-20 16:40:59.834627
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.1')
    v2 = Version('1.2')
    assert(v1 < v2)


# Generated at 2022-06-20 16:41:09.663459
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Invalid versions
    t1 = "1.3.a4"
    t2 = "1.3pl1"
    t3 = "1.3c4"

    # Valid versions
    t4 = "0.4"
    t5 = "0.4.0"
    t6 = "0.4.1"
    t7 = "0.5a1"
    t8 = "0.5b3"
    t9 = "0.5"
    t10 = "0.9.6"
    t11 = "1.0"
    t12 = "1.0.4a3"
    t13 = "1.0.4b1"
    t14 = "1.0.4"


# Generated at 2022-06-20 16:41:11.160957
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= Version()

# Generated at 2022-06-20 16:41:17.161230
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """Unit test for method __str__ of class StrictVersion

    """
    v = StrictVersion("1.0.4b1")
    assert str(v) == "1.0.4b1"
    v = StrictVersion("1.0.4")
    assert str(v) == "1.0.4"
    v = StrictVersion("1.0")
    assert str(v) == "1.0"
    v = StrictVersion("1.0b1")
    assert str(v) == "1.0b1"



# Generated at 2022-06-20 16:41:27.893699
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.1')
    assert v.version == (1, 1, 0)  # and v.prerelease is None
    v = StrictVersion('0.4.1')
    assert v.version == (0, 4, 1)  # and v.prerelease is None
    v = StrictVersion('1.1a1')
    assert v.version == (1, 1, 0)
    assert v.prerelease == ('a', 1)
    v = StrictVersion('1.1b1')
    assert v.version == (1, 1, 0)
    assert v.prerelease == ('b', 1)
    v = StrictVersion('1.1.dev')
    assert v.version == (1, 1, 0)
    assert v.prerelease == ('dev', 0)
    # Raises

# Generated at 2022-06-20 16:41:38.919854
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    current_version = Version(vstring='0.1a1')

    assert current_version < '0.1a2'
    assert current_version < '0.1a10'
    assert current_version < '0.1'
    assert current_version < '0.1b1'
    assert current_version < '0.1post4'
    assert current_version < '0.1.dev4'
    assert current_version < '0.1.post4.dev4'
    assert current_version < '0.1.post4.dev4.1.post4.dev4'
    assert current_version < '0.1.post4.dev4.1.post4.dev4.post4.dev4'

# Generated at 2022-06-20 16:41:39.981419
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3a4')
    assert v is not None


# Generated at 2022-06-20 16:41:41.286351
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.2')
    v2 = Version('1.2')
    assert ( v1 == v2 )


# Generated at 2022-06-20 16:41:48.488463
# Unit test for method __le__ of class Version
def test_Version___le__():
    import pytest

    assert Version('1.0').__le__('1.0') is True
    assert Version('1.0').__le__('2.0') is True
    assert Version('2.0').__le__('1.0') is False
    assert Version('1.0').__le__(Version('1.0')) is True
    assert Version('1.0').__le__(Version('2.0')) is True
    assert Version('2.0').__le__(Version('1.0')) is False



# Generated at 2022-06-20 16:42:17.336584
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    __test_LooseVersion_order()
    __test_LooseVersion_zero()



# Generated at 2022-06-20 16:42:28.223453
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    import os
    import tempfile

    class Version_class(Version):

        def __init__(self, *args, **kwargs):
            self._init(*args, **kwargs)

        def _init(self, *args, **kwargs):
            Version.__init__(*(self,) + args, **kwargs)

    # Not really testing the implementation, just making sure the interface is
    # there.
    with tempfile.NamedTemporaryFile(delete=False) as config_file:
        config_file.write(b'[defaults]\nroles_path = roles\ncallback_whitelist = profile_tasks')
        config_file.flush()
        config_file_name = config_file.name


# Generated at 2022-06-20 16:42:35.571935
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    major_minor = "1.2"
    major_minor_patch = "1.2.3"
    major_minor_patch_release = "1.2.3.4"
    major_minor_patch_release_candidate = "1.2.3.4rc5"
    assert Version(major_minor) > major_minor_patch
    assert Version(major_minor) > major_minor_patch_release
    assert Version(major_minor) > major_minor_patch_release_candidate
    assert Version(major_minor_patch) > major_minor_patch_release
    assert Version(major_minor_patch) > major_minor_patch_release_candidate
    assert Version(major_minor_patch_release) > major_minor_patch_release_

# Generated at 2022-06-20 16:42:46.300825
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from _compat import _check_mixin_compatibility

    class Derived(Version):
        def __init__(self, vstring=None):
            super(Derived, self).__init__(vstring)

        def parse(self, vstring):
            return

        def _cmp(self, other):
            return NotImplemented

    # Copying the test from Lib/unittest/case.py _assertNestedRaises()
    def assertNestedRaises(exception, callable=None, *args, **kwargs):
        context = _AssertRaisesContext(exception, self)
        if callable is None:
            return context
        with context:
            callable(*args, **kwargs)

    assertNestedRaises(TypeError, Derived().__gt__, 1)



# Generated at 2022-06-20 16:42:57.387086
# Unit test for constructor of class Version
def test_Version():
    v = Version()

# This is the string that starts an extended Python version number.
# An extended Python version number consists of a string following this
# one, which may contain letters, numbers, and/or period and underscore
# characters, followed by an underscore and a string of hex digits.
# The hex string is an MD5 checksum of the previous part of the
# extended version number, in ASCII encoding.

_PEP386_SHORT_VERSION_RE = r'\d+(?:\.\d+)+(?![._])'

# Generated at 2022-06-20 16:43:00.476338
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('')
    v.vstring = "foo"
    assert str(v) == "foo"


# Generated at 2022-06-20 16:43:04.915240
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    __repr__ = LooseVersion('3.3a3').__repr__
    r = __repr__()
    assert r == "LooseVersion ('3.3a3')"



# Generated at 2022-06-20 16:43:15.459170
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # Test for method __repr__ of class LooseVersion
    # Test behavior of __repr__ of LooseVersion
    v = LooseVersion('1.2.3')
    assert v.__repr__() == "LooseVersion ('1.2.3')", v.__repr__()
    v = LooseVersion('1.2.3.4')
    assert v.__repr__() == "LooseVersion ('1.2.3.4')", v.__repr__()



# Generated at 2022-06-20 16:43:17.378866
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert v is not None

# ------------------------------------------------------------------------------



# Generated at 2022-06-20 16:43:26.320431
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-20 16:43:58.653139
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v1.parse('1.2')
    v2 = Version()
    v2.parse('1.2')
    assert v1 == v2

# Generated at 2022-06-20 16:44:11.414414
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-20 16:44:19.681595
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    failed_instances_list = []

# Generated at 2022-06-20 16:44:24.979472
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version('5.5')
    assert(v1.__lt__(v2))
    assert(not v2.__lt__(v1))
    assert(not v1.__lt__(v1))


# Generated at 2022-06-20 16:44:32.508047
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    assert vars(StrictVersion('0.4')) == {
        'version': (0, 4, 0),
        'prerelease': None,
    }
    assert vars(StrictVersion('0.4.0')) == {
        'version': (0, 4, 0),
        'prerelease': None,
    }
    assert vars(StrictVersion('0.4.1')) == {
        'version': (0, 4, 1),
        'prerelease': None,
    }
    assert vars(StrictVersion('0.5a1')) == {
        'version': (0, 5, 0),
        'prerelease': ('a', 1),
    }

# Generated at 2022-06-20 16:44:38.339379
# Unit test for method __repr__ of class Version
def test_Version___repr__():
  # Test the method directly
  v=Version()
  v._Version__class__=Faux
  assert v.__repr__()=="Faux ('None')"
  # Test the method indirectly as part of an expression
  v._Version__class__=Faux
  assert repr(v)=="Faux ('None')"


# Generated at 2022-06-20 16:44:44.593884
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Check that the __lt__() method is provided by the base class and that it
    # just calls _cmp().
    class A(Version):
        def _cmp(self, other):
            return True
    a = A()
    assert(a < 'x')

# Generated at 2022-06-20 16:44:53.422394
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from copy import copy, deepcopy
    from types import ModuleType
    from unittest import TestCase
    from ansible.module_utils._text import to_native, to_text
    m = ModuleType('version_gt')
    try:
        m.__dict__.update(locals())
    except Exception:
        m.__dict__.update(locals() if PY3 else dict([(k, v) for k, v in locals().items() if '__' not in k]))
    exit_vals = {}
    exit_vals[True] = to_text('')
    exit_vals[False] = to_text('FAIL')

    version_tuple = (2, 0, 0, 'final', 0)
    __version__ = '2.0'

# Generated at 2022-06-20 16:44:58.152985
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion("0.01")
    r = repr(lv)
    assert r == "LooseVersion ('0.01')", repr(r)

loose_version = LooseVersion
assert_equal = unittest.TestCase.assertEqual


# Generated at 2022-06-20 16:45:10.285085
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion('1.5.1')

# Generated at 2022-06-20 16:45:54.530318
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # Test case #1
    version = distutils.version.LooseVersion('1.2.2.2a2')
    if version.__repr__() != "LooseVersion ('1.2.2.2a2')":
        return False
    # Test case #2
    version = distutils.version.LooseVersion('2.3.4.5b3')
    if version.__repr__() != "LooseVersion ('2.3.4.5b3')":
        return False
    return True


# Override the built in cmp function to support custom version comparison
# Function returns 1 if the first version is greater, -1 if the second
# version is greater, and 0 if they are equal.  It assumes that the
# strings passed in are valid version strings