

# Generated at 2022-06-20 16:36:13.774910
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    for str_ver, pkg_version in _test_cases:
        v = LooseVersion(str_ver)
        p = pkg_version.parse(str_ver)
        assert v.version == p.version
        assert v.vstring == p.vstring



# Generated at 2022-06-20 16:36:15.105925
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2.2') <= Version('1.2.3')

# Generated at 2022-06-20 16:36:24.798812
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    test_vectors = {
        # input, result of str(StrictVersion(input))
        '0.4': '0.4',
        '1.0': '1.0',
        '1.0.4a3': '1.0.4a3',
        '1.0.4b1': '1.0.4b1',
        '1.0.4': '1.0.4',
        '1.13+': '1.13',
        '1.13++': '1.13',
        '1.2.0': '1.2',
    }


# Generated at 2022-06-20 16:36:33.571994
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion('1.2')
    assert(lv.version == [1, 2])
    assert(str(lv) == '1.2')

    lv = LooseVersion('1.2a')
    assert(lv.version == [1, '2a'])
    assert(str(lv) == '1.2a')

    lv = LooseVersion('1.2a.1')
    assert(lv.version == [1, '2a', 1])
    assert(str(lv) == '1.2a.1')

    lv = LooseVersion('1.2.1a')
    assert(lv.version == [1, 2, '1a'])
    assert(str(lv) == '1.2.1a')


# Generated at 2022-06-20 16:36:38.174681
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Setup
    v = Version()

    # Exercise
    repr_value = repr(v)

    # Verify
    assert repr_value == "<class 'semantic_version.Version'> ('None')"


# Generated at 2022-06-20 16:36:43.286012
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Unit test for method __gt__ of class Version"""
    # Initialize version with a valid version string
    v = Version("1.2.3")

    # Tests
    assert v.__gt__("1.2.3") == False
    assert v.__gt__("1.2.3b1") == True
    assert v.__gt__("1.2.2") == True
    assert v.__gt__("1.3") == False



# Generated at 2022-06-20 16:36:47.000979
# Unit test for method __le__ of class Version
def test_Version___le__():
  # Testing __le__() method of class Version
  #
  # Init a Version object
  
  v = Version()
  assert v
  assert v == v
  assert v <= v
  assert not v < v
  assert v >= v
  assert not v > v


# Generated at 2022-06-20 16:36:51.205299
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert (v1 < v2) == False
    assert (v1 <= v2) == False
    assert (v1 > v2) == False
    assert (v1 >= v2) == False
    assert (v1 == v2) == False

# Generated at 2022-06-20 16:36:54.622470
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    expected = False
    actual = (v1 == v2)
    assert actual == expected


# Generated at 2022-06-20 16:36:57.950512
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.2.3a4")
    assert(v.__str__() == "1.2.3a4")
    v = StrictVersion("1.2.3")
    assert(v.__str__() == "1.2.3")
    v = StrictVersion("1.2a4")
    assert(v.__str__() == "1.2a4")


# Generated at 2022-06-20 16:37:14.716201
# Unit test for method __le__ of class Version
def test_Version___le__():
    from __future__ import annotations
    # Test when self._cmp returns True
    from distutils.version import Version
    import builtins
    builtins.__dict__['_dummy'] = 1
    v = Version('1.0.0')
    builtins.__dict__['_dummy'] = 0

# Generated at 2022-06-20 16:37:17.502452
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == 0, "Version.__init__"


# Generated at 2022-06-20 16:37:28.175610
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import sys

    try:
        assert (StrictVersion("1.3.0").__str__() == "1.3.0")
    except AssertionError:
        print("AssertionError failed" +
              sys.exc_info()[0] +
              "occurred.")
    else:
        print("assert (StrictVersion(\"1.3.0\").__str__() == " +
              "\"1.3.0\") passed.")

    try:
        assert (StrictVersion("1.3").__str__() == "1.3.0")
    except AssertionError:
        print("AssertionError failed" +
              "occurred.")

# Generated at 2022-06-20 16:37:30.761018
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    expected = "LooseVersion ('1.0')"
    actual = repr(LooseVersion('1.0'))
    assert expected == actual, 'got: %s' % actual



# Generated at 2022-06-20 16:37:42.546998
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vstring in ['0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3',
                    '0.5', '0.9.6', '1.0', '1.0.4a3', '1.0.4b1',
                    '1.0.4']:
        StrictVersion(vstring)

    try:
        StrictVersion('1')
    except ValueError:
        pass
    else:
        raise AssertionError("Failed to raise ValueError for '1'")

    try:
        StrictVersion('2.7.2.2')
    except ValueError:
        pass
    else:
        raise AssertionError("Failed to raise ValueError for '2.7.2.2'")


# Generated at 2022-06-20 16:37:44.853267
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert "%s ('%s')" % ('Version', str('1.2.3')) == 'Version (\'1.2.3\')'



# Generated at 2022-06-20 16:37:47.790058
# Unit test for method __le__ of class Version
def test_Version___le__():
    t = Version()
    try:
        assert t.__le__(None) is NotImplemented
    except AttributeError:
        pass


# Generated at 2022-06-20 16:37:54.344117
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert "1.0" == str(StrictVersion("1.0"))
    assert "1.0" == str(StrictVersion("1.0.0"))
    assert "1.2.3" == str(StrictVersion("1.2.3"))
    assert "1.2.3a1" == str(StrictVersion("1.2.3a1"))
    assert "1.2.3b2" == str(StrictVersion("1.2.3b2"))


# Generated at 2022-06-20 16:38:00.762100
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:38:06.399435
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from distutils.tests import support

# Generated at 2022-06-20 16:38:16.684771
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # init
    l = LooseVersion('1.1')
    # test
    assert l.__str__() == '1.1'
    # cleanup - none necessary



# Generated at 2022-06-20 16:38:27.207299
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    class VersionTest(Version):
        def __init__(self, s):
            Version.__init__(self, s)
        def parse(self, s):
            self.vstring = s
        def __repr__(self):
            return "VersionTest(%s)" % (self.vstring)

    v = VersionTest("1.2.3")
    assert v < VersionTest("2.0")
    #assert v < "1.2.4"  # Does not work
    assert v < VersionTest("1.2.4")
    assert v < VersionTest("1.2.3.0")
    assert not (v < VersionTest("1.2.3"))
    #assert not (v < "1.2.3")  # Does not work
    #assert not (v <= "1.2.3") 

# Generated at 2022-06-20 16:38:36.820042
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3b4')
    assert str(v) == '1.2.3b4'
    assert v._cmp('1.2.3b4') == 0
    assert v._cmp('1.2.3b3') > 0
    assert v._cmp('1.2.3') > 0
    assert v._cmp('1.2.3b5') < 0
    assert v._cmp('1.2.2') < 0
    assert v._cmp('1.2.4') < 0

    v.parse('1.2.3')
    assert str(v) == '1.2.3'
    assert v._cmp('1.2.3') == 0
    assert v._cmp('1.2.3b3') > 0
    assert v._cmp

# Generated at 2022-06-20 16:38:46.867382
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    d = Version('2.2a2.flufl1')
    assert (d == '2.2a2.flufl1')
    assert not (d == '2.2a2.flufl2')
    assert not (d == '2.2a2.flufl10')
    assert not (d == '2.2a2.flufl0')
    assert not (d == '2.2a2')
    assert not (d == '2.2a2.flufla')
    assert not (d == '2.2a2.flufl')
    assert not (d == '2.2a2.flufl.1')
    assert not (d == '2.2a2.flufl1.post2')
    assert not (d == '2.2a2.flufl1.dev3')

# Generated at 2022-06-20 16:38:48.748719
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('2.2beta29')
    if str(lv) != '2.2beta29':
        raise AssertionError("__repr__(LooseVersion('2.2beta29')) returned '%s' instead of '2.2beta29'" % (str(lv)))

# Generated at 2022-06-20 16:38:51.293839
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  v = Version()
  assert v.__ge__("1.10.0")


# Generated at 2022-06-20 16:39:00.970177
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:39:03.987436
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2.3')
    assert repr(v) == repr(eval(repr(v)))
    v = LooseVersion('1.2a3')
    assert repr(v) == repr(eval(repr(v)))
    v = LooseVersion('1.2.1')
    assert repr(v) == repr(eval(repr(v)))
# Test that Version doesn't crash when compared to whatever
# this is

# Generated at 2022-06-20 16:39:06.750960
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version.__ge__(Version(), None) == NotImplemented



# Generated at 2022-06-20 16:39:08.435782
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-20 16:39:30.788791
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import sys
    import unittest
    import test.test_version

    # Correctly parse the version string into a list of components
    lv = LooseVersion("1.5.1")
    assert lv.version == [1,5,1], \
           "Failed to parse 1.5.1 into a list of components"

    lv = LooseVersion("1.5.2b2")
    assert lv.version == [1,5,2,'b',2], \
           "Failed to parse 1.5.2b2 into a list of components"

    lv = LooseVersion("161")
    assert lv.version == [161], \
           "Failed to parse 161 into a list of components"

    lv = LooseVersion("3.10a")

# Generated at 2022-06-20 16:39:34.819336
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('1').__str__() == '1'
    assert LooseVersion('1.1').__str__() == '1.1'
    assert LooseVersion('1.1.1').__str__() == '1.1.1'


# Generated at 2022-06-20 16:39:38.112963
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion("1.0") == "1.0"
    assert StrictVersion("1.0") == (1, 0)
    assert StrictVersion((1, 0)) == (1, 0)
    assert StrictVersion((1, 0)) == "1.0"


# Generated at 2022-06-20 16:39:39.296960
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert (Version() == '')


# Generated at 2022-06-20 16:39:41.499421
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_instance = Version()
    version_instance.__init__()
    version_instance.__gt__(  )


# Generated at 2022-06-20 16:39:50.035073
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    """
    Verify that the StrictVersion instance for a number like '1.2.3' or '1.2'
    is parsed correctly and that the string representation is correct.
    """
    for vstring, version in [('1.2.0', (1, 2, 0)),
                             ('1.2.3', (1, 2, 3)),
                             ('2.0', (2, 0, 0))]:
        try:
            StrictVersion(vstring)
        except ValueError:
            raise AssertionError("%s shouldn't raise ValueError" % vstring)
        else:
            assert StrictVersion(vstring).version == version, (
                '%s is parsed incorrectly' % vstring)

# Generated at 2022-06-20 16:39:53.517767
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert str(v) == ''
    assert repr(v) == "Version ('')"

    w = Version('1.2.3a3')
    assert str(w) == '1.2.3a3'
    assert repr(w) == "Version ('1.2.3a3')"



# Generated at 2022-06-20 16:40:02.376674
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test_cmp(v1, v2, result):
        c = cmp(v1, v2)
        if c != result:
            print('%s cmp %s == %s != %s' % (v1, v2, c, result))
            raise AssertionError

    test_cmp(StrictVersion('1.2.3'), StrictVersion('1.2.3'), 0)
    test_cmp(StrictVersion('1.2.3'), StrictVersion('1.3'), -1)
    test_cmp(StrictVersion('1.2.3'), StrictVersion('1.3.0'), -1)
    test_cmp(StrictVersion('1.2.3'), StrictVersion('1.2.4'), -1)

# Generated at 2022-06-20 16:40:10.583983
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert (Version('1.0') >= Version('1.0'))
    assert (Version('1.0') >= '1.0')
    assert (Version('1.0') >= 0)
    assert (not Version('1.0') >= 1)
    assert (Version('1.0') >= (1, 0))
    assert (Version('1.0') >= (1, 0, 0))
    assert (not Version('1.0') >= (1, 0, 0, 0))
    assert (not Version('1.0') >= (0, 1))
    assert (Version('1.0') >= (1,))


    assert (not Version('1.0') >= Version('1.1'))
    assert (not Version('1.0') >= '1.1')

# Generated at 2022-06-20 16:40:17.092290
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # same as in StrictVersion
    assert str(LooseVersion('1.2')) == '1.2'
    assert str(LooseVersion('1.2a1')) == '1.2a1'
    assert str(LooseVersion('1.2a1.1')) == '1.2a1.1'
    # variant of 1.1.1.1
    assert str(LooseVersion('1.1.1')) == '1.1.1'
    assert str(LooseVersion('1.1.1.1')) == '1.1.1.1'
    # variant of 1.1.1.1.1
    assert str(LooseVersion('1.1.1')) == '1.1.1'

# Generated at 2022-06-20 16:40:54.816352
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    """Test the LooseVersion constructor."""
    version = LooseVersion('1.2')
    assert version.version == [1, 2]
    version = LooseVersion('1.2.3')
    assert version.version == [1, 2, 3]
    version = LooseVersion('1.2.3.4')
    assert version.version == [1, 2, 3, 4]

    version = LooseVersion('1.2.3a')
    assert version.version == [1, 2, 3, 'a']
    version = LooseVersion('1.2.3abc')
    assert version.version == [1, 2, 3, 'abc']

    version = LooseVersion('1.2.3b')
    assert version.version == [1, 2, 3, 'b']

# Generated at 2022-06-20 16:41:03.187325
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """Test the LooseVersion.parse() method

    """
    WrongInstances = [
        None,
        True,
        False,
        {},
        [],
        (),
        42,
        1.2,
        lambda x: x,
        StrictVersion("1.2.3"),
        ]
    for instance in WrongInstances:
        try:
            instance.parse("1.2.3")
            assert True, "this should throw an exception"
        except (AttributeError, TypeError):
            pass
    #
    lv = LooseVersion("1.2.3")
    lv.parse("1.2.3")
    assert (lv.version == [1, 2, 3]), "parsing '1.2.3' failed"
    lv.parse("1.2")

# Generated at 2022-06-20 16:41:10.460899
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    sv = StrictVersion('1.0')

    assert str(sv) == '1.0'

    sv = StrictVersion('1.0.0')
    assert str(sv) == '1.0.0'

    sv = StrictVersion('1.0.0b1')
    assert str(sv) == '1.0.0b1'

    sv = StrictVersion('1.0.0a1')
    assert str(sv) == '1.0.0a1'

    sv = StrictVersion('3.3.5.post1')
    assert str(sv) == '3.3.5.post1'



# Generated at 2022-06-20 16:41:14.577810
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    o = Version()
    s = repr(o)
    s_expect = "Version ('None')"
    assert s == s_expect, repr((s, s_expect))


# Generated at 2022-06-20 16:41:21.444656
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    s = StrictVersion('1.2')
    assert s.version == (1, 2, 0)
    assert s.prerelease is None

    s = StrictVersion('1.2.3.4')
    assert s.version == (1, 2, 3)
    assert s.prerelease is None

    s = StrictVersion('1.2.0')
    assert s.version == (1, 2, 0)
    assert s.prerelease is None

    s = StrictVersion('1.2a1')
    assert s.version == (1, 2, 0)
    assert s.prerelease == ('a', 1)

    s = StrictVersion('1.2b3')
    assert s.version == (1, 2, 0)
    assert s.prerelease == ('b', 3)

    s = StrictVersion

# Generated at 2022-06-20 16:41:27.989543
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion('1.2.3')
    if str(lv) != '1.2.3':
        raise AssertionError('1.2.3 != %s' % str(lv))

    lv = LooseVersion('a.b.c')
    if str(lv) != 'a.b.c':
        raise AssertionError('a.b.c != %s' % str(lv))

# Generated at 2022-06-20 16:41:31.881831
# Unit test for constructor of class Version
def test_Version():
    x = Version('1.45')
    assert x.__str__() == '1.45'
    assert x._version == ('1', '45')


# Generated at 2022-06-20 16:41:34.389518
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v._cmp(None) is NotImplemented
test_Version___lt__()


# Generated at 2022-06-20 16:41:40.613958
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from unittest import TestCase, TestLoader, TextTestRunner, TestSuite

    class Version___lt___TestCase(TestCase):
        def setUp(self):
            self.version_0_1 = Version('0.1')
            self.version_0_1_1 = Version('0.1.1')

        def test_Version___lt___TestCase_test_0(self):
            # Test comparisons
            assert self.version_0_1 < self.version_0_1_1

            assert self.version_0_1_1 != self.version_0_1

            assert self.version_0_1_1 != '0.1'

    suite = TestSuite()
    suite.addTest(Version___lt___TestCase('test_0'))

    runner = TextTestRunner()

# Generated at 2022-06-20 16:41:41.896703
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    sample = LooseVersion('0.2.3')
    assert repr(sample) == "LooseVersion ('0.2.3')"


# Generated at 2022-06-20 16:42:44.539044
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3a2')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 2)
# End unit test


# Generated at 2022-06-20 16:42:51.372799
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Test method __repr__ of class Version"""
    # Setup
    version = Version('0.9')
    
    # Exercise
    result = version.__repr__()
    
    # Verify
    assert type(result) == str
    assert result == "Version ('0.9')"
    

# Generated at 2022-06-20 16:42:55.815830
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils2 import version

    ver1 = version.Version("1.3.0")
    ver2 = version.Version("1.4.4")
    ver3 = version.Version("1.4.4")

    assert ver1 != ver2
    assert ver2 == ver3


# Generated at 2022-06-20 16:42:59.979125
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v1 = Version()
    v1_repr = v1.__repr__()
    assert v1_repr == "Version ('0.0')"


# Generated at 2022-06-20 16:43:04.638142
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    gt = Version_Version___gt__()
    gt._cmp = lambda x, y: 42
    assert gt.__gt__('foo') is True
    gt._cmp = lambda x, y: -42
    assert gt.__gt__('foo') is False



# Generated at 2022-06-20 16:43:13.248207
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """ Test __str__.
    """
    import unittest

    class Test_LooseVersion__str___(unittest.TestCase):
        def test___str___(self):
            self.assertEqual(LooseVersion("1.2.3").__str__(), "1.2.3")
    unittest.main()


# Generated at 2022-06-20 16:43:16.462737
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    version = Version()
    version.parse("1.2.3")
    assert repr(version) == "Version ('1.2.3')"
    assert str(version) == "1.2.3"

# Generated at 2022-06-20 16:43:19.463890
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    p = StrictVersion("2.7.2.2")
    assert p.version == (2, 7, 2, 2)


# Generated at 2022-06-20 16:43:23.743423
# Unit test for constructor of class Version
def test_Version():
    v = Version('0.4.0')
    assert str(v) == '0.4.0'

    # no vstring:
    v = Version()
    assert str(v) == ''



# Generated at 2022-06-20 16:43:31.536589
# Unit test for method __eq__ of class Version

# Generated at 2022-06-20 16:46:04.268243
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring):
        # parse the version string
        version = StrictVersion(vstring)

        # make sure that the string we used to create the version
        # is the same one that the version instance prints out
        # (minus leading 'v' -- I keep it in the test version
        # strings for my own sanity)
        assert str(version)[1:] == vstring, \
               "str(%s) != %s" % (version, vstring)

        # Make sure that the version instance can be used for comparisons
        # properly