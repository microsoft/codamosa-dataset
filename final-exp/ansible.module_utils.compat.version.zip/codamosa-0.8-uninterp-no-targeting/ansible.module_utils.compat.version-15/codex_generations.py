

# Generated at 2022-06-20 16:36:21.008859
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Version(string=None)
    #
    # Abstract base class for version numbering classes.  Just provides
    # constructor (__init__) and reproducer (__repr__), because those
    # seem to be the same for all version numbering classes; and route
    # rich comparisons to _cmp.

    # test for method '__ge__'

    # test if __ge__ gives the correct result

    from distutils.version import StrictVersion

    a = StrictVersion('1.2.3')
    b = StrictVersion('1.2.4')
    c = StrictVersion('1.2.1')
    d = StrictVersion('1.2.4')

    assert (a >= a)
    assert not (a >= b)
    assert (b >= a)
    assert (b >= c)

# Generated at 2022-06-20 16:36:29.355844
# Unit test for method __le__ of class Version
def test_Version___le__():
    method = object.__le__
    method = getattr(Version, method.__name__, method)
    assert "__le__" == method.__name__
    assert method.__qualname__ == "Version.__le__"
    assert "Compare the current instance with another instance of the same class (or a subclass)." == method.__doc__
    assert method.__module__ == __name__
    assert method.__defaults__ == (None,)
    assert not method.__code__.co_kwonlyargs
    assert not method.__code__.co_varnames
    assert not method.__annotations__
    assert not method.__dict__
    assert not method.__kwdefaults__

# Generated at 2022-06-20 16:36:39.944536
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    V = StrictVersion

    assert V("5.5").version == (5, 5, 0)
    assert V("5.5").prerelease == None

    assert V("5.5a1").version == (5, 5, 0)
    assert V("5.5a1").prerelease == ('a', 1)

    assert V("5.5b3").version == (5, 5, 0)
    assert V("5.5b3").prerelease == ('b', 3)

    assert V("5.5.6").version == (5, 5, 6)
    assert V("5.5.6").prerelease == None

    assert V("5.5.6a3").version == (5, 5, 6)
    assert V("5.5.6a3").prerelease == ('a', 3)


# Generated at 2022-06-20 16:36:42.091045
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    imports = {}
    result = eval(str(StrictVersion("0.4")), imports)
    assert result == StrictVersion("0.4")

# Generated at 2022-06-20 16:36:53.030909
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """Test LooseVersion.parse()"""

    # Should be a no-op:
    lv = LooseVersion()
    lv.parse('0.0')
    assert lv.version == (0,0)

    lv = LooseVersion()
    lv.parse('0.0.0')
    assert lv.version == (0,0,0)

    lv = LooseVersion()
    lv.parse('0.0.0.1.2.3')
    assert lv.version == (0,0,0,1,2,3)

    lv = LooseVersion()
    lv.parse('0.0.0.1.2.3RC4')
    assert lv.version == (0,0,0,1,2,'3RC4')

    lv = Loose

# Generated at 2022-06-20 16:36:55.859310
# Unit test for constructor of class Version
def test_Version():
    for V in Version, StrictVersion, LooseVersion:
        v = V(1, 2)
        assert str(v) == "1.2"

# Utility functions -- not part of the class.

# _cmpkey() is a convenience function that calls str() on an
# object, regardless of its type.

# Generated at 2022-06-20 16:37:04.515306
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import string
    allowed = string.ascii_letters + string.digits + '.-_'
    def _method_test(version, other):
        # Verify that Version('..') == <other> implies Version('') == <other>
        if isinstance(other, str) and set(version).issubset(allowed):
            assert Version('')._cmp(other) == version._cmp(other)
    s = Version('1.2a')
    # Verify that '1.2a' == <other> implies '1a' == <other>
    assert s._cmp('1a') == s._cmp('1.2a')
    for i, eq in enumerate((False, True)):
        assert (s == s) == eq
        assert (s != s) == (not eq)

# Generated at 2022-06-20 16:37:07.556413
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version1 = Version('1.2.3')
    version2 = Version('1.2.4')
    assert version1 < version2

# Generated at 2022-06-20 16:37:14.563864
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('0.4')
    assert v.version == (0, 4, 0)
    assert v.prerelease == None

    v.parse('0.4.0')
    assert v.version == (0, 4, 0)
    assert v.prerelease == None

    v.parse('0.4.1')
    assert v.version == (0, 4, 1)
    assert v.prerelease == None

    v.parse('1.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease == None

    v.parse('1.0.4a3')
    assert v.version == (1, 0, 4)
    assert v.prerelease == ('a', 3)

    v.parse('1.0.4b1')


# Generated at 2022-06-20 16:37:20.065429
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    import sys
    if sys.hexversion < 0x02040000:
        return
    v = LooseVersion('0.4')
    assert v.__repr__() == "LooseVersion ('0.4')"
    assert str(v) == "0.4"


# Generated at 2022-06-20 16:37:32.606406
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    good_tester = StrictVersion('1.2.3')
    if good_tester.version != (1,2,3):
        print('Failed to initialize from string "1.2.3"')

    bad_tester = StrictVersion('a.b.c')
    if bad_tester.version != (0,):
        print('Initialization from "a.b.c" did not default to (0,)')



# Generated at 2022-06-20 16:37:43.669630
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    """Test parse method of class StrictVersion."""

# Generated at 2022-06-20 16:37:54.514412
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ans = Version() > Version()
    assert ans == False
    ans = Version() > Version('0.0')
    assert ans == False
    ans = Version() > Version('0.0.0')
    assert ans == False
    ans = Version() > Version('0.0.0.0')
    assert ans == False
    ans = Version() > Version('0.0.0.0.0')
    assert ans == False
    ans = Version() > Version('0.0.0.0a0')
    assert ans == False
    ans = Version() > Version('0.0.0.0a0.dev0')
    assert ans == False
    ans = Version() > Version('0.0.0.0a0.dev0+abcdefg')
    assert ans == False

# Generated at 2022-06-20 16:38:00.893380
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    class TestCase:
        def __init__(self, vstring):
            self.vstring = vstring
            self.version = StrictVersion(vstring)

    test_cases = [TestCase('1.3.3'),
                  TestCase('0.4.1'),
                  TestCase('0.4'),
                  TestCase('0.4.0'),
                  TestCase('1.0.4b1'),
                  TestCase('1.0.4a3'),
                  TestCase('1.1'),
                  ]

    error_cases = ['1',
                   '1.2.3.4',
                   '2.7.2.2',
                   '1.3.a4',
                   '1.3pl1',
                   '1.3c4',
                   ]

    for case in test_cases:
        assert str

# Generated at 2022-06-20 16:38:03.824752
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion("1.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease is None


# Generated at 2022-06-20 16:38:13.966925
# Unit test for constructor of class Version
def test_Version():
    for vstring in ['1.2.3', '0.0', '2.35.0alpha1']:
        v = Version(vstring)
        assert str(v) == vstring
        assert repr(v) == "%s ('%s')" % ('Version', vstring)
        assert v == Version(vstring)
    class Derived(Version):
        def __init__(self, vstring=None):
            if vstring:
                self.parse(vstring)
    for vstring in ['1.2.3', '0.0', '2.35.0alpha1']:
        v = Derived(vstring)
        assert str(v) == vstring
        assert repr(v) == "%s ('%s')" % ('Derived', vstring)
        assert v == Derived(vstring)
       

# Generated at 2022-06-20 16:38:21.479369
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    from ansible.module_utils.six import PY3

    if PY3:
        test_values = [("1.2.1a1", "1.2.1a1"), ("1.2.1", "1.2.1")]
    else:
        test_values = [("1.2.1a1", "1.2.1a1"), ("1.2.1", "1.2.1"), (u"1.2.1", "1.2.1")]

    for value, expected_result in test_values:
        actual_result = str(value)
        assert actual_result == expected_result, "'{0}' != '{1}'".format(actual_result, expected_result)



# Generated at 2022-06-20 16:38:30.567504
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v1 = StrictVersion('1.0b1')
    v2 = StrictVersion('1.0b2')
    v3 = StrictVersion('1.2')
    v4 = StrictVersion('1.3a1')
    v5 = StrictVersion('1.3b1')
    v6 = StrictVersion('1.3')

    assert(str(v1) == '1.0b1')
    assert(str(v2) == '1.0b2')
    assert(str(v3) == '1.2')
    assert(str(v4) == '1.3a1')
    assert(str(v5) == '1.3b1')
    assert(str(v6) == '1.3')
    return True


# Generated at 2022-06-20 16:38:33.344185
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    if StrictVersion('1.2.3') == StrictVersion('1.2.3'):
        pass

# Generated at 2022-06-20 16:38:35.003423
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # __str__ is tested inside other test methods
    pass

# Unit tests for method __repr__ of class LooseVersion

# Generated at 2022-06-20 16:38:47.775050
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v1.parse('1.9a1')
    v2 = Version()
    v2.parse('1.9.9999')
    assert v1 > v2


# Generated at 2022-06-20 16:38:56.256235
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """Test _LooseVersion__repr__()."""

    semver = LooseVersion('1.5.2b2')
    assert semver.__repr__() == "LooseVersion ('1.5.2b2')"

    verstrict = StrictVersion('1.5.2b2')
    assert verstrict.__repr__() == "StrictVersion ('1.5.2b2')"

    verloose = LooseVersion('1.5.2b2')
    assert verloose.__repr__() == "LooseVersion ('1.5.2b2')"

    assert StrictVersion.__repr__(verloose) == "StrictVersion ('1.5.2b2')"


# Generated at 2022-06-20 16:39:03.784773
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-20 16:39:07.025041
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert (Version('1.1') >= Version('1.1')) == True
    

# Generated at 2022-06-20 16:39:08.990921
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('1.2a')
    assert repr(lv) == "LooseVersion ('1.2a')"

# Generated at 2022-06-20 16:39:16.768818
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """
    >>> str(LooseVersion('1.1'))
    '1.1'
    >>> str(LooseVersion('1.2a2'))
    '1.2a2'
    >>> str(LooseVersion('1.2.1'))
    '1.2.1'
    >>> str(LooseVersion('1.2.1.1'))
    '1.2.1.1'
    >>> str(LooseVersion('1.2.1b'))
    '1.2.1b'
    """

# Generated at 2022-06-20 16:39:21.406857
# Unit test for constructor of class Version
def test_Version():
    for version in [Version(), Version("my version")]:
        assert version.__class__.__name__ == 'Version', \
            "bad class from constructor: %s" % repr(version)
    assert repr(Version("my version")) == "Version ('my version')", \
        "bad result from Version.__repr__"



# Generated at 2022-06-20 16:39:24.420453
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    x1 = Version('1')
    x2 = Version('2')
    x3 = Version('3')
    assert(x2 > x1)
    assert(not (x2 > x3))


# Generated at 2022-06-20 16:39:26.391116
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v1 = StrictVersion('1.1')
    v2 = StrictVersion('1.2')
    assert v1 < v2


# Generated at 2022-06-20 16:39:28.026968
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert v1.__ge__(v2) == NotImplemented

# Generated at 2022-06-20 16:39:47.662985
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    from distutils.version import LooseVersion
    from distutils.version import StrictVersion

    from nose.tools import raises
    from nose.tools import assert_equal

    v1 = LooseVersion('1.1')
    v2 = LooseVersion('1.2')
    assert_equal(v1 > v2, False)
    assert_equal(v1 < v2, True)
    # Comparisons to None
    assert_equal(v1 > None, False)
    assert_equal(None > v1, False)
    assert_equal(v1 < None, False)
    assert_equal(None < v1, False)
    assert_equal(v1 == None, False)
    assert_equal(None == v1, False)
    # Comparisons to non-Version instances
   

# Generated at 2022-06-20 16:39:57.525605
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # Raises AssertionError if v1 not equal to v2
    # Raises AssertionError if v1 not less than v2
    v1 = LooseVersion("1.0")
    assert v1.__str__() == "1.0"
    v2 = LooseVersion("2.0")
    assert v1.__str__() != v2.__str__()
    assert v1.__str__() < v2.__str__()
    assert not v1.__str__() > v2.__str__()

    # Raises AssertionError if v1 not equal to v2
    # Raises AssertionError if v1 not less than v2
    v1 = LooseVersion("1.5.1")
    assert v1.__str__() == "1.5.1"
   

# Generated at 2022-06-20 16:40:07.866205
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    def check(a, b, expected):
        a_instance = Version(a)
        b_instance = Version(b)
        assert a_instance < b_instance == expected

    yield from check('1.9.1', '1.9.2', True)
    yield from check('1.9.2', '1.9.1', False)
    yield from check('1.9.1', '1.10', True)
    yield from check('1.10', '1.10.0', False)
    yield from check('1.10.0', '1.10', False)
    yield from check('1.10', '1.10.0', False)
    yield from check('1.10', '1.11.0rc1', True)

# Generated at 2022-06-20 16:40:09.957923
# Unit test for constructor of class LooseVersion
def test_LooseVersion():

    import doctest
    doctest.testmod(sys.modules["__main__"])


if __name__ == "__main__":
    test_LooseVersion()

# Generated at 2022-06-20 16:40:12.563127
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    f = LooseVersion('1.2.1')
    assert repr(f) == "LooseVersion ('1.2.1')"

# Generated at 2022-06-20 16:40:15.391326
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    ver1 = Version('1.0')
    ver2 = Version('1.0')
    assert ver1 == ver2
    assert not (ver1 != ver2)


# Generated at 2022-06-20 16:40:18.885128
# Unit test for constructor of class Version
def test_Version():
    assert str(Version('1.2')) == '1.2'
    assert str(Version('1.2')) == '1.2'
    assert str(Version()) == ''



# Generated at 2022-06-20 16:40:24.446200
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion("1.0")
    assert v.__repr__() == "LooseVersion ('1.0')", "LooseVersion.__repr__() should return the version id"


# Generated at 2022-06-20 16:40:32.150297
# Unit test for method __ge__ of class Version

# Generated at 2022-06-20 16:40:35.434534
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.0') == '1.0'
    assert Version('1.0') == '1.0.0'
    assert Version('1.0') == '1.0-0'
    assert not (Version('1.0') == '1.1')


# Generated at 2022-06-20 16:40:54.101809
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    test_version = StrictVersion('2.7.2.2')
    assert test_version.version == (2,7,2)
    assert test_version.prerelease == None

    test_version = StrictVersion('1.3.a4')
    assert test_version.version == (1,3,0)
    assert test_version.prerelease == ('a',4)

    test_version = StrictVersion('1.3pl1')
    assert test_version.version == (1,3,0)
    assert test_version.prerelease == None

    test_version = StrictVersion('1.3cp4')
    assert test_version.version == (1,3,0)
    assert test_version.prerelease == None

    test_version = StrictVersion('1.3c4')
    assert test_

# Generated at 2022-06-20 16:41:01.187632
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1.2.3').__repr__()=="LooseVersion ('1.2.3')"
    assert LooseVersion('1.2').__repr__()=="LooseVersion ('1.2')"
    assert LooseVersion(1.2).__repr__()=="LooseVersion ('1.2')"
    assert LooseVersion(1.2, 1.3).__repr__()=="LooseVersion ('1.2')"
    assert LooseVersion(1.2, 1.3, 1.4).__repr__()=="LooseVersion ('1.2')"
    assert LooseVersion(1.2, 1.3, 1.4, 1.5).__repr__()=="LooseVersion ('1.2')"


# Generated at 2022-06-20 16:41:05.750636
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2.3') <= Version('1.2.3')
    assert Version('1.2.3') <= Version('1.3')
    assert Version('1.3') <= Version('1.3.1')

# Generated at 2022-06-20 16:41:18.314456
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    import copy
    import datetime
    import json
    import math
    import operator
    import pycodestyle
    import sys
    import types
    import unittest
    import tempfile

    # Set up context
    ans = None
    _ans = None
    number = None
    _number = None
    __number = None
    _vstring = None
    vstring = None
    __vstring = None
    ver = None
    _ver = None
    __ver = None
    __ver2 = None
    __ver3 = None
    __ver4 = None
    __ver5 = None

# Generated at 2022-06-20 16:41:28.050158
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:41:34.800076
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def _test_parse_set(set):
        for arg in set:
            try:
                print(arg, eval(arg))
            except (ValueError, SyntaxError):
                print(arg, "ERROR")

    _test_parse_set(["0.4", "0.4.0", "0.4.1", "0.5a2", "0.5b3", "0.5",
                     "0.9.6", "1.0", "1.0.4a3", "1.0.4b1", "1.0.4",
                     "1.13++", "5.5.kw"])

    print("\nNow some errors:")

# Generated at 2022-06-20 16:41:38.891901
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion("1.9.9")
    assert v.__str__() == "1.9.9"
    v = LooseVersion("99.9.9")
    assert v.__str__() == "99.9.9"
    v = LooseVersion("99.9.9alpha")
    assert v.__str__() == "99.9.9alpha"


# Generated at 2022-06-20 16:41:43.701565
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import pytest
    a = Version('1.4.4')
    b = Version('1.4.4')
    if a == b:
        assert a >= b
    else:
        assert a >= b





# Generated at 2022-06-20 16:41:46.900002
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1._cmp(v2) == 0
    assert v1.__gt__(v2) == False

# Generated at 2022-06-20 16:41:47.759203
# Unit test for method __ge__ of class Version
def test_Version___ge__(): pass


# Generated at 2022-06-20 16:42:02.938221
# Unit test for constructor of class Version
def test_Version():
    try:
        Version(42)
    except TypeError:
        pass
    else:
        raise AssertionError("Version constructor takes a string only")
    v = Version("42.3")
    try:
        v2 = Version(v)
    except TypeError:
        pass
    else:
        raise AssertionError("Version constructor takes a string only")
    assert Version("1.2").parse("1.2") == "1.2"


# Generated at 2022-06-20 16:42:12.052882
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()

    # pylint: disable=line-too-long,bad-whitespace
    def expect(vstring, expected, msg=''):
        lv.parse(vstring)
        eq_(lv.version, expected, msg or vstring)

    # Make sure parse() recognizes a variety of version number styles
    expect('1.5.1',       [1, 5, 1],   'simple numeric version')
    expect('1.5.2b2',     [1, 5, '2b2'], 'numeric with pre-release')
    expect('161',         [161],       'just a number')
    expect('3.10a',       [3, '10a'],  'letter as a minor release')

# Generated at 2022-06-20 16:42:17.490310
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v1 = sys.version_info
    v2 = LooseVersion(str(v1[0]) + '.' + str(v1[1]) + '.0')
    v3 = LooseVersion(sys.version)
    if v2.__str__() != str(v1[0]) + '.' + str(v1[1]) + '.0':
        return 1
    if v3.__str__() != sys.version:
        return 1
    return 0


# Generated at 2022-06-20 16:42:27.015572
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest
    class TestCase005(unittest.TestCase):
        def runTest(self):
            # Unit test for method __eq__ of class Version
            self.assert_(Version('1.2.3') == Version('1.2.3'))
            self.assertNotEqual(Version('1.2.3'), Version('1.2.4'))
            self.assert_(Version('1.2.3') == '1.2.3')
            self.assertNotEqual(Version('1.2.3'), '1.2.4')
    return TestCase005

# Generated at 2022-06-20 16:42:30.047606
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert str(LooseVersion('1.2.3')) == '1.2.3'
    assert str(LooseVersion('1.2')) == '1.2'


# Generated at 2022-06-20 16:42:31.970842
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    def __lt__(self, other):
        c = self._cmp(other)
        if c is NotImplemented:
            return c
        return c < 0


# Generated at 2022-06-20 16:42:36.392913
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """Check that the LooseVersion.parse method works properly"""
    lv = LooseVersion("1.2.3")
    assert lv.version == [1, 2, 3]
    lv = LooseVersion("1.2.3pl4")
    assert lv.version == [1, 2, '3pl4']
    lv = LooseVersion("1.2.3.4")
    assert lv.version == [1, 2, 3, 4]


# Generated at 2022-06-20 16:42:46.552299
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-20 16:42:57.431103
# Unit test for method __str__ of class LooseVersion

# Generated at 2022-06-20 16:42:59.429629
# Unit test for constructor of class Version
def test_Version():
    import string
    assert repr(Version(string.lower)) == "Version ('lower')"


# Generated at 2022-06-20 16:43:19.617722
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.2.3a4')
    v2 = Version('1.2.3a4')
    assert v1 == v2



# Generated at 2022-06-20 16:43:25.584571
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    version = versionlib.LooseVersion('3.2.pl0')
    expected = '3.2.pl0'
    if str(version) != expected:
        raise AssertionError("%s not as expected: %s" %(str(version),
                                                        expected))


# Generated at 2022-06-20 16:43:37.268546
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    try:
        assert StrictVersion('1.2.3').__str__() == '1.2.3'
        assert StrictVersion('1.2').__str__() == '1.2'
        assert StrictVersion('1.2a3').__str__() == '1.2a3'
        assert StrictVersion('1.2b3').__str__() == '1.2b3'
        assert StrictVersion('1.2.3a3').__str__() == '1.2.3a3'
    except:
        pass
    else:
        raise AssertionError("should have raised ValueError")


# Generated at 2022-06-20 16:43:41.428313
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('0.0.0')
    assert v <= '0.0.0'
    assert v <= v



# Generated at 2022-06-20 16:43:44.588390
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    eq = v.__le__(1)
    assert isinstance(eq, bool) or eq is NotImplemented

# Generated at 2022-06-20 16:43:46.395615
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.10c1")
    assert str(v) == "1.10c1"


# Generated at 2022-06-20 16:43:53.122596
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring, parsed_version, prerelease):
        v = StrictVersion(vstring)

        assert v.version == parsed_version
        assert v.prerelease == prerelease
        assert str(v) == vstring

    test("0.4", (0, 4), None)
    test("0.4.0", (0, 4, 0), None)
    test("0.4.1", (0, 4, 1), None)
    test("0.5a1", (0, 5), ("a", 1))
    test("0.5b3", (0, 5), ("b", 3))
    test("0.5", (0, 5), None)
    test("0.9.6", (0, 9, 6), None)
    test("1.0", (1, 0), None)
   

# Generated at 2022-06-20 16:43:54.341502
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.1.1").__str__() == "1.1.1"



# Generated at 2022-06-20 16:44:04.011837
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def construct_parse(vstring, version, vstring_get):
        def test_parse(self=None):
            v = LooseVersion(vstring)
            self.failUnlessEqual(v.version, version)
            self.failUnlessEqual(str(v), vstring_get)
        return test_parse

# Generated at 2022-06-20 16:44:13.015112
# Unit test for constructor of class Version
def test_Version():
    import sys
    from types import IntType, TupleType
    s = Version('2.1.0')
    assert s._cmp(s) == 0
    assert s._cmp('2.1.0') == 0
    assert s._cmp(sys.maxint) == sys.maxint
    assert s._cmp(None) == NotImplemented
    try:
        s._cmp('2.1')
    except ValueError:
        pass
    else:
        raise AssertionError('unable to catch version number mismatch')
    s = Version('2.1')
    assert s._cmp('2.1.0') == 0

# Stolen from sre, cause I can't import sre

# Generated at 2022-06-20 16:45:13.481903
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest

    class Version___le__TestCase(unittest.TestCase):
        def test_it(self):
            v = Version()
            # line 210, unit test for method __le__ of class Version
            self.assertEquals(v.__le__(42), NotImplemented, "should be NotImplemented")
            # line 212, unit test for method __le__ of class Version
            self.assertEquals(v.__le__(v), True, "should be True")
            # line 214, unit test for method __le__ of class Version
            self.assertEquals(v.__le__(None), NotImplemented, "should be NotImplemented")
            # line 216, unit test for method __le__ of class Version

# Generated at 2022-06-20 16:45:24.791735
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    global failedfunc
    verbose = sys.argv[1]
    if verbose == "--verbose":
        sys.argv.pop(1)
        verbose = True
    if len(sys.argv) > 1:
        sys.exit(__doc__)
    success = failure = 0
    import doctest, strict_version
    try:
        doctest.testmod(strict_version, verbose=verbose)
        success = 1
    except Exception as e:
        failedfunc = 'test_StrictVersion___str__'
        if verbose:
            traceback.print_exc(file=sys.stderr)
    if success:
        sys.exit(0)
    else:
        sys.exit(1)


# Generated at 2022-06-20 16:45:27.184763
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert (v1 < v2) == v2.__gt__(v1), "v1=%s, v2=%s" % (v1, v2)



# Generated at 2022-06-20 16:45:35.497960
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    testdata = [
        ('0.4.0', '0.4'),
        ('0.4.1', '0.4.1'),
        ('0.5a2', '0.5a2'),
        ('0.5b3', '0.5b3'),
        ('0.5', '0.5'),
        ('0.9.6', '0.9.6'),
        ('1.0', '1.0'),
        ('1.0.4a3', '1.0.4a3'),
        ('1.0.4b1', '1.0.4b1'),
    ]

    for vstring, expected_str in testdata:
        sv = StrictVersion(vstring)
        assert str(sv) == expected_str



# Generated at 2022-06-20 16:45:41.664243
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    version = StrictVersion('1.2.3')
    assert version.version == (1, 2, 3)
    assert version.prerelease is None
    assert str(version) == '1.2.3'

    version = StrictVersion('1.2.3a1')
    assert version.version == (1, 2, 3)
    assert version.prerelease == ('a', 1)
    assert str(version) == '1.2.3a1'

    version = StrictVersion('1.2.0')
    assert version.version == (1, 2, 0)
    assert version.prerelease is None
    assert str(version) == '1.2'

    version = StrictVersion('1.2')
    assert version.version == (1, 2, 0)
    assert version.prerelease is None

# Generated at 2022-06-20 16:45:44.153143
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert v.__repr__() == 'Version (\'\')'

# Generated at 2022-06-20 16:45:48.405039
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = StrictVersion()
    version.version = (1, 2, 3)
    assert version.__str__() == '1.2.3'


# Generated at 2022-06-20 16:45:51.652588
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion("2g6")
    assert repr(v) == "LooseVersion ('2g6')"

# Generated at 2022-06-20 16:45:55.128900
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    __repr__1 = Version('10.8').__repr__()
    assert str(__repr__1) == "Version ('10.8')"

# Generated at 2022-06-20 16:45:57.901786
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    check = LooseVersion("1.3.3")