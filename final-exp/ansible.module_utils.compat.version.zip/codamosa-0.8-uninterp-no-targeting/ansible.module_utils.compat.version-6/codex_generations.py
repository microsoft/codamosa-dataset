

# Generated at 2022-06-20 16:36:13.693249
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """
    >>> str(LooseVersion("1.2.3"))
    "'1.2.3'"
    """


# Generated at 2022-06-20 16:36:20.357353
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import sys
    import pytest
    import distutils.version as m

    # Setup argument
    V = Version

    if sys.hexversion >= 0x03000000:
        # Setup argument
        other = 'sth'
        # Exercise function
        with pytest.raises(AttributeError):
            V._cmp(V(), other)
    else:
        # Setup argument
        other = ''
        # Exercise function
        with pytest.raises(AttributeError):
            V._cmp(V(), other)


# Generated at 2022-06-20 16:36:24.181497
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Test for Version.__repr__"""
    v = Version()
    assert isinstance(v, Version)
    assert v.__repr__() == "Version ('0')"
    v.parse("3.3.3")
    assert v.__repr__() == "Version ('3.3.3')"

# Generated at 2022-06-20 16:36:26.883574
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.2.3.4.5.6.7.8.9.10.11.12')
    assert str(v) == '1.2.3.4.5.6.7.8.9.10.11.12'


# Generated at 2022-06-20 16:36:28.615722
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    c = Version()
    assert c.__repr__() == "Version ('None')"


# Generated at 2022-06-20 16:36:30.212083
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version(1).__repr__() == "Version ('1')"


# Generated at 2022-06-20 16:36:33.465089
# Unit test for constructor of class Version
def test_Version():
    # Check the constructor and repr of Version
    assert repr(Version()) == "Version ('')"
    assert repr(Version('1.2.3a4')) == "Version ('1.2.3a4')"

    # Check the comparison methods
    # unit test for class Version

test_Version()


# Generated at 2022-06-20 16:36:38.468058
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import doctest
    doctest.testmod(verbose=False, optionflags=(doctest.ELLIPSIS + doctest.NORMALIZE_WHITESPACE + doctest.IGNORE_EXCEPTION_DETAIL))

# Generated at 2022-06-20 16:36:40.923196
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import sys
    v = LooseVersion('1.2.0-alpha1')
    validate_object(sys.modules[__name__], v)
    assert v.vstring == '1.2.0-alpha1'


# Generated at 2022-06-20 16:36:43.552543
# Unit test for method __le__ of class Version
def test_Version___le__():
    a = Version("1.1.1")
    b = Version("1.1.1a")
    assert not a.__le__(b)


# Generated at 2022-06-20 16:36:53.621215
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Return True if method __lt__ of class Version works as expected

    """
    v1 = Version('1.0.0')
    v2 = Version('2.0.0')
    assert v1 < v2



# Generated at 2022-06-20 16:36:59.569065
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('0.4.0').__str__() == '0.4.0'
    assert StrictVersion('0.4.0').__str__() == '0.4'
    assert StrictVersion('0.4.1').__str__() == '0.4.1'
    assert StrictVersion('0.5a1').__str__() == '0.5a1'
    assert StrictVersion('0.5b3').__str__() == '0.5b3'
    assert StrictVersion('0.5').__str__() == '0.5'
    assert StrictVersion('0.9.6').__str__() == '0.9.6'
    assert StrictVersion('1.0').__str__() == '1.0'

# Generated at 2022-06-20 16:37:06.391938
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    LV = LooseVersion
    assert str(LV('1.2.2.2')) == '1.2.2.2'
    assert str(LV('1.2.22')) == '1.2.22'
    assert str(LV('1.222')) == '1.222'
    assert str(LV('1222')) == '1222'
    assert str(LV('2g6')) == '2g6'
    assert str(LV('1.5.1')) == '1.5.1'
    assert str(LV('1.5.1b1')) == '1.5.1b1'
    assert str(LV('1.5.1a2')) == '1.5.1a2'

# Generated at 2022-06-20 16:37:10.008007
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('0.4.1')
    assert str(v) == '0.4.1', \
        'StrictVersion.__str__ is flawed'
    v = StrictVersion('1.0')
    assert str(v) == '1.0', \
        'StrictVersion.__str__ is flawed'
    v = StrictVersion('1')
    assert str(v) == '1.0', \
        'StrictVersion.__str__ is flawed'


# Generated at 2022-06-20 16:37:12.277379
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('12')
    assert lv.version == [12]
    lv.parse('abc12.42')
    assert lv.version == ['abc', 12, 42]

# Generated at 2022-06-20 16:37:24.583969
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    testcase = "test_Version___ge__"

# Generated at 2022-06-20 16:37:30.773724
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    def check(s):
        print(s)
        v = Version(s)
        assert repr(v) == "Version ('%s')" % (s,)

    check('1')
    check('1.2')
    check('1.2.3')
    check('1.2.3.alpha2')
    check('1.2a3')
    check('1.2b3')
    check('1.2.3c1')
    check('1.2.3c2pre')
    check('1.2.3-rc2')
    check('1.2.3-rc3')
    check('1.2.3-pre')
    check('1.2.3-pre1')
    check('1.2.3-pre2')
    check('1.2.3-pre10')


# Generated at 2022-06-20 16:37:37.609195
# Unit test for method __repr__ of class LooseVersion

# Generated at 2022-06-20 16:37:39.454831
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.1')
    assert str(v) == "1.1"

# Generated at 2022-06-20 16:37:41.399707
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert(False)  # No test implemented


# Generated at 2022-06-20 16:37:50.639885
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # Lazy to implement test, cause Python does it for me
    pass


# Generated at 2022-06-20 16:37:52.980036
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('2.3.4')
    assert (v1 > v2) == True


# Generated at 2022-06-20 16:37:59.800971
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    def check(v1, v2, expected):
        c = v1.__lt__(v2)
        if c is not expected:
            raise AssertionError("%r < %r should be %r, not %r" % (v1, v2, expected, c))

    v = StrictVersion
    check(v('1.5.1'), v('1.5.2b2'), True)
    check(v('161'), v('3.10a'), False)
    check(v('8.02'), v('8.02'), False)
    check(v('3.4j'), v('1996.07.12'), False)
    check(v('3.2.pl0'), v('3.1.1.6'), False)
    check(v('2g6'), v('11g'), True)
   

# Generated at 2022-06-20 16:38:00.867983
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('0.0.0')
    assert v >= None
test_Version___ge__()

# Generated at 2022-06-20 16:38:07.345574
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v1 = StrictVersion('1.3.7.2')
    assert v1.version == (1, 3, 7, 2)
    assert v1.prerelease == None
    v2 = StrictVersion('1.3.7-me.too')
    assert v2.prerelease == ('-', 'me.too')



# Generated at 2022-06-20 16:38:09.905745
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version('0.9.2')
    assert version < '0.9.3'

Version = Version # this line is needed for the object inspector to recognise that a class named Version exists



# Generated at 2022-06-20 16:38:18.762414
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Function to test the parse function of the LooseVersion class.

    # Just check that we can create a version number, and that the string
    # version of the instance matches the supplied version string.
    def _test_parse(vstring):
        v = LooseVersion(vstring)
        assert v.vstring == vstring
        assert str(v) == vstring

    for vstring_tests in [
        # check some valid version numbers
        ("1.0", "1.0.0", "1.0a1", "1.00", "1.0a1.0"),
        # check some invalid version numbers
        ('1.0a')
    ]:
        for vstring in vstring_tests:
            yield _test_parse, vstring

# Generated at 2022-06-20 16:38:21.195469
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3')
    assert (str(v) == '1.2.3')

# Generated at 2022-06-20 16:38:30.382673
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def failUnlessVersionEqual(input, expected_output):
        '''This function tests the constructor of class LooseVersion
        to check if it returns the correct tuple. The function is
        internally used by the test_LooseVersion()'''
        output = LooseVersion(input)
        if output.version != expected_output:
            print("version %s should be %s" % (output.version, expected_output))
            return False
        else:
            return True

    def test_LooseVersion_case1():
        '''Tests the constructor of class LooseVersion with the
        following version numbers as input. All these numbers are
        considered as valid version numbers under its scheme.
        '''

# Generated at 2022-06-20 16:38:32.037050
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('3..10a')
    try:
        assert repr(v) == "LooseVersion ('3..10a')"
        return True
    except:
        return False

# Generated at 2022-06-20 16:38:47.826571
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version("0.1a") >= Version("0.1a")


# Generated at 2022-06-20 16:38:50.643522
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    l = LooseVersion('1')
    assert l.__str__(), '1'
    l2 = LooseVersion('1.1')
    assert l2.__str__(), '1.1'


# Generated at 2022-06-20 16:38:52.585944
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion("1.0")
    assert str(lv) == "1.0"


# Generated at 2022-06-20 16:39:01.923684
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    LooseVersion('1.2')
    LooseVersion('1.2.3')
    LooseVersion('1.2.3.4')
    LooseVersion('1.2b3')
    LooseVersion('1.2.3b3')
    LooseVersion('5.5.kw')
    LooseVersion('5.5pl3')
    LooseVersion('5.5.pl3')
    LooseVersion('5.5.final')
    LooseVersion('5.5.1.2.3.4.5.6.7.8')
    LooseVersion('1.2+')
    LooseVersion('1.2+b3')
    LooseVersion('1.2+b3.4')
    LooseVersion('1.2+b3.4.5')

# Generated at 2022-06-20 16:39:03.658259
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    import re

    s = LooseVersion(1).__repr__()
    assert re.match("^LooseVersion \\(.*\\)$", s)

    s = LooseVersion('abc').__repr__()
    assert re.match("^LooseVersion \\(.*\\)$", s)



# Generated at 2022-06-20 16:39:07.656245
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert(Version() <= Version())
    assert(Version() <= "0.0")
    assert(Version() <= Version())
    assert(Version() <= "0.0")

# Generated at 2022-06-20 16:39:18.352271
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    cs = Version.__repr__

    assert cs(Version("1.0")) == "Version ('1.0')"
    assert cs(Version("1.0.1")) == "Version ('1.0.1')"
    assert cs(Version("1.0-1")) == "Version ('1.0-1')"
    assert cs(Version("1.0.post0")) == "Version ('1.0.post0')"

    assert cs(Version("1.0.dev0")) == "Version ('1.0.dev0')"
    assert cs(Version("1.0.a.dev0")) == "Version ('1.0.a.dev0')"


# Generated at 2022-06-20 16:39:21.846872
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class A(Version):
        def parse(self, vstring):
            return

        def _cmp(self, other):
            return 1
    a = A('1')
    b = A('2')
    o = a > b
    assert o



# Generated at 2022-06-20 16:39:23.828350
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert str(v) == "Version ('0.0')"

# Generated at 2022-06-20 16:39:29.571851
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Test method __eq__ of class Version"""

    def test(v1, v2):
        """Helper function for testing __eq__"""
        import unittest
        print('=== Testing __eq__ with [%s] vs [%s] ===' % (v1, v2))
        v1 = StrictVersion(v1)
        v2 = StrictVersion(v2)
        unittest.TestCase().assertEqual(v1 == v2, True)

    test('1.0','1.0')
    test('1.2','1.3')

# Generated at 2022-06-20 16:40:03.659116
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    import time, string
    eq = assert_equal

    eq(LooseVersion("1.2.0").version, (1, 2, 0))
    eq(LooseVersion("1.2.1a3").version, (1, 2, 1, "a", 3))
    eq(LooseVersion("1.2.1").version, (1, 2, 1))
    eq(LooseVersion("1.2").version, (1, 2))
    eq(LooseVersion("1").version, (1,))
    eq(LooseVersion("1.2a1").version, (1, 2, "a", 1))
    eq(LooseVersion("1.2.1-2").version, (1, 2, 1, "-", 2))

# Generated at 2022-06-20 16:40:13.732701
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v1 = LooseVersion('1')
    if v1.version != [1]: raise AssertionError
    v2 = LooseVersion('2a')
    if v2.version != [2, 'a']: raise AssertionError
    v3 = LooseVersion('3b')
    if v3.version != [3, 'b']: raise AssertionError
    v4 = LooseVersion('4.10')
    if v4.version != [4, 10]: raise AssertionError
    v5 = LooseVersion('5.10a')
    if v5.version != [5, 10, 'a']: raise AssertionError
    v6 = LooseVersion('6.10.2')
    if v6.version != [6, 10, 2]: raise AssertionError
    v7 = Loose

# Generated at 2022-06-20 16:40:25.668727
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert(str(LooseVersion('1.2.3')) == '1.2.3')
    assert(str(LooseVersion('1.2-b.3')) == '1.2-b.3')
    assert(str(LooseVersion('1.')) == '1.')
    assert(str(LooseVersion('.1')) == '.1')
    assert(str(LooseVersion('a.b')) == 'a.b')
    assert(str(LooseVersion('1.2a3')) == '1.2a3')
    assert(str(LooseVersion('1.2.3.4.5')) == '1.2.3.4.5')
    assert(str(LooseVersion('1-')) == '1-')

# Generated at 2022-06-20 16:40:26.773859
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    if not (StrictVersion((1,2,3)) == "1.2.3"):
        raise RuntimeError('Test failed')


# Generated at 2022-06-20 16:40:36.499367
# Unit test for constructor of class Version
def test_Version():
    # Test Version.__init__, Version.__repr__, Version.parse and __str__
    for vstring in ['0.4a1', '1.0', '2.0b2', '2.0.0']:
        v = Version(vstring)
        assert str(v) == vstring
        assert repr(v) == "%s ('%s')" % (v.__class__.__name__, vstring)

_PY_VERSION_SHORT = '%s.%s' % (sys.version_info[0], sys.version_info[1])

# Generated at 2022-06-20 16:40:38.658141
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.13++')
    assert repr(v) == "LooseVersion ('1.13++')"


# Generated at 2022-06-20 16:40:41.470085
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('2.0.4')
    v2 = Version('2.0.4')
    assert (v1 == v2)

# Generated at 2022-06-20 16:40:43.360720
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2.1')
    assert repr(v) == "LooseVersion ('1.2.1')"


# Generated at 2022-06-20 16:40:46.914956
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    from xml.parsers.expat import LooseVersion
    v = LooseVersion("1.2.3")
    assert str(v) == '1.2.3'


# Generated at 2022-06-20 16:40:57.911338
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('1.1.1') == LooseVersion('1.1.1')
    assert LooseVersion('1.1.1') != LooseVersion('1.1.2')
    assert LooseVersion('1.1') != LooseVersion('1.1.1')
    assert LooseVersion('1.1') < LooseVersion('1.1.1')
    assert LooseVersion('1.1') <= LooseVersion('1.1.1')
    assert LooseVersion('1.2') > LooseVersion('1.1.1')
    assert LooseVersion('1.2') >= LooseVersion('1.1.1')
    assert LooseVersion('1.1.1') != LooseVersion('1.1.1-1')
    assert LooseVersion('1.1.1') == Loose

# Generated at 2022-06-20 16:41:54.677840
# Unit test for method __le__ of class Version
def test_Version___le__():
    '''
    This is a unit test for method __le__ of class Version
    '''
    a = Version("1")
    b = Version("1")
    assert(a <= b)
    assert(a <= "1")
    assert("1" <= b)



# Generated at 2022-06-20 16:41:59.405622
# Unit test for constructor of class Version
def test_Version():
    # Test Version class constructor, with and without argument.
    # Test __repr__ method.
    v1 = Version()
    assert str(v1) == ''
    assert repr(v1) == "Version ('')"
    v2 = Version('1.2')
    assert str(v2) == '1.2'
    assert repr(v2) == "Version ('1.2')"


# Generated at 2022-06-20 16:42:11.093822
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Some correct version number strings
    correct_versions = ['1.0', '1.0.1', '1.2.2a1', '1.2.2b2', '1.2.2c3',
                        '1.2.2', '1.3.3.7']
    # Some incorrect version number strings
    incorrect_versions = ['a.b.c', '1.2', '1.2.2.2', '1.2.2-2', '1.2.2.2.2',
                          '1.1a', '1.1a1', '1.2b', '1.2b1', '1.2c', '1.2c1']
    StrictVersion('1.0')

# Generated at 2022-06-20 16:42:18.922501
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    import unittest
    class Test(unittest.TestCase):
        def test_normal(self):
            for vs in ['1.0', '1.2.3.4', '1.2', '0.4.1', '0.4.2',
                       '1.2.3a1', '1.2.3a4', '1.2.3b1', '1.2.3b4',
                       '1.2.3c1', '1.2.3c4', '1.2.0', '1.2.0.0',
                       '1.2.0.0.0']:
                v = StrictVersion(vs)
                self.assertEqual(str(v), vs)
                self.assertIsInstance(v, Version)

# Generated at 2022-06-20 16:42:22.647407
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('4.4') < Version('4.5')
    assert Version('4.5.5') < Version('4.5.6')


# Generated at 2022-06-20 16:42:29.713388
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    version = StrictVersion("0.4.0")
    assert version.version == (0, 4, 0)
    assert version.prerelease == None

    version = StrictVersion("0.4.1")
    assert version.version == (0, 4, 1)
    assert version.prerelease == None

    version = StrictVersion("0.5a1")
    assert version.version == (0, 5, 0)
    assert version.prerelease == ('a', 1)

    version = StrictVersion("0.5b3")
    assert version.version == (0, 5, 0)
    assert version.prerelease == ('b', 3)

    version = StrictVersion("0.5")
    assert version.version == (0, 5, 0)
    assert version.prerelease == None


# Generated at 2022-06-20 16:42:36.107828
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Standalone tests for the parse method of LooseVersion. It needs
    # to have been completely rewritten for Issue5319.
    def vlist(list_vstring):
        return [LooseVersion(v) for v in list_vstring]

    def check(list_vstring, expected_index, expected_crash):
        v = vlist(list_vstring)
        if expected_crash:
            try:
                return v.index(LooseVersion(expected_crash))
            except ValueError:
                return 'crash'
        else:
            return v.index(LooseVersion(expected_index))

    assert check(['0.1', '0.1.1'], '0.1.1', None) == 1

# Generated at 2022-06-20 16:42:39.846694
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """
    Unit test for method __gt__ of class Version
    """
    v = Version()
    v2 = Version()
    assert v > v2


# Generated at 2022-06-20 16:42:41.614488
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()

# Generated at 2022-06-20 16:42:43.920399
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv_1 = LooseVersion('1.0.4a3')
    str_1 = str(lv_1)
    assert str_1 == '1.0.4a3'


# Generated at 2022-06-20 16:45:07.620519
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # test that class constructor works
    lv = LooseVersion("1.5.1")
    assert lv.version == [1, 5, 1], lv.version
    lv = LooseVersion("161")
    assert lv.version == [161], lv.version
    lv = LooseVersion("1.5.1.1")
    assert lv.version == [1, 5, 1, 1], lv.version
    lv = LooseVersion("1.5.1pl0")
    assert lv.version == [1, 5, 1, 'pl', 0], lv.version
    lv = LooseVersion("1.5.1.post1234")
    assert lv.version == [1, 5, 1, 'post', 1234], lv.version

# Generated at 2022-06-20 16:45:15.330966
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion('1.0')
    assert v.version == (1,0,0)
    assert v.prerelease == None

    v = StrictVersion('1.0.0')
    assert v.version == (1,0,0)
    assert v.prerelease == None

    v = StrictVersion('1.0a1')
    assert v.version == (1,0,0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion('1.0.0a1')
    assert v.version == (1,0,0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion('1.0b3')
    assert v.version == (1,0,0)
    assert v.prerelease == ('b', 3)

    v

# Generated at 2022-06-20 16:45:21.042369
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2.3') <= Version('1.2.3')
    assert not (Version('1.2.3') <= Version('1.2.2'))
    assert not (Version('1.2.3') <= Version('1.2.4'))

# Generated at 2022-06-20 16:45:28.396010
# Unit test for constructor of class Version
def test_Version():
    assert Version("2a")._version == (2, 'a', None, None)
    assert Version("2.a")._version == (2, 'a', None, None)
    assert Version("2.a.0")._version == (2, 'a', 0, None)
    assert Version("2.a.0.0")._version == (2, 'a', 0, 0)
    assert Version("2.a.0.0.0")._version == (2, 'a', 0, 0, 0)
    assert Version("2.a.0.0.0.0")._version == (2, 'a', 0, 0, 0, 0)
    assert Version("2.a.0.0.0.0.0")._version == (2, 'a', 0, 0, 0, 0, 0)


# Generated at 2022-06-20 16:45:38.822142
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """ method __str__ of class StrictVersion
    
    *** IMPORTANT NOTE ***
    This unit test is generated by TestGen.
    Do NOT modify this test.
    Do NOT submit this test to the project.
    """
    print("")
    print("Running " + __name__)
    print("")
    version = StrictVersion("1.0.0.0.0")
    
    try:
        assert(str(version)=="1.0")
    except AssertionError as e:
        print("    assert (str(version)=='1.0') failed")
        print("  " + str(e))
        print("")
        print("  ACTUAL  : " + str(version))
        print("  EXPECTED: 1.0")
        print("")
        raise AssertionError


# Generated at 2022-06-20 16:45:42.463415
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1')
    v2 = Version('2')
    assert v1 < v2 == True

# Generated at 2022-06-20 16:45:45.792292
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion("1.0")
    assert repr(v) == "LooseVersion ('1.0')"


# Generated at 2022-06-20 16:45:54.229597
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """
    Test that __str__ corresponds to input passed to parse
    """
    _cmp = lambda a, b: (a > b) - (a < b)
    versions = ('0.9', '1.0', '1.0a1', '1.0b3', '1.0c1',
                '1.0.0', '1.0.4a3', '1.0.4b1', '1.0.4',
                '1.0.4.0')
    for version in versions:
        try:
            v1 = StrictVersion(version)
            assert v1.__str__() == version
        except ValueError:
            pass


# Generated at 2022-06-20 16:46:01.989785
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    s = StrictVersion("1.2.3")
    assert s.version == (1,2,3)
    assert s.prerelease == None
    s = StrictVersion("1.2.3a4")
    assert s.version == (1,2,3)
    assert s.prerelease == ('a',4)
    s = StrictVersion("1.2.0")
    assert s.version == (1,2,0)
    s = StrictVersion("1.2")
    assert s.version == (1,2,0)
    try:
        s = StrictVersion("1.2.3.4")
    except ValueError:
        pass
    else:
        assert 0, "did not raise ValueError"