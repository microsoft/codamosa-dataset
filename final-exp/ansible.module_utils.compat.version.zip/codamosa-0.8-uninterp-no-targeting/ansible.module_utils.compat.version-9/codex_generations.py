

# Generated at 2022-06-20 16:36:16.921273
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    cases = ['1.2.0', '1.2', '1.2a1', '1.2b3', '159.1', '1.98.6']
    cases = cases + ["1.2"+pre for pre in "abcdefghijklmnopqrstuvwxyz"]
    cases = cases + ["1.2"+pre+post
                     for pre in "abcdefghijklmnopqrstuvwxyz"
                     for post in "abcdefghijklmnopqrstuvwxyz"]

    for v in cases:
        assert(str(LooseVersion(v))==v)


# Generated at 2022-06-20 16:36:25.991533
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-20 16:36:33.248709
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    r"""Test for method __str__ of class LooseVersion

    Test the method __str__ of the class LooseVersion for the following cases:
        1. without parameter vstring
        2. with parameter vstring
    """

# Generated at 2022-06-20 16:36:43.659476
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Test invalid inputs
    invalid_versions = ["1", "2.7.2.2", "1.3.a4", "1.3pl1", "1.3c4"]
    for vstring in invalid_versions:
        try:
            StrictVersion(vstring)
        except ValueError:
            pass
        else:
            assert False, "Failed to raise ValueError for %s" % vstring
    # Test valid inputs and their representation

# Generated at 2022-06-20 16:36:53.589656
# Unit test for constructor of class Version
def test_Version():
    from distutils.tests import support

    x = Version('1.2.3')
    assert x.__class__ == Version

    assert x.__eq__(Version('1.2.3'))
    assert not x.__eq__(Version('1.2.4'))

    assert x.__le__(Version('1.2.3'))
    assert x.__lt__(Version('1.2.4'))
    assert x.__ge__(Version('1.2.3'))
    assert x.__gt__(Version('1.2.2'))

    support.assertRaises(TypeError, cmp, x, Version('1.2.3'))
    support.assertRaises(TypeError, x.__le__, '1.2.3')



# Generated at 2022-06-20 16:36:54.457333
# Unit test for constructor of class Version
def test_Version():
    V = Version()



# Generated at 2022-06-20 16:37:00.126446
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    print('Testing')
    v1 = Version('1')
    v2 = Version('2')
    assert v1 < v2
    assert v2 > v1
    assert v1 <= v2
    assert v2 >= v1
    assert v1 <= v1
    assert v1 >= v1
    assert not (v1 < v1)
    assert not (v1 > v1)
    print('Testing OK')

# Generated at 2022-06-20 16:37:01.592971
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import doctest
    doctest.run_docstring_examples(LooseVersion, globals())



# Generated at 2022-06-20 16:37:04.991505
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    # All three following versions should be parsed to the same tuple
    versions = ('1.2.3', '1.2.3.0', '1.2.3.0.0')
    for version in versions:
        lv.parse(version)
        assert lv.version == (1, 2, 3, 0, 0)

# Generated at 2022-06-20 16:37:07.811457
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.2.3')
    assert v.__str__() == '1.2.3'
    v = LooseVersion('1.2.3b1')
    assert v.__str__() == '1.2.3b1'
    v = LooseVersion('')
    assert v.__str__() == ''



# Generated at 2022-06-20 16:37:16.516840
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    pass

# Generated at 2022-06-20 16:37:23.865324
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    try:
        StrictVersion("1.2")
    except ValueError:
        # Error raised by constructor
        pass
    else:
        # Other error
        raise TestFailed("StrictVersion constructor should raise ValueError "
                         "for invalid input.")
    try:
        StrictVersion("1.2.3.4")
    except ValueError:
        # Error raised by constructor
        pass
    else:
        # Other error
        raise TestFailed("StrictVersion constructor should raise ValueError "
                         "for invalid input.")



# Generated at 2022-06-20 16:37:25.435178
# Unit test for method __le__ of class Version
def test_Version___le__():
    Version1 = Version()
    Version2 = Version()

    Version2.parse("1.1.0")
    assert(Version1 <= Version2)
    assert(not(Version1 <= "1.0.0"))
test_Version___le__()


# Generated at 2022-06-20 16:37:26.317975
# Unit test for method __ge__ of class Version
def test_Version___ge__(): return None


# Generated at 2022-06-20 16:37:31.949032
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion('1.2.3')
    assert lv.version == (1,2,3), lv.version

    lv = LooseVersion('1.1.6b1')
    assert lv.version == (1,1,6,'b',1), lv.version

    lv = LooseVersion('1.3.7.4')
    assert lv.version == (1,3,7,4), lv.version


# Generated at 2022-06-20 16:37:37.703471
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Test Version.__ge__ with no args
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2

    # Test Version.__ge__ with one arg
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v2 >= v1
    assert v1 >= v2 == False



# Generated at 2022-06-20 16:37:42.042590
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from ansible_galaxy.version import Version

    v = Version('1.7.2')
    assert str(v) == "Version ('1.7.2')"
    assert repr(v) == "Version ('1.7.2')"



# Generated at 2022-06-20 16:37:47.947479
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    obj = LooseVersion('2.2')
    actual = obj.__repr__()
    expected = "LooseVersion ('2.2')"
    compare(actual, expected)
# Test:
#   > obj = LooseVersion('2.2')
#   > obj.__repr__()
# Expect:
#   "LooseVersion ('2.2')"
#

# Generated at 2022-06-20 16:37:50.057628
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    version.__ge__('')


# Generated at 2022-06-20 16:37:54.037068
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    try:
        StrictVersion("1.1.1")
        StrictVersion("1.1.1c1")
        StrictVersion("1.1.1rc2")
        StrictVersion("1.1.1.2")
    except:
        print("Error creating StrictVersion object")
        return 1

    return 0


# Generated at 2022-06-20 16:38:09.435683
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    inst = Version('1.2')
    assert inst.__repr__() == "Version ('1.2')"


# Generated at 2022-06-20 16:38:18.556900
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import pytest
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1,2,3)
    assert v.prerelease is None

    v.parse('1.2.3a3')
    assert v.version == (1,2,3)
    assert v.prerelease == ('a',3)

    with pytest.raises(ValueError):
        v.parse('1.3.a3')

    with pytest.raises(ValueError):
        v.parse('1.3pl1')

    with pytest.raises(ValueError):
        v.parse('1.3c4')

    with pytest.raises(ValueError):
        v.parse('1')


# Generated at 2022-06-20 16:38:20.066178
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert str(LooseVersion("1.2.3")) == "1.2.3"


# Generated at 2022-06-20 16:38:22.043869
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test method __gt__ of class Version."""

    v = Version()
    assert v.__gt__(other=None) is NotImplemented



# Generated at 2022-06-20 16:38:28.157727
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  from distutils.version import LooseVersion
  assert LooseVersion('1.0') < LooseVersion('1.1')
  assert LooseVersion('1.0.1') < LooseVersion('1.1')
  assert LooseVersion('1.0a1') < LooseVersion('1.0')
  assert LooseVersion('1.0') < LooseVersion('1.0a1')
  assert LooseVersion('1.0') < LooseVersion('1.0.post42')
  assert LooseVersion('1.0.post42') < LooseVersion('1.0.post43')
  assert LooseVersion('1.0a1') < LooseVersion('1.0')
  # LooseVersion does not support comparing to objects of other types

# Generated at 2022-06-20 16:38:36.892583
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring):
        print("%s < %s" % (vstring, StrictVersion(vstring)))

    # smoke test
    test("1.0")
    test("1")
    test("1.0.4a3")
    test("1.0.4b1")
    test("1.0.4")
    test("1.0.4.0")
    test("1.0a1")
    test("1.0a1.1")
    test("1.0a2.1")
    test("1.0a11.1")
    test("1.0a12.1")
    test("1.0a12.1.2")
    test("1.0a12.1.2.3")

# Generated at 2022-06-20 16:38:43.687873
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  if not hasattr(Version(), "__ge__"):
    return

  assert Version('1') >= Version('1') == True
  assert Version('1') >= Version('2') == False
  assert Version('2') >= Version('1') == True

  assert Version('1') >= '1' == True
  assert Version('1') >= '2' == False
  assert Version('2') >= '1' == True

# Generated at 2022-06-20 16:38:45.809717
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    Version().__gt__()

# Generated at 2022-06-20 16:38:54.883315
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():

    v = StrictVersion("1.2.3a0")
    w = StrictVersion("1.2.3.a0")
    x = StrictVersion("1.2.0")
    y = StrictVersion("1.2")
    z = StrictVersion("1.2.0")
    a = StrictVersion("1.2.0.0")
    b = StrictVersion("1.2.0.0.0")
    c = StrictVersion("1.2.0.dev456")

    vv = str(v)
    ww = str(w)
    xx = str(x)
    yy = str(y)
    zz = str(z)
    aa = str(a)
    bb = str(b)
    cc = str(c)


# Generated at 2022-06-20 16:38:56.501329
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    other = 0
    assert v >= other == NotImplemented



# Generated at 2022-06-20 16:39:08.693824
# Unit test for constructor of class Version
def test_Version():
    try:
        Version()
        Version('1')
    except Exception as e:
        print(e, file=sys.stderr)
        raise



# Generated at 2022-06-20 16:39:10.399792
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'

# Generated at 2022-06-20 16:39:13.057420
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import builtins

    msg = " class method '{}' not implemented"
    assert hasattr(builtins, '__name__'), msg.format('__name__')

# Generated at 2022-06-20 16:39:24.547385
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = StrictVersion("1.2")
    assert s.version == (1,2,0)
    assert s.prerelease == None
    s = StrictVersion("1.2.3")
    assert s.version == (1,2,3)
    assert s.prerelease == None
    s = StrictVersion("1.2.3a4")
    assert s.version == (1,2,3)
    assert s.prerelease == ('a',4)
    s = StrictVersion("1.2.3b8")
    assert s.version == (1,2,3)
    assert s.prerelease == ('b',8)
    try:
        StrictVersion("1")
        raise Exception("should have raised ValueError for 1")
    except ValueError:
        pass

# Generated at 2022-06-20 16:39:26.208984
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.2')
    assert v.__le__('1.1') == False

# Generated at 2022-06-20 16:39:34.844705
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse('1.23.456')
    assert v.version == [1, 23, 456]
    v.parse('1')
    assert v.version == [1]
    v.parse('2')
    assert v.version == [2]
    v.parse('1.23.1')
    assert v.version == [1, 23, 1]
    v.parse('1.1.1')
    assert v.version == [1, 1, 1]
    v.parse('1.1.1.1')
    assert v.version == [1, 1, 1]
    v.parse('1.1.1.1.1.1')
    assert v.version == [1, 1, 1]

# Generated at 2022-06-20 16:39:39.760622
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion('2.2beta29')
    assert l.version == [2, 2, 'beta', 29]
    l = LooseVersion('1.13++')
    assert l.version == [1, 13, '++']
    l = LooseVersion('5.5.kw')
    assert l.version == [5, 5, 'kw']



# Generated at 2022-06-20 16:39:42.422424
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion('2.2beta29')
    assert lv.version == ['2', '2', 'beta', '29']


# Generated at 2022-06-20 16:39:50.575636
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Version: the base class for version numbering classes
    # This may also be assigned to an instance.
    v1 = Version()
    # The constructor will accept a string.
    v2 = Version('1.2')
    # Or any object that can be converted to a string.
    v3 = Version(object())
    # A version number is useful for comparison.
    # You can compare any two version numbers, or a version number
    # with a string (which will be converted to a version number first)
    assert v1 <= '1.2'
    assert v1 < '1.2'
    # The rich comparison methods have the same semantics as the
    # underlying _cmp method (so you can implement __lt__ in terms
    # of __le__, for example)
    assert (v1 < v2) == (v1 <= v2)


# Generated at 2022-06-20 16:39:52.238698
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version().__repr__() == "Version ('0')"
    assert Version('0').__repr__() == "Version ('0')"

# Generated at 2022-06-20 16:40:02.853847
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert (v >= 1) == NotImplemented



# Generated at 2022-06-20 16:40:04.440820
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert v.__repr__() == "Version ('0')"

# Generated at 2022-06-20 16:40:06.547665
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    l = LooseVersion('1.2.34')
    assert repr(l) == "LooseVersion ('1.2.34')", repr(l)


# Generated at 2022-06-20 16:40:09.301563
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    ''' Test whether string representation of a version is correct. '''
    assert LooseVersion('1.0').__str__() == '1.0'
    assert LooseVersion('1').__str__() == '1'


# Generated at 2022-06-20 16:40:15.792803
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v1 = StrictVersion("1.0")
    assert str(v1) == "1.0", "version string mismatch"
    assert v1.version == (1, 0, 0), "version component mismatch"
    assert v1.prerelease is None, "prerelease component mismatch"
    assert repr(v1) == "StrictVersion ('1.0')", "version repr mismatch"

    assert StrictVersion("1.4.2").version == (1, 4, 2), \
           "version component mismatch"
    assert StrictVersion("1.4.2").prerelease is None,\
           "prerelease component mismatch"

    assert StrictVersion("1.4.2b1").version == (1, 4, 2), \
           "version component mismatch"

# Generated at 2022-06-20 16:40:22.666204
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    # Create an instance of the Version class
    v1 = Version()
    # Create an instance of the Version class
    v2 = Version()
    
    # Call the __lt__ method of v1 on the parameter v2
    res = v1.__lt__(v2)
    # Assert the result is NotImplemented
    assert res is NotImplemented, "Expected NotImplemented"
    

# Generated at 2022-06-20 16:40:33.201402
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert str(StrictVersion("1.0")) == "1.0"
    assert str(StrictVersion("1.0.0")) == "1.0"
    assert str(StrictVersion("1.0.1")) == "1.0.1"
    assert str(StrictVersion("1.0a1")) == "1.0a1"
    assert str(StrictVersion("1.0b3")) == "1.0b3"
    assert str(StrictVersion("1.0.4a3")) == "1.0.4a3"
    assert str(StrictVersion("1.0.4b1")) == "1.0.4b1"

    assert str(StrictVersion("1.0rc1")) == "1.0rc1"

# Generated at 2022-06-20 16:40:40.240951
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    """Test the constructor of class LooseVersion"""

    version = LooseVersion("1.5.1")
    assert version.vstring == "1.5.1"
    assert version.version == [1, "5", 1]

    version = LooseVersion("161")
    assert version.vstring == "161"
    assert version.version == [161]

    version = LooseVersion("1.2.0")
    assert version.vstring == "1.2.0"
    assert version.version == [1, "2", 0]

    version = LooseVersion("1.2a1")
    assert version.vstring == "1.2a1"
    assert version.version == [1, "2", "a", 1]

    version = LooseVersion("1.2.a1")
    assert version.vstring

# Generated at 2022-06-20 16:40:50.473476
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:40:56.403900
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    assert LooseVersion('11g').version == [11, 'g']
    assert LooseVersion('1.13++').version == [1, 13, '++']
    assert LooseVersion('1.2.3.4').version == [1, 2, 3, 4]
    assert LooseVersion('2.2beta29').version == [2, 2, 'beta', 29]


# Generated at 2022-06-20 16:41:17.816999
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest

    class Version___gt___TestCase(unittest.TestCase):
        def test_gt(self):
            '''Test __gt__ method of Version class'''
            version = Version('1.0')
            self.assertTrue(version.__gt__(version))
            self.assertTrue(version > version)

    return unittest.makeSuite(Version___gt___TestCase)

if __name__ == "__main__":
    from unittest import TextTestRunner, TestSuite
    tests = TestSuite()
    tests.addTest(test_Version___gt__())
    runner = TextTestRunner()
    runner.run(tests)



# Generated at 2022-06-20 16:41:21.605857
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    r = Version('n')
    r < ''

# Generated at 2022-06-20 16:41:31.196666
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    LooseVersion.parse(LooseVersion(),'1.5.1')
    LooseVersion.parse(LooseVersion(),'1.5.2b2')
    LooseVersion.parse(LooseVersion(),'161')
    LooseVersion.parse(LooseVersion(),'3.10a')
    LooseVersion.parse(LooseVersion(),'8.02')
    LooseVersion.parse(LooseVersion(),'3.4j')
    LooseVersion.parse(LooseVersion(),'1996.07.12')
    LooseVersion.parse(LooseVersion(),'3.2.pl0')
    LooseVersion.parse(LooseVersion(),'3.1.1.6')
    LooseVersion.parse(LooseVersion(),'2g6')

# Generated at 2022-06-20 16:41:34.389686
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.2.3')
    assert repr(v) == "Version ('1.2.3')"


# Generated at 2022-06-20 16:41:40.616383
# Unit test for method __le__ of class Version
def test_Version___le__():
    test_cases = []
    test_cases.append(("'0.0', '0.1'", False))
    test_cases.append(("'0.9', '0.10'", False))
    test_cases.append(("'0.99', '0.100'", False))
    test_cases.append(("'1.0', '0.1'", True))
    test_cases.append(("'0.1', '0.0'", True))
    test_cases.append(("'0.1', '0.0'", True))
    test_cases.append(("'0.10', '0.9'", True))
    test_cases.append(("'0.100', '0.99'", True))

# Generated at 2022-06-20 16:41:45.001595
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # test the StrictVersion constructor
    v = StrictVersion("1.0a1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)
    assert str(v) == "1.0a1"

    v = StrictVersion("1.0.0.0")
    assert v.version == (1, 0, 0)
    assert str(v) == "1.0"

    v = StrictVersion("1.0")
    assert v.version == (1, 0, 0)
    assert str(v) == "1.0"

    v = StrictVersion("1.0b2")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('b', 2)

# Generated at 2022-06-20 16:41:51.119683
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert str(LooseVersion('1.2.3')) == '1.2.3'
    assert str(LooseVersion('1.2')) == '1.2'
    assert str(LooseVersion('1')) == '1'
    assert str(LooseVersion('1.2a3')) == '1.2a3'
    assert str(LooseVersion('1.2.a3')) == '1.2.a3'

    assert str(LooseVersion('1.2.0')) == '1.2'
    assert str(LooseVersion('1.00.3')) == '1.0.3'
    assert str(LooseVersion('1.002.003')) == '1.2.3'

# Generated at 2022-06-20 16:42:00.754693
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def test(version_str, major, minor, patch, prerelease):
        v = StrictVersion()
        v.parse(version_str)
        assert v.version == (int(major), int(minor), int(patch))
        assert v.prerelease == (prerelease[0], int(prerelease[1:]))

    test("0.4.0", 0, 4, 0, "")
    test("0.4", 0, 4, 0, "")
    test("0.4.1", 0, 4, 1, "")
    test("0.5a1", 0, 5, 0, "a1")
    test("0.5b3", 0, 5, 0, "b3")
    test("0.5", 0, 5, 0, "")

# Generated at 2022-06-20 16:42:11.428793
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Test comparison
    # (LooseVersion should sort version strings by numeric parts, so
    # "1.5" and "1.5.0" would be equal and would compare as equal to
    # "1.5.0.0" -- but all would compare as less than "1.6", and the
    # last three would compare as less than "1.5.0.1")

    items = map(LooseVersion,
                ['1.5.0.0', '1.5.0', '1.5', '1.6', '1.5.0.1', '1.5.0a'])
    sorted_items = copy.copy(items)
    sorted_items.sort()
    for i in range(5):
        assert sorted_items[i] == items[i]

# Generated at 2022-06-20 16:42:18.901130
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Create a mock object with the same interface as Version
    other = type('other', (object,), {k: v for k, v in Version.__dict__.items() if not k.startswith('__')})

    # Constructor and repr
    version = Version()
    assert repr(version) == "Version ('None')"
    version = Version('1.2.3')
    assert repr(version) == "Version ('1.2.3')"

    # __eq__
    version = Version('1.2.3')
    assert version == '1.2.3'
    assert not version == '1.2.4'
    assert not version == '1.2.0'
    assert not version == other



# Generated at 2022-06-20 16:42:51.371785
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('0.4a1')) == '0.4a1'
    assert str(StrictVersion('0.4')) == '0.4'
    assert str(StrictVersion('0.4.1')) == '0.4.1'



# Generated at 2022-06-20 16:42:54.454410
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    try:
        v.__le__(('whatever',))
    except TypeError:
        pass


# Generated at 2022-06-20 16:42:56.821329
# Unit test for constructor of class Version
def test_Version():
    v = Version(None)
    assert v is not None



# Generated at 2022-06-20 16:43:00.617353
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion()
    v.parse('1.1.1')
    assert str(v) == '1.1.1', repr(str(v))

# Generated at 2022-06-20 16:43:05.467498
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    instances = [Version(vstring='1'), Version(vstring='2'), Version(vstring='1')]
    assert instances[0].__eq__(instances[2]) == True
    assert instances[0].__eq__(instances[1]) == False

# Generated at 2022-06-20 16:43:18.144121
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    for version in ['1.2.3', '1.2.0', '1.2', '0.2.0', '1.2a1', '1.2b1']:
        if len(version.split('.')) > 2:
            if version.split('.')[-1].startswith(('a', 'b')):
                versionstring = '%s.%s%d' % (version.split('.')[0], version.split('.')[1], 0)
                prerelease = (version.split('.')[-1][0], int(version.split('.')[-1][1:]))
            else:
                versionstring = '.'.join(version.split('.')[:3])
                prerelease = None

# Generated at 2022-06-20 16:43:28.600439
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vs in [
        "0.4.0", "0.4", "0.4.0.0", "0.4.1",
        "0.5a1", "0.5b3", "0.5",
        "0.960923", "0.960923.1",
        "1.0", "1.0.4a3", "1.0.4b1", "1.0.4",
        ]:
        v = StrictVersion(vs)

    for vs in ["1.3.0rc2", "1.3.0c2", "1.3pl1", "1.3c4"]:
        try:
            v = StrictVersion(vs)
        except ValueError:
            pass

# Generated at 2022-06-20 16:43:32.427002
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    std = StrictVersion("2.1.0beta1")
    assert std.version == (2, 1, 0)
    assert std.prerelease == ('b', 1)

# Generated at 2022-06-20 16:43:36.491171
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # sdist's setup.py creates a PKG-INFO file with a version string
    # taken verbatim from the module's __version__ attribute.
    # Make sure that this version string is acceptable to StrictVersion.
    StrictVersion(VERSION)



# Generated at 2022-06-20 16:43:43.854120
# Unit test for constructor of class Version
def test_Version():
    assert(Version('1').__repr__() == "Version ('1')")
    assert(Version('1.2').__repr__() == "Version ('1.2')")
    assert(Version('1.2.3').__repr__() == "Version ('1.2.3')")



# Generated at 2022-06-20 16:44:34.366179
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    str_obj = LooseVersion('1.2.3').__str__()
    assert str_obj == '1.2.3'


# Generated at 2022-06-20 16:44:36.035510
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion("1.22")
    assert isinstance(lv.version, list)
    assert lv.version == [1, 22]


# Generated at 2022-06-20 16:44:38.010591
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    version = Version()
    assert repr(version) == "Version ('None')"

# Generated at 2022-06-20 16:44:49.878716
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import LooseVersion
    v1 = Version('1.0')
    v2 = Version('2.0')
    lv1 = LooseVersion('1.0')
    lv2 = LooseVersion('2.0')
    assert(v1.__gt__(v2) == v2.__lt__(v1))
    assert(v2.__gt__(v1) == v1.__lt__(v2))
    assert(v1.__gt__(v1) == v1.__lt__(v1))
    assert(v2.__gt__(v2) == v2.__lt__(v2))
    assert(v1.__gt__(v2) == lv1.__gt__(lv2))

# Generated at 2022-06-20 16:44:54.192358
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_instances = []
    
    
    
    
    
    
    raise NotImplementedError("TODO: auto-generated method body.")

# Generated at 2022-06-20 16:44:57.681429
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1.__le__(v2) == True


# Generated at 2022-06-20 16:45:07.906662
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    def rep (v):
        return eval(repr(v))

    assert rep(LooseVersion("0")) == LooseVersion("0")
    assert rep(LooseVersion("0.0.0")) == LooseVersion("0.0.0")
    assert rep(LooseVersion("1.0")) == LooseVersion("1.0")
    assert rep(LooseVersion("1.0+")) == LooseVersion("1.0+")
    assert rep(LooseVersion("1.0-0")) == LooseVersion("1.0-0")
    assert rep(LooseVersion("1.0-pre")) == LooseVersion("1.0-pre")
    assert rep(LooseVersion("1.0rc1")) == LooseVersion("1.0rc1")
    assert rep(LooseVersion("1.0a5"))

# Generated at 2022-06-20 16:45:09.101337
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v.__le__()


# Generated at 2022-06-20 16:45:11.963596
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    v = Version('1.2.3')
    assert v.__gt__('1.2.3'), "Version('1.2.3').__gt__('1.2.3') failed"

# Generated at 2022-06-20 16:45:13.079661
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    with pytest.raises(AttributeError):
        Version().__lt__

