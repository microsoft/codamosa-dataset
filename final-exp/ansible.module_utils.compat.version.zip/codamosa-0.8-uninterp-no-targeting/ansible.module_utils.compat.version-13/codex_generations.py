

# Generated at 2022-06-20 16:36:11.081253
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    version._cmp = lambda a: 1
    assert version <= 1

# Generated at 2022-06-20 16:36:13.828651
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Test method __eq__ of class Version"""

    v = Version("1.4")
    assert(v == "1.4")
    assert(v == Version("1.4"))


# Generated at 2022-06-20 16:36:15.185583
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__(Version()) == NotImplemented

# Generated at 2022-06-20 16:36:19.310485
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.0') < Version('1.1')
    assert Version('1.1') < Version('1.2')
    assert not Version('1.1') < Version('1.1')
    assert not Version('1.2') < Version('1.1')




# Generated at 2022-06-20 16:36:21.273564
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('2.2.1dev')
    assert v.__str__() == '2.2.1dev'

# Generated at 2022-06-20 16:36:22.373774
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    pass


# Generated at 2022-06-20 16:36:25.637565
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2') <= Version('1.2.3')
    assert Version('1.2') <= '1.2.3'
    assert not (Version('1.2') > '1.2.3')
    assert not (Version('1.2') >= '1.2.3')


# Generated at 2022-06-20 16:36:34.324762
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion()
    assert str(lv) == ''
    assert repr(lv) == "LooseVersion ('')"

    # check that bogus constructor args are caught
    try:
        lv = StrictVersion()
    except Exception:
        pass
    else:
        assert False, "should have raised exception"

# What follows are the test cases that Greg Stein and I cooked up.  I've
# converted them to make use of the unittest module.  They are basically
# in the form of:
#   assert x < y
# where x and y are version number strings.  In some cases, the test is
# commented out; the comment indicates a test that the algorithm passes.
# Also, the tests are alphabetically ordered.
#
# Oh, yes: they pass under the LooseVersion scheme.  Dunno about
# St

# Generated at 2022-06-20 16:36:44.318869
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    a = StrictVersion("1.2.3a2")
    b = StrictVersion("1.2.3.a2")
    c = StrictVersion("1.2.3a2.0")
    d = StrictVersion("1.2.3a2")
    e = StrictVersion("1.2.3a2.0")
    f = StrictVersion("1.2.3b3")
    g = StrictVersion("1.2.3")
    h = StrictVersion("1.2.4")
    i = StrictVersion("1.3.3")
    j = StrictVersion("2.2.3")
    k = StrictVersion("1.2.3a2.0.1")
    l = StrictVersion("1.2.3a2.1")
    m = St

# Generated at 2022-06-20 16:36:49.533797
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest

    class VersionSubclass(Version):
        def __init__(self, vstring=None):
            Version.__init__(self, vstring)
        def _cmp(self, other):
            return -1

    a = VersionSubclass('1.0')
    b = VersionSubclass('2.0')
    assert a < b



# Generated at 2022-06-20 16:37:11.893678
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert str(v) == '1.2.3'
    assert Version('1.1') == v

# Turn this off if you have a version of Python prior to 2.0

# Generated at 2022-06-20 16:37:14.250982
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version(vstring='1.2')
    assert repr(v) == "Version ('1.2')"
    assert repr(Version()) == "Version ('None')"

# Generated at 2022-06-20 16:37:26.445988
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    ver = StrictVersion("1.2.3")
    assert ver.version == (1, 2, 3)
    assert ver.prerelease is None
    ver = StrictVersion("1.2.3.4")
    assert ver.version == (1, 2, 3, 4)
    assert ver.prerelease is None
    ver = StrictVersion("1.2")
    assert ver.version == (1, 2, 0)
    assert ver.prerelease is None
    ver = StrictVersion("1")
    assert ver.version == (1, 0, 0)
    assert ver.prerelease is None
    ver = StrictVersion("1.2.3a4")
    assert ver.version == (1, 2, 3)
    assert ver.prerelease == ('a', 4)

# Generated at 2022-06-20 16:37:34.637249
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """
    Test LooseVersion.parse()
    """
    version = LooseVersion()
    version.parse('1.5.1')
    assert version.version == [1,5,1]
    version.parse('1.5.2b2')
    assert version.version == [1,5,2,'b',2]
    version.parse('161')
    assert version.version == [161]
    version.parse('3.10a')
    assert version.version == [3,10,'a']
    version.parse('8.02')

# Generated at 2022-06-20 16:37:39.029694
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import uuid
    v = Version()
    other = str(uuid.uuid4())
    c = v._cmp(other)
    if c is NotImplemented:
        c = 0
    assert v == c


# Generated at 2022-06-20 16:37:40.016139
# Unit test for method __le__ of class Version
def test_Version___le__():
    s = Version('1.0')
    assert (s <= '1.0')



# Generated at 2022-06-20 16:37:53.036618
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Constructor test - with, without arg
    str(LooseVersion())
    cmp(LooseVersion(), '0')
    cmp(LooseVersion('1.2.3'), '1.2.3')

    # Test __str__()
    assert str(LooseVersion('1.2.3')) == '1.2.3'
    assert str(LooseVersion('1.2.3a')) == '1.2.3a'
    assert str(LooseVersion('1.2.3a.4.5')) == '1.2.3a.4.5'
    assert str(LooseVersion('1.2.3.4.5')) == '1.2.3.4.5'

# Generated at 2022-06-20 16:37:59.206921
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    sv = StrictVersion
    tests = [   ( (1, 0), '1.0' ),
                ( (1, 0, 0), '1.0' ),
                ( (1, 1), '1.1' ),
                ( (1, 1, 0), '1.1' ),
                ( (1, 1, 1), '1.1.1' ),
                ( (1, 1, 1, 'a', 4), '1.1.1a4' ),
                ( (1, 1, 1, 'b', 6), '1.1.1b6' ),
              ]
    for (args, expected) in tests:
        assert str(sv(*args)) == expected


# Generated at 2022-06-20 16:38:01.937463
# Unit test for constructor of class Version
def test_Version():
    for vs in ('1.2.3', '1.2', '1.2rc1', '1.2.0.0', '1.2.0.0.0.0'):
        Version(vs)



# Generated at 2022-06-20 16:38:12.590891
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    '''Test of LooseVersion.parse'''
    def dt(v):
        return LooseVersion(v).version
    assert dt('1.3') == [1,3]
    assert dt('1.3.1') == [1,3,1]
    assert dt('1.3.1.2') == [1,3,1,2]
    assert dt('a.2.1') == ['a',2,1]
    assert dt('a.b.1') == ['a','b',1]
    assert dt('a.2.b') == ['a',2,'b']
    assert dt('a.2.1.b') == ['a',2,1,'b']

# Generated at 2022-06-20 16:38:37.775029
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    version_str = '1.0.4a3'
    v = StrictVersion(version_str)
    assert str(v) == version_str
    assert repr(v) == "StrictVersion ('1.0.4a3')"

    version_str = '1.0.4'
    v = StrictVersion(version_str)
    assert str(v) == version_str
    assert repr(v) == "StrictVersion ('1.0.4')"

    version_str = '1.0'
    v = StrictVersion(version_str)
    assert str(v) == version_str
    assert repr(v) == "StrictVersion ('1.0')"

    version_str = '1'
    v = StrictVersion(version_str)

# Generated at 2022-06-20 16:38:43.565377
# Unit test for method __le__ of class Version
def test_Version___le__():

    # Create an instance of the Version class
    version_obj = Version("Hello, world!")

    # Call the __le__ method of the object
    # Return True (or False) if the object is (or is not) less than or equal to
    # an object of the same class
    return version_obj.__le__("Hello, world!")


# Generated at 2022-06-20 16:38:47.775596
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.2.3b4")
    assert v.__str__() == "1.2.3b4"


# Generated at 2022-06-20 16:38:52.255146
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    v1 = Version("1.2.3")
    v2 = Version("1.2.4")
    return v1 > v2


# Generated at 2022-06-20 16:38:56.326102
# Unit test for method __le__ of class Version
def test_Version___le__():
    import datetime
    now = datetime.datetime.now()
    vstring = str(now)
    v = Version(vstring)
    assert vstring == str(v)
    assert Version.__le__(v, vstring)

# Generated at 2022-06-20 16:38:57.132018
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version().__repr__() == "Version ()"



# Generated at 2022-06-20 16:39:02.638881
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    global Version
    global RE_FLAGS
    # Test number generator.
    import random
    random.seed(1)

    def gen_version_string(max_parts=3, max_fields=3, max_value=1000):
        parts = []
        for _ in range(random.randint(1, max_parts)):
            fields = []
            for _ in range(random.randint(1, max_fields)):
                fields.append(str(random.randint(0, max_value)))
            parts.append('.'.join(fields))

        if random.randint(0, 2) == 0:
            # Add a suffix.
            suffix_chars = [chr(random.randint(ord('a'), ord('z'))) for _ in range(random.randint(1, 10))]
           

# Generated at 2022-06-20 16:39:05.612525
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # Verify the __repr__ method correctly returns the string representation
    # of the object
    from packaging.version import LooseVersion
    from packaging.version import _impl as version_impl
    for case in version_impl.__test_cases:
        test_version = LooseVersion(case)
        expected_repr = "LooseVersion('%s')" % test_version
        assert repr(test_version) == expected_repr

# Generated at 2022-06-20 16:39:15.270266
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    v3 = Version()
    assert v1 is None
    assert v2 is None
    assert v3 == 0
    assert v3 == 1
    assert v3 >= 1
    assert v3 >= 2
    assert v3 >= 0
    assert v3 >= 1
    assert v3 >= 0
    assert v3 >= 2
    assert v3 >= 0
    assert v3 >= 1
    assert v3 >= 1
    assert v3 >= 0
    assert v3 >= 0
    assert v3 >= 2
    assert v3 >= 0
    assert v3 >= 0
    assert v3 >= 1
    assert v3 >= 1
    assert v3 >= 1
    assert v3 >= 1
    assert v3 >= 2


# Generated at 2022-06-20 16:39:17.341694
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    ver = Version()
    assert repr(ver) == "Version ('0')"


# Generated at 2022-06-20 16:40:01.403356
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version("0.0")
    v2 = Version("0.1")
    assert v1 >= v2

    v1 = Version("0.0")
    v2 = Version("0.1")
    assert not v2 >= v1

    v1 = Version("0.0")
    v2 = Version("0.1")
    assert v1 >= "0.0"

    v1 = Version("0.0")
    v2 = Version("0.1")
    assert v2 >= "0.1"

    v1 = Version("0.0")
    v2 = Version("0.1")
    assert not "0.0" >= v2

    v1 = Version("0.0")
    v2 = Version("0.1")
    assert not "0.1" >= v1

# Generated at 2022-06-20 16:40:09.881765
# Unit test for method __le__ of class Version
def test_Version___le__():
    from ninemlcatalog.incoming import (
        LooseVersion, StrictVersion, version_cmp)
    # Tests taken directly from Python's test_distutils

# Generated at 2022-06-20 16:40:13.669571
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    obj = Version()
    obj.parse('1.0.0')
    assert obj.__ge__('1.0.0')
    obj.parse('1.0.1')
    assert obj.__ge__('1.0.0')

# Generated at 2022-06-20 16:40:25.627822
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Check instantiation from string
    lv = LooseVersion("1.2.3.4")
    assert lv.version == [1, 2, 3, 4], lv.version
    # Check instantiation from tuple
    lv = LooseVersion((1, 2, 3, 4))
    assert lv.version == [1, 2, 3, 4], lv.version
    # Check that tuple conversion works
    assert lv.version == list(lv), list(lv)
    # Check instantiation from LooseVersion
    lv2 = LooseVersion(lv)
    assert lv.version == lv2.version
    # Check comparison
    assert lv == lv2
    lv2.version = [1, 2, 5, 4]
    assert lv < lv2
    assert lv2 > lv

# Generated at 2022-06-20 16:40:30.043625
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version('').__repr__() == "Version ('%s')" % ''
    assert Version('1').__repr__() == "Version ('%s')" % '1'
    assert Version('1.2').__repr__() == "Version ('%s')" % '1.2'
    assert Version('1.2.3').__repr__() == "Version ('%s')" % '1.2.3'
    assert Version('1.2.3.4').__repr__() == "Version ('%s')" % '1.2.3.4'
    assert Version('1.2.3.4.5').__repr__() == "Version ('%s')" % '1.2.3.4.5'
    assert Version('1.2.3.4.5.6').__

# Generated at 2022-06-20 16:40:38.542835
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1.2.2').__repr__() == "LooseVersion ('1.2.2')"
    assert LooseVersion('1.2.2').__repr__() == "LooseVersion ('1.2.2')"
    assert LooseVersion('1.2.2').__repr__() == "LooseVersion ('1.2.2')"
    assert LooseVersion('1.2.2').__repr__() == "LooseVersion ('1.2.2')"
    assert LooseVersion('1.2.2').__repr__() == "LooseVersion ('1.2.2')"
    assert LooseVersion('1.2.2').__repr__() == "LooseVersion ('1.2.2')"
    assert LooseVersion('1.2.2').__

# Generated at 2022-06-20 16:40:41.709525
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    from Test import test_support
    version = LooseVersion('1.2a1')
    assert not test_support.run_unittest(test_LooseVersion___repr__)

# Generated at 2022-06-20 16:40:53.422820
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion('1.2.3')
    if v.version != ['1', '2', '3']:
        return 1

    v = LooseVersion('1.2.3.4')
    if v.version != ['1', '2', '3', '4']:
        return 2

    v = LooseVersion('1.2.3-alpha')
    if v.version != ['1', '2', '3', 'alpha']:
        return 3

    v = LooseVersion('1.2.3-alpha-1')
    if v.version != ['1', '2', '3', 'alpha', '1']:
        return 4

    v = LooseVersion('1.2.3-10')
    if v.version != ['1', '2', '3', '10']:
        return 5

# Generated at 2022-06-20 16:40:57.286349
# Unit test for constructor of class Version
def test_Version():
    """
    >>> V = Version()
    >>> str(V)
    ''
    >>> repr(V)
    "Version ('')"
    >>> V.parse("101")
    >>> str(V)
    '101'
    >>> repr(V)
    "Version ('101')"
    """



# Generated at 2022-06-20 16:41:04.689626
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-20 16:41:37.612933
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert (Version().__le__(Version()))

# Generated at 2022-06-20 16:41:48.960625
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    """pytest for method parse of class strictVersion"""
    test_cases = [
        ("0.4", "0.4"),
        ("0.4.0", "0.4"),
        ("0.4.1", "0.4.1"),
        ("0.5a1", "0.5.0a1"),
        ("0.5b3", "0.5.0b3"),
        ("0.5", "0.5"),
        ("0.9.6", "0.9.6"),
        ("1.0", "1.0"),
        ("1.0.4a3", "1.0.4a3"),
        ("1.0.4b1", "1.0.4b1"),
        ("1.0.4", "1.0.4"),
    ]

# Generated at 2022-06-20 16:41:52.557780
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('1.2')
    assert v > '1.1'
    assert not (v > '1.2')



# Generated at 2022-06-20 16:41:57.467606
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # test_Version___eq__()
    # Test that subclass instances compare correctly with other Version instances.
    class A(Version):
        def parse(self, vstring):
            self.data = len(vstring)

    class B(Version):
        def parse(self, vstring):
            self.data = int(vstring)

    x = A('123')
    y = B('123')
    assert x == y
    assert y == x
    assert not (x != y)
    assert not (x < y)
    assert not (x > y)
    assert x <= y
    assert x >= y
    assert not (y < x)
    assert not (y > x)
    assert y <= x
    assert y >= x



# Generated at 2022-06-20 16:42:01.457282
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    L = [('0.4', (0, 4)),
         ('1.0', (1, 0)),
         ('2.7.3', (2, 7, 3))
         ]
    for s, v in L:
        assert StrictVersion(s).version == v
        assert str(StrictVersion(s)) == s



# Generated at 2022-06-20 16:42:07.172258
# Unit test for constructor of class Version
def test_Version():
    for version in ["1.1", "1.2.3", "1.2.3a", "1.2.3b"]:
        v = Version(version)
        assert str(v) == version
        assert repr(v) == "Version ('%s')" % version



# Generated at 2022-06-20 16:42:17.952738
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import pytest
    from distutils2.version import Version
    # Test 1, 2
    # Test 1: test __lt__, __le__
    # Test 2: test __gt__, __ge__
    v1 = Version('1.0')
    assert v1.__lt__(v1) == False
    assert v1.__le__(v1) == True
    assert v1.__gt__(v1) == False
    assert v1.__ge__(v1) == True
    # Test 1, 2
    v2 = Version('1.0')
    v3 = Version('1.1')
    v4 = Version('1.2')
    v5 = Version('1.10')
    assert v1.__lt__(v3) == True
    assert v1.__lt__(v4)

# Generated at 2022-06-20 16:42:20.068663
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  # No easy way to test this method
  assert True


# Generated at 2022-06-20 16:42:28.970994
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring):
        return str(StrictVersion(vstring))
    assert test("1.0") == "1.0"
    assert test("1.3.0") == "1.3"
    assert test("1.4a4") == "1.4a4"
    assert test("1.4b6") == "1.4b6"
    assert test("1.5.0b6") == "1.5b6"
    try:
        test("1")
    except ValueError:
        pass
    else:
        assert 0, "constructor failed to raise ValueError"
    try:
        test("1.4a4.1")
    except ValueError:
        pass
    else:
        assert 0, "constructor failed to raise ValueError"



# Generated at 2022-06-20 16:42:33.399780
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test __gt__ of Version"""
    assert Version('2.0') > Version('1.5')
    assert Version('2.0') > '1.5'
    assert not Version('1.5') > Version('1.5')
    assert not Version('1.5') > Version('2.0')
    assert not Version('1.5') > '2.0'
test_Version___gt__() # Run the unit test

# Generated at 2022-06-20 16:43:35.666524
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.2.3')
    assert lv.__str__() == '1.2.3'


# Generated at 2022-06-20 16:43:40.334242
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version, _LooseVersion, _StrictVersion
    from distutils.version import _LegacyVersion

    # The following test suite compares all the possible combinations
    # between the three version classes: _StrictVersion, _LooseVersion
    # and _LegacyVersion.
    def test_comparison(v1, v2, expected_cmp, expected_eq):
        cmp_value = v1.__cmp__(v2)
        eq_value = v1 == v2
        print('cmp(%r, %r) -> %r' % (v1, v2, cmp_value))
        print('%r == %r -> %r' % (v1, v2, eq_value))
        assert cmp_value == expected_cmp
        assert eq_value == expected_eq

    # Test

# Generated at 2022-06-20 16:43:50.337838
# Unit test for method __le__ of class Version

# Generated at 2022-06-20 16:43:54.340702
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2.0')
    assert repr(v) == "LooseVersion ('1.2.0')", repr(v)

if __name__ == '__main__':
    test()

# Generated at 2022-06-20 16:43:58.694736
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """test method __str__ of class LooseVersion"""
    v = LooseVersion('123.456.789.0')
    assert str(v) == '123.456.789.0'


# Generated at 2022-06-20 16:44:02.428630
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.2')
    assert v.__str__() == '1.2'
    


# Generated at 2022-06-20 16:44:08.701578
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    from distutils.version import StrictVersion as SV
    assert SV("1.0").__str__() == "1.0"
    assert SV("1.0.1").__str__() == "1.0.1"
    assert SV("1.0.1a1").__str__() == "1.0.1a1"



# Generated at 2022-06-20 16:44:12.231494
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    v.parse('1.0')
    assert v.__repr__() == "Version ('1.0')"


# Generated at 2022-06-20 16:44:13.128340
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    Version("1.2") == Version("1.2")


# Generated at 2022-06-20 16:44:14.869689
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__(1) == NotImplemented
