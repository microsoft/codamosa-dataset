

# Generated at 2022-06-20 16:36:14.638320
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) == NotImplemented


# Generated at 2022-06-20 16:36:15.954743
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    VERSION_CLASSES.test_Version___ge__(Version)


# Generated at 2022-06-20 16:36:24.948177
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vs in ["0.4", "0.4.0", "0.4.1",
               "0.5a1", "0.5b3", "0.5",
               "0.9.6", "1.0", "2.7.2.2",
               "1.0.4a3", "1.0.4b1", "1.0.4"]:
        StrictVersion(vs)

    for vs in ["", "1", "1.3.a4", "1.3pl1", "1.3c4"]:
        try:
            StrictVersion(vs)
        except ValueError:
            pass
        else:
            raise AssertionError("testing version number %s" % vs)


# Generated at 2022-06-20 16:36:27.969980
# Unit test for method __le__ of class Version
def test_Version___le__():
    if hasattr(Version, '__le__'):
        print("method Version.__le__ exists")
    else:
        print("method Version.__le__ not found")


# Generated at 2022-06-20 16:36:29.633501
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  v1 = Version('1')
  v2 = Version('1')
  v3 = Version('2')
  assert(v1 == v2)
  assert(v1 != v3)


# Generated at 2022-06-20 16:36:31.671032
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert str(repr(Version("1"))) == "%s ('%s')" % ('Version', "1")

# Generated at 2022-06-20 16:36:35.960321
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test different types of version string
    assert LooseVersion('') == LooseVersion('')
    assert LooseVersion('').parse('') == LooseVersion('')
    assert LooseVersion('') != LooseVersion('1')
    assert LooseVersion('').parse('') != LooseVersion('1')
    assert LooseVersion('') != LooseVersion('1.1')
    assert LooseVersion('').parse('') != LooseVersion('1.1')
    assert LooseVersion('') != LooseVersion('1.1.1')
    assert LooseVersion('').parse('') != LooseVersion('1.1.1')
    assert LooseVersion('') != LooseVersion('1a1.1a1.1a1')

# Generated at 2022-06-20 16:36:44.833485
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2.3pl4').__str__() == '1.2.3pl4'
    assert StrictVersion('1.2.3a5').__str__() == '1.2.3a5'
    assert StrictVersion('1.2.3b6').__str__() == '1.2.3b6'
    assert StrictVersion('1.2').__str__() == '1.2'
    assert StrictVersion('1.2a3').__str__() == '1.2a3'
    assert StrictVersion('1.2a').__str__() == '1.2a0'

# Generated at 2022-06-20 16:36:47.213169
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("2.7")
    assert v.__str__() == "2.7"


# Generated at 2022-06-20 16:36:49.117081
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion()
    assert repr(lv) == "LooseVersion ('')"


# Generated at 2022-06-20 16:37:00.715927
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    version = LooseVersion('1.2.3a2')
    assert version.version == [1, 2, 3, 'a', 2]


# Generated at 2022-06-20 16:37:07.554466
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import pytest
    from pytest import raises
    #

    # Case 1: Two versions are equal
    #   Step 1: Instantiate the version string with '1.2.3'
    #   Step 2: Instantiate the version string with '1.2.3'
    #   Step 3: Compare the versions with the __eq__ operator
    #   Step 4: Verify that the result of the __eq__ operator is True
    # Case 2: Two versions are not equal
    #   Step 1: Instantiate the version string with '1.2.3'
    #   Step 2: Instantiate the version string with '1.2.4'
    #   Step 3: Compare the versions with the __eq__ operator
    #   Step 4: Verify that the result of the __eq__ operator is False
    # Case 3: Two versions are equal
    #  

# Generated at 2022-06-20 16:37:09.463293
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    instance = LooseVersion()
    instance.parse('1.5.1.4')
    expected = '1.5.1.4'
    actual = instance.__str__()
    assert expected == actual, 'expected: %r, but got: %r' % (expected, actual)



# Generated at 2022-06-20 16:37:19.613494
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # catch all the errors we possibly can
    for vstring in ('1.2', '1.2.3', '1.2.3a4', '1.2.3b5', '1.2.3c6',
                    '1.0.0.0', '1'):
        sv = StrictVersion(vstring)
        v = str(sv)
        if v != vstring:
            raise AssertionError("str(%s(%s)) != %s" % \
                (StrictVersion.__name__, vstring, vstring))

# Generated at 2022-06-20 16:37:29.895844
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Test Version.__lt__"""

    # test_Version_method___lt__:13
    assert (Version() < Version()) is False, 'test_Version_method___lt__:14'

    # test_Version_method___lt__:15
    assert (Version('1.9') < Version('1.9')) is False, 'test_Version_method___lt__:16'

    # test_Version_method___lt__:17
    assert (Version('1.9') < Version('1.10')) is True, 'test_Version_method___lt__:18'

    # test_Version_method___lt__:19
    assert (Version('1.10') < Version('1.9')) is False, 'test_Version_method___lt__:20'

    # test_Version_method___lt__:21
   

# Generated at 2022-06-20 16:37:36.585427
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('0.2').vstring == '0.2'
    assert LooseVersion('1.1.1').vstring == '1.1.1'
    assert LooseVersion('1.0.dev').vstring == '1.0.dev'
    assert LooseVersion('1.0a1.dev').vstring == '1.0a1.dev'
    assert LooseVersion('1.0a1.dev456').vstring == '1.0a1.dev456'
    assert LooseVersion('1.0a1.dev456').vstring == '1.0a1.dev456'
    assert LooseVersion('1.0a12.dev456').vstring == '1.0a12.dev456'

# Generated at 2022-06-20 16:37:39.096479
# Unit test for method __gt__ of class Version
def test_Version___gt__():
  ver = Version()
  assert gt(ver, other) == c > 0, 'AssertionError: %s' % repr(c > 0)



# Generated at 2022-06-20 16:37:41.363507
# Unit test for constructor of class Version
def test_Version():
    for vstring in ('0','0.4','0.4.1','0.4.2a1','0.4.2b3','0.4.2c1','0.4.2'):
        Version(vstring)



# Generated at 2022-06-20 16:37:52.505386
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:37:56.527226
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():

    # Test class LooseVersion with different strings
    # Method __str__ create string with remove spaces in string
    # Check the result of method
    test_LooseVersion = LooseVersion("test 1")
    assert test_LooseVersion.__str__() == "test1"
    assert not test_LooseVersion.__str__() == "test 1"
    assert test_LooseVersion.__str__() == "test1"

    test_LooseVersion = LooseVersion("test 1.0")
    assert test_LooseVersion.__str__() == "test1.0"
    assert not test_LooseVersion.__str__() == "test 1.0"

    test_LooseVersion = LooseVersion("test 1.0.0")

# Generated at 2022-06-20 16:38:14.997896
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion

    version = v('1.0')
    assert(tuple(version.version) == (1, 0, 0))
    assert(version.prerelease == None)
    assert(str(version) == '1.0')

    version = v('1.0.0')
    assert(tuple(version.version) == (1, 0, 0))
    assert(version.prerelease == None)
    assert(str(version) == '1.0.0')

    version = v('1.0a1')
    assert(tuple(version.version) == (1, 0, 0))
    assert(version.prerelease == ('a', 1))
    assert(str(version) == '1.0a1')

    version = v('1.0.0a1')

# Generated at 2022-06-20 16:38:16.281970
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("0.4").__str__() == "0.4"



# Generated at 2022-06-20 16:38:24.031570
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:38:31.211567
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("0.4.0")
    assert v.version == (0, 4, 0) and v.prerelease is None
    assert str(v) == '0.4.0'

    v = StrictVersion("0.4")
    assert v.version == (0, 4, 0) and v.prerelease is None
    assert str(v) == '0.4'

    v = StrictVersion("0.4.1")
    assert v.version == (0, 4, 1) and v.prerelease is None
    assert str(v) == '0.4.1'

    v = StrictVersion("0.5a1")
    assert v.version == (0, 5, 0) and v.prerelease == ('a', 1)
    assert str(v) == '0.5a1'

# Generated at 2022-06-20 16:38:34.410034
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    a = LooseVersion("1.2")
    b = LooseVersion("1.2.3")
    assert a < b
    assert a <= b
    assert a != b
    assert b >= a
    assert b > a
    assert 666 == b   # no == b[2] in LooseVersion...


# Generated at 2022-06-20 16:38:39.911995
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    c = LooseVersion()
    c.parse("1.5.1")
    ss = str(c)
    assert ss == "1.5.1", "Failed test 1"
    c.parse("1.5.2b2")
    ss = str(c)
    assert ss == "1.5.2b2", "Failed test 2"
    c.parse("1.51")
    ss = str(c)
    assert ss == "1.51", "Failed test 3"
    c.parse("8.02")
    ss = str(c)
    assert ss == "8.02", "Failed test 4"
    c.parse("3.4j")
    ss = str(c)
    assert ss == "3.4j", "Failed test 5"

# Generated at 2022-06-20 16:38:46.782356
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Create a LooseVersion instance
    v = LooseVersion('1.2.3.4')
    # Make sure that works
    assert str(v) == '1.2.3.4'
    # Make sure the instance can be pickled and unpickled with no lossage
    for proto in range(0, pickle.HIGHEST_PROTOCOL + 1):
        s = pickle.dumps(v, proto)
        v1 = pickle.loads(s)
        assert v.version == v1.version


if __name__ == "__main__":
    import test_version
    test_version.main()

# Generated at 2022-06-20 16:38:47.493773
# Unit test for method __le__ of class Version
def test_Version___le__():
  """__le__(self, other)"""
  pass


# Generated at 2022-06-20 16:38:53.033570
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    from distutils.version import LooseVersion
    from distutils.version import StrictVersion
    v1 = StrictVersion("1.0.0")
    v2 = LooseVersion("1.0a1")
    v3 = StrictVersion("1.0.1")
    assert(v1 <= v2)
    assert(v2 <= v3)
    assert(v1 <= v3)


# Generated at 2022-06-20 16:39:00.411245
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    version = Version('1')
    assert version < '2', 'must be True'
    assert version < 2, 'must be True'

    assert version < '1.1', 'must be True'
    assert version < 1.1, 'must be True'

    assert version < '1.0.1', 'must be True'

# Generated at 2022-06-20 16:39:25.422299
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion("0.4")) == "0.4"
    assert str(StrictVersion("0.4.0")) == "0.4.0"
    assert str(StrictVersion("0.4.1")) == "0.4.1"
    assert str(StrictVersion("0.5a1")) == "0.5a1"
    assert str(StrictVersion("0.5b3")) == "0.5b3"
    assert str(StrictVersion("0.5")) == "0.5"
    assert str(StrictVersion("0.9.6")) == "0.9.6"
    assert str(StrictVersion("1.0")) == "1.0"
    assert str(StrictVersion("1.0.4a3")) == "1.0.4a3"


# Generated at 2022-06-20 16:39:28.880010
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('123.456.789.0')
    assert eval(lv.__repr__()) == lv


# end class LooseVersion

# testcases for LooseVersion


# Generated at 2022-06-20 16:39:34.678759
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = distutils.version.LooseVersion('1.2.3.4')
    assert lv.__str__() == '1.2.3.4'
    lv = distutils.version.LooseVersion('abc')
    assert lv.__str__() == 'abc'

# Generated at 2022-06-20 16:39:37.309108
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    if StrictVersion('1.2.3') != StrictVersion('1.2.3'):
        raise AssertionError("version constructor or __eq__ is broken")



# Generated at 2022-06-20 16:39:47.078821
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    old_stdout = sys.stdout
    sys.stdout = StringIO()

# Generated at 2022-06-20 16:39:48.917789
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    other = Version()
    c = v._cmp(other)
    if c is NotImplemented:
        c
    return c > 0


# Generated at 2022-06-20 16:39:58.875154
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Note: Instances of LooseVersion and StrictVersion must be
    # constructed via their classes and not through the __init__
    # method of the Version class which is an abstract class.
    s = StrictVersion('1.0.4a3')
    assert s.parse('1.0.4a3') == ([1, 0, 4], ('a', 3))
    t = StrictVersion('1.0.4b1')
    assert t.parse('1.0.4b1') == ([1, 0, 4], ('b', 1))
    u = StrictVersion('1.0.4')
    assert u.parse('1.0.4') == ([1, 0, 4], None)
    v = StrictVersion('1.0')

# Generated at 2022-06-20 16:40:08.153757
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v = LooseVersion("1.4.4")
    assert str(v) == v.vstring
    v = LooseVersion("1.4.4-r1")
    assert str(v) == v.vstring
    v = LooseVersion("1.4.4.1")
    assert str(v) == v.vstring
    v = LooseVersion("1.4.4.1-r1")
    assert str(v) == v.vstring
    v = LooseVersion("1.4.4.1_rc2")
    assert str(v) == v.vstring
    v = LooseVersion("1.4.4.1-rc2")
    assert str(v) == v.vstring
    v = LooseVersion("1.4.4.1-r1_rc2")
   

# Generated at 2022-06-20 16:40:11.648669
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v1 = LooseVersion('1.2')
    assert v1.__str__() == '1.2'
    assert str(v1) == '1.2'
    assert v1 == '1.2'
    assert '1.2' == v1
    assert v1 == LooseVersion('1.2')


# Generated at 2022-06-20 16:40:14.121960
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3')
    assert v.__repr__() in ('Version (\'1.2.3\')',
                            'LooseVersion (\'1.2.3\')')


# Generated at 2022-06-20 16:40:43.278689
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-20 16:40:44.830161
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version('1')


# Generated at 2022-06-20 16:40:51.556990
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(('1.0')) == NotImplemented

    v = Version()
    v.parse('1.0')
    assert v.__le__(('1.0'))

    v = Version()
    v.parse('1.0')
    assert v.__le__(('0.0')) == False

    v = Version()
    v.parse('0.0')
    assert v.__le__(('1.0'))



# Generated at 2022-06-20 16:40:55.561080
# Unit test for constructor of class Version
def test_Version():
    class V(Version):
        def parse(self, vstring):
            self.vstring = vstring
    assert V('').vstring == ''
    assert V('abc').vstring == 'abc'


# Generated at 2022-06-20 16:40:57.614963
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion("1.10.4")
    assert str(v) == "1.10.4", str(v)


# Generated at 2022-06-20 16:41:04.818060
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-20 16:41:17.728427
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import nose.tools as nt
    # Test that the output of __str__ is what we expect
    # Try with various version numbers and with/without prereleases
    nt.assert_equal(str(StrictVersion("1.2.3")), "1.2.3")
    nt.assert_equal(str(StrictVersion("1.2")), "1.2")
    nt.assert_equal(str(StrictVersion("1")), "1.0")
    nt.assert_equal(str(StrictVersion("1.2.3a4")), "1.2.3a4")
    nt.assert_equal(str(StrictVersion("1.2.3b5")), "1.2.3b5")

# Generated at 2022-06-20 16:41:21.874122
# Unit test for constructor of class Version
def test_Version():
    'Version() returns instance that looks right'
    v = Version()
    assert v

# Unit tests for class Version

# Generated at 2022-06-20 16:41:26.308913
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """LooseVersion.__repr__"""
    lv = LooseVersion('12_3_')
    assert repr(lv) == "LooseVersion ('12_3_')"



# Generated at 2022-06-20 16:41:34.509807
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """Test if LooseVersion.__repr__() works as expected.

    Note:
      This test is not very useful, as it just tests if the call
      does not raise an exception.

    """
    f = LooseVersion("0.4.1")
    R = """LooseVersion ('0.4.1')"""
    assert(repr(f) == R)


# Generated at 2022-06-20 16:42:36.830454
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.0.0')
    return v >= '1' and v >= '1.0.0' and not v >= '2'
assert test_Version___ge__()


# Generated at 2022-06-20 16:42:40.112865
# Unit test for constructor of class Version
def test_Version():
    for vstring in ['1.2.3']:
        v = Version(vstring)
        assert str(v) == vstring


# Generated at 2022-06-20 16:42:43.776281
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("2.2.0a2")
    v2 = Version("2.2.0a1")
    assert v1 > v2

# Generated at 2022-06-20 16:42:56.837214
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    StrictVersion("1").parse("1")
    StrictVersion("1.2").parse("1.2")
    StrictVersion("1.2.3").parse("1.2.3")
    StrictVersion("1.2.3.4").parse("1.2.3.4")
    StrictVersion("1.2.3.4.5").parse("1.2.3.4.5")
    StrictVersion("1.2.3.4.5.6").parse("1.2.3.4.5.6")
    StrictVersion("1.2.3.4.5.6.7").parse("1.2.3.4.5.6.7")

# Generated at 2022-06-20 16:43:02.005299
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def check_parse(value, expected_return):
        v = StrictVersion(value)
        assert v.version == expected_return.version
        assert v.prerelease == expected_return.prerelease

    def check_parse_raises(value, exceptionType):
        try:
            StrictVersion(value)
        except exceptionType:
            pass
        else:
            pytest.fail(f"expected {exceptionType} exception")

    check_parse("1.2.3a4", StrictVersion("1.2.3a4"))

    check_parse("1.2.3b4", StrictVersion(" 1.2.3b4"))

    check_parse("1.2.3a4", StrictVersion("1.2.3a4 "))


# Generated at 2022-06-20 16:43:04.192149
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == '1'

# Generated at 2022-06-20 16:43:17.852149
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    assert lv.parse("1.5.1")
    assert lv.parse("1.5.2b2")
    assert lv.parse("161")
    assert lv.parse("3.10a")
    assert lv.parse("8.02")
    assert lv.parse("3.4j")
    assert lv.parse("1996.07.12")
    assert lv.parse("3.2.pl0")
    assert lv.parse("3.1.1.6")
    assert lv.parse("2g6")
    assert lv.parse("11g")
    assert lv.parse("0.960923")
    assert lv.parse("2.2beta29")
    assert lv.parse("1.13++")
    assert l

# Generated at 2022-06-20 16:43:25.944354
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():

    L = LooseVersion
    M = L('1.2.3.4')

    assert eval(repr(M)) == M

    class M(L):

        def __repr__(self):
            return 'Spam'

    assert eval(repr(M('1.2'))) == M('1.2')

    class M(L):

        def __init__(self, version):
            self.version = version

    assert eval(repr(M('1.2'))) == M('1.2')



# Generated at 2022-06-20 16:43:39.294922
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    for version, expected in [
        ('1.2.3.4', (1, 2, 3, '.', 4)),
        ('0.0', (0, 0)),
        ('1.2.3a1', (1, 2, 3, 'a', 1)),
        ('1.2.3b1', (1, 2, 3, 'b', 1)),
        ('1.2.3a10', (1, 2, 3, 'a', 10)),
        ('1.2.3b10', (1, 2, 3, 'b', 10))
    ]:
        sv = StrictVersion()
        sv.parse(version)
        result = sv.version + (sv.prerelease[0], sv.prerelease[1]) if sv.prerelease else sv.version
        assert result == expected


# Test the Strict

# Generated at 2022-06-20 16:43:43.378617
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Testing StrictVersion.__str__
    v1 = StrictVersion("1.0")
    assert str(v1) == "1.0"
    v2 = StrictVersion("1.0.0")
    assert str(v2) == "1.0"
    v3 = StrictVersion("1.0.0a1")
    assert str(v3) == "1.0a1"
    v4 = StrictVersion("1.0.0b1")
    assert str(v4) == "1.0b1"
