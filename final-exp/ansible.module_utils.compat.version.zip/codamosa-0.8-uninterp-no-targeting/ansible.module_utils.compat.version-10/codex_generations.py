

# Generated at 2022-06-20 16:36:16.787524
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion("1").version == (1, 0, 0)
    assert StrictVersion("1.2").version == (1, 2, 0)
    assert StrictVersion("1.2.3").version == (1, 2, 3)

    for v in ["1.2.dev456", "1.2a1", "1.2.a1", "1.2.1a2", "1.2.1.a2"]:
        try:
            StrictVersion(v)
        except ValueError:
            pass
        else:
            raise AssertionError("construction of %s shouldn't succeed" % v)


# Generated at 2022-06-20 16:36:18.339290
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('10') == 10

# Generated at 2022-06-20 16:36:26.546312
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    class Test:
        def __init__(self, vstring, parsed, exp_str):
            self.vstring = vstring
            self.parsed = parsed
            self.exp_str = exp_str


# Generated at 2022-06-20 16:36:31.111326
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version = StrictVersion('1.2.3')
    assert version.version == (1,2,3)
    assert version.prerelease is None
    version = StrictVersion('1.2.3a4')
    assert version.version == (1,2,3)
    assert version.prerelease == ('a', 4)
    version = StrictVersion('3.2a1')
    assert version.version == (3,2,0)
    assert version.prerelease == ('a', 1)
    version = StrictVersion('1.2b1')
    assert version.version == (1,2,0)
    assert version.prerelease == ('b', 1)


# Generated at 2022-06-20 16:36:32.753551
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.2.3.4")
    assert str(v) == "1.2.3.4"


# Generated at 2022-06-20 16:36:35.392385
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"
    assert LooseVersion('1.2.3').__repr__() != "LooseVersion ('1.2.3')"

# Generated at 2022-06-20 16:36:38.467766
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Implement your test here
    raise Exception("Test if not implemented")


# Generated at 2022-06-20 16:36:44.308656
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    if Version("0.0").__lt__("0.0"):
        raise RuntimeError("Failed")
    if Version("0.0") < "0.0":
        raise RuntimeError("Failed")
    if Version("0.0") == "0.0":
        raise RuntimeError("Failed")
    if not (Version("0.0") >= "0.0"):
        raise RuntimeError("Failed")
    if not (Version("0.0") <= "0.0"):
        raise RuntimeError("Failed")

# Generated at 2022-06-20 16:36:46.595765
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.0')
    assert v.__repr__() == "LooseVersion ('1.0')"

# Generated at 2022-06-20 16:36:47.699764
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert str(LooseVersion('1.2.3.4a1'))
    assert repr(LooseVersion('1.2.3.4a1'))



# Generated at 2022-06-20 16:37:03.982487
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion('1.0')
    assert v.version == (1,0,0)
    assert v.prerelease is None

    v = StrictVersion('1.0a1')
    assert v.version == (1,0,0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion('1.0b3')
    assert v.version == (1,0,0)
    assert v.prerelease == ('b', 3)


# Interface for version-number classes -- must be implemented
# by the following classes.
#    __init__ (string) - create and parse the given string
#    comparison operators (<, etc) - compare two version numbers
#    __str__ (self) - reconstruct string that created this version number
#    __repr__ (self) - generate Python code to recreate

# Generated at 2022-06-20 16:37:07.984675
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def make_StrictVersion(s):
        return StrictVersion(s).version

    assert make_StrictVersion('1.2.0') == (1, 2, 0)
    assert make_StrictVersion('1.2') == (1, 2, 0)


# Generated at 2022-06-20 16:37:11.684772
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest
    class MyTest(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_case_1(self):
            self.assertTrue(Version() >= '1')
    unittest.main()
test_Version___ge__()

# Generated at 2022-06-20 16:37:23.299985
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    import sys
    # Test case 1: nothing
    try:
        LooseVersion()
    except:
        print("FAIL: no string expected nothing to raise")
    else:
        print("FAIL: no string expected something to raise")
        sys.exit(1)

    # Test case 2: something
    try:
        LooseVersion("blah")
    except:
        print("FAIL: something (1) expected nothing to raise")
        sys.exit(1)
    else:
        print("ok")

    # Test case 3: something else
    try:
        LooseVersion("1.2.3rc1")
    except:
        print("FAIL: something else (2) expected nothing to raise")
        sys.exit(1)
    else:
        print("ok")



# Generated at 2022-06-20 16:37:23.994119
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(0) == NotImplemented


# Generated at 2022-06-20 16:37:30.093835
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    def __str__(self):
        if self.version[2] == 0:
            vstring = '.'.join(map(str, self.version[0:2]))
        else:
            vstring = '.'.join(map(str, self.version))

        if self.prerelease:
            vstring = vstring + self.prerelease[0] + str(self.prerelease[1])

        return vstring
    assert __str__(None) == None



# Generated at 2022-06-20 16:37:33.333082
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class A(Version):
        pass
    assert(A('1')>A('1'))

# Generated at 2022-06-20 16:37:34.753975
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert (Version() == Version()) is True


# Generated at 2022-06-20 16:37:36.455262
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    Version.__gt__(NotImplemented, None)


# Generated at 2022-06-20 16:37:47.693874
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def _test_cmp(a, b):
        av = StrictVersion(a)
        bv = StrictVersion(b)
        c = av._cmp(bv)
        if c < 0:
            print(av, " <", bv)
        elif c > 0:
            print(av, " >", bv)
        else:
            print(av, " ==", bv)


# Generated at 2022-06-20 16:38:11.882789
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse("1.5.2b2")
    assert (str(lv) == "1.5.2b2")
    lv.parse("161")
    assert (str(lv) == "161")
    lv.parse("8.02")
    assert (str(lv) == "8.02")
    lv.parse("3.4j")
    assert (str(lv) == "3.4j")
    lv.parse("1996.07.12")
    assert (str(lv) == "1996.07.12")
    lv.parse("1.13++")
    assert (str(lv) == "1.13++")
    lv.parse("5.5.kw")
    assert (str(lv) == "5.5.kw")

# Generated at 2022-06-20 16:38:13.890103
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    version._cmp = lambda self, other: other - 1
    assert version.__lt__(3) == True

# Generated at 2022-06-20 16:38:15.366056
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"

# Generated at 2022-06-20 16:38:18.691522
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3')
    assert str(v) == '1.2.3'


# Generated at 2022-06-20 16:38:21.110297
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert (v1 <= v2)
    assert (v1 >= v2)
    assert (v1 == v2)

# Generated at 2022-06-20 16:38:26.491328
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert str(LooseVersion('1.2')) == '1.2'
    assert str(LooseVersion('1.2.3')) == '1.2.3'
    assert str(LooseVersion('1.2b')) == '1.2b'
    assert str(LooseVersion('1.2.3a')) == '1.2.3a'
    assert str(LooseVersion('1.2pl3')) == '1.2pl3'
    assert str(LooseVersion('1.2.3pl1.4')) == '1.2.3pl1.4'


# Generated at 2022-06-20 16:38:32.424465
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from StringIO import StringIO

    import tokenize

    tokens = tokenize.generate_tokens(StringIO('LooseVersion("1.2")').readline)
    tmp = []
    while True:
        try:
            token = tokens.next()
        except StopIteration:
            break
        tmp.append(token)

    eq(tmp[0], (tokenize.NAME, 'LooseVersion', (1, 0), (1, 11), 'LooseVersion'))
    eq(tmp[1], (tokenize.OP, '(', (1, 11), (1, 12), '('))
    eq(tmp[2], (tokenize.STRING, '"1.2"', (1, 12), (1, 16), '"1.2"'))

# Generated at 2022-06-20 16:38:35.217169
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion("1.3.3")
    assert lv.vstring == "1.3.3"

import unittest


# Generated at 2022-06-20 16:38:39.108354
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.2.3')
    assert repr(v) == "Version ('1.2.3')"



# Generated at 2022-06-20 16:38:42.056269
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('1.0')) == '1.0'
    assert str(StrictVersion('1.0.0')) == '1.0'

# Generated at 2022-06-20 16:38:56.842326
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    s = LooseVersion('1.5.2b2')
    assert str(s) == '1.5.2b2'
    return



# Generated at 2022-06-20 16:38:58.686688
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v1 = LooseVersion('1.13++')
    assert (v1.__str__() == '1.13++')
    

# Generated at 2022-06-20 16:39:04.546999
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    from distutils2.version import StrictVersion

    v = StrictVersion('1.0.4b2')
    assert(str(v) == '1.0.4b2')

    v = StrictVersion('1.0.4b2.dev456')
    assert(str(v) == '1.0.4b2.dev456')

    v = StrictVersion('1.0.4a1.dev456')
    assert(str(v) == '1.0.4a1.dev456')

    v = StrictVersion('1.0.4rc2.dev456')
    assert(str(v) == '1.0.4rc2.dev456')

# Generated at 2022-06-20 16:39:08.651376
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    #
    #   Test that LooseVersion fails with non-version strings.
    #
    try:
        LooseVersion("Not a version")
    except ValueError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-20 16:39:10.705396
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    l = LooseVersion("abc.def")
    assert repr(l) == "LooseVersion ('abc.def')"

# Generated at 2022-06-20 16:39:21.451175
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # non-letters consisting of digits, dots, dashes, etc.
    assert LooseVersion('1.2.3a4') == LooseVersion('1.2.3a4')
    assert LooseVersion('1.2.3a4') == LooseVersion('1.2.3.a.4')
    assert LooseVersion('1.2.3a4.5') == LooseVersion('1.2.3a4.5')
    assert LooseVersion('1.2.3a4.5') == LooseVersion('1.2.3a4.005')
    assert LooseVersion('1.2.3a4.5') == LooseVersion('1.2.3a4.05')

# Generated at 2022-06-20 16:39:23.076973
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    r = Version()
    r.__class__ = Version

# Generated at 2022-06-20 16:39:24.668985
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    assert version.__gt__(None) == NotImplemented


# Generated at 2022-06-20 16:39:29.330436
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test 1
    lv = LooseVersion("1.5.1")
    assert lv.version == [1,5,1]
    # Test 2
    lv = LooseVersion("1.5.2b2")
    assert lv.version == [1,5,2,"b",2]
    # Test 3
    lv = LooseVersion("161")
    assert lv.version == [161]
    # Test 4
    lv = LooseVersion("3.10a")
    assert lv.version == [3,10,"a"]
    # Test 5
    lv = LooseVersion("8.02")
    assert lv.version == [8,2]
    # Test 6
    lv = LooseVersion("3.4j")

# Generated at 2022-06-20 16:39:32.704881
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.2.3.4')
    assert repr(v) == "Version ('1.2.3.4')"

# Generated at 2022-06-20 16:39:46.757633
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert repr(v) == "Version ('')"


# Generated at 2022-06-20 16:39:48.240596
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Test for __repr__ method of class Version
    assert str(Version('a')) == "Version ('a')"

# Generated at 2022-06-20 16:39:58.200483
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():

    def test_component_re_split(vstring, components):
        components = [x for x in LooseVersion.component_re.split(vstring) if x and x != '.']
        assert components == components

    test_component_re_split('1.5.1', ['1', '5', '1'])
    test_component_re_split('1.5.2b2', ['1', '5', '2', 'b', '2'])
    test_component_re_split('161', ['161'])
    test_component_re_split('3.10a', ['3', '10', 'a'])
    test_component_re_split('8.02', ['8', '02'])
    test_component_re_split('3.4j', ['3', '4', 'j'])


# Generated at 2022-06-20 16:40:04.804865
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not v1 < v2
    assert not v1 < '1.2.3'
    assert not v1 < v2
    assert v1 > '1.2.0'
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__('1.2.3') == NotImplemented

# Generated at 2022-06-20 16:40:06.273439
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version('1.2').__repr__() == 'Version (\'1.2\')'

# Generated at 2022-06-20 16:40:13.937753
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    import random
    import re
    import string
    import unittest

    # Taken from http://docs.python.org/library/string.html#string.letters
    letters = string.ascii_letters

    version_string = '.'.join([str(random.randint(0, sys.maxint))
                               for x in range(random.randint(1, 6))])
    version = LooseVersion(version_string)

    expected = "LooseVersion ('%s')" % version_string
    observed = repr(version)
    assert observed == expected, ''.join(difflib.ndiff(expected, observed))


# Generated at 2022-06-20 16:40:25.822031
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.0')
    assert str(v) == '1.0'
    #
    v = StrictVersion('1.0.1')
    assert str(v) == '1.0.1'
    #
    v = StrictVersion('1.0a1')
    assert str(v) == '1.0a1'
    #
    v = StrictVersion('1.0b2')
    assert str(v) == '1.0b2'
    #
    v = StrictVersion('1.0.1a1')
    assert str(v) == '1.0.1a1'
    #
    v = StrictVersion('1.0.1b2')
    assert str(v) == '1.0.1b2'

# Generated at 2022-06-20 16:40:30.636415
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """LooseVersion.__str__

    Tests that LooseVersion objects can be converted back to their
    original string representation.

    """
    tests = ('1.3.4', '1.3.4pre5', '2.2.4rc4', '1.2pl00', '1.2.3.4')
    for test in tests:
        assert str(LooseVersion(test)) == test, test


# Generated at 2022-06-20 16:40:36.046174
# Unit test for constructor of class LooseVersion
def test_LooseVersion():

    # Test tuples for equality and other comparisons
    # Equality
    assert ((0,) == (0,))
    assert ((0, 1, 2) == (0, 1, 2))
    # Inequality
    assert ((0,) != (0, 1))
    assert ((0, 1, 2) != (0, 2))
    assert ((0, 1, 20000) != (0, 1, 20001))


# A short test program.

# Generated at 2022-06-20 16:40:44.656495
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1') == '1'
    assert StrictVersion('1.2') == '1.2'
    assert StrictVersion('1.2.3') == '1.2.3'
    assert StrictVersion('1.2.3a') == '1.2.3a'
    assert StrictVersion('1.2.3a1') == '1.2.3a1'
    assert StrictVersion('1.2.3.4a1') == '1.2.3.4a1'
    assert StrictVersion('1.2.3a1.4') == '1.2.3a1.4'


# Generated at 2022-06-20 16:41:14.986239
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.2.0a1')
    assert repr(v) == "Version ('1.2.0a1')"



# Generated at 2022-06-20 16:41:21.725120
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Tests that the function returns the expected result
    # version1 = Version(vstring=None)
    version1 = Version(vstring=None)
    version2 = Version(vstring='1.0')
    version1._cmp = lambda arg: arg == version2
    expected_result = True
    result = version1 <= version2
    assert result == expected_result


# Generated at 2022-06-20 16:41:25.568533
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    version = LooseVersion('1.2dev')
    assert repr(version) == "LooseVersion ('1.2dev')"


# Generated at 2022-06-20 16:41:38.133210
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def _test_compare(v1, v2):
        v1 = LooseVersion(v1).version
        v2 = LooseVersion(v2).version
        eq = v1 == v2
        lt = v1 <  v2
        gt = v1 >  v2

        eq_op = ''
        lt_op = ''
        gt_op = ''
        if eq:
            eq_op = '=='
        if lt:
            lt_op = '<'
        if gt:
            gt_op = '>'

        if not (lt or gt or eq):
            raise ValueError("Comparison failed.", v1, v2, eq_op, lt_op, gt_op)


# Generated at 2022-06-20 16:41:47.456060
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    temp = LooseVersion()
    for version in ['1.5.1', '1.5.2b2', '161', '3.10a', '8.02', '3.4j', '1996.07.12', '3.2.pl0', '3.1.1.6', '2g6', '11g', '0.960923', '2.2beta29', '1.13++', '5.5.kw', '2.0b1pl0']:
        temp.parse(version)
        assert str(temp) == version


# Generated at 2022-06-20 16:41:59.697058
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vstring, parsed_version in (('0.4', ((0, 4, 0), None)),
                                    ('0.4.1', ((0, 4, 1), None)),
                                    ('0.5a1', ((0, 5, 0), ('a', 1))),
                                    ('1.0.4b3', ((1, 0, 4), ('b', 3))),
                                    ('1.0.4', ((1, 0, 4), None)),
                                   ):
        try:
            v = StrictVersion(vstring)
        except ValueError:
            print("couldn't parse %s" % vstring)
        else:
            print("%s -> %s" % (vstring, v.version))


if __name__ == '__main__':
    test_StrictVersion()

# Generated at 2022-06-20 16:42:03.109669
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    try: StrictVersion("1.3c4")
    except ValueError: pass



# Generated at 2022-06-20 16:42:12.121808
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():

    pkg = ['','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','']

    pkg[0] = '0.9.1'
    pkg[1] = '0.9.2'
    pkg[2] = '0.9.3'
    pkg[3] = '0.9.4'
    pkg[4] = '0.9.5'
    pkg[5] = '0.9.6'
    pkg[6] = '0.9.7'
    pkg[7] = '0.9.8'
    pkg[8] = '1.0.0'
    pkg[9] = '1.0.1'
    pkg

# Generated at 2022-06-20 16:42:13.545923
# Unit test for constructor of class Version
def test_Version():
    v = Version()


# Generated at 2022-06-20 16:42:16.402212
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2.3.4').__str__() == '1.2.3.4'
    assert StrictVersion('1.2.3').__str__() == '1.2.3'


# Generated at 2022-06-20 16:43:27.513577
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.2rc2')
    assert lv.version == ['1', '2', 'rc', '2'], lv.version

    lv = LooseVersion()
    lv.parse('1.2')
    assert lv.version == ['1', '2'], lv.version

    lv = LooseVersion()
    lv.parse('1.2.3.4.5.6')
    assert lv.version == ['1', '2', '3', '4', '5', '6'], lv.version

    lv = LooseVersion()
    lv.parse('1.2rc2.3.4')
    assert lv.version == ['1', '2', 'rc', '2', '3', '4'], lv

# Generated at 2022-06-20 16:43:33.052178
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """
    >>> vp = Version()
    >>> vp2 = Version('3.9.2')
    >>> vp2 >= vp
    True
    >>> vp >= vp2
    False
    """


# Generated at 2022-06-20 16:43:41.652468
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2') >= Version('1.2')
    assert Version('1.2.3') >= Version('1.2')
    assert Version('1.0') > Version('1.0b1')
    assert Version('1.0') >= Version('1.0b1')
    assert not Version('1.0.post1') > Version('1.0')
    assert Version('1.0.post1') >= Version('1.0')
    assert Version('1.0.post1') > Version('1.0c1')
    assert Version('1.0.post1') >= Version('1.0c1')
    assert Version('1.0.post1') > Version('1.0a1')
    assert Version('1.0.post1') >= Version('1.0a1')

# Generated at 2022-06-20 16:43:44.787013
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version(vstring='1.0.0').__repr__() == "Version ('1.0.0')"


# Generated at 2022-06-20 16:43:49.721618
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from distutils.version import Version
    v = Version("1.0")
    assert repr(v) == "Version ('1.0')", 'incorrect repr for Version("1.0")'
    v = Version("a.b")
    assert repr(v) == "Version ('a.b')", 'incorrect repr for Version("a.b")'
    v = Version("a.b.c")
    assert repr(v) == "Version ('a.b.c')", 'incorrect repr for Version("a.b.c")'


# Generated at 2022-06-20 16:43:52.609967
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    try:
        a = Version()
        return a >= 5
    except:
        return False



# Generated at 2022-06-20 16:43:55.010159
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3')
    assert v.__class__.__name__ == 'Version'



# Generated at 2022-06-20 16:43:59.091124
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion('1.0')
    assert v.version == (1,0,0)
    assert v.prerelease == None
    v = StrictVersion('1.0a1')
    assert v.version == (1,0,0)
    assert v.prerelease == ('a', 1)



# Generated at 2022-06-20 16:44:02.899919
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    i = Version('1.0')
    j = Version('1.0')
    assert (i >= j)

# Generated at 2022-06-20 16:44:08.665575
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Test case for method `Version.__lt__`.
    """
    v1 = Version('1.0')
    v2 = Version('2.a')
    assert isinstance(v1, Version)
    assert isinstance(v2, Version)
    assert v1 < v2

