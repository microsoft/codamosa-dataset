

# Generated at 2022-06-20 16:36:11.476504
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.0') > Version('1.0a1')


# Generated at 2022-06-20 16:36:21.357753
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def testcase(num, major, minor, patch, prerelease, prerelease_ver):
        v = StrictVersion(num)
        if v.version != (major, minor, patch):
            raise AssertionError("version part error")
        if v.prerelease != prerelease:
            raise AssertionError("prerelease error")
        if num != str(v):
            raise AssertionError("repr error")

    testcase("1.0", 1, 0, 0, None, None)
    testcase("1.0pl1", 1, 0, 0, "pl", 1)
    testcase("1.0.1", 1, 0, 1, None, None)
    testcase("1.0.1rc2", 1, 0, 1, "rc", 2)

# Generated at 2022-06-20 16:36:25.061986
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    a = Version('1.0')
    b = Version('1.1')
    if a > b:
        print('unexpected')
    if not a < b:
        print('unexpected')
    if not a <= b:
        print('unexpected')
    if a >= b:
        print('unexpected')

# Generated at 2022-06-20 16:36:29.847468
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    vstr = '1.0.1rc2'
    lv = LooseVersion(vstr)
    test.test_support.unlink(vstr)
    if str(lv) != vstr:
        raise test_support.TestFailed("LooseVersion(%s) failed, returned %s" % (vstr, lv))


# Generated at 2022-06-20 16:36:31.704190
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    a = Version('1')
    b = Version('2')

# Generated at 2022-06-20 16:36:34.316987
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v.parse("a.b.c")
    assert v <= "a.b.c"
    assert v <= "a.b.d"
    assert v <= "a.b.c-dev.2"


# Generated at 2022-06-20 16:36:35.385937
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # From the Python Documentation
    import doctest
    doctest.run_docstring_examples(LooseVersion.__repr__, globals())


# Generated at 2022-06-20 16:36:39.296584
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("1.0")
    v2 = Version("2.0")
    assert (v1 <= v2)



# Generated at 2022-06-20 16:36:49.296347
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """Unit test for method __str__ of class LooseVersion."""
    # import sys
    # from io import StringIO
    # from test.support import captured_stdout
    sys = None
    StringIO = None
    captured_stdout = None


# Generated at 2022-06-20 16:36:50.971105
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version()
    version.parse('v1.2.3')
    assert version == version



# Generated at 2022-06-20 16:37:09.057128
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Test the method __lt__ of class Version"""
    obj = Version()
    other = Version()
    obj._cmp = lambda s, o: 1
    assert obj.__lt__(other)
    obj._cmp = lambda s, o: 0
    assert not obj.__lt__(other)
    obj._cmp = lambda s, o: -1
    assert not obj.__lt__(other)
    obj._cmp = lambda s, o: NotImplemented
    assert obj.__lt__(other) is NotImplemented
test_Version___lt__()


# Generated at 2022-06-20 16:37:13.869148
# Unit test for method __repr__ of class LooseVersion

# Generated at 2022-06-20 16:37:26.345612
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    from distutils.version import StrictVersion as SV

    v = SV('1.2.0.0')
    assert str(v) == '1.2'
    v = SV('1.2.3.0')
    assert str(v) == '1.2.3'
    v = SV('1.2.0.0a1')
    assert str(v) == '1.2a1'
    v = SV('1.2.3.0a1')
    assert str(v) == '1.2.3a1'
    v = SV('1.2.0.0b1')
    assert str(v) == '1.2b1'
    v = SV('1.2.3.0b1')
    assert str(v) == '1.2.3b1'



# Generated at 2022-06-20 16:37:26.961673
# Unit test for constructor of class Version
def test_Version():
    Version("1.2.3")



# Generated at 2022-06-20 16:37:28.311449
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert (Version('1.2') >= '1.2')

# Generated at 2022-06-20 16:37:30.251587
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('2.3')
    v2 = Version('1.7')
    assert v1 > v2


# Generated at 2022-06-20 16:37:32.924963
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    StrictVersion("1.2.3a2")



# Generated at 2022-06-20 16:37:39.026898
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test a version without a prerelease
    ver = StrictVersion('1.0')
    ver.prerelease = None
    assert ver.__str__() == '1.0'
    # Test a version with a prerelease
    ver = StrictVersion('1.0a1')
    ver.prerelease = ('a', 1)
    assert ver.__str__() == '1.0a1'


# Generated at 2022-06-20 16:37:40.015249
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("12.0.1").__str__() ==  "12.0.1"


# Generated at 2022-06-20 16:37:42.412745
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1')
    v2 = Version('2')

    assert v2 > v1

# Generated at 2022-06-20 16:37:50.730693
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert not v == 'x'


# Generated at 2022-06-20 16:37:53.553104
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version("invalid")
    v2 = Version("invalid")
    assert v1 == v2, "Version instances with invalid version strings should be equal"

# Generated at 2022-06-20 16:37:55.241733
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version('2.4')
    assert version >= '2.4'
    assert not version >= '5.5'


# Generated at 2022-06-20 16:37:56.751730
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion("10.4.4")
    assert v.__str__() == "10.4.4"


# Generated at 2022-06-20 16:37:57.695775
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    assert version.__gt__('')



# Generated at 2022-06-20 16:38:04.697289
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils2.version import Version

    v = Version ('1.0')
    assert v.__gt__ ('1.0a1')
    assert not v.__gt__ ('1.2')
    assert not v.__gt__ (v)
    assert not v.__gt__ ('1.0')
    v = Version ('1.0a1')
    assert not v.__gt__ ('1.0')
    assert v.__gt__ ('0.9')
    assert not v.__gt__ ('1.0a2')
    assert not v.__gt__ (v)
    assert not v.__gt__ ('1.0a1')
    v = Version ('1.0a2')
    assert not v.__gt__ ('1.0')
    assert not v.__gt__ ('1.0a1')

# Generated at 2022-06-20 16:38:14.824391
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    l = LooseVersion("1.2.0")
    assert(l.version == [1, 2, 0])

    l = LooseVersion("1.2.0.0.0.0.0.0.0.0.0")
    assert(l.version == [1, 2, 0])

    l = LooseVersion("1.2pl0")
    assert(l.version == [1, "2pl0"])

    l = LooseVersion("1.2pl0.0")
    assert(l.version == [1, "2pl0", 0])

    l = LooseVersion("1pl0.0")
    assert(l.version == ["1pl0", 0])

    l = LooseVersion("myversion")
    assert(l.version == ["myversion"])


# Generated at 2022-06-20 16:38:21.405508
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('2g6').__str__() == '2g6'
    assert LooseVersion().__str__() == '0.0'
    assert LooseVersion('').__str__() == '0.0'
    assert LooseVersion('1.2a3').__str__() == '1.2a3'
    assert LooseVersion('1.2.1').__str__() == '1.2.1'
    assert LooseVersion('1.2.1').__str__() == '1.2.1'
    assert LooseVersion('1.2.1').__str__() == '1.2.1'
    assert LooseVersion('1.2.1').__str__() == '1.2.1'

# Generated at 2022-06-20 16:38:25.383919
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """
    >>> str(LooseVersion("1.5.3.dev1"))
    '1.5.3.dev1'
    """


# Generated at 2022-06-20 16:38:31.119493
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert '\'1.0.0\'' == repr(LooseVersion('1.0.0'))
    assert '\'1.0.1\'' == repr(LooseVersion('1.0.1'))
    assert '\'2.0.0\'' == repr(LooseVersion('2.0.0'))
    assert '\'3.0.0\'' == repr(LooseVersion('3.0.0'))
    assert '\'4.2.0\'' == repr(LooseVersion('4.2.0'))
    assert '\'5.0.0\'' == repr(LooseVersion('5.0.0'))


# Generated at 2022-06-20 16:38:39.256189
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert v._cmp('1.3.6') == 1



# Generated at 2022-06-20 16:38:44.507495
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    u"""'Version.__eq__' method should return True if both instances are equal,
    False otherwise."""
    v1 = Version()
    v2 = Version()
    assert v1 == v2
    v1 = Version('1')
    v2 = Version('1')
    assert v1 == v2
    v2 = Version('2')
    assert not v1 == v2

# Generated at 2022-06-20 16:38:52.164787
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion("1.99junk")
    eq = "LooseVersion ('1.99junk')"
    assert lv.__repr__() == eq

# Unit tests for class Version
if is_jython:
    from org.python.core import PyStringMap
    try:
        from org.python.core import Py
    except ImportError:
        from org.python.core import PyObject as Py

# Test for the special case of a false value

# Generated at 2022-06-20 16:39:01.628202
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()

    components = ['1', '5', '1']
    vstring = "1.5.1"
    lv.parse(vstring)
    assert lv.vstring == vstring
    assert lv.version == components

    components = ['1', '5', '2b2']
    vstring = "1.5.2b2"
    lv.parse(vstring)
    assert lv.vstring == vstring
    assert lv.version == components

    components = ['161']
    vstring = "161"
    lv.parse(vstring)
    assert lv.vstring == vstring
    assert lv.version == components

    components = ['3', '10a']
    vstring = "3.10a"
    lv.parse(vstring)

# Generated at 2022-06-20 16:39:02.661954
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version("1.0").__repr__() == "Version ('1.0')"

# Generated at 2022-06-20 16:39:05.715816
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= Version()



# Generated at 2022-06-20 16:39:10.017915
# Unit test for constructor of class Version
def test_Version():
    from distutils.tests import support
    x = Version()
    assert x.__class__.__name__ == "Version"
    x = Version('0')
    assert x.__class__.__name__ == "Version"
    # test __repr__ is at least sane
    assert repr(x) == "Version ('0')"



# Generated at 2022-06-20 16:39:20.726444
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Version constructor should convert strings to tuples and ints
    v = StrictVersion('1.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease == None

    # Constructor shouldn't care about whitespace
    assert StrictVersion('1.0   ').version == (1, 0, 0)
    assert StrictVersion('   1.0').version == (1, 0, 0)
    assert StrictVersion('1.0\t').version == (1, 0, 0)

    # Trailing junk should be disallowed
    raises(ValueError, StrictVersion, '1.0.0.0')
    raises(ValueError, StrictVersion, '1.0-a1')
    raises(ValueError, StrictVersion, '1.0rc1')

    # Single-digit parts are

# Generated at 2022-06-20 16:39:29.369162
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    class TestVersion(Version):
        def __init__(self, vstring):
            Version.__init__(self, vstring)
        def parse(self, vstring):
            self.vstring = vstring
        def __str__(self):
            return self.vstring
        def _cmp(self, other):
            if not isinstance(other, TestVersion):
                return NotImplemented
            return (self.vstring > other.vstring) - (self.vstring < other.vstring)
    v1 = TestVersion('1')
    v2 = TestVersion('2')
    v1_dup = TestVersion('1')
    assert(v1 >= v2)
    assert(not (v1 > v2))
    assert(v1 >= v1_dup)

# Generated at 2022-06-20 16:39:40.781362
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import unittest

    class TestLooseVersionParse(unittest.TestCase):
        def setUp(self):
            self.v = LooseVersion("2.3a3")

        def test_vstring(self):
            self.assertEqual(self.v.vstring, "2.3a3")

        def test_version(self):
            self.assertEqual(self.v.version, [2, 3, 'a', 3])

        def test_parse_underscore(self):
            self.v._LooseVersion__parse("1_2_3")
            self.assertEqual(self.v.version, [1, 2, 3])

        def test_parse_alphanum(self):
            self.v._LooseVersion__parse("1.2a3.4b")
            self

# Generated at 2022-06-20 16:39:55.175338
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    obj = Version()
    Version.__init__ = MagicMock(return_value=None)
    str = MagicMock(return_value="string")
    Version.__str__ = MagicMock(return_value=str)

# Generated at 2022-06-20 16:40:03.659035
# Unit test for constructor of class Version
def test_Version():
    # Test class decorator
    assert str(Version) == "<class '__main__.Version'>"

    # Test constructor, __str__ and __repr__
    v = Version('1.2.3')
    assert str(v) == '1.2.3'
    assert repr(v) == "Version ('1.2.3')"

    # Test comparison operators
    assert v == Version('1.2.3')
    assert v >= Version('1.2.3')
    assert v <= Version('1.2.3')
    assert v != Version('1.2.4')
    assert v < Version('1.2.4')
    assert v > Version('1.2')
    assert v >= Version('1.2')
    assert v <= Version('1.2.3.4')

    # Test NotImplemented

# Generated at 2022-06-20 16:40:05.557423
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.3.3")
    assert str(v) == "1.3.3"


# Generated at 2022-06-20 16:40:07.020486
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert v.__repr__() == "Version ('0')"


# Generated at 2022-06-20 16:40:14.491622
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert str(LooseVersion("1.2")) == "1.2"
    assert str(LooseVersion("2.2")) == "2.2"
    assert str(LooseVersion("0.99")) == "0.99"
    assert str(LooseVersion("0.99pl14")) == "0.99pl14"
    assert str(LooseVersion("1.0")) == "1.0"
    assert str(LooseVersion("1.0.4a3")) == "1.0.4a3"
    assert str(LooseVersion("1.0.4b1")) == "1.0.4b1"
    assert str(LooseVersion("1.0.4")) == "1.0.4"

# Generated at 2022-06-20 16:40:16.663718
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ver = Version()
    assert (not (ver < '1'))

# Generated at 2022-06-20 16:40:19.011805
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(1) == NotImplemented

test_Version___le__()


# Generated at 2022-06-20 16:40:24.459163
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    """
    >>> sv = StrictVersion()
    >>> sv.parse('1.2.3')
    >>> sv.version
    (1, 2, 3)
    >>> sv.prerelease
    >>> sv.parse('1.2.3a1')
    >>> sv.prerelease
    ('a', 1)
    """


# Generated at 2022-06-20 16:40:28.761629
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.1.1.1.1.1.1.1')
    assert v.__repr__() == "LooseVersion ('1.1.1.1.1.1.1.1')"
    v = LooseVersion('1.1.1+')
    assert v.__repr__() == "LooseVersion ('1.1.1+')"


# Generated at 2022-06-20 16:40:30.745305
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(Version()) == True, "method __eq__ failed"


# Generated at 2022-06-20 16:40:38.353705
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert v is not None


# Generated at 2022-06-20 16:40:40.873278
# Unit test for constructor of class Version
def test_Version():
    """Test the constructor of class Version
    """
    v = Version()
    assert v.__class__ is Version


# Generated at 2022-06-20 16:40:46.703883
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """
    >>> from distutils.version import LooseVersion
    >>> LooseVersion('1.2.3.4').parse('1.2.2rc2')
    >>> lv = LooseVersion('1.2.3.4')
    >>> lv.parse('1.2.2rc2')
    >>> lv.version
    ['1', '2', '2rc2']
    """


# XXX need some tests

# Generated at 2022-06-20 16:40:54.101563
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """Test for method __str__ of class StrictVersion"""

    v1 = StrictVersion("1.2.3a4")
    assert str(v1) == "1.2.3a4"
    v2 = StrictVersion("1.2.3")
    assert str(v2) == "1.2.3"
    v3 = StrictVersion("1.2")
    assert str(v3) == "1.2"



# Generated at 2022-06-20 16:40:56.192038
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('0.8')
    assert repr(v) == "LooseVersion ('0.8')"


# Generated at 2022-06-20 16:40:59.996703
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import pytest
    inst = Version()
    other = object()
    assert inst._cmp(other) is NotImplemented
    assert inst < other

    inst = Version()
    other = None
    assert inst._cmp(other) is NotImplemented
    assert inst < other



# Generated at 2022-06-20 16:41:09.696286
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse("1.0.1b1")
    assert lv.vstring == "1.0.1b1", lv.vstring
    assert lv.version == [1, 0, 1, "b", 1], lv.version
# end unit test for method parse of class LooseVersion


# AFAIK, there is only one other implementation of a public
# version-numbering scheme in the Python universe: that of the `Peak'
# project.  Relative to peak, this module has the following advantages:
# - supports public version numbers as simple as '1.1' (and as complex
#   as necessary)
# - supports a flexible scheme for specifying pre-release versions
# - has a more-complicated and more-buggy version-number parsing
#   routine that can handle things like

# Generated at 2022-06-20 16:41:11.230219
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    Version()

# Generated at 2022-06-20 16:41:14.118268
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.tests import support
    from distutils.version import Version
    _test_generic_equality(Version)
    support.run_unittest(__name__)

# Generated at 2022-06-20 16:41:19.678738
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    StrictVersion('0.4')
    StrictVersion('0.4.0')
    StrictVersion('0.4.1')
    StrictVersion('0.5a1')
    StrictVersion('0.5b3')
    StrictVersion('0.5')
    StrictVersion('0.9.6')
    StrictVersion('1.0')
    StrictVersion('1.0.4a3')
    StrictVersion('1.0.4b1')
    StrictVersion('1.0.4')
    StrictVersion('1.0')



# Generated at 2022-06-20 16:41:36.359795
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    tests = [("1.2.0", (1,2,0)),
             ("1.2.0a1", (1,2,0,'a',1)),
             ("3.4.0b1", (3,4,0,'b',1)),
             ("0.4", (0,4,0))]
    for tv, result in tests:
        v = StrictVersion(tv)
        assert v.version == result, "got %s, expected %s" % (v.version, result)


# Generated at 2022-06-20 16:41:42.570689
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('1.2a1').version == (1,2,'a','1')
    try:
        LooseVersion('1.2.3.4')
    except ValueError:
        pass

# end class LooseVersion


# Utility functions

# Generated at 2022-06-20 16:41:44.477574
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version().__repr__() == "Version ('0')"



# Generated at 2022-06-20 16:41:46.758121
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v._cmp('1.1.1') == 1

# Generated at 2022-06-20 16:41:52.080241
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    expected = True
    results = (Version('1.2.3') < Version('1.2.4'))
    assert type(results) == type(expected)
    assert results == expected


# Generated at 2022-06-20 16:42:00.888644
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """LooseVersion.__str__"""
    import unittest
    from sys import version_info


# Generated at 2022-06-20 16:42:03.316442
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert 'Version' == Version().__repr__()[:7]


# Generated at 2022-06-20 16:42:06.100344
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion("1.0.0")) == "1.0.0"

# Generated at 2022-06-20 16:42:12.501952
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    StrictVersion('1.2.3')
    StrictVersion('1.2')
    StrictVersion('1')
    n = StrictVersion()
    n.parse('2.3.4')
    n = StrictVersion('1.2.3b4')
    n = StrictVersion('1.2.3a4')
    return


LooseVersion = StrictVersion


# Generated at 2022-06-20 16:42:16.540893
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Initialize the instance
    instance = StrictVersion()
    # Test with a known value
    vstring = '1.2.3'
    instance.parse(vstring)
    assert instance.version == (1, 2, 3) and instance.prerelease is None

test_StrictVersion_parse()

# Generated at 2022-06-20 16:42:29.921535
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Verify that LooseVersion instances compare correctly.
    from distutils.version import LooseVersion
    assert LooseVersion('1.2.3a1') < LooseVersion('1.2.4b2')
    assert LooseVersion('1.2.3') < LooseVersion('1.2.3a1')
    assert LooseVersion('0.9') < LooseVersion('1.1')
    assert LooseVersion('1.2') < LooseVersion('1.2.3.4')
    assert LooseVersion('1.2.3.4') < LooseVersion('1.2.3.5')
    assert LooseVersion('1.2.3') < LooseVersion('1.2.3.4')

# Generated at 2022-06-20 16:42:35.655821
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    sv = StrictVersion('1.2.3')
    assert str(sv) == '1.2.3'

    sv = StrictVersion('1.2.3b1')
    assert str(sv) == '1.2.3b1'

    sv = StrictVersion('1.2.3b10')
    assert str(sv) == '1.2.3b10'

    sv = StrictVersion('1.2.3a1')
    assert str(sv) == '1.2.3a1'

    sv = StrictVersion('1.2.3a10')
    assert str(sv) == '1.2.3a10'


# Generated at 2022-06-20 16:42:44.110665
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    for args in [
        ("0", "0"),
        ("1.2", "1.2"),
        ("1.2.3", "1.2.3"),
        ("1.2.3a1", "1.2.3a1"),
        ("1.2.3b1", "1.2.3b1"),
    ]:
        x = StrictVersion(args[1])
        assert str(x) == args[1]


# Generated at 2022-06-20 16:42:56.890812
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test for method __gt__ of class Version"""
    ver1 = Version('1.0.0')
    ver2 = Version('2.0.0')
    assert (ver1 > ver2) == False
    assert (ver1 < ver2) == True
    assert (ver1 == ver2) == False
    assert (ver1 >= ver2) == False
    assert (ver1 <= ver2) == True

    ver1 = Version('1.0.0')
    ver2 = Version('1.0.0')
    assert (ver1 > ver2) == False
    assert (ver1 < ver2) == False
    assert (ver1 == ver2) == True
    assert (ver1 >= ver2) == True
    assert (ver1 <= ver2) == True

    ver1 = Version('2.0.0')
   

# Generated at 2022-06-20 16:43:07.543945
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2')
    assert v.version == (1, 2, 0)
    v = StrictVersion('1.2.0')
    assert v.version == (1, 2, 0)
    v = StrictVersion('1.2a1')
    assert v.version == (1, 2, 0) and v.prerelease == ('a', 1)
    v = StrictVersion('1.2.0a1')
    assert v.version == (1, 2, 0) and v.prerelease == ('a', 1)
    v = StrictVersion('1.2b3')
    assert v.version == (1, 2, 0) and v.prerelease == ('b', 3)
    v = StrictVersion('1.2')
    assert v.version == (1, 2, 0)


# Generated at 2022-06-20 16:43:16.781986
# Unit test for method __le__ of class Version
def test_Version___le__():
    try:
        from distutils.version import Version
    except ImportError:
        from .distutils.version import Version

    v = Version('1.0')
    assert v <= '1.0'
    assert v <= '1.0.0'
    assert v <= '1.0.0.0'
    assert v <= '1'
    assert v <= '2.0'
    assert v <= '2'

    assert not (v <= '0.9.9')
    assert not (v <= '0')



# Generated at 2022-06-20 16:43:19.797516
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Test method Version.__eq__"""
    assert Version('1.0') == Version('1.0')


# Generated at 2022-06-20 16:43:22.751761
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """
    This is a unit test for method __lt__ of class Version.
    """
    # Pass
    raise NotImplementedError()

# Generated at 2022-06-20 16:43:30.043259
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    strict_version = StrictVersion('1.4')
    assert strict_version.version == (1, 4, 0)

    strict_version = StrictVersion('1.4.2')
    assert strict_version.version == (1, 4, 2)

    strict_version = StrictVersion('1.4a1')
    assert strict_version.prerelease == ('a', 1)

    strict_version = StrictVersion('1.4b3')
    assert strict_version.prerelease == ('b', 3)

    # Invalid version
    try:
        strict_version = StrictVersion('1')
        assert False
    except ValueError:
        pass


# Generated at 2022-06-20 16:43:40.591962
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version("0.0.0")
    assert isinstance(v, Version)
    assert v == "0.0.0"
    assert v >= "0.0.0"
    assert v <= "0.0.0"
    assert v < "0.0.1"
    assert v <= "0.0.1"
    assert v < "0.1.0"
    assert v <= "0.1.0"
    assert v < "0.1.1"
    assert v <= "0.1.1"
    assert v < "1.0.0"
    assert v <= "1.0.0"
    assert v < "1.0.1"
    assert v <= "1.0.1"
    assert v < "1.1.0"

# Generated at 2022-06-20 16:43:57.849174
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion('1.0.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion('1.0.0.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease is None



# Generated at 2022-06-20 16:44:03.066965
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """LooseVersion a.k.a. Version
    """
    assert LooseVersion('1.15').version == (1, 15)
    assert LooseVersion('1.15').__str__() == '1.15'
    assert LooseVersion('1.15').version == LooseVersion(LooseVersion('1.15').__str__())
    assert LooseVersion('1.15').__str__() == LooseVersion('1.15').version



# Generated at 2022-06-20 16:44:12.841908
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    from distutils.version import Version

    class VersionTestCase(unittest.TestCase):
        def test___gt__(self):
            self.assertTrue(Version('1.0') > Version('0.9'))
            self.assertTrue(Version('1.0') > '0.9')
            self.assertTrue('1.0' > Version('0.9'))
            self.assertFalse(Version('1.0') > '1.0')
            self.assertFalse('1.0' > Version('1.0'))

    suite = unittest.makeSuite(VersionTestCase)
    if __name__ == '__main__':
        unittest.main(defaultTest='suite')


# Generated at 2022-06-20 16:44:16.033205
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion ("1.2.3")
    assert str(v) == v.vstring, '__str__ returns vstring'


# Generated at 2022-06-20 16:44:17.634972
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    a = Version('1.1')
    b = Version('v1.1')
    assert a >= b


# Generated at 2022-06-20 16:44:29.795568
# Unit test for method __str__ of class StrictVersion

# Generated at 2022-06-20 16:44:40.451637
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def test(vstring, errmsg):
        try:
            v = LooseVersion(vstring)
        except ValueError as exc:
            if exc.args[0] == errmsg:
                print("%r okay" % vstring)
            else:
                print("test_LooseVersion failed: expected %r, got %r" \
                    % (errmsg, exc))
        else:
            print("test_LooseVersion failed: expected %r, got none" % errmsg)

    test("1.5.1", None)
    test("1.5.2b2", None)
    test("161", None)
    test("3.10a", None)
    test("8.02", None)
    test("3.4j", None)
    test("1996.07.12", None)

# Generated at 2022-06-20 16:44:43.193216
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version("1") > Version("0")

# Generated at 2022-06-20 16:44:53.422381
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:44:55.328816
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v=Version()
    assert v=='0','version string not equal'

# Generated at 2022-06-20 16:45:09.216098
# Unit test for method __le__ of class Version
def test_Version___le__():
    global Version
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import re

try:
    RE_FLAGS = re.VERBOSE | re.ASCII
except AttributeError:
    RE_FLAGS = re.VERBOSE



# Generated at 2022-06-20 16:45:12.077804
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    class Foo(Version):
        def __init__(self, vstring=None):
            pass
        def __str__(self):
            return "13.37"
    assert repr(Foo()) == "Foo ('13.37')"

# Generated at 2022-06-20 16:45:15.272723
# Unit test for method __le__ of class Version
def test_Version___le__():
    print('Test of method __le__ of class Version')
    num1 = Version('1.2.4')
    num2 = Version('1.2')
    if num1 <= num2:
        print('Test case passed')
    else:
        print('Test case failed')

test_Version___le__()


# Generated at 2022-06-20 16:45:21.002432
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion("1.2.3")
    assert repr(v) == "LooseVersion ('1.2.3')", repr(v)
    assert repr(v) == repr(eval(repr(v))), repr(v)



# Generated at 2022-06-20 16:45:28.346447
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from copy import copy
    from pickle import loads, dumps
    from itertools import count
    from random import shuffle
    from sys import version_info

    from distutils import version

    c = version.Version("1.0")
    cpy = copy(c)
    assert c == cpy

    c = version.Version("1.0")
    cpy = loads(dumps(c))
    assert c == cpy

    # 1.0 < 2.0
    # 1.1 < 1.2
    # 1.0.1 < 1.0.2

    vlist = ["1.0", "1.1", "1.0.1"]
    assert vlist == sorted(vlist)

    vlist = ["1.0.0.0", "1.0.0", "1.0"]

# Generated at 2022-06-20 16:45:33.566940
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.5.2b2')
    assert lv.version == ['1', '5', '2', 'b', '2']
    assert lv.vstring == '1.5.2b2'

# Generated at 2022-06-20 16:45:36.421572
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1.0').__repr__() == "LooseVersion ('1.0')"



# Generated at 2022-06-20 16:45:39.621028
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2').__str__() == '1.2.0'
    assert StrictVersion('1').__str__() == '1.0.0'
    assert StrictVersion('0').__str__() == '0.0.0'

# Generated at 2022-06-20 16:45:48.871290
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion('1.2.3a4') > StrictVersion('1.2.3')

    # Test for issue #1205
    for s in ('Foobar 99', '99.1.2', '1.2a3b4', '1.2.3.4'):
        try:
            StrictVersion(s)
        except ValueError:
            pass
        else:
            raise AssertionError("Failed to raise ValueError for " + s)



# Generated at 2022-06-20 16:45:54.530313
# Unit test for method __le__ of class Version
def test_Version___le__():
 assert Version("1.0") <= Version("1.0")
 assert Version("1.0") <= Version("1.0.0")
 assert Version("0.6") <= Version("1.0")
 assert not (Version("1.1") <= Version("1.0"))