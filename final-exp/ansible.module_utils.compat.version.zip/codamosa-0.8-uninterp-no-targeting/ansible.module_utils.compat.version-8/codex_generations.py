

# Generated at 2022-06-20 16:36:12.321911
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """test_LooseVersion___repr__"""
    x = LooseVersion("1.0.2")

    assert x.__repr__() == "LooseVersion ('1.0.2')"


# Generated at 2022-06-20 16:36:22.154694
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # passing strings
    assert StrictVersion("1.2.3a4") < StrictVersion("1.2.3a4.1")
    assert StrictVersion("1.2.3a4.1") > StrictVersion("1.2.3a4")
    assert StrictVersion("1.2.3a4") < StrictVersion("1.2.3a4.1").version
    assert StrictVersion("1.2.3a4.1") > StrictVersion("1.2.3a4").version
    # passing actual version instances
    assert StrictVersion("1.2.3a4") < StrictVersion("1.2.3a4.1")
    assert StrictVersion("1.2.3a4.1") > StrictVersion("1.2.3a4")
    assert StrictVersion

# Generated at 2022-06-20 16:36:26.546385
# Unit test for method __lt__ of class Version
def test_Version___lt__():
   try:
      class DummyVersion:
         def __init__(self, vstring=None):
            pass

         def __repr__(self):
            pass
   except:
      assert False, "Class DummyVresion not defined"
   try:
      v = Version()
   except:
      assert False, "Failed to create an object of class Version"
   assert v < Version("1.0")

# Generated at 2022-06-20 16:36:34.822020
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:36:39.444790
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  print('test_Version___lt__')
  v = Version()
  assert v <= -1
  assert v < 0
  assert v < 1
  assert v <= 1


# Generated at 2022-06-20 16:36:42.243766
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v1._version = ['a']
    v2 = Version()
    v2._version = ['b']
    c = v1.__lt__(v2)
    assert c == True


# Generated at 2022-06-20 16:36:43.969071
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('2g6')
#
# The end.
#

# Generated at 2022-06-20 16:36:45.777880
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('2.4.1').__str__() == '2.4.1'



# Generated at 2022-06-20 16:36:54.093079
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('2.2beta29')
    assert lv.version == [2, 2, 'beta', 29]
    lv.parse('1.13++')
    assert lv.version == [1, 13, '++']
    lv.parse('0.960923')
    assert lv.version == [0, 960923]
    lv.parse('2.2.pl0')
    assert lv.version == [2, 2, 'pl', 0]
    lv.parse('5.5.kw')
    assert lv.version == [5, 5, 'kw']


# Generated at 2022-06-20 16:36:56.281368
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    s = repr(v)
    assert s == "Version ('')" or s == "Version ('')"
# end unit test for constructor of class Version



# Generated at 2022-06-20 16:37:16.004564
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert isinstance(v, Version)
    assert v == v

# Generated at 2022-06-20 16:37:26.908499
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils2.version import StrictVersion
    from distutils2.version import LooseVersion
    def _Version__le__1():
        """Test that StrictVersion is less or equal to itself, assuming
        it is equal to itself."""

        strict = StrictVersion('1.0')
        assert strict <= strict
        assert strict >= strict

    def _Version__le__2():
        """Test that LooseVersion is less or equal to itself, assuming
        it is equal to itself."""

        loose = LooseVersion('1.0a')
        assert loose <= loose
        assert loose >= loose

    def _Version__le__3():
        """Test that StrictVersion and LooseVersion are not less or
        equal to each other after being set to the same value."""

        strict = StrictVersion('1.0')

# Generated at 2022-06-20 16:37:34.896143
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert '\u0634.\u062a.\u0633' == LooseVersion('\u0634.\u062a.\u0633').__str__()
    assert '\u0634.\u062a.\u0633' == LooseVersion('\u0634.\u062a.\u0633').__str__()
    assert '\u0634.\u062a.\u0633' == LooseVersion('\u0634.\u062a.\u0633').__str__()
    assert '2.5.5' == LooseVersion('2.5.5').__str__()
    assert '2.5.5' == LooseVersion('2.5.5').__str__()

# Generated at 2022-06-20 16:37:43.933266
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """ Unit tests for method Version::__gt__"""
    # fail for strictversion compiled with python3.8, pass for others
    try:
        from distutils.version import StrictVersion
    except ImportError:
        from distutils.version import StrictVersion
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1.__gt__(v2)
    sv1 = StrictVersion('1.0')
    sv2 = StrictVersion('2.0')
    assert not sv1.__gt__(sv2)
    assert sv1.__ge__(sv2)



# Generated at 2022-06-20 16:37:50.064301
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Should return the same string as was parsed.
    a = StrictVersion("2.1.3.4")
    if str(a) != "2.1.3.4":
        return False
    b = StrictVersion("999.999.999")
    if str(b) != "999.999.999":
        return False
    return True


# Generated at 2022-06-20 16:37:59.394656
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:38:03.232927
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest
    class Test(unittest.TestCase):
        def test(self):
            ver = Version('1.0.0')
            self.assertTrue(ver >= '1.0.0')

    t = Test('test')
    t.test()

if __name__ == "__main__":
    test_Version___ge__()


# Generated at 2022-06-20 16:38:13.696353
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vstring in ['0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5', '0.9.6',
                    '1.0', '1.0.4a3', '1.0.4b1', '1.0.4']:
        v = StrictVersion(vstring)

# Generated at 2022-06-20 16:38:18.372278
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import doctest
    from ansible.module_utils.distutils import version

    failure_count, test_count = doctest.testmod(version, optionflags=doctest.ELLIPSIS)
    assert failure_count == 0


# Generated at 2022-06-20 16:38:20.185733
# Unit test for constructor of class Version
def test_Version():
    # Constructor without argument must work
    try:
        Version()
    except:
        raise AssertionError('Version() raised unexpected exception')



# Generated at 2022-06-20 16:38:34.962753
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    def t(a, b, c, d):
        if (a < b) != c:
            raise Exception("Version.__lt__ failed to return %s for '%s' < '%s'" % (c, a, b))
        if (b < a) != d:
            raise Exception("Version.__lt__ failed to return %s for '%s' < '%s'" % (d, b, a))
    t('1.0', '2.0', True, False)

# Generated at 2022-06-20 16:38:46.055780
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-20 16:38:50.772885
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import StrictVersion
    S0 = StrictVersion("1.0")
    S1 = StrictVersion("1.0")
    S2 = StrictVersion("1.1")
    assert S0 <= S2
    assert S0 <= S1
    assert S0 >= S1
    assert S0 >= S1


# Generated at 2022-06-20 16:39:00.678652
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import StrictVersion
    for versions in [('1.5.1', '1.5.2b2'), ('161', '3.10a'), ('8.02', '8.02'),
                     ('3.4j', '1996.07.12'), ('3.2.pl0', '3.1.1.6'),
                     ('2g6', '11g'), ('0.9', '2.2'), ('1.2.1', '1.2'),
                     ('1.1', '1.2.2'), ('1.2', '1.1'), ('1.2.1', '1.2.2'),
                     ('1.2.1', '1.1')]:
        if versions[0] <= versions[1]:
            print("%s <= %s" % versions)
            return False


# Generated at 2022-06-20 16:39:05.791477
# Unit test for constructor of class Version
def test_Version():
    class _BaseTest:
        def __init__(self, base_version, equal_versions, cmp_versions):
            self.base_version = base_version
            self.equal_versions = equal_versions
            self.cmp_versions = cmp_versions

    class Test(_BaseTest, Version):
        def parse(self, vstring):
            self.vstring = vstring

        def __str__(self):
            return self.vstring

        def __repr__(self):
            return 'Test(%s)' % self.vstring

        def _cmp(self, other):
            if isinstance(other, str):
                other = Test(other)
            assert isinstance(other, Test)
            order = ['<', '=', '>']

# Generated at 2022-06-20 16:39:07.200319
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    version = StrictVersion("1.10.2")



# Generated at 2022-06-20 16:39:12.736499
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from test.support import captured_stdout
    c = Version()
    c._cmp = lambda other: 1
    assert c.__gt__('test') == 1
    c._cmp = lambda other: NotImplemented
    assert c.__gt__('test') is NotImplemented
    assert c.__gt__(Version()) is NotImplemented
    c._cmp = lambda _: 0
    assert c.__gt__('test') == False



# Generated at 2022-06-20 16:39:23.522758
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # These should all work
    StrictVersion("1.2.3")
    StrictVersion("1.2")
    StrictVersion("1.2rc3")
    StrictVersion("1.2.0")
    StrictVersion("1.2.0.0")
    StrictVersion("1.2.0.0.0")

    # The following are all illegal, in various ways
    try:
        StrictVersion("1.2.3.4")
    except ValueError:
        pass
    else:
        raise AssertionError("1.2.3.4 is not a legal version number")

    try:
        StrictVersion("1.2.0.0.0.0.0")
    except ValueError:
        pass

# Generated at 2022-06-20 16:39:28.305341
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    sv = StrictVersion()
    sv.parse('0.4.0')
    assert(sv.version == (0, 4, 0))
    assert(sv.prerelease is None)
    sv.parse('0.4')
    assert(sv.version == (0, 4, 0))
    assert(sv.prerelease is None)
    sv.parse('1.0.4a3')
    assert(sv.version == (1, 0, 4))
    assert(sv.prerelease == ('a', 3))
    sv.parse('1.0.4')
    assert(sv.version == (1, 0, 4))
    assert(sv.prerelease is None)
    got_exception = False
    try:
        sv.parse('1.3.a4')
    except ValueError:
        got_exception

# Generated at 2022-06-20 16:39:30.688544
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert "1.2.3.4-a123-b456" == StrictVersion("1.2.3.4-a123-b456").__str__()



# Generated at 2022-06-20 16:39:48.405044
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """
    Method __repr__ of LooseVersion actually computes an instance of
    the class.

    >>> LooseVersion("1.0").__repr__()
    "LooseVersion ('1.0')"
    >>> LooseVersion("1.0").__repr__() == LooseVersion("1.0").__repr__()
    1
    >>> LooseVersion("1.0").__repr__() == LooseVersion("1.1").__repr__()
    0
    """


# Generated at 2022-06-20 16:39:50.289458
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.0') == Version('1.0')
    assert not (Version('1.0') == '1.0')



# Generated at 2022-06-20 16:39:54.468454
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    from distutils.tests import support
    import sys
    version = '3.2'
    v = LooseVersion (version)
    assert_equal (repr (v), "LooseVersion ('%s')" % version)
    version = '3.2.pl0'
    v = LooseVersion (version)
    assert_equal (repr (v), "LooseVersion ('%s')" % version)
    version = '3.2++'
    v = LooseVersion (version)
    assert_equal (repr (v), "LooseVersion ('%s')" % version)



# Generated at 2022-06-20 16:39:57.442712
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert v1.__ge__(v2) and v2.__ge__(v1)


# Generated at 2022-06-20 16:40:06.285750
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Make sure we can create a LooseVersion from a string
    a_version = LooseVersion('0.3.25')

    # Make sure we can extract elements from the LooseVersion
    if a_version.version[0] != 0 or a_version.version[1] != 3 or a_version.version[2] != 25:
        raise AssertionError

    # Make sure we can't screw with the LooseVersion
    try:
        a_version.version = [0,0,0]
    except AttributeError:
        # This is what we want
        pass
    else:
        raise AssertionError



# Generated at 2022-06-20 16:40:13.968630
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def test(vstring, errmsg=None):
        try:
            v = LooseVersion(vstring)
        except ValueError:
            if errmsg:
                sys.stdout.write("\n")
                sys.stdout.write(errmsg + "\n")
                sys.stdout.write("  should not have raised ValueError\n")
            raise
        except:
            if errmsg:
                sys.stdout.write("\n")
                sys.stdout.write(errmsg + "\n")
                sys.stdout.write("  raised wrong error type\n")
            raise
        if errmsg:
            sys.stdout.write("  should have raised ValueError\n")
            raise ValueError("should have raised ValueError")

# Generated at 2022-06-20 16:40:25.860728
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("0.4.1").__str__() == "0.4.1"
    assert StrictVersion("0.5a1").__str__() == "0.5a1"
    assert StrictVersion("0.5b3").__str__() == "0.5b3"
    assert StrictVersion("0.5").__str__() == "0.5"
    assert StrictVersion("0.9.6").__str__() == "0.9.6"
    assert StrictVersion("1.0").__str__() == "1.0"
    assert StrictVersion("1.0.4a3").__str__() == "1.0.4a3"
    assert StrictVersion("1.0.4b1").__str__() == "1.0.4b1"

# Generated at 2022-06-20 16:40:33.053503
# Unit test for constructor of class Version
def test_Version():
    # Test generic constructor
    v = Version()
    assert str(v) == ''


# The following functions and classes implement PEP 386 and PEP 440 versioning
# conventions.  PEP 386 supersedes PEP 345 (which is itself a superset of PEP
# 240).  PEP 440 supersedes PEP 386.
#
# See the following for more details:
#  * <http://www.python.org/dev/peps/pep-0386>
#  * <http://www.python.org/dev/peps/pep-0440>
#  * <http://www.python.org/dev/peps/pep-0345>
#  * <http://www.python.org/dev/peps/pep-0240>

# Regular expression template for matching the project version.
#


# Generated at 2022-06-20 16:40:38.705653
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    for v in ("1.5.1", "1.5.2b2", "161", "3.10a", "8.02", "3.4j",
              "1996.07.12", "3.2.pl0", "3.1.1.6", "2g6", "11g",
              "0.960923", "2.2beta29", "1.13++", "5.5.kw", "2.0b1pl0"):
        version = LooseVersion(v)
        assert str(version) == v


# Generated at 2022-06-20 16:40:49.463443
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Version.__ge__
    # Version.__ge__()
    # Version.__ge__(other)
    assert Version() >= Version()
    assert Version('1.2') >= Version('1.2')
    assert Version('1.2') >= Version('1.2a1')
    assert Version('1.2') >= Version('1.2b3')
    assert Version('1.2') >= Version('1.2c4')
    assert Version('1.2') >= Version('1.2a1.post1')
    assert Version() >= '2.2'


    # Issue 17889
    assert Version('1.0') >= '1'
    assert not (Version('1.0') >= '2')
    assert not (Version('1.0') >= '1.1')
    #assert not (Version('1.

# Generated at 2022-06-20 16:41:21.033253
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    s = LooseVersion("1.0.1")
    assert isinstance(s, LooseVersion)
    assert s.version == [1, 0, 1], "Wrong version parsed: "+str(s.version)
    s = LooseVersion("1.2.a3.0")
    assert isinstance(s, LooseVersion)
    assert s.version == [1, 2, "a", 3, 0]
    s = LooseVersion("1.2.1.2.3")
    assert isinstance(s, LooseVersion)
    assert s.version == [1, 2, 1, 2, 3]
    s = LooseVersion("1.2+b.3")
    assert isinstance(s, LooseVersion)
    assert s.version == [1, 2, "+b", 3]
    s = Loose

# Generated at 2022-06-20 16:41:31.060144
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Unit test for method __gt__ of class Version"""
    # Set up locals
    version1 = Version()
    version2 = Version()
    version3 = Version()
    version4 = Version()
    version1._System = "Linux"
    version2._System = "Linux"
    version3._System = "linux"
    version4._System = "linux"
    # Check value
    assert version1.__gt__(version2) == False, 'Value is false'
    # Check value
    assert version1.__gt__(version3) == False, 'Value is false'
    # Check value
    assert version1.__gt__(version4) == False, 'Value is false'
    # Check value
    assert version2.__gt__(version1) == False, 'Value is false'
    # Check value

# Generated at 2022-06-20 16:41:34.686166
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2')
    assert str(v) == '1.2'
    assert v.__repr__() == "Version ('1.2')"
    assert v == '1.2'
    assert '1.2' == v
    assert v != '1.2.0'
    assert v != '1.3'
    assert '1.2.0' != v
    assert '1.3' != v


# Generated at 2022-06-20 16:41:36.320616
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__(1) == NotImplemented

# Generated at 2022-06-20 16:41:39.713294
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    V = Version
    assert V('1.2.0') >= '1.2'

# Generated at 2022-06-20 16:41:41.076218
# Unit test for method __ge__ of class Version
def test_Version___ge__(): assert True # Don't know how to test

# Generated at 2022-06-20 16:41:50.045817
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    StrictVersion('1.3')
    StrictVersion('1.3.0')
    StrictVersion('1.3.0.0.0')
    StrictVersion('1.3b1')
    StrictVersion('1.3c1')
    StrictVersion('1.3.0a1')
    StrictVersion('1.3.0.0b1')
    StrictVersion('1.3.0.0.0c1')

# The following tests should fail:
#    StrictVersion('1.3.0.0.0.0')
#    StrictVersion('1.3-001')
#    StrictVersion('1.000')
#    StrictVersion('1.3.a1')
#    StrictVersion('1.3.b1')
#    StrictVersion('1.3

# Generated at 2022-06-20 16:41:51.621831
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    Version1 = Version()
    Version2 = Version()
    assert Version1 == Version2

# Generated at 2022-06-20 16:41:53.746148
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert (Version("1.2") < Version("1.2a1"))

# Generated at 2022-06-20 16:42:01.373238
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """This method tests the Version class' __lt__ method, which is implemented in
    the 'Version' abstract class.
    """
    from distutils.version import Version
    from distutils.version import LooseVersion
    from distutils.version import StrictVersion
    from distutils.version import IrrationalVersionError
    from distutils.version import parse

    # This is what a Version object __repr__ looks like,
    # so these are of the form: "Version('3.0')"
    version_objects = [
        Version("2"),
        Version("2.0"),
        Version("2.1"),
        Version("3"),
        Version("3.0"),
        Version("3.0.post1"),
    ]
    # The first version of the following should be less than the second version

# Generated at 2022-06-20 16:42:58.491360
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion ("2.2a2").__repr__() == "LooseVersion ('2.2a2')"

# Generated at 2022-06-20 16:43:08.156866
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def do_test(vstring, parsed, parts, prerelease):
        v = StrictVersion(vstring)
        if v.version != parsed:
            raise AssertionError("version component mismatch")
        if v.prerelease != prerelease:
            raise AssertionError("pre-release component mismatch")


# Generated at 2022-06-20 16:43:12.757332
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion('1.2.3') == StrictVersion('1.2.3')
    assert StrictVersion('1.2.3') == StrictVersion('1.2.3')
    assert StrictVersion('1.2.3a') < StrictVersion('1.2.3')
    assert StrictVersion('1.2.3b') < StrictVersion('1.2.3')
    assert StrictVersion('1.2.3c') < StrictVersion('1.2.3')
    assert StrictVersion('1.2.3rc') < StrictVersion('1.2.3')
    assert StrictVersion('1.0') == StrictVersion('1.0')
    assert StrictVersion('1.2.3a4') < StrictVersion('1.2.3a10')
    assert St

# Generated at 2022-06-20 16:43:24.349828
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    SV = StrictVersion

    v1 = SV('1.0')
    v2 = SV('2.0')
    v11 = SV('1.1')
    v12 = SV('1.2')
    v123 = SV('1.2.3')

    assert v123 < v12
    assert v12 < v11
    assert v11 < v2
    assert v2 < v1

    assert v1 <= v1
    assert v1 <= v123
    assert v1 <  v123

    assert v123 > v12
    assert v12 > v11
    assert v11 > v2
    assert v2 > v1

    assert v1 >= v1
    assert v123 >= v1
    assert v123 >  v1

    assert v1 == SV('1.0')
    assert v1 != v2

   

# Generated at 2022-06-20 16:43:31.638662
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    class_under_test = Version
    method_under_test = class_under_test.__lt__

    def raises(args, msg):
        try:
            method_under_test(*args)
            raise AssertionError("No exception raised", msg)
        except Exception as e:
            if msg and msg not in str(e):
                raise AssertionError("Wrong exception message: %s (expected '%s')" % (e, msg))

    Version('0.0.0').__lt__(Version('0.0.0'))

    Version('0.0.0').__lt__('0.0.0')
    Version('0.0.0').__lt__('0')
    Version('0.0.0').__lt__('0.0')
    Version('0.0.0').__lt__

# Generated at 2022-06-20 16:43:37.999677
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('0.0') < Version('0.1')
    assert Version('0.1') < Version('0.2')
    assert Version('0.2') < Version('1.0')
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= Version('0.0')
    assert Version('0.0') <= Version('0.0')
    assert Version('0.0') >= Version('-1.0')


# Generated at 2022-06-20 16:43:39.257345
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()

# Generated at 2022-06-20 16:43:41.689523
# Unit test for constructor of class Version
def test_Version():
    assert str(Version()) == '<uninitialized Version object>'
# end class Version



# Generated at 2022-06-20 16:43:44.321070
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # assert
    assert Version("1.1.1") == "Version ('1.1.1')"

# Generated at 2022-06-20 16:43:47.258004
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """
    Called from test/test_version.py
    """
    v = LooseVersion('1.2.3')
    assert repr(v) == "LooseVersion ('1.2.3')"


# Generated at 2022-06-20 16:45:55.154721
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    "Version.__lt__"

    v1 = Version()
    v2 = Version()
    assert not v1 < v2

# Generated at 2022-06-20 16:45:59.063250
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    v._cmp = (lambda x: 0)

    assert(not v.__gt__(None))
