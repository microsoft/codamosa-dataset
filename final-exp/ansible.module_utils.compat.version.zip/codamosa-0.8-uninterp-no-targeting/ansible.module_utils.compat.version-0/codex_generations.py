

# Generated at 2022-06-20 16:36:11.377188
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    for arg in []:
        for res in [True, False]:
            yield (eq_test, Version, arg, res)


# Generated at 2022-06-20 16:36:21.228080
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('0.4').__str__() == '0.4'
    assert StrictVersion('0.4.0').__str__() == '0.4.0'
    assert StrictVersion('0.4.1').__str__() == '0.4.1'
    assert StrictVersion('0.5a1').__str__() == '0.5a1'
    assert StrictVersion('0.5b3').__str__() == '0.5b3'
    assert StrictVersion('0.5').__str__() == '0.5'
    assert StrictVersion('0.9.6').__str__() == '0.9.6'
    assert StrictVersion('1.0').__str__() == '1.0'

# Generated at 2022-06-20 16:36:24.335952
# Unit test for method __le__ of class Version
def test_Version___le__():

    try:
        a = Version()
        b = Version()
        c = a.__le__(b)
    except Exception:
        c = None

    if c is None:
        return 'Fail'
    else:
        return 'Success'


# Generated at 2022-06-20 16:36:30.407615
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # A version is greater than another version if it is more recent.
    assert Version("1.0") > Version("0.9")
    assert not (Version("1.0") > Version("1.0"))
    assert not (Version("1.0") > Version("2.0"))
    # A version is greater than a string if the string does not parse
    # as a version.
    assert Version("1.0") > "0.9"
    assert not (Version("1.0") > "1.0")
    assert not (Version("1.0") > "2.0")
    # String comparison is performed by creating a Version from
    # the string.
    assert Version("1.0") > "0.9"
    assert not (Version("1.0") > "1.0")

# Generated at 2022-06-20 16:36:32.468606
# Unit test for constructor of class Version
def test_Version():
    for v in ['1.1', '1.2', '1.2.1', '2.1', '1.2-cvs']:
        Version(v)



# Generated at 2022-06-20 16:36:34.304635
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import pytest
    v = Version()
    with pytest.raises(NotImplementedError):
        v.__ge__()



# Generated at 2022-06-20 16:36:40.001295
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    from test_version_checker import VersionTests
    from testtools import make_tests

    vt = VersionTests('LooseVersion')
    vt.setup()
    vt.version = '1.0'
    vt.expected = '1.0'
    vt.reverse = False
    vt.older_and_newer(False)
    vt.setup()
    vt.version = '1.0a'
    vt.expected = '1.0a'
    vt.reverse = False
    vt.older_and_newer(False)
    vt.setup()
    vt.version = '1.0b'
    vt.expected = '1.0b'
    vt.reverse = False
    vt.older_and_newer(False)
   

# Generated at 2022-06-20 16:36:42.638583
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    vs1 = Version('1.2.3')
    vs2 = Version('1.2.3')
    assert vs1.__ge__(vs2)


# Generated at 2022-06-20 16:36:46.016027
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    tests = [LooseVersion('1'), LooseVersion('1.2'), LooseVersion('1.2.3'), LooseVersion('1.2.3.4')]

# Generated at 2022-06-20 16:36:47.981942
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert v1.__ge__(v2)

# Generated at 2022-06-20 16:36:59.000616
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert(repr(v) == "Version ('0')")


# Generated at 2022-06-20 16:37:07.235221
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    for input, expected in [
        ((1, 2, 3, "a", 1), "1.2.3a1"),
        ((1, 2, 0, "a", 1), "1.2a1"),
        ((1, 2, 3, "b", 1), "1.2.3b1"),
        ((1, 2, 0, "b", 1), "1.2b1")
    ]:
        if str(StrictVersion(input)) != expected:
            raise AssertionError("expected {}, got {}".format(expected, input))



# Generated at 2022-06-20 16:37:10.787050
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():

    v = StrictVersion("2.5.1")
    assert str(v) == "2.5.1", str(v)

    v = StrictVersion("2.5")
    assert str(v) == "2.5.0", str(v)

    v = StrictVersion("2.5a1")
    assert str(v) == "2.5a1", str(v)

    v = StrictVersion("2.5a0")
    assert str(v) == "2.5a0", str(v)


# Generated at 2022-06-20 16:37:19.865780
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.4')
    assert v.version == (1,4,0)
    assert v.prerelease is None
    v = StrictVersion('1.4.2')
    assert v.version == (1,4,2)
    assert v.prerelease is None
    v = StrictVersion('1.4a1')
    assert v.version == (1,4,0)
    assert v.prerelease == ('a', 1)
    v = StrictVersion('1.4.2b3')
    assert v.version == (1,4,2)
    assert v.prerelease == ('b', 3)



# Generated at 2022-06-20 16:37:23.000289
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.1')
    assert v < '1.2'
    assert v < Version('1.2')
    assert not (v < Version('0.2'))

# Generated at 2022-06-20 16:37:23.833399
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    other = ''
    assert v.__gt__(other) is NotImplemented



# Generated at 2022-06-20 16:37:24.181796
# Unit test for method __lt__ of class Version
def test_Version___lt__(): assert False

# Generated at 2022-06-20 16:37:33.494793
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    test_cases = {'1': ValueError,
                  '1.2.3.4': ValueError,
                  'a': ValueError,
                  '1.2a': ValueError,
                  '1.2a1': None,
                  '1.2.3': None,
                  '1.2.3.4': ValueError,
                  '1.2.3.4a5': ValueError,
                  '1.2.3a0': None,
                  '1.2.3b0': None,
                  '1.2.3.4b5': ValueError}
    for s, err in test_cases.items():
        if err:
            try:
                StrictVersion(s)
            except err:
                pass

# Generated at 2022-06-20 16:37:44.603203
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    from numbers import Integral
    assert isinstance(LooseVersion('1.1').__repr__(), str)
    assert LooseVersion('1.1').__repr__() == "LooseVersion ('1.1')"
    assert isinstance(LooseVersion('1').__repr__(), str)
    assert LooseVersion('1').__repr__() == "LooseVersion ('1')"
    assert isinstance(LooseVersion('1.0b3').__repr__(), str)
    assert LooseVersion('1.0b3').__repr__() == "LooseVersion ('1.0b3')"
    assert isinstance(LooseVersion('1.0.11').__repr__(), str)

# Generated at 2022-06-20 16:37:49.538762
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():

    #
    v = LooseVersion('1.2rc3')
    assert v.vstring == '1.2rc3'
    assert v.version == [1, 2, 'rc', 3]
    assert str(v) == '1.2rc3'



# Generated at 2022-06-20 16:37:59.636452
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest
    class Version___le__Test(unittest.TestCase):
        def test(self):
            v = Version()
            self.assertTrue(v <= v)
    unittest.main()


# Generated at 2022-06-20 16:38:02.271300
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    instance = Version()
    assert set(repr(instance).split(" ")[0:3]) == set([
        "distutils.version.Version",
        "('None')",
        "<class",
    ])


# Generated at 2022-06-20 16:38:04.103167
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    assert version.__ge__(None) is NotImplemented

# Generated at 2022-06-20 16:38:07.165294
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert isinstance(Version.__le__(object, object), object)


# Generated at 2022-06-20 16:38:08.785401
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert not (Version('1.2') >= Version('2.2'))


# Generated at 2022-06-20 16:38:10.046803
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.0.4a3") == "1.0.4a3"


# Generated at 2022-06-20 16:38:12.006295
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.4') == Version('1.4')


# Generated at 2022-06-20 16:38:20.388832
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:38:22.240258
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import sys
    if sys.version_info[0] < 3:
        return True
    else:
        test = StrictVersion("1.1.1")
        return bool(test)



# Generated at 2022-06-20 16:38:27.701351
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for sv in ['0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3',
                '0.5', '0.9.6', '1.0', '1.0.4a3', '1.0.4b1',
                '1.0.4']:
        StrictVersion(sv)
    for sv in ['1', '1.2.3.4', '1.2a3.4', '1.2b3.4', '2.7.2.2',
                '1.3.a4', '1.3pl1', '1.3c4']:
        try:
            StrictVersion(sv)
        except ValueError:
            pass

# Generated at 2022-06-20 16:38:52.665064
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    version_strs = ["1.5.1", "1.5.2b2", "161.6.2", "3.10a", "8.02", "3.4j",
                    "1996.07.12", "3.2.pl0", "2g6", "11g", "0.960923",
                    "2.2beta29", "1.13++", "5.5.kw", "2.0b1pl0"]

# Generated at 2022-06-20 16:39:01.077231
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    cases = (('1.2.0', (1, 2, 0)),
             ('1.2', (1, 2, 0)),
             ('1.2.3', (1, 2, 3)),
             ('1.02', (1, 2, 0)),
             ('1.2.3.4', NotImplemented),
             ('1.2-3', NotImplemented),
             ('1.2.a1', NotImplemented))
    for inp, outp in cases:
        try:
            v = StrictVersion(inp)
        except ValueError:
            if outp is NotImplemented:
                pass
            else:
                raise
        else:
            assert v.version == outp



# Generated at 2022-06-20 16:39:03.081863
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('')
    if v:
        v.parse('1.0.0a0')
    else:
        v.parse('1.0.0a0')

# Generated at 2022-06-20 16:39:04.749784
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    n = LooseVersion()
    n.parse('1.2.3')
    s = repr(n)
    assert s == "LooseVersion ('1.2.3')"


# Generated at 2022-06-20 16:39:15.505168
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    assert lv.parse('1.2b1') == None, "parse('1.2b1') should return None"
    assert lv.version == [1, 2, 'b', 1], "list of components"
    assert lv.vstring == '1.2b1', "save original string for __str__"
    assert str(lv) == '1.2b1', "__str__ should return original string"
    assert repr(lv) == "LooseVersion ('1.2b1')", "__repr__ should contain original string"
    assert lv.prerelease == (None, None), "prerelease version"
    assert lv.parse('1.2.3') == None, "parse('1.2.3') should return None"

# Generated at 2022-06-20 16:39:19.745136
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Test method __repr__ of class Version"""
    v = Version()
    assert repr(v) ==  "Version ('None')"
    v = Version('1.2.3')
    assert repr(v) == "Version ('1.2.3')"


# Generated at 2022-06-20 16:39:22.815025
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion()
    v.parse("1.13++")
    assert (str(v) == "1.13++")
test_LooseVersion___str__()



# Generated at 2022-06-20 16:39:27.917932
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    cases = ['1.2.3a0', '1.2.3b0', '1.2.3c0', '1.2.3', '1.2.3.4a0',
             '1.1', '1.2a1', '1.2.3a1.4.5', '0.4']

    for vs in cases:
        v = StrictVersion(vs)
        assert str(v) == vs



# Generated at 2022-06-20 16:39:37.288197
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import unittest

    class TestStrictVersionParse(unittest.TestCase):

        def test_parse(self):
            tests = ['1.4.1', '1.4', '1.4a3', '1.4b1', '1.4rc2',
                    '1.0.4a12', '1.0.4b2', '1.0.4rc3', '1.0.4',
                    '1.0', '1']

            for vstring in tests:
                pv = StrictVersion(vstring)
                self.assertEqual(str(pv), vstring)


# Generated at 2022-06-20 16:39:45.755220
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    vers = Version('1.0')
    assert vers <= '1.0'
    assert vers <= '1.1'
    assert not vers <= '0.0'
    assert vers >= '1.0'
    assert not vers >= '1.1'
    assert vers >= '0.0'
    assert vers < '1.1'
    assert not vers < '0.0'
    assert not vers < '1.0'
    assert vers > '0.0'
    assert not vers > '1.0'
    assert vers > '1.1'
    assert vers == '1.0'
    assert vers != '0.0'



# Generated at 2022-06-20 16:40:15.879357
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    import sys

    class Version_Subclass(Version):
        def _cmp(self, other):
            return 3

    v = Version_Subclass()
    try:
        result = v > v
    except:
        print('Bug in Version.__gt__: exception raised')
        sys.exit(1)

    if result:
        sys.exit(0)
    else:
        print('Bug in Version.__gt__: did not return True')
        sys.exit(1)

# Generated at 2022-06-20 16:40:18.245491
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(v) == False


# Generated at 2022-06-20 16:40:28.245792
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"
    assert LooseVersion('1.2.3')._cmp(LooseVersion('1.3.1.3')) == -1
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"
    assert LooseVersion('1.2.3')._cmp(LooseVersion('1.3.1.3')) == -1
    assert LooseVersion('1.3.1.3')._cmp(LooseVersion('1.2.3')) == 1
    assert LooseVersion('1.2.3')._cmp(LooseVersion('1.2')) == 1

# Generated at 2022-06-20 16:40:33.007521
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  x = Version()
  y = Version()
  x.parse('1.2.3b2')
  y.parse('1.2.3')
  assert(x >= y)
  y.parse('1.2.3b2')
  assert(x >= y)
  y.parse('1.2.3b1')
  assert(x >= y)


# Generated at 2022-06-20 16:40:35.664610
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion("1.2.1")
    assert repr(v) == "LooseVersion ('1.2.1')"
    assert str(v) == "1.2.1"


# Generated at 2022-06-20 16:40:40.954823
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():

    # From the doc:
    #    generate Python code to recreate
    #    the instance

    lv = LooseVersion('1.2.3.dev')
    assert repr(lv) == "LooseVersion ('1.2.3.dev')"
    lv = LooseVersion('1.2.3')
    assert repr(lv) == "LooseVersion ('1.2.3')"


# Generated at 2022-06-20 16:40:45.579225
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest

    class TestExample(unittest.TestCase):
        def runTest(self):
            version_instance = Version("abc")
            version_instance._cmp = lambda other: 0
            self.assertEqual(version_instance.__eq__("abc"), True)

    unittest.main()


# Generated at 2022-06-20 16:40:48.892958
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    cls = type('Version', (Version,), {})
    cls._cmp = lambda self, other: 0
    v = cls()
    assert not (v > 'a')



# Generated at 2022-06-20 16:40:59.542218
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-20 16:41:07.612847
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    v1 = eval(repr(Version('1.1')))
    v2 = eval(repr(Version('1.1')))
    assert not (v1 < v2)
    assert not (v2 < v1)

    v1 = eval(repr(Version('1.1.1')))
    v2 = eval(repr(Version('1.1.1')))
    assert not (v1 < v2)
    assert not (v2 < v1)


# Generated at 2022-06-20 16:42:04.212744
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    Version()

# Generated at 2022-06-20 16:42:06.745597
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version(1)
    v2 = Version(1)
    assert v == v2


# Generated at 2022-06-20 16:42:10.258844
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """
    >>> LooseVersion('1.0')
    LooseVersion ('1.0')
    """



# Generated at 2022-06-20 16:42:18.722040
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion('1.2.3.4')
    l1 = LooseVersion('1.2.3a4')
    l2 = LooseVersion('1.2.3.4.a4')
    l3 = LooseVersion('1,2.3.4.5')
    l4 = LooseVersion('1.2a3.post4.dev5')
    l5 = LooseVersion('1.2c5.post4.dev5')
    print(l.version)
    print(l1.version)
    print(l2.version)
    print(l3.version)
    print(l4.version)
    print(l5.version)

if __name__ == '__main__':
    test_LooseVersion_parse()

# Generated at 2022-06-20 16:42:28.548994
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__('1.0') == NotImplemented
    assert v.__lt__(StrictVersion('1.0')) == NotImplemented
    assert v.__lt__(LooseVersion('1.0')) == NotImplemented

    # 1.0 is less than 1.0.0
    assert StrictVersion('1.0') < StrictVersion('1.0.0')
    # 1.0.0.a1 is greater than 1.0
    assert StrictVersion('1.0.0.a1') > StrictVersion('1.0')
    # 1.0.a1 is greater than 1.0a1
    assert StrictVersion('1.0.a1') > StrictVersion('1.0a1')



# Generated at 2022-06-20 16:42:35.791388
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    for string, expected in [
            ('4.1.2', (4, 1, 2)),
            ('4.1', (4, 1, 0)),
            ('4', (4, 0, 0)),
            ('4.1a2', (4, 1, 0, ('a', 2))),
            ('4.1b2', (4, 1, 0, ('b', 2))),
            ('4.1.2a3', (4, 1, 2, ('a', 3))),
            ('4.1.2b3', (4, 1, 2, ('b', 3))),
            ('0.4', (0, 4, 0)),
            ('0.4.0', (0, 4, 0)),
            # Invalid versions
            ]:
        version = StrictVersion(string)
        actual = version._StrictVersion

# Generated at 2022-06-20 16:42:40.992517
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version("1.0")

    if version >= "1.00":
        pass
    else:
        assert False


    if not version >= "1.1":
        pass
    else:
        assert False



# Generated at 2022-06-20 16:42:45.845314
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.3')
    v2 = Version('1.3.1')
    v3 = Version('1.3.1')
    assert not (v1 > v2)
    assert not (v2 > v3)
    assert v2 > v1
    assert v2 >= v1
    assert v2 >= v3
    assert not (v1 >= v2)
    assert not (v2 >= v1)

# Generated at 2022-06-20 16:42:57.314902
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    if __name__ == '__main__':
        r = LooseVersion('1.2.3')
        assert r.version == [1,2,3]
        r = LooseVersion('1.2.3+build4')
        assert r.version == [1,2,3,"+build4"]
        r = LooseVersion('1.2+build4')
        assert r.version == [1,2,"+build4"]
        r = LooseVersion('1+build4')
        assert r.version == [1,"+build4"]
        r = LooseVersion('1')
        assert r.version == [1]
        r = LooseVersion('1.02')
        assert r.version == [1,2]
        r = LooseVersion('1.2.0')

# Generated at 2022-06-20 16:43:02.066028
# Unit test for constructor of class Version
def test_Version():
    def test(vstring):
        v = Version(vstring)
        return str(v), repr(v), v
    assert test('1.2') == ('1.2', "Version ('1.2')", Version('1.2'))



# Generated at 2022-06-20 16:45:24.230771
# Unit test for method __gt__ of class Version

# Generated at 2022-06-20 16:45:26.398276
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"
    v = Version("1.2.3")
    assert repr(v) == "Version ('1.2.3')"


# Generated at 2022-06-20 16:45:29.068704
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')", repr(v)


# Generated at 2022-06-20 16:45:38.995134
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """Unit test for method parse of class LooseVersion

    It's complicated to unit test this method. It's implemented in an almost-
    recursive way with the component_re regular expression, which matches a
    component and then calls itself to parse the next component. This is a
    problem for the regular expression '.', because it matches any character.
    A solution is to split the string in a list with this regular expression,
    and then match each component in the list.
    """
    import re
    from distutils.version import LooseVersion
    from distutils.tests import unittest


# Generated at 2022-06-20 16:45:44.288709
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test method __gt__ of class Version (imported from module version)."""

    v = Version()
    v.__repr__ = lambda: 'B'

    # coverage: branch not taken
    assert v < 1

# Generated at 2022-06-20 16:45:53.156717
# Unit test for constructor of class Version
def test_Version():
    v1 = Version.parse('1.3')
    v1_copy = Version(str(v1))
    assert v1 == v1_copy

    def test_bad_constructor():
        try:
            Version.parse('1.3a')
        except ValueError:
            pass
        else:
            raise AssertionError("failed to detect non-numeric version")

    test_bad_constructor()

RE_VERSION = re.compile(r'''^
    (?P<version>[^:]+)
    (:(?P<pre>.*))?$
''', RE_FLAGS)


# Generated at 2022-06-20 16:45:56.274696
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    sver = StrictVersion("1.0.0")
    assert str(sver) == "1.0.0"
    sver = StrictVersion("0.4")
    assert str(sver) == "0.4.0"
    sver = StrictVersion("0.5a1")
    assert str(sver) == "0.5a1"
    sver = StrictVersion("0.5")
    assert str(sver) == "0.5.0"

# Generated at 2022-06-20 16:46:01.383831
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    a = LooseVersion('1.0')
    assert str(a) == '1.0'
    a = LooseVersion('1.0.0')
    assert str(a) == '1.0.0'
    a = LooseVersion('1.0.0.0')
    assert str(a) == '1.0.0.0'
