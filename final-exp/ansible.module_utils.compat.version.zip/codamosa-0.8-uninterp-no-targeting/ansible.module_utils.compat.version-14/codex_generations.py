

# Generated at 2022-06-20 16:36:11.182264
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= 1
    assert v >= None
    assert v >= '1'
test_Version___ge__()


# Generated at 2022-06-20 16:36:20.357469
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("1.2")
    assert v1 > "0.3"
    assert v1 > "0.0.4"
    assert v1 > "0.2"
    assert v1 > "0.2.0"
    assert v1 > "0.0.3"
    assert v1 > "0.0.2.1"
    assert v1 > "0.0.2.0"
    assert v1 > "0.0.1.99"
    assert not v1 > "1.2"
    assert not v1 > "1.2.1"
    assert not v1 > "1.2.0"
    assert not v1 > "1.1.99"



# Generated at 2022-06-20 16:36:27.931819
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def _test(vstring, expected):
        sv = StrictVersion(vstring)
        sv.parse(vstring)
        if sv.version != expected.version:
            raise AssertionError("%r != %r" % (sv.version, expected.version))
        if sv.prerelease != expected.prerelease:
            raise AssertionError("%r != %r" % (sv.prerelease, expected.prerelease))

    _test("3.3c1", StrictVersion("3.3c1"))
    _test("2.2",   StrictVersion("2.2"))
    _test("1.1.1", StrictVersion("1.1.1"))
    _test("1.1.1a0", StrictVersion("1.1.1a0"))


# Generated at 2022-06-20 16:36:35.670991
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    import tempfile
    import os
    import pathlib
    import sys
    import shutil
    import random
    import builtins
    import importlib.util
    # Copy any needed files
    outer_path = os.path.abspath(__file__)
    outer_dir = os.path.dirname(outer_path)
    base_dir = os.path.join(outer_dir, "versions_TestVersion___lt__")
    if os.path.isdir(base_dir):
        shutil.rmtree(base_dir)
    os.mkdir(base_dir)
    inner_dir = os.path.join(base_dir,
                             "version")
    inner_path = os.path.join(inner_dir,
                              "__init__.py")
   

# Generated at 2022-06-20 16:36:44.813454
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('1.0')) == '1.0'
    assert str(StrictVersion('1.0-a1')) == '1.0a1'
    assert str(StrictVersion('1.0a1')) == '1.0a1'
    assert str(StrictVersion('1.0.0')) == '1.0.0'
    assert str(StrictVersion('1.0-0')) == '1.0.0'
    assert str(StrictVersion('1.0-0a1')) == '1.0.0a1'
    assert str(StrictVersion('1.0-a1')) == '1.0a1'
    assert str(StrictVersion('1.0.0-a1')) == '1.0.0a1'


# Generated at 2022-06-20 16:36:54.655792
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import re
    version_re = re.compile(r"^\d+(\.\d+)*([abc]|rc\d+)?$", re.IGNORECASE)
    def check(v):
        s = v.__str__()
        assert (isinstance(s, types.StringType))
        if (s != '0'):
            assert (version_re.match(s) is not None)
    check(LooseVersion('1.2.3'))
    check(LooseVersion('1.2.3.a'))
    check(LooseVersion('1.2.3.b'))
    check(LooseVersion('1.2.3.c'))
    check(LooseVersion('1.2.3.rc1'))

# Generated at 2022-06-20 16:36:57.556594
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv_obj = LooseVersion('1.1.3b')
    expected = "LooseVersion ('1.1.3b')"

    assert str(lv_obj.__repr__()) == expected

# Generated at 2022-06-20 16:36:59.250019
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.1') >= Version('1.0')

# Generated at 2022-06-20 16:37:02.194900
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    print('Testing method __gt__ of class Version')
    ver1 = Version()
    ver2 = Version('0.1')
    assert(ver1.__gt__(ver2) == False)
    assert(ver2.__gt__(ver1) == True)


# Generated at 2022-06-20 16:37:08.284720
# Unit test for method __le__ of class Version
def test_Version___le__():
    V = Version
    assert V('1.2') <= '1.2'
    assert V('1.2') <= '1.2.0'
    assert V('1.2') <= V('1.2.0')
    assert V('1.2.0') <= V('1.2.0.0')
    assert V('1.2.0.0') <= V('1.2.0.0')

    assert not V('1.2.0') <= V('1.2')
    assert not V('1.2.0.0') <= V('1.2.0')

    assert not V('1.2') <= V('1.2a1')
    assert not V('1.2a1') <= V('1.2')


# Generated at 2022-06-20 16:37:20.457424
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import subprocess
    import sys
    prog = 'import re; from distutils.version import Version; from distutils.tests import version_mock as mock ; from distutils.tests import support ; support.run_unittest(mock.TestVersion___ge__)'
    subprocess.call([sys.executable, "-c", prog])


# Generated at 2022-06-20 16:37:30.562625
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v == '0'

    class MyVersion(Version):
        def __init__(self, vstring=None):
            pass

        def parse(self, vstring):
            pass

        def __str__(self):
            return '1.0'

        def __repr__(self):
            return "MyVersion ('%s')" % str(self)

        def _cmp(self, other):
            if isinstance(other, MyVersion):
                return 0
            else:
                raise TypeError('other')

    v1 = MyVersion()
    w1 = MyVersion()
    v2 = Version()

    assert (v1 > v2) is NotImplemented
    assert v1 > w1
    assert v1 > '0'
    assert not (v1 > '1.0')

# Generated at 2022-06-20 16:37:33.379985
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion("123")
    assert lv.__str__() == "123"

# Generated at 2022-06-20 16:37:35.604422
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    a = LooseVersion('1.2.3')
    assert repr(a) == "LooseVersion ('1.2.3')"


# Generated at 2022-06-20 16:37:47.166981
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-20 16:37:56.335605
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def do_test(version, expected):
        "Pass a string version to StrictVersion.parse and make sure it" \
        " returns an object which compares equal to the tuple expected."
        # Make sure we have an instance of StrictVersion
        version = StrictVersion(version)
        # Convert both to tuples
        version = version.version + (version.prerelease,)
        expected = expected + (None,)
        assert version == expected

    do_test('1.2.3', (1, 2, 3))
    do_test('1.2.0', (1, 2, 0))
    do_test('1.2', (1, 2, 0))
    do_test('1.2a1', (1, 2, 0, ('a', 1)))

# Generated at 2022-06-20 16:37:57.999251
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert False == (v1 < v2)
    assert False == (v2 < v1)

# Generated at 2022-06-20 16:38:04.061412
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import unittest

    # test empty string
    expected = ""
    lv = LooseVersion(expected)
    observed = str(lv)
    unittest.TestCase().assertEqual(expected, observed,
                        msg="LooseVersion('%s') expected to return %s, got %s" % (str(lv), expected, observed))

    # test empty list
    expected = ""
    lv = LooseVersion()
    lv.version = []
    observed = str(lv)
    unittest.TestCase().assertEqual(expected, observed,
                        msg="LooseVersion('%s') expected to return %s, got %s" % (str(lv), expected, observed))

    # test empty list
    expected = ""
    lv = LooseVersion()
    lv.version = []
    lv

# Generated at 2022-06-20 16:38:14.187284
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    def testit(vstring, expected_repr):
        ver = LooseVersion(vstring)
        actual_repr = repr(ver)
        if actual_repr != expected_repr:
            raise AssertionError("%s != %s" % (actual_repr, expected_repr))
    testit("1.2.3", "LooseVersion ('1.2.3')")
    testit("1.2.3a", "LooseVersion ('1.2.3a')")
    testit("1.2.3b", "LooseVersion ('1.2.3b')")
    testit("1.2.3.4", "LooseVersion ('1.2.3.4')")

# Generated at 2022-06-20 16:38:20.998705
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version("1.0") > Version("1.0-a1")
    assert Version("1.0c1") > Version("1.0b2")
    assert Version("1.0") > Version("1.0a")
    assert Version("1.0") > Version("1.0a1")
    assert Version("1.0a1") > Version("1.0c1")
    assert Version("2.0") > Version("1.9.9.9")
    assert Version("1.0") > Version("1.0-rc1")  # PEP 440
    assert Version("1.0") > Version("1.0-1")  # PEP 440
    assert Version("1.0") > Version("1.0+abcdefghijklmnop")  # PEP 440


# Generated at 2022-06-20 16:38:38.882767
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    Version('1.1.1').__gt__('1.1')
    Version('1.1.1').__gt__('1.1.1')
    Version('1.1.1').__gt__('1.1.2')
    Version('1.1.1').__gt__('1.2')
    Version('1.1.1').__gt__('2')
    Version('1.1.1').__gt__('1.1b1')
    Version('1.1.1').__gt__('1.0.1rc1')
    Version('1.1.1').__gt__('1.1rc1')
    Version('1.1.1').__gt__(None)

# Generated at 2022-06-20 16:38:47.215341
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    for vstring in ['1.5.1', '161', '3.10a', '8.02', '3.4j', '1996.07.12',
                    '3.2.pl0', '3.1.1.6', '2g6', '11g', '0.960923',
                    '2.2beta29', '1.13++', '5.5.kw', '2.0b1pl0']:
        assert str(LooseVersion(vstring)) == vstring


# Tack on extra methods to class StrictVersion
# (I could have done this by just subclassing, but it gets a bit
# messy because StrictVersion defines __init__, and I want to avoid
# accidentally invoking StrictVersion.__init__ when I really mean
# Version.__init__)

# Generated at 2022-06-20 16:38:50.441854
# Unit test for constructor of class Version
def test_Version():
    from distutils.tests import support
    ver1 = Version()
    ver2 = Version('1.2')

    support.compare(repr(ver2),
                    'Version (\'1.2\')')


# Generated at 2022-06-20 16:38:57.557775
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    VERBOSE = 1
    if VERBOSE:
        print('Test for method __lt__ in class Version)')
    v1 = Version('1.2.3a1')
    v2 = Version('1.2.3b1')
    # the below test should pass.
    if v1 < v2:
        if VERBOSE:
            print('PASS\n')
        return 0

    if VERBOSE:
        print('FAIL\n')
    return 1


# Generated at 2022-06-20 16:39:00.973992
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.2.3')
    assert v <= '1.2.3'
    assert v <= '1.2.4'
    assert v <= Version('1.2.4')
    assert v <= Version('1.2.3')
    assert v <= Version('1.2.3.0')
    assert v <= Version('1.2.3.0.0')
    assert v <= Version('1.2.3.0.0.0')



# Generated at 2022-06-20 16:39:04.100168
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    print("Testing Version.__gt__...")
    v1 = Version("1.2.3")
    v2 = Version("1.2.4")
    v3 = Version("1.3.0")
    assert v1 < v2
    assert v1 < v3
    assert v2 < v3
    assert not v1 == v2
    assert not v1 == v3
    assert not v2 == v3


# Generated at 2022-06-20 16:39:15.451840
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3')
    assert v.version == '1.2.3'
    assert v.version_info == ('1', '2', '3', 'final', 0, ('1', '2', '3'))
    v = Version('1.2.3.dev3')
    assert v.version == '1.2.3.dev3'
    assert v.version_info == ('1', '2', '3', 'dev', 3, ('dev', 3))
    v = Version('0.4a1')
    assert v.version == '0.4a1'
    assert v.version_info == ('0', '4', 'a1', 'final', 0, ('a', '1'))
    v = Version('0.4rc2')

# Generated at 2022-06-20 16:39:21.186460
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert str(v) == ''
    assert repr(v) in ["Version ('')", "Version('')"]

    v = Version('1.2.3')
    assert str(v) == '1.2.3'
    assert repr(v) in ["Version ('1.2.3')", "Version('1.2.3')"]

test_Version()
del test_Version



# Generated at 2022-06-20 16:39:23.521934
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    r = LooseVersion("2")
    exp = '2'
    assert r.__str__() == exp



# Generated at 2022-06-20 16:39:25.252459
# Unit test for method __le__ of class Version
def test_Version___le__():
	v = Version()
	assert v.__le__(0) == NotImplemented

# Generated at 2022-06-20 16:39:55.574941
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from os import path
    from sys import path as sys_path
    from shutil import rmtree
    from tempfile import mkdtemp
    from textwrap import dedent

    def _make_dist(pkg_dir, pkg_name, version, **kw):
        # Make a simple distribution
        egg_info = "%s-%s.egg-info" % (pkg_name, version)
        pkg_info = path.join(pkg_dir, egg_info, "PKG-INFO")
        if not path.isdir(path.join(pkg_dir, egg_info)):
            os.makedirs(path.join(pkg_dir, egg_info))
        f = open(pkg_info, "w")

# Generated at 2022-06-20 16:40:00.884504
# Unit test for constructor of class Version
def test_Version():
    try:
        Version(1)
    except TypeError:
        pass
    else:
        raise AssertionError("Version(1) should have raised TypeError")
    v = Version("1")
    assert str(v) == "1"
    assert repr(v) == "'1'"


# Generated at 2022-06-20 16:40:06.965760
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v = LooseVersion('0.4')
    assert v.version == (0, 4)
    assert str(v) == '0.4'

    v = LooseVersion('1.2.3')
    assert v.version == (1, 2, 3)
    assert str(v) == '1.2.3'

    v = LooseVersion('1.2.3.4')
    assert v.version == (1, 2, 3, 4)
    assert str(v) == '1.2.3.4'

    v = LooseVersion('1.2b3')
    assert v.version == (1, '2b3')
    assert str(v) == '1.2b3'

    v = LooseVersion('1.2b3.4')

# Generated at 2022-06-20 16:40:14.463236
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    # From SourceForge bug #679521,
    # http://sourceforge.net/tracker/index.php?func=detail&aid=679521&group_id=5470&atid=105470
    #
    # Note that the version number is *invalid* as far as RFC 822 goes.
    # A build number is only allowed between the major/minor version
    # and the pre-release/post-release tags.
    lv.parse("2.2.3 (#42, May 25 2003, 18:44:16) [MSC 32 bit (Intel)]")
    assert lv.version == [2, 2, 3], lv.version
    # From SourceForge bug #679537,
    # http://sourceforge.net/tracker/index.php?func=detail

# Generated at 2022-06-20 16:40:21.131448
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v._cmp(object()) is NotImplemented
    assert v == NotImplemented
    assert not v != NotImplemented

    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 == v1
    assert v1 != v2

# Generated at 2022-06-20 16:40:23.499208
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v1 = LooseVersion("1.0.dev456")
    assert_equal(v1.version, ['1', '0', 'dev', '456'])


# Generated at 2022-06-20 16:40:31.611802
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert str(LooseVersion('1.0.4.2')) == '1.0.4.2'
    assert str(LooseVersion('1.5.1')) == '1.5.1'
    assert str(LooseVersion('161')) == '161'
    assert str(LooseVersion('3.10a')) == '3.10a'
    assert str(LooseVersion('8.02')) == '8.02'
    assert str(LooseVersion('3.4j')) == '3.4j'
    assert str(LooseVersion('1996.07.12')) == '1996.07.12'
    assert str(LooseVersion('3.2.pl0')) == '3.2.pl0'
    assert str(LooseVersion('3.1.1.6'))

# Generated at 2022-06-20 16:40:35.487542
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version

    assert not Version('1.0') == 0
    assert not Version('1.0') == ''
    assert not Version('1.0') == '1'
    assert not Version('1.0') == '1.0.a'
    assert not Version('1.0') == '1.0.1'
    assert not Version('1.0') == '1.0.a1'
    assert Version('1.0') == Version('1.0')
    assert not Version('1.0') == Version('1.a')
    assert not Version('1.0') == Version('1.0.1')
    assert not Version('1.0') == Version('1.0.a1')


# Generated at 2022-06-20 16:40:42.272512
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    for v in ['1.5.1', '1.5.2b2', '161', '3.10a', '8.02', '3.4j',
              '1996.07.12', '3.2.pl0', '3.1.1.6', '2g6', '11g', '0.960923',
              '2.2beta29', '1.13++', '5.5.kw', '2.0b1pl0']:
        print(LooseVersion(v))



# Generated at 2022-06-20 16:40:44.830629
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 <= v2


# Generated at 2022-06-20 16:41:16.093420
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # if no argument is passed, it should return
    # a string representation of the version number
    version = LooseVersion()
    version.parse('2.1.1a1')
    assert_equal(str(version), '2.1.1a1')


# Generated at 2022-06-20 16:41:17.727547
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    a = Version()
    b = Version()
    assert (a < b) == NotImplemented


# Generated at 2022-06-20 16:41:22.448709
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    other = Version()
    expected = False
    result = v.__ge__(other)
    assert result == expected


# Generated at 2022-06-20 16:41:31.443015
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-20 16:41:37.452813
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:41:39.298849
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.0')
    assert v <= '1.0'
    assert v <= Version('1.0')
    assert '1.0' <= v
    assert Version('1.0') <= v

# Generated at 2022-06-20 16:41:43.566030
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    return str(Version()) == "Version ('0')" and \
           repr(Version('1.2.3.4a3')) == "Version ('1.2.3.4a3')"


# Generated at 2022-06-20 16:41:46.863531
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import doctest
    return doctest.run_docstring_examples(LooseVersion.parse, globals(),
                                      optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-20 16:41:53.396387
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2')
    assert(str(v) == '1.2')
    v = StrictVersion('1.2.3a1')
    assert(str(v) == '1.2.3a1')

# Generated at 2022-06-20 16:41:59.343658
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    # check that Version.__repr__() returns something that can be
    # evaled to create a new object equivalent to the original one
    #
    # Make sure eval(repr(v)) == v
    assert eval(repr(v)) == v
    # For versions that support it, make sure eval(str(v)) == v
    try:
        assert eval(str(v)) == v
    except SyntaxError:
        pass



# Generated at 2022-06-20 16:42:31.353518
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2
    assert v1 <= v2
    assert v1 >= v2
    assert not v1 < v2
    assert not v1 > v2



# Generated at 2022-06-20 16:42:37.339231
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # StrictVersion.parse(vstring)

    # Ensure that we're not dependent on the sequence in which the
    # named groups were defined.
    for (major, minor, patch, prerelease, prerelease_num) in \
        [ (1, 2, 3, 'a', 4),
          (1, 2, 3, 'b', 4),
          (1, 2, 3, None, None),
          (1, 2, None, None, None),
          ]:
        vstring = '.'.join( \
            [ str(major), str(minor), \
              patch and str(patch) or '', \
              prerelease and (prerelease + str(prerelease_num)) or ''])
        v = StrictVersion(vstring)
        assert v.version == (major, minor, patch)

# Generated at 2022-06-20 16:42:45.778621
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Test each of the valid cases from the module docstring
    v = StrictVersion("0.4")
    assert v.version == (0, 4, 0)
    assert v.prerelease is None

    v = StrictVersion("0.4.0")
    assert v.version == (0, 4, 0)
    assert v.prerelease is None

    v = StrictVersion("1.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion("1.0.4a3")
    assert v.version == (1, 0, 4)
    assert v.prerelease == ('a', 3)

    v = StrictVersion("1.0.4b1")
    assert v.version == (1, 0, 4)
    assert v.pre

# Generated at 2022-06-20 16:42:56.411444
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import types
    v = Version()
    assert type(v.__ge__) is types.MethodType, 'Not a method'
    assert v.__ge__.__self__ is v, 'Method not bound'
    assert v.__ge__.__func__ is Version.__ge__, 'Method bound to wrong function'
    assert v.__ge__.__name__ == '__ge__', 'Method name is wrong'
    assert v.__ge__.__doc__ == Version.__ge__.__doc__, 'Method docstring is wrong'
    assert v.__ge__.__code__ is not Version.__ge__.__code__, 'Method code is shared'

# Generated at 2022-06-20 16:42:59.624984
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    a_Version = Version('a')
    assert repr(a_Version) == "Version ('a')"
    return



# Generated at 2022-06-20 16:43:02.131436
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version() == False
    assert Version() < None == NotImplemented

# Generated at 2022-06-20 16:43:05.829852
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0.0')
    v2 = Version('1.0.0')
    assert v1 <= v2
    v1 = Version('1.0.1')
    v2 = Version('1.0.0')
    assert v1 > v2

# Generated at 2022-06-20 16:43:13.524563
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version1 = "1.0"
    version2 = "2.0"
    assert eval("Version('"+version1+"') < Version('"+version2+"')") == True
    assert eval("Version('"+version1+"') < Version('"+version1+"')") == False

test_Version___lt__()

# Generated at 2022-06-20 16:43:18.481097
# Unit test for method __le__ of class Version
def test_Version___le__():
    _v1 = Version()
    _v2 = Version()
    _v3 = Version()
    _le1 = _v1.__le__(_v2)
    _le2 = _v2.__le__(_v1)
    _le3 = _v1.__le__(_v3)
    _le4 = _v3.__le__(_v1)
    return
test_Version___le__()

# Generated at 2022-06-20 16:43:21.961125
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion()
    l.parse('1.2.3a')
    assert l.version == [1, 2, 3, 'a']



# Generated at 2022-06-20 16:44:40.678511
# Unit test for constructor of class Version
def test_Version():
    from distutils.tests import run_unittest
    from distutils.tests import support
    from distutils.version import Version
    from test.support import run_unittest

    class TestCase(support.TempdirManager,
                   support.LoggingSilencer,
                   run_unittest.TestCase):
        pass

    class VersionTestCase(TestCase):
        def test_no_args(self):
            v = Version()

        def test_args(self):
            v = Version("1.2.3")
            self.assertEqual(str(v), "1.2.3")
            v = Version("1.2.0")
            self.assertEqual(str(v), "1.2")

    run_unittest(VersionTestCase)

# Here's a typical line from a .pypirc

# Generated at 2022-06-20 16:44:42.397352
# Unit test for constructor of class Version
def test_Version():
    pass


# Generated at 2022-06-20 16:44:48.994924
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Note: must keep in sync with actual implementation.
    cases = [
        ('1.2', ('1', '2', '0')),
        ('1.2.3a4', ('1', '2', '3')),
    ]

    for vstring, expected in cases:
        version = StrictVersion()
        version.parse(vstring)
        assert version.version == tuple(expected)
        assert str(version) == vstring


# Generated at 2022-06-20 16:45:00.184673
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def test(str_version, parsed_version):
        """Internal function that takes a version string and a parsed tuple
        and compares them after reconstructing the string from the tuple."""

        lv = LooseVersion(str_version)
        assert lv.version == parsed_version, "%s != %s" % (lv.version, parsed_version)
        assert str(lv) == str_version, "%s != %s" % (str(lv), str_version)

    test('1.2.0', (1, 2, 0))
    test('1.2', (1, 2))
    test('1.2a1', (1, 2, 'a', 1))
    test('1.2.3.4', (1, 2, 3, 4))

# Generated at 2022-06-20 16:45:10.738993
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vs in ['0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3',
               '0.5', '0.9.6', '1.0', '1.0.4a3', '1.0.4b1',
               '1.0.4']:
        v = StrictVersion(vs)
        assert v.version == eval(vs.replace('a', '.').replace('b', '.'))
        assert str(v) == vs

    assert StrictVersion('1.0') < StrictVersion('1.0.1')
    assert StrictVersion('1.1') > StrictVersion('1.0.4')
    assert StrictVersion('1.0.4') < StrictVersion('1.0.4a1')


# Generated at 2022-06-20 16:45:12.552208
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    sv = StrictVersion('35.180.2')
    assert str(sv) == '35.180.2'

# Generated at 2022-06-20 16:45:18.721863
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # do the same tests as the StrictVersion class:
    v = StrictVersion

# Generated at 2022-06-20 16:45:22.383599
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    for cls in [StrictVersion, LooseVersion]:
        v = cls('1.2.3')
        assert v == '1.2.3'
        assert v == cls('1.2.3')

# Generated at 2022-06-20 16:45:23.804096
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__(Version())
    assert not Version().__ge__(Version())



# Generated at 2022-06-20 16:45:32.622379
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Tests for major, minor, patch, prerelease and prerelease_num output
    match = StrictVersion.version_re.match("1.0.1a1")
    assert match.group(1) == "1" and match.group(2) == "0" and match.group(4) == "1" and match.group(5) == "a1" and match.group(6) == "1"
    match = StrictVersion.version_re.match("4.0")
    assert match.group(1) == "4" and match.group(2) == "0" and match.group(4) is None and match.group(5) is None and match.group(6) is None
    match = StrictVersion.version_re.match("1.0.0a0")