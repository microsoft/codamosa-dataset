

# Generated at 2022-06-20 16:36:14.309101
# Unit test for constructor of class Version
def test_Version():
    v = Version("1.3")
    assert repr(v) == "Version ('1.3')"


# Generated at 2022-06-20 16:36:22.236237
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version("2.0")
    assert v > "1.1", "1.1 is not greater than 2.0"
    assert v > Version("1.1"), "1.1 is not greater than 2.0"
    assert not v > "2.0", "2.0 is not greater than 2.0"
    assert not v > Version("2.0"), "2.0 is not greater than 2.0"
    assert not v > "2.1", "2.1 is not greater than 2.0"
    assert not v > Version("2.1"), "2.1 is not greater than 2.0"


# Generated at 2022-06-20 16:36:30.784751
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion
    lv('1')
    lv('1.2')
    lv('1.2.3')
    lv('1.2.3.4')
    lv('1.2a1')
    lv('1.2b3')
    lv('1.2c1')
    lv('1.2.3a1')
    lv('1.2.3b3')
    lv('1.2.3.4a1')
    lv('1.2.3.4b3')
    lv('1.2pl3')
    lv('1.2.3pl3')
    lv('1.2.3.4pl3')


# A couple of useful functions

# Generated at 2022-06-20 16:36:31.702913
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion("234")
    print(v)
    
test_LooseVersion___str__()


# Generated at 2022-06-20 16:36:33.988790
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    version = LooseVersion('1.1.2')
    assert(version.version == [1, 1, 2])

    version = LooseVersion(version)
    assert(version.version == [1, 1, 2])
    try:
        version = LooseVersion(2.0)
    except TypeError as e:
        assert(str(e) == "'module' object is not callable")


# end class LooseVersion

# Generated at 2022-06-20 16:36:39.712484
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion("1.234")
    assert v.version == [1, 234]
    v = LooseVersion("1.2.34")
    assert v.version == [1, 2, 34]

    # Check that strings and numbers are correctly identified
    v = LooseVersion('abc.def.ghi.jkl')
    assert v.version == ['abc', 'def', 'ghi', 'jkl']
    v = LooseVersion("1.2a.3b.4.rc1")
    assert v.version == [1, 2, 'a', 3, 'b', 4, 'rc', 1]
    v = LooseVersion("1")
    assert v.version == [1]
    v = LooseVersion("1.234.456a")

# Generated at 2022-06-20 16:36:42.602612
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion("01.03.03.07")
    assert lv.version == [1, '03', '03', '07'], lv.version
# end test


# Generated at 2022-06-20 16:36:45.967763
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    stver = StrictVersion("1.1.1b1")
    if stver.version != (1,1,1):
        return False
    if stver.prerelease != ('b', 1):
        return False
    return True

# Generated at 2022-06-20 16:36:54.203231
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    from distutils.version import Version

    class TestCase(unittest.TestCase):
        def test__lt__(self):
            v = Version('1.2.0a1')
            self.assertTrue(v < '1.2.0')
            self.assertFalse(v < '1.2.0a1')
            self.assertFalse(v < '1.2.0a0')
            self.assertTrue(v < '1.2.0a2')
            self.assertTrue(v < '1.2.0b1')
            self.assertTrue(v < '1.2.1')

    unittest.main()



# Generated at 2022-06-20 16:36:56.074441
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import doctest
    doctest.run_docstring_examples(StrictVersion.parse, globals())



# Generated at 2022-06-20 16:37:21.769733
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    clv = LooseVersion('1.1.1')
    assert repr(clv) == "LooseVersion ('1.1.1')"

# Generated at 2022-06-20 16:37:28.032768
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from tests.lib.distutils import Version

    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    v3 = Version('1.2.4')
    v4 = Version('1.2.5')

    assert v1 < v2
    assert v2 < v4
    assert not v2 < v3
    assert not v2 < v2
    assert not v3 < v2




# Generated at 2022-06-20 16:37:34.465785
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils2.version import Version
    from distutils2.tests import unittest, support
    import doctest
    doctest.testmod(support.distutils_version, verbose=False)
    # doctest: +ELLIPSIS
    # doctest: +NORMALIZE_WHITESPACE
    # doctest: +IGNORE_EXCEPTION_DETAIL
    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite(support.distutils_version))
    return suite
test_Version___eq__.__test__ = False # to be able to run it outside of test suite

# Generated at 2022-06-20 16:37:45.949691
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion('0.4.0')
    assert str(v) == '0.4.0'
    v = StrictVersion('0.4')
    assert str(v) == '0.4'
    v = StrictVersion('0.4a1')
    assert str(v) == '0.4a1'
    v = StrictVersion('0.4.1')
    assert str(v) == '0.4.1'
    v = StrictVersion('0.5a1')
    assert str(v) == '0.5a1'
    v = StrictVersion('0.5b3')
    assert str(v) == '0.5b3'
    v = StrictVersion('0.5')
    assert str(v) == '0.5'
    v = St

# Generated at 2022-06-20 16:37:49.686737
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    v1.parse("5.5")
    v2.parse("5.5")
    return v1.__ge__(v2)


# Generated at 2022-06-20 16:37:56.271807
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Setup
    version_obj_0 = Version('0.5.5')
    version_obj_1 = Version('')
    version_obj_2 = Version('0.5.5')
    version_obj_3 = Version('0.5.5')

    # Test
    assert (version_obj_1 < version_obj_3) == False

    # Test
    assert (version_obj_0 < version_obj_1) == False

    # Test
    assert (version_obj_3 < version_obj_0) == False

    # Test
    assert (version_obj_2 < version_obj_3) == False


# Generated at 2022-06-20 16:38:03.081932
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    for cls in [StrictVersion]:
        for my_ver, other_ver, expected in (
            ("0.4.0",   "0.4",  True),
            ("1.0.4.0", "1.0.4", True),
            ("1.1",     "1.2",  False),
            ("1.2",     "2.0",  False),
            ("1.1",     "1.1.1", False),
            ("1.0.4.0", "1.0.4.1", False),
        ):
            my = cls(my_ver)
            other = cls(other_ver)
            if my > other != expected:
                return 0
    else:
        return 1

# Generated at 2022-06-20 16:38:13.587636
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    import unittest

    class TestCase(unittest.TestCase):
        versions = [("1.5.1", (1, 5, 1), None),
                    ("1.5.2b2", (1, 5, 2), ('b', 2)),
                    ("161", (161,), None),
                    ("3.10a", (3, 10), ('a', 0)),
                    ("8.02", (8, 2), None),
                    ("3.4j", (3, 4), ('j', 0))]

        def setUp(self):
            pass

        def test_cmp(self):
            v = StrictVersion("1.5.1")
            self.assertEqual(v, StrictVersion("1.5.1"))

# Generated at 2022-06-20 16:38:20.519747
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    s = StrictVersion("1.0")
    assert(s.version == (1, 0, 0))
    assert(str(s) == "1.0")

    s = StrictVersion("1.0.0")
    assert(s.version == (1, 0, 0))
    assert(str(s) == "1.0.0")

    s = StrictVersion("1.0a1")
    assert(s.version == (1, 0, 0))
    assert(s.prerelease == ('a', 1))
    assert(str(s) == "1.0a1")

    s = StrictVersion("1.0b3")
    assert(s.version == (1, 0, 0))
    assert(s.prerelease == ('b', 3))

# Generated at 2022-06-20 16:38:22.252264
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(Version()) == NotImplemented


# Generated at 2022-06-20 16:38:38.348982
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    def test(class_, value, expected):
        with pytest.raises(TypeError):
            class_(1).__str__()

        s = class_(value)
        assert str(s) == expected
        assert type(str(s)) is str

    test(StrictVersion, '1.2.3a1', '1.2.3a1')
    test(StrictVersion, '1.2.3b2', '1.2.3b2')
    test(StrictVersion, '1.2.3', '1.2.3')
    test(StrictVersion, '1.2', '1.2')
    test(StrictVersion, '1', '1')



# Generated at 2022-06-20 16:38:39.911282
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-20 16:38:50.298490
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("0.4").__str__() == "0.4"
    assert StrictVersion("0.4.0").__str__() == "0.4.0"
    assert StrictVersion("0.4.1").__str__() == "0.4.1"
    assert StrictVersion("0.5a1").__str__() == "0.5a1"
    assert StrictVersion("0.5b3").__str__() == "0.5b3"
    assert StrictVersion("0.9.6").__str__() == "0.9.6"
    assert StrictVersion("1.0").__str__() == "1.0"
    assert StrictVersion("1.0.4a3").__str__() == "1.0.4a3"
    assert St

# Generated at 2022-06-20 16:38:52.500164
# Unit test for constructor of class Version
def test_Version():
    x = Version('1.1a')
    assert x.__repr__() == "Version ('1.1a')"


# Generated at 2022-06-20 16:38:55.211477
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    with pytest.raises(TypeError):
        LooseVersion().__repr__()


# Generated at 2022-06-20 16:38:56.453256
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    version = Version()
    version.__repr__()


# Generated at 2022-06-20 16:39:03.938706
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import unittest
    import sys
    import re

    class VersionTestCase(unittest.TestCase):
        def __init__(self, versionString, expectedResult=None, expectedException=None):
            unittest.TestCase.__init__(self)
            self.versionString = versionString
            self.expectedResult = expectedResult
            self.expectedException = expectedException

        def shortDescription(self):
            return self.versionString

        def runTest(self):
            if self.expectedException is not None:
                self.assertRaises(self.expectedException, self.doTest)
            else:
                self.doTest()

        def doTest(self):
            #print('test: ', self.versionString)
            parsed_version = StrictVersion(self.versionString)

# Generated at 2022-06-20 16:39:15.408890
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version = StrictVersion('0.4')
    assert str(strict_version) == '0.4'
    strict_version = StrictVersion('0.4.0')
    assert str(strict_version) == '0.4.0'
    strict_version = StrictVersion('0.4.1')
    assert str(strict_version) == '0.4.1'
    strict_version = StrictVersion('0.5a1')
    assert str(strict_version) == '0.5a1'
    strict_version = StrictVersion('0.5b3')
    assert str(strict_version) == '0.5b3'
    strict_version = StrictVersion('0.5')
    assert str(strict_version) == '0.5'
    strict_

# Generated at 2022-06-20 16:39:22.540725
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('214.6')
    assert str(v) == '214.6'

    v = StrictVersion('214.6.0')
    assert str(v) == '214.6.0'

    v = StrictVersion('214.6.0a1')
    assert str(v) == '214.6.0a1'

    v = StrictVersion('214.6.0b2')
    assert str(v) == '214.6.0b2'


# Generated at 2022-06-20 16:39:25.668873
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    version._cmp = MagicMock(return_value=NotImplemented)
    version.__le__('foo')
    version._cmp.assert_called_once_with('foo')



# Generated at 2022-06-20 16:39:40.018171
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version("0.0.0")
    assert v == "0.0.0"

# Generated at 2022-06-20 16:39:42.553612
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('None')"
    assert repr(Version("1")) == "Version ('1')"


# Generated at 2022-06-20 16:39:43.828418
# Unit test for method __eq__ of class Version
def test_Version___eq__(): assert Version().__eq__(Version()) == True


# Generated at 2022-06-20 16:39:51.572313
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest
    from distutils.version import StrictVersion, _LooseVersion
    from distutils.version import parse, StringType
    from distutils.version import _suggests_version_2, _suggests_version_3

    class VersionTestCase(unittest.TestCase):

        def assertGreater(self, a, b):
            self.assertTrue(a > b)

        def assertLess(self, a, b):
            self.assertTrue(a < b)

        def test_argument_validation(self):
            self.assertRaises(TypeError, StrictVersion)
            self.assertRaises(TypeError, StrictVersion, 1)
            self.assertRaises(TypeError, StrictVersion, 1, 2, 3)

# Generated at 2022-06-20 16:40:00.723113
# Unit test for method __le__ of class Version
def test_Version___le__():
  assert Version('1') <= 1, 'fail!'
  assert Version.parse('1') <= 1, 'fail!'
  assert not(Version('1') <= 0), 'fail!'
  assert not(Version.parse('1') <= 0), 'fail!'
  assert Version('1.0') <= 1, 'fail!'
  assert Version.parse('1.0') <= 1, 'fail!'
  assert Version('1.1') <= 1, 'fail!'
  assert Version.parse('1.1') <= 1, 'fail!'
  assert not(Version('1.1') <= 0), 'fail!'
  assert not(Version.parse('1.1') <= 0), 'fail!'
  assert Version('1.0.0') <= 1, 'fail!'
  assert Version.parse('1.0.0') <= 1, 'fail!'
  assert Version

# Generated at 2022-06-20 16:40:03.136285
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2')
    v2 = Version('1.2')
    assert (v1 < v2) is False
    return



# Generated at 2022-06-20 16:40:09.416318
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    import random
    import string
    import unittest
    random = random.Random()

    version = LooseVersion()
    version.vstring = random.choice(string.ascii_uppercase)
    version.__repr__()
    try:
        version.__repr__(foo=1)
        raise AssertionError("didn't raise exception on unknown keyword arg")
    except TypeError:
        pass

if __name__ == "__main__":
    from test import test_version
    test_version.test_main()

# Generated at 2022-06-20 16:40:12.218817
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert(Version('1.0') > Version('1.0.dev456'))

# Generated at 2022-06-20 16:40:23.811233
# Unit test for method __le__ of class Version
def test_Version___le__():
    import pytest
    from distutils.version import Version
    from io import StringIO
    from unittest import mock

    class TestStrictVersion(Version):

        def parse(self, vstring):
            self.vstring = vstring

        def _cmp(self, other):
            return 0

    # Verify that __le__ returns true when _cmp returns 0
    o1 = TestStrictVersion('1.0')
    o2 = TestStrictVersion('1.0')
    assert o1 <= o2

    # Verify that __le__ returns true when _cmp returns < 0
    o1._cmp = mock.Mock(return_value=-1)
    assert o1 <= o2

    # Verify that __le__ returns false when _cmp returns > 0
    o1._cmp = mock.Mock(return_value=1)


# Generated at 2022-06-20 16:40:31.796325
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-20 16:40:52.612169
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version("1.2.3").__eq__("1.2.3")

# Generated at 2022-06-20 16:40:55.832712
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = StrictVersion('1.0.4b1')
    expected = '1.0.4b1'
    actual = str(version)
    assert actual == expected


# Generated at 2022-06-20 16:41:03.339825
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.0')
    assert v < '1.1', "'1.0' < '1.1'"
    assert not v < '1.0', "'1.0' not < '1.0'"
    assert not v < '0.9', "'1.0' not < '0.9'"
    assert Version('1.0') < Version('1.1'), "Version('1.0') < Version('1.1')"
    assert not Version('1.0') < Version('1.0'), "not Version('1.0') < Version('1.0')"
    assert not Version('1.0') < Version('0.9'), "not Version('1.0') < Version('0.9')"



# Generated at 2022-06-20 16:41:11.382935
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert str(StrictVersion('1.3.3.7')) == '1.3.3.7'
    assert str(StrictVersion('1.3a4')) == '1.3a4'
    a = StrictVersion('1.3.3.7')
    b = StrictVersion('1.3.3.7')
    assert a._cmp(b) == 0
    c = StrictVersion('1.3.3.7')
    d = StrictVersion('1.3.3.7')
    assert a == d
    assert not a != d
    assert not a == 'foo'
    assert a != 'foo'
    assert not a < 'foo'
    assert not a <= 'foo'
    assert a > 'foo'
    assert a >= 'foo'

# Generated at 2022-06-20 16:41:15.936693
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # check case-insensitivity
    lv = LooseVersion("a2.2c1")

# Generated at 2022-06-20 16:41:20.717895
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion("3.1.1.6")
    expected = "LooseVersion ('3.1.1.6')"
    assert lv.__repr__() == expected


# Generated at 2022-06-20 16:41:28.901780
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """ parse(vstring: str) -> LooseVersion
    Parse a version string to create a LooseVersion instance.
    """
    #vstring, expected_version

# Generated at 2022-06-20 16:41:29.771522
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    return None


# Generated at 2022-06-20 16:41:38.268459
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert (v < '1.2.4'), "Version('1.2.3') should be < '1.2.4'"
    assert (v < '1.2.3.1'), "Version('1.2.3') should be < '1.2.3.1'"
    assert not (v < '1.2'), "Version('1.2.3') should not be < '1.2'"
    assert not (v < '1.2.3'), "Version('1.2.3') should not be < '1.2.3'"

# Generated at 2022-06-20 16:41:40.787552
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    ver = Version('1.0')
    assert repr(ver) == "Version ('1.0')"



# Generated at 2022-06-20 16:42:05.677073
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    class MockVersion(StrictVersion):
        def parse(self):
            super(MockVersion, self).parse(self._vstring)
    try:
        MockVersion('1.2.3')
    except ValueError:
        pass
    else:
        raise AssertionError('StrictVersion failed to raise ValueError')
    # Test strict version regex
    s = '1.2.30'
    MockVersion(s).parse()
    assert str(MockVersion(s)) == s, 'Strict version \'%s\' is not strict' % s
    s = '1.2.3a4'
    MockVersion(s).parse()
    assert str(MockVersion(s)) == s, 'Strict version \'%s\' is not strict' % s
    s = '1.2.9b5'
    Mock

# Generated at 2022-06-20 16:42:12.286762
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  obj = Version()
  values = [None, NotImplemented, 0, 0]
  for value in values:
    try:
      d = {'value': value}
      result = obj.__eq__(d['value'])
      assert False, "obj.__eq__({}) did not raise ValueError".format(repr(value))
    except ValueError:
      pass

# Generated at 2022-06-20 16:42:15.832712
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """Unit test for method __repr__ of class LooseVersion"""
    lv = LooseVersion('1.2.2')
    assert lv.__repr__() == 'LooseVersion (\'1.2.2\')'


# Generated at 2022-06-20 16:42:17.120068
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-20 16:42:21.840985
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v2.__gt__(v1)


# Generated at 2022-06-20 16:42:27.507589
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import distutils.version

    version = distutils.version.StrictVersion('1.0.0')
    assert str(version) == '1.0.0'
    version = distutils.version.StrictVersion('2.0.3')
    assert str(version) == '2.0.3'
    version = distutils.version.StrictVersion('3.0.0a1')
    assert str(version) == '3.0.0a1'



# Generated at 2022-06-20 16:42:34.979543
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
  from distutils.version import StrictVersion
  v1 = StrictVersion("1")
  v2 = StrictVersion("1.2")
  v3 = StrictVersion("1.2.3")
  v4 = StrictVersion("1.2.3.a1")
  v5 = StrictVersion("1.2.3.b2")
  assert(str(v1) == "1")
  assert(str(v2) == "1.2")
  assert(str(v3) == "1.2.3")
  assert(str(v4) == "1.2.3a1")
  assert(str(v5) == "1.2.3b2")
test_StrictVersion___str__()


# Generated at 2022-06-20 16:42:46.098337
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    cases = [('1.2',         ((1,2,0), None)),
             ('1.2.3',       ((1,2,3), None)),
             ('1.2.0',       ((1,2,0), None)),
             ('1.2.0a1',     ((1,2,0), ('a',1))),
             ('1.2.0b3',     ((1,2,0), ('b',3))),
             ('1.2.0rc2',    ((1,2,0), ('rc',2))),
             ('1.2.0.post1', ((1,2,0), ('post',1))),
             ('1.2.0.dev5',  ((1,2,0), ('dev',5)))
             ]


# Generated at 2022-06-20 16:42:47.246258
# Unit test for constructor of class Version
def test_Version():
    for v in ["1.3.4-4"]:
        Version(v)


# Generated at 2022-06-20 16:42:50.674704
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2
    assert not v1 > v2


# Generated at 2022-06-20 16:43:21.761152
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    inst = LooseVersion("expected")
    assert str(inst) == "expected"

# Generated at 2022-06-20 16:43:24.677950
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version("1.2.3a0")
    assert repr(v) == "Version ('1.2.3a0')"

# Generated at 2022-06-20 16:43:26.009529
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v



# Generated at 2022-06-20 16:43:31.158393
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils2.version import Version
    v1 = Version("1.0")
    v2 = Version("2.0")
    assert (v1 <= v2)

# Generated at 2022-06-20 16:43:34.589819
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.2.3")
    assert v.__str__() == "1.2.3"


# Generated at 2022-06-20 16:43:36.921915
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    '''Ensure __lt__ returns the correct result'''
    version1 = Version()
    version2 = Version()
    assert version1._cmp(version2) == 0

# Generated at 2022-06-20 16:43:48.485303
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion("1.1.1")
    print("Version = ", l._cmp("1.1.1"))
    print("Version = ", l._cmp("1.1.2"))
    print("Version = ", l._cmp("1.1.0"))
    print("Version = ", l._cmp("1.1"))
    print("Version = ", l._cmp("1.2"))
    print("Version = ", l._cmp("1.0.0"))
    print("Version = ", l._cmp("2.0"))


if __name__ == '__main__':
    test_LooseVersion_parse()

# Generated at 2022-06-20 16:43:56.547635
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    for vstring, errmsg in _LooseTestData:
        try:
            vtuple = LooseVersion(vstring)
        except ValueError:
            raise AssertionError("%s should not raise ValueError" % vstring)
        if str(vtuple) != vstring:
            raise AssertionError(errmsg % (vstring, str(vtuple)))


# Generated at 2022-06-20 16:44:00.015564
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    cls = LooseVersion
    c = lambda x: cls(x)
    assert c("1").__repr__() == "LooseVersion ('1')", \
           "LooseVersion('1') 'LooseVersion ('1')' expected."
test_LooseVersion___repr__()


# Generated at 2022-06-20 16:44:11.842189
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import unittest
    class Test(unittest.TestCase):
        def test_1(self):
            v = LooseVersion("1.2.3")
            self.assertEqual(v.__str__(), "1.2.3")
        def test_2(self):
            v = LooseVersion("1.2.3-alpha")
            self.assertEqual(v.__str__(), "1.2.3-alpha")
        def test_3(self):
            v = LooseVersion("1.3")
            self.assertEqual(v.__str__(), "1.3")
    unittest.main(exit=False, verbosity=1)
if __name__=="__main__":
    test_LooseVersion___str__()


# Generated at 2022-06-20 16:45:38.992613
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-20 16:45:43.222226
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('some.string')
    assert(repr(lv) == 'LooseVersion (\'some.string\')')


# Generated at 2022-06-20 16:45:54.044853
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    class Foo(object):
        def __eq__(self, other):
            return self is other
    class Bar(object):
        def __eq__(self, other):
            return self is not other
    @unittest.skipUnless(Foo() == Foo(), "self.__eq__(other) always returns self == other")
    class Version_Test___eq__(unittest.TestCase):
        def test_eq(self):
            v = Version()
            s = StrictVersion("1.0")
            self.assertTrue(v == v)
            self.assertFalse(v == s)
            self.assertFalse(s == v)
            self.assertFalse(v == "1.0")
           

# Generated at 2022-06-20 16:45:55.933930
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version("1.0") < Version("2.0")

# Generated at 2022-06-20 16:46:04.597463
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Test that two versions are correctly compared to each other.
    v2 = LooseVersion('2.1')
    v2_1 = LooseVersion('2.1')
    v2_2 = LooseVersion('2.2')
    v3 = LooseVersion('3.1')

    assert not v2 > v2_1
    assert not v2 > v2_2
    assert not v2 > v3

    assert not v2_1 > v2_1
    assert not v2_1 > v2_2
    assert not v2_1 > v3

    assert v2_2 > v2_1
    assert not v2_2 > v2_2
    assert not v2_2 > v3

    assert v3 > v2_1
    assert v3 > v2_2
    assert not v3