

# Generated at 2022-06-20 16:36:16.043541
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    from distutils.tests import support
    s = StrictVersion

    assert s('1.0').__str__() == '1.0'
    assert s('1.0.0').__str__() == '1.0'
    assert s('1.0a1').__str__() == '1.0a1'
    assert s('1.0.1a2').__str__() == '1.0.1a2'
    assert s('1.0.1b2').__str__() == '1.0.1b2'



# Generated at 2022-06-20 16:36:20.833045
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    version = Version()
    test_output = version.__repr__()
    assert (test_output == "Version ('None')")
    version = Version("2.4.9a")
    test_output = version.__repr__()
    assert (test_output == "Version ('2.4.9a')")


# Generated at 2022-06-20 16:36:22.418460
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert repr(LooseVersion("1.2")) == "LooseVersion ('1.2')"
    

# Generated at 2022-06-20 16:36:31.097422
# Unit test for constructor of class LooseVersion
def test_LooseVersion():

    lv1 = LooseVersion('1.2.3')      # list of ints
    lv2 = LooseVersion('1.2.3')
    lv3 = LooseVersion('1.2.4')
    lv4 = LooseVersion('1.2.3.4')    # list of strings
    lv5 = LooseVersion('1.2.3.4.5')
    lv6 = LooseVersion('1.2.3-4')    # string representation
    lv7 = LooseVersion('1.2.3-4.5')
    lv8 = LooseVersion('1.2.3-4.5.6')
    lv9 = LooseVersion('1.2.3-a0')   # alphabetic number

# Generated at 2022-06-20 16:36:37.551555
# Unit test for method __str__ of class LooseVersion

# Generated at 2022-06-20 16:36:39.027173
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert ( Version('1.0') >= Version('1.0') )

# Generated at 2022-06-20 16:36:41.624778
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    s = 'stuff'
    r = v._cmp(s)
    assert(r == NotImplemented)
    assert(v >= s == False)


# Generated at 2022-06-20 16:36:43.426000
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented


# Generated at 2022-06-20 16:36:54.629881
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion
    lvc = LooseVersion.__cmp__
    lv0 = lv('')
    assert_equal(str(lv0), '')
    assert_equal(lv0.version, [])
    assert_equal(lvc(lv0, ''), 0)
    assert_equal(lvc(lv0, '1'), -1)
    assert_equal(lvc('1', lv0), 1)
    lv1 = lv('1')
    assert_equal(lv1.version, [1])
    assert_equal(lvc(lv0, lv1), -1)
    lv2 = lv('1.2')
    assert_equal(lv2.version, [1, 2])
    assert_equal(lvc(lv1, lv2), -1)

# Generated at 2022-06-20 16:36:55.844852
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    version1 = Version()
    assert version1.__repr__() == "Version ('0')"



# Generated at 2022-06-20 16:37:09.354109
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  inst = Version()
  other = Version()
  c = inst._cmp(other)
  assert c is NotImplemented
  assert c == 0


# Generated at 2022-06-20 16:37:15.421488
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import os, sys
    from PopTest.tutils import *
    from distutils.version import StrictVersion


# Generated at 2022-06-20 16:37:19.195595
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.0')
    assert v.vstring == '1.0'
    v = LooseVersion('1.2a2')
    assert v.vstring == '1.2a2'


# Generated at 2022-06-20 16:37:21.861800
# Unit test for constructor of class Version
def test_Version():
    try:
        Version('')
    except ValueError:
        pass
    else:
        assert False, "empty string should have raised ValueError"


# Generated at 2022-06-20 16:37:24.799018
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version1 = Version('1.0.0')
    version2 = Version('2.0.0')
    assert (version1 > version2) is False

# Generated at 2022-06-20 16:37:30.053465
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version(None)
    assert repr(v) == "Version ('0')"
    assert repr(Version("1.2.3")) == "Version ('1.2.3')"


VERSION_PAT = re.compile(r'^(\d+) \. (\d+) (\. (\d+))? ([ab](\d+))?$',
        RE_FLAGS)


# Generated at 2022-06-20 16:37:34.071194
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v1 = LooseVersion("9.9.9")
    v2 = eval(repr(v1))
    assert v1 == v2


# Generated at 2022-06-20 16:37:45.588580
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert (str(eval(repr(LooseVersion()))) == '')
    assert (str(eval(repr(LooseVersion('1')))) == '1')
    assert (str(eval(repr(LooseVersion('10000b1')))) == '10000b1')
    assert (str(eval(repr(LooseVersion('1+')))) == '1+')
    assert (str(eval(repr(LooseVersion('1.2.3f')))) == '1.2.3f')
    assert (str(eval(repr(LooseVersion('1.2.3a.4')))) == '1.2.3a.4')
    assert (str(eval(repr(LooseVersion('1.2.3a.4+')))) == '1.2.3a.4+')

# Generated at 2022-06-20 16:37:55.347337
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    fail = 0
    try:
        LooseVersion("")
    except ValueError:
        pass
    else:
        fail = 1
    try:
        LooseVersion("1.2.3.4")
    except ValueError:
        pass
    else:
        fail = 1
    try:
        LooseVersion("1.2.3.4a")
    except ValueError:
        pass
    else:
        fail = 1
    try:
        LooseVersion("a.b.c.d")
    except ValueError:
        pass
    else:
        fail = 1
    try:
        LooseVersion("a-b_c+d")
    except ValueError:
        pass
    else:
        fail = 1

# Generated at 2022-06-20 16:37:57.687306
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__('0')



# Generated at 2022-06-20 16:38:18.722286
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import re, sys
    class Dummy:
        def _cmp(self, other):
            return 0
    for v in ['1.5.1', '1.5.2b2', '161', '3.10a', '8.02', '3.4j',
              '1996.07.12', '3.2.pl0', '3.1.1.6', '2g6', '11g',
              '0.960923', '2.2beta29', '1.13++', '5.5.kw']:
        sys.stdout.write("%15s" % v)

# Generated at 2022-06-20 16:38:20.850017
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('1.0b1pl0')
    assert repr(lv) == "LooseVersion ('1.0b1pl0')"


# Generated at 2022-06-20 16:38:22.402174
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    f = Version(vstring="1.2.3")
    g = Version(vstring="1.2.3")
    assert f == g


# Generated at 2022-06-20 16:38:23.606492
# Unit test for method __gt__ of class Version
def test_Version___gt__(): assert True

# Generated at 2022-06-20 16:38:27.375963
# Unit test for constructor of class Version
def test_Version():
    import sys
    import os
    x = Version()
    x = Version('2.2.3')
    if os.path.splitext(sys.argv[0])[1] in ['.py', '.pyc', '.pyo', '.pyd']:
        x = Version()
        x = Version('2.2.3')



# Generated at 2022-06-20 16:38:33.550419
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """
    It returns a negative value for a less than comparison.
    """
    # From the setup
    v1 = Version("1.0")
    # From the setup
    v2 = Version("2.0")
    # Call the method under test
    assert v1.__lt__(v2) == True


# Generated at 2022-06-20 16:38:34.978604
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert v1.__ge__(v2)

# Generated at 2022-06-20 16:38:42.457733
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1")
    v2 = Version("2")
    if not (v1 < v2):
        return False
    if not (v2 > v1):
        return False
    if not (v1 <= v2):
        return False
    if not (v2 >= v1):
        return False
    if v1 == v2:
        return False
    return True

# Generated at 2022-06-20 16:38:48.472613
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('abc')
    assert v > ''
    assert type(v) is not str
    assert type(v) is Version
    assert v.__class__.__name__ == 'Version'

# End of unit test for method __gt__ of class Version


# Generated at 2022-06-20 16:38:59.553633
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for num in [ "0.4.0",
                 "0.4",
                 "0.4.1",
                 "0.5a1",
                 "0.5b3",
                 "0.5",
                 "0.9.6",
                 "1.0",
                 "1.0.4a3",
                 "1.0.4b1",
                 "1.0.4",
                 '1.0.4-simply-testing',
                 '1.0.4-alpha',
                 '1.0.4-alpha.1',
                 '1.0.4-0.3.7',
                 '1.0.4-x.7.z.92',
                 ]:
        try:
            StrictVersion(num)
        except ValueError:
            raise AssertionError

# Generated at 2022-06-20 16:39:30.946413
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version("1.2.3a4.post3.dev3+abcdef")
    assert Version("1.2.3a4") > Version("1.2.3a4.post3.dev3+abcdef"), "Compare Version with a lower version"
    assert v > Version("1.2.3a4.post3.dev3+abcdee"), "Compare Version with a higher version"
    assert v > Version("1.2.3a4.post2.dev3.post2.dev3"), "Compare Version with a higher version"
    assert v > Version("1.2.3a4.post2.dev3.post2.dev3.post2.dev3"), "Compare Version with a higher version"

# Generated at 2022-06-20 16:39:33.968196
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('1.0')) == '1.0', \
        "__str__ does not produce the same string used to create the object"



# Generated at 2022-06-20 16:39:36.852383
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """-> str(LooseVersion())"""
    lv = LooseVersion("1.2")
    assert str(lv) == "1.2"
    # __str__ didn't put back the correct string


# Generated at 2022-06-20 16:39:46.634499
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # If the constructor is not specified, returns a version of None

    assert LooseVersion().version is None
    assert str(LooseVersion()) == "None"

    # Raise TypeError if the constructor is not a string
    raises(TypeError, LooseVersion, 1)
    # Raises a ValueError if the string provided is not a valid version
    raises(ValueError, LooseVersion, "hello there")
    # Otherwise, return a LooseVersion object
    assert isinstance(LooseVersion("1.5.1"), LooseVersion)
    assert isinstance(LooseVersion("1.5.1.1"), LooseVersion)
    assert isinstance(LooseVersion("2.2beta29"), LooseVersion)
    assert isinstance(LooseVersion("1.13++"), LooseVersion)

# Generated at 2022-06-20 16:39:47.838039
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"

# Generated at 2022-06-20 16:39:50.022288
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.13++')
    assert str(lv) == '1.13++', 'wrong string produced by __str__'


# Generated at 2022-06-20 16:39:59.734155
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse("0.4.0")
    assert v.version == (0, 4, 0)
    assert v.prerelease == None

    v.parse("0.4")
    assert v.version == (0, 4, 0)
    assert v.prerelease == None

    v.parse("1.4.7b2")
    assert v.version == (1, 4, 7)
    assert v.prerelease == ('b', 2)

    try:
        v.parse("1.3.a2")
        raise AssertionError("did not detect invalid version")
    except ValueError:
        pass

    try:
        v.parse("1.3.2-3")
        raise AssertionError("did not detect invalid version")
    except ValueError:
        pass

   

# Generated at 2022-06-20 16:40:01.985695
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    vv = Version()
    assert(vv >= "" is NotImplemented)


# Generated at 2022-06-20 16:40:10.257217
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from itertools import product
    import operator

    class FakeVersion(Version):
        def __init__(self, vstring=None):
            if vstring:
                self.parse(vstring)

        def parse(self, vstring):
            self.vstring = vstring

        def _cmp(self, other):
            raise NotImplementedError

    def assert_lt(version1, version2, operator_, **kwargs):
        assert operator_.lt(version1, version2, **kwargs)
        if operator_ is operator:
            assert operator_.le(version1, version2)
            assert not operator_.eq(version1, version2)
            assert not operator_.ge(version1, version2)
            assert not operator_.gt(version1, version2)


# Generated at 2022-06-20 16:40:17.043843
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    sv = StrictVersion("1.0.0")
    assert sv.version == (1, 0, 0) and sv.prerelease is None

    sv = StrictVersion("1.0a1")
    assert sv.version == (1, 0, 0) and sv.prerelease == ('a', 1)

    sv = StrictVersion("1.0b3")
    assert sv.version == (1, 0, 0) and sv.prerelease == ('b', 3)

    sv = StrictVersion("1.2.3")
    assert sv.version == (1, 2, 3) and sv.prerelease is None

    sv = StrictVersion("1.2b3")
    assert sv.version == (1, 2, 0) and sv.prerelease == ('b', 3)


# Generated at 2022-06-20 16:40:45.093211
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(1) == NotImplemented


# Generated at 2022-06-20 16:40:48.802195
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('2.0b1.pl0')
    assert str(lv) == '2.0b1.pl0'
    lv = LooseVersion()
    assert str(lv) == None


# Generated at 2022-06-20 16:40:58.372690
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import os
    import tempfile
    with tempfile.TemporaryDirectory(dir=os.getcwd()) as dirname:
        with open(dirname + '/spam.py', 'w') as file:
            file.write('''
if int(1) is True:
    import unit_test
    unit_test.fail()
''')
        with open(dirname + '/ham.py', 'w') as file:
            file.write('''
if int(1) is True:
    import unit_test
    unit_test.fail()
''')
        v = Version('')
        v.parse('1.2')
        v.parse('1.2a3')


# Generated at 2022-06-20 16:41:02.418671
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv1 = LooseVersion('1.5.1')
    lv2 = eval(repr(lv1))
    print(lv2)
    # assert lv1.version == lv2.version
    # assert lv1.vstring == lv2.vstring

if __name__ == '__main__':
    test_LooseVersion___repr__()

# Generated at 2022-06-20 16:41:11.143215
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():

    # Test that invalid strings cause an exception to be raised.
    for bad_string in ("NOT_A_VERSION", "1.2.2.X", "1.2.2.alpha1",
                       "1.2.2.a1", "1.2.2.1a"):
        bad_version = LooseVersion(bad_string)
        try:
            bad_version.parse(bad_string)
        except ValueError:
            pass
        else:
            raise AssertionError("Should have raised ValueError for invalid "
                                 "version %r." % bad_string)

    # Test that _LooseVersion objects can be compared with strings.
    version = LooseVersion("1.2.3")
    assert version == "1.2.3"
    assert version >= "1.2.3"
    assert version

# Generated at 2022-06-20 16:41:12.549864
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest

# Generated at 2022-06-20 16:41:14.459261
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert (v is not None)



# Generated at 2022-06-20 16:41:16.464752
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Version
    v = Version()
    # An instance of type Version
    v1 = Version()
    assert (v < v1) == NotImplemented


# Generated at 2022-06-20 16:41:16.984218
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    pass



# Generated at 2022-06-20 16:41:23.332721
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Unit test for method __le__ of class Version
    # version is an instance of class Version
    version = Version()
    # other is an instance of class Version
    other = Version()
    # replacement for assertEqual statements
    assert isinstance(version.__le__(other), bool)


# Generated at 2022-06-20 16:42:16.777932
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    return None


# Generated at 2022-06-20 16:42:25.622071
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.3a2')
    assert str(v) == '1.3a2'
    v = StrictVersion()
    v.parse('1.3b4')
    assert str(v) == '1.3b4'
    v = StrictVersion()
    v.parse('1.3')
    assert str(v) == '1.3'


# Generated at 2022-06-20 16:42:27.899185
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  v = Version('1.0.0b6')
  assert v < '1.0.0b7', "v < '1.0.0b7'"
  assert v < '1.0.0c1', "v < '1.0.0c1'"


# Generated at 2022-06-20 16:42:34.086623
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('0.4.0')
    assert v.version == (0, 4, 0), "version error"
    assert v.prerelease == None, "prerelease error"
    v = StrictVersion('0.4')
    assert v.version == (0, 4, 0), "version error"
    assert v.prerelease == None, "prerelease error"
    v = StrictVersion('0.4.0b4')
    assert v.version == (0, 4, 0), "version error"
    assert v.prerelease == ('b', 4), "prerelease error"


# Generated at 2022-06-20 16:42:36.577222
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('1.2.3')
    assert (v > '1.2')

# Generated at 2022-06-20 16:42:46.613049
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-20 16:42:50.054307
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v = LooseVersion('2.2b2')
    assert (v.version == [2, 2, 'b', 2])



# Generated at 2022-06-20 16:42:58.369880
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"
    assert LooseVersion('1.2.3.a').__repr__() == "LooseVersion ('1.2.3.a')"
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"

# Generated at 2022-06-20 16:43:08.103117
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Expected failures:
    for v in [ "1.2.1.1", "1.2a1", "1.2c1", "1.2-1", "1.2+1", "1.2.1-2" ]:
        try:
            LooseVersion(v)
        except ValueError:
            pass

# Generated at 2022-06-20 16:43:17.975050
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    sv = StrictVersion()
    try:
        sv.parse('1')
        assert False
    except ValueError:
        assert True
    try:
        sv.parse('2.7.2.2')
        assert False
    except ValueError:
        assert True
    try:
        sv.parse('1.3.a4')
        assert False
    except ValueError:
        assert True
    try:
        sv.parse('1.3pl1')
        assert False
    except ValueError:
        assert True
    try:
        sv.parse('1.3c4')
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-20 16:45:00.309300
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def test(vstring, p_version, p_vstring):
        v = LooseVersion("")
        v._parse = lambda x: None
        v.parse(vstring)
        assert v.version == p_version, \
            "wrong version %r (%r) for %r" % (v.version, p_version, vstring)
        assert v.vstring == p_vstring, \
            "wrong vstring %r (%r) for %r" % (v.vstring, p_vstring, vstring)

    test("0.4", [0, 4], "0.4")
    test("0.4.1", [0, 4, 1], "0.4.1")
    test("0.5a1", [0, 5, "a", 1], "0.5a1")
    test

# Generated at 2022-06-20 16:45:04.672691
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def t(s, want):
        v = LooseVersion(s)
        got = v.version
        if got != want:
            raise AssertionError("LooseVersion(%r).version == %r != %r" % (
                                 s, got, want))
    t("0.3c1", [0, '3c1'])
    t("1.2.3.4", [1, 2, 3, 4])
    t("1.2pl3", [1, '2pl3'])
    t("1.1", [1, 1])
    t("0.960923", [0, '960923'])
    t("1.2beta29", [1, '2beta29'])
    t("2.2.0", [2, 2, 0])

# Generated at 2022-06-20 16:45:11.638107
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = 'dtk-monitor-0.7.2-d5d5490.tar.gz'
    lv2 = 'dtk-monitor-0.7.2-d5d5490-dirty.tar.gz'
    lv3 = 'dtk-monitor-0.7.2-d5d5490'
    print(LooseVersion(lv).version)
    print(LooseVersion(lv).vstring)
    print(LooseVersion(lv2).version)
    print(LooseVersion(lv2).vstring)
    print(LooseVersion(lv3).version)
    print(LooseVersion(lv3).vstring)



if __name__ == '__main__':
    test_LooseVersion_parse()

# Generated at 2022-06-20 16:45:18.152651
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def check(vstring, expected):
        try:
            parsed = StrictVersion(vstring).parse(vstring)
        except ValueError:
            assert expected is None
        else:
            assert parsed == expected

    yield check, "1.0a", ("1.0a", (1, 0), ("a", 1))
    yield check, "2.0", ("2.0", (2, 0), (None, None))
    yield check, "2.0c", ("2.0c", (2, 0), ("c", 1))
    yield check, "2.0c2", ("2.0c2", (2, 0), ("c", 2))

# Generated at 2022-06-20 16:45:26.970265
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    try:
        v = Version()
    except Exception:
        pass
    else:
        raise Exception

    try:
        v = Version(vstring='')
    except Exception:
        pass
    else:
        raise Exception

    try:
        v = Version()
        v._cmp('')
    except Exception:
        pass
    else:
        raise Exception

    try:
        v = Version()
        str(v)
    except Exception:
        pass
    else:
        raise Exception

    try:
        v = Version()
        v == ''
    except Exception:
        pass
    else:
        raise Exception

    try:
        v = Version()
        v < ''
    except Exception:
        pass
    else:
        raise Exception


# Generated at 2022-06-20 16:45:34.432455
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    c = LooseVersion('1.13++')
    r = repr(c)
    assert r == "LooseVersion ('1.13++')"
    c = LooseVersion('1.13')
    r = repr(c)
    assert r == "LooseVersion ('1.13')"
    c = LooseVersion('1.13  gg')
    r = repr(c)
    assert r == "LooseVersion ('1.13  gg')"
    c = LooseVersion('1.13.1')
    r = repr(c)
    assert r == "LooseVersion ('1.13.1')"

# Generated at 2022-06-20 16:45:37.835532
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import pytest
    version1 = Version(vstring='0.9.4')
    version1.parse('1.0')
    version2 = Version(vstring='0.9.4')
    version2.parse('1.0.dev1')
    assert version1 < version2

# Generated at 2022-06-20 16:45:40.809472
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('1.10a4')) == '1.10a4'


# Generated at 2022-06-20 16:45:47.758145
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    version_instances = \
        [LooseVersion(vstring) for vstring in test_LooseVersion_vstrings]
    reconstructed_vstrings = [
        str(instance) for instance in version_instances]
    assert reconstructed_vstrings == test_LooseVersion_vstrings
    return


# Generated at 2022-06-20 16:45:49.060041
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1')
    assert v == Version('1')
