

# Generated at 2022-06-16 23:19:58.379487
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 >= v1
    assert v2 >= v1
    assert not v1 >= v2


# Generated at 2022-06-16 23:20:09.211083
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert v < '1.2.4'
    assert v < '1.2.3.4'
    assert v < '1.2.3.4.5'
    assert v < '1.2.3.4.5.6'
    assert v < '1.2.3.4.5.6.7'
    assert v < '1.2.3.4.5.6.7.8'
    assert v < '1.2.3.4.5.6.7.8.9'
    assert v < '1.2.3.4.5.6.7.8.9.10'
    assert v < '1.2.3.4.5.6.7.8.9.10.11'

# Generated at 2022-06-16 23:20:19.482548
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.2.3')
    assert v <= '1.2.3'
    assert v <= '1.2.4'
    assert not (v <= '1.2.2')
    assert v <= Version('1.2.3')
    assert v <= Version('1.2.4')
    assert not (v <= Version('1.2.2'))
    assert v <= '1.2.3rc1'
    assert v <= '1.2.3.post1'
    assert not (v <= '1.2.3.post2')
    assert v <= '1.2.3.dev1'
    assert v <= '1.2.3.dev2'
    assert not (v <= '1.2.3.dev3')

# Generated at 2022-06-16 23:20:23.139414
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == '1.0'
    assert v == Version('1.0')
    assert not v == '1.1'
    assert not v == Version('1.1')

# Generated at 2022-06-16 23:20:31.868236
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v.parse('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)
    v.parse('1.2.3b5')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 5)
    v.parse('1.2.3.4')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v.parse('1.2.3a4.5')
    assert v.version == (1, 2, 3)

# Generated at 2022-06-16 23:20:40.505345
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2').__str__() == '1.2'
    assert StrictVersion('1.2.3a4').__str__() == '1.2.3a4'
    assert StrictVersion('1.2.3b4').__str__() == '1.2.3b4'
    assert StrictVersion('1.2a4').__str__() == '1.2a4'
    assert StrictVersion('1.2b4').__str__() == '1.2b4'


# Generated at 2022-06-16 23:20:41.809013
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:20:43.076640
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:20:44.320290
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v


# Generated at 2022-06-16 23:20:46.185187
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v)
    assert not v.__eq__(None)


# Generated at 2022-06-16 23:20:57.479914
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(1) == NotImplemented


# Generated at 2022-06-16 23:21:06.515706
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__(Version()) == False
    assert v.__gt__(Version('1')) == False
    assert v.__gt__(Version('2')) == False
    assert v.__gt__(Version('1.0')) == False
    assert v.__gt__(Version('2.0')) == False
    assert v.__gt__(Version('1.0.0')) == False
    assert v.__gt__(Version('2.0.0')) == False
    assert v.__gt__(Version('1.0.0.0')) == False

# Generated at 2022-06-16 23:21:08.546257
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented


# Generated at 2022-06-16 23:21:11.303802
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert not v.__ge__(1)


# Generated at 2022-06-16 23:21:14.020934
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:21:16.248357
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:21:18.910761
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:21:20.397135
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:21:31.128918
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)
    assert not v.__ge__(1)
    assert not v.__ge__("1")
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__

# Generated at 2022-06-16 23:21:43.434913
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not v1 < v2
    assert not v2 < v1
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert not v2 < v1
    v1 = Version('1.2.3')
    v2 = Version('1.3.3')
    assert v1 < v2
    assert not v2 < v1
    v1 = Version('1.2.3')
    v2 = Version('2.2.3')
    assert v1 < v2
    assert not v2 < v1
    v1 = Version('1.2.3')

# Generated at 2022-06-16 23:22:03.037549
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2


# Generated at 2022-06-16 23:22:04.393709
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v


# Generated at 2022-06-16 23:22:06.252659
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:22:10.356979
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.0') == Version('1.0')
    assert not Version('1.0') == Version('1.1')
    assert not Version('1.0') == '1.0'
    assert not Version('1.0') == '1.1'

# Generated at 2022-06-16 23:22:12.134121
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(Version())
    assert v.__ge__(Version("1.0"))
    assert not v.__ge__(Version("2.0"))

# Generated at 2022-06-16 23:22:13.956245
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:22:15.575344
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)


# Generated at 2022-06-16 23:22:16.820256
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:22:18.306970
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:20.148700
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented


# Generated at 2022-06-16 23:22:56.775986
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert not (v1 < v1)
    assert not (v2 < v1)
    assert not (v2 < v2)


# Generated at 2022-06-16 23:22:59.123084
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:23:00.915391
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)

# Generated at 2022-06-16 23:23:03.220311
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert not (v != v)
    assert not (v != Version())

# Generated at 2022-06-16 23:23:05.381521
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented

# Generated at 2022-06-16 23:23:07.475391
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2


# Generated at 2022-06-16 23:23:11.195349
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= '1.0'
    assert v <= Version('1.0')
    assert not v <= '0.9'
    assert not v <= Version('0.9')


# Generated at 2022-06-16 23:23:12.724401
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:23:23.330614
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2
    assert v1 < '2.0'
    assert v1 <= '2.0'
    assert '2.0' > v1
    assert '2.0' >= v1
    assert not v1 == '2.0'
    assert v1 != '2.0'
    assert v1 < Version('2.0')
    assert v1 <= Version('2.0')
    assert Version('2.0') > v1
    assert Version('2.0') >= v1
    assert not v1 == Version('2.0')


# Generated at 2022-06-16 23:23:25.159135
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:24:41.147962
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert v != '1.2.4'
    assert v != Version('1.2.4')
    assert v != '1.2'
    assert v != Version('1.2')
    assert v != '1.2.3.4'
    assert v != Version('1.2.3.4')
    assert v != '1.2.3-4'
    assert v != Version('1.2.3-4')
    assert v != '1.2.3.4-5'
    assert v != Version('1.2.3.4-5')
    assert v != '1.2.3-4.5'

# Generated at 2022-06-16 23:24:43.106635
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented

# Generated at 2022-06-16 23:24:50.441838
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version
    v = Version('1.0')
    assert v == '1.0'
    assert v == Version('1.0')
    assert not v == '1.1'
    assert not v == Version('1.1')
    assert not v == '1.0.0'
    assert not v == Version('1.0.0')
    assert not v == '1.0.0.0'
    assert not v == Version('1.0.0.0')
    assert not v == '1.0.0.0.0'
    assert not v == Version('1.0.0.0.0')
    assert not v == '1.0.0.0.0.0'
    assert not v == Version('1.0.0.0.0.0')

# Generated at 2022-06-16 23:24:53.061915
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert not v.__ge__(object())

# Generated at 2022-06-16 23:24:56.108299
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:24:57.423180
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:24:59.043859
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented


# Generated at 2022-06-16 23:25:00.241991
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:25:02.799563
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()
    assert not v == Version('1.0')

# Generated at 2022-06-16 23:25:14.262223
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(None)
    assert v.__le__(1)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)

# Generated at 2022-06-16 23:28:00.789400
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:28:09.973999
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(None) == NotImplemented
    assert v1.__gt__(1) == NotImplemented
    assert v1.__gt__(1.0) == NotImplemented
    assert v1.__gt__('') == NotImplemented
    assert v1.__gt__('1') == NotImplemented
    assert v1.__gt__('1.0') == NotImplemented
    assert v1.__gt__('1.0.0') == NotImplemented
    assert v1.__gt__('1.0.0.0') == NotImplemented

# Generated at 2022-06-16 23:28:11.091138
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:28:19.918234
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 <= v2
    assert v1 <= '2.0'
    assert v1 <= Version('2.0')
    assert not (v1 <= '1.0')
    assert not (v1 <= Version('1.0'))
    assert not (v2 <= '1.0')
    assert not (v2 <= Version('1.0'))
    assert not (v2 <= v1)


# Generated at 2022-06-16 23:28:21.812440
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v
    assert not v < v
    assert v <= v
    assert not v > v
    assert v >= v

# Generated at 2022-06-16 23:28:26.936855
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert not v.__le__(None)


# Generated at 2022-06-16 23:28:31.587241
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert not Version('1.1') <= Version('1.0')


# Generated at 2022-06-16 23:28:33.479799
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented


# Generated at 2022-06-16 23:28:43.294679
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__(Version()) == False
    assert v.__gt__(Version("1")) == False
    assert v.__gt__(Version("2")) == False
    assert v.__gt__(Version("1.1")) == False
    assert v.__gt__(Version("1.2")) == False
    assert v.__gt__(Version("1.1.1")) == False
    assert v.__gt__(Version("1.1.2")) == False
    assert v.__gt__(Version("1.1.1.1")) == False
    assert v.__gt__(Version("1.1.1.2")) == False

# Generated at 2022-06-16 23:28:49.508232
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.0') > Version('0.9')
    assert Version('1.0') > '0.9'
    assert not Version('1.0') > Version('1.0')
    assert not Version('1.0') > '1.0'
    assert not Version('0.9') > Version('1.0')
    assert not Version('0.9') > '1.0'

