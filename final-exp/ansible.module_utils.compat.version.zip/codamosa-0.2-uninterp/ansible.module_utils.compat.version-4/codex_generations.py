

# Generated at 2022-06-16 23:19:54.598358
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:20:05.764552
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert v == Version('1')
    assert v == Version('1.0')
    assert v == Version('1.0.0')
    assert v == Version('1.0.0.0')
    assert v == Version('1.0.0.0.0')
    assert v == Version('1.0.0.0.0.0')
    assert v == Version('1.0.0.0.0.0.0')
    assert v == Version('1.0.0.0.0.0.0.0')
    assert v == Version('1.0.0.0.0.0.0.0.0')
    assert v == Version('1.0.0.0.0.0.0.0.0.0')


# Generated at 2022-06-16 23:20:08.493356
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert not v.__le__(None)


# Generated at 2022-06-16 23:20:18.897703
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v.parse('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)
    v.parse('1.2.3b4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 4)
    v.parse('1.2')
    assert v.version == (1, 2, 0)
    assert v.prerelease is None
    v.parse('1.2a4')
    assert v.version == (1, 2, 0)
    assert v.prerelease == ('a', 4)
    v

# Generated at 2022-06-16 23:20:23.656162
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2


# Generated at 2022-06-16 23:20:25.472951
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:20:37.903862
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert v == Version('1.0')
    assert v == '1.0'
    assert v == 1.0
    assert v == 1
    assert v == 1.0
    assert v == '1.0'
    assert v == '1'
    assert v == '1.0'
    assert v == '1.0'
    assert v == '1.0'
    assert v == '1.0'
    assert v == '1.0'
    assert v == '1.0'
    assert v == '1.0'
    assert v == '1.0'
    assert v == '1.0'
    assert v == '1.0'
    assert v == '1.0'
    assert v == '1.0'

# Generated at 2022-06-16 23:20:39.323168
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:20:40.640486
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:20:51.000154
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("1.0.4a3")
    assert v.version == (1, 0, 4)
    assert v.prerelease == ('a', 3)

    v = StrictVersion("1.0.4b1")
    assert v.version == (1, 0, 4)
    assert v.prerelease == ('b', 1)

    v = StrictVersion("1.0.4")
    assert v.version == (1, 0, 4)
    assert v.prerelease == None

    v = StrictVersion("1.2")
    assert v.version == (1, 2, 0)
    assert v.prerelease == None

    v = StrictVersion("1.2.0")
    assert v.version == (1, 2, 0)
    assert v.prerelease == None


# Generated at 2022-06-16 23:20:58.985279
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:21:07.367274
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test the parsing of version numbers
    lv = LooseVersion

    assert lv("1.0").version == (1, 0)
    assert lv("1.2.3").version == (1, 2, 3)
    assert lv("1.2.0").version == (1, 2, 0)
    assert lv("1.2.0").version == (1, 2, 0)
    assert lv("1.2.a").version == (1, 2, 'a')
    assert lv("1.2.0a").version == (1, 2, 0, 'a')
    assert lv("1.2.0.a").version == (1, 2, 0, 'a')
    assert lv("1.2.0.1.a").version == (1, 2, 0, 1, 'a')

# Generated at 2022-06-16 23:21:17.029416
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 <= v2
    assert v1 <= '1.0'
    assert v1 <= Version('1.0')
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v1 <= '1.0'
    assert v

# Generated at 2022-06-16 23:21:21.223863
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2
    assert v1 <= v2
    assert not v1 == v2
    assert not v1 > v2
    assert not v1 >= v2


# Generated at 2022-06-16 23:21:23.174605
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:21:33.240379
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.1') <= Version('1.2')
    assert Version('1.0') <= Version('1.0.1')
    assert Version('1.0.1') <= Version('1.0.2')
    assert Version('1.0.1') <= Version('1.1')
    assert Version('1.0.1') <= Version('1.1.1')
    assert Version('1.0.1') <= Version('1.1.1.1')
    assert Version('1.0.1') <= Version('1.1.1.1.1')
    assert Version('1.0.1') <= Version('1.1.1.1.1.1')
    assert Version

# Generated at 2022-06-16 23:21:37.650249
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert not (Version('1.1') <= Version('1.0'))

# Generated at 2022-06-16 23:21:45.154263
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.2.3").__str__() == "1.2.3"
    assert StrictVersion("1.2").__str__() == "1.2"
    assert StrictVersion("1.2.3a4").__str__() == "1.2.3a4"
    assert StrictVersion("1.2.3b4").__str__() == "1.2.3b4"
    assert StrictVersion("1.2a4").__str__() == "1.2a4"
    assert StrictVersion("1.2b4").__str__() == "1.2b4"


# Generated at 2022-06-16 23:21:47.339602
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2
    assert not (v1 != v2)


# Generated at 2022-06-16 23:21:49.969746
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:21:58.413350
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented


# Generated at 2022-06-16 23:22:09.519401
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert v == '0'
    assert v == '0.0'
    assert v == '0.0.0'
    assert v == '0.0.0.0'
    assert v == '0.0.0.0.0'
    assert v == '0.0.0.0.0.0'
    assert v == '0.0.0.0.0.0.0'
    assert v == '0.0.0.0.0.0.0.0'
    assert v == '0.0.0.0.0.0.0.0.0'
    assert v == '0.0.0.0.0.0.0.0.0.0'

# Generated at 2022-06-16 23:22:10.723034
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(1) == NotImplemented

# Generated at 2022-06-16 23:22:12.073553
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:22:20.396309
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert v.__ge__(1)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0j)
    assert v.__ge__(1.0+1.0j)
    assert v.__ge__(True)
    assert v.__ge__(False)
    assert v.__ge__(b'\x00')
    assert v.__ge__(bytearray(b'\x00'))
    assert v.__ge__(memoryview(b'\x00'))
    assert v.__ge__(NotImplemented)
    assert v.__ge__(Ellipsis)
    assert v.__ge__(object())


# Generated at 2022-06-16 23:22:32.523740
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == Version('1.0')
    assert v1 != '1.0'
    assert v1 != 1.0
    assert v1 != 1
    assert v1 != (1, 0)
    assert v1 != [1, 0]
    assert v1 != {'1': 0}
    assert v1 != None
    assert v1 != object()
    assert v1 != Version('1.0.post1')
    assert v1 != Version('1.0.dev1')
    assert v1 != Version('1.0.post1.dev1')
   

# Generated at 2022-06-16 23:22:34.989378
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert not (v != v)
    assert not (v != Version())

# Generated at 2022-06-16 23:22:36.270131
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:22:37.461690
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__gt__(v2) == False


# Generated at 2022-06-16 23:22:38.735162
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:22:52.343742
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:54.799597
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)

# Generated at 2022-06-16 23:23:04.907810
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert v == Version('1.2.3.0')
    assert v != '1.2.4'
    assert v != Version('1.2.4')
    assert v != Version('1.2.4.0')
    assert v != '1.2.3.0.0'
    assert v != Version('1.2.3.0.0')
    assert v != Version('1.2.3.0.0.0')
    assert v != '1.2.3.0.0.0.0'
    assert v != Version('1.2.3.0.0.0.0')

# Generated at 2022-06-16 23:23:16.766161
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not v1 < v2
    assert not v2 < v1
    v2 = Version('1.2.4')
    assert v1 < v2
    assert not v2 < v1
    v2 = Version('1.3.3')
    assert v1 < v2
    assert not v2 < v1
    v2 = Version('2.2.3')
    assert v1 < v2
    assert not v2 < v1
    v2 = Version('1.2.3.4')
    assert v1 < v2
    assert not v2 < v1
    v2 = Version('1.2.3.4.5')
    assert v1 < v2
    assert not v2 < v1

# Generated at 2022-06-16 23:23:18.616262
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented

# Generated at 2022-06-16 23:23:24.607390
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)
    assert not (v < v)
    assert v <= v
    assert not (v > v)
    assert v >= v
    assert not (v == None)
    assert v != None
    assert not (v < None)
    assert not (v <= None)
    assert v > None
    assert v >= None
    assert not (None == v)
    assert None != v
    assert None < v
    assert None <= v
    assert not (None > v)
    assert not (None >= v)

# Generated at 2022-06-16 23:23:26.449689
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:23:28.435074
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:23:29.816285
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:23:31.136873
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v)


# Generated at 2022-06-16 23:23:58.113900
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert not v == '1.2.4'
    assert not v == Version('1.2.4')

# Generated at 2022-06-16 23:24:05.056189
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True
    assert v.__eq__(None) == False
    assert v.__eq__(1) == False
    assert v.__eq__(1.0) == False
    assert v.__eq__('') == False
    assert v.__eq__('1') == False
    assert v.__eq__(()) == False
    assert v.__eq__([]) == False
    assert v.__eq__({}) == False
    assert v.__eq__(set()) == False
    assert v.__eq__(frozenset()) == False
    assert v.__eq__(Ellipsis) == False
    assert v.__eq__(NotImplemented) == False

# Generated at 2022-06-16 23:24:12.113356
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2


# Generated at 2022-06-16 23:24:13.915685
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-16 23:24:15.254562
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:24:26.338303
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == Version('1.0')
    assert v1 != Version('1.1')
    assert v1 != '1.0'
    assert v1 != '1.1'
    assert v1 != 1.0
    assert v1 != 1.1
    assert v1 != [1, 0]
    assert v1 != [1, 1]
    assert v1 != (1, 0)
    assert v1 != (1, 1)
    assert v1 != {'1': 0}
    assert v1 != {'1': 1}

# Generated at 2022-06-16 23:24:28.505520
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented


# Generated at 2022-06-16 23:24:30.938263
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:24:41.421348
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__gt__(v2) == False
    assert v1.__gt__('1.2.3') == False
    assert v1.__gt__('1.2.4') == False
    assert v1.__gt__('1.2.2') == True
    assert v1.__gt__('1.3.3') == False
    assert v1.__gt__('2.2.3') == False
    assert v1.__gt__('1.2.3a') == False
    assert v1.__gt__('1.2.3.1') == False
    assert v1.__gt__('1.2.3.0') == True

# Generated at 2022-06-16 23:24:43.184615
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-16 23:25:35.695964
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1.__lt__(v2) == NotImplemented

# Generated at 2022-06-16 23:25:36.516440
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:25:37.923179
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:25:49.215434
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__(Version()) == 0
    assert v.__gt__(StrictVersion("1.0")) == 0
    assert v.__gt__(LooseVersion("1.0")) == 0
    assert v.__gt__(LegacyVersion("1.0")) == 0
    assert v.__gt__(ComparableVersion("1.0")) == 0
    assert v.__gt__(LegacyVersion("1.0.0")) == 0
    assert v.__gt__(ComparableVersion("1.0.0")) == 0
    assert v.__gt__(LegacyVersion("1.0.0.0")) == 0
    assert v.__gt__

# Generated at 2022-06-16 23:25:51.321185
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-16 23:25:52.889708
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v == 1

# Generated at 2022-06-16 23:26:01.025685
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.1') <= Version('1.1')
    assert Version('1.1') <= Version('1.2')
    assert Version('1.2') <= Version('1.2')
    assert Version('1.2') <= Version('2.0')
    assert Version('2.0') <= Version('2.0')
    assert Version('2.0') <= Version('2.1')
    assert Version('2.1') <= Version('2.1')
    assert Version('2.1') <= Version('2.2')
    assert Version('2.2') <= Version('2.2')
    assert Version('2.2') <= Version('3.0')

# Generated at 2022-06-16 23:26:03.510265
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 <= v2

# Generated at 2022-06-16 23:26:05.598343
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1.__lt__(v2) == NotImplemented

# Generated at 2022-06-16 23:26:07.986392
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented

# Generated at 2022-06-16 23:28:25.741002
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:28:27.083230
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:28:28.190586
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:28:30.371024
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:28:31.640782
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:28:33.072540
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:28:43.036749
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.2.3')
    assert v <= '1.2.3'
    assert v <= '1.2.4'
    assert not (v <= '1.2.2')
    assert not (v <= '1.1.3')
    assert not (v <= '1.2.3.0')
    assert not (v <= '1.2.3-0')
    assert not (v <= '1.2.3.0-0')
    assert not (v <= '1.2.3.0-0.0')
    assert not (v <= '1.2.3.0-0.0.0')
    assert not (v <= '1.2.3.0-0.0.0.0')

# Generated at 2022-06-16 23:28:46.213878
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)

# Generated at 2022-06-16 23:28:47.670371
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:28:49.545777
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2
