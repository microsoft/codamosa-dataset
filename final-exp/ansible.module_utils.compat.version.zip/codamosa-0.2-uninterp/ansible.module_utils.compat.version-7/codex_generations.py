

# Generated at 2022-06-16 23:19:52.200217
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:19:53.975884
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == False


# Generated at 2022-06-16 23:19:55.190248
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:20:06.494394
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse("1.0.4a3")
    assert v.version == (1, 0, 4)
    assert v.prerelease == ('a', 3)
    v.parse("1.0.4b1")
    assert v.version == (1, 0, 4)
    assert v.prerelease == ('b', 1)
    v.parse("1.0.4")
    assert v.version == (1, 0, 4)
    assert v.prerelease == None
    v.parse("1.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease == None
    v.parse("1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == None

# Generated at 2022-06-16 23:20:08.827790
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:20:19.156102
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.0')
    assert str(v) == '1.0'
    v = StrictVersion('1.0.0')
    assert str(v) == '1.0'
    v = StrictVersion('1.0.1')
    assert str(v) == '1.0.1'
    v = StrictVersion('1.0a1')
    assert str(v) == '1.0a1'
    v = StrictVersion('1.0b1')
    assert str(v) == '1.0b1'
    v = StrictVersion('1.0.0a1')
    assert str(v) == '1.0a1'
    v = StrictVersion('1.0.0b1')

# Generated at 2022-06-16 23:20:21.897060
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-16 23:20:31.081057
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-16 23:20:32.926023
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:38.485512
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 < v2 == False
    assert v1 <= v2 == True
    assert v1 > v2 == False
    assert v1 >= v2 == True
    assert v1 == v2 == True
    assert v1 != v2 == False


# Generated at 2022-06-16 23:20:49.270357
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:50.411387
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) == NotImplemented


# Generated at 2022-06-16 23:20:53.466492
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    v.parse = lambda x: x
    v.__lt__ = lambda x: x
    assert v.__lt__(1) == 1


# Generated at 2022-06-16 23:20:58.809477
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 == v2
    assert not (v1 != v2)
    assert not (v1 < v2)
    assert v1 <= v2
    assert not (v1 > v2)
    assert v1 >= v2

# Generated at 2022-06-16 23:21:00.570398
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented


# Generated at 2022-06-16 23:21:02.286327
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:21:04.358357
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:21:07.394258
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert not v.__le__(None)


# Generated at 2022-06-16 23:21:08.881949
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:21:15.032664
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert v < '1.2.4'
    assert v < '1.3.3'
    assert v < '2.2.3'
    assert not v < '1.2.3'
    assert not v < '1.2.2'
    assert not v < '1.1.3'
    assert not v < '0.2.3'


# Generated at 2022-06-16 23:21:24.563295
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:21:34.299187
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.0') < Version('1.1')
    assert not Version('1.1') < Version('1.1')
    assert not Version('1.2') < Version('1.1')
    assert Version('1.0') < '1.1'
    assert not Version('1.1') < '1.1'
    assert not Version('1.2') < '1.1'
    assert not Version('1.0') < '1.0'
    assert not Version('1.1') < '1.0'
    assert not Version('1.1') < '1.0'
    assert not Version('1.0') < '1.0.0'
    assert not Version('1.0') < '1.0.0.0'

# Generated at 2022-06-16 23:21:41.009499
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2
    assert v1 >= '1.2.3'
    assert v1 >= '1.2.2'
    assert not (v1 >= '1.2.4')
    assert not (v1 >= '1.3.3')
    assert not (v1 >= '2.2.3')
    assert not (v1 >= '1.2.3a1')
    assert not (v1 >= '1.2.3.post1')
    assert not (v1 >= '1.2.3.dev1')
    assert not (v1 >= '1.2.3.dev1+sha')
    assert not (v1 >= '1.2.3.dev1+sha.1')

# Generated at 2022-06-16 23:21:44.115032
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:21:52.508766
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2.3') <= Version('1.2.3')
    assert Version('1.2.3') <= Version('1.2.4')
    assert Version('1.2.3') <= Version('1.3.3')
    assert Version('1.2.3') <= Version('2.2.3')
    assert not (Version('1.2.4') <= Version('1.2.3'))
    assert not (Version('1.3.3') <= Version('1.2.3'))
    assert not (Version('2.2.3') <= Version('1.2.3'))

# Generated at 2022-06-16 23:21:54.594491
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:21:57.456527
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:08.557339
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest
    class TestVersion___ge__(unittest.TestCase):
        def test_Version___ge__(self):
            # Version.__ge__
            # Method __ge__ of class Version
            self.assertEqual(Version().__ge__(Version()), NotImplemented)
            self.assertEqual(Version().__ge__(StrictVersion()), NotImplemented)
            self.assertEqual(Version().__ge__(LooseVersion()), NotImplemented)
            self.assertEqual(Version().__ge__(''), NotImplemented)
            self.assertEqual(Version().__ge__(0), NotImplemented)
            self.assertEqual(Version().__ge__(1), NotImplemented)

# Generated at 2022-06-16 23:22:10.019844
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:22:11.751661
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:28.569563
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented

# Generated at 2022-06-16 23:22:31.050908
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:22:40.171376
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1

# Generated at 2022-06-16 23:22:42.610907
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__gt__(v2) == False


# Generated at 2022-06-16 23:22:51.303547
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Version.__le__(Version, Version)
    assert Version('1.2.3') <= Version('1.2.3')
    assert not Version('1.2.3') <= Version('1.2.2')
    # Version.__le__(Version, str)
    assert Version('1.2.3') <= '1.2.3'
    assert not Version('1.2.3') <= '1.2.2'
    # Version.__le__(Version, object)
    assert not Version('1.2.3') <= object()


# Generated at 2022-06-16 23:23:02.238860
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(Version())
    assert v.__ge__(None)
    assert v.__ge__(object())
    assert v.__ge__(1)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0 + 0.0j)
    assert v.__ge__(True)
    assert v.__ge__(False)
    assert v.__ge__(())
    assert v.__ge__([])
    assert v.__ge__({})
    assert v.__ge__(set())
    assert v.__ge__(frozenset())
    assert v.__ge__(b'')
    assert v.__ge__(bytearray())

# Generated at 2022-06-16 23:23:03.468318
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:23:06.476001
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert v.__le__(Version('1.0'))
    assert not v.__le__(Version('0.9'))


# Generated at 2022-06-16 23:23:13.943136
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == Version('1.0')
    assert v1 != '1.0'
    assert v1 != 1.0
    assert v1 != None
    assert v1 != object()

# Generated at 2022-06-16 23:23:15.891243
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True

# Generated at 2022-06-16 23:23:45.844734
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented

# Generated at 2022-06-16 23:23:48.584691
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert v == '0'
    assert v == 0
    assert not v == 1
    assert not v == '1'

# Generated at 2022-06-16 23:23:56.305365
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2.3') >= Version('1.2.3')
    assert Version('1.2.3') >= '1.2.3'
    assert not (Version('1.2.3') >= Version('1.2.4'))
    assert not (Version('1.2.3') >= '1.2.4')
    assert not (Version('1.2.3') >= Version('1.3.3'))
    assert not (Version('1.2.3') >= '1.3.3')
    assert not (Version('1.2.3') >= Version('2.2.3'))
    assert not (Version('1.2.3') >= '2.2.3')
    assert Version('1.2.3') >= Version('1.2.3a1')

# Generated at 2022-06-16 23:23:57.863174
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()


# Generated at 2022-06-16 23:24:05.096898
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 <= v2
    assert v1 <= '1.2.3'
    assert v1 <= '1.2.4'
    assert not v1 <= '1.2.2'
    assert not v1 <= '1.1.3'
    assert not v1 <= '0.2.3'
    assert not v1 <= '1.2.3.4'
    assert not v1 <= '1.2.3-4'
    assert not v1 <= '1.2.3.4-5'
    assert not v1 <= '1.2.3.4-5.6'
    assert not v1 <= '1.2.3.4-5.6.7'
    assert not v1

# Generated at 2022-06-16 23:24:14.612650
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not (v1 < v2)
    assert not (v1 < '1.2.3')
    assert not (v1 < '1.2.4')
    assert not (v1 < '1.3.3')
    assert not (v1 < '2.2.3')
    assert v1 < '1.2.2'
    assert v1 < '1.1.3'
    assert v1 < '0.2.3'

# Generated at 2022-06-16 23:24:16.683362
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:24:19.489233
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented


# Generated at 2022-06-16 23:24:21.326251
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:24:23.083469
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:25:24.958205
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == False


# Generated at 2022-06-16 23:25:35.607436
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.0') <= Version('2.0')
    assert Version('1.0') <= Version('1.0.0')
    assert Version('1.0') <= Version('1.0.1')
    assert Version('1.0') <= Version('1.1.0')
    assert Version('1.0') <= Version('2.0.0')
    assert Version('1.0') <= Version('1.0.0.0')
    assert Version('1.0') <= Version('1.0.0.1')
    assert Version('1.0') <= Version('1.0.1.0')
    assert Version('1.0') <= Version('1.1.0.0')

# Generated at 2022-06-16 23:25:36.909072
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:25:39.822212
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v.parse('1.2.3')
    assert v <= '1.2.3'
    assert v <= '1.2.4'
    assert not v <= '1.2.2'


# Generated at 2022-06-16 23:25:41.711874
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:25:46.209285
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert not v1 > v2
    assert v1 <= v2
    assert not v1 >= v2
    assert not v1 == v2


# Generated at 2022-06-16 23:25:50.103612
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__('1.0')
    assert v.__ge__(Version('1.0'))
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:25:51.969811
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(v) == False


# Generated at 2022-06-16 23:26:00.488024
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v
    assert v >= '0'
    assert v >= 0
    assert not v >= 1
    assert not v >= '1'
    assert not v >= '1.0'
    assert not v >= '1.0.0'
    assert not v >= '1.0.0.0'
    assert not v >= '1.0.0.0.0'
    assert not v >= '1.0.0.0.0.0'
    assert not v >= '1.0.0.0.0.0.0'
    assert not v >= '1.0.0.0.0.0.0.0'
    assert not v >= '1.0.0.0.0.0.0.0.0'

# Generated at 2022-06-16 23:26:11.199037
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False

# Generated at 2022-06-16 23:27:28.032186
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:27:29.919997
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)

# Generated at 2022-06-16 23:27:34.733451
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 <= v2
    assert v1 <= '2.0'
    assert not v2 <= v1
    assert not v2 <= '1.0'
    assert v1 <= v1
    assert v1 <= '1.0'
    assert v2 <= v2
    assert v2 <= '2.0'


# Generated at 2022-06-16 23:27:41.407897
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert v < '1.2.4'
    assert v < '1.3.3'
    assert v < '2.2.3'
    assert not v < '1.2.3'
    assert not v < '1.2.2'
    assert not v < '1.1.3'
    assert not v < '0.2.3'
    assert not v < '1.2.3.4'
    assert not v < '1.2.3-4'
    assert not v < '1.2.3.4.5'
    assert not v < '1.2.3.4-5'
    assert not v < '1.2.3-4.5'
    assert not v < '1.2.3-4.5.6'

# Generated at 2022-06-16 23:27:49.948655
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert not v >= '1.2.4'
    assert not v >= '1.2.2'
    assert v >= '1.2.3a1'
    assert v >= '1.2.3b1'
    assert v >= '1.2.3c1'
    assert v >= '1.2.3rc1'
    assert v >= '1.2.3.post1'
    assert v >= '1.2.3.dev1'
    assert v >= '1.2.3.post0'
    assert v >= '1.2.3.dev0'
    assert v >= '1.2.3.post'
    assert v >= '1.2.3.dev'

# Generated at 2022-06-16 23:27:52.337801
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1.__gt__(v2) == False
    assert v2.__gt__(v1) == True


# Generated at 2022-06-16 23:27:55.429818
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= Version()


# Generated at 2022-06-16 23:27:59.538256
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:28:03.887959
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:28:05.518481
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented
