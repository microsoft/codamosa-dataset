

# Generated at 2022-06-16 23:19:56.625770
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:20:03.168491
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3')
    assert str(v) == '1.2.3'
    v = StrictVersion('1.2.3a4')
    assert str(v) == '1.2.3a4'
    v = StrictVersion('1.2.3b4')
    assert str(v) == '1.2.3b4'


# Generated at 2022-06-16 23:20:05.520452
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:20:16.479236
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v.parse('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)
    v.parse('1.2.3b4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 4)
    v.parse('1.2.3.4')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v.parse('1.2.3.4a5')
    assert v.version == (1, 2, 3)

# Generated at 2022-06-16 23:20:19.860454
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented

# Generated at 2022-06-16 23:20:30.284080
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion('1.0.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion('1.0a1')
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion('1.0.0a1')
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion('1.0b1')
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('b', 1)

    v

# Generated at 2022-06-16 23:20:40.370082
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.0.0')
    assert str(v) == '1.0.0'
    v = StrictVersion('1.0')
    assert str(v) == '1.0'
    v = StrictVersion('1.0a1')
    assert str(v) == '1.0a1'
    v = StrictVersion('1.0b1')
    assert str(v) == '1.0b1'
    v = StrictVersion('1.0.0a1')
    assert str(v) == '1.0.0a1'
    v = StrictVersion('1.0.0b1')
    assert str(v) == '1.0.0b1'


# Generated at 2022-06-16 23:20:42.028192
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2


# Generated at 2022-06-16 23:20:43.286763
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= v


# Generated at 2022-06-16 23:20:45.196074
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2

# Generated at 2022-06-16 23:20:57.303230
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2

# Generated at 2022-06-16 23:20:58.985497
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v)


# Generated at 2022-06-16 23:21:00.331198
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:21:02.003203
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:21:03.425907
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:21:05.202430
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v)
    assert not v.__eq__(None)


# Generated at 2022-06-16 23:21:09.089253
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert not Version('1.1') <= Version('1.0')

# Generated at 2022-06-16 23:21:12.114410
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert not v == None
    assert not v == "1.0"

# Generated at 2022-06-16 23:21:13.973859
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented


# Generated at 2022-06-16 23:21:18.245944
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2


# Generated at 2022-06-16 23:21:42.437337
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2.3') >= Version('1.2.3')
    assert Version('1.2.3') >= '1.2.3'
    assert not Version('1.2.3') >= Version('1.2.4')
    assert not Version('1.2.3') >= '1.2.4'
    assert not Version('1.2.3') >= Version('1.2.2')
    assert not Version('1.2.3') >= '1.2.2'
    assert not Version('1.2.3') >= Version('1.3.3')
    assert not Version('1.2.3') >= '1.3.3'
    assert not Version('1.2.3') >= Version('2.2.3')

# Generated at 2022-06-16 23:21:53.389461
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    class Version___lt__(unittest.TestCase):
        def test_Version___lt__(self):
            # Version.__lt__
            self.assertTrue(Version('1.2') < Version('1.3'))
            self.assertTrue(Version('1.2') < Version('1.2.1'))
            self.assertTrue(Version('1.2') < Version('1.2.0.1'))
            self.assertTrue(Version('1.2') < Version('1.2.0.0.1'))
            self.assertTrue(Version('1.2') < Version('1.2.0.0.0.1'))
            self.assertTrue(Version('1.2') < Version('1.2.0.0.0.0.1'))
            self

# Generated at 2022-06-16 23:21:56.133934
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented

# Generated at 2022-06-16 23:21:58.025246
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented

# Generated at 2022-06-16 23:22:04.440519
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 <= v2
    assert not v2 <= v1
    assert v1 <= '1.0'
    assert not v2 <= '1.0'
    assert '1.0' <= v1
    assert not '1.0' <= v2
    assert v1 <= v1
    assert '1.0' <= '1.0'


# Generated at 2022-06-16 23:22:14.971056
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= v
    assert not (v <= Version('1.0'))
    assert not (v <= '1.0')
    assert not (v <= '1.0.0')
    assert not (v <= '1.0.0.0')
    assert not (v <= '1.0.0.0.0')
    assert not (v <= '1.0.0.0.0.0')
    assert not (v <= '1.0.0.0.0.0.0')
    assert not (v <= '1.0.0.0.0.0.0.0')
    assert not (v <= '1.0.0.0.0.0.0.0.0')

# Generated at 2022-06-16 23:22:16.556612
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2


# Generated at 2022-06-16 23:22:18.079794
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented

# Generated at 2022-06-16 23:22:19.916250
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:22:21.185408
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:22:52.271441
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.0') > Version('0.9')
    assert not Version('0.9') > Version('1.0')
    assert not Version('1.0') > Version('1.0')


# Generated at 2022-06-16 23:22:58.516676
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2
    assert v2 > v1
    assert v1 <= v2
    assert v2 >= v1
    assert v1 != v2
    assert v2 != v1
    assert not (v1 == v2)
    assert not (v2 == v1)


# Generated at 2022-06-16 23:23:05.068882
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.1') <= Version('1.2')
    assert Version('1.0') <= Version('2.0')
    assert Version('1.0') <= Version('1.0.post1')
    assert Version('1.0.post1') <= Version('1.0.post2')
    assert Version('1.0.post1') <= Version('1.0.post1.dev1')
    assert Version('1.0.post1.dev1') <= Version('1.0.post1.dev2')
    assert Version('1.0.post1.dev1') <= Version('1.0.post1.dev1+abc')

# Generated at 2022-06-16 23:23:06.909283
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 >= v2

# Generated at 2022-06-16 23:23:09.212144
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented

# Generated at 2022-06-16 23:23:11.354908
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)


# Generated at 2022-06-16 23:23:18.115988
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)
    assert not (v < v)
    assert v <= v
    assert not (v > v)
    assert v >= v
    assert not (v == None)
    assert v != None
    assert not (v < None)
    assert not (v <= None)
    assert v > None
    assert v >= None


# Generated at 2022-06-16 23:23:22.316684
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2


# Generated at 2022-06-16 23:23:24.766966
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:23:34.250341
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == v1
    assert v2 == v2
    assert not (v1 < v1)
    assert not (v1 <= v1)
    assert not (v1 > v1)
    assert not (v1 >= v1)
    assert not (v1 != v1)
    assert not (v2 < v2)
    assert not (v2 <= v2)
    assert not (v2 > v2)
    assert not (v2 >= v2)
    assert not (v2 != v2)


# Generated at 2022-06-16 23:24:31.930346
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2

# Generated at 2022-06-16 23:24:42.129166
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse("1.5.1")
    assert lv.version == [1, 5, 1]
    lv.parse("1.5.2b2")
    assert lv.version == [1, 5, 2, "b", 2]
    lv.parse("161")
    assert lv.version == [161]
    lv.parse("3.10a")
    assert lv.version == [3, 10, "a"]
    lv.parse("8.02")
    assert lv.version == [8, 2]
    lv.parse("3.4j")
    assert lv.version == [3, 4, "j"]
    lv.parse("1996.07.12")
    assert lv.version == [1996, 7, 12]

# Generated at 2022-06-16 23:24:52.965477
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__(v2) == NotImplemented

# Generated at 2022-06-16 23:24:55.249000
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()

# Generated at 2022-06-16 23:24:59.085939
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert not v1 == v2


# Generated at 2022-06-16 23:25:01.325697
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:25:04.293738
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2

# Generated at 2022-06-16 23:25:07.449873
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:25:09.131437
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True


# Generated at 2022-06-16 23:25:11.157888
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2


# Generated at 2022-06-16 23:26:11.654514
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()

# Generated at 2022-06-16 23:26:15.080111
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.0')
    assert v <= '1.0'
    assert v <= '1.1'
    assert not v <= '0.9'


# Generated at 2022-06-16 23:26:16.340118
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:26:19.108987
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:26:30.397044
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)
    assert not v.__ge__(1)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0j)
    assert not v.__ge__(())
    assert not v.__ge__([])
    assert not v.__ge__({})
    assert not v.__ge__(set())
    assert not v.__ge__(frozenset())
    assert not v.__ge__(object())
    assert not v.__ge__(object)
    assert not v.__ge__(Exception())
    assert not v.__ge__(Exception)
    assert not v.__ge__(StopIteration())
    assert not v.__ge

# Generated at 2022-06-16 23:26:31.718967
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:26:33.897366
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert not (v != v)
    assert not (v != Version())


# Generated at 2022-06-16 23:26:35.982251
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented

# Generated at 2022-06-16 23:26:38.762830
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert not v.__ge__(object())


# Generated at 2022-06-16 23:26:40.620354
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:27:55.761040
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:28:06.265299
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.0') < Version('1.1')
    assert Version('1.0') < Version('1.1.0')
    assert Version('1.0') < Version('1.1.0.0')
    assert Version('1.0') < Version('1.1.0.0.0')
    assert Version('1.0') < Version('1.1.0.0.0.0')
    assert Version('1.0') < Version('1.1.0.0.0.0.0')
    assert Version('1.0') < Version('1.1.0.0.0.0.0.0')
    assert Version('1.0') < Version('1.1.0.0.0.0.0.0.0')

# Generated at 2022-06-16 23:28:07.488718
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:28:09.324517
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented


# Generated at 2022-06-16 23:28:15.720705
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented
    assert v.__ge__(1) is NotImplemented
    assert v.__ge__(1.0) is NotImplemented
    assert v.__ge__(1.0+0j) is NotImplemented
    assert v.__ge__(True) is NotImplemented
    assert v.__ge__(False) is NotImplemented
    assert v.__ge__(b'1.0') is NotImplemented
    assert v.__ge__(bytearray(b'1.0')) is NotImplemented
    assert v.__ge__(memoryview(b'1.0')) is NotImplemented
    assert v.__ge__(NotImplemented) is NotImplemented
   

# Generated at 2022-06-16 23:28:17.443368
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented

# Generated at 2022-06-16 23:28:19.079444
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True
    assert v.__eq__(None) == NotImplemented

# Generated at 2022-06-16 23:28:20.108138
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented

# Generated at 2022-06-16 23:28:20.940435
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:28:26.354495
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
