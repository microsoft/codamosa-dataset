

# Generated at 2022-06-16 23:19:50.250485
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:19:52.597113
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:20:00.490642
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None

    v.parse('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)

    v.parse('1.2.3b4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 4)

    v.parse('1.2.3.4')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None

    v.parse('1.2.3.4a5')
    assert v.version == (1, 2, 3)

# Generated at 2022-06-16 23:20:02.695745
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:04.493708
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) == NotImplemented

# Generated at 2022-06-16 23:20:06.396126
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:16.726292
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3')
    assert str(v) == '1.2.3'
    v = StrictVersion('1.2.3a4')
    assert str(v) == '1.2.3a4'
    v = StrictVersion('1.2.3b4')
    assert str(v) == '1.2.3b4'
    v = StrictVersion('1.2')
    assert str(v) == '1.2'
    v = StrictVersion('1.2a4')
    assert str(v) == '1.2a4'
    v = StrictVersion('1.2b4')
    assert str(v) == '1.2b4'


# Generated at 2022-06-16 23:20:21.219197
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert not v1 < v1
    assert not v2 < v1


# Generated at 2022-06-16 23:20:30.695553
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2').__str__() == '1.2'
    assert StrictVersion('1.2a3').__str__() == '1.2a3'
    assert StrictVersion('1.2b3').__str__() == '1.2b3'
    assert StrictVersion('1.2.0').__str__() == '1.2'
    assert StrictVersion('1.2.0a3').__str__() == '1.2a3'
    assert StrictVersion('1.2.0b3').__str__() == '1.2b3'
    assert StrictVersion('1.2.0.0').__str__() == '1.2'
   

# Generated at 2022-06-16 23:20:38.895872
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v.parse('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)
    v.parse('1.2.3b5')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 5)
    v.parse('1.2.3.4')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v.parse('1.2.3.4a5')
    assert v.version == (1, 2, 3)

# Generated at 2022-06-16 23:20:46.427919
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:20:48.304482
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:50.993800
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:20:52.659689
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:20:54.789786
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True
    assert v.__eq__(None) == False

# Generated at 2022-06-16 23:21:04.898741
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.0') < Version('1.1')
    assert Version('1.0') < Version('1.0.1')
    assert Version('1.0') < Version('1.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.0.0.0.1')

# Generated at 2022-06-16 23:21:10.918692
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.5.1')
    assert lv.version == [1, '.', 5, '.', 1]
    lv.parse('1.5.2b2')
    assert lv.version == [1, '.', 5, '.', 2, 'b', 2]
    lv.parse('161')
    assert lv.version == [161]
    lv.parse('3.10a')
    assert lv.version == [3, '.', 10, 'a']
    lv.parse('8.02')
    assert lv.version == [8, '.', 2]
    lv.parse('3.4j')
    assert lv.version == [3, '.', 4, 'j']

# Generated at 2022-06-16 23:21:19.199959
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.0') <= Version('2.0')
    assert Version('1.0') <= Version('1.0.1')
    assert Version('1.0') <= Version('1.0.0.1')
    assert Version('1.0') <= Version('1.0.0.0.1')
    assert Version('1.0') <= Version('1.0.0.0.0.1')
    assert Version('1.0') <= Version('1.0.0.0.0.0.1')
    assert Version('1.0') <= Version('1.0.0.0.0.0.0.1')

# Generated at 2022-06-16 23:21:21.539172
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented

# Generated at 2022-06-16 23:21:32.017332
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert v >= '1.2.2'
    assert not v >= '1.2.4'
    assert not v >= '1.3.3'
    assert not v >= '2.2.3'
    assert not v >= '1.2.3.0'
    assert not v >= '1.2.3.0.0'
    assert not v >= '1.2.3.0.0.0'
    assert not v >= '1.2.3.0.0.0.0'
    assert not v >= '1.2.3.0.0.0.0.0'
    assert not v >= '1.2.3.0.0.0.0.0.0'
    assert not v

# Generated at 2022-06-16 23:21:50.510358
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented
    assert v.__lt__(1) is NotImplemented
    assert v.__lt__('') is NotImplemented
    assert v.__lt__(()) is NotImplemented
    assert v.__lt__([]) is NotImplemented
    assert v.__lt__({}) is NotImplemented


# Generated at 2022-06-16 23:21:52.716938
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:21:57.093878
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented
    assert v2.__gt__(v1) == NotImplemented


# Generated at 2022-06-16 23:22:01.989871
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.5.1')
    assert lv.version == [1, '.', 5, '.', 1]
    lv.parse('1.5.2b2')
    assert lv.version == [1, '.', 5, '.', 2, 'b', 2]
    lv.parse('161')
    assert lv.version == [161]
    lv.parse('3.10a')
    assert lv.version == [3, '.', 10, 'a']
    lv.parse('8.02')
    assert lv.version == [8, '.', 2]
    lv.parse('3.4j')
    assert lv.version == [3, '.', 4, 'j']

# Generated at 2022-06-16 23:22:04.103553
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:05.945302
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:22:07.444417
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:22:08.994806
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:22:11.169279
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented

# Generated at 2022-06-16 23:22:19.787554
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= '1.0'
    assert not Version('1.0') >= Version('1.1')
    assert not Version('1.0') >= '1.1'
    assert not Version('1.1') >= Version('1.0')
    assert not Version('1.1') >= '1.0'
    assert Version('1.1') >= Version('1.1')
    assert Version('1.1') >= '1.1'
    assert Version('1.1') >= Version('1.0')
    assert Version('1.1') >= '1.0'
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= '1.0'
    assert not Version('1.0')

# Generated at 2022-06-16 23:22:46.511110
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented

# Generated at 2022-06-16 23:22:49.303698
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented
    assert v.__lt__(Version()) == NotImplemented


# Generated at 2022-06-16 23:23:00.545520
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__(Version()) == False
    assert v.__gt__(Version('1')) == False
    assert v.__gt__(Version('2')) == False
    assert v.__gt__(Version('1.0')) == False
    assert v.__gt__(Version('2.0')) == False
    assert v.__gt__(Version('1.0.0')) == False
    assert v.__gt__(Version('2.0.0')) == False
    assert v.__gt__(Version('1.0.0.0')) == False

# Generated at 2022-06-16 23:23:02.094090
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v2 > v1
    assert not (v1 > v2)
    assert not (v1 > v1)

# Generated at 2022-06-16 23:23:04.780856
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v2 > v1
    assert v1 < v2
    assert v1 <= v1
    assert v1 >= v1
    assert v1 == v1
    assert v1 != v2


# Generated at 2022-06-16 23:23:06.510277
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented

# Generated at 2022-06-16 23:23:08.308135
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True


# Generated at 2022-06-16 23:23:20.891071
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(Version())
    assert not v.__ge__(None)
    assert not v.__ge__(object())
    assert not v.__ge__(1)
    assert not v.__ge__(1.0)
    assert not v.__ge__('')
    assert not v.__ge__('1')
    assert not v.__ge__('1.0')
    assert not v.__ge__(())
    assert not v.__ge__(('1',))
    assert not v.__ge__(('1', '0'))
    assert not v.__ge__([])
    assert not v.__ge__(['1'])
    assert not v.__ge__(['1', '0'])

# Generated at 2022-06-16 23:23:23.501613
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:23:25.375688
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:24:20.015863
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 == v2
    assert not (v1 != v2)

# Generated at 2022-06-16 23:24:22.231104
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)

# Generated at 2022-06-16 23:24:30.734568
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented
    assert v.__ge__(Version()) == True
    assert v.__ge__(StrictVersion()) == True
    assert v.__ge__(LooseVersion()) == True
    assert v.__ge__('') == True
    assert v.__ge__('0') == True
    assert v.__ge__('0.0') == True
    assert v.__ge__('0.0.0') == True
    assert v.__ge__('0.0.0.0') == True
    assert v.__ge__('0.0.0.0.0') == True
    assert v.__ge__('0.0.0.0.0.0') == True

# Generated at 2022-06-16 23:24:32.514557
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:24:33.990556
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:24:43.678780
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2.3') >= Version('1.2.3')
    assert Version('1.2.3') >= '1.2.3'
    assert not Version('1.2.3') >= Version('1.2.4')
    assert not Version('1.2.3') >= '1.2.4'
    assert not Version('1.2.3') >= Version('1.3.3')
    assert not Version('1.2.3') >= '1.3.3'
    assert not Version('1.2.3') >= Version('2.2.3')
    assert not Version('1.2.3') >= '2.2.3'
    assert Version('1.2.3') >= Version('1.2.3a1')

# Generated at 2022-06-16 23:24:44.927758
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:24:46.544698
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.0")
    v2 = Version("1.1")
    assert v1 < v2

# Generated at 2022-06-16 23:24:51.160688
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert not (v1 < v1)
    assert not (v2 < v1)

# Generated at 2022-06-16 23:24:54.341962
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v
    assert not v < v
    assert v <= v
    assert not v > v
    assert v >= v

# Generated at 2022-06-16 23:25:50.412827
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:25:52.695094
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert not v1 < v2


# Generated at 2022-06-16 23:26:00.896647
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 <= v2
    assert v1 <= '1.2.3'
    assert v1 <= '1.2.4'
    assert v1 <= '1.3.3'
    assert v1 <= '2.2.3'
    assert not v1 <= '0.2.3'
    assert not v1 <= '1.1.3'
    assert not v1 <= '1.2.2'
    assert not v1 <= '1.2.3a1'
    assert not v1 <= '1.2.3.post1'
    assert not v1 <= '1.2.3rc1'

# Generated at 2022-06-16 23:26:03.457398
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2

# Generated at 2022-06-16 23:26:14.903326
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.0') < Version('1.1')
    assert Version('1.0') < Version('1.0.1')
    assert Version('1.0') < Version('1.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.0.0.0.1')

# Generated at 2022-06-16 23:26:16.500361
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-16 23:26:18.751771
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:26:27.546842
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    class Version___lt__(unittest.TestCase):
        def test_Version___lt__(self):
            '''Test method __lt__ of class Version'''
            v1 = Version('1.0')
            v2 = Version('1.1')
            self.assertTrue(v1 < v2)
            self.assertFalse(v1 > v2)
            self.assertFalse(v1 == v2)
            self.assertTrue(v1 <= v2)
            self.assertFalse(v1 >= v2)
    return Version___lt__


# Generated at 2022-06-16 23:26:29.899697
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:26:31.528557
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented

# Generated at 2022-06-16 23:28:53.463624
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented

# Generated at 2022-06-16 23:29:02.104397
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(Version())
    assert v.__ge__(Version('1.0'))
    assert v.__ge__(Version('1.0.0'))
    assert v.__ge__(Version('1.0.0.0'))
    assert v.__ge__(Version('1.0.0.0.0'))
    assert v.__ge__(Version('1.0.0.0.0.0'))
    assert v.__ge__(Version('1.0.0.0.0.0.0'))
    assert v.__ge__(Version('1.0.0.0.0.0.0.0'))

# Generated at 2022-06-16 23:29:03.634073
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:29:04.998060
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented

# Generated at 2022-06-16 23:29:06.044676
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:29:07.425548
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(v) == False


# Generated at 2022-06-16 23:29:12.633227
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:29:23.296935
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented
    assert v.__ge__(1) == NotImplemented
    assert v.__ge__(1.0) == NotImplemented
    assert v.__ge__(1.0+0.0j) == NotImplemented
    assert v.__ge__('') == NotImplemented
    assert v.__ge__('a') == NotImplemented
    assert v.__ge__(()) == NotImplemented
    assert v.__ge__([]) == NotImplemented
    assert v.__ge__({}) == NotImplemented
    assert v.__ge__(set()) == NotImplemented

# Generated at 2022-06-16 23:29:27.098097
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2

# Generated at 2022-06-16 23:29:31.890318
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert v1 <= v2
    assert v1 != v2
    assert v2 > v1
    assert v2 >= v1
    assert v1._cmp(v2) == -1
    assert v2._cmp(v1) == 1
    assert v1._cmp(v1) == 0
    assert v2._cmp(v2) == 0
