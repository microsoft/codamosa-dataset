

# Generated at 2022-06-16 23:19:52.774430
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2


# Generated at 2022-06-16 23:20:00.580329
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2
    assert v2 >= v1
    assert not (v1 > v2)
    assert not (v2 > v1)
    assert v1 <= v2
    assert v2 <= v1
    assert not (v1 < v2)
    assert not (v2 < v1)
    v2 = Version('1.2.4')
    assert v1 < v2
    assert v2 > v1
    assert v1 <= v2
    assert v2 >= v1
    assert not (v1 > v2)
    assert not (v2 < v1)
    assert not (v1 >= v2)
    assert not (v2 <= v1)

# Generated at 2022-06-16 23:20:02.297442
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:20:13.797578
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None

    v = StrictVersion('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)

    v = StrictVersion('1.2.3b4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 4)

    v = StrictVersion('1.2.3.4')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None

    v = StrictVersion('1.2.3a4.5')
    assert v.version == (1, 2, 3)
    assert v.pre

# Generated at 2022-06-16 23:20:15.818712
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)

# Generated at 2022-06-16 23:20:21.537672
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.0').__str__() == '1.0'
    assert StrictVersion('1.0.0').__str__() == '1.0'
    assert StrictVersion('1.0a1').__str__() == '1.0a1'
    assert StrictVersion('1.0b1').__str__() == '1.0b1'
    assert StrictVersion('1.0.0a1').__str__() == '1.0a1'
    assert StrictVersion('1.0.0b1').__str__() == '1.0b1'


# Generated at 2022-06-16 23:20:23.453423
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:20:26.059055
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented

# Generated at 2022-06-16 23:20:29.303085
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:31.706452
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3a4')
    assert str(v) == '1.2.3a4'


# Generated at 2022-06-16 23:20:42.683478
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2

# Generated at 2022-06-16 23:20:44.279427
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:45.849749
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:20:58.153761
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    v = Version('1.0')
    assert v <= '1.0'
    assert v <= '1.1'
    assert not v <= '0.9'
    assert not v <= '1.0a1'
    assert v <= '1.0.dev'
    assert v <= '1.0.post'
    assert v <= '1.0.post1'
    assert v <= '1.0.post.1'
    assert v <= '1.0.post.1.dev'
    assert v <= '1.0.post.1.dev1'
    assert v <= '1.0.post.1.dev.1'
    assert v <= '1.0.post.1.dev.1.post'

# Generated at 2022-06-16 23:21:00.664011
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented


# Generated at 2022-06-16 23:21:02.370755
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(0) == NotImplemented


# Generated at 2022-06-16 23:21:03.557887
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:21:14.921533
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version() >= Version()
    assert Version() >= Version('1')
    assert Version('1') >= Version()
    assert Version('1') >= Version('1')
    assert Version('1') >= Version('1.0')
    assert Version('1.0') >= Version('1')
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= Version('1.0.0')
    assert Version('1.0.0') >= Version('1.0')
    assert Version('1.0.0') >= Version('1.0.0')
    assert Version('1.0.0') >= Version('1.0.0.0')
    assert Version('1.0.0.0') >= Version('1.0.0')

# Generated at 2022-06-16 23:21:18.282361
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:21:29.373959
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__('') is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__(1.0) is NotImplemented
    assert v.__gt__(Version()) is NotImplemented
    assert v.__gt__(StrictVersion()) is NotImplemented
    assert v.__gt__(LooseVersion()) is NotImplemented
    assert v.__gt__(LegacyVersion()) is NotImplemented
    assert v.__gt__(ComparableVersion()) is NotImplemented
    assert v.__gt__(NumericVersion()) is NotImplemented
    assert v.__gt__(NormalizedVersion()) is NotImplemented
    assert v

# Generated at 2022-06-16 23:21:45.671927
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v == None
    assert not v == "1.0"

# Generated at 2022-06-16 23:21:54.645299
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("1.0") <= Version("1.0")
    assert Version("1.0") <= Version("1.1")
    assert Version("1.1") <= Version("1.1")
    assert not (Version("1.1") <= Version("1.0"))
    assert not (Version("1.0") <= Version("0.9"))
    assert not (Version("1.0") <= Version("1.0.post1"))
    assert not (Version("1.0.post1") <= Version("1.0"))
    assert not (Version("1.0.post1") <= Version("1.0.post0"))
    assert Version("1.0.post1") <= Version("1.0.post1")
    assert Version("1.0.post1") <= Version("1.0.post2")

# Generated at 2022-06-16 23:21:57.146543
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:21:59.441838
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:22:01.791488
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented


# Generated at 2022-06-16 23:22:03.241862
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:22:04.615860
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:22:06.463869
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:22:08.891849
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.1.1')
    v2 = Version('1.1.2')
    assert v1 < v2


# Generated at 2022-06-16 23:22:18.118691
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert v < '1.2.4'
    assert v < '1.2.3.1'
    assert v < '1.2.3.0.1'
    assert v < '1.2.3.0.0.1'
    assert v < '1.2.3.0.0.0.1'
    assert v < '1.2.3.0.0.0.0.1'
    assert v < '1.2.3.0.0.0.0.0.1'
    assert v < '1.2.3.0.0.0.0.0.0.1'
    assert v < '1.2.3.0.0.0.0.0.0.0.1'

# Generated at 2022-06-16 23:22:47.104823
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:49.456924
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:22:51.587791
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:22:53.480154
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) == NotImplemented


# Generated at 2022-06-16 23:22:55.060094
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:22:56.568563
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:22:59.329203
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 == v2


# Generated at 2022-06-16 23:23:02.539623
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2
    assert not v1 > v2
    assert not v1 >= v2
    assert not v2 < v1
    assert not v2 <= v1


# Generated at 2022-06-16 23:23:03.852992
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2


# Generated at 2022-06-16 23:23:06.013484
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()
    assert not v == Version("1.0")


# Generated at 2022-06-16 23:23:36.595303
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert v.__le__(None)
    assert not v.__le__(object())

# Generated at 2022-06-16 23:23:40.193798
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)
    assert not (v < v)
    assert v <= v
    assert not (v > v)
    assert v >= v

# Generated at 2022-06-16 23:23:43.494306
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1.__lt__(v2) == NotImplemented

# Generated at 2022-06-16 23:23:45.263422
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:23:46.971220
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2

# Generated at 2022-06-16 23:23:48.926872
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.0.0")
    v2 = Version("2.0.0")
    assert v1 < v2

# Generated at 2022-06-16 23:23:51.167530
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == (v1._cmp(v2) > 0)


# Generated at 2022-06-16 23:23:52.639113
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()
    assert not v == Version('1')


# Generated at 2022-06-16 23:23:56.152767
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert not (v1 < v1)
    assert not (v2 < v1)

# Generated at 2022-06-16 23:23:57.393280
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:24:52.517536
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented

# Generated at 2022-06-16 23:24:53.853453
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(Version())


# Generated at 2022-06-16 23:24:56.521683
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True


# Generated at 2022-06-16 23:25:03.764055
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == Version('1.0')
    assert v1 != 1
    assert v1 != '1.0'
    assert v1 != '2.0'
    assert v1 != '1'
    assert v1 != '1.0.0'
    assert v1 != '1.0.0.0'
    assert v1 != '1.0-0'
    assert v1 != '1.0.post0'
    assert v1 != '1.0c1'
    assert v1 != '1.0a1'

# Generated at 2022-06-16 23:25:06.989189
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) == NotImplemented


# Generated at 2022-06-16 23:25:15.869366
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    v = Version('1.2.3')
    assert v < '1.2.4'
    assert v < '1.2.3.1'
    assert v < '1.2.3a1'
    assert v < '1.2.3.post1'
    assert v < '1.2.3.dev1'
    assert v < '1.2.3.post1.dev1'
    assert v < '1.2.3.post1.dev2'
    assert v < '1.2.3.post1.dev3'
    assert v < '1.2.3.post1.dev4'
    assert v < '1.2.3.post1.dev5'
    assert v < '1.2.3.post1.dev6'


# Generated at 2022-06-16 23:25:17.901887
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v == None
    assert not v == '1.0'

# Generated at 2022-06-16 23:25:22.605834
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2


# Generated at 2022-06-16 23:25:24.207941
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:25:35.066882
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(None)
    assert v.__le__(1)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)
    assert v.__le__(1.0)

# Generated at 2022-06-16 23:27:44.350002
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert v != '1.2.4'
    assert v != Version('1.2.4')

# Generated at 2022-06-16 23:27:46.323486
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:27:52.635685
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.0') < Version('1.1')
    assert Version('1.0') < Version('1.0.1')
    assert Version('1.0') < Version('1.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.0.0.1')
    assert Version('1.0') < Version('1.0.0.0.0.0.0.0.1')

# Generated at 2022-06-16 23:27:55.761267
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:27:58.656529
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:28:00.306565
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:28:03.344433
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2') >= Version('1.2')
    assert Version('1.2') >= '1.2'
    assert not Version('1.2') >= Version('1.3')
    assert not Version('1.2') >= '1.3'

# Generated at 2022-06-16 23:28:07.510390
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert v >= '1.2.2'
    assert v >= '1.2'
    assert v >= '1'
    assert not (v >= '1.2.4')
    assert not (v >= '1.3')
    assert not (v >= '2')



# Generated at 2022-06-16 23:28:09.324174
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented

# Generated at 2022-06-16 23:28:15.999224
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 <= v2
    assert v1 <= '1.0'
    assert v1 <= '1.1'
    assert not v1 <= '0.9'
    assert not v1 <= '1.0a'
    assert not v1 <= '1.0.post1'
    assert not v1 <= '1.0.dev1'
    assert not v1 <= '1.0.dev1+sha.1234'
    assert not v1 <= '1.0.dev1+sha.1234.dirty'
    assert not v1 <= '1.0.post1.dev1'
    assert not v1 <= '1.0.post1.dev1+sha.1234'