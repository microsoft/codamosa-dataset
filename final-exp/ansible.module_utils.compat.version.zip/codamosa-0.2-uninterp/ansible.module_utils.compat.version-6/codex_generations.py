

# Generated at 2022-06-16 23:20:08.357687
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3')
    assert str(v) == '1.2.3'
    v = StrictVersion('1.2.3a1')
    assert str(v) == '1.2.3a1'
    v = StrictVersion('1.2.3b1')
    assert str(v) == '1.2.3b1'
    v = StrictVersion('1.2.3b0')
    assert str(v) == '1.2.3b0'
    v = StrictVersion('1.2.3b9')
    assert str(v) == '1.2.3b9'
    v = StrictVersion('1.2.3b10')
    assert str(v) == '1.2.3b10'
    v = Strict

# Generated at 2022-06-16 23:20:18.821673
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    v = Version('1.0')
    assert v <= '1.0'
    assert v <= '1.0.0'
    assert v <= '1.0.0.0'
    assert v <= '1.0.0.0.0'
    assert v <= '1.0.0.0.0.0'
    assert v <= '1.0.0.0.0.0.0'
    assert v <= '1.0.0.0.0.0.0.0'
    assert v <= '1.0.0.0.0.0.0.0.0'
    assert v <= '1.0.0.0.0.0.0.0.0.0'

# Generated at 2022-06-16 23:20:21.070694
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:28.967013
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 > v2
    assert not v1 >= v2
    assert not v2 < v1
    assert not v2 <= v1
    assert v1 == v1
    assert v1 <= v1
    assert v1 >= v1
    assert not v1 != v1
    assert not v1 < v1
    assert not v1 > v1

# Generated at 2022-06-16 23:20:30.393254
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:20:32.058958
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v)

# Generated at 2022-06-16 23:20:42.424389
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert v.__le__(Version('1'))
    assert v.__le__(Version('2'))
    assert v.__le__(Version('3'))
    assert v.__le__(Version('4'))
    assert v.__le__(Version('5'))
    assert v.__le__(Version('6'))
    assert v.__le__(Version('7'))
    assert v.__le__(Version('8'))
    assert v.__le__(Version('9'))
    assert v.__le__(Version('10'))
    assert v.__le__(Version('11'))
    assert v.__le__(Version('12'))
    assert v

# Generated at 2022-06-16 23:20:43.793160
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented


# Generated at 2022-06-16 23:20:45.476061
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:20:46.779257
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:20:58.005495
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 <= v2


# Generated at 2022-06-16 23:21:01.336685
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v2 > v1
    assert not v1 > v2
    assert not v1 > v1

# Generated at 2022-06-16 23:21:02.758660
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:21:05.492896
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2
    assert not (v1 < v1)
    assert not (v2 < v1)

# Generated at 2022-06-16 23:21:07.748818
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:21:10.884306
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2


# Generated at 2022-06-16 23:21:12.852929
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:21:14.538684
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)


# Generated at 2022-06-16 23:21:19.821342
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1


# Generated at 2022-06-16 23:21:20.571569
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:21:44.169152
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False

# Generated at 2022-06-16 23:21:46.068521
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:21:54.865953
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.5.1')
    assert lv.version == [1, '5', 1]
    lv.parse('1.5.2b2')
    assert lv.version == [1, '5', '2b2']
    lv.parse('161')
    assert lv.version == [161]
    lv.parse('3.10a')
    assert lv.version == [3, '10a']
    lv.parse('8.02')
    assert lv.version == [8, '02']
    lv.parse('3.4j')
    assert lv.version == [3, '4j']
    lv.parse('1996.07.12')

# Generated at 2022-06-16 23:21:58.926327
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert not (Version('1.1') <= Version('1.0'))

# Generated at 2022-06-16 23:22:00.803032
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:11.751630
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.1') <= Version('1.2')
    assert Version('1.0') <= Version('2.0')
    assert Version('1.0') <= Version('1.0.post1')
    assert Version('1.0.post1') <= Version('1.0.post1')
    assert Version('1.0.post1') <= Version('1.0.post2')
    assert Version('1.0.post1') <= Version('1.1')
    assert Version('1.0.post1') <= Version('2.0')
    assert Version('1.0.post1') <= Version('1.0.dev1')

# Generated at 2022-06-16 23:22:13.063014
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:22:21.026188
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == Version('1.0')
    assert v1 != '1.0'
    assert v1 != 1.0
    assert v1 != 1
    assert v1 != (1, 0)
    assert v1 != [1, 0]
    assert v1 != {'major': 1, 'minor': 0}
    assert v1 != object()
    assert v1 != None
    assert v1 != NotImplemented
    assert v1 != Ellipsis
    assert v1 != b'1.0'

# Generated at 2022-06-16 23:22:23.295444
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:22:25.037994
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2

# Generated at 2022-06-16 23:22:38.372461
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:22:45.608788
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented
    assert v.__ge__(1) == NotImplemented
    assert v.__ge__(1.0) == NotImplemented
    assert v.__ge__('') == NotImplemented
    assert v.__ge__('1') == NotImplemented
    assert v.__ge__('1.0') == NotImplemented
    assert v.__ge__(Version()) == True
    assert v.__ge__(StrictVersion()) == True
    assert v.__ge__(LooseVersion()) == True
    assert v.__ge__(LegacyVersion()) == True
    assert v.__ge__(ComparableVersion()) == True
    assert v.__ge__

# Generated at 2022-06-16 23:22:56.828578
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Test for method __lt__ (of class Version)
    v = Version('1.2.3')
    assert v < '1.2.4'
    assert v < '1.2.3.1'
    assert v < '1.2.3-1'
    assert v < '1.2.3-1.1'
    assert v < '1.2.3-1.1.1'
    assert v < '1.2.3-1.1.1.1'
    assert v < '1.2.3-1.1.1.1.1'
    assert v < '1.2.3-1.1.1.1.1.1'
    assert v < '1.2.3-1.1.1.1.1.1.1'

# Generated at 2022-06-16 23:22:58.673293
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:23:00.863381
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 >= v2


# Generated at 2022-06-16 23:23:02.496223
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:23:03.290536
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:23:04.828914
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:23:06.215542
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:23:12.958756
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v
    assert v >= '0'
    assert v >= '0.0'
    assert v >= '0.0.0'
    assert v >= '0.0.0.0'
    assert v >= '0.0.0.0.0'
    assert v >= '0.0.0.0.0.0'
    assert v >= '0.0.0.0.0.0.0'
    assert v >= '0.0.0.0.0.0.0.0'
    assert v >= '0.0.0.0.0.0.0.0.0'
    assert v >= '0.0.0.0.0.0.0.0.0.0'

# Generated at 2022-06-16 23:23:26.398888
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-16 23:23:28.886253
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2

# Generated at 2022-06-16 23:23:36.254396
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert not v == '1.2.4'
    assert not v == '1.2.3.4'
    assert not v == '1.2.3.4.5'
    assert not v == '1.2.3.4.5.6'
    assert not v == '1.2.3.4.5.6.7'
    assert not v == '1.2.3.4.5.6.7.8'
    assert not v == '1.2.3.4.5.6.7.8.9'
    assert not v == '1.2.3.4.5.6.7.8.9.10'

# Generated at 2022-06-16 23:23:37.720492
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:23:39.545624
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:23:41.453693
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:23:48.732528
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__lt__(v2) == False
    assert v1.__lt__(v2) == False
    assert v1.__lt__(v2) == False
    assert v1.__lt__(v2) == False
    assert v1.__lt__(v2) == False
    assert v1.__lt__(v2) == False
    assert v1.__lt__(v2) == False
    assert v1.__lt__(v2) == False
    assert v1.__lt__(v2) == False
    assert v1.__lt__(v2) == False
    assert v1.__lt__(v2) == False
    assert v1.__lt__

# Generated at 2022-06-16 23:23:50.290284
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2

# Generated at 2022-06-16 23:23:54.589032
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert not (v1 < v1)
    assert not (v2 < v1)

# Generated at 2022-06-16 23:23:58.156418
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert v == '1.0'
    assert v != '1.1'
    assert v != 1.0
    assert v != 1
    assert v != None
    assert v != object()


# Generated at 2022-06-16 23:24:24.830570
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:24:26.901675
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)

# Generated at 2022-06-16 23:24:28.738182
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:24:32.364215
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(Version())
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:24:33.579306
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True


# Generated at 2022-06-16 23:24:35.891783
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:24:37.240695
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:24:46.146444
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__(Version()) == False
    assert v.__gt__(Version('1.0')) == False
    assert v.__gt__(Version('0.9')) == True
    assert v.__gt__(Version('0.9.0')) == True
    assert v.__gt__(Version('0.9.1')) == False
    assert v.__gt__(Version('0.9.1.0')) == False
    assert v.__gt__(Version('0.9.1.1')) == False
    assert v.__gt__(Version('0.9.1.1.0')) == False

# Generated at 2022-06-16 23:24:46.944961
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version()


# Generated at 2022-06-16 23:24:50.526790
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented

# Generated at 2022-06-16 23:25:18.783441
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert not v >= '1.2.4'
    assert v >= '1.2.3a1'
    assert not v >= '1.2.3a2'
    assert v >= '1.2.3.dev1'
    assert not v >= '1.2.3.dev2'
    assert v >= '1.2.3.post1'
    assert not v >= '1.2.3.post2'
    assert v >= '1.2.3.post1.dev1'
    assert not v >= '1.2.3.post1.dev2'
    assert v >= '1.2.3.post1.dev1'

# Generated at 2022-06-16 23:25:21.303359
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:25:22.606666
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:25:27.686030
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == v1
    assert v2 == v2


# Generated at 2022-06-16 23:25:29.633570
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:25:39.428640
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__

# Generated at 2022-06-16 23:25:40.702404
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:25:43.433757
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v2 > v1

# Generated at 2022-06-16 23:25:44.814930
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:25:50.585961
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.0') > Version('0.9')
    assert Version('1.0') > '0.9'
    assert not Version('1.0') > Version('1.0')
    assert not Version('1.0') > '1.0'
    assert not Version('0.9') > Version('1.0')
    assert not Version('0.9') > '1.0'



# Generated at 2022-06-16 23:26:48.428460
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented

# Generated at 2022-06-16 23:26:50.826600
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)

# Generated at 2022-06-16 23:26:52.201203
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:26:54.360307
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version("1.0")
    v2 = Version("2.0")
    assert v1 >= v2

# Generated at 2022-06-16 23:26:56.251822
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True


# Generated at 2022-06-16 23:27:05.366214
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented
    assert v.__ge__(1) == NotImplemented
    assert v.__ge__(1.0) == NotImplemented
    assert v.__ge__(1.0+0j) == NotImplemented
    assert v.__ge__('') == NotImplemented
    assert v.__ge__('abc') == NotImplemented
    assert v.__ge__(()) == NotImplemented
    assert v.__ge__([]) == NotImplemented
    assert v.__ge__({}) == NotImplemented
    assert v.__ge__(object()) == NotImplemented
    assert v.__ge__(object) == NotImplemented


# Generated at 2022-06-16 23:27:06.897014
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:27:17.483868
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1.__gt__(v2)
    assert not v1

# Generated at 2022-06-16 23:27:19.047147
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:27:20.407922
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:29:40.432593
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:29:41.432980
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:29:44.791984
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v
    assert not v < v
    assert v <= v
    assert not v > v
    assert v >= v
