

# Generated at 2022-06-16 23:19:53.406260
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__('') is NotImplemented
    assert v.__gt__(Version()) == 0

# Generated at 2022-06-16 23:20:04.065446
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= '1.2.3'
    assert v >= '1.2.3.4'
    assert v >= '1.2.3.4.5'
    assert v >= '1.2.3.4.5.6'
    assert v >= '1.2.3.4.5.6.7'
    assert v >= '1.2.3.4.5.6.7.8'
    assert v >= '1.2.3.4.5.6.7.8.9'
    assert v >= '1.2.3.4.5.6.7.8.9.10'
    assert v >= '1.2.3.4.5.6.7.8.9.10.11'

# Generated at 2022-06-16 23:20:15.367338
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.0').__str__() == '1.0'
    assert StrictVersion('1.0.0').__str__() == '1.0'
    assert StrictVersion('1.0a1').__str__() == '1.0a1'
    assert StrictVersion('1.0b1').__str__() == '1.0b1'
    assert StrictVersion('1.0.0a1').__str__() == '1.0a1'
    assert StrictVersion('1.0.0b1').__str__() == '1.0b1'
    assert StrictVersion('1.0.0.0a1').__str__() == '1.0.0a1'
    assert StrictVersion('1.0.0.0b1').__str__()

# Generated at 2022-06-16 23:20:17.107625
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:28.858040
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.2.3')
    assert lv.version == [1, 2, 3]
    lv.parse('1.2.3.4')
    assert lv.version == [1, 2, 3, 4]
    lv.parse('1.2.3.4.5')
    assert lv.version == [1, 2, 3, 4, 5]
    lv.parse('1.2.3.4.5.6')
    assert lv.version == [1, 2, 3, 4, 5, 6]
    lv.parse('1.2.3.4.5.6.7')
    assert lv.version == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-16 23:20:35.685751
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3a4')
    assert str(v) == '1.2.3a4'
    v = StrictVersion('1.2.3')
    assert str(v) == '1.2.3'
    v = StrictVersion('1.2')
    assert str(v) == '1.2'
    v = StrictVersion('1')
    assert str(v) == '1'


# Generated at 2022-06-16 23:20:42.117812
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3')
    assert str(v) == '1.2.3'
    v = StrictVersion('1.2')
    assert str(v) == '1.2'
    v = StrictVersion('1.2.3a1')
    assert str(v) == '1.2.3a1'
    v = StrictVersion('1.2.3b1')
    assert str(v) == '1.2.3b1'


# Generated at 2022-06-16 23:20:49.833954
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("1.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion("1.0.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion("1.0a1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion("1.0.0a1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion("1.0b3")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('b', 3)

    v

# Generated at 2022-06-16 23:21:01.571320
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2').__str__() == '1.2'
    assert StrictVersion('1.2.3a1').__str__() == '1.2.3a1'
    assert StrictVersion('1.2.3b1').__str__() == '1.2.3b1'
    assert StrictVersion('1.2.3a1').__str__() == '1.2.3a1'
    assert StrictVersion('1.2.3b1').__str__() == '1.2.3b1'
    assert StrictVersion('1.2.3a1').__str__() == '1.2.3a1'

# Generated at 2022-06-16 23:21:13.241799
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None

    v = StrictVersion('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)

    v = StrictVersion('1.2.3b5')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 5)

    v = StrictVersion('1.2')
    assert v.version == (1, 2, 0)
    assert v.prerelease is None

    v = StrictVersion('1.2a3')
    assert v.version == (1, 2, 0)
    assert v.prerelease == ('a', 3)



# Generated at 2022-06-16 23:21:20.570704
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()


# Generated at 2022-06-16 23:21:22.116397
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:21:23.638053
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:21:25.088922
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:21:27.794086
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:21:36.313043
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert not (v == '1.2.4')
    assert not (v == Version('1.2.4'))
    assert not (v == '1.2')
    assert not (v == Version('1.2'))
    assert not (v == '1.2.3.4')
    assert not (v == Version('1.2.3.4'))
    assert not (v == '1.2.3dev')
    assert not (v == Version('1.2.3dev'))
    assert not (v == '1.2.3.dev')
    assert not (v == Version('1.2.3.dev'))

# Generated at 2022-06-16 23:21:38.064701
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:21:41.067169
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v
    assert not v < v
    assert v <= v
    assert not v > v
    assert v >= v

# Generated at 2022-06-16 23:21:43.320967
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:21:49.161561
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2.3') >= '1.2.3'
    assert Version('1.2.3') >= Version('1.2.3')
    assert not Version('1.2.3') >= '1.2.4'
    assert not Version('1.2.3') >= Version('1.2.4')

# Generated at 2022-06-16 23:22:04.003415
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:22:10.114062
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.0') > Version('0.9')
    assert Version('1.0') > '0.9'
    assert not Version('1.0') > Version('1.0')
    assert not Version('1.0') > '1.0'
    assert not Version('0.9') > Version('1.0')
    assert not Version('0.9') > '1.0'

# Generated at 2022-06-16 23:22:11.466133
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:22:14.580544
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.0")
    v2 = Version("2.0")
    assert v1 < v2
    assert not (v1 < v1)
    assert not (v2 < v1)

# Generated at 2022-06-16 23:22:15.647969
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:22:17.535838
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:22:19.097614
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:21.006913
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 >= v2


# Generated at 2022-06-16 23:22:27.140468
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.2.3') == Version('1.2.3')
    assert not Version('1.2.3') == Version('1.2.4')
    assert not Version('1.2.3') == '1.2.3'
    assert not Version('1.2.3') == '1.2.4'

# Generated at 2022-06-16 23:22:29.337050
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:23:03.810623
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not v1 < v2
    assert not v2 < v1
    v2 = Version('1.2.4')
    assert v1 < v2
    assert not v2 < v1
    v2 = Version('1.3.3')
    assert v1 < v2
    assert not v2 < v1
    v2 = Version('2.2.3')
    assert v1 < v2
    assert not v2 < v1
    v2 = Version('1.2.3.4')
    assert v1 < v2
    assert not v2 < v1
    v2 = Version('1.2.3.4.5')
    assert v1 < v2
    assert not v2 < v1

# Generated at 2022-06-16 23:23:05.698454
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:23:07.474815
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented


# Generated at 2022-06-16 23:23:20.053485
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == Version('1.0')
    assert v1 != '1.0'
    assert v1 != 1.0
    assert v1 != None
    assert v1 != 1

# Generated at 2022-06-16 23:23:21.190715
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:23:23.555733
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:23:34.065270
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse("1.5.1")
    assert lv.version == [1, 5, 1]
    lv.parse("1.5.2b2")
    assert lv.version == [1, 5, 2, 'b', 2]
    lv.parse("161")
    assert lv.version == [161]
    lv.parse("3.10a")
    assert lv.version == [3, 10, 'a']
    lv.parse("8.02")
    assert lv.version == [8, 2]
    lv.parse("3.4j")
    assert lv.version == [3, 4, 'j']
    lv.parse("1996.07.12")
    assert lv.version == [1996, 7, 12]

# Generated at 2022-06-16 23:23:36.243357
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:23:38.056446
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2

# Generated at 2022-06-16 23:23:39.998040
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:24:31.563335
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:24:33.516491
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:24:43.311195
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2.3') >= Version('1.2.3')
    assert Version('1.2.3') >= '1.2.3'
    assert not Version('1.2.3') >= Version('1.2.4')
    assert not Version('1.2.3') >= '1.2.4'
    assert not Version('1.2.3') >= Version('1.2.3.1')
    assert not Version('1.2.3') >= '1.2.3.1'
    assert not Version('1.2.3') >= Version('1.2.3.0')
    assert not Version('1.2.3') >= '1.2.3.0'
    assert not Version('1.2.3') >= Version('1.2.2')

# Generated at 2022-06-16 23:24:54.341771
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(v2) == NotImplemented

# Generated at 2022-06-16 23:24:56.622747
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:24:57.910192
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:24:59.465486
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:25:01.855404
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:25:04.612523
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert not v.__le__(None)

# Generated at 2022-06-16 23:25:13.821696
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2.3') <= Version('1.2.3')
    assert Version('1.2.3') <= Version('1.2.4')
    assert Version('1.2.3') <= Version('1.3.3')
    assert Version('1.2.3') <= Version('2.2.3')
    assert not (Version('1.2.3') <= Version('1.2.2'))
    assert not (Version('1.2.3') <= Version('1.1.3'))
    assert not (Version('1.2.3') <= Version('0.2.3'))


# Generated at 2022-06-16 23:26:09.876747
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2

# Generated at 2022-06-16 23:26:13.731097
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v2 > v1
    assert not v1 > v2
    assert not v1 > v1


# Generated at 2022-06-16 23:26:20.693599
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v
    assert v >= None
    assert v >= ''
    assert v >= '0'
    assert v >= '0.0'
    assert v >= '0.0.0'
    assert v >= '0.0.0.0'
    assert v >= '0.0.0.0.0'
    assert v >= '0.0.0.0.0.0'
    assert v >= '0.0.0.0.0.0.0'
    assert v >= '0.0.0.0.0.0.0.0'
    assert v >= '0.0.0.0.0.0.0.0.0'
    assert v >= '0.0.0.0.0.0.0.0.0.0'

# Generated at 2022-06-16 23:26:23.477325
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented

# Generated at 2022-06-16 23:26:25.245656
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented


# Generated at 2022-06-16 23:26:34.630574
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v.parse("1.2.3")
    assert v <= "1.2.3"
    assert v <= "1.2.4"
    assert not v <= "1.2.2"
    assert not v <= "1.1.3"
    assert not v <= "0.2.3"
    assert v <= "1.2.3a"
    assert v <= "1.2.3b"
    assert not v <= "1.2.3-a"
    assert not v <= "1.2.3-b"
    assert not v <= "1.2.3-1"
    assert not v <= "1.2.3-2"
    assert v <= "1.2.3.0"
    assert v <= "1.2.3.1"
    assert not v

# Generated at 2022-06-16 23:26:39.258888
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert v.__le__(Version('1.0'))
    assert not v.__le__(Version('0.9'))


# Generated at 2022-06-16 23:26:40.825193
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 <= v2

# Generated at 2022-06-16 23:26:51.513702
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented
    assert v.__lt__(1) is NotImplemented
    assert v.__lt__(1.0) is NotImplemented
    assert v.__lt__(1.0j) is NotImplemented
    assert v.__lt__(1.0 + 1.0j) is NotImplemented
    assert v.__lt__('') is NotImplemented
    assert v.__lt__('1') is NotImplemented
    assert v.__lt__(b'1') is NotImplemented
    assert v.__lt__(u'1') is NotImplemented
    assert v.__lt__(()) is NotImplemented
    assert v.__lt__([]) is NotImplemented
    assert v

# Generated at 2022-06-16 23:27:01.576571
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v1 != v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 < '2.0'
    assert v1 <= '2.0'
    assert v1 != '2.0'
    assert '2.0' > v1
    assert '2.0' >= v1
    assert v1 < '2.0.0'
    assert v1 <= '2.0.0'
    assert v1 != '2.0.0'
    assert '2.0.0' > v1
    assert '2.0.0' >= v1
    assert v1 < '2.0.0.0'

# Generated at 2022-06-16 23:28:13.311620
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not v1.__gt__(v2)
    assert not v1.__gt__('1.2.3')

# Generated at 2022-06-16 23:28:16.247823
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:28:17.645331
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:28:18.708287
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:28:25.011377
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.5.1')
    assert lv.version == [1, 5, 1]
    lv.parse('1.5.2b2')
    assert lv.version == [1, 5, 2, 'b', 2]
    lv.parse('161')
    assert lv.version == [161]
    lv.parse('3.10a')
    assert lv.version == [3, 10, 'a']
    lv.parse('8.02')
    assert lv.version == [8, 2]
    lv.parse('3.4j')
    assert lv.version == [3, 4, 'j']
    lv.parse('1996.07.12')
    assert lv.version == [1996, 7, 12]

# Generated at 2022-06-16 23:28:26.234867
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:28:34.890835
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__gt__(v2) == False
    assert v1.__gt__('1.2.3') == False
    assert v1.__gt__('1.2.4') == False
    assert v1.__gt__('1.3.3') == False
    assert v1.__gt__('2.2.3') == False
    assert v1.__gt__('1.2.2') == True
    assert v1.__gt__('1.1.3') == True
    assert v1.__gt__('0.2.3') == True


# Generated at 2022-06-16 23:28:39.901824
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert not (Version('1.1') <= Version('1.0'))

# Generated at 2022-06-16 23:28:52.736224
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2
    assert not (v1 < v2)
    assert v1 <= v2
    assert not (v1 > v2)
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert not (v1 >= v2)
    assert v1 < v2
    assert v1 <= v2
    assert not (v1 > v2)
    v1 = Version('1.2.3')
    v2 = Version('1.2.2')
    assert v1 >= v2
    assert not (v1 < v2)
    assert not (v1 <= v2)
    assert v1 > v2

# Generated at 2022-06-16 23:28:54.753775
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
