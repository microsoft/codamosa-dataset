

# Generated at 2022-06-16 23:20:00.966782
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Test for method __gt__ of class Version
    #
    # This test is not very good, because it only tests the
    # comparison of two specific instances.  It should be
    # expanded to test comparison of instances of different
    # classes, and comparison of instances of the same class
    # with different attributes.
    #
    # XXXX
    #
    v1 = StrictVersion("1.2.3a1")
    v2 = StrictVersion("1.2.3c1")
    assert v1 < v2
    assert v2 > v1
    assert v1 <= v1
    assert v1 >= v1
    assert v1 == v1
    assert v1 != v2



# Generated at 2022-06-16 23:20:12.756368
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert v == '0'
    assert v == 0
    assert v == '0.0'
    assert v == 0.0
    assert v == '0.0.0'
    assert v == 0.0
    assert v == '0.0.0.0'
    assert v == 0.0
    assert v == '0.0.0.0.0'
    assert v == 0.0
    assert v == '0.0.0.0.0.0'
    assert v == 0.0
    assert v == '0.0.0.0.0.0.0'
    assert v == 0.0
    assert v == '0.0.0.0.0.0.0.0'
    assert v == 0.

# Generated at 2022-06-16 23:20:14.872843
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 <= v2


# Generated at 2022-06-16 23:20:17.643077
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)
    assert not (v < v)
    assert v <= v
    assert not (v > v)
    assert v >= v

# Generated at 2022-06-16 23:20:21.218992
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert not v.__ge__(1)


# Generated at 2022-06-16 23:20:32.782324
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None

    v = StrictVersion('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)

    v = StrictVersion('1.2.3b4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 4)

    v = StrictVersion('1.2.3.4')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None

    v = StrictVersion('1.2.3.4a5')
    assert v.version == (1, 2, 3)
    assert v.pre

# Generated at 2022-06-16 23:20:35.257681
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:20:37.272632
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:20:44.694869
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.2.3')
    assert lv.version == [1, 2, 3]
    lv.parse('1.2.3.4')
    assert lv.version == [1, 2, 3, 4]
    lv.parse('1.2.3.4.5')
    assert lv.version == [1, 2, 3, 4, 5]
    lv.parse('1.2.3.4.5.6')
    assert lv.version == [1, 2, 3, 4, 5, 6]
    lv.parse('1.2.3.4.5.6.7')
    assert lv.version == [1, 2, 3, 4, 5, 6, 7]

# Generated at 2022-06-16 23:20:56.643104
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert v == Version('1.0')
    assert v == '1.0'
    assert not v == '1.1'
    assert not v == '1.0.1'
    assert not v == '2.0'
    assert not v == '1.0.0'
    assert not v == '1.0.0.0'
    assert not v == '1.0.0.0.0'
    assert not v == '1.0.0.0.0.0'
    assert not v == '1.0.0.0.0.0.0'
    assert not v == '1.0.0.0.0.0.0.0'

# Generated at 2022-06-16 23:21:17.392040
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2
    assert v2 >= v1
    assert v1 >= '1.2.3'
    assert v2 >= '1.2.3'
    assert '1.2.3' >= v1
    assert '1.2.3' >= v2
    assert v1 >= '1.2.4'
    assert v2 >= '1.2.4'
    assert '1.2.4' >= v1
    assert '1.2.4' >= v2
    assert v1 >= '1.3.3'
    assert v2 >= '1.3.3'
    assert '1.3.3' >= v1
    assert '1.3.3' >= v2
   

# Generated at 2022-06-16 23:21:26.800841
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__("1") is NotImplemented
    assert v.__gt__(Version("1")) is NotImplemented
    assert v.__gt__(StrictVersion("1")) is NotImplemented
    assert v.__gt__(LooseVersion("1")) is NotImplemented
    assert v.__gt__(LegacyVersion("1")) is NotImplemented
    assert v.__gt__(ComparableVersion("1")) is NotImplemented


# Generated at 2022-06-16 23:21:29.327042
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert not v.__le__(None)


# Generated at 2022-06-16 23:21:37.350556
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not (v1 < v2)
    assert not (v1 < '1.2.3')
    assert not (v1 < '1.2.4')
    assert not (v1 < '1.3.3')
    assert not (v1 < '2.2.3')
    assert v1 < '1.2.3.post1'
    assert v1 < '1.2.3.dev1'
    assert v1 < '1.2.3a1'
    assert v1 < '1.2.3b1'
    assert v1 < '1.2.3c1'
    assert v1 < '1.2.3rc1'

# Generated at 2022-06-16 23:21:38.865839
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:21:46.480169
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(v.__class__(v))
    assert v.__ge__(v.__class__(str(v)))
    assert v.__ge__(str(v))
    assert not v.__ge__(None)
    assert not v.__ge__(object())
    assert not v.__ge__(1)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1j)
    assert not v.__ge__(())
    assert not v.__ge__([])
    assert not v.__ge__({})
    assert not v.__ge__(set())
    assert not v.__ge__(frozenset())

# Generated at 2022-06-16 23:21:48.573394
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:21:50.315752
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:21:51.801715
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented


# Generated at 2022-06-16 23:22:03.891184
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)
    assert not v.__ge__(1)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0)
    assert not v

# Generated at 2022-06-16 23:22:20.727411
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:23.746154
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented

# Generated at 2022-06-16 23:22:34.902450
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)
    assert not v.__ge__(1)
    assert not v.__ge__('1')
    assert not v.__ge__('')
    assert not v.__ge__('a')
    assert not v.__ge__('1.0')
    assert not v.__ge__('1.0.0')
    assert not v.__ge__('1.0.0.0')
    assert not v.__ge__('1.0.0.0.0')
    assert not v.__ge__('1.0.0.0.0.0')
    assert not v.__ge__('1.0.0.0.0.0.0')
    assert not v.__ge__

# Generated at 2022-06-16 23:22:36.538841
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:38.200974
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True


# Generated at 2022-06-16 23:22:39.797457
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True


# Generated at 2022-06-16 23:22:41.139025
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:22:42.909597
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True


# Generated at 2022-06-16 23:22:44.289773
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:22:52.745660
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented
    assert v.__ge__(1) == NotImplemented
    assert v.__ge__("1") == NotImplemented
    assert v.__ge__(Version("1")) == NotImplemented
    assert v.__ge__(StrictVersion("1")) == NotImplemented
    assert v.__ge__(LooseVersion("1")) == NotImplemented


# Generated at 2022-06-16 23:23:22.133133
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-16 23:23:26.252682
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)
    assert not (v < v)
    assert v <= v
    assert not (v > v)
    assert v >= v

# Generated at 2022-06-16 23:23:33.310147
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert not v1 == v2
    assert not v1 > v2
    assert not v1 >= v2
    assert not v2 < v1
    assert not v2 <= v1
    assert not v2 == v1
    assert not v2 != v1

# Generated at 2022-06-16 23:23:36.348672
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-16 23:23:47.925174
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= '1.0'
    assert not (Version('1.0') >= Version('1.1'))
    assert not (Version('1.0') >= '1.1')
    assert not (Version('1.0') >= Version('2.0'))
    assert not (Version('1.0') >= '2.0')
    assert not (Version('1.0') >= Version('1.0.post1'))
    assert not (Version('1.0') >= '1.0.post1')
    assert Version('1.0.post1') >= Version('1.0')
    assert Version('1.0.post1') >= '1.0'

# Generated at 2022-06-16 23:23:50.195858
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()
    assert not v == Version('1.0')
    assert not v == '1.0'

# Generated at 2022-06-16 23:23:52.604125
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    assert v1 <= v2


# Generated at 2022-06-16 23:23:53.974696
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True


# Generated at 2022-06-16 23:23:55.755934
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:24:00.922812
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.2.3')
    assert v <= '1.2.3'
    assert v <= '1.2.4'
    assert v <= '1.3.3'
    assert v <= '2.2.3'
    assert not (v <= '0.2.3')
    assert not (v <= '1.1.3')
    assert not (v <= '1.2.2')


# Generated at 2022-06-16 23:24:32.358980
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented


# Generated at 2022-06-16 23:24:33.832198
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:24:36.264040
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2

# Generated at 2022-06-16 23:24:37.610170
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True

# Generated at 2022-06-16 23:24:39.318961
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented

# Generated at 2022-06-16 23:24:41.055691
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True


# Generated at 2022-06-16 23:24:51.361822
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented
    assert v.__eq__('') is NotImplemented
    assert v.__eq__(0) is NotImplemented
    assert v.__eq__(0.0) is NotImplemented
    assert v.__eq__(()) is NotImplemented
    assert v.__eq__([]) is NotImplemented
    assert v.__eq__({}) is NotImplemented
    assert v.__eq__(set()) is NotImplemented
    assert v.__eq__(frozenset()) is NotImplemented
    assert v.__eq__(object()) is NotImplemented
    assert v.__eq__(Version()) is NotImplemented
    assert v.__eq__(StrictVersion()) is NotIm

# Generated at 2022-06-16 23:24:52.786810
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:24:55.487370
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2


# Generated at 2022-06-16 23:25:03.188524
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert v1 <= v2
    assert not v1 == v2
    assert not v1 > v2
    assert not v1 >= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v2 == v1
    assert not v2 < v1
    assert not v2 <= v1
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not v1 < v2
    assert v1 <= v2
    assert v1 == v2
    assert not v1 > v2
    assert v1 >= v2
    assert not v2 < v1
    assert v2 <= v1

# Generated at 2022-06-16 23:26:01.057381
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:26:03.507827
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v == None
    assert not v == '1.0'


# Generated at 2022-06-16 23:26:07.767407
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    class Version___gt__TestCase(unittest.TestCase):
        def test_1(self):
            v1 = Version()
            v2 = Version()
            self.assertFalse(v1 > v2)
    unittest.main()


# Generated at 2022-06-16 23:26:14.225494
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.0') > Version('0.9')
    assert Version('1.0') > '0.9'
    assert not Version('1.0') > Version('1.0')
    assert not Version('1.0') > '1.0'
    assert not Version('0.9') > Version('1.0')
    assert not Version('0.9') > '1.0'


# Generated at 2022-06-16 23:26:15.760692
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:26:18.479743
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 <= v2

# Generated at 2022-06-16 23:26:20.818137
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2

# Generated at 2022-06-16 23:26:22.481176
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:26:24.144164
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:26:25.908884
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented


# Generated at 2022-06-16 23:28:45.924414
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:28:47.764323
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:28:49.974501
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 == v2


# Generated at 2022-06-16 23:28:51.764647
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:28:54.155131
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:29:03.677354
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert v != '1.2.4'
    assert v != Version('1.2.4')
    assert v != '1.2'
    assert v != Version('1.2')
    assert v != '1.2.3.4'
    assert v != Version('1.2.3.4')
    assert v != '1.2.3-4'
    assert v != Version('1.2.3-4')
    assert v != '1.2.3.4-5'
    assert v != Version('1.2.3.4-5')
    assert v != '1.2.3-4.5'

# Generated at 2022-06-16 23:29:05.034992
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2


# Generated at 2022-06-16 23:29:06.694358
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v == None
    assert not v == '1.0'


# Generated at 2022-06-16 23:29:07.775763
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:29:13.004284
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(1) == NotImplemented