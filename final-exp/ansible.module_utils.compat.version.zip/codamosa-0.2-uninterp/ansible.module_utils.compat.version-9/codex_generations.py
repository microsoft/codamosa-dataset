

# Generated at 2022-06-16 23:19:59.285487
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('1.0')
    assert v > '0.9'
    assert not v > '1.0'
    assert not v > '1.1'

# Generated at 2022-06-16 23:20:00.865270
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:20:03.406896
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:20:05.380591
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented

# Generated at 2022-06-16 23:20:07.742424
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:20:18.277455
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.0').__str__() == '1.0'
    assert StrictVersion('1.0.0').__str__() == '1.0'
    assert StrictVersion('1.0a1').__str__() == '1.0a1'
    assert StrictVersion('1.0b1').__str__() == '1.0b1'
    assert StrictVersion('1.0.0a1').__str__() == '1.0a1'
    assert StrictVersion('1.0.0b1').__str__() == '1.0b1'
    assert StrictVersion('1.0.1a1').__str__() == '1.0.1a1'

# Generated at 2022-06-16 23:20:29.042436
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__

# Generated at 2022-06-16 23:20:31.022290
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:20:33.220221
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.2.3a4")
    assert str(v) == "1.2.3a4"


# Generated at 2022-06-16 23:20:36.744969
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v
    assert not v < v
    assert v <= v
    assert not v > v
    assert v >= v


# Generated at 2022-06-16 23:20:45.308485
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:20:46.552477
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:20:51.585859
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert not (v1 < v1)
    assert not (v2 < v1)

# Generated at 2022-06-16 23:20:53.419092
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True


# Generated at 2022-06-16 23:20:55.561074
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v2 > v1


# Generated at 2022-06-16 23:20:57.527507
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:20:59.173881
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:21:00.523991
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v == None

# Generated at 2022-06-16 23:21:03.238606
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert not v1 < v1
    assert not v2 < v1


# Generated at 2022-06-16 23:21:04.025417
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version()


# Generated at 2022-06-16 23:21:19.148370
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False

# Generated at 2022-06-16 23:21:21.068053
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented

# Generated at 2022-06-16 23:21:25.718579
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert not (v != v)
    assert not (v != Version())
    assert not (v == None)
    assert v != None
    assert not (v == '1.0')
    assert v != '1.0'


# Generated at 2022-06-16 23:21:34.986320
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= '1.0'
    assert Version('1.0') >= '1.0.dev0'
    assert Version('1.0') >= '1.0.dev1'
    assert Version('1.0') >= '1.0.dev2'
    assert Version('1.0') >= '1.0.dev3'
    assert Version('1.0') >= '1.0.dev4'
    assert Version('1.0') >= '1.0.dev5'
    assert Version('1.0') >= '1.0.dev6'
    assert Version('1.0') >= '1.0.dev7'
    assert Version('1.0') >= '1.0.dev8'

# Generated at 2022-06-16 23:21:45.180013
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert v < '1.2.4'
    assert v < '1.2.3.4'
    assert v < '1.2.3-4'
    assert v < '1.2.3.post4'
    assert v < '1.2.3.dev4'
    assert v < '1.2.3.post4.dev4'
    assert v < '1.2.3.post4.dev5'
    assert v < '1.2.3.post5'
    assert v < '1.2.4'
    assert v < '1.3'
    assert v < '2'
    assert not (v < '1.2.3')
    assert not (v < '1.2.2')

# Generated at 2022-06-16 23:21:47.339886
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-16 23:21:49.494065
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:21:50.971152
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:22:03.089384
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Test for method __lt__ of class Version
    #
    # This test is not very good, because it depends on the
    # implementation of the __lt__ method.  It should be rewritten
    # to depend on the interface only.
    #
    # XXX rewrite this test
    v1 = Version("1.2.3a1")
    v2 = Version("1.2.3c1")
    assert v1 < v2
    assert v2 > v1
    assert v1 <= v2
    assert v2 >= v1
    assert v1 != v2
    assert v2 != v1
    v1 = Version("1.5.1")
    v2 = Version("1.5.2b2")
    assert v1 < v2
    assert v2 > v1
    assert v1 <= v2
    assert v

# Generated at 2022-06-16 23:22:04.882549
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented


# Generated at 2022-06-16 23:22:18.770073
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:22:19.956468
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:22:22.137439
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:22:29.022406
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 <= v2
    assert v1 <= '2.0'
    assert v1 <= Version('2.0')
    assert not v2 <= v1
    assert not v2 <= '1.0'
    assert not v2 <= Version('1.0')

# Generated at 2022-06-16 23:22:31.464941
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:22:40.716571
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 <= v2
    assert v1 <= '1.0'
    assert v1 <= '1.1'
    assert not v1 <= '0.9'
    assert not v1 <= '0.1'
    assert not v1 <= '0.0'

# Generated at 2022-06-16 23:22:42.208720
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) == NotImplemented


# Generated at 2022-06-16 23:22:44.526565
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert not v.__ge__(object())


# Generated at 2022-06-16 23:22:47.453861
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:22:58.852220
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2.3') >= Version('1.2.3')
    assert Version('1.2.3') >= '1.2.3'
    assert not (Version('1.2.3') >= Version('1.2.4'))
    assert not (Version('1.2.3') >= '1.2.4')
    assert not (Version('1.2.3') >= Version('1.3.3'))
    assert not (Version('1.2.3') >= '1.3.3')
    assert not (Version('1.2.3') >= Version('2.2.3'))
    assert not (Version('1.2.3') >= '2.2.3')
    assert Version('1.2.3') >= Version('1.2.3a1')

# Generated at 2022-06-16 23:23:27.004309
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert not v == None
    assert not v == '1.0'


# Generated at 2022-06-16 23:23:29.680306
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.0")
    v2 = Version("2.0")
    assert v1 < v2


# Generated at 2022-06-16 23:23:36.625140
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= '1.0'
    assert not (Version('1.0') >= Version('1.1'))
    assert not (Version('1.0') >= '1.1')
    assert Version('1.1') >= Version('1.0')
    assert Version('1.1') >= '1.0'
    assert not (Version('1.0') >= Version('2.0'))
    assert not (Version('1.0') >= '2.0')
    assert Version('2.0') >= Version('1.0')
    assert Version('2.0') >= '1.0'
    assert not (Version('1.0') >= Version('1.0.post1'))

# Generated at 2022-06-16 23:23:38.054628
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:23:40.656865
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented

# Generated at 2022-06-16 23:23:42.656665
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:23:44.453615
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == None


# Generated at 2022-06-16 23:23:45.752883
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:23:48.845940
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert v.__le__("1.0")
    assert not v.__le__("0.9")

# Generated at 2022-06-16 23:23:50.764359
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 <= v2


# Generated at 2022-06-16 23:24:46.290428
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:24:47.604658
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:24:50.477238
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:24:52.693693
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == False


# Generated at 2022-06-16 23:25:02.161610
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.0') <= Version('2.0')
    assert Version('1.0') <= Version('1.0.0')
    assert Version('1.0') <= Version('1.0.1')
    assert Version('1.0') <= Version('1.1.0')
    assert Version('1.0') <= Version('2.0.0')
    assert Version('1.0') <= Version('1.0.0.0')
    assert Version('1.0') <= Version('1.0.0.1')
    assert Version('1.0') <= Version('1.0.1.0')
    assert Version('1.0') <= Version('1.1.0.0')

# Generated at 2022-06-16 23:25:04.974905
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-16 23:25:07.538146
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__(Version()) == NotImplemented


# Generated at 2022-06-16 23:25:11.690168
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented
    assert v.__ge__(Version()) == True
    assert v.__ge__(Version("1.0")) == False
    assert v.__ge__("1.0") == False


# Generated at 2022-06-16 23:25:14.405640
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert v == Version('1')
    assert not (v == 1)
    assert not (v == '1')

# Generated at 2022-06-16 23:25:16.621779
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:27:29.920285
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= Version('1.0.0')
    assert Version('1.0.0') >= Version('1.0')
    assert Version('1.0.0') >= Version('1.0.0')
    assert Version('1.0') >= Version('1.0.0.0')
    assert Version('1.0.0.0') >= Version('1.0')
    assert Version('1.0.0.0') >= Version('1.0.0')
    assert Version('1.0.0.0') >= Version('1.0.0.0')
    assert Version('1.0') >= '1.0'
    assert Version('1.0') >= '1.0.0'

# Generated at 2022-06-16 23:27:30.665530
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()


# Generated at 2022-06-16 23:27:32.209085
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:27:33.714696
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:27:40.513517
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert not v == '1.2.4'
    assert not v == Version('1.2.4')
    assert not v == '1.2'
    assert not v == Version('1.2')
    assert not v == '1.2.3.4'
    assert not v == Version('1.2.3.4')
    assert not v == '1.2.3-4'
    assert not v == Version('1.2.3-4')
    assert not v == '1.2.3.4-5'
    assert not v == Version('1.2.3.4-5')

# Generated at 2022-06-16 23:27:41.771627
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:27:46.097765
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.0') > Version('0.9')


# Generated at 2022-06-16 23:27:47.395783
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented

# Generated at 2022-06-16 23:27:50.314190
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:27:51.465534
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True