

# Generated at 2022-06-16 23:19:58.182444
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 <= v2
    assert v1 <= '1.2.3'
    assert v1 <= '1.2.4'
    assert v1 <= '1.2.4b1'
    assert v1 <= '1.2.4c1'
    assert v1 <= '1.2.4rc1'
    assert v1 <= '1.2.4.post1'
    assert v1 <= '1.2.4.dev1'
    assert v1 <= '1.2.4.post1.dev1'
    assert v1 <= '1.2.4.post1.dev2'
    assert v1 <= '1.2.4.post1.dev3'

# Generated at 2022-06-16 23:19:59.934836
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:20:02.120631
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:03.599992
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v)

# Generated at 2022-06-16 23:20:05.619318
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True


# Generated at 2022-06-16 23:20:06.485422
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:20:08.078155
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:20:09.836284
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(v) == False


# Generated at 2022-06-16 23:20:19.888393
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.5.1')
    assert lv.version == [1, 5, 1], lv.version
    lv.parse('1.5.2b2')
    assert lv.version == [1, 5, '2b2'], lv.version
    lv.parse('161')
    assert lv.version == [161], lv.version
    lv.parse('3.10a')
    assert lv.version == [3, '10a'], lv.version
    lv.parse('8.02')
    assert lv.version == [8, '02'], lv.version
    lv.parse('3.4j')
    assert lv.version == [3, '4j'], lv.version
    l

# Generated at 2022-06-16 23:20:27.549802
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3')
    assert str(v) == '1.2.3'
    v = StrictVersion('1.2')
    assert str(v) == '1.2'
    v = StrictVersion('1.2.3a4')
    assert str(v) == '1.2.3a4'
    v = StrictVersion('1.2.3b4')
    assert str(v) == '1.2.3b4'


# Generated at 2022-06-16 23:20:38.127776
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:20:47.031186
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented
    assert v.__le__(1) is NotImplemented
    assert v.__le__(1.0) is NotImplemented
    assert v.__le__(True) is NotImplemented
    assert v.__le__(False) is NotImplemented
    assert v.__le__(object()) is NotImplemented
    assert v.__le__(object) is NotImplemented
    assert v.__le__(Version) is NotImplemented
    assert v.__le__(Version()) is NotImplemented
    assert v.__le__(Version('1.0')) is NotImplemented
    assert v.__le__(Version('1.0.0')) is NotImplemented
    assert v

# Generated at 2022-06-16 23:20:59.691142
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2
    assert v2 > v1
    assert v1 <= v2
    assert v2 >= v1
    assert v1 != v2
    assert not v1 == v2
    assert not v1 > v2
    assert not v2 < v1
    assert not v1 >= v2
    assert not v2 <= v1
    assert not v1 == 1
    assert v1 != 1
    assert not v1 == '1.0'
    assert v1 != '1.0'
    assert not v1 == '1.1'
    assert v1 != '1.1'
    assert not v1 == '1.0.0'
    assert v1 != '1.0.0'
    assert not v

# Generated at 2022-06-16 23:21:01.836003
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:21:03.397483
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented

# Generated at 2022-06-16 23:21:04.548129
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:21:06.820490
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:21:08.246131
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:21:10.652803
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2

# Generated at 2022-06-16 23:21:13.430963
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Version.__lt__: NotImplemented
    # assert Version().__lt__(object()) is NotImplemented
    pass


# Generated at 2022-06-16 23:21:24.312979
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-16 23:21:34.111632
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert not v1 == v2
    assert not v1 > v2
    assert not v1 >= v2
    assert not v2 < v1
    assert not v2 <= v1
    assert not v1 == '1.2.4'
    assert v1 != '1.2.4'
    assert not v1 > '1.2.4'
    assert not v1 >= '1.2.4'
    assert v1 < '1.2.4'
    assert v1 <= '1.2.4'

# Generated at 2022-06-16 23:21:35.254709
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:21:41.729694
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__

# Generated at 2022-06-16 23:21:43.242425
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(Version()) == NotImplemented


# Generated at 2022-06-16 23:21:45.331456
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:21:47.465475
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:21:50.888595
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert not v.__le__(None)

# Generated at 2022-06-16 23:22:02.946518
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert v != '1.2.4'
    assert v != Version('1.2.4')
    assert v != '1.2'
    assert v != Version('1.2')
    assert v != '1.2.3.4'
    assert v != Version('1.2.3.4')
    assert v != '1.2.3-4'
    assert v != Version('1.2.3-4')
    assert v != '1.2.3.4-5'
    assert v != Version('1.2.3.4-5')
    assert v != '1.2.3.4-5.6'

# Generated at 2022-06-16 23:22:04.726829
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:24.423402
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:22:35.526884
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.0') <= Version('2.0')
    assert Version('1.0') <= Version('1.0.0')
    assert Version('1.0') <= Version('1.0.1')
    assert Version('1.0') <= Version('1.1.0')
    assert Version('1.0') <= Version('2.0.0')
    assert Version('1.0') <= Version('1.0.0.0')
    assert Version('1.0') <= Version('1.0.0.1')
    assert Version('1.0') <= Version('1.0.1.0')
    assert Version('1.0') <= Version('1.1.0.0')

# Generated at 2022-06-16 23:22:44.014981
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(1) == NotImplemented
    assert v.__le__(None) == NotImplemented
    assert v.__le__(Version()) == True
    assert v.__le__(Version('1')) == True
    assert v.__le__(Version('2')) == True
    assert v.__le__(Version('1.0')) == True
    assert v.__le__(Version('1.1')) == True
    assert v.__le__(Version('1.0.0')) == True
    assert v.__le__(Version('1.0.1')) == True
    assert v.__le__(Version('1.0.0.0')) == True

# Generated at 2022-06-16 23:22:55.934142
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == Version('1.0')
    assert v1 != Version('1.1')
    assert v1 != '1.0'
    assert v1 != '1.1'
    assert v1 != 1.0
    assert v1 != 1.1
    assert v1 != None
    assert v1 != object()
    assert v1 != object
    assert v1 != Version
    assert v1 != Version('1.0.0')
    assert v1 != Version('1.0.0.0')

# Generated at 2022-06-16 23:22:58.672686
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2


# Generated at 2022-06-16 23:22:59.283666
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:23:00.993753
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:23:02.280257
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:23:03.838920
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented

# Generated at 2022-06-16 23:23:06.013320
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-16 23:23:41.924162
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__("1") is NotImplemented
    assert v.__gt__(Version("1")) is NotImplemented
    assert v.__gt__(StrictVersion("1")) is NotImplemented
    assert v.__gt__(LooseVersion("1")) is NotImplemented


# Generated at 2022-06-16 23:23:42.873804
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:23:45.308530
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:23:46.586585
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented


# Generated at 2022-06-16 23:23:48.192240
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-16 23:23:49.444944
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:23:59.795306
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented
    assert v.__ge__(1) == NotImplemented
    assert v.__ge__(1.0) == NotImplemented
    assert v.__ge__(1.0+0j) == NotImplemented
    assert v.__ge__(True) == NotImplemented
    assert v.__ge__(False) == NotImplemented
    assert v.__ge__(Version()) == True
    assert v.__ge__(StrictVersion()) == True
    assert v.__ge__(LooseVersion()) == True
    assert v.__ge__('') == NotImplemented
    assert v.__ge__('1') == NotImplemented

# Generated at 2022-06-16 23:24:04.420416
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= '1.0'
    assert Version('1.0') >= '1.0.0'
    assert Version('1.0') >= '1.0.0.0'
    assert not Version('1.0') >= '1.1'
    assert not Version('1.0') >= '1.1.0'
    assert not Version('1.0') >= '1.1.0.0'



# Generated at 2022-06-16 23:24:08.324410
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:24:12.631330
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)
    assert not (v < v)
    assert v <= v
    assert not (v > v)
    assert v >= v


# Generated at 2022-06-16 23:25:11.652213
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(Version())

# Generated at 2022-06-16 23:25:13.782141
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2


# Generated at 2022-06-16 23:25:16.865927
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented


# Generated at 2022-06-16 23:25:18.601633
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:25:20.902987
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:25:22.657898
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented


# Generated at 2022-06-16 23:25:24.847745
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:25:26.227148
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v2 > v1

# Generated at 2022-06-16 23:25:28.171800
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:25:38.256181
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert v1 <= v2
    assert v1 != v2
    assert v2 > v1
    assert v2 >= v1
    assert v1._cmp(v2) == -1
    assert v2._cmp(v1) == 1
    assert v1._cmp(v1) == 0
    assert v2._cmp(v2) == 0
    assert v1._cmp('1.2.4') == -1
    assert v2._cmp('1.2.3') == 1
    assert v1._cmp('1.2.3') == 0
    assert v2._cmp('1.2.4') == 0

# Generated at 2022-06-16 23:27:55.724528
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    assert v1 <= v2


# Generated at 2022-06-16 23:28:06.300660
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.2.3')
    assert lv.version == [1, 2, 3]
    lv.parse('1.2.3a4')
    assert lv.version == [1, 2, 3, 'a', 4]
    lv.parse('1.2.3.4')
    assert lv.version == [1, 2, 3, 4]
    lv.parse('1.2.3.4.5')
    assert lv.version == [1, 2, 3, 4, 5]
    lv.parse('1.2.3.4.5.6')
    assert lv.version == [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-16 23:28:10.040512
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2


# Generated at 2022-06-16 23:28:16.099844
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert v1.__ge__(v2)
    assert v2.__ge__(v1)
    assert v1.__ge__(v1)
    assert v2.__ge__(v2)
    assert not v1.__ge__(None)
    assert not v2.__ge__(None)
    assert not v1.__ge__(1)
    assert not v2.__ge__(1)
    assert not v1.__ge__("")
    assert not v2.__ge__("")
    assert not v1.__ge__("1")
    assert not v2.__ge__("1")
    assert not v1.__ge__("1.0")
    assert not v2.__ge__("1.0")
   

# Generated at 2022-06-16 23:28:17.522893
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:28:18.884794
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(v) == False


# Generated at 2022-06-16 23:28:20.198325
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented

# Generated at 2022-06-16 23:28:25.719303
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Version.__eq__(self, other)
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert not v == '1.2.4'
    assert not v == '1.2'
    assert not v == '1.2.3.4'
    assert not v == '1.2.2'
    assert not v == '1.2.3a1'
    assert not v == '1.2.3.a1'
    assert not v == '1.2.3.4.a1'
    assert not v == '1.2.3.4a1'
    assert not v == '1.2.3a1.4'
    assert not v == '1.2.3a1.4.5'

# Generated at 2022-06-16 23:28:33.921777
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()
    assert v == Version('1')
    assert v == Version('1.2')
    assert v == Version('1.2.3')
    assert v == Version('1.2.3.4')
    assert v == Version('1.2.3.4.5')
    assert v == Version('1.2.3.4.5.6')
    assert v == Version('1.2.3.4.5.6.7')
    assert v == Version('1.2.3.4.5.6.7.8')
    assert v == Version('1.2.3.4.5.6.7.8.9')
    assert v == Version('1.2.3.4.5.6.7.8.9.10')

# Generated at 2022-06-16 23:28:38.314754
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
