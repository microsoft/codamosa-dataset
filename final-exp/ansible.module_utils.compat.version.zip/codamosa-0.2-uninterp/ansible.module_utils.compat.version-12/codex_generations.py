

# Generated at 2022-06-16 23:20:02.756407
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None

    v = StrictVersion('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)

    v = StrictVersion('1.2.3b4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 4)

    v = StrictVersion('1.2.3a4.5')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)

    v = StrictVersion('1.2.3b4.5')
    assert v.version == (1, 2, 3)

# Generated at 2022-06-16 23:20:04.593144
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:20:06.535181
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented


# Generated at 2022-06-16 23:20:08.125972
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:20:09.930915
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:20:12.315299
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:20:14.114265
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:14.745427
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:20:16.392573
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:19.514176
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True


# Generated at 2022-06-16 23:20:36.509933
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:20:37.947837
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:20:46.916422
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.1') <= Version('1.2')
    assert Version('1.1') <= Version('1.1.1')
    assert Version('1.1.1') <= Version('1.1.2')
    assert Version('1.1.1') <= Version('1.1.1.1')
    assert Version('1.1.1.1') <= Version('1.1.1.2')
    assert Version('1.1.1.1') <= Version('1.1.1.1.1')
    assert Version('1.1.1.1.1') <= Version('1.1.1.1.2')

# Generated at 2022-06-16 23:20:59.514207
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.0.0')
    assert Version('1.0') <= Version('1.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0.0.0.0')

# Generated at 2022-06-16 23:21:07.706981
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # self.assertTrue(self.version < self.other)
    assert Version('1.0') < Version('2.0')
    # self.assertTrue(self.version < self.other)
    assert Version('1.0') < Version('1.1')
    # self.assertTrue(self.version < self.other)
    assert Version('1.0') < Version('1.0.1')
    # self.assertTrue(self.version < self.other)
    assert Version('1.0.0') < Version('1.0.1')
    # self.assertTrue(self.version < self.other)
    assert Version('1.0.0') < Version('1.0.1')
    # self.assertTrue(self.version < self.other)

# Generated at 2022-06-16 23:21:10.434292
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__gt__(v2) == False


# Generated at 2022-06-16 23:21:18.891930
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert v.__ge__(0)
    assert v.__ge__(1)
    assert v.__ge__(1.0)
    assert v.__ge__(1.1)

# Generated at 2022-06-16 23:21:29.850282
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import importlib
    import importlib.util
    import importlib.machinery
    import types
    import warnings
    import contextlib
    import io
    import re
    import textwrap
    import unittest.mock
    import runpy
    import zipfile
    import tarfile
    import zipimport
    import pkgutil
    import site
    import sysconfig
    import distutils.util
    import distutils.version
    import distutils.sysconfig
    import distutils.core
    import distutils.errors
    import distutils.command.build
    import distutils.command.build_ext
    import distutils.command.build_py
    import distutils.command.build_scripts
   

# Generated at 2022-06-16 23:21:32.597156
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented

# Generated at 2022-06-16 23:21:44.097726
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert (v < '1.2.4') == True
    assert (v < '1.2.3') == False
    assert (v < '1.2.2') == False
    assert (v < '1.2') == False
    assert (v < '1.2b1') == False
    assert (v < '1.2rc1') == False
    assert (v < '1.2a1') == False
    assert (v < '1.1.3') == False
    assert (v < '1.1.2') == False
    assert (v < '1.1.4') == False
    assert (v < '1.1') == False
    assert (v < '1.1b2') == False

# Generated at 2022-06-16 23:21:54.460165
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:21:57.352708
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) == NotImplemented


# Generated at 2022-06-16 23:21:58.874295
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v

# Generated at 2022-06-16 23:22:09.971924
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.0') < Version('1.1')
    assert Version('1.1') < Version('1.2')
    assert Version('1.2') < Version('1.3')
    assert Version('1.3') < Version('1.4')
    assert Version('1.4') < Version('1.5')
    assert Version('1.5') < Version('1.6')
    assert Version('1.6') < Version('1.7')
    assert Version('1.7') < Version('1.8')
    assert Version('1.8') < Version('1.9')
    assert Version('1.9') < Version('1.10')
    assert Version('1.10') < Version('1.11')
    assert Version('1.11') < Version('1.12')

# Generated at 2022-06-16 23:22:12.483217
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert not v.__ge__(object())


# Generated at 2022-06-16 23:22:20.669215
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.2.3') == Version('1.2.3')
    assert not Version('1.2.3') == Version('1.2.4')
    assert not Version('1.2.3') == Version('1.2.3.4')
    assert not Version('1.2.3') == Version('1.2.3.4.5')
    assert not Version('1.2.3') == Version('1.2.3.4.5.6')
    assert not Version('1.2.3') == Version('1.2.3.4.5.6.7')
    assert not Version('1.2.3') == Version('1.2.3.4.5.6.7.8')

# Generated at 2022-06-16 23:22:23.700427
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 <= v2

# Generated at 2022-06-16 23:22:34.859707
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(None) == NotImplemented
    assert v1.__gt__(1) == NotImplemented
    assert v1.__gt__(1.0) == NotImplemented
    assert v1.__gt__('') == NotImplemented
    assert v1.__gt__('1') == NotImplemented
    assert v1.__gt__(()) == NotImplemented
    assert v1.__gt__([]) == NotImplemented
    assert v1.__gt__({}) == NotImplemented
    assert v1.__gt__(set()) == NotImplemented

# Generated at 2022-06-16 23:22:36.139639
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:22:37.859995
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:23:03.549594
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(Version())
    assert not v.__ge__(None)
    assert not v.__ge__(object())
    assert not v.__ge__(1)
    assert not v.__ge__(1.0)
    assert not v.__ge__('')
    assert not v.__ge__('1')
    assert not v.__ge__('1.0')
    assert not v.__ge__('1.0.0')
    assert not v.__ge__('1.0.0.0')
    assert not v.__ge__('1.0.0.0.0')
    assert not v.__ge__('1.0.0.0.0.0')
    assert not v.__ge

# Generated at 2022-06-16 23:23:10.275962
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented
    assert v.__gt__(0) == NotImplemented
    assert v.__gt__(-1) == NotImplemented
    assert v.__gt__(None) == NotImplemented
    assert v.__gt__('') == NotImplemented
    assert v.__gt__('1') == NotImplemented
    assert v.__gt__('0') == NotImplemented
    assert v.__gt__('-1') == NotImplemented
    assert v.__gt__('') == NotImplemented
    assert v.__gt__(Version()) == NotImplemented


# Generated at 2022-06-16 23:23:12.403869
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) == NotImplemented

# Generated at 2022-06-16 23:23:23.098894
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__(1.0) is NotImplemented
    assert v.__gt__(1.0j) is NotImplemented
    assert v.__gt__(()) is NotImplemented
    assert v.__gt__([]) is NotImplemented
    assert v.__gt__({}) is NotImplemented
    assert v.__gt__(set()) is NotImplemented
    assert v.__gt__(frozenset()) is NotImplemented
    assert v.__gt__(object()) is NotImplemented
    assert v.__gt__(object) is NotImplemented
    assert v.__gt__(Version()) is Not

# Generated at 2022-06-16 23:23:25.110004
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:23:26.498147
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v

# Generated at 2022-06-16 23:23:29.260913
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == False


# Generated at 2022-06-16 23:23:34.459027
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert v.__le__('0.0')
    assert v.__le__(0.0)
    assert v.__le__(0)
    assert v.__le__(None)
    assert v.__le__(False)
    assert v.__le__(True)
    assert v.__le__(object())

# Generated at 2022-06-16 23:23:37.517628
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v == None
    assert not v == '1.0'

# Generated at 2022-06-16 23:23:39.283388
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:24:10.168326
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:24:12.305757
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:24:14.024067
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= v
    assert v <= '1.0'
    assert not (v <= '0.9')


# Generated at 2022-06-16 23:24:15.567948
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:24:26.486145
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= '1.0'
    assert Version('1.0') >= '1.0.0'
    assert not Version('1.0') >= '1.0.1'
    assert not Version('1.0') >= '2.0'
    assert not Version('1.0') >= '1.0.0.0'
    assert not Version('1.0') >= '1.0.0.0.0'
    assert not Version('1.0') >= '1.0.0.0.0.0'
    assert not Version('1.0') >= '1.0.0.0.0.0.0'

# Generated at 2022-06-16 23:24:28.279203
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:24:30.277183
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:24:31.980872
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:24:33.250012
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True


# Generated at 2022-06-16 23:24:43.105821
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2.3') >= '1.2.3'
    assert Version('1.2.3') >= '1.2.3a'
    assert Version('1.2.3') >= '1.2.3b'
    assert Version('1.2.3') >= '1.2.3c'
    assert Version('1.2.3') >= '1.2.3.0'
    assert Version('1.2.3') >= '1.2.3.0a'
    assert Version('1.2.3') >= '1.2.3.0b'
    assert Version('1.2.3') >= '1.2.3.0c'
    assert Version('1.2.3') >= '1.2.3.0.0'
    assert Version('1.2.3')

# Generated at 2022-06-16 23:25:42.246346
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__(Version()) == False

# Generated at 2022-06-16 23:25:44.902697
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:25:46.685310
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented

# Generated at 2022-06-16 23:25:48.582461
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:25:52.018454
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 >= v2 == False
    assert v1 >= v1 == True
    assert v2 >= v1 == True


# Generated at 2022-06-16 23:25:53.308812
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:26:01.274443
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2
    assert v1 >= '1.2.3'
    assert v1 >= '1.2.2'
    assert v1 >= '1.2'
    assert v1 >= '1'
    assert v1 >= '0.9.9'
    assert not (v1 >= '1.2.4')
    assert not (v1 >= '1.3')
    assert not (v1 >= '2')
    assert not (v1 >= '1.2.3.4')
    assert not (v1 >= '1.2.3a1')
    assert not (v1 >= '1.2.3.dev')
    assert not (v1 >= '1.2.3.post')

# Generated at 2022-06-16 23:26:02.648801
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(Version()) == True

# Generated at 2022-06-16 23:26:14.003942
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= v
    assert v <= '0'
    assert not v <= '1'
    assert not v <= '0.0'
    assert not v <= '0.0.0'
    assert not v <= '0.0.0.0'
    assert not v <= '0.0.0.0.0'
    assert not v <= '0.0.0.0.0.0'
    assert not v <= '0.0.0.0.0.0.0'
    assert not v <= '0.0.0.0.0.0.0.0'
    assert not v <= '0.0.0.0.0.0.0.0.0'
    assert not v <= '0.0.0.0.0.0.0.0.0.0'

# Generated at 2022-06-16 23:26:15.881255
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented

# Generated at 2022-06-16 23:28:39.772260
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) == NotImplemented


# Generated at 2022-06-16 23:28:43.240993
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True


# Generated at 2022-06-16 23:28:46.209011
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert not v.__le__(None)


# Generated at 2022-06-16 23:28:47.670010
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:28:49.121218
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:28:50.547779
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:29:00.237041
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)
    assert not v.__ge__(1)
    assert not v.__ge__(1.0)
    assert not v.__ge__('1.0')
    assert not v.__ge__(b'1.0')
    assert not v.__ge__(u'1.0')
    assert not v.__ge__(object())
    assert not v.__ge__(object)
    assert not v.__ge__(Exception)
    assert not v.__ge__(Exception())
    assert not v.__ge__(ValueError)
    assert not v.__ge__(ValueError())
    assert not v.__ge__(RuntimeError)

# Generated at 2022-06-16 23:29:10.437907
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.1') <= Version('1.2')
    assert Version('1.2') <= Version('2.0')
    assert Version('1.0') <= Version('2.0')
    assert Version('1.0') <= Version('2.1')
    assert Version('1.1') <= Version('2.0')
    assert Version('1.1') <= Version('2.1')
    assert Version('1.2') <= Version('2.0')
    assert Version('1.2') <= Version('2.1')
    assert Version('2.0') <= Version('2.0')
    assert Version('2.0') <= Version('2.1')

# Generated at 2022-06-16 23:29:13.080339
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:29:17.527474
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert not (v != v)
    assert not (v != Version())
