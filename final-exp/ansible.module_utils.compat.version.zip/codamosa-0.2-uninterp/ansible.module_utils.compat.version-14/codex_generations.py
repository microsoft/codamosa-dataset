

# Generated at 2022-06-16 23:19:53.661426
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented

# Generated at 2022-06-16 23:20:04.447261
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    v = Version('1.2.3')
    assert v.__gt__('1.2.2')
    assert not v.__gt__('1.2.3')
    assert not v.__gt__('1.2.4')
    assert not v.__gt__('1.3.3')
    assert not v.__gt__('2.2.3')
    assert not v.__gt__('1.2.3.0')
    assert not v.__gt__('1.2.3.0.0')
    assert not v.__gt__('1.2.3.0.0.0')
    assert not v.__gt__('1.2.3.0.0.0.0')

# Generated at 2022-06-16 23:20:08.925115
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2


# Generated at 2022-06-16 23:20:11.360951
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:20:20.147171
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2') >= Version('1.2')
    assert Version('1.2') >= '1.2'
    assert Version('1.2') >= '1.2.0'
    assert Version('1.2') >= '1.2.0.0'
    assert not (Version('1.2') >= '1.2.0.1')
    assert not (Version('1.2') >= '1.3')
    assert not (Version('1.2') >= '2.1')
    assert not (Version('1.2') >= '2.1.0')
    assert not (Version('1.2') >= '2.1.0.0')
    assert not (Version('1.2') >= '2.1.0.1')
    assert not (Version('1.2') >= '2.2')

# Generated at 2022-06-16 23:20:30.312523
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("1.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion("1.0.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion("1.0a1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion("1.0.0a1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion("1.0b3")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('b', 3)

    v

# Generated at 2022-06-16 23:20:32.349292
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2


# Generated at 2022-06-16 23:20:34.099408
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:35.962087
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.0') > Version('0.9')

# Generated at 2022-06-16 23:20:45.442350
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def check(vstring, expected):
        v = StrictVersion(vstring)
        assert v.version == expected[0]
        assert v.prerelease == expected[1]

    check('1.0', ((1, 0, 0), None))
    check('1.0.0', ((1, 0, 0), None))
    check('1.0a1', ((1, 0, 0), ('a', 1)))
    check('1.0.0a1', ((1, 0, 0), ('a', 1)))
    check('1.0b1', ((1, 0, 0), ('b', 1)))
    check('1.0.0b1', ((1, 0, 0), ('b', 1)))
    check('1.0.0.0', ((1, 0, 0), None))

# Generated at 2022-06-16 23:20:58.809363
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented


# Generated at 2022-06-16 23:20:59.904509
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    assert v1 <= v2


# Generated at 2022-06-16 23:21:02.004041
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert not v.__le__(None)

# Generated at 2022-06-16 23:21:03.730822
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(Version()) == NotImplemented

# Generated at 2022-06-16 23:21:05.021101
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:21:07.583811
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:21:17.127755
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.1') <= Version('1.2')
    assert Version('1.2') <= Version('2.0')
    assert Version('2.0') <= Version('2.0')
    assert Version('2.0') <= Version('2.1')
    assert Version('2.1') <= Version('2.2')
    assert Version('2.2') <= Version('3.0')
    assert Version('3.0') <= Version('3.0')
    assert Version('3.0') <= Version('3.1')
    assert Version('3.1') <= Version('3.2')
    assert Version('3.2') <= Version('4.0')

# Generated at 2022-06-16 23:21:19.191118
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:21:21.488035
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:21:23.909576
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2

# Generated at 2022-06-16 23:21:47.297990
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.5.1')
    assert lv.version == [1, '5', 1]
    lv.parse('1.5.2b2')
    assert lv.version == [1, '5', '2b', 2]
    lv.parse('161')
    assert lv.version == [161]
    lv.parse('3.10a')
    assert lv.version == [3, '10a']
    lv.parse('8.02')
    assert lv.version == [8, '02']
    lv.parse('3.4j')
    assert lv.version == [3, '4j']
    lv.parse('1996.07.12')

# Generated at 2022-06-16 23:21:50.313463
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert not v == None
    assert not v == '1'

# Generated at 2022-06-16 23:21:51.515797
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:21:53.733223
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:21:56.935199
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.0")
    v2 = Version("1.1")
    assert v1 < v2


# Generated at 2022-06-16 23:22:00.493079
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v2 > v1
    assert not (v1 > v2)
    assert not (v1 > v1)

# Generated at 2022-06-16 23:22:02.842248
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert not v.__gt__(v)


# Generated at 2022-06-16 23:22:04.615863
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) == NotImplemented

# Generated at 2022-06-16 23:22:06.463730
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:22:09.726673
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert not Version('1.1') <= Version('1.0')

# Generated at 2022-06-16 23:22:25.085850
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:22:36.099295
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__

# Generated at 2022-06-16 23:22:38.112358
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:22:39.375504
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:22:43.441075
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__(Version()) == False
    assert v.__gt__(Version('1.0')) == False
    assert v.__gt__(Version('0.1')) == True


# Generated at 2022-06-16 23:22:55.111301
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2.3') >= Version('1.2.3')
    assert Version('1.2.3') >= '1.2.3'
    assert Version('1.2.3') >= '1.2.3b'
    assert Version('1.2.3') >= '1.2.3a'
    assert Version('1.2.3') >= '1.2.3.0'
    assert Version('1.2.3') >= '1.2.3.0b'
    assert Version('1.2.3') >= '1.2.3.0a'
    assert Version('1.2.3') >= '1.2.3.0.0'
    assert Version('1.2.3') >= '1.2.3.0.0b'

# Generated at 2022-06-16 23:23:05.137315
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    v = Version('1.2.3')
    assert v > '1.2.2'
    assert v > '1.2.3'
    assert v > '1.2.4'
    assert v > '1.2.3a'
    assert v > '1.2.3.1'
    assert v > '1.2.3.1a'
    assert v > '1.2.3.1.1'
    assert v > '1.2.3.1.1a'
    assert v > '1.2.3.1.1.1'
    assert v > '1.2.3.1.1.1a'
    assert v > '1.2.3.1.1.1.1'

# Generated at 2022-06-16 23:23:06.983480
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-16 23:23:09.398180
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented


# Generated at 2022-06-16 23:23:11.512431
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-16 23:23:48.670934
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False
    assert v1.__gt__(v2) == False

# Generated at 2022-06-16 23:23:49.944903
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:23:52.024887
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:23:58.896333
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= '1.0'
    assert Version('1.0') >= '1.0.0'
    assert Version('1.0') >= '1.0.0.0'
    assert Version('1.0') >= '1.0.0.0.0'
    assert Version('1.0') >= '1.0.0.0.0.0'
    assert Version('1.0') >= '1.0.0.0.0.0.0'
    assert Version('1.0') >= '1.0.0.0.0.0.0.0'
    assert Version('1.0') >= '1.0.0.0.0.0.0.0.0'

# Generated at 2022-06-16 23:24:00.512904
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented

# Generated at 2022-06-16 23:24:01.585016
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:24:02.906292
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented

# Generated at 2022-06-16 23:24:05.250580
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:24:11.704768
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented
    assert v.__le__('') is NotImplemented
    assert v.__le__(0) is NotImplemented
    assert v.__le__(Version()) is True

# Generated at 2022-06-16 23:24:14.467769
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v
    assert not v == None
    assert v != None
    assert not v == '1.2.3'
    assert v != '1.2.3'


# Generated at 2022-06-16 23:25:16.163736
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.0.0')
    assert Version('1.0') <= Version('1.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0.0.0.0')

# Generated at 2022-06-16 23:25:17.732863
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented

# Generated at 2022-06-16 23:25:29.176616
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented
    assert v.__ge__(1) == NotImplemented
    assert v.__ge__(1.0) == NotImplemented
    assert v.__ge__(1.0+0j) == NotImplemented
    assert v.__ge__('') == NotImplemented
    assert v.__ge__('a') == NotImplemented
    assert v.__ge__(()) == NotImplemented
    assert v.__ge__([]) == NotImplemented
    assert v.__ge__({}) == NotImplemented
    assert v.__ge__(object()) == NotImplemented
    assert v.__ge__(object) == NotImplemented


# Generated at 2022-06-16 23:25:39.090402
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert v.__ge__(1)
    assert v.__ge__("1")
    assert v.__ge__("1.0")
    assert v.__ge__("1.0.0")
    assert v.__ge__("1.0.0.0")
    assert v.__ge__("1.0.0.0.0")
    assert v.__ge__("1.0.0.0.0.0")
    assert v.__ge__("1.0.0.0.0.0.0")
    assert v.__ge__("1.0.0.0.0.0.0.0")

# Generated at 2022-06-16 23:25:40.749929
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:25:42.206725
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:25:45.215127
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(Version())
    assert not v.__ge__(None)

# Generated at 2022-06-16 23:25:47.017433
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented

# Generated at 2022-06-16 23:25:49.657565
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2

# Generated at 2022-06-16 23:25:59.108901
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert v == Version('1.2.3.0')
    assert v != '1.2.4'
    assert v != Version('1.2.4')
    assert v != Version('1.2.4.0')
    assert v != '1.2.3.4'
    assert v != Version('1.2.3.4')
    assert v != '1.2.3.0.4'
    assert v != Version('1.2.3.0.4')

# Generated at 2022-06-16 23:28:12.333576
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert not v.__le__(None)

# Generated at 2022-06-16 23:28:16.485955
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v


# Generated at 2022-06-16 23:28:17.369802
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(v) == False

# Generated at 2022-06-16 23:28:20.491732
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:28:21.940832
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented

# Generated at 2022-06-16 23:28:33.377147
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert v < '1.2.4'
    assert v < '1.2.3.1'
    assert v < '1.2.3-1'
    assert v < '1.2.3-1.1'
    assert v < '1.2.3-1.1.1'
    assert v < '1.2.3-1.1.1.1'
    assert v < '1.2.3-1.1.1.1.1'
    assert v < '1.2.3-1.1.1.1.1.1'
    assert v < '1.2.3-1.1.1.1.1.1.1'

# Generated at 2022-06-16 23:28:38.663967
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 < v2


# Generated at 2022-06-16 23:28:41.836512
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 < v2 == False
    assert v1 <= v2 == True
    assert v1 > v2 == False
    assert v1 >= v2 == True
    assert v1 == v2 == True
    assert v1 != v2 == False


# Generated at 2022-06-16 23:28:45.008139
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v



# Generated at 2022-06-16 23:28:46.744522
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented