

# Generated at 2022-06-16 23:19:55.915075
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.2.3").__str__() == "1.2.3"
    assert StrictVersion("1.2").__str__() == "1.2"
    assert StrictVersion("1.2a3").__str__() == "1.2a3"
    assert StrictVersion("1.2b3").__str__() == "1.2b3"


# Generated at 2022-06-16 23:19:58.432606
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:00.209549
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented

# Generated at 2022-06-16 23:20:03.645710
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.0') == Version('1.0')
    assert Version('1.0') != Version('1.1')
    assert Version('1.0') != '1.0'


# Generated at 2022-06-16 23:20:06.070079
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v2 > v1

# Generated at 2022-06-16 23:20:09.211378
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented
    assert v.__le__(1) == NotImplemented

# Generated at 2022-06-16 23:20:19.483396
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.0.4a3')
    assert str(v) == '1.0.4a3'
    v = StrictVersion('1.0.4')
    assert str(v) == '1.0.4'
    v = StrictVersion('1.0')
    assert str(v) == '1.0'
    v = StrictVersion('1')
    assert str(v) == '1.0'
    v = StrictVersion('1.0.4b1')
    assert str(v) == '1.0.4b1'
    v = StrictVersion('1.0.4b1')
    assert str(v) == '1.0.4b1'
    v = StrictVersion('1.0.4b1')

# Generated at 2022-06-16 23:20:27.062677
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2


# Generated at 2022-06-16 23:20:34.454718
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None

    v.parse('1.2.3a1')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 1)

    v.parse('1.2.3b2')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 2)

    v.parse('1.2.3b02')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 2)

    v.parse('1.2.3b2.post4')
    assert v.version == (1, 2, 3)

# Generated at 2022-06-16 23:20:44.575606
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(None) == NotImplemented
    assert v1.__gt__(1) == NotImplemented
    assert v1.__gt__(1.0) == NotImplemented
    assert v1.__gt__(True) == NotImplemented
    assert v1.__gt__(False) == NotImplemented
    assert v1.__gt__('') == NotImplemented
    assert v1.__gt__('1') == NotImplemented
    assert v1.__gt__('1.0') == NotImplemented
    assert v1.__gt__('1.0.0') == NotImplemented
    assert v1.__

# Generated at 2022-06-16 23:20:52.460505
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:20:54.662817
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("1.0")
    v2 = Version("1.1")
    assert v2 > v1


# Generated at 2022-06-16 23:20:56.937271
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:20:58.595929
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:21:04.782907
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert not v1 == v2
    assert not v1 > v2
    assert not v1 >= v2
    assert not v2 < v1
    assert not v2 <= v1
    assert not v2 == v1
    assert not v2 != v1

# Generated at 2022-06-16 23:21:07.492537
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:21:08.987319
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:21:10.835954
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented

# Generated at 2022-06-16 23:21:19.149031
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2.3') >= Version('1.2.3')
    assert Version('1.2.3') >= Version('1.2.2')
    assert Version('1.2.3') >= Version('1.1.3')
    assert Version('1.2.3') >= Version('0.2.3')
    assert Version('1.2.3') >= Version('1.2.3a1')
    assert Version('1.2.3') >= Version('1.2.3c1')
    assert Version('1.2.3') >= Version('1.2.3.post1')
    assert Version('1.2.3') >= Version('1.2.3.dev1')
    assert Version('1.2.3') >= Version('1.2.3.dev2')

# Generated at 2022-06-16 23:21:21.961902
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert not v.__ge__(1)


# Generated at 2022-06-16 23:21:29.280026
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:21:33.314427
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.5.1')
    assert lv.version == [1, '5', 1]
    lv.parse('1.5.2b2')
    assert lv.version == [1, '5', '2b', 2]
    lv.parse('161')
    assert lv.version == [161]
    lv.parse('3.10a')
    assert lv.version == [3, '10a']
    lv.parse('8.02')
    assert lv.version == [8, '02']
    lv.parse('3.4j')
    assert lv.version == [3, '4j']
    lv.parse('1996.07.12')

# Generated at 2022-06-16 23:21:44.613308
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(None) == NotImplemented
    assert v1.__gt__(1) == NotImplemented
    assert v1.__gt__(1.0) == NotImplemented
    assert v1.__gt__('') == NotImplemented
    assert v1.__gt__('1') == NotImplemented
    assert v1.__gt__('1.0') == NotImplemented
    assert v1.__gt__(()) == NotImplemented
    assert v1.__gt__([]) == NotImplemented
    assert v1.__gt__({}) == NotImplemented
    assert v1.__gt__(set()) == Not

# Generated at 2022-06-16 23:21:46.885372
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)

# Generated at 2022-06-16 23:21:49.303623
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(0) == NotImplemented


# Generated at 2022-06-16 23:21:55.971615
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented
    assert v.__ge__(1) == NotImplemented
    assert v.__ge__('') == NotImplemented
    assert v.__ge__('1') == NotImplemented
    assert v.__ge__(()) == NotImplemented
    assert v.__ge__([]) == NotImplemented
    assert v.__ge__({}) == NotImplemented
    assert v.__ge__(object()) == NotImplemented
    assert v.__ge__(object) == NotImplemented
    assert v.__ge__(Version) == NotImplemented
    assert v.__ge__(Version()) == True

# Generated at 2022-06-16 23:22:04.486932
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == Version('1.0')
    assert v1 != '1.0'
    assert v1 != 1.0
    assert v1 != 1
    assert v1 != (1, 0)
    assert v1 != [1, 0]
    assert v1 != {'major': 1, 'minor': 0}
    assert v1 != object()



# Generated at 2022-06-16 23:22:06.358159
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v)

# Generated at 2022-06-16 23:22:08.353890
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:22:11.752439
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)
    assert not (v < v)
    assert v <= v
    assert not (v > v)
    assert v >= v


# Generated at 2022-06-16 23:22:19.550677
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2


# Generated at 2022-06-16 23:22:21.143039
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:33.196835
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2.3') <= Version('1.2.3')
    assert Version('1.2.3') <= Version('1.2.4')
    assert Version('1.2.3') <= Version('1.3.3')
    assert Version('1.2.3') <= Version('2.2.3')
    assert Version('1.2.3') <= Version('1.2.3.0')
    assert Version('1.2.3') <= Version('1.2.3.1')
    assert Version('1.2.3') <= Version('1.2.3.0.0')
    assert Version('1.2.3') <= Version('1.2.3.0.1')
    assert Version('1.2.3') <= Version('1.2.3.0.0.0')
   

# Generated at 2022-06-16 23:22:34.453006
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:22:43.308180
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2.3') <= Version('1.2.3')
    assert Version('1.2.3') <= Version('1.2.4')
    assert Version('1.2.3') <= Version('1.3.3')
    assert Version('1.2.3') <= Version('2.2.3')
    assert not Version('1.2.4') <= Version('1.2.3')
    assert not Version('1.3.3') <= Version('1.2.3')
    assert not Version('2.2.3') <= Version('1.2.3')
    assert Version('1.2.3') <= '1.2.3'
    assert Version('1.2.3') <= '1.2.4'
    assert Version('1.2.3') <= '1.3.3'

# Generated at 2022-06-16 23:22:47.604680
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= '1.2.3'
    assert v <= Version('1.2.3')
    assert not v <= '0.9.9'
    assert not v <= Version('0.9.9')


# Generated at 2022-06-16 23:22:52.166599
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented
    assert v.__lt__(1) == NotImplemented
    assert v.__lt__('') == NotImplemented
    assert v.__lt__(Version()) == NotImplemented

# Generated at 2022-06-16 23:22:59.695582
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert not v == '1.2.4'
    assert not v == Version('1.2.4')
    assert not v == '1.2'
    assert not v == Version('1.2')
    assert not v == '1.2.3.4'
    assert not v == Version('1.2.3.4')


# Generated at 2022-06-16 23:23:00.720180
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented


# Generated at 2022-06-16 23:23:01.973314
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)


# Generated at 2022-06-16 23:23:16.314936
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)

# Generated at 2022-06-16 23:23:17.232655
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True

# Generated at 2022-06-16 23:23:19.531096
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented


# Generated at 2022-06-16 23:23:21.002231
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:23:22.064957
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:23:25.473120
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 == v2


# Generated at 2022-06-16 23:23:28.235786
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == False

# Generated at 2022-06-16 23:23:30.396939
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-16 23:23:31.664179
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True

# Generated at 2022-06-16 23:23:33.194753
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2

# Generated at 2022-06-16 23:23:47.711458
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:23:55.656865
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(None) == NotImplemented
    assert v1.__gt__(1) == NotImplemented
    assert v1.__gt__(1.0) == NotImplemented
    assert v1.__gt__('') == NotImplemented
    assert v1.__gt__('1') == NotImplemented
    assert v1.__gt__('1.0') == NotImplemented
    assert v1.__gt__(u'1') == NotImplemented
    assert v1.__gt__(u'1.0') == NotImplemented
    assert v1.__gt__(b'1') == NotImplemented

# Generated at 2022-06-16 23:23:57.268959
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:24:00.172138
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('1.2.3')
    assert v > '1.2.2'
    assert not v > '1.2.3'
    assert not v > '1.2.4'


# Generated at 2022-06-16 23:24:01.188655
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:24:02.366159
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:24:05.011207
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:24:09.329542
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v2 > v1

# Generated at 2022-06-16 23:24:12.365518
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert v1 >= v2
    assert v1 >= v1
    assert v2 >= v2
    assert v2 >= v1


# Generated at 2022-06-16 23:24:14.094742
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:24:45.941332
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented
    assert v.__eq__(1) is NotImplemented
    assert v.__eq__('') is NotImplemented
    assert v.__eq__(Version()) == 0
    assert v.__eq__(Version('1.0')) == 0
    assert v.__eq__(Version('1.1')) == 0


# Generated at 2022-06-16 23:24:47.014489
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:24:48.863686
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 < v2 == False


# Generated at 2022-06-16 23:24:59.758841
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= Version()
    assert not (v <= Version('1.0'))
    assert not (v <= Version('1.0.0'))
    assert not (v <= Version('1.0.0.0'))
    assert not (v <= Version('1.0.0.0.0'))
    assert not (v <= Version('1.0.0.0.0.0'))
    assert not (v <= Version('1.0.0.0.0.0.0'))
    assert not (v <= Version('1.0.0.0.0.0.0.0'))
    assert not (v <= Version('1.0.0.0.0.0.0.0.0'))

# Generated at 2022-06-16 23:25:12.297406
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert v == Version('1.2.3')
    assert not (v == '1.2.4')
    assert not (v == Version('1.2.4'))
    assert not (v == Version('1.2.4'))
    assert not (v == '1.2')
    assert not (v == Version('1.2'))
    assert not (v == Version('1.2'))
    assert not (v == '1.2.3.4')
    assert not (v == Version('1.2.3.4'))
    assert not (v == Version('1.2.3.4'))

# Generated at 2022-06-16 23:25:18.455932
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 <= v2
    assert not v2 <= v1
    assert v1 <= '1.0'
    assert not v2 <= '1.0'
    assert v1 <= v1
    assert v2 <= v2
    assert not v1 <= '1.1'
    assert v2 <= '1.1'
    assert not v1 <= '2.0'
    assert not v2 <= '2.0'
    assert not v1 <= '0.9'
    assert not v2 <= '0.9'
    assert not v1 <= '1.0.post1'
    assert not v2 <= '1.0.post1'
    assert not v1 <= '1.0.dev1'
    assert not v2

# Generated at 2022-06-16 23:25:21.303292
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True
    assert v.__eq__(None) == NotImplemented

# Generated at 2022-06-16 23:25:22.990963
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:25:25.235347
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:25:27.128949
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2


# Generated at 2022-06-16 23:25:58.779772
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:25:59.696470
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:26:01.751909
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented


# Generated at 2022-06-16 23:26:05.679437
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2


# Generated at 2022-06-16 23:26:07.368144
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:26:08.795016
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v)

# Generated at 2022-06-16 23:26:10.823158
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:26:13.539893
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:26:15.035417
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= v


# Generated at 2022-06-16 23:26:16.927485
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:26:50.730126
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented

# Generated at 2022-06-16 23:26:52.599371
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:26:53.901850
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:27:03.676501
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.2.3')
    assert v <= '1.2.3'
    assert v <= '1.2.4'
    assert not v <= '1.2.2'
    assert not v <= '1.1.3'
    assert not v <= '0.2.3'
    assert not v <= '1.2.3a'
    assert not v <= '1.2.3.4'
    assert not v <= '1.2.3-4'
    assert not v <= '1.2.3_4'
    assert not v <= '1.2.3.4.5'
    assert not v <= '1.2.3.4-5'
    assert not v <= '1.2.3.4_5'

# Generated at 2022-06-16 23:27:12.916151
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.0.0')
    assert Version('1.0') <= Version('1.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0.0.0')
    assert Version('1.0') <= Version('1.0.0.0.0.0.0.0.0')

# Generated at 2022-06-16 23:27:14.845703
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:27:24.682804
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented
    assert v.__lt__('') == NotImplemented
    assert v.__lt__(0) == NotImplemented
    assert v.__lt__(0.0) == NotImplemented
    assert v.__lt__(()) == NotImplemented
    assert v.__lt__([]) == NotImplemented
    assert v.__lt__({}) == NotImplemented
    assert v.__lt__(object()) == NotImplemented
    assert v.__lt__(Version()) == NotImplemented
    assert v.__lt__(StrictVersion()) == NotImplemented
    assert v.__lt__(LooseVersion()) == NotImplemented
    assert v.__lt__(LegacyVersion()) == Not

# Generated at 2022-06-16 23:27:33.470612
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.0') >= '1.0'
    assert not (Version('1.0') >= Version('1.1'))
    assert not (Version('1.0') >= '1.1')
    assert not (Version('1.0') >= Version('2.0'))
    assert not (Version('1.0') >= '2.0')
    assert Version('1.1') >= Version('1.0')
    assert Version('1.1') >= '1.0'
    assert Version('2.0') >= Version('1.0')
    assert Version('2.0') >= '1.0'
    assert not (Version('1.0') >= Version('1.0.post1'))

# Generated at 2022-06-16 23:27:34.679305
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:27:37.196441
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:28:58.416430
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(Version())
    assert v.__ge__(None)
    assert v.__ge__(NotImplemented)
    assert v.__ge__(0)
    assert v.__ge__(1)
    assert v.__ge__(-1)
    assert v.__ge__(1.0)
    assert v.__ge__(-1.0)
    assert v.__ge__(1.0 + 0j)
    assert v.__ge__(-1.0 + 0j)
    assert v.__ge__(True)
    assert v.__ge__(False)
    assert v.__ge__('')
    assert v.__ge__('a')
    assert v.__ge__('0')


# Generated at 2022-06-16 23:28:59.830198
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented


# Generated at 2022-06-16 23:29:04.292374
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 <= v2


# Generated at 2022-06-16 23:29:11.400157
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(Version())
    assert v.__ge__(None)
    assert v.__ge__('')
    assert v.__ge__(0)
    assert v.__ge__(1)
    assert v.__ge__(1.0)
    assert v.__ge__(1.1)
    assert v.__ge__(1.2)
    assert v.__ge__(1.3)
    assert v.__ge__(1.4)
    assert v.__ge__(1.5)
    assert v.__ge__(1.6)
    assert v.__ge__(1.7)
    assert v.__ge__(1.8)

# Generated at 2022-06-16 23:29:14.183631
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert not v.__ge__(1)

# Generated at 2022-06-16 23:29:17.014668
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:29:19.331504
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:29:21.261542
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v
    assert not v == None
    assert v != None

# Generated at 2022-06-16 23:29:26.788890
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented


# Generated at 2022-06-16 23:29:29.936477
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version()
    v2 = Version()
    assert v1.__ge__(v2)
    assert v2.__ge__(v1)
    assert v1.__ge__(v1)
    assert v2.__ge__(v2)
