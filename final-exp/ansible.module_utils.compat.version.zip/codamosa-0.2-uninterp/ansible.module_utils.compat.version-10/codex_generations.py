

# Generated at 2022-06-16 23:20:02.390395
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = StrictVersion("1.2.3")
    assert s.version == (1, 2, 3)
    assert s.prerelease is None

    s = StrictVersion("1.2.3a4")
    assert s.version == (1, 2, 3)
    assert s.prerelease == ('a', 4)

    s = StrictVersion("1.2.3b4")
    assert s.version == (1, 2, 3)
    assert s.prerelease == ('b', 4)

    s = StrictVersion("1.2a4")
    assert s.version == (1, 2, 0)
    assert s.prerelease == ('a', 4)

    s = StrictVersion("1.2b4")
    assert s.version == (1, 2, 0)

# Generated at 2022-06-16 23:20:03.784981
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:20:05.382328
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:20:16.394195
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v.parse('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)
    v.parse('1.2.3b4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 4)
    v.parse('1.2.3.4')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v.parse('1.2.3a4.5')
    assert v.version == (1, 2, 3)

# Generated at 2022-06-16 23:20:19.860021
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:20:28.818418
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2').__str__() == '1.2'
    assert StrictVersion('1.2a1').__str__() == '1.2a1'
    assert StrictVersion('1.2b1').__str__() == '1.2b1'
    assert StrictVersion('1.2.3a1').__str__() == '1.2.3a1'
    assert StrictVersion('1.2.3b1').__str__() == '1.2.3b1'


# Generated at 2022-06-16 23:20:36.925423
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse("1.5.1")
    assert lv.version == [1, 5, 1]
    lv.parse("1.5.2b2")
    assert lv.version == [1, 5, 2, 'b', 2]
    lv.parse("161")
    assert lv.version == [161]
    lv.parse("3.10a")
    assert lv.version == [3, 10, 'a']
    lv.parse("8.02")
    assert lv.version == [8, 2]
    lv.parse("3.4j")
    assert lv.version == [3, 4, 'j']
    lv.parse("1996.07.12")
    assert lv.version == [1996, 7, 12]

# Generated at 2022-06-16 23:20:39.906161
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v
    assert not v < v
    assert v <= v
    assert not v > v
    assert v >= v


# Generated at 2022-06-16 23:20:48.316957
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(None) == NotImplemented
    assert v1.__gt__(1) == NotImplemented
    assert v1.__gt__(1.0) == NotImplemented
    assert v1.__gt__('') == NotImplemented
    assert v1.__gt__('1') == NotImplemented
    assert v1.__gt__('1.0') == NotImplemented
    assert v1.__gt__('1.0.0') == NotImplemented
    assert v1.__gt__('1.0.0.0') == NotImplemented

# Generated at 2022-06-16 23:20:51.715183
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) == NotImplemented

# Generated at 2022-06-16 23:21:06.952677
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert v < '1.2.4'
    assert v < '1.2.3.1'
    assert v < '1.2.3.0.1'
    assert v < '1.2.3.0.0.1'
    assert v < '1.2.3.0.0.0.1'
    assert v < '1.2.3.0.0.0.0.1'
    assert v < '1.2.3.0.0.0.0.0.1'
    assert v < '1.2.3.0.0.0.0.0.0.1'
    assert v < '1.2.3.0.0.0.0.0.0.0.1'

# Generated at 2022-06-16 23:21:08.756431
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:21:10.641341
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-16 23:21:12.605513
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)


# Generated at 2022-06-16 23:21:24.803992
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) is NotImplemented
    assert v.__ge__(1) is NotImplemented
    assert v.__ge__(object()) is NotImplemented
    assert v.__ge__(Version()) == True
    assert v.__ge__(StrictVersion()) == True
    assert v.__ge__(LooseVersion()) == True
    assert v.__ge__(LegacyVersion()) == True
    assert v.__ge__(ComparableVersion()) == True
    assert v.__ge__(NumericVersion()) == True
    assert v.__ge__(NormalizedVersion()) == True
    assert v.__ge__(LocalVersion()) == True
    assert v.__ge__(LocalVersion('1.0')) == True

# Generated at 2022-06-16 23:21:28.716983
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)
    assert not (v < v)
    assert v <= v
    assert not (v > v)
    assert v >= v


# Generated at 2022-06-16 23:21:30.395377
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-16 23:21:32.307269
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented

# Generated at 2022-06-16 23:21:33.666153
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:21:37.238711
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:21:51.487849
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:21:54.416366
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 >= v2

# Generated at 2022-06-16 23:21:57.300593
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True


# Generated at 2022-06-16 23:22:08.405520
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.1') <= Version('1.2')
    assert not Version('1.2') <= Version('1.1')
    assert not Version('1.1') <= Version('1.0')
    assert not Version('1.0') <= Version('0.9')
    assert Version('1.0') <= '1.0'
    assert Version('1.0') <= '1.1'
    assert Version('1.1') <= '1.2'
    assert not Version('1.2') <= '1.1'
    assert not Version('1.1') <= '1.0'
    assert not Version('1.0') <= '0.9'
    assert '1.0'

# Generated at 2022-06-16 23:22:09.877550
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:22:13.063144
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 >= v1
    assert not v1 >= v2
    assert v2 >= v1
    assert v2 >= v2


# Generated at 2022-06-16 23:22:14.658242
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:16.277468
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 <= v2


# Generated at 2022-06-16 23:22:20.034572
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0') <= Version('1.0')
    assert Version('1.0') <= Version('1.1')
    assert Version('1.1') <= Version('1.1')
    assert not Version('1.1') <= Version('1.0')

# Generated at 2022-06-16 23:22:32.198202
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert v.__ge__('')
    assert v.__ge__('1')
    assert v.__ge__(1)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)

# Generated at 2022-06-16 23:22:58.851156
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v


# Generated at 2022-06-16 23:23:00.171159
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:23:01.491220
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented


# Generated at 2022-06-16 23:23:03.096008
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:23:10.692697
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v.parse('1.0')
    assert v <= '1.0'
    assert v <= '1.0.0'
    assert v <= '1.0.0.0'
    assert v <= '1.0.0.0.0'
    assert v <= '1.0.0.0.0.0'
    assert v <= '1.0.0.0.0.0.0'
    assert v <= '1.0.0.0.0.0.0.0'
    assert v <= '1.0.0.0.0.0.0.0.0'
    assert v <= '1.0.0.0.0.0.0.0.0.0'

# Generated at 2022-06-16 23:23:13.174398
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2

# Generated at 2022-06-16 23:23:16.398754
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:23:17.649489
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert not v.__le__(None)


# Generated at 2022-06-16 23:23:18.971089
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2


# Generated at 2022-06-16 23:23:20.377622
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:24:11.413276
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:24:12.783868
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:24:14.751694
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert not v.__le__(None)


# Generated at 2022-06-16 23:24:25.998183
# Unit test for method __lt__ of class Version

# Generated at 2022-06-16 23:24:31.773954
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2


# Generated at 2022-06-16 23:24:33.024462
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:24:34.509906
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:24:36.494377
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1 < v2


# Generated at 2022-06-16 23:24:45.573866
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented
    assert v.__gt__(1) is NotImplemented
    assert v.__gt__('') is NotImplemented
    assert v.__gt__(()) is NotImplemented
    assert v.__gt__([]) is NotImplemented
    assert v.__gt__({}) is NotImplemented
    assert v.__gt__(object()) is NotImplemented
    assert v.__gt__(Version()) is False
    assert v.__gt__(LooseVersion('1')) is False
    assert v.__gt__(LooseVersion('0')) is False
    assert v.__gt__(LooseVersion('0.0')) is False

# Generated at 2022-06-16 23:24:52.606895
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented
    assert v.__ge__(1) == NotImplemented
    assert v.__ge__("") == NotImplemented
    assert v.__ge__(Version()) == True
    assert v.__ge__(StrictVersion()) == True
    assert v.__ge__(LooseVersion()) == True


# Generated at 2022-06-16 23:25:47.125721
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:25:57.537169
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    v = Version('1.2.3')
    assert v > '1.2.2'
    assert v > '1.2'
    assert v > '1'
    assert v > '1.2.3a1'
    assert v > '1.2.3.dev1'
    assert not v > '1.2.3'
    assert not v > '1.2.3.post1'
    assert not v > '1.2.3.post1.dev1'
    assert not v > '1.2.3.post1.dev2'
    assert not v > '1.2.3.post2'
    assert not v > '1.2.4'
    assert not v > '1.3'
    assert not v > '2'

# Generated at 2022-06-16 23:26:03.172202
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(Version())
    assert not v.__le__(None)
    assert not v.__le__(1)
    assert not v.__le__(1.0)
    assert not v.__le__('')
    assert not v.__le__('1')
    assert not v.__le__('1.0')
    assert not v.__le__('1.0.0')
    assert not v.__le__('1.0.0.0')
    assert not v.__le__('1.0.0.0.0')
    assert not v.__le__('1.0.0.0.0.0')

# Generated at 2022-06-16 23:26:04.712305
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:26:06.648737
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()
    assert not (v != Version())

# Generated at 2022-06-16 23:26:07.941676
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= None


# Generated at 2022-06-16 23:26:09.928962
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:26:12.936907
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True
    assert v.__eq__(None) == False

# Generated at 2022-06-16 23:26:14.959224
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(None) == NotImplemented

# Generated at 2022-06-16 23:26:16.540560
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:28:30.724787
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__(v)

# Generated at 2022-06-16 23:28:33.321190
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2


# Generated at 2022-06-16 23:28:41.910871
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented
    assert v.__le__(1) is NotImplemented
    assert v.__le__(1.0) is NotImplemented
    assert v.__le__('') is NotImplemented
    assert v.__le__('1') is NotImplemented
    assert v.__le__(Version()) is True
    assert v.__le__(StrictVersion('1')) is True
    assert v.__le__(LooseVersion('1')) is True

# Generated at 2022-06-16 23:28:47.060112
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert not v == 1
    assert not v == '1'
    assert not v == Version('1')


# Generated at 2022-06-16 23:28:57.713339
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2.3') <= Version('1.2.3')
    assert Version('1.2.3') <= Version('1.2.4')
    assert Version('1.2.3') <= Version('1.2.3a')
    assert Version('1.2.3') <= Version('1.2.3.1')
    assert Version('1.2.3') <= Version('1.2.3.1a')
    assert Version('1.2.3') <= Version('1.2.3.1a1')
    assert Version('1.2.3') <= Version('1.2.3.1a2')
    assert Version('1.2.3') <= Version('1.2.3.1a11')

# Generated at 2022-06-16 23:28:59.348199
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(Version()) == NotImplemented


# Generated at 2022-06-16 23:29:07.073814
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert not v1 == v2
    assert v1 != v2


# Generated at 2022-06-16 23:29:08.619546
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 >= v2

# Generated at 2022-06-16 23:29:13.081120
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:29:16.890228
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version()
    assert not v == Version('1.0')
