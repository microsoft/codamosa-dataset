

# Generated at 2022-06-16 23:20:00.524286
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented
    assert v.__ge__(1) == NotImplemented
    assert v.__ge__(1.0) == NotImplemented
    assert v.__ge__('') == NotImplemented
    assert v.__ge__('1') == NotImplemented
    assert v.__ge__(()) == NotImplemented
    assert v.__ge__([]) == NotImplemented
    assert v.__ge__({}) == NotImplemented
    assert v.__ge__(object()) == NotImplemented

# Generated at 2022-06-16 23:20:02.694790
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) == NotImplemented

# Generated at 2022-06-16 23:20:04.540980
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:20:15.720140
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v.parse('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)
    v.parse('1.2.3b5')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 5)
    v.parse('1.2.3a4.5')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)
    v.parse('1.2.3b5.6')
    assert v.version == (1, 2, 3)
   

# Generated at 2022-06-16 23:20:24.455513
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert v != '1.2.4'
    assert v != Version('1.2.4')
    assert v != '1.2'
    assert v != Version('1.2')
    assert v != '1.2.3.4'
    assert v != Version('1.2.3.4')


# Generated at 2022-06-16 23:20:27.020168
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)

# Generated at 2022-06-16 23:20:29.221800
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert not v >= '1.2.4'

# Generated at 2022-06-16 23:20:38.127802
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2').__str__() == '1.2'
    assert StrictVersion('1.2.3a1').__str__() == '1.2.3a1'
    assert StrictVersion('1.2.3b1').__str__() == '1.2.3b1'
    assert StrictVersion('1.2a1').__str__() == '1.2a1'
    assert StrictVersion('1.2b1').__str__() == '1.2b1'


# Generated at 2022-06-16 23:20:41.360058
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 == v2
    v3 = Version('1.2.4')
    assert v1 != v3

# Generated at 2022-06-16 23:20:42.990439
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) == NotImplemented

# Generated at 2022-06-16 23:20:53.089370
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented

# Generated at 2022-06-16 23:20:54.877543
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-16 23:21:04.977444
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1.__gt__(v2) == False
    assert v1.__gt__('1.2.3') == False
    assert v1.__gt__('1.2.4') == False
    assert v1.__gt__('1.2.2') == True
    assert v1.__gt__('1.3.3') == False
    assert v1.__gt__('2.2.3') == False
    assert v1.__gt__('0.2.3') == True
    assert v1.__gt__('1.2.3.4') == False
    assert v1.__gt__('1.2.3.4.5') == False
    assert v1.__gt__

# Generated at 2022-06-16 23:21:07.539109
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented

# Generated at 2022-06-16 23:21:09.845378
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2
    assert not (v1 != v2)


# Generated at 2022-06-16 23:21:12.654063
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)


# Generated at 2022-06-16 23:21:14.998508
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert not v1.__gt__(v2)

# Generated at 2022-06-16 23:21:27.709173
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented
    assert v.__le__(1) == NotImplemented
    assert v.__le__(1.0) == NotImplemented
    assert v.__le__(1.0+0j) == NotImplemented
    assert v.__le__(True) == NotImplemented
    assert v.__le__(False) == NotImplemented
    assert v.__le__('') == NotImplemented
    assert v.__le__('a') == NotImplemented
    assert v.__le__('0') == NotImplemented
    assert v.__le__('0.0') == NotImplemented

# Generated at 2022-06-16 23:21:36.245882
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(None)
    assert not v.__ge__(1)
    assert not v.__ge__(1.0)
    assert not v.__ge__(1.0j)

# Generated at 2022-06-16 23:21:38.818319
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 >= v2


# Generated at 2022-06-16 23:21:54.025657
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(None) is NotImplemented


# Generated at 2022-06-16 23:21:58.566839
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= v
    assert v <= '1.0'
    assert v <= Version('1.0')
    assert not v <= '0.9'
    assert not v <= Version('0.9')

# Generated at 2022-06-16 23:22:03.755998
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 < v2 == False
    assert v1 <= v2 == True
    assert v1 > v2 == False
    assert v1 >= v2 == True
    assert v1 == v2 == True
    assert v1 != v2 == False


# Generated at 2022-06-16 23:22:07.581189
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented
    assert v.__lt__(1) is NotImplemented
    assert v.__lt__('') is NotImplemented
    assert v.__lt__(()) is NotImplemented
    assert v.__lt__([]) is NotImplemented
    assert v.__lt__({}) is NotImplemented
    assert v.__lt__(object()) is NotImplemented
    assert v.__lt__(Version()) is NotImplemented

# Generated at 2022-06-16 23:22:09.045809
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:10.420233
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented


# Generated at 2022-06-16 23:22:19.257784
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2
    assert v1 <= v2
    assert v2 > v1
    assert v2 >= v1
    assert v1 != v2
    assert v1 == Version('1.0')
    assert v1 != Version('1.0.0')
    assert v1 != Version('1.0.0.0')
    assert v1 != Version('1.0.0.0.0')
    assert v1 != Version('1.0.0.0.0.0')
    assert v1 != Version('1.0.0.0.0.0.0')
    assert v1 != Version('1.0.0.0.0.0.0.0')

# Generated at 2022-06-16 23:22:20.821723
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:22:24.613582
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented
    assert v.__le__(1) == NotImplemented

# Generated at 2022-06-16 23:22:26.577322
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v

# Generated at 2022-06-16 23:22:52.745269
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    assert v1 <= v2


# Generated at 2022-06-16 23:23:03.389864
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2.3') >= Version('1.2.3')
    assert not Version('1.2.3') >= Version('1.2.4')
    assert not Version('1.2.3') >= Version('1.3.3')
    assert not Version('1.2.3') >= Version('2.2.3')
    assert not Version('1.2.3') >= Version('1.2.3.post1')
    assert not Version('1.2.3') >= Version('1.2.3.dev1')
    assert not Version('1.2.3') >= Version('1.2.3.dev1.post1')
    assert not Version('1.2.3') >= Version('1.2.3.dev1.post1.dev2')
    assert not Version('1.2.3')

# Generated at 2022-06-16 23:23:10.905653
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(Version())
    assert v.__ge__(None)
    assert v.__ge__(1)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge__(1.0)
    assert v.__ge

# Generated at 2022-06-16 23:23:12.819102
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:23:23.391354
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)
    assert v.__ge__(None)
    assert v.__ge__('')
    assert v.__ge__(0)
    assert v.__ge__(1)
    assert v.__ge__(1.0)
    assert v.__ge__(1.1)

# Generated at 2022-06-16 23:23:25.618297
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(1) == NotImplemented


# Generated at 2022-06-16 23:23:28.384122
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v)
    assert not v.__eq__(None)

# Generated at 2022-06-16 23:23:30.917589
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v) == True
    assert v.__ge__(None) == NotImplemented


# Generated at 2022-06-16 23:23:32.176611
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-16 23:23:34.578660
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented


# Generated at 2022-06-16 23:24:25.531589
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:24:30.076256
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)
    assert not (v < v)
    assert v <= v
    assert not (v > v)
    assert v >= v


# Generated at 2022-06-16 23:24:36.217319
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert (v1 < v2) == True
    assert (v1 <= v2) == True
    assert (v1 == v2) == False
    assert (v1 != v2) == True
    assert (v1 >= v2) == False
    assert (v1 > v2) == False


# Generated at 2022-06-16 23:24:45.297868
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == NotImplemented
    assert v1.__gt__(None) == NotImplemented
    assert v1.__gt__(1) == NotImplemented
    assert v1.__gt__(1.0) == NotImplemented
    assert v1.__gt__(True) == NotImplemented
    assert v1.__gt__(False) == NotImplemented
    assert v1.__gt__('') == NotImplemented
    assert v1.__gt__('1') == NotImplemented
    assert v1.__gt__('1.0') == NotImplemented
    assert v1.__gt__('1.0.0') == NotImplemented
    assert v1.__

# Generated at 2022-06-16 23:24:46.654090
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) == NotImplemented


# Generated at 2022-06-16 23:24:48.376777
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= v

# Generated at 2022-06-16 23:24:52.196738
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not (v != v)
    assert not (v < v)
    assert v <= v
    assert not (v > v)
    assert v >= v

# Generated at 2022-06-16 23:24:55.244710
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert v1.__gt__(v2) == False


# Generated at 2022-06-16 23:24:56.934535
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented


# Generated at 2022-06-16 23:25:00.865182
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 < v2
    assert v1 <= v2
    assert not v1 == v2
    assert v1 != v2
    assert not v1 > v2
    assert not v1 >= v2


# Generated at 2022-06-16 23:26:50.826501
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v
    assert not v == None
    assert v != None

# Generated at 2022-06-16 23:27:00.864904
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2.3') <= Version('1.2.3')
    assert Version('1.2.3') <= Version('1.2.4')
    assert Version('1.2.3') <= Version('1.2.3a')
    assert Version('1.2.3') <= Version('1.2.3.0')
    assert Version('1.2.3') <= Version('1.2.3.0.0')
    assert Version('1.2.3') <= Version('1.2.3.0.0.0')
    assert Version('1.2.3') <= Version('1.2.3.0.0.0.0')
    assert Version('1.2.3') <= Version('1.2.3.0.0.0.0.0')

# Generated at 2022-06-16 23:27:02.237802
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True

# Generated at 2022-06-16 23:27:04.849936
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented

# Generated at 2022-06-16 23:27:08.797857
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest
    class Version___eq__1(unittest.TestCase):
        def test(self):
            """Unit test for method __eq__ of class Version"""
            v = Version()
            self.assertEqual(v.__eq__(v), True)
    unittest.main()


# Generated at 2022-06-16 23:27:10.281552
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)

# Generated at 2022-06-16 23:27:11.711878
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(v) == True

# Generated at 2022-06-16 23:27:22.385942
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= '1.0'
    assert v >= '1.0'
    assert v == '1.0'
    assert v != '1.1'
    assert v < '1.1'
    assert v <= '1.1'
    assert v != '0.9'
    assert v > '0.9'
    assert v >= '0.9'
    assert v != '1.0.0'
    assert v != '1.0.1'
    assert v != '1.0.0.0'
    assert v != '1.0.0.1'
    assert v != '1.0.0.0.0'
    assert v != '1.0.0.0.1'
    assert v != '1.0.0.0.0.0'
   

# Generated at 2022-06-16 23:27:29.942835
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert v == Version()
    assert v == Version('')
    assert v == Version('0')
    assert v == Version('0.0')
    assert v == Version('0.0.0')
    assert v == Version('0.0.0.0')
    assert v == Version('0.0.0.0.0')
    assert v == Version('0.0.0.0.0.0')
    assert v == Version('0.0.0.0.0.0.0')
    assert v == Version('0.0.0.0.0.0.0.0')
    assert v == Version('0.0.0.0.0.0.0.0.0')

# Generated at 2022-06-16 23:27:30.690231
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)


# Generated at 2022-06-16 23:29:44.469932
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    v2 = Version('2.0')
    assert v1 < v2