

# Generated at 2022-06-22 22:22:36.931579
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils2.version import Version
    v = Version()
    v1 = Version("1.0")
    v10 = Version("1.0")
    assert v == v1
    assert v10 == v1

# Generated at 2022-06-22 22:22:46.419527
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    str_vers = (
        '1.0', '1.0.0', '1.1', '1.2', '1.2.1', '1.3a1',
        '1.3b1', '1.3c1', '1.3.0.0', '0.4', '0.4.1',
        '0.5a1', '0.5b3', '0.5', '1.0pre1', '1.0pre2')

    if __debug__:
        # if we're not in optimized mode, check that our prerelease
        # patterns are right
        r = StrictVersion.version_re
        t1 = ('1.0a1', ('1', '0', '', 'a1', '1'))

# Generated at 2022-06-22 22:22:57.439410
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Method __ge__ of class Version.

    This method tests if the method __ge__ works as expected.
    """
    from distutils2.version import LooseVersion
    version1 = LooseVersion('1.3')
    version2 = LooseVersion('1.3')
    assert(version1 >= version2)
    version1 = LooseVersion('1.2.1')
    version2 = LooseVersion('1.2')
    assert(version1 >= version2)
    version1 = LooseVersion('1.3dev3')
    version2 = LooseVersion('1.3a3')
    assert(version1 >= version2)
    version1 = LooseVersion('1.2.1.dev2')
    version2 = LooseVersion('1.2.dev2')
    assert(version1 >= version2)


# Generated at 2022-06-22 22:22:59.944657
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  v1 = Version(None)
  v2 = Version(None)
  r = v1.__ge__(v2)
  assert True


# Generated at 2022-06-22 22:23:12.058053
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:23:17.060132
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils2.version import Version
    from types import *
    c = Version()
    assert c is not None, "Unable to construct an instance of Version"
    assert isinstance(c, Version)
    try:
        assert c.__ge__('1') == NotImplemented
    except Exception as e:
        raise AssertionError(e)
    try:
        assert c.__ge__(None) is False
    except Exception as e:
        raise AssertionError(e)



# Generated at 2022-06-22 22:23:21.425540
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion("1.0.0").__str__() == "1.0.0"
    assert LooseVersion("non-digit-stuff").__str__() == "non-digit-stuff"


# Generated at 2022-06-22 22:23:30.416717
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion("1.1").__str__() == "1.1"
    assert LooseVersion("10.2").__str__() == "10.2"
    assert LooseVersion("1.a").__str__() == "1.a"
    assert LooseVersion("1.1.1").__str__() == "1.1.1"
    assert LooseVersion("1.2.3").__str__() == "1.2.3"
    assert LooseVersion("1.1a1").__str__() == "1.1a1"
    assert LooseVersion("1.1.1a1").__str__() == "1.1.1a1"
    assert LooseVersion("1.1.1+").__str__() == "1.1.1+"
    assert LooseVersion

# Generated at 2022-06-22 22:23:33.425222
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    version = Version()
    other = 1
    exit_return = version.__gt__(other)
    assert exit_return == NotImplemented

# Generated at 2022-06-22 22:23:40.050610
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0.0') <= Version('1.0.0')
    assert not Version('1.0.1') <= Version('1.0.0')
    assert not Version('2.0.0') <= Version('1.0.0')


    # Test that strings are converted to Version objects
    assert Version('1.0.0') <= '1.0.0'
    assert not Version('1.0.1') <= '1.0.0'
    assert not Version('2.0.0') <= '1.0.0'

# Generated at 2022-06-22 22:23:46.126957
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3b4')
    assert v.__str__() == '1.2.3b4'

    # Test trailing zero in minor
    v = StrictVersion('1.2.0b4')
    assert v.__str__() == '1.2.0b4'



# Generated at 2022-06-22 22:23:49.932997
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # Arrange
    v1 = LooseVersion("0.960923")
    # Act
    v = str(v1)
    # Assert
    assert v == "0.960923"


# Generated at 2022-06-22 22:24:01.962163
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion.__str__(StrictVersion('0.4')) == '0.4'
    assert StrictVersion.__str__(StrictVersion('0.4.0')) == '0.4.0'
    assert StrictVersion.__str__(StrictVersion('0.4.1')) == '0.4.1'
    assert StrictVersion.__str__(StrictVersion('0.5a1')) == '0.5a1'
    assert StrictVersion.__str__(StrictVersion('0.5b3')) == '0.5b3'
    assert StrictVersion.__str__(StrictVersion('0.5')) == '0.5'

# Generated at 2022-06-22 22:24:04.424134
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    from .tests.test_distutils.test_version import StrictVersionTestCase
    import doctest
    doctest.testmod(StrictVersionTestCase)



# Generated at 2022-06-22 22:24:08.221338
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.2.3a2') < Version('1.2.4b') == True
    assert Version('1.2.3a2') < Version('1.2.3') == False
    assert Version('1.2.3a2') < Version('1.2.3a2') == False

# Generated at 2022-06-22 22:24:14.247304
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('4.0')
    v2 = Version('4.1')
    assert (v1 < v2) is True
    assert (v1 <= v2) is True
    assert (v1 > v2) is False
    assert (v1 >= v2) is False
    assert (v1 == v2) is False
    assert (v1 != v2) is True


# Generated at 2022-06-22 22:24:18.183603
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.2.3").__str__() == '1.2.3', \
           "ValueError not raised by StrictVersion.__str__()"
    try:
        assert StrictVersion("1.2.3").__str__() == '1.2.3', \
               "ValueError not raised by StrictVersion.__str__()"
    except ValueError:
        pass
    else:
        raise AssertionError("ValueError not raised by StrictVersion.__str__()")

# Generated at 2022-06-22 22:24:28.190437
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert str(StrictVersion("1.2.3a4")) == "1.2.3a4"
    assert str(StrictVersion("1.2.3b4")) == "1.2.3b4"
    assert str(StrictVersion("1.2.3c4")) == "1.2.3c4"
    assert str(StrictVersion("1.2.3.0")) == "1.2.3"

    # Try representing a version specifier (see PEP 345) which isn't
    # a version identifier.
    try:
        StrictVersion("1.2rc1")
    except ValueError as e:
        assert str(e) == "invalid version number '1.2rc1'"
    else:
        assert False, "expected ValueError"



# Generated at 2022-06-22 22:24:29.902035
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert (v.__gt__(None) is NotImplemented)


# Generated at 2022-06-22 22:24:33.168827
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    v = Version('0.4')
    assert v < '1.0'
    assert v < '0.4.0'
    assert not v < '0.3'
    assert not v < '0.4'

# Generated at 2022-06-22 22:24:39.688929
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    sv = StrictVersion()
    #=====================
    v = '0.4'
    sv.parse(v)
    assert sv.version == (0, 4, 0)
    assert sv.prerelease == None
    assert str(sv) == v
    #=====================
    v = '0.4.0'
    sv.parse(v)
    assert sv.version == (0, 4, 0)
    assert sv.prerelease == None
    assert str(sv) == v
    #=====================
    v = '0.4.1'
    sv.parse(v)
    assert sv.version == (0, 4, 1)
    assert sv.prerelease == None
    assert str(sv) == v
    #=====================
    v = '0.5a1'

# Generated at 2022-06-22 22:24:43.895679
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.2')
    assert str(v) == '1.2'
    v = LooseVersion('2.2beta29')
    assert str(v) == '2.2beta29'
    v = LooseVersion('11g')
    assert str(v) == '11g'

# Generated at 2022-06-22 22:24:46.581374
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    Version('1.0').__repr__()

# Generated at 2022-06-22 22:24:48.710941
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    c = Version()
    assert c.__gt__("0.1") == False


# Generated at 2022-06-22 22:24:51.216856
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    class_version = Version
    version = class_version(vstring=None)
    other = None
    assert version._cmp(other) is NotImplemented

# Generated at 2022-06-22 22:24:53.630198
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    x = LooseVersion("1.5.1")
    y = LooseVersion("1.5.2b3")
    y2 = LooseVersion("161")



# Generated at 2022-06-22 22:25:01.226513
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    # Test with an instance of Version as the right hand operand
    v1 = Version()
    v2 = Version()
    v2.parse('01.23.45a6')
    assert v1 == v1, 'expected v1 == v1'
    assert not v1 == v2, 'expected not v1 == v2'

    # Test with a string as the right hand operand
    assert v1 == '', 'expected v1 == ""'
    assert v2 == '01.23.45a6', 'expected v2 == "01.23.45a6"'
    assert not v1 == '01.23.45a6', 'expected not v1 == "01.23.45a6"'

# Generated at 2022-06-22 22:25:04.344871
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version("1.2")
    assert (v >= "1.1")
    assert (v >= v)
    assert (not (v >= "1.3"))
    assert (not (v >= 42))

# Generated at 2022-06-22 22:25:12.866527
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    version_info = (1, 2, 3, 'alpha', 1)
    version_string = '1.2.3a1'
    v = StrictVersion(*version_info)
    assert str(v) == version_string
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 1)

    v = StrictVersion(version_string)
    assert str(v) == version_string
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 1)



# Generated at 2022-06-22 22:25:18.797896
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import inspect
    import re
    import os
    import sys

    if sys.version_info >= (3,):
        return

    if os.path.exists('looseversion.pyc'):
        os.remove('looseversion.pyc')

    if os.path.exists('looseversion.py'):
        os.remove('looseversion.py')

    from distutils import version
    import imp

    imp.reload(version)

    exec('from looseversion import LooseVersion')

    src = inspect.getsource(version.LooseVersion)
    count = 0
    for line in src.split('\n'):
        if re.search('__str__', line):
            continue
        count += 1

# Generated at 2022-06-22 22:25:23.354281
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    import unittest
    import sys
    class Test(unittest.TestCase):
        def test_instance(self):
            # The format of the instance representation is fixed
            # so we simply verify that it is present
            self.assertRegex(repr(Version()), "^Version\('',\)$")
    Test().test_instance()

# Generated at 2022-06-22 22:25:25.346757
# Unit test for method __le__ of class Version
def test_Version___le__():
    class Super:
        def __le__(self, rhs):
            return 42

    class Sub(Version, Super):
        def parse(self, vstring):
            self.ver = vstring

    subinst = Sub('42')
    assert subinst <= 'hello'
    assert subinst <= Super()

# Generated at 2022-06-22 22:25:28.054768
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v._cmp = lambda other: 0
    result = v.__le__(None)
    assert result is True
    result = v.__le__(object())
    assert result is NotImplemented

# Generated at 2022-06-22 22:25:32.704092
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion(None)
    v.version = (2, 5, 6)
    assert str(v) == '2.5.6'
    v.version = (1, 0)
    assert str(v) == '1.0'
    v.version = (2, 5, 6)
    v.prerelease = ('a', 42)
    assert str(v) == '2.5.6a42'
    v.prerelease = ('b', 1)
    assert str(v) == '2.5.6b1'


# Generated at 2022-06-22 22:25:43.354313
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def test_cmp(v1, v2):
        if vercmp(LooseVersion(v1), LooseVersion(v2)) != 0:
            # Some version of CVS's python version string is not
            # fully numeric. If the version number is followed by
            # a heavy-chained string, strip it before trying the
            # comparison again.
            l = v2.split('_', 1)
            if len(l) == 2 and vercmp(LooseVersion(v1),
                                      LooseVersion(l[0])) == 0:
                return
            raise AssertionError("%s != %s" % (v1, v2))


# Generated at 2022-06-22 22:25:49.052851
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import sys
    if sys.version_info[0:2] == (2, 3):
        return
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2.3a1').__str__() == '1.2.3a1'
    assert StrictVersion('1.2.3a1.post1').__str__() == '1.2.3a1'
    assert StrictVersion('1.2.3a1.dev1').__str__() == '1.2.3a1'
    assert StrictVersion('1.2.3.dev1').__str__() == '1.2.3.dev1'


# Generated at 2022-06-22 22:25:51.867852
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    cv = LooseVersion ('1.5.1')
    assert cv.__str__ () == '1.5.1'
    assert str (cv) == '1.5.1'



# Generated at 2022-06-22 22:25:54.062329
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"


# Generated at 2022-06-22 22:25:57.743163
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.9.7-rc')
    assert str(v) == '1.9.7-rc'



# Generated at 2022-06-22 22:26:00.733050
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from . import version_data
    for (args, expected) in version_data.StrictVersion_tests:
        result = StrictVersion(*args).__eq__(expected)
        assert result == args[1] == expected


# Generated at 2022-06-22 22:26:05.217052
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """Test LooseVersion.__str__()"""

    lv = LooseVersion([1,13,'++'])
    assert lv.__str__() == "1.13++"

    lv2 = LooseVersion()
    assert lv2.__str__() == ""

    lv3 = LooseVersion([1,0,'RC',12])
    assert lv3.__str__() == "1.0RC12"


# Generated at 2022-06-22 22:26:09.987218
# Unit test for constructor of class Version
def test_Version():
    x = Version('1.2.3')
    assert x.__class__.__name__ == 'Version'
    assert str(x) == '1.2.3'
    assert repr(x) == "Version ('1.2.3')"


# Generated at 2022-06-22 22:26:14.666727
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.4')
    v2 = Version('1.4')
    assert (v1 >= v2)

    v3 = Version('1.5')
    assert (v3 >= v1)
    assert (not (v1 >= v3))

# Generated at 2022-06-22 22:26:21.600127
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from Version import Version

    # Create an instance of Version
    version = Version()

    # Call instance method _cmp
    # version._cmp is NotImplemented by default
    assert version._cmp is NotImplemented

    # Assign parameter 'other'
    other = "Before python, there was ABC"

    # Call instance method _cmp and save result
    result = version._cmp(other)

    # Assert result is NotImplemented
    assert result is NotImplemented

    # Assign parameter 'other'
    other = "ABC is a programming language too!"

    # Call instance method _cmp and save result
    result = version._cmp(other)

    # Assert result is NotImplemented
    assert result is NotImplemented

    # Assign parameter 'other'
    other = "is a programming language too!"

    # Call

# Generated at 2022-06-22 22:26:25.832782
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Test that __ge__ is reflexive
    assert(Version() >= Version())
    # Test that __ge__ is transitive
    assert(Version() >= Version() >= Version())
    # Test that __ge__ is anti-symmetric
    assert(Version() >= Version() <= Version())
    # Test that __ge__ is consistent
    assert(Version() >= Version() == Version() >= Version())



# Generated at 2022-06-22 22:26:39.255723
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    try:
        assert (Version() >= Version())
        assert (Version() >= 0)
        assert (0 <= Version())
        assert (Version() >= '')
        assert ('' <= Version())
        assert (Version() >= 'a')
        assert ('a' <= Version())
    except Exception as e:
        return e



# Generated at 2022-06-22 22:26:42.349901
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert repr(LooseVersion ('1.2a2')) == "LooseVersion ('1.2a2')"

# Generated at 2022-06-22 22:26:48.021368
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.1')
    v2 = Version('1.2')
    assert v1 > v2  # __gt__
    assert not v1 > v1  # __gt__
    assert not v2 > v1  # __gt__
    assert not v2 > v2  # __gt__

# Generated at 2022-06-22 22:26:56.571187
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    cases = [("0.4.0", (0, 4, 0)),
             ("1.0", (1, 0, 0)),
             ("1.0.4a3", (1, 0, 4)),
             ("1.0.4b1", (1, 0, 4)),
             ("1.0.4", (1, 0, 4)),
            ]
    for vstring, parsed in cases:
        got = str(StrictVersion(vstring))
        if got != vstring:
            raise AssertionError("StrictVersion constructor failed: "
                                 "expected %s, got %s" % (vstring, got))
        got = StrictVersion(vstring).version

# Generated at 2022-06-22 22:27:03.253464
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def parse_error(t):
        try:
            StrictVersion(t)
        except ValueError:
            pass
        else:
            print('StrictVersion not raising error:', t)

    parse_error('1')
    parse_error('2.7.2.2')
    parse_error('1.3.a4')
    parse_error('1.3pl1')
    parse_error('1.3c4')


# Generated at 2022-06-22 22:27:06.304297
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    d = pkg_resources.parse_version('2.2')._cmp(pkg_resources.parse_version('2.20'))
    print(d)

# Generated at 2022-06-22 22:27:15.420277
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring, err=None):
        try:
            StrictVersion(vstring)
        except ValueError:
            if err:
                return
            raise AssertionError("invalid version raised ValueError")

        if err:
            raise AssertionError("valid version didn't raise ValueError")

    test('1.2.3a0')
    test('1.2.0')
    test('1.2')
    test('1.2rc3')
    test('1.2.0rc3')
    test('1.2.0.0rc3')
    test('1.2.0.0.0rc3')
    test('1.2.0.0.0.0rc3')

    test('1.2.3.4')
    test('a.b.c.d')


# Generated at 2022-06-22 22:27:17.300368
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    inst_1 = Version()
    assert repr(inst_1) == "Version ('0')"


# Generated at 2022-06-22 22:27:29.344298
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # StrictVersion.parse(version_string) -> None
    # Must raise ValueError for invalid version_string
    # Must set the version attribute for a valid string
    # Test valid args
    s = StrictVersion()
    assert not hasattr(s, 'version')
    s.parse('1.2.3.4')
    assert s.version == (1, 2, 3, 4)
    s.parse('10.20.30.40')
    assert s.version == (10, 20, 30, 40)
    # Test invalid args
    try:
        s.parse('x.y.z')
        raise AssertionError('Failed to raise ValueError on x.y.z')
    except ValueError:
        pass

# Generated at 2022-06-22 22:27:31.829573
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():

    # test that it returns a string 
    assert isinstance(LooseVersion("0.0.0").__str__(), str)


# Generated at 2022-06-22 22:27:33.812500
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.0')
    assert repr(v) == "Version ('1.0')"

# Generated at 2022-06-22 22:27:39.347887
# Unit test for constructor of class Version
def test_Version():
    vcs = ('0.4', '1.0', '1.1')
    for v in vcs:
        v1 = Version(v)
        assert str(v1) == v, "expected '%s', got '%s'" % (v, str(v1))
        v2 = eval(repr(v1))
        assert str(v2) == v, "expected '%s', got '%s'" % (v, str(v2))


# Generated at 2022-06-22 22:27:50.305440
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:28:01.433045
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():

    # test if floats and strings can be combined in a version
    # and if we can sort them
    a = LooseVersion('1.0.0')
    b = LooseVersion('1.0.0.0.0')
    c = LooseVersion('1.0.0b')
    d = LooseVersion('1.0.0b-1')
    e = LooseVersion('1.0.0b1')
    f = LooseVersion('1.0.0rc')
    g = LooseVersion('1.0.0.dev1')
    h = LooseVersion('1.0.0.post1')
    i = LooseVersion('1.0.0.post0.dev1')
    j = LooseVersion('1.0.0+build1')


# Generated at 2022-06-22 22:28:06.325744
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  v = Version()
  assert (v >= v) == True
  assert (v <= v) == True
  assert (v < v) == False
  assert (v > v) == False



# Generated at 2022-06-22 22:28:09.094667
# Unit test for constructor of class Version
def test_Version():
    # Verify that string argument gets ignored
    v1 = Version("ignored")
    v2 = Version()
    assert str(v1) == str(v2)


# Generated at 2022-06-22 22:28:13.754378
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('None')"

    v = Version("blah")
    assert repr(v) == "Version ('blah')"



# Generated at 2022-06-22 22:28:15.532074
# Unit test for method __lt__ of class Version
def test_Version___lt__():
	assert Version().__lt__(Version()) == NotImplemented

# Generated at 2022-06-22 22:28:21.081016
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    for item in get_Version___eq___test_data():
        v1, v2, expected = item
        v1 = Version(v1)
        v2 = Version(v2)
        actual = (v1 == v2)
        assert actual == expected


# Generated at 2022-06-22 22:28:24.031318
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    import doctest
    return doctest.run_docstring_examples(
        LooseVersion.__repr__, globals(),
        name="LooseVersion.__repr__")


# Generated at 2022-06-22 22:28:31.414514
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = StrictVersion('0.4')
    assert s.version == (0, 4, 0), "error setting major/minor/patch"
    assert s.prerelease == None, "error setting prerelease"
    s = StrictVersion('0.4.0')
    assert s.version == (0, 4, 0), "error setting major/minor/patch"
    assert s.prerelease == None, "error setting prerelease"
    s = StrictVersion('0.4.1')
    assert s.version == (0, 4, 1), "error setting major/minor/patch"
    assert s.prerelease == None, "error setting prerelease"
    s = StrictVersion('0.4.1')
    assert s.version == (0, 4, 1), "error setting major/minor/patch"
   

# Generated at 2022-06-22 22:28:40.246248
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v1 = StrictVersion('1.1.1')
    s1 = str(v1)
    assert( s1 == '1.1.1' )

    v2 = StrictVersion('1.2a1')
    s2 = str(v2)
    assert( s2 == '1.2a1' )

    v3 = StrictVersion('1.2b1')
    s3 = str(v3)
    assert( s3 == '1.2b1' )

    v4 = StrictVersion('1.2')
    s4 = str(v4)
    assert( s4 == '1.2' )

# Generated at 2022-06-22 22:28:43.552082
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    v = Version('1.1')
    assert not v.__lt__(v)
    assert v.__lt__(v + 1)



# Generated at 2022-06-22 22:28:54.872045
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Note: examples/test_version.py also contains tests
    # for this class, but that's a wonderful example of
    # how *NOT* to write a unit test...
    # Here are some tests, which are derived from the
    # examples given in the module doc string:

    v = StrictVersion('0.4')
    assert str(v) == '0.4'
    v = StrictVersion('0.4.0')
    assert str(v) == '0.4'
    v = StrictVersion('0.4.1')
    assert str(v) == '0.4.1'
    v = StrictVersion('0.5a1')
    assert str(v) == '0.5a1'
    v = StrictVersion('0.5b3')

# Generated at 2022-06-22 22:29:06.053358
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Simple replacements
    assert str(StrictVersion("1.2.3.foo")) == '1.2.3'
    assert str(StrictVersion("1.2.3-")) == '1.2.3'
    assert str(StrictVersion("1.2.3-foo")) == '1.2.3'
    assert str(StrictVersion("1.2.3-4")) == '1.2.3'
    assert str(StrictVersion("1.2.3-4foo")) == '1.2.3'
    assert str(StrictVersion("1.2.3-4foo5")) == '1.2.3'
    assert str(StrictVersion("1.2.3-45")) == '1.2.3'
    assert str(StrictVersion("1.2.3-45foo"))

# Generated at 2022-06-22 22:29:17.359869
# Unit test for method __eq__ of class Version

# Generated at 2022-06-22 22:29:26.349071
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # verify that parse() goes through the expected sequence of
    # steps to figure out whether or not it has a prerelease tag.
    # (this behaviour was broken in 0.9.6)

    class MockStrictVersion(StrictVersion):
        def __init__(self, vstring):
            self._parse = []
            StrictVersion.__init__(self, vstring)

        def parse(self, vstring):
            self._parse.append(vstring)
            StrictVersion.parse(self, vstring)

    v = MockStrictVersion("1.7a1")
    assert v._parse == ["1.7a1", "1.7", "1.7a1"], v._parse

    v = MockStrictVersion("1.7.1a1")

# Generated at 2022-06-22 22:29:37.230482
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # This is a generated test to see if the method __gt__ of class Version generates the correct output per input
    # The function WILL fail on an incorrect output. However, there is no known inputs for which this happens
    # If this function fails, please check the partial_ordering_test and make sure all outputs are correct
    assert (Version('1.0') > Version('0.9')), "Cannot order version '1.0' and version '0.9'"
    assert (Version('0.0.5') > Version('0.0.4')), "Cannot order version '0.0.5' and version '0.0.4'"
    assert not (Version('0.9') > Version('1.0')), "False positive when ordering version '0.9' and version '1.0'"

# Generated at 2022-06-22 22:29:41.512416
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import pytest

    v = LooseVersion()

    # Give a verbose error message
    with pytest.raises(ValueError, match="invalid version number 'A'"):
        v.parse('A')

# Generated at 2022-06-22 22:29:51.541299
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert str(LooseVersion('1.2a2'))=='1.2a2'
    assert str(LooseVersion('12'))=='12'
    assert str(LooseVersion('1.2b3'))=='1.2b3'
    assert str(LooseVersion('1.2a'))=='1.2a'
    assert str(LooseVersion('1.2b'))=='1.2b'
    assert str(LooseVersion('1.2.4'))=='1.2.4'
    assert str(LooseVersion('1.2.3a'))=='1.2.3a'
    assert str(LooseVersion('1.2.0'))=='1.2.0'

# Generated at 2022-06-22 22:30:01.009150
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    cases = {
        (0, 0, 0): '0.0',
        (0, 0, 1): '0.0.1',
        (1, 2, 3): '1.2.3',
        (1, 2, 0): '1.2',
        (1, 0, 0): '1.0',
    }

    for v in cases:
        sv = StrictVersion(f'{v[0]}.{v[1]}.{v[2]}')
        assert str(sv) == cases[v], f'{v}'


# Generated at 2022-06-22 22:30:11.481694
# Unit test for constructor of class Version
def test_Version():
    """Test Version's constructor.
    """
    # empty string -> default instance
    v = Version()
    assert v._cmp("0") == 0, "_cmp(0) should return 0 for empty string"

    # 'simple' strings
    for vs in ("0", "1.2", "1.2.3", "1.2.3.4"):
        v = Version(vs)
        assert str(v) == vs

    # test ordering
    assert Version('2') > Version('1'), "2 > 1"
    assert Version('1.3') > Version('1.2'), "1.3 > 1.2"
    assert Version('1.2.3') > Version('1.2.2'), "1.2.3 > 1.2.2"
    assert Version('2') >= Version('1'), "2 >= 1"

# Generated at 2022-06-22 22:30:13.558114
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.0')
    assert v < '1.1'


# Generated at 2022-06-22 22:30:16.817693
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    version = LooseVersion('1.4.3')
    assert str(version) == '1.4.3', str(version)

# Generated at 2022-06-22 22:30:27.573201
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.2a3").__str__() == "1.2a3"
    assert StrictVersion("1.2b3").__str__() == "1.2b3"
    assert StrictVersion("1.2a2").__str__() == "1.2a2"
    assert StrictVersion("1.2b2").__str__() == "1.2b2"
    assert StrictVersion("1.2.0").__str__() == "1.2"
    assert StrictVersion("1.2.0a3").__str__() == "1.2a3"
    assert StrictVersion("1.2.0b3").__str__() == "1.2b3"

# Generated at 2022-06-22 22:30:29.282659
# Unit test for method __le__ of class Version
def test_Version___le__():
    Version.__le__(1, 2)


# Generated at 2022-06-22 22:30:37.519354
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:30:41.662508
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion('1.0a1')
    assert str(v) == '1.0a1'
    assert repr(v) == "StrictVersion ('1.0a1')"



# Generated at 2022-06-22 22:30:43.912203
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version("1.2.3")
    assert v >= "1.2.3-rc"
    assert not v >= "1.2.4"

# Generated at 2022-06-22 22:30:48.228877
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 >= v2



# Generated at 2022-06-22 22:30:57.198466
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def compare_to_expected(s, expected):
        lv = LooseVersion(s)
        if lv.version != expected:
            raise AssertionError("%s: expected %s, got %s" %
                                 (s, expected, lv.version))

    compare_to_expected("1.5.1", [1, 5, 1])
    compare_to_expected("1.5.2b2", [1, 5, 2, "b2"])
    compare_to_expected("161", [161])
    compare_to_expected("3.10a", [3, 10, "a"])
    compare_to_expected("8.02", [8, 2])
    compare_to_expected("3.4j", [3, 4, "j"])

# Generated at 2022-06-22 22:31:01.978709
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    instance = Version('1.1')
    other = '1.1'
    expected = True
    actual = instance.__ge__(other)
    assert actual is expected, 'Test for method __ge__ of class Version failed'

# Generated at 2022-06-22 22:31:08.304518
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from lib2to3.fixes.fix_imports2 import _MAGIC_NUMBER
    v = Version()
    assert repr(v) == 'Version ()'
    v = Version('42')
    assert repr(v) == "Version ('42')"
    v = Version(str(__name__) + str(_MAGIC_NUMBER))
    assert repr(v) == "Version ('lib2to3.fixes.fix_imports2.py269')"



# Generated at 2022-06-22 22:31:11.891065
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion("1.1.1") == StrictVersion("1.1.1")
    assert StrictVersion("1.2.1") >= StrictVersion("1.2")
    assert StrictVersion("1.2") <= StrictVersion("1.2.1")
    assert StrictVersion("1.2") < StrictVersion("1.3")
    assert StrictVersion("1.2") > StrictVersion("1.1")



# Generated at 2022-06-22 22:31:17.555792
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    ver = Version('1.0.0')
    assert ver>='1.0.0'
    assert ver>='0.9.9'
    assert not ver>='1.0.1'
    assert not ver>='1.1'
    assert not ver>='1.1.0'
    assert not ver>='2.0'
    assert not ver>='2.0.0'


# Generated at 2022-06-22 22:31:19.992188
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1, v2 = LooseVersion('1.0'), LooseVersion('2.0')
    assert v1 < v2


# Generated at 2022-06-22 22:31:22.339169
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == 'Version (\'\')'



# Generated at 2022-06-22 22:31:25.303616
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Setup
    version = Version()

    # Teardown
    del version


# Generated at 2022-06-22 22:31:28.273588
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.0.4b1')
    assert v.version == (1, 0, 4)
    assert v.prerelease == ('b', 1)

# Generated at 2022-06-22 22:31:30.341382
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version("1.1.1") == Version("1.1.1")

# Generated at 2022-06-22 22:31:34.486642
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    v3 = Version('3.0')
    if v1 != v2:
        pass

# Generated at 2022-06-22 22:31:38.490396
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import StrictVersion
    from distutils.tests import support
    support.run_unittest(StrictVersionTestCase)



# Generated at 2022-06-22 22:31:46.970786
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v == Version('1.2.3')
    assert '1.2.3' == v
    assert Version('1.2.3') == v
    assert not v == '1.2.4'
    assert not v == Version('1.2.4')
    assert not '1.2.4' == v
    assert not Version('1.2.4') == v
    assert not v == '1.2.3.4'
    assert not v == Version('1.2.3.4')
    assert not '1.2.3.4' == v
    assert not Version('1.2.3.4') == v

# Generated at 2022-06-22 22:31:51.586701
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Test for method __repr__ (Basic tests) of class Version
    import unittest
    class Test(unittest.TestCase):
        def test(self):
            v = Version()
            self.assertTrue('Version' in repr(v))
            self.assertTrue('(%r)' % str(v) in repr(v))
    Test().test()




# Generated at 2022-06-22 22:31:59.569330
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.0.6.1a6").__str__() == "1.0.6.1a6"
    assert StrictVersion("1.0.6.1b123").__str__() == "1.0.6.1b123"
    assert StrictVersion("1.0.6.1").__str__() == "1.0.6.1"
    assert StrictVersion("1.0.6").__str__() == "1.0.6"
    assert StrictVersion("1.0").__str__() == "1.0"



# Generated at 2022-06-22 22:32:04.625816
# Unit test for constructor of class Version
def test_Version():
    import string
    allowed_chars = ('0123456789.'
                     + string.ascii_letters
                     + string.whitespace
                     + string.punctuation
                     )
    try:
        allowed_chars = allowed_chars + unicode('', 'ascii')
    except NameError:
        pass

    for c in allowed_chars:
        Version(c)



# Generated at 2022-06-22 22:32:05.987949
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v == v


# Generated at 2022-06-22 22:32:12.945752
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
        test = LooseVersion
        cases = ['1', '1.2', '1.2a3', '1.2.a4', '1.2.1a4', '1.2.a', '1.2.1a']
        for c in cases:
            try:
                test(c)
            except:
                print("test_LooseVersion: constructor failed "
                      "with '%s'" % c)
# end test_LooseVersion()



# Generated at 2022-06-22 22:32:24.036531
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def should_fail(vstring):
        try:
            StrictVersion(vstring)
        except ValueError:
            pass
        else:
            raise RuntimeError(
                'no error thrown for invalid version string "%s"' % vstring)

    should_fail('1')
    should_fail('2.7.2.2')
    should_fail('1.3.a4')
    should_fail('1.3pl1')
    should_fail('1.3c4')

    def should_succeed(vstring, expected):
        version = StrictVersion(vstring)

# Generated at 2022-06-22 22:32:31.848136
# Unit test for method __le__ of class Version
def test_Version___le__():
    from .distutils2.version import Version
    from .distutils2.tests import unittest
    import sys

    class VersionTestCase(unittest.TestCase):

        def test_lessthan(self):
            v1 = Version('1.5.1')
            v1_1 = Version('1.5.2b2')
            v2 = Version('161')
            v3 = Version('3.10a')
            v4 = Version('8.02')
            v5 = Version('3.4j')
            v6 = Version('1996.07.12')
            versions = [v1, v1_1, v2, v3, v4, v5, v6]

# Generated at 2022-06-22 22:32:35.799049
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # this string is present in the code
    assert LooseVersion('1.1.1.r5').version == [1, 1, 1, 'r', 5]
    # for the method __cmp__, see below
