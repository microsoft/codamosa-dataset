

# Generated at 2022-06-22 22:22:40.214627
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import new
    import unittest

    class LooseVersionTestCase(unittest.TestCase):

        def test_empty(self):
            self.assertEqual(LooseVersion("").__str__(), "")

        def test_basic(self):
            self.assertEqual(LooseVersion("1.2").__str__(), "1.2")
            self.assertEqual(LooseVersion("1.2.3").__str__(), "1.2.3")
            self.assertEqual(LooseVersion("abc").__str__(), "abc")
            self.assertEqual(LooseVersion("1.2a3").__str__(), "1.2a3")
            self.assertEqual(LooseVersion("1_2").__str__(), "1_2")

    return unittest.Test

# Generated at 2022-06-22 22:22:42.306756
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    with pytest.raises(NotImplementedError):
        Version.__eq__(Version(), Version())



# Generated at 2022-06-22 22:22:43.617206
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3.4')


# Generated at 2022-06-22 22:22:45.224859
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3')
    assert str(v) == '1.2.3'

# Generated at 2022-06-22 22:22:48.974356
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    a = LooseVersion('1.0')
    b = LooseVersion('1.0')
    
    def test_1():
        assert a.__str__() == '1.0'


# Generated at 2022-06-22 22:22:58.462076
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test the case where the patch level is 0
    s = StrictVersion(vstring='0.4.0')
    assert str(s) == '0.4'
    s = StrictVersion(vstring='0.4.0.0')
    assert str(s) == '0.4'
    s = StrictVersion(vstring='2.7.2.0')
    assert str(s) == '2.7.2'
    # Test the case where we have a prerelease level
    s = StrictVersion(vstring='0.4.0a1')
    assert str(s) == '0.4a1'
    s = StrictVersion(vstring='0.4.0b2')
    assert str(s) == '0.4b2'

# Generated at 2022-06-22 22:23:02.126405
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    Test_Version_Version = Version(None)

    assert Test_Version_Version.__ge__('1.1') is False


# Generated at 2022-06-22 22:23:10.237174
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    versions_list = [
        '0.4',
        '0.4.0',
        '0.4.1',
        '0.5a1',
        '0.5b3',
        '0.5',
        '0.9.6',
        '1.0',
        '1.0.4a3',
        '1.0.4b1',
        '1.0.4'
    ]
    for version in versions_list:
        assert str(StrictVersion(version)) == version


# Generated at 2022-06-22 22:23:17.958196
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    global g_test_LooseVersion_parse_fail
    g_test_LooseVersion_parse_fail = False
    #
    #
    #
    lv = LooseVersion('1.0')
    assert lv.version == [1, 0]
    #
    #
    #
    lv = LooseVersion('1.0.0.0.0')
    assert lv.version == [1, 0, 0, 0, 0]
    #
    #
    #
    lv = LooseVersion('1.2b1')
    assert lv.version == [1, 2, 'b', 1]
    #
    #
    #
    lv = LooseVersion('5.5.kw')
    assert lv.version == [5, 5, 'kw']
    #
    #


# Generated at 2022-06-22 22:23:27.987447
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2')
    assert v.version == (1,2,0)
    assert v.prerelease is None
    v.parse('1.2a1')
    assert v.version == (1,2,0)
    assert v.prerelease == ('a', 1)
    v.parse('1.2.34')
    assert v.version == (1,2,34)
    assert v.prerelease is None
    v.parse('1.2.34a5')
    assert v.version == (1,2,34)
    assert v.prerelease == ('a', 5)
    v.parse('0.4')
    assert v.version == (0,4,0)
    assert v.prerelease is None

# Generated at 2022-06-22 22:23:32.813656
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """
    >>> r = LooseVersion('1.2.3a')
    >>> print(r)
    1.2.3a
    >>> print(str(r))
    1.2.3a
    >>> print(repr(r))
    LooseVersion ('1.2.3a')

    """


# Generated at 2022-06-22 22:23:41.565718
# Unit test for method __le__ of class Version
def test_Version___le__():
    class StubVersion(Version):
        def parse(self, s):
            raise NotImplementedError()
        def __str__(self):
            raise NotImplementedError()
        def _cmp(self, other):
            raise NotImplementedError()
    stub_version1 = StubVersion()
    stub_version2 = StubVersion()
    # Case: no _cmp
    with pytest.raises(NotImplementedError):
        stub_version1.__le__(stub_version2)
    # Case: _cmp returns NotImplemented
    class StubVersion(Version):
        def parse(self, s):
            raise NotImplementedError()
        def __str__(self):
            raise NotImplementedError()
        def _cmp(self, other):
            return NotImplemented
    stub_

# Generated at 2022-06-22 22:23:47.234576
# Unit test for method __str__ of class LooseVersion

# Generated at 2022-06-22 22:23:49.822386
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.0')
    assert v1 < '1.1'

# Generated at 2022-06-22 22:23:52.935597
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version("4.2.7.2").__repr__() == "Version ('4.2.7.2')"

# Generated at 2022-06-22 22:23:54.482248
# Unit test for constructor of class Version
def test_Version():
    Version(None)
    Version('')
    Version('1')
    Version('0.0')



# Generated at 2022-06-22 22:24:05.384027
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import pytest

    assert LooseVersion('3.10a').version == [3, 10, 'a']
    assert LooseVersion('2.1.2.2').version == [2, 1, 2, 2]
    assert LooseVersion('0.960923').version == [0, 960923]
    assert LooseVersion('1.13++').version == [1, 13, '++']
    assert LooseVersion('5.5.kw').version == [5, 5, 'kw']
    assert LooseVersion('2.0b1pl0').version == [2, 0, 'b', 1, 'pl', 0]
    assert LooseVersion('2g6').version == [2, 'g', 6]
    assert LooseVersion('11g').version == [11, 'g']

# Generated at 2022-06-22 22:24:14.471091
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # This is a first implementation of a unit test for method __str__
    # of class LooseVersion.
    lv = LooseVersion('1.0')
    assert str(lv) == '1.0'
    lv = LooseVersion('1.0.0')
    assert str(lv) == '1.0.0'
    lv = LooseVersion('1.2.1a1')
    assert str(lv) == '1.2.1a1'
    lv = LooseVersion('1.0.0.1a')
    assert str(lv) == '1.0.0.1a'
    lv = LooseVersion('3.2.2a2')
    assert str(lv) == '3.2.2a2'

# Generated at 2022-06-22 22:24:25.686967
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert str(StrictVersion('1.2.3a4')) == '1.2.3a4'
    assert str(StrictVersion('1.2.0')) == '1.2'
    assert str(StrictVersion('1.2')) == '1.2'
    assert str(StrictVersion('1.2b3')) == '1.2b3'
    assert str(StrictVersion('1.2.0')) == '1.2'
    assert str(StrictVersion('')) == ''
    assert str(StrictVersion('1.2.3.4')) == '1.2.3.4'

    assert (StrictVersion('1.2') == StrictVersion('1.2.0'))

# Generated at 2022-06-22 22:24:27.700709
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    assert v1 <= '2.0'

# Generated at 2022-06-22 22:24:30.867065
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.2.3.4')
    assert str(v) == "1.2.3.4"
    v2 = LooseVersion()
    assert str(v2) == "None"

# Generated at 2022-06-22 22:24:34.918611
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.1a-1')
    assert str(v) == '1.1a-1', '__str__ method of LooseVersion returns wrong result'
    return



# Generated at 2022-06-22 22:24:39.088711
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    r"""
    >>> ver = LooseVersion('Name-0.0.1')
    >>> ver.__str__()
    'Name-0.0.1'
    """


# Generated at 2022-06-22 22:24:41.382271
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():

    assert str(LooseVersion('1.5.2b2')) == '1.5.2b2'


# Generated at 2022-06-22 22:24:48.286574
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.0') >= Version('1.0')
    assert Version('1.02') >= Version('1.02')
    assert Version('1.1') >= Version('1.0')
    assert Version('2.0') >= Version('1.0')
    assert Version('1.1.1') >= Version('1.0.0')
    assert Version('2.0.2.2') >= Version('2.0.2')
    assert not (Version('1.0') >= Version('1.1'))
    assert not (Version('1.02') >= Version('1.2'))
    assert not (Version('1.1') >= Version('2.0'))
    assert not (Version('1.0.0') >= Version('1.1.1'))

# Generated at 2022-06-22 22:24:51.459500
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test basic equality
    assert Version() == Version()

    # Test equality with a string
    assert Version() == '0'

    # Test basic inequality
    assert Version() != '1'

# Generated at 2022-06-22 22:25:00.376462
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    sv = StrictVersion()

    # Valid versions
    for v in ['0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5', '0.9.6',
              '1.0', '1.0.4a3', '1.0.4b1', '1.0.4']:
        sv.parse(v)

    # Invalid versions
    for v in ['1', '2.7.2.2', '1.3.a4', '1.3pl1', '1.3c4']:
        try:
            sv.parse(v)
            assert False, 'expected ValueError'
        except ValueError:
            pass

# Generated at 2022-06-22 22:25:09.596705
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # Test a simple version string
    v = LooseVersion("1.3.4.5")
    assert v.version == [1, 3, 4, 5]
    assert str(v) == "1.3.4.5"
    assert v.vstring == "1.3.4.5"

    # Test more complicated versions
    v = LooseVersion("1.3a4.5")
    assert v.version == [1, 3, 'a', 4, 5]
    assert str(v) == "1.3a4.5"
    assert v.vstring == "1.3a4.5"

    v = LooseVersion("1g3.4.5")
    assert v.version == [1, 'g', 3, 4, 5]

# Generated at 2022-06-22 22:25:19.942844
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    """Test class StrictVersion"""
    def test_cmp(vstring, wstring):
        version = StrictVersion(vstring)
        wanted = StrictVersion(wstring)
        try:
            got = version == wanted
        except ValueError:
            # print "invalid versions", vstring, wstring
            assert wanted == 'invalid'
        else:
            assert got == (wanted == 'equal')

        try:
            got = version < wanted
        except ValueError:
            # print "invalid versions", vstring, wstring
            assert wanted == 'invalid'
        else:
            assert got == (wanted == 'less')

    test_cmp('1.1', '1.1')
    test_cmp('1.1', '1.2')

# Generated at 2022-06-22 22:25:24.708879
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.5')
    assert str(v) == '1.5'
    assert repr(v) == "Version ('1.5')"
    assert v == '1.5'
    assert not (v < '1.5')
    assert v <= '1.5'
    assert not (v > '1.5')
    assert v >= '1.5'



# Generated at 2022-06-22 22:25:31.948839
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version() >= Version()
    assert Version("1.2") >= Version("1.2")
    assert Version("1.2-dev") >= Version("1.2-dev")
    assert Version("1.2") >= Version("1.2-dev")
    assert Version("1.2") >= Version("1.2b")
    assert Version("1.2-dev") >= Version("1.2b")
    assert Version("1.2") >= Version("1.2.dev")
    assert Version("1.2-dev") >= Version("1.2b.dev")
    assert Version("1.2") >= Version("1.2b.dev")
    assert Version("1.2") >= Version("1.2c.dev")
    assert Version("1.2") >= Version("1.2rc")

# Generated at 2022-06-22 22:25:37.533545
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version('0.0.0')
    version2 = Version('0.0.0')
    if version < version2:
        raise RuntimeError('Version not properly implemented')
    elif not version >= version2:
        raise RuntimeError('Version not properly implemented')

# Generated at 2022-06-22 22:25:45.096890
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    print('Testing method __str__ of class StrictVersion')

    import re

    # test_versionNumbers
    result0 = str(StrictVersion('1.0'))
    expected0 = '1.0'
    assert result0 == expected0

    result1 = str(StrictVersion('2.7.2.2'))
    expected1 = '2.7.2.2'
    assert result1 == expected1

    result2 = str(StrictVersion('1.3.a4'))
    expected2 = '1.3.a4'
    assert result2 == expected2

    result3 = str(StrictVersion('1.3pl1'))
    expected3 = '1.3pl1'
    assert result3 == expected3

    result4 = str(StrictVersion('1.3c4'))
   

# Generated at 2022-06-22 22:25:46.735873
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version("1.0")
    assert(v == v)

# Generated at 2022-06-22 22:25:50.482926
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.0")
    v2 = Version("1.1")
    assert v1 < v2
    assert v2.__lt__("1.3") == True
    assert v2.__lt__("2.0") == True

# Generated at 2022-06-22 22:25:52.909462
# Unit test for method __le__ of class Version
def test_Version___le__():
  v = Version()
  assert v.__le__( v )


# Generated at 2022-06-22 22:25:55.801846
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('1.2')
    v2 = Version('1.2')
    eq_(v1 < v2, False)


# Generated at 2022-06-22 22:26:05.657934
# Unit test for constructor of class Version
def test_Version():
    for V in LooseVersion, StrictVersion:
        # Make sure it doesn't choke on a non-string
        a = V(1)
        assert str(a) == "1"
        a = V(None)
        assert str(a) == ""

        # Make sure it doesn't choke on an empty string
        a = V("")
        assert str(a) == ""

        # Make sure it doesn't choke on leading zeros
        a = V("010")
        assert str(a) == "10"
        a = V("0001.2")
        assert str(a) in ("1.2", "1.020000")

        # Make sure it doesn't choke on an integer
        a = V(0)
        assert str(a) in ("0", "0.0")


# Regular expressions used to parse version numbers


# Generated at 2022-06-22 22:26:17.808993
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Test some invalid strings:
    for v in ("1.2.3.4", "1.2.3a4", "1.2.3b4", "1.2.3a4.5"):
        try:
            StrictVersion(v)
        except ValueError:
            pass
        else:
            raise AssertionError(
                  "invalid version number should have raised ValueError")

    # Test some valid strings, and their equivalence:

# Generated at 2022-06-22 22:26:19.595382
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('1')
    assert v > '0.9'
test_Version___gt__()

# Generated at 2022-06-22 22:26:21.228734
# Unit test for constructor of class Version
def test_Version():
    assert Version()
    assert Version('')
    assert Version('1.2.3a1')



# Generated at 2022-06-22 22:26:23.703212
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v) == True
    assert v.__le__(None) == NotImplemented
    assert v.__le__(True) == NotImplemented

# Generated at 2022-06-22 22:26:29.261003
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # We can't really test the output of __repr__ since it contains the
    # class name and since we have no control over the module name (we
    # could set __module__ but that is not part of the supported
    # interface and may not work on all Python versions).  So we simply
    # call this method and hope it runs to completion.
    Version().__repr__()

# Generated at 2022-06-22 22:26:40.203972
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert_raises_regex(NotImplementedError, 'Version._cmp not implemented')
    try:
        Version().__gt__('s')
        assert False
    except NotImplementedError:
        pass
    try:
        Version().__gt__(Version())
        assert False
    except NotImplementedError:
        pass
    try:
        Version('a').__gt__('s')
        assert False
    except NotImplementedError:
        pass
    try:
        Version('a').__gt__(Version())
        assert False
    except NotImplementedError:
        pass
    try:
        Version().__gt__('a')
        assert False
    except NotImplementedError:
        pass

# Generated at 2022-06-22 22:26:42.873979
# Unit test for method __le__ of class Version
def test_Version___le__():
    dv = Version()
    dc = Version()

    assert( dv <= dc )



# Generated at 2022-06-22 22:26:48.721464
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    s = StrictVersion()
    assert s.__str__() == ""
    s.parse("2.7.2.2")
    assert s.__str__() == "2.7.2.2"
    s.parse("2.7.2.2a2")
    assert s.__str__() == "2.7.2.2a2"


# Generated at 2022-06-22 22:26:51.898607
# Unit test for method __le__ of class Version
def test_Version___le__():
    try:
        obj = Version()
        obj.__le__('text')
    except Exception as e:
        assert(type(e) == NotImplementedError)
    else:
        assert(False)

# End of Version class



# Generated at 2022-06-22 22:26:54.956272
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"

# Generated at 2022-06-22 22:27:00.875145
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse("1.5.1")
    eq('1.5.1', str(lv))

    lv.parse("1.5.2b2")
    eq('1.5.2b2', str(lv))

    lv.parse("161")
    eq('161', str(lv))

    lv.parse("3.10a")
    eq('3.10a', str(lv))

    lv.parse("8.02")
    eq('8.02', str(lv))

    lv.parse("3.4j")
    eq('3.4j', str(lv))

    lv.parse("1996.07.12")
    eq('1996.07.12', str(lv))

    lv.parse("3.2.pl0")

# Generated at 2022-06-22 22:27:12.625617
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Make sure the constructor takes four args, so old code doesn't
    # break silently because of the new prerelease stuff.
    try:
        StrictVersion("1.2", 0, 2, "")
    except TypeError:
        pass
    else:
        raise TestFailed("StrictVersion constructor takes four args")
    # Test the constructor
    StrictVersion("2.0")
    StrictVersion("1.1")
    StrictVersion("0.4.0")
    StrictVersion("0.4")
    StrictVersion("0.4.1")
    StrictVersion("2.0.0")
    StrictVersion("1.1.0")
    # Test the constructor with prerelease tags
    StrictVersion("2.0a1")
    StrictVersion("2.0.0a1")
    St

# Generated at 2022-06-22 22:27:13.891186
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    other = Version()
    c = v._cmp(other)
    if c is NotImplemented:
        return c
    return c <= 0# Unit test for method __gt__ of class Version

# Generated at 2022-06-22 22:27:21.343466
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Unit test for method `Version.__eq__`"""
    # Test 1
    a = Version(Material('1.0')); b = Version(Material('1.0'))
    assert a.__eq__(b) == True
    # Test 2
    a = Version(Material('1.0')); b = Version(Material('1.1'))
    assert a.__eq__(b) == False
    # Test 3
    a = Version(Material('1.0')); b = Version(Material('2.0'))
    assert a.__eq__(b) == False


# Generated at 2022-06-22 22:27:32.365931
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # Test for following case:
    #   given a string vstring, calling LooseVersion(vstring).__str__()
    #   should return vstring
    # Test data:
    #   a string vstring
    # Expected results:
    #   LooseVersion(vstring).__str__() == vstring
    # Test method:
    #   construct LooseVersion with given parameter vstring, then compare
    #   result of __str__ with vstring
    vstring = '1.5.1'
    assert LooseVersion(vstring).__str__() == vstring
    vstring = '1.5.2b2'
    assert LooseVersion(vstring).__str__() == vstring
    vstring = '161'
    assert LooseVersion(vstring).__str__() == vstring
    vstring

# Generated at 2022-06-22 22:27:35.307356
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    x = Version()
    x.__ge__('1')
    x.__ge__(None)
    x._cmp = lambda a: NotImplemented
    x.__ge__(1)

# Generated at 2022-06-22 22:27:42.286645
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    """
    >>> StrictVersion('1').parse('1.3.3.7')
    Traceback (most recent call last):
      ...
    ValueError: invalid version number '1.3.3.7'

    >>> StrictVersion('1.1').parse('2.6.0')
    >>> StrictVersion('1.1').version
    (2, 6, 0)

    >>> StrictVersion('1.1').parse('2.6.0a1')
    >>> StrictVersion('1.1').version
    (2, 6, 0)

    >>> StrictVersion('1.1').parse('2.6')
    >>> StrictVersion('1.1').version
    (2, 6, 0)
    """



# Generated at 2022-06-22 22:27:45.329332
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion("1.0.100").__repr__() == \
    "LooseVersion ('1.0.100')", __repr__.__doc__



# Generated at 2022-06-22 22:27:47.535267
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version("1.2.3")
    assert repr(v) == "Version ('1.2.3')", repr(v)


# Generated at 2022-06-22 22:27:48.495526
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert v


# Generated at 2022-06-22 22:27:50.080670
# Unit test for method __le__ of class Version
def test_Version___le__():
    ver = Version('1.1')
    assert ver <= '1.1'

# Generated at 2022-06-22 22:28:01.397305
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """
    Define new class to test method __eq__ of class Version with extra variables
    """
    class NewVersion(Version):
        def __init__(self, vstring=None):
            self.parse(vstring)

        def parse(self, vstring):
            self.vstring = vstring
            self.v_int = 1
            self.v_float = 1.0
            self.v_tuple = (1, 1, 1)

        def _cmp(self, other):
            if isinstance(other, str):
                if self.vstring == other:
                    return 0
            if isinstance(other, int):
                if self.v_int == other:
                    return 0
            if isinstance(other, float):
                if self.v_float == other:
                    return 0

# Generated at 2022-06-22 22:28:03.317177
# Unit test for constructor of class Version
def test_Version():
    import test.support
    test.support.run_unittest(VersionTestCase)



# Generated at 2022-06-22 22:28:07.928258
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    name = "Version.__gt__"
    v = Version(vstring='1.2.9')
    assert v.__gt__('1.2.8')


# Generated at 2022-06-22 22:28:13.769860
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    version_tests = ((LooseVersion('1.2'),
                     'LooseVersion (\'1.2\')'),
                     (LooseVersion('1.2.3'),
                     'LooseVersion (\'1.2.3\')'),
                    (LooseVersion('1.2.3.4'),
                     'LooseVersion (\'1.2.3.4\')'))

    for v, r in version_tests:
        assert repr(v) == r


# Generated at 2022-06-22 22:28:22.530582
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    for value in ['1.1', '1.1a1']:
        v1 = Version(value)
        for value2 in ['1.0', '1.0a1', '1.1', '1.1a1', '1.1.1', '1.2']:
            v2 = Version(value2)
            print('v1: %s    v2: %s    v1 >= v2: %s' % (v1, v2, v1 >= v2))

# Generated at 2022-06-22 22:28:30.548056
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    """Check that the LooseVersion class is working as expected."""
    s = "1.0a1b"
    c = LooseVersion(s)
    assert c.version == [1, 0, 'a', 1, 'b']
    assert c.vstring == "1.0a1b"
    s = "2.2.0"
    c = LooseVersion(s)
    assert c.version == [2, 2, 0]
    assert c.vstring == "2.2.0"
    s = "2.2.0b1"
    c = LooseVersion(s)
    assert c.version == [2, 2, 0, "b", 1]


# Generated at 2022-06-22 22:28:33.164350
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    a = Version('0.0.0')
    b = Version('0.0.0')
    assert(a == b)


# Generated at 2022-06-22 22:28:41.511691
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2.3a4').__str__() == '1.2.3a4'
    assert StrictVersion('1.2.3b5').__str__() == '1.2.3b5'
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2a3').__str__() == '1.2a3'
    assert StrictVersion('1.2b4').__str__() == '1.2b4'
    assert StrictVersion('1.2').__str__() == '1.2'

# Generated at 2022-06-22 22:28:45.236756
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import distutils.version

    ver = distutils.version.StrictVersion("alpha.0.0")
    assert ver.__str__() == "alpha.0.0"



# Generated at 2022-06-22 22:28:47.276398
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1') == Version('1')
    assert not (Version('1') == Version('2'))

# Generated at 2022-06-22 22:28:51.994367
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest

    class Version___gt__(unittest.TestCase):
        def test_1(self):
            v1 = Version()

            # Call tested method
            result = v1.__gt__(1)
            self.assertTrue(result)
    unittest.main()


# Generated at 2022-06-22 22:28:59.470474
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    BOOLEANS_TRUE=BOOLEANS_TRUE
    BOOLEANS_FALSE=BOOLEANS_FALSE
    assert BOOLEANS_TRUE
    test_Version___repr__.stypy_type_store = module_type_store
    test_Version___repr__.stypy_function_name = 'test_Version___repr__'
    test_Version___repr__.stypy_param_names_list = []
    test_Version___repr__.stypy_varargs_param_name = None
    test_Version___repr__.st

# Generated at 2022-06-22 22:29:00.598255
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version('1')

# Generated at 2022-06-22 22:29:04.056120
# Unit test for constructor of class Version
def test_Version():
    from distutils.tests import support
    assert support.get_attribute(Version('2.1.0'), '_version') == '2.1.0'



# Generated at 2022-06-22 22:29:15.469324
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for s in ('0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5',
              '0.9.6', '1.0', '1.0.4a3', '1.0.4b1', '1.0.4'):
        v = StrictVersion(s)
        assert str(v) == s
        assert v.version == StrictVersion(s).version
        if 'a' in s or 'b' in s:
            assert v.prerelease != (None, None)
        else:
            assert v.prerelease == (None, None)
    try:
        StrictVersion('1.2.3.4')
    except ValueError:
        pass

# Generated at 2022-06-22 22:29:24.921224
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    for v in ['1.5.1',
              '1.5.2b2',
              '161',
              '3.10a',
              '8.02',
              '3.4j',
              '1996.07.12',
              '3.2.pl0',
              '3.1.1.6',
              '2g6',
              '11g',
              '0.960923',
              '2.2beta29',
              '1.13++',
              '5.5.kw',
              '2.0b1pl0']:
        try:
            LooseVersion(v)
        except ValueError:
            print("LooseVersion test failed on %s" % v)


# Generated at 2022-06-22 22:29:28.112562
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version("1.0.0")
    assert(v <= "1.0.0")
    assert(v <= "10.0.0")
    assert(v <= "1.10.0")
    assert(not (v <= "0.0.9"))

# Generated at 2022-06-22 22:29:30.343292
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    pass


# Generated at 2022-06-22 22:29:31.227799
# Unit test for constructor of class Version
def test_Version():
    v = Version()


# Generated at 2022-06-22 22:29:39.187550
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    testv = StrictVersion()
    sv = StrictVersion

    testv.parse("1")
    assert str(testv), "1"
    assert testv.version == (1, 0, 0)
    assert testv.prerelease == None

    testv.parse("1.0")
    assert str(testv), "1.0"
    assert testv.version == (1, 0, 0)
    assert testv.prerelease == None

    testv.parse("1.0.0")
    assert str(testv), "1.0.0"
    assert testv.version == (1, 0, 0)
    assert testv.prerelease == None

    testv.parse("1.0b1")
    assert str(testv), "1.0b1"

# Generated at 2022-06-22 22:29:41.617216
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version("1.2") == Version("1.2")
    assert Version("1.2") != Version("1.1")


# Generated at 2022-06-22 22:29:43.993714
# Unit test for constructor of class Version
def test_Version():
    # Test the constructor of class Version
    # (since so many other classes use it)
    v = Version()
    assert v._cmp("1.1") == 0



# Generated at 2022-06-22 22:29:49.325617
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # should be the same as LooseVersion("0.9.9")
    v = LooseVersion("0.9.9")
    if str(v) != "0.9.9":
        raise AssertionError("__str__ doesn't work")
    if repr(v) != "LooseVersion ('0.9.9')":
        raise AssertionError("__repr__ doesn't work")
    if v != "0.9.9":
        raise AssertionError("__cmp__ doesn't work")



# Generated at 2022-06-22 22:30:02.267335
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():

    v = StrictVersion("0.4")
    assert v.version == (0, 4)
    assert not v.prerelease

    v = StrictVersion("0.4.0")
    assert v.version == (0, 4, 0)
    assert not v.prerelease

    v = StrictVersion("0.4.0.0")
    assert v.version == (0, 4, 0)
    assert not v.prerelease

    v = StrictVersion("0.4a1")
    assert v.version == (0, 4)
    assert v.prerelease == ('a', 1)

    v = StrictVersion("0.4b3")
    assert v.version == (0, 4)
    assert v.prerelease == ('b', 3)

    v = StrictVersion("0.4.1")
   

# Generated at 2022-06-22 22:30:13.991635
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    input1 = StrictVersion('1')
    output1 = '1'
    assert str(input1) == output1, "'StrictVersion.__str__(self)' failed"

    input2 = StrictVersion('1.1')
    output2 = '1.1'
    assert str(input2) == output2, "'StrictVersion.__str__(self)' failed"

    input3 = StrictVersion('1.1.1')
    output3 = '1.1.1'
    assert str(input3) == output3, "'StrictVersion.__str__(self)' failed"

    input4 = StrictVersion('1.1.1a')
    output4 = '1.1.1a1'
    assert str(input4) == output4, "'StrictVersion.__str__(self)' failed"



# Generated at 2022-06-22 22:30:16.865989
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    result = version.__lt__('')
    assert result

# Generated at 2022-06-22 22:30:18.869147
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.tests import support
    v = Version()
    assert v.__ge__(None) == NotImplemented


# Generated at 2022-06-22 22:30:30.003901
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('1.1').__str__() == '1.1'
    assert LooseVersion('1.1a').__str__() == '1.1a'
    assert LooseVersion('1.1.a').__str__() == '1.1.a'
    assert LooseVersion('1.1 a').__str__() == '1.1 a'
    assert LooseVersion('1.1. a').__str__() == '1.1. a'
    assert LooseVersion('1.1 1').__str__() == '1.1 1'
    assert LooseVersion('1.1 .1').__str__() == '1.1 .1'
    assert LooseVersion('1.1.1 +').__str__() == '1.1.1 +'

# Generated at 2022-06-22 22:30:37.851868
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    try:
        StrictVersion('1.0').parse('1.1')
    except ValueError:
        pass
    try:
        StrictVersion('1.0').parse('1')
    except ValueError:
        pass
    try:
        StrictVersion('1.0').parse('1.0.0.0')
    except ValueError:
        pass
    try:
        StrictVersion('1.0').parse('foo')
    except ValueError:
        pass
    try:
        StrictVersion('1.0').parse('1.0foo')
    except ValueError:
        pass
    try:
        StrictVersion('1.0').parse('1.0.0foo')
    except ValueError:
        pass

# Generated at 2022-06-22 22:30:45.422615
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    # REQ-BLD-VERSION-074
    # REQ-BLD-VERSION-075
    # REQ-BLD-VERSION-076

    from distutils.version import Version

    v1 = Version(2)
    v2 = Version(1)

    assert v1 > v2
    assert not v1 < v2
    assert not v1 == v2

    v1 = Version('1.1')
    v2 = Version(1, 2)

    assert v1 < v2
    assert not v1 == v2
    assert not v1 > v2


# Generated at 2022-06-22 22:30:55.867154
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    test = LooseVersion('1.2.3')
    assert repr(test) == 'LooseVersion (\'1.2.3\')'
    test = LooseVersion('1.2.3a4')
    assert repr(test) == 'LooseVersion (\'1.2.3a4\')'
    test = LooseVersion('1.2.3.4')
    assert repr(test) == 'LooseVersion (\'1.2.3.4\')'
    test = LooseVersion('1.2.3alpha4')
    assert repr(test) == 'LooseVersion (\'1.2.3alpha4\')'
    test = LooseVersion('1.2.3.4.5')
    assert repr(test) == 'LooseVersion (\'1.2.3.4.5\')'

# Generated at 2022-06-22 22:30:59.290244
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    t = StrictVersion('1.2.3')
    assert str(t) == '1.2.3'


# Generated at 2022-06-22 22:31:03.658520
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # create an instance of the class
    t = Version()

    # try to call the method
    if t.__eq__(1) == None:
        raise Exception("return type mismatch")



# Generated at 2022-06-22 22:31:06.482932
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__ge__(v)
    assert not v.__ge__(1)
    assert v.__ge__(None) is NotImplemented

# Generated at 2022-06-22 22:31:17.944503
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v1 = StrictVersion("1.0a1")
    assert v1.version == (1, 0, 0), "version tuple should be (1, 0, 0)"
    assert v1.prerelease == ("a", 1), "prerelease should be ('a', 1)"
    assert str(v1) == "1.0a1", "string representation should be '1.0a1'"
    assert repr(v1) == "StrictVersion ('1.0a1')"

    v2 = StrictVersion("1.0c4")
    assert v2.version == (1, 0, 0), "version tuple should be (1, 0, 0)"
    assert v2.prerelease == ("c", 4), "prerelease should be ('c', 4)"

# Generated at 2022-06-22 22:31:25.004765
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    versions = ['1.2.3', '1.2', '1.2rc1', '1.2b3', '1.2.3b3',
                '1.2.3.b3', '1.2.3.4b3', '1.2.3.4rc3']
    for version in versions:
        StrictVersion(version)


# Generated at 2022-06-22 22:31:30.906949
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    data = [
        ("1",             (1, 0, 0)),
        ("1.2",           (1, 2, 0)),
        ("0.9.6",         (0, 9, 6)),
        ("1.2.3",         (1, 2, 3)),
        ("1.0.0.0.0.0",   (1, 0, 0, 0, 0, 0)),
        ("1.aaaaaaaaaa",  None),
        ("1.2.aaaaaaaaaa",None),
        ("1.2.3.aaaaaaaaaa",None),
        ("1.2.3.4.aaaaaaaaaa",None),
        ("1.2.3.4.5.aaaaaaaaaa",None),
        ("1.2.3.4.5.6.aaaaaaaaaa",None),
    ]

# Generated at 2022-06-22 22:31:41.759163
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v0_4 = StrictVersion("0.4")
    v0_4_0 = StrictVersion("0.4.0")
    v0_4_1 = StrictVersion("0.4.1")

    assert (v0_4 == v0_4_0), "equality wrong"
    assert (v0_4 < v0_4_1), "less-than wrong"

    try:
        StrictVersion("1.3.a4")
    except ValueError:
        pass
    else:
        raise AssertionError("expected ValueError")


# Generated at 2022-06-22 22:31:44.200404
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('1.2.2')
    assert lv.__repr__() == "LooseVersion ('1.2.2')"


# Generated at 2022-06-22 22:31:49.308171
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version(vstring='1.1.1')
    w = Version(vstring='2.2.2')
    # Test the comparison where the method __gt__ should return True.
    assert v.__gt__(w) == True
    # Test the comparison where the method __gt__ should return False.
    assert w.__gt__(v) == False


# Generated at 2022-06-22 22:31:55.254501
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    strict_ver = StrictVersion('1.3a4')
    assert strict_ver.version == (1, 3, 0)
    assert strict_ver.prerelease == ('a', 4)


# Set of invalid StrictVersion strings
strict_invalid_vers = [
    '1',
    '2.7.2.2',
    '1.3.a4',
    '1.3pl1',
    '1.3c4',
]



# Generated at 2022-06-22 22:32:01.098524
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion("1.0.4a3")
    assert str(v) == "1.0.4a3"
    assert v.version == (1, 0, 4)
    assert v.prerelease == ('a', 3)
    assert str(v) == "1.0.4a3"



# Generated at 2022-06-22 22:32:05.624424
# Unit test for method __le__ of class Version
def test_Version___le__():
    print ('Testing method __le__...')
    v = Version('1.2.3')
    print ('  %s is <= %s (should be False)' % (v, '1.2.3'))
    print(v <= '1.2.3')
    return True  # this is a sample, the method always returns True
test_Version___le__()


# Generated at 2022-06-22 22:32:08.577294
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('None')"


# Generated at 2022-06-22 22:32:10.779045
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    v = Version()
    v2 = Version()
    assert (v < v2) == NotImplemented



# Generated at 2022-06-22 22:32:23.408336
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("1.0a1")
    v.parse("1.0a1")
    v.parse("1.0a2")
    v.parse("1.0a10")
    v.parse("1.0b1")
    v.parse("1.0b2")
    v.parse("1.0b10")
    v.parse("1.0c1")
    v.parse("1.0c2")
    v.parse("1.0c10")
    v.parse("1.0rc1")
    v.parse("1.0rc2")
    v.parse("1.0rc10")
    v.parse("1.0")
    v.parse("1.0pl1")
    v.parse("1.0.dev456")

# Generated at 2022-06-22 22:32:26.305066
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # Check that str(rcs_revision) returns a string.
    v = LooseVersion('0.0.0.1')

# Generated at 2022-06-22 22:32:29.757135
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  with pytest.raises(NotImplementedError):
    v = Version()
    v2 = Version()
    v3 = Version()
    # Try to compare v against a string, an instance and a number
    v < "123"
    v < v2
    v < 123

