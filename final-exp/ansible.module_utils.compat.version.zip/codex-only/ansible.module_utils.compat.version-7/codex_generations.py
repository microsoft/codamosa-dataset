

# Generated at 2022-06-22 22:22:37.026121
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass

    # Invalid


# Generated at 2022-06-22 22:22:39.596426
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()

    assert repr(v) == "Version ('0')"


# Generated at 2022-06-22 22:22:42.559796
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version("1.0")
    t = repr(v)
    # print("t = {0}".format(t))
    assert t == "Version ('1.0')"
    return

# Generated at 2022-06-22 22:22:44.185558
# Unit test for method __le__ of class Version
def test_Version___le__():

    v = Version('1.2.3')
    assert v <= '1.2.3'

# Generated at 2022-06-22 22:22:47.574083
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    cls = Version
    version = cls('2.2')
    assert version == Version('2.2')
    assert version is not Version('2.2')


# Generated at 2022-06-22 22:22:53.933390
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.0.0').__str__() == '1.0.0'
    assert StrictVersion('1.0').__str__() == '1.0.0'
    assert StrictVersion('1').__str__() == '1.0.0'
    assert StrictVersion('1.0a1').__str__() == '1.0a1'
    assert StrictVersion('1.0.0b1').__str__() == '1.0.0b1'


# Generated at 2022-06-22 22:22:57.179749
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        Version() > '5'
    except TypeError:
        pass
    else:
        raise AssertionError
    try:
        Version() > 'a'
    except TypeError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-22 22:23:05.124868
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    cases = ['1', '1.2', '1.2.3',
             '1.2b3', '1.2c4', '1.2.3a0', '1.2.3b0', '1.2.3c0', '1.2.0']

    for case in cases:
        try:
            StrictVersion(case)
        except ValueError:
            print("%s not ok" % case)
        else:
            print("%s ok" % case)



# Generated at 2022-06-22 22:23:08.010689
# Unit test for method __repr__ of class Version
def test_Version___repr__():

    from distutils.tests import support
    v = Version('1.2.3')
    assert v.__repr__() == "Version ('1.2.3')"


# Generated at 2022-06-22 22:23:10.602116
# Unit test for constructor of class Version
def test_Version():
    for V in (StrictVersion, LooseVersion, Version):
        v = V(1.1)
        assert v == eval(repr(v))



# Generated at 2022-06-22 22:23:11.564824
# Unit test for constructor of class Version
def test_Version():
    v = Version()



# Generated at 2022-06-22 22:23:13.813294
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
  v = StrictVersion('1.2.3a4')
  assert v.__str__() == '1.2.3a4'


# Generated at 2022-06-22 22:23:14.662220
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= Version()

# Generated at 2022-06-22 22:23:18.378536
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version("abcdefg")
    assert(repr(v) == "Version ('abcdefg')")

# Generated at 2022-06-22 22:23:21.876413
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """Unit test for method __repr__ of class LooseVersion"""
    assert_equals(repr(LooseVersion("2.2")), "LooseVersion ('2.2')")



# Generated at 2022-06-22 22:23:30.739588
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import StrictVersion
    import unittest

    class VersionTestCase(unittest.TestCase):

        def test_rcs(self):
            self.assertGreater(StrictVersion('1.2.3'), StrictVersion('1.2.3rc1'))
            self.assertGreater(StrictVersion('1.2.3'), StrictVersion('1.2.3c1'))

        def test_pre(self):
            self.assertGreater(StrictVersion('1.2.3'), StrictVersion('1.2.3.0a2'))
            self.assertGreater(StrictVersion('1.2.3'), StrictVersion('1.2.3.0b1'))

# Generated at 2022-06-22 22:23:38.660564
# Unit test for constructor of class Version
def test_Version():
    import test.test_support
    for V in ['0.4a1', '0.4b3', '0.4c1', '0.4.0', '0.5a1', '0.5b3', '0.5c1', '0.5.0', '0.9.6', '0.9.7', '0.9.8', '0.9.9', '0.10.0', '1.0.0']:
        v = Version(V)
        assert str(v) == V
        assert eval(repr(v)) == v




# Generated at 2022-06-22 22:23:51.215285
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    return
    # Imports
    from distutils.version import Version
    from distutils.version import parse
    from itertools import product

# Generated at 2022-06-22 22:23:52.853275
# Unit test for method __le__ of class Version
def test_Version___le__():
    # stub
    assert True


# Generated at 2022-06-22 22:24:03.868819
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    global errors
    errors = 0
    v = LooseVersion("1.4.4")
    cmp_str(v.__str__(), "1.4.4")
    v.parse("1.4.4")
    cmp_str(v.__str__(), "1.4.4")
    v.parse("1.4.4")
    cmp_str(v.__str__(), "1.4.4")
    v.parse("1.4.4")
    cmp_str(v.__str__(), "1.4.4")
    v.parse("1.4.4")
    cmp_str(v.__str__(), "1.4.4")
    v.parse("1.4.4")

# Generated at 2022-06-22 22:24:12.049497
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def test_version(vstring, version, prerelease):
        v = StrictVersion(vstring)
        assert v.version == version
        assert v.prerelease == prerelease

    test_version('1.0', (1, 0, 0), None)
    test_version('1.0a1', (1, 0, 0), ('a', 1))
    test_version('1.0.0', (1, 0, 0), None)
    test_version('1.0b1', (1, 0, 0), ('b', 1))
    test_version('0.4', (0, 4, 0), None)
    test_version('0.4.0', (0, 4, 0), None)
    test_version('0.4.1', (0, 4, 1), None)

# Generated at 2022-06-22 22:24:24.346404
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion("1.0.4a3")
    assert str(v) == "1.0.4a3"
    assert v == "1.0.4a3"
    assert v < "1.0.4"
    v = StrictVersion("1.0.4b1")
    assert str(v) == "1.0.4b1"
    assert v == "1.0.4b1"
    assert v < "1.0.4"
    v = StrictVersion("1.0.4")
    assert str(v) == "1.0.4"
    assert v == "1.0.4"
    assert v < "1.0.4a1"
    v = StrictVersion("1.0.4.0")

# Generated at 2022-06-22 22:24:26.643119
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert v.__repr__() == "Version ('0.0')"

# Generated at 2022-06-22 22:24:28.029647
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    pass # TODO: implement your test here


# Generated at 2022-06-22 22:24:32.185258
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from lib2to3.fixer_util import Version
    import unittest

    class Version___ge__Tester(unittest.TestCase):
        def test_Version___ge__(self):
            # FIXME: implement your test here
            raise NotImplementedError()

    unittest.main()

# Generated at 2022-06-22 22:24:36.048966
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version('5.2.2').__repr__() == "Version ('5.2.2')"


# Generated at 2022-06-22 22:24:38.551847
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    assert v1 <= Version()
    assert not v1 <= None

# Generated at 2022-06-22 22:24:46.976840
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion


# Generated at 2022-06-22 22:24:56.408409
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import sys
    import os
    import random
    import unittest
    import StringIO
    import pickle

    class LooseVersion___str__TestCase(unittest.TestCase):
        def check(self, arg):
            if isinstance(arg, tuple):
                self.check(*arg)
            elif isinstance(arg, str):
                self.assertEqual(LooseVersion(arg).__str__(), arg)
            elif isinstance(arg, int):
                self.check(".")
            else:
                raise AssertionError("unexpected type in LooseVersion___str__TestCase.check: %r" % (type(arg),))

        def test_basic(self):
            for i in xrange(256):
                self.check(random.randint(0, 10**10))

# Generated at 2022-06-22 22:24:57.491584
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert repr(Version()) == 'Version (\'\')'



# Generated at 2022-06-22 22:25:04.262311
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # This only tests that it's callable and works for
    # the given types of its arguments.
    Version().__gt__(Version())
    Version().__gt__('1')
    Version('1').__gt__('1')
    Version('1.1').__gt__('1.2')
    Version('1.2').__gt__('1.1')



# Generated at 2022-06-22 22:25:15.980495
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
  lv = LooseVersion()
  lv.parse(vstring="1.5.1")
  lv.parse(vstring="1.5.2b2")
  lv.parse(vstring="161")
  lv.parse(vstring="3.10a")
  lv.parse(vstring="8.02")
  lv.parse(vstring="3.4j")
  lv.parse(vstring="1996.07.12")
  lv.parse(vstring="3.2.pl0")
  lv.parse(vstring="3.1.1.6")
  lv.parse(vstring="2g6")
  lv.parse(vstring="11g")
  lv.parse(vstring="0.960923")

# Generated at 2022-06-22 22:25:17.695737
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("1.0.0")
    assert (v1 <= v1)
    assert not (v1 <= "1.0.0")

# Generated at 2022-06-22 22:25:19.807465
# Unit test for method __ge__ of class Version
def test_Version___ge__():
	v = Version("1.1.1")
	v2 = Version("1.1.1")
	assert v >= v2


# Generated at 2022-06-22 22:25:21.336922
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version().__lt__(None) == NotImplemented



# Generated at 2022-06-22 22:25:26.126637
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    LooseVersion('0.4')
    LooseVersion('1.0.4b1')
    LooseVersion('1.13++')
    LooseVersion('5.5.kw')
    LooseVersion('2.0b1pl0')
    # LooseVersion('2.1.0-2')
    LooseVersion('2.6.21')
    LooseVersion('2.6.21.1')



# Generated at 2022-06-22 22:25:27.287624
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v = LooseVersion('1.2.3')


# Generated at 2022-06-22 22:25:37.584696
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  from semantic_version import Version
  v1 = Version('1.0.4')
  v2 = Version('1.0.4a1')
  assert not v1 < v2
  assert not v2 < v1
  assert not v1 < v1
  # ... same result for __gt__, __le__ and __ge__
  # Unit test for method __eq__ of class Version
  v1 = Version('1.0.4')
  v2 = Version('1.0.4a1')
  assert v1 == v1
  assert v2 == v2
  assert not v1 == v2
  assert not v2 == v1
  # Unit test for method parse of class Version
  v1 = Version('1.0.4')
  v2 = Version('1.0.4a1')
  assert v1

# Generated at 2022-06-22 22:25:49.659561
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # valid LooseVersion strings
    s = "1.5.1"
    v = LooseVersion (s)
    assert str(v) == s
    assert v.vstring == s
    assert v.version == [1, 5, 1]

    s = "161"
    v = LooseVersion (s)
    assert str(v) == s
    assert v.vstring == s
    assert v.version == [161]

    s = "3.4j"
    v = LooseVersion (s)
    assert str(v) == s
    assert v.vstring == s
    assert v.version == [3, 4, "j"]

    s = "1996.07.12"
    v = LooseVersion (s)
    assert str(v) == s
    assert v.vstring == s
   

# Generated at 2022-06-22 22:25:53.427017
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    version = LooseVersion('196.12b')
    assert repr(version) == "LooseVersion ('196.12b')"

# Generated at 2022-06-22 22:25:59.008281
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion("1.0")
    s = v.__str__()

    assert s=="1.0", "Method __str__ of class LooseVersion returned %s, expected %s" % (repr(s), repr("1.0"))


# Generated at 2022-06-22 22:26:02.564988
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1.2') >= Version('1.2')
    assert Version('1.2.1') >= Version('1.2')
    assert not (Version('1.2') >= Version('1.2.1'))


# Generated at 2022-06-22 22:26:05.717119
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert str(v) == "Version ('0')"

# Generated at 2022-06-22 22:26:17.810218
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """test for method __repr__ of class LooseVersion"""
    v1 = "1.5.1"
    v2 = "1.5.2b2"
    v3 = "161"
    v4 = "3.10a"
    v5 = "8.02"
    v6 = "3.4j"
    v7 = "1996.07.12"
    v8 = "3.2.pl0"
    v9 = "3.1.1.6"
    v10 = "2g6"
    v11 = "11g"
    v12 = "0.960923"
    v13 = "2.2beta29"
    v14 = "1.13++"
    v15 = "5.5.kw"

# Generated at 2022-06-22 22:26:19.594313
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"

# Generated at 2022-06-22 22:26:31.126669
# Unit test for method __str__ of class StrictVersion

# Generated at 2022-06-22 22:26:34.981597
# Unit test for constructor of class Version
def test_Version():
    for ver in Version("Foo"), Version(vstring="Foo"):
        assert ver == "Foo"
        assert repr(ver) == "Version ('Foo')"


# Generated at 2022-06-22 22:26:43.349009
# Unit test for method __gt__ of class Version
def test_Version___gt__():
   ver1 = Version('1.6b1')
   ver2 = Version('1.6')
   ver3 = Version('1.6b2')
   ver4 = Version('2.0a1')
   ver5 = Version('1.6.0')
   ver6 = Version('1.7')
   ver7 = Version('1.6.1')
   ver8 = Version('1.6b')
   ver9 = Version('1.6b1.dev456')
   ver10 = Version('1.6.dev456')
   ver11 = Version('1.6.0')
   ver12 = Version('1.7a1')
   ver13 = Version('1.6a1.dev456')
   ver14 = Version('1.6.1')
   ver15 = Version('1.6a1')
   ver

# Generated at 2022-06-22 22:26:55.505294
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    cases = [
        ('1', '1'),
        ('1.2', '1.2'),
        ('1.2.3', '1.2.3'),
        ('1.2.3a4', '1.2.3a4'),
        ('1.2.3b5', '1.2.3b5'),
        ('1.2.3', '1.2.3'),
        ('1.2.3.4', '1.2.3.4'),
        ('1.2.3.4a5', '1.2.3.4a5'),
        ('1.2.3.4b6', '1.2.3.4b6'),
        ('1.2.3.4', '1.2.3.4'),
    ]

    for v, exp in cases:
        res

# Generated at 2022-06-22 22:27:06.349919
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    for x in ['1', '1.1', '1.1a', '1.1c', '1.1a']:
        for y in ['1', '1.1', '1.1a', '1.1c', '1.1a']:
            vx = Version(x)
            vy = Version(y)
            if x == y:
                assert (
                    vx < vy) == False, '%r was not less than %r' % (vx, vy)
                assert (
                    vx <= vy) == True, '%r was not less-than-or-equal to %r' % (
                    vx, vy)

# Generated at 2022-06-22 22:27:13.144359
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version("1.2.3").__eq__("1.2.3") == False
    assert Version("1.2.3").__eq__("1.2.3.0") == True
    assert Version("1.2.3").__eq__("1.2.2") == False
    assert Version("1.2.3").__eq__("1.3") == False
    assert Version("1.2.3").__eq__("1.2.x") == False
# unit tests for class Version

# Generated at 2022-06-22 22:27:22.610684
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion()
    l.parse('1.2')
    assert l.version == [1, 2]
    l.parse('1.2.3.4')
    assert l.version == [1, 2, 3, 4]
    l.parse('1.2a3')
    assert l.version == [1, 2, 'a', 3]
    l.parse('1.2.3a4.5.6b7.8b.9')
    assert l.version == [1, 2, 3, 'a', 4, 5, 6, 'b', 7, 8, 'b', 9]

    l.parse('1.2.3.4.5')
    assert l.version == [1, 2, 3, 4, 5]

# Generated at 2022-06-22 22:27:33.464447
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:27:41.757611
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    def test_code(version_number, reference):
        from distutils.version import StrictVersion
        v = StrictVersion(version_number)
        assert v.__str__() == reference

    test_code('0.4', '0.4')
    test_code('0.4.0', '0.4.0')
    test_code('0.4.1', '0.4.1')
    test_code('0.5a1', '0.5a1')
    test_code('0.5b3', '0.5b3')
    test_code('0.5', '0.5')
    test_code('0.9.6', '0.9.6')
    test_code('1.0', '1.0')

# Generated at 2022-06-22 22:27:51.368202
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Version instance with vstring == N/A
    v_n_a = Version()
    # Version instance with vstring == 1.0.0
    v_1_0_0 = Version('1.0.0')
    assert v_n_a.__ge__(v_1_0_0) is NotImplemented
    assert v_1_0_0.__ge__(v_n_a) is NotImplemented
    # Version instance with vstring == a.b.c.dev1
    v_a_b_c_dev1 = Version('a.b.c.dev1')
    assert v_a_b_c_dev1.__ge__(v_1_0_0) is NotImplemented

# Generated at 2022-06-22 22:27:58.287859
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """Unit test for StrictVersion.__str__()"""

    v1 = StrictVersion('0.45.0')
    assert str(v1) == '0.45'

    v2 = StrictVersion('1.0.0')
    assert str(v2) == '1.0'

    v3 = StrictVersion('2.10a1')
    assert str(v3) == '2.10a1'



# Generated at 2022-06-22 22:28:00.050046
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import doctest
    doctest.testmod(verbose=False)


test_StrictVersion_parse()



# Generated at 2022-06-22 22:28:12.468261
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('2.1')"


import string

_sv_sep_re = '[-._]'  # separator
_sv_sep_char_re = '[-_]'  # separator with char restriction
_sv_ver_re = r'\d+(?:[%s]\d+)*' % (_sv_sep_char_re,)  # N.N.N with sep restriction
_sv_pre_re = r'(?:[a-z]|(?:[a-z]\d+(?:[%s]\d+)*))' % (_sv_sep_char_re,)  # pre-release

# Generated at 2022-06-22 22:28:13.887508
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('2.6a0')
    assert repr(v) == "LooseVersion ('2.6a0')"


# Generated at 2022-06-22 22:28:19.042781
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2-3.4-zzz')
    assert repr(v) == "LooseVersion ('1.2-3.4-zzz')", repr(v)


# Generated at 2022-06-22 22:28:21.759733
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion()
    lv.parse("1.2")
    assert repr(lv) == "LooseVersion ('1.2')"


# Generated at 2022-06-22 22:28:23.943891
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    x = Version('2.2')
    y = Version('2.1')
    z = Version()
    x.__ge__(y)



# Generated at 2022-06-22 22:28:29.567378
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version("1.0.0")
    assert (v <= "1.0.0")
    assert (v <= LooseVersion("1.0"))
    assert (v <= LooseVersion("1.0.0"))
    assert (v <= LooseVersion("1.0.0b1"))
    assert (v <= LooseVersion("1.0.0.post0"))
    assert (not (v <= LooseVersion("1.0.post0")))
    assert (not (v <= LooseVersion("1.0.1")))

# Generated at 2022-06-22 22:28:32.139670
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    vstring='1.5.1'
    v = LooseVersion(vstring)
    assert v.__str__() == vstring


# Generated at 2022-06-22 22:28:42.675576
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion

    lv_eq = operator.eq
    lv_ne = operator.ne
    lv_lt = operator.lt
    lv_le = operator.le
    lv_gt = operator.gt
    lv_ge = operator.ge

    # equality
    assert lv_eq(lv("1.0"), lv("1.0"))
    assert lv_ne(lv("1.0"), lv("1.1"))
    assert lv_eq(lv("1.0a1"), lv("1.0a1"))
    assert lv_ne(lv("1.0a1"), lv("1.0b1"))
    assert lv_ne(lv("1.0"), lv("1.0rc1"))

# Generated at 2022-06-22 22:28:48.696503
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest
    class Test(unittest.TestCase):
        def test(self):
            self.assertEqual(Version().__ge__(1),NotImplemented)
            self.assertEqual(Version().__ge__(None),NotImplemented)
            self.assertEqual(Version().__ge__(object()),NotImplemented)
    unittest.main()


# Generated at 2022-06-22 22:28:58.031527
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    for data in [
            (('abc', 'abc', False), {}),
            ((Version('abc'), 'abc', False), {}),
            ((Version('abc'), Version('def'), False), {}),
            ((Version('abc'), Version('abc'), False), {}),
            ((Version('abc'), Version('abd'), True), {}),
            ((Version('abc'), Version('ab'), False), {}),
            ((Version('ab'), Version('abc'), True), {}),
            ((Version('abc'), Version('abcdef'), True), {}),
            ((Version('abcdef'), Version('abc'), False), {}),
            ((Version('abc'), Version('abc'), False), {}),
        ]:
        (args, kwargs) = data
        # Verify that stderr is not printed on every call

# Generated at 2022-06-22 22:29:07.118444
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # Test with short string
    v = LooseVersion('1.2.3')
    assert v.vstring == '1.2.3'
    assert v.__str__() == v.vstring

    # Test with long string (including strings)
    v = LooseVersion('a.b.c.d')
    assert v.vstring == 'a.b.c.d'
    assert v.__str__() == v.vstring

    # Test with empty string
    v = LooseVersion('')
    assert v.vstring == ''
    assert v.__str__() == v.vstring

    # Test with None
    v = LooseVersion(None)
    assert v.vstring == None
    assert v.__str__() == v.vstring

    # Test with a mixture of everything

# Generated at 2022-06-22 22:29:18.338327
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:29:26.813080
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion("1.0")
    if (str(v) != "1.0.0"):
        raise AssertionError("failed StrictVersion('1.0')->__str__")
    v = StrictVersion("1.0.0")
    if (v.version != (1, 0, 0)):
        raise AssertionError("failed StrictVersion('1.0.0')->version")
    v = StrictVersion("1.0a1")
    if (v.prerelease != ('a', 1)):
        raise AssertionError("failed StrictVersion('1.0a1')->prerelease")
    v = StrictVersion("1.0.1rc2")

# Generated at 2022-06-22 22:29:34.337802
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # 1. test with simple strings
    lv = LooseVersion('1')
    expected = "LooseVersion ('1')"
    result = repr(lv)
    assert result == expected

    # 2. test with complex strings
    lv = LooseVersion('1.0.2')
    expected = "LooseVersion ('1.0.2')"
    result = repr(lv)
    assert result == expected



# Generated at 2022-06-22 22:29:45.715888
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    import sys

    if sys.version.startswith('2.2'):
        # For Python 2.2, where cmp() is obsolete and does not
        # handle tuples correctly
        def cmp(a, b):
            return (a > b) - (a < b)

    def failUnlessEqual(a, b):
        if a != b:
            raise AssertionError("%r != %r" % (a, b))


# Generated at 2022-06-22 22:29:48.685766
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    LooseVersion((1,2,3,'a'))

# XXX for compatibility with old version numbering scheme:
#
# (I'm open to ideas for better names for these two classes.)


# Generated at 2022-06-22 22:29:51.749224
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # Create an instance of LooseVersion with a vstring
    v = LooseVersion('1.2.3')
    # Call method __repr__
    r = v.__repr__()
    # Assert string representation of instance is equal to 'LooseVersion('1.2.3')'
    assert r == 'LooseVersion (\'1.2.3\')', "Value of r is incorrect"



# Generated at 2022-06-22 22:29:56.437358
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert(LooseVersion('1.2.3.4') < LooseVersion('1.2.3.4a1'))
    assert(LooseVersion('1.2.3.4b2') == LooseVersion('1.2.3.4b2'))
    assert(LooseVersion('1.2.3') < LooseVersion('1.2.3pl1'))
    assert(LooseVersion('1.2.3') < LooseVersion('1.2.3.0'))
    assert(LooseVersion('1.2.3.0') == LooseVersion('1.2.3.0'))
    assert(LooseVersion('1.2.3a') < LooseVersion('1.2.3b'))

# Generated at 2022-06-22 22:29:58.074019
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('99')
    assert v < '100'

# Generated at 2022-06-22 22:30:02.226814
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('2.2beta29') == LooseVersion('2.2beta29'), \
           "Bogus test suite: '%s' != '%s'" % \
           (LooseVersion('2.2beta29'), LooseVersion('2.2beta29'))



# Generated at 2022-06-22 22:30:04.097734
# Unit test for constructor of class Version
def test_Version():
    from tests.lib.versions import TestVersions
    TestVersions.check_class(Version)



# Generated at 2022-06-22 22:30:07.222227
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3b2')
    assert str(v) == '1.2.3b2'


# Generated at 2022-06-22 22:30:11.665827
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    expected = StrictVersion('1.0')
    actual = StrictVersion().parse('1.0')
    assert expected.version == actual.version
    assert expected.prerelease == actual.prerelease

# Generated at 2022-06-22 22:30:23.150451
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease == None

    v = StrictVersion('1.0.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease == None

    v = StrictVersion('1.0a1')
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion('1.0.0a1')
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion('1.0b3')
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('b', 3)

    v

# Generated at 2022-06-22 22:30:26.469589
# Unit test for constructor of class Version
def test_Version():
    # with no args
    v = Version()

    # with a string
    v = Version('1.2.3')

    # with something else
    try:
        v = Version(9)
    except ValueError:
        pass


# Generated at 2022-06-22 22:30:32.400544
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion ('7.2')
    assert str(v) == '7.2'
    assert repr(v) == "LooseVersion ('7.2')"
    v = LooseVersion ('2.2beta29')
    assert str(v) == '2.2beta29'
    v = LooseVersion ('1.13++')
    assert str(v) == '1.13++'
    return

# Generated at 2022-06-22 22:30:38.617249
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv_1 = LooseVersion()

    # valid versions
    lv_1.parse('1.5.1')
    assert lv_1.version == [1, 5, 1]
    lv_1.parse('1.5.2b2')
    assert lv_1.version == [1, 5, 2, 'b', 2]
    lv_1.parse('161')
    assert lv_1.version == [161]
    lv_1.parse('3.10a')
    assert lv_1.version == [3, 10, 'a']
    lv_1.parse('8.02')
    assert lv_1.version == [8, 2]
    lv_1.parse('3.4j')

# Generated at 2022-06-22 22:30:48.211247
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Test all examples given in the class docstring, as they're canonical
    vs = ('0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5', '0.9.6', '1.0',
          '1.0.4a3', '1.0.4b1', '1.0.4')
    for v in vs:
        StrictVersion(v)

    # Test various forms of bogus input
    for v in ('', '1', '2.7.2.2', '1.3.a4', '1.3pl1', '1.3c4'):
        try:
            StrictVersion(v)
        except ValueError:
            pass

# Generated at 2022-06-22 22:30:55.033283
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():

    # StrictVersion__str__() => string
    # returns a string that can be used to re-create the version instance

    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2').__str__() == '1.2'
    assert StrictVersion('1.2a1').__str__() == '1.2a1'
    assert StrictVersion('1.2.0').__str__() == '1.2'

    # XXX __repr__ has not been tested at all



# Generated at 2022-06-22 22:30:56.773324
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    '''Test method Version.__ge__.'''
    v = Version()
    w = Version()
    assert v>=w



# Generated at 2022-06-22 22:31:08.409311
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def do_test(vstring, parsed, parsed_as_loose):
        v = StrictVersion(vstring)
        assert str(v) == parsed
        assert v.version == parsed_as_loose.version
        assert v.prerelease == parsed_as_loose.prerelease

    do_test('1.2.3a4', '1.2.3a4', StrictVersion('1.2.3a4'))
    do_test('1.2.3-b2', '1.2.3b2', StrictVersion('1.2.3b2'))
    do_test('1.2', '1.2', StrictVersion('1.2'))
    do_test('  2.2  ', '2.2', StrictVersion('2.2'))

# Generated at 2022-06-22 22:31:10.439331
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v1 = LooseVersion('1.0.1')
    assert v1.version == [1, 0, 1]
    assert str(v1) == '1.0.1'



# Generated at 2022-06-22 22:31:14.013304
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    testdata = [
        (LooseVersion('1.5'),
            "LooseVersion ('1.5')"),
        ]
    for loose_version, expected in testdata:
        assert str(loose_version) == expected



# Generated at 2022-06-22 22:31:17.066236
# Unit test for constructor of class Version
def test_Version():
    Version()
    v = Version()
    v.parse('1.2.3')
    repr(v)
    str(v)
    Version('1.2.3')
    Version(vstring='1.2.3')



# Generated at 2022-06-22 22:31:25.844419
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    LooseVersion('1.4')
    LooseVersion('1.4.11')
    LooseVersion('3.10a')
    LooseVersion('1.5.1b1')
    LooseVersion('1.5.1b2')
    LooseVersion('1.5.1c1')
    LooseVersion('1.5.1c2')
    LooseVersion('1.5.1')
    LooseVersion('161')
    LooseVersion('3.10a')
    LooseVersion('8.02')
    LooseVersion('3.4j')
    LooseVersion('1996.07.12')
    LooseVersion('3.2.pl0')
    LooseVersion('3.1.1.6')
    LooseVersion('2g6')
    LooseVersion('11g')


# Generated at 2022-06-22 22:31:35.384229
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:31:43.631251
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """test method LooseVersion.__repr__ for type conversion"""
    v = LooseVersion("1.2.3")
    assert type(str(v)) == str
    assert str(v) == "1.2.3"
    assert type(LooseVersion("3.3.3").__repr__()) == str
    assert LooseVersion("3.3.3").__repr__() == "LooseVersion ('3.3.3')"


# Generated at 2022-06-22 22:31:45.735580
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version(1)
    assert v.__repr__() == "Version ('1')"



# Generated at 2022-06-22 22:31:51.889739
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    tests = [
        ((1, 2, 0, None),
         '1.2'),

        ((1, 2, 3, None),
         '1.2.3'),

        ((1, 2, 3, ('a', 3)),
         '1.2.3a3'),
    ]

    sv = StrictVersion
    for test in tests:
        version = test[0]
        result = test[1]
        assert str(sv(version)) == result, str(sv(version))



# Generated at 2022-06-22 22:32:02.481507
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # a sequence of (version, list-of-valid-strings) tuples
    versions = [
        ((1, 2, 3), ['1.2.3', '1.2.3.0', '1.2.3.0.0']),
        ((1, 2, 3, 'alpha', 1), ['1.2.3a1', '1.2.3.0a1', '1.2.3.0.0a1']),
        ]

    for (version, vstrings) in versions:

        for vstring in vstrings:
            v = StrictVersion(vstring)
            assert v.version == version
            assert str(v) == vstring

        # invalid string raises ValueError

# Generated at 2022-06-22 22:32:13.059322
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:32:19.704185
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """Unit test for method LooseVersion.parse"""
    import tests
    import random


# Generated at 2022-06-22 22:32:21.760009
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version()
    assert version._cmp(version) == 0, 'version._cmp(version) == 0'

# Generated at 2022-06-22 22:32:29.720243
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    StrictVersion("1").parse("1")
    try:
        StrictVersion("2.7.2.2").parse("2.7.2.2")
    except ValueError:
        pass
    try:
        StrictVersion("1.3.a4").parse("1.3.a4")
    except ValueError:
        pass
    try:
        StrictVersion("1.3pl1").parse("1.3pl1")
    except ValueError:
        pass
    try:
        StrictVersion("1.3c4").parse("1.3c4")
    except ValueError:
        pass
test_StrictVersion_parse()



# Generated at 2022-06-22 22:32:40.598054
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def verify(v1, v2):
        if v2 is None:
            return v1.parse(v1.vstring) is not None
        else:
            return v1.version == v2[0] and v1.prerelease == v2[1]

    _verify = verify
    import string
    StrictVersion.version_re = re.compile(r'^(\d+) \. (\d+) (\. (\d+))? '
                                          r'([ab](\d+))?$', RE_FLAGS)
    sv = StrictVersion
    BAD_VERSION = '1.3.a4'

    assert _verify(sv('1.3.0'), ((1, 3, 0), None))
    assert _verify(sv('1.3'), ((1, 3, 0), None))