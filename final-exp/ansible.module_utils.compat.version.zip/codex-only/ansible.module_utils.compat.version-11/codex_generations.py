

# Generated at 2022-06-22 22:22:36.105591
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    with pytest.raises(NotImplementedError):
        v = Version()
        v == None


# Generated at 2022-06-22 22:22:39.410301
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion("3.4.2")
    assert_equal(str(v), "3.4.2")

# Since LooseVersion is a subclass of Version, it's tested by the
# unit test for the Version class.  We only need to test stuff that
# has been overridden, namely parse() and _cmp().


# Generated at 2022-06-22 22:22:42.803535
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version("1.0")
    v2 = Version("1.0.0")
    assert v1 == v2, \
        "Version('1.0') and Version('1.0.0') should be equivalent"

# Generated at 2022-06-22 22:22:43.728567
# Unit test for constructor of class Version
def test_Version():
    Version()
    Version("123.456")


# Generated at 2022-06-22 22:22:48.271576
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    for v in ['1.5.1', '1.5.2b2', '161', '3.10a', '8.02', '3.4j',
              '1996.07.12', '3.2.pl0', '3.1.1.6', '2g6', '11g',
              '0.960923', '2.2beta29', '1.13++', '5.5.kw', '2.0b1pl0']:
        assert str(LooseVersion(v)) == v


# Generated at 2022-06-22 22:22:58.244258
# Unit test for method __str__ of class StrictVersion

# Generated at 2022-06-22 22:23:05.310112
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version

    # Construct a Version instance
    inst = Version('1.0')

    # Check result of equality method
    assert inst == '1.0'
    assert inst == 1.0
    assert inst == '1.0.0'
    assert inst == '1.0.0.0.0'
    assert inst == Version('1.0')
    assert inst == Version('1.0.0')
    assert inst == Version('1.0.0.0.0')
    assert inst != '1.1'
    assert inst != Version('1.1')
    assert inst != 1.1
    assert inst != '1.0dev'
    assert inst != '1.0-alpha'
    assert inst != '1.0-beta'
    assert inst != '1.0-beta4'
#

# Generated at 2022-06-22 22:23:12.355305
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    from distutils.version import StrictVersion
    a = StrictVersion("1.2.3")
    assert str(a) == "1.2.3"
    assert repr(a) == "StrictVersion ('1.2.3')"
    a = StrictVersion("1.2")
    assert str(a) == "1.2"
    a = StrictVersion("1")
    assert str(a) == "1"
    a = StrictVersion("10")
    assert str(a) == "10"


# Generated at 2022-06-22 22:23:13.572039
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert (Version() <= Version())  # __le__



# Generated at 2022-06-22 22:23:15.343762
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version("1.2.3")
    v2 = Version("1.2.3")
    assert v1 == v2

# Generated at 2022-06-22 22:23:18.323404
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import doctest
    doctest.testmod(StrictVersion, extraglobs={'StrictVersion': StrictVersion})

# Generated at 2022-06-22 22:23:21.008609
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    t = LooseVersion("1.2")
    assert not t.version_re.match("1.2")



# Generated at 2022-06-22 22:23:26.118479
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('0.0.1')
    eq_(str(lv), '0.0.1')
    eq_(repr(lv), 'LooseVersion (\'0.0.1\')')


if __name__ == "__main__":
    from util.maketest import run_unittests
    run_unittests(__name__)

# Generated at 2022-06-22 22:23:29.583964
# Unit test for constructor of class Version
def test_Version():
    for v in ['', '1', '1.2', '1.2.3']:
        Version(v)


# Generated at 2022-06-22 22:23:39.411636
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('0.4')
    assert v.version == (0,4,0)
    assert v.prerelease is None
    v = StrictVersion('0.4.0')
    assert v.version == (0,4,0)
    assert v.prerelease is None
    v = StrictVersion('0.4.1')
    assert v.version == (0,4,1)
    assert v.prerelease is None
    v = StrictVersion('0.5a1')
    assert v.version == (0,5,0)
    assert v.prerelease == ('a', 1)
    v = StrictVersion('0.5b3')
    assert v.version == (0,5,0)
    assert v.prerelease == ('b', 3)

# Generated at 2022-06-22 22:23:48.079938
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3')
    assert v == '1.2.3'
    assert v >= '1.2.3'
    assert v <= '1.2.3'
    assert (v != '1.2.3') == False
    assert (v == '1.2.4') == False
    assert v < '1.2.4'
    assert v <= '1.2.4'
    assert (v > '1.2.4') == False
    assert (v >= '1.2.4') == False



# Generated at 2022-06-22 22:23:58.301128
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring):
        print()
        print(vstring)
        version = StrictVersion(vstring)
        print("  version =", version)
        print("      str =", str(version))
        print("    repr =", repr(version))

    test('1.4')
    test('1.4.1')
    test('1.4.2b2')
    test('1.0.4a3')
    test('1.1-2')

    test('1.1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0')


# Generated at 2022-06-22 22:24:04.883289
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    global __test_LooseVersion___str___passed__
    try:
        lv = LooseVersion('1.13++')
        s = str(lv)
    except:
        pass
    else:
        if s == '1.13++':
            __test_LooseVersion___str___passed__ = 1
        else:
            raise AssertionError(s)

# Generated at 2022-06-22 22:24:06.669951
# Unit test for constructor of class Version
def test_Version():
    v1 = Version()
    v2 = Version('2')
    v3 = Version(v2)


# Generated at 2022-06-22 22:24:13.073991
# Unit test for method __gt__ of class Version
def test_Version___gt__():
  v1 = Version('2.1')
  v2 = Version('2.2b2')
  v3 = Version('1.1')
  assert v1 > v3
  assert v2 < v3
  assert v1 < v2
  assert v1 < '2.2b2'
  assert v2 > '2.2b2'


# Generated at 2022-06-22 22:24:24.838153
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Create a new instance of Version
    v = Version()

    # Assert type of v.__repr__() is str
    assert isinstance(v.__repr__(), str)


RE_LOOSE_VERSION = re.compile(r""" ^
    (\d+)                # major
    \D*
    ((?:\d+ | [a-z]+ | \.)*)     # minor
    \D*
    ((?:\d+ | [a-z]+ )*)     # micro
    \D*
    (\d+)?               # pre-release
    ([ab](\d+)?)?        # post-release
    (?:\+(\d+ | [a-z]+)*)?   # dev
    $""", RE_FLAGS)


# Generated at 2022-06-22 22:24:33.522893
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:24:37.785006
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    #Just a one-liner test
    assert LooseVersion('1.2.3.4').__str__() == '1.2.3.4'



# Generated at 2022-06-22 22:24:41.817115
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Setup
    strict_version = StrictVersion()
    # Exercise
    strict_version.parse('1.0')
    # Verify
    assert isinstance(strict_version.version, tuple)
    assert strict_version.version == (1, 0, 0)


# Generated at 2022-06-22 22:24:48.490105
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """
    This function tests the parsing function of class LooseVersion.
    It creates a version string, parse it and compares the result
    of the parsing with the version string itself.

    @return: None
    """
    v_lst = ["1g0", "1.5.1", "1.5.2b2", "161", "3.10a", "8.02",
             "3.4j", "1996.07.12", "3.2.pl0", "3.1.1.6", "2g6",
             "11g", "0.960923", "2.2beta29", "1.13++", "5.5.kw",
             "2.0b1pl0"]

# Generated at 2022-06-22 22:24:58.722488
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def test(version_str, expected_version, expected_prerelease):
        v = StrictVersion(version_str)
        assert v.version == expected_version, (
            "expected version %r, got %r" % (expected_version, v.version)
        )
        assert v.prerelease == expected_prerelease, (
            "expected prerelease %r, got %r" % (expected_prerelease, v.prerelease)
        )

    test("0.4", (0, 4), None)
    test("0.4.0", (0, 4, 0), None)
    test("0.4.1", (0, 4, 1), None)
    test("0.5a1", (0, 5), ('a', 1))

# Generated at 2022-06-22 22:25:01.186870
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert v.__repr__() == "Version ('None')"
    v = Version('3.2')
    assert v.__repr__() == "Version ('3.2')"


# Generated at 2022-06-22 22:25:08.760180
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    from distutils.tests import support
    import unittest

    class VersionTestCase(support.EnvironGuard,
                          unittest.TestCase):

        def test_gt(self):
            v1 = Version("1.0")
            v2 = Version("2.0")

            self.assertTrue(v1 < v2)
            self.assertTrue(v2 > v1)

            self.assertFalse(v1 > v2)
            self.assertFalse(v2 < v1)

            self.assertFalse(v1 > "1.1")
            self.assertTrue(v1 < "1.1")

    unittest.main()



# Generated at 2022-06-22 22:25:19.228468
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """
    Tests for method __eq__ of class Version
    """
    # TEST CASE: Version.__eq__(), not equal
    assert not Version("1.0") == Version("1.1")

    # TEST CASE: Version.__eq__(), equal
    assert Version("1.0") == Version("1.0")

    # TEST CASE: Version.__eq__(), non-Version, non-equal
    assert not Version("1.0") == None

    # TEST CASE: Version.__eq__(), non-Version, equal
    assert Version("1.0") == "1.0"

    # TEST CASE: Version.__eq__(), string and None, equal
    assert "1.0" == Version("1.0")

    # TEST CASE: Version.__eq__(), string and None, not equal
    assert "1.0" != Version

# Generated at 2022-06-22 22:25:21.149738
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version('1.2') == Version(1.2)
# End unit test



# Generated at 2022-06-22 22:25:26.044045
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('2.2')
    assert str(lv) == '2.2'
    lv = LooseVersion()
    assert str(lv) is None



# Generated at 2022-06-22 22:25:29.537994
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    '''This script unit-tests method parse of class LooseVersion.
    It creates an instance, then assigns various bad arg and checks for
    raise of ValueError.
    '''
    c = LooseVersion()
    c.parse('')
# end test_LooseVersion_parse()


# Generated at 2022-06-22 22:25:31.573276
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ver = Version()
    assert(ver.__gt__("") == NotImplemented)

# Generated at 2022-06-22 22:25:35.143155
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v_class = Version()
    v_class2 = Version()
    assert v_class != v_class2


# Generated at 2022-06-22 22:25:44.097610
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    try:
        StrictVersion("")
    except ValueError as e:
        print("ValuesError %s" % e)
    try:
        StrictVersion("1")
    except ValueError as e:
        print("ValuesError %s" % e)
    try:
        StrictVersion("2.2.2.2")
    except ValueError as e:
        print("ValuesError %s" % e)
    try:
        StrictVersion("1.3.a4")
    except ValueError as e:
        print("ValuesError %s" % e)
    try:
        StrictVersion("1.3pl1")
    except ValueError as e:
        print("ValuesError %s" % e)

# Generated at 2022-06-22 22:25:53.863443
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion("1.3.3").version == (1,3,3)
    assert StrictVersion("1.2").version == (1,2,0)
    assert StrictVersion("1.3.0").version == (1,3,0)
    assert StrictVersion("2").version == (2,0,0)
    assert StrictVersion("2.0").version == (2,0,0)
    assert StrictVersion("2.0a1").version == (2,0,0)
    assert StrictVersion("2.0c1").version == (2,0,0)
    assert StrictVersion("2.0b1").version == (2,0,0)
    assert StrictVersion("2.0a1").prerelease == ('a', 1)

# Generated at 2022-06-22 22:26:04.848161
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # These tests require testing direct comparison of version objects.
    # For this version of distutils we can not do that because it would
    # mess up the backwards compatibility, so we test it by comparing
    # two strings.
    v = Version('1.2.3')
    assert v == '1.2.3'
    v = Version('1.2.3.0')
    assert v == '1.2.3.0'
    v = Version('1.2.3.0.post11')
    assert v == '1.2.3.0.post11'

    # Comparison to other types should return False
    v = Version('1.2.3')
    assert not (v == 1)
    assert not (v == [1, 2, 3])
    assert not (v == {'a': 1})
    # Unit test

# Generated at 2022-06-22 22:26:07.289958
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    o = Version('1')
    assert_raises(NotImplementedError, lambda: o < 1)

# Generated at 2022-06-22 22:26:11.536422
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    ver1 = Version('1.2.3')
    ver2 = Version('1.2.3')
    assert (ver1 >= ver2)
    ver2 = Version('1.2.4')
    assert (not (ver1 >= ver2))

# Generated at 2022-06-22 22:26:14.616802
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version('1.0.0')
    assert version <= version
    assert version <= '1.0.0'

# Generated at 2022-06-22 22:26:17.480729
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version(vstring='0')
    v2 = Version(vstring='1')
    assert v1.__lt__(v2) == True


# Generated at 2022-06-22 22:26:21.736839
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Version.__repr__() -> str
    # Returns a Python expression string that represents this instance.
    #
    # Tests for this method will appear soon.
    # Raises
    # ------
    # AttributeError
    #     If version is not set.
    print(Version.__repr__(Version))



# Generated at 2022-06-22 22:26:23.232882
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == ""

# Generated at 2022-06-22 22:26:25.616236
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.0')
    assert repr(v) == "Version ('1.0')"

# Generated at 2022-06-22 22:26:26.628029
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= Version()

# Generated at 2022-06-22 22:26:34.920235
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('1')).endswith('1')
    assert str(StrictVersion('1.2')).endswith('1.2')
    assert str(StrictVersion('1.2.3')).endswith('1.2.3')
    assert str(StrictVersion('1.2.3a4')).endswith('1.2.3a4')
    assert str(StrictVersion('1.2.3b5')).endswith('1.2.3b5')
    assert str(StrictVersion('1.2.3a5')).endswith('1.2.3a5')



# Generated at 2022-06-22 22:26:40.497220
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    test_values = ["1.2.3", (1, 2, 3, 4), ["1", "2", "3", "4"]]
    for value in test_values:
        if not isinstance(value, str):
            value = '.'.join(map(str,value))
        v = StrictVersion(value)
        assert v.__str__() == '1.2.3'


# Generated at 2022-06-22 22:26:45.034020
# Unit test for constructor of class Version
def test_Version():
    for vstring in ('1.2.3', '10.2.3', '1.12.3', '1.2.13'):
        version = Version(vstring)
        assert repr(version) == 'Version (%s)' % version


# Generated at 2022-06-22 22:26:52.671308
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v1 = LooseVersion("1.3a4")
    assert len(v1.version) == 3
    assert type(v1.version[2]) is str
    assert v1.version[2][0] == "a"

    v2 = LooseVersion("1.3")
    assert len(v2.version) == 2
    assert type(v2.version[0]) is int
    assert type(v2.version[1]) is int

    ##################################################################
    # test the sorting order given by LooseVersion
    def test(a, b):
        """test that a < b"""
        assert LooseVersion(a) < LooseVersion(b)

    test("1.0", "1.0.1")
    test("1.0a1", "1.0")


# Generated at 2022-06-22 22:26:54.756411
# Unit test for constructor of class Version
def test_Version():
    assert repr(Version()) == "Version ('0')"
    assert repr(Version('1.2.3')) == "Version ('1.2.3')"


# Generated at 2022-06-22 22:27:05.684420
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """__str__(self) """
    lv = LooseVersion('1.2.3')
    assert lv.__str__() == '1.2.3'

    lv = LooseVersion('1.2.3.4')
    assert lv.__str__() == '1.2.3.4'

    lv = LooseVersion('1.2.3.4.5')
    assert lv.__str__() == '1.2.3.4.5'

    lv = LooseVersion('1.2.3.4.5.6')
    assert lv.__str__() == '1.2.3.4.5.6'

    lv = LooseVersion('1.2.3.4.5alpha')

# Generated at 2022-06-22 22:27:09.636999
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    a = LooseVersion('1.1.0')
    b = LooseVersion(a)
    assert a.__repr__() != b.__repr__()

test_LooseVersion___repr__()

# Generated at 2022-06-22 22:27:11.289924
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ver = Version()

    assert (ver.__lt__(1) is NotImplemented)



# Generated at 2022-06-22 22:27:15.796411
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    print("Test for method __eq__ of class Version")
    a = Version("1.0")
    b = Version("1.0")

    assert(a == b)

# Generated at 2022-06-22 22:27:18.245237
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
	"""__repr__(self) -> string

	Return a string representing this version.
	"""

	__repr__ = LooseVersion("2.0.0").__repr__
	assert __repr__() == "LooseVersion ('2.0.0')"
	return
test_LooseVersion___repr__()

# Generated at 2022-06-22 22:27:29.050322
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    l = []
    for v in ["1.5.1", "1.5.2b2", "161", "3.10a", "8.02", "3.4j",
              "1996.07.12", "3.2.pl0", "3.1.1.6", "2g6", "11g",
              "0.960923", "2.2beta29", "1.13++", "5.5.kw", "2.0b1pl0"]:
        l.append(LooseVersion(v))

    l.sort()
    for i in range(len(l) - 1):
        assert l[i] < l[i + 1]


# Generated at 2022-06-22 22:27:36.727939
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():

    version_string = "1.2.3a1+456.789"
    # sdist, bdist_dumb and bdist_wininst are missing to test __str__()
    # is not affected by the format
    test_formats = ['bdist_rpm', 'bdist_dmg', 'bdist_egg', 'bdist_wheel',
                   'bdist_msi']
    for fmt in test_formats:
        v = LooseVersion(version_string)
        v.metadata = fmt
        assert str(v) == version_string + "+" + fmt



# Generated at 2022-06-22 22:27:40.430509
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v.__lt__(None) is NotImplemented



# Generated at 2022-06-22 22:27:50.554562
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    #jd = LooseVersion
    lv = LooseVersion
    # test default args
    assert lv().version == (0,)
    # test string arg
    assert lv('1.2.3').version == (1,2,3)
    assert lv('1.2.3a').version == (1,2,3,'a')
    assert lv('1.2.3b').version == (1,2,3,'b')
    assert lv('1.2.3b-1').version == (1,2,3,'b-1')
    assert lv('1.2.3b2').version == (1,2,3,'b2')
    assert lv('1.2.3.4').version == (1,2,3,4)

# Generated at 2022-06-22 22:27:53.406409
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():    
    v = StrictVersion("1.0a1")
    assert str(v) == "1.0a1"


# Generated at 2022-06-22 22:28:02.204225
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Test brand-new constructor, the one that gets called by the
    # Metadata constructor.  When the class is called as
    #   StrictVersion('1.2.3')
    # there must be a tuple instance as .version, and it must be
    #   (1, 2, 3)
    # (by default, the .prerelease and .is_prerelease attributes are
    #  None and False, but those aren't important here)
    v = StrictVersion('1.2.3')
    assert isinstance(v.version, tuple)
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    assert not v.is_prerelease



# Generated at 2022-06-22 22:28:13.993132
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import unittest
    res = LooseVersion("1.5.1").parse("1.5.1")
    assert res == None, res
    res = LooseVersion("1.5.2b2").parse("1.5.2b2")
    assert res == None, res
    res = LooseVersion("161").parse("161")
    assert res == None, res
    res = LooseVersion("3.10a").parse("3.10a")
    assert res == None, res
    res = LooseVersion("8.02").parse("8.02")
    assert res == None, res
    res = LooseVersion("3.4j").parse("3.4j")
    assert res == None, res
    res = LooseVersion("1996.07.12").parse("1996.07.12")
    assert res

# Generated at 2022-06-22 22:28:19.596723
# Unit test for constructor of class Version
def test_Version():
    # Test default
    v = Version()
    assert v.version is None
    # Test positional argument
    v = Version('1.2.3')
    assert v.version == '1.2.3'


# Generated at 2022-06-22 22:28:28.763908
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion('')
    l.parse('1.2a2')
    assert l.version == [1, 2, 'a', 2]
    l.parse('1.2.3')
    assert l.version == [1, 2, 3]
    l.parse('1.2')
    assert l.version == [1, 2]
    l.parse('1.2pre3')
    assert l.version == [1, 2, 'pre', 3]
    l.parse('1.2.3.4')
    assert l.version == [1, 2, 3, 4]
    l.parse('1.2\n')
    assert l.version == [1, 2]
    l.parse('1.2.3.4.5')

# Generated at 2022-06-22 22:28:39.954277
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    for data in (('1', (1, 0, 0)), ('1.2', (1, 2, 0)), ('1.2.3', (1, 2, 3))):
        version = StrictVersion(data[0])
        assert version.version == data[1], str(version.version)
        assert version.prerelease is None
        assert repr(version) == "StrictVersion ('%s')" % data[0]
    for data in (('1.2a1', ('a', 1)), ('1.2.3b2', ('b', 2))):
        version = StrictVersion(data[0])
        assert version.prerelease == data[1]
        assert repr(version) == "StrictVersion ('%s')" % data[0]



# Generated at 2022-06-22 22:28:42.029673
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert v.__repr__() == "Version ('<unknown>')"

# Generated at 2022-06-22 22:28:43.850884
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version("0.0.1") > Version("0.0.0b")

# Generated at 2022-06-22 22:28:55.119571
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    sv = StrictVersion
    v = sv("1.0")
    assert v.version == (1,0,0)
    assert v.prerelease == None
    v = sv("1.0.0")
    assert v.version == (1,0,0)
    assert v.prerelease == None
    v = sv("1.0a1")
    assert v.version == (1,0,0)
    assert v.prerelease == ('a',1)
    v = sv("1.0b3")
    assert v.version == (1,0,0)
    assert v.prerelease == ('b',3)
    try:
        v = sv("1")
        assert False
    except ValueError: pass

# Generated at 2022-06-22 22:28:58.757887
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version('0.0.dev1')
    v2 = Version('0.0')
    assert v1 < v2

# Generated at 2022-06-22 22:29:01.775453
# Unit test for method __le__ of class Version
def test_Version___le__():
    from ansible_galaxy.utils.version import Version

    instance = Version()

    assert instance.__le__('1.0') == NotImplemented



# Generated at 2022-06-22 22:29:04.350307
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Unit test for method __ge__ of class Version"""
    v1 = '1.1a-1'
    v2 = Version(v1)
    assert v2 >= v1


# Generated at 2022-06-22 22:29:10.010893
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
        v = ModuleVersion("1.2.3")
        v2 = ModuleVersion("1.2.3.4")
        assert(v.parse("1.2.3") == "1.2.3")
        assert(v2.parse("1.2.3.4") == "1.2.3.4")

# Generated at 2022-06-22 22:29:21.211859
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    """
    Tests that StrictVersion.parse() correctly parses a string representation
    of a version as a tuple of its numeric components, and that
    pre-release tags are ignored.
    """
    strict_version = StrictVersion()
    strict_version.parse("1.0a0")
    assert strict_version.version == (1, 0, 0)
    assert strict_version.prerelease == ('a', 0)

    strict_version.parse("0.9.6")
    assert strict_version.version == (0, 9, 6)
    assert strict_version.prerelease == None

    strict_version.parse("12345")
    assert strict_version.version == (12345, 0, 0)

    strict_version.parse("1.0.4a3")

# Generated at 2022-06-22 22:29:26.578990
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('0.4.1')
    assert str(v) == '0.4.1'
    v = StrictVersion('0.5b3')
    assert str(v) == '0.5b3'
    v = StrictVersion('1.0.4b1')
    assert str(v) == '1.0.4b1'



# Generated at 2022-06-22 22:29:37.230728
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    
    lv.parse('2.2')
    assert lv.version == [2, 2]
    
    lv.parse('2.2a')
    assert lv.version == [2, 2, 'a']
    
    lv.parse('2.2.a')
    assert lv.version == [2, 2, 'a']
    
    lv.parse('a.b')
    assert lv.version == ['a', 'b']
    
    lv.parse('a b')
    assert lv.version == ['a', 'b']
    
    lv.parse('a..b')
    assert lv.version == ['a', 'b']
    
    lv.parse('a..b...c')

# Generated at 2022-06-22 22:29:40.995888
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v.parse = lambda x: None
    other = Version()
    other.parse = lambda x: None
    ret = v.__le__(other)
    return ret


# Generated at 2022-06-22 22:29:45.565501
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import unittest

    class Version_TestCase(unittest.TestCase):
        def test_Version___ge__(self):
            with self.assertRaises(NotImplementedError):
                Version().__ge__()

    unittest.main()



# Generated at 2022-06-22 22:29:53.711051
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion('1.2.3') > '1.2.2'
    assert StrictVersion('1.2') > StrictVersion('1.2a1')
    assert StrictVersion('1.2a1') < StrictVersion('1.2b1')
    assert StrictVersion('1.2.3dev') < StrictVersion('1.2.3')
    assert StrictVersion('1.2.3') != StrictVersion('2.0')
    assert StrictVersion('1.3.3') > StrictVersion('1.2.3')
    assert StrictVersion('1.3.3') > StrictVersion('1.3.3.1')
    assert StrictVersion('1.3.3') > StrictVersion('1.3.3b1')

# Generated at 2022-06-22 22:30:04.987127
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """Test method __str__ of class StrictVersion"""
    # Constructor tests
    x = StrictVersion()
    assert str(x) == '0.0'
    x = StrictVersion('0.0')
    assert str(x) == '0.0'
    x = StrictVersion('1.5')
    assert str(x) == '1.5'
    x = StrictVersion('1.5.3')
    assert str(x) == '1.5.3'
    x = StrictVersion('1.5b3')
    assert str(x) == '1.5b3'
    x = StrictVersion('1.5a3')
    assert str(x) == '1.5a3'
    x = StrictVersion('1.5.3.4')

# Generated at 2022-06-22 22:30:16.573682
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.2')
    assert str(lv) == '1.2'
    lv = LooseVersion('1.2.3')
    assert str(lv) == '1.2.3'
    lv = LooseVersion('1.2a3')
    assert str(lv) == '1.2a3'
    lv = LooseVersion('1.2b3')
    assert str(lv) == '1.2b3'
    lv = LooseVersion('1.2c3')
    assert str(lv) == '1.2c3'
    lv = LooseVersion('1')
    assert str(lv) == '1'
    lv = LooseVersion('1.2.3.4')

# Generated at 2022-06-22 22:30:27.343191
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # no arguments
    try:
        v = StrictVersion()
    except TypeError:
        pass
    else:
        raise AssertionError("StrictVersion() should have failed")

    # non-string object
    try:
        v = StrictVersion(1)
    except TypeError:
        pass
    else:
        raise AssertionError("StrictVersion(1) should have failed")

    # multiple arguments
    try:
        v = StrictVersion("1", "1")
    except TypeError:
        pass
    else:
        raise AssertionError("StrictVersion(1, 1) should have failed")

    # too many numeric parts

# Generated at 2022-06-22 22:30:36.525780
# Unit test for constructor of class Version
def test_Version():
    assert str(Version('1.1')) == '1.1'
    assert str(Version()) == ''
    assert str(Version('1.2.3')) == '1.2.3'
    assert str(Version('a b c')) == 'a b c'
    assert str(Version('a b_c')) == 'a b_c'
    assert str(Version('a!b-c')) == 'a!b-c'
    assert str(Version()) == ''
    assert Version('1.1') == Version('1.1')
    assert Version('1.1') != Version('1.2')
    assert Version('1.2') > Version('1.1')
    assert Version('1.1') < Version('1.2')

# Generated at 2022-06-22 22:30:42.302638
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('0.1.0')
    v2 = Version('2.0.0')
    
    assert v1 != v2
    assert v2 != v1
    
    assert v1 == Version('0.1.0')
    assert v2 == Version('2.0.0')


# Generated at 2022-06-22 22:30:49.763931
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def __test(vstring, pvstring):
        cmp = LooseVersion(vstring).parse(vstring)
        assert LooseVersion(vstring).version == cmp.version, (
            LooseVersion(vstring).version, cmp.version
        )
    __test('1.0', '1.0')
    __test('1.1', '1.1')
    __test('1.2.0', '1.2.0')
    __test('1.2.1', '1.2.1')
    __test('1.2.2', '1.2.2')
    __test('1.2.3a0', '1.2.3a0')
    __test('1.2.3a1', '1.2.3a1')

# Generated at 2022-06-22 22:30:58.126633
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    SV = StrictVersion("1.0")
    assert SV.version == (1, 0, 0)
    assert SV.prerelease is None
    SV = StrictVersion("1.0.0")
    assert SV.version == (1, 0, 0)
    assert SV.prerelease is None
    SV = StrictVersion("1.0a1")
    assert SV.version == (1, 0, 0)
    assert SV.prerelease == ('a', 1)
    SV = StrictVersion("1.0b3")
    assert SV.version == (1, 0, 0)
    assert SV.prerelease == ('b', 3)
    SV = StrictVersion("1.0.0a3")
    assert SV.version == (1, 0, 0)
    assert SV.prerelease == ('a', 3)
    SV

# Generated at 2022-06-22 22:31:06.624291
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion("1.2.3") == "1.2.3"
    assert LooseVersion("1.2") == "1.2"
    assert LooseVersion("1.2+") == "1.2+"
    assert LooseVersion("1.2.3+") == "1.2.3+"
    assert LooseVersion("1.2.3+4.5.6") == "1.2.3+4.5.6"

if __name__ == "__main__":
    test_LooseVersion()

# Generated at 2022-06-22 22:31:10.563985
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    version._cmp = Mock(return_value=int)
    version.__lt__('')
    version._cmp.assert_called_with('')



# Generated at 2022-06-22 22:31:13.437329
# Unit test for constructor of class Version
def test_Version():
    for vstring in ('1.2.3', 'a.b', 'M.N'):
        assert vstring == Version(vstring)


# Generated at 2022-06-22 22:31:18.279806
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    object1 = Version()
    object2 = Version()
    object3 = Version()
    assert object3.__gt__(object1) == NotImplemented
    assert object3.__gt__(object2) == NotImplemented

if __name__ == '__main__':
    test_Version___gt__()

# Generated at 2022-06-22 22:31:20.457833
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion("1.0")
    assert repr(lv) == "LooseVersion ('1.0')"


# Generated at 2022-06-22 22:31:27.954536
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import sys
    import StringIO
    import StringIO
    import unittest

    class StubTestResult:
        def __init__(self):
            self.failures = 0
            self.errors = 0

        def startTest(self,test):
            pass

        def stopTest(self,test):
            pass

        def error(self,test,err):
            self.errors += 1

        def failure(self,test,err):
            self.failures += 1

    class StubTestCase(unittest.TestCase):
        def __str__(self):
            return ("<StubTestCase run=False>"
                    "[failures=%s, errors=%s]") % (self.failures, self.errors)
        def run(self,result=None):
            if result is None: result = self.defaultTest

# Generated at 2022-06-22 22:31:36.482195
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:31:40.719751
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    v = Version('1.2.3a1')
    assert v

#
# The classes that do the actual work
#



# Generated at 2022-06-22 22:31:51.157822
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:31:53.638033
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1=Version()
    v2=Version()
    #self.assertEqual(expected, v1.__le__(v2))
    raise NotImplementedError()


# Generated at 2022-06-22 22:32:03.826931
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease is None
    v = StrictVersion('1.2.3a4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 4)
    v = StrictVersion('1.2.3b4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 4)
    v = StrictVersion('1.2.3rc4')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('rc', 4)
    v = StrictVersion('1.2a2')
    assert v.version == (1, 2)

# Generated at 2022-06-22 22:32:06.380210
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    "Test Version.__repr__"
    assert repr(Version('1.2.3')) == "Version ('1.2.3')"

# Generated at 2022-06-22 22:32:09.278873
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert (not (v < '0.0.0'))

# Generated at 2022-06-22 22:32:17.189953
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:32:26.594852
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Returns a message that describes the differences between the
    # returned tuple and the expected tuple.  Returns empty string if
    # the tuples are equal.  Note: only used when the inputs are valid
    # version number strings.
    def msgdiff(input, rtuple, expected):
        if rtuple == expected:
            return ''
        msg = "'%s' parsed as %s" % (input, str(rtuple))
        msg = msg + " but expected %s" % str(expected)
        return msg

    lv = LooseVersion("1.1.1")
    assert lv.version == (1, 1, 1), \
        "major.minor.micro version parsed as %s" % str(lv.version)
    lv = LooseVersion("1.1")

# Generated at 2022-06-22 22:32:31.608027
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()

    # Test good version strings
    v.parse('1.2')
    v.parse('1.2.3')
    v.parse('1.2.3a4')
    v.parse('1.2.3b5')

    # Test invalid version strings
    try:
        v.parse('1.2.3rc4')
    except ValueError:
        pass
    else:
        raise AssertionError("'1.2.3rc4' should not be allowed as a version")



# Generated at 2022-06-22 22:32:32.840554
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__(): 
    pass 


# Generated at 2022-06-22 22:32:36.029608
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest

    # create a version that is greater
    version = Version("2")
    version2 = Version("1")
    # run the method and check the results
    assert version > version2