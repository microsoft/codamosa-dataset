

# Generated at 2022-06-22 22:22:40.393192
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    from distutils.tests import support

    L = [
        ('1.0', (1, 0, 0, None)),
        ('1.0.0', (1, 0, 0, None)),
        ('1.5.1', (1, 5, 1, None)),
        ('1.5.1b1', (1, 5, 1, ('b', 1))),
        ('1.5.1a2', (1, 5, 1, ('a', 2)))
        ]

    for vs, vt in L:
        c = StrictVersion(vs)
        support.compare(c.version, vt)
        support.compare(c.prerelease, vt[3])
        support.compare(str(c), vs)

    support.compare(c.version, (1, 5, 1))
   

# Generated at 2022-06-22 22:22:44.477008
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("1.4.99")
    assert v.version == (1,4,99)
    assert v.prerelease is None

    v = StrictVersion("1.4.99c3")
    assert v.version == (1,4,99)
    assert v.prerelease == ('c',3)


# Generated at 2022-06-22 22:22:48.891923
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert (v1 < v2) and not (v1 == v2)
    try:
        v1 > v2
        assert False
    except TypeError:
        pass



# Generated at 2022-06-22 22:22:50.764469
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Unit test for method Version.__ge__"""
    def SUT(self):
        return self

    return SUT


# Generated at 2022-06-22 22:22:52.697501
# Unit test for method __eq__ of class Version
def test_Version___eq__():
  assert getattr(Version, "__eq__")(Version(1), 1)



# Generated at 2022-06-22 22:22:57.372705
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    version._cmp = lambda x: NotImplemented
    assert not version.__le__(None)
    version._cmp = lambda x: 1
    assert version.__le__(None)
    version._cmp = lambda x: -1
    assert not version.__le__(None)
    version._cmp = lambda x: 0
    assert version.__le__(None)

# Generated at 2022-06-22 22:22:59.763153
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    s = StrictVersion()
    s.version = (1, 2, 3)
    s.prerelease = ('a', 1)

    assert str(s) == "1.2.3a1"


# Generated at 2022-06-22 22:23:10.419927
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version(None)
    v2 = Version(None)

    # equals
    assert v1._cmp(v2) == 0
    assert v1 <= v2
    assert v1 >= v2

    # v2 greater
    assert v1._cmp(v2) < 0
    assert v1 <= v2
    assert v1 < v2
    assert not v1 >= v2
    assert not v1 > v2

    # v1 greater
    assert v1._cmp(v2) > 0
    assert v1 >= v2
    assert v1 > v2
    assert not v1 <= v2
    assert not v1 < v2


# Generated at 2022-06-22 22:23:11.726683
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert  Version('1.1') > Version('1.0')

# Generated at 2022-06-22 22:23:18.811104
# Unit test for method __lt__ of class Version

# Generated at 2022-06-22 22:23:26.264857
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import types
    import unittest
    class Version___gt__(unittest.TestCase):
        def test(self):
            self.assertTrue(Version.__gt__(1,2) is NotImplemented)
    suite = unittest.TestSuite([
        unittest.defaultTestLoader.loadTestsFromTestCase(Version___gt__)])
    unittest.TextTestRunner().run(suite)
    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-22 22:23:37.763367
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('123').__str__() == '123', LooseVersion('123').__str__()
    assert LooseVersion('1.3').__str__() == '1.3', LooseVersion('1.3').__str__()
    assert LooseVersion('1.3.1').__str__() == '1.3.1', LooseVersion('1.3.1').__str__()
    assert LooseVersion('1.3.1.1').__str__() == '1.3.1.1', LooseVersion('1.3.1.1').__str__()
    assert LooseVersion('1.3.1.1a').__str__() == '1.3.1.1a', LooseVersion('1.3.1.1a').__str__()

# Generated at 2022-06-22 22:23:39.341958
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v = LooseVersion ('1.2a3')
    assert v.version == [1, '2a', 3]
    assert str(v) == '1.2a3'
    assert repr(v) == "LooseVersion ('1.2a3')"


# Generated at 2022-06-22 22:23:51.934198
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    s = StrictVersion("1.0")
    assert s == "1.0", "str() of StrictVersion yielded unexpected result"
    assert s >= "1.0a", "str() of StrictVersion yielded unexpected result"
    assert s > "0.9", "str() of StrictVersion yielded unexpected result"
    assert s < "1.1", "str() of StrictVersion yielded unexpected result"
    assert s <= "1.0rc1", "str() of StrictVersion yielded unexpected result"
    assert not (s >= "1.1"), "str() of StrictVersion yielded unexpected result"
    assert not (s > "2.0"), "str() of StrictVersion yielded unexpected result"
    assert not (s <= "0.9"), "str() of StrictVersion yielded unexpected result"

# Generated at 2022-06-22 22:23:56.768986
# Unit test for constructor of class Version
def test_Version():
    # Various tests for Version class using
    # LooseVersion.
    class TVersion(Version):
        def __init__(self, vstring=None):
            Version.__init__(self, vstring)
        def parse(self, vstring):
            pass
        def _cmp(self, other):
            return 0
    a = TVersion('1.2.3')
    assert str(a) == '1.2.3'
    assert repr(a) == "TVersion ('1.2.3')"
    assert a == '1.2.3'
    assert (a < '1.2.4') is False
    assert (a <= '1.2.4') is False
    assert (a > '1.2.4') is False
    assert (a >= '1.2.4') is False



# Generated at 2022-06-22 22:24:06.418099
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version
    from ansiblelint.staging import harness
    from ansiblelint.runner import Runner

    class Subclass(Version):
        pass

    for (expected, a, b) in (
            (True, Subclass('1.0'), '1.0'),
            (False, Subclass('1.0'), '2.0'),
            (NotImplemented, Subclass('1.0'), object()),
            (NotImplemented, Subclass('1.0'), None),
    ):
        with harness.run(Runner(['-p', 'lib/ansiblelint/rules']), '.') as r:
            assert (a == b) is expected
            assert (b == a) is expected
            assert r.logged_matches == 0


# Generated at 2022-06-22 22:24:10.465758
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import pytest
    from distutils.version import Version
    v1 = Version('1.2rc5')
    assert v1.__lt__('1.2') == True
    v2 = Version('1.3')
    assert v1.__lt__(v2) == True
    v3 = Version('1.2.2')
    assert v1.__lt__(v3) == True

# Generated at 2022-06-22 22:24:16.070511
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    class Mock(Version):
        def __init__(self, other):
            self._cmp_other = other
            Version.__init__(self)

        def _cmp(self, other):
            assert other == self._cmp_other
            return NotImplemented

    v = Mock(10)
    assert (v < 10) is NotImplemented
    assert (v <= 10) is NotImplemented
    assert (v > 10) is NotImplemented
    assert (v >= 10) is NotImplemented


# Generated at 2022-06-22 22:24:27.316909
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Two examples from Greg Ward's post
    assert LooseVersion("1.5.1") < LooseVersion("1.5.2b2")
    assert LooseVersion("161") < LooseVersion("3.10a")

    # Some other examples
    assert LooseVersion("8.02") < LooseVersion("3.4j")
    assert LooseVersion("3.4j") > LooseVersion("3.1.1.6")
    assert LooseVersion("2g6") < LooseVersion("11g")
    assert LooseVersion("0.960923") < LooseVersion("2.2beta29")
    assert LooseVersion("1.13++") < LooseVersion("5.5.kw")

# Generated at 2022-06-22 22:24:30.904090
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    """Test that the LooseVersion constructor works."""
    lv = LooseVersion('1.2.2b2')
    assert lv.version == ['1', '2', '2', 'b', '2'], 'error in LooseVersion constructor'

# end class LooseVersion

# Generated at 2022-06-22 22:24:33.092354
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    sv = StrictVersion('1.3.6')
    assert sv.version == (1, 3, 6)
    assert sv.prerelease == None



# Generated at 2022-06-22 22:24:39.098685
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    class TestVersion___gt__(unittest.TestCase):
        def test_simple(self):
            v1 = Version('1.2.3')
            v2 = Version('1.2.3')
            self.assertFalse(v1.__gt__(v2))

        def test_custom(self):
            class TestVersion(Version):
                pass

            v1 = TestVersion('1.2.3')
            v2 = TestVersion('1.2.3')
            self.assertFalse(v1.__gt__(v2))

    if __name__ == '__main__':
        unittest.main()



# Generated at 2022-06-22 22:24:39.966216
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    pass


# Generated at 2022-06-22 22:24:45.319722
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import types

    class DummyType(type):
        def _cmp(self, other):
            if other == self:
                return 0
            return -1

    class Dummy:
        __metaclass__ = DummyType

        def __init__(self):
            self.__class__._cmp = types.MethodType(lambda self, other: 0, self.__class__)

    dummy = Dummy()

    dummy == dummy
    dummy >= dummy
    dummy <= dummy
    dummy != dummy

    dummy < dummy
    dummy > dummy

# Generated at 2022-06-22 22:24:47.490209
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('1.0') == LooseVersion()


# Generated at 2022-06-22 22:24:56.647976
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    a = LooseVersion('1.0.4.4.4.4.4')
    b = LooseVersion('1.0.4.4.4.4.4.4')
    c = LooseVersion('1.0.4.4.4.4.4')
    assert a == c, 'Bad comparison'
    assert a < b, 'Bad comparison'
    assert a != b, 'Bad comparison'
    assert a < '1.0.4.4.4.4.4.4', 'Bad comparison'
    assert a != '1.0.4.4.4.4.4.4', 'Bad comparison'
    assert '1.0.4.4.4.4.4.4' > a, 'Bad comparison'
    assert '1.0.4.4.4.4.4.4'

# Generated at 2022-06-22 22:25:03.267602
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion('1.0a1')
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion('1.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease == None

    v = StrictVersion('1.0.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease == None

    try:
        v = StrictVersion('1.0f')
    except ValueError:
        pass
    else:
        raise AssertionError("didn't raise ValueError")

    try:
        v = StrictVersion('1.0.a')
    except ValueError:
        pass

# Generated at 2022-06-22 22:25:06.074678
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.2.3')
    assert lv.__str__() == lv.vstring, '__str__'


# Generated at 2022-06-22 22:25:17.398254
# Unit test for method __le__ of class Version
def test_Version___le__():
    # simple test
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    assert v1 <= v2
    # check boundaries (exact)
    v3 = Version('1.1.1')
    v4 = Version('1.2.3')
    assert v3 <= v4
    v5 = Version('1.2.2')
    v6 = Version('1.2.3')
    assert v5 <= v6
    v7 = Version('1.2.2')
    v8 = Version('1.2.3.4')
    assert v7 <= v8
    # check boundaries (inexact)
    v9 = Version('1.999999.1')
    v10 = Version('2.0.0')
    assert v9 <= v10
    v

# Generated at 2022-06-22 22:25:26.411526
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def compare(vstring1, vstring2):
        "Helper function to run a test and prints results"
        version1 = StrictVersion(vstring1)
        version2 = StrictVersion(vstring2)
        assert version1.__str__() == vstring1
        assert version2.__str__() == vstring2
        return version1._cmp(version2)

    assert compare("1.5.1", "3.4.2") == -1
    assert compare("161.5.1", "3.4.2") == 1
    assert compare("3.4.2", "161.5.1") == -1
    assert compare("3.4.2", "3.4.2") == 0
    assert compare("3.4.2", "3.4.2.1") == -1
    assert compare

# Generated at 2022-06-22 22:25:28.129400
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    c = get_version()
    c = c._cmp((c+0.1))
    print('ok')

# Generated at 2022-06-22 22:25:34.696154
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    version = StrictVersion
    v = version('1.0')
    assert v.version == (1,0,0) and v.prerelease is None, \
        'version 1.0'
    v = version('1.0.0')
    assert v.version == (1,0,0) and v.prerelease is None, \
        'version 1.0.0'
    v = version('1.0a1')
    assert v.version == (1,0,0) and v.prerelease == ('a',1), \
        'version 1.0a1'
    v = version('1.0.0a1')
    assert v.version == (1,0,0) and v.prerelease == ('a',1), \
        'version 1.0.0a1'

# Generated at 2022-06-22 22:25:43.891355
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    class DummyVersion(Version):
        def __init__(self, n):
            self.n = n

        def parse(self, vstring):
            raise NotImplementedError

        def __str__(self):
            raise NotImplementedError

        def _cmp(self, other):
            return self.n - other.n

    general = [
        # Comparisons between two different classes
        (Version, {'vstring': '1'}, [
            (DummyVersion(1), False),
            (DummyVersion(2), NotImplemented),
        ]),
        (DummyVersion, {'n': 1}, [
            (Version('1'), NotImplemented),
            (DummyVersion(1), False),
            (DummyVersion(2), NotImplemented),
        ]),
    ]
   

# Generated at 2022-06-22 22:25:47.876010
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version

    v1 = Version('1.4.1')
    v2 = Version('1.4')

    try:
        v1 < v2
    except Exception:
        raise AssertionError('Failed to create safe comparison operators')



# Generated at 2022-06-22 22:25:56.504576
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    class Version___lt__Tester(unittest.TestCase):
        def test_Version___lt__(self):
            # Make sure that exceptions raised in the remainder of this
            # function are not mistaken as expected exceptions
            self.failureException = AssertionError
            # Insert your test code below
            # ...
            # Test for method Version.__lt__( ... )
            # Test for subclass of Version
            class Test(Version):

                def parse(self, vstring): self.vstring = vstring
                def __eq__(self, other):
                    return self.vstring == other or \
                        self.vstring == 'xxx' and other == 'yyy' or \
                        self.vstring == 'foo' and other == 'bar'
                def __lt__(self, other):
                    return self

# Generated at 2022-06-22 22:26:05.892658
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    strict = StrictVersion

    assert strict('1.0') == strict('1.0')
    assert strict('1.0') < strict('1.1')
    assert strict('1.0') < strict('1.0.1')
    assert strict('1.1') > strict('1.0.1')

    assert strict('1.0') < strict('1.0a1')
    assert strict('1.0a1') < strict('1.0b1')

    assert not strict('1.0a1') < strict('1.0a')
    assert strict('1.0a1') < strict('1.0a2')

    assert strict('1.0a1') > strict('1.0a')

    assert not strict('1.0') < strict('1.0')

# Generated at 2022-06-22 22:26:08.080813
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Just compare a Version.
    v1 = Version('1')
    v2 = Version('1')
    assert v1 <= v2

# Generated at 2022-06-22 22:26:18.295232
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse("1.4.1")
    assert v.version == (1,4,1)
    assert v.prerelease == None
    v.parse("1.4.1a1")
    assert v.version == (1,4,1)
    assert v.prerelease == ('a', 1)
    v.parse("1.4.1b3")
    assert v.version == (1,4,1)
    assert v.prerelease == ('b', 3)
    v.parse("1.4.1.1")
    assert v.version == (1,4,1,1)
    assert v.prerelease == None


# Generated at 2022-06-22 22:26:24.087119
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('0.4')
    assert v.version == (0, 4, 0)
    assert v.prerelease is None
    v.parse('0.4.1')
    assert v.version == (0, 4, 1)
    assert v.prerelease is None
    v.parse('0.5a1')
    assert v.version == (0, 5, 0)
    assert v.prerelease == ('a', 1)
    v.parse('0.5b3')
    assert v.version == (0, 5, 0)
    assert v.prerelease == ('b', 3)
    v.parse('0.5')
    assert v.version == (0, 5, 0)
    assert v.prerelease is None
    v.parse('0.9.6')


# Generated at 2022-06-22 22:26:25.820829
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    obj = Version()
    assert obj == obj.__class__

# Generated at 2022-06-22 22:26:35.466712
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():

    assertLooseVersion('4.4.4', LooseVersion('4.4.4'))
    assertLooseVersion('4.4.4', LooseVersion('4.4.4a'))
    assertLooseVersion('4.4.4', LooseVersion('4.4.4-a'))
    assertLooseVersion('4.4.4', LooseVersion('4.4.4b'))
    assertLooseVersion('4.4.4', LooseVersion('4.4.4-b'))
    assertLooseVersion('4.4.4', LooseVersion('4.4.4pl'))
    assertLooseVersion('4.4.4', LooseVersion('4.4.4-pl'))

# Generated at 2022-06-22 22:26:43.662380
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # check what happens when trailing non-alphanumeric characters are present
    assert(LooseVersion("1.2.1+") == LooseVersion("1.2.1"))

    lv_strs = ['1.2.1', '1.2.1+', '1.2.1.3', '1.2.1.3+', '1.2.1b5',
               '1.2.1b5+', '1.2.1c5', '1.2.1c5+', '1.2.1rc5', '1.2.1rc5+',
               '1.2.1.rc5', '1.2.1.rc5+']


# Generated at 2022-06-22 22:26:45.390361
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= '000000.000000'


# Generated at 2022-06-22 22:26:49.723694
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    print('Test for method __ge__ of class Version (' + str((Version(), Version(''))) + ')')

    version = Version()
    version2 = Version('')
    if version >= version2 != True:
        raise AssertionError('version >= version2 != True')



# Generated at 2022-06-22 22:26:55.901275
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.2.3').__lt__(Version('1.2.4'))
    assert not Version('1.2.4').__lt__(Version('1.2.4'))
    assert not Version('1.2.4').__lt__(Version('1.2.3'))
    assert Version('1.2.3').__lt__('1.2.4')
    assert not Version('1.2.4').__lt__('1.2.4')
    assert not Version('1.2.4').__lt__('1.2.3')

# Generated at 2022-06-22 22:27:06.542220
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:27:15.575921
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def check(vstring, exp_version, exp_prerelease):
        ver = StrictVersion()
        ver.parse(vstring)
        assert ver.version == exp_version, \
               ("test case %s: %s != %s" % (vstring, ver.version, exp_version))
        assert ver.prerelease == exp_prerelease, \
               ("test case %s: %s != %s" % (vstring, ver.prerelease,
                                            exp_prerelease))
    check('1.0', (1,0,0), None)
    check('1.1.0', (1,1,0), None)
    check('1.1.a', (1,1,0), 'a')
    check('1.1.a0', (1,1,0), 'a0')
   

# Generated at 2022-06-22 22:27:17.674197
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    from vensim.version import LooseVersion
    v = LooseVersion('1.5')
    assert repr(v) == "LooseVersion ('1.5')"


__all__.extend(['LooseVersion', 'test_LooseVersion___repr__'])


# Generated at 2022-06-22 22:27:23.179744
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert (Version('1.2.3') < Version('2.3.4')) is True
    assert (Version('1.2.3') < Version('1.2.3')) is False
    assert (Version('1.2.3') < Version('0.2.3')) is False


# Generated at 2022-06-22 22:27:33.879137
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    # Set up context. Declare variables and load resources.
    v1 = '1.0a1'
    v2 = '1.0a2'
    v3 = '1.0a3'
    v4 = '1.0'
    v5 = '1.0b'
    v6 = '1.0c'
    v7 = '1.0rc1'
    v8 = '1.0'
    v9 = '1.0post'
    v10 = '1.0.post1'
    v11 = '1.0.post1.dev2'
    v12 = '2.0'

    # Exercise SUT.
    assert Version(v1) >= Version(v1)
    assert Version(v2) >= Version(v1)

# Generated at 2022-06-22 22:27:41.988548
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # https://github.com/pypa/pip/commit/24f2523e4f864a4a2595d36b9e958c73aede2d57
    # https://github.com/pypa/pip/commit/afc8a9a6fe3c3bb2b2a8b8f7e20803c6a1854fcf
    # https://github.com/pypa/pip/pull/4073
    assert StrictVersion('0.4').version == (0, 4, 0)
    assert StrictVersion('0.4.0').version == (0, 4, 0)
    assert StrictVersion('0.4.0').prerelease is None
    assert StrictVersion('0.4a1').version == (0, 4, 0)
    assert Strict

# Generated at 2022-06-22 22:27:51.304871
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def check(vstring):
        v = LooseVersion(vstring)
        assert(str(v) == vstring)

    check('1.5.1')
    check('1.5.2b2')
    check('161')
    check('3.10a')
    check('8.02')
    check('3.4j')
    check('1996.07.12')
    check('3.2.pl0')
    check('3.1.1.6')
    check('2g6')
    check('11g')
    check('0.960923')
    check('2.2beta29')
    check('1.13++')
    check('5.5.kw')
    check('2.0b1pl0')

# Generated at 2022-06-22 22:27:58.866415
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    StrictVersion('1.2.3')
    StrictVersion('1.2')
    StrictVersion('1')
    StrictVersion('1.2.3a4')
    StrictVersion('1.2.3b4')
    StrictVersion('1.2.3b4.2')  # Wrongly parsed
    try:
        StrictVersion('1.2.3a4.2')
    except ValueError:
        pass
    else:
        raise AssertionError("never get here")



# Generated at 2022-06-22 22:28:00.674343
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert (v1 < v2) == False


# Generated at 2022-06-22 22:28:12.986261
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('27')
    assert not (v >= v)

try:
    from functools import total_ordering
except ImportError:
    # Python < 2.7
    def total_ordering(cls):
        """Class decorator that fills in missing ordering methods"""
        converts = [('__lt__', [('__gt__', lambda self, other: not (self < other or self == other))]),
                    ('__le__', [('__ge__', lambda self, other: not self > other)]),
                    ('__gt__', [('__lt__', lambda self, other: not (self > other or self == other))]),
                    ('__ge__', [('__le__', lambda self, other: not self < other)])]

# Generated at 2022-06-22 22:28:18.789018
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v1 = StrictVersion('1.2a3')
    assert str(v1) == '1.2a3'
    v2 = StrictVersion('1.0.1.2b3')
    assert str(v2) == '1.0.1.2b3'

# Generated at 2022-06-22 22:28:20.729356
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= Version()
    assert Version() >= Version()
    assert Version() == Version()



# Generated at 2022-06-22 22:28:22.955077
# Unit test for constructor of class Version
def test_Version():
    'Test Version constructor'
    x = Version()
    assert str(x) == '', 'empty string for uninitialized Version'



# Generated at 2022-06-22 22:28:25.416421
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v2 = Version()
    ans = v == v2
    assert (isinstance(ans, bool) and not ans)

# Generated at 2022-06-22 22:28:31.045609
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    print("Test Version.__eq__()")
    v = Version("1.0")
    assert "1.0" == str(v)
    assert v == "1.0"
    assert v == Version("1.0")
    assert v == v
    assert not v == "1.0.1"
    assert not v == Version("1.0.1")
    assert not v == v.__dict__
    try:
        v == []
    except TypeError:
        pass
    else:
        assert False, "Version.__eq__() failed to raise TypeError"


# Generated at 2022-06-22 22:28:41.756935
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():

    version = StrictVersion( '0.4' )
    assert str( version ) == '0.4', repr( str( version ) )
    assert repr( version ) == "StrictVersion ('0.4')", repr( repr( version ) )
    version = StrictVersion( '0.4.0' )
    assert str( version ) == '0.4.0', repr( str( version ) )
    assert repr( version ) == "StrictVersion ('0.4.0')", repr( repr( version ) )
    version = StrictVersion( '0.4.1' )
    assert str( version ) == '0.4.1', repr( str( version ) )
    assert repr( version ) == "StrictVersion ('0.4.1')", repr( repr( version ) )

# Generated at 2022-06-22 22:28:43.428640
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(1) == NotImplemented



# Generated at 2022-06-22 22:28:54.739785
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:29:01.549455
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    __tracebackhide__ = True
    from distutils.version import Version
    version = Version('1.2.99999')
    assert version.__eq__('1.3a1') is False
    assert version.__eq__('1.2.99999') is True
    assert version.__eq__(1) is NotImplemented


# Generated at 2022-06-22 22:29:02.480621
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    pass


# Generated at 2022-06-22 22:29:03.728203
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= Version('0')



# Generated at 2022-06-22 22:29:15.087570
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("1.0.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion("1.0.0a1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion("1.0.0b1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('b', 1)

    v = StrictVersion("1.0.0c1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('c', 1)

    v = StrictVersion("1.0.0.0")
    assert v.version == (1, 0, 0)
    assert v

# Generated at 2022-06-22 22:29:17.986131
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    sampleVersion = Version("1.0")
    assert sampleVersion.__repr__() == "Version ('1.0')"

# Generated at 2022-06-22 22:29:19.848354
# Unit test for method __gt__ of class Version
def test_Version___gt__():
  v = Version("1.0")
  assert v > 0 == False
test_Version___gt__()


# Generated at 2022-06-22 22:29:21.328456
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('123.22')
    assert(str(v) == v.vstring)


# Generated at 2022-06-22 22:29:30.561928
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:29:35.566095
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    cls = Version
    cls_name = "Version"
    arg0 = ""
    arg1 = ""
    arg2 = ""
    arg3 = ""
    arg4 = ""
    arg5 = ""
    arg6 = ""
    arg7 = ""
    res = cls(arg0).__lt__(arg1)
    assert res

    res = cls(arg2).__lt__(arg3)
    assert res

    res = cls(arg4).__lt__(arg5)
    assert res

    res = cls(arg6).__lt__(arg7)
    assert res

# Generated at 2022-06-22 22:29:38.186016
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        assert Version() > 0
    except TypeError:
        pass
    else:
        raise Exception()

# Generated at 2022-06-22 22:29:47.704326
# Unit test for method __repr__ of class LooseVersion

# Generated at 2022-06-22 22:29:48.723718
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(object()) is NotImplemented


# Generated at 2022-06-22 22:29:51.505442
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version

    v = Version("0.2a")
    assert(not v < "0.1")
    assert(not v < "0.2")
    assert(not v < "0.2a")

# Generated at 2022-06-22 22:30:03.601592
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    """Test the StrictVersion.parse method"""
    v = StrictVersion()

    # Should parse normal version numbers, with two or three parts
    assert v.parse('0.4') == ('0', '4')
    assert v.parse('0.4.0') == ('0', '4', '0')

    # A trailing 'pre-release' suffix is handled
    assert v.parse('0.4a1') == ('0', '4', 'a1')
    assert v.parse('0.4.0b3') == ('0', '4', '0', 'b3')
    assert v.parse('0.4c4') == ('0', '4', 'c4')

    # And some invalid version numbers
    try:
        v.parse('1')
        assert False
    except ValueError:
        pass
   

# Generated at 2022-06-22 22:30:05.430580
# Unit test for method __le__ of class Version
def test_Version___le__():
    expected = True
    actual = Version() <= Version()
    assert expected == actual, '%r != %r' % (expected, actual)


# Generated at 2022-06-22 22:30:07.461519
# Unit test for method __le__ of class Version
def test_Version___le__():
    ver = Version('1')
    print(ver)
    print(ver <= '1')


# Generated at 2022-06-22 22:30:10.395767
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    with pytest.raises(NotImplementedError):
        version.Version().__ge__("")



# Generated at 2022-06-22 22:30:12.625304
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("1.2.3") <= Version("1.2.4")


# Generated at 2022-06-22 22:30:15.481276
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    w = Version()

    assert v <= w
    assert v >= w
    assert v <= '1.0'
    assert v >= '1.0'

# Generated at 2022-06-22 22:30:22.398720
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('3.46.0-rc.1')
    assert not v < '3.46.0'
    assert not v < '3.46.0-rc.1'
    assert v < '3.46.0-rc.2'
    assert v <= '3.46.0-rc.2'
    assert v <= '3.46.0-rc.1'
    assert not v <= '3.46.0-rc.0'


# Generated at 2022-06-22 22:30:26.757940
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert eval(repr(Version())) == Version(), "eval(repr(Version())) == Version()"
    # test with string argument
    assert eval(repr(Version("1.0"))) == Version("1.0"), "eval(repr(Version('1.0'))) == Version('1.0')"


# Generated at 2022-06-22 22:30:34.651396
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    class Version_TestCase(unittest.TestCase):
        def test__Version___eq__(self):
            # __eq__
            v1 = Version(1)
            v2 = Version(2)
            self.assertEqual(v1, v1)
            self.assertNotEqual(v1, v2)
            self.assertNotEqual(v1, 1)
            with self.assertRaises(TypeError):
                v1 == object()
    return Version_TestCase


# Generated at 2022-06-22 22:30:41.609835
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    result=LooseVersion('1.5.2b2')
    if not result == '1.5.2b2':
        print('LooseVersion(1.5.2b2)->__str__ did not return "1.5.2b2"\n')
        print(result)


# Generated at 2022-06-22 22:30:43.885519
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert not v >= '1.2.4'



# Generated at 2022-06-22 22:30:47.070589
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    return 0

# Generated at 2022-06-22 22:30:48.460915
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    instance = Version()
    assert instance == {}



# Generated at 2022-06-22 22:30:56.524573
# Unit test for constructor of class Version
def test_Version():
    assert Version()
    assert Version("1.2")
    assert repr(Version()) == "Version ('')"
    assert repr(Version("1.2")) == "Version ('1.2')"

    try:
        Version().parse("1.2")
    except AttributeError:
        pass
    else:
        raise AssertionError("shouldn't get here")


# Regex for non-digit stuff
_NONDIGIT_RE = re.compile(r'[^\d]+', RE_FLAGS)
# Regex for non-digit stuff up to the next digit
_NONDIGIT_NEXT_DIGIT_RE = re.compile(r'\D+', RE_FLAGS)


# Generated at 2022-06-22 22:31:06.263668
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    with patch("sys.version_info", (1,) * 5) as sys:
        v = StrictVersion("1.2.3")
        p = patch("distutils.version.StrictVersion.__str__",
                  return_value="foo")
        with p as mock:
            assert v.__str__() == "foo"
            assert mock.called
        p = patch("distutils.version.StrictVersion.__str__",
                  return_value="foo")
        with p as mock:
            assert str(v) == "foo"
            assert mock.called



# Generated at 2022-06-22 22:31:07.732138
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import doctest
    doctest.testmod()


# Generated at 2022-06-22 22:31:19.229708
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v1 = StrictVersion("1.0")
    assert v1 == ("1.0")
    assert str(v1) == "1.0"
    v2 = StrictVersion("1.0.0")
    assert v2 == ("1.0.0")
    assert str(v2) == "1.0.0"


# Interface for version-number classes -- must be implemented
# by the following classes (the concrete ones -- Version should
# be treated as an abstract class).
#    __init__ (string) - create and take same action as 'parse'
#                        (string parameter is optional)
#    parse (string)    - convert a string representation to whatever
#                        internal representation is appropriate for
#                        this style of version numbering
#    __str__ (self)    - convert back to a string; should be very similar
#                       

# Generated at 2022-06-22 22:31:22.574657
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion ()
    v.parse("1.23.45")
    v.__str__()
    ###assertEquals(v.__str__(), "1.23.45", "LooseVersion: __str__ returned a wrong value")


# Generated at 2022-06-22 22:31:29.290988
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # test pre-alpha formatting
    assert LooseVersion("0a1").parse("0.a1") == ("0.a1", ['0', 'a1'])
    assert LooseVersion("1.1.dev34").parse("1.1.dev34") == ("1.1.dev34", ['1', '1', 'dev34'])
    assert LooseVersion("1.1a2").parse("1.1a2") == ("1.1a2", ['1', '1a2'])
    assert LooseVersion("1.1.a").parse("1.1.a") == ("1.1.a", ['1', '1', 'a'])

    # test alpha formatting

# Generated at 2022-06-22 22:31:31.268007
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('None')"


# Generated at 2022-06-22 22:31:40.622736
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils2.version import StrictVersion
    from distutils2.version import LooseVersion
    from distutils2.version import Version

    class MyVersion(Version):
        pass

    v1 = MyVersion('1.0')
    v2 = MyVersion('2.0')

    assert v1 <= v1
    assert v1 <= v2
    assert not v2 <= v1

    assert not v1 > v2
    assert v2 > v1



# Generated at 2022-06-22 22:31:51.116565
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()

    for s in ['0.4.0', '0.4', '0.4.1.2', '1.0.4b2', '1.0.4b2.post1']:
        v.parse(s)
        print('parse: {} -> {}'.format(s, str(v)))
        assert str(v) == s

    try:
        v.parse('1')
        assert False
    except ValueError as e:
        print(e)

    try:
        v.parse('1.1.b1')
        assert False
    except ValueError as e:
        print(e)

    try:
        v.parse('1.2.3a2.post1')
        assert False
    except ValueError as e:
        print(e)


# Generated at 2022-06-22 22:31:53.378358
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("0.0.0") <= Version("1.1.1")


# Generated at 2022-06-22 22:31:54.437654
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    return None

# Generated at 2022-06-22 22:31:56.754209
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert v.__repr__() == "Version ('0')"



# Generated at 2022-06-22 22:31:58.983150
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert v.__repr__() == "Version ('None')"


# Generated at 2022-06-22 22:32:08.385892
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """
    The method __str__ of class LooseVersion returns the vstring
    which should be equal to the string version of version.
    """
    l = LooseVersion("0.4.1")
    assert str(l) == l.vstring == "0.4.1"
    l = LooseVersion("0.4")
    assert str(l) == l.vstring == "0.4"
    l = LooseVersion("0.4a2")
    assert str(l) == l.vstring == "0.4a2"
    l = LooseVersion("0.4b1")
    assert str(l) == l.vstring == "0.4b1"
    l = LooseVersion("0.5a1")

# Generated at 2022-06-22 22:32:12.036951
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v1 = LooseVersion('1.11')
    v2 = LooseVersion('1.2')

    assert repr(v1) == "LooseVersion ('1.11')"
    assert repr(v2) == "LooseVersion ('1.2')"



# Generated at 2022-06-22 22:32:21.937341
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    res = StrictVersion('0.4.1a1')
    assert str(res) == '0.4.1a1'
    res = StrictVersion('0.4.1a1')
    assert str(res) == '0.4.1a1'
    res = StrictVersion('0.4.1')
    assert str(res) == '0.4.1'
    res = StrictVersion('0.1')
    assert str(res) == '0.1'
    res = StrictVersion('1.2')
    assert str(res) == '1.2'


# Generated at 2022-06-22 22:32:30.627393
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # test an invalid version string
    try:
        StrictVersion('1.3.a4')
    except ValueError:
        pass
    else:
        print('StrictVersion.parse() failed to detect invalid version string')

    # test the expected version strings
    for vstring in ('0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3',
                    '0.5', '0.9.6', '1.0', '1.0.4a3', '1.0.4b1', '1.0.4'):
        if str(StrictVersion(vstring)) != vstring:
            print('StrictVersion.parse() failed to parse "%s"' % vstring)



# Generated at 2022-06-22 22:32:32.551810
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert( isinstance(v, Version) )
    assert( v >= 0 )

