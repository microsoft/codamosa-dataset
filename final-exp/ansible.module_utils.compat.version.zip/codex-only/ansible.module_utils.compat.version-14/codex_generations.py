

# Generated at 2022-06-22 22:22:35.171159
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.2.1')
    assert v.__str__() == '1.2.1'
    v = LooseVersion()
    assert v.__str__() is None
   

# Generated at 2022-06-22 22:22:45.469035
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert str(StrictVersion()) == '0.0'
    assert StrictVersion('1').version == (1, 0, 0)
    assert StrictVersion('1.2').version == (1, 2, 0)
    assert StrictVersion('1.2.3').version == (1, 2, 3)
    assert str(StrictVersion('')) == '0.0'
    assert str(StrictVersion('0.4.0')) == '0.4'
    assert str(StrictVersion('1.0')) == '1.0'
    assert str(StrictVersion('1.5.1')) == '1.5.1'
    assert str(StrictVersion('1.5.0')) == '1.5'

# Generated at 2022-06-22 22:22:50.338677
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Run tests for method __le__ of class Version
    import unittest
    import types

    class Test__le__(unittest.TestCase):
        def test_eq(self):
            v1 = Version(None)
            v2 = Version(None)
            self.assertTrue(v1 <= v2, 'v1 <= v2 should be True')
            self.assertTrue(v2 <= v1, 'v2 <= v1 should be True')

        def test_lt(self):
            v1 = Version(None)
            v2 = Version(None)
            v2.parse('2')
            self.assertTrue(v1 <= v2, 'v1 <= v2 should be True')
            self.assertFalse(v2 <= v1, 'v2 <= v1 should be False')


# Generated at 2022-06-22 22:22:59.302149
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    class TestStrictVersion___str__(StrictVersion):
        def _cmp(self, other):
            return 0

    test_cases = [
        # test_cases: (version, expected)
        ((0, 0, 0, ('a', 1)), '0.0a1'),
        ((1, 0, 0, ('a', 1)), '1.0a1'),
        ((1, 2, 0, ('a', 1)), '1.2a1'),
        ((1, 2, 3, ('a', 1)), '1.2.3a1'),
        ((0, 0, 0), '0.0'),
        ((1, 0, 0), '1.0'),
        ((1, 2, 0), '1.2'),
        ((1, 2, 3), '1.2.3'),
    ]


# Generated at 2022-06-22 22:23:11.422666
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Create an instance of Version
    version = Version()

    # Call method __gt__ with a known value
    result = version.__gt__('over 9000')
    assert result == NotImplemented

    # Call method __gt__ with a known value
    result = version.__gt__('0.0')
    assert result == NotImplemented

    # Call method __gt__ with a known value
    result = version.__gt__('1.0')
    assert result == NotImplemented

    # Call method __gt__ with a known value
    result = version.__gt__('2.0')
    assert result == NotImplemented

    # Call method __gt__ with a known value
    result = version.__gt__('3.0')
    assert result == NotImplemented

    # Call method __gt__ with a known value

# Generated at 2022-06-22 22:23:12.366692
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert True

# Generated at 2022-06-22 22:23:17.869225
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """
    Unit test for method __repr__ of class LooseVersion
    """
    import sys
    import os
    import getopt
    import time

    def usage():
        print("usage: python test_LooseVersion___repr__.py")

    try:
        opts, args = getopt.getopt(sys.argv[1:], 'h', ['help'])
    except:
        usage()
    for opt, arg in opts:
        if opt in ('-h', '--help'):
            usage()
        else:
            print("unhandled option " + opt)

    if args:
        print("unhandled argument " + str(args))

    # Initialize variables
    test_class = LooseVersion
    test_method = '__repr__'

# Generated at 2022-06-22 22:23:19.556268
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # print "This is a test of method __str__ of class LooseVersion"
    assert LooseVersion("1.5.2b2") == "1.5.2b2"


# Generated at 2022-06-22 22:23:22.417893
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """
    >>> repr(LooseVersion('2.2.0'))
    'LooseVersion (\'2.2.0\')'
    """


# Generated at 2022-06-22 22:23:23.619081
# Unit test for constructor of class Version
def test_Version():
    v = Version("1.2")



# Generated at 2022-06-22 22:23:26.716589
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v._cmp = lambda x: None
    try:
        v.__le__(1)
    except NotImplementedError:
        pass
    except:
        fail("expecting NotImplementedError")

# Generated at 2022-06-22 22:23:38.134409
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    print("test_LooseVersion_parse...")
    
    assert(str(LooseVersion("1.1")) == "1.1")
    assert(str(LooseVersion("1.1.1")) == "1.1.1")
    assert(str(LooseVersion("1.1.1a")) == "1.1.1a")
    assert(str(LooseVersion("1.1.1aa")) == "1.1.1aa")
    assert(str(LooseVersion("1.1.1b")) == "1.1.1b")
    assert(str(LooseVersion("1.1.1bb")) == "1.1.1bb")
    #assert(str(LooseVersion("1.1.1ab")) == "1.1.1ab")     # fail
    #assert(str(

# Generated at 2022-06-22 22:23:41.604521
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion()
    vstring = '1.13++'
    v.parse(vstring)
    assert v.__str__() == vstring
test_LooseVersion___str__()

# Generated at 2022-06-22 22:23:47.256757
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:23:49.046926
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    # __ge__ of class Version

    pass



# Generated at 2022-06-22 22:23:51.805953
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """

    """
    # The method is expected to return a String
    assert isinstance(LooseVersion().__repr__(), str)


# Generated at 2022-06-22 22:23:54.628319
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import StrictVersion
    v = StrictVersion("1.0")
    assert v == StrictVersion("1.0")
    assert not (v == 1.0)



# Generated at 2022-06-22 22:24:05.421463
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert str(LooseVersion("1.2.3")) == "1.2.3"
    assert str(LooseVersion("1.2.0")) == "1.2"
    assert str(LooseVersion("1.02")) == "1.02"
    assert str(LooseVersion("1.2.3.4")) == "1.2.3.4"
    assert str(LooseVersion("1.0001")) == "1.0001"
    assert str(LooseVersion("1.2.03")) == "1.2.03"
    assert str(LooseVersion("1.2a3")) == "1.2a3"
    assert str(LooseVersion("1.2b3")) == "1.2b3"

# Generated at 2022-06-22 22:24:07.269490
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    f = Version()
    f.__repr__() == "%s ('%s')"
    return True

# Generated at 2022-06-22 22:24:10.300591
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion("1.2.3")) == "1.2.3"


# Generated at 2022-06-22 22:24:12.255509
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version

    v = Version('1.0')
    assert (v < '1.1') == True

# Generated at 2022-06-22 22:24:24.397372
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def check(vstring, pvs):
        vs = StrictVersion(vstring)
        if pvs:
            assert vs.version == pvs[0]
        else:
            assert vs.version == (0,)
        if len(pvs) > 1:
            assert vs.prerelease == pvs[1]
        else:
            assert vs.prerelease is None
        assert str(vs) == vstring

    check('1.0', ((1, 0, 0), None))
    check('1.0.0', ((1, 0, 0), None))
    check('1.0a1', ((1, 0, 0), ('a', 1)))
    check('1.0.0a1', ((1, 0, 0), ('a', 1)))

# Generated at 2022-06-22 22:24:26.692796
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= 'foo'
    assert Version('1.2') <= '1.2'


# Generated at 2022-06-22 22:24:35.351445
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:24:45.577424
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    from distutils.tests import support
    support.run_unittest(VersionTestCase)
    # verify reference counting
    import sys
    if hasattr(sys, "gettotalrefcount"):
        import gc
        counts = [None] * 5
        for i in range(len(counts)):
            test = VersionTestCase('test_case')
            test.setUp()
            test.test_cmp_complex()
            counts[i] = sys.gettotalrefcount()
            test.tearDown()
            del test
            gc.collect()

# Generated at 2022-06-22 22:24:55.142191
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion('1.2.3') == StrictVersion('1.2.3')
    assert StrictVersion('1.2.3') < StrictVersion('1.2.3a1')
    assert StrictVersion('1.2.3') > StrictVersion('1.2.3a0')
    assert StrictVersion('1.2.3') > StrictVersion('1.2.3rc1')
    assert StrictVersion('1.2.3') > StrictVersion('1.2.3b2')
    assert StrictVersion('1.2.3') > StrictVersion('1.2.3.1')
    assert StrictVersion('1.2.3') == StrictVersion('1.2.3.0')

# Generated at 2022-06-22 22:24:58.984750
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    val = Version('1.0.0')
    c = val._cmp(val)
    assert c == 0
    a = val._cmp(Version('0.9.9'))
    assert a > 0
    b = val._cmp(Version('1.0.1'))
    assert b < 0


# Generated at 2022-06-22 22:25:09.394357
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()

    # test_Version___lt__::test_None:
    v2 = None
    try:
        v < v2
        return False
    except TypeError:
        pass

    # test_Version___lt__::test_not_a_version:
    v2 = 'foobar'
    try:
        v < v2
        return False
    except TypeError:
        pass

    # test_Version___lt__::test_something_higher:
    v = Version(vstring='1.0')
    v2 = Version(vstring='1.1')
    return (v < v2) and not (v2 < v)

    # test_Version___lt__::test_equal_versions:
    v = Version(vstring='1.0')

# Generated at 2022-06-22 22:25:15.650547
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3rc1')
    assert str(v) == '1.2.3rc1'
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('rc', 1)
    v.parse('1.2.0')
    assert v.version == (1, 2, 0)
    assert v.prerelease == None


# Generated at 2022-06-22 22:25:18.485964
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from copy import deepcopy
    x = Version('1.0')
    y = Version('')
    y = deepcopy(x)
    assert x.__ge__(y)

# Generated at 2022-06-22 22:25:21.144377
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse("1.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease is None


# Generated at 2022-06-22 22:25:23.317132
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    v.parse('1.0.0')
    assert v > '0.9'
    assert v > Version('0.9')



# Generated at 2022-06-22 22:25:31.090343
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():

    def check(v, r):
        rr = LooseVersion(v).__repr__()

# Generated at 2022-06-22 22:25:32.415825
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert v._cmp(v) == 0



# Generated at 2022-06-22 22:25:36.554059
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """Method _str_"""
    a = LooseVersion("2.2.2")
    assert a.__str__() == "2.2.2"


# Generated at 2022-06-22 22:25:48.922257
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    assert LooseVersion('1.2').version == [1, 2]
    assert LooseVersion('1.2.3').version == [1, 2, 3]
    assert LooseVersion('1.2.3a2').version == [1, 2, 3, 'a', 2]
    assert LooseVersion('1.2a2').version == [1, 2, 'a', 2]
    assert LooseVersion('1.2b2').version == [1, 2, 'b', 2]
    assert LooseVersion('1.2pre3').version == [1, 2, 'pre', 3]
    assert LooseVersion('1.2pre3').version == [1, 2, 'pre', 3]
    assert LooseVersion('1.2rc3').version == [1, 2, 'rc', 3]
    assert LooseVersion

# Generated at 2022-06-22 22:25:57.166902
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def check(vstring, components):
        lv = LooseVersion(vstring)
        if lv.version != components:
            raise AssertionError("%s gives %s != %s" % (vstring, lv.version, components))
        # make sure str() gives the same thing back
        if str(lv) != vstring:
            raise AssertionError("%s gives %s != %s" % (vstring, str(lv), vstring))


# Generated at 2022-06-22 22:25:59.741446
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v1 = LooseVersion("1.2.3")
    assert repr(v1) == "'1.2.3'"
    assert v1.__str__() == "1.2.3"

# Generated at 2022-06-22 22:26:02.114062
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"
    assert str(v) == '0'


# Generated at 2022-06-22 22:26:08.355988
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v).startswith('Version (\'')
    assert repr(v).endswith('\')')
    v = Version('1.1.1')
    assert repr(v).startswith('Version (\'')
    assert repr(v).endswith('\')')

# Generated at 2022-06-22 22:26:11.499188
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.2')
    assert v.__str__() == '1.2'
    v.parse('40')
    assert v.__str__() == '40'



# Generated at 2022-06-22 22:26:14.622599
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('1.0')
    x = v > '1.1'
    assert not x  # 0.1



# Generated at 2022-06-22 22:26:16.091260
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    return 'assert True' in (Version() == '')

# Generated at 2022-06-22 22:26:17.721951
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert (v >= None) == NotImplemented



# Generated at 2022-06-22 22:26:20.587670
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse("1.0.4b1")
    assert(v.version == (1, 0, 4))
    assert(v.prerelease == ("b", 1))

# Generated at 2022-06-22 22:26:25.241365
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    def str___repr__(self):
        return (
            self.__class__.__name__,
            str(self),
        )

    expected_class_name = "Version"
    expected_str = None
    v = Version(expected_str)
    assert v.__repr__() == repr(expected_class_name), repr(expected_str)
    assert v.__repr__() != repr("A", "B")

# Generated at 2022-06-22 22:26:28.798159
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    version_instance = Version()
    version_instance.parse()
    assert isinstance(version_instance.__repr__(), str)
    assert version_instance.__repr__() == "(Version (), 'None')" 

# Generated at 2022-06-22 22:26:30.990629
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert not v1.__gt__(v2)

# Generated at 2022-06-22 22:26:37.430597
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from pip._vendor.packaging.version import Version
    v1 = Version()
    v2 = Version()
    assert not v1.__gt__(v1)
    assert not v1.__gt__(v2)
    assert not v2.__gt__(v1)
    assert not v2.__gt__(v2)

# Generated at 2022-06-22 22:26:42.661217
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    print("Test LooseVersion.__repr__")

    v = LooseVersion("1.2.3")
    s = repr(v)
    assert s == "LooseVersion ('1.2.3')"


# Generated at 2022-06-22 22:26:54.907987
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    _parse = StrictVersion("0.9.9").parse
    _parse("0.9.9")
    try:
        _parse("0.9.9.9")
        assert False
    except ValueError:
        pass
    try:
        _parse("0.9.9b9")
        assert False
    except ValueError:
        pass
    try:
        _parse("0.9.9.a9")
        assert False
    except ValueError:
        pass
    try:
        _parse("0.9.9.1b9")
        assert False
    except ValueError:
        pass
    try:
        _parse("0.9.9.1.9")
        assert False
    except ValueError:
        pass

# Generated at 2022-06-22 22:27:04.728867
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Test for case in which both operands are instances of Version.
    class TestVersion(Version):
        def parse(self, vstring):
            self.string = vstring
            self.version = [ord(vstring[i]) for i in range(len(vstring))]

        def _cmp(self, other):
            if isinstance(other, Version):
                return cmp(self.version, other.version)
            else:
                return NotImplemented

    v1 = TestVersion('one')
    v2 = TestVersion('two')
    v3 = TestVersion('three')

    assert v1 <= v2
    assert v2 <= v3
    assert not v3 <= v2
    assert not v2 <= v1
    assert v2 <= v2

# Generated at 2022-06-22 22:27:14.736061
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('') == ''
    assert LooseVersion('0') == '0'
    assert LooseVersion('1.2') == '1.2'
    assert LooseVersion('1.2.3') == '1.2.3'
    assert LooseVersion('a') == 'a'
    assert LooseVersion('a.b.c') == 'a.b.c'
    # lack of a string parameter asserts
    raises(TypeError, LooseVersion)
    # passing None
    raises(ValueError, LooseVersion, None)
    # passing an object with a __str__
    class StrStr:
        def __str__(self):
            return '1.2'
    assert LooseVersion(StrStr()) == '1.2'


# Generated at 2022-06-22 22:27:23.743700
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from io import StringIO
    from contextlib import redirect_stdout

    v = LooseVersion()
    v.parse('1.2.1')
    assert v.version == [1, 2, 1]
    v.parse('1.2.1a1')
    assert v.version == [1, 2, 1, 'a', 1]
    v.parse('1.2.1.a1')
    assert v.version == [1, 2, 1, 'a', 1]
    v.parse('1.2.1.b1')
    assert v.version == [1, 2, 1, 'b', 1]
    v.parse('1.2.1.pl1')
    assert v.version == [1, 2, 1, 'pl', 1]
    v.parse('2g6')
    assert v

# Generated at 2022-06-22 22:27:31.736674
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2.3')
    if repr(v) != "LooseVersion ('1.2.3')":
        raise AssertionError("'1.2.3' != %s" % repr(v))
    v = LooseVersion('1.2.3~rc4')
    if repr(v) != "LooseVersion ('1.2.3~rc4')":
        raise AssertionError("'1.2.3~rc4' != %s" % repr(v))



# Generated at 2022-06-22 22:27:34.513096
# Unit test for constructor of class Version
def test_Version():
    v = Version()

    v = Version('1.2.3.4')
    assert str(v) == '1.2.3.4'



# Generated at 2022-06-22 22:27:36.641062
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1.2.0').__repr__() == "LooseVersion ('1.2.0')"

# Generated at 2022-06-22 22:27:40.865858
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2.3')
    assert repr(v) == "LooseVersion ('1.2.3')"

# Generated at 2022-06-22 22:27:42.598473
# Unit test for constructor of class Version
def test_Version():
    for v in ['1', '2.3', '4.5.6']:
        Version(v)


# Generated at 2022-06-22 22:27:43.556731
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version() == Version()


# Generated at 2022-06-22 22:27:47.083813
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    u = Version('2.0')
    assert u == '2.0'
    assert not (u == '2.1')
    assert u == u
    assert not (u == -1)


# Generated at 2022-06-22 22:27:51.213201
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """LooseVersion.__repr__

    Method to return a representation of the class.
    """

    versionstring = "0.4.20050315"
    versiontest = LooseVersion(versionstring)

    versiontestrepr = "LooseVersion ('%s')" % versionstring
    assert versiontest.__repr__() == versiontestrepr


# Generated at 2022-06-22 22:28:02.036617
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion("1.2") == LooseVersion("1.2")
    assert LooseVersion("1.2") < LooseVersion("1.3")
    assert LooseVersion("1.2.0") == LooseVersion("1.2")
    assert LooseVersion("1.2") < LooseVersion("1.2.1.1")
    assert LooseVersion("1.2.1") < LooseVersion("1.2.2")
    assert LooseVersion("1.2.1") < LooseVersion("1.2.1.1")

    assert LooseVersion("1.2a") < LooseVersion("1.2")
    assert LooseVersion("1.2a") < LooseVersion("1.2b")

# Generated at 2022-06-22 22:28:13.882412
# Unit test for method __repr__ of class LooseVersion

# Generated at 2022-06-22 22:28:17.766136
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__('0.0') == NotImplemented


# Generated at 2022-06-22 22:28:27.612592
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion('1.2.3')
    assert lv.version == [1, 2, 3]

    lv = LooseVersion('1.2')
    assert lv.version == [1, 2]

    lv = LooseVersion('1.2a')
    assert lv.version == [1, 2, 'a']

    lv = LooseVersion('1.2rc3')
    assert lv.version == [1, 2, 'rc3']

    lv = LooseVersion('1.2.0')
    assert lv.version == [1, 2, 0]

    lv = LooseVersion('1.2.0.0')
    assert lv.version == [1, 2, 0, 0]

    lv = LooseVersion('1.2.1')

# Generated at 2022-06-22 22:28:39.368808
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('')

    for i in (0, '', ' ', '  ', '\t', ' \t ', ' \t\t \t ', '\t \t'):
        lv = LooseVersion()
        lv.parse(i)
        assert lv.vstring == ''

    for i in ('0', '0 ', ' 0 ', ' 00 ', ' 0 ', ' 0', '1', '1 ', ' 1 ', ' 11 ', ' 1 ', ' 1', '01', '001', 'A', 'a', 'A ', ' a ', ' A ', ' a'):
        lv = LooseVersion()
        lv.parse(i)
        assert lv.vstring == i


# Generated at 2022-06-22 22:28:44.728110
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # FIXME: implement this!
    # raise NotImplementedError()
    v1 = Version("0.0")
    v2 = Version("0.1")
    # print(v1, v2, v1>v2)
    assert (v1>v2) == False
    assert (v2>v1) == True
    assert v1._cmp(v1) == 0
    assert v1._cmp(v2) == -1
    return


# Generated at 2022-06-22 22:28:48.344341
# Unit test for constructor of class Version
def test_Version():
    assert Version('1.2.3')
    assert Version()       # Create instance with no args
    assert Version().parse('1.2.3')  # Create by passing a string to parse()

# Unit tests for cmp function of class Version

# Generated at 2022-06-22 22:28:49.403618
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__("") == False

# Generated at 2022-06-22 22:28:51.067572
# Unit test for method __ge__ of class Version
def test_Version___ge__(): assert Version() >= Version()

# Generated at 2022-06-22 22:28:55.484996
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    try:
        test_version = StrictVersion('1.2.3-alpha')
    except ValueError:
        print("Raised ValueError as expected.  No further tests performed.")


# Another class which behaves pretty much like StrictVersion,
# but assumes default .final versions, which is something we
# need for the modulefinder version matching scheme.

# Generated at 2022-06-22 22:28:58.405852
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"

# Generated at 2022-06-22 22:29:02.219165
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """test__LooseVersion___str__()"""
    l = LooseVersion()
    l.parse("1.2.3b4")
    assert l.__str__() == "1.2.3b4"


# Generated at 2022-06-22 22:29:09.671012
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.2.3")
    v2 = Version("1.2.3")
    v3 = Version("1.2.4")
    assert v1 == v2
    assert not v1 < v2
    assert not v1 > v2
    assert not v1 == v3
    assert v1 < v3
    assert not v1 > v3
    assert not v1 == 1
    assert v1 < 1
    assert v1 < 2



# Generated at 2022-06-22 22:29:11.758840
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version('1.1.1').__repr__() == "Version ('1.1.1')"


# Generated at 2022-06-22 22:29:13.052377
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version()
    assert version.__eq__(version) is NotImplemented

# Generated at 2022-06-22 22:29:24.171071
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion('1.2')
    assert len(lv.version) == 2, lv.version
    assert lv.vstring == '1.2', lv.vstring
    lv = LooseVersion('1.2.a')
    assert len(lv.version) == 3, lv.version
    assert lv.vstring == '1.2.a', lv.vstring
    lv = LooseVersion('1.2a')
    assert len(lv.version) == 2, lv.version
    assert lv.vstring == '1.2a', lv.vstring


# class VersionPredicate(object):
#     """A class encapsulating a simple predicate comparing a package
#     to a required version.  The package must be greater than or equal
#     to the required version.


# Generated at 2022-06-22 22:29:32.606784
# Unit test for method __str__ of class LooseVersion

# Generated at 2022-06-22 22:29:34.644200
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("1.0a1")
    assert(v.version == (1,0,0))


# Generated at 2022-06-22 22:29:38.246554
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    t = LooseVersion()
    t.version = (0,0,0)
    assert t.__str__() == "0.0.0"

# Generated at 2022-06-22 22:29:47.738607
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring, errmsg="error in constructor"):
        try:
            StrictVersion(vstring)
        except ValueError:
            return "OK"
        else:
            return errmsg + ": '%s'" % vstring


# Generated at 2022-06-22 22:29:53.433677
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.0.0').__str__() == '1.0.0'
    assert StrictVersion('1.0').__str__() == '1.0'
    assert StrictVersion('1.0a1').__str__() == '1.0a1'
    assert StrictVersion('1.0b3').__str__() == '1.0b3'
    assert StrictVersion('1.0a1').__str__() == '1.0a1'
    assert StrictVersion('1.0.1').__str__() == '1.0.1'
    assert StrictVersion('1.1.0').__str__() == '1.1'
    assert StrictVersion('1.1.0a3').__str__() == '1.1a3'
    assert St

# Generated at 2022-06-22 22:30:04.850996
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vstring, parsed in [
        (None, (0, 0, 0)),
        ("0.4", (0, 4, 0)),
        ("1.0", (1, 0, 0)),
        ("1.0.4b2", (1, 0, 4, ('b', 2))),
        ("1.13+", (1, 13, 0)),
        ("1999.12.31.2", (1999, 12, 31, 0)),
        ]:
        try:
            version = StrictVersion(vstring)
        except ValueError:
            if parsed is not None:
                raise
        else:
            if vstring is None:
                vstring = '0.0'
            assert str(version) == vstring
            assert version.version == parsed[0:3]

# Generated at 2022-06-22 22:30:16.428423
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():

    # Clear the trace
    set_trace([])

    # Create the object
    aStrictVersion = StrictVersion(vstring="0.4.1")

    # Unit test the method
    aStrictVersion.__str__()

    # Clear the trace
    set_trace([])

    # Create the object
    aStrictVersion = StrictVersion(vstring="0.5a1")

    # Unit test the method
    aStrictVersion.__str__()

    # Clear the trace
    set_trace([])

    # Create the object
    aStrictVersion = StrictVersion(vstring="0.5b3")

    # Unit test the method
    aStrictVersion.__str__()

    # Clear the trace
    set_trace([])

    # Create the object
    aStrictVersion = StrictVersion

# Generated at 2022-06-22 22:30:27.067228
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    try:
        StrictVersion(b"2.7.2")
    except TypeError:
        pass
    assert StrictVersion("2.7.2") == StrictVersion("2.7.2")
    assert StrictVersion("2.7.2") != StrictVersion("2.7.2.1")
    assert StrictVersion("2.7.2.1") == StrictVersion("2.7.2.1")
    assert StrictVersion("2.7.2") != StrictVersion("2.7.2.1a")
    assert StrictVersion("2.7.2.1a") == StrictVersion("2.7.2.1a")
    assert StrictVersion("2.7.2") != StrictVersion("2.7.2.1b")

# Generated at 2022-06-22 22:30:36.361493
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Quickie test of constructor
    LooseVersion('1.2.3a4')


# Here's something that works for "3.1.1.6" -- but it's not a general
# purpose solution!  Here's why:
#   - there's really no way to know what's a "patch level" and what's
#     part of the "minor" version number
#   - there's no way to compare partial versions -- what if someone
#     releases a product as "3.1a4" and then later drops the "a"
#     because they decide it's not really an alpha release?
#   - it can only handle up to four parts (ie. "3.1.1.6")
#
# It would be better to just look for a sequence of alpha/numeric
# characters, and split out the numeric bits.
#



# Generated at 2022-06-22 22:30:39.312087
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    inst = LooseVersion('2.2.0')
    assert inst.__str__() == '2.2.0'

# Generated at 2022-06-22 22:30:48.241211
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    cases = [('1.2.3a4', ('1.2.3a4', (1, 2, 3), ('a', 4))),
             ('2',        ('2',     (2, 0, 0), None)),
             ('1.0.4b3',  ('1.0.4b3',  (1, 0, 4), ('b', 3))),
             ('2.7.2',    ('2.7.2',    (2, 7, 2), None))]

    for version, expected in cases:
        v = StrictVersion(version)
        got = (str(v), v.version, v.prerelease)
        if got != expected:
            raise AssertionError('%r != %r' % (got, expected))



# Generated at 2022-06-22 22:30:55.968089
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        from unittest2 import TestCase
    except ImportError:
        from unittest import TestCase
    import sys

    class TestVersion(TestCase):
        # Test that __gt__ raises NotImplemented when __cmp__ returns
        # NotImplemented.
        def test_cmp_not_implemented(self):
            class CmpNotImplemented(Version):
                def __init__(self, version):
                    Version.__init__(self, version)

                def __cmp__(self, other):
                    return NotImplemented

            self.assertRaises(TypeError,
                              CmpNotImplemented('1').__gt__,
                              CmpNotImplemented('2'))

        # Test that __gt__ calls __cmp__ when it is defined

# Generated at 2022-06-22 22:30:59.019461
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"


# Generated at 2022-06-22 22:31:00.164024
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version() > None



# Generated at 2022-06-22 22:31:09.696473
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    from distutils.tests import support

    a = LooseVersion("1.2.0")
    b = LooseVersion("1.2.1")
    c = LooseVersion("1.2a1")
    d = LooseVersion("1.2.0.4")

    support.assertGreater(b, a)
    support.assertGreater(c, a)
    support.assertGreater(c, b)
    support.assertGreater(d, a)
    support.assertGreater(d, b)
    support.assertGreater(d, c)

    f = LooseVersion("1.2.f")
    g = LooseVersion("1.2.g")

    support.assertGreater(g, f)
    support.assertGreater(f, a)

# Generated at 2022-06-22 22:31:12.489562
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) == NotImplemented
    assert v.__le__('99.99') == NotImplemented



# Generated at 2022-06-22 22:31:13.966397
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Docstring and tests are inherited from class object
    pass

# Generated at 2022-06-22 22:31:23.576256
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    selftests = [
        True,
        True,
        False,
        False,
        False,
        False,
        True,
        True,
        True,
        True,
        False,
        False,
        False,
        False,
        False,
        False,
        False,
        False,
    ]
    i = 0

# Generated at 2022-06-22 22:31:26.223079
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse('1.2.3')
    assert v.version == [1, 2, 3]


# Generated at 2022-06-22 22:31:35.618953
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """test function __str__ of class StrictVersion"""
    _test_StrictVersion___str___v0 = StrictVersion("1.0.1")
    _test_StrictVersion___str___v1 = StrictVersion("1.0")
    _test_StrictVersion___str___v2 = StrictVersion("1.0.0")
    _test_StrictVersion___str___v3 = StrictVersion("1.1")
    _test_StrictVersion___str___v4 = StrictVersion("1.1.1")
    _test_StrictVersion___str___v5 = StrictVersion("1.1a1")
    _test_StrictVersion___str___v6 = StrictVersion("1.0.0a5")
    _test_StrictVersion___str___v

# Generated at 2022-06-22 22:31:46.750769
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import sys
    import random

    i, n = 100, 10
    while i > 0:
        i -= 1
        v1 = [random.randint(-9,9) for x in range(n)]
        v2 = v1[:]
        v1[n-1] += 2
        v2[n-1] += 1
        v1 = Version(".".join(str(i) for i in v1))
        v2 = Version(".".join(str(i) for i in v2))
        assert v1 > v2
        assert v1 >= v2
        assert v1 != v2
        assert not v1 < v2
        assert not v1 <= v2
        assert not v1 == v2

    # Corner case
    v1 = Version("")
    v2 = Version("")

# Generated at 2022-06-22 22:31:55.348190
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:32:06.379669
# Unit test for constructor of class Version

# Generated at 2022-06-22 22:32:16.045910
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    class Test_Version___lt__(unittest.TestCase):
        def test(self):
            self.assertTrue(Version() < '1')
            self.assertTrue(Version('1') < '1.1')
            self.assertTrue(Version('1.1') < '1.2')
            self.assertTrue(Version('1.2') < '1.2.1')
            self.assertTrue(Version('1.2.1') < '2.0')
            self.assertTrue(Version('2.0') < '3')
            self.assertTrue(Version('1') < '1.1a1')
            self.assertTrue(Version('1') < '1.1dev')
            self.assertTrue(Version('1') < '1.1b1')
            self.assertTrue

# Generated at 2022-06-22 22:32:22.284518
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import pytest
    v = Version()
    v.__ge__ = None
    with pytest.raises(AttributeError) as e:
        Version.__ge__(v, None)
    assert "unbound" in str(e.value)
test_Version___ge__()


# Generated at 2022-06-22 22:32:23.215931
# Unit test for method __ge__ of class Version
def test_Version___ge__(): assert Version() >= Version()

# Generated at 2022-06-22 22:32:25.701292
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2a1')
    assert str(v) == '1.2a1'



# Generated at 2022-06-22 22:32:27.105505
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert str(Version("1.2")) == "1.2"


# Generated at 2022-06-22 22:32:30.004585
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    instance = LooseVersion('1.2.3')
    assert str(instance) == '1.2.3'

