

# Generated at 2022-06-22 22:22:45.438329
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("0.4").__str__() == "0.4"
    assert StrictVersion("0.4.0").__str__() == "0.4.0"
    assert StrictVersion("0.4.1").__str__() == "0.4.1"
    assert StrictVersion("0.5a1").__str__() == "0.5a1"
    assert StrictVersion("0.5b3").__str__() == "0.5b3"
    assert StrictVersion("0.5").__str__() == "0.5"
    assert StrictVersion("0.9.6").__str__() == "0.9.6"
    assert StrictVersion("1.0").__str__() == "1.0"

# Generated at 2022-06-22 22:22:55.512052
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    """Test the constructor of the class LooseVersion"""

    def check_loose_version(vstring):
        """Check that LooseVersion parses the given string correctly"""
        version = LooseVersion(vstring)
        if version.vstring != vstring:
            raise AssertionError("%s != %s" % (version.vstring, vstring))

    check_loose_version('1.5.2b2')
    check_loose_version('161')
    check_loose_version('3.10a')
    check_loose_version('8.02')
    check_loose_version('3.4j')
    check_loose_version('1996.07.12')
    check_loose_version('3.2.pl0')

# Generated at 2022-06-22 22:22:56.801162
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    _test_parse(LooseVersion)


# Generated at 2022-06-22 22:22:59.117578
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.0.0')
    # I would expect '1.0.0', but the code doesn't work that way
    #assert str(v) == '1.0.0'



# Generated at 2022-06-22 22:23:01.734838
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version("1.0") < Version("2.0"), "Failed to compare Version instances"

# Generated at 2022-06-22 22:23:10.342237
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest.mock as mock
    a = Version()
    b = Version()
    a._cmp = mock.Mock()
    b._cmp = mock.Mock()
    assert a.__le__(b) == a._cmp.return_value <= 0
    a._cmp.assert_called_with(b)
    a._cmp.return_value = 3.2
    assert a.__le__(b) == True
    assert a.__le__(b) == a._cmp.return_value <= 0
    b._cmp.assert_not_called()

# Generated at 2022-06-22 22:23:14.653488
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    class V(Version):
        def parse(self, vstring):
            self.value = int(vstring)
        def _cmp(self, other):
            return self.value - other.value
    v1 = V('1')
    assert(v1 == V('1')) # from Version
    assert(not v1==V('2')) # from V


# Generated at 2022-06-22 22:23:26.718071
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:23:32.696746
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Test method __repr__ of class Version"""
    v = Version()
    assert str(v) == "Version ('None')"

    v2 = Version("1.2.3")
    assert str(v2) == "Version ('1.2.3')"
#test_Version___repr__()


# Generated at 2022-06-22 22:23:34.147251
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    v = Version('1.2')



# Generated at 2022-06-22 22:23:37.482184
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Test method __repr__ of class Version"""
    v = Version()
    assert repr(v) == "Version ('None')"
    v = Version('2.0')
    assert repr(v) == "Version ('2.0')"


# Generated at 2022-06-22 22:23:41.251919
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """_LooseVersion__repr__()"""
    lv = LooseVersion('1.2.3-pre')
    s = repr(lv)
    assert s == "LooseVersion ('1.2.3-pre')"


# Generated at 2022-06-22 22:23:46.969522
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    import unittest


# Generated at 2022-06-22 22:23:50.499571
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion("1.2.3a0")
    assert lv.version == [1, 2, 3, 'a', 0]



# Generated at 2022-06-22 22:23:52.923540
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    args = None
    v = LooseVersion(args)
    assert repr(v) == "LooseVersion ('')"



# Generated at 2022-06-22 22:23:55.097324
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Version.__ge__(self, other)
    assert Version("1.0").__ge__("1.0")


# Generated at 2022-06-22 22:23:58.425572
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    if LooseVersion("1.1") != "1.1":
        print("LooseVersion('1.1') != '1.1'")


# Generated at 2022-06-22 22:24:02.045674
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    def test():
        v1 = Version('1')
        v2 = Version('2')
        assert v1 >= v1
        assert not v1 >= v2
        assert v2 >= v1
    test()

# Generated at 2022-06-22 22:24:10.467377
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for num in ["0.4", "0.4.0"]:
        assert StrictVersion(num) == StrictVersion("0.4.0")
        assert StrictVersion(num).version == (0, 4, 0)

    for num in ["0.4.1", "0.5a1", "0.5b3", "0.5", "0.9.6", "1.0",
                "1.0.4a3", "1.0.4b1", "1.0.4"]:
        StrictVersion(num)


# Generated at 2022-06-22 22:24:13.481259
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    f = open('../test/input_data/input_data_version')
    n = open('../test/input_data/input_data_version_n')
    lines = f.readlines()
    nlines = n.readlines()
    data = [[LooseVersion(l.strip()) for l in lines], [l.strip() for l in nlines]]
    print(data)

test_LooseVersion_parse()

# Generated at 2022-06-22 22:24:25.152402
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring, parsed, ignored):
        s = str(StrictVersion(vstring))
        assert s == parsed, "%s should have been parsed as %s, not %s" % \
               (vstring, parsed, s)

    test("0.4.0", "0.4", "0.4.0")
    test("0.4",   "0.4", "0.4.0")
    test("0.4.1", "0.4.1", "0.4.1")
    test("0.5a1", "0.5a1", "0.5a1")
    test("0.5b3", "0.5b3", "0.5b3")
    test("0.5",   "0.5", "0.5.0")

# Generated at 2022-06-22 22:24:28.735234
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(None) is NotImplemented
    assert v.__eq__('None') is NotImplemented

    assert v.__eq__('None') is NotImplemented

# Generated at 2022-06-22 22:24:33.168880
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    #test_Version___eq__()
    assert 'Version.__eq__'
    #1
    v1 = Version('1.2')
    v2 = Version('1.2')
    assert v1 == v2
    #2
    v1 = Version('1.2')
    v2 = Version('1.3')
    assert v1 != v2

# Generated at 2022-06-22 22:24:34.276280
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version('1') >= Version('1')
    

# Generated at 2022-06-22 22:24:45.323919
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def check(vstring):
        return StrictVersion(vstring)._cmp(vstring)

    assert check("1.0") == 0
    assert check("1.0.0.0") == 0, "zero-padded parts should not matter"
    assert check("1.0.0.0.0") == 0
    assert check("1.0-0") == 0, "zero-padded parts should not matter"
    assert check("1.0-0.0") == 0
    assert check("1.0-0.0.0") == 0
    assert check("1.0.0a1") == 0
    assert check("1.0.0b1") == 0
    assert check("1.0.0c1") == 0
    assert check("1.0.0rc1") == 0

# Generated at 2022-06-22 22:24:55.619242
# Unit test for method __le__ of class Version
def test_Version___le__():
  from distutils.version import _LooseVersion
  from distutils.version import LooseVersion
  from distutils.version import _StrictVersion
  from distutils.version import StrictVersion
  from distutils.version import Version
  from distutils.version import _LegacyVersion
  from distutils.version import LegacyVersion
  from distutils.version import _LooseVersion
  from distutils.version import LooseVersion
  from distutils.version import _StrictVersion
  from distutils.version import StrictVersion
  from distutils.version import Version
  from distutils.version import _LegacyVersion
  from distutils.version import LegacyVersion
  from distutils.version import _LooseVersion
  from distutils.version import LooseVersion
  from distutils.version import _StrictVersion
  from distutils.version import StrictVersion

# Generated at 2022-06-22 22:25:00.802385
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    verify = Version.verify

    assert verify('1.2.3', '1.2.3')
    assert verify('1.2.3', (1,2,3))

    assert not verify('1.2.3', '1.2.4')
    assert not verify('1.2.3', (1,2,4))

    assert not verify('1.2.0', (1,2))
    assert not verify('1.2.0', '1.2')

    # The following is a special case introduced when I started
    # ineriting from UserDict -- the UserDict class has __version__
    # data members, which get picked up by the old style test set
    # when I added the __version__ attribute to the Version class.
    # Since this shouldn't break with the introduction of any future
    # version of

# Generated at 2022-06-22 22:25:09.676856
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from pk.loosev_parse import LooseVersion
    from pk.loosev_parse import LooseVersion
    print('testing class LooseVersion, method parse')

# Generated at 2022-06-22 22:25:19.994812
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    from distutils.version import StrictVersion
    """Tests for StrictVersion.parse() method."""
    import unittest

    class TestCase(unittest.TestCase):

        def test_parse_1(self):
            s = StrictVersion("0.4")
            self.assertEqual(s.version, (0, 4, 0))
            self.assertEqual(s.prerelease, None)
            self.assertEqual(s.string, "0.4")

        def test_parse_2(self):
            s = StrictVersion("0.4.0")
            self.assertEqual(s.version, (0, 4, 0))
            self.assertEqual(s.prerelease, None)
            self.assertEqual(s.string, "0.4.0")


# Generated at 2022-06-22 22:25:23.081407
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert(v.__gt__(None) is NotImplemented)
    assert(v.__gt__(v) is False)
    assert(v.__gt__('1') is NotImplemented)


# Generated at 2022-06-22 22:25:26.314699
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.0.0')
    assert repr(v) == "Version ('1.0.0')"


# Generated at 2022-06-22 22:25:33.593251
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring, components):
        v = StrictVersion(vstring)
        assert v.version == components

    test('0.4',          (0,4,0))
    test('0.4.0',        (0,4,0))
    test('0.4.1',        (0,4,1))
    test('0.5a1',        (0,5,0,'a',1))
    test('0.5b3',        (0,5,0,'b',3))
    test('0.5',          (0,5,0))
    test('0.9.6',        (0,9,6))
    test('1.0',          (1,0,0))
    test('1.0.4a3',      (1,0,4,'a',3))


# Generated at 2022-06-22 22:25:38.239988
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    def __str__():
        '''
        >>> __str__()
        0.4.1
        '''
        v = LooseVersion("0.4.1")
        print(str(v))

    __str__()


# Generated at 2022-06-22 22:25:42.772411
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Test Version._repr__()
    
    >>> v = Version()
    >>> print(v)
    None ('%s')
    
    """


# Generated at 2022-06-22 22:25:45.653782
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    try:
        LooseVersion().__str__()
    except (TypeError, AttributeError):
        pass
    else:
        print('Method __str__ of class LooseVersion not working right')


# Generated at 2022-06-22 22:25:47.815445
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version

    ver_a = Version('1.0')
    ver_b = Version('0.8')
    assert ver_a > ver_b

# Generated at 2022-06-22 22:25:56.473756
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Have to use uppercase names for StrictVersion and LooseVersion
    # because this package is loaded from the test directory, not the
    # directory above it.
    StrictVersion = __import__("distutils.version").StrictVersion
    LooseVersion = __import__("distutils.version").LooseVersion

    eq = lambda v, w: (v == w) and (str(v) == str(w))

# Generated at 2022-06-22 22:26:05.869490
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    sv = StrictVersion('1.2.3a4')
    assert sv.version == (1, 2, 3)
    assert sv.prerelease == (a, 4)
    sv = StrictVersion()
    try:
        sv.parse('1')
        assert False  # error: did not raise exception
    except ValueError:
        pass
    try:
        sv.parse('2.7.2.2')
        assert False  # error: did not raise exception
    except ValueError:
        pass
    try:
        sv.parse('1.3.a4')
        assert False  # error: did not raise exception
    except ValueError:
        pass
    try:
        sv.parse('1.3pl1')
        assert False  # error: did not raise exception
    except ValueError:
        pass
   

# Generated at 2022-06-22 22:26:12.372183
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion('3.1.4')
    assert str(l) == '3.1.4'
    assert repr(l) == "LooseVersion ('3.1.4')"

    l = LooseVersion('')
    assert l.version == []
    assert str(l) == ''
    assert repr(l) == "LooseVersion ('')"

    l = LooseVersion('1')
    assert l.version == [1]
    assert str(l) == '1'
    assert repr(l) == "LooseVersion ('1')"

    l = LooseVersion('1.2')
    assert l.version == [1, 2]
    assert str(l) == '1.2'
    assert repr(l) == "LooseVersion ('1.2')"

    l = LooseVersion

# Generated at 2022-06-22 22:26:22.345061
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def assert_StrictVersion(vstring):
        assert StrictVersion(vstring).parse(vstring) == None

    assert_StrictVersion('0.4')
    assert_StrictVersion('0.4.0')
    assert_StrictVersion('0.4.1')
    assert_StrictVersion('0.5a1')
    assert_StrictVersion('0.5b3')
    assert_StrictVersion('0.5')
    assert_StrictVersion('0.9.6')
    assert_StrictVersion('1.0')
    assert_StrictVersion('1.0.4a3')
    assert_StrictVersion('1.0.4b1')
    assert_StrictVersion('1.0.4')



# Generated at 2022-06-22 22:26:26.475501
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion()
    assert __repr__(v) == "LooseVersion ('%s')" % str(v)


__all__.append('test_LooseVersion___repr__')


# Generated at 2022-06-22 22:26:29.136545
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:26:37.613738
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    from tests import test_distutils

    v = StrictVersion('1.2.3')
    test_distutils.assert_equal(str(v), '1.2.3')
    v = StrictVersion('1.2.3rc1')
    test_distutils.assert_equal(str(v), '1.2.3rc1')
    v = StrictVersion('1.2.3.4')
    test_distutils.assert_equal(str(v), '1.2.3.4')



# Generated at 2022-06-22 22:26:50.140430
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Parsing of version strings containing no dots or letters,
    #   "1", "1.0.0"
    # is OK.
    lv = LooseVersion()
    lv.parse('1')
    assert lv.version == [1]
    lv.parse('1.0.0')
    assert lv.version == [1, 0, 0]

    # Parsing of version strings containing dots and letters,
    #   "1.2a3", "1.2b3", "1.2", "1.2.3",
    # is OK.
    lv.parse('1.2a3')
    assert lv.version == [1, 2, 'a', 3]
    lv.parse('1.2b3')

# Generated at 2022-06-22 22:26:51.500817
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    import doctest
    doctest.testmod()


# Generated at 2022-06-22 22:26:58.939576
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """Test parsing of versions
    """
    lv = LooseVersion("")
    assert lv.version == ()

    lv = LooseVersion("1.5")
    assert lv.version == (1, 5)

    lv = LooseVersion("1.5.0")
    assert lv.version == (1, 5, 0)

    lv = LooseVersion("1.5.0.0")
    assert lv.version == (1, 5, 0, 0)

    lv = LooseVersion("010.005")
    assert lv.version == (10, 5)

    lv = LooseVersion("1.5.0.post241")
    assert lv.version == (1, 5, 0, 'post241')

    lv = LooseVersion("1.5.dev")

# Generated at 2022-06-22 22:27:07.028974
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion('1.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease == None
    v = StrictVersion('1.0.0')
    assert v.version == (1, 0, 0)
    assert v.prerelease is None
    v = StrictVersion('1.0a1')
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)
    v = StrictVersion('1.0b3')
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('b', 3)



# Generated at 2022-06-22 22:27:15.622044
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """
    >>> lv = LooseVersion()
    >>> lv.parse('2.2beta29')
    >>> lv.version
    [2, 2, 'beta', 29]
    >>> lv.parse('5.5.kw')
    >>> lv.version
    [5, 5, 'kw']
    >>> lv = LooseVersion()
    >>> lv.parse('2g6')
    >>> lv.version
    [2, 'g', 6]
    >>> lv.parse('3.10a')
    >>> lv.version
    [3, 10, 'a']
    """
    pass    # Not necessary, since the tests are embedded in the docstring

test_LooseVersion_parse.__test__ = False



# Generated at 2022-06-22 22:27:25.394255
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    """Tests LooseVersion constructor for correct response to the
    following version number strings:

        1.5.1
        1.5.2b2
        161
        3.10a
        8.02
        3.4j
        1996.07.12
        3.2.pl0
        3.1.1.6
        2g6
        11g
        0.960923
        2.2beta29
        1.13++
        5.5.kw
        2.0b1pl0
    """


# Generated at 2022-06-22 22:27:27.460482
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"


# Generated at 2022-06-22 22:27:29.717637
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Test Version.__le__"""
    # [pre]
    # [post]
    pass # TODO


# Generated at 2022-06-22 22:27:35.506713
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1.__eq__(v2) == NotImplemented

    v3 = Version()
    v4 = Version()
    assert v3.__eq__(v4) == NotImplemented

    v5 = Version()
    v6 = Version()
    assert v5.__eq__(v6) == NotImplemented

# Generated at 2022-06-22 22:27:39.459681
# Unit test for constructor of class Version
def test_Version():
    for vs in ('2.4', '1.0-ALPHA', '2.2.0', '0.960923'):
        v = Version(vs)
        assert str(v) == vs
        assert repr(v) == "%s ('%s')" % (v.__class__.__name__, vs)


# Generated at 2022-06-22 22:27:44.579577
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version('1.2.3')
    assert v < '1.2.4'
    assert v < '1.2.3.4'
    assert v < '2.2.3'
    assert v < '2.2'
    assert v < '3'
    assert v < ''
    assert v < 'a'
    assert v < 'A'
    assert v < 'A.2'
    assert v < 'A.2.3'
    assert v < 'A.2.3.4'
    assert v < 'A.3'
    assert v < 'A.a'
    assert v < 'A.b'
    assert v < 'A.a.2'
    assert v < 'A.a.2.3.4'
    assert v < 'A.a.3'
    assert v

# Generated at 2022-06-22 22:27:50.230946
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    c = Version()
    c._cmp = lambda x : -1
    assert c.__eq__('b') is False
    c._cmp = lambda x : 0
    assert c.__eq__('b') is True
    c._cmp = lambda x : 1
    assert c.__eq__('b') is False
    c._cmp = lambda x : NotImplemented
    assert c.__eq__('b') is NotImplemented

# Generated at 2022-06-22 22:27:55.752674
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from libtbx.test_utils.pytest_utils import approx_equal
    assert Version("1.0.0") >= Version("1.0.0")
    assert Version("1.0.0") >= Version("0.9.9")
    assert not (Version("1.0.0") >= Version("1.0.1"))


# Generated at 2022-06-22 22:28:03.431109
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion
    assert v('1.2') >= v('1.2b')
    assert v('1.2.1') > v('1.2')
    assert v('1.2.1') > v('1.2b')
    assert v('1.2b') < v('1.2')
    assert v('1.2b') < v('1.2.1')
    assert v('1.2') == v('1.2')
    assert v('1.2') == v('1.2.0')
    assert v('1.2') == v('1.2.0.0.0')
    assert v('1.2') != v('1.2.0.0.1')



# Generated at 2022-06-22 22:28:08.750746
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == "", "Expected True, got False!"
    assert v != 2, "Expected False, got True!"
    assert v == v, "Expected True, got False!"


# Generated at 2022-06-22 22:28:13.699228
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v_1_0_4a3 = StrictVersion('1.0.4a3')
    assert(str(v_1_0_4a3) == '1.0.4a3')


# Generated at 2022-06-22 22:28:18.445574
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion()
    l.parse('3.10a')
    assert l.vstring=='3.10a'
    assert l.version==[3, 10, 'a']

    l = LooseVersion()
    l.parse('1.13++')
    assert l.vstring=='1.13++'
    assert l.version==[1, 13, '++']


if __name__ == "__main__":
    test_LooseVersion_parse()
    print('Test passed.')

# Generated at 2022-06-22 22:28:21.569866
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    strict_version = StrictVersion('0.9.6')
    assert strict_version.version == (0, 9, 6)
    assert strict_version.prerelease is None


# Generated at 2022-06-22 22:28:30.004063
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Testing empty class Version
    def test_empty():
        v = Version()
        assert v == 1 is False
        assert v == '' is False
        assert v == '1' is False
        assert v == '1.0' is False
        assert v == '1.0.0' is False
        assert v == '1.0.0.0' is False
        assert v == '   1  . 0 . 0 .  0  ' is False

    test_empty()

    # Testing parse() to produce same error message as constructor
    def test_parse():
        v = Version()
        for s in ('', '1', '1.0', '1.0.0', '1.0.0.0'):
            try:
                v.parse(s)
                assert False
            except ValueError:
                assert True

   

# Generated at 2022-06-22 22:28:34.346386
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    # Create an instance of the Version class
    version_instance = Version("1.0")

    # Call the __lt__ method to compare version_instance with a string
    result = version_instance.__lt__("1.1")

    assert result


# Generated at 2022-06-22 22:28:37.059479
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('4.1.2rc4')
    assert repr(v) == "LooseVersion ('4.1.2rc4')"

# Generated at 2022-06-22 22:28:48.299580
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1,2,3), "expect: (1,2,3) got: %s" % str(v.version)
    assert v.prerelease == None, "expect: None got: %s" % str(v.prerelease)

    v.parse('1.2.3a4')
    assert v.version == (1,2,3), "expect: (1,2,3) got: %s" % str(v.version)
    assert v.prerelease == ('a',4), "expect: ('a',4) got: %s" % str(v.prerelease)


# Generated at 2022-06-22 22:28:57.763502
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Test valid versions
    v = StrictVersion("1.0.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease == None

    v = StrictVersion("1")
    assert v.version == (1,)
    assert v.prerelease == None

    v = StrictVersion("1.0.4a3")
    assert v.version == (1, 0, 4)
    assert v.prerelease == ('a', 3)

    # Test invalid versions
    try:
        StrictVersion("1.2.3.4")
    except ValueError:
        pass
    except Exception as e:
        raise AssertionError("Unexpected exception raised: %s" % e)
    else:
        raise AssertionError("Expected ValueError not raised")


# Generated at 2022-06-22 22:29:06.019380
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert v._cmp(None) is NotImplemented
    assert v == 0, repr(v)
    assert v == '', repr(v)
    assert v >= 0, repr(v)
    assert v <= 0, repr(v)
    assert not v > 0, repr(v)
    assert not v < 0, repr(v)
    assert v != 1, repr(v)
    assert not v == 1, repr(v)
    assert v < 1, repr(v)
    assert v <= 1, repr(v)
    assert not v > 1, repr(v)
    assert not v >= 1, repr(v)


# Generated at 2022-06-22 22:29:17.359412
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import sys
    import os
    import pytest

    # Declare the package version number
    __version__ = '1.0.0'

    # Assume that the devpy package is installed in the same directory as this file
    devpyDir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    # Include the directory where module devpy is installed in the Python search path
    sys.path.insert(0, devpyDir)

    # Import devpy module
    import devpy.utilities.version as dutv

    # Get the class definition
    Version = dutv.Version

    # instantiate the class
    version = Version()
    version.parse('1.0.0')

    # Execute the code to be tested

# Generated at 2022-06-22 22:29:26.148461
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("0.4b2").__str__() == "0.4b2"
    assert StrictVersion("0.4").__str__() == "0.4"
    assert StrictVersion("0.4.1").__str__() == "0.4.1"
    assert StrictVersion("0.5a1").__str__() == "0.5a1"
    assert StrictVersion("0.5b3").__str__() == "0.5b3"
    assert StrictVersion("0.5").__str__() == "0.5"
    assert StrictVersion("0.9.6").__str__() == "0.9.6"
    assert StrictVersion("1.0").__str__() == "1.0"

# Generated at 2022-06-22 22:29:32.580008
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """Test method __str__ of class StrictVersion"""
    v = StrictVersion("0.9.6")
    assert v.__str__() == "0.9.6"
    v = StrictVersion("0.9")
    assert v.__str__() == "0.9"


# Generated at 2022-06-22 22:29:40.369526
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    try:
        Version('1')
    except ValueError:
        pass
    else:
        raise AssertionError("Failed to raise ValueError on Version('1')")

    try:
        StrictVersion('1')
    except ValueError:
        pass
    else:
        raise AssertionError("Failed to raise ValueError on StrictVersion('1')")

    try:
        StrictVersion('1.2.3.4')
    except ValueError:
        pass
    else:
        raise AssertionError("Failed to raise ValueError on StrictVersion"
                             "('1.2.3.4')")

    try:
        StrictVersion('1.2.a3')
    except ValueError:
        pass

# Generated at 2022-06-22 22:29:48.892506
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Assert that the provided values produce the expected output
    assert StrictVersion("1.0").version == (1, 0, 0),\
        "Version with major and minor number should be expanded to minor, " \
        "major and patch"
    assert StrictVersion("1.0.0").version == (1, 0, 0), \
        "Version with major, minor and patch should be expanded to major, " \
        "minor and patch"
    assert StrictVersion("0.4").version == (0, 4, 0), \
        "Version with major and minor number should be expanded to minor, " \
        "major and patch"
    assert StrictVersion("0.4").prerelease == None, \
        "Version with major and minor number should be expanded to minor, " \
        "major and patch"

# Generated at 2022-06-22 22:29:51.363888
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    l = LooseVersion('1.2.3')
    assert isinstance(LooseVersion('1.2.3'), LooseVersion)
    assert str(l) == '1.2.3'


# Generated at 2022-06-22 22:29:56.047778
# Unit test for method __le__ of class Version
def test_Version___le__():
    
    v = Version("1.1")
    assert (v <= "1.1") == True
    assert (v <= "2.1") == True
    assert (v <= "1.0") == False
    
    
    

# Generated at 2022-06-22 22:30:08.321738
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def check(x, expect):
        actual = str(LooseVersion(x))
        assert expect == actual, "%s --> %s [expected: %s]" % (x, actual, expect)

    for v in ['1.2.3', '1.2.3a', '1.2.1.b', '0.9.6', '1.2.a4', '2.4.a']:
        check(v, v)
    for (v, expect) in [('3.3.3.3.3', '3.3.3.3'), ('1.1.a2.3', '1.1.0a2.3')]:
        check(v, expect)

# Generated at 2022-06-22 22:30:10.603934
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == v
    assert not v != v
    assert v == '1'
    assert not v != '1'

# Generated at 2022-06-22 22:30:16.092608
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:30:20.120940
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    version = LooseVersion('Python-2.0')
    str = version.__str__()
    assert str == 'Python-2.0', str

    version = LooseVersion('1.5.1')
    str = version.__str__()
    assert str == '1.5.1', str


# Generated at 2022-06-22 22:30:22.256095
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    v.__gt__()


# Generated at 2022-06-22 22:30:23.813415
# Unit test for method __le__ of class Version

# Generated at 2022-06-22 22:30:26.385753
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert v >= '1.2.2'

# Generated at 2022-06-22 22:30:28.844394
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v1 = Version('1.0')
    assert repr(v1) == "Version ('1.0')"


# Generated at 2022-06-22 22:30:33.165490
# Unit test for method __repr__ of class Version
def test_Version___repr__():
   _version_ = new_Version(None)
   _expected_version_.__repr__()
   _received_version_.__repr__()
   if expected == received:
       print('Passed')
   else:
       print('Failed: ' + 'Expected: ' + expected + ' but received: ' + received)

# Generated at 2022-06-22 22:30:45.457379
# Unit test for method __le__ of class Version
def test_Version___le__():
    # 'Version' class provides rich comparison methods
    v1 = Version("1.2.3a3")
    assert v1 <= v1
    assert not (v1 < v1)
    assert not (v1 > v1)
    assert v1 >= v1
    v2 = Version("1.2.3")
    assert v2 <= v2
    assert not (v2 < v2)
    assert not (v2 > v2)
    assert v2 >= v2
    assert v1 <= v2
    assert v1 < v2
    assert not (v1 > v2)
    assert not (v1 >= v2)
    assert not (v2 <= v1)
    assert not (v2 < v1)
    assert v2 > v1
    assert v2 >= v1



# Generated at 2022-06-22 22:30:49.917647
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    try:
        StrictVersion().parse('')
    except Exception as e:
        if str(e) == "invalid version number ''":
            pass
        else:
            raise e
    else:
        raise AssertionError


# Generated at 2022-06-22 22:30:51.764950
# Unit test for constructor of class Version
def test_Version():
    for vstring in ('1.2.3', '1.2.3.4', '1.2.3.4.5'):
        v = Version(vstring)
        assert v._version == vstring



# Generated at 2022-06-22 22:30:53.703971
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("1.0")
    v2 = Version("4.5.6")
    assert v1 <= v2


# Generated at 2022-06-22 22:31:00.196067
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # this is a lame test, need something more
    s = StrictVersion("1.2.3")

    del s
    try:
        s = StrictVersion("1.234.3a1")
    except ValueError:
        pass
    else:
        raise AssertionError("invalid version number not detected")

    del s
    try:
        s = StrictVersion("1.2.3.a1")
    except ValueError:
        pass
    else:
        raise AssertionError("invalid version number not detected")

    del s
    try:
        s = StrictVersion("1.2.a1")
    except ValueError:
        pass
    else:
        raise AssertionError("invalid version number not detected")

    del s

# Generated at 2022-06-22 22:31:06.011079
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test Version.__ge__."""
    v = Version('1.0')
    assert v >= '1.0'
    assert v >= Version('1.0')
    assert v >= 1.0
    assert not v >= '2.0'
    assert not v >= Version('2.0')
    assert not v >= 2.0



# Generated at 2022-06-22 22:31:08.258933
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    for _i in range(1000000):
        v = Version()
        o = Version()
        bool(v == o)



# Generated at 2022-06-22 22:31:19.614283
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    t = LooseVersion
    assert t('1.2.3').parse('1.2.3') == t('1.2.3')
    assert t('a').parse('a') == t('a')
    assert t('a.b').parse('a.b') == t('a.b')
    assert t('a.b.c').parse('a.b.c') == t('a.b.c')
    assert t('a-c').parse('a-c') == t('a-c')
    assert t('a.b-c').parse('a.b-c') == t('a.b-c')
    assert t('a.b-c.d').parse('a.b-c.d') == t('a.b-c.d')

# Generated at 2022-06-22 22:31:20.588342
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    pass



# Generated at 2022-06-22 22:31:23.047179
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert (Version('1') >= Version('1'))
    assert (Version('1') >= Version('0'))
    assert (not (Version('1') >= Version('2')))



# Generated at 2022-06-22 22:31:26.675588
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    t1 = LooseVersion('2.2beta29')
    t2 = LooseVersion('2.3alpha1')
    assert t1 < t2


# Generated at 2022-06-22 22:31:29.109850
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version("1.2.3")
    assert repr(v) == "Version ('1.2.3')"



# Generated at 2022-06-22 22:31:36.976226
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def check_parse(s, t):
        v = LooseVersion(s)
        if v.version != t:
            raise AssertionError("%s -> %s != %s" % (s, v.version, t))
        p = str(v)
        if p != s:
            raise AssertionError("%s -> %s != %s" % (s, p, s))

    check_parse('0.4.0', (0,4,0))
    check_parse('1.5.1', (1,5,1))
    check_parse('1.5.2b2', (1,5, '2b', 2))
    check_parse('161', (161,))
    check_parse('3.10a', (3, '10a'))

# Generated at 2022-06-22 22:31:41.035623
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert_equals(v.__gt__(None), NotImplemented)
    assert_false(v.__gt__(v))



# Generated at 2022-06-22 22:31:45.453483
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:31:46.892976
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.2') < Version('1.4')

# Generated at 2022-06-22 22:31:55.424756
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import pytest
    sv = StrictVersion()

    with pytest.raises(ValueError):
        sv.parse('1')
    with pytest.raises(ValueError):
        sv.parse('2.7.2.2')
    with pytest.raises(ValueError):
        sv.parse('1.3.a4')
    with pytest.raises(ValueError):
        sv.parse('1.3pl1')
    with pytest.raises(ValueError):
        sv.parse('1.3c4')

    sv.parse('0.4')
    assert sv.version == (0, 4, 0)
    assert sv.prerelease is None
    sv.parse('0.4.0')
    assert sv.version == (0, 4, 0)
    assert sv.prerelease is None

# Generated at 2022-06-22 22:31:57.520359
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  assert Version() < Version(), "Version() < Version()"


# Generated at 2022-06-22 22:32:00.114723
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('1.0')
    assert repr(lv) == 'LooseVersion (\'1.0\')'


# Generated at 2022-06-22 22:32:11.052009
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion("a")
    assert l.version == ['a'], l.version

    l = LooseVersion("1.a")
    assert l.version == [1, 'a'], l.version

    l = LooseVersion("1.2.a")
    assert l.version == [1, 2, 'a'], l.version

    l = LooseVersion("12.3")
    assert l.version == [12, 3], l.version

    l = LooseVersion("1.b.4")
    assert l.version == [1, 'b', 4], l.version

    l = LooseVersion("1.2.2.b.4.5")
    assert l.version == [1, 2, 2, 'b', 4, 5], l.version



# Generated at 2022-06-22 22:32:16.210086
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('0.0.1')
    v2 = Version('0.0.1')
    assert v1.__gt__(v2) == False


# Generated at 2022-06-22 22:32:25.782357
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
  import unittest

  # Setup test suite
  suite = unittest.TestSuite()

  # Add tests

  # Test 1: Check that the following works as expected
  version_string = '1.0.0'
  suite.addTest(StrictVersionTestCase("test_StrictVersion___str__", version_string))

  # Test 2: Check that the following works as expected
  version_string = '1.2.3a1'
  suite.addTest(StrictVersionTestCase("test_StrictVersion___str__", version_string))

  # Test 3: Check that the following works as expected
  version_string = '1.2.3'
  suite.addTest(StrictVersionTestCase("test_StrictVersion___str__", version_string))

  # Additional tests can be added as needed.

 

# Generated at 2022-06-22 22:32:27.819025
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion()
    l.parse('0.960923')
    assert l.version == ['0', '960923']

# Generated at 2022-06-22 22:32:29.896586
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3a0')
    assert v.__str__() == '1.2.3a0'


# Generated at 2022-06-22 22:32:34.059093
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = StrictVersion("1.2.3a0")
    assert s.version == (1,2,3)
    assert s.prerelease == ('a', 0)


# Generated at 2022-06-22 22:32:39.954305
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # see issue #13012
    v = LooseVersion('1.1.1.1')
    assert repr(v) == "LooseVersion ('1.1.1.1')"

    v = LooseVersion('1.*.*.1')
    assert repr(v) == "LooseVersion ('1.*.*.1')"

# Utility functions -- not necessarily useful outside of this module
# The "looks like a version number" heuristic is mine :-) --Guido
