

# Generated at 2022-06-22 22:22:37.200390
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    class LV(LooseVersion):
        pass

    lv = LV('1.5.2')
    assert lv.version == (1, 5, 2), lv.version
    lv = LV(1.5)
    assert lv.version == (1, 5, 0), lv.version


test_LooseVersion()

# Generated at 2022-06-22 22:22:40.686021
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import pytest

    with pytest.raises(NotImplementedError, match="abstract method"):
        x = Version()
        x < 1

# Generated at 2022-06-22 22:22:44.338253
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    import distutils.version

    a = distutils.version.Version("1.2")
    if not str(a) == "1.2":
        raise AssertionError
    if not repr(a) == "Version ('1.2')":
        raise AssertionError

# Generated at 2022-06-22 22:22:46.339333
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    test_string = "LooseVersion ('%s')" % str(LooseVersion('1.2'))
    assert str(repr(LooseVersion('1.2'))) == test_string



# Generated at 2022-06-22 22:22:51.664118
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
   x = LooseVersion("1.2.3")
   assert(x.vstring == "1.2.3")
   assert(x.version == [1,2,3])
   x = LooseVersion("1.2b3")
   assert(x.vstring == "1.2b3")
   assert(x.version == [1,2,"b",3])
   x = LooseVersion("1_2.3a4")
   assert(x.vstring == "1_2.3a4")
   assert(x.version == [1,"2",3,"a",4])
   x = LooseVersion("1.2.3pre_4.5.6")
   assert(x.vstring == "1.2.3pre_4.5.6")

# Generated at 2022-06-22 22:22:54.032644
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = StrictVersion('1.2.3')
    v2 = StrictVersion('1.2.3')
    assert v1 < v2 is False


# Generated at 2022-06-22 22:23:01.848669
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    def test(o):
        print(o.__str__())
    sw = StrictVersion()
    e = sw.parse("0.4")
    test(sw)
    e = sw.parse("0.4.0")
    test(sw)
    e = sw.parse("0.4.1")
    test(sw)
    e = sw.parse("0.5a1")
    test(sw)
    e = sw.parse("0.5b3")
    test(sw)
    e = sw.parse("0.5")
    test(sw)
    e = sw.parse("0.9.6")
    test(sw)
    e = sw.parse("1.0")
    test(sw)
    e = sw.parse("1.0.4a3")

# Generated at 2022-06-22 22:23:09.632797
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion()
    v.parse("1.2.3")
    assert str(v) == "1.2.3"
    v.parse("1.2.3a2")
    assert str(v) == "1.2.3a2"
    v.parse("1.2")
    assert str(v) == "1.2"
    v.parse("1.2a3")
    assert str(v) == "1.2a3"


# Generated at 2022-06-22 22:23:13.406416
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    try:
        LooseVersion()
    except TypeError:
        pass
    else:
        raise AssertionError("%s didn't raise "
                             "TypeError for missing argument" %
                             LooseVersion)
#...

if __name__ == "__main__":
    test_LooseVersion()

# Generated at 2022-06-22 22:23:17.199955
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1.2a1').__repr__() == "LooseVersion ('1.2a1')"
"""Unit test for class LooseVersion"""
from pylint.lint import Run
from pylint.reporters import BaseReporter
from unittest import TestCase
from contextlib import contextmanager
from io import StringIO
from sys import getrefcount as grc

from distutils.version import LooseVersion

from pylint_plugin_utils.version import parse_version



# Generated at 2022-06-22 22:23:18.041935
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == None is NotImplemented

# Generated at 2022-06-22 22:23:20.151966
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version().__gt__(None) is NotImplemented
    assert Version().__gt__(NotImplemented) is NotImplemented
    assert not Version().__gt__(None)
    assert not Version().__gt__(NotImplemented)



# Generated at 2022-06-22 22:23:29.565193
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:23:33.427845
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert v._cmp('1.2.3') == 0
    assert v.__repr__() == "Version ('0')"
    assert v.__str__() == '0'


# Generated at 2022-06-22 22:23:35.362448
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "%s ('%s')" % ('Version', str(v)), repr(v)

# Generated at 2022-06-22 22:23:36.957976
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('')
    assert v.__le__('') is True
    return

# Generated at 2022-06-22 22:23:39.369429
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Version()
    assert repr(Version()) == "Version ('0')"
    # Version('a')
    assert repr(Version('a')) == "Version ('a')"

# Generated at 2022-06-22 22:23:51.973132
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
  sv = StrictVersion()
  sv.parse('0.4')
  assert (sv.version == (0, 4, 0))
  assert (sv.prerelease == None)
  sv.parse('0.4.0')
  assert (sv.version == (0, 4, 0))
  assert (sv.prerelease == None)
  sv.parse('0.4.1')
  assert (sv.version == (0, 4, 1))
  assert (sv.prerelease == None)
  sv.parse('0.5a1')
  assert (sv.version == (0, 5, 0))
  assert (sv.prerelease == ('a', 1))
  sv.parse('0.5b3')
  assert (sv.version == (0, 5, 0))

# Generated at 2022-06-22 22:23:53.829174
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert issubclass(set, object)
    assert not issubclass(set, int)


# Generated at 2022-06-22 22:23:58.054547
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass

    # No parameters
    # Return type: bool
    # Raises:
    #  - AttributeError


    # No parameters
    # Return type: bool
    # Raises:
    #  - AttributeError



# Generated at 2022-06-22 22:23:59.462616
# Unit test for constructor of class Version
def test_Version():
    x = Version('1.2.3')


# Generated at 2022-06-22 22:24:07.863474
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def check(vstring, parsed_tuple_version):
        result = LooseVersion(vstring)

# Generated at 2022-06-22 22:24:10.351766
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    VERSION = Version()
    assert VERSION == '1', 'Version.__eq__() should return True'

# Generated at 2022-06-22 22:24:11.674586
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1')
    assert v == '1'



# Generated at 2022-06-22 22:24:13.190886
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() < Version('1')


# Generated at 2022-06-22 22:24:24.917404
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    Version().__ge__(Version())
    Version('').__ge__(Version())
    Version('').__ge__(Version(''))
    Version('1').__ge__(Version('1'))
    Version('1').__ge__(Version('2'))
    Version('2').__ge__(Version('1'))
    Version('1.1').__ge__(Version('1.1'))
    Version('1.1').__ge__(Version('1.2'))
    Version('1.2').__ge__(Version('1.1'))
    Version('1.1.1').__ge__(Version('1.1.1'))
    Version('1.1.1').__ge__(Version('1.1.2'))

# Generated at 2022-06-22 22:24:27.573669
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    assert v1.__le__(v2) == True


# Generated at 2022-06-22 22:24:29.480409
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    try:
        assert False, "Unreachable"
    except NotImplementedError as e:
        pass

# Generated at 2022-06-22 22:24:34.354263
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    v = ('161','3.10a','8.02','3.4j','1996.07.12','3.2.pl0','3.1.1.6','2g6',
         '11g','0.960923','2.2beta29','1.13++','5.5.kw','2.0b1pl0')
    for i in range(len(v)):
        lv.parse(v[i])
        assert lv.vstring == v[i]

# Test the sorting of LooseVersion

# Generated at 2022-06-22 22:24:45.359478
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:24:49.253994
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import sys

    v = Version()
    if v < '2':
        assert sys.version_info < (3, 0)
    else:
        assert sys.version_info >= (3, 0)



# Generated at 2022-06-22 22:24:51.659955
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import unittest

    a = LooseVersion ("1.5.1")
    b = str (a)
    assert b == "1.5.1"


# Generated at 2022-06-22 22:24:54.455348
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.tests import support
    support.run_unittest(VersionTestCase)
from distutils.tests import support
import unittest

from distutils import version



# Generated at 2022-06-22 22:24:56.535059
# Unit test for constructor of class Version
def test_Version():
    assert Version("2.2a1")
    assert Version("123.456.7890")

# End of class Version



# Generated at 2022-06-22 22:24:59.157396
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert(repr(v) == "Version ('None')")

    v = Version("1")
    assert(repr(v) == "Version ('1')")


# Generated at 2022-06-22 22:25:03.692408
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import StrictVersion

    v = StrictVersion('1.0')
    assert not v < v

    # test for issue 8214
    assert v < StrictVersion(' 1.0')



# Generated at 2022-06-22 22:25:12.622516
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils2.version import Version
    from distutils2.version import LooseVersion
    from distutils2.version import StrictVersion

    v = Version()
    
    # This test cannot be written using assertLess because that function uses
    # __lt__.
    if not v.__lt__(LooseVersion('1.2.2')):
        raise AssertionError

    # This test cannot be written using assertLess because that function uses
    # __lt__.
    if not v.__lt__(StrictVersion('1.2.2')):
        raise AssertionError


# Generated at 2022-06-22 22:25:13.973070
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1')
    assert v == '1'


# Generated at 2022-06-22 22:25:20.311278
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    '''
    __gt__ should return True if the object is greater than other,
    and False if the object is less than or equal to other.
    '''
    test = Version('2')
    other = Version('1')
    assert test.__gt__(other) == True
    other = Version('2')
    assert test.__gt__(other) == False
    other = Version('3')
    assert test.__gt__(other) == False


# Generated at 2022-06-22 22:25:21.762217
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version() == False
    

# Generated at 2022-06-22 22:25:32.168425
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = StrictVersion('1')
    print (s)
    assert s.version == (1,)
    assert s.prerelease == None
    assert str(s) == '1'

    s = StrictVersion('1.2')
    print(s)
    assert s.version == (1, 2)
    assert s.prerelease == None
    assert str(s) == '1.2'

    s = StrictVersion('1.2.3')
    print(s)
    assert s.version == (1, 2, 3)
    assert s.prerelease == None
    assert str(s) == '1.2.3'

    s = StrictVersion('1.2a1')
    assert s.version == (1, 2)
    assert s.prerelease == ('a', 1)

# Generated at 2022-06-22 22:25:34.983886
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    __test_version(StrictVersion)


# Generated at 2022-06-22 22:25:44.021252
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:25:49.218923
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
  v = LooseVersion()
  v.parse ("1.0a")

  assert v.prerelease == ('a', 0), 'expected v.prerelease to be a, 0 not %s' % (v.prerelease)
  assert v.version == (1, 0, 0), 'expected v.version to be 1.0.0 not %s' % (v.version)

# Generated at 2022-06-22 22:25:52.361173
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    StrictVersion('1.3')
    StrictVersion('1.3.0')
    StrictVersion('1.3.0.post4')
    StrictVersion('1.3c1')
    StrictVersion(None)


# Generated at 2022-06-22 22:25:55.061511
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = StrictVersion('0.1')
    ret = version.__str__()
    assert ret == '0.1'


# Generated at 2022-06-22 22:26:05.464276
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring):
        version = StrictVersion(vstring)
        assert str(version) == vstring

    valid_versions = [
        "0.4",
        "0.4.0",
        "0.4.1",
        "0.5a1",
        "0.5b3",
        "0.5",
        "0.9.6",
        "1.0",
        "1.0.4a3",
        "1.0.4b1",
        "1.0.4"
    ]

    invalid_versions = [
        "1",
        "2.7.2.2",
        "1.3.a4",
        "1.3pl1",
        "1.3c4"
    ]


# Generated at 2022-06-22 22:26:17.624380
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('3.14')
    v2 = Version('3.1.4')
    v3 = Version('3.2')

    # v1 == v2 because they're equal (same string, same repr)
    if not (v1 == v2):
        return 'Failed test:  v1 = {} v2 = {}, expected == to return True'.format(v1, v2)

    # v2 == v2 because they're equal (same string, same repr)
    if not (v2 == v2):
        return 'Failed test:  v2 = {}, expected == to return True'.format(v2)

    # v1 != v3 because v1 < v3
    if v1 == v3:
        return 'Failed test:  v1 = {} v3 = {}, expected == to return False'.format

# Generated at 2022-06-22 22:26:26.106721
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import sys
    import test.test_support
    from test.test_support import run_unittest
    from test.test_support import import_module

    if import_module('cmd') is None:
        raise test.test_support.TestSkipped("cmd module required")

    # Test cmd.py's version_string()

    # if the major version is an even number, the 'commands' module
    # uses a different version string format.
    old_version_string = cmd.version_string
    if sys.version_info[0] % 2 == 1:
        cmd.version_string = lambda: (2, 1, 0, 'alpha', 0)
    else:
        cmd.version_string = lambda: '2.1a0'
    cmd.Cmd.version = "2.1.0"
    cmd.Cmd._

# Generated at 2022-06-22 22:26:28.797737
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Test method Version.__repr__"""
    v = Version('1.2.3')
    assert repr(v) == "Version ('1.2.3')"



# Generated at 2022-06-22 22:26:33.312764
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """
    Test the method that returns a string representation of a LooseVersion
    object.
    """
    assert eval(repr(LooseVersion('1.2.3.4dev.5'))) == LooseVersion('1.2.3.4dev.5')
    assert eval(repr(LooseVersion('1.2'))) == LooseVersion('1.2')


# Generated at 2022-06-22 22:26:34.882826
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__(None) == NotImplemented


# Generated at 2022-06-22 22:26:38.016827
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    test_instance = Version('0.0.1')
    expected_value = "Version ('0.0.1')"
    assert test_instance.__repr__() == expected_value


# Generated at 2022-06-22 22:26:46.666801
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = StrictVersion('1.0')
    assert str(version) == '1.0'
    version = StrictVersion('1.0.0.0')
    assert str(version) == '1.0'
    version = StrictVersion('1.0.4a3')
    assert str(version) == '1.0.4a3'
    version = StrictVersion('1.0pl1')
    assert str(version) == '1.0'

# Generated at 2022-06-22 22:26:51.368149
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """
    Test method __repr__ from class LooseVersion, with valid inputs
    """
    l = LooseVersion('1.1')
    assert repr(l) == "LooseVersion ('1.1')", \
        "Test Failed: Value expected 'LooseVersion ('1.1')', value returned : %s" % repr(l)

# Generated at 2022-06-22 22:26:54.212165
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    v3 = v1
    v4 = Version('n/a')
    result = v1._cmp(v2)
    expected = 0
    assert result == expected


# Generated at 2022-06-22 22:26:55.963676
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    vstring = "1.0"
    res = LooseVersion(vstring)
    assert res.__str__() == vstring

# Generated at 2022-06-22 22:27:06.579845
# Unit test for method __le__ of class Version
def test_Version___le__():
    tests = {
        # return None ...
        (
            # args
            Version, Version('')
        ): None,
        (
            # args
            Version, '1'
        ): None,
        (
            # args
            Version, b'1'
        ): None,
        (
            # args
            Version, ()
        ): None,
        (
            # args
            Version, []
        ): None,
        (
            # args
            Version, ['']
        ): None,
        (
            # args
            Version, {}
        ): None,
        (
            # args
            Version, {'1': '1'}
        ): None,
        (
            # args
            Version, object()
        ): None,
    }

# Generated at 2022-06-22 22:27:10.350090
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ver1 = Version(vstring='1.0')
    ver2 = Version(vstring='1.1')
    if not (ver1 < ver2):
        return False
    return True

# Generated at 2022-06-22 22:27:16.577011
# Unit test for method __le__ of class Version
def test_Version___le__():
   assert Version("1") <= Version("2")
   assert Version("2") >= Version("1")
   assert not (Version("2") <= Version("1"))
   assert not (Version("1") >= Version("2"))

# Generated at 2022-06-22 22:27:17.787820
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    Version()

# Generated at 2022-06-22 22:27:29.001102
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = '1.2.3rc1'
    ob = StrictVersion(s)
    assert ob.version == (1, 2, 3)
    assert ob.prerelease == ('rc', 1)

    with pytest.raises(ValueError):
        ob.parse('1.2.3.4')

    with pytest.raises(ValueError):
        ob.parse('1.2.2pl2')

    with pytest.raises(ValueError):
        ob.parse('1.2.3')

    with pytest.raises(ValueError):
        ob.parse('1.2')

    with pytest.raises(ValueError):
        ob.parse('a.b.c')



# Generated at 2022-06-22 22:27:39.037611
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    def check_version(vstring, version_info):
        lv = LooseVersion(vstring)
        assert(lv.version == version_info)
        assert(str(lv) == vstring)

    check_version('1.5.1', [1, '5', '1'])
    check_version('1.5.2b2', [1, '5', '2b2'])
    check_version('161', [161])
    check_version('3.10a', [3, '10a'])
    check_version('8.02', [8, '02'])
    check_version('3.4j', [3, '4j'])
    check_version('1996.07.12', [1996, '07', '12'])

# Generated at 2022-06-22 22:27:50.080954
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Test that each of the examples given in the class docstring
    # will compare equal (within LooseVersion) to a string version
    # of the same value.  The string version is the input to
    # LooseVersion.  The list of examples is embedded in the
    # docstring of the LooseVersion class, so we have to extract
    # it.
    # The regexp \w includes [a-zA-Z0-9_] but not '+' (which is legal
    # in a version string according to PEP 386), so '++' is not
    # included as a test, nor are several other examples (eg. '11g'
    # and '3.4j') because it seems unreasonable to expect them to
    # compare equal to '3.4j'.

    # test that we have the correct docstring
    found_doc

# Generated at 2022-06-22 22:27:58.582559
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert str(StrictVersion("1.19.23")) == "1.19.23"
    assert str(StrictVersion("2-1")) == "2"
    assert str(StrictVersion("3.3.3a3")) == "3.3.3a3"
    assert str(StrictVersion("1,2.3")) == "2.3"
    assert str(StrictVersion("1.2.3-alpha")) == "1.2.3"
    assert str(StrictVersion("1.2.3.alpha")) == "1.2.3"



# Generated at 2022-06-22 22:28:01.538557
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion("1.2.3.4")
    assert str(v) == "1.2.3.4"
    assert isinstance(str(v), str)


# Generated at 2022-06-22 22:28:04.180750
# Unit test for constructor of class Version
def test_Version():
    a = Version()
    b = Version(a)
    c = Version(str(a))
    assert a == b and a == c



# Generated at 2022-06-22 22:28:08.534057
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    r1 = LooseVersion('1.1').__repr__()
    assert(r1 == "LooseVersion ('1.1')")


# Generated at 2022-06-22 22:28:12.791156
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    fv = Version('2.8.3')
    assert repr(fv) == "Version ('2.8.3')"



# Generated at 2022-06-22 22:28:13.764832
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__(None) is NotImplemented

# Generated at 2022-06-22 22:28:25.757184
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # We simulate the "construction" of a StrictVersion class using:
        # class StrictVersion:
        #     pass
    # since we are only interested in testing the __str__ method
    # (the other methods are tested in other unit tests).
    input_list = []
    expected_list = []
    # The following are valid version numbers (shown in the order that
    # would be obtained by sorting according to the supplied cmp function):
    input_list.append([(0, 4, 0), None])
    expected_list.append("0.4")
    input_list.append([(0, 4, 0), None])
    expected_list.append("0.4")
    input_list.append([(0, 4, 1), None])
    expected_list.append("0.4.1")

# Generated at 2022-06-22 22:28:34.536047
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion('1') == StrictVersion('1.0')
    assert StrictVersion('1.0a1') == StrictVersion('1.0a1')
    assert StrictVersion('1.4.1') == StrictVersion('1.4.1')


# Interface for version-number classes -- must be implemented
# by the following classes (the concrete ones -- Version should
# be treated as an abstract class).
#    __init__ (string) - create and take same action as 'parse'
#                        (string parameter is optional)
#    parse (string)    - convert a string representation to whatever
#                        internal representation is appropriate for
#                        this style of version numbering
#    __str__ (self)    - convert back to a string; should be very similar
#                        (if not identical to) the string supplied to parse
#    __re

# Generated at 2022-06-22 22:28:44.369401
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring):
        version = StrictVersion(vstring)

# Generated at 2022-06-22 22:28:47.033719
# Unit test for method __le__ of class Version
def test_Version___le__():
    Version = Version
    version = Version("a")
    version._cmp = lambda x: 0
    assert version <= "a"


# Generated at 2022-06-22 22:28:49.057478
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("1.1.1")
    v2 = Version("1.1.2")
    assert v1 <= v2


# Generated at 2022-06-22 22:28:51.536464
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    s_ver = StrictVersion('1')
    assert (str(s_ver)) == '1'


# Generated at 2022-06-22 22:28:53.414543
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('abc')
    assert str(v) == 'abc'


# Generated at 2022-06-22 22:28:56.219773
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.2.3.4.5.6.7.8.9')
    assert str(v) == '1.2.3.4.5.6.7.8.9'
    v.parse('1.2.3')
    assert str(v) == '1.2.3'


# Generated at 2022-06-22 22:28:56.973324
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__(Version())

# Generated at 2022-06-22 22:29:06.656645
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    assert StrictVersion('10.0.0').version == (10, 0, 0)
    assert StrictVersion('10.0').version == (10, 0, 0)
    assert StrictVersion('10').version == (10, 0, 0)

    assert StrictVersion('10.0.0a1').version == (10, 0, 0)
    assert StrictVersion('10.0.0b1').version == (10, 0, 0)
    assert StrictVersion('10.0a1').version == (10, 0, 0)
    assert StrictVersion('10.0b1').version == (10, 0, 0)
    assert StrictVersion('10a1').version == (10, 0, 0)
    assert StrictVersion('10b1').version == (10, 0, 0)


# Generated at 2022-06-22 22:29:10.101533
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():

    lv = LooseVersion('1.0')
    assert repr(lv) == "LooseVersion ('1.0')"

    lv = LooseVersion()
    assert repr(lv) == "LooseVersion ('None')"



# Generated at 2022-06-22 22:29:11.788471
# Unit test for method __le__ of class Version
def test_Version___le__():
    a = Version('1.0')
    b = Version('1.0')
    return a <= b


# Generated at 2022-06-22 22:29:14.090729
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.0')
    assert repr(v) == "Version ('1.0')"


# Generated at 2022-06-22 22:29:17.732322
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"

    v = Version('2.1.0')
    assert repr(v) == "Version ('2.1.0')"

# Generated at 2022-06-22 22:29:26.492562
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def se(expected, vstring):
        if isinstance(expected, tuple):
            expected = StrictVersion(expected)
        actual = StrictVersion(vstring)
        assert actual == expected, "%s != %s" % (actual, expected)

    se("'1.0'", '1.0')
    se("'1.0'", '1.0.0')

    se("'0.0'", '0.0')
    se("'0.0'", '0.0.0')
    se("'0.0'", '0')

    se("'1.2'", '1.2')
    se("'1.2.0'", '1.2.0')
    se("'1.2.0'", '1.2')


# Generated at 2022-06-22 22:29:27.957298
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils2.version import Version
    s = Version()
    assert isinstance(s, Version)

# Generated at 2022-06-22 22:29:29.711186
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    a = Version()
    assert repr(a) == "Version ('None')"


# Generated at 2022-06-22 22:29:32.033160
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    run_test('StrictVersion___str__', str, [], {'self': StrictVersion('1.0.4b1')}, '1.0.4b1')


# Generated at 2022-06-22 22:29:36.199090
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # From issue #2311
    import random

    Version.__gt__(1, "2")
    Version.__gt__("1", 2)
    Version.__gt__("2", "1")
    Version.__gt__("2", 1)
    Version.__gt__(1, random.Random())
    Version.__gt__(1, "1")



# Generated at 2022-06-22 22:29:38.460073
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert(Version('1.2') < Version('1.9'))
    


# Generated at 2022-06-22 22:29:41.903806
# Unit test for constructor of class Version
def test_Version():
    try:
        Version()
    except Exception:
        return 0
    else:
        return 1

test_Version.__test__ = False # so this test won't be executed when we run the module


# Generated at 2022-06-22 22:29:49.819286
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion("8.4")
    lv_repr = repr(lv)
    lv2 = eval(lv_repr)

    assert type(lv2) is LooseVersion
    assert str(lv2) == "8.4"

if __name__=='__main__':
    test_LooseVersion___repr__()
# class Predicate(object):
#
#     """A callable object that will test some condition on the supplied
#     arguments.
#
#     The predicate must be a class of arity one, taking a single argument.
#     If the predicate is called with an argument that yields True, then the
#     call will yield True.  If the argument is False or evaluates to False,
#     then the predicate will yield False.
#
#     Examples:
#
#       >>> from

# Generated at 2022-06-22 22:29:52.505611
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Assert that 'if c is NotImplemented:' is false
    assert False

# Generated at 2022-06-22 22:30:02.146207
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version(vstring="1.9b4")
    assert(v1 >= "1.8b4")
    assert(not (v1 >= "1.8b5"))

    v2 = Version(vstring="1.8b5")
    v3 = Version(vstring="1.8b5")
    assert(v2 >= v3)
    assert(v2 >= "1.8b5")

    assert(not (v1 >= "1.9b5"))
    assert(not (v2 >= "1.9b5"))
    assert(not (v1 >= "1.10b3"))


# Generated at 2022-06-22 22:30:04.522800
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.2.3')
    assert repr(v) == "Version ('1.2.3')"


# Generated at 2022-06-22 22:30:06.218760
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert True

# Generated at 2022-06-22 22:30:09.709184
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version("1.2.3")
    assert v < "1.2.4"
    assert v < "1.3"
    assert v < "2"
    assert not v < "1.2.3"
    assert not v < "1.2"


# Generated at 2022-06-22 22:30:14.768990
# Unit test for constructor of class Version
def test_Version():
    assert Version('').__repr__() == "Version ('')"
    assert Version('  1.3.6.2a2 ').__repr__() == "Version ('1.3.6.2a2')"
    # Tests for rich comparison methods are required to be in the
    # concrete subclasses.


# Generated at 2022-06-22 22:30:23.102936
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    import unittest
    class LooseVersionTestCase(unittest.TestCase):
        def test_cmp(self):
            self.assertEqual(LooseVersion("1.5.1") < LooseVersion("1.6.0"), True)
            self.assertEqual(LooseVersion("1.5.1") > LooseVersion("1.6.0"), False)
            self.assertEqual(LooseVersion("1.5.1") == LooseVersion("1.6.0"), False)
            self.assertEqual(LooseVersion("1.6.0") > "1.6", True)
            self.assertEqual(LooseVersion("1.6.0") > "1.6.1", False)


# Generated at 2022-06-22 22:30:25.064897
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = StrictVersion("1.0")
    print("s: ", s.version)

# Generated at 2022-06-22 22:30:26.302049
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    if (True >= Version("1.0.0")):
        pass


# Generated at 2022-06-22 22:30:29.152326
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('1.2.3a4')
    assert repr(lv) == "LooseVersion ('1.2.3a4')"

# Generated at 2022-06-22 22:30:34.729540
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion("1.5.1")
    assert lv.version == [1, '5', '1']
    lv = LooseVersion("1.5.1post1")
    assert lv.version == [1, '5', '1', 'post', 1]
    lv = LooseVersion("1.5.1pre1")
    assert lv.version == [1, '5', '1', 'pre', 1]


# Generated at 2022-06-22 22:30:46.509990
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version

    # test that __eq__ works as expected
    eq(1, Version('1.0'))
    eq(1, str(Version('1.0')))
    eq(1, repr(Version('1.0')))

    # test that __lt__ works as expected
    ok_(Version('1.0') < Version('2.0'))
    ok_(Version('2.0b') < Version('2.0'))
    ok_(Version('2.0') < Version('2.0.0'))
    ok_(Version('2.0.0a') < Version('2.0.0'))
    ok_(Version('2.0') < Version('2.0pl2'))
    ok_(Version('2.0pl1') < Version('2.0pl2'))

# Generated at 2022-06-22 22:30:55.994696
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def compare_lists(list1, list2):
        if len(list1) != len(list2):
            return False
        for i in range(len(list1)):
            if not (list1[i] == list2[i]):
                return False
        return True
    s = StrictVersion('1.0.1')
    assert compare_lists(s.version, [1, 0, 1])
    assert s.prerelease == None
    s = StrictVersion('1.0.1a1')
    assert compare_lists(s.version, [1, 0, 1])
    assert s.prerelease == ('a', 1)
    s = StrictVersion('1.0.1b2')
    assert compare_lists(s.version, [1, 0, 1])

# Generated at 2022-06-22 22:30:59.449558
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version("1.2a").__repr__()
    assert v == "Version ('1.2a')"

# Generated at 2022-06-22 22:31:09.555328
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion("1")) == "1"
    assert str(StrictVersion("1.0")) == "1.0"
    assert str(StrictVersion("1.0.0")) == "1.0"
    assert str(StrictVersion("1.2")) == "1.2"
    assert str(StrictVersion("1.2.0")) == "1.2"
    assert str(StrictVersion("1.2.3")) == "1.2.3"
    assert str(StrictVersion("1.2a3")) == "1.2a3"
    assert str(StrictVersion("1.2.3")) == "1.2.3"
    # Missing patch level
    assert str(StrictVersion("1.2.3a4")) == "1.2.3a4"

# Generated at 2022-06-22 22:31:20.327771
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v.__eq__(True) is NotImplemented
    v = Version()
    assert v.__eq__(False) is NotImplemented
    v = Version()
    assert v.__eq__("True") is NotImplemented
    v = Version()
    assert v.__eq__("False") is NotImplemented
    v = Version()
    assert v.__eq__("") is NotImplemented
    v = Version()
    assert v.__eq__(" ") is NotImplemented
    v = Version()
    assert v.__eq__("3") is NotImplemented
    v = Version()
    assert v.__eq__("1.0") is NotImplemented
    v = Version()
    assert v.__eq__("1.1") is NotImple

# Generated at 2022-06-22 22:31:23.109536
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version('1.2.3') > '1.2.2'


# Generated at 2022-06-22 22:31:33.117760
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring):
        v = StrictVersion(vstring)
        print(v, '==', vstring)
        assert (str(v) == vstring), '%s != %s' % (str(v), vstring)

    test('0.4')
    test('0.4.0')
    test('0.4.1')
    test('0.5a1')
    test('0.5b3')
    test('0.5')
    test('0.9.6')
    test('1.0')
    test('1.0.4a3')
    test('1.0.4b1')
    test('1.0.4')



# Generated at 2022-06-22 22:31:35.183467
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils2.version import Version
    v = Version('')
    assert v >= 1 



# Generated at 2022-06-22 22:31:46.476272
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    import pytest
    v1 = Version('1.1')
    assert isinstance(v1,Version)

    assert v1 >= '1.0'
    assert not v1 >= '1.2'
    assert v1 >= v1

    class Test(Version):
        Version.version_re = r'\s*(\w+)'
        Version.component_re = r'(\w+)'
        Version.version_re_flags = 0
        def parse(self, vstring):
            m = self.component_regex.match(vstring)
            if not m:
                raise ValueError("invalid version number '{}'".format(vstring))
            components = m.groups()
            (version,) = components
            self.version = version

# Generated at 2022-06-22 22:31:55.162892
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    string = 'Version ("%s")' % '1.2.3'
    assert str(Version("1.2.3") >= "1.5") == string
    assert str(Version("1.1.3") >= "1.2.3") == string
    assert str(Version("1.2.3") >= "1.2") == string
    assert str(Version("1.2.3") >= "1.2.3") == string
    assert str(Version("1.2.3") >= Version("1.2.3")) == string

    assert str(Version("1.2.3") >= "1.5") == string
    assert str(Version("1.1.3") >= "1.2.3") == string
    assert str(Version("1.2.3") >= "1.2") == string
    assert str

# Generated at 2022-06-22 22:32:06.077042
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    """Simple unit test for LooseVersion constructor"""
    assert LooseVersion('1.23.45') == LooseVersion('1.23.45')
    assert LooseVersion('1.23.45') < LooseVersion('1.23.45.6')
    assert LooseVersion('1.23.45') < LooseVersion('1.23.45.6')
    assert LooseVersion('1.23.45.6') < LooseVersion('1.23.45.7')
    assert LooseVersion('1.23.45') < LooseVersion('1.23.46')
    assert LooseVersion('1.23.45') < LooseVersion('1.24.45')
    assert LooseVersion('1.23') < LooseVersion('1.23.45')

# Generated at 2022-06-22 22:32:15.921327
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('5')
    assert v.version == (5,0,0)
    assert v.prerelease == None

    v = StrictVersion('1.2')
    assert v.version == (1,2,0)
    assert v.prerelease == None

    v = StrictVersion('1.2.3')
    assert v.version == (1,2,3)
    assert v.prerelease == None

    v = StrictVersion('1.2a3')
    assert v.version == (1,2,0)
    assert v.prerelease == ('a',3)

    v = StrictVersion('1.2.3a4')
    assert v.version == (1,2,3)
    assert v.prerelease == ('a',4)


# Generated at 2022-06-22 22:32:25.373139
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.2.3.4')
    assert lv.version == [1, 2, 3, 4]
    lv.parse('1.2a3')
    assert lv.version == [1, 2, 'a', 3]
    lv.parse('1.2.pl3')
    assert lv.version == [1, 2, 'pl', 3]
    lv.parse('1.2pl3')
    assert lv.version == [1, 2, 'pl', 3]
    lv.parse('1.2.3')
    assert lv.version == [1, 2, 3]
    lv.parse('1.2')
    assert lv.version == [1, 2]
    lv.parse('1.2')
   

# Generated at 2022-06-22 22:32:28.162646
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    ver = LooseVersion()
    ver.parse("1.2.2")
    r = repr(ver)
    assert r == "LooseVersion ('1.2.2')"



# Generated at 2022-06-22 22:32:29.021554
# Unit test for method __le__ of class Version
def test_Version___le__():
    Version()

# Generated at 2022-06-22 22:32:31.564249
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.0.0')
    assert not v <= '0.0.0'

# Generated at 2022-06-22 22:32:34.110841
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version("1.2")
    assert v == Version("1.2")

