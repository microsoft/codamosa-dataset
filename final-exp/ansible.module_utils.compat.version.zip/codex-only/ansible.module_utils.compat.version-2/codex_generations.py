

# Generated at 2022-06-22 22:22:44.862044
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Simple constructor test
    v = StrictVersion("1.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease == None
    assert str(v) == "1.0"

    # Test pre-release version parsing
    v = StrictVersion("1.0a1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    # Test more complicated pre-release version parsing
    v = StrictVersion("1.0.1b2")
    assert v.version == (1, 0, 1)
    assert v.prerelease == ('b', 2)

    # Test some invalid version numbers
    try:
        v = StrictVersion("1.0.1.0")
    except ValueError:
        pass

# Generated at 2022-06-22 22:22:46.396323
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version(vstring="123")
    assert((v > "124") == False), "Value is %r" % repr(v)

# Generated at 2022-06-22 22:22:49.493156
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    raise NotImplementedError("TODO: Write unit tests for this class")

# Generated at 2022-06-22 22:22:58.493558
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion()
    l.parse('1.2.2')
    l.parse('1.2')
    l.parse('1.2.2b2')
    l.parse('161')
    l.parse('3.10a')
    l.parse('8.02')
    l.parse('3.4j')
    l.parse('1996.07.12')
    l.parse('3.2.pl0')
    l.parse('3.1.1.6')
    l.parse('2g6')
    l.parse('11g')
    l.parse('0.960923')
    l.parse('2.2beta29')
    l.parse('1.13++')
    l.parse('5.5.kw')

# Generated at 2022-06-22 22:23:01.204358
# Unit test for constructor of class Version
def test_Version():
    v = Version('1')
    assert str(v) == '1'


# Generated at 2022-06-22 22:23:12.397506
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Test valid "StrictVersion" input
    version = StrictVersion("0")
    assert str(version) == "0", "StrictVersion \"0\""
    version = StrictVersion("0.0")
    assert str(version) == "0.0", "StrictVersion \"0.0\""
    version = StrictVersion("0.0.0")
    assert str(version) == "0.0.0", "StrictVersion \"0.0.0\""
    version = StrictVersion("10.1")
    assert str(version) == "10.1", "StrictVersion \"10.1\""
    version = StrictVersion("10.1.1")
    assert str(version) == "10.1.1", "StrictVersion \"10.1.1\""

# Generated at 2022-06-22 22:23:24.575212
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:23:28.881685
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"
    v = Version("1.2.3")
    assert repr(v) == "Version ('1.2.3')"


# Generated at 2022-06-22 22:23:33.565306
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Test of version numbering classes
    v1 = Version()
    v2 = Version()
    #print(v1, v2, v1 < v2, v1 == v2, v1 > v2)
    assert v1 < v2 and not v1 == v2 and not v1 > v2


# Generated at 2022-06-22 22:23:42.057513
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import unittest
    import sys

    class TestCase(unittest.TestCase):
        def test(self, version, parsed_tuple):
            v = LooseVersion(version)
            self.assertEqual(v.version, parsed_tuple,
                             "Failed to parse %s as %s"
                             % (version, parsed_tuple))
            # Make sure the string round-trips
            self.assertEqual(str(v), version)

        def test_simple_numeric(self):
            self.test("1.0", (1, 0))
            self.test("1.0.0", (1, 0, 0))
            self.test("1.2.3.4.5.6.7", (1, 2, 3, 4, 5, 6, 7))


# Generated at 2022-06-22 22:23:43.587610
# Unit test for method __le__ of class Version
def test_Version___le__():
    # No docstring for this method
    pass

# Generated at 2022-06-22 22:23:45.670263
# Unit test for constructor of class Version
def test_Version():
    assert str(Version('1.2.3')) == '1.2.3'


# Generated at 2022-06-22 22:23:53.665018
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Unit test for method __gt__ of class Version"""

    class A(Version):
        def __init__(self, s):
            self.s = s
        def __str__(self):
            return self.s
        def parse(self, s):
            pass
        def _cmp(self, other):
            return NotImplemented

    # Test with a true value
    assert (A('a') > 'b')

    # Test with a false value
    assert not (A('a') > 'a')


# Generated at 2022-06-22 22:24:04.657296
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion

# Generated at 2022-06-22 22:24:06.459587
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('0.4.0').__str__() == '0.4.0'


# Generated at 2022-06-22 22:24:15.579911
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    eq = assertEqual
    lv = LooseVersion

    # Some valid version number strings
    eq(lv('1.5.1'), ('1', '5', '1'))
    eq(lv('1.5.2b2'), ('1', '5', '2b2'))
    eq(lv('161'), ('161',))
    eq(lv('3.10a'), ('3', '10a'))
    eq(lv('8.02'), ('8', '02'))
    eq(lv('3.4j'), ('3', '4j'))
    eq(lv('1996.07.12'), ('1996', '07', '12'))
    eq(lv('3.2.pl0'), ('3', '2', 'pl0'))

# Generated at 2022-06-22 22:24:21.164271
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion("1.3.3a2")
    assert lv.version == [1, 3, 3, "a", 2]
    assert str(lv) == "1.3.3a2"
    assert repr(lv) == "LooseVersion ('1.3.3a2')"



# Generated at 2022-06-22 22:24:30.753659
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    old_version = LooseVersion("1.6.22")
    import sys
    new_version = sys.version
    new_version = LooseVersion(new_version)
    if old_version.parse(new_version):
        c = old_version._cmp(new_version)

# Generated at 2022-06-22 22:24:32.304918
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2

# Generated at 2022-06-22 22:24:36.254910
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version().__repr__() == "Version ('0')"
    assert Version('1').__repr__() == "Version ('1')"
    assert Version('').__repr__() == "Version ('')"
    assert Version('1.2.3').__repr__() == "Version ('1.2.3')"
    assert Version('').__repr__() == "Version ('')"

# Generated at 2022-06-22 22:24:40.524728
# Unit test for constructor of class Version
def test_Version():
    # Make sure that the repr() of the version matches the class name
    # and the version string.
    global Version
    assert repr(Version('1.2.3')) == "Version ('1.2.3')"


# Generated at 2022-06-22 22:24:46.387053
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"
test_LooseVersion___repr__()


# In order to allow the end-user developer to specify the compare function
# they want to use, we need to work around the fact that unittest.TestCase.assertRaises
# can only be used in a 'with' block.
# So we use a wrapper around unittest.TestCase.assertRaisesRegexp which provides
# an assertRaises method which can be used in a 'with' block.

# Generated at 2022-06-22 22:24:48.938740
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion("1.2a2")
    assert str(v) == "1.2a2"


# Generated at 2022-06-22 22:24:50.736371
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert v.__repr__() == "Version ('0')"


# Generated at 2022-06-22 22:24:58.139204
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion(1) == LooseVersion("1")
    assert LooseVersion(1) == LooseVersion("1.0")
    assert LooseVersion(1) == LooseVersion("1.0.0")
    assert LooseVersion(0) == LooseVersion("0.0")
    assert LooseVersion(1) > LooseVersion("0")
    assert LooseVersion(1) > LooseVersion("0.0")
    assert LooseVersion(1) > LooseVersion("0.0.0")
    assert LooseVersion(0) < LooseVersion("1")
    assert LooseVersion(0) < LooseVersion("1.0")
    assert LooseVersion(0) < LooseVersion("1.0.0")



# Generated at 2022-06-22 22:25:01.037941
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # assert isinstance(Version().__ge__(), bool)
    pass


# Generated at 2022-06-22 22:25:02.579004
# Unit test for constructor of class Version
def test_Version():
    V = Version
    v = V('1.2.3')



# Generated at 2022-06-22 22:25:13.427779
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    import unittest

    class TestStrictVersion(unittest.TestCase):
        def test_constructor(self):
            str(StrictVersion("1.2.3"))
            str(StrictVersion("1.2.3a1"))
            str(StrictVersion("1.2.3b1"))
            str(StrictVersion("1.2.3.dev1"))
            str(StrictVersion("1.2.3.a1"))
            str(StrictVersion("1.2.3.b1"))
            str(StrictVersion("1.2.3.dev1"))

            StrictVersion("1.2.3")
            StrictVersion("1.2.3a1")
            StrictVersion("1.2.3b1")
            StrictVersion("1.2.3.dev1")

# Generated at 2022-06-22 22:25:16.473935
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Issue #3319: Broken on 2.2 with -O
    v1 = Version('1')
    v2 = Version('2')
    assert v1 != v2

# Generated at 2022-06-22 22:25:22.611228
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    s = StrictVersion('1.2.3')
    assert s < '1.2.4'
    assert s <= '1.2.4'
    assert '1.2.4' > s
    assert '1.2.4' >= s
    assert not (s >= '1.2.4')
    assert not (s > '1.2.4')
    assert not ('1.2.4' < s)
    assert not ('1.2.4' <= s)



# Generated at 2022-06-22 22:25:25.660418
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version().__repr__() == "Version ('0')"



# Generated at 2022-06-22 22:25:29.776633
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils2.version import Version
    from distutils2.compat import StringIO
    class TestVersion(Version):
        def __init__(self, vstring=None): pass
        def parse(self, vstring): pass
        def _cmp(self, other): return 0
    v1 = TestVersion()
    v2 = TestVersion()
    assert (v1 > v2) == True

# Generated at 2022-06-22 22:25:31.970478
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('2.6.4')
    assert lv.__str__() == '2.6.4'



# Generated at 2022-06-22 22:25:35.201222
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"

# Generated at 2022-06-22 22:25:37.887552
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('1.2.3a4.5').__str__() == '1.2.3a4.5'


# Generated at 2022-06-22 22:25:45.215633
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:25:47.547506
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import LooseVersion

    assert LooseVersion('1.9.1') <= LooseVersion('1.9.1a1')



# Generated at 2022-06-22 22:25:54.593184
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert str(v) == ""
    assert repr(v) == "Version ('')"

    w = Version("")
    assert v == w

    x = Version('0.4a3')
    assert str(x) == '0.4a3'
    y = Version(str(x))
    assert x == y

    x = Version('1.5.1 (cvs 1.5.1-1)')
    assert str(x) == '1.5.1 (cvs 1.5.1-1)'
    y = Version(str(x))
    assert x == y



# Generated at 2022-06-22 22:26:05.234785
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    inst = StrictVersion('0.4')
    assert inst.__str__() == '0.4'

    inst = StrictVersion('0.4.0')
    assert inst.__str__() == '0.4.0'

    inst = StrictVersion('0.5a1')
    assert inst.__str__() == '0.5a1'

    inst = StrictVersion('0.5b3')
    assert inst.__str__() == '0.5b3'

    inst = StrictVersion('0.5')
    assert inst.__str__() == '0.5'

    inst = StrictVersion('0.9.6')
    assert inst.__str__() == '0.9.6'

    inst = StrictVersion('1.0')

# Generated at 2022-06-22 22:26:10.786155
# Unit test for constructor of class Version
def test_Version():
    for vstring in ['1.2.3', '1.2.3-pre+alpha', '1.2.3+alpha', '1.2.3+']:
        assert Version(vstring).__repr__() == "Version ('%s')" % vstring


# test if version is a valid version string according to PEP 440

# Generated at 2022-06-22 22:26:20.008531
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.2").__str__() == "1.2"
    assert StrictVersion("1.2.3").__str__() == "1.2.3"
    assert StrictVersion("1.2a3").__str__() == "1.2a3"
    assert StrictVersion("1.2b3").__str__() == "1.2b3"
    assert StrictVersion("1.2.3a3").__str__() == "1.2.3a3"
    assert StrictVersion("1.2.3b3").__str__() == "1.2.3b3"


# Generated at 2022-06-22 22:26:23.884920
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # Returns a string representation
    v1 = LooseVersion ('1.2.3')
    v2 = LooseVersion ('2.3.4.5')
    assert repr(v1) == "LooseVersion ('1.2.3')"
    assert repr(v2) == "LooseVersion ('2.3.4.5')"

# Generated at 2022-06-22 22:26:27.292838
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version().__lt__(0) == NotImplemented
    assert Version().__lt__(Version()) == NotImplemented
    assert Version().__lt__('0') == NotImplemented


# Generated at 2022-06-22 22:26:30.677901
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    cases = ["1.4.1", "1.5a3", "1.5.3b2", "161", "3.10a", "8.02"]
    for c in cases:
        StrictVersion(c)
    raise test_StrictVersion



# Generated at 2022-06-22 22:26:41.084253
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import sys

    print("Testing __str__")
    v = StrictVersion("1.2.3")
    assert str(v) == "1.2.3"

    v = StrictVersion("1.2")
    assert str(v) == "1.2"

    v = StrictVersion("1.2.3.dev456")
    assert str(v) == "1.2.3.dev456"

    v = StrictVersion("1.2.3a4")
    assert str(v) == "1.2.3a4"

    try:
        StrictVersion("1.2.3.dev456")._cmp("1.2.3.dev456")
    except NameError:
        pass
    else:
        assert False, "Failed test_StrictVersion___str__."

# Unit

# Generated at 2022-06-22 22:26:44.776989
# Unit test for constructor of class Version
def test_Version():
    for v in ["0", "1.2", "1.2.3.4"]:
        assert Version(v)._cmp(Version(v)) == 0


# Generated at 2022-06-22 22:26:56.834538
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    for version in ('1.5.1', '161', '1.5.1.2.dev456', '1.5.1.2a3',
                    '1.5.1.2b1', '1.5.1.2c4', '1.5.1.2rc1', '1.5.1.2', '1.5.1.2.r32',
                    '1.5.1.2.r32.42.123.456', '0.960923', '2.2beta29', '1.13++',
                    '5.5.kw'):
        v = LooseVersion(version)
        assert v.version == version

    # Make sure that it blows up on things that we don't handle.
    # (See LooseVersion.__init__ and LooseVersion.parse.)  In

# Generated at 2022-06-22 22:27:07.262270
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
        sv = StrictVersion()
        sv.parse("1.2")
        assert sv.version == (1,2,0)
        assert sv.prerelease is None
        sv.parse("1.2.0")
        assert sv.version == (1,2,0)
        assert sv.prerelease is None
        sv.parse("1.2a")
        assert sv.version == (1,2,0)
        assert sv.prerelease == ('a', 0)
        sv.parse("1.2b")
        assert sv.version == (1,2,0)
        assert sv.prerelease == ('b', 0)
        sv.parse("1.2a0")
        assert sv.version == (1,2,0)
        assert sv.prerelease == ('a', 0)

# Generated at 2022-06-22 22:27:08.936438
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    pass


# Generated at 2022-06-22 22:27:11.337499
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import StrictVersion
    s = StrictVersion('1.2.3')
    assert s.__lt__('1.2.3') == False

# Generated at 2022-06-22 22:27:15.796675
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version(vstring="1.2b")
    v2 = Version(vstring="1.2.1")
    assert v1 < v2



# Generated at 2022-06-22 22:27:17.213642
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version()
    version.__lt__(1)



# Generated at 2022-06-22 22:27:29.340148
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
  lv = distutils.version.LooseVersion("1.2.3a")
  assert_equal(str(lv), "1.2.3a", "LooseVersion: Bad string representation")
  lv = distutils.version.LooseVersion("1.3.3a")
  assert_equal(str(lv), "1.3.3a", "LooseVersion: Bad string representation")
  lv = distutils.version.LooseVersion("1.4.3a")
  assert_equal(str(lv), "1.4.3a", "LooseVersion: Bad string representation")
  lv = distutils.version.LooseVersion("1.5.3a")
  assert_equal(str(lv), "1.5.3a", "LooseVersion: Bad string representation")

# Generated at 2022-06-22 22:27:32.424069
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion ('1.2.3')
    assert v.__repr__() == "LooseVersion ('1.2.3')"


# Generated at 2022-06-22 22:27:35.007474
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Test for the representation of a Version object."""
    version = Version('')
    assert repr(version), "Version ('%s')"


# Generated at 2022-06-22 22:27:39.346543
# Unit test for method __le__ of class Version
def test_Version___le__():
    # This test fails because we have not yet implemented the __le__ method.
    # Once you have implemented the __le__ method, this test should pass.
    v1 = Version('0.0')
    v2 = Version('1.0')
    assert v1.__le__(v2)
    assert v1.__le__('1.0')

# Generated at 2022-06-22 22:27:50.003520
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """__repr__(self)"""
    v = LooseVersion('1')
    assert repr(v) == "LooseVersion ('1')"

    v = LooseVersion('1.2')
    assert repr(v) == "LooseVersion ('1.2')"

    v = LooseVersion('1.2dev')
    assert repr(v) == "LooseVersion ('1.2dev')"

    v = LooseVersion('1.2.3.4')
    assert repr(v) == "LooseVersion ('1.2.3.4')"

    v = LooseVersion('1.2.3.4a5')
    assert repr(v) == "LooseVersion ('1.2.3.4a5')"


# Generated at 2022-06-22 22:28:01.397523
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("0.4").__str__() == "0.4"
    assert StrictVersion("0.4.1").__str__() == "0.4.1"
    assert StrictVersion("0.5a1").__str__() == "0.5a1"
    assert StrictVersion("0.5b3").__str__() == "0.5b3"
    assert StrictVersion("0.9.6").__str__() == "0.9.6"
    assert StrictVersion("1.0").__str__() == "1.0"
    assert StrictVersion("1.0.4a3").__str__() == "1.0.4a3"
    assert StrictVersion("1.0.4b1").__str__() == "1.0.4b1"

# Generated at 2022-06-22 22:28:10.377604
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    def check(got, expected):
        try:
            assert got == expected
        except AssertionError as e:
            raise AssertionError("%s != %s" % (got, expected))

    check(Version("1.1").__gt__("1.2"), False)
    check(Version("1.2").__gt__("1.1"), True)
    check(Version("1.1").__gt__("1.1"), False)
    check(Version("a").__gt__("b"), NotImplemented)



# Generated at 2022-06-22 22:28:18.890772
# Unit test for method __str__ of class StrictVersion

# Generated at 2022-06-22 22:28:28.354558
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('0.4').__str__() == '0.4', repr(StrictVersion('0.4').__str__())
    assert StrictVersion('0.4.0').__str__() == '0.4.0', repr(StrictVersion('0.4.0').__str__())
    assert StrictVersion('0.4.1').__str__() == '0.4.1', repr(StrictVersion('0.4.1').__str__())
    assert StrictVersion('0.5a1').__str__() == '0.5a1', repr(StrictVersion('0.5a1').__str__())
    assert StrictVersion('0.5b3').__str__() == '0.5b3', repr(StrictVersion('0.5b3').__str__())


# Generated at 2022-06-22 22:28:39.904944
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version('4.4.1')
    assert v >= '4.4.1'
    assert not v >= '4.4.2'
    assert not v >= '4.5.0'
    assert v >= '4.4'
    assert v >= '4.4.1.a.post7'
    assert v >= '4.4.1.a.post7.dev1'
    assert v >= '4.4dev'

    v = Version('4.4.1.a')
    assert v >= '4.4.1'
    assert not v >= '4.4.2'
    assert not v >= '4.5.0'
    assert v >= '4.4'
    assert v >= '4.4.1.a'

# Generated at 2022-06-22 22:28:42.392236
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.2.3')
    assert repr(v) == "Version ('1.2.3')"


# Generated at 2022-06-22 22:28:53.808094
# Unit test for method __str__ of class LooseVersion

# Generated at 2022-06-22 22:28:56.846904
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    version = StrictVersion("1.2.3")
    assert version.version == (1, 2, 3)
    assert version.prerelease is None

    version = StrictVersion("1.2.3a4")
    assert version.prerelease == ("a", 4)



# Generated at 2022-06-22 22:28:58.030649
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    # No exception raised
    v == '2.0.0'


# Generated at 2022-06-22 22:28:59.133398
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('1') == '1'

# end class LooseVersion



# Generated at 2022-06-22 22:29:01.363036
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version("1.0").__repr__() == "Version ('1.0')"
    

# Generated at 2022-06-22 22:29:07.279634
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    import unittest
    import sys
    class Version___repr__(unittest.TestCase):
        """Test for Version.__repr__()"""
        def test_Version___repr__(self):
            v = Version("1.4.4")
            self.assertEqual(repr(v), "'1.4.4'")
    tests = Version___repr__()
    suite = unittest.TestLoader().loadTestsFromModule(tests)
    unittest.TextTestRunner(verbosity=2, stream=sys.stderr).run(suite)


# Generated at 2022-06-22 22:29:18.538832
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('abc') > LooseVersion('aabb')
    assert LooseVersion('abc') == LooseVersion('aabb',3)
    assert LooseVersion('abc') < LooseVersion('aabb',4)
    assert LooseVersion('a') < LooseVersion('b')
    assert LooseVersion('0.9') < LooseVersion('1.0')
    assert LooseVersion('1.2') < LooseVersion('1.2.1')
    assert LooseVersion('1.2.1') < LooseVersion('1.2.2')
    assert LooseVersion('1.2.1') < LooseVersion('1.2.1.0')
    assert LooseVersion(' 01.2.3 ') == LooseVersion('     1.2.3')

# Generated at 2022-06-22 22:29:21.515317
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """
    Unit test for method __ge__ of class Version
    """
    v = Version()
    res = v.__ge__(100)
    assert type(res) == bool

# Generated at 2022-06-22 22:29:24.917630
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3')

    assert str(v) == '1.2.3'
    assert repr(v) == "Version ('1.2.3')"


# Create concrete version numbering classes


# Generated at 2022-06-22 22:29:27.084249
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    obj_Version = Version()
    assert obj_Version.__gt__() == NotImplemented



# Generated at 2022-06-22 22:29:31.897790
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """
    Test method __lt__ of class Version
    """
    v1 = Version('1.1')
    v2 = Version('2.2')
    assert v1 < v2
    return



# Generated at 2022-06-22 22:29:40.025356
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    from test import support

    import sys
    import unittest
    from copy import copy as _copy
    from test.support import run_unittest

    class LooseVersionTestCase(unittest.TestCase):
        def assert_parsing(self, input, result):
            self.assertEqual(str(LooseVersion(input)), result)
        def test_equality(self):
            self.assertEqual(LooseVersion('1.2.0'), LooseVersion('1.2'))
            self.assertEqual(LooseVersion('1.2'), LooseVersion('1.2.0'))
            self.assertNotEqual(LooseVersion('1.2'), LooseVersion('1.2.1'))

# Generated at 2022-06-22 22:29:41.853960
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    instance = Version()
    assert isinstance(instance.__ge__(instance), bool)

# Generated at 2022-06-22 22:29:45.590055
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """
    A LooseVersion instance shall return a string representation of the
    version number when the method __str__ is called.
    """
    loose = LooseVersion()
    loose.parse('1.2.3')
    assert str(loose) == '1.2.3'


# Generated at 2022-06-22 22:29:53.710581
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    import pickle
    class Version___gt__Tests(unittest.TestCase):
        def test__Version___gt__(self):
            self.assertTrue(Version("1.0") > Version("1.0.post1"))
            self.assertTrue(Version("1.0") > Version("1.0rc1"))
            self.assertTrue(Version("1.0") > Version("1.0c1"))
            self.assertFalse(Version("1.0") > Version("1.0"))
            self.assertFalse(Version("1.0.post1") > Version("1.0"))
            self.assertFalse(Version("1.0rc1") > Version("1.0"))
            self.assertFalse(Version("1.0c1") > Version("1.0"))
            self.assertFalse

# Generated at 2022-06-22 22:30:03.739631
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    cases = [
        '1.2.3',
        '0.0.0',
        '1.2',
        '0.0',
        '1.2.3.4',
        'a.b.c',
        '12',
        '11.1.1b1',
        '0.0.0.1.2.3',
        '0.0.0.1',
        '1.0a1',
        '1.0b2',
        '1.0c2',
        '1.0rc2',
        '1.0',
    ]

    for case in cases:
        StrictVersion(case)

# Generated at 2022-06-22 22:30:13.306311
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """Test function for LooseVersion.__repr__"""
    assert LooseVersion().__repr__() == "LooseVersion ('')"
    assert LooseVersion('1.0').__repr__() == "LooseVersion ('1.0')"
    assert LooseVersion('1.0.0').__repr__() == "LooseVersion ('1.0.0')"
    assert LooseVersion('1.0.0.0').__repr__() == "LooseVersion ('1.0.0.0')"
    assert LooseVersion('1.0-alpha').__repr__() == "LooseVersion ('1.0-alpha')"
    assert LooseVersion('1.0-alpha.1').__repr__() == "LooseVersion ('1.0-alpha.1')"
    assert LooseVersion

# Generated at 2022-06-22 22:30:20.368833
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v1 = LooseVersion('1.1.1')
    v2 = LooseVersion('2.2.2')
    assert v1 != v2, "v1 (%s) and v2 (%s) should be different" % (v1, v2)
    assert repr(v1) == "LooseVersion ('1.1.1')"
    assert repr(v2) == "LooseVersion ('2.2.2')"


# Generated at 2022-06-22 22:30:29.460464
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    #
    # This test is incomplete
    #

    # Test some basic comparisons that should work
    lv = LooseVersion

# Generated at 2022-06-22 22:30:37.632905
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """Test method __str__ of class LooseVersion"""
    v1 = LooseVersion('1.0')
    assert(v1.__str__() == '1.0')
    v2 = LooseVersion('1.2.3')
    assert(v2.__str__() == '1.2.3')
    v3 = LooseVersion('a1.b2.c3')
    assert(v3.__str__() == 'a1.b2.c3')
    v4 = LooseVersion('1.2.3dev')
    assert(v4.__str__() == '1.2.3dev')
    v5 = LooseVersion("1.2.3.4")
    assert(v5.__str__() == '1.2.3.4')


# Generated at 2022-06-22 22:30:44.735121
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Unit test for method __le__ of class Version"""

    v = Version()
    v._cmp = lambda x: 0
    assert(v <= "string")
    v._cmp = lambda x: 1
    assert(not (v <= "string"))
    v._cmp = lambda x: -1
    assert(v <= "string")

    class Object:
        def __le__(self, other): return True
    assert(v <= Object())
# end unit test for method __le__ of class Version


# Generated at 2022-06-22 22:30:54.163891
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert v._cmp("1") == -1
    assert repr(v) == "Version ('0')"
    v = Version("1")
    assert v._cmp("1") == 0
    assert repr(v) == "Version ('1')"
    v = Version("1.2")
    assert v._cmp("1.1") == 1
    assert v._cmp("1.2") == 0
    assert v._cmp("1.2.1") == -1
    assert v._cmp("1.3") == -1
    assert v._cmp("2.0") == -1
test_Version.test = True



# Generated at 2022-06-22 22:31:06.627502
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    strict_version = StrictVersion()
    assert(strict_version.version == (0, 0, 0))
    assert(strict_version.prerelease == None)

    strict_version.parse("0.4")
    assert(strict_version.version == (0, 4, 0))
    assert(strict_version.prerelease == None)

    strict_version.parse("0.4.1")
    assert(strict_version.version == (0, 4, 1))
    assert(strict_version.prerelease == None)

    strict_version.parse("0.5a1")
    assert(strict_version.version == (0, 5, 0))
    assert(strict_version.prerelease == ('a', 1))

    strict_version.parse("0.5b3")

# Generated at 2022-06-22 22:31:10.551049
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    import datetime
    import pytest
    from rikerbot.api.version import Version

    v = Version()
    assert v.__repr__() == "Version ('None')"


# Generated at 2022-06-22 22:31:12.427970
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.0')
    assert repr(v) == "Version ('1.0')"


# Generated at 2022-06-22 22:31:19.709412
# Unit test for constructor of class Version
def test_Version():
    for v in ['1.3.4', '2.5.5.5']:
        assert eval(repr(Version(v))) == Version(v)
    for v in ['1.3.4', '2.5.5.5']:
        assert eval(repr(StrictVersion(v))) == StrictVersion(v)
    for v in ['1.3.4', '2.5.5.5']:
        assert eval(repr(LooseVersion(v))) == LooseVersion(v)


# Generated at 2022-06-22 22:31:25.544014
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion()
    l.parse('1.2')
    assert l.version == [1, 2]

    l = LooseVersion()
    l.parse('1.2a3')
    assert l.version == [1, 2, 'a', 3]


# Generated at 2022-06-22 22:31:32.480040
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion()
    v.parse("1.3")
    assert v.__str__() == "1.3"

    v.parse("1.3.2")
    assert v.__str__() == "1.3.2"

    v.parse("1.3a1")
    assert v.__str__() == "1.3a1"

    v.parse("1.3a1")
    assert v.__str__() == "1.3a1"


# Generated at 2022-06-22 22:31:34.603869
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert repr(LooseVersion("1.3:0")) == "LooseVersion ('1.3:0')"



# Generated at 2022-06-22 22:31:46.129593
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    import sys
    if sys.version_info >= (3,7):
        assert LooseVersion("1").__repr__() == "LooseVersion ('1')"

    assert LooseVersion("0.5").__repr__() == "LooseVersion ('0.5')"
    assert LooseVersion("1.2.4").__repr__() == "LooseVersion ('1.2.4')"
    assert LooseVersion("1.5b3").__repr__() == "LooseVersion ('1.5b3')"
    assert LooseVersion("1.2.4").__repr__() == "LooseVersion ('1.2.4')"
    assert LooseVersion("1.5b3").__repr__() == "LooseVersion ('1.5b3')"

# Generated at 2022-06-22 22:31:54.986588
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert(LooseVersion("1.2.3") == (1, 2, 3))
    assert(LooseVersion("a.b.c") == ('a', 'b', 'c'))
    assert(LooseVersion("1.2.3a4pre5") == (1, 2, 3, 'a', 4, 'pre', 5))
    assert(LooseVersion("0.4.0.post1") == (0, 4, 0, 'post', 1))
    assert(LooseVersion("1.0.dev345") == (1, 0, 'dev', 345))
    assert(LooseVersion("4.0.0") == (4, 0, 0))
    assert(LooseVersion("4.1.1b1.dev1") == (4, 1, 1, 'b', 1, 'dev', 1))
   

# Generated at 2022-06-22 22:32:06.032926
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    versions = [StrictVersion("1.0"),
                StrictVersion("1.0a1"),
                StrictVersion("1.0b1"),
                StrictVersion("1.0a2"),
                StrictVersion("1.0b2"),
                StrictVersion("1.0c1"),
                StrictVersion("1.0"),
                StrictVersion("1.1"),
                StrictVersion("2.0"),
                ]
    versions.sort()

# Generated at 2022-06-22 22:32:15.888798
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Test the constructor (ie. __init__() and parse())
    def test_errors(vstring):
        try:
            StrictVersion(vstring)
        except ValueError:
            pass
        else:
            raise AssertionError("invalid version number '%s' not caught" %
                                 vstring)

    test_errors('1')
    test_errors('2.7.2.2')
    test_errors('1.3.a4')
    test_errors('1.3pl1')
    test_errors('1.3c4')


# Interface for version-number classes -- must be implemented
# by the following classes (the concrete ones -- Version should
# be treated as an abstract class).
#    __init__ (string) - create and take same action as 'parse'
#                        (string parameter is optional)

# Generated at 2022-06-22 22:32:17.908804
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    with raises(NotImplementedError):
        Version().__ge__(0)



# Generated at 2022-06-22 22:32:21.979935
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("3.9.5")
    v2 = Version("3.9.5")
    assert v1 <= v2

    v1 = Version("3.9.5")
    v2 = Version("3.9.6")
    assert not (v1 <= v2)


# Generated at 2022-06-22 22:32:22.764784
# Unit test for method __le__ of class Version
def test_Version___le__():
    Version(None)


# Generated at 2022-06-22 22:32:27.193262
# Unit test for method __le__ of class Version
def test_Version___le__():
    import os

    # Parameters
    v = Version()
    other = Version()

    # setup

    # execute
    result = v.__le__(other)
    assert type(result) is bool

    # verify

    # cleanup
    # If we get here then the test passes



# Generated at 2022-06-22 22:32:30.864520
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    inst = Version()
    for x in [NotImplemented, -1, 0, 1]:
        assert inst.__ge__(x) == (x >= 0)


# Generated at 2022-06-22 22:32:34.269386
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    expected = "1.0.0"
    actual   = str(StrictVersion("1.0.0"))
    assert actual == expected, "Failed!"

