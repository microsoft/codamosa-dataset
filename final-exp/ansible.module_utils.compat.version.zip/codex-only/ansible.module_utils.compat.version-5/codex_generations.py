

# Generated at 2022-06-22 22:22:36.430293
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.4')
    assert v1 == v1
    assert v2 == v2
    assert v1 == '1.2.3'
    assert v2 == '1.2.4'
    assert not v1 == '1.2.4'
    assert not v2 == '1.2.3'
    assert not v1 == v2
    assert not v2 == v1


# Generated at 2022-06-22 22:22:41.978183
# Unit test for constructor of class Version
def test_Version():
    v = Version()


# XXX There's something wrong with the test, which was probably
# XXX written before rich comparisons were defined.  Since this
# XXX class is a trivial base class anyway, I'm disabling the test
# XXX for now -- mbp 2000/03/09
#
#def test_Version_str_repr():
#    pass


# Generated at 2022-06-22 22:22:47.629959
# Unit test for method __le__ of class Version
def test_Version___le__():
    Test_Version___le__ = TestCase(unittest.TestCase)
    v1 = Version('0.01')
    Test_Version___le__.assertTrue(v1 <= '0.01')
    Test_Version___le__.assertTrue(v1 <= v1)
    Test_Version___le__.assertTrue(v1 <= Version('0.01'))

# Generated at 2022-06-22 22:22:52.526852
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:22:56.638616
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    try:
        StrictVersion('1.2.3')
    except ValueError as e:
        print("FAIL: StrictVersion('1.2.3') failed -- %s" % e)
    else:
        print("OK:   StrictVersion('1.2.3') works")



# Generated at 2022-06-22 22:22:59.954578
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1').__str__() == '1'
    assert StrictVersion('1.2').__str__() == '1.2'
    assert StrictVersion('1.2.3').__str__() == '1.2.3'
    assert StrictVersion('1.2.3a4').__str__() == '1.2.3a4'


# Generated at 2022-06-22 22:23:03.820586
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
   lv = LooseVersion('3.3')
   assert repr(lv) == "LooseVersion ('3.3')"

# Generated at 2022-06-22 22:23:07.375182
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()

    for vstring in valid_version_list:
        lv.parse(vstring)
        assert str(lv) == vstring, ("LooseVersion.parse(%s) failed" % vstring)

# Generated at 2022-06-22 22:23:08.771117
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert True

# Generated at 2022-06-22 22:23:11.906232
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1')
    v2 = Version('2')
    assert not v1 <= '2'
    assert v1 <= '1'
    assert not v2 <= '1'
    assert v2 <= '2'

# Generated at 2022-06-22 22:23:18.290995
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert (Version() >= Version()) == True
    assert (Version() >= Version('0.0.0')) == True
    assert (Version('1.0.0') >= Version('1.0.0')) == True
    assert (Version('1.0.0') >= Version('1.0.0')) == True
    assert (Version('1.0.0') >= Version()) == True
    assert (Version('1.0.0') >= Version('0.0.0')) == True
    assert (Version('1.0.0') >= Version('0.0.1')) == True
    assert (Version('1.0.0') >= Version('1.0.0.0')) == True

# Generated at 2022-06-22 22:23:28.139090
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.tests import support
    V = support.PEP386Version
    assert V('1.2') >= V('1.3')
    assert not (V('1.3') >= V('1.2'))
    assert V('1.2.0') >= V('1.2')
    assert not (V('1.2') >= V('1.2.0'))
    assert V('1.2.0') >= V('1.2a1')
    assert not (V('1.2a1') >= V('1.2.0'))
    assert V('1.2.0') >= V('1.2.b1')
    assert not (V('1.2.b1') >= V('1.2.0'))

# Generated at 2022-06-22 22:23:30.679822
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = distutils.version.LooseVersion('1.2.3+a4')
    assert str(v) == v.vstring, "__str__ doesn't return init string"



# Generated at 2022-06-22 22:23:37.529946
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test with no pre-release string
    v = StrictVersion("1.0.4")
    assert str(v) == "1.0.4"
    # Test with no minor version and no pre-release string
    v = StrictVersion("1.0")
    assert str(v) == "1.0"
    # Test with all fields filled in
    v = StrictVersion("1.0.4b1")
    assert str(v) == "1.0.4b1"

# Generated at 2022-06-22 22:23:49.878058
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import sys
    assert StrictVersion("0.3.0").parse("0.3.0") == (0, 3, 0)
    assert StrictVersion("0.3.0").parse("0.3") == (0, 3, 0)
    assert StrictVersion("0.3.0a0").parse("0.3a0") == (0, 3, 0, 'a', 0)
    assert StrictVersion("0.3.0a0").parse("0.3a0") == (0, 3, 0, 'a', 0)
    assert StrictVersion("0.3.0a0").parse("0.3b0") == (0, 3, 0, 'b', 0)

# Generated at 2022-06-22 22:23:53.032388
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v.parse('1')
    assert v == '1'
    assert not v == '2'


# Generated at 2022-06-22 22:23:55.674451
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2a3')
    assert v.__repr__() == "LooseVersion ('1.2a3')"


# Generated at 2022-06-22 22:24:06.166067
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import LooseVersion
    from distutils.version import StrictVersion

    assert (LooseVersion('1') >= LooseVersion('1') and
            StrictVersion('1') >= StrictVersion('1'))

    # Not equal, but "greater"
    assert (LooseVersion('2.4.4') >= LooseVersion('2.4.3') and
            StrictVersion('2.4.4') >= StrictVersion('2.4.3'))

    # Lesser
    assert (not LooseVersion('1.1.1') >= LooseVersion('2.2.2') and
            not StrictVersion('1.1.1') >= StrictVersion('2.2.2'))



# Generated at 2022-06-22 22:24:10.058473
# Unit test for constructor of class Version
def test_Version():
    for v in ["0.4.0", "0.4"]:
        Version(v)


# Generated at 2022-06-22 22:24:17.391984
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vs in ['0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5', '0.9.6',
               '1.0', '1.0.4a3', '1.0.4b1', '1.0.4']:
        StrictVersion(vs)

    for vs in ['1', '1.2.3.4', '1.2a3', '1.2b3', '1.2pl1', '1.2rc1']:
        try:
            StrictVersion(vs)
        except ValueError:
            pass
        else:
            raise AssertionError("%s is supposed to be illegal" % vs)



# Generated at 2022-06-22 22:24:28.077218
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    e = StrictVersion("0.4.2")
    assert str(e) == "0.4.2"
    e = StrictVersion("0.4")
    assert str(e) == "0.4"
    e = StrictVersion("0.4.0")
    assert str(e) == "0.4.0"
    e = StrictVersion("0.4a1")
    assert str(e) == "0.4a1"
    e = StrictVersion("0.4b2")
    assert str(e) == "0.4b2"
    e = StrictVersion("0.4.0a1")
    assert str(e) == "0.4.0a1"
    e = StrictVersion("0.4.0b2")

# Generated at 2022-06-22 22:24:32.859458
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # assert that s >= s
    for v in all_pairs:
        assert (v[0] >= v[0]) == (v[0] == v[0])

    # assert that s >= t only if s > t or s == t
    for v1, v2 in all_pairs:
        assert (v1 >= v2) == (v1 > v2 or v1 == v2)


# Generated at 2022-06-22 22:24:38.702626
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    pass
    

    # XXX backwards compat (was __cmp__, but that's now _cmp)
    def __cmp__(self, other):
        c = self._cmp(other)
        if c is NotImplemented:
            return c
        else:
            return c and c / abs(c)

    def _cmp(self, other):
        if isinstance(other, str):
            other = self.__class__(other)

        if type(self) is not type(other):
            raise TypeError("cannot compare %s and %s"
                            % (self.__class__.__name__,
                               other.__class__.__name__))

        return NotImplemented



# Generated at 2022-06-22 22:24:45.914413
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # A basic test
    assert StrictVersion('1.2.3') == StrictVersion('1.2.3')

    # Make sure that it handles a pre-release tag properly
    assert StrictVersion('1.2.3b2') < StrictVersion('1.2.3')

    # Make sure that it handles an Epoch tag properly
    assert StrictVersion('1!2.3b2') < StrictVersion('1.2.3')

    # Make sure that it handles a release tag properly
    assert StrictVersion('1.2.3a0') < StrictVersion('1.2.3')

    # Make sure that it handles a local version tag properly
    assert StrictVersion('1.2.3+xyz') == StrictVersion('1.2.3')

    # Make sure we can compare with a Version object


# Generated at 2022-06-22 22:24:55.725017
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import pytest
    import sys

    class TestVersion(Version):
        def parse(self, vstring):
            self.version = vstring
        def _cmp(self, other):
            if isinstance(other, str):
                other = TestVersion(other)
            return (sys.version_info[0], self.version) < (sys.version_info[0], other.version)

    v2_0 = TestVersion("2.0")
    v1_5 = TestVersion("1.5")
    v1_6 = TestVersion("1.6")

    assert not v2_0 > "2.0"
    assert not v1_5 > "1.5.0.0"
    assert not v2_0 > "2.0a1"
    assert v1_6 > "1.5.0"


# Generated at 2022-06-22 22:24:59.458783
# Unit test for constructor of class Version
def test_Version():
    for v in ['1.2.3', '1.2.3-4']:
        vobj = Version(v)
        assert str(vobj) == v
        assert repr(vobj) == "%s ('%s')" % (vobj.__class__.__name__, v)



# Generated at 2022-06-22 22:25:09.520176
# Unit test for constructor of class Version
def test_Version():
    for v in ['0.4a1', '0.4a2.dev456', '0.4a12.dev456', '0.4a12', '0.4b1.dev456',
              '0.4b2', '0.4b2.post345.dev456', '0.4b2.post345', '0.4c1.dev456',
              '0.4c1', '0.4c2.dev456', '0.4c2.post345.dev456', '0.4c2.post345',
              '0.4', '0.4.post456.dev34', '0.4.post456', '1.0']:
        v1 = Version(v)
        v2 = Version(str(v1))
        assert v1 == v2

# Generated at 2022-06-22 22:25:16.207829
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version1 = Version("1.0.1")
    version2 = Version("2.0.1")
    assert(version1 >= version2)
    version1 = Version("2.0.1")
    version2 = Version("1.0.1")
    assert(version1 >= version2)
    version1 = Version("2.0.1")
    version2 = Version("2.0.1")
    assert(version1 >= version2)


# Generated at 2022-06-22 22:25:18.394494
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """
    >>> l = LooseVersion("1.2.3")
    >>> l__str__ = l.__str__()
    >>> l__str__
    '1.2.3'
    """


# Generated at 2022-06-22 22:25:26.007216
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    tests = (
        (
            'StrictVersion("1.3.1")',
            '1.3.1'
        ),
        (
            'StrictVersion("1.3")',
            '1.3'
        ),
        (
            'StrictVersion("1.2.5a5")',
            '1.2.5a5'
        ),
        (
            'StrictVersion("1.2.5b2")',
            '1.2.5b2'
        ),
    )

    for test in tests:
        assert eval(test[0]).__str__() == test[1], test[0]


# Generated at 2022-06-22 22:25:29.757192
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert str(v) == ''     # default for string representation
    v = Version('1.2')
    assert str(v) == '1.2'  # string representation follows constructor
    v = Version('1.2')
    assert eval(repr(v)) == v  # eval of repr generates original value



# Generated at 2022-06-22 22:25:31.970291
# Unit test for method __repr__ of class Version
def test_Version___repr__():

    from distutils.version import Version
    ver = Version('B')
    assert ver.__repr__() == "Version ('B')"



# Generated at 2022-06-22 22:25:35.693892
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.2.3')
    assert v.__repr__() == "Version ('1.2.3')"


# Generated at 2022-06-22 22:25:38.411245
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    sv = StrictVersion(vstring='1.2')
    assert str(sv) == "1.2"


# Generated at 2022-06-22 22:25:45.373022
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("1.2")
    assert v.version == (1, 2, 0)
    assert v.prerelease == None

    v = StrictVersion("1.2.0")
    assert v.version == (1, 2, 0)
    assert v.prerelease == None

    v = StrictVersion("1.2.3-a42")
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 42)

    try:
        StrictVersion("1.2.0.0")
    except ValueError as e:
        assert str(e) == "invalid version number '1.2.0.0'"
    else:
        assert False, "Expected ValueError"


# Generated at 2022-06-22 22:25:54.939978
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    StrictVersion.parse('0.4.1')
    StrictVersion.parse('0.5a1')
    StrictVersion.parse('0.5b3')
    StrictVersion.parse('0.5.0')
    StrictVersion.parse('0.9.6')
    StrictVersion.parse('1.0')
    StrictVersion.parse('1.0.4a3')
    StrictVersion.parse('1.0.4b1')
    StrictVersion.parse('1.0.4')
    StrictVersion.parse('1')
    StrictVersion.parse('2.7.2.2')
    StrictVersion.parse('1.3.a4')
    StrictVersion.parse('1.3pl1')
    StrictVersion.parse('1.3c4')

#

# Generated at 2022-06-22 22:26:03.718627
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest
    class TestVersion___eq__(unittest.TestCase):

        def test__eq__(self):
            v1 = Version(vstring='1.0')
            v2 = Version(vstring='1.0')
            self.assertEqual(v1 == v2, True)
            self.assertEqual(v1 == '1.0', True)
            v3 = Version(vstring='1.1')
            self.assertEqual(v1 == v3, False)

    unittest.main()


# Generated at 2022-06-22 22:26:10.440564
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """

    __str__(self)

    Return the version string corresponding to self: the result
      of parsing self.vstring.

    """
    assert LooseVersion('1.2.3').__str__() == '1.2.3'

    v = LooseVersion('1.2.3')
    v.parse('1.2')
    assert v.__str__() == '1.2'


# Generated at 2022-06-22 22:26:21.442070
# Unit test for method __le__ of class Version
def test_Version___le__():
    import pytest

    from types import NotImplementedType, TypeType

    from distutils.version import Version

    version = Version()
    version_cmp = version._cmp

    __tracebackhide__ = True

    with pytest.raises(TypeError) as excinfo:
        version < 'a'
    assert excinfo.value.args[0] == 'can only compare versions to other versions'

    with pytest.raises(TypeError) as excinfo:
        version <= 'a'
    assert excinfo.value.args[0] == 'can only compare versions to other versions'

    with pytest.raises(TypeError) as excinfo:
        version > 'a'
    assert excinfo.value.args[0] == 'can only compare versions to other versions'


# Generated at 2022-06-22 22:26:22.962660
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    x = Version()
    assert repr(x) == "Version ('None')"

# Generated at 2022-06-22 22:26:32.205798
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    StrictVersion('1.1.1')
    StrictVersion('1.1')
    StrictVersion('0.99.99')
    StrictVersion('0.0.0')
    StrictVersion('1')
    StrictVersion('1.1b1')
    StrictVersion('1.1.a1')
    StrictVersion('1.1a1')
    StrictVersion('1.1c1')
    StrictVersion('1.1a1.1a1')
    StrictVersion('1.1a.1')
    StrictVersion('1.1.1a')
    StrictVersion('1.1.1b')
    StrictVersion('1.1.1.1a')
    StrictVersion('1.1.1b.1')



# Generated at 2022-06-22 22:26:38.427230
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v1 = StrictVersion("1.0")
    assert v1.version == (1, 0, 0)
    assert v1.prerelease is None

    v2 = StrictVersion("1.0.0")
    assert v2.version == (1, 0, 0)
    assert v2.prerelease is None

    v3 = StrictVersion("1.5.1")
    assert v3.version == (1, 5, 1)
    assert v3.prerelease is None

    v4 = StrictVersion("1.5.1b2")
    assert v4.version == (1, 5, 1)
    assert v4.prerelease == ('b', 2)

    v5 = StrictVersion("161.5.1b2")
    assert v5.version == (161, 5, 1)
    assert v

# Generated at 2022-06-22 22:26:46.262565
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Tests.test_distutils.test_version.VersionTestCase.test___gt__
    version1 = Version('1.2.3')
    version2 = Version('1.2.4')
    assert version1 > version2 is False
    assert version1 >= version2 is False
    assert version1 < version2 is True
    assert version1 <= version2 is True
    assert version1 == version2 is False


# Generated at 2022-06-22 22:26:55.457988
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    cfg = {
        "object":{
            "type":"exception",
            "description":"bad version number"
        },
        "answers":{
            "1.2.3c4":"1.2.3c4",
            "1.3.3Ok":"1.3.3Ok",
            "14.4j":"14.4j"
        }
    }
    for input,output in cfg['answers'].items():
        lv = LooseVersion(input)
        if str(lv) != output:
            return cfg['object']

# Generated at 2022-06-22 22:27:00.080657
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.13++')
    assert str(lv) == lv.vstring
    assert lv == '1.13++'
    assert '1.13++' == lv



# Generated at 2022-06-22 22:27:12.509223
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion("1.2.3a2") == StrictVersion("1.2.3a2")
    assert StrictVersion("1.2") == StrictVersion("1.2.0")
    assert StrictVersion("1.2") != StrictVersion("1.2.3")
    assert StrictVersion("1.2.3") > StrictVersion("1.2.0")
    assert StrictVersion("1.2.3a4") < StrictVersion("1.2.3")
    assert StrictVersion("1.2.3a4") < StrictVersion("1.2.3b4")
    assert StrictVersion("1.2.3a4") < StrictVersion("1.2.3a5")

# Generated at 2022-06-22 22:27:22.441454
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Test method __eq__ of class Version"""

    import sys
    import unittest
    from distutils2.compat import unittest as compat_unittest

    import distutils2._backport.version
    version_class = distutils2._backport.version.Version
    version_constructor = distutils2._backport.version.Version

    class Test_Version___eq__(compat_unittest.TestCase):

        def test_equal_version_numbers(self):
            """Tests equal version numbers"""


# Generated at 2022-06-22 22:27:29.150505
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    for v in ["1.2.3", "4.5.6", "7.8.9"]:
        assert v == str(LooseVersion(v))
        assert v == str(LooseVersion("2.2.2" + v))
        assert v == str(LooseVersion(v + "2.2.2"))
        assert v == str(LooseVersion("2.2.2" + v + "2.2.2"))


# Generated at 2022-06-22 22:27:32.015368
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('1.2.3')
    assert lv.__repr__() == "LooseVersion ('1.2.3')"


# Generated at 2022-06-22 22:27:38.514208
# Unit test for constructor of class Version
def test_Version():
    import unittest

    class TestVersion(Version):
        def parse(self, vstring):
            self.vstring = vstring

        def _cmp(self, other):
            if isinstance(other, TestVersion):
                return cmp(self.vstring, other.vstring)
            else:
                return -1

    class VersionTestCase(unittest.TestCase):
        def test_constructor(self):
            v = TestVersion()
            self.failUnless(isinstance(v, TestVersion))
            w = TestVersion('123')
            self.failUnless(isinstance(w, TestVersion))

    suite = unittest.TestSuite()
    suite.addTest(VersionTestCase('test_constructor'))
    unittest.TextTestRunner().run(suite)



# Generated at 2022-06-22 22:27:49.882466
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vs in ["0.4", "0.4.0", "0.4.1", "0.5a1", "0.5b3", "0.5",
               "0.9.6", "1.0", "1.0.4a3", "1.0.4b1", "1.0.4"]:
        StrictVersion(vs)

    for vs in ["", "1", "2.7.2.2", "1.3.a4", "1.3pl1", "1.3c4"]:
        try:
            StrictVersion(vs)
        except ValueError:
            pass

# Generated at 2022-06-22 22:27:53.851596
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    from distutils2.version import LooseVersion
    v = LooseVersion('1.2')
    expected = "LooseVersion ('1.2')"
    assert v.__repr__() == expected

# Generated at 2022-06-22 22:28:03.033058
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion

    versions = map(lv, ["1.2.3",
                        "1.2.3a4",
                        "1.2.3.4",
                        "1.1.1",
                        "1.2.0"])

    assert  versions[0] == "1.2.3"
    assert  versions[1] == "1.2.3a4"
    assert  versions[2] == "1.2.3.4"
    assert  versions[3] == "1.1.1"
    assert  versions[4] == "1.2.0"
    assert  versions[0] < versions[1] < versions[3]
    assert  versions[0] < versions[2] < versions[3]

# Generated at 2022-06-22 22:28:08.484334
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    cls = LooseVersion('1.7.1')
    assert repr(cls) == "LooseVersion ('1.7.1')"
    assert str(cls) == '1.7.1'



# Generated at 2022-06-22 22:28:12.791067
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.1')
    assert v == '1.1'
    assert not v == '1.2'


# Generated at 2022-06-22 22:28:20.405329
# Unit test for method __str__ of class LooseVersion

# Generated at 2022-06-22 22:28:23.766524
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion('1.2a2')
    assert lv.version == [1, 2, 'a', 2]
    lv = LooseVersion('1')
    assert lv.version == [1]



# Generated at 2022-06-22 22:28:27.863568
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
  """__str__"""
  v1 = LooseVersion('1.j')
  v2 = '1.j'
  eq_(str(v1), v2)
  v1 = LooseVersion('1.12345')
  v2 = '1.12345'
  eq_(str(v1), v2)


# Generated at 2022-06-22 22:28:34.551457
# Unit test for method __le__ of class Version
def test_Version___le__():
  y = Version()
  x = y
  z = y
  assert(x <= z)
  assert(y <= z)
  assert(z <= z)
  assert(x <= y)
  assert(z <= y)
  assert(z <= x)
  assert(not (z <= False))
  assert(not (z <= True))
  assert(not (z <= None))


# Generated at 2022-06-22 22:28:40.646764
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.tests import support
    from distutils.version import Version
    from unittest import TestCase
    tc = TestCase('__init__')
    v = Version('1.0')
    tc.assertEqual(v <= '1.0.1', True)
    tc.assertEqual(v <= '1.0', True)
    tc.assertEqual(v <= '0.9', False)

# Generated at 2022-06-22 22:28:43.156206
# Unit test for constructor of class Version
def test_Version():
    for vstring in ['1.2.3', '1.1']:
        assert Version(vstring).parse(vstring) == vstring



# Generated at 2022-06-22 22:28:44.213833
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    pass


# Generated at 2022-06-22 22:28:48.882145
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import sys
    version = sys.version_info[:3]
    v_str = StrictVersion(__version__).__str__()
    assert v_str == '.'.join([str(i) for i in version]), \
        "Unexpected string output: '%s'" % v_str


# Generated at 2022-06-22 22:28:58.140972
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Test versions that are "equal"
    assert StrictVersion("1.2.3") == StrictVersion("1.2.3")
    assert StrictVersion("1.2.3") == StrictVersion("1.2.3.0")
    assert StrictVersion("1.2.3") == StrictVersion("001.002.003")
    assert StrictVersion("1.2.3") == "1.2.3"
    assert "1.2.3" == StrictVersion("1.2.3")

    # Test versions that are "not equal"
    assert StrictVersion("1.2.3") != StrictVersion("1.2.4")
    assert StrictVersion("1.2.3") != StrictVersion("1.2.3a1")
    assert StrictVersion("1.2.3")

# Generated at 2022-06-22 22:29:00.311957
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_Version = VersionClass(vstring=5)
    assert(test_Version == 5)



# Generated at 2022-06-22 22:29:08.101875
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('0.4').__str__() == '0.4.0'
    assert StrictVersion('0.4.0').__str__() == '0.4.0'
    assert StrictVersion('0.4.1').__str__() == '0.4.1'
    assert StrictVersion('0.5a1').__str__() == '0.5a1'
    assert StrictVersion('0.5b3').__str__() == '0.5b3'
    assert StrictVersion('0.5').__str__() == '0.5.0'
    assert StrictVersion('0.9.6').__str__() == '0.9.6'
    assert StrictVersion('1.0').__str__() == '1.0.0'
    assert StrictVersion

# Generated at 2022-06-22 22:29:09.796219
# Unit test for method __le__ of class Version
def test_Version___le__():
    a = Version()
    assert not a.__le__('1.2')

# Generated at 2022-06-22 22:29:12.879230
# Unit test for constructor of class Version
def test_Version():
    v1 = Version("1.2")
    assert repr(v1) == "Version ('1.2')"
    v2 = Version("2.1")
    assert repr(v2) == "Version ('2.1')"



# Generated at 2022-06-22 22:29:14.943481
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # Always return an exception of None
    return None


# Generated at 2022-06-22 22:29:16.827137
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version("1")
    assert v < "2"


# Generated at 2022-06-22 22:29:26.082071
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def compare(vstring, version_info):
        v = LooseVersion(vstring)
        assert v.version == version_info and str(v) == vstring, \
               'error parsing %r' % vstring
    compare('0.4', [0, '4'])
    compare('0.4.0', [0, '4', 0])
    compare('0.4.1', [0, '4', 1])
    compare('1.0', [1, 0])
    compare('1.5.1', [1, '5', 1])
    compare('1.5.1b1', [1, '5', 1, 'b', 1])
    compare('1.0.4b2', [1, 0, '4', 'b', 2])

# Generated at 2022-06-22 22:29:28.497879
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version = StrictVersion("1.2.3.4")
    assert version.version == (1,2,3)
    assert version.prerelease == ('.',4)


# Generated at 2022-06-22 22:29:30.244202
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.2')
    assert str(lv) == '1.2'



# Generated at 2022-06-22 22:29:31.151683
# Unit test for constructor of class Version
def test_Version():
    v = Version()



# Generated at 2022-06-22 22:29:38.778483
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse("1.0.0")
    assert v.version == [1, 0, 0], \
        'failed to parse version'
    v.parse("1.2x.3")
    assert v.version == [1, '2x', 3], \
        'failed to parse version'
    v.parse("0.4.0")
    assert v.version == [0, 4, 0], \
        'failed to parse version'
    v.parse("2.2.0")
    assert v.version == [2, 2, 0], \
        'failed to parse version'
    v.parse("1.1.1.1.1.1.1")

# Generated at 2022-06-22 22:29:40.690789
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
  assert StrictVersion("1.2.0rc2").__str__() == "1.2.0rc2"
  assert StrictVersion("1.6.0").__str__() == "1.6.0"


# Generated at 2022-06-22 22:29:49.114074
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:30:02.228618
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion('1.0')
    assert v.version == (1,0,0), 'wrong version number'
    assert v.prerelease == None, 'prerelease set'

    v = StrictVersion('1.0a1')
    assert v.version == (1,0,0), 'wrong version number'
    assert v.prerelease == ('a',1), 'wrong prerelease'

    v = StrictVersion('1.0b3')
    assert v.version == (1,0,0), 'wrong version number'
    assert v.prerelease == ('b',3), 'wrong prerelease'

    v = StrictVersion('1.2.0')
    assert v.version == (1,2,0), 'wrong version number'
    assert v.prerelease == None, 'prerelease set'


# Generated at 2022-06-22 22:30:12.333901
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # Verify that string representation of the 'LooseVersion' object
    # is correct.
    from distutils.tests import support
    lv = distutils.version.LooseVersion
    eq = support.cmp_obj_attrs_eq

# Generated at 2022-06-22 22:30:13.895554
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version().__gt__('') == NotImplemented

# Generated at 2022-06-22 22:30:25.840391
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion('1.5')
    assert lv.version == [1, 5]
    assert str(lv) == '1.5'

    lv = LooseVersion('3.10a')
    assert lv.version == [3, 10, 'a']
    assert str(lv) == '3.10a'

    lv = LooseVersion('0.960923')
    assert lv.version == [0, 960923]
    assert str(lv) == '0.960923'

    lv = LooseVersion('2.2beta29')
    assert lv.version == [2, 2, 'beta', 29]
    assert str(lv) == '2.2beta29'

    lv = LooseVersion('1.13++')

# Generated at 2022-06-22 22:30:35.341504
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test with a pre-release version.
    ver = StrictVersion('1.2.0a1')
    assert str(ver) == '1.2.0a1'
    # Test with a pre-release version.
    ver = StrictVersion('1.3.5.7a5')
    assert str(ver) == '1.3.5.7a5'
    # Test with a pre-release version.
    ver = StrictVersion('2.0.0b9')
    assert str(ver) == '2.0.0b9'
    # Test with a pre-release version.
    ver = StrictVersion('2.0.0b10')
    assert str(ver) == '2.0.0b10'
    # Test with a pre-release version.

# Generated at 2022-06-22 22:30:46.604343
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    try:
        v.parse("")
    except ValueError:
        pass
    else:
        assert False, "expected error on empty string"

    try:
        v.parse("1")
    except ValueError:
        pass
    else:
        assert False, "expected error on 1"

    try:
        v.parse("1.2.3.4")
    except ValueError:
        pass
    else:
        assert False, "expected error on 1.2.3.4"

    try:
        v.parse("1.1rc1")
    except ValueError:
        pass
    else:
        assert False, "expected error on 1.1rc1"

    v.parse("1.1")

# Generated at 2022-06-22 22:30:49.763552
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
  try:
    assert StrictVersion('1.2.3.4').__str__() == '1.2.3.4'
    assert StrictVersion('1.2a3').__str__() == '1.2a3'
  except AssertionError as e: raise AssertionError(str(e)) from None


# Generated at 2022-06-22 22:30:52.266680
# Unit test for constructor of class Version
def test_Version():
    Version("1.2.3")                                                       #doctest: +ELLIPSIS
    Version()                                                              #doctest: +ELLIPSIS



# Generated at 2022-06-22 22:30:58.008302
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    StrictVersion('1.1.1')
    with pytest.raises(ValueError):
        StrictVersion('1.1')
    with pytest.raises(ValueError):
        StrictVersion('1.a')
    with pytest.raises(ValueError):
        StrictVersion('1.1.a')
    with pytest.raises(ValueError):
        StrictVersion('1.1.1.2')
    with pytest.raises(ValueError):
        StrictVersion('1.1.1ab')


# Generated at 2022-06-22 22:31:08.933698
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion('1.5.1')

# Generated at 2022-06-22 22:31:12.225121
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Implicitly tested by the following methods:
    # Version.__le__
    # Version.__eq__
    # Version.__ge__
    # Version.__gt__
    pass


# Generated at 2022-06-22 22:31:15.750921
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # issue2366
    # LooseVersion fails to parse string with more than 3 numeric parts
    LooseVersion("2.0.0.junk")

__all__ = ['StrictVersion', 'LooseVersion', 'parse', 'Version']

# Generated at 2022-06-22 22:31:16.776384
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version() >= Version()



# Generated at 2022-06-22 22:31:25.675022
# Unit test for constructor of class Version
def test_Version():
    for V in [StrictVersion, LooseVersion]:
        assert V("1.2") == V("1.2.0")
        assert V("1.2") < V("1.2.1")
        assert V("1.2.0") == V("1.2")
        assert V("1.2.1") > V("1.2")
        assert V("1.2.0") < V("1.2.1")
        assert V("1.2a2") < V("1.2")

# Pre-release/alpha/beta/candidate/final-regexp, used by
# StrictVersion and LooseVersion, and supplied as an
# attribute of Version for the benefit of downstream classes
# which wish to use similar version numbering schemes.
#
# The regexp is able to handle versions with:
#   -

# Generated at 2022-06-22 22:31:35.252519
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """
    method LooseVersion.__str__()
    """

# Generated at 2022-06-22 22:31:46.505306
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.2.3')
    assert v.version == (1, 2, 3)
    assert v.prerelease == None

    v.parse('1.2.3a3')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('a', 3)

    v.parse('1.2.3b3')
    assert v.version == (1, 2, 3)
    assert v.prerelease == ('b', 3)

    # Can't do this, since we require a period before the prerelease
    # identifier
    try:
        v.parse('1.2.3c3')
        assert False, "Should have raised ValueError"
    except ValueError:
        pass


# Generated at 2022-06-22 22:31:49.425528
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version().__lt__(1) == NotImplemented
    assert Version().__lt__(Version()) == False
    assert Version().__lt__(Version('')) == False



# Generated at 2022-06-22 22:31:51.011484
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert repr((Version() >= Version())) == 'True'

# Generated at 2022-06-22 22:31:52.587094
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    instance = Version()
    assert instance.__repr__() == "Version ('None')"

# Generated at 2022-06-22 22:31:55.347095
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:32:03.366766
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('1.2.3')) == '1.2.3'
    assert str(StrictVersion('0.4')) == '0.4'
    assert str(StrictVersion('1.0.4a3')) == '1.0.4a3'
    assert str(StrictVersion('1.0.4b1')) == '1.0.4b1'
    assert str(StrictVersion('1.0.4')) == '1.0.4'


# Generated at 2022-06-22 22:32:04.269049
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()

# Generated at 2022-06-22 22:32:14.546861
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:32:20.340747
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Version.__le__() -> bool
    # Test that Version.__le__ returns NotImplemented when not overridden
    class NewVersion(Version):
        def _cmp(self, other):
            return NotImplemented
    v1 = NewVersion()
    v2 = NewVersion()
    assert v1.__le__(v2) is NotImplemented


# Generated at 2022-06-22 22:32:28.215926
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    global top_level_parse
    top_level_parse = False
    def get_local_parse():
        def local_parse(self, vstring):
            global top_level_parse
            global local_parse
            if top_level_parse:
                top_level_parse = False
                local_parse = local_parse_bak
                self.parse(vstring)
            else:
                local_parse_bak(self, vstring)
        return local_parse

    local_parse_bak = StrictVersion.parse
    StrictVersion.parse = get_local_parse()

global top_level_parse
top_level_parse = True
test_StrictVersion_parse()


# Generated at 2022-06-22 22:32:40.116257
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('')
    v.parse("1.0")
    assert v.version == (1, 0)

    v.parse("1.0.1")
    assert v.version == (1, 0, 1)

    v.parse("1.0.1b1")
    assert v.version == (1, 0, 1)
    assert v.prerelease == ('b', 1)

    v.parse("1.0.1.3")
    assert v.version == (1, 0, 1, 3)
    assert v.prerelease == ('b', 1)

    v.parse("1.0.1b1.3")
    assert v.version == (1, 0, 1, 3)
    assert v.prerelease == ('b', 1)

