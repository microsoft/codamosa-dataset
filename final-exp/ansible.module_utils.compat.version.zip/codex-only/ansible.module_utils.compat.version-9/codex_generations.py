

# Generated at 2022-06-22 22:22:43.921871
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for v in ["0.4", "0.4.0", "0.4.1", "0.5a1", "0.5b3", "0.5",
              "0.9.6", "1.0", "1.0.4a3", "1.0.4b1", "1.0.4"]:
        StrictVersion(v)
    for v in ["1", "2.7.2.2", "1.3.a4", "1.3pl1", "1.3c4"]:
        try:
            StrictVersion(v)
        except ValueError:
            pass
        else:
            print("StrictVersion failed to reject bogus version '%s'" % v)

# Unit tests for class StrictVersion

# Generated at 2022-06-22 22:22:49.008308
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import random, sys
    try:
        random = random.SystemRandom()
        using_sysrandom = True
    except NotImplementedError:
        import random
        using_sysrandom = False
    v = None
    i = 0
    while 1:
        r = random.randint(0, sys.maxsize)
        v = Version(r)
        if (v == v) != 1:
            print('Failed at:', i)
            return 0
        i += 1
        if i % (1 << 20) == 0: print('%s\r' % i, end='', flush=True)


# Generated at 2022-06-22 22:22:51.152903
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.0.0') <= Version('1.1.1')
    assert not (Version('1.1.1') <= Version('1.0.0'))

# Generated at 2022-06-22 22:22:57.653197
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Base class doesn't raise errors
    StrictVersion()
    StrictVersion('1.2.3a4')
    StrictVersion('1.2.4b5')

    # Invalid strings
    for v in ['1', '2.3.4', '1.2.3.4', '1.2pl3', '1.2c3']:
        try:
            StrictVersion(v)
        except ValueError:
            pass
        else:
            raise AssertionError("StrictVersion failed to reject '%s'" % v)


# Generated at 2022-06-22 22:23:01.164309
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.0')
    assert v >= '0.9'
    assert v >= Version('1.0')
    assert v >= '1.0'


# Generated at 2022-06-22 22:23:06.738186
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert str(LooseVersion("1.2")) == "1.2", "LooseVersion constructor failure"

test_LooseVersion()

# Metadata version qualifier regular expression

_version_qualifier_re = re.compile(r'(\d+ | [a-z]+ | \.)', re.VERBOSE)


# Generated at 2022-06-22 22:23:08.870499
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert (Version('1.4') > Version('1.3.4')), 'Version comparison must be well ordered'


# Generated at 2022-06-22 22:23:13.035348
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Testing method __repr__ of class Version"""
    Version()
    Version("0")
    Version("0.2")
    Version("1.2.3")
    Version("1.1a2")
    Version("2.3.4.b5")
    Version("1.2+3.4j5")


# Generated at 2022-06-22 22:23:14.916231
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    instance = LooseVersion("1.0")
    assert isinstance(instance, Version)
    assert not isinstance(instance, StrictVersion)
    assert str(instance) == "1.0"



# Generated at 2022-06-22 22:23:17.142731
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version()
    version1 = Version()
    assert version.__eq__(version1)


# Generated at 2022-06-22 22:23:19.574628
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert v is not None


# Generated at 2022-06-22 22:23:22.796242
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse("0.4.2")
    assert (lv.vstring == "0.4.2")


if __name__ == "__main__":
    # Test script
    if len(sys.argv) > 1:
        sys.exit(os.system("python -m unittest " + sys.argv[1]))
    else:
        sys.exit(os.system("python -m unittest discover"))

# Generated at 2022-06-22 22:23:24.619619
# Unit test for constructor of class Version
def test_Version():
    assert Version().__class__ is Version
    assert Version('').__class__ is Version


# Generated at 2022-06-22 22:23:27.182728
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version('1.2').__repr__() == "Version ('1.2')"

# Generated at 2022-06-22 22:23:38.172261
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:23:50.658927
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """
    Some test cases for the LooseVersion class in case the code is
    changed sometime in the future, then this test will catch the
    breakage.
    """
    try:
        import warnings
    except ImportError:
        warnings = None

    str_v = "1.1a1"
    l = LooseVersion(str_v)
    assert l.version == [1,1,"a",1]
    assert str(l) == str_v
    l = LooseVersion()
    l.parse(str_v)
    assert l.version == [1,1,"a",1]
    assert str(l) == str_v

    # Make sure that it ignores leading and trailing spaces
    l = LooseVersion()
    l.parse("   1.1b1   ")

# Generated at 2022-06-22 22:23:52.668885
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version("1")
    v2 = Version("0.99")
    assert v1 >= v2


# Generated at 2022-06-22 22:23:54.185403
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    x = Version()
    y = Version()
    if not ( x > y ):
        raise AssertionError



# Generated at 2022-06-22 22:23:56.387966
# Unit test for constructor of class Version
def test_Version():
    a = Version()
    t = Version("1.2.3")


# Generated at 2022-06-22 22:24:06.146024
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    test_cases = [
        ("1.2",      (1, 2, 0), None),
        ("1.2.3",    (1, 2, 3), None),
        ("1.2a1",    (1, 2, 0), ('a', 1)),
        ("1.2b3",    (1, 2, 0), ('b', 3)),
        ("1.2.3a4",  (1, 2, 3), ('a', 4)),
        ("1.2.3b5",  (1, 2, 3), ('b', 5)),
    ]

    for case in test_cases:
        (vstring, version, prerelease) = case

        s = StrictVersion(vstring)
        assert s.version == version
        assert s.prerelease == prerelease

        s2 = StrictVersion()
       

# Generated at 2022-06-22 22:24:08.683075
# Unit test for constructor of class Version
def test_Version():
    import test.support

    # Make sure a TypeError is raised if the version number is
    # invalid -- in this case, not a string.
    try:
        Version(3)
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised')



# Generated at 2022-06-22 22:24:10.561196
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """Test that calling __repr__ returns expected output."""
    v = LooseVersion('1.0')
    assert v
    assert '1.0' == v.vstring
    assert eval(repr(v)) == v


# Generated at 2022-06-22 22:24:11.546661
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    pass # Skip test


# Generated at 2022-06-22 22:24:16.151844
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def check_function(Version):
        assert Version(__version__) == Version(__version__)
        assert Version(__version__) != Version('1.0.0')
    check_function(Version)


# Generated at 2022-06-22 22:24:18.328094
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(Version())  # => True

# Generated at 2022-06-22 22:24:20.833903
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    import re
    v = Version()
    assert re.match(r'''^Version\s*\(\s*''', repr(v))


# Generated at 2022-06-22 22:24:21.929375
# Unit test for constructor of class Version
def test_Version():
    x = Version('1_23.45')



# Generated at 2022-06-22 22:24:24.387398
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version("")
    assert v == NotImplemented, "Version.__eq__ didn't return NotImplemented"

test_Version___eq__()

# Generated at 2022-06-22 22:24:33.192002
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # single integer
    x = LooseVersion("1")
    assert x.version == [1]
    assert x.vstring == '1'

    # two integers
    x = LooseVersion("1.2")
    assert x.version == [1, 2]
    assert x.vstring == '1.2'

    # integer, string and integer
    x = LooseVersion("1.2b3")
    assert x.version == [1, 'b', 2, 3]
    assert x.vstring == '1.2b3'

    # float, float
    x = LooseVersion("1.2.3")
    assert x.version == [1, 2, 3]
    assert x.vstring == '1.2.3'

    # integer, '.', integer

# Generated at 2022-06-22 22:24:44.674640
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    """Test the LooseVersion constructor."""
    assert str(LooseVersion("1")) == "1"
    assert str(LooseVersion("1.2")) == "1.2"
    assert str(LooseVersion("1.2.3")) == "1.2.3"
    assert str(LooseVersion("1.2.0")) == "1.2"
    assert str(LooseVersion("1.2.0.0")) == "1.2"
    assert str(LooseVersion("1g")) == "1g"
    assert str(LooseVersion("1.2g")) == "1.2g"
    assert str(LooseVersion("1.2.3a")) == "1.2.3a"
    assert str(LooseVersion("1.2.0.0a")) == "1.2a"

# Generated at 2022-06-22 22:24:46.936537
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert (str(StrictVersion('1.2.3.4')) == '1.2.3.4')
    assert (str(StrictVersion('1.2.3')) == '1.2.3')



# Generated at 2022-06-22 22:24:49.527982
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"
    assert repr(1) == "1"



# Generated at 2022-06-22 22:24:57.828612
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    import requests
    import unittest

    v = LooseVersion('1.2')
    r = repr(v)

    print(
        'In %(file)s:%(func)s at line %(lineno)s: %(message)s' %
        {
            'lineno': inspect.currentframe().f_lineno,
            'file': __file__,
            'func': inspect.currentframe().f_code.co_name,
            'message': 'The result should be: \'LooseVersion (\'1.2\')\'.\n'
                       'Actual result: %s' % r
        }
    )

    assert r == 'LooseVersion (\'1.2\')', 'The result should be: \'LooseVersion (\'1.2\')\'.\n' \
                                         

# Generated at 2022-06-22 22:25:01.701124
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('0.4.2')
    assert(repr(v) == "Version ('0.4.2')")


# Generated at 2022-06-22 22:25:10.319387
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    V = Version
    assert V('1.1') < V('1.2')
    assert V('1.0') < V('1.1a')
    assert V('1.0.4') < V('1.0.4.1')
    assert V('1.0.4') < V('1.0.5')
    assert V('1.0') < V('1.0.4')
    assert V('1.0pl0') < V('1.0pl1')
    assert V('1.0a1') < V('1.0a2')
    assert V('1.0a') < V('1.0a1')
    assert V('1.0') < V('1.0a')
    assert V('2g6') < V('2.0')
    assert V('1.13++')

# Generated at 2022-06-22 22:25:12.317911
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3a4')
    assert str(v) == '1.2.3a4'


# Generated at 2022-06-22 22:25:14.513435
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.0.1b1')
    assert str(v).startswith('1.0.1')
    assert str(v).endswith('b1')


# Generated at 2022-06-22 22:25:23.981148
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import sys
    

# Generated at 2022-06-22 22:25:31.312059
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    """StrictVersion() should parse '1.0' and '1.0a1'"""
    tests = ['1.0',
             '1.0a1',
             '1.0a2',
             '1.0b1',
             '1.0b2',
             '0.4',
             '0.4.0',
             '0.4.1',
             '2.7.2.2',
             '1.3.a4',
             '1.3pl1',
             '1.3c4']

    for test in tests:
        try:
            StrictVersion(test)
        except ValueError:
            raise AssertionError(
                'Failed to parse test case %r' % test
            )


# Generated at 2022-06-22 22:25:41.423796
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version = StrictVersion('1.0.4a3')
    assert version.version == (1,0,4)
    assert version.prerelease == ('a', 3)


    version = StrictVersion('1.0.4b1')
    assert version.version == (1,0,4)
    assert version.prerelease == ('b', 1)


    version = StrictVersion('1.0.4')
    assert version.version == (1,0,4)
    assert version.prerelease is None


    version = StrictVersion('1.0')
    assert version.version == (1,0,0)
    assert version.prerelease is None



# Generated at 2022-06-22 22:25:47.927676
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import Version

    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert v >= '1.2.2'
    assert not v >= '1.2.4'

    assert not v >= '1.3.3'
    assert not v >= '2.2.3'

    assert v >= '1.2'
    assert not v >= '1.2.3.4'


# Generated at 2022-06-22 22:25:56.565641
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    try: StrictVersion()
    except: pass

    try: StrictVersion('')
    except: pass

    try: StrictVersion('1.2.3.4')
    except: pass

    assert StrictVersion('1.2.3a1') < StrictVersion('1.2.3')
    assert StrictVersion('1.2.3') > StrictVersion('1.2.3a1')
    assert StrictVersion('1.2.3') == StrictVersion('1.2.3')
    assert StrictVersion('1.2.3a4') < StrictVersion('1.2.3a10')
    assert StrictVersion('1.2.3a40') > StrictVersion('1.2.3a4')
    assert StrictVersion('1.2.3a4') == StrictVersion

# Generated at 2022-06-22 22:26:00.865755
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = distutils.version.Version(vstring='1.2.3a0')
    assert version.__le__(other='1.2.3a0') is True


# Generated at 2022-06-22 22:26:11.988622
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import LooseVersion

    v1 = LooseVersion('1.2')
    v2 = LooseVersion('1.3')
    v3 = LooseVersion('1.3a')
    v4 = LooseVersion('1.3a2')
    v5 = LooseVersion('1.3a2')
    v6 = LooseVersion('1.3a2.1')
    v7 = LooseVersion('1.3a20')
    assert v2 > v1
    assert v2 > '1.2'
    assert v3 > v2
    assert v3 >= v2
    assert v3 < v6
    assert v4 > v3
    assert v5 == v4
    assert v6 > v5
    assert v7 > v6



# Generated at 2022-06-22 22:26:22.625306
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion("1.0") == StrictVersion("1.0.0")
    assert StrictVersion("1.0.4.2") == StrictVersion("1.0.4.2")
    assert StrictVersion("1.2") > StrictVersion("1.1")
    assert StrictVersion("1.1") < StrictVersion("1.2")
    assert StrictVersion("1.2.1") > StrictVersion("1.2")
    assert StrictVersion("1.2") < StrictVersion("1.2.1")
    assert StrictVersion("1.0a1") < StrictVersion("1.0")
    assert StrictVersion("1.0") > StrictVersion("1.0a1")
    assert StrictVersion("1.0") > StrictVersion("1.0a4")

# Generated at 2022-06-22 22:26:31.716931
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring, parsed, prerelease):
        assert str(vstring) == parsed
        assert vstring.prerelease is prerelease
        print('OK')
    test(StrictVersion('0.4'), '0.4', None)
    test(StrictVersion('0.4.0'), '0.4.0', None)
    test(StrictVersion('0.4.1'), '0.4.1', None)
    test(StrictVersion('0.5a1'), '0.5a1', ('a', 1))
    test(StrictVersion('0.5b3'), '0.5b3', ('b', 3))
    test(StrictVersion('0.5'), '0.5', None)
    test(StrictVersion('0.9.6'), '0.9.6', None)


# Generated at 2022-06-22 22:26:41.681988
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion("")
    assert lv.version == []

    lv = LooseVersion("0")
    assert lv.version == [0]

    lv = LooseVersion("0.0")
    assert lv.version == [0, 0]

    lv = LooseVersion("0.0.0")
    assert lv.version == [0, 0, 0]

    lv = LooseVersion("0.0.0.0")
    assert lv.version == [0, 0, 0, 0]

    lv = LooseVersion("0.0a")
    assert lv.version == [0, 0, 'a']

    lv = LooseVersion("0.0a0")
    assert lv.version == [0, 0, 'a0']

    lv = Loose

# Generated at 2022-06-22 22:26:53.882215
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # make sure it can take a version string as an argument
    assert str(LooseVersion("1.1")) == "1.1"
    assert str(LooseVersion("2.1")) == "2.1"
    assert str(LooseVersion("1.2")) == "1.2"
    assert str(LooseVersion("1.2a3")) == "1.2a3"
    assert str(LooseVersion("1.2.3")) == "1.2.3"

    # make sure it can take a version tuple as an argument
    assert str(LooseVersion((1, 1))) == "1.1"
    assert str(LooseVersion((2, 1))) == "2.1"
    assert str(LooseVersion((1, 2))) == "1.2"

# Generated at 2022-06-22 22:26:55.964452
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.0.0')
    assert v.version == (1, 0, 0) and v.prerelease is None



# Generated at 2022-06-22 22:26:58.719148
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v1 = StrictVersion("1.0.4a1")
    v2 = StrictVersion("1.0.4a2")
    assert str(v1) == "1.0.4a1"
    assert str(v2) == "1.0.4a2"


# Generated at 2022-06-22 22:27:08.785928
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    vstring = '42.42.42'
    v = StrictVersion(vstring)
    assert str(v) == vstring
    vstring = '42.42'
    v = StrictVersion(vstring)
    assert str(v) == vstring
    vstring = '42.42a1'
    v = StrictVersion(vstring)
    assert str(v) == vstring
    vstring = '42.42b3'
    v = StrictVersion(vstring)
    assert str(v) == vstring
    vstring = '42.42a1'
    v = StrictVersion(vstring)
    assert str(v) == vstring
    vstring = '42.42b3'
    v = StrictVersion(vstring)
    assert str(v) == vstring
    vstring

# Generated at 2022-06-22 22:27:10.626252
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion("0.960923")
    assert v.vstring == v.__str__()

# Generated at 2022-06-22 22:27:15.278811
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion("1.2")
    assert repr(v) == "LooseVersion ('1.2')"



# Generated at 2022-06-22 22:27:24.056628
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest
    import distutils.version

    class Version_TestCase(unittest.TestCase):
        def test_function__eq__(self):
            test = [
                distutils.version.Version("1"),
                distutils.version.Version("2"),
                distutils.version.Version("3"),
                distutils.version.Version("3.1"),
                distutils.version.Version("3.2"),
                distutils.version.Version("3.2.1"),
                distutils.version.Version("3.2b1"),
                distutils.version.Version("3.5.2"),
                distutils.version.Version("3.5.2a1"),
            ]

# Generated at 2022-06-22 22:27:35.207783
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3')
    assert str(v) == '1.2.3'
    v = StrictVersion('1.2')
    assert str(v) == '1.2'
    v = StrictVersion('1.2a2')
    assert str(v) == '1.2a2'
    v = StrictVersion('1.2.3a2')
    assert str(v) == '1.2.3a2'
    v = StrictVersion('1.2.3b2')
    assert str(v) == '1.2.3b2'
    v = StrictVersion('1.2.3b4')
    assert str(v) == '1.2.3b4'


# Generated at 2022-06-22 22:27:37.236313
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.2.0')
    assert lv.__str__() == '1.2.0'


# Generated at 2022-06-22 22:27:39.115805
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v1 = LooseVersion('1.0')
    assert repr(v1) == "LooseVersion ('1.0')"


# Generated at 2022-06-22 22:27:43.558894
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """ test_LooseVersion___str__() """
    s = LooseVersion("MArk")
    assert 'MArk'  == str(s)
    s.parse("Hans")
    assert 'Hans'  == str(s)


# Generated at 2022-06-22 22:27:47.895496
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    x = LooseVersion('1.234.567')
    if str(x) == '1.234.567':
        print('test_LooseVersion ok')
    else:
        print('test_LooseVersion failed: %s' % str(x))


# Generated at 2022-06-22 22:27:49.266290
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()

    assert v == 1


# Generated at 2022-06-22 22:27:54.137257
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    if "LooseVersion" in globals():
        assert eval(LooseVersion("1").__repr__()) == LooseVersion("1")
if __name__ == "__main__":
    test_LooseVersion___repr__()

# Generated at 2022-06-22 22:27:58.905088
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    class_ = Version
    v = class_('1.0')
    v1 = class_('1.0')
    assert v >= v1
    assert not (v > v1)
    v2 = class_('2.0')
    assert v2 > v1
    assert not (v2 <= v1)

# Generated at 2022-06-22 22:27:59.950741
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()

# Generated at 2022-06-22 22:28:12.432964
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:28:16.440195
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    version = LooseVersion('1.3.1')
    assert version >= '1.3'
    assert version >= '1.3.1'
    assert version >= LooseVersion('1.3')
    assert version >= LooseVersion('1.3.1')


if __name__ == "__main__":
    test_LooseVersion()

# Generated at 2022-06-22 22:28:18.736676
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version('1.2') < Version('1.3')



# Generated at 2022-06-22 22:28:24.116236
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Test method __repr__ of class Version"""
    # Initialize object
    x = Version('1.0')
    # Check repr
    assert repr(x) == "Version ('1.0')"
    # Initialize object
    x = Version('1.2.3')
    # Check repr
    assert repr(x) == "Version ('1.2.3')"



# Generated at 2022-06-22 22:28:25.791872
# Unit test for constructor of class Version
def test_Version():
    # should not raise an exception
    Version()       # no arg
    Version("0.4")  # string arg


# Generated at 2022-06-22 22:28:29.512766
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1.2.3') <= '1.2.3'
    assert Version('1.2.3') <= Version('1.2.3')
    assert Version('1.2.3') <= '1.2.4'


# Generated at 2022-06-22 22:28:32.083197
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3')
    assert v.__repr__() == "Version ('1.2.3')"


# Generated at 2022-06-22 22:28:36.968489
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    a = Version('2.0')
    b = Version('1.1')
    c = Version('1.1b1')
    d = Version('1.1.1')
    assert a >= b; assert b <= a
    assert b >= c; assert c <= b
    assert b >= d; assert d <= b


# Generated at 2022-06-22 22:28:46.082996
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.0')
    if not hasattr(v, 'version') or not isinstance(v.version, tuple):
        raise ValueError('version attribute missing or not a tuple')
    elif v.version != (1, 0, 0):
        raise ValueError('version attribute has wrong value')
    if not hasattr(v, 'prerelease') or v.prerelease != None:
        raise ValueError('prerelease attribute missing or not a tuple')
    v = StrictVersion('1.0.a4')
    if not hasattr(v, 'version') or not isinstance(v.version, tuple):
        raise ValueError('version attribute missing or not a tuple')
    elif v.version != (1, 0, 0):
        raise ValueError('version attribute has wrong value')

# Generated at 2022-06-22 22:28:56.309516
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    SUT = StrictVersion

    x = SUT("1.0")
    assert str(x) == "1.0"
    x = SUT("0.4")
    assert str(x) == "0.4"
    x = SUT("0.4.1")
    assert str(x) == "0.4.1"
    x = SUT("0.4.1.1")
    assert str(x) == "0.4.1"
    x = SUT("0.5a1")
    assert str(x) == "0.5a1"
    x = SUT("0.5b3")
    assert str(x) == "0.5b3"
    x = SUT("0.5")
    assert str(x) == "0.5"
    x = SUT

# Generated at 2022-06-22 22:28:58.058662
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    obj = LooseVersion("1.5.1")
    assert obj.__str__() == "1.5.1"
# Unit tests for method parse of class LooseVersion

# Generated at 2022-06-22 22:28:59.367186
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.tests import support
    v = Version()
    assert v.__eq__(None) is NotImplemented

# Generated at 2022-06-22 22:29:01.594882
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v <= v
    assert Version() <= Version()

# Generated at 2022-06-22 22:29:07.410266
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = StrictVersion('1.0')
    assert str(version) == '1.0'
    version = StrictVersion('1.0.0')
    assert str(version) == '1.0'
    version = StrictVersion('1.0b2')
    assert str(version) == '1.0b2'
    version = StrictVersion('1.0.a1')
    assert str(version) == '1.0a1'
    version = StrictVersion('1.0.0.0')
    assert str(version) == '1.0'



# Generated at 2022-06-22 22:29:15.138998
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert repr(LooseVersion("1.2")) == "LooseVersion ('1.2')"
    assert repr(LooseVersion("1.2.3")) == "LooseVersion ('1.2.3')"
    assert repr(Version("1.2")) == "1.2"
    assert str(Version("1.2.3")) == "1.2.3"
    assert str(LooseVersion("1.2.3")) == "1.2.3"
    assert str(Version("1.2.3")) == "1.2.3"
    assert str(LooseVersion("1.2b1")) == "1.2b1"
    assert str(Version("1.2b1")) == "1.2b1"

# Generated at 2022-06-22 22:29:19.459374
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    SV = StrictVersion('5a5')
    assert SV.version == (5,)
    assert SV.prerelease == ('a', 5)
    SV = StrictVersion('5.6.7')
    assert SV.version == (5, 6, 7)
    assert SV.prerelease == None
    SV = StrictVersion('5.6.7a5')
    assert SV.version == (5, 6, 7)
    assert SV.prerelease == ('a', 5)



# Generated at 2022-06-22 22:29:24.367142
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    _list = ['0.1', '0.2.3', '1.2-3', '1.2.3-4']
    for _v in _list:
        _obj = LooseVersion(_v)
        print(_obj, type(_obj))
        _obj = eval(repr(_obj))
        print(_obj, type(_obj))
        assert str(_obj) == _v


# Generated at 2022-06-22 22:29:30.380427
# Unit test for method __le__ of class Version
def test_Version___le__():
    v,w = Version('1.2.3'), Version('1.2.4')
    assert v <= w
    assert not v > w
    assert not v < w

    v,w = Version('1.2.3'), Version('1.2.3')
    assert v <= w
    assert not v > w
    assert not v < w

    v,w = Version('1.2.3'), Version('1.2.2')
    assert not v <= w
    assert not v > w
    assert v < w


# Generated at 2022-06-22 22:29:36.410018
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:29:37.078556
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass

# Generated at 2022-06-22 22:29:46.230466
# Unit test for constructor of class Version
def test_Version():
    # Constructor should require no arguments
    assert str(Version()) == ""

    # Constructor should take a string argument, if given
    assert str(Version("myversion")) == "myversion"

    # Constructor should be able to parse a string
    v = Version()
    v.parse("myversion")
    assert str(v) == "myversion"
    assert repr(v) == "Version ('myversion')"

    # Constructor should accept and ignore unknown keyword arguments
    assert str(Version(whatever="myversion")) == ""
    # and should pass known keyword arguments on to parse()
    v = Version()
    v.parse(whatever="myversion")
    assert str(v) == ""


# Generated at 2022-06-22 22:29:48.689745
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.2.3.4')
    lv.parse('123abcdef')
    assert lv.__str__() == '123abcdef'

# Generated at 2022-06-22 22:29:51.471057
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert v1 <= v2
    assert not (v1 <= v1)
    assert not (v2 <= v1)



# Generated at 2022-06-22 22:29:52.032408
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    pass


# Generated at 2022-06-22 22:29:54.508369
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion("2.0")
    assert isinstance(v, Version), "v is not Version" 
    assert str(v) == "2.0", "v is not '2.0'" 
    assert repr(v) == "LooseVersion ('2.0')", "v is not 'LooseVersion ('2.0')'" 

# Generated at 2022-06-22 22:30:05.327940
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Test against the LooseVersion that provides the minimal implementation
    # of the __le__ operator. LooseVersion provides a __cmp__ method that
    # raises a TypeError if the type of the argument does not match the type
    # of the instance.
    v1 = Version('1.0')
    v2 = Version('1.1')
    assert (v1 <= v2) is True
    assert (v1 <= '1.1') is True
    assert (v1 <= '1.0') is True
    assert (v1 <= '1.0.0') is True
    assert (v1 <= '1.0.0.0') is True
    assert (v1 <= v1) is True
    assert (v1 <= '1.X') is False
    assert (v1 <= 1) is False

# Generated at 2022-06-22 22:30:13.809685
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    import unittest

# Generated at 2022-06-22 22:30:17.057123
# Unit test for method __ge__ of class Version

# Generated at 2022-06-22 22:30:27.793575
# Unit test for method __le__ of class Version
def test_Version___le__():
    import tempfile
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins

    open_name = 'ansible.module_utils.basic.open'

    # Patch 'open'
    open_original = getattr(builtins, 'open')
    setattr(builtins, 'open', lambda *args, **kwargs: open_original(*args, **kwargs))

    # Create temporary file
    handle, path = tempfile.mkstemp()

    # Create instance of class 'Version'
    version_instance = Version()


# Generated at 2022-06-22 22:30:36.807368
# Unit test for method __le__ of class Version
def test_Version___le__():
    ver = Version()
    # test 1
    check = False
    try:
        ver._cmp = lambda x,y: 1
        check = ver <= True
    except:
        check = True
    assert check
    # test 2
    check = False
    try:
        ver._cmp = lambda x,y: -1
        check = ver <= True
    except:
        check = True
    assert check
    # test 3
    check = False
    try:
        ver._cmp = lambda x,y: 1
        check = ver <= False
    except:
        check = True
    assert check
    # test 4
    check = False
    try:
        ver._cmp = lambda x,y: -1
        check = ver <= False
    except:
        check = True
    assert check
    # test 5
    check

# Generated at 2022-06-22 22:30:41.911204
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  import unittest
  import distutils.version

  class Version___lt__TestCase(unittest.TestCase):
    def test(self):
      class DerivedVersion(distutils.version.Version):
        def __init__(self, vstring):
          distutils.version.Version.__init__(self, vstring)
          self.foo = 'bar'

        def _cmp(self, other):
          if self.foo == 'bar' and other.foo == 'baz':
            return -1
          else:
            return 1

      vstring = '1.0'
      self.assertEqual(DerivedVersion(vstring)._cmp('1.0'), NotImplemented)
      self.assertEqual(DerivedVersion(vstring) < '1.0', False)

# Generated at 2022-06-22 22:30:46.533394
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import operator, types
    # This test is automatically generated from source code comments.
    # Any edits to the test will be lost, if it is regenerated.
    v = LooseVersion('1.5.1')
    assert v.__str__() == '1.5.1'
    v = LooseVersion('1.5.2b2')
    assert v.__str__() == '1.5.2b2'
    v = LooseVersion('161')
    assert v.__str__() == '161'
    v = LooseVersion('3.10a')
    assert v.__str__() == '3.10a'
    v = LooseVersion('8.02')
    assert v.__str__() == '8.02'
    v = LooseVersion('3.4j')

# Generated at 2022-06-22 22:30:48.025357
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')"


# Generated at 2022-06-22 22:30:49.918458
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    x = 0
    version = Version()
    returned = version.__lt__(x)



# Generated at 2022-06-22 22:30:51.765722
# Unit test for constructor of class Version
def test_Version():
    for vstring in ['1.2', '2.3.4', '0.1.2']:
        v = Version(vstring)
        assert str(v) == vstring


# Generated at 2022-06-22 22:31:00.646878
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """
    Test function for method __repr__ of class LooseVersion.
    """
    lv = LooseVersion('1.0.0')
    assert lv.__repr__() == "LooseVersion ('1.0.0')"
    lv = LooseVersion('42')
    assert lv.__repr__() == "LooseVersion ('42')"
    lv = LooseVersion('3.4.5')
    assert lv.__repr__() == "LooseVersion ('3.4.5')"


# Generated at 2022-06-22 22:31:10.303676
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion("1.2") < "1.2.0" < "1.2.1"
    assert LooseVersion("1.2.1") < "1.2.5" < "1.5b1"
    assert LooseVersion("1.2.1") < "1.2.1.1"
    assert LooseVersion("1.2.1") < "1.2.1a1"
    assert LooseVersion("1.2.1") < "1.2.1b3" < "1.2.1b21"
    assert LooseVersion("1.2.1") < "1.2.1c1" < "1.2.1pl2"
    assert LooseVersion("1.2.1") == "1.2.1.0"

# Case 1: the current version

# Generated at 2022-06-22 22:31:20.805535
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion("0.4")) == "0.4"
    assert str(StrictVersion("0.4.0")) == "0.4"
    assert str(StrictVersion("0.4.1")) == "0.4.1"
    assert str(StrictVersion("0.5a1")) == "0.5a1"
    assert str(StrictVersion("0.5b3")) == "0.5b3"
    assert str(StrictVersion("0.5")) == "0.5"
    assert str(StrictVersion("0.9.6")) == "0.9.6"
    assert str(StrictVersion("1.0")) == "1.0"
    assert str(StrictVersion("1.0.4a3")) == "1.0.4a3"

# Generated at 2022-06-22 22:31:33.081210
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    global v1, v2, v3, v4, v5
    v1 = Version('1.2.3')
    v2 = Version('1.3.3')
    v3 = Version('1.3.3')
    v3.parse('1.3.3')
    v4 = Version('1.3.3')
    v4.parse('1.3')
    v5 = Version('1.3.3')
    v5.parse('1.3.3')
    if v1 > v2:
        raise RuntimeError
    if not (v2 > v1):
        raise RuntimeError
    if not (v2 > v3):
        raise RuntimeError
    if not (v2 > v4):
        raise RuntimeError
    if not (v2 > v5):
        raise RuntimeError



# Generated at 2022-06-22 22:31:45.207142
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():

    s = "123"
    lv = LooseVersion(s)
    assert lv.vstring == s
    assert lv.version == [123]
    lv.parse(s)
    assert lv.vstring == s
    assert lv.version == [123]

    s = "123b456"
    lv = LooseVersion(s)
    assert lv.vstring == s
    assert lv.version == [123, "b", 456]
    lv.parse(s)
    assert lv.vstring == s
    assert lv.version == [123, "b", 456]

    s = "abc-123"
    lv = LooseVersion(s)
    assert lv.vstring == s
    assert lv.version == ["abc", "-", 123]
    l

# Generated at 2022-06-22 22:31:54.284229
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:32:05.026480
# Unit test for method __eq__ of class Version
def test_Version___eq__():

  import sys
  from StringIO import StringIO

  from lib.python.version import Version
  passed = 0
  failed = 0
  total = 0
  if "import " in str(Version):
    passed = passed + 1
  else:
    failed = failed + 1
  total = total + 1
  if "_cmp" in str(Version):
    passed = passed + 1
  else:
    failed = failed + 1
  total = total + 1
  try:
    x = Version()
  except:
    passed = passed + 1
  else:
    failed = failed + 1
  total = total + 1
  try:
    x = Version("")
  except:
    passed = passed + 1
  else:
    failed = failed + 1
  total = total + 1

# Generated at 2022-06-22 22:32:15.167148
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('1.5.1') < LooseVersion('1.6.2')
    assert LooseVersion('1.5.1') < LooseVersion('1.6.2b')
    assert LooseVersion('1.6.2') > LooseVersion('1.5.1')
    assert LooseVersion('1.6.2') > LooseVersion('1.5.1a')
    assert LooseVersion('1.5.1') < LooseVersion('1.5.2')
    assert LooseVersion('1.5.1') > LooseVersion('1.5')
    assert LooseVersion('1.5.1') > LooseVersion('1.5a')
    assert LooseVersion('1.5a') < LooseVersion('1.5b')
    assert LooseVersion('1.5')

# Generated at 2022-06-22 22:32:24.894529
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1')
    assert lv.version == [1]
    assert lv.vstring == '1'

    lv.parse('1.2')
    assert lv.version == [1, 2]
    assert lv.vstring == '1.2'

    lv.parse('1.2.3')
    assert lv.version == [1, 2, 3]
    assert lv.vstring == '1.2.3'

    lv.parse('00161')
    assert lv.version == [161]
    assert lv.vstring == '00161'

    lv.parse('2.2.0b1')
    assert lv.version == [2, 2, 'b', 1]

# Generated at 2022-06-22 22:32:28.754651
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.2.3')
    assert lv.__str__()=='1.2.3'
    lv = LooseVersion('1.2.3.a')
    assert lv.__str__()=='1.2.3.a'


# Generated at 2022-06-22 22:32:35.013910
# Unit test for method __le__ of class Version
def test_Version___le__():
  v1 = Version("1")
  v2 = Version("2")
  assert v1 <= v2
  assert not (v1 < v2)
  assert v1 <= "1"
  assert v1 <= v1
  assert not (v1 <= "0")
  assert not (v2 <= v1)
