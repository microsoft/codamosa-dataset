

# Generated at 2022-06-22 22:22:40.455841
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from ansible_collections.rubrik.cdm.plugins.module_utils.rubrik_cdm.version import StrictVersion

    v = StrictVersion("1.2.3")
    assert not v == "1.2.4"  # Test Failure
    assert v == "1.2.3"  # Test Success



# Generated at 2022-06-22 22:22:48.015671
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():

    def test(v):
        return repr(LooseVersion(v))

    assert test('1.2a') == "LooseVersion ('1.2a')"
    assert test('1.2b') == "LooseVersion ('1.2b')"
    assert test('1.2c') == "LooseVersion ('1.2c')"
    assert test('1.2.3a') == "LooseVersion ('1.2.3a')"
    assert test('1.2.3b') == "LooseVersion ('1.2.3b')"
    assert test('1.2.3c') == "LooseVersion ('1.2.3c')"

    assert test('1.2.3.4a') == "LooseVersion ('1.2.3.4a')"

# Generated at 2022-06-22 22:22:50.620083
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion("0.9.6")
    assert str(lv) == "0.9.6"



# Generated at 2022-06-22 22:22:52.136748
# Unit test for constructor of class Version
def test_Version():
    for vs in ['0.4a1', '1.4', '1.10', '1.23.45', '0.23']:
        assert repr(Version(vs)) == "Version ('%s')" % vs


# Generated at 2022-06-22 22:22:54.145500
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('1.2.3')
    assert repr(lv) == "LooseVersion ('1.2.3')"

# Generated at 2022-06-22 22:23:01.936894
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    from unittest import TestCase

    class StrictVersion___str__(TestCase):
        def test_StrictVersion___str__(self):
            v = StrictVersion("1.0")
            self.assertEqual(str(v), "1.0")

            v = StrictVersion("1.0.0")
            self.assertEqual(str(v), "1.0.0")

            v = StrictVersion("1.0a1")
            self.assertEqual(str(v), "1.0a1")

            v = StrictVersion("1.0.0b1")
            self.assertEqual(str(v), "1.0.0b1")

            v = StrictVersion("1.0.0a1")

# Generated at 2022-06-22 22:23:02.768184
# Unit test for method __repr__ of class Version
def test_Version___repr__(): pass

# Generated at 2022-06-22 22:23:07.512952
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Constructor should always return something that compares equal to
    # itself
    for v in ("1.0", "1.3.0", "1.3.9", "1.3.9.1", "1.3.9.1-1"):
        assert LooseVersion(v) == v


# Generated at 2022-06-22 22:23:16.529591
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import pytest
    from distutils.version import StrictVersion

    v = StrictVersion('1.2.3.4')
    assert str(v) == '1.2.3'
    assert (not hasattr(v, 'prerelease'))
    v = StrictVersion('1.2.3a4')
    assert str(v) == '1.2.3a4'
    assert v.prerelease == ('a', 4)
    v = StrictVersion('1.2.3b4')
    assert str(v) == '1.2.3b4'
    assert v.prerelease == ('b', 4)
    v = StrictVersion('1.2.3.4a5')
    assert str(v) == '1.2.3a5'

# Generated at 2022-06-22 22:23:27.578776
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    assert StrictVersion('0.4').version == (0, 4, 0)
    assert StrictVersion('0.4.0').version == (0, 4, 0)
    assert StrictVersion('0.4.1').version == (0, 4, 1)
    assert StrictVersion('0.5a1').version == (0, 5, 0)
    assert StrictVersion('0.5a1').prerelease == ('a', 1)
    assert StrictVersion('0.5b3').version == (0, 5, 0)
    assert StrictVersion('0.5b3').prerelease == ('b', 3)
    assert StrictVersion('1.0.4b1').version == (1, 0, 4)
    assert StrictVersion('1.0.4b1').prerelease == ('b', 1)

# Generated at 2022-06-22 22:23:34.319141
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest
    # Unit tests for method __le__ of class Version
    class Test___le__(unittest.TestCase):
        def test___le__1(self):
            self.assertTrue(True, "Test if the method __le__ of class Version works.")
        def test___le__2(self):
            self.assertTrue(True, "Test if the method __le__ of class Version works.")
    unittest.main()

# Generated at 2022-06-22 22:23:45.406566
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('0.4').__str__() == '0.4'
    assert StrictVersion('0.4.0').__str__() == '0.4'
    assert StrictVersion('0.4.1').__str__() == '0.4.1'
    assert StrictVersion('0.5b3').__str__() == '0.5b3'
    assert StrictVersion('0.5').__str__() == '0.5'
    assert StrictVersion('0.9.6').__str__() == '0.9.6'
    assert StrictVersion('1.0').__str__() == '1.0'
    assert StrictVersion('1.0.4a3').__str__() == '1.0.4a3'

# Generated at 2022-06-22 22:23:55.637033
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('12')
    assert v.version == (12, 0, 0)
    assert v.prerelease is None

    v.parse('12.345')
    assert v.version == (12, 345, 0)
    assert v.prerelease is None

    v.parse('12.345.67')
    assert v.version == (12, 345, 67)
    assert v.prerelease is None

    v.parse('12.345.67a12')
    assert v.version == (12, 345, 67)
    assert v.prerelease == ('a', 12)

    v.parse('12.345.67b12')
    assert v.version == (12, 345, 67)
    assert v.prerelease == ('b', 12)


# Generated at 2022-06-22 22:23:58.033887
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('2.2a2')
    assert(v.__str__() == '2.2a2')


# Generated at 2022-06-22 22:24:01.737388
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion
    assert v('1.2.3a4') < v('1.2.3a5')
    assert v('1.2.3a5') < v('1.2.3b1')


# Generated at 2022-06-22 22:24:03.574834
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.0.4").__str__() == "1.0.4"



# Generated at 2022-06-22 22:24:04.734135
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert (v < v) == False


# Generated at 2022-06-22 22:24:11.597072
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    v.parse('2.0')
    assert v <= '2.0', '>='
    assert v >= '2.0', '<='
    assert v < '2.1', '>'
    assert v < '2.0.1', '>'
    assert v <= '2.0.0', '>='
    assert v >= '2.0.0', '<='
    assert not v < '2.0', 'not >'
    assert not v < '2.0.0', 'not >'
    assert not v > '2.0.0', 'not <'
    assert not v > '2.0', 'not <'



# Generated at 2022-06-22 22:24:15.537751
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  v = Version('1.0a1')
  assert v < '1.0'

  v = Version('1.0a1')
  assert v < '1.0a2'

# Generated at 2022-06-22 22:24:26.957611
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version.__gt__
    assert v(Version("1.0.dev0"), "1.0") == False
    assert v(Version("2.0b2"), "2.0b1") == True
    assert v(Version("1.0"), "1.0.0") == False
    assert v(Version("1.0.dev0"), Version("1.0")) == False
    assert v(Version("2.0b2"), Version("2.0b1")) == True
    assert v(Version("1.0"), Version("1.0.0")) == False
    assert v(Version("1.0a2"), "1.0.a.2") == False
    assert v(Version("2.0b1"), "2.0b2") == False

# Generated at 2022-06-22 22:24:30.126330
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.0.0")
    v2 = Version("2.0.0")
    c = v1._cmp(v2)
    assert c == -1


# end of test___lt__


# Generated at 2022-06-22 22:24:37.575805
# Unit test for method __lt__ of class Version

# Generated at 2022-06-22 22:24:41.683567
# Unit test for method __le__ of class Version
def test_Version___le__():
    g = globals()
    g['__builtins__']['__name__'] = '__builtins__'
    cls = g['Version']
    n = cls.__le__
    cls.__le__
    #TODO


# Generated at 2022-06-22 22:24:42.817923
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    StrictVersion('1.2')



# Generated at 2022-06-22 22:24:48.012955
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v1_0 = StrictVersion("1.0")
    v1_1 = StrictVersion("1.1")
    assert v1_0 < v1_1
    assert v1_1 > v1_0
    assert v1_0 == StrictVersion("1.0.0")
    assert v1_0 <= StrictVersion("1.0.0")
    assert v1_0 >= StrictVersion("1.0.0")
    assert v1_0 != v1_1



# Generated at 2022-06-22 22:24:50.465604
# Unit test for constructor of class Version
def test_Version():
    assert repr(Version())=="Version ('')"
    assert repr(Version('1.2.3'))=="Version ('1.2.3')"


# Generated at 2022-06-22 22:24:52.484819
# Unit test for constructor of class Version
def test_Version():
    import test.support
    v = Version()
    test.support.check_warnings()


# Generated at 2022-06-22 22:25:01.346709
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    sv = StrictVersion("1.2.3")
    assert str(sv) == "1.2.3"
    sv = StrictVersion("1.2")
    assert str(sv) == "1.2.0"
    sv = StrictVersion("1.2.0")
    assert str(sv) == "1.2.0"
    sv = StrictVersion("1.2a3")
    assert str(sv) == "1.2a3"
    sv = StrictVersion("1.2b3")
    assert str(sv) == "1.2b3"
    sv = StrictVersion("1.2.3a4")
    assert str(sv) == "1.2.3a4"
    sv = StrictVersion("1.2.3b4")

# Generated at 2022-06-22 22:25:10.085944
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # Should return "LooseVersion ('0.3.3')"
    assert LooseVersion('0.3.3').__repr__() == "LooseVersion ('0.3.3')"
    # Should return "LooseVersion ('2.3.3')"
    assert LooseVersion('2.3.3').__repr__() == "LooseVersion ('2.3.3')"
    # Should return "LooseVersion ('2.3.3')", no matter what LooseVersion.version is
    # This is because __repr__ just uses LooseVersion.vstring (the string supplied to __init__
    # or LooseVersion.parse)
    lv = LooseVersion('2.3.3')
    lv.version = ['string', 'should', 'not', 'appear']
    assert lv.__

# Generated at 2022-06-22 22:25:20.458456
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion
    lv("4.2.2P+")
    lv("20001206")
    lv("20001206.1")
    lv("20001206.1.1")
    lv("20001206.1.1.1")
    lv("20001206.1.1.1.1")
    lv("20001206.1.1.1.1.1")
    lv("20001206.1.1.1.1.1.1")
    lv("20001206.1.1.1.1.1.1.1")
    lv("20001206.1.1.1.1.1.1.1.1")

# Generated at 2022-06-22 22:25:22.215771
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    version_instance = Version("")
    assert str(version_instance) == "Version ('None')"


# Generated at 2022-06-22 22:25:30.195130
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(version):
        return StrictVersion(version)
    assert test('1.2.3a4').version == (1, 2, 3)
    assert test('1.2.0').version == (1, 2, 0)
    assert test('2.1').version == (2, 1, 0)
    assert test('1.2.3a4').prerelease == ('a', 4)
    assert test('1.2.3b4').prerelease == ('b', 4)
    assert test('1.2.3a4.post345').prerelease == ('a', 4)
    assert test('1.2.3c4.dev345').prerelease == ('c', 4)
    assert test('1.2.3').prerelease == None
    assert test('1.2.3.dev').prerelease == None
   

# Generated at 2022-06-22 22:25:36.136504
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from py_distutils_version import Version
    from py_distutils_version import _BaseVersion as base_version

    v = Version("1.0.0")
    assert repr(v) == "Version ('1.0.0')", repr(v)
    assert str(v) == "1.0.0"

# Generated at 2022-06-22 22:25:38.240345
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("1").__le__("1") == True
test_Version___le__()

# Generated at 2022-06-22 22:25:43.180313
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # Version.test_LooseVersion___repr__()
    lv = LooseVersion ('1.0')
    assert repr(lv) == "LooseVersion ('1.0')"


# Generated at 2022-06-22 22:25:53.032473
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from distutils.version import Version
    from pytest import raises

    def s(x):
        return Version(x)

    # int
    assert not s('1') < 1
    assert s('1') < 2
    assert not s('1') < 0

    # float
    assert not s('1.0') < 1.0
    assert s('1.0') < 1.1
    assert s('1.0') < 2.0
    assert not s('1.0') < 0.9
    assert s('1.0') < 2

    # string
    assert not s('1.0') < '1.0'
    assert s('1.0') < '1.1'
    assert s('1.0') < '2.0'
    assert not s('1.0') < '0.9'
   

# Generated at 2022-06-22 22:26:04.518432
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion("1.2a2")
    assert lv.version == ['1', '2', 'a', '2']
    lv = LooseVersion("1.2")
    assert lv.version == ['1', '2']
    lv = LooseVersion("1.2.3")
    assert lv.version == ['1', '2', '3']
    lv = LooseVersion("1.2.3.4")
    assert lv.version == ['1', '2', '3', '4']
    lv = LooseVersion("1.2.a3")
    assert lv.version == ['1', '2', 'a', '3']
    lv = LooseVersion("1.2.a3.4")

# Generated at 2022-06-22 22:26:16.922607
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion('')
    v.parse('1.5.1')
    assert v.version == [1,5,1]
    assert v.vstring == '1.5.1'

    v = LooseVersion('')
    v.parse('1.5.2b2')
    assert v.version == [1,5,2,'b',2]
    assert v.vstring == '1.5.2b2'

    v = LooseVersion('')
    v.parse('161')
    assert v.version == [161]
    assert v.vstring == '161'

    v = LooseVersion('')
    v.parse('3.10a')
    assert v.version == [3,10,'a']
    assert v.vstring == '3.10a'

   

# Generated at 2022-06-22 22:26:23.260654
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('2.3.0').__str__() == '2.3.0'
    assert StrictVersion('0.9.6').__str__() == '0.9.6'
    assert StrictVersion('2.3.0.0').__str__() == '2.3.0'
    assert StrictVersion('3.3.0').__str__() == '3.3.0'
    assert StrictVersion('3.3.0.0').__str__() == '3.3.0'
    assert StrictVersion('2.3.0a0').__str__() == '2.3.0a0'
    assert StrictVersion('2.3.0b0').__str__() == '2.3.0b0'

# Generated at 2022-06-22 22:26:26.473808
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version("0.0.1")
    assert v >= "0.0.1"
    assert v >= Version("0.0.1")


# Generated at 2022-06-22 22:26:29.427566
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Method __eq__ of class Version"""
    inst = Version('1.2.3')
    method = getattr(inst, '__eq__')
    method(inst)


# Generated at 2022-06-22 22:26:37.094606
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import unittest

# Generated at 2022-06-22 22:26:49.722780
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:26:54.024170
# Unit test for constructor of class Version
def test_Version():
    # The default Version behavior is not to define class variables
    # that affect the string formatting.
    v = Version()
    assert str(v) == ''
    assert repr(v) == "Version ('')"
    # This should raise a TypeError, since there aren't any positional
    # args defined
    raises(TypeError, Version, 1, 2, 3)



# Generated at 2022-06-22 22:27:00.382594
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    import unittest
    from test.support import captured_stdout

    # These testcases assume the ordering:
    #   0.4a1 < 0.4b1 < 0.4 < 0.4.1 < 0.5a1 < 0.5b1 < 0.5

    class TestStrictVersion(unittest.TestCase):

        def test_cmp(self):
            eq = self.assertEqual
            ver1 = StrictVersion
            eq(ver1('1.3.3'), ver1('1.3.3'))
            eq(ver1('1.3.3'), ver1('1.3.3a2'))
            self.assertTrue(ver1('1.3.3') < ver1('1.3.4'))

# Generated at 2022-06-22 22:27:09.376556
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert str(StrictVersion('1.3.2')) == '1.3.2'
    assert StrictVersion('1.2.2') < StrictVersion('1.3.2')
    assert StrictVersion('1.3.2') > StrictVersion('1.0.4')
    import operator
    for ver in [ '1.0.4a3', '1.0.4b1', '1.0.4' ]:
        assert operator.gt(StrictVersion('1.0.5'), StrictVersion(ver))
        assert operator.lt(StrictVersion('1.0.3'), StrictVersion(ver))

# Generated at 2022-06-22 22:27:16.273454
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert_equal(LooseVersion("1.1").__repr__(), "LooseVersion ('1.1')")
    assert_equal(LooseVersion("1.1.1").__repr__(), "LooseVersion ('1.1.1')")
    assert_equal(LooseVersion("1.1.1.1").__repr__(), "LooseVersion ('1.1.1.1')")
    assert_equal(LooseVersion("1.1.1.2").__repr__(), "LooseVersion ('1.1.1.2')")
    assert_equal(LooseVersion("1.1.1.3").__repr__(), "LooseVersion ('1.1.1.3')")


# Generated at 2022-06-22 22:27:18.899697
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test for Version.__ge__()"""
    v = Version()
    assert v.__ge__(v) == 1
    v = Version()
    assert v.__ge__(v) == 1



# Generated at 2022-06-22 22:27:24.311937
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    x = 1
    y = None
    assert v._cmp(x) == NotImplemented, "Unit test for Version.__gt__() has failed."
    assert v._cmp(y) == NotImplemented, "Unit test for Version.__gt__() has failed."


# Generated at 2022-06-22 22:27:31.859785
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion('1.2.3')
    assert lv.__repr__() == "LooseVersion ('1.2.3')"
    lv = LooseVersion('1.2b3')
    assert lv.__repr__() == "LooseVersion ('1.2b3')"
    lv = LooseVersion('1.2rc3')
    assert lv.__repr__() == "LooseVersion ('1.2rc3')"


# Generated at 2022-06-22 22:27:40.912997
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:27:47.849395
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    def f(v1, v2, v3):
        """Checks that v2.__eq__(v1) == v3"""
        c1 = v2.__eq__(v1)
        c2 = v3
        assert c1 == c2, (v1, v2, v3, c1, c2)

    v = Version('1')
    f('1', v, True)
    f('1.0', v, True)
    f('2', v, False)



# Generated at 2022-06-22 22:27:54.204606
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from  re import split

    version = LooseVersion()
    version.parse('1.5.1')
    assert version.version == ['1','5','1']
    
    version.parse('1.5.2b2')
    assert version.version == ['1','5','2','b','2']
    
    version.parse('161')
    assert version.version == ['161']
    
    version.parse('3.10a')
    assert version.version == ['3','10','a']
    
    version.parse('8.02')
    assert version.version == ['8','02']
    
    version.parse('3.4j')
    assert version.version == ['3','4','j']
    
    version.parse('1996.07.12')

# Generated at 2022-06-22 22:28:03.204182
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:28:14.017845
# Unit test for method __le__ of class Version
def test_Version___le__():


# Test Case:
    # Testing if one class is <= another
    class class_a(Version):
        def __init__(self, vstring):
            Version.__init__(self, vstring)
    class class_b(Version):
        def __init__(self, vstring):
            Version.__init__(self, vstring)


    c1 = class_a('1.2.3')
    c2 = class_b('1.2.3')

    print(c1 <= c2)
    assert c1 <= c2 == True
# test_Version___le__()
# Main function, if this is called, the unit test is executed
if __name__ == '__main__':
    test_Version___le__()

# Generated at 2022-06-22 22:28:26.229942
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    input = ['1.2.3',
             '1.2.3a4',
             '1.2.3b5',
             '1.2.3.4',
             '1.2.3.4a5',
             '1.2.3.4b6']

    for s in input:
        v = StrictVersion(s)
        if v.version != (1, 2, 3):
            raise AssertionError("constructor failed: '%s'" % s)
        if (v.prerelease and
            (v.prerelease[0] != s[-1] or v.prerelease[1] != int(s[-2]))):
            raise AssertionError("constructor failed: '%s'" % s)


# Generated at 2022-06-22 22:28:34.638965
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:28:36.902317
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v1 = StrictVersion("1.0")
    v2 = StrictVersion("1.0.0")

test_StrictVersion()

# Generated at 2022-06-22 22:28:43.738185
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('1.2').__str__() == '1.2'
    assert LooseVersion('1.2a').__str__() == '1.2a'
    assert LooseVersion('1.2.0').__str__() == '1.2.0'
    assert LooseVersion('1.2.3.4').__str__() == '1.2.3.4'
    assert LooseVersion('1.2.3.4a').__str__() == '1.2.3.4a'

# Generated at 2022-06-22 22:28:54.994907
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lver = LooseVersion
    # before we test that it does the right thing, let's make sure it
    # does *anything* right...
    lver('0.0').parse('1.2.3')
    lver('0.0').parse('a.b.c')


# Generated at 2022-06-22 22:29:01.049651
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    version.parse("1.1.0")
    other = Version()
    other.parse("1.1.1")
    c = version._cmp(other)
    if c is True:
        print("True")
    else:
        print("False")

test_Version___gt__()

# Generated at 2022-06-22 22:29:12.349856
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def test_parse(vstring, version, prerelease):
        v = StrictVersion(vstring)
        assert v.version == version
        assert v.prerelease == prerelease
        assert vstring == str(v)

    test_parse('1.0',     (1, 0, 0),  None)
    test_parse('1.0  ',   (1, 0, 0),  None)
    test_parse('1.2.0',   (1, 2, 0),  None)
    test_parse('1.2',     (1, 2, 0),  None)
    test_parse('1.2a1',   (1, 2, 0),  ('a', 1))
    test_parse('1.2b3',   (1, 2, 0),  ('b', 3))

# Generated at 2022-06-22 22:29:23.552207
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # a recent version of Python
    assert StrictVersion('1.5.2') == StrictVersion('1.5.2')
    assert StrictVersion('1.5.2') < StrictVersion('2.4.1post1')
    assert StrictVersion('1.5.2') > StrictVersion('1.5')
    assert StrictVersion('1.5.2') >= StrictVersion('1.5.2')
    assert StrictVersion('1.5.2') <= StrictVersion('1.5.2')

    # pre-releases
    assert StrictVersion('1.5.2a1') < StrictVersion('1.5.2')
    assert StrictVersion('1.5.2a1') < StrictVersion('1.5.2b1')

    # post-releases
    assert St

# Generated at 2022-06-22 22:29:25.244974
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.0')
    v2 = Version('1.0')
    assert v1 == v2


# Generated at 2022-06-22 22:29:36.618084
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    assert LooseVersion('1.25.0').version == (1, 25, 0)
    assert LooseVersion('1.2.2b2').version == (1, 2, 2, 'b', 2)
    assert LooseVersion('1.2.1').version == (1, 2, 1)
    assert LooseVersion('161').version == (161,)
    assert LooseVersion('3.10a').version == (3, 10, 'a')
    assert LooseVersion('8.02').version == (8, 2)
    assert LooseVersion('3.4j').version == (3, 4, 'j')
    assert LooseVersion('1996.07.12').version == (1996, 7, 12)
    assert LooseVersion('3.2.pl0').version == (3, 2, 'pl', 0)

# Generated at 2022-06-22 22:29:46.852166
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    assert LooseVersion("2.2beta29").version == [ 2, 2, 'beta', 2, 9 ]
    assert LooseVersion("161").version == [ 161 ]
    assert LooseVersion("1.5.1").version == [ 1, 5, 1 ]
    assert LooseVersion("1.5.2b2").version == [ 1, 5, 2, 'b', 2 ]
    assert LooseVersion("1.5.2b21").version == [ 1, 5, 2, 'b', 2, 1 ]
    assert LooseVersion("1.5.2b3").version == [ 1, 5, 2, 'b', 3 ]
    assert LooseVersion("1.5.2b4").version == [ 1, 5, 2, 'b', 4 ]

# Generated at 2022-06-22 22:29:51.470587
# Unit test for method __le__ of class Version
def test_Version___le__():
    x = Version('1.0.0')
    y = Version('1.0.1')
    assert (x <= y)

    x = Version('1.0.0')
    y = Version('1.0.1')
    assert (x <= y)

    x = Version('1.0.0')
    y = Version('1.0.0')
    assert (x <= y)



# Generated at 2022-06-22 22:29:59.348521
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    instance = Version()
    assert(instance.__ge__(None) == NotImplemented)
    assert(instance.__ge__(2) == NotImplemented)
    assert(instance.__ge__(1.0) == NotImplemented)
    assert(instance.__ge__(Version('2.0')) == NotImplemented)
    assert(instance.__ge__('2.0') == NotImplemented)



# Generated at 2022-06-22 22:30:03.080719
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """
    This is the unit test for method __repr__ of class LooseVersion.
    """
    version = LooseVersion("1.0.0")
    assert repr(version) == "LooseVersion ('1.0.0')"


# Generated at 2022-06-22 22:30:04.986943
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version() <= Version()
    assert Version('0') <= Version('0')
    assert not Version('0') <= Version('1')



# Generated at 2022-06-22 22:30:08.396108
# Unit test for constructor of class Version
def test_Version():
    for v in ['1.3.4', '-1', '0']:
        vv = Version(v)
        assert v == str(vv)
        assert repr(vv).endswith("('%s')" % v)


# Generated at 2022-06-22 22:30:11.618483
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version(u'0.1.2')
    assert v > u'0.1.1'

# Generated at 2022-06-22 22:30:14.724977
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    v.parse("1.1")
    c = v._cmp("1.0")
    if c is NotImplemented:
        return c
    assert c > 0



# Generated at 2022-06-22 22:30:15.953107
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    pass

    # assert obj.__eq__(other) == expected


# Generated at 2022-06-22 22:30:17.022840
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    x = Version('1.2')
    assert repr(x) == "Version ('1.2')"

# Generated at 2022-06-22 22:30:19.479404
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version("1.3.3")
    assert v == "1.3.3"
    assert not v == "2.3.3"

# Generated at 2022-06-22 22:30:25.417722
# Unit test for constructor of class Version
def test_Version():
    global V
    v = V("1.2.3.4")
    eq_(eval(repr(v)), v)
    eq_(str(v), '1.2.3.4')

# Utility function(s) to convert a string version number to a sequence
# of integers, and back to a string.  Useful for implementing
# __cmp__ methods in concrete subclasses.


# Generated at 2022-06-22 22:30:26.410122
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse(): pass

# Generated at 2022-06-22 22:30:29.608552
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from . import version_helper
    from .version_helper import Version

    v = Version("1.2.3")
    assert repr(v) == "Version ('1.2.3')"

# Generated at 2022-06-22 22:30:31.836951
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v = LooseVersion("0.4.0.b1")
    assert v == (0, 4, 0, "b1")



# Generated at 2022-06-22 22:30:38.682665
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from distutils.version import Version
    from distutils.version import StrictVersion
    from distutils.version import LooseVersion

    v = Version()
    # Check
    assert repr(v) == "Version ('')"
    v = Version('1')
    # Check
    assert repr(v) == "Version ('1')"
    # Check
    assert repr(v) == "Version ('1')"

    v = StrictVersion()
    # Check
    assert repr(v) == "StrictVersion ('')"
    v = StrictVersion('1')
    # Check
    assert repr(v) == "StrictVersion ('1')"

    v = LooseVersion()
    # Check
    assert repr(v) == "LooseVersion ('')"
    v = LooseVersion('1')
    # Check
    assert repr

# Generated at 2022-06-22 22:30:48.242035
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import unittest
    from distutils2.compat import StringIO

# Generated at 2022-06-22 22:30:57.197171
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    s = StrictVersion
    # Normalized versions
    assert str(s('1.2')) == '1.2'
    assert str(s('1.2.0')) == '1.2'

    # Non-normalized versions
    assert str(s('1')) == '1.0'
    assert str(s('1.2.0.0')) == '1.2'

    # Invalid version number formats
    raises = (ValueError, IndexError, TypeError)
    for v in ('1.2.3a4x', '1.2a', '1.2.3.4a'):
        try:
            s(v)
        except raises:
            pass
        else:
            assert 0, 'should have raised exception for %r' % v

    # Test comparison of normalized and non-normalized

# Generated at 2022-06-22 22:31:00.487788
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    import doctest
    doctest.testmod(version)

if __name__ == "__main__":
    test_LooseVersion()



# Generated at 2022-06-22 22:31:08.897906
# Unit test for constructor of class Version
def test_Version():
    from distutils.tests import run_unittest
    from test.test_distutils import LoggingSilencer

    class VersionTestCase(unittest.TestCase):

        def test_init(self):
            ver = Version() # no version string given
            self.assertEqual(str(ver), "")

            ver = Version("1.2")
            self.assertEqual(str(ver), "1.2")
            ver = Version("1.2.3")
            self.assertEqual(str(ver), "1.2.3")

    with LoggingSilencer():
        run_unittest(VersionTestCase)



# Generated at 2022-06-22 22:31:16.600793
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import sys
    import unittest

    class test_cases(unittest.TestCase):
        def test_one(self):
            expected = [3, 10, 0]
            v = LooseVersion()
            v.parse('3.10.0')
            self.assertEqual(v.version, expected, sys._getframe().f_code.co_name)

        def test_two(self):
            v = LooseVersion()
            v.parse('1997.07.16')
            expected = [1997, 7, 16]
            self.assertEqual(v.version, expected, sys._getframe().f_code.co_name)

        def test_three(self):
            v = LooseVersion()
            v.parse('3.2.pl0')

# Generated at 2022-06-22 22:31:18.676722
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import types

    assert isinstance(Version.__gt__, types.MethodType)


# Generated at 2022-06-22 22:31:26.732618
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v >= v
    assert v <= v
    assert v == v
    assert not v != v
    assert not v < v
    assert not v > v
    v = Version('1.2')
    assert not v < v
    assert v <= v
    assert not v > v
    assert v >= v
    assert v == v
    assert not v != v
    u = Version('1.2a1')
    assert v < u
    assert v <= u
    assert not v > u
    assert not v >= u
    assert not v == u
    assert v != u
    assert not u < v
    assert not u <= v
    assert u > v
    assert u >= v
    assert not u == v
    assert u != v
    w = Version('1.2')

# Generated at 2022-06-22 22:31:28.820503
# Unit test for constructor of class Version
def test_Version():
    assert str(Version('1.2.3')) == '1.2.3'



# Generated at 2022-06-22 22:31:31.914608
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    expected = "LooseVersion ('1.2.3')"
    assert repr(LooseVersion('1.2.3')) == expected, repr(LooseVersion('1.2.3'))

# Generated at 2022-06-22 22:31:36.697429
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Version is an abstract class and cannot be instantiated.
    with pytest.raises(TypeError) as err:
        d = distutils.version.Version()
    assert str(err.value) == "Can't instantiate abstract class Version with abstract methods _cmp"



# Generated at 2022-06-22 22:31:46.876724
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    my_version = StrictVersion("1.0.4a3")
    assert my_version.version == (1, 0, 4), "my_version.version"
    assert my_version.prerelease == ('a', 3), "my_version.prerelease"
    my_version.parse("1.0")
    assert my_version.version == (1, 0, 0), "my_version.version"
    assert my_version.prerelease == None, "my_version.prerelease"
    ok = False
    try:
        my_version.parse("1.0.a3")
    except ValueError:
        ok = True
    assert ok, "'1.0.a3' should have raised a ValueError"
    # Unit test for method __str__ of class StrictVersion

# Generated at 2022-06-22 22:31:58.709616
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # test for simple string
    import os
    os.system("python -c 'import setupfiles; c=setupfiles.LooseVersion(\"0.0.1\"); print(c.__repr__())'")
    # test for string with number
    os.system("python -c 'import setupfiles; c=setupfiles.LooseVersion(\"0.0.1.2\"); print(c.__repr__())'")
    # test for number
    os.system("python -c 'import setupfiles; c=setupfiles.LooseVersion(0.01); print(c.__repr__())'")
    # test for negative number
    os.system("python -c 'import setupfiles; c=setupfiles.LooseVersion(-0.1); print(c.__repr__())'")
    # test for empty

# Generated at 2022-06-22 22:32:00.910618
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2.3')
    assert repr(v) == "LooseVersion ('1.2.3')"


# Generated at 2022-06-22 22:32:03.686455
# Unit test for constructor of class Version
def test_Version():
    assert repr(Version('1.2.3a4')) == "Version ('1.2.3a4')"
    assert repr(Version()) == "Version ('')"


# Generated at 2022-06-22 22:32:06.610591
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Create the class instance
    v = StrictVersion("1.2.3")
    # Compare the result to the expected u
    assert v.__str__() == "1.2.3"



# Generated at 2022-06-22 22:32:16.199714
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """ Test parse method of class LooseVersion
    """
    lv = LooseVersion()
    print(lv.parse('1.0'))
    print(lv.parse('1.2b3'))
    print(lv.parse('161'))
    print(lv.parse('3.10a'))
    print(lv.parse('8.02'))
    print(lv.parse('3.4j'))
    print(lv.parse('1996.07.12'))
    print(lv.parse('3.2.pl0'))
    print(lv.parse('3.1.1.6'))
    print(lv.parse('2g6'))
    print(lv.parse('11g'))
    print(lv.parse('0.960923'))

# Generated at 2022-06-22 22:32:19.113322
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v1 = LooseVersion('1.2.3b4')
    assert v1.__str__() == '1.2.3b4'
    return


# Generated at 2022-06-22 22:32:28.180567
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # This test is designed to verify the parsing of text into correct
    # lists of numbers and strings.

    # The test is quite extensive and will not easily accept changes
    # unless you design it so.

    # Case 1: no numbers at all
    l = LooseVersion('')
    assert l.version == []

    # Case 2: only a string
    l = LooseVersion('a')
    assert l.version == ['a']

    # Case 3: a number (one digit) and a string
    l = LooseVersion('1a')
    assert l.version == [1, 'a']

    # Case 4: a number (several digits) and a string
    l = LooseVersion('12a')
    assert l.version == [12, 'a']

    # Case 5: a decimal point, no number on the left
   

# Generated at 2022-06-22 22:32:32.035145
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # assert(issubclass(Version, object))
    # version = Version()
    assert(False)  # TODO: implement your test here


# Generated at 2022-06-22 22:32:38.448454
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Default args
    print("Default args")
    v = Version()
    assert repr(v) == "Version ('0')"

    # Input args
    print("Input args")
    v = Version("1.2.3")
    assert repr(v) == "Version ('1.2.3')"


# Unit tests for methods __eq__, __ge__, __gt__, __le__, and __lt__ of class Version