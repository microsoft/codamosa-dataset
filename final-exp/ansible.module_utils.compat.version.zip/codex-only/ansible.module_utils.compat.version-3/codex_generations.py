

# Generated at 2022-06-22 22:22:38.709275
# Unit test for method __le__ of class Version
def test_Version___le__():
    import unittest
    class Test(unittest.TestCase):
        def test_succeeds(self):
            version = Version('1.3.3')
            other = Version('1.3.3')
            self.assertTrue(version <= other)
    unittest.main()


# Generated at 2022-06-22 22:22:46.042111
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import random, string
    digits = list(range(0, 10))
    ascii_letters = list(string.ascii_letters)
    for i in range(10000):
        components = []
        for j in range(random.randint(1, 10)):
            if random.choice((True, False)):
                components.append(str(random.choice(digits)))
            else:
                random.shuffle(ascii_letters)
                components.append(''.join(ascii_letters[0:random.randint(1, 26)]))
        vstring = '.'.join(components)
        vtuple = tuple(components)
        l = LooseVersion(vstring)

# Generated at 2022-06-22 22:22:49.566240
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.0.4a3')
    assert str(v) == '1.0.4a3'
    v = StrictVersion('1.0')
    assert str(v) == '1.0'


# Generated at 2022-06-22 22:22:52.516221
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.2.3')
    print(lv)
    print(lv.vstring)
    print(lv.version)


# Generated at 2022-06-22 22:22:54.827531
# Unit test for constructor of class Version
def test_Version():
    assert Version()._version == ()
    assert Version('')._version == ()
    assert Version('1.2.3')._version == (1, 2, 3)



# Generated at 2022-06-22 22:22:56.638245
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(None) is NotImplemented

# Generated at 2022-06-22 22:23:03.526637
# Unit test for method __le__ of class Version
def test_Version___le__():
    def _test(v1, v2, expected):
        actual = v1.__le__(v2)
        if actual != expected:
            error_message = "FAIL: Version(\"{}\").__le__(Version(\"{}\")) return {}, expected {}"
            error_message = error_message.format(v1, v2, actual, expected)
            return error_message
    error_message = _test("1.0.0", "1.0.0", True)
    if error_message is not None:
        return error_message
    error_message = _test("1.0.0", "1.0.1", True)
    if error_message is not None:
        return error_message

# Generated at 2022-06-22 22:23:05.123420
# Unit test for constructor of class Version
def test_Version():
    Version('1.2.3')

# Picky version numbering classes


# Generated at 2022-06-22 22:23:14.805190
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def _check(vstring, version, prerelease):
        myver = StrictVersion(vstring)
        assert myver.version == version
        assert myver.prerelease == prerelease

    def _check_parse_error(vstring):
        try:
            StrictVersion(vstring)
        except ValueError:
            pass
        else:
            raise AssertionError("%r didn't raise ValueError" % vstring)

    _check_parse_error("the magic debug number 1.3")
    _check_parse_error("1.3---5")
    _check_parse_error("1.3.pl1")
    _check_parse_error("1.3rc3")
    _check_parse_error("1.3c4")
    _check_parse_error("1.3.4_01")

# Generated at 2022-06-22 22:23:18.378662
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion ('1.2.3')
    assert repr(v) == "LooseVersion ('1.2.3')"

# Generated at 2022-06-22 22:23:21.061683
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ev1 = Version()
    ev2 = Version()
    assert ev1.__gt__(ev2) == False, "assert failed"


# Generated at 2022-06-22 22:23:25.770861
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def parse(vstring, version_tuple):
        lv = LooseVersion(vstring)
        assert lv.version == version_tuple, '%s -> %s, not %s' % (
            vstring, lv.version, version_tuple)

    # Examples taken directly from the module doc string
    parse('1.5.1', (1, 5, 1))
    parse('1.5.2b2', (1, 5, '2b2'))
    parse('161', (161,))
    parse('3.10a', (3, '10a'))
    parse('8.02', (8, '02'))
    parse('3.4j', (3, '4j'))
    parse('1996.07.12', (1996, '07', '12'))

# Generated at 2022-06-22 22:23:29.963271
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Unit test for Version.__repr__"""
    v = Version("1.2.3")
    assert repr(v) == "Version ('1.2.3')"

# Generated at 2022-06-22 22:23:39.846142
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion("1.2.3")
    assert(str(v) == "1.2.3")
    v = StrictVersion("1.2")
    assert(str(v) == "1.2")
    v = StrictVersion("1")
    assert(str(v) == "1.0")

    try:
        StrictVersion("abc")
    except ValueError as e:
        assert("invalid version number 'abc'" in str(e))


# Interface for version-number classes -- must be implemented
# by the following classes (the concrete ones -- Version should
# be treated as an abstract class).
#    __init__ (string) - create and take same action as 'parse'
#                        (string parameter is optional)
#    parse (string)    - convert a string representation to whatever
#                        internal representation is

# Generated at 2022-06-22 22:23:44.984683
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    try:
        v1_gt_v2 = v1.__gt__(v2)
    except AttributeError:
        v1_gt_v2 = False
    return v1_gt_v2

# Generated at 2022-06-22 22:23:52.798505
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('1.0')) == '1.0'
    assert str(StrictVersion('1.0.1')) == '1.0.1'
    assert str(StrictVersion('1.0a1')) == '1.0a1'
    assert str(StrictVersion('1.0b1')) == '1.0b1'
    assert str(StrictVersion('1.0b2')) == '1.0b2'


# Generated at 2022-06-22 22:24:03.828486
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    if __debug__:
        lv = LooseVersion()
        lv._beautify = lambda s: s
        #
        lv.parse('')
        assert lv.version == []
        #
        lv.parse('1.5.1')
        assert lv.version == [1, 5, 1]
        #
        lv.parse('1.5.2b2')
        assert lv.version == [1, 5, 2, 'b', 2]
        #
        lv.parse('161')
        assert lv.version == [161]
        #
        lv.parse('3.10a')
        assert lv.version == [3, 10, 'a']
        #
        lv.parse('8.02')
        assert lv.version == [8, '02']

# Generated at 2022-06-22 22:24:12.000936
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:24:24.304489
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:24:31.866901
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('1.0.1').__str__() == '1.0.1'
    assert LooseVersion('1.2a4').__str__() == '1.2a4'
    assert LooseVersion('1.2.3.4').__str__() == '1.2.3.4'
    assert LooseVersion('\\xd0\\xb0').__str__() == '\\xd0\\xb0'
    assert LooseVersion('1.2-').__str__() == '1.2-'
    assert LooseVersion('1.2_').__str__() == '1.2_'


# Generated at 2022-06-22 22:24:43.238050
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Check type of __le__
    assert(type(Version().__le__) == type(Version.__le__))
    # Check precedence
    assert(Version("1.0") <= Version("10.1"))
    assert(Version("1.0") <= Version("1.0"))
    assert(not Version("10.1") <= Version("1.0"))
    # Check invalid argument
    try:
        Version("1.0").__le__("1.0")
        raise AssertionError("ValueError not raised")
    except ValueError:
        pass
    # Check method resolution order
    assert(bool is type(Version().__le__(Version("1.0"))))


# Generated at 2022-06-22 22:24:44.345614
# Unit test for constructor of class Version
def test_Version():
    v = Version()



# Generated at 2022-06-22 22:24:53.313853
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion("1.2").__str__() == "1.2"
    assert StrictVersion("1.2.3.4").__str__() == "1.2.3.4"
    assert StrictVersion("1.2").__str__() == "1.2"
    assert StrictVersion("1.2.3c5").__str__() == "1.2.3c5"
    assert StrictVersion("1.2.3a5").__str__() == "1.2.3a5"
    assert StrictVersion("1.2.3.4a5").__str__() == "1.2.3.4a5"
    assert StrictVersion("1.2.3.4b5").__str__() == "1.2.3.4b5"
    assert Strict

# Generated at 2022-06-22 22:24:57.478800
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert str(StrictVersion('1.2.3a4')) == '1.2.3a4'
    try:
        StrictVersion('abc')
    except ValueError:
        pass
    else:
        raise AssertionError("'abc' is an invalid version number.")


# Generated at 2022-06-22 22:25:03.601907
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:25:10.422811
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('1.2.3a') == ['1', '2', '3', 'a']
    assert LooseVersion('1.2.3a') < ['1', '2', '4']
    assert LooseVersion('1.2.3') < ['1', '2', '3', 'a']
    assert LooseVersion('1.2.3') < ['1', '2', '3', '4']



# Generated at 2022-06-22 22:25:16.017121
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    import unittest

    class VersionTestCase(unittest.TestCase):
        def test_Version___repr__(self):
            v = Version()
            self.assertEqual(repr(v), "Version ('0')")
            v = Version('1.2')
            self.assertEqual(repr(v), "Version ('1.2')")
            v = Version('4.3.2.1')
            self.assertEqual(repr(v), "Version ('4.3.2.1')")

    unittest.main()


# Generated at 2022-06-22 22:25:17.516683
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    c = Version()
    d = c._cmp(None)
    assert isinstance(d, NotImplementedType)


# Generated at 2022-06-22 22:25:26.529475
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    sc = StrictVersion
    # We could also test all valid strings, but I know that _cmp
    # takes care of that ;-)
    # First test the main class

# Generated at 2022-06-22 22:25:33.736948
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """Test LooseVersion.parse method"""
    l = LooseVersion()


# Generated at 2022-06-22 22:25:39.006415
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():

    import random, string


# Generated at 2022-06-22 22:25:51.262821
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # The constructor should parse the string and remember the pieces
    lv = LooseVersion("1.5.1")
    assert lv.version == [1, '5', 1], lv.version
    assert str(lv) == "1.5.1", str(lv)

    # Leading zeros should be ignored for numeric comparisons
    lv = LooseVersion("1.5.001")
    assert lv.version == [1, '5', 1], lv.version

    # The constructor should detect the major and minor version
    lv = LooseVersion("1.5.001")
    assert lv.version == [1, '5', 1], lv.version

    # The constructor should allow any alphanumeric separator characters
    lv = LooseVersion("1.5.1-3")

# Generated at 2022-06-22 22:25:55.803904
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert v.__repr__() == "Version ('0.0')"
    v.parse('1.0')
    assert v.__repr__() == "Version ('1.0')"



# Generated at 2022-06-22 22:25:59.180367
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version(vstring='3.3.3') < Version(vstring='3.3.4')
    assert Version(vstring='3.3.3') < Version(vstring='4')
    assert not Version(vstring='3.3.4') < Version(vstring='3.3.4')
    assert not Version(vstring='4') < Version(vstring='4')


# Generated at 2022-06-22 22:26:06.514611
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    import pytest

    from distutils.version import LooseVersion as Version

    # The test subclasses are there to be able to call assertRaisesRegex
    # against a classmethod, which is not possible due to the way
    # assertRaisesRegex subclasses TestCase.

    class TestVersion___lt__(unittest.TestCase):

        def test_looseversion_lt(self):
            v1 = Version('2.2.0')
            v2 = Version('2.2.1')
            self.assertTrue(v1 < v2)
            self.assertTrue(v1 <= v2)
            self.assertTrue(v2 > v1)
            self.assertTrue(v2 >= v1)
            self.assertFalse(v1 == v2)


# Generated at 2022-06-22 22:26:18.285485
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:26:21.101483
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Test cases for method __gt__ of class Version
    v1 = Version("1.0")
    v2 = Version("2.0")

    assert v1 < v2
test_Version___gt__()

# Generated at 2022-06-22 22:26:28.517069
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    global LooseVersion
    class LV(LooseVersion):
        """ this is so we can easily inspect the parsed result """
        def parse(self, vstring):
            return LooseVersion.parse(self, vstring)

    v = LV("1.0")
    assert v.version == (1,0), "error parsing '1.0' -- got %s" % v.version
    assert str(v) == "1.0", "error in str() -- got %s" % str(v)



# Generated at 2022-06-22 22:26:39.639218
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version_class = StrictVersion
    expect = [('0.4',       ((0, 4, 0), None)),
              ('0.4.0',     ((0, 4, 0), None)),
              ('1.0',       ((1, 0, 0), None)),
              ('1.0.4a3',   ((1, 0, 4), ('a', 3))),
              ('1.0.4b1',   ((1, 0, 4), ('b', 1))),
              ('0.9.6',     ((0, 9, 6), None)),
              ('2.3.5.6',   ValueError),
              ('1.3pl1',    ValueError),
              ('1.3c4',     ValueError),
              ('1',         ValueError),
              ('1.3.a4',    ValueError)]

   

# Generated at 2022-06-22 22:26:48.020234
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    from distutils2.compat import unittest2

    class VersionTestCase(unittest2.TestCase):

        def test___eq__(self):
            v = distutils2.version.Version('1')

            # some initialization code here

            self.assertEquals(v.__eq__('1'), True)


    suite = unittest2.TestLoader().loadTestsFromTestCase(VersionTestCase)
    unittest2.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-22 22:26:56.571238
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vstring, parsed in [('0.4', ((0,4,0), None)),
                            ('0.4.0', ((0,4,0), None)),
                            ('0.4.1', ((0,4,1), None)),
                            ('0.5a1', ((0,5,0), ('a', 1))),
                            ('0.5b3', ((0,5,0), ('b', 3))),
                            ('0.5', ((0,5,0), None)),
                            ('0.9.6', ((0,9,6), None)),
                            ('1.0', ((1,0,0), None)),
                            ('1.0.4a3', ((1,0,4), ('a', 3)))]:
        v = StrictVersion(vstring)
        assert v

# Generated at 2022-06-22 22:26:58.048641
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    version = LooseVersion("0.960923")
    assert repr(version) == "LooseVersion ('0.960923')"


# Generated at 2022-06-22 22:27:04.080891
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('3.1a')
    assert v.version == (3, 1, 0)
    assert v.prerelease == ('a', 1)

    v.parse('0.4.0')
    assert v.version == (0, 4, 0)
    assert v.prerelease is None

    try:
        v.parse('1.3.a4')
    except ValueError:
        pass
    else:
        assert 0

# Generated at 2022-06-22 22:27:14.611419
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = StrictVersion('1.2.3')
    assert (s.version, s.prerelease) == ((1, 2, 3), None)

    s = StrictVersion('1.2')
    assert (s.version, s.prerelease) == ((1, 2, 0), None)

    s = StrictVersion('1.2b3')
    assert (s.version, s.prerelease) == ((1, 2, 0), ('b', 3))

    s = StrictVersion('1.2.3a4')
    assert (s.version, s.prerelease) == ((1, 2, 3), ('a', 4))

    s = StrictVersion('1.2.0')
    assert (s.version, s.prerelease) == ((1, 2, 0), None)

    # Examples found in the wild


# Generated at 2022-06-22 22:27:21.087029
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    """
    StrictVersion.__str__()
    """

    # Test for the following bugs:
    #   - Bug #1025897: StrictVersion.__str__() doesn't work for
    #     versions with just one or two significant numbers

    v = StrictVersion('1')
    assert str(v) == '1', '1 should equal 1'

    v = StrictVersion('1.2')
    assert str(v) == '1.2', '1.2 should equal 1.2'


# Generated at 2022-06-22 22:27:23.742247
# Unit test for method __le__ of class Version
def test_Version___le__():
    '''
    Unit tests for Version.__le__
    '''

    v1 = Version('1.0')
    assert(v1 <= '1.0')


# Generated at 2022-06-22 22:27:26.476320
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.0.0a1.dev1")
    assert str(v) == "1.0.0a1.dev1"



# Generated at 2022-06-22 22:27:36.641468
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v = LooseVersion('1.2.3')
    assert v.version == [1,2,3]
    v = LooseVersion('1.2.3.4')
    assert v.version == [1,2,3,4]
    v = LooseVersion('1.2')
    assert v.version == [1,2]
    v = LooseVersion('1.2rc1')
    assert v.version == [1,2,'rc',1]
    v = LooseVersion('1.2.3a1')
    assert v.version == [1,2,3,'a',1]

    # Padding is ignored:
    # - no longer truthy, padded numeric parts are no longer numeric
    #   so they're not comparable
    #v = LooseVersion('1.02.3')
    #assert

# Generated at 2022-06-22 22:27:49.137993
# Unit test for method __gt__ of class Version
def test_Version___gt__():
  from ansiblelint import utils
  from ansiblelint.rules.ANSIBLE0007 import Version

  vver1 =  Version("3.6.5")
  vver2 =  Version("3.6.7")
  vver3 =  Version("4.0.0")
  vver4 =  Version("4.2.0")

  assert utils.version_compare(vver2, vver1) > 0
  assert utils.version_compare(vver3, vver1) > 0
  assert utils.version_compare(vver3, vver2) > 0
  assert utils.version_compare(vver4, vver1) > 0
  assert utils.version_compare(vver4, vver2) > 0
  assert utils.version_comp

# Generated at 2022-06-22 22:28:01.135139
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('1').__str__() == '1'
    assert LooseVersion('2').__str__() == '2'
    assert LooseVersion('2').__str__() == '2'
    assert LooseVersion('1.1').__str__() == '1.1'
    assert LooseVersion('2.2').__str__() == '2.2'
    assert LooseVersion('2.2').__str__() == '2.2'
    assert LooseVersion('1.1.1').__str__() == '1.1.1'
    assert LooseVersion('2.2.2').__str__() == '2.2.2'
    assert LooseVersion('2.2.2').__str__() == '2.2.2'

# Generated at 2022-06-22 22:28:05.213687
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    from distutils.tests import support
    version = '2.3.3'
    lv = LooseVersion(version)
    assert repr(lv) == "LooseVersion ('%s')" % version


# Generated at 2022-06-22 22:28:07.875965
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    r = repr(v)
    assert r == "Version ('0.0')"



# Generated at 2022-06-22 22:28:15.469599
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    strict_version = StrictVersion()

# Generated at 2022-06-22 22:28:19.894169
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    ts = LooseVersion('3.4.7')
    assert(repr(ts) == "LooseVersion ('3.4.7')")

# Generated at 2022-06-22 22:28:28.702056
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    check = LooseVersion("1.23.123")
    assert(check.vstring == "1.23.123")
    assert(check.version == [1, 23, 123])

    check = LooseVersion("a.b.c")
    assert(check.vstring == "a.b.c")
    assert(check.version == ['a', 'b', 'c'])

    check = LooseVersion("a.1.c")
    assert(check.vstring == "a.1.c")
    assert(check.version == ['a', 1, 'c'])

    check = LooseVersion("a.b.1")
    assert(check.vstring == "a.b.1")
    assert(check.version == ['a', 'b', 1])


# Generated at 2022-06-22 22:28:30.691398
# Unit test for constructor of class Version
def test_Version():
    version = Version(1.0)
    return version



# Generated at 2022-06-22 22:28:36.159987
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Tests for method __ge__ of class Version"""
    v = Version()
    assert(v >= v)
    assert(not (v >= '0.0'))
test_Version___ge__()


# Generated at 2022-06-22 22:28:45.521607
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse("1.5.1")
    assert v.version == [1, 5, 1]
    v = LooseVersion()
    v.parse("1.5.2b2")
    assert v.version == [1, 5, 2, "b", 2]
    v = LooseVersion()
    v.parse("161")
    assert v.version == [161]
    v = LooseVersion()
    v.parse("3.10a")
    assert v.version == [3, 10, "a"]
    v = LooseVersion()
    v.parse("8.02")
    assert v.version == [8, 2]
    v = LooseVersion()
    v.parse("3.4j")
    assert v.version == [3, 4, "j"]


# Generated at 2022-06-22 22:28:55.340396
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion(
        "1.0").__str__() == "1.0", ""
    assert StrictVersion(
        "1.0a1").__str__() == "1.0a1", ""
    assert StrictVersion(
        "1.0b1").__str__() == "1.0b1", ""
    assert StrictVersion(
        "1.0rc1").__str__() == "1.0rc1", ""
    assert StrictVersion(
        "1.0.0.0").__str__() == "1.0.0", ""
    assert StrictVersion(
        "0.0.0.0").__str__() == "0.0", ""

# Generated at 2022-06-22 22:28:59.383635
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert "Version('1.2.3') < Version('1.2.4')" == repr(Version('1.2.3') < Version('1.2.4'))

# Generated at 2022-06-22 22:29:00.500910
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version().__gt__(Version())



# Generated at 2022-06-22 22:29:10.442619
# Unit test for constructor of class Version
def test_Version():
    v = Version('1.2.3')
    assert str(v) == '1.2.3'
    assert str(Version(v)) == '1.2.3'
    assert (Version() == Version('0')) and (Version() < Version('1'))
    try:
        Version('')
    except ValueError:
        pass

# Generated at 2022-06-22 22:29:12.836107
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert not (Version("1") == Version("2"))
    assert Version("1") == Version("1")
    assert not (Version("1") == Version("1.0"))


# Generated at 2022-06-22 22:29:16.928219
# Unit test for method __le__ of class Version
def test_Version___le__():
    ver = Version('4.4')
    assert ver <= '4.4.9'
    assert ver <= '4.4.0'
    assert ver <= ver
    assert ver <= '4.5'



# Generated at 2022-06-22 22:29:26.145986
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # An error is raised if the argument cannot be parsed.
    lv = LooseVersion()
    raises(ValueError, lv.parse, "x.y.z")

    # check what '' means
    lv.parse('')
    assert lv.version == []
    assert str(lv) == ''

    # Check that a trailing '.' is ignored.
    lv.parse('1.2.3.')
    assert lv.version == [1, 2, 3]
    assert str(lv) == '1.2.3'

    # A single string (not a tuple) is acceptable as the argument to parse().
    lv.parse('1.2.3')
    assert lv.version == [1, 2, 3]
    assert str(lv) == '1.2.3'

# An error is

# Generated at 2022-06-22 22:29:27.275281
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1')
    assert v == '1'



# Generated at 2022-06-22 22:29:29.357601
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.2.3')
    assert repr(v) == "Version ('1.2.3')"


# Generated at 2022-06-22 22:29:35.311711
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import LooseVersion
    v1 = LooseVersion('2.2a2')
    v2 = LooseVersion('2.2a2')
    v3 = LooseVersion('2.2b2')
    assert (v1 == v1)
    assert (v2 == v2)
    assert (v3 == v3)
    assert (v1 == v2)
    assert (v1 != v3)

# Generated at 2022-06-22 22:29:45.548693
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import copy
    import sys

    version1 = create_version_instance(Version, '1.0')
    version2 = create_version_instance(Version, '1.0')
    version3 = create_version_instance(Version, '2.0')
    version4 = create_version_instance(Version, None)
    version5 = create_version_instance(Version, None)

    assert version1 != version2
    assert version2 != version1
    assert version2 != version3
    assert version3 != version2
    assert version4 != version5
    assert version4 != version1
    assert version4 != version2
    assert version1 != version4
    assert version2 != version4
    assert version5 != version4

    assert version1 != '1.0'


# Generated at 2022-06-22 22:29:50.353884
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion("1.1.1")
    assert v.version == (1, 1, 1)
    assert v.prerelease is None

    v = StrictVersion("1.1.1b2")
    assert v.version == (1, 1, 1)
    assert v.prerelease == ("b", 2)

    v = StrictVersion("1.1.1a1")
    assert v.version == (1, 1, 1)
    assert v.prerelease == ("a", 1)


# Generated at 2022-06-22 22:29:51.573365
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    from test_version import LooseVersionTestCase
    import unittest
    test_support.run_unittest(LooseVersionTestCase)



# Generated at 2022-06-22 22:29:55.841873
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    a1 = Version('1.0')
    a2 = Version('1.0')
    a3 = Version('2.0')
    assert a1 == a2
    assert a1 != a3

# Generated at 2022-06-22 22:29:59.680790
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
        v1 = LooseVersion('1.22')
        assert repr(v1) == "LooseVersion ('1.22')"
        assert str(v1) == '1.22'


# Generated at 2022-06-22 22:30:01.860216
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert str(Version('1.0')) == "Version ('1.0')"


# Generated at 2022-06-22 22:30:03.394469
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  assert Version().__lt__(Version()) == NotImplemented


# Generated at 2022-06-22 22:30:14.811011
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import sys

    # py3k has no Unicode support for regular expressions
    if sys.version_info >= (3,0):
        import doctest
        # Using the doctest module and its global namespace to execute the
        # intended test.
        # Inside the doctest file we have:
        #     >>> a = '1.5.2b2'
        #     >>> b = '3.4j'
        #     >>> v1 = LooseVersion(a)
        #     >>> v2 = LooseVersion(b)
        #     >>> v1.parse(a)
        #     >>> v2.parse(b)
        #
        # The result is compared to the doctest output snapshot.
        doctest.testfile('tests/test_version.doctest')

# Generated at 2022-06-22 22:30:16.018439
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    foo = Version()
    return foo.__repr__()



# Generated at 2022-06-22 22:30:20.022139
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.2.3.4')
    assert v.__str__() == '1.2.3.4'
    v = LooseVersion('1.2.3.4.5')
    assert v.__str__() == '1.2.3.4.5'



# Generated at 2022-06-22 22:30:22.159726
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert (v <= v) == True


# Generated at 2022-06-22 22:30:31.868102
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():

    from distutils.tests import support
    from distutils.version import StrictVersion

    def check(vstring, errmsg="unable to parse version string %r"):
        version = StrictVersion(vstring)
        pvstring = str(version)
        if vstring != pvstring:
            raise AssertionError(errmsg % vstring)
        # test that the string form can be parsed back
        # to reconstruct the same version tuple
        version = StrictVersion(pvstring)
        if str(version) != pvstring:
            raise AssertionError(errmsg % vstring)

    strict_version = StrictVersion
    check('1.0')
    check('1.0.0')
    check('1.1')
    check('1.0.4a3')

# Generated at 2022-06-22 22:30:43.601564
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    import unittest

    class Test_parse(unittest.TestCase):
        def test_good_version_number(self):
            expected = (1, 0, 2)
            actual = StrictVersion('1.0.2')
            self.assertEqual(actual.version, expected)

        def test_good_version_number_without_patch_number(self):
            expected = (1, 0, 0)
            actual = StrictVersion('1.0')
            self.assertEqual(actual.version, expected)

        def test_good_version_number_with_abc(self):
            expected = (1, 0, 2)
            actual = StrictVersion('1.0.2a1')
            self.assertEqual(actual.version, expected)


# Generated at 2022-06-22 22:30:49.776302
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    from lib2to3 import pygram
    from lib2to3.pgen2 import token

    version_string = '1.5beta4pre4+'
    version = LooseVersion(version_string)
    assert(version.__str__() == version_string)

# Generated at 2022-06-22 22:30:51.824339
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    v3 = Version('1.2.4')
    assert v1 <= v2
    assert not (v1 <= v3)


# Generated at 2022-06-22 22:30:59.246223
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # test what LooseVersion can digest and what not
    ok = LooseVersion
    raises = LooseVersionError = ValueError
    ok('1.2')
    ok('1.2.3')
    ok('1.2a2')
    ok('1.2.3a2')
    ok('1.2.3a2.4')
    ok('0.4.0')
    ok('2g6')
    ok('0.960923')
    ok('2.2beta29')
    ok('1.13++')
    ok('5.5.kw')
    ok('2.0b1pl0')
    ok('1.3alpha1')
    ok('1.3.0alpha1')
    ok('1.3.0.1alpha1')

# Generated at 2022-06-22 22:30:59.939434
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    pass

# Generated at 2022-06-22 22:31:09.864824
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # test 1 - basic version number
    version_re = re.compile("^(\\d+) \\. (\\d+) (\\. (\\d+))? ([ab](\\d+))?$",
                            RE_FLAGS)
    vstring = "1.1.1a1"
    vstring = "1.0.0"
    vstring = "1.0.0a0"
    vstring = "3.7.3"
    match = version_re.match(vstring)
    if match:
        print('test_StrictVersion_parse() passed')
    else:
        print('test_StrictVersion_parse() failed')
    # test 2 - basic checking for values matching
    vstring = "1.1.1a1"
    match = version_re.match(vstring)
   

# Generated at 2022-06-22 22:31:11.661337
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.0')
    assert repr(v) == "Version ('1.0')"



# Generated at 2022-06-22 22:31:13.671126
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ver = Version()
    assert None == ver.__lt__(other=None)

# Generated at 2022-06-22 22:31:15.480047
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.0')
    assert v == Version('1.0')

# Generated at 2022-06-22 22:31:18.726381
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Initialize version class object v
    v = Version()
    # Arrange
    observed = v.__le__(Version())
    # Assert
    assert observed == True


# Generated at 2022-06-22 22:31:30.871851
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:31:44.320818
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Constructor with a single argument
    try:
        StrictVersion('0.4')
    except ValueError:
        print('test_StrictVersion 1: failed')
    try:
        StrictVersion('0.4.0')
    except ValueError:
        print('test_StrictVersion 2: failed')
    try:
        StrictVersion('0.4.0')
    except ValueError:
        print('test_StrictVersion 3: failed')
    try:
        StrictVersion('1.0')
    except ValueError:
        print('test_StrictVersion 4: failed')
    try:
        StrictVersion('204.1dev')
    except ValueError:
        print('test_StrictVersion 5: failed')

# Generated at 2022-06-22 22:31:45.156510
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version(None) >= None



# Generated at 2022-06-22 22:31:48.220362
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion("1.1")
    assert lv.version == [1,1], lv.version
    assert str(lv) == "1.1", str(lv)



# Generated at 2022-06-22 22:31:56.044171
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Check that __lt__ features on a quite generic Version instance.
    from distutils.tests import support
    import unittest

    class TestableVersion(Version):
        def _cmp(self, other):
            return True

    test_cases = (TestableVersion(1), TestableVersion(2))

    # Check that we can get a TypeError
    # when trying to compare with a non-Version instance.
    self = test_cases[0]
    support.run_unittest(
        unittest.FunctionTestCase(lambda: self < "toto"),
        )

    # Check that the test cases have been correctly initialized.
    self = test_cases[0]
    cp = self._cmp
    self._cmp = lambda other: isinstance(other, Version)

# Generated at 2022-06-22 22:31:57.202871
# Unit test for method __gt__ of class Version
def test_Version___gt__(): assert Version('1.2').__gt__('1.1')


# Generated at 2022-06-22 22:32:01.147239
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    strict_version  = StrictVersion("1.2")
    assert strict_version.version == (1, 2, 0)
    assert strict_version.prerelease is None
    assert str(strict_version) == "1.2"


# Generated at 2022-06-22 22:32:02.789851
# Unit test for method __le__ of class Version
def test_Version___le__():
    test_inst = Version()
    assert test_inst.__le__

# Generated at 2022-06-22 22:32:05.183310
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    lv = LooseVersion ("1.3.3")
    assert lv.__repr__() == "LooseVersion ('1.3.3')"


# Generated at 2022-06-22 22:32:15.259877
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.0.0')
    assert str(v) == '1.0.0'

    v = StrictVersion('1.0')
    assert str(v) == '1.0.0'

    v = StrictVersion('1')
    assert str(v) == '1.0.0'

    v = StrictVersion('1.0.0a0')
    assert str(v) == '1.0.0a0'

    v = StrictVersion('1.0.0b0')
    assert str(v) == '1.0.0b0'

    v = StrictVersion('1.0.0rc1')
    assert str(v) == '1.0.0rc1'

    v = StrictVersion('1.0.0')
    v.prerelease

# Generated at 2022-06-22 22:32:16.903794
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version().__le__(1) == False

# Generated at 2022-06-22 22:32:26.339756
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vstring in [ "0.4.0", "0.4", "0.4.1", "0.5a1", "0.5b3",
                     "0.5", "0.9.6", "1.0", "1.0.4a3", "1.0.4b1",
                     "1.0.4", "1.0.4.0" ]:
        Version(vstring)

    for vstring in [ "1", "2.7.2.2", "1.3.a4", "1.3pl1", "1.3c4",
                     "1.0.4.5" ]:
        try:
            Version(vstring)
        except ValueError:
            pass

# Generated at 2022-06-22 22:32:33.778251
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring):
        version = StrictVersion(vstring)
        print(vstring, "-->", version, "-->", str(version))

    test("0.4.0")
    test("4.10")
    test("4.10.3")
    test("4.3a1")
    test("4.3b2")


if __name__ == "__main__":
    test_StrictVersion()

# Generated at 2022-06-22 22:32:35.488744
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2