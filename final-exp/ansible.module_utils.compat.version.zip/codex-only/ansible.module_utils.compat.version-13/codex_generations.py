

# Generated at 2022-06-22 22:22:44.437816
# Unit test for method __str__ of class StrictVersion

# Generated at 2022-06-22 22:22:47.162722
# Unit test for method __le__ of class Version
def test_Version___le__():
    import copy
    v = Version()
    v2 = copy.copy(v)
    assert v <= v2
    try:
        v._cmp = NotImplemented
        assert not (v <= v2)
    finally:
        # Restore like nothing happened
        v._cmp = None



# Generated at 2022-06-22 22:22:51.187054
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    version._cmp = MagicMock(return_value=1)
    assert version <= Version() == False
    version._cmp = MagicMock(return_value=0)
    assert version <= Version() == True
    version._cmp = MagicMock(return_value=-1)
    assert version <= Version() == True

# Generated at 2022-06-22 22:22:54.830541
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test method Version.__gt__ of class Version."""

    # setup
    v = Version("0")

    # test
    result = v.__gt__(v)

    # assert
    assert result == NotImplemented

# Generated at 2022-06-22 22:23:01.686996
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    for vstring in ['1', '1.4', '1.4.3', '1.4.3.2', '1.4a3', '1.4b3',
                    '1.4c3']:
        try:
            StrictVersion(vstring)
        except ValueError:
            pass
        else:
            raise AssertionError(
                "StrictVersion should not accept '%s'" % vstring)


# Generated at 2022-06-22 22:23:12.786341
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    V = Version
    assert V('1.5.1') < V('1.5.2dev')
    assert V('1.5.1') < V('1.5.2a1')
    assert V('1.5.1') != V('1.5.2')
    assert V('1.5.2') > V('1.5')
    assert V('1.5.2') < V('7.5')
    assert (V('1.5.1') > V('1.5') and
            V('1.5.1') < V('1.6a1'))
    assert V('1.5.2') == V('1.5.2')
    assert V('2.5') > V('2.2')
    assert V('2.5.0') > V('2.5a1')

# Generated at 2022-06-22 22:23:14.645068
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.2.3a4")
    assert v.__str__() == "1.2.3a4"

test_StrictVersion___str__()



# Generated at 2022-06-22 22:23:16.548571
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    import doctest
    test_results = doctest.testmod()

    if test_results.failed:
        raise ImportError("Unit test for StrictVersion.py failed.")



# Generated at 2022-06-22 22:23:27.580312
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # parse string with only numbers
    s = '1.0'
    lv = LooseVersion()
    lv.parse(s)
    assert(lv.version == [1,0])

    # parse string with only letters
    s = 'a.b'
    lv = LooseVersion()
    lv.parse(s)
    assert(lv.version == ['a', 'b'])

    # parse string with numbers and letters
    s = 'a2.b2'
    lv = LooseVersion()
    lv.parse(s)
    assert(lv.version == ['a', 2, 'b', 2])

    # parse string with numbers, letters and dots
    s = '.a.3.b.4.'
    lv = LooseVersion()
    lv.parse(s)

# Generated at 2022-06-22 22:23:30.017237
# Unit test for constructor of class Version
def test_Version():
    for vs in ['', '1.2.3', 'a.b.c']:
        Version(vs)


# Generated at 2022-06-22 22:23:34.483612
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion("1.1.0")
    assert repr(v) == "LooseVersion ('1.1.0')"
    v = LooseVersion("1.2.0-a2")
    assert repr(v) == "LooseVersion ('1.2.0-a2')"


# Generated at 2022-06-22 22:23:37.204282
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2.3.4')
    repr = eval(repr(v))
    assert repr.version == v.version and repr.vstring == v.vstring



# Generated at 2022-06-22 22:23:39.589121
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion("1.0.4a3")
    assert repr(v) == "StrictVersion ('1.0.4a3')"


# Generated at 2022-06-22 22:23:52.443890
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    StrictVersion('0.7.0')
    StrictVersion('1.3')
    StrictVersion('1.3.0')

    # Prerelease tags are allowed
    StrictVersion('1.3a1')
    StrictVersion('1.3.0a1')
    StrictVersion('1.3.0a1.0')

    # Unicode and bytes (interpreted as ASCII) both work
    StrictVersion(b'1.3.0')
    StrictVersion('1.3.0')

    # Leading zeros are not allowed for the first component
    try:
        StrictVersion('01.3.0')
    except ValueError:
        pass
    else:
        raise AssertionError

    # Leading zeros are allowed for subsequent components
    StrictVersion('1.03.0')
    Strict

# Generated at 2022-06-22 22:23:56.009177
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    expected = NotImplemented
    actual = v.__gt__('1.0')
    assert actual == expected, 'actual: %s, expected: %s' % (actual, expected)

# Generated at 2022-06-22 22:24:00.761453
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version ("1.2.3")
    expected="Version ('1.2.3')"
    print ("Expected: {}".format(expected))
    print ("Actual: {}".format(v.__repr__()))
    assert (v.__repr__()==expected)


# Generated at 2022-06-22 22:24:03.696166
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version()
    version._cmp = lambda x: 0
    assert version > ""
    version = Version()
    version._cmp = lambda x: NotImplemented
    assert version > ""



# Generated at 2022-06-22 22:24:10.163232
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('').parse('').version == []
    assert LooseVersion('').parse('1').version == [1]
    assert LooseVersion('').parse('1.2').version == [1, 2]
    assert LooseVersion('').parse('1.2.3').version == [1, 2, 3]
    assert LooseVersion('').parse('1.2.0').version == [1, 2, 0]
    assert LooseVersion('').parse('1.02').version == [1, '02']
    assert LooseVersion('').parse('1.2.3.4.5.6').version == \
           [1, 2, 3, 4, 5, 6]

# Generated at 2022-06-22 22:24:17.606486
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    StrictVersion("1.2.3")
    StrictVersion("1.2.3.4.5")
    StrictVersion("1.2.0")
    StrictVersion("1.2")
    StrictVersion("1.2b3")
    StrictVersion("1.2b3.4")
    StrictVersion("1.2c1")
    StrictVersion("1.2.3.a.4")
    StrictVersion("1.2.3.b.4")
    StrictVersion("1.2.3.c.4")
    StrictVersion("1.2.4.4.5")
    StrictVersion("1.2.4.4.5.6.7")
    StrictVersion("1.2.4.4.5.6.7.8")

# Generated at 2022-06-22 22:24:24.218955
# Unit test for method __lt__ of class Version

# Generated at 2022-06-22 22:24:29.337846
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """Method __repr__ of class LooseVersion."""
    v = LooseVersion('1.3')
    assert v.__repr__() == "LooseVersion ('1.3')"
    v = LooseVersion('1.3b')
    assert v.__repr__() == "LooseVersion ('1.3b')"



# Generated at 2022-06-22 22:24:31.142881
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('0')", repr(v)

# Generated at 2022-06-22 22:24:33.278429
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version = StrictVersion("2.7.2.2")
    assert str(strict_version) == "2.7.2.2"

# Generated at 2022-06-22 22:24:37.957026
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version('0.1.0')
    assert version < '0.1.1'
    assert version < '0.2.0'
    assert version < '1.0.0'



# Generated at 2022-06-22 22:24:46.676918
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.tests import support

    def check(inst, other, expected):
        actual = inst.__ge__(other)
        if actual is not expected:
            raise AssertionError('expected {}, got {} for ({}).__ge__({})'.format(
                expected, actual, inst, other))

    check(
        Version('1.1'),
        Version('1.1'),
        True
    )

    check(
        Version('2'),
        Version('1.1'),
        True
    )

    check(
        Version('1.1'),
        Version('2'),
        False
    )

    check(
        Version('1.1.0.0.0.1'),
        Version('1.1'),
        True
    )


# Generated at 2022-06-22 22:24:54.228710
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    vclass = StrictVersion
    for s, n in [("0.4.0", (0, 4, 0)),
                 ("1.0", (1, 0)),
                 ("1.0.0", (1, 0, 0))]:
        assert vclass(s).version == n
    for s in ["1.0.0.0", ".1", "1.", "quux-0.6"]:
        try:
            vclass(s)
        except ValueError:
            pass
        else:
            print("%r should be invalid" % s)



# Generated at 2022-06-22 22:25:02.098237
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    cases = ["1.5.1",   # simple case
             "1.5.2b2", # beta release
             "161",     # minor release missing
             "0.9",     # major release missing
             "1.2.3a0", # alpha release
             "0.0.0",   # zero releases
             "1.1",     # final releases
             "1.1.1",   # final releases
             "1.1b1",   # beta releases
             "1.1a2"    # alpha releases
             ]

# Generated at 2022-06-22 22:25:10.691556
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:25:12.240479
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('')
    v2 = Version('')
    return v1 <= v2



# Generated at 2022-06-22 22:25:19.709846
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test with a prerelease.
    v = StrictVersion("1.6.1.dev123")
    expected = "1.6.1.dev123"
    assert v.__str__() == expected
    # Test without a prerelease.
    v = StrictVersion("1.6.1")
    expected = "1.6.1"
    assert v.__str__() == expected
    # Test without a micro version.
    v = StrictVersion("1.6")
    expected = "1.6"
    assert v.__str__() == expected


# Generated at 2022-06-22 22:25:21.240110
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Tests method __lt__ of class Version
    """
    pass



# Generated at 2022-06-22 22:25:25.217425
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion("1.2.3")
    print(repr(v))
    

# Generated at 2022-06-22 22:25:28.532716
# Unit test for constructor of class Version
def test_Version():
    v = Version()

    v = Version('1.2.3')
    assert repr(v).endswith(" ('1.2.3')")

    v = Version(1, 2, 3)
    assert repr(v).endswith(" (1.2.3)")



# Generated at 2022-06-22 22:25:32.230475
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vstring in ('0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5',
                    '0.9.6', '1.0', '2.7.2', '1.0.4a3', '1.0.4b1', '1.0.4'):
        assert str(StrictVersion(vstring)) == vstring


# Generated at 2022-06-22 22:25:35.975025
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    version = LooseVersion('2.0')
    r = repr(version)
    assert r == "LooseVersion ('2.0')"

# Generated at 2022-06-22 22:25:43.354297
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:25:53.271592
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # check the contents, and the string representation, of version numbers
    version = LooseVersion("1.0a2.dev456")
    assert version.version == (1, 0, 'a', 2, 'dev', 456)
    assert str(version) == "1.0a2.dev456"

    version = LooseVersion("1.0.dev456")
    assert version.version == (1, 0, 'dev', 456)
    assert str(version) == "1.0.dev456"

    version = LooseVersion("1.0.dev456.gabcdef")
    assert version.version == (1, 0, 'dev', 456, 'g', 'abcdef')
    assert str(version) == "1.0.dev456.gabcdef"

# Machine- and human-readable versions of license strings


# Generated at 2022-06-22 22:26:01.654940
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.13++')
    assert lv.version == [1, 13, '++']

    lv.parse('0.960923')
    assert lv.version == [0, 960923]

    lv.parse('3.10a')
    assert lv.version == [3, 10, 'a']

    lv.parse('11g')
    assert lv.version == [11, 'g']

# Generated at 2022-06-22 22:26:10.697964
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.1')
    v2 = Version('1.12')
    assert not (v1 == v2)
    assert not (v1 != v2)
    v1 = Version('1.1')
    v2 = Version('1.12')
    assert not (v1 == v2)
    assert v1 != v2
    v1 = Version('1.1')
    v2 = Version('1.1')
    assert v1 == v2
    assert not (v1 != v2)


# Generated at 2022-06-22 22:26:21.696347
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import re
    import unittest

    class TestCase(unittest.TestCase):

        def test_parse_string(self):
            self.assertEqual(LooseVersion('1.1').version, (1, 1))
            self.assertEqual(LooseVersion('1.1.0').version, (1, 1, 0))
            self.assertEqual(LooseVersion('123').version, (123,))
            self.assertEqual(LooseVersion('a').version, ('a',))
            self.assertEqual(LooseVersion('A').version, ('A',),)
            self.assertEqual(LooseVersion('a.1').version, ('a', 1))
            self.assertEqual(LooseVersion('A.1').version, ('A', 1))

# Generated at 2022-06-22 22:26:24.562853
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.2')
    assert v.__str__() == v.vstring == '1.2'


# Generated at 2022-06-22 22:26:27.744990
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.2.3')
    assert v >= '1.2.3'
    assert v >= '1.2.2'
    assert not v >= '1.2.4'

# Generated at 2022-06-22 22:26:31.330938
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = My_Version("1.1")
    w = My_Version("1.2")
    assert v.__gt__(w) == False

test_Version___gt__()

# Generated at 2022-06-22 22:26:35.700189
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version("1.0")
    assert (v1 <= "1.0")
    assert (v1 <= v1)
    assert (v1 <= "1.1")

# Generated at 2022-06-22 22:26:39.957935
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert v1.__lt__(v2) == NotImplemented
    assert v1.__lt__('1.0') == NotImplemented


# Generated at 2022-06-22 22:26:51.792605
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # The string representation of version numbers is fully specified.
    #
    ver = StrictVersion
    assert str(ver("1.0")) == "1.0"
    assert str(ver("1.0.0")) == "1.0.0"
    assert str(ver("1.0a1")) == "1.0a1"
    assert str(ver("1.0.0a1")) == "1.0.0a1"
    assert str(ver((1,))) == "1.0"
    assert str(ver((1, 0))) == "1.0"
    assert str(ver((1, 0, 0))) == "1.0.0"
    assert str(ver((1, 0, 0, "a", 1))) == "1.0.0a1"


# Generated at 2022-06-22 22:26:55.258490
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():assert StrictVersion('').__str__() == StrictVersion(0,0).__str__() == '0.0'

# Generated at 2022-06-22 22:26:57.487560
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert str(StrictVersion('1.2.3a4')) == '1.2.3a4'


# Utility classes

# Generated at 2022-06-22 22:27:08.320529
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    import sys

    if LooseVersion(sys.version) < '2.0':
        raise AssertionError("test must be run with Python 2.0 or greater")

    s = '2.2.0'
    v = LooseVersion(s)

    assert v.version == (2, 2, 0), \
           '%s should be (2, 2, 0), got %s' % (s, v.version)
    assert str(v) == s, 'str(v) should be %s, got %s' % (s, str(v))
    assert repr(v) == "LooseVersion ('2.2.0')", \
           'repr(v) should be LooseVersion (\'2.2.0\'), got %s' % repr(v)
# End of unit test


# Note that the class

# Generated at 2022-06-22 22:27:09.428580
# Unit test for method __le__ of class Version
def test_Version___le__():
   with pytest.raises(NotImplementedError):
       Version().__le__(str)



# Generated at 2022-06-22 22:27:16.693829
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse("1.0.0")
    assert lv.version == [1, 0, 0]
    lv.parse("1.5.1b1")
    assert lv.version == [1, 5, 1, 'b', 1]
    lv.parse("161")
    assert lv.version == [161]
    lv.parse("3.10a")
    assert lv.version == [3, 10, 'a']
    lv.parse("8.02")
    assert lv.version == [8, 2]
    lv.parse("3.4j")
    assert lv.version == [3, 4, 'j']
    lv.parse("1996.07.12")
    assert lv.version == [1996, 7, 12]

# Generated at 2022-06-22 22:27:28.689355
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(vstring):
        assert str(StrictVersion(vstring)) == vstring
        assert repr(StrictVersion(vstring)) == \
               "StrictVersion ('%s')" % vstring

    test('1.0')
    test('1.0.1')
    test('1.1')
    test('1.2.3a2')
    test('1.2.3b1')
    test('1.2.3b1')
    test('1.2.3')
    test('1.2.3.4')


# Interface for version-number classes -- must be implemented
# by the following classes (the concrete ones -- Version should
# be treated as an abstract class).
#    __init__ (string) - create and take same action as 'parse'
#                        (string parameter is optional)
#

# Generated at 2022-06-22 22:27:33.264984
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Version class should not have a __gt__ method
    from distutils.version import Version
    c = Version()
    try:
        c.__gt__('1.2.3')
    except AttributeError:
        pass
    else:
        raise AssertionError
test_Version___gt__()


# Generated at 2022-06-22 22:27:37.569493
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Version.__repr__ -> String
    # Returns a string representation of a version object.
    try:
        v = Version()
    except (TypeError, AttributeError):
        v = Version('1.2.3')
    assert repr(v) == "Version ('%s')" % (str(v),), repr(v)

# Generated at 2022-06-22 22:27:40.292689
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import _BaseVersion, StrictVersion, LooseVersion
    v = Version()
    assert v == '1.0'



# Generated at 2022-06-22 22:27:50.483785
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion('1.0')
    assert v.version == (1, 0, 0), v.version
    assert v.prerelease is None, v.prerelease

    v = StrictVersion('1.1pre2')
    assert v.version == (1, 1, 0), v.version
    assert v.prerelease == ('pre', 2), v.prerelease

    assert_raises(ValueError, StrictVersion, '1.1.1.0')
    assert_raises(ValueError, StrictVersion, '1.1.1.0.0')
    assert_raises(ValueError, StrictVersion, '1.1.1rc0')
    assert_raises(ValueError, StrictVersion, '1.1pl0')

# Generated at 2022-06-22 22:28:01.565559
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
        LG = LooseVersion
        parts = (1, 5, 1)
        for v in ('1.5.1', '1.5.1-', '1.5.1+'):
            assert LG(v).parse(v) == parts
            assert LG(v).version == parts

        parts = (1, 5, 1, 'beta', 1)
        for v in ('1.5.1-beta', '1.5.1beta', '1.5.1-beta-1', '1.5.1beta1'):
            assert LG(v).parse(v) == parts
            assert LG(v).version == parts

        parts = (1, 5, 1, 'final', 0)

# Generated at 2022-06-22 22:28:13.603588
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    n = StrictVersion()
    n.parse('0.0.1')
    assert n.version == (0, 0, 1)

    # This should raise a ValueError
    try:
        n.parse('Not a valid string')
    except ValueError:
        pass
    else:
        assert False

    n.parse('1.2.10')
    assert n.version == (1, 2, 10)

    n.parse('1.2b10')
    assert n.version == (1, 2, 0)
    assert n.prerelease == ('b', 10)

    # This should raise a ValueError
    try:
        n.parse('1.2.12b1')
    except ValueError:
        pass
    else:
        assert False

    # This should raise an AssertionError

# Generated at 2022-06-22 22:28:25.556298
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    StrictVersion('1.2.3').parse('1.2.3')
    StrictVersion('1.2.3').parse('   1.2.3')
    StrictVersion('1.2.3.4').parse('   1.2.3.4')
    StrictVersion('1.2').parse('   1.2')
    StrictVersion('1.2.3.4a1').parse('   1.2.3.4a1')
    StrictVersion('1.2.3a1').parse('   1.2.3a1')
    StrictVersion('1.2.3-3.4').parse('   1.2.3-3.4')
    StrictVersion('1.2.3b1').parse('   1.2.3b1')

# Generated at 2022-06-22 22:28:28.180540
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest, doctest, Version
    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite(Version))
    return suite

# Generated at 2022-06-22 22:28:39.905212
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    f = Version
    assert f('0') < f('1'), "'0' < '1' failed"
    assert f('0.4') < f('0.5'), "'0.4' < '0.5' failed"
    assert f('0.4') < f('0.4.1'), "'0.4' < '0.4.1' failed"
    assert f('0.4a') < f('0.4b'), "'0.4a' < '0.4b' failed"
    assert f('0.4c') < f('0.5'), "'0.4c' < '0.5' failed"
    assert f('0.960923') < f('1.2.3a0'), "'0.960923' < '1.2.3a0' failed"

# Generated at 2022-06-22 22:28:51.537100
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse('5.5.kw')
    assert v.version == [5,5,'kw']

    v.parse('2.2beta29')
    assert v.version == [2,2,'beta',29]

    v.parse('1.13++')
    assert v.version == [1,13,'++']

    v.parse('2.0b1pl0')
    assert v.version == [2,0,'b',1,'pl',0]

    v.parse('0.960923')
    assert v.version == [0,960923]

    v.parse('11g')
    assert v.version == [11,'g']

    v.parse('2g6')
    assert v.version == [2,'g',6]


# Generated at 2022-06-22 22:28:53.792830
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version(vstring='1')
    v2 = Version(vstring='1')
    assert (v1 == v2) == True, "Not equal"
    assert (v1 == '1') == True, "Not equal"

# Generated at 2022-06-22 22:28:54.388866
# Unit test for method __ge__ of class Version
def test_Version___ge__(): return None

# Generated at 2022-06-22 22:29:03.606601
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Create the class instance
    _version = Version()

    # Call the method
    # The actual test is that we're raising an exception, as the
    # method call should fail.
    try:
        _version.__eq__(None)
        raise Exception("Expected a ValueError to be raised")
    except ValueError as e:
        # The expected exception we're checking for
        assert(type(e) == ValueError)

    # The following print should have no output.
    print("__eq__ test passed")

# Generated at 2022-06-22 22:29:11.434421
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert str(LooseVersion('1.1.1b2')) == '1.1.1b2'
    assert str(LooseVersion('1.1.1')) == '1.1.1'
    assert str(LooseVersion('1.1.1a1')) == '1.1.1a1'
    assert str(LooseVersion('0.0.1')) == '0.0.1'
    assert str(LooseVersion('0.0.0')) == '0.0.0'

# Generated at 2022-06-22 22:29:22.721740
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    from test import test_support
    classLV = LooseVersion("Sphinx (1.4.9)")
    assert str(classLV) == 'Sphinx (1.4.9)'
    classLV = LooseVersion("1.0")
    assert str(classLV) == '1.0'
    classLV = LooseVersion("1.0.0")
    assert str(classLV) == '1.0.0'
    classLV = LooseVersion("1.1b1")
    assert str(classLV) == '1.1b1'
    classLV = LooseVersion("1.1pl3")
    assert str(classLV) == '1.1pl3'
    classLV = LooseVersion("2.5.6")
    assert str(classLV) == '2.5.6'


# Generated at 2022-06-22 22:29:29.026523
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion('1.2.3.4')
    assert l.version == [1, 2, 3, 4]
    l = LooseVersion('1.2.3a')
    assert l.version == [1, 2, 3, 'a']
    l = LooseVersion('1.2.3b-4')
    assert l.version == [1, 2, 3, 'b-4']
    l = LooseVersion('1.00000')
    assert l.version == [1, 0, 0, 0]


# Generated at 2022-06-22 22:29:38.033170
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:29:44.077395
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    for v in ['0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5', '0.9.6', '1.0',
              '1.0.4a3', '1.0.4b1', '1.0.4']:
        assert str(StrictVersion(v)) == v.strip()



# Generated at 2022-06-22 22:29:52.943954
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:29:55.996986
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import pytest
    with pytest.raises(NotImplementedError):
        Version().__eq__(None)


# Generated at 2022-06-22 22:29:58.218750
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('1.3.3').__str__() == '1.3.3'

# Generated at 2022-06-22 22:30:08.006574
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v1 = StrictVersion("1.0")
    assert v1.version == (1, 0, 0), "v1.version == (1, 0, 0)"
    assert v1.prerelease == None, "v1.prerelease == None"

    v2 = StrictVersion("1.0a1")
    assert v2.version == (1, 0, 0), "v2.version == (1, 0, 0)"
    assert v2.prerelease == ('a', 1), "v2.prerelease == ('a', 1)"

    v3 = StrictVersion("1.0b2")
    assert v3.version == (1, 0, 0), "v3.version == (1, 0, 0)"
    assert v3.prerelease == ('b', 2), "v3.prerelease == ('b', 2)"



# Generated at 2022-06-22 22:30:10.611209
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert repr(Version()) == "Version ('0')"



# Generated at 2022-06-22 22:30:14.475564
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test calling StrictVersion.__str__ with a valid version string.
    vstring = StrictVersion('1.0').__str__()
    assert vstring == '1.0'
    # The following test will fail with Python 3.0.
    # vstring = StrictVersion('1.0a0').__str__()
    # assert vstring == '1.0a0'


# Generated at 2022-06-22 22:30:18.636069
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    a = Version("0.4.0")
    b = Version("0.5.0")
    assert a < b
    assert not a > b
    assert a <= b
    assert not a >= b
    assert not a == b

# Generated at 2022-06-22 22:30:29.810808
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    sv = StrictVersion('1.10')
    assert sv.version == (1, 10, 0), sv.version
    assert sv.prerelease == None, sv.prerelease

    sv = StrictVersion('1.10b2')
    assert sv.version == (1, 10, 0), sv.version
    assert sv.prerelease == ('b', 2), sv.prerelease

    sv = StrictVersion('2.7.3')
    assert sv.version == (2, 7, 3), sv.version
    assert sv.prerelease == None, sv.prerelease

    sv = StrictVersion('2.7.3.1')
    assert sv.version == (2, 7, 3), sv.version
    assert sv.prerelease == None, sv.prerelease


# Generated at 2022-06-22 22:30:31.304851
# Unit test for method __le__ of class Version
def test_Version___le__():
	assert Version() <= '1.12.1'




# Generated at 2022-06-22 22:30:36.590796
# Unit test for constructor of class Version
def test_Version():
    class TestVersion(Version):
        def __init__(self, vstring):
            Version.__init__(self, vstring)
            self.vstring = vstring

        def parse(self, vstring):
            pass

        def __str__(self):
            return self.vstring

        def _cmp(self, other):
            return 0

    assert str(TestVersion('XXX')) == 'XXX'
    assert repr(TestVersion('XXX')) == "TestVersion ('XXX')"



# Generated at 2022-06-22 22:30:43.032539
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import unittest
    class LooseVersion___str__TestCase(unittest.TestCase):
        def test_1(self):
            """LooseVersion('1.2').__str__() == '1.2'"""
            self.assertEqual(LooseVersion('1.2').__str__(), '1.2')
    unittest.main()

# Generated at 2022-06-22 22:30:51.250281
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    class_   = StrictVersion
    vstring  = "1.0a1"

    # Create an instance of the class
    s = class_()
    s.parse(vstring)

    assert s.version[0] == 1
    assert s.version[1] == 0
    assert s.version[2] == 0
    assert s.prerelease[0] == 'a'
    assert s.prerelease[1] == 1


# Generated at 2022-06-22 22:30:52.515103
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert v < '1'

# Generated at 2022-06-22 22:30:54.468013
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    version = Version(vstring='1.0')
    assert repr(version) == "Version ('1.0')"


# Generated at 2022-06-22 22:30:57.267260
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('1.2.3')
    r = repr(v)
    assert r == "LooseVersion ('1.2.3')"


# Generated at 2022-06-22 22:31:08.758023
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # zero argument
    try:
        ob = Version()
    except:
        assert False, "creation of object Version from no arguments should not raise exception"
    assert str(ob) == "<Version object at 0x?>", "str(Version()) should return '<Version object at 0x?>'"
    assert repr(ob) == "Version ('0')", "repr(Version()) should return 'Version (''0'')'"
    # one argument
    try:
        ob = Version("1.2.3")
    except:
        assert False, "creation of object Version from arguments ('1.2.3') should not raise exception"
    assert str(ob) == "1.2.3", "str(Version('1.2.3')) should return '1.2.3'"

# Generated at 2022-06-22 22:31:12.176113
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    s = LooseVersion('2.2')
    assert isinstance(s.version, tuple)
    assert s.version == (2, 2)
    assert str(s) == '2.2'



# Generated at 2022-06-22 22:31:17.227394
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """
    >>> v = Version("0.0.1")
    >>> v > None
    >>> v > "0.0.1"
    >>> v > "0.0.2"
    >>> v > "0.0.0"
    >>> v >= "0.0.0"
    >>> v >= "0.0.1"
    """



# Generated at 2022-06-22 22:31:21.023024
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion('1.a.1')
    assert lv.version == [1, 'a', 1]

    lv = LooseVersion('1.1.a')
    assert lv.version == [1, 1, 'a']


# Generated at 2022-06-22 22:31:26.300557
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v1 = LooseVersion("6.0.8rc2")
    v2 = LooseVersion("4.4.1.1")
    v3 = LooseVersion("2.3.3.3")
    assert v1.__repr__() == "LooseVersion ('6.0.8rc2')"
    assert v2.__repr__() == "LooseVersion ('4.4.1.1')"
    assert v3.__repr__() == "LooseVersion ('2.3.3.3')"



# Generated at 2022-06-22 22:31:35.618892
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:31:46.750862
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion("99.4.4")) == "99.4.4"
    assert str(StrictVersion("99")) == "99.0"
    assert str(StrictVersion("99.4.4.3")) == "99.4.4"
    assert str(StrictVersion("99.4.4.a4")) == "99.4.4a4"
    assert str(StrictVersion("99.4")) == "99.4"
    assert str(StrictVersion("99.4.a4")) == "99.4a4"
    assert str(StrictVersion("99.4.b4")) == "99.4b4"
    assert str(StrictVersion("99.4.a0")) == "99.4a0"
    assert str(StrictVersion("99.4.b0"))

# Generated at 2022-06-22 22:31:53.928276
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    tests = ('1.0', '1.0.4a3', '1.0.4b1', '1.0.4', '1.1a2', '1.1a2.post345.dev456')

    for test_case in tests:
        try:
            assert StrictVersion(test_case) == test_case
        except ValueError:
            assert False


# Generated at 2022-06-22 22:31:56.441572
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    assert(v1 <= v2)
    assert(v1 <= v1)
    assert(v2 <= v1)

# Generated at 2022-06-22 22:32:06.589907
# Unit test for constructor of class StrictVersion

# Generated at 2022-06-22 22:32:09.473699
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    return v1 == v2

# Generated at 2022-06-22 22:32:17.309566
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion("1").version == (1,0,0)
    assert StrictVersion("1.2").version == (1,2,0)
    assert StrictVersion("1.2.3").version == (1,2,3)
    assert StrictVersion("1.2a1").version == (1,2,0)
    assert StrictVersion("1.2a1").prerelease == ('a',1)
    assert StrictVersion("1.2b3").version == (1,2,0)
    assert StrictVersion("1.2b3").prerelease == ('b',3)
    assert StrictVersion("1.2.3.4") == "1.2.3"
    assert StrictVersion("1.2.0").version == (1,2,0)


# Generated at 2022-06-22 22:32:26.718417
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    strict_version = StrictVersion('1.3')
    assert strict_version.version == (1, 3, 0)

    try:
        StrictVersion('2.7.2.2')
    except ValueError as e:
        assert e.args == ("invalid version number '2.7.2.2'",)
    else:
        raise AssertionError("invalid version number did not raise")

    try:
        StrictVersion('1.3.a4')
    except ValueError as e:
        assert e.args == ("invalid version number '1.3.a4'",)
    else:
        raise AssertionError("invalid version number did not raise")


# Generated at 2022-06-22 22:32:31.036888
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from distutils.version import Version
    from distutils.tests import support
    from io import StringIO
    import pickle
    s = StringIO()
    version = Version('1.2.3')
    pickle.dump(version, s, pickle.HIGHEST_PROTOCOL)
    version1 = pickle.loads(s.getvalue())
    support.compare_obj(version, version1)

# Generated at 2022-06-22 22:32:36.679145
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    # Test instantiating with a version string
    v = Version('1.2.3')
    assert(repr(v) == "Version ('1.2.3')")

    # Test instantiating with a version string and parsing it
    v = Version()
    v.parse('1.2.3')
    assert(repr(v) == "Version ('1.2.3')")
