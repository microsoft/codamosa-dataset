

# Generated at 2022-06-22 22:22:39.531479
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # pylint: disable=E1120
    assert str(StrictVersion("1.2.3.a")) == "1.2.3a"
    assert str(StrictVersion("1.2.3b")) == "1.2.3b"

test_StrictVersion___str__()



# Generated at 2022-06-22 22:22:43.821472
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert StrictVersion('1.2.3') <= StrictVersion('1.2.3')
    assert StrictVersion('1.2.3') <= StrictVersion('1.2.4')
    assert not StrictVersion('1.2.3') <= StrictVersion('1.2.2')

# Generated at 2022-06-22 22:22:49.915398
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    from distutils.tests import support
    import unittest

    class TestCase(support.EnvironGuard, unittest.TestCase):
        def test_mixin(self):

            v = StrictVersion('1.0')
            w = StrictVersion('1.0')
            x = StrictVersion('1.0.0')
            y = StrictVersion('1.0a1')
            z = StrictVersion('1.0b1')

            self.assertTrue(v == w)
            self.assertTrue(v == x)
            self.assertTrue(v != y)

            self.assertTrue(x == w)
            self.assertTrue(x != y)

            self.assertTrue(y != z)

            self.assertTrue(z < y)
            self.assertTrue(y < x)

           

# Generated at 2022-06-22 22:22:53.247314
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # The code to be unit tested
    result = LooseVersion('1.1.1')
    # The expected result
    expected = ([1, '.', 1, '.', 1])
    assert result.version == expected
    return


# Generated at 2022-06-22 22:22:55.471485
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """LooseVersion.__str__()"""
    c = LooseVersion("1.0a1")
    assert str(c) == "1.0a1"


# Generated at 2022-06-22 22:22:58.962261
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import Version
    v = Version('1.0')
    assert not v.__ge__(2)
    assert not v.__ge__(0)
    assert v.__ge__(0.3)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 22:23:02.242112
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  v1 = Version()
  v2 = Version()
  assert (v1 >= v2) == True
  return


# Generated at 2022-06-22 22:23:07.277789
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('1.2').__str__() == '1.2'
    assert StrictVersion('1.2.3.4').__str__() == '1.2.3'
    assert StrictVersion('1.2a3').__str__() == '1.2a3'


# Generated at 2022-06-22 22:23:09.446484
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    from distutils.tests import support
    support.run_unittest(Test__str_l)

# Generated at 2022-06-22 22:23:17.488704
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    import unittest
    import sys
    from distutils.tests.test_version import VersionTestCase

    # The following 2 lines are for Python 2.x
    if sys.version_info[0] < 3:
        exec("""def __repr__(self):\n    return self.__str__()""")
    #

    # Warning: the following may fail if latest version of the Python
    # distutils distribution is not available
    distutils_version = __import__('distutils.version')
    test_version = distutils_version.LooseVersion('0.93a0')

    class TestCase(VersionTestCase):

        def setUp(self):
            VersionTestCase.setUp(self)
            self.testcase = test_version

        def tearDown(self):
            VersionTestCase.tearDown(self)

# Generated at 2022-06-22 22:23:21.470154
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    vString = "0.3.0a3"
    lv = LooseVersion(vString)
    assert lv.__str__() == vString, "__str__ method failed"


# Generated at 2022-06-22 22:23:22.428741
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert str(LooseVersion('1.5.3.3')) == '1.5.3.3'


# Generated at 2022-06-22 22:23:25.635123
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
	ver = LooseVersion('1.5.5')
	temp = repr(ver)
	r = "'1.5.5'"
	return temp == r

# Generated at 2022-06-22 22:23:37.690463
# Unit test for method parse of class StrictVersion

# Generated at 2022-06-22 22:23:39.454629
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('1.1').__str__() == '1.1'

# Generated at 2022-06-22 22:23:52.094738
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Check basic construction
    LooseVersion("1.2.3")
    LooseVersion("1.1")
    LooseVersion("1")

    # 'Object identity.  LooseVersion instances are equal if and only if
    # their string forms compare equal.'
    v1 = LooseVersion("1.2.3")
    v2 = LooseVersion("1.2.3")
    assert v1 == v2, 'A == B'
    assert (v1 != v2) is False, 'A != B is False'
    assert not v1 != v2, 'not (A != B)'

    v1, v2 = LooseVersion("1"), LooseVersion("2")
    assert v1 < v2, 'A < B'
    assert v2 > v1, 'B > A'
    assert v2 >= v1

# Generated at 2022-06-22 22:24:03.105862
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:24:11.180820
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion("1.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion("1.0.0")
    assert v.version == (1, 0, 0)
    assert v.prerelease is None

    v = StrictVersion("1.0a1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    v = StrictVersion("1.0.0a1")
    assert v.version == (1, 0, 0)
    assert v.prerelease == ('a', 1)

    try:
        v = StrictVersion("1.0-a1")
        assert 0
    except ValueError:
        pass


# Generated at 2022-06-22 22:24:13.293968
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion('blah')
    assert isinstance(v.version, list)
    assert v.version == ['b','l','a','h']

    c = LooseVersion('-123.456')
    assert isinstance(c.version, list)
    assert c.version == [-123,456]

# Generated at 2022-06-22 22:24:16.102464
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion("1.2a3")
    assert lv.__str__() == "1.2a3"


# Generated at 2022-06-22 22:24:20.340874
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    v1 = Version('5')
    assert v1 >= v


    v2 = Version('6')
    assert v2 >= v1


    v3 = Version('6')
    assert v2 >= v3


    v4 = Version('6.0')
    v5 = Version('6.0.0')
    assert v4 >= v5


    v6 = Version('6.0.0.0')
    assert v5 >= v6


    v7 = Version('6.0.0.0.0')
    assert v6 >= v7


    v8 = Version('6.0.0.0.0.0')
    assert v7 >= v8


    assert not v8 >= v7

    assert not v7 >= v6

    assert not v6 >= v5


# Generated at 2022-06-22 22:24:25.607323
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    for args in [  # Invalid values for the vstring argument
            '',
            '-',
            '.',
            '1',
            '1.',
            '1.2',
            '1.2.3',
            '1.2.3.4',
    ]:
        with pytest.raises(ValueError):
            Version(vstring=args)

# Generated at 2022-06-22 22:24:28.029543
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    x = Version("1.2a1")
    assert repr(x) == "Version ('1.2a1')"

# Generated at 2022-06-22 22:24:30.057556
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version('1.0.0')
    assert repr(v) == "Version ('1.0.0')"


# Generated at 2022-06-22 22:24:31.349528
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    # version.py:268


# Generated at 2022-06-22 22:24:36.924090
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    version_string = '1.1.0'
    result = LooseVersion(version_string).__repr__()
    expected_result = "LooseVersion ('%s')" % version_string
    assert result == expected_result
    


# Generated at 2022-06-22 22:24:40.613943
# Unit test for method __le__ of class Version
def test_Version___le__():
    for other in [
        Version(),
        Version('1')]:

        for param in [
            Version(),
            Version('1')]:

            other.__le__(param)


# Generated at 2022-06-22 22:24:42.675736
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert repr(LooseVersion("1.0.1")) == 'LooseVersion (\'1.0.1\')'


# Generated at 2022-06-22 22:24:51.418600
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse("1.2.3")
    assert v.version == (1, 2, 3), v.version
    assert v.prerelease == None, v.prerelease
    v.parse("1.2.3a2")
    assert v.version == (1, 2, 3), v.version
    assert v.prerelease == ('a', 2), v.prerelease
    v.parse("1.2a2")
    assert v.version == (1, 2, 0), v.version
    assert v.prerelease == ('a', 2), v.prerelease
    try:
        v.parse("1.2.3a")
        assert False, "Did not raise a value error"
    except ValueError:
        pass

# Generated at 2022-06-22 22:24:58.941875
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    # Make sure the __str__ method of a LooseVersion object
    # returns the input string that created it.
    l = []
    # Generate a list of possible valid strings
    # for version identification

# Generated at 2022-06-22 22:25:02.847858
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion('1.2.3')
    print('1.2.3 =', v)


# Generated at 2022-06-22 22:25:09.493306
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v1 = LooseVersion(1)
    v2 = LooseVersion('1')
    v3 = LooseVersion('1.0')
    v4 = LooseVersion('2.0')
    assert v1 == v2
    assert v4 > v3
    assert v4 > v2
    assert v3 < v4
    assert v2 < v4
    assert v2 <= v4
    assert v2 <= v2


# Generated at 2022-06-22 22:25:11.414758
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from .version import Version

    v = Version('1')
    assert v > 0
    assert v > '1'



# Generated at 2022-06-22 22:25:14.769910
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    """Testing StrictVersion class constructor"""
    s = StrictVersion("1.4.4")
    assert str(s) == "1.4.4", "%s is not 1.4.4" % s

# Generated at 2022-06-22 22:25:15.691716
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(None) is False

# Generated at 2022-06-22 22:25:21.084464
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from types import ClassType
    from distutils2.version import Version
    from ansible_test.units.compat.mock import Mock
    from ansible_test.units.compat.mock import patch

    _version_, args, kwargs = Mock(), (), {}
    _self_ = args[0] = Mock(**{'_cmp.return_value': 0})

    assert Version.__ge__ is Version.__ge__.__func__
    Version.__ge__(_version_, *args, **kwargs)

    _self_._cmp.assert_called_with(_version_)



# Generated at 2022-06-22 22:25:23.550674
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():

    from distutils.version import LooseVersion
    v = LooseVersion ('1.2')
    assert repr(v) == "LooseVersion ('1.2')\n", repr(v)


# Generated at 2022-06-22 22:25:29.704127
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    _version = Version()
    _version._Version__ge__ = _stub_call('Version', '_Version__ge__', '_version')
    _version._cmp = _stub_call('Version', '_cmp', '_version')
    _version.__ge__('_other')


    _version = Version()
    _version._Version__ge__ = _stub_call('Version', '_Version__ge__', None)
    _version._cmp = _stub_call('Version', '_cmp', '_c')
    _version.__ge__('_other')

# Generated at 2022-06-22 22:25:41.499729
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    L = LooseVersion

    assert L('1.2.0') < L('1.2.1')
    assert L('1.2.1') > L('1.2.0')
    assert L('1.2.1') == L('1.2.1')
    assert L('1.2.0') != L('1.2.1')

    assert L('1.2.0') < L('1.2.1-1')
    assert L('1.2.1-1') > L('1.2.0')
    assert L('1.2.1-1') == L('1.2.1-1')
    assert L('1.2.0') != L('1.2.1-1')


# Generated at 2022-06-22 22:25:43.453227
# Unit test for method __repr__ of class Version
def test_Version___repr__():
  v = StrictVersion("2")
  assert repr(v) == "StrictVersion ('2')"

# Generated at 2022-06-22 22:25:44.442123
# Unit test for constructor of class Version
def test_Version():
    v = Version()


# Generated at 2022-06-22 22:25:48.475899
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    try:
        eq = assertEqual
        v = LooseVersion('1.13++')
        r = repr(v)
        eq(r, "LooseVersion ('1.13++')")
    except:
        print(repr(v))
        raise


# Generated at 2022-06-22 22:25:56.899201
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert (
        repr(StrictVersion("1.2.3.4")) == "StrictVersion ('1.2.3.4')")
    assert (
        repr(StrictVersion("1.2.3a4")) == "StrictVersion ('1.2.3a4')")
    assert (
        repr(StrictVersion("1.2.3b4")) == "StrictVersion ('1.2.3b4')")
    assert (
        repr(StrictVersion("1.2.3.4a5")) == "StrictVersion ('1.2.3.4a5')")
    assert (
        repr(StrictVersion("1.2.3.4b5")) == "StrictVersion ('1.2.3.4b5')")

# Generated at 2022-06-22 22:26:00.069811
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    """Unit test for Version.__repr__"""
    version = Version()
    result = repr(version)
    expected = "Version ('0')"
    assert result == expected, "result: %r != expected: %r" % (result, expected)




# Generated at 2022-06-22 22:26:00.653739
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    return None


# Generated at 2022-06-22 22:26:11.586295
# Unit test for constructor of class Version
def test_Version():
    # constructor should accept a string
    assert Version("1.2.3").version == "1.2.3"
    assert str(Version("1.2.3")) == "1.2.3"
    assert repr(Version("1.2.3")) == "Version ('1.2.3')"

    # constructor should also accept another Version instance
    assert Version(Version("1.2.3")).version == "1.2.3"
    assert str(Version(Version("1.2.3"))) == "1.2.3"
    assert repr(Version(Version("1.2.3"))) == "Version ('1.2.3')"

    # constructor should also accept a number
    try:
        from numbers import Number
    except ImportError:
        pass

# Generated at 2022-06-22 22:26:19.476613
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = LooseVersion('1.5.1')
    assert v.__str__() == '1.5.1'

    v = LooseVersion('1.5.2b2')
    assert v.__str__() == '1.5.2b2'

    v = LooseVersion('161')
    assert v.__str__() == '161'

    v = LooseVersion('3.10a')
    assert v.__str__() == '3.10a'

    v = LooseVersion('8.02')
    assert v.__str__() == '8.02'

    v = LooseVersion('3.4j')
    assert v.__str__() == '3.4j'

    v = LooseVersion('1996.07.12')

# Generated at 2022-06-22 22:26:20.758604
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v.__ge__(v)

# Generated at 2022-06-22 22:26:28.049812
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-22 22:26:36.445641
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion("1.3a2")
    assert StrictVersion("1.3.0a2")
    assert StrictVersion("1.3b1")
    assert not StrictVersion("1.3b1.1")
    assert StrictVersion("2.0")
    assert StrictVersion("2.1.1")
    assert StrictVersion("1.1") < StrictVersion("1.2")
    assert StrictVersion("1.1") < StrictVersion("1.2.1")
    assert StrictVersion("1.2") < StrictVersion("1.2.1")
    assert StrictVersion("1.1b2") < StrictVersion("1.1")
    assert StrictVersion("1.1a1") < StrictVersion("1.1a2")

# Generated at 2022-06-22 22:26:44.030396
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    class Version___lt__(unittest.TestCase):
        def test_object(self):
            ''' Object must be instance of Version '''
            testobj = Version("")
            testobj2 = Version("")
            self.assertIsInstance(testobj, Version)
            self.assertEqual(testobj._cmp(testobj2), 0)
    unittest.main()

# Generated at 2022-06-22 22:26:44.707061
# Unit test for constructor of class Version
def test_Version():
    v = Version()


# Generated at 2022-06-22 22:26:48.677953
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from distutils.version import Version
    assert repr(Version()) == 'Version (\'0\')'
    assert repr(Version('1.2.3a1')) == 'Version (\'1.2.3a1\')'

# Generated at 2022-06-22 22:26:57.112484
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    LV = LooseVersion


# Generated at 2022-06-22 22:27:00.837223
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('1.1')
    assert not (v >= '1.2')
    assert v >= '1.1'
    assert v >= Version('1.1')

# Generated at 2022-06-22 22:27:06.252088
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    try:
        StrictVersion('1.2.3')
        StrictVersion('1.2.3-a')
        StrictVersion('1.2.3-a1')
    except ValueError:
        print("error in strict version constructor")
    else:
        print("all ok")



# Generated at 2022-06-22 22:27:10.776440
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import tempfile

    # Create an instance of the class we are testing
    obj = Version('0.0.0')
    assert obj == '0.0.0'
    obj = Version('version')
    assert obj != '0.0.0'



# Generated at 2022-06-22 22:27:16.684657
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """Test for method __repr__ of class LooseVersion"""
    v = LooseVersion("2.2.0")
    assert v.__repr__() == "LooseVersion ('2.2.0')"


# Generated at 2022-06-22 22:27:28.600242
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    v0 = LooseVersion('0')
    assert v0 == (0,),        "simple numeric zero failed"
    assert v0 <  (0,1),       "simple numeric zero failed"

    v1 = LooseVersion('1.5.1')
    assert v1 == (1, 5, 1),   "simple numeric version failed"
    assert v1 <  (1, 6),      "simple numeric version failed"
    assert v1 <  (1, 5, 2),   "simple numeric version failed"
    assert v1 >  (1, 5),      "simple numeric version failed"
    assert v1 == '1.5.1',     "simple numeric version failed"
    assert v1 != (1, 5, 'x'), "simple numeric version failed"

    v2 = LooseVersion('1.5.1.6')
   

# Generated at 2022-06-22 22:27:30.054108
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('1') <= Version('2')

# Generated at 2022-06-22 22:27:39.718037
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    '''test cases for method __str__ of class LooseVersion'''

# Generated at 2022-06-22 22:27:42.311123
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    for args in [
        ("0.0.0",),
        (None,)
    ]:
        v = Version(*args)
        for other in [
            ("0.0.0",),
            (None,)
        ]:
            print(v.__eq__(*other))
    pass


# Generated at 2022-06-22 22:27:43.657529
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import doctest
    return doctest.testmod(LooseVersion)

# Generated at 2022-06-22 22:27:47.253118
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    from LooseVersion import LooseVersion
    global lv
    lv = LooseVersion("1.1.1")
    assert repr(lv) == "LooseVersion ('1.1.1')"


# Generated at 2022-06-22 22:27:57.645995
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    s = StrictVersion("1.2.4")
    assert isinstance(s.version, tuple)
    assert (s.version == (1,2,4))
    assert s.prerelease is None
    s = StrictVersion("1.2.4b1")
    assert isinstance(s.version, tuple)
    assert (s.version == (1,2,4))
    assert (s.prerelease == ("b",1))

    try:
        s = StrictVersion("1.2.4a")
        raise AssertionError("Failed to raise ValueError on '1.2.4a'")
    except ValueError:
        pass


# Generated at 2022-06-22 22:28:09.715425
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """Parse a string and create a LooseVersion instance.

    """

# Generated at 2022-06-22 22:28:16.156646
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # test bad strings
    VERSION_STRINGS = [
        # too many components
        "1.2.3.4",
        # alpha component not last
        "1.2a3.4",
        # alpha component has no number
        "1.2a.4",
        # second component not numeric
        "1.b3",
        # second component missing
        "1.",
        # empty string
        "",
        # missing first component
        ".2",
        # alpha component preceded by invalid character
        "1.2.dev3",
        # trailing garbage
        "1.2.3abc",
        # missing second component entirely
        "1.",
        # missing second component entirely, with garbage
        "1.abc",
    ]


# Generated at 2022-06-22 22:28:25.586338
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion("1.2.3")
    assert lv.parse("2.3.4") == lv.version, "parse should change version in place"
    assert lv.version == [2,3,4]
    assert lv.parse("2.3.4") is None, "parse should return None"


if __name__ == "__main__":
    if not testmod().failed:
        print("version.py: All tests successful.")
        sys.exit(0)
    sys.exit(1)
    #print (StrictVersion("1.2.3a2") > StrictVersion("1.2.3"))

# Generated at 2022-06-22 22:28:29.184988
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    if True:
        # The following __repr__ calls are used by the test infrastructure
        # to define the input and expected results for this test.
        assert Version().__repr__() == "Version ('0')"
        assert Version('1.0').__repr__() == "Version ('1.0')"


# Generated at 2022-06-22 22:28:32.030199
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    p = LooseVersion("1.2.3")
    assert repr(p) == "LooseVersion ('1.2.3')"



# Generated at 2022-06-22 22:28:42.594808
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert isinstance(LooseVersion("1.20"), LooseVersion)

# end class LooseVersion

# Once upon a time, this module defined two other classes:
#   FancyVersion -- an object that works like LooseVersion, but can
#                   be pickled.  (Actually, it was more complex than that)
#   StrictFancyVersion -- like StrictVersion, but included a pre-release tag
#                   and could be compared with a string to give the same
#                   results as StrictVersion.
#
# I've pulled it out of the package to avoid name bloat and unnecessary
# complexity.  If there really really is a demand for these classes, I
# guess they can be reinstated.  Had a hard enough time getting rid of
# them in the first place.  :-)


# Generated at 2022-06-22 22:28:43.598748
# Unit test for method __le__ of class Version
def test_Version___le__():
    return True


# Generated at 2022-06-22 22:28:54.872651
# Unit test for constructor of class Version
def test_Version():
    # If __init__ is implemented all methods from Version should work
    class v(Version):
        def parse(self, vstring):
            self.vstring = vstring
            self.version = 1
        def _cmp(self, other):
            return self.version - other.version

    v1 = v('v1')
    assert v1.vstring == 'v1'
    assert str(v1) == 'v1'
    assert repr(v1) == "v ('v1')"
    assert v1.version == 1
    assert v1 == v1
    assert not v1 != v1
    assert v1 == v('v1')
    assert not v1 != v('v1')
    assert v1 != v('v2')
    assert v1 < v('v2')

# Generated at 2022-06-22 22:28:59.125661
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v1 = LooseVersion("1.2.3a4")
    assert v1.__str__() == "1.2.3a4"



# Generated at 2022-06-22 22:29:00.395361
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    """_LooseVersion__repr__(self)"""
    obj = LooseVersion()
    assert not obj.__repr__()


# Generated at 2022-06-22 22:29:02.384651
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Unit test for method __le__ of class Version"""
    version = distutils.version.Version("1.0.0")
    assert version <= "1.0.0"
    assert version <= "1.0"
    assert version <= "1.1"

# Generated at 2022-06-22 22:29:06.803793
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.0')
    result = v <= '1.0'
    assert result

    v = Version('1.0')
    result = v <= '1.1'
    assert not result

    v = Version('1.1')
    result = v <= '1.0'
    assert not result

    v = Version('1.1')
    result = v <= '1.1'
    assert result



# Generated at 2022-06-22 22:29:09.544762
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Tests that __str__() returns a string for a non pre-release version number
    assert str(StrictVersion("1.0.0")) == '1.0.0'

# Generated at 2022-06-22 22:29:20.700601
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    import unittest

# Generated at 2022-06-22 22:29:23.436547
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    print("Testing Version.__lt__")
    version1 = Version("1.0.0")
    version2 = Version("2.0.0")
    assert version1 < version2



# Generated at 2022-06-22 22:29:28.171399
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('1.2.3.a4')) == '1.2.3.a4'
    assert str(StrictVersion('1.2.3b4')) == '1.2.3b4'
    assert str(StrictVersion('1.2.3')) == '1.2.3'
    assert str(StrictVersion('1.2.3.4')) == '1.2.3.4'
    assert str(StrictVersion('1.2')) == '1.2'
    assert str(StrictVersion('1')) == '1'


# Generated at 2022-06-22 22:29:30.735949
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion("1.0a2")


# Generated at 2022-06-22 22:29:38.676615
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from lib2to3.pgen2.tokenize import generate_tokens, untokenize, NUMBER, STRING, NAME, OP

    class Version(Version):  # noqa
        def parse(self, s):
            self.s = s
    v = Version('1.2.3')
    tokens = list(generate_tokens(lambda L=iter(v.__repr__()): next(L)))

# Generated at 2022-06-22 22:29:48.048693
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    a = LooseVersion
    assert a("1.2").version == [1, 2], "Parse error in LooseVersion.parse, first part"
    assert a("1.2.3").version == [1, 2, 3], "Parse error in LooseVersion.parse, second part"
    assert a("1.2.0").version == [1, 2, 0], "Parse error in LooseVersion.parse, third part"
    assert a("1.2a1").version == [1, 2, 'a', 1], "Parse error in LooseVersion.parse, fourth part"
    assert a("1.2b1").version == [1, 2, 'b', 1], "Parse error in LooseVersion.parse, fifth part"

# Generated at 2022-06-22 22:29:54.959691
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('1.1.1') == LooseVersion('1.1.1')
    assert LooseVersion('1.1.1') < LooseVersion('1.1.2')
    assert LooseVersion('1.1.2') > LooseVersion('1.1.1')
    assert LooseVersion('1.1.2') < LooseVersion('1.1.10')
    assert LooseVersion('1.1.10') > LooseVersion('1.1.2')
    assert LooseVersion('1.1.2') < LooseVersion('1.2')
    assert LooseVersion('1.2') > LooseVersion('1.1.2')
    assert LooseVersion('1.2') == LooseVersion('1.2.0')
    assert LooseVersion('1.2') < Loose

# Generated at 2022-06-22 22:29:59.686320
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    Version = distutils.version.Version
    # given:
    v1 = Version('1.1')
    v2 = Version('1.2.3')
    # exercise:
    result = v1 < v2
    # verify:
    assert True == result



# Generated at 2022-06-22 22:30:10.646153
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert (Version(vstring="0.0.0") > Version(vstring="0.0.0")) == False
    assert (Version(vstring="0.0.0") > Version(vstring="0.0.1")) == False
    assert (Version(vstring="0.0.0") > Version(vstring="0.1.0")) == False
    assert (Version(vstring="0.0.0") > Version(vstring="1.0.0")) == False
    assert (Version(vstring="0.0.1") > Version(vstring="0.0.0")) == True
    assert (Version(vstring="0.0.1") > Version(vstring="0.0.1")) == False

# Generated at 2022-06-22 22:30:12.381088
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    x = Version()
    assert str(eval(repr(x))) == str(x), 'eval(repr(x)) == x fails'

# Generated at 2022-06-22 22:30:21.172633
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    testdata = [
        ('0.4', '0.4'),
        ('0.4.0', '0.4.0'),
        ('1.0.4b1', '1.0.4b1'),
        ('1.3c4', ValueError),
        ('1.0.4a3  ', ValueError),
        ('', ValueError),
    ]

    for (input, expected) in testdata:
        if isinstance(expected, type) and issubclass(expected, Exception):
            assertRaises(expected, StrictVersion, input)
        else:
            s = str(StrictVersion(input))
            assert s == expected, \
                "__str__('%s') returned %r, expected %r" % (input, s, expected)


# Generated at 2022-06-22 22:30:31.571075
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import LooseVersion, StrictVersion
    assert not (StrictVersion('1.2') > LooseVersion('1.2'))
    assert StrictVersion('1.2') > LooseVersion('1.2.0')
    assert not (StrictVersion('1.2.0') > LooseVersion('1.2'))
    assert not (StrictVersion('1.2') > LooseVersion('1.1.1'))
    assert StrictVersion('1.2') > LooseVersion('1.1')
    assert not (StrictVersion('1.1') > LooseVersion('1.2'))
    assert StrictVersion('1.2') > LooseVersion('1.1a1')
    assert not (StrictVersion('1.1a1') > LooseVersion('1.2'))

# Generated at 2022-06-22 22:30:33.111043
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert(not v1 > v2)

# Generated at 2022-06-22 22:30:37.761885
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    class TestVersion:
        def __init__(self,vstring=None):
            return

    import sys

    try:
        # python < 3.0
        raise Exception('Only >= 3.0 supported')
    except:
        e = sys.exc_info()[1]
        print(e)
    # try:
    #     raise Exception, 'Only >= 3.0 supported'
    # except:
    #     e = sys.exc_info()[1]
    #     print e
    v = Version()

    # Check __ge__ is implemented
    v.__ge__()


# Generated at 2022-06-22 22:30:47.393032
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Test class initialization
    sv = StrictVersion('1.0.0')
    assert sv.version == (1, 0, 0)
    assert sv.prerelease is None
    assert str(sv) == '1.0'

    sv = StrictVersion('1.0.0a0')
    assert sv.version == (1, 0, 0)
    assert sv.prerelease == ('a', 0)
    assert str(sv) == '1.0a0'

    sv = StrictVersion('1.0')
    assert sv.version == (1, 0, 0)
    assert sv.prerelease is None
    assert str(sv) == '1.0'

    # General numeric version


# Generated at 2022-06-22 22:30:53.996914
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    repr(v)
    for tv in ['1.2.3', '1.2.3.4', '2.5b3', '2.5b3build210',
               '2.5b3.post3.dev4', '2.5rc2.dev4', '2.5', '2.5.1', '2.5.2']:
        v = Version(tv)
        assert str(v) == tv
        assert repr(v) == "Version ('%s')" % tv



# Generated at 2022-06-22 22:31:06.481084
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    versions = ['1.5.1', '1.5.2b2', '161', '3.10a', '8.02', '3.4j',
                '1996.07.12', '3.2.pl0', '3.1.1.6', '2g6', '11g',
                '0.960923', '2.2beta29', '5.5.kw', '2.0b1pl0']
    for str in versions:
        v = LooseVersion(str)
        msg = "LooseVersion constructor failed on '%s'" % str
        assert str == str(v), msg

# Here's a naive test suite for the LooseVersion class.  The point here
# is to have a large collection of "obviously correct" version number
# comparison tests, taking into account the rules given above.

# Generated at 2022-06-22 22:31:10.013433
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    x = Version()
    x.parse('1.0')
    y = Version()
    y.parse('2.0')
    z = x > y

# Generated at 2022-06-22 22:31:14.013059
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = StrictVersion("1.25.0")
    assert str(version) == "1.25.0"

    version = StrictVersion("1.25.0a1")
    assert str(version) == "1.25.0a1"



# Generated at 2022-06-22 22:31:16.836195
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import unittest, StrictVersion
    class StrictVersion___str__TestCase(unittest.TestCase):
        def test(self):
            pass
    unittest.main()


# Generated at 2022-06-22 22:31:20.093738
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    from distutils.version import _BaseVersion
    v = _BaseVersion('1234.5678')
    assert repr(v) == "_BaseVersion ('1234.5678')"



# Generated at 2022-06-22 22:31:26.986126
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == NotImplemented
    class SubVersion(Version):
        def __init__(self):
            Version.__init__(self)
        def _cmp(self, other):
            return 0
    v2 = SubVersion()
    assert not v2 == NotImplemented
    assert v2 == v2
    assert v2 == 0

# Generated at 2022-06-22 22:31:30.819435
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v=Version()
    v._cmp=lambda x,y: x+y
    assert(v.__lt__(3)==3)
    assert(v.__lt__(None)==NotImplemented)


# Generated at 2022-06-22 22:31:44.308482
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert StrictVersion('1.2.3') == StrictVersion('1.2.3')
    assert StrictVersion('1.2.3') != StrictVersion('1.2.4')
    assert StrictVersion('1.2.3') < StrictVersion('1.2.4')
    assert StrictVersion('1.2.4') > StrictVersion('1.2.3')
    assert StrictVersion('1.2.3') <= StrictVersion('1.2.3')
    assert StrictVersion('1.2.3') >= StrictVersion('1.2.3')
    assert StrictVersion('1.2.3') != '1.2.3'

    assert StrictVersion('1.2.3') == StrictVersion('1.2.3.0')


# Generated at 2022-06-22 22:31:46.982919
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import LooseVersion
    assert Version() > LooseVersion('1.2.3') == LooseVersion('1.2.3') < Version()


# Generated at 2022-06-22 22:31:54.444689
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    from distutils.tests.test_version import StrictVersionTest
    assert StrictVersionTest('test__le__', Version('1.1.1'), '1.1.0', None).test() == 1
    assert StrictVersionTest('test__le__', Version('1.1.1'), '1.1', None).test() == 1
    assert StrictVersionTest('test__le__', Version('1.1.1'), '1.1.1', None).test() == 1
    assert StrictVersionTest('test__le__', Version('1.1.0'), '1.1.1', None).test() == 0


# Generated at 2022-06-22 22:31:57.684814
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import Version
    v = Version('3.3.3')
    assert v.__gt__('3.3.2')


# Generated at 2022-06-22 22:31:59.260183
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert 0 == 0
    return

# Generated at 2022-06-22 22:32:02.180426
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v.parse('1.2')

    if v <= '1.1':
        print('Version.__le__ bug failed')



# Generated at 2022-06-22 22:32:12.794070
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    def __test_subsub(subsub, subsub_result):
        lv = LooseVersion()
        lv.parse(subsub)
        assert str(lv) == subsub_result

    def __test_sub(sub, sub_result):
        __test_subsub(sub, sub_result)
        __test_subsub(sub+".0", sub_result)
        __test_subsub(sub+".0.0.0", sub_result)

    __test_sub("1.5.1", "1.5.1")
    __test_sub("1.5.2b2", "1.5.2b2")
    __test_sub("161", "161")
    __test_sub("3.10a", "3.10a")

# Generated at 2022-06-22 22:32:16.905426
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = StrictVersion('1.0')
    v2 = StrictVersion('1.0')

    assert (v1 >= v2)

# Generated at 2022-06-22 22:32:26.340278
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # All version numbers must compare equal to themselves
    ver = "1.234rc2"
    s = StrictVersion(ver)
    assert str(s) == ver
    assert s._cmp(ver) == 0
    assert StrictVersion(s) == s

    ver = "1.234"
    s = StrictVersion(ver)
    assert str(s) == ver
    assert s._cmp(ver) == 0
    assert StrictVersion(s) == s

    ver = "0.4.1"
    s = StrictVersion(ver)
    assert str(s) == ver
    assert s._cmp(ver) == 0
    assert StrictVersion(s) == s

    ver = "0.4"
    s = StrictVersion(ver)
    assert str(s) == ver

# Generated at 2022-06-22 22:32:29.808744
# Unit test for constructor of class Version
def test_Version():
    v = Version()
    assert str(v) == ''
    assert repr(v) == "Version ('''')"

    v = Version('1.2')
    assert str(v) == '1.2'
    assert repr(v) == "Version ('1.2')"

test_Version()



# Generated at 2022-06-22 22:32:31.239955
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    assert True


    return


# Generated at 2022-06-22 22:32:31.936563
# Unit test for constructor of class Version
def test_Version():
    Version()



# Generated at 2022-06-22 22:32:43.856763
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse("1")
    assert v.version == [1]
    v.parse("1.2")
    assert v.version == [1,2]
    v.parse("1.2j")
    assert v.version == [1, 2, 'j']
    v.parse("3.3.3")
    assert v.version == [3, 3, 3]
    v.parse("3.3.3.3")
    assert v.version == [3, 3, 3, 3]
    v.parse("3.3.3.pl.3")
    assert v.version == [3, 3, 3, 'pl', 3]
    v.parse("3.3pl3")
    assert v.version == [3, 3, 'pl3']