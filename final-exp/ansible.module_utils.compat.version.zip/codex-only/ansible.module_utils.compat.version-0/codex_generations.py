

# Generated at 2022-06-22 22:22:42.865947
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    import tempfile, sys

    # Create a sequence of version numbers (as strings)
    versions = ['1.5.1', '1.5.2b2', '161', '3.10a', '8.02', '3.4j', '1996.07',
                '3.2.pl0', '3.1.1.6', '2g6', '11g', '0.960923', '2.2beta29',
                '1.13++']
    versions.sort()

    # Create a sequence of LooseVersion instances from the strings
    loose_versions = [LooseVersion(v) for v in versions]

    # Create a temporary filename

# Generated at 2022-06-22 22:22:46.486339
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    cases = ['1.3.7.4', '1.3', '1.3.4a7']
    for str in cases:
        try:
            StrictVersion(str)
        except ValueError as e:
            print(('test_StrictVersion: constructor raised %s for "%s"' %
                  (e.__class__.__name__, str)))



# Generated at 2022-06-22 22:22:50.766516
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    for num in range(-4, 5):
        for num2 in range(-4, 5):
            v = Version()
            v._cmp = lambda x: num
            assert (v >= num2) == (num >= num2)


# Generated at 2022-06-22 22:22:59.663953
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    assert LooseVersion('1.2.1').__str__() == '1.2.1'
    assert LooseVersion('1.2b').__str__() == '1.2b'
    assert LooseVersion('1.2.b').__str__() == '1.2.b'
    assert LooseVersion('1.2.1pl').__str__() == '1.2.1pl'
    assert LooseVersion('1.2.1pl2').__str__() == '1.2.1pl2'
    assert LooseVersion('1.2.1pl33').__str__() == '1.2.1pl33'
    assert LooseVersion('1.2.1pl33.3').__str__() == '1.2.1pl33.3'

# Generated at 2022-06-22 22:23:00.967579
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    v = LooseVersion('string')
    assert repr(v) == "LooseVersion ('string')"


# Generated at 2022-06-22 22:23:12.223870
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    # Test some valid version number strings
    v = StrictVersion('1.0')
    assert v.version == (1,0,0)
    assert v.prerelease == None

    v = StrictVersion('1.0.0')
    assert v.version == (1,0,0)
    assert v.prerelease == None

    v = StrictVersion('1.0a1')
    assert v.version == (1,0,0)
    assert v.prerelease == ('a',1)

    v = StrictVersion('1.0.1a2')
    assert v.version == (1,0,1)
    assert v.prerelease == ('a',2)

    v = StrictVersion('1.0b1')
    assert v.version == (1,0,0)
    assert v.prerelease

# Generated at 2022-06-22 22:23:16.200968
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    ver = Version('3.4')
    if not (ver == Version('3.4')):
        raise ValueError("(Version('3.4') == Version('3.4'))")
    if not (Version('3.4') == '3.4'):
        raise ValueError("(Version('3.4') == '3.4')")




# Generated at 2022-06-22 22:23:27.449520
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from .unit_test import TestCase
    from .unit_test import _Call
    from .unit_test import _Mock

    class _VersionTestCase(TestCase):

        def assert_Version_eq(self, version, other, expected):
            try:
                self.assertEqual(version == other, expected)
            except AssertionError:
                # TODO: this should be an AssertionError
                raise AssertionError("assertEqual(%r == %r, %r)" % (version, other, expected))

    test_cases = (
        # version, other, expected
        (_VersionTestCase.assert_Version_eq, "1.0", "1.0", True),
    )


# Generated at 2022-06-22 22:23:29.043346
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert (v >= None)



# Generated at 2022-06-22 22:23:32.559133
# Unit test for method __lt__ of class Version
def test_Version___lt__():
  v1 = Version(vstring="9.9.9")
  v2 = Version(vstring="9.9.9")
  assert v1 < v2 == NotImplemented

# Generated at 2022-06-22 22:23:36.687640
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    lv = LooseVersion('1.5.1')
    assert str(lv) == '1.5.1'
    assert a == b, 'a={} != b={}'.format(a, b)
    assert a == b, f'a={a} != b={b}'


# Generated at 2022-06-22 22:23:39.317566
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    "Test for method __repr__"
    v = Version(None)
    assert (v.__repr__() == "Version ('None')"), "__repr__() should return 'Version ('None')'"



# Generated at 2022-06-22 22:23:51.935272
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    '''Method __gt__ of class Version'''
    def test_positive():
        '''Test positive results.'''
        v = Version('1.1.1')
        assert v.__gt__('1.1.2')

    def test_negative():
        '''Test negative results.'''
        v = Version('1.1.1')
        assert not v.__gt__('1.1.0')

    def test_error():
        '''Test error conditions.'''
        v = Version('1.1.1')
        try:
            v.__gt__('a.a.a')
            assert False, '__gt__ did not catch bad version string'
        except ValueError:
            pass
    test_positive()
    test_negative()
    test_error()

# Generated at 2022-06-22 22:23:53.344369
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    # Ensure that the constructor fails if called with a bad argument
    try:
        to_loose_version('xyz')
    except ValueError:
        pass
    else:
        raise TestFailed('no exception thrown')



# Generated at 2022-06-22 22:24:04.347779
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    assert v.parse('5.5.kw') == (5,5,'kw')
    assert v.parse('161') == (161,)
    assert v.parse('1.5.1') == (1,5,1)
    assert v.parse('1.5.2b2') == (1,5,2,'b',2)
    assert v.parse('8.02') == (8,2)
    assert v.parse('3.4j') == (3,4,'j')
    assert v.parse('3.1.1.6') == (3,1,1,6)
    assert v.parse('2g6') == (2,'g',6)
    assert v.parse('1996.07.12') == (1996,7,12)

# Generated at 2022-06-22 22:24:10.583578
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    def check(expected, s):
        v = LooseVersion(s)
        actual = v.__str__()
        equal = (expected == actual)
        if equal:
            return
        raise AssertionError("%s == %s (%s)" % (expected, actual, s))

    check("1.5.1", "1.5.1")
    check("1.5.2b2", "1.5.2b2")
    check("161", "161")
    check("3.10a", "3.10a")
    check("8.02", "8.02")
    check("3.4j", "3.4j")
    check("1996.07.12", "1996.07.12")
    check("3.2.pl0", "3.2.pl0")

# Generated at 2022-06-22 22:24:15.668190
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert(v1 == v2)
    assert(not v1 != v2)
    assert(not v1 > v2)
    assert(v1 >= v2)
    assert(not v1 < v2)
    assert(v1 <= v2)


# Generated at 2022-06-22 22:24:18.857607
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
        v = StrictVersion('1.0.1a1')
        assert str(v) == '1.0.1a1'


# Generated at 2022-06-22 22:24:20.392556
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version('2.1') <= Version('2.2')


# Generated at 2022-06-22 22:24:31.350991
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    for vstring in [
        '1.4', '1.4.1', '1.4.2a1', '1.4.2b3', '1.4.2',
        '1.4a2', '1.4b2', '1.4c2', '1.4rc1', '1.4',
        '1.5.dev1', '1.5.dev2', '1.5.dev2'
    ]:
        StrictVersion(vstring)


# Generated at 2022-06-22 22:24:43.657933
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    cases = ['alpha', 'alpha.1', 'alpha.beta', 'alpha.beta.1',
             '1', '1.2', '1.2.3', '1.2.3.4',
             '1.2.3.4.5.6.7.8.9.0',
             '1.02', '1.2.003',
             '1.2.3a1', '1.2.3b2',
             '1.2.3a1.2.3b2',
             '1.2.3a1.02.003.b2',
             '1.1rc1',
             '1.2.3.4rc1']


# Generated at 2022-06-22 22:24:49.351306
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import sys
    import os
    import unittest
    import doctest
    sys.path.insert(0, os.path.dirname(os.curdir))
    sys.path.insert(0, os.path.join(os.path.dirname(os.curdir), os.path.pardir,
                                    'lib'))
    from distutils2.tests import support
    from distutils2 import version


# Generated at 2022-06-22 22:24:51.643179
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert_match(__repr__(__ge__(__init__('b'),'')),'Version')


# Generated at 2022-06-22 22:24:57.348244
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    l = LooseVersion('1.2.3')
    assert (l.version == [1, 2, 3])

    l = LooseVersion('1.2.3a1')
    assert (l.version == [1, 2, 3, 'a', 1])

    l = LooseVersion('1.2-pl3')
    assert (l.version == [1, 2, 'pl', 3])

    l = LooseVersion('3.0-j')
    assert (l.version == [3, 0, 'j'])


# Generated at 2022-06-22 22:25:08.118318
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vstring in ['1.2.3', '0.2.3', '0.2.3a4']:
        assert str(StrictVersion(vstring)) == vstring
        assert StrictVersion(vstring)._cmp(vstring) == 0
        assert StrictVersion(vstring).version == (1, 2, 3)
        print("_cmp(%s, '%s') = %s" % (vstring, vstring, StrictVersion(vstring)._cmp(vstring)))

    assert StrictVersion('1.2.3')._cmp('1.2.3') == 0
    assert StrictVersion('.2.3')._cmp('.2.3') == 0
    assert StrictVersion('1.2.3') == StrictVersion('.2.3')


# Generated at 2022-06-22 22:25:10.795571
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # VERSION = "<class 'distutils.version.Version'>"

    v = Version(None)
    assert v._cmp(6) == NotImplemented



# Generated at 2022-06-22 22:25:15.886652
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Version(version_string)
    v_obj = Version('1.2.3.4')

    # Version(version_string)
    v_obj2 = Version('1.2.3')

    # __le__(other_version)
    v_obj3 = v_obj.__le__(v_obj2)

    return

# Generated at 2022-06-22 22:25:16.913522
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    pass


# Generated at 2022-06-22 22:25:25.967554
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def check(expected_version, expected_prerelease, test_string):
        version = StrictVersion()
        version.parse(test_string)
        assert version.version == expected_version
        assert version.prerelease == expected_prerelease
    check((0, 4), None, '0.4')
    check((0, 4), None, '0.4.0')
    check((0, 4, 1), None, '0.4.1')
    check((0, 5, 0), ('a', 1), '0.5a1')
    check((0, 5, 0), ('b', 3), '0.5b3')
    check((0, 9, 6), None, '0.9.6')
    check((1, 0), None, '1.0')

# Generated at 2022-06-22 22:25:26.491545
# Unit test for method __ge__ of class Version
def test_Version___ge__(): pass


# Generated at 2022-06-22 22:25:33.708248
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.2.3')
    v1_copy = v1
    v_copy_str = "Version ('1.2.3')"
    v1_str = "1.2.3"
    v2 = Version('2.0.0')
    v2_str = "2.0.0"
    v3 = Version('2.0.0a1')
    v3_str = "2.0.0a1"
    v4 = Version('2.0.0rc1')
    v4_str = "2.0.0rc1"
    v5 = '1.2'
    v6 = Version('1.2a')
    v6_str = "1.2a"

    assert v1.__ge__(v1)
    assert v1.__ge__

# Generated at 2022-06-22 22:25:43.670783
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    assert v._cmp("2.7.2.2") == -1
    assert v._cmp("1.3.a4") == -1
    assert v._cmp("1.3pl1") == -1
    assert v._cmp("1.3c4") == -1
    assert v._cmp("1") == -1
    assert v._cmp("1.0") == 1
    assert v._cmp("1.0.4a3") == 1
    assert v._cmp("1.0.4b1") == 1
    assert v._cmp("1.0.4.1") == -1
    assert v._cmp("6.5.4.3") == -1
    assert v._cmp("6.5.4.3beta") == -1

# Generated at 2022-06-22 22:25:46.880322
# Unit test for constructor of class Version
def test_Version():
    import unittest

    class VersionTestCase(unittest.TestCase):

        def test_class_init(self):
            v = Version()

    unittest.main()


# Generated at 2022-06-22 22:25:49.120325
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion('1.2.3').__repr__() == "LooseVersion ('1.2.3')"


# Generated at 2022-06-22 22:25:54.903019
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1_1 = Version('1')
    v1_2 = Version('1')
    v1_3 = Version('1.5')
    
    assert v1_1 == v1_2
    assert not(v1_1 == v1_3)


# Generated at 2022-06-22 22:26:05.146628
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    class LV(LooseVersion):
        def __init__(self, vstring=None):
            self.parse(vstring)
    
    lv_proper = lambda version: LV(version)
    lv_improper = lambda version: LV('1.2.3' + version)
    for version in ('', '1', '1.2', '1.2.3', '1.2.3a4'):
        yield lv_proper, version
    for version in ('a', 'a1', '1a', '1.2a',
                    '1.2.3a', '1.2.3a4b5', '1.2.3a4b5.6'):
        yield lv_improper, version


# Generated at 2022-06-22 22:26:17.482182
# Unit test for constructor of class LooseVersion

# Generated at 2022-06-22 22:26:21.057996
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    print('Testing Version.__repr__')
    v = Version()
    assert repr(v) == "Version ('0')"
    v = Version('1.2.3')
    assert repr(v) == "Version ('1.2.3')"


# Generated at 2022-06-22 22:26:24.197835
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version("1.0rc1")
    v1b = Version("1.0")
    assert v1 < v1b
    assert v1 <= v1b
    assert not (v1 > v1b)
    assert not (v1 >= v1b)



# Generated at 2022-06-22 22:26:25.821029
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    assert v == Version('1.0')


# Generated at 2022-06-22 22:26:34.920474
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    for vstring in ("1.0", "1.2.3"):
        Version(vstring)
        StrictVersion(vstring)
        v = StrictVersion(vstring)
        assert str(v) == vstring
        assert repr(v) == "StrictVersion ('%s')" % vstring

    # Verify that StrictVersion cannot be instantiated with
    # unparsable version strings.
    for vstring in ("1.0rc1", "1.2.3foo", "1.2.a1"):
        try:
            StrictVersion(vstring)
        except ValueError:
            pass
        else:
            raise AssertionError("cannot instantiate StrictVersion with '%s'" % vstring)



# Generated at 2022-06-22 22:26:38.060480
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    global Args
    assert test_Version___repr__, 'Test must be triggered'
    # Version.__repr__
    Args = []
    assert None, 'No return value expected'

# Generated at 2022-06-22 22:26:50.460691
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion("1.2") == LooseVersion("1.2.0")
    assert LooseVersion("1.2") < LooseVersion("1.2.1")
    assert LooseVersion("1.2") < LooseVersion("1.2.a")
    assert LooseVersion("1.2a") < LooseVersion("1.2b")
    assert LooseVersion("1.2pl3") < LooseVersion("1.2")
    assert LooseVersion("1.3") > LooseVersion("1.2.pl3")
    assert LooseVersion("1.3") > LooseVersion("1.2.r3")
    assert LooseVersion("1.2") < LooseVersion("1.2.1")

# Generated at 2022-06-22 22:26:58.257779
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from os.path import abspath, dirname, join, normpath

    test_dir = normpath(join(dirname(abspath(__file__)), '..'))
    ansible_base_path = normpath(join(test_dir, '..', '..', '..'))
    ansible_version_file = join(ansible_base_path, 'lib', 'ansible', 'module_utils', 'ansible_release.py')

    # load ansible_release.py
    with open(ansible_version_file) as f:
        code = compile(f.read(), ansible_version_file, 'exec')
        exec(code)

    # This will fail if __gt__ is not implemented for Version
    ansible_version = StrictVersion(__version__)

# Generated at 2022-06-22 22:27:02.060199
# Unit test for constructor of class Version
def test_Version():
    """Test for class Version."""
    for vstring in ['1.2.3', '0.4', '000.003.003']:
        v = Version(vstring)
        assert str(v) == vstring



# Generated at 2022-06-22 22:27:04.542476
# Unit test for method __gt__ of class Version
def test_Version___gt__():
  inst = Version()
  inst2 = Version()
  assert inst.__gt__(inst2) == NotImplemented



# Generated at 2022-06-22 22:27:14.917057
# Unit test for method __le__ of class Version
def test_Version___le__():
    """
    Test that Version.__le__ works as expected.
    """
    import pytest

    @pytest.mark.parametrize(
        'a, b, expected', [
            ('0.0', '0.0.0', True),
            ('0.0', '0.1.0', True),
            ('0.0', '0.0.1', True),
            ('0.1', '1.0.0', True),
            ('0.0', '0.0.0.dev1', False),
        ])
    def test_op(a, b, expected):
        from distutils import version

        v_a = version.LooseVersion(a)
        v_b = version.LooseVersion(b)

        assert (v_a <= v_b) == expected

    test_op

# Generated at 2022-06-22 22:27:16.290933
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    assert LooseVersion("2.2a2").__repr__()  == "LooseVersion ('2.2a2')"


# Generated at 2022-06-22 22:27:18.594500
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    v = Version()
    assert repr(v) == "Version ('None')"
    v.parse("3.2.1")
    assert repr(v) == "Version ('3.2.1')"
    assert str(v) == "3.2.1"
    assert v._version == "3.2.1"

# Generated at 2022-06-22 22:27:31.170725
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    def test(string, expected_parts=None):
        v = StrictVersion(string)
        assert str(v) == string
        assert v.version == (expected_parts or (0,))[:3]
        if v.prerelease is not None:
            assert len(v.prerelease) == 2
            assert v.prerelease[0] in 'ab'
            assert isinstance(v.prerelease[1], int)

    test('1.3.6')
    test('1.3.6.foo', (1, 3, 6))
    test('0.9', (0, 9))
    test('1.3b2', (1, 3))
    test('1.3c1', (1, 3))
    test('0.4.0', (0, 4, 0))

# Generated at 2022-06-22 22:27:40.482071
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion('1.5.1') == LooseVersion('1.5.2b2')
    assert LooseVersion('161') == LooseVersion('3.10a')
    assert LooseVersion('8.02') == LooseVersion('3.4j')
    assert LooseVersion('1996.07.12') == LooseVersion('3.2.pl0')
    assert LooseVersion('3.1.1.6') == LooseVersion('2g6')
    assert LooseVersion('11g') == LooseVersion('0.960923')
    assert LooseVersion('2.2beta29') == LooseVersion('1.13++')
    assert LooseVersion('5.5.kw') == LooseVersion('2.0b1pl0')

    # If a string can't be parsed as a LooseVersion

# Generated at 2022-06-22 22:27:41.914525
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("3.5") <= Version("3.5")

# Generated at 2022-06-22 22:27:43.971798
# Unit test for constructor of class Version
def test_Version():
    assert str(Version()) == ""
    assert str(Version("1.2.3")) == "1.2.3"



# Generated at 2022-06-22 22:27:47.580018
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """Version.__lt__ should return NotImplemented when the arguments
    types differ.
    """
    v1 = Version()
    assert v1.__lt__(0) is NotImplemented

# Generated at 2022-06-22 22:27:50.267709
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    v = '0.2.0'
    lv = LooseVersion(v)
    assert (str(lv) == v)
    assert (str(lv) == v)


# Generated at 2022-06-22 22:27:53.906427
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    test_version = LooseVersion('1.2.4')
    assert LooseVersion.__repr__(test_version) == "LooseVersion ('1.2.4')"


# Generated at 2022-06-22 22:28:01.533921
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    _version1 = Version(1)
    _version2 = Version(2)
    assert (_version2 >= _version1)

    _version1 = Version(2)
    _version2 = Version(1)
    assert not (_version2 >= _version1)

    _version1 = Version("1.0")
    _version2 = Version("2.0")
    assert (_version2 >= _version1)

    _version1 = Version("2.0")
    _version2 = Version("1.0")
    assert not (_version2 >= _version1)


# Generated at 2022-06-22 22:28:13.564921
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def create_test_f(version_str, expected_output_tuple):
        def test_f():
            v = LooseVersion(version_str)
            output_tuple = v.version

# Generated at 2022-06-22 22:28:20.840118
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    def f(n, m, k, a, b):
        return [n, m, k, a, b]
    v.parse('1')
    assert v.version_re.match('1').groups() == f(1, None, None, None, None)
    v.parse('1.2')
    assert v.version_re.match('1.2').groups() == f(1, 2, None, None, None)
    v.parse('1.2.3')
    assert v.version_re.match('1.2.3').groups() == f(1, 2, 3, None, None)
    v.parse('1.2.3a4')

# Generated at 2022-06-22 22:28:22.684953
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert repr(Version("1.0")) == "Version ('1.0')"

# Generated at 2022-06-22 22:28:32.167764
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    def test_ssv_op(a, b):
        # Tests that StrStrictVersion(a) <op> StrStrictVersion(b)
        # returns True.
        # <op> is a function from the <python module>:<function name> string
        # to a function name in module operator.
        # eg: 'lt': operator.lt
        module_name, func_name = a[-2:].split(':')
        module_func_name = '%s.%s' % (module_name, func_name)
        func = eval(module_func_name)
        def test_ssv(self):
            self.assertTrue(func(StrictVersion(a), StrictVersion(b)))
        return test_ssv


# Generated at 2022-06-22 22:28:42.715855
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    assert LooseVersion("1.2.3").version == (1,2,3)
    assert LooseVersion("a.b.c").version == ('a','b','c')
    assert LooseVersion("a.b").version == ('a','b')

    assert LooseVersion("1.2.0").version == (1,2,0)
    assert LooseVersion("1.02.0").version == (1,2,0)
    assert LooseVersion("1.002.0").version == (1,2,0)
    assert LooseVersion("1.0002.0").version == (1,2,0)

    assert LooseVersion("1.2.3").version == (1,2,3)
    assert LooseVersion("1.2.03").version == (1,2,3)
    assert LooseVersion

# Generated at 2022-06-22 22:28:54.086338
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    v = StrictVersion("1.0")
    assert str(v) == "1.0"

    v = StrictVersion("1.0.0")
    assert str(v) == "1.0"

    v = StrictVersion("1.0.0a1")
    assert str(v) == "1.0.0a1"

    v = StrictVersion("1.0.0b3")
    assert str(v) == "1.0.0b3"

    v = StrictVersion("1.0.0rc3")
    assert str(v) == "1.0.0rc3"

    v = StrictVersion("1.0.0.post1")
    assert str(v) == "1.0.0.post1"

    # Regression test for http://bugs.python.org

# Generated at 2022-06-22 22:29:05.948443
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion('1.2.3')
    assert(v.version == [1, '2', '3'])
    v = LooseVersion('1.2.3a4')
    assert(v.version == [1, '2', '3', 'a', 4])
    v = LooseVersion('0.4.0')
    assert(v.version == [0, '4', '0'])
    v = LooseVersion('0.4.1')
    assert(v.version == [0, '4', '1'])
    v = LooseVersion('0.5a1')
    assert(v.version == [0, '5', 'a', 1])
    v = LooseVersion('0.5b3')
    assert(v.version == [0, '5', 'b', 3])

# Generated at 2022-06-22 22:29:08.724596
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    assert v.__le__(v)
    assert v.__le__('1.0')


# Generated at 2022-06-22 22:29:19.853518
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    import warnings

    warnings.simplefilter('error')

    def check(vstring):
        version = StrictVersion(vstring)
        if version.__str__() != vstring:
            print("bad string", vstring)
        if eval(version.__repr__()) != version:
            print("bad repr", version.__repr__())

    versions = ['0.4', '0.4.0', '0.4.1', '0.5a1', '0.5b3', '0.5',
                '0.9.6', '1.0', '1.0.4a3', '1.0.4b1', '1.0.4']

# Generated at 2022-06-22 22:29:21.557733
# Unit test for method __repr__ of class Version
def test_Version___repr__():
    assert Version('1.2').__repr__() == "Version ('1.2')"


# Generated at 2022-06-22 22:29:24.608997
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    actual = Version('2.2') == Version('2.2')
    expected = True
    assert actual == expected, 'expected "%s", but got "%s"' % (expected, actual)

# Generated at 2022-06-22 22:29:32.878300
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    a = LooseVersion('1.0')
    assert(a.version == (1,0))
    a = LooseVersion('1.0.0')
    assert(a.version == (1,0,0))
    a = LooseVersion('1.1.0')
    assert(a.version == (1,1,0))
    a = LooseVersion('1.1.1')
    assert(a.version == (1,1,1))
    a = LooseVersion('1.0a1')
    assert(a.version == (1,0,'a1'))
    a = LooseVersion('1.0.0a1')
    assert(a.version == (1,0,0,'a1'))
    a = LooseVersion('1.0.1a1')

# Generated at 2022-06-22 22:29:35.171562
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    '''Method __gt__ of class Version'''
    v = Version()
    assert not v >  0
    assert not v > -1


# Generated at 2022-06-22 22:29:38.362915
# Unit test for constructor of class Version
def test_Version():
    v = Version()                # no args
    assert v is not None

    v = Version('1.2.3a4')       # string
    assert v is not None


# Generated at 2022-06-22 22:29:40.593638
# Unit test for method __le__ of class Version
def test_Version___le__():
    Version()
    v = Version()
    v.__le__(v)

# Generated at 2022-06-22 22:29:49.051616
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():

    # Data

    verbose = False

    # Test

    test_versions = []
    test_versions.append(['0.4', '0.4.0'])
    test_versions.append(['0.4.1', '0.4.1.0'])
    test_versions.append(['0.5a1', '0.5.0a1'])
    test_versions.append(['0.5b3', '0.5.0b3'])
    test_versions.append(['0.5', '0.5.0'])
    test_versions.append(['0.9.6', '0.9.6'])
    test_versions.append(['1.0', '1.0.0'])

# Generated at 2022-06-22 22:29:53.283830
# Unit test for constructor of class Version
def test_Version():
    v1 = Version()
    v2 = Version('1')
    v3 = Version('1.2.3')
    v4 = Version('alpha.1')



# Generated at 2022-06-22 22:29:54.930868
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import doctest
    doctest.testmod(LooseVersion.parse)


# Generated at 2022-06-22 22:29:57.909713
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("1.2.3a4")
    assert str(v) == "1.2.3a4"

# Generated at 2022-06-22 22:29:59.866327
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v2 = Version()
    assert v == v2


# Generated at 2022-06-22 22:30:06.561676
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    from ansible.module_utils.six import PY3
    if not PY3:
        raise SkipTest("Skipping for Python 2")
    # Testing <
    v1 = Version('1.5.1')
    v2 = Version('1.5.2b2')
    v3 = Version('161')
    assert v2 < v3
    assert not (v2 < v1)

# Generated at 2022-06-22 22:30:14.534970
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
   assert LooseVersion('1.5.1').__str__() == '1.5.1'
   assert LooseVersion('1.5.2b2').__str__() == '1.5.2b2'
   assert LooseVersion('161').__str__() == '161'
   assert LooseVersion('3.10a').__str__() == '3.10a'
   assert LooseVersion('8.02').__str__() == '8.02'
   assert LooseVersion('3.4j').__str__() == '3.4j'
   assert LooseVersion('1996.07.12').__str__() == '1996.07.12'
   assert LooseVersion('3.2.pl0').__str__() == '3.2.pl0'

# Generated at 2022-06-22 22:30:21.375012
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = StrictVersion('0.0.0')
    v2 = StrictVersion('1.2.3')
    v1_gt_v2 = v1 >= v2
    if v1_gt_v2:
        __result__ = 1
    else:
        __result__ = 0

    __result__ = 1 not in [__result__]
    assert not __result__



# Generated at 2022-06-22 22:30:31.846916
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    lv = LooseVersion
    lv('').parse('')
    lv('1.5.1').parse('1.5.1')
    lv('1.5.2b2').parse('1.5.2b2')
    lv('161').parse('161')
    lv('3.10a').parse('3.10a')
    lv('8.02').parse('8.02')
    lv('3.4j').parse('3.4j')
    lv('1996.07.12').parse('1996.07.12')
    lv('3.2.pl0').parse('3.2.pl0')
    lv('3.1.1.6').parse('3.1.1.6')
    lv('2g6').parse('2g6')


# Generated at 2022-06-22 22:30:35.377538
# Unit test for method __str__ of class LooseVersion
def test_LooseVersion___str__():
    """
    >>> lv = LooseVersion('1.a.1')
    >>> str(lv)
    '1.a.1'

    >>> lv = LooseVersion('1.a.1')
    >>> lv.parse('2.b.2')
    >>> str(lv)
    '2.b.2'
    """


# Generated at 2022-06-22 22:30:38.798095
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    ver_inst = Version('1.2.3')
    assert ver_inst == '1.2.3'



# Generated at 2022-06-22 22:30:44.102673
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Create an instance of StrictVersion
    v = StrictVersion(vstring='1.3.3.3')
    assert v.version == (1, 3, 3, 3)
    assert v.prerelease is None

    v = StrictVersion(vstring='1.4b4')
    assert v.version == (1, 4)
    assert v.prerelease == ('b', 4)

    v = StrictVersion(vstring='1.4')
    assert v.version == (1, 4, 0)
    assert v.prerelease is None

    v = StrictVersion(vstring='1.0b1')
    assert v.version == (1, 0)
    assert v.prerelease == ('b', 1)

    v = StrictVersion(vstring='1.3.2')

# Generated at 2022-06-22 22:30:48.417952
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
   assert repr(LooseVersion('1.2a2')) == "LooseVersion ('1.2a2')"

# Generated at 2022-06-22 22:30:49.919885
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__(Version()) == NotImplemented


# Generated at 2022-06-22 22:30:52.027005
# Unit test for constructor of class LooseVersion
def test_LooseVersion():
    global LooseVersion
    print(LooseVersion)
    if __name__ != '__main__':
        import doctest
        doctest.testmod()

if __name__ == '__main__':
    test_LooseVersion()

# Generated at 2022-06-22 22:30:55.405614
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion("a.5.b.1-alpha")
    assert v.version == ['a', 5, 'b', 1, 'alpha']
test_LooseVersion_parse()


# Generated at 2022-06-22 22:30:57.023168
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    return LooseVersion("1.jpg")


# Generated at 2022-06-22 22:31:08.585694
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import LooseVersion, StrictVersion, LegacyVersion, Version
    from distutils.version import _legacy_cmp, _suggest_normalized_version
    from distutils.version import _parse_version_parts, __normalize_version


    def _legacy_cmp(op, a, b):
        try:
            return op(__normalize_version(a), __normalize_version(b))
        except Exception:
            return NotImplemented


    def _suggest_normalized_version(ver):
        try:
            return __normalize_version(ver)
        except Exception:
            return NotImplemented

    class LooseVersion(_suggest_normalized_version, _legacy_cmp, Version):
        pass



# Generated at 2022-06-22 22:31:13.866738
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.2')
    assert isinstance(v1, Version)
    v2 = Version('1.1.9')
    assert isinstance(v2, Version)
    if not v1 > v2:
        assert False, 'v1 > v2'
    else:
        assert (v1 > v2)



# Generated at 2022-06-22 22:31:23.538304
# Unit test for constructor of class StrictVersion
def test_StrictVersion():
    assert(str(StrictVersion("1.2a2")) == "1.2a2")
    assert(str(StrictVersion("1.2b2")) == "1.2b2")
    assert(str(StrictVersion("1.2.3.4")) == "1.2.3")
    assert(str(StrictVersion("1.2.0")) == "1.2")
    assert(str(StrictVersion("1.2.0.0")) == "1.2")
    assert(str(StrictVersion("1.02")) == "1.2")
    assert(str(StrictVersion("1.2.3a2")) == "1.2.3a2")
    assert(str(StrictVersion("1.2.0a2")) == "1.2a2")

# Generated at 2022-06-22 22:31:34.005391
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    import unittest
    import sys

    class Version___gt___TestCase(unittest.TestCase):
        def test_1(self):
            self.assertEqual(Version('1').__lt__('2'), True)
            self.assertEqual(Version('2').__lt__('1'), False)
        def test_2(self):
            self.assertEqual(Version('1').__le__('2'), True)
            self.assertEqual(Version('1').__le__('1'), True)
            self.assertEqual(Version('2').__le__('1'), False)
        def test_3(self):
            self.assertEqual(Version('1').__gt__('2'), False)
            self.assertEqual(Version('2').__gt__('1'), True)

# Generated at 2022-06-22 22:31:40.103007
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():
    # The function was changed not to return a string, but to
    # return an instance of class LooseVersion.  This test
    # should still pass.
    assert eval(str(LooseVersion("1.1"))) == LooseVersion("1.1")



# Generated at 2022-06-22 22:31:50.153520
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    c = LooseVersion()
    c.parse('1.5.1')
    eq(c.version, [1, 5, 1])
    c.parse('1.5.2b2')
    eq(c.version, [1, 5, 2, 'b', 2])
    c.parse('161')
    eq(c.version, [161])
    c.parse('3.10a')
    eq(c.version, [3, 10, 'a'])
    c.parse('8.02')
    eq(c.version, [8, '02'])
    c.parse('3.4j')
    eq(c.version, [3, '4', 'j'])
    c.parse('1996.07.12')
    eq(c.version, [1996, 7, 12])
    c

# Generated at 2022-06-22 22:31:51.756186
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    v.__lt__(None)


# Generated at 2022-06-22 22:32:02.470608
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def parse(s):
        try:
            return StrictVersion(s)
        except ValueError:
            return None

    def version_parts(v, n=3):
        return v.version + (v.prerelease and ("-" + v.prerelease[0] + str(v.prerelease[1])))


# Generated at 2022-06-22 22:32:03.990942
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version("1.0") > Version("1")
# end def test_Version___gt__


# Generated at 2022-06-22 22:32:12.200420
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert StrictVersion('0.4.0').__str__() == '0.4.0'
    assert StrictVersion('1.0').__str__() == '1.0.0'
    assert StrictVersion('1.0.50').__str__() == '1.0.50'
    assert StrictVersion('0.4.0b1').__str__() == '0.4.0b1'
    assert StrictVersion('0.4.0a1').__str__() == '0.4.0a1'


# Generated at 2022-06-22 22:32:16.377508
# Unit test for method __repr__ of class LooseVersion
def test_LooseVersion___repr__():

    l = LooseVersion('1.1.1')
    assert repr(l) == "LooseVersion ('1.1.1')"


# Generated at 2022-06-22 22:32:25.899691
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    l = LooseVersion()
    l.parse('1.2.3.4')
    assert l.version==[1, 2, 3, 4], l.version

    l.parse('1.2.0')
    assert l.version==[1, 2, 0], l.version

    l.parse('1.2')
    assert l.version==[1, 2], l.version

    l.parse('1.2pl3')
    assert l.version==[1, 2, 'pl', 3], l.version

    l.parse('1.2rc3')
    assert l.version==[1, 2, 'rc', 3], l.version

    l.parse('1.2.post456')
    assert l.version==[1, 2, 'post', 456], l.version


# Generated at 2022-06-22 22:32:35.225755
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version('0')
    w = Version('1.2')
    x = Version('1.2.0.0')
    y = Version('1.2.0.0.0.0')
    assert(not v.__ge__(w) and v.__ge__(x) and v.__ge__(y))
    assert(w.__ge__(v) and not w.__ge__(x) and w.__ge__(y))
    assert(not x.__ge__(v) and x.__ge__(w) and not x.__ge__(y))


# Generated at 2022-06-22 22:32:36.454913
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion("6.1.1")
    assert str(v) == "6.1.1"