

# Generated at 2022-06-25 11:06:37.202368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random_0 = None
# Instantiating of class LookupModule
    lookup_module_0 = LookupModule(**random_0)
    lookup_module_0.run(terms,inject)
    

# Generated at 2022-06-25 11:06:39.925638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, object)
#<<INCLUDE_ANSIBLE_MODULE_COMMON>>

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 11:06:48.990178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fhit = 0
    fmiss = 0
    for _ in range(0, 10000):
        foo = random.randrange(0, 2)
        if foo == 0:
            terms = None
        else:
            terms = random.randrange(-1000, 1000)
        lookup_module_0 = LookupModule()
        try:
            lookup_module_0.run(**terms)
        except:
            fmiss += 1
        else:
            fhit += 1
    print(fmiss)
    print(fhit)
# End of unit tests for method run of class LookupModule


# Generated at 2022-06-25 11:06:57.668728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["Njg1OTNhNzA5ZmFi", "NjE0NDI0ZDQzOTM1", "OGU3MjE3YjY5N2Y5"]
    dict_1 = {"inject": "OGU3MjE3YjY5N2Y5"}
    inject = "OGU3MjE3YjY5N2Y5"
    kwargs = {"inject": "OGU3MjE3YjY5N2Y5"}
    list_1 = lookup_module_0.run(terms, **dict_1)
    list_2 = lookup_module_0.run(terms, **kwargs)

# Generated at 2022-06-25 11:07:00.348212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["Rue France"]
    inject_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, inject_0, **kwargs_0) == ["Rue France"]


# Generated at 2022-06-25 11:07:10.989567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms', 'Terms']
    list_3 = []
    list_3.append(list_0)
    list_3.append(None)
    list_3.append(None)
    list_3.append(None)
    list_3.append(None)
    list_3.append(None)
    list_3.append(None)
    list_3.append(None)
    list_3.append(None)
    list

# Generated at 2022-06-25 11:07:22.442336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        "inject": dict(),
        "terms": [
            "example string 0",
            "example string 1",
            "example string 2",
            "example string 3",
            "example string 4",
            "example string 5",
        ],
        "kwargs": dict(),
    }
    lookup_module_0 = LookupModule(**dict_0)
    dict_1 = {
        "inject": dict(),
        "terms": [
            "example string 0",
            "example string 1",
            "example string 2",
            "example string 3",
            "example string 4",
            "example string 5",
        ],
        "kwargs": dict(),
    }
    lookup_module_1 = LookupModule(**dict_1)

# Generated at 2022-06-25 11:07:25.619319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = "file:///tmp/test_file"
    lookup_module_0 = LookupBase()
    lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:07:31.753416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_0['inject'] = dict()
    dict_0['terms'] = []
    dict_0['terms'].append('http://www.cnn.com/')
    dict_0['terms'].append('http://www.npr.org/')
    lookup_module_0 = LookupModule(**dict_0)
    ret = lookup_module_0.run(**dict_0)
    assert ret == ['http://www.npr.org/']


# Generated at 2022-06-25 11:07:37.773470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  dict_run = {
    'inject': {
        'a': {
            'b': [
                'c',
                'd',
                'e',
                'f'
            ],
            'g': {
                'h': [
                    'i',
                    'j',
                    'k'
                ]
            }
        }
    }
}
  lookup_module_run = LookupModule(**dict_run)
  run_return = lookup_module_run.run('a.b')
  assert run_return == [
	'c',
	'd',
	'e',
	'f'
]

# Generated at 2022-06-25 11:07:48.371807
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'inject': None,
        'terms': [
            'go through the door',
            'drink from the goblet',
            'press the red button',
            'do nothing'
        ],
        '**kwargs': {
        }
    }
    lookup_module_0 = LookupModule(**dict_0)

    ret = lookup_module_0.run(**dict_0)
    assert ret in (dict_0['terms'],)

# Generated at 2022-06-25 11:07:53.109450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
    }
    lookup_module_0 = LookupModule(**dict_0)
    random.seed(1)
    assert lookup_module_0.run(["hello", "goodbye", "other"]) == [
        "goodbye"]



# Generated at 2022-06-25 11:08:01.608384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'terms': [
            'foo',
            'bar',
            'baz'
        ]
    }
    lookup_module_0 = LookupModule(**dict_0)
    result = lookup_module_0.run(**dict_0)
    assert result.__contains__('bar') == False
    assert result.__contains__('baz') == False

# Generated at 2022-06-25 11:08:05.429295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['terms'] = ["g"]
    dict_0['inject'] = None
    dict_0['kwargs'] = dict()
    lookup_module_0 = LookupModule(**dict_0)
    # Fixme : generate a random input
    res = lookup_module_0.run(["g"], None, **dict())
    assert res == []

# Generated at 2022-06-25 11:08:08.589010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-25 11:08:13.936329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['run'] = run
    dict_0['_templar'] = _templar
    dict_0['get_basedir'] = get_basedir
    dict_0['cleanup'] = cleanup
    dict_0['__class__'] = __class__
    dict_0['__delattr__'] = __delattr__
    dict_0['__doc__'] = __doc__
    dict_0['__format__'] = __format__
    dict_0['__getattribute__'] = __getattribute__
    dict_0['__hash__'] = __hash__
    dict_0['__init__'] = __init__
    dict_0['__new__'] = __new__
    dict_0['__reduce__'] = __reduce__

# Generated at 2022-06-25 11:08:16.303268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    object_0 = lookup_module_0.run(to_native(['bar']), to_native(None))
    print(object_0)


# Generated at 2022-06-25 11:08:21.641530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if True:
        raise Exception()
    else:
        lookup_module_0 = LookupModule()
        terms = [u'green', u'purple']
        ret = lookup_module_0.run(**terms)
        print(ret)

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:08:28.524762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(**None)
    lookup_module_1 = lookup_module_0

    # Run the method with arguments.
    # The method call should return a list of matching items.
    lookup_module_1.run(*None, **None)

    # Run the method with default arguments.
    # The method call should return a list of matching items.
    lookup_module_0.run()



# Generated at 2022-06-25 11:08:30.376270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_instance_0 = TestCase.get_class_instance(LookupModule, class_under_test='LookupModule')
    

    assert class_instance_0.run() == None

# Generated at 2022-06-25 11:08:39.062461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = None
    inject_0 = None
    kwargs_0 = None
    ret_1 = lookup_module_0.run(terms_0, inject_0, kwargs_0)
    assert(ret_1 == None)



# Generated at 2022-06-25 11:08:43.605022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:08:47.688256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [1, 2, 3, 4, 5]
    lookup_module_0 = LookupModule(**terms_0)
    assert (lookup_module_0.run(terms_0) == [1, 2, 3, 4, 5]) == False
    assert lookup_module_0.run(terms_0) in [1, 2, 3, 4, 5]

# Generated at 2022-06-25 11:08:50.897214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    _1 = list
    _2 = str
    _3 = int

    def run(self, terms, inject=None, **kwargs):
        return [int(random.choice(terms))]
    lookup_module_0.run = run
    lookup_module_0.run()
    lookup_module_0.run()

# Generated at 2022-06-25 11:08:56.793577
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['terms'] = dict()
    dict_0['inject'] = dict()
    dict_0 = dict()
    dict_0['kwargs'] = dict()
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run()

# Generated at 2022-06-25 11:09:04.559423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = "go through the door"
    list_0 = list()
    list_0.append(str_0)
    list_1 = list()
    list_1.append(list_0)
    dict_1 = dict()
    dict_1.update({'terms': list_1})
    dict_2 = dict()
    dict_2.update({'test_case_0': dict_1})
    dict_2.update({'test_case_0': dict_0})
    dict_2.update({'test_case_0': None})
    lookup_module_0.run(dict_2)

# Generated at 2022-06-25 11:09:10.238817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'terms': [
            'a',
            'b',
            'c'
        ]
    }
    lookup_module_0 = LookupModule(**dict_0)
    str_ret_0 = lookup_module_0.run(**dict_0)
    assert any(map(lambda r: str_ret_0 == r, [
        'a',
        'b',
        'c'
    ]))


# Generated at 2022-06-25 11:09:20.498375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'inject': None,
    }
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = 'e'
    list_0 = []
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_0.append(str_0)
    list_1 = ['s', 'e', 's', 'e', 's']
    assert (lookup_module_0.run(**list_0) == list_1)


# Testing for class LookupModule

# Generated at 2022-06-25 11:09:24.635938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    params = None
    assert lookup_module_0.run(params) == None


# Generated at 2022-06-25 11:09:28.264497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    lookup_module_0 = LookupModule(**dict_0)
    terms_0 = []
    terms_1 = terms_0
    dict_1 = None
    dict_2 = dict_1
    ret_2 = lookup_module_0.run(terms_1, **dict_2)
    assert isinstance(ret_2, list)


# Generated at 2022-06-25 11:09:30.978005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(LookupModule.run)

# Generated at 2022-06-25 11:09:41.281639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['x', 'C', '/>/', 'h', '"', '>', '~', 'K']
    terms_1 = ['x', 'C', '/>/', 'h', '"', '>', '~', 'K']
    ret_0 = lookup_module_0.run(terms_0, lookup_module_0)
    if ret_0:
        print("test 0")
    ret_1 = lookup_module_0.run(terms_1, lookup_module_0)
    if ret_1:
        print("test 1")


# Generated at 2022-06-25 11:09:49.100625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(isinstance(lookup_module_0, LookupModule))
    assert(isinstance(lookup_module_1, LookupModule))
    assert(isinstance(lookup_module_2, LookupModule))
    ret_1 = lookup_module_0.run(['red'], terms, terms)
    assert(ret_1 is None)
    ret_2 = lookup_module_1.run(['red'], terms, terms)
    assert(isinstance(ret_2, list))
    assert(len(ret_2) == 1)
    assert(ret_2[0] == 'green')
    ret_3 = lookup_module_2.run(['red'], terms, terms)
    assert(ret_3 == ['green'])

# Generated at 2022-06-25 11:09:54.225799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of the class to be tested
    lookup_module_1 = LookupModule()
    # Create a tuple to pass to run()
    tuple_0 = ("terms", None)
    # Call the method being tested
    return_value_0 = lookup_module_1.run(*tuple_0)
    # Assert return value is not None
    assert return_value_0 is not None

# Generated at 2022-06-25 11:10:03.968412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:10:08.989943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.get_connection = lambda: None
    lookup_module_0.set_options = classmethod(lambda self: None)
    terms_0 = []
    inject_0 = None
    kwargs_0 = {}
    return_value_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    assert return_value_0 == []


# Generated at 2022-06-25 11:10:14.915965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "No mojo, no jojo"
    ret_0 = lookup_module_0.run(terms_0)

    assert ret_0 == "No mojo, no jojo"


# Generated at 2022-06-25 11:10:22.620170
# Unit test for method run of class LookupModule
def test_LookupModule_run():

	# Basic test
    lookup_instance_0 = LookupModule()
    assert callable(lookup_instance_0.run)
    assert isinstance(lookup_instance_0.run(["test"]), list)
    assert isinstance(lookup_instance_0.run(["test"])[0], basestring)
    assert lookup_instance_0.run(["test"])[0] in ["test"]

# Generated at 2022-06-25 11:10:29.491371
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    # tests with the first default args, the ones we expect to be used in normal cases
    assert lookup_module_0.run([list_0]) == [list_0]
    assert lookup_module_0.run([list_1]) == [list_1]
    assert lookup_module_0.run([list_2]) == [list_2]
    assert lookup_module_0.run([list_3]) == [list_3]
    assert lookup_module_0.run([list_4]) == [list_4]
    assert lookup_module_0.run([list_5]) == [list_5]
    assert lookup_module_0.run([list_6]) == [list_6]

# Generated at 2022-06-25 11:10:32.486795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_1 = ''
    lookup_module_0 = LookupModule(**{})
    try:
        lookup_module_0.run(terms_1)
    except:
        pass

# Generated at 2022-06-25 11:10:44.347314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = ['test_List']
    inject_0 = None
    kwargs_0 = None
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    assert isinstance(result, list) == True
    assert len(result) == 1
    assert isinstance(result[0], str) == True

# Generated at 2022-06-25 11:10:48.334129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = None
    inject_0 = None
    kwargs_0 = None
    lookup_module_0 = LookupModule(**kwargs_0)
    return_value_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)

# Generated at 2022-06-25 11:10:53.903872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = get_ansible_lookup_plugin(LookupModule)
    terms = None
    inject = None
    kwargs = None
    assert len(lookup_module_1.run(terms, inject, kwargs)) == 0

# Generated at 2022-06-25 11:10:57.653906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = None
    lookup_module_0 = LookupModule(**dict_0)
    # Test with run called with no arguments
    # This should throw an exception
    with pytest.raises(UnboundLocalError) as exception:
        lookup_module_0.run()



# Generated at 2022-06-25 11:11:03.572674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    inject = {}
    kwargs = {}
    ret = lookup_module_0.run(**dict(terms=terms, inject=inject, **kwargs))
    assert ret == [terms]

# Generated at 2022-06-25 11:11:07.882939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [{'list_of_strings': ['foo','bar','baz']}]
    lookup_module_0.run(terms, inject=None, **None)


# Generated at 2022-06-25 11:11:10.275383
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    data = [5]

    ret = lookup_module_0.run(data)
    assert ret == [5]

# Generated at 2022-06-25 11:11:15.139126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = random.randint(0, 100)
    terms_1 = bool(terms)

    ret = terms
    if terms:
        try:
            ret = [random.choice(terms)]
        except Exception as e:
            raise AnsibleError("Unable to choose random term: %s" % to_native(e))

    terms_2 = ret

    lookup_module_0 = LookupModule()

    params = {'terms': terms}
    result = lookup_module_0.run(**params)
    assert result == terms_2


# Generated at 2022-06-25 11:11:22.508513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms_0 = []
  inject_0 = None
  kwargs_0 = None
  assert lookup_module_0.run(terms_0, inject=inject_0) == terms_0
  terms_1 = ["b", "d", "e", "c", "a"]
  inject_1 = None
  kwargs_1 = None
  assert lookup_module_0.run(terms_1, inject=inject_1) in terms_1

# Generated at 2022-06-25 11:11:32.074623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict(**dict())
    str_0 = 'oHbHTOmPdBLf'
    set_0 = set()
    list_0 = list()
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(**dict_0)
    lookup_module_3 = LookupModule(**dict_0)
    lookup_module_2 = LookupModule(**dict_0)
    str_1 = 'JyFDi1bEaGgYlWS'
    lookup_module_2.run(str_1, dict_0)
    str_2 = 'dPnm9XqI3GbxE'
    lookup_module_0.run(str_2, dict_0)

# Generated at 2022-06-25 11:11:53.619475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        from random import sample as random_sample
    except ImportError:
        from random import choice as random_sample
    lookup_module_1 = LookupModule()
    list_0 = ["red", "green", "blue"]
    list_1 = ["green", "red", "blue"]
    list_2 = [lookup_module_1.run(list_0), lookup_module_1.run(list_1)]
    set_0 = set(list_2)
    list_3 = [set_0.issuperset(set(list_0)), str(random_sample(list_0,1)[0]) in list_0]
    if all(list_3):
        return True
    else:
        raise Exception("AssertionError %s not True" % list_3)

# Generated at 2022-06-25 11:12:01.975519
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:12:05.327330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = {}
    list_1 = lookup_module_0.run(list_0, **dict_0)
    assert list_1


# Generated at 2022-06-25 11:12:10.749053
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    LookupModule_instance = LookupModule()
    assert LookupModule_instance.run(terms=None, inject=None, **{}) == None

if __name__ == "__main__":
    print("Test the functions of LookupModule")
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:12:16.408755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

if __name__ == "__main__":
    test_case_0()
    x = test_LookupModule_run()
    print(x)

# Generated at 2022-06-25 11:12:19.249836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(**dict_0)
    str_0 = "with_random_choice"
    list_0 = []
    print(lookup_module_0.run(str_0, list_0))

# Generated at 2022-06-25 11:12:25.433639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [1,2,3,4]
    inject_0 = None
    kwargs_0 = {}
    expected_value_0 = [1,2,3,4]
    lookup_module_0 = LookupModule()
    actual_value_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    assert actual_value_0 == expected_value_0

# Generated at 2022-06-25 11:12:31.537721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        {
            '__playbook__': None,
            'name': 'copy',
            'ns': 'ansible.builtin.copy',
            'args': [
                'files',
                'src=files',
                'dest=/tmp/myfiles'
            ],
            'tags': None,
            'vars': {}
        },
        {
            '__playbook__': None,
            'name': 'copy',
            'ns': 'ansible.builtin.copy',
            'args': [
                'files',
                'src=files',
                'dest=/tmp/otherfiles'
            ],
            'tags': None,
            'vars': {}
        }
    ]
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms)

# Generated at 2022-06-25 11:12:33.613069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    terms_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:12:42.404493
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Test case 0
    test_case = 0
    terms_0 = None
    inject_0 = None
    lookup_plugin_0_kwargs = dict()
    lookup_plugin_0_kwargs['lookup_module'] = lookup_module_0
    lookup_module_0.run(terms=terms_0, inject=inject_0, **lookup_plugin_0_kwargs)
    try:
        lookup_module_0.run(terms=terms_0, inject=inject_0, **lookup_plugin_0_kwargs)
    except Exception:
        import traceback
        exc_info_0 = sys.exc_info()
        traceback_0 = traceback.format_tb(exc_info_0[2])
        print('exception')

# Generated at 2022-06-25 11:13:00.539169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True
  #assert False


# Generated at 2022-06-25 11:13:02.625541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    list_0 = []
    dict_1 = {}
    str_0 = lookup_module_1.run(list_0, inject=dict_1)
    str_1 = lookup_module_1.run()
    return str_0, str_1



# Generated at 2022-06-25 11:13:09.975575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['1', '2', '3']
    inject = 500
    kwargs = {'test':'unit test'}
    lookup_module_1 = LookupModule()
    new_list = lookup_module_1.run(terms, inject, **kwargs)
    assert(len(terms) == 3)
    assert(type(new_list[0]) is str)


# Generated at 2022-06-25 11:13:14.046087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # assertions
    assert True # TODO: implement your test here


# Generated at 2022-06-25 11:13:17.539475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1, 2, 3, 4, 5]
    lookup_module_0 = LookupModule(**terms)
    lookup_module_0.run([1, 2, 3, 4, 5])

# Generated at 2022-06-25 11:13:24.322746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  str_0 = None
  list_0 = [str_0]
  dict_0 = None
  lookup_module_0 = LookupModule(**dict_0)
  lookup_module_0.run(list_0, **dict_0)
  return

if __name__ == '__main__':
  test_case_0()
  test_LookupModule_run()
  print("Unit tests for random_choice.py passed")

# Generated at 2022-06-25 11:13:31.181423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  dict_0 = {
    "to_native": to_native,
    "AnsibleError": AnsibleError,
    "random": random,
  }
  terms_0 = "abcd"
  inject_0 = None
  kwargs_0 = {}
  random_choice_0 = lookup_module_0.run(terms_0, inject_0, ** kwargs_0)
  print(random_choice_0)

# Generated at 2022-06-25 11:13:36.250821
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Construct args
    terms = ['foo', 'bar', 'baz']

    # Invoke method
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(**dict(terms=terms))

    # Check result
    assert result in terms

# Generated at 2022-06-25 11:13:45.910027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

    # Mock test_case_0-3 with generated test_case_0-3 and test_case_0-3_0-0-0-0
    # arg not present so generate default value
    test_case_0_0_0_0 = []

    # Mock test_case_0-3 with generated test_case_0-3 and test_case_0-3_0-0-0-1
    # arg not present so generate default value
    test_case_0_0_0_1 = {}

    assert lookup_module_0.run(test_case_0_0_0_0, test_case_0_0_0_1) == test_case_0_0_0_0

    # Mock test_case

# Generated at 2022-06-25 11:13:52.477962
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    x = gen_arg_list(arg_type=dict)
    lookup_module_0 = LookupModule(**x)

    x = gen_arg_list(arg_type=dict)
    lookup_module_1 = LookupModule(**x)

    # test case with missing or extra params
    with pytest.raises(TypeError):
        lookup_module_0.run()
        lookup_module_1.run()

# Generated at 2022-06-25 11:14:39.722744
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = "a"
    inject_0 = None
    kwargs_0 = dict()
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms, inject_0, **kwargs_0)
    assert isinstance(ret, list)
    assert ret == ['a']

# Generated at 2022-06-25 11:14:48.002916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    list_0 = []
    dict_1 = {}
    list_1 = []
    list_2 = []
    dict_2 = {}
    list_3 = []
    list_4 = []
    list_5 = []
    list_6 = []
    assert lookup_module_0.run(list_0, dict_1) == []
    assert lookup_module_0.run(list_1, dict_2) == []



# Generated at 2022-06-25 11:14:53.130770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = None
    lookup_module_0 = LookupModule(**terms_0)
    assert lookup_module_0.run() == None

# Generated at 2022-06-25 11:14:59.993269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    local_var_0 = None
    local_var_1 = None
    local_var_0 = lookup_module_0.run(local_var_1)
    assert local_var_0 == []



# Generated at 2022-06-25 11:15:02.620212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'terms': None,
    }
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.set_options({
        'new': False,
    })
    lookup_module_0.run([])


from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-25 11:15:06.980757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['terms'] = [random.choice(terms)]
    dict_0['inject'] = None
    dict_0['kwargs'] = dict()
    lookup_module_0 = LookupModule(**dict_0)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 11:15:11.452945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = list()
    inject_0 = None
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run(terms_0, inject_0)

# Generated at 2022-06-25 11:15:17.395007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [""]
    terms_1 = [""]
    terms_2 = [""]
    terms_3 = []
    terms_4 = [""]
    terms_5 = [""]
    terms_6 = [""]
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms_0)
    lookup_module_0.run(terms_1)
    lookup_module_0.run(terms_2)
    lookup_module_0.run(terms_3)
    lookup_module_0.run(terms_4)
    lookup_module_0.run(terms_5)
    lookup_module_0.run(terms_6)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:15:21.800222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [None]
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run(**list_0)

if __name__ == "__main__":
    # Unit test for class LookupModule
    test_LookupModule_run()

# Generated at 2022-06-25 11:15:28.299663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def run_method_of_LookupModule_instance(parameter_0):
        lookup_module_0 = LookupModule()
        return lookup_module_0.run(parameter_0)
    class_0 = LookupModule()
    list_0 = list()
    random.choice(list_0)
    list_1 = list()
    list_2 = list()
    list_3 = list()
    list_4 = list()
    list_5 = list()
    list_6 = list()
    list_7 = list()
    list_8 = list()
    tuple_0 = (None,)
    tuple_1 = (None, None)
    tuple_2 = (None,)
    tuple_3 = (None, None)
    tuple_4 = (None,)
    tuple_5 = (None, None)