

# Generated at 2022-06-25 11:06:35.788938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupbase_0 = LookupModule()
    lookupbase_0.run([1, 2, 3, 4, 5], None, )


# Generated at 2022-06-25 11:06:42.725632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms = [
        'go through the door',
        'drink from the goblet',
        'press the red button',
        'do nothing'
    ]
    terms_param = terms
    inject = None
    kwargs = dict()

    ret = lookup_module_0.run(terms_param, inject, **kwargs)
    assert ret == terms

# Generated at 2022-06-25 11:06:53.055451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test invocation of run with correct parameters, test return value
    assert lookup_module_0.run(terms=[]) == []

    #test invocation of run with correct parameters, test return value
    assert lookup_module_0.run(terms=[]*10000) == []*10000

    #test invocation of run with correct parameters, test return value
    assert lookup_module_0.run(terms=[""]) == [""]

    #test invocation of run with correct parameters, test return value
    assert lookup_module_0.run(terms=[0]) == [0]

    #test invocation of run with correct parameters, test return value
    assert lookup_module_0.run(terms=[0]*10000) == [0]*10000

    #test invocation of run with correct parameters, test return value
    assert lookup_

# Generated at 2022-06-25 11:07:02.224020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    assert len(lookup_module_1.run([9, 8, 7, 6], inject=None, **{})) == 1
    assert len(lookup_module_1.run([9, 8, 7, 6], inject=None, **{})) == 1
    assert len(lookup_module_1.run([9, 8, 7, 6], inject=None, **{})) == 1
    assert len(lookup_module_1.run([9, 8, 7, 6], inject=None, **{})) == 1

    assert len(lookup_module_1.run(["x", "y", "z"], inject=None, **{})) == 1

# Generated at 2022-06-25 11:07:07.241199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['"foo"', "str", "str"]
    random_choice_0 = lookup_module_0.run(terms_0)
    assert random_choice_0 == "foo"


# Generated at 2022-06-25 11:07:10.461086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'a',
        'b',
        'c',
        'd'
    ]

    lookup_module = LookupModule()
    result = lookup_module.run(terms=terms, inject=None)

    assert result == ['a']

# Generated at 2022-06-25 11:07:12.402554
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  assert lookup_module_0.run(terms=["test1", "test2", "test3"]) == ["test2"]


# Generated at 2022-06-25 11:07:17.720284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([1, 2, 3], None, {}) in [1, 2, 3]

# Generated at 2022-06-25 11:07:19.938138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(["foo", "bar"])

# Generated at 2022-06-25 11:07:24.183136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run("a value") == ["a value"]

# Generated at 2022-06-25 11:07:36.683880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = [
        'a',
        'b',
        'c',
        'd',
        'e',
        'f',
    ]
    random_choice = lookup_module_0.run(term_0)

if __name__ == "__main__":
     test_LookupModule_run()
    #test_case_0()
    #import sys
    #try:
    #    test_case_0()
    #except:
    #    print('Uncaught Exception: ', sys.exc_info()[0])
    #    raise

# Generated at 2022-06-25 11:07:38.507118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(["a", "b", "c"])

    assert result == ["a"] or result == ["b"] or result == ["c"]

# Generated at 2022-06-25 11:07:40.387732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    lookup_module_run_0.run(["first", "second", "third"], {})

# Generated at 2022-06-25 11:07:50.655582
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Check that keys are returned in order when no value is specified

    # Create a mock inventory
    assert not False
    # Create the test case
    assert not False
    # Run the test
    assert not False

    # Check that keys are returned in random order when value is specified
    # Create a mock inventory
    assert not False
    # Create the test case
    assert not False
    test_run_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    # Run the test
    assert not False

    # Check that invalid values are handled gracefully
    # Create a mock inventory
    assert not False
    # Create the test case
    assert not False
    # Run the test
    assert not False

# Generated at 2022-06-25 11:07:53.816990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  list_of_strings = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
  assert isinstance(lookup_module.run([list_of_strings])[0], str)

# Generated at 2022-06-25 11:08:01.320066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    selftest_args_0 = ['foo']
    selftest_kwargs_0 = {}
    ret_val_0 = lookup_module_1.run(selftest_args_0, **selftest_kwargs_0)
    print(ret_val_0)


# Generated at 2022-06-25 11:08:03.298911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Tests that the returned list has exactly one element.
    assert len(lookup_module.run(["foo", "bar"])) == 1

# Generated at 2022-06-25 11:08:05.007570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [1]
    assert lookup_module_0.run(terms_0) == terms_0


# Generated at 2022-06-25 11:08:10.002359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    assert lookup_module_0.run(terms_0, [], []) == []

# Generated at 2022-06-25 11:08:11.110351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = lookup_module_0.run(terms=[1, 2, 3])

    assert 2 == 2


# Generated at 2022-06-25 11:08:19.345941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        ret = lookup_module_0.run(terms = ['foo', 'bar'])
        assert ret == ['foo'] or ret == ['bar']
    except Exception as e:
        raise Exception(e)


# Generated at 2022-06-25 11:08:22.778020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['go through the door']), "Returned list should be equal to ['go through the door']"

# Generated at 2022-06-25 11:08:25.118013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # get a random element from a list
    lookup_module_0.run(['a', 'b', 'c'])

# Generated at 2022-06-25 11:08:27.855605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    lookup_module_0.run(['foo'])

# Generated at 2022-06-25 11:08:34.886004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert [u'go through the door'] == lookup_module.run([u'go through the door', u'drink from the goblet', u'press the red button', u'do nothing'])
    assert [u'drink from the goblet'] == lookup_module.run([u'drink from the goblet', u'press the red button', u'do nothing', u'go through the door'])
    assert [u'press the red button'] == lookup_module.run([u'press the red button', u'do nothing', u'go through the door', u'drink from the goblet'])

# Generated at 2022-06-25 11:08:38.422276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(len(lookup_module_0.run(["a", "b", "c"])) == 1)

# Generated at 2022-06-25 11:08:47.121200
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with term = []
    assert lookup_module_0.run([]) == [], "Expected: %s, Actual: %s" % ([], lookup_module_0.run([]))
    # Test with term = ['']
    assert lookup_module_0.run(['']) == [''], "Expected: %s, Actual: %s" % (['blah'], lookup_module_0.run(['']))

# Generated at 2022-06-25 11:08:49.639947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Actual
    lookup_module_0 = LookupModule()
    actual = lookup_module_0.run(['a', 'b', 'c'])

    # Expected
    expected = ['b']

    assert actual == expected

test_LookupModule_run()

# Generated at 2022-06-25 11:08:53.155023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  try:
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])
  except AnsibleError as err:
    pass

# Generated at 2022-06-25 11:08:59.317170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookupModule0 = LookupModule()

# Generated at 2022-06-25 11:09:18.412624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.lookup_basedir = None
    lookup_module_0.run = lambda terms, inject=None, **kwargs: ['a']
    lookup_plugin = lookup_module_0.run
    assert 'a' == lookup_plugin("faketerm")
#    assert 'a' == lookup_plugin("faketerm", inject=None, **kwargs)


# Generated at 2022-06-25 11:09:20.563450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])
    lookup_module_0.run([], inject=None)

# Generated at 2022-06-25 11:09:24.430151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [
        'ansible',
        'ansible'
    ]
    assert lookup_module_1.run(terms) == ['ansible']


# Generated at 2022-06-25 11:09:28.601149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = ['a', 'b', 'c', 'd', 'e']
    inject_0 = [None]
    param_0 = None
    kwargs_0 = {}

    res_0 = lookup_module_0.run(terms_0, inject_0, param_0, kwargs_0)
    assert res_0 is not None



# Generated at 2022-06-25 11:09:30.916757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run()
    assert (ret == [])

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:09:39.584386
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = [ "a", "b", "c" ]

    try:

        ret = lookup_module_0.run(terms_0)
        assert len(ret) == 1
        assert ret[0] in [ "a", "b", "c" ]

    except Exception as e:
        print("Exception caught: %s" % to_native(e))
        assert 0

test_LookupModule_run()

# Generated at 2022-06-25 11:09:44.426656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test = lookup_module.run(['a', 'b'], [], [], [])
    assert test == ['a'] or test == ['b']

# Generated at 2022-06-25 11:09:45.517510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list = [ 'one', 'two', 'three' ]
    lookup_module = LookupModule()
    assert lookup_module.run(list)

# Generated at 2022-06-25 11:09:58.691924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:10:01.402564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0(lookup_module_0)
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-25 11:10:29.439891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
#
#     # random.choice() is non-deterministic, so we can't know the order of the results.
#     # TODO: find a better way to get deterministic results in the unit test
#     A = ["a", "b", "c"]
#     B = ["e", "f", "g"]
#     C = []
#     D = ["z"]
#
#     assert lookup_module_0.run(A) == lookup_module_0.run(A)
#     assert lookup_module_0.run(B) == lookup_module_0.run(B)
#     assert lookup_module_0.run(C) == []
#     assert lookup_module_0.run(D) == ["z"]

# Generated at 2022-06-25 11:10:33.908260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t']) == ['f']

# Generated at 2022-06-25 11:10:42.700409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _terms = ["one", "two", "three"]
    _inject = {}
    # _kwargs = {}
    lookup_module_0 = LookupModule()
    # random.choice is mocked to always return "one"
    _random_choice = lambda x: "one"
    with mock.patch.object(lookup_module_0, "run", return_value=["one"]):
        result = lookup_module_0.run(terms=_terms, inject=_inject)
        assert result == ["one"]

    result = lookup_module_0.run(terms=_terms, inject=_inject)
    assert result == ["one"]

# Generated at 2022-06-25 11:10:46.943176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    random.seed(1)
    assert lookup_module.run(['hello', 'world']) == ['world']
    random.seed(1)
    assert lookup_module.run(['hello', 'world', '!']) == ['world']

# Generated at 2022-06-25 11:10:54.331183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["a", "b", "c"]
    ret = lookup_module_0.run(terms)

    assert ret == ["a"] or ret == ["b"] or ret == ["c"]
    #assert False

test_LookupModule_run()

# Generated at 2022-06-25 11:10:56.647994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert True == lookup_module_1.run(["foo","bar"])


# Generated at 2022-06-25 11:10:58.663819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['string_0']
    assert lookup_module_0.run(terms_0) == terms_0

# Generated at 2022-06-25 11:11:02.726787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    my_var = []
    lookup_module_0.run(my_var)


# Generated at 2022-06-25 11:11:07.444005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # test with dummy input
    terms = ["test", "test1", "test2"]
    ret = lookup_module_0.run(terms)
    assert ret[0] in terms

# Generated at 2022-06-25 11:11:08.295910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(LookupModule.run)

# Generated at 2022-06-25 11:11:57.498630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()
    ret_0 = lookup_module_0.run(terms="test_terms_0")

# Generated at 2022-06-25 11:12:04.293300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]

    # Expected fails
    try: 
        assert lookup_module_0.run(terms, inject=None) != ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
        raise AssertionError('Error: Expected assert to fail but it passed')
    except AssertionError as e:
        pass

# Generated at 2022-06-25 11:12:07.968044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 11:12:09.499235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run([1, 2, 3])

# Generated at 2022-06-25 11:12:11.795507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ('hi',)
    assert lookup_module_0.run(terms_0) in terms_0

# Generated at 2022-06-25 11:12:16.529057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms=['Aaaa', 'Bbbb'], inject=None, **kwargs)


# Generated at 2022-06-25 11:12:19.096932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = "foo,bar,baz"
    res = lookup_module_0.run(terms)

    # Assume any non-empty list is valid
    assert res

# Generated at 2022-06-25 11:12:21.624456
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([]) == []

# Generated at 2022-06-25 11:12:26.795270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._display.verbosity = 1

    test_case_0()
    test_case_1()


# Generated at 2022-06-25 11:12:29.470563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader()
    lookup_module_0.set_environment()

# Generated at 2022-06-25 11:14:18.736604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    param_0 = [
        'John', 
        'Kate', 
        'Alex'
        ]
    param_1 = {}
    ret_obj_0 = lookup_module_0.run(param_0, 
                                    param_1)
    assert ret_obj_0 is not None


# Generated at 2022-06-25 11:14:20.144096
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["a", "b"]
    inject = None
    kwargs = {}
    assert len(lookup_module_0.run(terms, inject, **kwargs)) == 1
    assert len(lookup_module_0.run(terms, inject, **kwargs)) != 0


# Generated at 2022-06-25 11:14:26.736628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['item_0', 'item_1' ]
    inject_0 = { }
    assert lookup_module_0.run(terms_0, inject_0) == ['item_0']
# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 11:14:31.627447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(['foo', 'bar'])
    assert res == ['foo'] or res == ['bar']

# Generated at 2022-06-25 11:14:38.178212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{"item": "test"}]
    lookup_module_0 = LookupModule()

    try:
        result_0 = lookup_module_0.run(terms)
    except Exception as  e:
        result_0 = "Error catch:" + e

    try:
        result_1 = lookup_module_0.run(terms,None)
    except Exception as  e:
        result_1 = "Error catch:" + e

    try:
        result_2 = lookup_module_0.run(terms,None,**{"item": "test"})
    except Exception as  e:
        result_2 = "Error catch:" + e


# Generated at 2022-06-25 11:14:41.671968
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [1,2,3,4]
    assert lookup_module.run(terms) in terms


# Generated at 2022-06-25 11:14:46.420290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    results = lookup_module.run(['dude', 'walter', 'theodore'])
    assert results, 'Return value is empty'
    assert results[0] in ['dude', 'walter', 'theodore']

# Generated at 2022-06-25 11:14:48.262064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    ret_0 = lookup_module_0.run(terms_0)


# Generated at 2022-06-25 11:14:54.018956
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Test #0 - Successfully select one item

    terms = [b'a', b'b']
    result = lookup_module.run(terms)
    assert len(result) == 1
    assert result[0] in terms

    # Test #1 - Correct error handling when list is empty

    terms = []
    with pytest.raises(AnsibleError):
        lookup_module.run(terms)

    # Test #2 - Correct error handling when list is None

    terms = None
    with pytest.raises(AnsibleError) as e:
        lookup_module.run(terms)
    assert e.value.args[0] == "Unable to choose random term: 'NoneType' object is not iterable"

# Generated at 2022-06-25 11:15:00.287162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['foo', 'bar']
    inject_0 = None
    kwargs_0 = {'somekey': 'somevalue'}
    assert lookup_module_0.run(terms_0, inject_0, **kwargs_0) == ['foo']