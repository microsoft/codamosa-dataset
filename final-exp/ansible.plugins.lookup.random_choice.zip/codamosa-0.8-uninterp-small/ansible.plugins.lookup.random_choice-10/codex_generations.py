

# Generated at 2022-06-25 11:06:36.776599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['one', 'two', 'three', 'four', 'five']
    assert lookup_module.run(terms) != []

# Generated at 2022-06-25 11:06:37.882438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(True)

# Generated at 2022-06-25 11:06:42.997486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        assert 0
    except Exception as e:
        print("random_choice.py: "+e.__str__())
        assert 0


# Generated at 2022-06-25 11:06:49.738525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(0)
    data = [["test"], 10, 20]
    expected = 20
    actual = lookup_module_0.run(data)
    assert actual == expected
    random.seed(1)
    data = [10, 20, 30]
    expected = 30
    actual = lookup_module_1.run(data)
    assert actual == expected

# Generated at 2022-06-25 11:06:56.683455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['rwsr-xr-x', 'rw-r--r--', 'r--r--r--', 'rwxr-xr-x', 'rw-r--r--', 'rwxr-x---', 'rw-r--r--', 'rwxr-xr-x', 'rw-r--r--']
    inject_0 = None
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, inject=inject_0, **kwargs_0)
    print(result_0)
    print(result_0)

# Generated at 2022-06-25 11:06:59.768499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    tm = lm.run(['a', 'b'])
    # Test whether it returns a list
    assert isinstance(tm, list)
    # Test whether the lengths of the list are equal.
    assert len(tm) == 1
    

# Generated at 2022-06-25 11:07:10.917938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

    test_terms_0 = [[' ']]
    inject_0 = {'vars': {'var': 'var'}}
    kwargs_0 = {'variable_start_string': 'variable_start_string', 'variable_end_string': 'variable_end_string'}
    result_0 = lookup_module_0.run(test_terms_0, inject_0, **kwargs_0)
    assert result_0 == [' ']


# Generated at 2022-06-25 11:07:12.822083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for _ in range(10):
        assert len(test_case_0.run(['1', '2', '3', '4', '5'])) == 1


# Generated at 2022-06-25 11:07:22.335006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = [ "", "", "", "", "", "", "", "", "", "" ]
    ret_2 = lookup_module_0.run(terms_0)
    assert len(ret_2) == 1

    terms_1 = [ "", "", "", "", "", "", "", "", "", "" ]
    ret_1 = lookup_module_0.run(terms_1)
    assert len(ret_1) == 1

    terms_2 = [ "", "", "", "", "", "", "", "", "", "" ]
    ret_0 = lookup_module_0.run(terms_2)
    assert len(ret_0) == 1

# vim: filetype=python

# Generated at 2022-06-25 11:07:26.259918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert lookup_module.run([5, 10, 15]) == [5] or lookup_module.run([5, 10, 15]) == [10] or lookup_module.run([5, 10, 15]) == [15]

# Generated at 2022-06-25 11:07:30.769703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['test_terms_0']
    test_0 = lookup_module_0.run(terms_0)
    if len(test_0) == 1:
        return True
    else:
        return False



# Generated at 2022-06-25 11:07:35.223658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arguments_0 = ["three", "two", "one"]
    expected_0 = ["two"]
    actual_0 = lookup_module_0.run(arguments_0)
    assert actual_0 == expected_0

    lookup_module_1 = LookupModule()
    arguments_1 = ["three", "two", "one"]
    expected_1 = ["two"]
    actual_1 = lookup_module_1.run(arguments_1)
    assert actual_1 == expected_1


# Generated at 2022-06-25 11:07:35.677641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-25 11:07:38.697278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=[1, 2, 3], inject=None, **{}) == [1, 2, 3]
    # random.choice() returns one random element from a list
    assert len(lookup_module_0.run(terms=[1, 2, 3], inject=None, **{})) == 1

# Generated at 2022-06-25 11:07:42.019307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms=None, inject=None, **{}) # TODO: Use actual kwargs instead of **{}


# Generated at 2022-06-25 11:07:49.894437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg0 = ["This", "is", "a", "list."]
    arg1 = None
    arg2 = {}
    test_case_0 = lookup_module_0.run(arg0, arg1, arg2)
    lookup_module_1 = LookupModule()
    arg0 = ["Is", "this", "a", "list?"]
    arg1 = None
    arg2 = {}
    test_case_1 = lookup_module_1.run(arg0, arg1, arg2)

# Generated at 2022-06-25 11:07:52.690531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["hello", "world"]
    assert lookup_module_0.run(terms) == terms

# Generated at 2022-06-25 11:07:56.504004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # If a list is passed as input parameter then return one of the element randomly
    assert len(lookup_module.run(['1', '2', '3'], inject=None, **{})) == 1
    # If a non list parameter is passed as input parameter then return the input as it is.
    assert lookup_module.run('', inject=None, **{}) == ''


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:08:00.069734
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_run_instance = LookupModule()
    test_run_instance.run(['a', 'b', 'c'], inject=None, **{'dict_type': 'normal'})
    test_run_instance.run(['a', 'b', 'c'], inject=None, kwargs='normal')

# Generated at 2022-06-25 11:08:06.010818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [{'this', 'is', 'a', 'test'}, {'random', 'choice', 'will', 'be', 'made'}]
    lookup_module_2 = LookupModule()
    lookup_module_2.run(terms)

    terms = []
    lookup_module_3 = LookupModule()
    lookup_module_3.run(terms)

# Generated at 2022-06-25 11:08:16.196731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    assert lookup_module_0.run([1, 2, 3])[0] in [1, 2, 3]
    assert lookup_module_1.run([1, 2, 3])[0] in [1, 2, 3]


# Generated at 2022-06-25 11:08:26.268006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    response_0 = lookup_module_0.run(['docker', 'k8s'])
    response_1 = lookup_module_1.run(['docker', 'k8s'], inject=None, preferred='preferred')
    response_2 = lookup_module_2.run(['docker', 'k8s'], inject='inject')
    assert response_1[0] == 'docker' or response_1[0] == 'k8s'
    assert response_2 == ['docker'] or response_2 == ['k8s']
    assert response_0 == ['docker'] or response_0 == ['k8s']

# Generated at 2022-06-25 11:08:34.413030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    foo = LookupModule()
    assert foo.run(terms=['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], inject=None, **{}) == ['9']
    assert foo.run(terms=['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], inject=None, **{}) == ['6']
    assert foo.run(terms=['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'], inject=None, **{}) == ['4']

# Generated at 2022-06-25 11:08:37.584108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    assert lookup_module_0.run(None).__eq__([])
    assert lookup_module_0.run([]).__eq__([])
    assert lookup_module_1.run(None).__eq__([])
    assert lookup_module_1.run([]).__eq__([])
    assert lookup_module_0.run([]).__eq__(lookup_module_1.run([]))


# Generated at 2022-06-25 11:08:41.105293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['example1','example2']
    inject = None
    result = lookup_module.run(terms, inject)
    assert result == ['example1'] or result ==['example2']

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:08:44.746012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["Terms"]
    inject_0 = None
    lookup_module_0.run(terms_0, inject_0)

# Generated at 2022-06-25 11:08:46.932392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_0.run()
    lookup_module_1.run()

# Generated at 2022-06-25 11:08:55.558462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "Hello world"
    terms_1 = "Hello world"
    terms_2 = ""
    terms_3 = "Hello world"
    terms_4 = "Hello world"

    ret_0 = lookup_module_0.run(terms=terms_0)
    lookup_module_0.run(terms=terms_1,inject=ret_0)
    lookup_module_0.run(terms=terms_2,inject=ret_0)
    lookup_module_0.run(terms=terms_3,inject=ret_0)
    lookup_module_0.run(terms=terms_4,inject=ret_0)

# Generated at 2022-06-25 11:08:59.086421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    inject = dict()
    lookup_module_0.run(terms_0, inject)


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:09:05.822682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # call run with results in random choice for list
    results = lookup.run(["one", "two", "three"], inject={"one": "one",
                                                          "two": "two",
                                                          "three": "three"})
    assert len(results) is 1
    assert "one" in results
    assert "two" in results
    assert "three" in results

    # call run with results in random choice for list
    results = lookup.run(None, inject={"one": "one",
                                       "two": "two",
                                       "three": "three"})
    assert not results
    assert len(results) is 0

# Generated at 2022-06-25 11:09:18.738756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.run(terms=None, inject=None)
    lookup_module_3 = LookupModule()
    lookup_module_3.run(terms=0, inject=None)

# Generated at 2022-06-25 11:09:26.998996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert(lookup_module.run([], {}) == [])

    assert(len(lookup_module.run(["aaa", "bbb", "ccc", "ddd", "eee"], {})) == 1)

    assert(lookup_module.run([], {'_loader': None}) == [])

    assert(lookup_module.run(None, None) == None)

    assert(lookup_module.run(["aaa", "bbb", "ccc", "ddd", "eee"], {}))

# Generated at 2022-06-25 11:09:34.192287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["1", "2", "3", "4", "5"]
    ret = lookup_module.run(terms)
    assert(len(ret) == 1)
    assert(ret[0] == "1" or ret[0] == "2" or ret[0] == "3" or ret[0] == "4" or ret[0] == "5")

# Generated at 2022-06-25 11:09:43.419960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    terms = []
    try:
        lookup_module_0.run(terms)
    except AnsibleError as err:
        assert 'Unable to choose random term: index out of range' in str(err)
    finally:
        pass
    terms = [0, '', '1']
    ret = lookup_module_0.run(terms)
    assert ret == terms
    terms = [0, '', '1']
    ret = lookup_module_1.run(terms)
    assert ret == terms
    terms = ['1', '', '0']
    ret = lookup_module_1.run(terms)
    assert ret == terms
    terms = ['1', '', '0']

# Generated at 2022-06-25 11:09:50.022156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    cases = [
        #Case 0: Test case with single term
        {"terms":[ "foo" ], "result":["foo"] },
        #Case 1: Test case with multiple term
        {"terms":[ "foo", "bar" ], "result":["foo"] },
        #Case 2: Test case with empty list
        {"terms":[ ], "result":[] },
        #Case 3: Test case with empty list
        {"terms":[ [] ], "result":[] },
        #Case 4: Test case with empty list
        {"terms":[ None ], "result":[] }
    ]

    for case in cases:
        print("terms: {}, result: {}".format(case['terms'], case['result']))
        lookup_module = LookupModule()
        assert lookup_module.run(case['terms']) == case['result']


# Generated at 2022-06-25 11:09:52.134414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()
    lookup_module.run()
    lookup_module.run()

# Generated at 2022-06-25 11:10:01.090575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    terms_0 = None
    inject_0 = None
    result_0 = lookup_module_0.run(terms_0, inject=inject_0)
    terms_1 = ["a", "b", "c"]
    inject_1 = None
    result_1 = lookup_module_1.run(terms_1, inject=inject_1)
    terms_2 = ["b", "c", "d"]
    inject_2 = None
    result_2 = lookup_module_0.run(terms_2, inject=inject_2)
    terms_3 = ["a", "b", "c"]
    inject_3 = None

# Generated at 2022-06-25 11:10:04.587488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [ ]
    inject_0 = { }
    kwargs_0 = { }
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(terms_0, inject=inject_0, **kwargs_0)
    assert ret_0 == [ ]

# Generated at 2022-06-25 11:10:08.363916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    random.seed(0)
    terms = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    lookup_module_0.run(terms, inject=None)
    assert(terms == ['drink from the goblet'])

# Generated at 2022-06-25 11:10:18.384613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    terms_0 = [to_native(u"rooftop")]
    terms_1 = [to_native(u"fjord")]
    terms_2 = [to_native(u"lounge"), to_native(u"gargoyle")]
    terms_3 = [to_native(u"lounge"), to_native(u"gargoyle"), to_native(u"barracuda")]
    ret_0 = lookup_module_0.run(terms_0)
    ret_1 = lookup_module_1.run(terms_1)
    ret_2 = lookup_module_0.run(terms_2)
    ret_3 = lookup_module_0.run(terms_3)
    # check

# Generated at 2022-06-25 11:10:43.239882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run("aTb", inject=None, **{}) == 'b'
    assert lookup_module_0.run("abcd", inject=None, **{}) == list("abcd")
    assert lookup_module_0.run("caco", inject=None, **{}) == "c"
    assert lookup_module_0.run("a", inject=None, **{}) == "a"
    assert lookup_module_0.run("b", inject=None, **{}) == "b"
    assert lookup_module_0.run("z", inject=None, **{}) == "z"


# Generated at 2022-06-25 11:10:48.568977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_1 = LookupModule()
        term_0 = "term_0"
        lookup_module_0.run(term_0)
        term_1 = "term_1"
        lookup_module_1.run(term_1)
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 11:10:57.714190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    r_lm = LookupModule()  # isinitialize object of LookupModule

    test_value = r_lm.run(terms=["apple","orange","banana","raspberry"],inject=None , test=None)
    assert test_value in ["apple","orange","banana","raspberry"]
    test_value1 = r_lm.run(terms=["apple","orange","banana","raspberry"],inject=None , test=None)
    assert test_value1 in ["apple","orange","banana","raspberry"]
    test_value2 = r_lm.run(terms=["apple","orange","banana","raspberry"],inject=None , test=None)
    assert test_value2 in ["apple","orange","banana","raspberry"]



# Generated at 2022-06-25 11:11:07.320727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Stub for the LookupModule class
    class LookupModule(object):
        def __init__(self, terms=None, inject=None, kwargs=None):
            self.terms = terms
            self.inject = inject
            self.kwargs = kwargs

    # The constructor for LookupModule expects parameters: terms, inject, kwargs
    lookup_module = LookupModule(
        terms=["A", "B"],
        inject=None,
        kwargs=None
    )

    # Using the run method (with no parameters) of the LookupModule object returns a subset of the terms list
    result = lookup_module.run()
    assert result in [["A"], ["B"]]



# Generated at 2022-06-25 11:11:16.052481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_Ins_0 = LookupModule()
    lookup_module_Ins_1 = LookupModule()
    arg0 = ['a', 'b', 'c']
    arg1 = ['a', 'b']
    arg2 = ['a']
    arg3 = ['']
    arg4 = [' ']
    arg5 = ['   ']
    arg6 = ['p', 'y', 't', 'h', 'o', 'n']
    arg7 = ['python, java, c#, c++, javascript']
    arg8 = ['alpha', 'beta', 'gama', 'delta', 'theta']
    arg9 = ['a', 'b', 'c', 'd', 'e']

# Generated at 2022-06-25 11:11:25.193134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [1,2,3,4,5,6,7,8,9,10]
    lookup_module_1 = LookupModule()
    terms = [1,2,3,4,5,6,7,8,9,10]

    assert(lookup_module_0.run(terms) == lookup_module_1.run(terms))
    assert(lookup_module_0.run(terms) == lookup_module_1.run(terms))
    assert(lookup_module_0.run(terms) == lookup_module_1.run(terms))


# Generated at 2022-06-25 11:11:26.742125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run("terms")


# Generated at 2022-06-25 11:11:28.449651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [u'go through the door', u'drink from the goblet', u'press the red button', u'do nothing']
    ret = lookup_module_0.run(terms)

    assert(ret[0] != '')


# Generated at 2022-06-25 11:11:30.599599
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms = []
    ret = []
    assert lookup_module_0.run(terms) == ret


# Generated at 2022-06-25 11:11:34.920305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_0.run(['go through the door', 'drink from the goblet', 'press the red button', 'do nothing'], [])


# Generated at 2022-06-25 11:12:22.104738
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an object of class LookupModule
    lookup_module_0 = LookupModule()
    # Create an object of class LookupBase
    lookup_base_0 = LookupBase()
    # Initialize values for the method run of object lookup_module_0
    lookup_module_0.run([], None)
    # Initialize values for the method run of object lookup_module_0
    lookup_module_0.run([''], None)
    # Initialize values for the method run of object lookup_module_0
    lookup_module_0.run(['\u3000', '\u3000', '\u3000'], None)
    # Initialize values for the method run of object lookup_module_0
    lookup_module_0.run(['\u3001', '\u3001', '\u3001'], None)

# Generated at 2022-06-25 11:12:28.126172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    arguments = ["one","two","three"]
    var0 = lookup_module_0.run(arguments)
    var1 = lookup_module_1.run(arguments)
    assert var0 != var1

# Generated at 2022-06-25 11:12:29.437256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["a","b"])

# Generated at 2022-06-25 11:12:32.059038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = {}
    inject = None
    lookup_module_0.run(terms, inject)


# Generated at 2022-06-25 11:12:37.950459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()    # create instance of LookupModule
    #assert that method run will return ['start']
    assert lookup_module.run([['start'],['start']]) == ['start']
    assert lookup_module.run([['start']]) == ['start']

# Generated at 2022-06-25 11:12:41.586751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(["1", "2", "3"])

# Generated at 2022-06-25 11:12:49.540803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    inject_0 = None
    kwargs_0 = { }
    ret_0 = lookup_module_0.run(terms_0, inject=inject_0, **kwargs_0)
    lookup_module_1 = LookupModule()
    terms_1 = []
    inject_1 = None
    kwargs_1 = { }
    ret_1 = lookup_module_1.run(terms_1, inject=inject_1, **kwargs_1)
    assert ret_0 == ret_1

# Generated at 2022-06-25 11:12:55.140079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_5 = LookupModule()
    assert lookup_module_5.run(terms=[]) == []
    lookup_module_6 = LookupModule()

# Generated at 2022-06-25 11:13:00.921864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    ret_0 = lookup_module_0.run(terms_0)
    assert ret_0 == []
    terms_1 = ["foo"]
    ret_1 = lookup_module_0.run(terms_1)
    assert ret_1 == ["foo"]
    terms_2 = ["foo", "bar"]
    ret_2 = lookup_module_0.run(terms_2)
    assert ret_2 == ["foo"]
    ret_3 = lookup_module_1.run(terms_2)
    assert ret_3 == ["foo"]

# Generated at 2022-06-25 11:13:05.327638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([random.choice(["value_1", "value_2"])])
    lookup_module_0.run([random.choice(["value_1", "value_2"])])
    lookup_module_0.run([random.choice(["value_1", "value_2"])])
    lookup_module_0.run([random.choice(["value_1", "value_2"])])
    lookup_module_0.run([random.choice(["value_1", "value_2"])])
    lookup_module_0.run([random.choice(["value_1", "value_2"])])
    lookup_module_0.run([random.choice(["value_1", "value_2"])])
    lookup_module_

# Generated at 2022-06-25 11:14:35.942011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  lookup_module.run("")
  lookup_module.run(["1", "2", "3"])

# Generated at 2022-06-25 11:14:43.929484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['a', 'b', 'c', 'd', 'e']
    lookup_result_0 = lookup.run(terms)
    lookup_result_1 = lookup.run(terms)
    lookup_result_2 = lookup.run(terms)
    lookup_result_3 = lookup.run(terms)
    lookup_result_4 = lookup.run(terms)
    lookup_result_5 = lookup.run(terms)
    lookup_result_6 = lookup.run(terms)
    lookup_result_7 = lookup.run(terms)
    lookup_result_8 = lookup.run(terms)
    lookup_result_9 = lookup.run(terms)
    lookup_result_10 = lookup.run(terms)
    lookup_result_11 = lookup.run(terms)
    lookup_result

# Generated at 2022-06-25 11:14:46.952695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = [1, 2, 3]
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(l)

#
#   This is an obligatory example of a test case (even if it is empty)
#

# Generated at 2022-06-25 11:14:49.293055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run([])

# Generated at 2022-06-25 11:14:54.941970
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for run of class LookupModule
    lookup_module_0 = LookupModule()

    params_0 = ['test_param_4', 'test_param_5']
    assert lookup_module_0.run(params_0) == ['test_param_4']
    # Check for correct type
    assert isinstance(lookup_module_0.run(params_0), list)
    assert lookup_module_0.run(params_0) == ['test_param_4']
    params_0 = ['test_param_4', 'test_param_5', 'test_param_5']
    assert lookup_module_0.run(params_0) == ['test_param_4']
    params_0 = ['test_param_4']

# Generated at 2022-06-25 11:14:57.594311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'go through the door', u'drink from the goblet', u'press the red button', u'do nothing']
    ret_1 = lookup_module_0.run(terms_0)
    assert len(ret_1) == 1

# Generated at 2022-06-25 11:14:58.849973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["Red", "Green", "Blue"]
    lookup_module = LookupModule()
    assert len(lookup_module.run(terms)) == 1

# Generated at 2022-06-25 11:15:01.673656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up object
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

    terms = [1, 2, 3, 4]
    # invoke method
    result = lookup_module_0.run(terms)
    assert result in terms


# Generated at 2022-06-25 11:15:08.195420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters
    terms = ["a", "b", "c"]
    inject = {"a": "b"}
    kwargs = {}
    # Expected return value
    expected_return_value = ["a", "b", "c"]
    # Call method
    lookup_module = LookupModule()
    return_value = lookup_module.run(terms, inject, **kwargs)
    # Assertion
    assert return_value == expected_return_value

# Generated at 2022-06-25 11:15:11.453370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run([]) == []
    assert lookup_module_1.run(["1","2","3"]) == ["1","2","3"]