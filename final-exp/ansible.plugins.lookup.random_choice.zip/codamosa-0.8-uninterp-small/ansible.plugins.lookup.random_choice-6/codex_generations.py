

# Generated at 2022-06-25 11:06:40.102693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'z'
    lookup_module_0 = LookupModule(str_0)
    str_0 = '\x98\xf6\x1f\x14\x0f\xd8'
    str_0 = ['ghi', 'def']
    lookup_module_0.run(str_0, 'Z')


# Generated at 2022-06-25 11:06:48.850592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'l'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'q\xcb\xa8\rj\xca'
    dict_0 = {'l': str_0, 'd': bytes_0}
    str_1 = 'l'
    bool_0 = dict_0.__contains__(str_1)
    var_0 = lookup_module_0.run(dict_0)
    var_1 = lookup_module_0.run(dict_0)


# Generated at 2022-06-25 11:06:57.667067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    list_0 = []
    bytearray_0 = bytearray()
    list_1 = [list_0, bytearray_0]
    int_0 = lookup_module_run(list_1)
    int_1 = lookup_module_run(list_1)
    int_2 = lookup_module_run(list_1)
    int_3 = lookup_module_run(list_1)
    int_4 = lookup_module_run(list_1)
    int_5 = lookup_module_run(list_1)
    int_6 = lookup_module_run(list_1)
    int_7 = lookup_module_run(list_1)
    int_

# Generated at 2022-06-25 11:06:59.912648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instantiate a new instance of type LookupModule
    lookup_module_1 = LookupModule("str_2")
    # Assert that the return type of run() is list.
    assert isinstance(lookup_module_1.run(), list)

# Generated at 2022-06-25 11:07:10.953646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(LookupBase)
    x = random.choice(BasicBlock)
    lookup_module_0.run = x
    if (lookup_module_0.module_utils_args == 'None'):
        var_0 = None
    else:
        var_0 = lookup_module_0.module_utils_args
    if (lookup_module_0.module_utils_path == 'None'):
        var_1 = None
    else:
        var_1 = lookup_module_0.module_utils_path
    if (lookup_module_0.play_context == 'None'):
        var_2 = None
    else:
        var_2 = lookup_module_0.play_context

# Generated at 2022-06-25 11:07:15.080837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True


# Generated at 2022-06-25 11:07:20.025006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
    int_0 = lookup_module_0.run(bytes_0)
    assert int_0 == 0
    #assert str_0 == var_0

# Generated at 2022-06-25 11:07:26.637118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    str_1 = 'ascii_letters'
    var_1 = lookup_module_0.run(str_1)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:07:37.849848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'qEu4o4ulK'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'0'
    str_1 = 'aaaaa'
    var_0 = lookup_run(bytes_0, str_1)
    # AssertionError: <type 'str'> != <type 'str'>
    str_0 = '\x06\x05\x18'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'1'
    str_1 = '\xbb\xcc\x8f\x0eX'
    var_0 = lookup_run(bytes_0, str_1)
    # AssertionError: <type 'str'> != <type 'str'>

# Generated at 2022-06-25 11:07:44.032446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = "ascii_letters"
    lookup_module_0 = LookupModule(terms)
    ansible_module_0 = AnsibleModule(terms)
    kwargs = {kwargs_0:var_0 for kwargs_0, var_0 in ansible_module_0}

    # Act
    # Assert
    assert_raises(AnsibleError, lookup_module_0.run(terms, **kwargs))


# Generated at 2022-06-25 11:07:54.799486
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:07:55.871285
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:08:01.465975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
    var_0 = lookup_run(bytes_0)

# Generated at 2022-06-25 11:08:08.209861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # initialization
  str_0 = 'ascii_letters'
  lookup_module_0 = LookupModule(str_0)
  bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'

  # invocation
  var_0 = lookup_module_0.run(bytes_0)

  # check for valid results
  assert var_0 == '\x8f\x02\xa0\xa1\xce\x03}D\x1c\x84n\x01\x0b\x91\xcf\x18\x9a\x1d'


# Generated at 2022-06-25 11:08:10.206513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    list_0 = []
    lookup_module_0.run(list_0)


# Generated at 2022-06-25 11:08:18.493115
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  str_0 = 'ascii_letters'
  str_1 = 'X'
  lookup_module_0 = LookupModule(str_0)
  #test_string = input("Enter a string: ")
  test_string = "Hello"
  for i in test_string:
      if(i == str_1):
          print("True")
      else:
          print("False")
  bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
  #var_0 = lookup_run(bytes_0)
  

# Generated at 2022-06-25 11:08:21.796850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
    lookup_module_0.run(bytes_0)

# Generated at 2022-06-25 11:08:27.587691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(str_1)
    list_0 = [str_0]
    ret_0 = lookup_module_1.run(list_0)
    assert ret_0 == ['OiOm6UZ'], 'ret_0 = %s' % ret_0


# Generated at 2022-06-25 11:08:32.080869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'ascii_letters'
    lookup_module_1 = LookupModule(str_1)
    bytes_1 = b'p\x8d\x1a\x0e\x05\xf5\x06\x1e\x0c'
    lookup_module_1.run(bytes_1)


# Generated at 2022-06-25 11:08:38.118580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Assign argument 'data' to appropriate variable
    data = str()

    # Create the 'LookupModule' object
    instance = LookupModule(data)

    # Obtain return value of method 'run'
    ret = instance.run(data)

# Generated at 2022-06-25 11:08:49.846793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import sys

    result = None

    b_0 = b'\x16\xff\x00\x00\xfe\x01\x03\x00'

# Generated at 2022-06-25 11:08:54.357304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Sample set of parameters
    terms = ['Hello', 'World']
    lookup_module = LookupModule(terms)
    random_value = lookup_module.run(terms)
    assert random_value in terms

# Generated at 2022-06-25 11:09:03.319520
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:09:12.646629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    byte_0 = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\xff\xa4\x90\x51\x6a\xeb\x36\x0c\x7e\xd7\xdf\xc0\xde\x09\x84\x4f\x06\x61\x7a\xee\x49\x52\xd3\x7d\x2f\x7a\x1d\xe7\xee\xf6\xbd\x69\x7e\xaf\x13\x5a\x00\x00\x00\xff\xff\x00\x0e\x00\x1d\x00\x00'
    lookup_module_1 = LookupModule

# Generated at 2022-06-25 11:09:21.762923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'T'
    lookup_module_0 = LookupModule(str_0)
    str_1 = 'ascii_letters'
    lookup_module_1 = LookupModule(str_1)
    str_2 = 'g'
    lookup_module_2 = LookupModule(str_2)
    str_3 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    lookup_module_3 = LookupModule(str_3)

# Generated at 2022-06-25 11:09:24.788644
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

if __name__ == '__main__':
    test_LookupModule_run()
    print('Test Completed\n')

# Generated at 2022-06-25 11:09:31.831676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # str()
    str_0 = str()
    # [str]
    #list_0 = [str_0]
    byte_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
    lst_0 = []

    lst_0.append(byte_0)
    lst_0.append(byte_0)
    lst_0.append(byte_0)
    lst_0.append(byte_0)
    lst_0.append(byte_0)
    lst_0.append(byte_0)
    lst_0.append(byte_0)
    lst_0.append(byte_0)
    lst_0.append(byte_0)
    lst_0.append(byte_0)


# Generated at 2022-06-25 11:09:38.636268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
    var_0 = lookup_run(bytes_0)

# Generated at 2022-06-25 11:09:44.831060
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule('abc')
    var_0 = lookup_run(b'abc')


if __name__ == '__main__':
    # test_LookupModule_run()
    # test_case_0()
    pass

# Generated at 2022-06-25 11:09:58.691166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    list_0 = []
    eval_0 = eval(list_0)
    bytes_0 = b'\xb4\xc4\xd0\xa4\x90\xb44'
    bytes_1 = b'a\x9b\xc2\xe2\xa07\x1f\x0c\x0f\xa8k\x10\x7f\xbf\xa4\xcb\xc0\xfe\x1f\xe8\xfc\xa2\x9e\xcd\x91\xd1'

# Generated at 2022-06-25 11:10:06.895203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  str_0 = '4CuV%/j\x02\x7f\x96\x1c\x1e\x0f'
  lookup_module_0 = LookupModule(str_0)
  bytes_0 = b'u\xc9\x7f\x9d\x7f\xb3\x12\x06\x02\x7f\xc9\x7f\x9dL\x0c\x1e\x0f'
  var_0 = lookup_run(bytes_0)


# Generated at 2022-06-25 11:10:12.764276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
    dict_0 = {}
    dict_1 = {}
    dict_0['lookup_options'] = dict_1
    list_0 = []
    str_1 = 'ascii_letters'
    list_0.append(str_1)
    lookup_module_0.run(list_0, dict_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:10:14.357395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule()
    assert x.run(terms) == 'O'


# Generated at 2022-06-25 11:10:23.206827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupBase('ascii_letters')
    super_method_call_1 = lookup_module_0.run
    super_method_call_1.assert_called_with('ASV')
    bytes_0 = b'5\x87\x81r\xd8\xea\xfe\x1e\x06\x8eJ\xc9'
    var_0 = lookup_run(bytes_0)
    assert var_0 == 'ASV'


# Generated at 2022-06-25 11:10:28.051405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'hyphen'
    lookup_module_1 = LookupModule(str_1)
    str_2 = 'ascii_letters'
    lookup_module_2 = LookupModule(str_2)


# Generated at 2022-06-25 11:10:32.043146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule('ascii_letters')
    arg_0 = ['cat', 'dog', 'horse']
    var_0 = lookup_module_0.run(arg_0)
    assert isinstance(var_0, list)

# Generated at 2022-06-25 11:10:32.618121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True

# Generated at 2022-06-25 11:10:36.801956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run() == b'\x10\xe4\x1f\xc2\xf9\x89\xc4\xbe\xb4\x14\x0c\xe5G\x9a\x9b\x81\x01\x10\xe8'

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-25 11:10:38.536902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # @param terms
    # @param inject
    # @param kwargs
    # @return list[str].
    assert type(lookup_module_0.run()) is list

# Generated at 2022-06-25 11:10:49.219766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        str_0 = 'd'
        lookup_module_0 = LookupModule(str_0)
        str_1 = '<p>Hello World!</p>'
        list_0 = ['<p>Hello World!</p>']
        bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
        assert Eq(lookup_module_0.run(list_0, inject=bytes_0), list_0)

if __name__  ==  '__main__':
    import subprocess
    from os import path
    from tempfile import gettempdir
    path_0 = path.join(gettempdir(), 'ansible_test_random_choice_lookup_module_py.py')

# Generated at 2022-06-25 11:10:56.646904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'abcd'
    str_1 = 'abcd'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = '\x87\xef\xf5\x1d\x7fz'
    str_2 = lookup_module_0.run(bytes_0)
    assert str_1 == str_2


# Generated at 2022-06-25 11:10:59.780437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
    var_0 = lookup_module_run(bytes_0)


# Generated at 2022-06-25 11:11:03.145860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  # Test with checksum with random value
  checksum = random.getrandbits(128)
  result = lookup_module.run(checksum)
  assert result != False, "lookup_module.run() returned False"


# Generated at 2022-06-25 11:11:08.431299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
    lookup_module_0.run(bytes_0)

# Generated at 2022-06-25 11:11:16.947507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule("ascii_letters")

# Generated at 2022-06-25 11:11:19.469351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = list()
    terms.append(b'LookupModule')
    terms.append(b'LookupBase')
    lookup_module_0 = LookupModule(terms)
    ret = lookup_module_0.run(terms)
#    assert obj.run(terms) == ret



# Generated at 2022-06-25 11:11:21.302721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret_var = test_case_0()
    assert ret_var == 'wMcVSJiM'


# Generated at 2022-06-25 11:11:26.785741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
    str_1 = 'random_choice'
    dict_0 = {str_1:bytes_0}
    list_0 = [str_1]
    lookup_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 11:11:36.021858
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ascii_letters'
    lookup_module_0 = LookupModule(str_0)
    bytes_0 = b'\xd7\xddse\x85v\xb8Px/,\x0e'
    var_0 = lookup_module_0.run(bytes_0)
    assert var_0 == b'\x04\xa2\x9d\xd5\x95\xe5\x97\x11\x8d\x1a\x94\x04\x9c\xb8\xd5\x04\x1a\x95\x8d\x11\x97\xe5\x95\xd5\x9d'
    

# Generated at 2022-06-25 11:11:41.772526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params_0 = [b'u\x16U6\xdb\xf3\x1c%\x1a\xad\xa5\x89', b'\x9f\x00\xcc\x00\x1f']
    inject_0 = {}
    kwargs_0 = {}
    ret_0 = b'\x9f\x00\xcc\x00\x1f'
    ret_1 = lookup_run(params_0, inject_0, **kwargs_0)
    assert(ret_0 == ret_1)


# Generated at 2022-06-25 11:11:47.641039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True


# Generated at 2022-06-25 11:11:54.406003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    lookup_module_1 = LookupModule(None)
    lookup_module_0.run('\x1dH\x0e\t\x12\x1c', dict([]))
    lookup_method_0 = getattr(lookup_module_1, 'run')
    str_0 = '\nA\x03\x06'
    lookup_method_0(str_0, dict({}))

# Generated at 2022-06-25 11:12:02.679932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = "vmware"
    dict_0 = collections.OrderedDict(((str_0, (1, 2, 3)),))
    dict_1 = collections.OrderedDict(((u"ansible_facts", dict_0),))
    list_0 = []
    list_0.append(dict_1)
    list_0.append(dict_1)
    list_0.append(dict_1)
    list_0.append(dict_1)
    list_0.append(dict_1)
    list_0.append(dict_1)
    list_0.append(dict_1)
    list_0.append(dict_1)
    list_0.append(dict_1)
    list_0.append(dict_1)

# Generated at 2022-06-25 11:12:04.633489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    assert lookup_module_0.run() is None

# Generated at 2022-06-25 11:12:14.293002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = '1\x03\r\r'
    lookup_module_0 = LookupModule(var_0)
    str_0 = '\x7f\x0f\x7f\x1b\x7f\x1f\x7f\x0f\x7f\x1b\x7f\x1f\x7f\x0f\x7f\x1b\x7f\x1f\x7f\x0f'
    var_1 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 11:12:17.264005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    v = "laksdjf"
    r = random.choice
    if r(v):
        print(r(v))

# Generated at 2022-06-25 11:12:22.773127
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:12:26.564689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f_str_0 = '4CuV%`/j\x02\x7f\x96\x1c\x1e\x0f'
    result_0 = LookupModule(f_str_0)
    assert result_0.run() == '\x7f\x96\x1c\x1e\x0f'


# Generated at 2022-06-25 11:12:27.209920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()



# Generated at 2022-06-25 11:12:34.176886
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:12:48.185020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:12:50.357203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:12:53.430662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "Hello, world"
    inject_0 = "/usr/local/bin/test"
    with_random_choice_0 = False
    try:
        var_0 = lookup_module_0.run(terms_0, inject_0, with_random_choice_0)
        assert (not (var_0))
    except Exception:
        raise


# Generated at 2022-06-25 11:12:54.488897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:12:55.518085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = to_native(lookup_module_1.run())
    assert var_1 is None


# Generated at 2022-06-25 11:12:59.007251
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [u'red', u'green', u'blue']
    var_0 = lookup_module_0.run(var_0)
    #assert var_0 in [u'red', u'green', u'blue']

# Test case for LookupModule with no argument

# Generated at 2022-06-25 11:13:01.655706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

    assert len(var_0) == 1
    assert var_0[0] in list_0


# Generated at 2022-06-25 11:13:02.955721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(None, None, to_native=None)


# Generated at 2022-06-25 11:13:07.434248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupModule()
    var_1 = run(var_0)


# Generated at 2022-06-25 11:13:13.754653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert 'no' in var_0, 'Unable to run testcase'
    assert 'undefined' in var_0, 'Unable to run testcase'
    assert 'E' in var_0, 'Unable to run testcase'
    assert 'w' in var_0, 'Unable to run testcase'
    assert 'f' in var_0, 'Unable to run testcase'
    assert 'g' in var_0, 'Unable to run testcase'
    assert '8' in var_0, 'Unable to run testcase'
    assert '$.exec' in var_0, 'Unable to run testcase'

# Generated at 2022-06-25 11:13:41.110347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # TODO: Write test
  pass

# Generated at 2022-06-25 11:13:43.713936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError) as execinfo:
        term_0 = list(range(0, 10))
        lookup_module_0 = LookupModule()
        lookup_module_0.run(terms=term_0)


# Generated at 2022-06-25 11:13:44.546552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:13:49.144488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)
    assert len(var) == 1
    assert var[0] in ["go through the door", "drink from the goblet", "press the red button", "do nothing"]

# Generated at 2022-06-25 11:13:52.955849
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert return_list([random_choice_choice(["a", "b", "c"])]) == lookup_module_0.run(["a", "b", "c"])

# Generated at 2022-06-25 11:13:55.582367
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ["do nothing"]

# Generated at 2022-06-25 11:13:58.138449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:14:01.100475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    var_0 = lookup_run(lookup_module_0, terms_0)



# Generated at 2022-06-25 11:14:02.921536
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)



# Generated at 2022-06-25 11:14:04.498852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["foo"],None)
    assert "foo" in var_0

# Generated at 2022-06-25 11:14:51.512899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["AC1", "AC2", "AC3"])
    assert re.search(r'.+', var_0)


# Generated at 2022-06-25 11:14:55.402035
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    inject = None
    kwargs = {'validate': None}
    var_0 = lookup_module_0.run(terms, inject, **kwargs)
    assert len(var_0) == 0


# Generated at 2022-06-25 11:15:00.167158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    # test
    assert lookup_module_0.run() == None
    assert lookup_module_0.run() == None
    assert lookup_module_0.run() == None
    assert lookup_module_0.run() == None
    assert lookup_module_0.run() == None
    assert lookup_module_0.run() == None
    assert lookup_module_0.run() == None
    assert lookup_module_0.run() == None
    assert lookup_module_0.run() == None
    assert lookup_module_0.run() == None


# Generated at 2022-06-25 11:15:02.546599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = [ u'blue', u'green' ]
    lookup_module_1 = LookupModule()
    var_2 = lookup_module_1.run(var_1)
    assert var_2 == [ u'blue' ] or var_2 == [ u'green' ]


# Generated at 2022-06-25 11:15:04.684006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    var_1 = lookup_module_0.run(terms)

    assert var_1 == []


# Generated at 2022-06-25 11:15:12.357868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([])
    assert len(var_0) == 0
    var_0 = lookup_module_0.run([
        'a',
        'b',
        'c',
        'd'])
    assert len(var_0) == 1

# Generated at 2022-06-25 11:15:15.915951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["a", "b", "c"])
    str_0 = str(var_0)
    str_1 = "a"
    str_2 = "b"
    str_3 = "c"


# Generated at 2022-06-25 11:15:20.923468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = lookup_run(lookup_module_0)
    var_2 = lookup_run(lookup_module_0)
    var_3 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:15:22.204419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:15:27.166276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [u'a', u'b', u'c', u'd', u'e', u'f', u'g', u'h', u'i', u'j', u'k', u'l', u'm', u'n', u'o', u'p', u'q', u'r', u's', u't', u'u', u'v', u'w', u'x', u'y', u'z']
    var_2 = lookup_module_0.run(var_1)