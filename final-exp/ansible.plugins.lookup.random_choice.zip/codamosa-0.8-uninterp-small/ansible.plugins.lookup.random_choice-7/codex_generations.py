

# Generated at 2022-06-25 11:06:40.044273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = random.choice([])
    var_1 = 'AnsibleError'
    # check raise AnsibleError error
    # assertRaises(AnsibleError, lookup_module_0.run, var_0)
    # check type of return value
    assert type(var_0) == list, 'return value is not of type list'


# Generated at 2022-06-25 11:06:41.239948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:06:45.734547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, ['a', 'b', 'c'])


# Generated at 2022-06-25 11:06:52.731100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = ['c', 'a', 'b']
    var_2 = lookup_run(lookup_module_1, var_1)
    assert (var_2 == ['c'] or var_2 == ['a'] or var_2 == ['b'])


# Generated at 2022-06-25 11:06:58.138439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run()



# Generated at 2022-06-25 11:07:04.785242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = [u'foo', u'bar', u'baz']
    var_2 = lookup_run(lookup_module_1, var_1)
    assert var_2 == [u'foo']

# Generated at 2022-06-25 11:07:13.192713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms=['a', 'b', 'c'])
    assert len(var_1) == 1
    assert var_1[0] in ('a', 'b', 'c')


# Generated at 2022-06-25 11:07:20.299469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [u"gotcha", u"goto", u"goto-nonnull", u"if", u"if-goto", u"label", u"pop", u"push", u"return", u"function", u"call"]
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == "goto-nonnull", "Incorrect return value from LookupModule.run"

# Generated at 2022-06-25 11:07:24.611867
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, inject, **kwargs)


# Generated at 2022-06-25 11:07:27.947044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Check function returns the correct result
  assert len(var_0) == 1
  assert var_0[0] in ["go through the door", "drink from the goblet", "press the red button", "do nothing"]

# Generated at 2022-06-25 11:07:32.818363
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(None, None, None)
        try:
            lookup_module_0.run(None, None, None)
        except:
            pass
    except:
        pass

# Generated at 2022-06-25 11:07:39.254841
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:07:44.823998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ["a","b","c"]
    var_1 = lookup_module_0.run(var_0)
    assert(len(var_0) > len(var_1))
    assert(var_1 in var_0)

# Verify that the lookup module functions properly with a dict of values

# Generated at 2022-06-25 11:07:49.182766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms, inject)
    assert type(ret) == list
    assert ret == ["go through the door"]
    assert len(ret) == 1

# Generated at 2022-06-25 11:07:53.250249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [u'go through the door', u'drink from the goblet', u'press the red button', u'do nothing']
    lookup_module_0.run(var_1)

# Generated at 2022-06-25 11:07:58.000705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a lookup plugin instance
    lookup_0 = LookupModule()
    # items to be used in tests
    test_items_0 = None
    test_items_1 = []
    # call method
    result_0 = lookup_0.run(test_items_0)
    result_1 = lookup_0.run(test_items_1)

if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 11:08:00.040624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    result = lookup_module_2.run(terms)
    assert result == expected


# Generated at 2022-06-25 11:08:04.220513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = ['b']
    var_2 = var_0 == var_1
    if var_2:
        print("PYTHON EXECUTED SUCCESSFULLY")
    else:
        print("PYTHON EXECUTED FAILED")

# Generated at 2022-06-25 11:08:06.478473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = [1, 2, 3]
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    assert var_1 == [random.choice(term)]


# Generated at 2022-06-25 11:08:08.122747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) is None, "lookup_module_0.run([]) is None"


# Generated at 2022-06-25 11:08:15.900877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_main_class_3 = LookupModule()
    var_2 = ['a', 'b', 'c']
    var_3 = None
    var_5 = lookup_module_main_class_3.run(var_2, var_3)

# Generated at 2022-06-25 11:08:20.792117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=1, inject=2, kwargs=3)
    assert var_0 is None

# Generated at 2022-06-25 11:08:25.586751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([1, 2, 3])
    assert var_0 == 2

# Generated at 2022-06-25 11:08:26.922730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:08:27.950127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True # TODO: implement your test here


# Generated at 2022-06-25 11:08:29.823902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run('test', {})
    assert var_1 == 'test'


# Generated at 2022-06-25 11:08:31.997782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [u'sun', u'rain', u'snow']
    var_2 = lookup_module_0.run(var_1)


# Generated at 2022-06-25 11:08:42.317230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = list()
    var_1.append('People who live in glass houses should not throw stones.')
    var_1.append('The early bird catches the worm.')
    var_1.append('Slow and steady wins the race.')
    var_1.append('Good things come to those who wait.')
    var_1.append('The squeaky wheel gets the oil.')
    var_2 = lookup_module_0.run(var_1,)
    for item_ in var_2:
        assert type(item_) is str, "The item_ generated is not of type 'str'"
        assert len(item_) > 0, "The item_ generated is empty string"


# Generated at 2022-06-25 11:08:46.540294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import __main__ as test_module
    temp = test_module.__loader__.get_source("/home/travis/.ansible/plugins/lookup/random_choice")
    print(temp)

    lookup_module_0 = LookupModule()

    var_0 = lookup_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 11:08:49.781187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run(terms=[], inject=None, **{})

# Generated at 2022-06-25 11:09:04.341689
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run(terms=["go through the door", "drink from the goblet", "press the red button", "do nothing"], inject=None, **{"**kwargs": None})
    assert len(var) == 1
    assert var[0] in ["go through the door", "drink from the goblet", "press the red button", "do nothing"]


# Generated at 2022-06-25 11:09:05.650716
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:09:09.489657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)
    assert var == "exception", "1st run should have failed"
    var = lookup_run(lookup_module)
    assert var == "exception", "2nd run should have failed"

# Generated at 2022-06-25 11:09:10.511678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(['a', 'b', 'c'], {})

# Generated at 2022-06-25 11:09:11.312093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()

# Generated at 2022-06-25 11:09:13.901682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert var_0 == [], "Expected return value is [], got {}".format(var_0)


# Generated at 2022-06-25 11:09:17.004344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, inject, **kwargs)
    return var_0

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:09:19.805077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["item_1", "item_2", "item_3"]
    ret = lookup_module.run(terms=terms)
    assert isinstance(ret, list)
    assert ret[0] in terms

# Generated at 2022-06-25 11:09:24.642072
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['foo', 'bar']
    result = lookup_module_0.run(terms_0)
    assert 'foo' in result or 'bar' in result


# Generated at 2022-06-25 11:09:29.066285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 'method' in test_case_0.__code__.co_varnames
    assert 'self' in test_case_0.__code__.co_varnames
    assert 'terms' in test_case_0.__code__.co_varnames
    assert 'inject' in test_case_0.__code__.co_varnames
    assert 'kwargs' in test_case_0.__code__.co_varnames

# Generated at 2022-06-25 11:09:50.990028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance_1 = LookupModule()
    lookup_instance_1.run()


# Generated at 2022-06-25 11:09:53.399250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert isinstance(var_0, list)


# Generated at 2022-06-25 11:10:01.446453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]

    # CA-29594
    # Lookup may return a single element even when a list is passed in.
    # This is always the case with random_choice. Hence, "in" is used rather than "=="
    var_1 = lookup_module_0.run(var_0)
    assert var_1[0] in var_0

    # CA-29594
    # The first element is a string. Hence, "in" is used rather than "=="
    var_2 = lookup_run(lookup_module_0)
    assert var_2[0] in var_0

# Generated at 2022-06-25 11:10:03.302173
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:10:06.819243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [None]
    var_1 = {x: x for x in range(10)}
    results_0 = lookup_module_0.run(var_0, inject=var_1)
    assert results_0 == var_0

# Generated at 2022-06-25 11:10:09.443081
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([u'foo', u'bar', u'baz'])
    assert var_0 == [u'foo', u'bar', u'baz']

# Generated at 2022-06-25 11:10:14.369093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == var_0


# Generated at 2022-06-25 11:10:15.342242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 11:10:18.085832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    var_0 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:10:23.627905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    words = ["spam","eggs","bacon","toast","coffee"]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(words)
    assert len(var_0) == 1
    assert var_0[0] in words

# Generated at 2022-06-25 11:11:08.123416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(var_1)
    assert var_0 in var_1

# Generated at 2022-06-25 11:11:10.542959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var = [u'go through the door']
    lookup_module_0.run(var)
    

# Generated at 2022-06-25 11:11:17.409324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    var_0 = ['a']
    var_1 = lookup_module_0.run(var_0)

    assert var_1 == ['a']
    var_2 = lookup_module_0.run(var_0)

    assert var_2 == ['a']
    var_3 = lookup_module_0.run(var_0)

    assert var_3 == ['a']
    var_4 = lookup_module_0.run(var_0)

    assert var_4 == ['a']
    var_5 = lookup_module_0.run(var_0)

    assert var_5 == ['a']



# Generated at 2022-06-25 11:11:29.057933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [["first", "second", "third"], "first"]
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == var_0[1]
    var_0 = [["first", "second", "third"], "first", "second"]
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == var_0[1] or var_1 == var_0[2]
    var_0 = [["first", "second", "third"], "first", "second", "third"]
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == var_0[1] or var_1 == var_0[2] or var_1 == var_

# Generated at 2022-06-25 11:11:31.621831
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['string'])

    assert len(var_0) == 1
    assert var_0[0] == 'string'

# Generated at 2022-06-25 11:11:36.458974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_t_0 = ["foo", "bar", "baz"]
    ret_0 = lookup_module_0.run(list_t_0)
    assert ret_0 == ["foo"] or ret_0 == ["bar"] or ret_0 == ["baz"]


# Generated at 2022-06-25 11:11:39.331034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_fallback = ['a']
    var_0 = lookup_module_0.run(lookup_fallback)
    assert var_0 == ['a']


# Generated at 2022-06-25 11:11:44.335460
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of class LookupModule()
    lookup_module_run = LookupModule()

    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Run the method run of class LookupModule on terms
    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Run the method run of class LookupModule on terms
    # Create an instance of class AnsibleError
    ansible_error = AnsibleError()

    # Run the method run of class LookupModule on terms
    var_run = lookup_run(lookup_module_run)

# Generated at 2022-06-25 11:11:54.255703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    var_1 = lookup_module_0.run(var_0)
    assert var_1 == ["drink from the goblet"]
    assert [var_1] == ["drink from the goblet"]
    assert var_1[0] == "drink from the goblet"
    assert type(var_1[0]) == str
    assert [var_1[0]] == ["drink from the goblet"]
    assert type(var_1[0]) == str
    assert [var_1[0]] == ["drink from the goblet"]
    assert type(var_1[0]) == str

# Generated at 2022-06-25 11:12:00.008844
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    var_1 = [1, 2, 4, 5]
    var_2 = [5, 4, 1, 2]
    var_3 = [2, 5, 4, 3]

    lookup_module = LookupModule()

    assert lookup_module.run([1, 2, 3, 4], []) == [1, 2, 3, 4]
    assert lookup_module.run(var_1) in var_1
    assert lookup_module.run(var_2) in var_2
    assert lookup_module.run(var_3) in var_3


# Generated at 2022-06-25 11:13:28.368058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run == lookup_module_0.run


# Generated at 2022-06-25 11:13:31.179448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Arrange
  lookup_module = LookupModule()
  terms = [1, 2, 3, 4, 5]

  # Act
  ret = lookup_module.run(terms)

  # Assert
  assert ret in terms

# Generated at 2022-06-25 11:13:32.533723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)

# Test cases for example test

# Generated at 2022-06-25 11:13:34.843537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = ['foo', 'bar']
    ret_1 = lookup_module_1.run(terms_1)
    assert len(ret_1) == 1
    assert ret_1[0] in terms_1

# Generated at 2022-06-25 11:13:35.756169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)
    assert True



# Generated at 2022-06-25 11:13:42.376837
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = 'honk honk'
    var_0 = lookup_module_1.run(terms_0, None, )
    assert var_0 == 'honk honk'

# Generated at 2022-06-25 11:13:47.840079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([('red',), ('orange',), ('yellow',), ('green',), ('blue',), ('indigo',), ('violet',)])
    assert var_0 == ['red'], 'Unit test for "run" method of class "LookupModule" return %s' % var_0


# Generated at 2022-06-25 11:13:49.964994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert(len(var_0) == 1)

# Generated at 2022-06-25 11:13:53.986524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('')


if __name__ == '__main__':

    print(test_case_0())
    print(test_LookupModule_run())

# Generated at 2022-06-25 11:14:01.151602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['d', 'd', 'd', 'd']
    var_0 = lookup_module_0.run(terms_0)
    assert var_0 == ['d']
    
    
    
