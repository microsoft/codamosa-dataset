

# Generated at 2022-06-25 11:06:40.222204
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Source: https://stackoverflow.com/questions/306400/how-to-randomly-select-an-item-from-a-list
    import random

    foo = ['a', 'b', 'c', 'd', 'e']
    print(random.choice(foo))

    # If you want to be sure to choose from a shuffled sequence:
    random.shuffle(foo)
    print(random.choice(foo))


# Generated at 2022-06-25 11:06:46.654928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'terms'
    dict_0 = {str_0: str_0}
    lookup_module_0 = LookupModule(**dict_0)
    list_0 = ['terms']
    dict_1 = {'terms': list_0}
    lookup_module_0.run(**dict_1)


# Generated at 2022-06-25 11:06:47.403327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:06:50.283781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'f'
    dict_0 = {str_0: str_0}
    list_0 = [str_0, str_0]
    lookup_module_0.run(list_0, **dict_0)

# Generated at 2022-06-25 11:06:54.317386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [1,2,3]
    ansible_lookup_plugin = lookup_module_0.run(terms)
    assert ansible_lookup_plugin == [1] or \
           ansible_lookup_plugin == [2] or \
           ansible_lookup_plugin == [3]

# Generated at 2022-06-25 11:06:57.774269
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ["double - tap"]
    inject = {"ansible_check_mode": True}

    lookup_module_0 = LookupModule(**inject)
    assert lookup_module_0.run(terms, inject) == ["double - tap"]


# Generated at 2022-06-25 11:07:02.137073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['**kwargs'] = dict()
    dict_0['inject'] = dict()
    dict_0['terms'] = [str()]
    lookup_module_0 = LookupModule(**dict_0)
    o = lookup_module_0.run(**dict_0)
    assert o is None
    try:
        dict_0['terms'] = list()
        dict_0['terms'].append(str())
        dict_0['terms'].append(str())
        o = lookup_module_0.run(**dict_0)
        assert o is not None
    except Exception as e:
        print(e)

# Generated at 2022-06-25 11:07:07.166040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["A", "B", "C"]
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms)

    assert "A" in result or "B" in result or "C" in result


# Generated at 2022-06-25 11:07:10.966257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    list_0 = [set(), set()]
    lookup_module_0 = LookupModule()
    list_1 = [frozenset()]
    assert lookup_module_0.run(list_0) == list_1

# Generated at 2022-06-25 11:07:21.789578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    from ansible.errors import AnsibleError

    term_0 = ['m']
    inject_0 = None
    kwargs_0 = dict()
    dict_0 = dict()

    try:
        lookup_module_0 = LookupModule(**dict_0)
        random_choice_0 = lookup_module_0.run(term_0, inject_0, **kwargs_0)
        assert(random_choice_0 == term_0)
    except AnsibleError as ansible_error_0:
        str_0 = 'Unable to choose random term: '
        str_0 = str_0 + str(ansible_error_0)
        assert(str_0 != None)

# Generated at 2022-06-25 11:07:30.771139
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    lookup_module_0.run(['F4MB', 'ZW2^', '6*b9'])
    lookup_module_0.run(['0B_l', '#8EL', 'Vzv&'])
    lookup_module_0.run(['_0v0', '\x2d\x13', 'sVzv'])

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:07:34.221274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)

    # Test if default values are set properly in __init__
    assert lookup_module_0._templar == None, "Default value of _templar is incorrect"

    # Test if the exceptions thrown are expected
    try:
        lookup_module_0.run()
    except Exception as e:
        assert isinstance(e, AttributeError)



# Generated at 2022-06-25 11:07:35.803241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(**{'run': {}})
    assert lookup_module_0.run == {}

# Generated at 2022-06-25 11:07:37.274726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run(None, None)
    except:
        pass

# Generated at 2022-06-25 11:07:42.716869
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = '/'
    dict_1 = {str_1: str_1}
    lookup_module_2 = LookupModule(**dict_1)
    list_0 = ['e', '`']

    str_0 = lookup_module_2.run(list_0)

    # assertion: str_0 is the most similar to 'e'
    assert str_0 == 'e'


# Generated at 2022-06-25 11:07:50.145593
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Input params
    terms = ''; inject = 'G'; kwargs = {}

    lookup_module_1 = LookupModule()

    # Invoke method
    result = lookup_module_1.run(terms, inject, **kwargs)
    assert (result == [])

    # Input params
    terms = ''; inject = ''; kwargs = {}

    # Invoke method
    result = lookup_module_1.run(terms, inject, **kwargs)
    assert (result == [])

# Generated at 2022-06-25 11:07:54.638979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'X'
    dict_0 = {str_0: str_0}
    lookup_module_0 = LookupModule(**dict_0)
    str_1 = '+'
    list_0 = [str_1]
    list_1 = lookup_module_0.run(list_0)

    assert list_1[0] == '+'

# Generated at 2022-06-25 11:07:59.955520
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Now set up a different context for testing
    random.seed(5)
    assert LookupModule().run(['a','b','c','d','e'], inject=None) == ['c']
    random.seed(5)
    assert LookupModule().run(['a','b','c','d','e'], inject=None) == ['c']
    random.seed(5)
    assert LookupModule().run(['a','b','c','d','e'], inject=None) == ['c']

# Generated at 2022-06-25 11:08:03.709532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lookup_module_0 = LookupModule(**dict_0)

    # Test the return type of method run
    assert isinstance(lookup_module_0.run([1]), list)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:08:04.975208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:08:16.443911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    argument_0 = ['', 'A']
    argument_1 = None
    argument_2 = {}
    return_value_0 = lookup_module_0.run(argument_0, argument_1, argument_2)
    assert len(return_value_0) == 1 and return_value_0[0] in argument_0

# Generated at 2022-06-25 11:08:18.383385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run(None, None)
    lookup_module_0.run(['5', 'm', '5', 'mJj'], None)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:08:20.417976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    terms = ['abc', 'def', 'ghi']
    ret = obj.run(terms)
    assert ret in terms


# Generated at 2022-06-25 11:08:24.593804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(None, None)


# Generated at 2022-06-25 11:08:29.546225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    str_0 = '^9y4@4/a\x06'
    str_1 = '!\x0c\x1c.q\x03\x06\x16\x15\x05\x16\x0e'
    list_1 = [str_0, str_1]
    tuple_1 = (list_1, )
    lookup_module_0.run(tuple_1, **dict_0)


# Generated at 2022-06-25 11:08:31.720818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:08:35.089774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #random.choice
    
    #random.choice

    str_0 = 'K'
    str_1 = 'x'
    list_0 = [str_0, str_1]
    list_1 = []
    int_0 = 0
    lookup_module_0 = LookupModule()
    lookup_module_0.run(list_0, list_1, int_0)

# Generated at 2022-06-25 11:08:42.427912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '`'
    list_0 = [str_0]
    dict_0 = {str_0: str_0}
    str_1 = 'a'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(**dict_0)
    result = lookup_module_0.run(list_0, **dict_1)
    assert result == list_0
    assert list_0 == list_0
    assert dict_0 == dict_0
    assert list_0 == list_0


# Generated at 2022-06-25 11:08:44.429494
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = '6'
    list_0 = []
    dict_0 = {str_1: list_0}
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run(dict_0, dict_0)

# Generated at 2022-06-25 11:08:47.067961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '&'
    str_1 = 'I'
    str_2 = '7'
    list_0 = ['5', str_2, str_0, str_2, str_1, str_0]
    str_3 = ':'
    bool_0 = False
    dict_0 = {str_1: bool_0, str_3: bool_0}
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run(list_0, inject=None)


# Generated at 2022-06-25 11:09:00.411142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = random.choice([])
    str_1 = random.choice(str_0)
    str_2 = random.uniform(0.0, 1.0)
    str_3 = random.randint(1, 6)
    str_4 = random.randrange(10)
    str_5 = random.gauss(1.0, 2.0)
    ret = lookup_run(lookup_module_0, lookup_module_0)
    # AssertionError: assertion failed:
    # Expected: <class 'ansible.errors.AnsibleError'>
    # Actual  : <class 'list'>
    assert isinstance(ret, ansible.errors.AnsibleError)
    # AssertionError: assertion failed:
    # Expected:

# Generated at 2022-06-25 11:09:03.537203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'go through the door', u'press the red button', u'drink from the goblet', u'do nothing']
    kwargs_0 = {
        u'inject': u'{}',
    }
    lookup_module_0.run(terms_0, **kwargs_0)

# Generated at 2022-06-25 11:09:08.199463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [list(), '0', '1']
    lookup_module_0 = LookupModule()
    var_1 = lookup_run(lookup_module_0, lookup_module_0, var_0)
    assert (var_1 == [var_0[2]])


# Generated at 2022-06-25 11:09:09.677206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["test_string_0", "test_string_1"])


# Generated at 2022-06-25 11:09:14.536640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule, "run", None))


# Generated at 2022-06-25 11:09:16.632598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    results = lookup_module_1.run(None)
    assert results == list


# Generated at 2022-06-25 11:09:23.584751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_self = MagicMock(spec=LookupModule)
    mock_terms = MagicMock(spec=list)
    mock__raw = MagicMock(spec=list)
    mock_inject = MagicMock(spec=dict)
    mock_kwargs = MagicMock(spec=dict)
    type(mock__raw)._raw = PropertyMock(return_value=mock__raw)

    # set up the mock
    mock__raw.choice.side_effect = [list]

    # invoke the behavior
    result = run(mock_self, mock_terms, inject=mock_inject, **mock_kwargs)

    # check the result
    # first check the calls to method choice
    assert mock__raw.choice.call_count == 1
    # next check the call to method __getitem__

# Generated at 2022-06-25 11:09:25.882049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # @todo check chosen item type
    lookup_module = LookupModule()
    var = lookup_module.run(Terms(Term([]))) # @todo [] should return empty list
    assert type(var) is list

# Generated at 2022-06-25 11:09:27.308325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, inject, **kwargs)

# Generated at 2022-06-25 11:09:30.622392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = lookup_module_0.run(var_0)
    assert len(var_1) == 0
    assert var_1[0] is var_0
    assert len(var_1) == 0
    assert var_1[0] is var_0
    assert len(var_1) == 0
    assert var_1[0] is var_0

# Generated at 2022-06-25 11:09:44.871435
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run()
    except AnsibleLookupError as err:
        assert err == AnsibleLookupError


# Generated at 2022-06-25 11:09:46.005657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:09:49.938634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == []
    

# Generated at 2022-06-25 11:09:54.186377
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = ["one", "two", "three"]
    var_2 = lookup_run(lookup_module_0, lookup_module_0, terms=var_1)
    assert len(var_2) == 1
    assert var_2[0] in var_1


# Generated at 2022-06-25 11:09:59.027915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [1, 2, 3]
    var_2 = lookup_module_0.run(var_1)

    assert(len(var_2) <= 1)
    assert(var_2[0] in var_1)


# Generated at 2022-06-25 11:10:02.099228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_args = dict()
    lookup_args['terms'] = test_terms
    lookup_args['inject'] = test_inject
    assert var_0 == lookup_run(lookup_module_0, lookup_args)

# Generated at 2022-06-25 11:10:10.189384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict()
    args['terms'] = dict()
    args['inject'] = ''

    # Testing with empty value for args['terms']
    # Expected result: the function should return an empty list
    value_0 = dict()
    value_0['terms'] = None
    value_0['inject'] = ''
    args['terms'] = value_0['terms']
    args['inject'] = value_0['inject']
    assert lookup_module.run({}) == value_0['terms']

    # Testing with default value for args['terms']
    # Expected result: the function should return an empty list
    value_1 = dict()
    value_1['terms'] = []
    value_1['inject'] = ''
    args['terms'] = value_1['terms']

# Generated at 2022-06-25 11:10:12.724569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  raise NotImplementedError()

# Generated at 2022-06-25 11:10:14.622370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(lookup_module_0)

# Generated at 2022-06-25 11:10:21.013654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    list_1 = lookup_run(lookup_module_0, lookup_module_0, list_0)
    output = None
    assert output in list_1


# Generated at 2022-06-25 11:10:46.916114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [1, 2, 3, 4, 5]
    var_0 = lookup_module_0.run(terms_0)

    assert var_0 in [1, 2, 3, 4, 5]


# Generated at 2022-06-25 11:10:52.396989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = lookup_run(lookup_module_0, lookup_module_0)
  return



# Generated at 2022-06-25 11:10:56.401503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    assert var_0 == None, "Method run of class LookupModule did not return expected value."

# Generated at 2022-06-25 11:11:02.131271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = False
    var_2 = False
    var_3 = False
    var_4 = False
    var_5 = False
    var_6 = False
    var_7 = False
    terms_1 = [var_1]
    inject_1 = var_2
    kwargs_1 = {'lookup_module': var_3, 'lookup_module_0': var_4, 'terms_1': terms_1, 'inject_1': inject_1, 'ret': var_5, 'e': var_6, 'native_e': var_7}
    lookup_module_1 = LookupModule()
    reference_1 = lookup_module_1.run(terms_1, inject_1, **kwargs_1)

# Generated at 2022-06-25 11:11:08.385555
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Example of test case

    lookup_module_0 = LookupModule()


    var_0 = [{"dest": "../scripts/foo", "src": "bar", "repo": "ansible/ansible", "version": "devel"}]

    var_1 = lookup_run(lookup_module_0, var_0)
    # Check result
    assert var_1 == var_0

# Generated at 2022-06-25 11:11:16.917426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # random_choice
    # Unit: random_choice

    # Tests:
    # (1) No input
    # (2) One item in list
    # (3) Ten items in list

    # (1) No input
    test_cases = {"inject": {"ansible_random_choice": {}}, "terms": []}

    if test_cases["terms"]:
        test_cases["inject"]["ansible_random_choice"]["terms"] = test_cases["terms"]
        lookup_module_1 = LookupModule()
        var_1 = lookup_run(lookup_module_1, lookup_module_1)

    # (2) One item in list
    test_cases = {"inject": {"ansible_random_choice": {}}, "terms": ["one"]}


# Generated at 2022-06-25 11:11:18.383584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 11:11:19.811091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1, lookup_module_1)
    assert len(var_1) == 1

# Generated at 2022-06-25 11:11:21.735848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 11:11:22.446937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0()


# Generated at 2022-06-25 11:12:10.473023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1, lookup_module_1)
    assert var_1 is not None
    assert var_1 == ["do nothing"]

# Generated at 2022-06-25 11:12:21.106873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:12:30.915919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("testing LookupModule.run()")

    lookup_module_0 = LookupModule()

    # test with good options
    print("testing with good options")
    var_0 = lookup_module_0.run(None, None)
    assert var_0 is None, "random_choice: var_0 should be None"
    assert var_0 is None, "random_choice: var_0 should be None"

    # test with bad options
    print("testing with bad options")
    var_0 = lookup_module_0.run(None, None)
    assert var_0 is None, "random_choice: var_0 should be None"
    assert var_0 is None, "random_choice: var_0 should be None"

# Generated at 2022-06-25 11:12:32.227935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['a'])


# Generated at 2022-06-25 11:12:34.278448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_5 = LookupModule()
    var_5 = lookup_module_5.run(["foo"], None, None)
    assert var_5 == ["foo"]



# Generated at 2022-06-25 11:12:38.312074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [u' go through the door', u' drink from the goblet', u' press the red button', u' do nothing']
    var_1 = lookup_run(lookup_module_0, lookup_module_0, var_0)


# Generated at 2022-06-25 11:12:42.808323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, terms, inject, **kwargs)


# Generated at 2022-06-25 11:12:48.045726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(lookup_plugin=None, terms=[])
    assert_equal(var_0, [], "list index out of range")


# Generated at 2022-06-25 11:12:51.054874
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    var_12 = test_case_0()

    assert isinstance(var_12, list)
    assert var_12 == [10]



# Generated at 2022-06-25 11:12:55.810663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 11:14:39.077084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = math.random
    kwargs_0 = [terms_0]
    lookup_modulen_0 = lookup_module_0.run(*kwargs_0)

# Generated at 2022-06-25 11:14:49.391160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = {}
    t['a'] = "apple"
    t['b'] = "banana"
    t['c'] = "citrus"
    l1 = ["apple", "banana", "citrus"]
    l2 = ["apple", "citrus", "banana"]
    l3 = ["banana", "apple", "citrus"]
    l4 = ["banana", "citrus", "apple"]
    l5 = ["citrus", "apple", "banana"]
    l6 = ["citrus", "banana", "apple"]
    assert t[lookup_module_0.run(l1)[0]] == "apple"
    assert t[lookup_module_0.run(l2)[0]] == "apple"

# Generated at 2022-06-25 11:14:52.470053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = ["list element"]
    var_2 = lookup_run(lookup_module_1, lookup_module_1, terms_0, inject=None)


# Code for utility method lookup_run, to help debuging for method LookupModule.run

# Generated at 2022-06-25 11:15:01.784013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_5 = [('go through the door', 'drink from the goblet', 'press the red button', 'do nothing')]
    var_7 = lookup_module_1.run(var_5, inject=None)
    print('test_LookupModule_run')
    var_4 = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    var_6 = lookup_run(var_4)
    print(var_6)

# Generated at 2022-06-25 11:15:05.440276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  trms = ['a', 'b', 'c']
  lookup_module_1 = LookupModule()
  var_1 = lookup_run(lookup_module_1, lookup_module_1)
  assert var_1 == trms[0]


# Generated at 2022-06-25 11:15:09.098320
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(None, None, None)

# Generated at 2022-06-25 11:15:12.083101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 11:15:17.039972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["hi"], inject=None, **{'_terms': ["hi"]})

# Generated at 2022-06-25 11:15:21.337372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms = "dummy_terms", inject = "dummy_inject", kwargs = "dummy_kwargs")


# # Unit test for method random_choice of class LookupModule

# Generated at 2022-06-25 11:15:23.204019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, lookup_module_0)
    assert var_0 == 'foo'