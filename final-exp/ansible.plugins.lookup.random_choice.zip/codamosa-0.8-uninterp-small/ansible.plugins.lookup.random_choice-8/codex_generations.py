

# Generated at 2022-06-25 11:06:38.235166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_2 = "ha'ha"
    str_1 = 'C'
    lookup_module_0 = LookupModule(str_2, str_1)


# Generated at 2022-06-25 11:06:45.653633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1121.0

# Generated at 2022-06-25 11:06:56.566444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    :param terms:
    :param inject:
    :param kwargs:
    :return: ret
    '''

# Generated at 2022-06-25 11:07:00.969138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 375.0
    lookup_module_0 = LookupModule(float_0, str_0)
    str_0 = '<n\x1d\x07\x05\x1e9m\x16\x1d\x1e'
    var_0 = '*\x1d'
    var_1 = lookup_module_0.run(var_0, inject=None, **kwargs)
    assert var_1 == '*\x1d'


# Generated at 2022-06-25 11:07:09.537827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_from_factory = LookupBase.lookup_plugin_class('random_choice')
    lookup_module = lookup_module_from_factory()
    assert(isinstance(lookup_module, LookupModule))
    # this should return a list with a single item in it
    result = lookup_module.run(terms=['a', 'b', 'c'])
    assert(isinstance(result, list))
    assert(len(result) == 1)
    terms_set = set(['a', 'b', 'c'])
    assert(result[0] in terms_set)

# Generated at 2022-06-25 11:07:10.434229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 11:07:13.135528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    in_0 = '|'
    in_1 = None
    lookup_instance = LookupModule(in_0, in_1)
    in_2 = {'|': 'o'}
    out_3 = lookup_instance.run()
    assert out_3 == 'o'

# Generated at 2022-06-25 11:07:16.257757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_0 = []
    assert(test_0 == lookup_module_0.run(test_0))


# Generated at 2022-06-25 11:07:23.497233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1225.0
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_0 = LookupModule(float_0, str_0)
    str_1 = '<!wZ65i\x16\x1d\x18U6\x0cG'
    str_2 = '\x1f\\3\x06\x1e!K\x08\x01\x13\x07\x0e\x0eB\x1f\x1e\x1dg\x18'
    str_3 = '\x07\x1e\x1aL\x0e\x07\x1e\x1d\x1d\x1f'

# Generated at 2022-06-25 11:07:28.564519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\x0b5IOnS;qLt'
    str_1 = '\x0b5IOnS;qLt'
    float_0 = 1225.0
    ret_val_0 = lookup_module_0.run(terms, inject=None)
    assert ret_val_0 == [None]


# Generated at 2022-06-25 11:07:34.644553
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 919.0
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_0 = LookupModule(float_0, str_0)



# Generated at 2022-06-25 11:07:39.374792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 748.0
    float_1 = 1.0
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_0 = LookupModule(float_0, str_0)
    float_1 = lookup_module_0.run(float_1)
    print(float_1)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:07:50.559866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = 'KnK\x7fPZg(L4\x1dXA\x7f'
    int_1 = 146
    lookup_module_0 = LookupModule(str_1, int_1)
    str_1 = '\n3qf"\x27\x7fR@\x06n=6\x17"\x1b'
    int_1 = 147
    str_2 = '\x0b\x7f\x22\x0c\x5c\x5c'
    int_2 = 74
    dict_1 = dict()
    dict_1[str_1] = int_1
    dict_1[str_2] = int_2
    list_1 = list(dict_1.values())
    ret = lookup_module_0.run

# Generated at 2022-06-25 11:07:57.051245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    inject_0 = 'w\x1b'
    terms_0 = '\r*r\rk\x0e'
    lookup_module_1 = LookupModule(inject_0, terms_0)
    with pytest.raises(AnsibleError, match="Unable to choose random term: %s" % to_native(e)) as excinfo:
        lookup_module_1.run(inject_0, terms_0, **kwargs)
    assert excinfo.value.args[0] == "Unable to choose random term: %s" % to_native(e)

# Generated at 2022-06-25 11:08:04.099141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 796.0
    list_0 = ['\x13\x1fO\x1d\x05D']
    int_0 = 48
    float_1 = 781.0
    lookup_module_0 = LookupModule(float_0, list_0, int_0, float_1)
    try:
        result = lookup_module_0.run()

        try:
            assert (result == [])
        except AssertionError:
            raise

    except Exception:
        result = None



# Generated at 2022-06-25 11:08:08.348586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'nJkU6^d'
    str_1 = 'a/0'
    list_0 = [str_0, str_1]
    lookup_module_0 = LookupModule(list_0, None)
    str_2 = 'S*?m'
    str_3 = 'E8X4'
    list_1 = [str_2, str_3]
    ret_0 = lookup_module_0.run(list_1)
    assert ret_0 == list_1

# Generated at 2022-06-25 11:08:11.620479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 7800.0
    str_0 = 'ToHm\x7fIJv)}8b'
    lookup_module_0 = LookupModule(float_0, str_0)
    float_0 = 0.0
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_0 = LookupModule(float_0, str_0)

# Generated at 2022-06-25 11:08:20.465386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 85.087
    str_0 = '7~B\x1b?\x06'
    lookup_module_0 = LookupModule(float_0, str_0)
    # assert isinstance(lookup_module_0.run(DummyFile()), object)
    # assert isinstance(lookup_module_0.run(DummyFile()), object)
    # assert isinstance(lookup_module_0.run(DummyFile()), object)
    # assert isinstance(lookup_module_0.run(DummyFile()), object)
    # assert isinstance(lookup_module_0.run(DummyFile()), object)
    # assert isinstance(lookup_module_0.run(DummyFile()), object)
    # assert isinstance(lookup_module_0

# Generated at 2022-06-25 11:08:28.018149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(12345678)
    lookup_module_0.run(True)
    lookup_module_0.run(12345678)
    lookup_module_0.run(124567)
    lookup_module_0.run(56)
    lookup_module_0.run(0)
    lookup_module_0.run(12345678)
    lookup_module_0.run(124567)
    lookup_module_0.run(56)


# Generated at 2022-06-25 11:08:35.032261
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1111.0
    str_0 = ''
    lookup_module_0 = LookupModule(float_0, str_0)
    lookup_results_0 = lookup_module_0.run(float_0, str_0)
    assert lookup_results_0 == float_0
    assert lookup_results_0 == float_0
    assert lookup_results_0 == float_0
    assert lookup_results_0 == float_0
    assert lookup_results_0 == float_0
    assert lookup_results_0 == float_0
    assert lookup_results_0 == float_0
    assert lookup_results_0 == float_0
    assert lookup_results_0 == float_0
    assert lookup_results_0 == float_0
    assert lookup_results_0 == float_0
    assert lookup_results_

# Generated at 2022-06-25 11:08:47.262817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [1225.0]
    inject_0 = '\x0b5IOnS;qLt'
    kwargs_0 = None
    lookup_module_0 = LookupModule(terms=terms_0, inject=inject_0, kwargs=kwargs_0)
    ret = lookup_module_0.run(terms=terms_0, inject=inject_0, kwargs=kwargs_0)
    assert ret

# Generated at 2022-06-25 11:08:51.165301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    v_0 = '\x03XB\x7f#'
    v_1 = '\x05$\x1d\x0e\x1c-\x08\\'
    test_case_0()
    lookup_module_0 = LookupModule(v_0, v_1)
    lookup_module_0.run(v_0, v_1)


# Generated at 2022-06-25 11:09:00.141843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(float_0, str_0)
    list_0 = []
    inject_0 = {}
    kwargs_0 = dict
    kwargs_0 = dict
    kwargs_0 = dict
    kwargs_0 = dict
    kwargs_0 = dict
    kwargs_0 = dict
    kwargs_0 = dict
    kwargs_0 = dict
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_6 = 0
    list_0 = lookup_module_0.run(list_0, inject=inject_0, **kwargs_0)

# Generated at 2022-06-25 11:09:01.720620
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Call LookupModule.run(list, None, **kwargs)
    test_case_0()

# Generated at 2022-06-25 11:09:06.015219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1225.0
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_0 = LookupModule(float_0, str_0)
    str_1 = '\x0b5IOnS;qLt'
    lookup_module_0.run(str_1, inject=None)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:09:14.430238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1225
    str_0 = 'E\x7f %]a'
    lookup_module_0 = LookupModule(float_0, str_0)
    terms_0 = []
    terms_0.append('4#\x9f[\xfc&\x1c\x0c\x0f\x1c\xdf\x13\x0f\x06\x0b\x1c\x1a\x1e\x1a')
    terms_0.append('~\x01\x11\x1a\x1b\x1e\x1b')

# Generated at 2022-06-25 11:09:17.023769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'Yaie)n2^L\x7f'
    int_0 = -13
    lookup_module_0 = LookupModule(int_0, str_0)
    str_1 = lookup_module_0.run()

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 11:09:20.081045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  str_0 = '\x0b5IOnS;qLt'
  int_0 = -1207026693082508950
  int_1 = -1
  lookup_module_0 = LookupModule(int_0, int_1)
  str_1 = lookup_module_0.run(str_0)


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:09:27.100945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_0 = LookupModule()
    list_1 = ['\x1f', '\x87\x0c|\x03', '\x87\x0c|\x03']
    str_0 = '\x87\x0c|\x03'
    assert class_0.run(list_1, str_0) == list_1


# Generated at 2022-06-25 11:09:28.135751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 11:09:48.262841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1225.0
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_1 = LookupModule(float_0, str_0)
    print("\nRunning unit test for method run of class LookupModule:")
    print("test_LookupModule_run: lookup_module_1.run(None, None, [], None)")
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_1.run(None, None, [], None)
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_1.run(None, None, [], None)
    str_0 = '\x0b5IOnS;qLt'

# Generated at 2022-06-25 11:09:51.373067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1225.0
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_0 = LookupModule(float_0, str_0)
    list_0 = ['\x0b5IOnS;qLt', '\x0b5IOnS;qLt', '\x0b5IOnS;qLt']
    list_1 = ['\x0b5IOnS;qLt']
    assert lookup_module_0.run(list_0) == list_1


# Generated at 2022-06-25 11:10:00.751395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1225.0
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_0 = LookupModule(float_0, str_0)

# Generated at 2022-06-25 11:10:02.887876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a = LookupModule()
    a.options = {"x": "chocolate", "y": "vanilla"}
    a.run([1, 2, 3])

# Generated at 2022-06-25 11:10:10.898760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 1225.0
    str_0 = '\x0b5IOnS;qLt'
    lookup_module_0 = LookupModule(float_0, str_0)
    list_0 = []
    dict_0 = {}
    str_1 = 'H\x1d\x1aXj\x1b\x15'
    dict_0[str_1] = '%c\x1a\x1b\x1a'
    str_2 = '\x0b5IOnS;qLt'
    dict_0[str_2] = '\x17\x16\x12\r\x1a'
    str_3 = 'H\x1d\x1aXj\x1b\x15'

# Generated at 2022-06-25 11:10:13.689080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 3655793811
    int_1 = 8
    list_0 = [int_0, int_1]
    var_0 = test_case_0()
    var_1 = lookup_module_0.run(list_0)
    assert var_1 == var_0

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:10:19.338835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:10:24.312129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    list_0 = []

    # This call to run() executes the following:
    # return ret
    ret = lookup_module_0.run(list_0)
    assert(ret == list_0)
    # assert(ret == list_0)

# Generated at 2022-06-25 11:10:26.836753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  assert lookup_module.run()

# Generated at 2022-06-25 11:10:31.214570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = 'RRY'
    assert_0 = 'RRY'
    lookup_module_0 = LookupModule(terms_0)
    result_0 = lookup_module_0.run(terms_0)
    assert result_0 == assert_0


# Generated at 2022-06-25 11:10:51.621941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert var_0 == [""]

# Generated at 2022-06-25 11:10:55.452244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ["We are in the endgame now."]
    ret = lookup_module_0.run(var_0)
    assert isinstance(ret, list)
    assert ret == ["We are in the endgame now."]


# Generated at 2022-06-25 11:10:58.132339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_x = ["foo","bar","baz"]
    lookup_module_x = LookupModule()
    var_y = lookup_module_x.run(var_x)
    assert len(var_y) == 1
    assert var_y[0] in var_x

# Generated at 2022-06-25 11:11:02.454127
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)

# Generated at 2022-06-25 11:11:05.866721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = lookup_run(lookup_module_1)

# Generated at 2022-06-25 11:11:07.365075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run()

# Generated at 2022-06-25 11:11:16.088379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)
    var_1 = lookup_run(lookup_module_1)
    var_1 = lookup_run(lookup_module_1)
    var_1 = lookup_run(lookup_module_1)
    var_1 = lookup_run(lookup_module_1)
    var_1 = lookup_run(lookup_module_1)
    var_1 = lookup_run(lookup_module_1)
    var_1 = lookup_run(lookup_module_1)
    var_1 = lookup_run(lookup_module_1)
    var_1 = lookup_run(lookup_module_1)
    var_1 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:11:20.975042
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=[random.choice(terms)])
    assert var_0 == ret
    assert var_0[0] == ret



# Generated at 2022-06-25 11:11:26.785489
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # FAIL: AssertionError: [('A', 'list'), 'A', 'list'] != [('A', list)]
    # values to be compared are:
    # [('A', 'list'), 'A', 'list']
    # [('A', list)]
    # var_0 - [('A', 'list'), 'A', 'list']
    # var_1 - [('A', list)]
    lookup_module_0 = LookupModule()
    lookup_module_0.run('A, list')

# Generated at 2022-06-25 11:11:28.067417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    for i in range(0, 1000):
        var_0 = lookup_module_0.run("str")
        assert var_0 == "str"

# Generated at 2022-06-25 11:12:09.298339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run(LookupModule()) == []
    assert lookup_run(LookupModule(), ['first', 'second'], None) == ['first']
    assert lookup_run(LookupModule(), ['first', 'second'], None) == ['first']

# Generated at 2022-06-25 11:12:16.290255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # assert lookups/random_choice
    assert lookup_module_0.run(terms=None) == None

    # assert lookups/random_choice
    assert lookup_module_0.run(terms=[]) == []

    # assert lookups/random_choice
    assert lookup_module_0.run(terms=['a']) == ['a']

    # assert lookups/random_choice

# Generated at 2022-06-25 11:12:18.909629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["str_0", "str_1", "str_2"]
    assert lookup_module_0.run(terms_0) == ["str_1"]

# Generated at 2022-06-25 11:12:21.545180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_instance = LookupModule()
    terms = ["wumpus", "minotaur", "elf"]

    # Call method run on lookup_module_instance with arguments terms,inject,kwargs
    # Return value should be 'elf'
    assert lookup_module_instance.run(terms,inject,kwargs) == "elf"

# Generated at 2022-06-25 11:12:28.450358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test_LookupModule_run")
    # testing input
    print(LookupModule.run, "LookupModule.run")
    terms = [1, 2, 3]
    inject = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    print(var_0)


# Generated at 2022-06-25 11:12:38.447247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = lookup_module_0.run(terms=["item1", "item2"], inject=None, **kwargs)
  var_0 = lookup_run(lookup_module_0)
  var_0 = lookup_module_0.run(terms=["item1", "item2"], inject=None, **kwargs)
  assert "terms" in kwargs
  assert "inject" in kwargs
  assert "kwargs" in kwargs

# Generated at 2022-06-25 11:12:42.794736
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:12:52.997195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create object of class LookupModule
    lookup_module_0 = LookupModule()
    # Store a list to var_0
    var_0 = [1, 2, 3, 4, 5]
    # Call method run of LookupModule with arguments var_0 and keyword arguments {}
    try:
        var_1 = lookup_run(lookup_module_0, var_0)
    except AnsibleError as e:
        # catch AnsibleError and print value of e
        print(e)
    else:
        # Retrieve name of type of value of var_1
        var_2 = type(var_1).__name__
        # Validate if var_2 equals to var_1
        assert var_2 == var_1
    pass

# Generated at 2022-06-25 11:13:02.104316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert [False] == lookup_module_0.run([False])
    assert [True] == lookup_module_0.run([True])
    assert [] == lookup_module_0.run([])
    assert [None] == lookup_module_0.run([None])
    assert [[]] == lookup_module_0.run([[]])
    assert [{}] == lookup_module_0.run([{}])
    assert [1] == lookup_module_0.run([1])
    assert ["test_string"] == lookup_module_0.run(["test_string"])
    assert [{'name': 'test_map'}] == lookup_module_0.run([{'name': 'test_map'}])

# Generated at 2022-06-25 11:13:07.625597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 11:14:30.151879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:14:32.017673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:14:33.915955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print(test_case_0())

# Generated at 2022-06-25 11:14:37.433384
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run([1, 2, 3, 4, 5], inject=None, **{'vars': None})
    assert var_1 == [3]

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:14:43.824714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = {'lorem_2': 'lorem_2', }
    var_2 = LookupModule()
    var_3 = ((var_1,), {'lorem_2': 'lorem_2', }, )
    var_4 = var_2.run(*var_3)
    assert var_4 == 'lorem_2'


# Generated at 2022-06-25 11:14:45.083544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(test_case_0(), object)

# Generated at 2022-06-25 11:14:46.537143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, inject)

# Generated at 2022-06-25 11:14:58.260675
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run([u'1', u'2'], u'3', test_case_0=u'test_case_0')
    if var_1 == [u'2']:
        pass
    else:
        raise AssertionError("Method run returned incorrect value. Expected '%s' but got '%s'" % (u'2', var_1))

    # Runs one or more tests for method run
    def test_case_4():
        lookup_module_4 = LookupModule()
        var_4 = lookup_run(lookup_module_4)

    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 11:14:59.992943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(5, )
    assert var_0 == 5

# Generated at 2022-06-25 11:15:01.338732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = lookup_run(lookup_module_0)
  assert var_0 == []