

# Generated at 2022-06-25 11:06:36.737180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Fix me!!!
# if __name__ == "__main__":
#     test_LookupModule_run()

# Generated at 2022-06-25 11:06:39.251274
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)

    ret = lookup_module_0.run(['some_random_input'])
    assert 'some_random_input' in ret

# Generated at 2022-06-25 11:06:45.320262
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing error condition when no option is passed
    try:
        result = lookup_module_0.run([])
        assert False, "If no options passed to lookup, it should throw an exception"
    except AnsibleError as e:
        assert str(e) == "with_random_choice expects a list", "If no options passed to lookup, it should throw an exception"

  # Testing random choice
    try:
        result = lookup_module_0.run(["a", "b"])
        assert result[0] in ["a","b"], "Random choice should return one of the elements from the list"
    except AnsibleError as e:
        assert False, "Random choice should return one of the elements from the list"

# Generated at 2022-06-25 11:06:55.529034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = [{'f': 0.424, 'r': 0.108}, {'f': 0.108, 'r': 0.622}, {'f': 0.177, 'r': 0.282}, {'f': 0.205, 'r': 0.629}, {'f': 0.204, 'r': 0.68}]
    terms = [list(e.values()) for e in data]
    lookup_module_0 = LookupModule(data)
    terms_list_0 = terms
    value = lookup_module_0.run(terms_list_0)
    assert value == [data[4]], "value does not equal [{'f': 0.204, 'r': 0.68}]"

# Generated at 2022-06-25 11:06:56.360694
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:06:59.352459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    assert lookup_module_0.run(["abc"]) == ["abc"]
# END

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:07:03.284348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_4 = {}
    lookup_module_4 = LookupModule(dict_4)
    terms_1 = []
    lookup_module_4.run(terms_1)


# Generated at 2022-06-25 11:07:09.804108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict = {  }
    lookup_module = LookupModule(dict)
    terms = [["1","2","3"]]
    lookup_module_0 = lookup_module.run(terms, **dict)
# Testing module with option: test_case_0

# Generated at 2022-06-25 11:07:15.873459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = 'a_0'
    inject_0 = 'b_0'
    kwargs_0 = dict()
    __return__ = 'c_0'
    return_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    assert return_0 == __return__


# Testing function random of module random

# Generated at 2022-06-25 11:07:19.688002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    obj_0 = lookup_module_0.run(None, random.choice)
    assert obj_0 == None


# Generated at 2022-06-25 11:07:26.680486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    inject_0 = {}
    kwargs_0 = {}
    result = lookup_module_0.run(terms_0, inject_0, **kwargs_0)

# Generated at 2022-06-25 11:07:33.695209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    rand_examples_0 = [1, 2, 3, 4, 5, 6]
    assert lookup_module_0.run(rand_examples_0) == rand_examples_0


# Generated at 2022-06-25 11:07:38.838150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms = [random.choice(terms)]
    terms = "9K%E!rq3&T8;<D>w6'2iY.n$bAhauUZ#`G{&r0B0xl?9dzmKU+c%U"
    ret = lookup_module_0.run(terms)
    assert ret == "9K%E!rq3&T8;<D>w6'2iY.n$bAhauUZ#`G{&r0B0xl?9dzmKU+c%U"

# Generated at 2022-06-25 11:07:43.172617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    list_0 = []
    assert lookup_module_0.run(list_0) == list_0


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:07:48.291658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    inject_0 = {}
    ret_0 = lookup_module_0.run(terms_0, inject_0)

# Generated at 2022-06-25 11:07:57.880994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    ret = lookup_module_0.run([],{},templar=None,variables={})
    assert ret == []
    ret = lookup_module_0.run([],{},templar=None,variables={})
    assert ret == []
    ret = lookup_module_0.run([],{},templar=None,variables={})
    assert ret == []
    ret = lookup_module_0.run([],{},templar=None,variables={})
    assert ret == []
    ret = lookup_module_0.run([],{},templar=None,variables={})
    assert ret == []

# Generated at 2022-06-25 11:08:01.573427
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
# Stop the test if the above line raises exception
    ret_value_1 = lookup_module_1.run(["foo", "bar"])
    assert ret_value_1 == ["foo"]


# Generated at 2022-06-25 11:08:06.149868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    inject_0 = {}
    kwargs_0 = {}
    result_0 = lookup_module_0.run(terms_0, inject=inject_0, **kwargs_0)
    assert len(result_0) == 0
    terms_1 = [1, 2, 3]
    kwargs_1 = {}
    result_1 = lookup_module_0.run(terms_1, **kwargs_1)
    assert result_1 is not None

# Generated at 2022-06-25 11:08:14.339896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    str_0 = 'message not in file'
    str_1 = 'File does not exist'
    str_2 = 'vars.yml'
    str_3 = 'yaml'

# Generated at 2022-06-25 11:08:23.226875
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Fails with self.assertEqual(random.shuffle(terms), 'Red')
    test_terms_0 = [
        'Red',
        'Green',
        'Blue',
        'Yellow',
        'Purple',
        'Orange',
        'Brown',
        'Black',
        'White',
        'Indigo',
        'Violet',
        'Grey',
        'Cyan',
        'Magenta',
    ]
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run(test_terms_0)

    return


test_LookupModule_run()

# Generated at 2022-06-25 11:08:30.371193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    result = lookup_module_0.run("list_0")
    assert "list_0" in result

# Generated at 2022-06-25 11:08:31.997487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:08:35.737486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        test_case_0()
    except NameError:
        raise Exception('Test case 0 failed')

if __name__ == '__main__':
    import os
    import sys
    import unittest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    unittest.main()

# Generated at 2022-06-25 11:08:38.194459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  dict_0 = {}
  lookup_module_0 = LookupModule(dict_0)
  terms_0 = []
  inject_0 = None
  kwargs_0 = {}
  str_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
  # print(str_0)

# Generated at 2022-06-25 11:08:40.653642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)

    terms_0 = []
    inject_0 = {}
    result_0 = lookup_module_0.run(terms_0, inject_0)

# Generated at 2022-06-25 11:08:44.704423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['1', '2', '3', '4', '5']
    assert lookup_module._run(terms) in terms

# Generated at 2022-06-25 11:08:46.893544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)

    assert lookup_module_0.run(['one', 'two']) == ['two']

# Generated at 2022-06-25 11:08:51.141987
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    items = [
        [()],
        [('',)],
        [('Random',)],
        [('Random', '', '')],
        [('Random', '', '', '')]
    ]

    for item in items:
        with pytest.raises(AnsibleError):
            lookup_module_0 = LookupModule({})
            result = lookup_module_0.run(item)

# Generated at 2022-06-25 11:08:56.193359
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Random choice terms
    terms_0 = ['a', 'b', 'c']
    lookup_module_0 = LookupModule(terms_0)
    assert len(lookup_module_0.run(terms_0)) == 1

# Generated at 2022-06-25 11:08:58.493063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == "__main__":
    # Unit test for method run of class LookupModule
    test_LookupModule_run()

# Generated at 2022-06-25 11:09:07.578583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:09:10.547924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    result = lookup_module_0.run(terms_0)
    assert result == [], "The results returned by run not as expected"

# Generated at 2022-06-25 11:09:20.619248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_paths_0 = [

        ]
    ansible_module_0 = AnsibleModule(module_paths_0)
    assert getattr(ansible_module_0, 'new_module') == None
    assert getattr(ansible_module_0, 'argument_spec') is None
    assert getattr(ansible_module_0, 'no_log') == False
    assert getattr(ansible_module_0, '_name') == 'random'
    assert getattr(ansible_module_0, '_load_params') == None
    assert getattr(ansible_module_0, 'aliases') == []
    assert getattr(ansible_module_0, 'exit_json') == None
    assert getattr(ansible_module_0, 'fail_json') == None

# Generated at 2022-06-25 11:09:24.667700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    terms = []
    assert lookup_module_0.run(terms) == []

# Generated at 2022-06-25 11:09:28.126934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  dict_0 = {}
  lookup_module_0 = LookupModule(dict_0)
  assert len(list(filter(lambda x: x and True, list(map(lambda x: lookup_module_0.run(terms=x, inject=None, **None), ['1', '2', '3', '4']))))) == 0

# Generated at 2022-06-25 11:09:34.227833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x_1 = "go through the door"
    x_2 = "drink from the goblet"
    x_3 = "press the red button"
    x_4 = "do nothing"
    random_list_0 = [x_1, x_2, x_3, x_4]
    terms = random_list_0
    lookup_module_0 = LookupModule({})
    result = lookup_module_0.run(terms)
    assert result == random_list_0

# Generated at 2022-06-25 11:09:37.501883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    r = LookupModule.run('something', [], inject={}, **{'stuff': ''})
    assert r == ['something']

# Generated at 2022-06-25 11:09:39.181225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule_obj = LookupModule()
    # There are no assertions to verify.
    lookupModule_obj.run()

# Generated at 2022-06-25 11:09:45.029756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    str_0 = lookup_module_0.run(list_0)


# test lookups with fake data

# Generated at 2022-06-25 11:09:58.691470
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    assert(lookup_module_0.run() == [])

    lookup_module_0 = LookupModule()
    assert(lookup_module_0.run([1, 2]) == [2])

    lookup_module_0 = LookupModule()
    assert(lookup_module_0.run([1]) == [1])

    lookup_module_0 = LookupModule()
    assert(lookup_module_0.run([1, 2]) == [2])

    lookup_module_0 = LookupModule()
    lookup_module_0.run('d')
    assert(lookup_module_0.run([1, 2]) == ['d'])

    lookup_module_0 = LookupModule()
    lookup_module_0.run([1, 2])

# Generated at 2022-06-25 11:10:22.618601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    inject_0 = None
    kwargs_0 = {}
    kwargs_1 = kwargs_0
    ret_0 = lookup_module_0.run(terms_0, inject=inject_0, **kwargs_1)
    assert len(ret_0) == 0

# Generated at 2022-06-25 11:10:24.226611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = Ping()
    lookup_module_0.run(terms, inject=None, **kwargs)

# Generated at 2022-06-25 11:10:27.752503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term = 'marshmallows'
    lookup_module = LookupModule()
    result = lookup_module.run(term)
    assert term == 'marshmallows'

# Generated at 2022-06-25 11:10:31.382593
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    assert isinstance(lookup_module_0.run(dict_0), list)


# Generated at 2022-06-25 11:10:36.051362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    try:
        arg_0 = terms_0
        arg_1 = None
        random_choice_0 = lookup_module_0.run(arg_0, arg_1)
        assert random_choice_0 is not None
    except Exception as e:
        assert False


# Generated at 2022-06-25 11:10:39.662356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:10:44.384948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = {
        'key': 'value',
    }
    inject_0 = 'value'
    assert lookup_module_0.run(terms_0, inject=inject_0) == [terms_0['key']]


# Generated at 2022-06-25 11:10:50.169611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    list_0 = []
    dict_1 = {}
    str_0 = lookup_module_0.run(list_0, dict_1)
    assert str_0 == list_0
    list_1 = ["foo", "bar", "baz"]
    dict_2 = {}
    str_1 = lookup_module_0.run(list_1, dict_2)
    assert str_1 in list_1

# Generated at 2022-06-25 11:10:52.690891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:10:57.544664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = {}
    lookup_module_0.run(list_0, inject=dict_0, **dict_0)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:11:36.618568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    inject_0 = None
    kwargs_0 = {}
# AssertionError: Expected call: run(['a', 'b', 'c'], None, {})
# Actual call: run(['a', 'b', 'c'], None, {})

# Generated at 2022-06-25 11:11:39.768700
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    dict_0 = {}
    dict_1 = {"inject": dict_0}
    list_0 = []
    assert lookup_module_0.run(list_0, **dict_1) == list_0

# Generated at 2022-06-25 11:11:47.194702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    try:
        lookup_module_0.run(None, None, None)
    except AnsibleError:
        assert True
    else:
        assert False

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 11:11:53.234817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    values_0 = []
    inject_0 = None
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, inject=inject_0, **kwargs_0) == values_0


# Generated at 2022-06-25 11:12:00.569889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = [
        [
            "first",
            "second",
            "third"
        ],
        {},
        {
            "wantlist": True
        }
    ]
    args_1 = [
        [
            "first",
            "second",
            "third"
        ],
        {},
        {
            "wantlist": False
        }
    ]
    # Test of random with wantlist True
    lookup_module_0 = LookupModule({})
    assert len(lookup_module_0.run(*args_0)) == 1
    # Test of random with wantlist False
    lookup_module_1 = LookupModule({})
    assert len(lookup_module_1.run(*args_1)) == 1


# Generated at 2022-06-25 11:12:02.753559
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # LookupModule.run(terms, inject=None, **kwargs)

    # Case 0
    # TBD

    pass

# Generated at 2022-06-25 11:12:13.218977
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Define test variables and initialize-reinitialize object
    terms_0 = []
    terms_1 = ['x', 'y', 'z']
    terms_2 = ['a', 'b', 'c']
    terms_3 = ['l', 'm', 'n']
    lookup_module_0 = LookupModule(None)

    # Perform the test - return list should have one element
    assert(len(lookup_module_0.run(terms_0)) == 1)

    # Perform the test - return list should have three elements
    assert(len(lookup_module_0.run(terms_1)) == 1)

    # Perform the test - return list should have three elements
    assert(len(lookup_module_0.run(terms_2)) == 1)

    # Perform the test - return list should have three elements
   

# Generated at 2022-06-25 11:12:15.992654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:12:18.943813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    ret = lookup_module_0.run(terms, inject)
    assert ret == [(terms[random.randint(0, len(terms) - 1)])]


# Generated at 2022-06-25 11:12:19.374668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 11:13:41.153327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 11:13:42.877656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:13:51.277946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = []
    args = (terms_0)
    ret_0 = lookup_module_0.run(*args)
    assert ret_0 == []

    dict_1 = {}
    lookup_module_1 = LookupModule(dict_1)
    terms_1 = []
    terms_1.append('foo')
    terms_1.append('bar')
    args = (terms_1)
    ret_1 = lookup_module_1.run(*args)
    assert ret_1 == ['foo'] or ret_1 == ['bar']

# Generated at 2022-06-25 11:13:57.148676
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    from ansible.plugins.lookup import AnsibleLookupError

    # parameters for testcase 1
    terms_1 = ['a', 'b']
    # expected result for testcase 1
    expected_result_1 = "a"

    # testcase 1
    assert lookup_module_0.run(terms_1, {}) == expected_result_1


# Generated at 2022-06-25 11:14:02.433513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)
    terms_0 = 'This is a test'
    return_value_0 = lookup_module_0.run(terms_0)

    if (return_value_0 == True):
        print('Great!')

# Generated at 2022-06-25 11:14:04.727798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Call to run with a single argument
    ret_0 = lookup_module_0.run([])

    # Asserts on the return value
    assert type(ret_0) == list
    assert not ret_0

# Generated at 2022-06-25 11:14:10.776620
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_t = {}
    lookup_module_t = LookupModule(dict_t)
    sample_list = ["apple","orange"]
    assert(type(lookup_module_t.run(sample_list)) == list)

# Generated at 2022-06-25 11:14:19.259471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    lookup_module_1 = LookupModule({})
    lookup_module_2 = LookupModule({})
    lookup_module_3 = LookupModule({})
    lookup_module_4 = LookupModule({})
    lookup_module_5 = LookupModule({})

    assert lookup_module_0.run(["\x1a", "8.5", "0$", ";", "9", "^6", "2", "\x0f0"], {})
    assert lookup_module_1.run(["\x1a", "8.5", "0$", ";", "9", "^6", "2", "\x0f0"], {})

# Generated at 2022-06-25 11:14:23.650315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test run()
    """

    terms = [5, 3, 6]
    inject = None
    kwargs = {}

    lookup_module_0 = LookupModule(terms, inject, **kwargs)
    ret = lookup_module_0.run(terms, inject, **kwargs)

    assert ret is not None

# Generated at 2022-06-25 11:14:27.540206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule(dict())
    assert lookup_module.run([]) == [], "No terms was given"
    assert lookup_module.run(["a", "b", "c"]) == ["a", "b", "c"], "Random term was not returned"

    # Check for runtime exception
    assert lookup_module.run([]) == "Unable to choose random term: <unprintable Error object"