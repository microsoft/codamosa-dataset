

# Generated at 2022-06-25 11:06:36.521886
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule(list())

    assert lookup_module.run(list()) in [list()]

# Generated at 2022-06-25 11:06:42.701482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(terms, inject)
    assert lookup_module_0.run() == [1], "Expected [1], but got: %s" % lookup_module_0.run()


# Generated at 2022-06-25 11:06:50.919260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = random.choice(["-g", "-f", "-e", "-o", "-r", "-s", "-b"])
    inject = random.choice(["-z", "-x", "-p", "-b", "-d", "-e", "-s"])
    kwargs = { "key": random.choice([":", "-", "%", "@", "$", "^"]) }
    assert isinstance(lookup_module_0.run(terms, inject, **kwargs), list)


# Generated at 2022-06-25 11:06:52.966299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    list_0 = [set_0]
    lookup_module_0 = LookupModule(list_0)

    lookup_module_0.run([])


# Generated at 2022-06-25 11:06:59.617718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1
    set_0 = set()
    list_0 = [set_0]
    lookup_module_0 = LookupModule(list_0)
    assert isinstance(lookup_module_0, LookupModule)
    lookup_module_0.run(terms=0)

# Generated at 2022-06-25 11:07:05.542118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set([])
    list_0 = [set_0]
    lookup_module_0 = LookupModule(list_0)
    ret = lookup_module_0.run(list_0)
    assert 0 == len(ret)


# Generated at 2022-06-25 11:07:13.227821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    list_0 = [set_0]
    lookup_module_0 = LookupModule(list_0)
    int_0 = random.randint(0, 100)

    assert lookup_module_0.run([int_0]) == [int_0]


# Generated at 2022-06-25 11:07:14.357882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.run('str_0')


# Generated at 2022-06-25 11:07:18.380881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    iterator_0 = [1, 2, 3]
    iterator_1 = [1, 2, 3]
    lookup_module_0 = LookupModule(iterator_1)
    terms_0 = [iterator_0]
    inject_0 = None
    kwargs_0 = {'a': 0, 'b': 0}
    result_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)

# Generated at 2022-06-25 11:07:19.036336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:07:31.864527
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Test with a list of strings
    list_0 = ["red", "orange", "yellow", "green", "blue", "indigo", "violet"]
    try:
        lookup_module_0.run(list_0)
    except Exception as e:
        assert False, "Unable to run module: %s" % to_native(e)
    # Test with a list of dictionaries
    list_1 = [{1: 2}, {3: 4}, {5: 6}]
    try:
        lookup_module_0.run(list_1)
    except Exception as e:
        assert False, "Unable to run module: %s" % to_native(e)
    # Test with a mixed list

# Generated at 2022-06-25 11:07:33.666883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, inject=None, **kwargs)
    
if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:07:35.803595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:07:40.948526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    expected_0 = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    var_0 = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    actual_0 = lookup_module_1.run(var_0)
    assert actual_0 in expected_0 == var_0
    expected_1 = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    var_1 = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    actual_1 = lookup_module_1.run(var_1)
    assert actual_1 in expected_1 == var_1

# Generated at 2022-06-25 11:07:52.380339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_3.run(['f', '1', '12'])

# Generated at 2022-06-25 11:07:58.273701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:08:01.031574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args_0 = [[""]]
    var_0 = lookup_module_0.run(args_0[0])



# Generated at 2022-06-25 11:08:04.098126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [ 'term1', 'term2', 'term3']
    kwargs_1 = {}
    var_1 = lookup_module_1.run(terms_1, **kwargs_1)
    assert var_1 in terms_1

# Generated at 2022-06-25 11:08:09.155045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_2 = lookup_vars()
    var_3 = lookup_context()
    var_4 = to_native()
    var_5 = "Unable to choose random term: #FIXME"
    var_6 = lookup_run(lookup_module_0,var_2,var_3,var_4,var_5)
    var_7 = lookup_run(lookup_module_0,var_2,var_3,var_4)


# Generated at 2022-06-25 11:08:14.731333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:08:24.702731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [
        'arg_0',
        'arg_1',
        'arg_2',
        'arg_3',
        'arg_4',
        'arg_5',
        'arg_6',
        'arg_7',
        'arg_8',
        'arg_9'
    ]
    var_1 = lookup_module_1.run(terms_1)

# Generated at 2022-06-25 11:08:27.449022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:08:29.297154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert (var_0 == []), 'The expected answer is [].'

# Generated at 2022-06-25 11:08:36.048440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  assert lookup_module_0.run([]) == [], 'Test Failed'
  assert lookup_module_0.run([], inject={'random': random}) == [], 'Test Failed'
  assert lookup_module_0.run(['foo', 'bar', 'baz']) == [random.choice(['foo', 'bar', 'baz'])], 'Test Failed'
  assert lookup_module_0.run([u'one', u'two', u'three']) == [random.choice([u'one', u'two', u'three'])], 'Test Failed'

# Generated at 2022-06-25 11:08:40.256585
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["hello", "world", "bye"])
    assert var_0[0] in ["hello", "world", "bye"]


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:08:44.451137
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert var_0 == ret

# unit tests end here
if __name__ == '__main__':
  test_case_0()
  test_LookupModule_run()

# Generated at 2022-06-25 11:08:49.292712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [u"go through the door", u"drink from the goblet", u"press the red button", u"do nothing"]
    var_2 = lookup_module_0.run(var_1, inject=None, **kwargs)
    assert len(var_2) == 1, "'ansible.plugins.lookup.random_choice' object does not support slice"

# Generated at 2022-06-25 11:08:54.235292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        var = lookup_run(['foo', 'bar'])
        assert var == 'foo' or var == 'bar'
    except Exception as e:
        assert False, "unexpected exception: %s" % to_native(e)


# Generated at 2022-06-25 11:08:56.440528
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Generated at 2022-06-25 11:08:59.442485
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [terms]
    inject=[inject]
    kwargs=[kwargs]
    assert lookup_module_0.run(terms, inject, kwargs), 'Return random item from list'

# Generated at 2022-06-25 11:09:07.731217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    inject_0 = None
    kwargs_0 = dict()
    ret_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    assert isinstance(ret_0, list)
    assert len(ret_0) == 0
    assert ret_0 == []


# Generated at 2022-06-25 11:09:11.286761
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    terms = [('a'), ('b'), ('c'), ('d')]
    expected = [('b')]
    lookup_module = LookupModule()

    # Act
    result = lookup_module.run(terms)

    # Assert
    assert result == expected


# Generated at 2022-06-25 11:09:14.978884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_2 = ['a', 'b', 'c']
    var_3 = lookup_module_0.run(var_2)
    assert var_3 == ['a'] or var_3 == ['b'] or var_3 == ['c']
    var_4 = ['a', 'b', 'c']
    var_5 = lookup_module_0.run(var_4, {})
    assert var_5 == ['a'] or var_5 == ['b'] or var_5 == ['c']

# Generated at 2022-06-25 11:09:18.857845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  var = []
  lookup_module_0 = LookupModule()
  var_0 = lookup_module_0.run(var)
  assert len(var_0) == 1

# Generated at 2022-06-25 11:09:23.885970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert_equal(lookup_module_0.run(None, None), [])

# Generated at 2022-06-25 11:09:25.609081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run
    # expected result:

    print("RESULT: " + str(var_0))

# Generated at 2022-06-25 11:09:27.270799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:09:29.639769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = ["0"]
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(var_0)
    assert len(var_1) == 1 


# Generated at 2022-06-25 11:09:34.228287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No parametrization

    lookup_module_0 = LookupModule()

    with pytest.raises(AnsibleError, match=r"Unable to choose random term: "):
        ret_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:09:37.501478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_module.run(["test","test2"])
    assert var == "test"

# Generated at 2022-06-25 11:09:50.461351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from random import choice as GetRandomChoice
    
    choices = (
        "Go through the door.",
        "Drink from the goblet.",
        "Press the red button.",
        "Do nothing.",
    )
    
    # Get random choice
    random_choice = GetRandomChoice(choices)
    
    assert random_choice == "Go through the door." or random_choice == "Drink from the goblet." or random_choice == "Press the red button." or random_choice == "Do nothing."

# Generated at 2022-06-25 11:09:56.155961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = [["go through the door", "drink from the goblet", "press the red button", "do nothing"]]
    var_2 = lookup_run(lookup_module_1, var_1)

#TODO: Implement this Unit test

# Generated at 2022-06-25 11:09:58.709573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(['baz', 'bar'])

    assert(var_1 == ['baz'])

# Generated at 2022-06-25 11:10:01.443861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    input_0 = [['']]
    input_1 = {}
    var_0 = lookup_module_0.run(input_0, input_1)
    print(var_0)

# Generated at 2022-06-25 11:10:04.297674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)

    if var_1 == ['case 0']:
        assert True
    else:
        assert False


# Generated at 2022-06-25 11:10:06.117473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["foo","bar"])


# Generated at 2022-06-25 11:10:10.868256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    if var_0 != ["go through the door", "drink from the goblet", "press the red button", "do nothing"]:
        raise AssertionError()

if __name__ == "__main__":
    try:
        test_case_0()
        test_LookupModule_run()
    except:
        raise AssertionError()

# Generated at 2022-06-25 11:10:16.211322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 0
    assert lookup_run(LookupModule()) == None

    # test case 1
    assert lookup_run(LookupModule()) == None

    # test case 2
    assert lookup_run(LookupModule()) == None

    # test case 3
    assert lookup_run(LookupModule()) == None

    # test case 4
    assert lookup_run(LookupModule()) == None

    # test case 5
    assert lookup_run(LookupModule()) == None

    # test case 6
    assert lookup_run(LookupModule()) == None

    # test case 7
    assert lookup_run(LookupModule()) == None

    # test case 8
    assert lookup_run(LookupModule()) == None

    # test case 9
    assert lookup_run(LookupModule()) == None

    # test case 10
    assert lookup

# Generated at 2022-06-25 11:10:19.678011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(None)
    assert isinstance(var_1, list)

# Generated at 2022-06-25 11:10:23.456281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    var = lookup_module.run(terms=[])
    assert var == []


# Generated at 2022-06-25 11:10:49.014763
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # var_1 = random.choice(terms)
    # "assert isinstance(var_1,  , msg=None):"
    # "assert var_1.__class__.__name__ ==  , msg=None):"
    var_3 = []
    assert not var_3, 'empty sequence is always false'
    var_2 = lookup_module_0.run(lookup_module_0.terms, var_3)
    # Test "if terms:"

# Generated at 2022-06-25 11:10:53.642854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(terms, inject, **kwargs)
    assert lookup_module_0
    assert ret_0


# Generated at 2022-06-25 11:10:59.652772
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = list()
    var_1.insert(0, "go through the door")
    var_1.insert(1, "drink from the goblet")
    var_1.insert(2, "press the red button")
    var_1.insert(3, "do nothing")
    var_2 = lookup_run(lookup_module_0)
    assert var_2 == "go through the door" or var_2 == "drink from the goblet" or var_2 == "press the red button" or var_2 == "do nothing"

# Generated at 2022-06-25 11:11:05.565321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  var_1 = lookup_module_1.run(terms=lookup_name, inject=var_0)
  var_2 = lookup_module_1.run(terms=None, inject=var_0)
  assert var_1 == ['a', 'b', 'c'] or var_1 == ['a', 'c', 'b']
  assert var_2 is None

# Generated at 2022-06-25 11:11:07.405150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(None)
    assert True

# Generated at 2022-06-25 11:11:11.536616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, [], dict())
    assert len(var_0) == 0
    var_1 = lookup_run(lookup_module_0, [1, 2, 3], dict())
    assert len(var_1) == 1


# Generated at 2022-06-25 11:11:15.405409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['a','b','c']) # should return a,b,or c
    lookup_module_0.run([]) # should return empty list
    lookup_module_0.run(['a',1,'2']) # should return a, 1, or 2

# Generated at 2022-06-25 11:11:17.081962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0.run(terms, inject=None)
  assert True

# Generated at 2022-06-25 11:11:22.732020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert True
#
# def test_case_2():
#     lookup_module_0 = LookupModule()
#
# assert len(lookup_module_0.run(['a', 'b', 'c', 'd', 'e'])) == 1

# Generated at 2022-06-25 11:11:30.906478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [
        {
            'key_0': 'val_0',
            'key_1': 'val_1',
        },
        {
            'key_0': 'val_2',
        },
    ]
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(terms_0)
    assert ret_0 == [
        {
            'key_0': 'val_2',
        },
    ], 'Expected different answer'
    assert type(ret_0) is list, 'Expected a different type'
    assert ret_0[0] is not None, 'Expected a different value'


# Generated at 2022-06-25 11:12:15.993548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([[1, 2, 3, 4]], inject=None) == [3]

# Generated at 2022-06-25 11:12:18.949639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

    # assert that method run of class LookupModule returns None
    assert var_0 is None



# Generated at 2022-06-25 11:12:20.102453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:12:22.463114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  fields = []
  params = {"inject": None, "terms": ""}
  x = LookupModule()
  assert(x.run(fields, params)) == None

# Generated at 2022-06-25 11:12:27.226487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['string_0'])  # AssertionError: assert val == ['string_0']


# Generated at 2022-06-25 11:12:31.125696
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # unit test for run method of class LookupModule
  lookup_module = LookupModule()

  # test with a list of values
  terms = ['A','B','C','D']
  res = lookup_module.run(terms)
  assert len(res) == 1
  assert res[0] in terms

  # test with an empty list
  terms = []
  res = lookup_module.run(terms)
  assert len(res) == 0

# Generated at 2022-06-25 11:12:35.863685
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(None) == None
    assert lookup_module_1.run(None, inject=None) == None
    assert lookup_module_1.run(['a', 'b', 'c']) == ['c']
    assert lookup_module_1.run(['a', 'b', 'c'], inject=None) == ['c']
    assert lookup_module_1.run(['a', 'b', 'c'], **{'kwargs': None}) == ['c']

# Generated at 2022-06-25 11:12:41.498985
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = list()
    terms_1 = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    for var_0 in range(1, 100):
        if var_0 < 50:
            terms_0.append(terms_1)
        else:
            terms_0.append(terms_1.pop())

    inject_0 = None 
    ret_0 = lookup_module_0.run(terms_0, inject=inject_0)
    if type(ret_0) == list:
        print("Testcase 0 passed")
    else: 
        print("Testcase 0 failed")


test_LookupModule_run()
test_case_0()

# Generated at 2022-06-25 11:12:44.352658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['']
    var_0 = lookup_module_0.run(var_0, )
    assert var_0 == []



# Generated at 2022-06-25 11:12:46.735573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms)

# Generated at 2022-06-25 11:14:17.060288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()


# Generated at 2022-06-25 11:14:18.715078
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:14:20.291333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  try:
    i = lookup_module.run(terms)
    if i == None:
      print("True")
    else:
      print("False")
  except Exception as e:
    print("True")


# Generated at 2022-06-25 11:14:28.341420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    terms_0 = list()
    var_1 = lookup_module_0.run(terms_0)
    assert(var_1 == list)
    assert(len(var_1) == 0)

    terms_0 = list()
    var_1 = lookup_module_0.run(terms_0, inject=None)
    assert(var_1 == list)
    assert(len(var_1) == 0)


# Generated at 2022-06-25 11:14:32.373300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    assert lookup_module_0.run(var_0)



# Generated at 2022-06-25 11:14:42.438514
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    print("Testing LookupModule.run...")

    # Create new instance of LookupModule
    lookup_module_0 = LookupModule()

    # Assign parameter terms to a new list
    terms_0 = [None, None]

    # Call method run of LookupModule with parameters terms and inject, expect result __return
    var_0 = lookup_module_0.run(terms_0, None)

    # Check that var_0 is type raw
    print("Checking if var_0 is of type raw...")
    assert isinstance(var_0, raw)
    print("var_0 is of type raw")

    # LookupModule.run(terms, inject, kwargs)

    print("Done.")

# Generated at 2022-06-25 11:14:47.242046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    res = lookup_module.run(["foo", "bar", "baz"], inject=None, **{})
    if not ((res == ["foo"]) or (res == ["bar"]) or (res == ["baz"])):
        raise AssertionError("Unable to pick random term")

# Generated at 2022-06-25 11:14:52.464980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['']
    inject_0 = None
    kwargs_0 = {}
    var_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    assert var_0 is not None
    assert type(var_0) is list
    assert len(var_0) == 1
    assert '' in var_0


# Generated at 2022-06-25 11:14:58.382909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:15:02.731163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_2 = [1, 2, 3, 4]
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms_2)
    assert var_1 == [1]
    lookup_module_2 = LookupModule()
    var_2 = lookup_module_2.run(terms_2)
    assert var_2 == [3]
    lookup_module_3 = LookupModule()
    var_3 = lookup_module_3.run(terms_2)
    assert var_3 == [2]