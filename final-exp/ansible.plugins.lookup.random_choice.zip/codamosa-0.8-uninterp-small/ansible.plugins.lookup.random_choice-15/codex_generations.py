

# Generated at 2022-06-25 11:06:39.675241
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    complex_0 = ["hi", "there"]
    complex_1 = dict()
    for _tmp_0 in range(100):
        complex_1[complex_0] = lookup_module_0.run(complex_0)
    assert_0 = None
    var_0 = lookup_run(assert_0)


# Generated at 2022-06-25 11:06:40.744232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert callable(getattr(LookupModule, "run", None)), "LookupModule does not have required method 'run'"

# Generated at 2022-06-25 11:06:42.965708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    complex_0 = None
    ret = lookup_module_0.run(complex_0)
    assert ret == None

# Generated at 2022-06-25 11:06:51.130362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [{"a": "b"}]
    inject_0 = ""
    kwargs_0 = {}
    var_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    assert var_0 == [{"a": "b"}]
    terms_1 = []
    var_1 = lookup_module_0.run(terms_1, inject_0, **kwargs_0)
    assert var_1 == []

# Generated at 2022-06-25 11:06:53.384578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    complex_0 = None
    var_0 = lookup_module_0.run(complex_0)
    set_0 = None
    var_1 = lookup_module_0.run(set_0)

# Generated at 2022-06-25 11:06:56.565747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_0 = LookupModule()
    complex_0 = []

# Generated at 2022-06-25 11:06:59.416325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    complex_0 = None
    var_1 = lookup_run(lookup_module_0, complex_0)
    set_0 = None
    var_2 = lookup_run(set_0)


# Generated at 2022-06-25 11:07:04.921407
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    complex_0 = None
    var_0 = lookup_run(lookup_module_0, complex_0)
    set_0 = None
    var_1 = lookup_run(set_0)

# Generated at 2022-06-25 11:07:16.428523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    complex_0 = None
    terms_0 = None
    var_2 = lookup_run(lookup_module_0, terms_0)
    msg_0 = "expected type 'Choice', got 'NoneType'"
    assert msg_0 == None, msg_0
    complex_1 = None
    terms_1 = complex_1
    var_2 = lookup_run(lookup_module_0, terms_1)
    msg_1 = "expected type 'Choice', got 'NoneType'"
    assert msg_1 == None, msg_1
    complex_2 = None
    terms_2 = complex_2
    var_2 = lookup_run(lookup_module_0, terms_2)
    msg_2 = "expected type 'Choice', got 'NoneType'"
    assert msg

# Generated at 2022-06-25 11:07:20.051024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert set_0.difference(var_1) == set([])
    assert var_1.difference(set_0) == set([])

# Generated at 2022-06-25 11:07:29.947150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2.0
    lookup_module_1 = lookup_module_0
    var_0 = lookup_run(float_0)
    var_1 = lookup_run(float_0)
    var_2 = lookup_run(float_0)
    var_3 = lookup_run(float_0)
    var_4 = lookup_run(float_0)
    var_5 = lookup_run(float_0)
    var_6 = lookup_run(float_0)



# Generated at 2022-06-25 11:07:35.868511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    terms = [0, 1, 2, 3]
    injec = {'a': 'a', 'b': 'b'}
    kwargs = {'inject': injec, 'terms': terms}
    ret = lookupModule.run(terms, injec, **kwargs)
    assert ret == [0, 1, 2, 3]

# Generated at 2022-06-25 11:07:37.305208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    float_0 = 2.0
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 11:07:39.258636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2.0
    var_0 = lookup_module_0.run(float_0)

# Generated at 2022-06-25 11:07:43.349951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2.0
    var_0 = lookup_run(float_0)
    if var_0 == term:
        print("Success")
    else:
        print("Failure")


# Generated at 2022-06-25 11:07:49.289740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2.0
    lookup_module_var_0 = lookup_module_0.run(float_0)
    assert lookup_module_var_0 == float_0
    assert float_0 == float_0
    assert lookup_module_0.run(float_0) == float_0

# Generated at 2022-06-25 11:07:52.089298
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert True # TODO: implement your test here


# Generated at 2022-06-25 11:07:59.149502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2.0
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 11:08:00.290986
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(TypeError):
        LookupModule.run(None)


# Generated at 2022-06-25 11:08:05.465064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 2.0
    var_0 = lookup_module_0.run(float_0)
    assert var_0 == [0.4831405652713165], "Incorrect return value from LookupModule.run"

# Generated at 2022-06-25 11:08:11.932681
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    terms_1 = terms_0
    terms_0.append("go through the door")
    terms_0.append("drink from the goblet")
    terms_0.append("press the red button")
    terms_0.append("do nothing")
    var_0 = lookup_module_0.run(terms_1)
    assert var_0[0] in ["go through the door", "drink from the goblet", "press the red button", "do nothing"]

# Generated at 2022-06-25 11:08:18.286979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #random.choice(terms)
    lookup_module = LookupModule()
    terms = [1,2,3,4,5]
    assert(lookup_module.run(terms) in terms)

    #with AnsibleError exception
    lookup_module2 = LookupModule()
    terms2 = ["foo", "bar"]
    assert(lookup_module2.run(terms2) == terms2)
    
    lookup_module3 = LookupModule()
    terms3 = []
    assert(lookup_module3.run(terms3) == terms3)

# Generated at 2022-06-25 11:08:24.848378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    
    var_1 = ["foo1","foo2"]
    var_2 = None
    var_3 = {}
    lookup_module_1.run(var_1,var_2,**var_3)

if __name__ == "__main__":
    test_case_0()
    #test_LookupModule_run()

# Generated at 2022-06-25 11:08:27.294523
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 11:08:34.384470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = "r'^[a-z]$'"
    str_1 = "(str_0,)"
    str_2 = "str_2"
    str_3 = "tuple"
    str_4 = "__import__"
    str_5 = "_xrange"
    str_6 = "long"
    str_7 = "FutureWarning"
    tuple_0 = ("item",)
    tuple_1 = ()
    tuple_2 = (tuple_0,)
    tuple_3 = ()
    tuple_4 = (tuple_3,)
    tuple_5 = (tuple_2, str_2, str_3, str_4, str_5, str_6, str_7)
    tuple_6 = (str_1,)
    tuple_7 = (str_0,)
    tuple_

# Generated at 2022-06-25 11:08:35.519570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=['with'])
    assert var_0 == ['with']


# Generated at 2022-06-25 11:08:39.788052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_list = [0, 1]
    lookup_module = LookupModule()
    assert lookup_module.run([], test_list) ==  [] and test_list == [0, 1]

    test_list = [0, 1]
    lookup_module = LookupModule()
    assert lookup_module.run(test_list, []) ==  [0, 1] and test_list == [0, 1]

    lookup_module = LookupModule()
    assert lookup_module.run([0, 1], []) in  [[0], [1]]

    lookup_module = LookupModule()
    assert lookup_module.run([0, 1, 2, 3, 4], []) in [[0], [1], [2], [3], [4]]

# Generated at 2022-06-25 11:08:43.988304
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    assert lookup_module_0.run(var_0) == ['do nothing']

# Generated at 2022-06-25 11:08:45.878749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms)


# Generated at 2022-06-25 11:08:48.431153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule
    var_0 = lookup_run(lookup_module_0)
    if (var_0 == [random.choice(terms)]):
        return True
    else :
        return False

# Generated at 2022-06-25 11:08:56.291113
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:08:58.238583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(lookup_module_1)


# Generated at 2022-06-25 11:09:00.331590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(None)

    # Implementation tests
    assert isinstance(var_0, list)
    assert var_0 == ret
    assert var_0 == []

# Generated at 2022-06-25 11:09:02.819360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['tuple']
    var_0 = lookup_module_0.run(terms_0)


# class used as magic mock in unit test

# Generated at 2022-06-25 11:09:06.382481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["test"])
    assert var_0 == ["test"]
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(["test", "test2"])
    assert var_1 in (["test"], ["test2"])

# Generated at 2022-06-25 11:09:11.826845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    # test exception raise of random.choice
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run([])
    assert 'Unable to choose random term' in str(excinfo.value)
    # test run with correct parameters
    var_0 = lookup_module_1.run([1, 2])
    assert var_0 == [2] or var_0 == [1]

# Generated at 2022-06-25 11:09:16.342461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = []
    var_1 = dict()
    obj_0 = LookupModule()
    ret_0 = obj_0.run(var_0,var_1)
    assert ret_0 == []

# Generated at 2022-06-25 11:09:19.497002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["foo", "bar", "baz"])
    assert var_0 == ["foo"] or var_0 == ["bar"] or var_0 == ["baz"]

# Generated at 2022-06-25 11:09:26.771774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run 'random_choice' lookup on the provided terms

    # Unit:test_case_0
    terms_0 = ['test_20170722_125613', 'test_20170722_130938', 'test_20170722_132048']
    var_5 = lookup_module_0.run(
        terms=terms_0
    )

# Generated at 2022-06-25 11:09:28.401426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_run(lookup_module_0), list)


# Generated at 2022-06-25 11:09:37.588701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:09:43.977044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = "item_0"
    var_2 = lookup_module_0.run(var_1)
    assert var_2 == ["item_0"]
    var_3 = ["item_1", "item_2"]
    var_4 = lookup_module_0.run(var_3)
    assert var_4 == var_3


# Generated at 2022-06-25 11:09:50.635612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(lookup_module_2)
    assert var_2 == 'test_value_3'

# Generated at 2022-06-25 11:10:00.240196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
        "ip=1.2.3.4",
        "org=acme",
        "group=developers",
    ]

    expected_result = [
        "ip=1.2.3.4,org=acme,group=developers",
        "org=acme,ip=1.2.3.4,group=developers",
        "org=acme,group=developers,ip=1.2.3.4",
        "group=developers,org=acme,ip=1.2.3.4",
        "group=developers,ip=1.2.3.4,org=acme",
        "ip=1.2.3.4,group=developers,org=acme",
    ]

    assert len(run(args)) == 6
    assert sorted

# Generated at 2022-06-25 11:10:03.054317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    v0 = []
    v1 = [v0]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(v1)
    assert var_0 == v0


# Generated at 2022-06-25 11:10:04.586333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()


# Generated at 2022-06-25 11:10:07.747364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('var_0')

# Testing method run of class LookupModule for correctness
# AssertionError: Error: Unable to choose random term: 'var_0' is not in list

# Generated at 2022-06-25 11:10:15.589480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([to_text('foo'), to_text('bar')], spy=None, environment={})
    assert len(var_0) == 1
    if var_0 == to_text('foo'):
        print('OK')
    else:
        print('ERR')

# Generated at 2022-06-25 11:10:26.955912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = ['a', 'b']
    var_2 = lookup_run(lookup_module_1, var_1)
    assert isinstance(var_2, list)
    assert len(var_2) == 1
    var_3 = var_2[0]
    if var_3 == 'a':
      assert var_2[0] == 'a'
    elif var_3 == 'b':
      assert var_2[0] == 'b'
    else:
        raise Exception("Test Failed")
    var_4 = lookup_run(lookup_module_1)
    assert isinstance(var_4, list)
    assert len(var_4) == 1
    var_5 = var_4[0]

# Generated at 2022-06-25 11:10:29.536330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_v1 = LookupModule()
    var_v1 = lookup_run(lookup_module_v1)
    assert var_v1 == 1



# Generated at 2022-06-25 11:10:57.292556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = None
    inject = None
    kwargs = None
    ret_0 = lookup_module_0.run(terms, inject, **kwargs)
    if ret_0 != None:
        print("{}".format(ret_0))
    terms = None
    inject = None
    kwargs = None
    ret_0 = lookup_module_0.run(terms, inject, **kwargs)
    if ret_0 != None:
        print("{}".format(ret_0))
    terms = None
    inject = None
    kwargs = None
    ret_0 = lookup_module_0.run(terms, inject, **kwargs)
    if ret_0 != None:
        print("{}".format(ret_0))
    terms = None

# Generated at 2022-06-25 11:11:03.322723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = ['foo', 'bar']
    var_1 = lookup_module_0.run(var_0)
    assert len(var_1) == 1


# Generated at 2022-06-25 11:11:09.509825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [["a", "b", "c"]]
    inject_0 = "inject"
    kwargs_0 = {}
    expected_0 = ["a"]
    actual_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    assert actual_0 == expected_0

# Testing error condition

# Generated at 2022-06-25 11:11:11.265692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:11:16.088731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict()
    args['terms'] = ['a','b','c']
    lookup_module_0 = LookupModule()
    res = lookup_module_0.run(args['terms'])
    assert len(res) == 5
    assert 'a' in res
    assert 'b' in res
    assert 'c' in res
    assert type(res) == type(['a','b','c'])


# Generated at 2022-06-25 11:11:19.966014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert var_0 == "random_choice"

# Generated at 2022-06-25 11:11:21.503088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:11:23.270414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:11:25.426779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    assert var_0 == None

# Generated at 2022-06-25 11:11:29.696394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No parameter passed
    lookup_instance_0 = LookupModule()
    assert isinstance(lookup_instance_0.run(), list)

    # Parameter passed
    lookup_instance_1 = LookupModule()
    lookup_instance_1.run(terms=["N/A"], inject=None)


# Generated at 2022-06-25 11:12:11.014464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    lookup_module_0 = LookupModule()
    terms = [1, 2, 3, 4, 5]

    # Act
    var_1 = lookup_module_0.run(terms,None)

    # Assert
    assert var_1 == [1,2,3,4,5]

# Generated at 2022-06-25 11:12:17.969482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #from ansible.plugins.lookup.random_choice import LookupModule
    lookup_module = LookupModule()
    var = lookup_module.run(terms=['a', 'b', 'c', 'd'])
    assert var[0] in ['a', 'b', 'c', 'd']

# Generated at 2022-06-25 11:12:26.496600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    chosen = {
        "the door": 0,
        "the goblet": 0,
        "the red button": 0,
        "nothing": 0
    }
    terms = ["the door", "the goblet", "the red button", "nothing"]

    for i in range(0, 10000):
        lookup_module_0 = LookupModule()
        var_0 = lookup_module_0.run(terms, None)
        chosen[var_0[0]] += 1

    for k, v in chosen.items():
        print("%s was chosen %d times" % (k, v))

# Generated at 2022-06-25 11:12:29.595868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_0 = []
    var_0 = lookup_module_0.run(arg_0)
    assert len(var_0) == 0



# Generated at 2022-06-25 11:12:36.536372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("HERE")
    lookup_module_0 = LookupModule()

    var_0 = lookup_module_0.terms = ["a", "b", "c", "d"]

    var_1 = lookup_module_0.run(var_0)

    var_2 = lookup_module_0.results

# Generated at 2022-06-25 11:12:39.035107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1,2,3]
    inject = None
    kwargs = {'a':1, 'b':2}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, inject, kwargs)
    # assert var_0
    assert True

# Generated at 2022-06-25 11:12:42.455504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_0 = LookupModule()
   var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:12:53.334693
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Pick some random items from the list

    # 5 Items was too a small number to showcase randomness.
    # 10 Items was too small to showcase randomness.
    # 15 Items was too small to showcase randomness.
    # 16 Items is still too small to showcase randomness.
    # 32 Items ensure that every item as been picked at least once.
    some_items = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G']
    expected_result = {"_raw": "r"}


# Generated at 2022-06-25 11:12:57.788790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 'msg' in var_0
    assert var_0['msg'] == 'drink from the goblet' or var_0['msg'] == 'do nothing' or var_0['msg'] == 'go through the door' or var_0['msg'] == 'press the red button'


# Generated at 2022-06-25 11:13:04.378664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_terms_0 = ["item_0", "item_1", "item_2", "item_3", "item_4", "item_5", "item_6", "item_7", "item_8", "item_9", "item_10", "item_11", "item_12", "item_13", "item_14", "item_15", "item_16", "item_17", "item_18", "item_19", "item_20", "item_21", "item_22", "item_23", "item_24", "item_25", "item_26", "item_27", "item_28", "item_29"]
    lookup_run(lookup_module_0, terms=test_terms_0)

# Generated at 2022-06-25 11:14:36.542010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L_0 = LookupModule()
    assert L_0.run([]) == []

    from ansible.errors import AnsibleError
    data = [
        {'foo': 'bar', 'baz': "qux"},
        {'foo': 'bar', 'baz': "qux"},
        {'foo': 'bar', 'baz': "qux"},
        {'foo': 'bar', 'baz': "qux"},
        {'foo': 'bar', 'baz': "qux"},
    ]
    L_1 = LookupModule()
    assert len(L_1.run(data)) == 1

# Generated at 2022-06-25 11:14:41.529207
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(None)
    assert isinstance(var_0, list)
    var_1 = lookup_module_0.run([])
    assert isinstance(var_1, list)
    var_2 = lookup_module_0.run([u'foo'])
    assert isinstance(var_2, list)

# Generated at 2022-06-25 11:14:44.407325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:14:54.381708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert len(var_0) > 0
    assert len(var_0) > 0
    assert len(var_0) <= 10
    assert len(var_0) <= 10
    assert len(var_0) > 1
    assert len(var_0) > 1
    assert len(var_0) > 20
    assert len(var_0) > 20
    assert len(var_0) == 40
    assert len(var_0) == 40
    assert len(var_0) <= 20
    assert len(var_0) <= 20
    assert len(var_0) > 10
    assert len(var_0) > 10
    assert len(var_0) <= 30

# Generated at 2022-06-25 11:15:03.627045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Random choice on a empty list
    lookup_module_0 = LookupModule()
    var_0 = []
    var_1 = {}
    ret_0 = lookup_module_0.run(var_0, var_1)
    # Should be an empty list
    ret_1 = []
    assert ret_0 == ret_1
    # Random choice on a multi element list
    lookup_module_1 = LookupModule()
    var_2 = [0, 1, 2, 3, 4]
    var_3 = {}
    ret_2 = lookup_module_1.run(var_2, var_3)
    # Should be a single element list
    ret_3 = [2]
    assert ret_2 == ret_3
    # Random choice on a single element list
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 11:15:05.536704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ['drink from the goblet']

# Generated at 2022-06-25 11:15:11.310917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, [["str"]], [])
    assert var_0 == ["str"]


# Generated at 2022-06-25 11:15:14.336285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    var_1 = ['a', 'b']
    var_2 = {'a': 'a', 'b': 'b'}
    assert lookup_module_0.run(var_1, var_2) == ['a', 'b']

# Generated at 2022-06-25 11:15:17.422433
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = [1, 2, 3]
    assert lookup_module_0.run(var_0) is None

# Generated at 2022-06-25 11:15:26.033122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    v_0 = [
        'go through the door',
        'drink from the goblet',
        'press the red button',
        'do nothing'
    ]
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(v_0)
    var_1 = length(var_0)
    assert var_1 == 1
    var_2 = var_0[0]
    printing('var_2', var_2)
    printing('v_0', v_0)
    var_3 = var_2 in v_0
    var_4 = assert_equal(var_3, True)
