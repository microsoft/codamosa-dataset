

# Generated at 2022-06-25 11:06:38.524936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = [0]
    str_1 = 'sgdvT'
    dict_1 = {str_1: str_1}
    lookup_module_1 = LookupModule(**dict_1)
    var_1 = lookup_run(list_1)


# Generated at 2022-06-25 11:06:41.895962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    str_0 = 'WzN=Z'
    dict_0 = {str_0: str_0}
    lookup_module_0 = LookupModule(**dict_0)
    assert lookup_module_0.run(list_0) == None

# Generated at 2022-06-25 11:06:51.693747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_anonymous_0():
        try:
            rnd_0 = random.SystemRandom()
            terms_0 = [rnd_0.choice(str_0) for i in range(rnd_0.randint(0, 1000))]
            str_1 = 'WzN=Z'
            dict_0 = {str_1: str_1}
            lookup_module_0 = LookupModule(**dict_0)
            lookup_module_0.run(terms_0)
        except Exception as e_0:
            list_0 = [terms_0, str_1, dict_0, lookup_module_0, e_0]
            test_anonymous_0.__class__ = str_1



# Generated at 2022-06-25 11:06:58.186810
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = []
    dict_1 = {}
    lookup_module_1 = LookupModule(**dict_1)
    assert_equal(lookup_module_1.run(list_1), list_1)
    list_2 = ['PpOuIJirnzD']
    dict_2 = {}
    lookup_module_2 = LookupModule(**dict_2)
    assert_not_equal(lookup_module_2.run(list_2), list_2)
    list_3 = ['nWgJtT', 'fTlTm']
    dict_3 = {}
    lookup_module_3 = LookupModule(**dict_3)
    assert_not_equal(lookup_module_3.run(list_3), list_3)

# Generated at 2022-06-25 11:07:10.423891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_3 = []
    list_3.append(list_3)
    str_0 = 'WzN=Z'
    dict_0 = {str_0: str_0}
    lookup_module_0 = LookupModule(**dict_0)
    lookup_module_0.run(list_3)
    list_2 = []
    list_2.append(list_2)
    str_1 = 'WzM=Z'
    dict_1 = {str_1: str_1}
    lookup_module_1 = LookupModule(**dict_1)
    lookup_run(list_2)
    list_1 = []
    list_1.append(list_1)
    str_2 = 'WzM=Z'
    dict_2 = {str_2: str_2}


# Generated at 2022-06-25 11:07:12.367284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args_0 = [None, None, None]
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 11:07:17.714627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    input_0 = "terms"
    terms = input_0
    lookup_module_0.run(**terms)



# Generated at 2022-06-25 11:07:25.349624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule(**{})
    var_0 = lookup_module_0.run(list_0)
    assert len(var_0) == 0
    assert var_0[0] == list_0
    assert var_0[0] == list_0
    assert var_0[0] == list_0
    assert var_0[0] == list_0
    assert var_0[0] == list_0
    assert var_0[0] == list_0
    assert var_0[0] == list_0
    assert var_0[0] == list_0
    assert var_0[0] == list_0
    assert var_0[0] == list_0
    assert var_0[0] == list_0
    assert var_0

# Generated at 2022-06-25 11:07:26.596356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 0
    test_case_0()



# Generated at 2022-06-25 11:07:34.849101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(**{'loader': '', 'fail_on_undefined_lookup': True, 'vars': '', 'run_once': True})
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    list_0 = [lookup_module_0]
    list_1 = [lookup_module_1]
    list_2 = [lookup_module_2]
    dict_0 = {'list_0': list_0, 'list_1': list_1, 'list_2': list_2}
    str_0 = 'e'
    lookup_module_3 = LookupModule(**dict_0)
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    dict_1

# Generated at 2022-06-25 11:07:39.487015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test of method run of class LookupModule
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 11:07:42.194796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 11:07:47.373017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    # Test method run of class LookupModule with arguments:
    # var_0 = [True, False]
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 11:07:57.118978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    list_0 = [ "", "", "", "", "" ]
    str_0 = "K9on<y^P&2vUdW(U8?F_sjKw$=v0'lo}8$oYT9@yK3Au}x"
    def test_run_0(self):
        self.assertEqual(self.bool_0, self.lookup_module_0.run(self.list_0, None, None))

    def test_run_1(self):
        self.assertEqual(self.str_0, self.lookup_module_0.run(self.list_0, None, None))


# Generated at 2022-06-25 11:08:01.943277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        assert True
    except:
        lookup_module_0 = LookupModule()
        with pytest.raises(AnsibleError) as excinfo:
            lookup_module_0.run()
        assert 'Unable to choose random term:' in str(excinfo.value)

# Generated at 2022-06-25 11:08:04.282664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    list_0 = list()
    lookup_module_0 = LookupModule()
    list_1 = lookup_run(bool_0)
    assert list_1 == list_0


# Generated at 2022-06-25 11:08:05.286151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = LookupModule.run(True, [], [])


# Generated at 2022-06-25 11:08:06.724322
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "terms"
    lookup_module_0.run(terms_0)


# Generated at 2022-06-25 11:08:12.077574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    list_0 = lookup_module_0.run(bool_0)
    var_0 = bool_0
    var_0 = list_0
    var_1 = lookup_module_0.run(list_0)
    var_2 = list_0
    var_2 = var_1
    #assert( var_1 == var_2)


# Generated at 2022-06-25 11:08:16.582762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mylist = ['apple', 'banana', 'cherry', 'durian']
    terms = mylist
    inject = None
    kwargs = {}
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, inject, **kwargs)


# Generated at 2022-06-25 11:08:25.875090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # If condition 0, do nothing
    # If condition 1, do nothing
    # If condition 2, do nothing
    # If condition 3, do nothing


# Generated at 2022-06-25 11:08:34.382287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Accessing module_utils.basic.AnsibleModule's member
    ansible_module_0 = Basic.AnsibleModule(argument_spec=None, bypass_checks=False, check_invalid_arguments=None, mutually_exclusive=None, no_log=False, required_together=None, supports_check_mode=False)
    lookup_module_0 = LookupModule()
    # Accessing module_utils.basic.AnsibleModule's member
    lookup_module_0.get_bin_path = ansible_module_0.get_bin_path
    lookup_module_0.run = ansible_module_0.run
    terms = None
    inject = None
    # Accessing module_utils.basic.AnsibleModule's member
    lookup_module_0.params = ansible_module_0.params


# Generated at 2022-06-25 11:08:38.689372
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 11:08:45.248002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    ret_0 = lookup_module_0.run(bool_0)
    if ret_0:
        bool_1 = True
    else:
        bool_1 = False
    assert bool_1

# Generated at 2022-06-25 11:08:48.137193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class_0 = LookupModule()
    lookup_module_0 = LookupModule()
    test_case_0(class_0, lookup_module_0)

# Generated at 2022-06-25 11:08:50.919300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = False
    var_1 = []
    var_2 = {}
    var_3 = test_LookupModule_instance()
    try:
        var_3.run(var_0,var_1,var_2)
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 11:08:55.457835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 11:08:57.636285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 11:08:59.894610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  ret_0 = lookup_module_0.run(["a","b","c"])
  assert len(ret_0) == 1

# Generated at 2022-06-25 11:09:03.393993
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    terms_1 = []
    lookup_module_2 = LookupModule()
    lookup_module_2.run(terms_1)
    terms_3 = [0]
    lookup_module_2.run(terms_3)
    lookup_module_2.run([0, 1])

# Generated at 2022-06-25 11:09:16.004798
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    True
    # State whether true or false

    ##
    #
    # Assertion method
    #
    #

# Generated at 2022-06-25 11:09:19.184037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # The following statements will be used to test run method
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(arg1_terms)
    var_1 = lookup_module_0.run(arg1_terms, arg2_inject)

# Generated at 2022-06-25 11:09:24.401162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    dict_0 = dict()
    var_0 = lookup_module_0.run(list_0, dict_0)

# Generated at 2022-06-25 11:09:31.464444
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Good
    yml1 = 'good_test.yml'
    bool_0 = True
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0)
    print(var_0)

    # Bad - bool_0 is None
    yml1 = 'bad_test.yml'
    bool_0 = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0)
    print(var_0)

    # Bad - bool_0 is an empty list
    yml1 = 'bad_test.yml'
    bool_0 = []
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 11:09:36.428246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run("")


# Generated at 2022-06-25 11:09:37.329972
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert False



# Generated at 2022-06-25 11:09:43.471692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = "str"
    int_1 = 1
    str_2 = "str"
    int_2 = 1
    str_3 = "str"
    int_3 = 1
    str_4 = "str"
    int_4 = 1
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(str_1, int_1, str_2, int_2, str_3, int_3, str_4, int_4)
    var_1 = bool(var_0)
    bool_1 = True
    assert var_1 == bool_1


# Generated at 2022-06-25 11:09:47.785075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # Setup arguments and test object
  foo = "bar"
  kwargs = {"foo": foo}
  self = LookupModule(kwargs)
  terms = "terms"
  inject = "inject"
  # Invoke method
  result = self.run(terms , inject)
  # Check for collision with default args
  assert "inject" not in kwargs, "inject in kwargs"
  # Return value
  return result

# Generated at 2022-06-25 11:09:49.050427
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_1 = True
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(bool_1)

# Generated at 2022-06-25 11:09:57.410748
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create object of LookupModule class
    lookup_module_0 = LookupModule()
    # Call method run of class LookupModule with arguments
    # and assert value
    assert lookup_module_0.run() == [ansible.errors.AnsibleError]
    assert lookup_module_0.run() == [random.choice]
    assert lookup_module_0.run() == [ansible.errors.AnsibleError]
    assert lookup_module_0.run() == [random.choice]
    assert lookup_module_0.run() == [None]

# Generated at 2022-06-25 11:10:26.114934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # try it with an empty list
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([], dict())
    assert var_0 == [], var_0

    # try it with a list of one item
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(['a'], dict())
    assert var_1 == ['a'], var_1

    # try it with a list of two items, run it twice
    # and see if they're different
    lookup_module_2 = LookupModule()
    var_2 = lookup_module_2.run(['a', 'b'], dict())
    var_3 = lookup_module_2.run(['a', 'b'], dict())

# Generated at 2022-06-25 11:10:28.009312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])


# Generated at 2022-06-25 11:10:31.997475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


# Boilerplate code to allow this to be a standalone script
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 11:10:39.946430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["terms_0", "terms_1", "terms_2"]
    inject_0 = mocker.sentinel.inject_0
    var_0 = lookup_module_0.run(terms_0, inject=inject_0)
    assert var_0 == lookup_module_0.run(terms_0, inject=inject_0)
    assert var_0 == ["terms_0", "terms_1", "terms_2"]
    lookup_module_1 = LookupModule()
    terms_1 = ["terms_0", "terms_1", "terms_2"]
    inject_1 = mocker.sentinel.inject_1
    var_1 = lookup_module_1.run(terms_1, inject=inject_1)
    assert var

# Generated at 2022-06-25 11:10:41.525842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run('foo')
    assert var_1 == ['foo']


# Generated at 2022-06-25 11:10:44.329909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    terms_0 = {}
    var_1 = lookup_run(lookup_module_2, terms_0)

    #assert var_1 ==

# Generated at 2022-06-25 11:10:55.053990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_1 = LookupModule()
  lookup_module_1.original_terms = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "s", "t", "u", "v", "w", "x", "y", "z"]
  lookup_module_1.playbook_dir = "/root/git/ansible/examples/ansible_collections/azure/azcollection/playbook.yml"
  c = lookup_module_1.run()

# Generated at 2022-06-25 11:10:58.188938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)
    if type(var) is not list:
        raise AssertionError(var)

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-25 11:11:02.697753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(lookup_module_0)

# Generated at 2022-06-25 11:11:13.433854
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def test_case_1():
        lookup_module_1 = LookupModule()
        var_1 = lookup_run(lookup_module_1)
        assert var_1 == [terms[1]]

    def test_case_2():
        lookup_module_2 = LookupModule()
        var_2 = lookup_run(lookup_module_2)
        assert var_2 == [terms[1]]

    def test_case_3():
        lookup_module_3 = LookupModule()
        var_3 = lookup_run(lookup_module_3)
        assert var_3 == [terms[1]]

    def test_case_4():
        lookup_module_4 = LookupModule()
        var_4 = lookup_run(lookup_module_4)
        assert var_4 == [terms[1]]

# Generated at 2022-06-25 11:11:56.520990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_1 = ['']
    var_2 = {}
    lookup_module_1 = LookupModule()
    var_3 = lookup_module_1.run(var_1, inject=var_2)

# Generated at 2022-06-25 11:11:58.825617
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == True

# Generated at 2022-06-25 11:12:04.409518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ret

# Generated at 2022-06-25 11:12:09.091705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert type(var_0) == list
    assert var_0 == ['drink from the goblet']


# Generated at 2022-06-25 11:12:12.830047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['foo']
    dict_0 = {'a': 'A', 'b': 'B'}
    with pytest.raises(AnsibleError):
        var_0 = lookup_module_0.run(list_0, dict_0)


# Generated at 2022-06-25 11:12:15.962417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:12:18.355825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == random.choice(terms)


# Generated at 2022-06-25 11:12:29.278611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()

    # test for case "random_choice: [ 'a', 'b', 'c' ]"
    var_0 = [ 'a', 'b', 'c']
    var_0 = lookup_module_0.run(var_0)
    var_1 = ['a', 'b', 'c']
    assert var_0 in var_1

    # test for case "random_choice: [ 'a', 'b', 'c', "d' ]"
    var_0 = [ 'a', 'b', 'c', 'd']


# Generated at 2022-06-25 11:12:31.566505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])


# Generated at 2022-06-25 11:12:33.647751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == 'foo', "var_0 == lookup_run()"

# Generated at 2022-06-25 11:13:57.566290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_run(term_0, inject=0) == term_1

# Generated at 2022-06-25 11:14:05.753883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ["go through the door"], "Test 1 of method run of class LookupModule failed"
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ["go through the door"], "Test 2 of method run of class LookupModule failed"
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 == ["drink from the goblet"], "Test 3 of method run of class LookupModule failed"
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:14:09.477150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    run_method_var = lookup_module_0.run()
    assert run_method_var == None

# Generated at 2022-06-25 11:14:18.530209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup mock ansible_module_utils.basic.AnsibleModule.run_command
    with patch.object(ansible_module_utils.basic.AnsibleModule, 'run_command', autospec=True) as mock_run_command:

        # Setup test parameters
        terms = 'alien'

        # Instantiate a class for testing Ansible lookup plugin 'random_choice'
        lookup_module_2 = LookupModule()

        # Invoke method run of class LookupModule
        result = lookup_module_2.run(terms)

        # Check if the result is as expected
        assert result == ['alien']

        mock_run_command.assert_not_called()

# Generated at 2022-06-25 11:14:25.115501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = random.choice(['go through the door', 'press the red button', 'drink from the goblet',
                           'do nothing'])

    lookup_module_0 = LookupModule()

    assert lookup_module_0.run(['go through the door', 'press the red button', 'drink from the goblet',
                                'do nothing'])

    assert lookup_module_0.run(['go through the door', 'press the red button', 'drink from the goblet',
                                'do nothing']) == [var_0]


# Generated at 2022-06-25 11:14:27.476323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = "null"
    var_0 = lookup_module_0.run(terms_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 11:14:29.407017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:14:31.074754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, terms = '')
    assert var_0 == ''

# Generated at 2022-06-25 11:14:33.327043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  var = lookup_module.run('abcd')
  assert 'a' in var
  assert 'b' in var
  assert 'c' in var
  assert 'd' in var

# Generated at 2022-06-25 11:14:39.541927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a fixed seed to ensure consistent results every time.
    random.seed(123)

    assert lookup_run([1, 2, 3]) == [1]
    assert lookup_run([1, 2, 3]) == [2]
    assert lookup_run([1, 2, 3]) == [2]
    assert lookup_run([1, 2, 3]) == [3]
    assert lookup_run([1, 2, 3]) == [1]
    assert lookup_run([1, 2, 3]) == [3]
    assert lookup_run([1, 2, 3]) == [2]
    assert lookup_run([1, 2, 3]) == [1]
    assert lookup_run([1, 2, 3]) == [3]
    assert lookup_run([1, 2, 3]) == [3]