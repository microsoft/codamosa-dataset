

# Generated at 2022-06-25 11:06:42.273946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = None
    str_1 = ""
    str_2 = "m"
    list_0 = ['o']
    ret_1 = [False]
    ret_2 = [1]
    ret_3 = [0.0]
    ret_4 = [random.choice(list_0)]
    lookup_module_0 = LookupModule(str_0)
    lookup_module_0.get_basedir = MagicMock(return_value=str_0)
    lookup_module_0.run(list_0, terms=None)

    lookup_module_0.run(ret_1, terms=None)

    lookup_module_1 = LookupModule(str_0)
    lookup_module_1.run(ret_2, terms=None)


# Generated at 2022-06-25 11:06:49.127548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule. 
    '''
    lookup_module_0 = LookupModule()
    str_0 = None
    dict_0 = {str_0: str_0}
    str_1 = lookup_module_0.run(None, None, **dict_0)

# Test function without docstring

# Generated at 2022-06-25 11:06:55.247601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_2 = lookup_module_0
    list_0 = [None]
    dict_0 = {None: None}
    dict_1 = dict_0
    dict_2 = dict_1
    dict_3 = dict_2
    dict_4 = dict_3
    dict_5 = dict_4
    dict_6 = dict_5
    dict_7 = dict_6
    dict_8 = dict_7
    dict_9 = dict_8
    dict_10 = dict_9
    dict_11 = dict_10
    dict_12 = dict_11
    dict_13 = dict_12
    dict_14 = dict_13
    dict_15 = dict_14
    dict_16 = dict_15
    dict_17 = dict_16
   

# Generated at 2022-06-25 11:06:56.963708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = None
    terms_0 = str_0
    inject_0 = lookup_module_0.run(terms_0)
    return


# Generated at 2022-06-25 11:06:59.415747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule(None)
  terms = None
  inject = None
  kwargs = None
  x = lookup_module_0.run(terms,inject,kwargs)
  return x == None


# Generated at 2022-06-25 11:07:04.924177
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = None
    list_0 = [str_0]
    dict_0 = {str_0: str_0}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run(list_0)

# Generated at 2022-06-25 11:07:09.496297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Call method 'run'
    lookup_module_0.run()

# Generated at 2022-06-25 11:07:14.288624
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = None
    dict_0 = {str_0: str_0}
    lookup_module_0.run(str_0, inject=dict_0)
    lookup_module_0.run(str_0, dict_0)


# Generated at 2022-06-25 11:07:16.857748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    str_0 = "ansible.plugins.lookup.random_choice"
    ret_0 = lookup_module_0.run(["random_choice"], None)
    assert ret_0 == str_0

# Generated at 2022-06-25 11:07:21.272576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = None
    #dict_0 = {str_0: str_0}
    #lookup_module_0 = LookupModule(dict_0)
    lookup_module_0 = LookupModule()
    terms = ["test1", "test2"]
    print(lookup_module_0.run(terms, None))

# Generated at 2022-06-25 11:07:32.496988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    lookup_module_0 = LookupModule(dict_0)

    int_0 = random.randint(1, 100)
    for int_1 in range(int_0):
        boolean_0 = bool(int_1 % 2)
        if (not boolean_0):
            dict_0['lookup_module_0'] = lookup_module_0
            str_0 = 'lookup_module_0'
            dict_0[str_0] = str_0

    dict_0[int_0] = int_0
    dict_0['int_1'] = int_1
    terms_0 = set(dict_0)
    terms_0.pop()
    lookup_module_0.run(terms_0, dict_0)
    assert dict_0['str_0'] == str

# Generated at 2022-06-25 11:07:33.784221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    tuple_0 = (1, )
    lookup_module_0.run(tuple_0, {}, {})

# Generated at 2022-06-25 11:07:36.396086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = dict_0
    lookup_module_0 = LookupModule(dict_0)
    arg_0 = [list()]
    arg_1 = dict_1
    lookup_module_0.run(arg_0, arg_1)

# Generated at 2022-06-25 11:07:38.334652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    list_1 = lookup_module_0.run(list_0)

# Generated at 2022-06-25 11:07:49.669937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:07:53.284360
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = "ansible-lookup"
    inject = dict()
    kwargs = dict()
    lookup_module_0 = LookupModule()

    assert lookup_module_0.run(terms, inject, **kwargs) == ansible-lookup

# Generated at 2022-06-25 11:07:54.339140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule.run(LookupModule)


# Generated at 2022-06-25 11:07:56.153967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    lookup_module_0.run(None, None)


# Generated at 2022-06-25 11:07:59.822559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['3', '2', '5', '2']) == ['2']
    assert lookup_module_0.run(['0']) == ['0']


# Generated at 2022-06-25 11:08:02.288463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arg1
    terms = ["test_0", "test_1", "test_2"]
    # Arg2
    inject = None
    lookup_module_1 = LookupModule({})
    assert isinstance(lookup_module_1.run(terms, inject), list)


# Generated at 2022-06-25 11:08:09.566486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    

# Generated at 2022-06-25 11:08:20.184737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = lookup_module_0
    assert var_1 is not None, "lookup_module_0"
    var_2 = lookup_module_0
    assert isinstance(var_2, LookupModule), "type(lookup_module_0)"
    assert var_2 is not None, "lookup_module_0"
    var_3 = lookup_module_0
    var_4 = lookup_module_0
    var_5 = lookup_module_0
    var_6 = lookup_module_0
    var_7 = lookup_module_0
    var_8 = lookup_module_0
    assert_equals(var_8, 1)
    var_9 = lookup_module_

# Generated at 2022-06-25 11:08:24.319822
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["1", "2", "3"]) != []

# Generated at 2022-06-25 11:08:28.460282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a random list
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0, ['first','second','third','fourth','fifth','sixth','seventh'])
    assert lookup_run(lookup_module_0, ['first','second','third','fourth','fifth','sixth','seventh']) != ['first','second','third','fourth','fifth','sixth','seventh']


# Generated at 2022-06-25 11:08:31.203309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random_list = [0, 1, 2, 3, 4]

    lookup_module = LookupModule()
    random_choice = lookup_run(lookup_module, random_list)

    assert random_choice in random_list


# Boilerplate method to run test

# Generated at 2022-06-25 11:08:34.138344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = "terms"
    var_0 = lookup_module_0.run(terms)
    var_0 = lookup_module_0.run(terms)
    var_0 = lookup_module_0.run(terms)

# Generated at 2022-06-25 11:08:38.953573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 is not None


# Generated at 2022-06-25 11:08:45.583873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_unittest = ["test_0", "test_1"]
    assert True

    # Check if the return str is equal to one of the list
    ret_str = run(list_unittest, inject=None)
    assert ret_str in list_unittest



# Generated at 2022-06-25 11:08:47.928728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  terms = ['one', 'two', 'three']
  lookup_terms = [terms]
  val = lookup_module.run(lookup_terms)
  assert val in terms

# Generated at 2022-06-25 11:08:49.812153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=terms, inject=inject)
# vim: foldmethod=marker

# Generated at 2022-06-25 11:08:58.450057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = random.random()
    var_1 = lookup_module_0.run([str(var_0)])
    var_2 = list()
    var_2.append(str(var_0))
    print(var_1 == var_2)


# Generated at 2022-06-25 11:09:00.418682
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([
        'x'])


# Generated at 2022-06-25 11:09:01.633330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_run('')

# Generated at 2022-06-25 11:09:05.685478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    var_1 = list()
    var_1.append("go through the door")
    var_1.append("drink from the goblet")
    var_1.append("press the red button")
    var_1.append("do nothing")
    assert var_0 == var_1

# Generated at 2022-06-25 11:09:08.525240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms=[], inject=None, kwargs=None)
    print('var_0 =', var_0)


# Generated at 2022-06-25 11:09:13.725065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit tests for method run of class LookupModule
    lookup_module_0 = LookupModule()
    var_2 = [lookup_module_0, 'lookup_module_0', None, 2]
    var_3 = list()
    var_3.append(var_2)
    var_3.append(2)
    var_4 = lookup_module_0.run(var_3)
    assert len(var_4) == 1
    assert var_4[0] == var_2

# Generated at 2022-06-25 11:09:15.921471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)
    assert var_0 is None

# Generated at 2022-06-25 11:09:17.131701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert len(var_0) == 1

# Generated at 2022-06-25 11:09:19.906016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = ['B', 'A', 'C']
    var_2 = lookup_module_0.run(var_1)
    assert var_2 == lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:09:25.961564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [0]
    var_2 = {}
    var_3 = lookup_run(lookup_module_0, var_1, var_2)

# Generated at 2022-06-25 11:09:37.587236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []


# Generated at 2022-06-25 11:09:38.147339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:09:40.427390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=[1, 2, 3])
    lookup_module_1.run(inject=[1, 2, 3])
    lookup_module_1.run(terms=[1, 2, 3], inject=[1, 2, 3])
    test_case_0()

# Generated at 2022-06-25 11:09:46.337099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_args_0 = {'terms': [1, 2, 3]}
    lookup_module_ret_0 = lookup_module_0.run(**lookup_module_args_0)
    assert_equal(lookup_module_ret_0, [1, 2, 3])



# Generated at 2022-06-25 11:09:49.927979
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  test_case = dict()
  test_case[0] = dict()

  lookup_module_0 = LookupModule()
  try:
    term_0 = test_case[0]
    try:
      lookup_module_0.run(term_0)
    except Exception as err:
      print(err)
  except Exception as err:
    print(err)
  print('test_case 0: OK')

# Generated at 2022-06-25 11:09:59.857803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_0():
        lookup_module_0 = LookupModule()
        var_0 = [
            {
                'msg': 'go through the door',
            },
            {
                'msg': 'drink from the goblet',
            },
            {
                'msg': 'press the red button',
            },
            {
                'msg': 'do nothing',
            },
        ]
        var_1 = lookup_run(lookup_module_0)
        assert var_1 == var_0
    def test_1(self):
        lookup_module_0 = LookupModule()
        lookup_module_0._templar = MagicMock()
        var_0 = lookup_run(lookup_module_0)
        assert var_0 == 'A'

# Generated at 2022-06-25 11:10:08.173908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([])
    if var_0 != []:
        raise RuntimeError("Expected None, got {}".format(var_0))
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(["foo", "bar", "baz"])
    if var_0 not in (["foo"], ["bar"], ["baz"]):
        raise RuntimeError("Expected ([\"foo\"], [\"bar\"], [\"baz\"]), got {}".format(var_0))
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(["foo", "bar", "baz"])

# Generated at 2022-06-25 11:10:14.240483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run = [random.choice("This is a test")]
    assert lookup_module.run == [random.choice("This is a test")]

# Generated at 2022-06-25 11:10:16.537466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:10:22.618847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert (type(lookup_module) is LookupModule)
    lookup_run = lookup_module.run()
    assert (type(lookup_run) is tuple)
    lookup_run = lookup_module.run([])
    assert (type(lookup_run) is list)

# Generated at 2022-06-25 11:10:44.134949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(terms=var_0)
    assert var_1 == var_0

# Generated at 2022-06-25 11:10:45.896386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:10:47.321878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x_0 = []
    results_0 = LookupModule.run(x_0)
    assert results_0 == x_0

# Generated at 2022-06-25 11:10:51.581490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])

# Generated at 2022-06-25 11:10:59.086766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["baz", "bar", "foo"]
    parameters = {}
    # magic number 1
    if random.random() < 0.5:
        parameters["inject"] = None
    else:
        parameters["inject"] = {}
    parameters["test_parameter"] = "test_value"
    result = lookup_module_0.run(terms, **parameters)
    assert type(result) == list
    var_2 = result[0]
    assert type(var_2) == str
    assert var_2 in ["baz", "bar", "foo"]
    assert len(result) == 1


# Generated at 2022-06-25 11:11:05.994911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run("") == []
    assert lookup_module_1.run([1, 2, 3]) == [3]
    assert lookup_module_1.run(["foo", "bar", "baz"]) in [["foo"], ["bar"], ["baz"]]
    assert lookup_module_1.run(["one", "two", "three"]) in [["one"], ["two"], ["three"]]

# Generated at 2022-06-25 11:11:08.516580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    v = lookup_module.run(["a", "b", "c"])
    assert v == ["a"] or v == ["b"] or v == ["c"]

# Generated at 2022-06-25 11:11:14.334392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [
        [
            'a',
        ],
        [
            'b',
        ],
        [
            'c',
        ]
    ]
    # (used by Ansible)
    lookup_module_0 = LookupModule()
    look_0 = lookup_module_0.run(terms_0)
    if look_0 != None:
        assert 1, "unexpected output {} should be None".format(look_0)

# Test cases for class LookupModule

# Generated at 2022-06-25 11:11:17.412107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with missing args
    result = lookup_module_0.run()
    assert [] == result

    # Test with valid args
    terms_0 = []
    result = lookup_module_0.run(terms_0)
    assert [] == result

# Generated at 2022-06-25 11:11:21.048391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Get length of available choices list
    var_0 = len(lookup_module_0.run())

    # Randomly generate index for choice
    var_1 = random.randint(0, var_0 - 1)

    # Pick random choice from available choices
    var_2 = lookup_module_0.run()[var_1]

    # Return random choice
    return var_2


if __name__ == '__main__':
    print(test_LookupModule_run())

# Generated at 2022-06-25 11:12:00.136616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No return value; don't test
    pass

# Generated at 2022-06-25 11:12:04.829848
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup test case
    test_case_0()
    # Teardown test case
    # No teardown needed

if __name__ == '__main__':
    test_lookup_module()

# Generated at 2022-06-25 11:12:10.669174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = {
      "item": "go through the door",
    }
    var_1 = {
      "item": "press the red button",
    }
    var_2 = {
      "item": "drink from the goblet",
    }
    var_3 = {
      "item": "do nothing",
    }

# Generated at 2022-06-25 11:12:15.019805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run



# Generated at 2022-06-25 11:12:21.307893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert lookup_module.run([1,2,3,4,5],inject=None,**{}) == [1,2,3,4,5]
    assert lookup_module.run(['foo','bar','baz'],inject=None,**{}) in [['foo'], ['bar'], ['baz']]

# Generated at 2022-06-25 11:12:28.486631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  assert lookup_module.run(["a", "b", "c"]) == ["a"]
  assert lookup_module.run(["a", "b", "c"]) == ["b"]
  assert lookup_module.run(["a", "b", "c"]) == ["c"]
  assert lookup_module.run(["a", "b", "c"]) == ["a"]

# Generated at 2022-06-25 11:12:30.671040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        var_0 = lookup_run(lookup_module_0)
    except Exception as exception_instance:
        # assert the exception here

        # cleanup the test
        return

    # cleanup the test
    return


# Generated at 2022-06-25 11:12:36.883156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = lookup_module_0.run(['a', 'b', 'c'], dict(a=1, b=2, c=3))
    assert var_1 == ['a'] and var_1 == ['b'] and var_1 == ['c']

# Generated at 2022-06-25 11:12:38.591398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(['azure'])

    lookup_module_1 = LookupModule()
    lookup_module_1.run(['digital'])

# Generated at 2022-06-25 11:12:43.694077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = [1]
    var_2 = {}
    var_0 = lookup_module_0.run(var_1, inject=var_2)
    assert var_0 == [1]



# Generated at 2022-06-25 11:14:09.076442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  var_0 = lookup_run(lookup_module_0)
  assert 'msg' in var_0

# Generated at 2022-06-25 11:14:12.141413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["a", "b"]
    ret = LookupModule.run(terms)
    expected = ["a", "b"]
    assert(ret == expected)

# Generated at 2022-06-25 11:14:16.656375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   lookup_module_0 = LookupModule()
   var_0 = lookup_run(lookup_module_0)
   if var_0:
      print(var_0)

if __name__ == "__main__":
   test_LookupModule_run()

# Generated at 2022-06-25 11:14:18.660242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(lookup_module)
    assert True # TODO: implement your test here


# Generated at 2022-06-25 11:14:24.963311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_list_0 = [ 'a', 'b', 'c', 'd' ]
    var_1 = lookup_module_0.run(var_list_0)
    var_2 = lookup_module_0.run(var_list_0)
    var_3 = lookup_module_0.run(var_list_0)
    var_4 = list(set(var_1 + var_2 + var_3))
    assert var_4 == var_list_0

# Generated at 2022-06-25 11:14:26.518183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:14:31.904542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_1 = ['a']
    test_return = lookup_module_0.run(arg_1)
    assert test_return == ['a']

# Generated at 2022-06-25 11:14:33.115821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(lookup_module_0)

# Generated at 2022-06-25 11:14:35.018618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 11:14:40.971734
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup test data
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(["hi", "there"])

    # Verify that method run of class LookupModule returns expected results
    assert var_0 == ["hi"], 'The test returned an unexpected result.'