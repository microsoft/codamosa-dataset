

# Generated at 2022-06-25 11:06:40.270254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.choice = lambda: 'random_value'
    list_0 = ['list_value_0','list_value_1','list_value_2','list_value_3','list_value_4','list_value_5','list_value_6','list_value_7','list_value_8','list_value_9']
    lookup_module_0 = LookupModule(list_0)
    assert 'random_value' == lookup_module_0.run(list_0)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 11:06:40.984104
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case for String

    test_case_0()

# Generated at 2022-06-25 11:06:42.652714
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a = []
    b = {}
    assert(lookup_module_0.run(a,b) == a)

# Generated at 2022-06-25 11:06:44.143509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-25 11:06:55.023284
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:06:59.218081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0_instance = None
    rand = random.randrange(1, 50)
    result = LookupModule.run(list_0_instance, [rand])
    assert len(result) == 1
    assert result[0] == rand

# Generated at 2022-06-25 11:07:08.018103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['a', 'b', 'c']
    lookup_module_0 = LookupModule(list_0)
    terms_0 = list_0
    result_0 = lookup_module_0.run(terms_0)

    list_1 = ['a', 'b', 'c']
    lookup_module_1 = LookupModule(list_1)
    terms_1 = list_1
    inject_1 = None
    kwargs = {}
    result_1 = lookup_module_1.run(terms_1, inject_1, **kwargs)


# Generated at 2022-06-25 11:07:10.840912
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule(None)
    assert lookup_module_1.run(["foo", "bar"]) == ["foo"]
    assert lookup_module_1.run(["foo", "bar"]) == ["bar"]


# Generated at 2022-06-25 11:07:12.980518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    terms_0 = None
    lookup_module_0 = LookupModule(list_0)
    ret_0 = lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:07:25.512178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    injection_0 = None
    assert lookup_module_0.run(list_0, injection_0) == list_0


# Generated at 2022-06-25 11:07:33.801683
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    terms_0 = []

    # Call the method
    result = lookup_module_0.run(terms_0)

    # Check the result
    # self.assertTrue(result, msg="")

# Generated at 2022-06-25 11:07:35.771068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [1, 2, 3, 4]
    lookup_module_0 = LookupModule(list_0)
    lookup_module_0.run(list_0)


# Generated at 2022-06-25 11:07:37.783517
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [1, 2, 3, 4, 5]
    lookup_module_0 = LookupModule(list_0)
    list_1 = [1, 2]
    assert lookup_module_0.run(list_1) == list_1

# Generated at 2022-06-25 11:07:42.240100
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["Diana", "Martha", "Lisa", "Lauren"]
    lookup_module_0 = LookupModule(terms)
    term_random_choice = lookup_module_0.run(terms)
    assert terms.__contains__(term_random_choice[0])


# Generated at 2022-06-25 11:07:47.080345
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    terms_0 = []
    lookup_module_0.run(terms_0)


# Generated at 2022-06-25 11:07:51.198704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    terms_0 = None
    lookup_module_0 = LookupModule(list_0)
    lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:07:56.493458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms_0) == list_1

# Test case for return values

# Generated at 2022-06-25 11:08:01.677530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = [u'go through the door', u'drink from the goblet', u'press the red button', u'do nothing']
    lookup_module_1 = LookupModule(list_1)
    assert isinstance(lookup_module_1, LookupModule)

# Generated at 2022-06-25 11:08:03.963077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [
        'a',
        'b',
        'c',
    ]
    lookup_module_0 = LookupModule(list_0)
    ret_0 = lookup_module_0.run(inject)
    assert ret_0 == 'a'

# Generated at 2022-06-25 11:08:08.220202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  list_0 = None
  lookup_module_0 = LookupModule(list_0)
  terms_0 = ["foo"]
  self_0 = None
  inject_0 = None
  kwargs_0 = None
  try:
    ret_0 = lookup_module_0.run(terms_0, inject=inject_0, self=self_0)
    return ret_0['_raw']
  except Exception as e:
    print(e)

test_LookupModule_run()

# Generated at 2022-06-25 11:08:13.420193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    list_1 = ["And now for something completely different", "It's the arts", "The air conditioning is not working"]
    expected_result_1 = "It's the arts"
    actual_result_1 = lookup_module_0.run(list_1)
    assert actual_result_1 == expected_result_1

# Generated at 2022-06-25 11:08:17.275888
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)

    # parameters:
    #  - terms:
    #  - inject:
    #  - kwargs:
    expected_result_0 = None
    result_0 = lookup_module_0.run(None, None, )

    assert expected_result_0 == result_0

# Generated at 2022-06-25 11:08:23.941495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a new object
    module_args = {}
    lookup_module_0 = LookupModule(module_args)
    # Set up parameter 'terms'
    terms_1 = ['one', 'two', 'three']

    # Call method run
    result = lookup_module_0.run(terms=terms_1)

    assert isinstance(result, list)
    assert result[0] in terms_1

# Generated at 2022-06-25 11:08:27.970747
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms_0 = [5, 10]
    list_0 = terms_0
    lookup_module_0 = LookupModule(list_0)
    ret = lookup_module_0.run(terms_0)
    assert ret == [10]


# Generated at 2022-06-25 11:08:31.483497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)

    terms_0 = [""]
    inject_0 = None
    lookup_module_0.run(terms_0, inject_0)

# Generated at 2022-06-25 11:08:33.284090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_1 = LookupModule(list_0)

# Generated at 2022-06-25 11:08:40.527502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    terms_0 = ["1", "2", "3"]
    inject_0 = None
    kwargs_0 = {}
    instance_0 = LookupModule(list_0)
    result_0 = instance_0.run(terms_0, inject_0, **kwargs_0)

    assert result_0 == ['2']

# Generated at 2022-06-25 11:08:46.581960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = {'random_choice': ['drink from the goblet']}
    list_0 = ['go through the door',
              'drink from the goblet',
              'press the red button',
              'do nothing']
    lookup_module_0 = LookupModule(list_0)
    assert lookup_module_0.run(list_0) == ret


# Generated at 2022-06-25 11:08:50.101104
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    lookup_module_0 = LookupModule(list_0)
    lookup_module_0.run()

# Generated at 2022-06-25 11:08:55.442932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = None
    try:
        assert lookup_module_0.run(terms_0)
    except Exception as e:
        print("Unable to choose random term: %s" % to_native(e))

test_LookupModule_run()

# Generated at 2022-06-25 11:09:03.205590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = None
    lookup_module_1 = LookupModule(list_1)
    list_2 = []
    lookup_module_2 = LookupModule(list_2)
    list_3 = ["foo", "bar", "baz", "qux"]
    lookup_module_3 = LookupModule(list_3)


# Generated at 2022-06-25 11:09:05.172175
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert "go through the door" in str(test_case_0())

# Generated at 2022-06-25 11:09:07.218186
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    lookup_module_0.run(terms_0)


# Generated at 2022-06-25 11:09:10.823937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)

    # Call method run with arguments
    # Return value should be of type
    assert isinstance(lookup_module_0.run(list_0), list)
# test_LookupModule_run


# Generated at 2022-06-25 11:09:17.173588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    terms_0 = None
    inject_0 = None
    kwargs_0 = {}
    lookup_module_0 = LookupModule(list_0)
    assert isinstance(lookup_module_0.run(terms_0, inject_0, **kwargs_0), list)

# Generated at 2022-06-25 11:09:20.982505
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [
        'simple',
        'test',
        'list',
        ]
    lookup_module_0 = LookupModule(list_0)
    result = lookup_module_0.run(list_0)
    assert(len(result) == 1)
    assert(list_0.count(result[0]) == 1)


# Generated at 2022-06-25 11:09:30.285420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = []
    lookup_module_0 = LookupModule(list_0)
    list_1 = lookup_module_0.run(list_0)
    assert list_1 == []

    list_0 = [1]
    lookup_module_0 = LookupModule(list_0)
    list_1 = lookup_module_0.run(list_0)
    assert 1 in list_1

    list_0 = [3]
    lookup_module_0 = LookupModule(list_0)
    list_1 = lookup_module_0.run(list_0)
    assert 3 in list_1

    list_0 = [2, 1]
    lookup_module_0 = LookupModule(list_0)
    list_1 = lookup_module_0.run(list_0)
    assert 2

# Generated at 2022-06-25 11:09:36.862380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check length of return
    list_1 = ["test_run_0","test_run_1","test_run_2"]
    lookup_module_1 = LookupModule(list_1)
    assert len(lookup_module_1.run(list_1)) in [1,2,3]

# Generated at 2022-06-25 11:09:40.766844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule(None)
    assert lookup_module

    assert lookup_module.run(None) == None

    terms = [1,2,3]
    assert lookup_module.run(terms) in terms

    terms = ["foo","bar","baz"]
    assert lookup_module.run(terms) in terms

# Generated at 2022-06-25 11:09:44.871627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    list_1 = list()
    lookup_module_0 = LookupModule(list_0)
    lookup_module_0.run(list_1, inject=None)


# Generated at 2022-06-25 11:09:58.471415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(['list_0', 'list_1'])
    assert lookup_module_0.run(['list_0', 'list_1'], inject=None, **{'foo': 'bar'}) == ['list_0']

# Generated at 2022-06-25 11:10:01.765170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms_0 = ["name", "test_password", "test_user"]
  expected_result_0 = ["test_user"]
  lookup_module_0 = LookupModule(terms_0)
  result_0 = lookup_module_0.run(terms_0)
  assert result_0 == expected_result_0

# Generated at 2022-06-25 11:10:05.271007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random_choice_0 = None
    lookup_module_0 = LookupModule(random_choice_0)
    list_0 = ["n", "z", "n", "YM6rs", "6", "n", "o", "B"]
    ret = lookup_module_0.run(terms=list_0)

# Generated at 2022-06-25 11:10:08.700074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(list_0)

    dict_0 = dict()
    list_0 = []
    dict_0['terms'] = list_0
    dict_0['inject'] = list_0

    lookup_module_0.run(list_0, inject=list_0)

# Generated at 2022-06-25 11:10:14.915889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_1 = []
    lookup_module_1 = LookupModule(terms_1)
    terms_2 = [1, 2, 3]
    lookup_module_2 = LookupModule(terms_2)
    lookup_module_2.run(terms=terms_2)

# Generated at 2022-06-25 11:10:26.454057
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [u' ', u'a', u'b', u'c', u'd', u'e', u'f', u'g', u'h', u'i',
              u'j', u'k', u'l', u'm', u'n', u'o', u'p', u'q', u'r', u's',
              u't', u'u', u'v', u'w', u'x', u'y', u'z']
    lookup_module_0 = LookupModule(list_0)

# Generated at 2022-06-25 11:10:27.360669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 11:10:32.405423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    terms_0 = [
        (
            '',
        ),
        (
            '',
        ),
    ]
    ret_0 = lookup_module_0.run(terms_0)
    assert ret_0 == terms_0

# Generated at 2022-06-25 11:10:34.078510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  if Callable(test_LookupModule_run):
    test_LookupModule_run()



# Generated at 2022-06-25 11:10:39.022546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-25 11:10:59.311281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_9 = 'terms_9'
    lookup_module_0 = LookupModule(terms_9)
    assert lookup_module_0.run(terms_9) == 'terms_9'

# Generated at 2022-06-25 11:11:08.022512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    int_0 = 1
    arguments = (terms, int_0)
    ret_0 = lookup_module_0.run(arguments)
    assert(ret_0 == [])
    str_0 = 'x'
    list_1 = [str_0]
    ret_0 = lookup_module_0.run(list_1)
    assert(ret_0 == [str_0])
    str_1 = 'y'
    list_2 = [str_1]
    ret_1 = lookup_module_0.run(list_2)
    assert(ret_1 == [str_1])
    str_2 = 'z'
    list_3 = [str_2]
    ret_2 = lookup_module_

# Generated at 2022-06-25 11:11:12.539686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    terms_0 = [""]
    inject = None

    # Call method run with a first argument of terms_0
    ret_0 = lookup_module_0.run(terms_0, inject)

    # Method run has returned [""]
    assert ret_0 == [""]

# Generated at 2022-06-25 11:11:19.618491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  list_0 = None
  lookup_module_0 = LookupModule(list_0)
  list_0 = [None]
  injected_dict = {}
  kwargs_dict = {}
  str_1 = lookup_module_0.run(list_0, injected_dict, **kwargs_dict)
  assert(str_1 == [None])
  list_1 = []
  str_2 = lookup_module_0.run(list_1, injected_dict, **kwargs_dict)
  assert(str_2 == [])
  list_2 = ["test"]
  str_3 = lookup_module_0.run(list_2, injected_dict, **kwargs_dict)
  assert(str_3 == ["test"])
  list_3 = ["test", "test2"]

# Generated at 2022-06-25 11:11:24.865206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [
        {
            'list': [
                'p',
                'a',
                'c'
            ]
        }
    ]
    lookup_module_0 = LookupModule(list_0)
    ret = lookup_module_0.run(list_0, {}, {}, {}, {})
    assert 'list' not in ret[0]
    assert 'unencrypted' not in ret[0]

# Generated at 2022-06-25 11:11:30.131670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    terms_0 = None
    inject_0 = None
    kwargs_0 = {}
    ret_0 = lookup_module_0.run(terms_0, inject=inject_0, **kwargs_0)
    assert ret_0 is None, 'Methods with same arguments. ERROR!'


# Generated at 2022-06-25 11:11:33.258193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    terms_1 = []
    inject_2 = None
    lookup_module_0 = LookupModule(list_0)
    ret_0 = lookup_module_0.run(terms_1, inject=inject_2)
    assert not ret_0

    list_0 = None
    terms_1 = []
    inject_2 = None
    kwargs_3 = {}
    lookup_module_0 = LookupModule(list_0)
    ret_0 = lookup_module_0.run(terms_1, inject=inject_2, **kwargs_3)
    assert not ret_0



# Generated at 2022-06-25 11:11:38.367107
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    terms_0 = None
    inject_0 = None
    kwargs_0 = {}
    assert (lookup_module_0.run(terms_0, inject_0, **kwargs_0) == [])

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 11:11:43.659145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = ['foo', 'bar']
    rand_choice_0 = random.choice(list_0)
    lookup_module_0 = LookupModule(list_0)
    assert rand_choice_0 == lookup_module_0.run(list_0)

# Generated at 2022-06-25 11:11:50.748233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [
        {
            'name': 'foo',
            'list': [1, 2, 3]
        }
    ]
    lookup_module_0 = LookupModule(list_0)

    assert lookup_module_0._get_terms(['foo', 'bar'], {}) == [1, 2, 3]
    assert lookup_module_0._get_terms(['foo', 'bar', 'baz'], {}) == 1

# Generated at 2022-06-25 11:12:32.015770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    assert lookup_module_0.run('', None, False) == '123'

# Generated at 2022-06-25 11:12:36.953803
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    assert lookup_module_0.run('random') is None

# Generated at 2022-06-25 11:12:42.805604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    assert lookup_module_0 == {}, 'Expected {}, got {}'.format({}, lookup_module_0)




# Generated at 2022-06-25 11:12:51.169105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    terms_0_0 = list_0
    inject_0_0 = None
    kwargs_0_0 = {}
    lookup_module_0 = LookupModule(list_0)
    try:
        result_0_0 = lookup_module_0.run(terms_0_0, inject_0_0, **kwargs_0_0)
    except Exception as e:
        assert False


# Generated at 2022-06-25 11:12:58.127825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [
        'extra',
        'extra',
        'extra',
        'extra',
        'extra'
    ]
    terms = list_0
    lookup_module_0 = LookupModule(terms)
    # assert random.choice(terms) == lookup_module_0.run(list_0), 'Argument "list_0": An unexpected value is returned'



# Generated at 2022-06-25 11:13:02.191640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    terms_0 = []
    inject_0 = None
    kwargs_0 = {'allow_unsafe': False}
    ret_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)

# Generated at 2022-06-25 11:13:09.342917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    terms_0 = None
    lookup_module_0.run(terms_0)

if __name__ == "__main__":
    test_LookupModule_run()
    test_case_1()

# Generated at 2022-06-25 11:13:16.068608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['Bass', 'Crystal', 'Maze']
    inject = None
    list_0 = LookupModule(terms)
    list_1 = list_0.run(terms, inject)

    # Asserting the size of the list_1 created
    assert len(list_1) == 1

# Generated at 2022-06-25 11:13:21.781602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    gv_list_0 = None
    gv_int_0 = 10
    # Invoke method
    module_0 = LookupModule(gv_list_0)
    res_0 = module_0.run(gv_int_0)


test_LookupModule_run()

# Generated at 2022-06-25 11:13:26.818133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["go through the door","drink from the goblet","press the red button","do nothing"]
    lookup_module = LookupModule(terms)
    result = lookup_module.run(terms)
    assert result in terms

# Generated at 2022-06-25 11:15:01.648255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)

    # parameters

    terms_1 = None

    inject_1 = None

    # execution
    with pytest.raises(AnsibleError) as exec_info:
        lookup_module_0.run(terms_1, inject=inject_1)

    # assertions
    assert exec_info.type == AnsibleError

    # return the created lookup module
    return lookup_module_0

# Generated at 2022-06-25 11:15:05.441366
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_1 = None
    inject_1 = True

    lookup_module_1 = LookupModule(list_1)
    res = lookup_module_1.run(list_1, inject=inject_1)
    assert res == None


# Generated at 2022-06-25 11:15:13.706651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)

    list_1 = None
    terms_1 = list_1
    known_random_1 = None
    inject_1 = None
    kwargs_1 = None
    val_1_0 = lookup_module_0.run(terms_1, inject=inject_1, **kwargs_1)
    assert val_1_0 is None


# Generated at 2022-06-25 11:15:24.558926
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 11:15:35.582300
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    list_0 = None
    lookup_module_0 = LookupModule(list_0)

    #
    # this test should not cause an exception to be raised
    #
    try:
        lookup_module_0.run(terms=list_0)
    except Exception as e:
        assert False

    list_0 = ['ansible', 'ansible.com']
    lookup_module_0 = LookupModule(list_0)

    #
    # this test should not cause an exception to be raised
    #
    try:
        lookup_module_0.run(terms=list_0)
    except Exception as e:
        assert False

    list_0 = ['ansible', 'ansible.com']
    lookup_module_0 = LookupModule(list_0)

    #
    # this test should not cause an exception

# Generated at 2022-06-25 11:15:40.124356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    terms_0 = ['list']
    inject_0 = None

# Generated at 2022-06-25 11:15:44.271023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = [1]
    lookup_module_0 = LookupModule(list_0)
    result = lookup_module_0.run(list_0)
    assert result == [1]

# Generated at 2022-06-25 11:15:51.584012
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin_0 = LookupModule({'msg': 'msg'})
    assert lookup_plugin_0.run(['msg']) == ['msg']
    assert lookup_plugin_0.run(['msg']) == ['msg']
    lookup_plugin_1 = LookupModule({})
    assert lookup_plugin_1.run(['msg']) == ['msg']

# Generated at 2022-06-25 11:15:53.333120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_0 = None
    lookup_module_0 = LookupModule(list_0)
    result = lookup_module_0.run(list_0)
    assert result == list_0

# Generated at 2022-06-25 11:15:54.742705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # initialize list_0
    list_0 = None
    lookup_module_0 = LookupModule(list_0)

    # Run the method "run()" of class LookupModule
    test_case_0()