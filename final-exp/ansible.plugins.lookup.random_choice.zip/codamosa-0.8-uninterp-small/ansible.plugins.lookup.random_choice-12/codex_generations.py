

# Generated at 2022-06-25 11:06:39.681658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    ret = lookup_module_0.run(terms_0)
    assert ret == terms_0
    terms_1 = ["T", "E", "S", "T"]
    ret = lookup_module_0.run(terms_1)
    assert ret in terms_1


# Generated at 2022-06-25 11:06:48.744919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args_0 = {'inject': {'random.choice': __random_choice}, 'kwargs': {}}
    results_0 = lookup_module_0.run([], **args_0)
    assert results_0 == []

    args_1 = {
        'inject': {
            'random.choice': __random_choice
        },
        'kwargs': {}
    }
    results_1 = lookup_module_0.run([1, 2, 3], **args_1)
    assert results_1 == [3]



# Generated at 2022-06-25 11:06:53.333047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = ['foo', 'bar', 'baz', 'qux']
    str_1 = lookup_module_0.run(str_0)
    return str_1

# Generated at 2022-06-25 11:06:56.913273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    input_0 = ['file1.txt', 'file2.txt', 'file3.txt']

    # Test using kwargs
    lookup_module_0.run(terms=input_0, inject={}, **{'wantlist': True})

    # Test using positional arguments
    lookup_module_0.run(input_0)

# Generated at 2022-06-25 11:06:58.607317
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run([]) == []
    assert lookup_module_0.run(['a']) == ['a']
    

# Generated at 2022-06-25 11:06:59.533659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 11:07:02.502959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == [], "LookupModule.run returned unexpected value"

# Generated at 2022-06-25 11:07:07.012443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term = None
    try:
        lookup_module_0.run(term, inject=None)
    except:
        assert False

# Sample test for method run of class LookupModule

# Generated at 2022-06-25 11:07:10.841492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # DEV: Run case with no return value
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms=['a', 'b'], inject=None)
    assert isinstance(ret, list)
    assert len(ret) == 1
    assert ret[0] in ['a', 'b']

# Generated at 2022-06-25 11:07:16.797516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This test is used to verify whether run method (randomly choose) of LookupModule class is working fine.
    When there are no terms, it returns empty list.
    When there are only one term, it returns that term.
    When there are terms, it returns a random term.
    """
    lookup_module_0 = LookupModule()
    assert [] == lookup_module_0.run([])
    assert ["0"] == lookup_module_0.run(["0"])
    assert set(["0", "1", "2", "3"]) == set(lookup_module_0.run(["0", "1", "2", "3"]))


# Generated at 2022-06-25 11:07:22.034565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  print("Test run")
  lm = LookupModule()
  print(lm.run(terms=["one", "two", "three"], inject=None))
  print(lm.run(terms=["one", "two", "three"], inject=None))
  print(lm.run(terms=["one", "two", "three"], inject=None))
  print(lm.run(terms=["one", "two", "three"], inject=None))

# Generated at 2022-06-25 11:07:30.071179
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    random_terms = [
        ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing'],
        ['go through the door', 'drink from the goblet', 'press the red button'],
        ['go through the door', 'drink from the goblet'],
        ['go through the door'],
        [],
    ]

    for terms in random_terms:
        for _ in range(5):
            assert lookup_module.run(terms) in terms

# Generated at 2022-06-25 11:07:38.959220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=['go through the door', 'drink from the goblet',
                                    'press the red button', 'do nothing']) == ['go through the door']
    assert lookup_module.run(terms=['go through the door', 'drink from the goblet',
                                    'press the red button', 'do nothing']) == ['press the red button']
    assert lookup_module.run(terms=['go through the door', 'drink from the goblet',
                                    'press the red button', 'do nothing']) == ['do nothing']
    assert lookup_module.run(terms=['go through the door', 'drink from the goblet',
                                    'press the red button', 'do nothing']) == ['press the red button']

# Generated at 2022-06-25 11:07:40.095838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run([])

# Generated at 2022-06-25 11:07:42.459679
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #assert lookup_module_0.run(terms) == ret
    pass



# Generated at 2022-06-25 11:07:44.114845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:07:48.786049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['ab']
    ret_0 = lookup_module_0.run(terms_0)
    assert len(ret_0) == 1

# Generated at 2022-06-25 11:07:53.215055
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_2 = [1, 2, 3]
    dict_4 = lookup_module_0.run(list_2)
    assert dict_4 == [1, 2, 3]


# Generated at 2022-06-25 11:07:59.075806
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["term1","term2"]
    inject = None
    kwargs = {}
    lookup_module_0 = LookupModule()
    returned_value_0 = lookup_module_0.run(terms,inject,**kwargs)
    assert returned_value_0 == ["term1"] or returned_value_0 == ["term2"]

# Generated at 2022-06-25 11:08:04.256235
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    inject = None
    assert lookup_module_0.run(terms, inject) == []
    terms = ['a', 'b', 'c']
    assert lookup_module_0.run(terms, inject) == ['a'] or lookup_module_0.run(terms, inject) == ['b'] or lookup_module_0.run(terms, inject) == ['c']
    terms = [[1], [2], [3]]
    assert lookup_module_0.run(terms, inject) == [[1]] or lookup_module_0.run(terms, inject) == [[2]] or lookup_module_0.run(terms, inject) == [[3]]

# Generated at 2022-06-25 11:08:09.816939
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  terms = ["foo", "bar", "baz"]
  inject = {"a": 1, "b": 2}


  import random
  random.choice = mock_random_choice

  lookup_module_0 = LookupModule()

  ret_0 = lookup_module_0.run(terms, inject)

  assert ret_0 == ["baz"]


# Generated at 2022-06-25 11:08:14.319369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(None) == None

    lookup_module_1 = LookupModule()
    assert lookup_module_1.run(0) == 0

    lookup_module_2 = LookupModule()
    assert lookup_module_2.run(1.1) == 1.1

    lookup_module_3 = LookupModule()
    assert lookup_module_3.run('') == ''

    lookup_module_4 = LookupModule()
    assert lookup_module_4.run('test') == 'test'

    lookup_module_5 = LookupModule()
    assert lookup_module_5.run(['test', 'string']) == ['test', 'string']

# Generated at 2022-06-25 11:08:15.788232
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []


# Generated at 2022-06-25 11:08:19.488977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fixture = {
        'terms': [[
            'go through the door',
            'drink from the goblet',
            'press the red button',
            'do nothing'
        ]]
    }

    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(**fixture)
    assert ret[0] in fixture['terms'][0]

# Generated at 2022-06-25 11:08:21.129151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['foo']
    assert lookup_module_0.run(terms) == ['foo']


# Generated at 2022-06-25 11:08:27.786588
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    string_0_1 = "string_0"
    list_0 = ["list_0"]
    list_1 = lookup_module_1.run(string_0_1, inject=list_0, **kwargs)
    assert (list_1 == list_0)


# Generated at 2022-06-25 11:08:29.926905
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms="MAGIC-8-BALL")
    assert result == "MAGIC-8-BALL"
    raise Exception("Test Failed")

# Generated at 2022-06-25 11:08:34.220360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        # This is not working.
#        lookup_module_0.run(terms=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], inject=None, **kwargs={})
        lookup_module_0.run(terms=[1, 2, 3, 4, 5], inject=None, **{'vault_password': None})
    except Exception as e:
        assert(False)



# Generated at 2022-06-25 11:08:36.047894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = None
    lookup_module_0 = LookupModule()
    x = lookup_module_0.run(x)
    assert isinstance(x, list)

test_LookupModule_run()

# Generated at 2022-06-25 11:08:40.254913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()

    try:
        lookup_module_2.run(["one", "two", "three"])
    except Exception as e:
        raise Exception("Unable to run method run of class LookupModule: %s" % str(e))


# Generated at 2022-06-25 11:08:47.617976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'go through the door', u'drink from the goblet', u'press the red button', u'do nothing']
    lookup_module_0.run(terms_0)

# Generated at 2022-06-25 11:08:53.305315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.constants import DEFAULT_SUDO_PASS
    from collections import namedtuple
    import os

    LookupBase._loader = None
    PlaybookExecutor._loader = None
    PlayContext._loader = None
    PlayContext._prompt = False

    # Create a named tuple class to represent a task result
    ResultType = namedtuple('ResultType', 'msg success')

    # Workspace
    current_dir = os.getcwd()
    assert current_dir == os.path.expanduser('~')
    assert current_dir == os.path.abspath('.')

    #

# Generated at 2022-06-25 11:09:01.509752
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    test_terms_0 = [
        u'do nothing',
        u'press the red button',
        u'drink from the goblet',
        u'go through the door',
    ]
    test_inject_0 = None
    test_kwargs_0 = {}
    test_choices_0 = [
        u'press the red button',
        u'do nothing',
        u'drink from the goblet',
        u'go through the door',
    ]

    result = lookup_module_0.run(test_terms_0, test_inject_0, **test_kwargs_0)

    assert result == test_choices_0

# Generated at 2022-06-25 11:09:03.280500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])
# Test cases for class LookupModule

# Generated at 2022-06-25 11:09:05.196691
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_run_0 = lookup_module_0.run(None)
    assert lookup_module_run_0 == None

# Generated at 2022-06-25 11:09:08.694903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    r = [u'test']
    i = {}
    test_case_0 = LookupModule()
    result = test_case_0.run(r, inject=i)
    assert result == r

    result = test_case_0.run([])
    assert result == []

# Generated at 2022-06-25 11:09:10.864906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(None) == []
    #assert lookup_module_0.run(None, None) == []

# Generated at 2022-06-25 11:09:19.769795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This is the test case for AnsibleModule#main to test the module against a message queue
    temp_list_0 = []
    temp_list_0.append("go through the door")
    temp_list_0.append("drink from the goblet")
    temp_list_0.append("press the red button")
    temp_list_0.append("do nothing")
    lookup_module_0 = LookupModule()
    new_list_0 = lookup_module_0.run(temp_list_0)
    assert len(new_list_0) == 1

# Generated at 2022-06-25 11:09:30.892605
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    fixtures = {
        'default': [
            [
                [
                    'go through the door',
                    'drink from the goblet',
                    'press the red button',
                    'do nothing',
                ],
            ],
        ],
    }

    for fixture_name, fixture_test_values in fixtures.items():
        for fixture_test_value in fixture_test_values:
            lookup_module = LookupModule()
            terms = fixture_test_value[0]

            result = lookup_module.run(terms)

    # AssertionError: ['go through the door'] != ['do nothing']
    assert result == ['go through the door']

test_case_0()

# Generated at 2022-06-25 11:09:34.833312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = 'terms'
    inject_0 = None
    kwargs_0 = {
        'password': 'password',
        'paths': ['paths', 'paths', 'paths'],
        'vault_password': 'vault_password',
        'private_key_file': ['private_key_file', 'private_key_file'],
    }
    lookup_module_0.run(terms_0, inject_0, **kwargs_0)

# Generated at 2022-06-25 11:09:47.936192
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # tests whether the random choice is coming a particular value
    # set in the list
    terms_0 = ['a','b','c','d','e']
    ret = lookup_module_0.run(terms_0)
    assert ret[0] in ['a','b','c','d','e'],"Result is not in the list"

# test whether a type error is raised when a value other than a list is passed

# Generated at 2022-06-25 11:09:52.056088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    expected_0 = [random.choice([])]
    expected_1 = [random.choice(['go through the door', 'drink from the goblet', 'press the red button', 'do nothing'])]
    actual_0 = lookup_module_0.run([])
    actual_1 = lookup_module_1.run(['go through the door', 'drink from the goblet', 'press the red button', 'do nothing'])
    assert actual_0 == expected_0
    assert actual_1 == expected_1


# Tests run OK

# Generated at 2022-06-25 11:09:59.509091
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_str = "terms"
    terms_str1 = "terms1"
    terms_str2 = "terms2"
    terms_str3 = "terms3"
    terms = [terms_str, terms_str1, terms_str2, terms_str3]
    inject = "inject"
    kwargs = {"kwargs": None}
    expected = [terms_str]
    result = lookup_module_0.run(terms, inject, **kwargs)
    assert result == expected


# Generated at 2022-06-25 11:10:00.631788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(getattr(LookupModule, "run"))



# Generated at 2022-06-25 11:10:05.716111
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test case for __init__(self, **kwargs)
    # TODO: implement your test here

    # Test case for run(self, terms, inject=None, **kwargs)
    # TODO: implement your test here
    terms = None
    inject = None
    kwargs = None
    ret = lookup_module_0.run(terms, inject, **kwargs)

    assert ret is None


# Generated at 2022-06-25 11:10:10.189478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    list = [ 'ansible', 'ansible-docs' ]
    results = lookup_module.run(list)

    assert len(results) == 1
    assert results[0] in list

    list = [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
    results = lookup_module.run(list)

    assert len(results) == 1
    assert results[0] in list

# Generated at 2022-06-25 11:10:14.434796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # default case
    lists = ["Lists0", "Lists1"]
    ret = lookup_module.run(lists)
    assert len(ret) == 1


# Generated at 2022-06-25 11:10:17.296895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [['_raw']]
    lookup_module_0.run( terms, inject=None)


# Generated at 2022-06-25 11:10:21.236421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms = []

    ret_1 = lookup_module_0.run(terms)

    assert ret_1 == []

# Generated at 2022-06-25 11:10:24.519740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Call method run of class LookupModule on terms
    ret = lookup_module_0.run(terms)
    assert True == isinstance(ret, list)

# Generated at 2022-06-25 11:10:47.770955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
# No exception expected for this call
    lookup_module_0.run([])
    return


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 11:10:50.174748
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg_0 = []
    with pytest.raises(AnsibleError):
        lookup_module_0.run(arg_0)


# Test for method run of class LookupModule

# Generated at 2022-06-25 11:10:54.897093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('running unit test for LookupModule method run')

    lookup_module_0 = LookupModule()
    terms_0 = []
    inject_0 = {}
    kwargs_0 = {}
    lookup_module_0.run(terms_0, inject=inject_0, **kwargs_0)

    return


# Generated at 2022-06-25 11:10:56.613420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["b", "a", "c"]
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0.run(terms), list)


# Generated at 2022-06-25 11:11:06.207548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 11:11:07.994089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms =['Test']
    result = lookup_module.run(terms)
    assert result == ['Test']

# Generated at 2022-06-25 11:11:10.408195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['pcp', 'pcp', 'pcp']) == ['pcp']

# Generated at 2022-06-25 11:11:16.268294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_0 = LookupModule()
    param_0 = []
    param_1 =None
    result_0 = lookup_module_run_0.run(param_0, param_1)
    print(result_0)

    lookup_module_run_1 = LookupModule()
    param_2 = ['one', 'two', 'three', 'four', 'five']
    param_3 =None
    result_1 = lookup_module_run_1.run(param_2, param_3)
    print(result_1)

# Generated at 2022-06-25 11:11:27.112602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    random.seed(250)
    lookup_module_1 = LookupModule()
    random.seed()
    lookup_module_2 = LookupModule()

    terms_0 = [ ]
    expected_0 = [ ]
    ret_0 = lookup_module_0.run(terms=terms_0)
    assert ret_0 == expected_0

    terms_1 = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
    expected_1 = ["m"]
    ret_1 = lookup_module_1

# Generated at 2022-06-25 11:11:29.269765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert list([3]) == lookup_module_0.run(terms=list([1, 2, 3, 4]))

# Generated at 2022-06-25 11:12:17.136658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run([[0, 1, 2, 3, 4, 5]])
    print(result)
    assert (result >= [0])


# Generated at 2022-06-25 11:12:18.500408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
 #    


# Generated at 2022-06-25 11:12:24.924812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    inject = None
    kwargs = {}
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms=terms_0, inject=inject, **kwargs)
    assert ret == lookup_module_0.run(terms=terms_0, inject=inject, **kwargs)


# Generated at 2022-06-25 11:12:29.248008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([1,2,3],inject=None) == [1,2,3] # Randomly picks one term of the list
    assert lookup_module.run([1,2,3],inject=None,terms=[1,2,3]) == [1,2,3] # Randomly picks one term of the list

# Generated at 2022-06-25 11:12:34.478103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1,2,3,4,5]
    lookup_module_0 = LookupModule()
    assert(lookup_module_0.run(terms) in terms)


# Generated at 2022-06-25 11:12:37.890956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = [0]
    assert lookup_module_0.run(terms_1) == [0]
    assert lookup_module_0.run(terms_1, inject=None) == [0]

# Generated at 2022-06-25 11:12:42.410299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])
    assert True


# Generated at 2022-06-25 11:12:53.335832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_6 = LookupModule()
    terms_1 = None
    terms_2 = ['a', 'b', 'c']
    terms_3 = ['1', '2', '3']
    terms_4 = [1, 2.0, '3']
    terms_6 = []
    terms_7 = [None, None, None]
    inject_1 = None
    inject_2 = {}
    inject_3 = {'a': 'b'}
    inject_4 = {'c': 'd'}
    inject_5 = {'b': []}


# Generated at 2022-06-25 11:12:58.090976
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['a', 'b', 'c']
    res = lookup_module_0.run(terms)
    print(">>>>>>>>> " + str(res))

if __name__ == "__main__":
    test_LookupModule_run()
    # test_case_0()

# Generated at 2022-06-25 11:13:04.555925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = [
        "a",
        "b",
        "c",
    ]

    inject_0 = None

    kwargs_0 = {}

    try:
        result_0_0 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    except AnsibleError as e_0:
        print(e_0)
    result_0_1 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)
    result_0_2 = lookup_module_0.run(terms_0, inject_0, **kwargs_0)

# Generated at 2022-06-25 11:14:40.639332
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_case_0()

if __name__ == '__main__':
    import doctest
    doctest.testmod()

    # Unit test for method run of class LookupModule
    test_LookupModule_run()

# Generated at 2022-06-25 11:14:45.636140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [10, 20, 30]
    inject = None
    kwargs = {}
    result = lookup_module_0.run(terms, inject, **kwargs)


# Generated at 2022-06-25 11:14:47.062964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert 'haha' == lookup_module_0.run('haha')

# Generated at 2022-06-25 11:14:53.277156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()

    # Testing nested random choice with multiple choices
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run([400])
    assert 'Unable to choose random term' in str(excinfo.value)

    # Testing nested random choice with multiple

# Generated at 2022-06-25 11:14:59.992601
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [str(),str(),str(),str(),str(),str(),str(),str(),str(),str()]
    terms_0 = terms
    lookup_module_0.run(terms_0)



# Generated at 2022-06-25 11:15:03.535623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run("test")

# Generated at 2022-06-25 11:15:08.263094
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    try:
        lookup_module_0 = LookupModule()
        terms = None
        inject = None
        kwargs = {  }
        lookup_module_0.run(terms, inject, **kwargs)
    except Exception as e:
        assert "Unable to choose random term: argument of type 'NoneType' is not iterable" in str(e)

# Generated at 2022-06-25 11:15:14.570327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    input_value_0 = [""]
    input_value_1 = []
    input_value_2 = []
    input_value_3 = {}
    input_value_4 = {}
    try:
        lookup_module_0.run(input_value_0, inject=None, **kwargs)
    except AnsibleError as err:
        assert(str(err) == "Unable to choose random term: index is out of range for axis 0 with size 0")


# Generated at 2022-06-25 11:15:21.598669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = [u'foo', u'bar', u'baz']
    inject = {}
    kwargs = {}
    ret = lookup_module_0.run(terms_1, inject=inject, **kwargs)
    assert len(ret) == 1


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 11:15:25.605546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([['go through the door']],LookupModule()) == ['go through the door']
    assert lookup_module_1.run([['go through the door','do nothing','drink from the goblet','press the red button']], LookupModule()) == ['go through the door','do nothing','drink from the goblet','press the red button']