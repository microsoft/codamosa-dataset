

# Generated at 2022-06-11 15:48:52.134928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-11 15:48:58.841149
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    terms = ["test1", "test2", "test3"]
    res = test_object.run(terms)
    assert (len(res) == 1 and res[0] in terms)
    assert res[0] == test_object.run(terms)[0]
    assert res[0] == test_object.run(terms)[0]
    assert res[0] == test_object.run(terms)[0]

# Generated at 2022-06-11 15:49:05.113159
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Running test_LookupModule_run")

    list_input = [ 'go through the door',
                   'drink from the goblet',
                   'press the red button',
                   'do nothing'
                 ]
    terms = [list_input]
    inject = {}

    try:
        obj_lookupmodule = LookupModule()
        result = to_native(obj_lookupmodule.run(terms, inject))
        assert result in list_input
    except Exception as e:
        print(e)
        assert False
    print("PASS")

# Generated at 2022-06-11 15:49:08.445105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'my terms'
    expect = terms
    lookup_class = LookupModule()
    result = lookup_class.run(terms)
    assert result == expect

# Generated at 2022-06-11 15:49:15.651323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    assert lookup.run([]) == []
    assert len(lookup.run(['foo','bar','baz','quux','quuux','quuuux','quuuuux','quuuuuux'])) == 1
    assert (lookup.run(['foo','bar','baz','quux','quuux','quuuux','quuuuux','quuuuuux'])[0] in ['foo', 'bar', 'baz', 'quux', 'quuux', 'quuuux', 'quuuuux', 'quuuuuux'])

# Generated at 2022-06-11 15:49:24.886868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    # Test 1: no element in choice list
    terms = []
    ret = lm.run(terms)
    assert terms == ret

    # Test 2: one element in choice list
    terms = ["one"]
    ret = lm.run(terms)
    assert terms == ret

    # Test 3: more than one elements in choice list
    terms = ["one", "two", "three", "four", "five"]
    ret = lm.run(terms)
    assert isinstance(ret, list) and (len(ret) == 1) and (ret[0] in terms)

# Generated at 2022-06-11 15:49:26.398068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(['a','b','c','d'])
    assert result in ['a','b','c','d']

# Generated at 2022-06-11 15:49:28.546129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = [1,2,3]
    result = lookup.run(terms)
    assert result in terms

# Generated at 2022-06-11 15:49:32.491354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({})
    terms=['term1', 'term2', 'term3']
    result=lookup.run(terms, {})
    assert(result[0] in terms)


# Generated at 2022-06-11 15:49:40.470801
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with empty list of terms
    test_obj = LookupModule()
    assert test_obj.run([]) == []

    # Test with single term in list
    test_obj = LookupModule()
    assert test_obj.run(["test"]) == ["test"]

    # Test with multiple terms in list
    test_obj = LookupModule()
    assert test_obj.run(["test1", "test2"]) in ["test1", "test2"]

# Generated at 2022-06-11 15:49:48.310598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import assertCountEqual
    import random

    test_module = AnsibleModule(
        name='test',
        argument_spec = {}
    )
    random.seed(10)
    term = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
    lookup_module = LookupModule()
    result = lookup_module.run(term, test_module)
    assertCountEqual(test_module, result, ['u'])

# Generated at 2022-06-11 15:49:51.762221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    foo = ["hello","world"]
    for _ in range(0,10):
        ret = LookupModule().run(foo)
        assert foo[0] == ret[0] or foo[1] == ret[0]

# Generated at 2022-06-11 15:49:54.439614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    terms = ["a","b"]
    results = test.run(terms)
    assert len(results) == 1
    assert results[0] in terms

# Generated at 2022-06-11 15:49:58.037611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Test to verify run method of class LookupModule
    '''
    lookup_instance = LookupModule()
    terms = [{'name': 'test'}]
    injected_val = 'test'
    assert lookup_instance.run(terms=terms, inject=injected_val) is not None

# Generated at 2022-06-11 15:50:02.916660
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    args = {'_raw': ['drink from the goblet', 'do nothing', 'go through the door', 'press the red button']}

    random_term = LookupModule(None, args)
    assert random_term.run(['drink from the goblet', 'do nothing', 'go through the door', 'press the red button']) == args['_raw']

# Generated at 2022-06-11 15:50:06.531442
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    res = LookupModule().run([["a","b","c"]])
    assert res == ["a"] or res == ["b"] or res == ["c"]

    res = LookupModule().run([["a"]])
    assert res == ["a"]

# Generated at 2022-06-11 15:50:16.048451
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Simple call with a list of strings
    obj = LookupModule()
    result = obj.run([['a', 'b', 'c', 'd', 'e']])
    assert type(result) == list
    assert len(result) == 1
    assert result[0] in ['a', 'b', 'c', 'd', 'e']

    # Simple call with a list of integers
    obj = LookupModule()
    result = obj.run([[1, 2, 3, 4, 5]])
    assert type(result) == list
    assert len(result) == 1
    assert result[0] in [1, 2, 3, 4, 5]

    # Simple call with a list of floats
    obj = LookupModule()

# Generated at 2022-06-11 15:50:23.137487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Creating instance of LookupModule
    lm = LookupModule()

    # Creating a test list to test run method
    list1 = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]

    # Calling run method of LookupModule with list1 as argument
    # We will get one item from the list as output
    output = lm.run(terms=list1)

    # Checking if the output is present in list1
    assert output[0] in list1

# Generated at 2022-06-11 15:50:25.010704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["foo", "bar", "baz"]
    lm = LookupModule()
    result = lm.run(terms)

    assert result in terms

# Generated at 2022-06-11 15:50:28.652595
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run([1, 2, 3]) == [1] or module.run([1, 2, 3]) == [2] or module.run([1, 2, 3]) == [3]

# Generated at 2022-06-11 15:50:33.373024
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Example of setUp() method to initialize the class under test
    obj = LookupModule()

    # Example of test
    obj.run([1,2,3], None)

# Generated at 2022-06-11 15:50:38.734268
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # Test 1
    terms = ['test 1', 'test 2']
    r = l.run(terms)
    assert len(r) == 1
    assert terms.index(r[0]) > -1

    # Test 2
    terms = []
    r = l.run(terms)
    assert len(r) == 0

# Generated at 2022-06-11 15:50:40.934166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert LookupModule(None, dict()).run([1, 2, 3, 4, 5], {}) == [1, 2, 3, 4, 5]


# Generated at 2022-06-11 15:50:43.403972
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["one", "two", "three"], inject={}, **{"test": True})

test_LookupModule_run()

# Generated at 2022-06-11 15:50:47.015106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["term 1", "term 2"]
    assert len(terms) == 2
    assert len(LookupModule().run(terms)) == 1

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-11 15:50:51.111229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    terms = ["first", "second", "third"]
    result = test_object.run(terms, "")
    assert result[0] in terms
    print("SUCCESS:  test_LookupModule_run")


# Generated at 2022-06-11 15:50:52.557871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert len(LookupModule().run(["a", "b", "c"]), 1)

# Generated at 2022-06-11 15:50:54.809836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    expected = []
    actual = module.run([])
    assert expected == actual



# Generated at 2022-06-11 15:50:57.923777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lo = LookupModule()
    result = lo.run([1, 2, 3])
    assert result[0] in [1, 2, 3]

# Generated at 2022-06-11 15:51:08.225556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create instance
    lookup_module = LookupModule()
    # validate some scenarios
    list_values = ['a','b','c','d','e','f','g','h']
    assert lookup_module.run(list_values) == ['a']
    assert lookup_module.run(list_values) == ['a']
    assert lookup_module.run(list_values) == ['a']
    assert lookup_module.run(list_values) == ['a']
    assert lookup_module.run(list_values) == ['a']
    assert lookup_module.run(list_values) == ['a']
    assert lookup_module.run(list_values) == ['a']
    assert lookup_module.run(list_values) == ['a']
    assert lookup_module.run(list_values) == ['a']

# Generated at 2022-06-11 15:51:14.801943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  item = LookupModule()
  terms = ["a", "b", "c"]
  result = item.run(terms=terms)
  assert True == result in terms

# Generated at 2022-06-11 15:51:17.439063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = list(range(0,100))
    lookup_module = LookupModule()
    try:
        assert lookup_module.run(terms=terms)
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-11 15:51:25.170519
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['hello, world', 'hello all', 'hello everyone']
    terms2 = ['1', '2', '3', '4']
    lookup_obj = LookupModule()
    output = lookup_obj.run(terms, inject=None, **{})
    assert output[0] in terms
    assert len(output) == 1

    output2 = lookup_obj.run(terms2, inject=None, **{})
    assert output2[0] in terms2
    assert len(output2) == 1

# Generated at 2022-06-11 15:51:29.633283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    lookup_module = LookupModule()

    assert lookup_module.run([to_bytes('a'), to_bytes('b'), to_bytes('c'), to_bytes('d')]) in [to_bytes('a'), to_bytes('b'), to_bytes('c'), to_bytes('d')]

# Generated at 2022-06-11 15:51:31.698717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    test_terms = ['a', 'b']
    assert len(lookup.run(test_terms))==1

# Generated at 2022-06-11 15:51:34.154529
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["hello", "world"]) in [["hello"], ["world"]]

# Generated at 2022-06-11 15:51:36.218557
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    testLookupModule = LookupModule()
    assert testLookupModule.run(terms=['abc', 'def', 'ghi']) == ['def']

# Generated at 2022-06-11 15:51:46.457608
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class Args(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

    def run_result(terms):
        ret = terms
        if terms:
            ret = [random.choice(terms)]

        return ret

    args = Args(**{'terms': ['a term', 'another term', 'yet another term']})
    lm = LookupModule()
    # get a result randomly
    lm.run(args.terms, inject=None, **{'variable': '_content'})

    # get all results in the list of `terms`
    results = []
    times = args.terms.__len__()
    while times > 0:
        results.append(lm.run(args.terms, inject=None, **{'variable': '_content'}))

# Generated at 2022-06-11 15:51:51.056996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # test invalid input

# Generated at 2022-06-11 15:51:54.233301
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["term1", "term2", "term3"]
    expected_output = ["term1", "term2", "term3"]
    lookup_module = LookupModule()
    assert lookup_module.run(terms) in expected_output

# Generated at 2022-06-11 15:52:04.462987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    result = lm.run(['a', 'b', 'c'])
    print(result)


# Generated at 2022-06-11 15:52:06.705265
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['first', 'second']
    lookup = LookupModule()

    result = lookup.run(terms)
    assert len(result) == 1
    assert result[0] in terms

# Generated at 2022-06-11 15:52:12.219165
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test method run with empty list of strings
    lookup_module = LookupModule()
    result = lookup_module.run([], None)

    # Test method run with random choice
    lookup_module = LookupModule()
    result = lookup_module.run(['first', 'second'], None)
    assert result[0] == 'first' or result[0] == 'second'

# Generated at 2022-06-11 15:52:16.681180
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    ret = [{'item': 'go through the  door'}, {'item': 'drink from the goblet'}, {'item': 'press the red button'}, {'item': 'do nothing'}]
    ret = ret

    return ret

# Generated at 2022-06-11 15:52:19.535492
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["I'm a dummy"]) == ["I'm a dummy"]
    assert len(LookupModule().run(["I'm a dummy", "I'm another dummy"])) == 1
# vim: sts=4 sw=4 et

# Generated at 2022-06-11 15:52:27.539967
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # GIVEN: Test module and a random list of terms
    test_module = LookupModule()
    terms = ['One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen']
    expected_return = 'One'

    # WHEN: call the run method of the Lookup module
    returned_value = test_module.run(terms, inject=None)

    # THEN: The returned value should be a list with a random element of the given list
    assert isinstance(returned_value, list)
    assert len(returned_value) == 1
    assert returned_value[0] in terms

# Generated at 2022-06-11 15:52:32.002299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pl = LookupModule()
    result = pl.run(['one', 'two', 'three', 'four'])
    assert type(result) is list
    assert result[0] in ['one', 'two', 'three', 'four']

# Generated at 2022-06-11 15:52:38.071242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_obj = LookupModule()

    # Test case to check if random term is returned from list of terms
    terms = ['first_term', 'second_term', 'third_term']
    assert module_obj.run(terms) in terms

    # Test case to check if exception is raise when the input is empty
    terms = []
    try:
        module_obj.run(terms)
    except AnsibleError:
        pass
    else:
        assert False, "Expected an AnsibleError"

# Generated at 2022-06-11 15:52:42.918941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = ['drink from the goblet']
    lookup_module_obj = LookupModule()
    ret = lookup_module_obj.run(['go through the door', 'drink from the goblet', 'press the red button', 'do nothing'], inject=None, **{})
    assert ret == result

# Generated at 2022-06-11 15:52:47.583604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestLookupModule(LookupModule):
        def __init__(self):
            super(TestLookupModule, self).__init__()
            random.seed(3)
    tlm = TestLookupModule()
    return tlm.run(terms=['a', 'b', 'c'])

# Generated at 2022-06-11 15:53:05.393480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule()


# Generated at 2022-06-11 15:53:07.975017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random_choice = LookupModule()
    assert random_choice.run([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-11 15:53:11.970853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()

    # try empty terms
    assert test.run([]) == []

    # try with non-empty terms
    terms = ["a", "b", "c"]
    random_choice = test.run(terms)
    assert random_choice in terms

# Generated at 2022-06-11 15:53:22.736937
# Unit test for method run of class LookupModule

# Generated at 2022-06-11 15:53:28.462964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with empty list
    assert LookupModule(None, None).run([], {}) == [], "Empty list returned wrong"
    # Test with one element
    assert LookupModule(None, None).run([1], {}) == [1], "One element returned wrong"
    # Test with list of element
    assert sorted(LookupModule(None, None).run([1, 2], {})) == sorted([1, 2]), "List with two elements returned wrong"

# Generated at 2022-06-11 15:53:36.642227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

# Generated at 2022-06-11 15:53:39.259809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  module = LookupModule()
  assert module.run(None) == None

  list = [ "abhinav", "ansible", "lookup"]
  assert module.run(list) == list

# Generated at 2022-06-11 15:53:43.154052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(["smile", "frown"])
    assert(len(ret) == 1)
    assert("smile" in ret or "frown" in ret)


# Generated at 2022-06-11 15:53:46.076335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['a', 'b', 'c']) in [['a'], ['b'], ['c']]

# Generated at 2022-06-11 15:53:47.831394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['1', '2', '3']
    l = LookupModule()
    l.run(terms) == terms

# Generated at 2022-06-11 15:54:26.546461
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = ['one', 'two', 'three']
    test_inject = None
    test_kwargs = {}
    test_instance = LookupModule()
    test_result = test_instance.run(test_terms, test_inject, **test_kwargs)
    assert len(test_terms) >= len(test_result)

# Generated at 2022-06-11 15:54:31.224458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test that when list is empty then empty list is returned
    list = LookupModule().run([])
    assert list == []

    # Test that when list is non-empty then non-empty list is returned
    list = LookupModule().run([1])
    assert list != []

# Generated at 2022-06-11 15:54:36.255998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(
        terms=[
            "go through the door",
            "drink from the goblet",
            "press the red button",
            "do nothing"
        ]
    )
    assert len(ret) == 1
    assert ret[0] in [
        "go through the door",
        "drink from the goblet",
        "press the red button",
        "do nothing"
    ]

# Generated at 2022-06-11 15:54:40.316325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    numbers = [1, 2, 3, 4, 5, 6]
    lookup = LookupModule()
    ans = lookup.run(numbers)
    try:
        assert isinstance(ans[0], int)
    except:
        assert False, 'LookupModule class method run not returning the expected'

# Generated at 2022-06-11 15:54:44.092221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['1', '2']
    result = lookup.run(terms)
    if result[0] != '1' and result[0] != '2':
        raise Exception("random() function of python returns unexpected result")

# Generated at 2022-06-11 15:54:46.948728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    con = LookupModule()
    term = [1,2,3,4]
    con.run(term)
    # Need proper unit test

# Generated at 2022-06-11 15:54:48.587490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ThisClass = LookupModule(dict(), dict())
    terms = [1, 2, 3]
    ret = ThisClass.run(terms)
    assert(ret in terms)

# Generated at 2022-06-11 15:54:52.990011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    values = ['one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen']
    ret = lm.run(terms=values)
    assert len(ret) == 1
    assert ret[0] in values


# Generated at 2022-06-11 15:54:58.723933
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Turn on debug logging
    import logging
    import sys
    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

    # Create a test input list
    test_list = ["foo", "bar", "baz"]

    # Create LookupModule object
    lm = LookupModule()

    # Run method under test
    result = lm.run(test_list)

    # Test outcome
    assert(result)
    assert(len(result) == 1)
    assert(result[0] in test_list)


# Generated at 2022-06-11 15:55:00.582227
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [u'a', u'b', u'c']
    module = LookupModule()
    assert module.run(terms) in terms

# Generated at 2022-06-11 15:56:15.939615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    randlist = [1, 2, 3, 4]
    # need to convert the list to terms format
    terms = []
    for i in randlist:
        terms.append(str(i))

# Generated at 2022-06-11 15:56:26.790365
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # mock object
    class MockClass:
        def __init__(self, value=None):
            self._value = value

        def __str__(self):
            return self._value

        def __repr__(self):
            return self._value

    mock_obj = MockClass()

    # define return values of methods
    terms = [mock_obj, MockClass('multiple'), MockClass('terms')]
    terms_empty = []
    rand_choice = MockClass('random')

    # mock random.choice method
    def rand_choice_mock(terms):
        assert(terms)
        return rand_choice

    # mock random module
    random_mock = MockClass({'choice': rand_choice_mock})

    # mock modules
    modules_dict = {
        'random': random_mock
    }

# Generated at 2022-06-11 15:56:34.162318
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return_value = [u'go through the door']
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=[u'go through the door', u'drink from the goblet', u'press the red button', u'do nothing'], inject=None, **{})
    assert result == return_value

# Generated at 2022-06-11 15:56:39.561362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Create instance of LookupModule class
    lookup_module = LookupModule()
    #Call method run with params
    #terms - list of strings
    test_terms = ['qwerty', 'asdfgh', 'zxcvb']
    result = lookup_module.run(test_terms)
    #Check condition
    if not result:
        raise Exception("Result is empty")
    if result[0] not in test_terms:
        raise Exception("Result is not in terms")

# Generated at 2022-06-11 15:56:43.424801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    assert m.run(['mylist']) == ['mylist']
    assert m.run(['mylist', 'yourlist']) != ['mylist', 'yourlist']



# Generated at 2022-06-11 15:56:45.746512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['a', 'b']
    assert len(lookup_module.run(terms)) == 1

# Generated at 2022-06-11 15:56:51.231864
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    random.seed(0)
   
    lookup_module = LookupModule()
    
    assert lookup_module.run(terms=['a']) == ['a']
    assert lookup_module.run(terms=['a', 'b', 'c']) == ['a']
    assert lookup_module.run(terms=['a', 'b', 'c']) == ['c']
    assert lookup_module.run(terms=['a', 'b', 'c']) == ['a']
    assert lookup_module.run(terms=['a', 'b', 'c']) == ['b']
    random.seed()

# Generated at 2022-06-11 15:57:01.492840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    class TestCase(unittest.TestCase):

        def setUp(self):
            self.mock_choices = ['item1', 'item2', 'item3', 'item4']

        def test_choose_random_choice_when_term_is_a_list(self):
            lookup = LookupModule()
            self.assertIn(lookup.run(self.mock_choices)[0], self.mock_choices)

        def test_return_empty_list_when_term_is_empty_list(self):
            lookup = LookupModule()
            self.assertEqual([], lookup.run([]))

        def test_return_empty_list_when_term_is_none(self):
            lookup = LookupModule()

# Generated at 2022-06-11 15:57:08.265618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	try:
		with open('/tmp/lookup_plugin.out',"w") as fd:
			fd.write(LookupModule().run(['ansible','linux','data','pipeline']))
			fd.close()
	except Exception as e:
		with open('/tmp/lookup_plugin.err',"w+") as fd:
			fd.write(str(e))
			fd.close()

# Generated at 2022-06-11 15:57:13.817970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
        Testing method run()
    """

    module = AnsibleModule(
        argument_spec = dict(
            terms = dict(type='list', required=True)
        )
    )

    terms = ['c', 'b', 'a']

    random.seed(0)
    result = LookupModule().run(terms, inject=None, **dict())
    assert result == ['a']