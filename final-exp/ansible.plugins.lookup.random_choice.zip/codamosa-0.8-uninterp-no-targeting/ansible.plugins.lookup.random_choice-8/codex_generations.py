

# Generated at 2022-06-21 06:27:26.439234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import io
    import unittest

    ''' setup mocks'''
    class MockRandom(object):
        def choice(self, list):
            return random.choice(list)
        def random(self):
            return 0.5

    ''' test LookupModule'''
    class TestLookupModule(unittest.TestCase):
        def test_run_random(self):
            sys.modules['random'] = MockRandom()
            lookup = LookupModule()
            data = ["1", "2"]
            result = lookup.run(data)
            self.assertEqual(result, ["1"])

        def test_run_empty(self):
            sys.modules['random'] = MockRandom()
            lookup = LookupModule()
            data = []
            result = lookup.run(data)
           

# Generated at 2022-06-21 06:27:28.562969
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # create a class and check if it returned
    LookupModule()

# Generated at 2022-06-21 06:27:31.469623
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule()
    assert(lookup_class.run(["string1", "string2"]) == ["string1"])

# Generated at 2022-06-21 06:27:34.780856
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    ret = lookup_module.run(terms=["a", "b", "c", "d", "e", "f"])
    assert len(ret) == 1

# Generated at 2022-06-21 06:27:36.201554
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()

    assert lm is not None

# Generated at 2022-06-21 06:27:37.544921
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()



# Generated at 2022-06-21 06:27:40.064064
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms="terms")
    assert result == "terms"

# Generated at 2022-06-21 06:27:45.911081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Only one item in terms
    terms = ['ansible']
    random.seed(0)
    ret = LookupModule().run(terms)
    assert ret == ['ansible']

    # More than one item in terms
    terms = ['ansible', 'is', 'amazing']
    random.seed(0)
    ret = LookupModule().run(terms)
    assert ret == ['is']

# Generated at 2022-06-21 06:27:48.622917
# Unit test for constructor of class LookupModule
def test_LookupModule():

    random_choice = LookupModule()
    assert random_choice.run([]) == []

# Generated at 2022-06-21 06:27:52.548522
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = None
    result = lm.run(terms)
    assert result == None

    terms = ['1', '2', '3']
    result = lm.run(terms)
    assert len(result) == 1
    assert result[0] in terms

# Generated at 2022-06-21 06:27:58.221168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [1,2,3]
    assert lookup_module.run(terms) == 1 or lookup_module.run(terms) == 2 or lookup_module.run(terms) == 3
    assert lookup_module.run(None) is None

# Generated at 2022-06-21 06:28:00.064605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-21 06:28:09.498537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    #Lets start with an array of 2 elements
    terms = ["Through the door","Drink from the chalice"]

    #Array with 2 elements and choice should occour from 2 elements
    result = lu.run(terms)
    assert len(result) == 1

    #Array with 3 elements and choice should occour from 3 elements
    terms = ["Through the door","Drink from the chalice","Press the red button"]
    result = lu.run(terms)
    assert len(result) == 1

    #Array with 1 element
    terms = ["Through the door"]
    result = lu.run(terms)
    assert len(result) == 1
    assert result[0] == "Through the door"

    #Array with 1 element
    terms = []

# Generated at 2022-06-21 06:28:17.102218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case 1
    # run a test when no param is specified
    # it should not raise an exception but empty list
    lookup_instance = LookupModule()
    terms = [1, 2, 3]
    try:
        result = lookup_instance.run(terms = terms)
        assert isinstance(result, list)
    except Exception as e:
        raise e

    # test case 2
    # run a test when 0 param is specified
    # it should not raise an exception but empty list
    lookup_instance = LookupModule()
    terms = []
    try:
        result = lookup_instance.run(terms = terms)
        assert isinstance(result, list)
    except Exception as e:
        raise e

# Generated at 2022-06-21 06:28:21.692781
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Get initial vars
    terms = ["one","two","three"]
    inject = {}
    kwargs = {}

    # Create object of class LookupModule
    lookup_module = LookupModule()
    # Run run method of class LookupModule
    lookup_module.run(terms, inject, **kwargs)

# Generated at 2022-06-21 06:28:22.228740
# Unit test for constructor of class LookupModule
def test_LookupModule():

  LookupModule()

# Generated at 2022-06-21 06:28:23.129387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:28:26.553463
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["one","two","three"]
    # random_choice returns the list with random element from terms
    result = lookup_module.run(terms)
    assert(terms) == result

# Generated at 2022-06-21 06:28:29.519602
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["something from the list", "some other thing from the list"]
    looker = LookupModule()
    assert len(looker.run(terms)) == 1

# Generated at 2022-06-21 06:28:39.485944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def __assert(terms, expected_result):
        lookup_plugin = LookupModule()

        result = lookup_plugin.run(terms, {})
        assert result == expected_result, "For terms: %s, expected: %s, but got: %s" % (terms, expected_result, result)

    __assert([], [])
    __assert(["a"], ["a"])
    __assert(["a", "b"], ["a"])
    __assert(["a", "b", "c", "d", "e", "f"], ("a", "b", "c", "d", "e", "f"))

# Generated at 2022-06-21 06:28:42.817442
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().run([0]) != 1

# Generated at 2022-06-21 06:28:43.710435
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 06:28:44.880688
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 06:28:45.941372
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ut_obj = LookupModule()

    assert ut_obj is not None

# Generated at 2022-06-21 06:28:51.262415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def mock_random_choice(terms, unused_rand_int=None):
        return 'some item'
    random.choice = mock_random_choice
    terms = ['one', 'two', 'three']
    expect = 'some item'
    actual = LookupModule().run(terms, None)
    assert actual == expect

# Generated at 2022-06-21 06:28:57.535853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    assert len( lu.run( ['a', 'b', 'c'] ) ) == 1
    assert lu.run( ['a', 'b', 'c'] )[0] in ['a', 'b', 'c']
    assert lu.run([] ) == []
    assert lu.run( None ) == None

# Generated at 2022-06-21 06:29:00.336601
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    assert LookupModule.name == "random_choice"

# Generated at 2022-06-21 06:29:07.890576
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an object of class LookupModule
    testObj = LookupModule()

    # Create an empty list and assing it to variable terms
    terms = []
    assert testObj.run(terms) == []

    # Create a list with few elements and assing it to variable terms
    terms = ["a", "b", "c"]
    assert testObj.run(terms) in terms

    # Create a list with only one element and assing it to variable terms
    terms = ["a"]
    assert testObj.run(terms) == ["a"]

    # Create a list with duplicate elements and assing it to variable terms
    terms = ["a", "b", "c", "c", "c"]
    assert testObj.run(terms) in terms

# Generated at 2022-06-21 06:29:11.379372
# Unit test for constructor of class LookupModule
def test_LookupModule():

    test_input = [1,2,3]
    expected = [1]
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(test_input)
    assert expected == result

# Generated at 2022-06-21 06:29:14.558084
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    # TODO implement unit test
    assert True



# Generated at 2022-06-21 06:29:25.804448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(LookupModule.run([1,2,3,4,5], 0, [6,7,8,9,0]) == [6])
    assert(LookupModule.run([1,2,3,4,5], 0, [6,7,8,9,0]) == [6])
    assert(LookupModule.run([1,2,3,4,5], 0, [6,7,8,9,0]) == [6])

# Generated at 2022-06-21 06:29:31.553621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    # Case-1: None
    ret = lu.run(None)
    assert ret == None

    # Case-2: empty list
    ret = lu.run([])
    assert isinstance(ret, list)
    assert len(ret) == 0

    # Case-3: standard operation
    ret = lu.run([1, 2, 3])
    assert isinstance(ret, list)
    assert len(ret) == 1
    assert ret[0] in [1, 2, 3]

# Generated at 2022-06-21 06:29:33.746632
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:29:39.453462
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    result = lookup.run(terms=['a','b','c','d','e','f','g','h','i','j'])
    assert any(x==result[0] for x in ['a','b','c','d','e','f','g','h','i','j'])

# Generated at 2022-06-21 06:29:42.346146
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Unit test the constructor of the lookup module class
    '''
    ret = LookupModule()
    assert isinstance(ret, LookupModule)


# Generated at 2022-06-21 06:29:47.447960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    data_list = [1,2,3,4,5,6]
    shuffled_list = LookupModule().run([1,2,3,4,5,6])
    assert data_list != shuffled_list

# Generated at 2022-06-21 06:29:50.590872
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    ret = lookup_plugin.run([1,2,3,4,5], inject=None, test='test')
    assert isinstance(ret, list)
    assert len(ret) == 1
    assert ret[0] in [1,2,3,4,5]

# Generated at 2022-06-21 06:30:00.560603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This method unit tests the run method of the LookupModule
    class
    """
    class TestClass(object):
        """
        This is a test class for the LookupModule class.
        """
        terms = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']

        def run(self, terms, inject=None, **kwargs):
            test = LookupModule()
            test_terms = TestClass.terms
            return test.run(test_terms, None, **kwargs)

    test_object = TestClass()
    result = test_object.run(terms, None, **kwargs)
    assert result[0] in TestClass.terms

# Generated at 2022-06-21 06:30:04.421184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = ["1", "2", "3"]
    result = lookup_plugin.run(terms, inject=None, **{"wantlist": True})
    assert (result in terms)

# Generated at 2022-06-21 06:30:10.352826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.basedir = '/tmp'
    l.run = [1, 2, 3]
    assert l.run(l.run) in l.run

# Generated at 2022-06-21 06:30:26.271220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("In test_LookupModule_run method")

    terms = ["A", "B", "C", "D"]
    lookup = LookupModule()
    result = lookup.run(terms)

    assert result in terms
    print("test_LookupModule_run - OK")

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:30:28.302791
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module_instance = LookupModule()
    assert isinstance(lookup_module_instance, LookupModule) == True


# Generated at 2022-06-21 06:30:31.316051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing', 'die']
    ran = 'do nothing'

    lookup = LookupModule()
    r = lookup.run(data)
    assert r[0] in data

# Generated at 2022-06-21 06:30:43.179800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"], inject=None) == ['3']
    assert lookup_module.run(terms=["1", "2", "3", "4", "5"], inject=None) == ['1']
    assert lookup_module.run(terms=["1", "2", "3", "4", "5"], inject=None) == ['1']
    assert lookup_module.run(terms=["1", "2", "3", "4", "5"], inject=None) == ['1']

# Generated at 2022-06-21 06:30:46.512877
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["one", "two", "three", "four", "five"]) == ["one"]

# Generated at 2022-06-21 06:30:56.218276
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule
    l = LookupModule()

    # Create a list of integers
    numbers=[1,2,3,4,5]

    # Create a list of strings
    terms=['a', 'b', 'c', 'd', 'e']

    # Try to run random choice on a different list of integers
    assert l.run([]) == [], "Incorrect list of terms for []"

    assert l.run([1]) == [1], "Incorrect list of terms for [1]"

    # The following are examples of lists passed to the LookupModule
    example_lists = [numbers,terms]

    # Loop through the list of lists
    for terms in example_lists:

        # Use the run method of the class LookupModule to run the random choice
        l.run(terms)

        # The length

# Generated at 2022-06-21 06:31:01.634480
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None, "Unable to instantiate LookupModule class"

# Generated at 2022-06-21 06:31:02.238733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(False)

# Generated at 2022-06-21 06:31:10.537930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [["a", "b", "c"]]
    terms = [["a", "b", "c"]]

    lookup_obj = LookupModule()
    result = lookup_obj.run(terms, inject=args)

    assert len(result) == 1
    assert result[0] in terms[0]



# Generated at 2022-06-21 06:31:11.972259
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 06:31:32.947303
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert repr(LookupModule)

# Generated at 2022-06-21 06:31:36.193504
# Unit test for constructor of class LookupModule
def test_LookupModule():
  ansible_random_choice_instance = LookupModule()
  # test run
  assert ansible_random_choice_instance.run(terms=['a','b','c']) == ['c']

# Generated at 2022-06-21 06:31:38.613906
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["one", "two", "three", "four"]
    ret = LookupModule().run(terms)
    assert ret != terms

# Generated at 2022-06-21 06:31:46.430031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input variables
    terms = [1, 2, 3, 4]
    terms_none = None
    terms_one = [1]

    # Expected result
    result_random = [random.choice(terms)]

    # Actual result
    result_actual_random = LookupModule().run(terms)

    # Test
    assert result_random == result_actual_random
    assert LookupModule().run(terms_none) == terms_none
    assert LookupModule().run(terms_one) == terms_one

# Generated at 2022-06-21 06:31:48.513120
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  a = [1, 2, 3, 4]
  b = lm.run(a)
  assert (b != a)

# Generated at 2022-06-21 06:31:52.161386
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    the_list = ["a", "b", "c"]
    result = lookup.run(the_list)
    assert len(result) == 1
    assert result[0] in the_list

# Generated at 2022-06-21 06:31:58.272950
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    f = LookupModule

    func_name = 'run'

    # Test 1

    terms = ['superadmin', 'admin', 'user', 'guest']
    inject = {}
    results = f.run(func_name, terms, inject)
    assert results == ['admin']

    # Test 2: Check to see if error is raised when terms is not a list

    terms = "asdlksdlsd"
    try:
        results = f.run(func_name, terms, inject)
        success = True
    except AnsibleError as e:
        success = False
    assert not success

# Generated at 2022-06-21 06:31:59.304595
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule() , LookupModule)

# Generated at 2022-06-21 06:32:03.544360
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        'term1',
        'term2'
    ]
    random.seed(a=0)  # pylint: disable=undefined-variable
    lu = LookupModule()
    result = lu.run(terms=terms)
    assert result == ['term1']

# Generated at 2022-06-21 06:32:05.480217
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['a', 'b', 'c']
    ret = LookupModule().run(terms)
    assert ret in terms

# Generated at 2022-06-21 06:32:47.890457
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:32:49.297152
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-21 06:32:54.171284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['a', 'b', 'c']

    # Create object
    lookup_module = LookupModule()

    # Retrieve random value from list
    result = lookup_module.run(terms)

    # Check if correct type
    assert isinstance(result, list)

    # Check if correct length
    assert len(result) == 1

    # Check if value in initial list
    assert result[0] in terms

# Generated at 2022-06-21 06:32:55.907669
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert type(LookupModule(None, None, None, None)) == LookupModule


# Generated at 2022-06-21 06:32:59.111230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['a', 'b', 'c']
    lookup_module = LookupModule()
    random_choice = lookup_module.run(terms)
    assert random_choice[0] != ''
    assert random_choice[0] in terms

# Generated at 2022-06-21 06:33:02.785551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameters = dict()
    module = LookupModule()
    terms = [1, 2, 3]
    result = module.run(terms, inject=None, **parameters)
    assert result[0] in terms


# Generated at 2022-06-21 06:33:04.882653
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['a','b','c','d']
    result = lm.run(terms)
    assert result in terms

# Generated at 2022-06-21 06:33:10.418786
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testdict = {'name': 'Magic 8 ball for MUDs', 'debug': {'msg': '{{ item }}'}, 'with_random_choice': [('go through the door', 'drink from the goblet', 'press the red button', 'do nothing')]}
    assert LookupModule(testdict).run(testdict['with_random_choice'])

# Generated at 2022-06-21 06:33:12.890533
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for class LookupModule """
    module = LookupModule()
    expected_result = 'bar'
    assert module.run(['foo', 'bar']) == [expected_result]

# Generated at 2022-06-21 06:33:15.968653
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:34:42.379236
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test instantiation of class LookupModule
    lookup_plugin = LookupModule()

    # test run method
    assert isinstance(lookup_plugin.run(["a", "b", "c"]), list)

# Generated at 2022-06-21 06:34:45.235755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # one element
    assert lm.run(['a'])[0] == 'a'
    # multiple elements
    assert lm.run(['a', 'b'])[0] in ['a', 'b']
    # no elements
    assert lm.run([]) == []

# Generated at 2022-06-21 06:34:49.228334
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # instantiate the class
    my_class = LookupModule()
    assert issubclass(LookupModule, LookupBase) == True # tests if it's a subclas of LookupBase
    assert isinstance(my_class, LookupBase) == True # tests if it's an instance of LookupBase

# Generated at 2022-06-21 06:34:52.114359
# Unit test for method run of class LookupModule
def test_LookupModule_run():

   # look = LookupModule()
   # print(look.run([1,2,3,4,5,6,7,8,9,10]))
   assert True==True

# Generated at 2022-06-21 06:34:56.228248
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm_obj = LookupModule()
    terms = [1,2,3,4,5]
    result = lm_obj.run(terms)
    assert type(result) == list
    assert result[0] in terms

# Generated at 2022-06-21 06:34:56.855988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-21 06:35:00.805132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [3, 4, 5]
    lookup_module = LookupModule()
    random_choice = lookup_module.run(terms)
    assert random_choice in terms

# Generated at 2022-06-21 06:35:01.408782
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:35:05.363556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    m_lm = LookupModule()
    terms = [ "go through the door", "drink from the goblet", "press the red button", "do nothing" ]

    # Act
    result = m_lm.run(terms)

    # Assert
    assert len(result) == 1
    assert result[0] in terms

# Generated at 2022-06-21 06:35:10.235862
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    terms1 = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    assert lookup_obj.run(terms1) in terms1