

# Generated at 2022-06-21 06:27:21.889007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Apply test with one empty parameter
    result = LookupModule().run([])
    assert len(result) == 0

    # Apply test with one of the parameter empty
    result = LookupModule().run([''])
    assert len(result) == 1
    assert result[0] == ''

    # Apply test with normal case
    result = LookupModule().run(['a', 'b', 'c'])
    assert len(result) == 1
    assert result[0] in ['a', 'b', 'c']

# Generated at 2022-06-21 06:27:23.095908
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module.run is not None


# Generated at 2022-06-21 06:27:24.743352
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule(None, None, None, None)


# Generated at 2022-06-21 06:27:25.973467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert isinstance(my_lookup, LookupModule)

# Generated at 2022-06-21 06:27:34.679561
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None
    terms = [1, 2, 3]
    ret = lookup_module.run(terms, None, None)
    assert ret is not None
    assert len(ret) is 1
    assert ret[0] in terms
    try:
        ret = lookup_module.run(None, None, None)
        assert False
    except AnsibleError as e:
        assert str(e).find("Unable to choose random term:") >= 0

# Generated at 2022-06-21 06:27:36.938526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.load()
    result = len(lookup.run(['one','two','three']))
    assert result == 1

# Generated at 2022-06-21 06:27:38.008474
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random_lookup = LookupModule()
    assert isinstance(random_lookup, LookupModule)

# Generated at 2022-06-21 06:27:44.203057
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test case 1
    debug = dict(msg="Hello World")
    terms = ['1', 'a', 'b', 'c']

    result = LookupModule(None, None).run(terms, None, debug)

    assert result in terms

    # test case 2
    terms = ['1', 'a', 'b', 'c']

    result = LookupModule(None, None).run(terms, None, None)

    assert result in terms

# Generated at 2022-06-21 06:27:46.326491
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert "LookupModule" == str(LookupModule.__class__)

# Generated at 2022-06-21 06:27:54.139006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit-test setup
    lookup_module = LookupModule()

    # Test Coding
    terms = [1,2,3,4,5]
    result = lookup_module.run(terms)

    # Unit-test assertions
    assert isinstance(result, list), "Result must be a list"
    assert result[0] in terms, "Result must be in the list of terms"

    # Test exception handling
    try:
        lookup_module.run(['a'])
    except AnsibleError:
        pass
    else:
        raise AssertionError("Exception must be raised for invalid input")

# Generated at 2022-06-21 06:28:00.808077
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule('random_choice')
    data = ['hello', 'world', 'foo', 'bar']
    ret = lookup_module.run(data, inject={}, **{})
    if ret not in data:
        raise Exception('random choice error.')

# Test random_choice module

# Generated at 2022-06-21 06:28:08.574731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = [
        ['Run lookup module test.', {}, ['Run lookup module test.']],
        ['Run lookup module test.', None, ['Run lookup module test.']],
        ['Run lookup module test.', {'a': 'A'}, ['Run lookup module test.']],
        [
            ['a', 'b'],
            {},
            ['a, b']
        ],
    ]
    for term, parameters, expected in data:
        try:
            instance = LookupModule()
            result = instance.run(term, parameters)
            assert result == expected
        except:
            print('When term=%s and parameters=%s, the result is not %s' % (term, parameters, expected))

# Generated at 2022-06-21 06:28:09.498362
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:28:10.941060
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret is not None

# Generated at 2022-06-21 06:28:12.670166
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin != None

# Generated at 2022-06-21 06:28:19.224016
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an instance of LookupModule
    # Instance of AnsibleModule is passed as first argument
    # Must depart with 'test_'
    lookup_plugin = LookupModule(None, None, None)
    # Set the global variable ansible_version
    lookup_plugin.ansible_version = (1, 2, 3)
    assert lookup_plugin.ansible_version == (1, 2, 3)

# Generated at 2022-06-21 06:28:22.920263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule.run(["foo", "bar"])
    assert(ret != ["foo", "bar"])
    assert(ret == "foo" or ret == "bar")

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:28:31.168561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    aModule = LookupModule()
    assert aModule.run(terms=[1,2,3], inject=None, variable_manager=None, loader=None)
    assert aModule.run(terms=[1,2,3], inject=None, variable_manager=None, loader=None)
    assert aModule.run(terms=[1,2,3], inject=None, variable_manager=None, loader=None)
    assert aModule.run(terms=[1,2,3], inject=None, variable_manager=None, loader=None)

# Generated at 2022-06-21 06:28:39.793126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Check list with one element
    terms = ["one element"]
    result = lookup_module.run(terms)
    assert len(result) == 1

    # Check list with 2 elements
    terms = ["first", "second"]
    result = lookup_module.run(terms)
    assert len(result) == 1

    # Check empty list
    terms = []
    result = lookup_module.run(terms)
    assert len(result) == 0

# Generated at 2022-06-21 06:28:43.203687
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # ansible.module_utils.basic._ANSIBLE_ARGS[0] is set to /dev/null.
  # ansible.module_utils.basic.SYS_ARGV[0] is set to /dev/null.
  #
  assert LookupModule() is not None

# Generated at 2022-06-21 06:28:52.610005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(["1", "2", "3"])
    l.run(["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"])

# Generated at 2022-06-21 06:28:54.959833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lup = LookupModule()
    assert lup.run(terms=None) == []

# Generated at 2022-06-21 06:28:56.725782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Simple only one element in list
    assert(LookupModule.run(None, ["Hello"])[0] == "Hello")
    # Simple random choice on 3 elements list
    mylist = ["Hello", "World", "My name is Ansible"]
    assert(LookupModule.run(None, mylist)[0] in mylist)

# Generated at 2022-06-21 06:28:58.309564
# Unit test for constructor of class LookupModule
def test_LookupModule():
    n = LookupModule()
    assert isinstance(n, LookupModule)

# Generated at 2022-06-21 06:28:58.915441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 06:29:02.838165
# Unit test for constructor of class LookupModule
def test_LookupModule():
    w = LookupModule()

    assert w.run(None) == None 
    assert w.run([]) == []
    assert w.run([1,2,3]) != []
    assert w.run(['one','two','three']) != []

# Generated at 2022-06-21 06:29:03.412358
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:29:05.322151
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)
    assert lookup.run == LookupModule.run

# Generated at 2022-06-21 06:29:17.392171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    # No term(s)
    no_term = []
    res = lookup.run(no_term)
    assert res == [], "When term is empty list, the result should be empty list"

    # One term
    one_term = ["a", "b", "c"]
    res = lookup.run(one_term)
    assert res == ["a"] or res == ["b"] or res == ["c"] or res == ["d"], "When term contains one element, the result should contain only that element"

    # Multiple terms
    terms = ["a", "b", "c"]
    res = lookup.run(terms)
    assert res == ["a"] or res == ["b"] or res == ["c"], "When term contains multiple elements, the result should contain one of those elements"

# Generated at 2022-06-21 06:29:21.186440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup = LookupModule() # instantiate
  assert isinstance(lookup.run(terms = [1, 2, 3]), list)
  assert isinstance(lookup.run(terms = []), list)

# Generated at 2022-06-21 06:29:29.235235
# Unit test for constructor of class LookupModule
def test_LookupModule():
    json_result = {
        "_raw": ""
    }
    t = LookupModule()
    result = t.run(terms="")
    assert(result == "")
    result = t.run(terms=["hello", "world"])
    assert result in ("hello", "world")

# Generated at 2022-06-21 06:29:33.799849
# Unit test for constructor of class LookupModule
def test_LookupModule():
    values_list = ['a', 'b', 'c']
    l = LookupModule()
    results = l.run(values_list)
    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0] in values_list

# Generated at 2022-06-21 06:29:37.106918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    assert my_lookup.run(terms=["one", "two", "three"]) == ["one"] or ["two"] or ["three"]

# Generated at 2022-06-21 06:29:39.291768
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, 'run')

# Generated at 2022-06-21 06:29:41.053242
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()
    l.run(["1","2","3"])

# Generated at 2022-06-21 06:29:44.210403
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    items = ["1", "2", "3"]

    assert lookup._flatten(items) == items, "_flatten() failed for a simple list. Output %s" % lookup._flatten(items)

# Generated at 2022-06-21 06:29:49.634795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    #expected result for input "myMessage"
    expected_result=[u'myMessage']
    #create instance of LookupModule
    argument_spec=dict()
    rand_choice=LookupModule(None,argument_spec,None,None)
    #call function run of class LookupModule with "myMessage"
    result=rand_choice.run(["myMessage"])
    #assert result
    assert result==expected_result

# Generated at 2022-06-21 06:29:58.068941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    with pytest.raises(AnsibleError) as execinfo:
        lookup_module.run([])
    assert 'Unable to choose random term:' in str(execinfo.value)
    assert lookup_module.run([1, 2, 3]) == [2] # is not a random choice (unit testing is not random)

# Generated at 2022-06-21 06:30:06.831937
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run with success
    lu_obj = LookupModule()
    result = lu_obj.run(terms=[''])
    assert result == ['']

    result = lu_obj.run(terms=['ab'])
    assert result == ['ab']

    result = lu_obj.run(terms=['ab', 'bc'])
    assert result in [['ab'], ['bc']]

    # Unit test for method run with failure
    result = lu_obj.run(terms='')
    assert result == []

# Generated at 2022-06-21 06:30:08.275729
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [1,2,3]
    test = LookupModule()
    test.run(terms)

# Generated at 2022-06-21 06:30:21.183384
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # data generated with:
    # python -c "import random; print '\n'.join(str(random.randint(0,100)) for _ in range(100))" > test
    f = open('/Users/sashs/Documents/Git/ansible-modules-core/test')
    lines = f.readlines()
    lines = [line.strip() for line in lines]
    lines = [line for line in lines if line]

    l = LookupModule()
    result = l.run(lines)
    assert len(result) == 1
    assert result[0] in lines

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:30:24.396627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['a1', 'b2']
    lookup_module = LookupModule()
    assert lookup_module.run(terms) in [['a1'], ['b2']]

# Generated at 2022-06-21 06:30:25.534359
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l != None

# Generated at 2022-06-21 06:30:29.272444
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor of class LookupModule
    lookup_module = LookupModule()
    # Unit test for run() of class LookupModule
    # parameters of run()
    terms = 'test'
    inject = 'test'
    kwargs = 'test'
    lookup_module.run(terms, inject, **kwargs)

# Generated at 2022-06-21 06:30:32.658243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([1,2,3]) == [2]
    assert LookupModule().run([1,2,3], inject={'random': random.Random(0)}) == [1]

# Generated at 2022-06-21 06:30:37.304423
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    result = lm.run([1, 2, 3, 4, 5])
    assert result
    assert len(result) == 1

# Generated at 2022-06-21 06:30:41.161758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    values = ['one', 'two', 'three']
    module = LookupModule()

    # run once to get the random choice
    result = module.run(values)

    # assert the random choice is in the list of expected values
    assert result[0] in values

# Generated at 2022-06-21 06:30:52.670013
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialize the class
    random_choice = LookupModule()

    # Test with a random element of a list
    random_choice.run([0, 1, 2, 3, 4, 5], None)

    # Test with an empty list
    random_choice.run([], None)

    # Test with a list of multiple elements
    random_choice.run(['a', 'b', 'c'], None)

    # Test with a list of a single element
    random_choice.run(['a'], None)

    # Test with an empty list
    random_choice.run(None, None)

    # Test with a random element of a string
    random_choice.run('abcde', None)

    # Test with an empty string
    random_choice.run('', None)

    # Test with a string of multiple elements
    random

# Generated at 2022-06-21 06:30:58.671275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader({
        'get_basedir': lambda *args, **kwargs: '',
        'get_vars': lambda *args, **kwargs: {},
        'path_dwim': lambda *args, **kwargs: [],
    })

    terms = ['ansible', 'openstack', 'salt']
    refute = terms[:]
    result = lookup.run(terms)
    assert isinstance(result, list)
    assert result
    assert len(result) == 1
    assert result[0] in terms
    assert result[0] in refute
    refute.remove(result[0])
    assert not [x for x in result if x in refute]

# Generated at 2022-06-21 06:30:59.391086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:31:25.930185
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import unittest, sys
    from ansible.plugins.loader import lookup_loader

    class TestLookupModule(unittest.TestCase):

        def test_module(self, terms=['fire', 'earth', 'wind', 'water']):
            loader = lookup_loader
            terms = terms
            random_choice = loader.get('random_choice')
            my_random_choice = random_choice.LookupModule()
            my_random_choice.run(terms)
            assert len(set(terms).intersection(my_random_choice.run(terms))) == 1

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestLookupModule))
    result = unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 06:31:30.609764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    list_elements = ["apples", "oranges", "pears"]
    random_element = module.run(terms = list_elements, inject = None, **dict())
    assert random_element in list_elements

# Generated at 2022-06-21 06:31:32.365978
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()

# Generated at 2022-06-21 06:31:38.113067
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lm = LookupModule()
    # Create an arbitrary list
    list = ["string1", "string2", "string3"]
    # Run method run of LookupModule
    value = lm.run(list)
    # Check if value returned is a valid element of the original list
    assert value[0] in list

# Generated at 2022-06-21 06:31:40.195494
# Unit test for constructor of class LookupModule
def test_LookupModule():
    fn = LookupModule()
    assert isinstance(fn, LookupModule)

# Tests for methods of class LookupModule

# Generated at 2022-06-21 06:31:46.200369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialization
    lookup = LookupModule()

    # Test
    assert lookup.run(terms=["A", "B", "C"]) == ["A"] or lookup.run(terms=["A", "B", "C"]) == ["B"] or lookup.run(terms=["A", "B", "C"]) == ["C"]

# Generated at 2022-06-21 06:31:52.359910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with a list
    try:
        ret = LookupModule().run(['one', 'two', 'three'])
    except Exception as e:
        raise AnsibleError("Unable to choose random term: %s" % to_native(e))
    assert isinstance(ret, list)
    assert ret[0] in ['one', 'two', 'three']

    # test with an empty list
    try:
        ret = LookupModule().run(list())
    except Exception as e:
        raise AnsibleError("Unable to choose random term: %s" % to_native(e))
    assert isinstance(ret, list)
    assert len(ret) == 0

# Generated at 2022-06-21 06:31:53.617371
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:31:57.528518
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_obj = LookupModule()

# Generated at 2022-06-21 06:31:59.370216
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   # Note: This is not a correct test. With randome_coice, the result is nondeterministic.
   assert (1, 2) == (1, 2)

# Generated at 2022-06-21 06:32:38.034071
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:32:43.488469
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Store class name to local variable
    cls = LookupModule()

    # Get method from class to local variable
    method = cls.run

    # Check if method returns
    assert method([], None), 'LookupModule.run() should return'
    assert method(["a","b"], None), 'LookupModule.run() should return'

# Generated at 2022-06-21 06:32:49.392441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["first", "second", "third"]
    terms_random = LookupModule().run(terms)
    assert terms_random in terms

# Generated at 2022-06-21 06:32:54.997183
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test to return the random item from list
    def run_test(items):

        # Create an instance of class LookupModule
        lookupModule = LookupModule()

        # Test to return the random item from list
        assert lookupModule.run(items)[0] in items

    run_test(['item1', 'item2', 'item3'])

# Generated at 2022-06-21 06:33:03.658480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test if lookup returns one item for each term only one term
    terms = ['one', 'two', 'three']
    single_choice = lookup.run(terms)
    assert len(terms) == 3
    assert len(single_choice) == 1
    assert terms.count(single_choice[0]) == 1

    # Test if lookup returns one item for each term only one term
    terms = ['one', 'two', 'three']
    single_choice = lookup.run(terms)
    assert len(terms) == 3
    assert len(single_choice) == 1
    assert terms.count(single_choice[0]) == 1


# Generated at 2022-06-21 06:33:09.983452
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Testing with a list of strings
    l = ["hello", "world", "bye", "everybody"]
    # Tests if an element of the list is the same
    assert random.choice(l) in l
    
    # Testing with a list of objects
    l = [1, 2.3, 5.6, 100]
    # Tests if an element of the list is the same
    assert random.choice(l) in l

# Generated at 2022-06-21 06:33:16.557021
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import random
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from ansible.plugins.lookup.random_choice import LookupModule
    class TestLookupModuleRun(unittest.TestCase):
        def setUp(self):
            self.test_random_choice = LookupModule()
            self.test_terms_len = random.randint(1, 10)
            self.test_terms_list = []
            for i in range(0, self.test_terms_len):
                self.test_terms_list.append(random.randint(0, 100))

# Generated at 2022-06-21 06:33:23.632955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with empty list
    result = LookupModule().run([])
    assert result == []

    # Test with single value
    result = LookupModule().run(['a'])
    assert result == ['a']

    # Test with multiple values
    for runs in range(0, 100):
        result = LookupModule().run(['a', 'b', 'c'])
        assert len(result) == 1
        assert result[0] in ['a', 'b', 'c']

# Generated at 2022-06-21 06:33:26.187946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["first", "second"]
    # Depends on random so we cannot be 100% sure
    assert lookup.run(terms) in terms

# Generated at 2022-06-21 06:33:32.115335
# Unit test for constructor of class LookupModule
def test_LookupModule():
    list_terms = [
        "go through the door",
        "drink from the goblet",
        "press the red button",
        "do nothing"
    ]
    obj = LookupModule()
    random_result = obj.run(list_terms)
    assert random_result in list_terms
    assert not isinstance(random_result, list)

# Generated at 2022-06-21 06:34:53.632018
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 06:34:54.508109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:35:01.231331
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule({},{"a":[1,2]}).run([1,2]) == [1,2]
    assert len(LookupModule({},{"a":[1,2]}).run([1,2])) == 2
    assert len(LookupModule({},{"a":[1,2]}).run([1])) == 1
    assert len(LookupModule({},{"a":[1,2]}).run([])) == 0

# Generated at 2022-06-21 06:35:02.149869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myObject = LookupModule()

# Generated at 2022-06-21 06:35:09.043879
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for method run of class LookupModule for multiple elements in the list
    t = [
        "Elem1",
        "Elem2",
        "Elem3"
    ]
    rl = LookupModule()
    res = rl._lookup_plugin.run(t)
    assert (res in t)

    # Test for method run of class LookupModule for single element in the list
    t = [
        "Elem1"
    ]
    rl = LookupModule()
    res = rl._lookup_plugin.run(t)
    assert (res == t[0])

    # Test for method run of class LookupModule for the empty list
    t = []
    rl = LookupModule()
    res = rl._lookup_plugin.run(t)

# Generated at 2022-06-21 06:35:17.779664
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("***** Unit tests begin *****")
    lm = LookupModule()
    print("\nLookupModule() unit tests:\n")
    print("lookup_class_name = ", lm.lookup_class_name)
    print("lookup_provider = ", lm.lookup_provider)
    print("lookup_loader = ", lm.lookup_loader)
    print("run = ", lm.run)
    print("\n***** Unit tests end *****")


# Generated at 2022-06-21 06:35:19.792378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test.run(terms=["test", "wait"], inject=None, **{})

# Generated at 2022-06-21 06:35:21.103987
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module is not None)

# Generated at 2022-06-21 06:35:22.545187
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().run(terms="") == ""


# Generated at 2022-06-21 06:35:23.648512
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None