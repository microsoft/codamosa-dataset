

# Generated at 2022-06-21 06:27:19.230399
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ''' testing constructor of class LookupModule '''
    ret = LookupModule()

    assert(type(ret) == LookupModule)


# Generated at 2022-06-21 06:27:20.649315
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class_ins = LookupModule()
    assert class_ins

# Generated at 2022-06-21 06:27:21.491582
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-21 06:27:22.407572
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:27:24.951990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['value1', 'value2']
    ret = lookup_module.run(terms)
    assert ret in terms

# Generated at 2022-06-21 06:27:29.623814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['test1', 'test2', 'test3']
    l = LookupModule()
    value = l.run(terms)
    assert value in terms

# Generated at 2022-06-21 06:27:30.086402
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() != None

# Generated at 2022-06-21 06:27:36.783070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # selected_elements and elements are list of strings
    # when elements is a non-empty list, selected_elements[0] is a random element from elements
    # when elements is an empty list, selected_elements is also an empty list
    elements = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    selected_elements = LookupModule().run(elements)
    assert selected_elements[0] in elements

# Generated at 2022-06-21 06:27:38.742558
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:27:40.232378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    assert mod != None


# Generated at 2022-06-21 06:27:45.562674
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_obj = LookupBase()
    assert test_obj

# Run tests with `python3 -m pytest test_random_choice.py -v`

# Generated at 2022-06-21 06:27:52.507500
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    test_inject = {}
    test_terms = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    test_ret = lookup_module.run(test_terms, test_inject)
    assert test_ret in test_terms

# Generated at 2022-06-21 06:28:00.465181
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    terms = [
        'a',
        'b',
        'c',
        'd',
        'e'
    ]
    choices = []
    attempts = 100
    while len(choices) < attempts:
        choice = lookup_module.run(terms=terms)[0]
        if choice not in choices:
            choices.append(choice)

    assert len(choices) == len(terms)

# Generated at 2022-06-21 06:28:01.052701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:28:02.020059
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-21 06:28:04.466997
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule([[1,2],[2,3],[3,4]])
    assert c.lookup([1,2]) == [1,2]

# Generated at 2022-06-21 06:28:07.032789
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    testlist = ["hello", "world", "sup"]
    assert lm.run(testlist)


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:28:08.368242
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  return lookup


# Generated at 2022-06-21 06:28:11.992616
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_LookupModule = LookupModule()
    assert test_LookupModule is not None

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:28:13.242207
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module


# Generated at 2022-06-21 06:28:21.781089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Check numeric value of variable with value "1"
    # init object
    obj = LookupModule()
    # init variable
    terms = ["foo", "bar", "baz"]
    # run test
    test = obj.run(terms = terms)
    res = False
    for i in range(3):
        if test[0] in terms:
            res = True
            break
    assert res == True


# Generated at 2022-06-21 06:28:23.377592
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert len(lookup.run([0,1,2,3,4])) == 1

# Generated at 2022-06-21 06:28:24.540919
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:28:25.200654
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:28:35.410174
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with terms
    terms = ["a","b","c"]
    lm = LookupModule()
    result = lm.run(terms=terms)

    assert isinstance(result, list), "Expected type for result is list"
    assert result and result[0] in terms, "Result %s does not match with any element in list of terms" % result[0]

    # Test with empty terms
    terms = []
    lm = LookupModule()
    result = lm.run(terms=terms)

    assert result is None, "Result is none"
    assert result is None, "Result is none"


# Generated at 2022-06-21 06:28:45.204328
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # instantiate class LookupModule, pass in sample arguments for test
    lookup_instance = LookupModule(
        loader=None,
        templar=None,
        shared_loader_obj=None)

    # unit test for run method of class LookupModule
    def test_run():

        # instantiate class LookupModule, pass in sample arguments for test
        lookup_instance = LookupModule(
            loader=None,
            templar=None,
            shared_loader_obj=None)

        # unit test for run method of class LookupModule
        def test_run():
            # use assert statements to test the results
            assert lookup_instance.run(
                terms=[
                    'a',
                    'b',
                    'c'],
                inject=None,
                **{}) == ['b']
            assert lookup_instance

# Generated at 2022-06-21 06:28:46.592232
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_random_choice = LookupModule()

    assert my_random_choice is not None

# Generated at 2022-06-21 06:28:47.217687
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:28:50.931472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results = LookupModule().run(terms=['a', 'b', 'c'])
    assert (len(results) == 1)
    assert (results[0] in ['a', 'b', 'c'])
    return True


# Generated at 2022-06-21 06:28:53.522437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(None, None).run([1, 2, 3, 4]) == [4]

# Generated at 2022-06-21 06:29:00.700455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    items = ['aa', 'bb', 'cc']
    lookup = LookupModule()
    assert lookup.run(items) in items

# Generated at 2022-06-21 06:29:07.398370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
        ansible module unit test for Ansible Module LookupModule
    """
    try:
        from ansible.utils.display import Display
        display = Display()
        display.verbosity = 3
    except ImportError:
        pass

    ansible_lookup = LookupModule()
    ansible_lookup.set_options({'verbosity': 0})
    test_list = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    result = ansible_lookup.run(terms=test_list, inject=None, verbosity=1)
    assert result[0] in test_list

# Generated at 2022-06-21 06:29:10.670717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["one","two"],None) == ["one"] or lookup.run(["one","two"],None) == ["two"]

# Generated at 2022-06-21 06:29:14.558090
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=[1, 2, 3, 4, 5], inject={})

# Generated at 2022-06-21 06:29:17.390346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    result = look.run(["foobar1","foobar2","foobar3"])
    assert result[0] in ["foobar1","foobar2","foobar3"]

# Generated at 2022-06-21 06:29:23.040913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize lookup module
    rcl = LookupModule()
    # select a random element from a list
    rcl.run(['pk','tj','fr','ag','bh','zc','br'])
    # select a random element from a string
    rcl.run('pk tj fr ag bh zc br'.split())

# Generated at 2022-06-21 06:29:28.074414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(2)
    lookup_obj = LookupModule()
    item = lookup_obj.run(['hello', 'test', 'foo', 'bar'])
    assert item == ["bar"]
    item = lookup_obj.run(['hello'])
    assert item == ["hello"]
    item = lookup_obj.run([])
    assert item == []

# Generated at 2022-06-21 06:29:31.490741
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = [ 'A', 'B', 'C', 'D']
    test_ret = LookupModule.run(None, test_terms)
    assert len(test_ret) == 1

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-21 06:29:34.974542
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['foo','bar','baz']
    r = LookupModule().run(terms)
    assert r != [], "lookup module lookup_plugin.random_choice test failed"

# Generated at 2022-06-21 06:29:36.534110
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-21 06:29:46.840499
# Unit test for constructor of class LookupModule
def test_LookupModule():
    foo = LookupModule()
    assert foo is not None

# Generated at 2022-06-21 06:29:47.337321
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:29:49.773667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert [1, 2, 3] in lm.run([[1, 2, 3], [4, 5, 6]]), "List should be in list"


# Generated at 2022-06-21 06:30:01.967081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import unittest
    current_directory = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, current_directory + "/../../../../")
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 06:30:08.122780
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random_choice = LookupModule()
    assert random_choice.run(["term1", "term2", "term3"]) in ["term1", "term2", "term3"]

    try:
        random_choice.run("ERROR")
    except AnsibleError as e:
        assert e.message == "Unable to choose random term: 'str' object is not callable"

# Generated at 2022-06-21 06:30:10.446327
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule([1, 2, 3, 4, 5]).run()
    assert result in [2, 3, 4, 5, 1]

# Generated at 2022-06-21 06:30:12.671009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module=LookupModule()
    lookup_module.run(['a', 'b', 'c'])
    assert True

# Generated at 2022-06-21 06:30:13.644237
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-21 06:30:14.194334
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:30:23.263480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import wrap_var

    random.seed(123)
    m = LookupModule()
    terms = [42]
    assert m.run(terms=terms, inject=dict()) == [42]

    terms = [1, 2, 3, 4]
    assert m.run(terms=terms, inject=dict()) == [1]

    assert m.run(terms=None, inject=dict()) is None

    assert m.run(terms=wrap_var(None), inject=dict()) is None

# Generated at 2022-06-21 06:30:44.645852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
     lookup_obj = LookupModule()
     terms = ["Go through the door", "drink from the goblet", "press the red button", "do nothing"]
     result = lookup_obj.run(terms)
     assert len(result) == 1
     assert result[0] in terms
     #assert lookup_obj.run(terms) == [random.choice(terms)]
     #assert lookup_obj.run(None) == []

# Generated at 2022-06-21 06:30:46.203297
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-21 06:30:48.268640
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup,LookupModule) == True


# Generated at 2022-06-21 06:30:57.002234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # NOTE: this is not really a unit test, so it's disabled unless being
    # run explicitly.  It's more of a fuzz tester because it doesn't
    # actually assert anything useful.  This should be fixed to do something
    # more useful, but the idea was to catch a random_choice index error
    # that was seen on the mailing list a year ago.

    results = []

    for i in range(0, 10):
        lookup_module = LookupModule()
        results.append(lookup_module.run(["1", "2", "3"]))

    print(results)

# The following allows this to be called directly for testing, but will
# still allow it to be used as a lookup.
if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-21 06:31:04.173709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test for LookupModule method run.

    :return: None
    """
    lookup_module = LookupModule()

    result = lookup_module.run(['li1', 'li2', 'li3'], None)
    if len(result) != 1:
        raise AssertionError("Invalid length of random result list.")

# Generated at 2022-06-21 06:31:06.215849
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create test object
    lookup = LookupModule()
    # Return random element of list
    terms = ["foo", "bar", "baz"]
    assert lookup.run(terms) in terms

# Generated at 2022-06-21 06:31:08.946441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    terms = ["foo", "bar"]
    assert len(obj.run(terms)) == 1
    assert obj.run(terms) in terms

# Generated at 2022-06-21 06:31:09.749942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 06:31:12.379981
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-21 06:31:24.925036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # copy from https://github.com/ansible/ansible/blob/devel/lib/ansible/plugins/lookup/random_choice.py
    # copied for more in-depth testing
    import unittest
    import ansible.parsing.dataloader
    import ansible.utils.plugin_docs

    class TestLookupModule(unittest.TestCase):
        def test_random_choice(self):
            test_terms = ['first', 'second', 'third', 'fourth', 'fifth']
            from random import shuffle
            shuffle(test_terms)
            lookup_plugin = LookupModule()
            
            # test single random choice
            for i in range(0, 10):
                got_random_choice = lookup_plugin.run(test_terms)

# Generated at 2022-06-21 06:32:01.367613
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 06:32:03.024906
# Unit test for constructor of class LookupModule
def test_LookupModule():
    rand_value = LookupModule.rand_value(
            random.choice(LookupModule.terms))
    if rand_value not in LookupModule.terms:
        raise ValueError("rand_value not in terms")

# Generated at 2022-06-21 06:32:05.754277
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        raise AssertionError("LookupModule() class constructor failed: %s" % to_native(e))

# Generated at 2022-06-21 06:32:08.455442
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_module = LookupModule()
    print("Testing LookupModule constructor")
    assert isinstance(test_module, LookupModule)

# Generated at 2022-06-21 06:32:11.711337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-21 06:32:15.382355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_dict={'x':1, 'y':2}
    test_obj = LookupModule()
    # Test A
    assert test_obj.run(my_dict) == [{'x':1, 'y':2}]

# Generated at 2022-06-21 06:32:20.466052
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test instantiation of class LookupModule
    lookup_module = LookupModule()

    # test call of run() method
    ret = lookup_module.run(['foo', 'bar', 'baz'])
    assert ret == ['foo'] or ret == ['bar'] or ret == ['baz']

# Generated at 2022-06-21 06:32:27.854114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret_test_LookupModule_run  = []
    ret_test_LookupModule_run.append(random.choice([1, 2, 3, 4]))
    ret_test_LookupModule_run.append(random.choice([1, 2, 3, 4]))
    ret_test_LookupModule_run.append(random.choice([1, 2, 3, 4]))
    ret_test_LookupModule_run.append(random.choice([1, 2, 3, 4]))
    ret_test_LookupModule_run.append(random.choice([1, 2, 3, 4]))
    print(ret_test_LookupModule_run)

test_LookupModule_run()

# Generated at 2022-06-21 06:32:32.563589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    oneterm = ['test']
    assert m.run(oneterm) == ['test']

    two_terms = ['test', 'test2']
    assert m.run(two_terms) in (['test'], ['test2'])

# Generated at 2022-06-21 06:32:37.412540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ["foo", "bar", "baz"]
    # We can't guarantee the result, but we can guarantee that it only returns
    # one value from the list.
    assert len(lookup.run(terms)) == 1
    assert len(lookup.run(terms, None)) == 1
    assert len(lookup.run(terms, inject=None, **None)) == 1

# Generated at 2022-06-21 06:34:00.565751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    ret = lookup_plugin.run(
        [
            {'key1': 'value1', 'key2': 'value2'}, 
            {'key1': 'value3', 'key2': 'value4'}, 
            {'key1': 'value5', 'key2': 'value6'}
        ],
        inject={'key1': 'value1'}, 
        **{'key1': 'value1', 'key2': 'value2'}
    )
    assert (len(ret) == 1)


# Generated at 2022-06-21 06:34:07.284522
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()
    assert lk.run(None, None) == [None]
    assert lk.run([None], None) == [None]
    assert lk.run(None, None, None) == [None]
    assert lk.run([1, 2, 3], None) == [1, 2, 3]

# Generated at 2022-06-21 06:34:15.578400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    look = LookupModule()
    ret = look.run(None)
    assert ret == [], "should be []"
    ret = look.run("foo")
    assert ret == ["foo"], "should be ['foo']"
    ret = look.run(["a", "b", "c"])
    assert ret in [["a"], ["b"], ["c"]], "should be ['a'], ['b'], or ['c']"
    assert ret != ["a", "b", "c"], "should not be ['a', 'b', 'c']"
    assert ret != ['a', 'b', 'c'], "should not be ['a', 'b', 'c']"

# Generated at 2022-06-21 06:34:16.521946
# Unit test for constructor of class LookupModule
def test_LookupModule():
 return LookupModule()

# Generated at 2022-06-21 06:34:19.145487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module=LookupModule()

    terms1 = ['a','b','c','d','e','f','g','h','i']
    ret1 = lookup_module.run(terms1)

    assert type(ret1) == list
    assert len(ret1) == 1
    assert ret1[0] in terms1

# Generated at 2022-06-21 06:34:23.248899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [1,2,3,4,5,6,7]
    ret = lookup_module.run(terms)
    
    assert(ret[0] in terms)

# Generated at 2022-06-21 06:34:34.608943
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Return a random element from the terms
    terms = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    expected_output = [random.choice(terms)]
    module = LookupModule()
    output = module.run(terms)
    assert output == expected_output

    # Return a random element from the terms
    terms = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"]
    expected_output = [random.choice(terms)]
    module = LookupModule()
    output = module.run(terms)
    assert output == expected_output

    # Return a none in case of empty list
    terms = []
    expected_output = []
    module = LookupModule()
    output = module.run(terms)
   

# Generated at 2022-06-21 06:34:44.145774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    ## Passing a positive list of integers
    returned_value = lookup_obj.run([1,2,3])
    assert isinstance(returned_value, list) == True
    if isinstance(returned_value, list) == True:
        assert len(returned_value) == 1
    ## Passing a positive list of strings
    returned_value = lookup_obj.run(["a","b","c"])
    assert isinstance(returned_value, list) == True
    if isinstance(returned_value, list) == True:
        assert len(returned_value) == 1
    ## Passing a positive list of arbitrary objects
    returned_value = lookup_obj.run([1,"a",{"greeting":"hello"},object])
    assert isinstance(returned_value, list)

# Generated at 2022-06-21 06:34:46.091709
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not hasattr(LookupModule, 'run')

# Generated at 2022-06-21 06:34:46.657514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True