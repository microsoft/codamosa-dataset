

# Generated at 2022-06-21 06:27:20.610426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Check the method run of class LookupModule'''
    my_lookup = LookupModule()

    mylist = ['a', 'b', 'c']
    selected = my_lookup.run(mylist)

    assert not selected == mylist
    assert selected in mylist

# Generated at 2022-06-21 06:27:23.696846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''

    terms = ['cow','horse','duck']
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms)
    assert result[0] in terms


# Generated at 2022-06-21 06:27:25.376310
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_obj = LookupModule()
    assert test_obj is not None

# Generated at 2022-06-21 06:27:26.059481
# Unit test for constructor of class LookupModule
def test_LookupModule():
	l = LookupModule()
	assert l

# Generated at 2022-06-21 06:27:27.962291
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None

# Generated at 2022-06-21 06:27:39.963297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(terms=[1,2,3], inject=None, random=lambda: .1)
    l.run(terms=[1,2,3], inject=None, random=lambda: .2)
    l.run(terms=[1,2,3], inject=None, random=lambda: .3)
    l.run(terms=[1,2,3], inject=None, random=lambda: .4)
    l.run(terms=[1,2,3], inject=None, random=lambda: .5)
    l.run(terms=[1,2,3], inject=None, random=lambda: .6)
    l.run(terms=[1,2,3], inject=None, random=lambda: .7)

# Generated at 2022-06-21 06:27:42.620001
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    test_list = [1, 2, 3, 4, 5]
    assert len(lookup.run(test_list)) == 1

# Generated at 2022-06-21 06:27:49.084666
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # init LookupModule Class
    lookup_module = LookupModule()
    # term_of_list is value returned from run method
    term_of_list = lookup_module.run(["a", "b", "c"])
    assert term_of_list in ["a", "b", "c"]
    print("[OK] random_choice plugin")

# Generated at 2022-06-21 06:27:52.256206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run(terms=['a','b','c']) == ['b']
    assert l.run(terms=['a']) == ['a']
    assert l.run(terms=[]) == []

# Generated at 2022-06-21 06:27:54.207576
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-21 06:27:59.375288
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert [0] == lookup.run([0, 1, 2])

# Generated at 2022-06-21 06:28:01.052040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  #Test function
  assert 1 == 1
  return

# Generated at 2022-06-21 06:28:05.298498
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    terms = ['a','b','c']
    result = lookup.run(terms)
    assert result == terms or result == [terms[0]] or result == [terms[1]] or result == [terms[2]]

    terms = []
    result = lookup.run(terms)
    assert result == []

# Generated at 2022-06-21 06:28:11.351994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import sys
    import os

    sys.path.append(os.path.dirname(os.path.abspath(__file__)))

    # Create a lookup module instance
    lookup_module = LookupModule()

    # get random choice from the list - expected 2
    choices = [1, 2, 3]
    result = lookup_module.run(choices)
    assert result == [2]

# Generated at 2022-06-21 06:28:13.935551
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(4)
    l = LookupModule()
    assert l.run(['a', 'b', 'c']) == ['c']
    assert l.run(['a', 'b', 'c']) == ['b']

# Generated at 2022-06-21 06:28:17.129776
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.__class__.__name__ == "LookupModule"


# Generated at 2022-06-21 06:28:23.417109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with one element in the list
    ret = LookupModule()
    list = ['one']
    assert ret.run(list)[0] == list[0]

    # Test with two element in the list
    list = ['one', 'two']
    assert ret.run(list)[0] in list

    # Test with more than two element in the list
    list = ['one', 'two', 'three', 'four', 'five']
    assert ret.run(list)[0] in list

# Generated at 2022-06-21 06:28:36.195914
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [1,2,3,4,5]
    class_obj = LookupModule()
    LookupModule_return = class_obj.run(terms)
    LookupModule_return1 = class_obj.run(terms)
    LookupModule_return2 = class_obj.run(terms)
    LookupModule_return3 = class_obj.run(terms)
    LookupModule_return4 = class_obj.run(terms)
    LookupModule_return5 = class_obj.run(terms)
    assert True , LookupModule_return[0] in terms
    assert True , LookupModule_return1[0] in terms
    assert True , LookupModule_return2[0] in terms
    assert True , LookupModule_return3[0] in terms
    assert True , LookupModule_return4

# Generated at 2022-06-21 06:28:40.471732
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # look up module
    lm = LookupModule()

    # create test arguments
    terms = ['red', 'white', 'green']

    # call run function
    ret = lm.run(terms)

    # assert
    assert len(ret) > 0



# Generated at 2022-06-21 06:28:41.374348
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None

# Generated at 2022-06-21 06:28:51.460399
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # No argument
    test = LookupModule().run(None, None, inject=None)
    assert test is None

    # List of arguments
    terms = [1, 2, 3]
    test = LookupModule().run(terms, None, inject=None)
    assert test != terms
    assert test == [random.choice(terms)]

# Generated at 2022-06-21 06:29:02.288436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_terms = ['abc', 'def', 'ghi']
    ret = LookupModule().run(list_terms)
    assert ret == ['abc'] or ret == ['def'] or ret == ['ghi']

    nlist_terms = ['abc', 'def', 'ghi', 1, 2, 3]
    ret = LookupModule().run(nlist_terms)
    assert ret == ['abc'] or ret == ['def'] or ret == ['ghi'] or ret == [1] or ret == [2] or ret == [3]

    ret = LookupModule().run([])
    assert len(ret) == 0

    ret = LookupModule().run(None)
    assert ret == None

# Generated at 2022-06-21 06:29:03.620860
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:29:08.708766
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create object of class LookupModule
    lookup = LookupModule()

    # Create a list
    terms = [1, 2, 3, 4, 5]

    # Call method run
    result = lookup.run(terms=terms)

    # Assert that the result is in the list
    assert(result[0] in terms)

# Generated at 2022-06-21 06:29:11.226140
# Unit test for constructor of class LookupModule
def test_LookupModule():
  a = LookupModule()
  b = vars(a)
  # check the type of __class__
  assert (type(a.__class__)) is type

# Generated at 2022-06-21 06:29:20.115240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test to return random term from list
    input = ['While running a playbook one can use variables','like {{ inventory_hostname }}','variables are very useful','when performing repetitive tasks']
    test = LookupModule()
    ret = test.run(input)
    assert isinstance(ret, list)
    assert ret[0] in input

    # Test to return error
    input = {'key': 'value'}
    test = LookupModule()
    try:
        ret = test.run(input)
    except Exception as e:
        assert 'Unable' in to_native(e)

# Generated at 2022-06-21 06:29:25.487307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1,2,3,4,5]
    random_no = random.choice(terms)
    lookup_obj = LookupModule()
    new_terms = lookup_obj.run(terms, inject=None, **kwargs)
    assert new_terms[0] == random_no
    assert len(new_terms) == 1

# Generated at 2022-06-21 06:29:29.417449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lc = LookupModule()
    terms = ['ansible', 'is', 'the', 'best', 'tool']
    inject = {'random_string': '123'}
    result = lc.run(terms, inject)
    assert result in (terms)
    assert result != ''
# EOF

# Generated at 2022-06-21 06:29:31.267438
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['a', 'b', 'c']) == ['b']

# Generated at 2022-06-21 06:29:35.186443
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        print("Error in constructor of LookupModule class: %s" % to_native(e))
        assert False


# Generated at 2022-06-21 06:29:47.306197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = [1,2,3]
    expected = terms
    # Act
    look = LookupModule()
    result = look.run(terms)
    # Assert
    assert result == expected

# Generated at 2022-06-21 06:29:49.977743
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options([])
    # Random choice can return any of the 3 items in the list
    assert(lookup.run([[1, 2, 3]]) in [[1], [2], [3]])

# Generated at 2022-06-21 06:29:57.853648
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialising the Lookup Module
    lookup = LookupModule()
    
    # Creating a random list of terms to choose from
    test_list = ['hello', 'world', '!']

    # Testing for random choice from list
    result = lookup.run(terms=test_list, inject=None)
    assert result[0] in test_list

# Generated at 2022-06-21 06:30:01.091858
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:30:07.563397
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock methods
    mylookup = LookupModule()

    # mock options
    mylookup.get_basedir = Mock(return_value=None)
    mylookup.get_basedir.return_value = '/ansible/plugins/lookup'
    mylookup.templar = Mock()

    terms = ['a','b','c']
    expected_data = ['a','b','c']
    data = mylookup.run(terms, inject={}, **{})
    assert data == expected_data


# Generated at 2022-06-21 06:30:11.433670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module=LookupModule()

    terms=["alpha","bravo","charlie"]
    ret=lookup_module.run(terms)

    assert(len(ret)==1)
    assert(ret[0] in terms)

# Generated at 2022-06-21 06:30:12.885017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')


# Generated at 2022-06-21 06:30:24.706635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Define default parameters for method run of class LookupModule
    terms = ['alligators', 'crocodiles', 'lizards', 'snakes']
    inject = {'terms' : ['alligators', 'crocodiles', 'lizards', 'snakes']}
    kwargs = {'terms': ['alligators', 'crocodiles', 'lizards', 'snakes'], 'inject': {'terms' : ['alligators', 'crocodiles', 'lizards', 'snakes']}}
    # Instantiate class LookupModule
    lookup_plugin = LookupModule()
    # Execute method run of class LookupModule
    result = lookup_plugin.run(terms, inject, **kwargs)
    for i in result:
        assert i in terms

# Generated at 2022-06-21 06:30:32.828466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Test:
        def __init__(self):
            pass

        def fail(self):
            raise Exception('error')

    class SideEffect:
        def __init__(self, test):
            self.test = test

        def __call__(self, terms, inject=None, **kwargs):
            if self.test.fail_run:
                raise AnsibleError("error")
            else:
                self.test.called_run = True
                return terms

    def test_with_terms(test):
        test.called_run = False
        test.fail_run = False
        LookupModule.run = SideEffect(test)
        module = LookupModule()
        terms = ['t1', 't2']
        res = module.run(terms)
        assert res == terms, res


# Generated at 2022-06-21 06:30:38.482538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [1, 2, 3]
    lookup_instance = LookupModule()
    assert lookup_instance.run(terms)

# Generated at 2022-06-21 06:30:52.929850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_string = 'a b c d e'
    my_obj = LookupModule()     
    my_result = my_obj.run([input_string], inject=None)
    print("Result = {}".format(my_result))
    for i in my_result:
        print("i = {}".format(i))

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:30:53.498200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:30:54.656432
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    terms = ["Linux", "Windows", "macOS", "Android"]
    print(random.choice(terms))

# Generated at 2022-06-21 06:31:01.271991
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(["1","2","3"]) != []
    assert module.run(["a", "b", "c"][0]) == ["a"]

# Generated at 2022-06-21 06:31:04.614401
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 06:31:07.290712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['a', 'b', 'c']
    random_term = lm.run(terms)
    assert random_term in terms

# Generated at 2022-06-21 06:31:08.677168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: Implement it
    pass

# Generated at 2022-06-21 06:31:13.443636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # args can be called directly with a list from another method
    lookup_plugin = LookupModule()
    terms = ['a', 'b', 'c']
    assert lookup_plugin.run(terms) == ['a'] or lookup_plugin.run(terms) == ['b'] or lookup_plugin.run(terms) == ['c']

# Generated at 2022-06-21 06:31:24.077918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    # test a simple list
    random.seed(1)
    l = ["foo", "bar", "baz"]
    r = m.run(l)
    assert len(r) == 1
    assert r[0] in l
    assert r[0] == "foo"

    # test a more complex list
    random.seed(2)
    l = ["foo", ["sublist", "sublist"], "bar"]
    r = m.run(l)
    assert len(r) == 1
    assert r[0] in l
    assert r[0] == ["sublist", "sublist"]

    # test an empty list
    random.seed(3)
    l = []
    r = m.run(l)
    assert len(r) == 0
    assert r == []

# Generated at 2022-06-21 06:31:28.982418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
        [
            "go through the door",
            "drink from the goblet",
            "press the red button",
            "do nothing",
        ]
    ]
    lookup = LookupModule()
    assert len(lookup.run(args)) >= 1

# Generated at 2022-06-21 06:31:47.615688
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-21 06:31:51.363085
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['foo', 'bar', 'baz']
  random_choice = LookupModule()
  ret = random_choice.run(terms)
  assert ret[0] in terms

# Generated at 2022-06-21 06:31:56.221370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mod = LookupModule()

    terms = ['item1', 'item2']
    ret = lookup_mod.run(terms)
    assert len(ret) == 1

    ret = lookup_mod.run(terms)
    assert len(ret) == 1

    ret = lookup_mod.run(terms)
    assert len(ret) == 1

    ret = lookup_mod.run([])
    assert ret == []

# Generated at 2022-06-21 06:32:00.655593
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # make sure the class can be instantiated
    # the module does not have any parameters, so the terms argument should be empty
    lm = LookupModule(None, terms=[])

    assert lm is not None

# Generated at 2022-06-21 06:32:02.370735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-21 06:32:04.117054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(['a', 'b', 'c']) in ['a', 'b', 'c']

# Generated at 2022-06-21 06:32:08.454903
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys

    sys.path.append(os.path.dirname(os.path.abspath(__file__)))
    import module_utils.random_choice as random_choice

    assert random_choice.LookupModule

# Generated at 2022-06-21 06:32:15.833587
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Given
    class_to_test = LookupModule(loader=None, templar=None, shared_loader_obj=None)
    terms = ["term1", "term2"]
    expected_ret = [random.choice(terms)]

    # When
    ret = class_to_test.run(terms, inject=None, **kwargs)

    # Then
    assert ret == expected_ret

# Generated at 2022-06-21 06:32:17.409532
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule.run([1, 2, 3, 4], None, None)
    assert isinstance(ret, list)

# Generated at 2022-06-21 06:32:19.990061
# Unit test for constructor of class LookupModule
def test_LookupModule():

    terms = ['first', 'second', 'third', 'fourth']
    name = 'random_choice'
    L1 = LookupModule()
    ret = L1.run(terms, inject=None, **{'name': name})
    assert ret in terms

# Generated at 2022-06-21 06:32:58.675360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["one", "two", "three"]
    result = lookup_module.run(terms)
    assert isinstance(result, list)
    assert result[0] in terms

# Generated at 2022-06-21 06:33:00.709863
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tests that LookupModule is a subclass of LookupBase
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 06:33:06.137022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Implement test for  method run of class LookupModule
    module = __import__('ansible.plugins.lookup.random_choice')
    class_ = getattr(module, 'LookupModule')
    instance = class_()

    result = instance.run(["foo", "bar", "baz"])
    assert result in ["foo", "bar", "baz"]

# Generated at 2022-06-21 06:33:08.997267
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_test = LookupModule()
    assert lookup_test is not None
    assert callable(lookup_test.run)

# Generated at 2022-06-21 06:33:11.413605
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["a", "b", "c", "d"]
    assert LookupModule().run(terms) in terms
    assert LookupModule().run(terms) in terms

# Generated at 2022-06-21 06:33:17.163923
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for class constructors
    """
    # check LookupModule class object creation
    module = LookupModule()
    assert module is not None
    # module.run()

# Generated at 2022-06-21 06:33:20.003830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    example = ["hello", "world", "this", "is", "a", "test"]
    lookup = LookupModule()
    lookup.run(example)

# Generated at 2022-06-21 06:33:27.810757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Options(object):
        def __init__(self, var1, var2):
            self.var1 = var1
            self.var2 = var2
    options = Options('var1', 'var2')

    l = LookupModule()
    l.set_options(options)
    try:
        l.run('abc', 'xyz')
    except AnsibleError:
        pass

    l = LookupModule()
    l.set_options(options)
    l.run(['abc', 'ufo'], 'xyz')

# Generated at 2022-06-21 06:33:33.595123
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an object of LookupModule
    lookupmodule = LookupModule()
    # Create a list containing terms
    terms = ['a', 'b', 'c', 'd', 'e', 'f']
    # Store the result of function run in result
    result = lookupmodule.run(terms, inject=None, **{})
    len_result = len(result)
    assert len_result == 1

# Generated at 2022-06-21 06:33:40.420023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with list of input parameters
    test_param1 = ['item1', 'item2']
    test_param2 = {'item1', 'item2'}
    test_param3 = ['item1', 'item2']
    test_param4 = {'item1', 'item2'}
    test_param5 = ['item1', 'item2']
    test_param6 = {'item1', 'item2'}
    result = LookupModule.run(test_param1, test_param2, test_param3, test_param4, test_param5, test_param6)
    assert result == ['item1', 'item2']

    # test with no input parameters
    result = LookupModule.run()
    assert result == []

# Generated at 2022-06-21 06:35:06.421515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(7)
    lookup_mock = LookupModule()

    # no terms returns an empty list
    assert lookup_mock.run([], []) == []

    # one term returns a list with one element
    assert lookup_mock.run(['a'], []) == ['a']

    # two terms returns a list with one element, randomly chosen one of the two given
    assert lookup_mock.run(['a', 'b'], []) == ['a']

    # three terms returns a list with one element, randomly chosen one of the three given
    assert lookup_mock.run(['a', 'b', 'c'], []) == ['c']

# Generated at 2022-06-21 06:35:09.196821
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lm = LookupModule()
        assert lm != None
    except Exception as e:
        print(str(e))
        print("Failed to construct LookupModule")


# Generated at 2022-06-21 06:35:12.968959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.run('random_choice', ['foo', 'bar'], inject={}, a=1, b=2)

# Generated at 2022-06-21 06:35:15.708769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.run(['a', 'b', 'c']) in [['a'], ['b'], ['c']]

# Generated at 2022-06-21 06:35:16.422094
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 06:35:21.903528
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    rawt = [u'go through the door', u'drink from the goblet', u'press the red button', u'do nothing']
    ret = [u'go through the door', u'press the red button']
    assert rawt not in ret
    assert random.choice(rawt) in ret
    assert LookupModule().run(terms=rawt) in ret
    assert LookupModule()

# Generated at 2022-06-21 06:35:23.509487
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    # Test with no arguments
    assert lu is not None

# Generated at 2022-06-21 06:35:32.784182
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test - method run of class LookupModule")
    # Test with simple term
    term1 = "random_choice"
    l0 = []
    l0.append(term1)
    print("Test with term:", term1)
    lm = LookupModule()
    res = lm.run(terms=l0)
    print("Result: ", res)
    assert res == l0
    # Test with simple terms
    terms2 = ["random_choice1", "random_choice2"]
    print("Test with terms:", terms2)
    res = lm.run(terms=terms2)
    print("Result: ", res)
    assert res == terms2
    # Test with terms_array
    terms3 = [["random_choice3"], ["random_choice4"]]

# Generated at 2022-06-21 06:35:34.458653
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Type the following to see if it returns an empty string')
    print('------------------------------------------------------------')
    print(LookupModule().run('',''))

# Generated at 2022-06-21 06:35:43.669354
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of class LookupModule
    lookup = LookupModule()
    
    # Create test variable terms with value of list
    terms = [1, 2, 3]
    # Assert that the expected value is equal to the actual value returned by method run
    assert lookup.run(terms) == terms
    assert len(lookup.run(terms)) == 1

    # Create test variable terms with value of string
    terms = "go through the door"
    # Assert that the expected value is equal to the actual value returned by method run
    assert lookup.run(terms) == terms
    assert len(lookup.run(terms)) == 1

    return True