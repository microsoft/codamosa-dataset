

# Generated at 2022-06-21 06:27:18.059907
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:27:22.090303
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  test_terms = [ "go through the door", "drink from the goblet", "press the red button" ]
  test_instance = LookupModule()
  test_out = test_instance.run(test_terms)
  assert test_out != None
  assert len(test_out) == 1
  assert test_out[0] in test_terms

# Generated at 2022-06-21 06:27:26.280686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule().run([])
    assert isinstance(ret, list)
    assert len(ret) == 0
    ret = LookupModule().run(['first', 'second', 'third'])
    assert isinstance(ret, list)
    assert len(ret) == 1
    assert ret[0] in ['first', 'second', 'third']

# Generated at 2022-06-21 06:27:31.253393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms=['a', 'b', 'c']
    ret = LookupModule().run(terms)
    assert ret[0] == 'a' or ret[0] == 'b' or ret[0] == 'c'
    return


# Generated at 2022-06-21 06:27:32.423056
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    return True

# Generated at 2022-06-21 06:27:34.421614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.name == 'random_choice'


# Generated at 2022-06-21 06:27:39.654381
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = [1, 2, 3]
    test_inject = None
    test_kwargs = {}
    lookupM_obj = LookupModule()
    ret = lookupM_obj.run(test_terms, test_inject, **test_kwargs)
    assert isinstance(ret, list)
    assert len(ret) == 1

# Generated at 2022-06-21 06:27:43.111874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 1:
    terms = ['a', 'b', 'c', 'd']
    expected = ['a', 'b', 'c', 'd']
    got = LookupModule().run(terms)
    assert isinstance(got, list)
    assert all(item in expected for item in got)

# Generated at 2022-06-21 06:27:54.200123
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test1:
    # check if the random value matches with in list
    first_random_value = random.choice(["go through the door","drink from the goblet"])
    lookup_obj = LookupModule()
    result = lookup_obj.run(["go through the door","drink from the goblet"])
    assert(result == [first_random_value])

    # test2:
    # check if the error message is returned when the required values are not in the list.
    present_value = "test"
    try:
        lookup_obj = LookupModule()
        lookup_obj.run(["go through the door"])
        raise Exception("Expected error did not occur")
    except AnsibleError as e:
        assert("Unable to choose random term" in str(e))

# Generated at 2022-06-21 06:27:56.383218
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu.run(["one", "two", "three"])

# Generated at 2022-06-21 06:28:08.232911
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Terms for which random choice should be returned
    term1 = [1, 2, 3, 4, 5]

    # Lookup module object
    lookup_module = LookupModule()

    # Test with an empty list
    assert lookup_module.run([], None, None) == []

    # Test with an empty string
    assert lookup_module.run([""], None, None) == [""]

    # Test with a valid list
    assert lookup_module.run(term1, None, None) != []

    # Test with a None object
    try:
        lookup_module.run(None, None, None)
    except AnsibleError as e:
        assert str(e) == "Unable to choose random term: 'NoneType' object is not subscriptable"

    # Test with a string

# Generated at 2022-06-21 06:28:11.902887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = None

    try:
        ret = LookupModule()
    except Exception as e:
        ret = None

    assert ret is not None


# Generated at 2022-06-21 06:28:22.003686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()

    # Test exception with ansible variable
    terms = {'first_item': 'a', 'second_item': 'b'}
    assert my_lookup.run(terms) == terms

    # Test exception with ansible variable
    terms = ['a']
    assert my_lookup.run(terms) == ['a']

    # Test exception with ansible variable
    terms = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    assert my_lookup.run(terms) == [random.choice(terms)]

# Generated at 2022-06-21 06:28:26.653922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # We will use the main function to test run() function
    source = "['one', 'two', 'three']"
    terms = [source]
    lookup = LookupModule()
    result = lookup.run(terms, inject=None, **dict())
    assert result == source, "Returned result does not match expected result."
    return True

# Generated at 2022-06-21 06:28:39.405942
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule """
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.errors import AnsibleError

    lookup_module = LookupModule()

    with pytest.raises(AnsibleError) as e:
        lookup_module.run(None, None)
    assert to_bytes(e.value) == b"Unable to choose random term: 'NoneType' object is not iterable"

    with pytest.raises(AnsibleError) as e:
        lookup_module.run("", None)
    assert to_bytes(e.value) == b"Unable to choose random term: '' object is not iterable"

    with pytest.raises(AnsibleError) as e:
        lookup_module.run(123, None)

# Generated at 2022-06-21 06:28:42.085998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(["string1", "string2", "string3"], None) != None
    assert lookup_plugin.run(None, None) == None

# Generated at 2022-06-21 06:28:43.331525
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.__name__ == 'LookupModule'

# Generated at 2022-06-21 06:28:46.960263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit testing run method of LookupModule class
    """

    # test return of a random element of a list
    mock_params= {'terms': ['a', 'b'], 'inject': None}
    lookup_module_instance = LookupModule()
    assert lookup_module_instance.run(**mock_params) == ['a']


# Generated at 2022-06-21 06:28:50.182475
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('### START LookupModule()')
    lookup_module = LookupModule()
    assert type(lookup_module) is LookupModule
    print('### DONE LookupModule()')



# Generated at 2022-06-21 06:28:54.960060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run([])
    assert ret == []

    ret = LookupModule().run(['a', 'b', 'c'])
    assert ret in [['a'], ['b'], ['c']]

# Generated at 2022-06-21 06:28:58.364769
# Unit test for constructor of class LookupModule
def test_LookupModule():

    assert(1==1)

# Generated at 2022-06-21 06:28:58.968701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:29:01.971275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock a list of terms
    terms = ["term1", "term2", "term3"]
    # create instance
    LookupMod = LookupModule()
    # build parameters needed to call run
    inject = None
    kwargs = dict()
    # call run with appropriate parameters
    result = LookupMod.run(terms, inject, **kwargs)
    # check that the result is in the terms
    assert result[0] in terms

# Generated at 2022-06-21 06:29:06.127730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = [1, 2, 3, 4]

    assert callable(lookup_module.run)
    assert isinstance(lookup_module.run(terms), list)

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-21 06:29:08.709644
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Check if __init__ is defined
    assert '__init__' in dir(LookupModule)


# Generated at 2022-06-21 06:29:14.617809
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # Random choice will always be one of the element of the list
    result = lookup_module.run(["one", "two", "three", "four", "five", "six"], {})
    assert result in (["one"], ["two"], ["three"], ["four"], ["five"], ["six"])

# Generated at 2022-06-21 06:29:18.630191
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Passing the test_LookupModule_run method."""
    results = LookupModule.run(["Testing one", "Testing two", "Testing three"], "", "")
    for result in results:
        assert result in ["Testing one", "Testing two", "Testing three"]


# Generated at 2022-06-21 06:29:24.323014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()

    # Test with all parameters specified
    terms = ["a", "b"]
    wanted_result = ["a"]
    result = lookupModule.run(terms=terms)
    assert result == wanted_result

    # Test with None terms
    wanted_result = None
    result = lookupModule.run(terms=None)
    assert result == wanted_result

# Generated at 2022-06-21 06:29:25.385510
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() != None

# Generated at 2022-06-21 06:29:32.572622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dummy_class = type('DummyClass', (object,), {})()
    dummy_class.args = {'_terms': ['1', '2', '3'], '_zsh_extensions': False}
    lookup_obj = LookupModule(loader=dummy_class, templar=dummy_class, shared_loader_obj=dummy_class)

    for i in range(3):
        if any(lookup_obj.run(dummy_class.args['_terms']) not in dummy_class.args['_terms']):
            raise AssertionError()
    if len(set(lookup_obj.run(dummy_class.args['_terms']))) != 1:
        raise AssertionError()

# Generated at 2022-06-21 06:29:46.027889
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    terms = ("a","b","c")
    temp_random = random.Random()
    temp_random.seed(1)
    random.seed(1)
    lm = LookupModule()
    terms = ("a","b","c")
    result = lm.run(terms)
    assert result ==  ["b"]
    random.seed(1)
    lm = LookupModule()
    terms = ("a","b","c")
    result = lm.run(terms)
    assert result ==  ["b"]
    terms = ("a","b","c")
    result = lm.run(terms)
    assert result ==  ["b"]

# Generated at 2022-06-21 06:29:52.669598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    def test_random_choice(args, expect):
        count_correct_result = 0
        for i in range(0, len(args)):
            l = LookupModule()
            l.run(args[i])
            result = l.run(args[i])
            if result[0] in expect[i]:
                count_correct_result = count_correct_result + 1
        return count_correct_result / len(args)

    args1 = [[1,2,3,4], ['a', 'b', 'c', 'd'], [1,2,3,4], ['a', 'b', 'c', 'd'], [1,2,3,4]]

# Generated at 2022-06-21 06:29:59.653331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    import unittest

    d_random_choice = [7, 14, 21]

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.lookup = LookupModule()

        def test_run(self):
            ret = self.lookup.run(d_random_choice)
            self.assertTrue(ret[0] in d_random_choice)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestLookupModule)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 06:30:02.928880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class EmptyModule:
        def __init__(self):
            pass

    m = EmptyModule()
    l = LookupModule(m)

    assert l.run([]) == []
    assert l.run(['a','b','c']) in [['a'],['b'],['c']]

# Generated at 2022-06-21 06:30:05.714938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(['a', 'b', 'c']) in ['a', 'b', 'c']

# Generated at 2022-06-21 06:30:18.493305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Setup
    #
    terms = [1, 2, 3, 4]
    inject = {}
    kwargs = {}
    ret = [1]
    ans = LookupModule().run(terms, inject, **kwargs)

    #
    # Test
    #
    assert ans == ret
    #
    # Cleanup
    #
    return

__all__ = ["test_LookupModule_run"]

if __name__ == "__main__":
    import sys
    import unittest

    # import module snippets
    from ansible.module_utils.common.collections import ImmutableDict

    class TestLookupModule(unittest.TestCase):
        def test_LookupModule_run(self):
            test_LookupModule_run()

    suite = unittest.TestLoader

# Generated at 2022-06-21 06:30:29.775228
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global __file__
    import os
    import sys
    # Find the ansible lookup directory
    MOD_PATH = os.path.dirname(os.path.realpath(__file__))
    if ("/usr/lib/ansible/plugins/lookup/random_choice.py" in MOD_PATH):
        # This is the 'ansible' directory and not the ansible lookup directory
        MOD_PATH = os.path.join(os.path.split(MOD_PATH)[0], "plugins/lookup/random_choice.py")
    # Change the current working directory
    sys.path.append(os.path.split(MOD_PATH)[0])
    os.chdir(os.path.split(MOD_PATH)[0])
    from ansible.plugins.lookup.random_choice import LookupModule
    # Create an object

# Generated at 2022-06-21 06:30:31.852813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(['first','second','third','forth'])

# Generated at 2022-06-21 06:30:41.559502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Case 1: If "terms" has one element, return it.
    assert lookup_module.run(['foo']) == ['foo']
    # Case 2: If "terms" has more than one element, return one of it randomly.
    assert lookup_module.run(['foo','bar']) in (['foo'],['bar'])
    # Case 3: If "terms" is empty, return it.
    assert lookup_module.run([]) == []
    # Case 4: If "terms" is None, return it.
    assert lookup_module.run(None) == None

# Generated at 2022-06-21 06:30:45.131304
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test with invalid variable name
    lookup = LookupModule()
    assert lookup.run("Invalid variable") == "Invalid variable"

    # Test with valid variable name
    terms = ["one", "two", "three"]
    assert lookup.run( terms ) in terms

# Generated at 2022-06-21 06:30:56.705259
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert issubclass(type(l), LookupBase)


# Generated at 2022-06-21 06:31:02.999705
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["one", "two", "three"]
    inject = None
    lh = LookupModule()
    random_choice = lh.run(terms)
    assert random_choice[0] in terms

# Generated at 2022-06-21 06:31:10.997082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    result = lookup.run(terms=[1,2,3,4,5,6,7,8,9,0], inject=None, **kwargs)
    assert result in [1,2,3,4,5,6,7,8,9,0]
    result = lookup.run(None, None, **kwargs)
    assert result is None

# Generated at 2022-06-21 06:31:19.065218
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ansible = __import__('ansible')
    lookup_module = __import__('ansible.plugins.lookup.random_choice')
    lookup_module.LookupModule(ansible.module_utils.basic.AnsibleModule)

# Generated at 2022-06-21 06:31:20.816347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(['red', 'green', 'blue'])

# Generated at 2022-06-21 06:31:24.924129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1, 2, 3, 4]
    terms_new = random.choice(terms)
    assert terms_new in terms, "test_LookupModule_run: Failed to pick a random element"

# Generated at 2022-06-21 06:31:32.786728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_elems = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    lookup_obj = LookupModule()
    result = lookup_obj.run(list_elems)
    assert len(result) == 1
    assert type(result[0]) == str

# Generated at 2022-06-21 06:31:36.975952
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create object of class LookupModule
    object_lookup_module = LookupModule()

    # Method run() is used in Ansible Core, we do not implement it
    # But its name must be declared in class LookupModule
    assert hasattr(object_lookup_module, 'run')

# Generated at 2022-06-21 06:31:39.918305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["ham", "eggs"]
    ret = lookup.run(terms)
    assert len(ret) == 1
    assert ret[0] in terms


# Generated at 2022-06-21 06:31:45.628519
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = [1,2,3,4]
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(data, inject={})
    assert len(result) == 1
    assert result[0] in data

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 06:32:16.996378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()

    # Should return the same list of strings, but the list should be
    # randomly ordered
    assert len(mod.run([u"one", u"two", u"three"])) == 3
    assert len(mod.run([u"one", u"two", u"three"])) == 3

    # Should return the same list of strings, but the list should be
    # randomly ordered
    assert len(mod.run([u"one", u"two", u"three"])) == 3
    assert len(mod.run([u"one", u"two", u"three"])) == 3

    # Should return an empty list if the argument is an empty list
    assert mod.run([]) == []

    # Should raise an error if the argument is not a list
    bad_list = u"Not a set of strings"


# Generated at 2022-06-21 06:32:19.093693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule.run(terms=['first', 'second', 'third'], inject=None) in [["first"], ["second"], ["third"]]

# Generated at 2022-06-21 06:32:19.969414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert( LookupModule() )

# Generated at 2022-06-21 06:32:22.627502
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ["foo", "bar", "baz"]
    lookup_module = LookupModule()

    random_item = lookup_module.run(terms, inject=None, **{})

    assert random_item in terms

# Generated at 2022-06-21 06:32:36.566220
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModule_Mock():
        def __init__(self, terms, inject=None, **kwargs):
            self.res = terms
            self.inject = inject
            self.kwargs = kwargs

    class Values():
        def __init__(self, value):
            self.value = value
    class Mocks():
        def __init__(self):
            self.LookupModule_Mock = LookupModule_Mock
            self.Values = Values

    def test_run_with_terms(mocks):
        terms = ["a", "b", "c"]
        lookupModule = mocks.LookupModule_Mock(terms)
        kwargs = {"inject": "inject"}
        ret = LookupModule().run(terms, **kwargs)
        assert ret == lookupModule.res


# Generated at 2022-06-21 06:32:37.703626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = LookupModule()
    assert ret

# Generated at 2022-06-21 06:32:41.526571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    res = lookup.run(terms = ["one", "two", "three"], inject = None, **{})
    assert res[0] in ["one", "two", "three"]

# Generated at 2022-06-21 06:32:44.796714
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['ansible', 'openshift', 'python']
    ret = LookupModule()
    new_ret = ret.run(terms)
    assert isinstance(new_ret, list)
    assert isinstance(new_ret[0], str)

# Generated at 2022-06-21 06:32:50.242852
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["a", "b", "c"]
    x = LookupModule()
    ret = x.run(terms)
    assert ret == ["a"] or ret == ["b"] or ret == ["c"]

# Generated at 2022-06-21 06:32:51.931066
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_lookup = LookupModule()
    assert isinstance(test_lookup, LookupModule)

# Generated at 2022-06-21 06:33:31.628947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert [1] == lookup_module.run([1, 2, 3], {})


# Generated at 2022-06-21 06:33:36.669418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    ret = lookup.run([u"Cindy", u"Bobby", u"Carlton", u"DJ", u"Max", u"Nick"], inject=None, **{})
    assert any(test in ret for test in [u"Cindy", u"Bobby", u"Carlton", u"DJ", u"Max", u"Nick"])
    assert len(ret) == 1

# Generated at 2022-06-21 06:33:44.872783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    L = LookupModule()
    ret = L.run([], None)
    assert ret == [], 'Return value is not empty'

    try:
        ret = L.run(['a', 'b'], None)
        assert ret == ['a'] or ret == ['b'], 'Return value is not a list'
    except AnsibleError as e:
        assert str(e) == 'Unable to choose random term: ', 'Unable to choose random term'

# Generated at 2022-06-21 06:33:46.355033
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 06:33:53.806225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule with arguments for method run
    test_instance = LookupModule()
    test_terms = ['testlist1', 'testlist2']
    test_inject = None
    test_kwargs = {}

    returned = test_instance.run(test_terms, test_inject, **test_kwargs)
    # returned should be an single element list.
    assert isinstance(returned, list)
    assert len(returned) == 1
    # returned[0] should be in the test_terms list
    assert returned[0] in test_terms

# Generated at 2022-06-21 06:33:54.627084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["a", "b", "c"]
    instance = LookupModule()
    result = instance.run(terms)
    assert (result in terms)

# Generated at 2022-06-21 06:33:57.805080
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [1,2,3,4]
    ret = LookupModule().run(terms)
    assert len(ret) == 1
    assert isinstance(ret[0], int)
    #print ("ret = ", ret)

# Generated at 2022-06-21 06:34:00.327586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run([1,2,3,4,5])
    assert 1 <= lookup_module.run([1,2,3,4,5]) <= 5

# Generated at 2022-06-21 06:34:07.968924
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    module = LookupModule()
    # _run_terms is used by module_utils._text.call_function and can be used for unit test
    terms = [1, 2, 3]
    res = module.run(terms=terms)
    assert res
    assert len(res) == 1
    assert terms[0] == res[0] or terms[1] == res[0] or terms[2] == res[0]

# Generated at 2022-06-21 06:34:15.443214
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    lookup_plugin = LookupModule()
    lookup_plugin.set_options(variable_manager=variable_manager)
    terms = ['a', 'b']
    results = lookup_plugin.run(terms)
    assert len(results) == 1
    assert results[0] in terms

# Generated at 2022-06-21 06:35:40.665424
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(1)
    lookup_plugin = LookupModule()
    #valid input
    assert lookup_plugin.run(["a", "b", "c"]) == ["c"]
    #empty input
    assert lookup_plugin.run([]) == []
    #None input
    assert lookup_plugin.run(None) == []


# Generated at 2022-06-21 06:35:44.290992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ansible','michael','dehaan']
    ret = lookup_module.run(terms)
    assert ret in terms

# Generated at 2022-06-21 06:35:47.937087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	try:
		import random
	except ImportError:
		random = None
	if random:
		array = [1,2,3,4,5,6,7,8,9]
		random.shuffle(array)
	else:
		raise ImportError()

# Generated at 2022-06-21 06:35:48.636222
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup_plugin = LookupModule()

# Generated at 2022-06-21 06:35:49.873427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ar=[]
    lm=LookupModule()
    lm.run(ar)

# Generated at 2022-06-21 06:35:50.391257
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:35:54.045969
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def mock_random_choice(*args):
        return 'some'

    random.choice = mock_random_choice

    import ansible.plugins.lookup.random_choice
    lookup_module = ansible.plugins.lookup.random_choice.LookupModule()
    assert lookup_module.run(terms=['any', 'some', 'one']) == ['some']

# Generated at 2022-06-21 06:35:55.477161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-21 06:36:03.374633
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Constructor of class LookupModule
    '''
    memory = {}
    loader = 'loader'
    templar = 'templar'
    shared_loader_obj = 'shared_loader_obj'
    utils = 'utils'

    lookup_module = LookupModule(loader=loader,
                                 templar=templar,
                                 shared_loader_obj=shared_loader_obj,
                                 **memory)

    assert lookup_module._templar == templar
    assert lookup_module._loader == loader
    assert lookup_module._shared_loader_obj == shared_loader_obj


# Generated at 2022-06-21 06:36:05.310413
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lookup_module = LookupModule()
   assert lookup_module is not None

