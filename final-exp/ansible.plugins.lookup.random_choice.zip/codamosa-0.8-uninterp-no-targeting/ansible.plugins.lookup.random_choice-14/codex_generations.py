

# Generated at 2022-06-21 06:27:21.411043
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module._templar = object()
    lookup_module._loader  = object()
    assert isinstance(lookup_module, LookupModule)  # check type of created object
    assert lookup_module._templar == object()  # check value of class attribute
    assert lookup_module._loader  == object()  # check value of class attribute

# Generated at 2022-06-21 06:27:21.971136
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:27:34.015254
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create mock ansible module object
    class AnsibleModule:
        def __init__(self):
            self.params = dict()

    # Create mock ansible module test object
    class AnsibleModuleTest:
        def __init__(self):
            self.result = dict()

    # Create mock ansible module object
    ansible_module_obj = AnsibleModule()

    # Create mock ansible module test object
    ansible_module_test_obj = AnsibleModuleTest()

    # Create object of class LookupModule
    lookup_module_obj = LookupModule()

    # Test run method of class LookupModule
    # This test is correct as per current implementation of run method in
    # class LookupModule

# Generated at 2022-06-21 06:27:37.790979
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Testing LookupModule without parameters
    lookup_module = LookupModule()

    # Testing LookupModule with parameters
    lookup_module = LookupModule(loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 06:27:39.456486
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert type(LookupModule.run(["foo", "bar"], {})) is list

# Generated at 2022-06-21 06:27:51.487367
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Unit test for constructor of class LookupModule"""
    
    # Case 1: define class LookupModule with terms = [1, 2, 3]
    # Expected result: the list ret = [3]
    lookup_module = LookupModule()
    ret = lookup_module.run([1,2,3])
    assert ret == [3], "Wrong input terms and output"
    
    # Case 2: define class LookupModule with terms = ['a', 'b', 'c', 'd']
    # Expected result: the list ret = ['b', 'd']
    lookup_module = LookupModule()
    ret = lookup_module.run(['a', 'b', 'c', 'd'])
    assert ret == ['b', 'd'], "Wrong input terms and output"
    
    # Case 3: define class

# Generated at 2022-06-21 06:27:52.436222
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Begin test_LookupModule")
    assert False

# Generated at 2022-06-21 06:27:56.331659
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        assert(True)
    except AssertionError:
        print("AssertionError")
    except Exception as e:
        print("Unable to choose random term: %s" % to_native(e))

# Generated at 2022-06-21 06:28:00.952018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # unit test for without exception handling
    module_obj = LookupModule()
    terms=['cyrus','rahul','snyc','surya']
    ret = module_obj.run(terms=terms)
    assert ret in terms


# Generated at 2022-06-21 06:28:03.421871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    list_of_terms = ['test1', 'test2']
    assert l.run(list_of_terms) == list_of_terms

# Generated at 2022-06-21 06:28:10.581844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    terms = ['a', 'b', 'c']
    tickets = []
    for i in range(10000):
        tickets.append(l.run(terms))
    for term in terms:
        assert tickets.count(term) >= 1000, 'the number of ticket is not correct'

# Generated at 2022-06-21 06:28:15.995840
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms=['1','2','3']
    items = [random.choice(terms) for x in range(100)]
    terms_count = len(terms)
    items_count = len(items)
    assert items_count == 100
    for index in range(0, terms_count):
        assert items[index] == terms[index]
    assert items[terms_count] == items[terms_count + 1]
    assert items[-1] == items[0]

# Generated at 2022-06-21 06:28:18.316211
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()
    terms = ['foo', 'bar']
    assert lookup_obj.run(terms=terms) == terms

# Generated at 2022-06-21 06:28:28.249313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import PY3

    class TestLookupModule(LookupBase):
        def run(self, terms, inject=None, **kwargs):
            return [to_text(x) for x in (
                super(TestLookupModule, self).run(terms, inject, **kwargs)
            )]

    lookup_plugin = TestLookupModule()
    # test with list
    assert lookup_plugin.run(terms=['a', 'b', 'c']) != lookup_plugin.run(terms=['a', 'b', 'c'])
    # test with scalar

# Generated at 2022-06-21 06:28:29.520284
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Constructor of LookupModule can run")

# Generated at 2022-06-21 06:28:35.016106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    random_terms = ['a', 'b', 'c']
    test_result = test_object.run(random_terms)
    assert test_result == ['a'] or test_result == ['b'] or test_result == ['c']

# Generated at 2022-06-21 06:28:38.971794
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ["A","B","C"]
    result = module.run(terms)
    # Check if the result of random has returned one element from terms.
    assert True if result[0] in terms else False



# Generated at 2022-06-21 06:28:40.305479
# Unit test for constructor of class LookupModule
def test_LookupModule():
    foo = LookupModule()
    assert foo is not None

# Generated at 2022-06-21 06:28:42.900375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [1,2,3,4,5]

    ret = lookup_module.run(terms)
    assert ret[0] in terms

# Generated at 2022-06-21 06:28:45.114631
# Unit test for constructor of class LookupModule
def test_LookupModule():
    results = LookupModule().run(["a", "b", "c"])
    for result in results:
        assert result in ["a", "b", "c"]

# Generated at 2022-06-21 06:28:54.959633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lk = LookupModule()
    terms = ['a', 'b', 'c', 'd']
    assert lk.run(terms)


# Generated at 2022-06-21 06:29:01.509250
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ''' Testing the return value for method LookupModule.run for
        file lookup/random_choice.py
    '''
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=['a', 'b', 'c']) == ['a'] or lookup_plugin.run(terms=['a', 'b', 'c']) == ['b'] or lookup_plugin.run(terms=['a', 'b', 'c']) == ['c']

# Generated at 2022-06-21 06:29:03.325540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    ret = look.run("test")
    assert ret == "test"

# Generated at 2022-06-21 06:29:04.572693
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule('random_choice', 'A')



# Generated at 2022-06-21 06:29:06.943027
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    result = lookup.run(["test1", "test2"])
    assert result in ["test1", "test2"]


# Generated at 2022-06-21 06:29:08.853176
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-21 06:29:11.379338
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1, 2, 3, 4, 5]
    results = LookupModule().run(terms)
    assert results in terms
    assert results != []


# Generated at 2022-06-21 06:29:14.902559
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    ret = lookup_module.run(terms=['hello', 'world'])
    assert isinstance(ret, list)

# Generated at 2022-06-21 06:29:18.039600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(["a", "b", "c"], inject={'random': True})
    l.run(["a", "b", "c"], inject={'random': False})

# Generated at 2022-06-21 06:29:21.087155
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["x","y","z"]
    liu = LookupModule()
    result = liu.run(terms)
    assert result[0] in terms

# Generated at 2022-06-21 06:29:33.910668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [1, 2, 3]
    ret = lookup_module.run(terms)
    assert len(ret) == 1
    assert ret[0] in terms


# Generated at 2022-06-21 06:29:37.225269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['one', 'two', 'three']
    item = lookup.run(terms)
    assert item[0] in terms

# Generated at 2022-06-21 06:29:41.666521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Check if two random number are the same
    """
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(terms=[1, 2, 3]) != lookup_plugin.run(terms=[1, 2, 3])

# Generated at 2022-06-21 06:29:44.128341
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["c", "d", "e", "f"]
    return_value = LookupModule().run(terms)
    assert(random.choice(terms) == return_value)

# Generated at 2022-06-21 06:29:46.993563
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["test", "ansible", "pep8"]
    results = lookup_module.run(terms)
    assert results != ""

# Generated at 2022-06-21 06:29:51.471875
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create instance of class LookupModule
    lm = LookupModule()

    # Test method run on empty terms
    terms = None
    result = lm.run(terms)
    assert result == terms

    # Test method run on single term
    terms = ['one']
    result = lm.run(terms)
    assert result == terms

    # Test method run on multiple terms
    terms = ['one', 'two', 'three']
    result = lm.run(terms)
    assert result != terms

# Generated at 2022-06-21 06:29:53.911366
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 06:29:55.499630
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None


# Generated at 2022-06-21 06:29:58.130323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [1, 2, 3]
    result = lookup.run(terms)
    assert isinstance(result, list)
    assert result[0] in terms

# Generated at 2022-06-21 06:30:01.272701
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 06:30:22.517718
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except:
        assert False


# Generated at 2022-06-21 06:30:25.402870
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.run(["choice", "choice", "choice"])
    assert(hasattr(lookup, "run") == True)

# Generated at 2022-06-21 06:30:28.812881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.random_choice import LookupModule
    lookup = LookupModule()
    terms = [1, 2, 3, 4]
    terms_taken = lookup.run(terms)
    assert(terms_taken[0] in terms)

# Generated at 2022-06-21 06:30:33.831079
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    terms_input = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    inject_input = [{"item": "go through the door"}]
    assert lookup_module.run(terms_input, inject_input) == ["go through the door"]

    terms_input = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    inject_input = [{"item": "press the red button"}]
    assert lookup_module.run(terms_input, inject_input) == ["go through the door"]

# Generated at 2022-06-21 06:30:39.441344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ["Foo", "Bar"]
    expected = "Foo"
    lookup_module = LookupModule()

    # Act
    result = lookup_module.run(terms)

    # Assert
    assert result[0] in terms
    return result

# Generated at 2022-06-21 06:30:50.958569
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with an empty list
    terms = []
    returned_value = LookupModule().run(terms)
    assert returned_value == []
    # Test with a single value
    terms = ["value"]
    returned_value = LookupModule().run(terms)
    assert returned_value == ["value"]
    # Test with a list of values
    terms = ["a", "b", "c"]
    returned_value = LookupModule().run(terms)
    assert returned_value in [["a"], ["b"], ["c"]]
    # Test with a list of values and an index value
    terms = ["a", "b", "c"]
    inject = { 'index': 1 }
    returned_value = LookupModule().run(terms, inject=inject)

# Generated at 2022-06-21 06:30:55.306356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['ansible','containers','orchestration','management','pipeline','kubernetes','microservices','configuration','automation','continuous','integration','deployment','aws','jenkins','docker','azure','devops','cloud','saas']
    ret = lookup_module.run(terms)
    assert ret[0] in terms

# Generated at 2022-06-21 06:30:58.807429
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu != None

# Generated at 2022-06-21 06:31:01.530653
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Test LookupModule constructor"""

    lm = LookupModule()
    assert lm is not None


# Generated at 2022-06-21 06:31:09.164601
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # create object of class LookupModule
    lookup_module = LookupModule()
    source = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    try:
        # use run method of class LookupModule
        result = lookup_module.run(source)
        assert(result != None)
    except Exception as e:
        # non expected exception
        raise e

# Generated at 2022-06-21 06:31:54.133561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    test_terms = ['1','2','3','4','5','6','7','8','9','10']
    expected_result = '1'
    lookup_module = LookupModule()
    result = lookup_module.run(test_terms, inject=None, **{})
    assert expected_result == result[0]

# Generated at 2022-06-21 06:31:55.515239
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-21 06:31:57.280982
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = ["foo", "bar", "baz"]
    test_obj = LookupModule()
    assert test_obj.run(terms=data) in data

# Generated at 2022-06-21 06:32:01.074526
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # arrange
    terms = ['foo', 'bar', 'baz']

    # act
    lookup_module = LookupModule()
    result = lookup_module.run(terms)

    # assert
    assert result in terms
    assert len(result) == 1

# Generated at 2022-06-21 06:32:03.593660
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""
    lookup_obj = LookupModule()
    assert lookup_obj is not None

# Generated at 2022-06-21 06:32:08.455006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    random.seed(1)
    ret = lookup_obj.run(["hi", "bye"])
    random.seed(1)
    assert ret == [random.choice(["hi", "bye"])]

# Generated at 2022-06-21 06:32:12.456838
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L is not None
    assert isinstance(L, LookupModule)
    assert isinstance(L, LookupBase)

# Generated at 2022-06-21 06:32:17.999524
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("---Start---")
    print(LookupModule().run([], [], [], [], [], []))
    print("---End---")
if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-21 06:32:25.829937
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    lookup_module = LookupModule()
    # test with a list of integer, should return one random element
    result = lookup_module.run(terms=[1,2,3,4,5], inject=None, **{})
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] in [1,2,3,4,5]
    # test with a list of byte string, should return one random byte string
    result = lookup_module.run(terms=[to_bytes("hello"), to_bytes("there")], inject=None, **{})
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0]

# Generated at 2022-06-21 06:32:27.086351
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 06:33:51.321324
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_object = LookupModule()
    assert lookup_object is not None

# Generated at 2022-06-21 06:33:58.522730
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # set up parameters of class LookupModule
    # Note: here, 'a,b,c' is a single parameter (input to the constructor)
    lookup_module = LookupModule(['a,b,c'])

    # test run() of class LookupModule
    # Since the parameters are _random, the result will be one of 'a', 'b', 'c'
    result = lookup_module.run(['a', 'b', 'c'])
    assert result == ['a'] or result == ['b'] or result == ['c']

# Generated at 2022-06-21 06:34:01.740692
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create an instance
    lm = LookupModule()

    # define a string to return
    string1 = 'a'

    # call the run method
    result = lm.run(terms=[string1])

    # assert that the result equals the string
    assert result[0] == string1

# Generated at 2022-06-21 06:34:04.433186
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    item = ['foo','bar','baz','quux']

    lookup_module = LookupModule()
    r = lookup_module.run(item, inject=None)
    assert r == ['foo']

# Generated at 2022-06-21 06:34:09.167636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['a', 'b', 'c']
    ret = lookup_module.run(terms)
    assert(terms.index(ret[0]) >= 0)

# Generated at 2022-06-21 06:34:12.351929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["term1", "term2", "term3"]
    # The method run should return a term of the list terms
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms)
    assert result[0] in terms

# Generated at 2022-06-21 06:34:14.647439
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert len(lookup_module.run(terms=[1,2,3,4])) == 1

# Generated at 2022-06-21 06:34:17.331931
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-21 06:34:23.539029
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    hash = []
    i = 0
    while i < 100:
        hash.append(lookup_module.run(['one', 'two', 'three', 'four']))
        i += 1

    # Now test if all the 4 elements are present in the hash list
    assert ('one' in hash) and ('two' in hash) and ('three' in hash) and ('four' in hash)

# Generated at 2022-06-21 06:34:33.590824
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import sys
    import yaml
    yaml_path = os.path.dirname(__file__) + "/random_choice.yml"
    with open(yaml_path,'r') as f:
        yaml_config = yaml.load(f)

    # To create a mock object
    test_obj = LookupModule()

    # Declare variables used in test
    arg_list = yaml_config['test_run'][0]
    terms = arg_list['terms']
    inject = arg_list['inject']

    ret = test_obj.run(terms, inject)
    assert type(ret) is list
    assert ret in terms