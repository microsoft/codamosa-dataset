

# Generated at 2022-06-23 11:59:45.496972
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None) is not None

# Generated at 2022-06-23 11:59:46.706243
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None


# Generated at 2022-06-23 11:59:47.869899
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    print(lookup_module)

# Generated at 2022-06-23 11:59:50.515724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule().run(['Item 1', 'Item 2', 'Item 3'])

# Generated at 2022-06-23 11:59:51.140143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 11:59:55.310899
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest.mock as mock
    lookup = LookupModule()
    assert lookup.run(terms=["a", "b"]) in [["a"], ["b"]], "LookupModule.run() returned an unexpected result"

# Generated at 2022-06-23 12:00:01.075280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run([]) == []
    assert lookup_module.run(["a"]) in (["a"],)
    assert len(lookup_module.run(["a", "b"])) == 1
    assert lookup_module.run(["a", "b"]) in (["a"], ["b"])
    assert lookup_module.run(["a", "b"]) not in ([], ["a", "b"])

# Generated at 2022-06-23 12:00:08.679796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test settings
    test_input = ['test1', 'test2', 'test3']
    test_output = ['test1', 'test2', 'test3']

    # Test exception for invalid input
    with pytest.raises(AnsibleError) as exception_info:
        LookupModule.run(test_input)

    assert str(exception_info).startswith('Unable to choose random term:')

    # Test behaviour for valid input
    assert LookupModule.run(test_output) in test_input

# Generated at 2022-06-23 12:00:12.272313
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    result = lookup.run( ['this', 'is', 'a', 'test'])
    assert len(result) == 1, "Should be one element in the array"
    assert result[0] in ['this', 'is', 'a', 'test'], "Random choice is out of range"

# Generated at 2022-06-23 12:00:18.337830
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Running test_LookupModule")
    lookup_plugin = LookupModule()
    term = ['foo']
    result = lookup_plugin.run(term)
    print("result={}".format(result))
    assert result == ['foo']

    lookup_plugin = LookupModule()
    result = lookup_plugin.run(None)
    print("result={}".format(result))
    assert result == []


# Generated at 2022-06-23 12:00:23.014378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = [1, 2, 3, 4]
    random_terms = lookup_plugin.run(terms=terms)
    assert terms.count(random_terms[0]) == 1
    assert len(random_terms) == 1

# Generated at 2022-06-23 12:00:33.548587
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:00:39.468129
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mylookup = LookupModule()
    # Test with empty list
    assert(mylookup.run(terms=[], inject=None, **{}) == [])
    # Test with single element
    assert(mylookup.run(terms=[0], inject=None, **{}) == [0])
    # Test with multiple elements
    assert(mylookup.run(terms=[0, 1], inject=None, **{}) in [[0], [1]])

# Generated at 2022-06-23 12:00:40.504168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:00:42.016391
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert isinstance(test, LookupModule)

# Generated at 2022-06-23 12:00:42.905604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()

# Generated at 2022-06-23 12:00:45.107740
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert isinstance(LookupModule().run(terms=["go through the door", "drink from the goblet", "press the red button", "do nothing"]), list)

# Generated at 2022-06-23 12:00:46.550881
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result

# Generated at 2022-06-23 12:00:50.055394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_obj = LookupModule()
    terms = [1, 2, 3]
    terms_list = my_obj.run(terms)
    assert terms_list in [1, 2, 3]
# Unit test end

# Generated at 2022-06-23 12:00:58.077950
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup.run(terms='')
    assert 'empty' in excinfo.value.args[0]
    # choice of one item from list
    terms = ['test']
    ret = lookup.run(terms=terms)
    assert ret == ['test']
    # choice of two items from list
    terms = ['test1', 'test2']
    ret = lookup.run(terms=terms)
    assert ret == ['test1'] or ret == ['test2']

# Generated at 2022-06-23 12:01:03.017650
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test that constructor succeeds without exception
    try:
        lookup_module = LookupModule()
    except Exception:
        print("Test for construction of class LookupModule failed")
        return

    print("Test for construction of class LookupModule passed")



# Generated at 2022-06-23 12:01:06.367275
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert [] == lookup_module.run(terms="")
    if lookup_module.run(terms=[]) == lookup_module.run(terms=""):
        assert True
    else:
        assert False

# Generated at 2022-06-23 12:01:07.511354
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup = LookupModule()
    assert lookup



# Generated at 2022-06-23 12:01:10.464856
# Unit test for constructor of class LookupModule
def test_LookupModule():
   L = LookupModule()
   assert isinstance(L, LookupModule)


# Generated at 2022-06-23 12:01:11.932612
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:01:16.683065
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Hack needed to import module into current namespace
    lookup = globals()['LookupModule']()

    # Hack to stuff argv with vales needed by ansible
    import sys
    sys.argv = [ sys.argv[0], '--connection=local' ]

    # Init class with terms to work on
    terms = [ 'foo', 'bar', 'baz' ]

    # Do 3 runs so we can prove a random element is picked each time
    expected_results = [ terms, terms, terms ]
    for expected in expected_results:
        result = lookup.run(terms=terms)
        if len(result) != 1:
            raise Exception("LookupModule.run should have returned exactly one element")

# Generated at 2022-06-23 12:01:22.817832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    To test method run of LookupModule, do the following:
        1. Create a LookupModule object with test_terms
        2. Call method of LookupModule
        3. Assert returned value is among element of the test_terms list
    '''
    test_terms = [
        u"go through the door",
        u"drink from the goblet",
        u"press the red button",
        u"do nothing",
        ]

    lookup = LookupModule()
    result = lookup.run(test_terms)
    assert result[0] in test_terms

# Generated at 2022-06-23 12:01:29.452954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert(lookup_module.run(terms=["one", "two", "three"], inject=None, **{}) == ['one']
    or lookup_module.run(terms=["one", "two", "three"], inject=None, **{}) == ['two']
    or lookup_module.run(terms=["one", "two", "three"], inject=None, **{}) == ['three'])

# Generated at 2022-06-23 12:01:33.633454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [10, 20, 30, 40, 50]
    result = lookup_module.run(terms=terms)
    print(result)
    assert result != [], "Testcase Passed"

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 12:01:36.611850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(LookupModule().run([1, 2, 3]) == [1] or LookupModule().run([1, 2, 3]) == [2] or LookupModule().run([1, 2, 3]) == [3])

# Generated at 2022-06-23 12:01:38.421557
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 12:01:41.473073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    arr = [1, 2, 3, 4]
    result = lookup_module.run(arr)
    assert result in arr
    arr = []
    result = lookup_module.run(arr)
    assert result == arr

# Generated at 2022-06-23 12:01:43.590875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    assert l.run(["a","b","c"]) == ["a"] or ["b"] or ["c"]

# Generated at 2022-06-23 12:01:47.308305
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(["test1", "test2", "test3"])
    assert ret[0] in ("test1", "test2", "test3")

# Generated at 2022-06-23 12:01:59.148611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import pytest
    from ansible.parsing.vault import VaultLib


    # Create the LookupModule object
    lm = LookupModule()

    # Unit test for LookupModule.run
    input_terms = [
        [0, 1, 2, 3, 4],
        [10, 20, 30],
        ['a', 'b', 'c', 'd'],
        ['red', 'blue', 'yellow'],
        ['paper', 'scissors', 'rock']
    ]

    results = lm.run(input_terms, inject={})

    # Ensure that we received the correct number of results
    assert len(input_terms) == len(results)

    # Ensure that every element in the result list is in the input list

# Generated at 2022-06-23 12:02:01.277474
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run([1, 2, 3, 4])
    print(result)

# Generated at 2022-06-23 12:02:02.412168
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() is not None

# Generated at 2022-06-23 12:02:03.837481
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run(terms=[1,2,3], inject=None)

# Generated at 2022-06-23 12:02:06.302173
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run([{"one": "two"}])

# Generated at 2022-06-23 12:02:13.101216
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    test_terms = ["term1", "term2", "term3"]
    test_inject = None
    lookup_obj = LookupModule()
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 0
    lookup_obj._display = display
    
    # Act
    ret = lookup_obj.run(test_terms, test_inject)
    
    # Assert
    assert ret in ["term1", "term2", "term3"]

# Generated at 2022-06-23 12:02:14.548382
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert type(LookupModule.run) == type(LookupBase.run)

# Generated at 2022-06-23 12:02:16.119983
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing Constructor')
    lookup = LookupModule()


# Generated at 2022-06-23 12:02:25.301543
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Assert that 4 items of a list with 4 items are selected at random
    lookup_module = LookupModule()
    terms = [u'term1', u'term2', u'term3', u'term4']
    result = lookup_module.run(terms=terms)
    assert result in terms

    # Assert that 3 items of a list with 4 items are selected at random
    lookup_module = LookupModule()
    terms = [u'term1', u'term2', u'term3', u'term4']
    result = lookup_module.run(terms=terms, inject=dict(random_item_count='3'))
    assert result in terms
    assert result.__len__() == 3

    # Assert that random_item_count has precedence over a list with 4 items
    lookup_module = LookupModule()


# Generated at 2022-06-23 12:02:29.108846
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # call the constructor
    lm = LookupModule()
    #check the object vaues
    assert lm.run(['a', 'b', 'c']) == ['a'] or ['b'] or ['c']

# Generated at 2022-06-23 12:02:32.933790
# Unit test for constructor of class LookupModule
def test_LookupModule():
  # mock input
  terms = ['foo','bar']
  # assert the test conditions
  assert LookupModule.run(LookupModule(), terms, inject=None, **{})[0] == 'bar'

# Generated at 2022-06-23 12:02:37.802073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._templar = None
    lookup_module._loader = None
    lookup_module.basedir = None
    lookup_module.set_options({})

    assert lookup_module.run([]) == []
    assert lookup_module.run([1, 2, 3]) == [3]

# Generated at 2022-06-23 12:02:49.124525
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils import basic
    import sys

    class Options:
        def __init__(self, **kw):
            self.__dict__.update(kw)


# Generated at 2022-06-23 12:02:50.670009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(['a', 'b', 'c']) == ['b']

# Generated at 2022-06-23 12:02:52.996555
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["a", "b", "c", "d", "e"]
    lookup_plugin = LookupModule()
    response = lookup_plugin.run(terms)
    assert response in terms

# Generated at 2022-06-23 12:02:55.032855
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lkmodule = LookupModule()
    assert lkmodule.run([1,2,3]) == [3]

# Generated at 2022-06-23 12:02:58.151713
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data = [['test1'],['test2'],['test3'],['test4'],['test5']]
    result = LookupModule().run(data)
    assert result[0] in data

# Generated at 2022-06-23 12:03:01.755296
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ['a', 'b', 'c', 'd']

    found = lookup.run(terms, inject=1)

    assert len(found) == 1
    assert found[0] in terms


# Generated at 2022-06-23 12:03:04.115510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lp = LookupModule()
    terms = ['term1', 'term2', 'term3', 'term4']
    assert lp.run(terms) in terms

# Generated at 2022-06-23 12:03:10.793499
# Unit test for constructor of class LookupModule
def test_LookupModule():
    if __name__ == '__main__':
        lookup = LookupModule()
        terms = ["ansible", "ansible-tower", "ansible-docs", "ansible-modules", "ansible-modules-core", "ansible-modules-extras", "ansible-modules-extra"]
        ret = lookup.run(terms, inject=None, **kwargs)
        assert ret != None
        if ret is not None:
           assert ret in terms
        print(ret)

# Generated at 2022-06-23 12:03:12.253727
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert set(LookupModule.run(LookupModule(),
    ('A', 'B', 'C'))[0]) - set(['A', 'B', 'C']) == set([])

# Generated at 2022-06-23 12:03:14.424703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test1 = LookupModule()
    terms = ["option 1", "option 2", "option 3"]
    assert test1.run(terms) in terms


# Generated at 2022-06-23 12:03:18.484547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
     lookupmodule = LookupModule()

     terms = ['a', 'b', 'c']
     results = lookupmodule.run(terms, inject={}, **{})
     assert len(results) == 1
     assert results[0] in terms

# Generated at 2022-06-23 12:03:22.485479
# Unit test for constructor of class LookupModule
def test_LookupModule():
  print(dir())
  testObj = LookupModule()
  print(testObj)
  print(testObj.__dict__)
  print(testObj.__class__.mro())
  print(testObj.run([1,2,3]))

test_LookupModule()

# Generated at 2022-06-23 12:03:32.515608
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Random choice from 1 element
    lookup = LookupModule()
    terms = ['foo']
    assert lookup.run(terms) == ['foo']

    # Random choice from 1 element
    lookup = LookupModule()
    terms = ['foo']
    assert lookup.run(terms) == ['foo']

    # Random choice from 2 elements
    lookup = LookupModule()
    terms = ['foo', 'bar']
    assert lookup.run(terms) in [['foo'], ['bar']]
    assert lookup.run(terms) in [['foo'], ['bar']]
    assert lookup.run(terms) in [['foo'], ['bar']]

    # Random choice from 3 elements
    lookup = LookupModule()
    terms = ['foo', 'bar', 'baz']

# Generated at 2022-06-23 12:03:33.987332
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_object = LookupModule()
    assert test_object is not None


# Generated at 2022-06-23 12:03:34.543962
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:03:40.927331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    import collections
    l = LookupModule()
    # Test method run
    terms = ["foo", "bar"]
    terms_dict = collections.OrderedDict()
    terms_dict["foo"] = "bar"
    terms_dict["bar"] = "foo"
    # Test run with list and dict
    assert l.run(terms) in terms
    assert l.run(terms_dict) in terms_dict

# Generated at 2022-06-23 12:03:42.592946
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Constructor Test for random_choice plugin")
    random_choice = LookupModule()
    assert random_choice != None

# Generated at 2022-06-23 12:03:47.580376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test.set_options({'_terms': [1,2,3,4]})
    assert test.run() == [3]

# Test the case when terms are an empty list

# Generated at 2022-06-23 12:03:48.167887
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:03:50.627259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    terms = ["first", "second", "third"]
    ret = lookup_module.run(terms)
    assert ret in terms



# Generated at 2022-06-23 12:03:52.939143
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ['a', 'b', 'c']
    results = lookup.run(terms)
    assert len(results)==1

# Generated at 2022-06-23 12:03:55.400236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  l = LookupModule()
  l.run([1,2,3,4,5,6,7,8,9,10],None)

# Generated at 2022-06-23 12:03:57.383967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(terms=[1]) == [1]
    assert module.run(terms=[1, 2, 3]) != [1, 2, 3]

# Generated at 2022-06-23 12:04:07.768630
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    from ansible.errors import AnsibleError

    # test with junk input
    lookup = LookupModule()
    assert lookup.run(['junkinput']) == ['junkinput']

    random.seed(0)
    # test with one element in the list
    lookup = LookupModule()
    assert lookup.run(['junkinput']) == ['junkinput']

    # test different input values
    lookup = LookupModule()
    assert lookup.run(['junkinput', 'testvalue']) == ['testvalue']

    random.seed(0)
    # test different input values
    lookup = LookupModule()
    assert lookup.run(['junkinput', 'testvalue']) == ['junkinput']
    random.seed()

    # test with an empty list
    lookup = LookupModule()


# Generated at 2022-06-23 12:04:13.111324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # test random_choice with a single element
    test_terms = ['foo']
    result = l.run(test_terms)
    assert result == ['foo']

    # test random_choice with 3 elements
    test_terms = ['foo', 'bar', 'baz']
    result = l.run(test_terms)
    assert result in test_terms



# Generated at 2022-06-23 12:04:17.744886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = [1,2,3,4,5]
    t1 = [1,2,3,4,5]

    t2 = []
    lkup = LookupModule()
    res = lkup.run(t)
    assert(len(res) == 1)
    assert(res[0] in t1)

# Generated at 2022-06-23 12:04:20.307728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_o = LookupModule(None, None, None)
    ret = lookup_o.run([1, 2, 3])
    assert ret[0] in [1, 2, 3]

# Generated at 2022-06-23 12:04:26.170444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test 'random_choice' method with only one element in the list
    lookup_module = LookupModule()
    assert lookup_module.run(terms=["one"]) == ["one"]

    # Test 'random_choice' method with more than one element in the list
    lookup_module = LookupModule()
    assert len(lookup_module.run(terms=["one", "two", "three"])) == 1

# Generated at 2022-06-23 12:04:27.178264
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:04:36.428441
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    result = {
        'hello': 'world'
    }

    # create an instance of LookupModule
    lookup_module = LookupModule()

    # test with invalid array
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module.run(result)

    assert 'Unable to choose random term: list.index(x): x not in list' in to_native(excinfo.value)

    # test with valid array
    result = ['hello', 'world']
    data = lookup_module.run(result)
    assert (data == ['hello']) or (data == ['world']) or (data == ['hello', 'world'])

# Generated at 2022-06-23 12:04:36.833471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:04:39.393777
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = lookup_plugin.run(terms=['a', 'b', 'c'], inject=None)
    assert len(terms) == 1
    assert terms[0] in ['a', 'b', 'c']

# Generated at 2022-06-23 12:04:41.827886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ["1", "2", "3", "4", "5"]
    ret = lm.run(terms)
    assert ret in terms

# Generated at 2022-06-23 12:04:48.776617
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    This is a unit test of constructor of class LookupModule
    """
    # pylint: disable=protected-access
    # pylint: disable=missing-docstring
    terms = ["1", "2", "3"]
    inject = {}
    kwargs = {"key": "value"}
    lookup = LookupModule()
    assert lookup.run(terms, inject, **kwargs) == terms

# Generated at 2022-06-23 12:04:49.205492
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:04:57.001205
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test 2 or more choices
    input_data=[1, 2, 3]
    random_choice=LookupModule()
    output_data=random_choice.run(terms=input_data)
    assert len(output_data) == 1

    # Test 1 choice
    input_data=[1]
    random_choice=LookupModule()
    output_data=random_choice.run(terms=input_data)
    assert len(output_data) == 1

    # Test 0 choice
    input_data=[]
    random_choice=LookupModule()
    output_data=random_choice.run(terms=input_data)
    assert len(output_data) == 0

# Generated at 2022-06-23 12:05:00.880643
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = ['A', 'B', 'C']

    try:
        assert lookup_module.run(terms) in terms
    except Exception:
        assert lookup_module.run(terms) == terms

# Generated at 2022-06-23 12:05:01.763082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:05:03.163207
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()
    assert isinstance(instance, LookupModule)

# Generated at 2022-06-23 12:05:04.999529
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-23 12:05:05.598615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:05:07.680446
# Unit test for constructor of class LookupModule
def test_LookupModule():
    f = [1,2,3,4]
    random.shuffle(f)
    lookup1 = LookupModule()
    assert f == lookup1.run(terms=f)

# Generated at 2022-06-23 12:05:11.430820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['test1', 'test2']
    result = lm.run(terms=terms)
    assert result[0] in terms


# Generated at 2022-06-23 12:05:17.824199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ Unit test for method run of class LookupModule"""
    lookup = LookupModule()

    assert [random.choice([1, 2, 3])] == lookup.run([1, 2, 3])

    assert [random.choice(['a', 'b'])] == lookup.run(['a', 'b'])

    assert [] == lookup.run(None)

    assert [] == lookup.run([])

# Generated at 2022-06-23 12:05:21.501360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['term1', 'term2', 'term3', 'term4']
    lookup_module = LookupModule()
    random_term = lookup_module.run(terms)
    assert random_term[0] in terms

# Generated at 2022-06-23 12:05:32.130997
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(LookupModule().run([[1,2,3,4]]) == [[1,2,3,4]])
    assert(LookupModule().run([[], [2]]) == [[2]])
    assert(LookupModule().run([[], [], [3]]) == [[3]])
    assert(LookupModule().run([[], [], [], [4]]) == [[4]])
    assert(LookupModule().run([[], [], [], [], [5]]) == [[5]])
    assert(LookupModule().run([[], [], [], [], [], [6]]) == [[6]])
    assert(LookupModule().run([[], [], [], [], [], [], [7]]) == [[7]])

# Generated at 2022-06-23 12:05:40.282374
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class Options:
        _terms = ["term1", "term2", "term3"]

    class Runner:
        def __init__(self, **kwargs):
            self.connection = "local"
            self.module_name = "lookup_random_choice"
            self.task_vars=kwargs
            self.options = Options()

    lookup_plugin = LookupModule()
    lookup_plugin._load_name = "random_choice"

    assert "term2" in lookup_plugin.run([])
    assert "term1" in lookup_plugin.run(Runner(ansible_facts={"ansible_local": {"random_fact": "term1"}}))

# Generated at 2022-06-23 12:05:42.197304
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

# Generated at 2022-06-23 12:05:51.960499
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return
    ##########################################
    # set up
    ##########################################
    # Nothing to do here
    
    ##########################################
    # test cases
    ##########################################
    # Case 1 - Positive
    # Input: 
    #    terms = ['a','b','c']
    
    terms = ['a','b','c']
    lm = LookupModule()
    ret = lm.run(terms)
    print("Return Code :%s" % ret)
    
    # Case 2 - Positive
    # Input: 
    #    terms = []
    terms = []
    ret = lm.run(terms)
    print("Return Code :%s" % ret)
    
    # Case 3 - Negative
    # Input: 
    #    terms = None
    terms = None

# Generated at 2022-06-23 12:05:53.784842
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 12:05:55.605197
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:05:56.744580
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 12:06:03.408809
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        test_lookup_module = LookupModule()
        # test __init__()
        assert test_lookup_module
    except Exception:
        raise Exception("Failed to create instance of LookupModule")

    # test run()
    try:
        terms = ["test_term1", "test_term2"]
        test_lookup_module.run(terms)
    except Exception as e:
        raise Exception("Failed to run LookupModule")


# Generated at 2022-06-23 12:06:10.270321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test raises error:
    from ansible.plugins.lookup import LookupModule
    import random
    data = ["a", "b", "c"]
    random.choice = lambda x: None
    test = LookupModule()
    assert test.run(data) == data

    # Test raises error:
    random.choice = lambda x: "a"
    test = LookupModule()
    assert test.run([]) == []

# Generated at 2022-06-23 12:06:11.719515
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:06:13.578540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:06:14.916631
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:06:26.487704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    from ansible.plugins.lookup import LookupBase

    # Make sure ansible directory is in sys path.
    current_path = os.getcwd()
    ansible_path = os.path.dirname(os.path.dirname(current_path))
    sys.path.insert(0, ansible_path)

    # Import class LookupModule
    import plugins.lookup.random_choice
    reload(plugins.lookup.random_choice)
    from plugins.lookup.random_choice import LookupModule

    # Test run method
    terms = ["a","b","c"]
    print("class LookupModule.run(%s)" % terms)
    lookup = LookupModule()
    result = lookup.run(terms)
    print("result = %s" % result)
   

# Generated at 2022-06-23 12:06:27.790483
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None


# Generated at 2022-06-23 12:06:30.562254
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['a', 'b', 'c']
    lookup = LookupModule()
    assert len(lookup.run(terms)) == 1

# Generated at 2022-06-23 12:06:34.793831
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['one', 'two', 'three', 'four', 'five']
    result = LookupModule().run(terms)
    if result not in terms:
        raise Exception('The result is not one of terms')

# Generated at 2022-06-23 12:06:37.197847
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    terms = ['first choice', 'second choice']
    ret = obj.run(terms)

    assert(ret == terms or ret == ['second choice'] or ret == ['first choice'])
    assert(isinstance(ret, list))

# Generated at 2022-06-23 12:06:38.562512
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-23 12:06:41.530004
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test1: test_LookupModule_run")
    values = [2, 3, 5, 7, 11, 13, 17, 19]
    random_value = LookupModule().run(values)[0]
    assert random_value in values
    


# Generated at 2022-06-23 12:06:46.335017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with a single term.
    lm = LookupModule()
    assert len(lm.run(['hola'])) == 1

    # Test with multiple terms.
    lm = LookupModule()
    assert len(lm.run(['hola', 'mundo'])) == 1
    assert len(lm.run(['hola', 'mundo'])) == 1
    assert len(lm.run(['hola', 'mundo'])) == 1
    assert len(lm.run(['hola', 'mundo'])) == 1
    assert len(lm.run(['hola', 'mundo'])) == 1

# Generated at 2022-06-23 12:06:49.250254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    my_terms = ["foo", "bar"]
    assert lookup_module.run(my_terms, inject=None) == my_terms

# Generated at 2022-06-23 12:06:49.928501
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:06:53.331968
# Unit test for constructor of class LookupModule

# Generated at 2022-06-23 12:06:59.185504
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import json
    global_args = {}
    
    # Instantiation of class LookupModule with term and inject
    argspecs = {}
    terms = ['blue', 'red', 'yellow']
    inject = None
    lm = LookupModule(**argspecs)
    # Calling run() method of class and print output
    try:
        result = lm.run(terms=terms, inject=inject)
        print(result)
    except Exception as e:
        print(e)


# main function

# Generated at 2022-06-23 12:07:01.787193
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    ret = lm.run(['1','2','3'])
    assert ret[0] in ['1','2','3']

# Generated at 2022-06-23 12:07:08.936534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        # Inject is a dictionary, representing the variables available in Ansible
        # For example:
        # inject = dict(var1='var1', var2=dict(subvar1=[1,2,3]))
        inject = dict()

        terms = list()
        terms.append(dict(id=1,name='john'))
        terms.append(dict(id=2,name='jane'))
        terms.append(dict(id=3,name='joe'))

        lookup_plugin = LookupModule()
        res = lookup_plugin.run(terms, inject, **dict)

        assert len(res) == 1
    except Exception as e:
        print('Exception: %s' % e)
        assert False

# Generated at 2022-06-23 12:07:12.167402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lu = LookupModule()
        assert lu is not None
        value = lu.run(["foo", "bar"])
        assert value is not None
    except AnsibleError as aerr:
        assert aerr.message is None

# Generated at 2022-06-23 12:07:15.572255
# Unit test for constructor of class LookupModule
def test_LookupModule():
    p = LookupModule()
    # test return
    assert p.run(["https://localhost:8080", "https://localhost:8081"]) is not None

# Generated at 2022-06-23 12:07:17.550397
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule("action","module",("foo","bar"))
    assert lookup_module

# Generated at 2022-06-23 12:07:23.013547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
        [
            "John",
            "JoJo",
            "Jose",
            "Joseph",
            "JoJoJoJoJoJoJoJoJoJoJoJoJoJoJoJoJoJoJoJoJoJo",
            "Josephine",
        ],
    ]
    t = LookupModule()
    t.run(terms = args[0])

# Generated at 2022-06-23 12:07:24.745254
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    terms = ["one", "two", "three"]
    result = test_object.run(terms)
    assert(result in terms)

# Generated at 2022-06-23 12:07:27.603086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    terms = ['cat', 'dog', 'snake']
    result = lookup_plugin.run(terms, inject={})
    assert result == ['cat'] or result == ['dog'] or result == ['snake']


# Generated at 2022-06-23 12:07:36.235951
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Input parameters for this method
    terms = [
        "go through the door",
        "drink from the goblet",
        "press the red button",
        "do nothing",
    ]
    inject = None
    kwargs = {}

    # Expected return value for this method
    ret = terms

    # Obtaining an instance of the class
    instance = LookupModule()

    # Call method run of the class with parameters
    assert instance.run(terms, inject, **kwargs) == ret

# Generated at 2022-06-23 12:07:40.857087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_random_choice = LookupModule()
    test_terms = ['one', 'two', 'three', 'four']
    ret = lookup_random_choice.run(test_terms)
    assert(ret != None)
    assert(len(ret) == 1)
    assert(ret[0] in test_terms)

# Generated at 2022-06-23 12:07:42.542046
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:07:46.497364
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        the_list = [1,2,3,4,5]
        choice = LookupModule()
        result = choice.run(the_list)
        
        assert(result in the_list)

    except Exception as e:
        raise AnsibleError("Unable to choose random term: %s" % to_native(e))

# Generated at 2022-06-23 12:07:51.858506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ['instant', 'boiling', 'strong', 'weak']
    lookup_module = LookupModule()

    # Act
    results = lookup_module.run(terms)

    # Assert
    assert len(results) == 1
    assert results[0] in terms

# Generated at 2022-06-23 12:07:52.163323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:07:53.727009
# Unit test for constructor of class LookupModule
def test_LookupModule():
    foo = LookupModule()
    assert foo is not None


# Generated at 2022-06-23 12:07:54.966878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['a','b','c']
    assert(LookupModule().run(terms))
# Unit test end

# Generated at 2022-06-23 12:07:57.180460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    results = LookupModule.run(['one','two'], None)
    assert results[0] == 'one' or results[0] == 'two'

# Generated at 2022-06-23 12:08:00.076838
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data_input = ['ansible', 'docs']
    assert LookupModule.run(LookupModule, data_input) in data_input

# Generated at 2022-06-23 12:08:06.585252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  class TestLookupModule(LookupModule):
    def __init__(self, terms, inject=None, **kwargs):
      self._terms = terms
      self._loaded_terms = terms
    def get_original_terms(self):
      return self._terms

  try:
    test_instance=TestLookupModule([''])
    test_instance.run(None)
  except Exception as e:
    return False
  return True

# Generated at 2022-06-23 12:08:09.096273
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: implement this.
    pass

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 12:08:10.881686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['One', 'Two', 'Three', 'Four']
    l = LookupModule()
    returned_value = l.run(terms)
    assert returned_value in terms, 'AssertionError'

# Generated at 2022-06-23 12:08:13.495902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run(['1','2','3','4']) != lookup_plugin.run(['1','2','3','4'])

# Generated at 2022-06-23 12:08:15.734290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  l = LookupModule()
  import random
  assert l.run([random.randint(0, 10)]) == [random.randint(0, 10)]

# Generated at 2022-06-23 12:08:16.747214
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert 1 == 1
  

# Generated at 2022-06-23 12:08:18.587937
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    # test __init__()
    assert lookup_plugin

# Generated at 2022-06-23 12:08:29.098181
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    test class LookupModule
    """
    lookup_module = LookupModule()

    # Test ret of class LookupModule
    # boolean_type, list_type, and str_type are arguments
    # ret is returned value
    boolean_type = True
    list_type = ['foo','bar']
    str_type = 'foo'

    ret = lookup_module.run(boolean_type)
    assert ret  == [boolean_type]

    ret = lookup_module.run(list_type)
    assert True in ( ret[0] in list_type )

    ret = lookup_module.run(str_type)
    assert ret  == [str_type]

# Generated at 2022-06-23 12:08:31.753127
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ret = terms = [1, 2]
    random_terms = [random.choice(terms)]
    assert(ret == random_terms)

# Generated at 2022-06-23 12:08:37.189731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule

    This test is also used as an example of how to write tests for lookup plugins.
    """

    # Instantiate LookupModule class
    lookupModule = LookupModule()

    # Test of run method
    terms = [1, 2, 3, 4, 5]
    for i in range(100):
        ret = lookupModule.run(terms, None)
        assert len(ret) == 1
        assert ret[0] in terms

# Generated at 2022-06-23 12:08:38.728278
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()
    l.run(['foo', 'bar'])

# Generated at 2022-06-23 12:08:40.929415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["a", "b", "c"]
    assert lookup_module.run(terms) in terms

# Generated at 2022-06-23 12:08:42.117442
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()


# Generated at 2022-06-23 12:08:49.683854
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test run with empty terms.
    result = lookup_module.run(terms=[], inject=None, **{})
    assert result == []

    # Test run with at least one item in the list.
    result = lookup_module.run(terms=[x for x in range(10)], inject=None, **{})
    assert result[0] in [x for x in range(10)]

    # Test expected exceptions.
    try:
        result = lookup_module.run(terms=[None], inject=None, **{})
        assert False
    except AnsibleError:
        pass

# Generated at 2022-06-23 12:08:57.517272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a LookupModule object,
    # with a list of 3 elements as parameter of method run,
    # check if the return is one of the three elements
    lookup_plugin = LookupModule()
    list_of_three_elements = ['first', 'second', 'third']
    random_pick = lookup_plugin.run(None, terms=list_of_three_elements)[0]
    assert random_pick in list_of_three_elements, "Return is not a element of the given list"

# Generated at 2022-06-23 12:09:05.832971
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # Test when called without any term element
  lu = LookupModule()
  terms = []
  ret = lu.run(terms)
  assert isinstance(ret, list)
  assert len(ret) == 0

  # Test when called with one term element
  lu = LookupModule()
  terms = ['value1']
  ret = lu.run(terms)
  assert isinstance(ret, list)
  assert len(ret) == 1
  assert ret == ['value1']

  # Test when called with two term elements
  lu = LookupModule()
  terms = ['value1', 'value2']
  ret = lu.run(terms)
  assert isinstance(ret, list)
  assert len(ret) == 1
  assert ret == ['value1']

# Generated at 2022-06-23 12:09:11.053640
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test of method run with empty terms
    lookup_instance = LookupModule()
    assert list() == lookup_instance.run(terms=list())

    # Test of method run with terms
    terms = list()
    terms.append("first term")
    terms.append("second term")
    assert 1 == len(lookup_instance.run(terms=terms))

# Generated at 2022-06-23 12:09:12.351552
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 12:09:17.919534
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of the random_choice lookup class
    random_choice = LookupModule()

    # Create a list of terms
    terms = ["term1", "term2", "term3"]

    # Run a test using the random_choice.run method
    results = random_choice.run(terms)

    # Assert that the results are one of the terms
    assert results[0] in terms

# Generated at 2022-06-23 12:09:21.077083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test the method run with a list of one element
    terms = list("e")
    lookup_module = LookupModule()
    assert lookup_module.run(terms) == ["e"]


# Generated at 2022-06-23 12:09:21.452332
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:09:24.116157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    assert(module.run(terms))

# Generated at 2022-06-23 12:09:27.536489
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    random_choice = "do nothing"

    assert random_choice == LookupModule().run(terms)[0]

# Generated at 2022-06-23 12:09:30.074060
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        lookup_module = LookupModule()
        terms = ['Ansible', 'is', 'awesome']
        random_item = lookup_module.run(terms)
        assert random_item[0] in terms

# Generated at 2022-06-23 12:09:33.100544
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    test_instance = LookupModule()
    terms = ["Entry1","Entry2","Entry3"]
    response = test_instance.run(terms)

    assert (response in terms)

# Generated at 2022-06-23 12:09:39.974031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run([
        "go through the door",
        "drink from the goblet",
        "press the red button",
        "do nothing",
    ])
    assert(ret and len(ret) == 1 and
           ret[0] in [
               "go through the door",
               "drink from the goblet",
               "press the red button",
               "do nothing",
           ])

# Generated at 2022-06-23 12:09:42.634126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1,2,3,4,5]
    results = LookupModule.run(None, terms)
    assert len(results) == 1
    assert results[0] in terms

# Generated at 2022-06-23 12:09:53.901079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Inject is a map for testing module.
    # It must contain a key named 'random_choice'
    # This key must have a list of values as value
    # Currently, the value is a list of 1 element
    # This element is the expected value of the run() method
    inject = dict(
        random_choice=[
            "Initial value"])

    # Create an instance of the LookupModule class
    lookup_plugin = LookupModule()

    # The run() method needs 2 arguments
    # The first one is a list of terms
    # The second one is the inject map
    # This method returns a list with one element
    # That element must be the expected value
    # This assertion checks if this element is the expected one
    assert lookup_plugin.run(terms=[], inject=inject) == inject['random_choice']