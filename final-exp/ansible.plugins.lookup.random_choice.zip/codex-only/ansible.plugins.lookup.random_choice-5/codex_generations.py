

# Generated at 2022-06-23 11:59:48.267830
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # no 'assert' below to allow other test to happen
    lookup_module = LookupModule()

# Generated at 2022-06-23 11:59:57.937450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("LookupModule")
    terms = ['ansible', 'automation']
    random_choice = 'ansible'
    try:
        from unittest.mock import MagicMock
        lookup_base = MagicMock()
        lookup_base.run = MagicMock(return_value=random_choice)
        result = lookup_base.run(terms, inject=None, **kwargs)
        assert random_choice == result[0]
    except ImportError:
        print("no mock lib")

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 12:00:00.365333
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)


# Generated at 2022-06-23 12:00:06.001911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set up arguments used by the ansible module
    terms = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    inject = None
    kwargs = {}

    lm = LookupModule()
    new_terms = lm.run(terms, inject, **kwargs)

    assert new_terms in terms
    assert len(new_terms) is 1

# Generated at 2022-06-23 12:00:07.783212
# Unit test for constructor of class LookupModule
def test_LookupModule():
    source = LookupModule()
    # No test yet
    assert True

# Generated at 2022-06-23 12:00:11.674811
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    items = [ "one", "two", "three", "four"]
    results = []
    for i in range(0,10):
        results.append(LookupModule().run(items)[0])
    assert len(set(results)) == len(items)


# Generated at 2022-06-23 12:00:16.764693
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # build test
    test_terms = ["hello","world","my","name","is","john","cena"]
    # test
    result = LookupModule.run(test_terms)
    if any(result[0] not in test_terms[i] for i in range(0, len(test_terms))):
        raise Exception('test has failed - result not in test_terms')
    print('test passed')

# Generated at 2022-06-23 12:00:21.496341
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test function for LookupModule run() method."""
    for terms in [['one', 'two'], ['one'], list(), tuple()]:
        lookup_module = LookupModule()
        assert(type(lookup_module.run(terms)) in [list, tuple])

# Generated at 2022-06-23 12:00:22.791449
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:00:28.362894
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialise class
    lookup = LookupModule()
    # Run method
    result = lookup.run([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], inject={'a': 1, 'b': 2})
    # Check results
    assert result in [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-23 12:00:33.375954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['test1', 'test2', 'test3', 'test4']
    ret = lookup_module.run(terms)
    assert ret == ['test2'] or ret == ['test1'] or ret == ['test3']  or ret == ['test4']

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:00:34.320471
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj != None

# Generated at 2022-06-23 12:00:35.656598
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-23 12:00:38.573285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['a', 'b', 'c']
    ret = lookup_module.run(terms)
    assert(ret in terms)

# Generated at 2022-06-23 12:00:39.633524
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule."""
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:00:40.674443
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    myobj = LookupModule()

    assert myobj is not None

# Generated at 2022-06-23 12:00:45.306973
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run([])
    assert result is None
    result = LookupModule().run(["testa", "testb"])
    assert len(result) == 1
    assert result[0] == "testa" or result[0] == "testb"
    result = LookupModule().run("")
    assert result is None

# Generated at 2022-06-23 12:00:49.263270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    test_terms = [('term_one',), ('term_two',), ('term_three',)]
    assert len(lookup_plugin.run(test_terms)) == 1


# Generated at 2022-06-23 12:00:53.638039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["First","Second","Third"]) == ["First"] or \
        LookupModule().run(["First","Second","Third"]) == ["Second"] or \
        LookupModule().run(["First","Second","Third"]) == ["Third"]

# Generated at 2022-06-23 12:00:57.208686
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    randomChoice = LookupModule()
    test_terms=[1,2]
    result = randomChoice.run(terms=test_terms)
    assert result[0] == test_terms[0] or result[0] == test_terms[1]

# Generated at 2022-06-23 12:00:59.579943
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:01:07.133105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_class = LookupModule()
    terms = [{"client": "client1", "ansible_host": "10.10.10.1", "ansible_port": 22},
             {"client": "client2", "ansible_host": "10.10.10.2", "ansible_port": 22},
             {"client": "client3", "ansible_host": "10.10.10.3", "ansible_port": 22}]
    print("test run with terms=%s" % terms)
    print("res: %s" % test_class.run(terms))

# Generated at 2022-06-23 12:01:07.659237
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:01:19.124190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test if method run returns random element
    # Test if method run returns the entire list if there is an error when trying to choose a random string

    # Test method run on a list of terms with three elements
    terms = ['dog', 'cat', 'snake'] 
    random_element = random.choice(terms)

    lookup_random_element = LookupModule().run(terms, inject=None)

    assert random_element == lookup_random_element[0]

    # Test method run on a list of terms with one element
    terms = ['dog']

    lookup_random_element = LookupModule().run(terms, inject=None)

    assert terms == lookup_random_element

    # Test method run on an empty list of terms
    terms = []

    lookup_random_element = LookupModule().run(terms, inject=None)


# Generated at 2022-06-23 12:01:21.768125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['a', 'b', 'c', 'd']

    for i in range(0, 10):
        choice = lookup_module.run(terms)[0]
        assert choice in terms

# Generated at 2022-06-23 12:01:23.609853
# Unit test for constructor of class LookupModule
def test_LookupModule():
    arguments = [
        "arg1",
        "arg2",
        "arg3"
    ]
    LK = LookupModule(arguments)
    LK.run(LK)
    return

# Generated at 2022-06-23 12:01:25.546729
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 12:01:36.572770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    play_source = dict(
        name='untitled',
        hosts=['localhost'],
        gather_facts=dict(gather_subset=['!all']),
        tasks=[dict(action=dict(module='debug', args=None))]
    )

    play = Play.load(play_source, variable_manager=variable_manager, loader=loader)

    # play._tqm = TaskQueueManager(
    #    inventory=inventory,
    #

# Generated at 2022-06-23 12:01:39.040911
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create instance of class LookupModule with empty arguments
    look = LookupModule()

    # Check that 'run' method exists
    assert hasattr(look, 'run')

# Generated at 2022-06-23 12:01:40.288261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_constructor = LookupModule()
    assert test_constructor

# Generated at 2022-06-23 12:01:44.053231
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    lookup_plugin.terms = ["string1", "string2"]
    assert len(lookup_plugin.run([]) == 0)
    assert isinstance(lookup_plugin.run(lookup_plugin.terms), list)

# Generated at 2022-06-23 12:01:45.317266
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:01:46.126981
# Unit test for constructor of class LookupModule
def test_LookupModule():
    _ = LookupModule()

# Generated at 2022-06-23 12:01:54.263316
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class LookupModule_Impl(LookupModule):
        def __init__(self, random_choice_list, **kwargs):
            self.random_choice_list = random_choice_list
            self.random = random

        def random_choice(self, random_choice_list):
            return random.choice(random_choice_list)

    module = LookupModule_Impl(['foo', 'bar'])
    assert module.run(['foo', 'bar']) == ['bar']

# Generated at 2022-06-23 12:01:56.706657
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test constructor
    lookup_modul = LookupModule()
    assert type(lookup_modul) == LookupModule


# Generated at 2022-06-23 12:01:59.968674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    termsList = [ 'ansible', 'puppet', 'chef', 'salt' ]
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(termsList)
    assert result != []

# Generated at 2022-06-23 12:02:03.201263
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    assert test_object.run(terms = ["one", "two", "three"]) != []
    assert test_object.run(terms = ["one", "two", "three"]) != "one" or "two" or "three" or "four"

# Generated at 2022-06-23 12:02:06.261983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["foo", "bar"]) == ["bar"]

# Generated at 2022-06-23 12:02:12.513434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    # Case 1: No random item from list
    result = lookup_plugin.run(terms=None, inject=None, **kwargs)
    assert not result

    # Case 2: Random item from list
    terms = ["test1", "test2", "test3"]
    result = lookup_plugin.run(terms=terms, inject=None, **kwargs)
    assert len(result) == 1

# Generated at 2022-06-23 12:02:15.100669
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["term1", "term2", "term3"]
    assert len(LookupModule(None, None).run(terms)) == 1

# Generated at 2022-06-23 12:02:22.390097
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_ret = lookup_module.run(["test1", "test2", "test3"], inject=None, terms=["test1", "test2", "test3"])
    assert isinstance(lookup_ret, list)
    assert lookup_ret[0] != "test2"  # Always the case because random generation
    assert lookup_ret[0] != "test3"  # Always the case because random generation
    assert lookup_ret[0] != "test1"  # Always the case because random generation

# Generated at 2022-06-23 12:02:27.801324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with empty terms
    p = LookupModule()
    assert p.run([]) == []

    # Test with a single item
    p = LookupModule()
    assert p.run(['a']) == ['a']

    # Test with multiple items (as it's random we can not assert the result)
    p = LookupModule()
    assert p.run(['a', 'b', 'c']) != []

    # Test with invalid type
    p = LookupModule()
    try:
        p.run(None)
    except AnsibleError:
        pass
    else:
        raise Exception("Expected failure not detected.  Invalid input to lookup module not detected.")

# Generated at 2022-06-23 12:02:34.312572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options({})
    lookup_module.run = types.MethodType(run_replace, lookup_module)

    # Verify all codes
    lookup_module.run(['a', 'b', 'c'])

    # Verify one of codes
    lookup_module.run(['a'])

    # Verify empty
    lookup_module.run([])


# Generated at 2022-06-23 12:02:36.804928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  looker = LookupModule()
  assert(looker.run(["a", "b"]) in ["a", "b"])

# Generated at 2022-06-23 12:02:44.322081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import __builtin__ as builtins
    import mock
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    mock_find_plugin = mock.Mock()
    mock_term = mock.Mock()

    test_value = 'test'

    with mock.patch.object(builtins, 'setattr'):
        lookup_plugin = LookupModule()

    with mock.patch.object(random, 'choice') as mock_choice:
        mock_choice.return_value = test_value
        assert lookup_plugin.run(mock_term, loader, mock_find_plugin) == test_value
        mock_choice.assert_call_once_with(mock_term)


# Generated at 2022-06-23 12:02:49.924295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert LookupModule().run(terms) == [random.choice(terms)]
    assert LookupModule().run(terms, inject={}) == [random.choice(terms)]
    assert LookupModule().run(terms, inject={}, **{}) == [random.choice(terms)]

# Generated at 2022-06-23 12:02:52.027236
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    ansible_module = AnsibleModule()

    assert lookup_module != None
    assert ansible_module != None

# Generated at 2022-06-23 12:02:53.234350
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None)

# Generated at 2022-06-23 12:02:57.977365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    # create object for class LookupModule
    list_terms = ["a", "b", "c", "d"]
    # assign some value to list_terms
    result = m.run(list_terms, inject=None, **None)
    # check if run method returns correct result
    assert any(result) == True

# Generated at 2022-06-23 12:02:58.943145
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:03:00.658699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = LookupModule()
    assert f.run(terms=[]) == []


# Generated at 2022-06-23 12:03:02.747465
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['test']
    lookup_module = LookupModule()
    assert lookup_module.run(terms, inject = None) is not None

# Generated at 2022-06-23 12:03:03.208803
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:03:05.945079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_list = ['test1','test2','test3']
    lookup_module_class = LookupModule()
    result1 = lookup_module_class.run(terms_list)
    result2 = lookup_module_class.run(terms_list)
    assert result1 != result2

# Generated at 2022-06-23 12:03:10.898030
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Positive test case
    list_of_strings = ['foo','bar','baz','boo','buzz']
    result = lookup.run(terms=list_of_strings, inject=None)
    assert result in list_of_strings
    # Negative test case
    result = lookup.run([])
    assert result == []

# Generated at 2022-06-23 12:03:22.083675
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule().run
    assert lookup_module([1]) == [1]
    assert lookup_module([1, 2]) == [1]
    assert lookup_module([1, 2, 3]) == [1]
    assert lookup_module([1, 2, 3, 4]) == [1]
    assert lookup_module([1, 2, 3, 4, 5]) == [1]
    assert lookup_module([1, 2, 3, 4, 5, 6]) == [1]
    assert lookup_module([1, 2, 3, 4, 5, 6, 7]) == [1]
    assert lookup_module([1, 2, 3, 4, 5, 6, 7, 8]) == [1]
    assert lookup_module([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1]

# Generated at 2022-06-23 12:03:23.145307
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(hasattr(LookupModule(), 'run'))

# Generated at 2022-06-23 12:03:25.068907
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = random.choice("test")
    assert module is not None, "Unable to create an instance of LookupModule"

# Generated at 2022-06-23 12:03:32.398014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    # ansible-test units -vv --python tests/units/plugins/lookup/random_choice_test.py
    assert lookup_obj.run(['spam', 'ham', 'eggs']) == ['spam']
    assert lookup_obj.run(None) == None
    assert lookup_obj.run([]) == []
    #assert lookup_obj.run(['spam', 'ham']) == ['ham']
    assert lookup_obj.run(['spam', 'ham', 'eggs']) == ['eggs']

# Generated at 2022-06-23 12:03:35.992691
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    terms = ["ansible", "terraform", "chef", "puppet", "saltstack"]
    print(lu.run(terms))
    terms = []
    print(lu.run(terms))

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:03:36.948427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:03:41.931708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup = LookupModule()
    out_list = my_lookup.run(["I", "am", "a", "test"])
    assert out_list == ["I"] or out_list == ["am"] or out_list == ["a"] or out_list == ["test"]
    return

# Generated at 2022-06-23 12:03:42.898292
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:03:45.714766
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module.run([])
    assert "Unable to choose random term: sequence index must be integer, not 'NoneType'" in str(excinfo.value)

# Generated at 2022-06-23 12:03:50.708208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule(Loader, None, None).run([1,2,3]) == [3]
    assert LookupModule(Loader, None, None).run([1,2,3]) == [2]
    assert LookupModule(Loader, None, None).run([1,2,3]) == [2]

# Generated at 2022-06-23 12:03:53.480698
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert 'msg: "go through the door"' in lu.run(['go through the door', 'drink from the goblet', 'press the red button', 'do nothing'])

# Generated at 2022-06-23 12:03:57.394310
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test constructor with an invalid options
    lookup = LookupModule()
    assert lookup is not None
    terms = ["1", "2", "3"]
    ret = lookup.run(terms)
    assert len(ret) == 1

# Generated at 2022-06-23 12:03:58.771201
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random_choice = LookupModule()
    assert random_choice

# Generated at 2022-06-23 12:04:06.045365
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Mock arguments for LookupModule
    my_list = ['a', 'b', 'c', 'd']
    mock_terms = my_list

    # Run an instance of LookupModule, from plugins/lookup/random_choice.py
    lookup_plugin = LookupModule()

    # Run method run of class LookupModule
    test_result = lookup_plugin.run(mock_terms)

    # Test if the returned result is in my_list
    assert test_result[0] in my_list

# Generated at 2022-06-23 12:04:06.655152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:04:09.472871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["term1", "term2","term3"]
    t1 = LookupModule()
    assert len(t1.run(terms, None)) == 1


# Generated at 2022-06-23 12:04:11.815969
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert (LookupModule().run([[1,2,3]])
            == [random.choice([1,2,3])])

# Generated at 2022-06-23 12:04:16.463537
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    # Create a LookupModule object
    lm = LookupModule()

    # Create a list of terms to test
    terms = ["alpha", "beta", "gamma", "theta", "omega"]
    # Call object to get random element in list
    result = lm.run(terms)
    assert(result[0] in terms)

# Generated at 2022-06-23 12:04:18.254989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(['a','b','c','d'])

# Generated at 2022-06-23 12:04:20.786087
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert str(LookupModule()) == "<ansible.plugins.lookup.random_choice.LookupModule object at 0x7f1e0c98f0b8>"

# Generated at 2022-06-23 12:04:27.034696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_instance = LookupModule()
    results = test_instance.run([42, 27])
    assert(len(results) == 1 and (27 in results or 42 in results))
    results = test_instance.run(["foo", "bar"])
    assert(len(results) == 1 and ("foo" in results or "bar" in results))
    results = test_instance.run([])
    assert(len(results) == 0)

# Generated at 2022-06-23 12:04:30.243219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(["a", "b", "c"])
    assert result == ["a"] or result == ["b"] or result == ["c"]

# Generated at 2022-06-23 12:04:32.702112
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [1, 2, 3, 4]
    lookup_plugin = LookupModule()
    value = lookup_plugin.run(terms)[0]
    assert value in terms

# Generated at 2022-06-23 12:04:37.137656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    block1 = [1,2,3]
    block2 = [0]
    block3 = []

    lkm = LookupModule()
    assert lkm.run(block1) == [random.choice(block1)]
    assert lkm.run(block2) == block2
    assert lkm.run(block3) == block3

# Generated at 2022-06-23 12:04:41.589122
# Unit test for constructor of class LookupModule
def test_LookupModule():
 
    terms = ['A','BB','CCC','DDDD','EEEEE']
    random_result = random.choice(terms)

    # The constructor of class LookupModule is implicitly called when
    # an instance of the class is created.
    lookup = LookupModule()

    # Unit test for run() method
    result = lookup.run(terms)
    assert result[0] == random_result

# Generated at 2022-06-23 12:04:43.877756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=["one", "two"]) == ["one"]

# Generated at 2022-06-23 12:04:44.909178
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:04:52.034369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Method 'run' of class 'LookupModule' should return random element from list")
    # Parameter 'terms'
    a_lookupModule = LookupModule()
    terms = [1, 2, 3]
    print("Test method 'run' of class 'LookupModule': Should return")
    print(terms)
    print("...but returns")
    print(a_lookupModule.run(terms))

# Generated at 2022-06-23 12:04:52.635318
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:04:59.717362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost',])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 12:05:04.372916
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list1 = ["abc", "cde", "efg"]

    assert len(list1) == 3
    assert test_LookupModule.run(list1)
    assert isinstance(test_LookupModule.run(list1), list)
    assert len(test_LookupModule.run(list1)) == 1

# Generated at 2022-06-23 12:05:05.734661
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:05:14.198465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test when terms are given
    lookup_obj = LookupModule()
    terms = ['a', 'b', 'c', 'd']
    ret = lookup_obj.run(terms)
    assert ret in terms
    # Test when empty terms
    lookup_obj = LookupModule()
    terms = []
    ret = lookup_obj.run(terms)
    assert ret == []
    # Test when wrong type
    lookup_obj = LookupModule()
    terms = 'a'
    ret = lookup_obj.run(terms)
    assert ret == 'a'

# Generated at 2022-06-23 12:05:17.613963
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with no term
    lookup_module = LookupModule()
    print(lookup_module)

    # Test with term
    lookup_module = LookupModule()
    print(lookup_module)

# Generated at 2022-06-23 12:05:19.365260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l


# Generated at 2022-06-23 12:05:25.037370
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    # test the case of terms is not null
    terms = ["1", "2", "3"]
    # the number of test case
    n = 10
    for i in range(n):
        ret = lookup.run(terms)
        assert ret[0] in terms

    # test the case of terms is null
    terms = None
    ret = lookup.run(terms)
    assert ret == None

# Generated at 2022-06-23 12:05:26.343858
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_object = LookupModule()
    assert test_object is not None

# Generated at 2022-06-23 12:05:30.598437
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = [["a", "b", "c"], [1, 2, 3]]
    ret = lookup_plugin.run(terms)
    return ret


if __name__ == '__main__':
    print(test_LookupModule())

# Generated at 2022-06-23 12:05:35.417695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_basedir = lambda self, terms: ''
    terms = ['test1','test2','test3','test4']
    random_values = l.run(terms)
    assert random_values[0] in terms


# Generated at 2022-06-23 12:05:35.897147
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:05:38.546678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = [1, 2, 3, 4, 5]
    term = terms.pop(random.randrange(len(terms)))
    lookup_module = LookupModule()
    
    # Act
    random_term = lookup_module.run(terms)
    assert(term == random_term[0])

# Generated at 2022-06-23 12:05:42.446603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1, 2, 3, 4, 5]
    assert(LookupModule(basedir=None, runner=None, inventory=None).run(terms=terms) is not None)


# Generated at 2022-06-23 12:05:47.869097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lk = LookupModule()
    res = lk.run(terms = ['1','2','3','4','5','6','7','8','9','10'], inject = None, **{})
    assert len(res) == 1
    assert int(res[0]) in range(1,11)

# Generated at 2022-06-23 12:05:49.020945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print(random.choice([1,2,3,4,5,6]))

# Generated at 2022-06-23 12:05:50.433770
# Unit test for constructor of class LookupModule
def test_LookupModule():
   module = LookupModule()


# Generated at 2022-06-23 12:05:54.628574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Random choice should return an item from the list with given items

    """
    lookup = LookupModule()
    assert lookup.run(['item1', 'item2', 'item3']) == ['item2']

# Generated at 2022-06-23 12:05:57.206638
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        # Test if the constructor of class LookupModule is working without arguments
        LookupModule()
    except TypeError:
        assert False

# Generated at 2022-06-23 12:06:08.311786
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of class LookupModule
    lookup_module = LookupModule()

    # Test the method run with a list of terms
    # Expected result: a string containing one of the terms, selected at random
    terms = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    result = lookup_module.run(terms)
    assert result != "" and result != None, "Error when testing run: the result must not be an empty string or None"
    assert isinstance(result, list), "Error when testing run: the result must be a list"
    assert len(result) == 1, "Error when testing run: the result must be a list with 1 element"
    assert result[0] in terms, "Error when testing run: the result must be a list with an element from one of the terms"

# Generated at 2022-06-23 12:06:13.618616
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    data = [1,2,3,4]
    # test for terms
    terms = data
    ret = lookup.run(terms)
    assert ret != data
    # test for no terms
    terms = []
    ret = lookup.run(terms)
    assert ret == data

# Generated at 2022-06-23 12:06:17.442886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize objects
    lookup_module_obj = LookupModule()
    terms = ['Red', 'Green', 'Yellow']
    # Execute the method run and return results
    results = lookup_module_obj.run(terms)
    # Verify results
    assert('Red' == results[0] or 'Green' == results[0] or 'Yellow' == results[0])

# Generated at 2022-06-23 12:06:20.028969
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["1","2","3"]
    lookup = LookupModule()
    result = lookup.run(terms)
    assert result == [result[0]]

# Generated at 2022-06-23 12:06:27.541219
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()
    ret = lookup.run(["one", "two", "three", "four", "five"])
    assert ret != None, "Failed to return a result with all terms"

    ret = lookup.run(["one"])
    assert ret != None, "Failed to return the term with only one term"

    ret = lookup.run([])
    assert ret == [], "Failed to return empty list with empty term"

    ret = lookup.run(None)
    assert ret == None, "Failed to return None with None term"

# Generated at 2022-06-23 12:06:32.562995
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:06:36.515986
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [1,2,3]
    expected = [1,2,3]
    module = LookupModule()

    # Return random elements from the list
    for i in range(0,10):
        random_element = module.run(terms)
        assert random_element in expected

    # Return error
    terms = "only one element allowed"

    try:
        module.run(terms)
    except AnsibleError:
        pass

# Generated at 2022-06-23 12:06:38.512745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = [1, 2, 3]
    assert(len(LookupModule().run(ret)) == 1)

# Generated at 2022-06-23 12:06:47.799118
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    args = {}
    terms = [
        "first",
        "second",
        "third"
    ]
    test_value = False

    # Test if run method returns a value
    lookup_plugin = LookupModule()
    test_value = lookup_plugin.run(terms)
    assert test_value

    # Test if run method returns proper value given terms and args
    terms_len = len(terms)
    lookup_plugin = LookupModule()
    test_value = lookup_plugin.run(terms)
    assert len(test_value) == 1
    assert test_value[0] in terms

    # Test if run method returns proper value given args
    terms = []
    lookup_plugin = LookupModule()
    test_value = lookup_plugin.run(terms)
    assert test_value == terms

# Generated at 2022-06-23 12:06:54.372871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    assert [u'A'] == lookup_module.run([u'A', u'B'])
    assert [u'A'] == lookup_module.run([u'A', u'B', u'C'])
    assert [u'A'] == lookup_module.run([u'A', u'B', u'C', u'D'])

# Generated at 2022-06-23 12:06:56.011324
# Unit test for constructor of class LookupModule
def test_LookupModule():
	module = LookupModule()

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:06:57.619075
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l.run(['foo', 'bar']) == ['bar']

# Generated at 2022-06-23 12:06:58.770328
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module



# Generated at 2022-06-23 12:07:01.684656
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    t = ['a', 'b', 'c']
    L.run(t)
    # test to get random element from the list
    assert L.run(t) in t

# Generated at 2022-06-23 12:07:11.420310
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    results = [
        {'_raw': 'drink from the goblet'},
        {'_raw': 'press the red button'},
        {'_raw': 'go through the door'},
        {'_raw': 'do nothing'}
    ]

    # Shortcut to class attributes
    LookupModule_run = LookupModule.run

    # Call of LookupModule.run
    terms = [
        "go through the door",
        "drink from the goblet",
        "press the red button",
        "do nothing"
    ]
    ret = LookupModule_run(LookupModule(), terms)

    # Check a random mix of items in results
    assert ret in results

    # Execute LookupModule.run 3 times and check if
    # each time a item of 'ret' is correct
   

# Generated at 2022-06-23 12:07:17.920874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_config = {"terms": ["go through the door", "drink from the goblet", "press the red button", "do nothing"]}
    response = LookupModule().run(**test_config)
    assert len(response) == 1, "Length of response is not equal to 1"
    assert response[0] in test_config["terms"], "Response [0] is not in the given test_config"

# Generated at 2022-06-23 12:07:21.225006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(['foo', 'bar'])
    assert len(ret) == 1 and (ret[0] == 'foo' or ret[0] == 'bar')

# Generated at 2022-06-23 12:07:22.494453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = [ "go through the door", "drink from the goblet", "press the red button", "do nothing" ]
    assert( LookupModule.run(result) in result )

# Generated at 2022-06-23 12:07:23.405181
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:07:25.245521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    assert len(lookupModule.run(['foo', 'bar'])) == 1



# Generated at 2022-06-23 12:07:27.491614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [1,2,3,4]
    expected_result = [1,2,3,4]
    assert lookup_module.run(terms) == expected_result

# Generated at 2022-06-23 12:07:36.125477
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(terms=["A","B","C"])
    l.run(terms=["A"])
    l.run(terms=["A","B","C"],delimiter="/",key="my variables.",default="d",internal=True,separator="!")
    l.run(terms=[])
    l.run(terms=["A","B","C"],inject=True)
    l.run(terms=["A","B","C"],inject=False)

# Generated at 2022-06-23 12:07:40.305063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()

    list_terms = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    assert lu.run(terms=list_terms) in list_terms

    assert lu.run(terms="") == ""

# Generated at 2022-06-23 12:07:41.661260
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:07:42.437739
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:07:48.764099
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # to_native function returns the same exception message passed to it
    # so to check if the exception message is passed to to_native
    # we will check if the return value of to_native
    # is same as the exception message
    # Assigning Exception message to a variable
    ex_msg = "error"
    # Exception object is created with message containing the value of ex_msg
    # then ex_msg is passed to run function
    # we expect an exception to be raised and the message of exception
    # should be same as the value of ex_msg
    try:
        raise Exception(ex_msg)
    except Exception as e:
        assert e.args[0] == ex_msg

# Generated at 2022-06-23 12:07:50.340714
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(
        LookupModule() 
    )

# Generated at 2022-06-23 12:07:56.001502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Returns a random choice from a list."""
    lookup_plugin = LookupModule()
    lookup_plugin._templar = Dict()
    results = lookup_plugin.run(["a", "b", "c"], [])
    assert len(results) == 1
    assert results[0] in ["a", "b", "c"]


# Return a random choice from a list.


# Generated at 2022-06-23 12:07:57.717964
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run('', {})

# Generated at 2022-06-23 12:08:02.940762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    terms = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    ret = lookup_instance.run(terms)
    assert isinstance(ret, list)
    assert len(ret) == 1
    assert len(set(ret) & set(terms)) == 1

# Generated at 2022-06-23 12:08:14.424813
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 12:08:15.799917
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 12:08:17.109539
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test.run(None, None)

# Generated at 2022-06-23 12:08:18.587936
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result



# Generated at 2022-06-23 12:08:19.747280
# Unit test for constructor of class LookupModule
def test_LookupModule():
    item = LookupModule()
    print(item)

# Generated at 2022-06-23 12:08:23.259743
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [1,2,3]
    assert len(terms)>1
    lookup = LookupModule()
    result = lookup.run(terms)
    assert len(result)>0

# Generated at 2022-06-23 12:08:26.616537
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_terms = [1, 2, 3]
    lookup_module = LookupModule()
    assert lookup_module.run(test_terms) == test_terms

# Generated at 2022-06-23 12:08:27.613652
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test

# Generated at 2022-06-23 12:08:34.129903
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    random_choice = lookup_plugin.run([
        {'foo': 'bar'},
        {'baz': 'qux'},
        {'moo': 'cow'},
        {'milk': 'truck'}
    ], inject={})

    assert isinstance(random_choice, list)
    assert len(random_choice) == 1
    assert isinstance(random_choice[0], dict)

# Generated at 2022-06-23 12:08:37.711661
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule().run(['1', '2', '3'])
    assert result != '1' or result != '2' or result != '3'

# Generated at 2022-06-23 12:08:46.890615
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    result = l.run([1,2,3,4])
    if not result:
        raise AssertionError("LookupModule_run() result is None")
    if len(result) != 1:
        raise AssertionError("LookupModule_run() expected result length is 1")
    if result[0] not in [1,2,3,4]:
        raise AssertionError("LookupModule_run() returned incorrect value")
    result2 = l.run(None)
    if not result2:
        raise AssertionError("LookupModule_run() result with None is None")
    if len(result2) != 0:
        raise AssertionError("LookupModule_run() expected result length with None is 0")

if __name__ == '__main__':
    test

# Generated at 2022-06-23 12:08:50.198695
# Unit test for constructor of class LookupModule
def test_LookupModule():
    init_val = ['a', 'b']
    lookup_module_obj = LookupModule(init_val)
    assert lookup_module_obj.get_random() in init_val

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:08:51.831085
# Unit test for constructor of class LookupModule
def test_LookupModule():
	lookup_plugin = LookupModule()
	assert lookup_plugin

# Generated at 2022-06-23 12:08:55.809043
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_instance = LookupModule()
    terms = ['first', 'second', 'third']
    inject = None
    random_term = LookupModule_instance.run(terms, inject)
    assert random_term in terms

# Generated at 2022-06-23 12:08:57.056088
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tested by unit test
    pass

# Generated at 2022-06-23 12:08:57.885926
# Unit test for constructor of class LookupModule
def test_LookupModule():
    current_instance = LookupModule()
    assert current_instance

# Generated at 2022-06-23 12:09:00.856143
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # args[0] is a list with one argument, a string
    terms = ["one", "two", "three"]
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert result >= ["one", "two", "three"]
    assert result <= ["one", "two", "three"]

# Generated at 2022-06-23 12:09:06.769758
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # test constructor
    lookup = LookupModule()
    assert lookup.run([1, 5, 10]) == [1, 5, 10]
    assert lookup.run(["one"]) == ["one"]
    assert lookup.run(["one", "two", "three"]) in [["one"], ["two"], ["three"]]

# Generated at 2022-06-23 12:09:09.889427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for the 'random_choice' lookup module."""
    random_choice_lookup_plugin = LookupModule()
    assert random_choice_lookup_plugin is not None

# Generated at 2022-06-23 12:09:10.859604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:09:12.664535
# Unit test for constructor of class LookupModule
def test_LookupModule():
    empty_terms = None
    module = LookupModule()

    assert module.run(empty_terms) == empty_terms

# Generated at 2022-06-23 12:09:14.462744
# Unit test for constructor of class LookupModule
def test_LookupModule():
  temp_lookup = LookupModule()
  assert type(temp_lookup) is LookupModule

# Generated at 2022-06-23 12:09:15.612829
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule


# Generated at 2022-06-23 12:09:26.098945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(LookupModule().run(terms=['a', 'b', 'c'])[0] in ['a', 'b', 'c'])
    assert(LookupModule().run(terms=[1, 2, 3])[0] in [1, 2, 3])
    assert(LookupModule().run(terms=[]) == [])
    assert(LookupModule().run(terms=['a', 'b', 'c'])[0] in ['a', 'b', 'c'])
    assert(LookupModule().run(terms=[]) == [])
    #assert(LookupModule().run(['a', 'b', 'c'])[0] in ['a', 'b', 'c'])
    #assert(LookupModule().run([1, 2, 3])[0] in [1, 2, 3])
    #assert

# Generated at 2022-06-23 12:09:30.241958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    _inject = {
        'random': random
    }
    _terms = [
        '1', '2', '3'
    ]
    _module = LookupModule()
    _value = _module.run(_terms, _inject)
    assert type(_value) == list
    assert _value[0] in _terms

# Generated at 2022-06-23 12:09:31.552401
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-23 12:09:40.922227
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    t = LookupModule()

    # test random choice if there is only 1 item in list
    v = ["one"]
    w = t.run(terms=v)
    assert w == v

    # test random choice if there is 2 items in list
    v = ["one", "two"]
    w = t.run(terms=v)
    assert w != v

    v = ["one", "two", "three"]
    w = t.run(terms=v)
    assert w != v

    # test random choice if there is nothing in a list
    v = []
    w = t.run(terms=v)
    assert w == v

# Generated at 2022-06-23 12:09:43.268780
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lm = LookupModule()
  assert(lm.run(['a', 'b', 'c']))


# Generated at 2022-06-23 12:09:54.224190
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    lu = LookupModule()

    # valid, list
    assert lu.run(['item 1', 'item 2', 'item 3']) == ['item 2']

    # valid, string
    assert lu.run('string') == ['string']

    # valid, string with comma
    assert lu.run('string, string') == ['string']

    # invalid, list
    assert lu.run(['invalid string', 2, {}]) == ['invalid string']

    # invalid, string
    assert lu.run(['invalid string, 2, {}']) == ['invalid string, 2, {}']

    # invalid, no argument
    assert lu.run() == []