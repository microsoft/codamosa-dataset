

# Generated at 2022-06-23 11:59:50.559061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(42)  # Set seed so that behaviour is consistent with expected value
    test_args = ["host-1", "host-2"]
    test_kwargs = {}
    lookup_obj = LookupModule()
    result = lookup_obj.run(test_args, test_kwargs)
    assert len(result) == 1
    assert result[0] == "host-2"

# Generated at 2022-06-23 11:59:52.377760
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test with no argument
    LookupModule()


# Generated at 2022-06-23 11:59:54.907958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [ "foo", "bar", "baz" ]
    assert lookup_module.run(terms) == terms

# Generated at 2022-06-23 11:59:56.289010
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 11:59:58.315375
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:00:04.198796
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor test
    lookup_plugin = LookupModule()

    # return random value
    assert lookup_plugin.run(['a','b','c','d','e']) in ['a','b','c','d','e']
    assert lookup_plugin.run(['a','b','c','d','e']) in ['a','b','c','d','e']
    assert lookup_plugin.run(['a','b','c','d','e']) in ['a','b','c','d','e']

    test_list = ['A','B','C','D']
    assert lookup_plugin.run(test_list) in test_list

# Generated at 2022-06-23 12:00:05.667883
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # instance of class LookupModule
    lm1 = LookupModule()

    # check default value of ret
    assert lm1.ret is None

    # check default value of terms
    assert lm1.terms is None

# Generated at 2022-06-23 12:00:06.598129
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:00:15.337727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dummy_terms = ['test1', 'test2', 'test3']
    dummy_ret = dummy_terms
    lookup_ret = None
    lookup = LookupModule(loader=None, templar=None, **{'_INJECT': {'lookup_plugin_count': [0]}})
    if lookup:
        try:
            lookup_ret = lookup.run(terms=dummy_terms, inject={})
            if dummy_ret:
                assert dummy_ret == lookup_ret
        except Exception as e:
            raise Exception("Error: {}".format(e))
        finally:
            if lookup_ret:
                for i in lookup_ret:
                    if i in dummy_ret:
                        print("Test case [{}] - pass".format(i))

# Generated at 2022-06-23 12:00:16.538311
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert a


# Generated at 2022-06-23 12:00:18.966252
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
        assert True
    except:
        assert False


# Generated at 2022-06-23 12:00:23.678645
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test a random choice is made among terms
    terms = ["a", "b", "c"]
    result = LookupModule().run(terms, None)
    assert result in terms

    # Test that empty list is returned
    terms = []
    result = LookupModule().run(terms, None)
    assert result == []

# Generated at 2022-06-23 12:00:30.624119
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(1)
    # Test when list is given
    terms = ["first", "second", "third"]
    result = LookupModule.run(LookupModule(), terms)
    assert result == ["third"]
    result = LookupModule.run(LookupModule(), terms)
    assert result == ["third"]
    result = LookupModule.run(LookupModule(), terms)
    assert result == ["second"]
    # Test when empty list is given
    terms = []
    result = LookupModule.run(LookupModule(), terms)
    assert result == []

# Generated at 2022-06-23 12:00:35.158059
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class_instance = LookupModule()
    terms = ["1", "2", "3"]
    injected = {'ansible_facts': {'test': 'test value'}}
    result = class_instance.run(terms, injected, test="test arg")
    assert isinstance(result, list)
    assert len(result) == 1

# Generated at 2022-06-23 12:00:40.475174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_type_instance = LookupModule()
    module_args=dict(terms=[1,2,3,4,5])
    result = lookup_type_instance.run(**module_args)

    assert result[0] in module_args['terms']
    return 0


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:00:44.552291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    # testing without terms
    terms = []
    assert [] == lookup_plugin.run(terms, inject=None, **kwargs)

    # testing with terms
    terms = ['a', 'b']        
    assert lookup_plugin.run(terms, inject=None, **kwargs) in terms

# Generated at 2022-06-23 12:00:46.389679
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_instance = LookupModule()
    assert test_instance

# Generated at 2022-06-23 12:00:53.099846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_LookupModule_run.__self__.maxDiff = None
    lookup_module = LookupModule()
    # test with no arguments
    assert lookup_module.run([]) == []
    # test with one arguments
    assert lookup_module.run(["a"]) == ["a"]
    # test with multiple arguments
    assert lookup_module.run(["a", "b", "c", "d"]) in ["a", "b", "c", "d"]

# Generated at 2022-06-23 12:00:57.568219
# Unit test for constructor of class LookupModule
def test_LookupModule():
    
    terms = ['a', 'b', 'c']
    assert(len(terms) == 3)
    ret = LookupModule('random_choice', terms, None, [], {}).run(terms)
    assert(len(ret) == 1)
    assert(set(ret).issubset(terms))

# Generated at 2022-06-23 12:01:02.967756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('TESTING')
    lookup_instance = LookupModule()
    results = lookup_instance.run(terms=['a','b','c'])
    print(results)

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-23 12:01:04.494281
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return lookup_module

# Generated at 2022-06-23 12:01:05.446552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  #TODO: implement this
  return True

# Generated at 2022-06-23 12:01:07.231217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["foo", "bar", "baz"]
    assert lookup.run(terms) == terms

# Generated at 2022-06-23 12:01:08.081718
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:01:12.036919
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule(None)
    try:
        assert isinstance(lookup_class, LookupModule)
    except AssertionError:
        raise AssertionError()

# Generated at 2022-06-23 12:01:13.483101
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert(lookup_module != None)

# Generated at 2022-06-23 12:01:17.477340
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']

    ret = lookup_module.run(terms)

    assert ret[0] in terms

# Generated at 2022-06-23 12:01:23.476357
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case where terms is a list
    terms = ["Term1", "Term2", "Term3"]
    ret = LookupModule().run(terms)
    assert len(ret) == 1
    assert ret[0] in terms

    # Test case where terms is a string
    terms = "Terms"
    ret = LookupModule().run(terms)
    assert len(ret) == 1
    assert ret[0] == terms

# Generated at 2022-06-23 12:01:25.505610
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule,'run')

# Generated at 2022-06-23 12:01:29.752794
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(None)
    assert True

if __name__ == '__main__':
    l = LookupModule()
    l.run(None)
    print('Unit test complete')

# Generated at 2022-06-23 12:01:34.313086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test with valid input, a list of strings
    test_input = ['foo', 'bar', 'baz']
    test_obj = LookupModule()
    result = test_obj.run(terms=test_input)
    assert isinstance(result, list) and result in test_input

    # test with invalid input, a string
    

# Generated at 2022-06-23 12:01:35.124071
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:01:37.176357
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Test constructor to class LookupModule """
    lk = LookupModule()
    assert isinstance(lk, LookupModule)

# Generated at 2022-06-23 12:01:45.725749
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.inventory import Host, Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = Inventory(
            loader=loader,
            variable_manager=VariableManager(),
            host_list=['localhost']
     )
    inventory.add_group('test_group')
    inventory.add_host(Host(name='localhost', groups=['test_group']))
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 12:01:52.470355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a new instance of 'LookupModule' which is a child class of LookupBase
    lookup_module = LookupModule()

    # Create and return a 'terms' array to use with the run method
    terms = ['abc', 'def', 'ghi']

    # Return the random choice and store it
    random_choice = lookup_module.run(terms)[0]

    # Check if the random choice is in the terms array
    assert random_choice in terms

# Generated at 2022-06-23 12:02:03.315009
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    #Assert that a random item from list will be returned
    lookup = LookupModule()
    expected_result = [0]
    assert expected_result == lookup.run([0,1,2,3])

    #Assert that a random item from list will be returned
    lookup = LookupModule()
    expected_result = ["Daniel"]
    assert expected_result == lookup.run(["Daniel", "Lydia", "David", "Jojo"])

    #Assert that a random item from list will be returned
    lookup = LookupModule()
    expected_result = [12]
    assert expected_result == lookup.run([12, 14, 16, 18, 20])

    #Assert that a random item from list will be returned
    lookup = LookupModule()
    expected_result = [0]
    assert expected_result == lookup.run

# Generated at 2022-06-23 12:02:11.017300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    arguments = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
    ret = l.run(arguments)
    assert len(ret) == 1

# Generated at 2022-06-23 12:02:18.943236
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a test object
    o = LookupModule()
    # test a list with one element
    assert o.run([1]) == [1]
    # test with empty list
    assert o.run([]) == []
    # test a list with two elements
    assert o.run([1,2]) in [[1],[2]]
    # test a list with more than two elements
    assert o.run([1,2,3,4,5]) in [[1],[2],[3],[4],[5]]

# Generated at 2022-06-23 12:02:21.084579
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Execute the constructor of class LookupModule
    lookup_module = LookupModule()

    # Assert equality
    assert lookup_module == lookup_module

# Generated at 2022-06-23 12:02:23.588641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run([], None) == []
    assert module.run(None, None) == []

# Generated at 2022-06-23 12:02:24.998663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert len(LookupModule().run(['a','b','c','d']))==1

# Generated at 2022-06-23 12:02:30.691737
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()

    # test random choice
    assert l.run(terms=['apache', 'nginx']) in (['apache'], ['nginx'])
    # test empty list
    assert l.run(terms=[]) == []
    # test non-list
    assert l.run(terms="test") == "test"

# Generated at 2022-06-23 12:02:32.108093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()

    res = obj.run(['foo'])
    assert isinstance(res, list)


# Generated at 2022-06-23 12:02:37.427087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    from ansible.plugins import lookup_loader
    lookup_loader._module_cache={}

    lookup = lookup_loader.get('random_choice', 'LookupModule')

    # Act
    actual = lookup.run([1,2,3])

    # Assert
    assert 1 == len(actual)
    assert actual[0] in [1,2,3]

# Generated at 2022-06-23 12:02:38.317927
# Unit test for constructor of class LookupModule
def test_LookupModule():
    s = LookupModule()
    assert s is not None

# Generated at 2022-06-23 12:02:41.187954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["foo", "bar", "baz"]
    lookup_obj = LookupModule()
    result = lookup_obj.run(terms)
    assert result in terms

# Generated at 2022-06-23 12:02:44.350355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    result = module.run(["one", "two", "three"], None)
    assert result == "one" or result == "two" or result == "three"

# Generated at 2022-06-23 12:02:45.384747
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:02:52.669598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class Random:
        def choice(self, seq):
            return seq[0]
    tmp_random = random.random
    random.random = Random()

    lookup = LookupModule()
    # tempfile.mktemp(x) is a function of a class and can
    # not be stubbed so we avoid using it in lookup plugins
    terms = ['foo', 'bar', 'baz']
    result = lookup.run(terms, [], wanted='a', something='b')
    assert result == ['foo']
    random.random = tmp_random

# Generated at 2022-06-23 12:02:56.278450
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LUM = LookupModule()
    terms = ['a', 'b', 'c']
    result = LUM.run(terms)
    assert result == ['c'] or result == ['b'] or result == ['a']


# Generated at 2022-06-23 12:03:00.056658
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(['a', 'b', 'c'])
    assert(ret[0] in ['a', 'b', 'c'])
    ret = lookup_module.run([])
    assert(len(ret) == 0)

# Generated at 2022-06-23 12:03:07.183073
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.six import PY2

    if PY2:
        import __builtin__ as builtins
    else:
        import builtins

    LookupModuleClass = lookup_loader.get('random_choice')
    assert(isinstance(LookupModuleClass, type))

    lookup = LookupModuleClass()

    assert(isinstance(lookup, LookupModule))

    result = lookup.run(['foo', 'bar'])
    assert(isinstance(result, list))
    assert(len(result) == 1)
    assert(result[0] in ['foo', 'bar'])

# Generated at 2022-06-23 12:03:10.621108
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        test_class = LookupModule()
        assert test_class is not None
    except NameError as e:
        assert False, "unable to create LookupModule(): %s" % to_native(e)

# Generated at 2022-06-23 12:03:14.622194
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("\nTestLookupModule\n")
    m = LookupModule()
    assert m.run(terms=None, inject=None, **{}) == []
    assert m.run(terms=[1, 2, 3], inject=None, **{}) == [2]

# Generated at 2022-06-23 12:03:16.373440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:03:17.390768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:03:25.169844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Preferred method to suppy arguments to the run method of the LookupModule class
    # is to us the init method. Not all arguments are supported in the __init__ method.
    # For example, the terms parameter is not supported by the LookupModule __init__ method.
    # Therefore, do the necessary initialization in the init method and supply the rest of the
    # arguments in the run method.
    lookup_plugin = LookupModule()
    assert type(lookup_plugin) == LookupModule
    assert lookup_plugin.run(['Huey', 'Dewey', 'Louie'], []) == ['Huey']

# Generated at 2022-06-23 12:03:28.600453
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Assert that the constructor of class LookupModule
    # is a constructor of class LookupBase
    assert issubclass(LookupModule, LookupBase)
    assert LookupModule is not LookupBase


# Generated at 2022-06-23 12:03:29.202983
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:03:30.901364
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.run(["test1", "test2", "test3"], None)

# Generated at 2022-06-23 12:03:33.062535
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:03:34.223827
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()
    assert l

# Generated at 2022-06-23 12:03:36.213964
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins
    lookup = ansible.plugins.lookup.random_choice.LookupModule()
    assert lookup != None

# Generated at 2022-06-23 12:03:37.974891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["a", "b", "c"]
    lookup = LookupModule()
    result = lookup.run(terms)
    assert result == ["a"] or result == ["b"] or result == ["c"]

# Generated at 2022-06-23 12:03:40.137518
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:03:41.104286
# Unit test for constructor of class LookupModule
def test_LookupModule():
    tmp = LookupModule()
    assert tmp

# Generated at 2022-06-23 12:03:43.501961
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    res = l.run([1,2,3,4,5])
    assert res[0] in [1,2,3,4,5]

# Generated at 2022-06-23 12:03:44.580330
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["foo", "bar"]
    assert Terms in terms
    assert Terms not in None

# Generated at 2022-06-23 12:03:52.516035
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case with empty list
    test_terms = []
    test_ret = []

    lookup = LookupModule()
    result = lookup.run(test_terms, inject=None)

    assert result == test_ret

    # Test case with non empty list
    test_terms = ["test1", "test2", "test3"]
    test_ret = ["test1", "test2", "test3"]

    lookup = LookupModule()
    result = lookup.run(test_terms, inject=None)

    assert result[0] in test_ret

# Generated at 2022-06-23 12:03:55.939616
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random_terms = ['abc', 'def', 'xyz']
    test = LookupModule()
    result = test.run(random_terms,10)
    assert result == test.run(random_terms,10)

# Generated at 2022-06-23 12:04:06.542312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    from ansible.plugins.lookup import LookupModule
    from ansible.module_utils._text import to_native
    from ansible.errors import AnsibleError

    # Initializations
    result = []
    test_terms = []
    lookup_instance = LookupModule()
    inject = {}
    kwargs = {}

    # Test 1: Empty terms
    test_terms = None
    result = lookup_instance.run(terms=test_terms, inject=inject, **kwargs)
    assert result == []

    # Test 2: Single Element
    test_terms = ['element']
    result = lookup_instance.run(terms=test_terms, inject=inject, **kwargs)
    assert result == ['element']

    # Test 3: Single Element - Negative
    test_terms = ['element']
   

# Generated at 2022-06-23 12:04:09.699625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    obj = LookupModule()
    assert obj.run([]) == []
    assert obj.run([1, 2]), [1, 2]
    assert obj.run([1, 2]) != [2, 1]

# Generated at 2022-06-23 12:04:20.024056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(1)     # for test to produce same result.
    terms = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    random_output = LookupModule().run(terms)
    assert random_output == [1]
    terms.remove(1)
    random_output = LookupModule().run(terms)
    assert random_output == [10]
    terms.remove(10)
    random_output = LookupModule().run(terms)
    assert random_output == [5]
    terms.remove(5)
    random_output = LookupModule().run(terms)
    assert random_output == [8]
    terms.remove(8)
    random_output = LookupModule().run(terms)
    assert random_output == [3]

# Generated at 2022-06-23 12:04:25.477083
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Declare test data
    terms = ["one", "two", "three"]
    expected_result = terms
    random.seed(1)

    # Create instance of class LookupModule
    lookup_module = LookupModule()

    # Execute the run() method using the test data
    result = lookup_module.run(terms)
    assert result == expected_result

# Generated at 2022-06-23 12:04:29.772879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Instanciate LookupModule object
    obj = LookupModule()
    # Expected data
    terms = ['A', 'B', 'C', 'D']
    # Returned data
    ret = obj.run(terms)
    # Assert returned data
    assert ret in terms

# Generated at 2022-06-23 12:04:30.958866
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:04:33.209726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['alps', 'himalayas']
    result = LookupModule().run(terms)
    assert result in terms

# Generated at 2022-06-23 12:04:33.651387
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:04:36.047635
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.lookup.random_choice as random_choice
    print("Test LookupModule constructor")
    ret = random_choice.LookupModule()
    assert ret is not None
    print("Passed")


# Generated at 2022-06-23 12:04:38.613252
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # LookupModule(*args, **kwargs)
    # copy of instance LookupModule
    lookup_module = LookupModule()
    # test of isinstance(object, classinfo)
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 12:04:41.255770
# Unit test for constructor of class LookupModule
def test_LookupModule():
    data_input = ["one", "two", "three", "four", "five"]
    data_output = LookupModule().run(terms=data_input)
    assert data_input == data_output

# Generated at 2022-06-23 12:04:43.419719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run([1,2,3,4]) == [LookupModule().run([1,2,3,4])[0]]

# Generated at 2022-06-23 12:04:49.536930
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tests the constructor of class LookupModule
    terms = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p']
    ret = LookupModule()
    assert ret.run(terms) == ['a'] #This is okay, because dict is unordered


# Generated at 2022-06-23 12:04:51.626427
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None


# Generated at 2022-06-23 12:04:52.643436
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert callable(LookupModule)


# Generated at 2022-06-23 12:04:54.543527
# Unit test for constructor of class LookupModule
def test_LookupModule():
  terms = ["hello", "goodbye"]
  lookup = LookupModule()
  assert (lookup.run(terms) in terms)

# Generated at 2022-06-23 12:04:56.874467
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Test LookupModule with empty parms
    assert LookupModule().run(None,None) == None

# Generated at 2022-06-23 12:05:07.746490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    mock_inject = {}
    mock_kwargs = {}
    mock_terms = [1,2]

    # verify required keys in mock_inject
    assert 'vars' in mock_inject
    assert '_uses_shell' in mock_inject
    assert '_uses_delegate_to' in mock_inject
    assert '_raw_params' in mock_inject
    assert '_templar' in mock_inject

    # verify required keys in mock_kwargs
    assert 'wantlist' in mock_kwargs

    # verify_required keys in mock_kwargs['wantlist']
    assert 'wantlist' in mock_kwargs

    # verify run return when mock_terms is not empty

# Generated at 2022-06-23 12:05:09.489713
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run([]) == []
    assert len(lm.run(['foo', 'bar', 'baz'])) == 1


# Generated at 2022-06-23 12:05:12.278703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['foo', 'bar', 'baz']) in ['foo', 'bar', 'baz']

# Generated at 2022-06-23 12:05:18.879945
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test with simple input
    terms = ['one', 'two']
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=terms, inject=None)
    assert result[0] in terms

    # test with empty input
    terms = []
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms=terms, inject=None)
    assert result == []

# Generated at 2022-06-23 12:05:22.611493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    assert lookup_module.run(terms=terms) in terms

# Generated at 2022-06-23 12:05:25.767862
# Unit test for constructor of class LookupModule
def test_LookupModule():

    term_list = ['Term1', 'Term2', 'Term3', 'Term4']
    random_terms = LookupModule().run(terms=term_list)
    assert(len(random_terms) == 1)

# Generated at 2022-06-23 12:05:27.433039
# Unit test for constructor of class LookupModule
def test_LookupModule():
   l = LookupModule()
   assert l != None

# Generated at 2022-06-23 12:05:32.287839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ 'term1', 'term2', 'term3' ]
    lookup_plugin = LookupModule()
    result = lookup_plugin.run(terms, inject={})

    assert result is not None
    assert len(result) == 1
    assert result[0] in terms


# Generated at 2022-06-23 12:05:33.649769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert Callable(LookupModule)

# Generated at 2022-06-23 12:05:34.874929
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule().run([])) == 0

# Generated at 2022-06-23 12:05:37.771720
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms  = ['foo', 'bar', 'baz']
    lookupModule = LookupModule()
    result = lookupModule.run(terms, inject="_raw")
    assert(len(result) == 1)
    assert(result[0] in terms)


# Generated at 2022-06-23 12:05:43.190847
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module.run([1, 2, 3]) == [3]
    assert module.run(['a', 'b', 'c', 'd']) == ['d']
    assert module.run(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']) == ['e']

# Generated at 2022-06-23 12:05:44.306993
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:05:47.610039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(1)
    l = LookupModule()
    assert l.run(terms=["a", "b", "c"]) == ["c"]

# Generated at 2022-06-23 12:05:59.229487
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test basic case
    value = [1, 2, 3]
    result = lookup_module.run(value)
    if result not in value:
        raise Exception("Expected %s to be in %s, got %s" % (result, value, result))

    # Test with empty list
    value = []

# Generated at 2022-06-23 12:06:00.650321
# Unit test for constructor of class LookupModule
def test_LookupModule():
    m = LookupModule()

# Generated at 2022-06-23 12:06:06.386142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_parameter = ["a", "b", "c"]
    # run method of LookupModule class
    result = LookupModule.run(LookupModule(), terms_parameter)
    # result contains only one item from terms_parameter
    assert len(result) == 1
    # result contains a value from terms_parameter
    assert result[0] in terms_parameter


# Generated at 2022-06-23 12:06:10.218506
# Unit test for constructor of class LookupModule
def test_LookupModule():
    options = {'_terms': {'a': 'b'}, '_raw': 'c'}
    lookup = LookupModule()
    terms = lookup.run(terms=['a'], inject=options)
    assert terms[0] == 'a'

# Generated at 2022-06-23 12:06:11.670762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True, "Tests not implemented yet."

# Generated at 2022-06-23 12:06:14.654521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Test LookupModule class, method run
    """
    terms = ['one', 'two', 'three']
    random_term = random.choice(LookupModule().run(terms))
    assert random_term in terms

# Generated at 2022-06-23 12:06:20.382604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.runner = MockRunner()

    # Will call run_command with a list of terms
    terms = [1, 2, 3, 4]
    result = l.run(terms, inject=None, **{})

    # Returned value should be a list
    assert result == terms

# Mock class to catch the random.choice

# Generated at 2022-06-23 12:06:24.966646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    words = ['foo', 'bar', 'baz', 'quux', 'spam', 'ham']
    random.shuffle(words)
    word = words[0]
    lookup = LookupModule()
    result = lookup.run(terms=words, inject={})
    assert result == [word]

# Generated at 2022-06-23 12:06:25.885283
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert not module

# Generated at 2022-06-23 12:06:26.722536
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 12:06:27.322413
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:06:32.072148
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    test_terms = ["a", "b", "c", "d"]
    result = lookup_plugin.run(test_terms, None)
    assert result in test_terms

# Generated at 2022-06-23 12:06:38.094873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    items = ['a','b','c','d']
    lookup_module = LookupModule()

    # Test that method run returns the items list
    assert lookup_module.run(items) == ['a','b','c','d']
    # Test that method run returns a random item from the item list
    for x in range(0, len(items)):
        random_item = lookup_module.run(items)
        assert random_item in items

# Generated at 2022-06-23 12:06:41.810981
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # testing the random choice method
    test_terms = ['a','ab','abc','abcd','abcde','abcdef','abcdefg']

    tmp_term = None

    for i in range(10):
        tmp_term = LookupModule().run(terms=test_terms, inject=None, **{})[0]
        assert tmp_term in test_terms,"random choice value %s not in terms" % tmp_term

# Generated at 2022-06-23 12:06:42.963639
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_x = LookupModule()
    assert lookup_x

# Generated at 2022-06-23 12:06:45.979435
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module=LookupModule()
    terms=["a","b","c"]
    ret=module.run(terms)
    assert(ret[0] in terms)

# Generated at 2022-06-23 12:06:49.717674
# Unit test for constructor of class LookupModule
def test_LookupModule():

	terms = ["1", "2", "3", "4", "5"]
	l = LookupModule()
	ret = l.run(terms)
	assert ret in terms

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:06:50.726361
# Unit test for constructor of class LookupModule
def test_LookupModule():
    instance = LookupModule()

# Generated at 2022-06-23 12:07:00.492242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with empty or invalid data
    lookup_plugin = LookupModule()
    try:
        # Empty list
        result = lookup_plugin.run([])
        if result != []:
            raise Exception("Empty list not returned")
        print("Empty list passed")
        # Invalid list
        result = lookup_plugin.run([1, 2, 3, 4, 5, 6])
        if result != [1, 2, 3, 4, 5, 6]:
            raise Exception("Invalid list not returned")
        print("Invalid list passed")
    except Exception as e:
        print(e)
    
    # Test with valid data

# Generated at 2022-06-23 12:07:02.112702
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    assert L is not None


# Generated at 2022-06-23 12:07:07.859162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1,2,3,4,5]
    try:
        instance = LookupModule()
        assert(len(instance.run(terms))==1)
    except Exception as e:
        raise AnsibleError("Unable to choose random term: %s" % to_native(e))
    print("test_LookupModule_run is passed")

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:07:09.431019
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ Test constructor for LookupModule
    """
    random_gen = LookupModule()
    assert random_gen

# Generated at 2022-06-23 12:07:11.972473
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup = LookupModule()

    terms = ['a', 'b', 'c']
    result = lookup.run(terms, None)
    assert(len(result) == 1 and result[0] in terms )

# Generated at 2022-06-23 12:07:21.640456
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    class DummyModule(object):
        def __init__(self):
            self.params = {}

    lookup_module = LookupModule()
    lookup_module._loader = DummyModule()

    # No exception if args is present in terms
    terms = [1, 2, 3]
    lookup_module.run(terms, [])

    # Exception if args is not present in terms
    terms = None
    try:
        lookup_module.run(terms, [])
    except AnsibleError as e:
        assert str(e) == "Unable to choose random term: sequence item 0: expected str instance, NoneType found"

# Generated at 2022-06-23 12:07:22.272044
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-23 12:07:23.968434
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert type(module) == LookupModule


# Generated at 2022-06-23 12:07:25.344910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tested with pytest
    lm = LookupModule()
    assert lm.run(["lucky", "unlucky"]) in ["lucky", "unlucky"]

# Generated at 2022-06-23 12:07:37.350269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.pycompat24 import _ansible_module_runner
    from ansible.module_utils._ast import literal_eval

    # Test one value is returned if one item is provided
    set_module_args = dict(
        _raw_params='["test"]'
    )
    module = _ansible_module_runner(lookup_plugins=['ansible.plugins.lookup.random_choice'], set_module_args=set_module_args)
    result = module.run()
    result.pop('invocation')
    assert result == dict(
        success=True,
        items=["test"],
        ansible_facts=dict(ansible_random_choice=["test"])
    )

    # Test only period is returned for multiple items

# Generated at 2022-06-23 12:07:38.537052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = [1, 2, 3, 4]
    result = lookup_module.run(terms)
    assert result != None
    assert result[0] in terms

# Generated at 2022-06-23 12:07:41.503794
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lm=LookupModule()
    terms=["a","b","c"]
    ret=my_lm.run(terms)
    assert(ret != terms)

# Generated at 2022-06-23 12:07:49.296779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # create an instance of LookupModule class
    lookup_module = LookupModule()
    
    # assert the class is instance of LookupModule class 
    assert isinstance(lookup_module, LookupModule)    
    
    # create a list of terms
    terms = ["five", "one", "two", "three", "four", "five"]

    # call method run of class LookupModule with the terms list as input
    random_terms = lookup_module.run(terms)

    # assert the method run of class LookupModule is returning a list
    assert isinstance(random_terms, list)

    # assert the method run of class LookupModule is returning a list with single items 
    assert len(random_terms) == 1

    # assert the method run of class LookupModule is returning a item which is actually from the terms list

# Generated at 2022-06-23 12:07:51.404418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    import random
    terms = []
    for i in range(1,random.randint(1,10)):
        terms.append(i)
    assert lookup_module.run(terms) in terms
    assert lookup_module.run(None) == None
    assert lookup_module.run("hello") == "hello"

# Generated at 2022-06-23 12:07:58.409667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test run method with wrong argument type
    lookup_plugin = LookupModule()
    with pytest.raises(AnsibleError) as excinfo:
        lookup_plugin.run(42)
    assert 'Unable to choose random term' in str(excinfo)
    assert 'TypeError' in str(excinfo)

    # Test run method with correct argument type
    result = lookup_plugin.run([2, 3])
    assert type(result) is list
    assert len(result) == 1
    assert result[0] in [2, 3]


# Generated at 2022-06-23 12:08:01.929559
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test with non-empty terms parameter
    lookup_plugin = LookupModule()
    terms = [1, 2, 3]
    result = lookup_plugin.run(terms)
    assert result in terms

    # test with empty terms parameter
    terms = []
    result = lookup_plugin.run(terms)
    assert result == []

# Generated at 2022-06-23 12:08:03.475377
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lu = LookupModule()

# To verify above method
test_LookupModule()

# Generated at 2022-06-23 12:08:11.689525
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # inputs
    terms = ['a', 'b', 'c', 'd']

    # instantiate
    lu = LookupModule()

    # test
    ret = lu.run(terms)

    # verify
    assert ret in terms

    # unit test for method run of class LookupModule
    # test empty terms
    terms = []

    # instantiate
    lu = LookupModule()

    # test
    ret = lu.run(terms)

    # verify
    assert ret == []

# Generated at 2022-06-23 12:08:13.066691
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(lookup is not None)

# Generated at 2022-06-23 12:08:17.086615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import pytest
    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('random_choice')
    assert lookup.__class__.__name__ == "LookupModule"

    assert lookup.run([]) == []

    assert lookup.run([1, 2, 3]) is not None
    assert lookup.run([1, 2, 3]) == [2]

# Generated at 2022-06-23 12:08:22.829126
# Unit test for constructor of class LookupModule
def test_LookupModule():

    mylookup = LookupModule()
    mylookup.run([], None)
    mylookup.run([], {}, {})

    assert_equals(mylookup.run([], None), [])
    assert_not_equals(mylookup.run([], {"a": [1, 2, 3]}), [1, 2, 3])

# Generated at 2022-06-23 12:08:23.862949
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:08:27.451223
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random_choice = LookupModule()
    random_choice.run(["30.40.50.60", "10.20.30.40", "24.34.44.54"])
    random_choice.run([])

# Generated at 2022-06-23 12:08:32.255907
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tests whether it must raise an error when argument is not of type list
    terms = "random_choice"
    random_lookup = LookupModule()
    result = [random_lookup.run(terms)]
    assert len(result) == 1
    assert result[0] == terms


# Generated at 2022-06-23 12:08:33.783559
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


# Generated at 2022-06-23 12:08:35.391742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert not LookupModule.run(["A", "B", "C"], ["A", "B", "C"])

# Generated at 2022-06-23 12:08:36.292790
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None

# Generated at 2022-06-23 12:08:38.376769
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.lookup import LookupModule
    ret = LookupModule()
    assert ret

# Generated at 2022-06-23 12:08:40.930056
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert(isinstance(lookup, LookupModule))

# Unit test - test that a random element from the list is returned

# Generated at 2022-06-23 12:08:44.607818
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["apple", "orange", "banana"]
    assert random.choice(terms) in terms
    mylookup = LookupModule()
    result = mylookup.run(terms)
    assert "apple" in result or "orange" in result or "banana" in result

# Generated at 2022-06-23 12:08:55.562793
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # List of choices is empty
    result = lookup_module.run([])
    if result != []:
        raise Exception("Unexpected result: %s (expected: [])" % str(result))

    # Single choice
    result = lookup_module.run(["apple"])
    if result != ["apple"]:
        raise Exception("Unexpected result: %s (expected: ['apple'])" % str(result))

    # Multiple choices
    # A choice has to be present in returned list
    result = lookup_module.run(["apple", "banana", "coconut"])

# Generated at 2022-06-23 12:09:01.521082
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["red", "blue", "green"]
    # For the sake of the test, we will assume the worst case
    # scenario.  That is, the random value chosen is the first
    # value in the list.
    random.choice = lambda x: x[0]
    lm = LookupModule()
    result = lm.run(terms)
    random.choice = random.choice
    assert result == ["red"]

# Generated at 2022-06-23 12:09:09.933056
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with a list of two items.
    item = ['first', 'second']
    module = LookupModule()
    assert len(module.run(item)) == 1

    # Test with a list of one item.
    item = ['only one']
    module = LookupModule()
    assert len(module.run(item)) == 1

    # Test with an empty list.
    item = []
    module = LookupModule()
    assert len(module.run(item)) == 0

# Generated at 2022-06-23 12:09:10.908571
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule != None

# Generated at 2022-06-23 12:09:12.162520
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert callable(lookup)

# Generated at 2022-06-23 12:09:21.382314
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Testing the lookup module when the terms is an empty list
    terms = []
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert result == terms

    # Testing the lookup module when the terms is a list with one element
    terms = ["Hello"]
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert result == ["Hello"]

    # Testing the lookup module when the terms is a list with two elements
    terms = ["Hello","World"]
    lookup_module = LookupModule()
    result = lookup_module.run(terms)
    assert result in (["Hello"],["World"])


# Generated at 2022-06-23 12:09:22.438939
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 12:09:23.885751
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_obj = LookupModule()
    assert my_obj != None

# Generated at 2022-06-23 12:09:28.793828
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    terms = ['term1', 'term2', 'term3']

    # Test with empty term list
    result = m.run(terms=[])
    assert result == []
    result = m.run(terms=['term1', ''])
    assert result == ['term1']

    # Test with non empty term list
    for i in range(10):
        result = m.run(terms=terms)
        assert result in terms

# Generated at 2022-06-23 12:09:31.165242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    list_terms=['Hello','Welcome','Hi']
    lookup = LookupModule()
    value = lookup.run(list_terms)
    assert isinstance(value,list)
    assert value[0] in ['Hello','Welcome','Hi']

# Generated at 2022-06-23 12:09:36.930597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create instance of class LookupModule()
    lookup_random_choice = LookupModule()

    # assert random choice of list of integer
    assert lookup_random_choice.run([1,2,3]) in [1,2,3]

    # assert random choice of list of string
    assert lookup_random_choice.run(["one","two","three"]) in ["one","two","three"]

# Generated at 2022-06-23 12:09:39.575388
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        print("Could not create LookupModule, unexpected error: ", e)


# Generated at 2022-06-23 12:09:43.121463
# Unit test for constructor of class LookupModule
def test_LookupModule():

    try:
        import random
    except ImportError as e:
        print(e)

    results = LookupModule().run(terms='hello')
    assert(results == 'hello')

    results = LookupModule().run(terms=['hello', 'goodbye'])
    assert(results in ['hello', 'goodbye'])

# Generated at 2022-06-23 12:09:49.942409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Imports for unit tests
    import pytest
    from ansible.errors import AnsibleError

    def test_case_1(mocker):
        """
        Test case 1: ret list is not empty
        """
        mocker.patch.object(random, 'choice')
        mocker.patch.object(LookupBase, 'run')

        terms = ["1","2","3"]
        terms_mock = mocker.MagicMock(return_value=terms)
        random.choice.return_value = "2"

        lookup_obj = LookupModule()
        ret = lookup_obj.run(terms=terms_mock)

        random.choice.assert_called_once_with(terms)
        assert ret[0] == "2"
