

# Generated at 2022-06-23 11:59:45.756419
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

if __name__ == "__main__":
    test_LookupModule()

# Generated at 2022-06-23 11:59:47.228759
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor for class LookupModule should not raise any exception
    lookup_plugin = LookupModule()

# Generated at 2022-06-23 11:59:48.997451
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Checking with terms parameter present
    terms = ['foo', 'bar', 'baz']
    l = LookupModule()
    l.run(terms)


# Generated at 2022-06-23 11:59:52.499215
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run(terms=['test_term']) == ['test_term']

# Generated at 2022-06-23 12:00:01.863162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def test_one():
        lookup_module = LookupModule()
        try:
            terms = ['term1', 'term2']
            result = lookup_module.run(terms)
            assert result != None
            assert len(result) == 1
            assert result[0] in terms

            terms = ['term1', 'term2', 'term3']
            result = lookup_module.run(terms)
            assert result != None
            assert len(result) == 1
            assert result[0] in terms

            terms = []
            result = lookup_module.run(terms)
            assert result != None
            assert len(result) == 0

        except AnsibleError as e:
            assert e.message == "Unable to choose random term: empty sequence"

    test_one()

# Generated at 2022-06-23 12:00:02.456664
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:00:03.899234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing LookupModule")
    x = LookupModule()
    assert isinstance(x, LookupModule)


# Generated at 2022-06-23 12:00:09.324120
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup = LookupModule()
    lookup.set_options(dict())
    choice_list = [i for i in range(1, 200)]
    # Perform test
    test_result = lookup.run(choice_list)
    # Assert result
    assert isinstance(test_result, list) and test_result[0] in choice_list

# Generated at 2022-06-23 12:00:11.898835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['1', '2', '3']

    print("Testing LookupModule class")
    print("Method run:")
    print(LookupModule().run(terms))


# Generated at 2022-06-23 12:00:12.596248
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()


# Generated at 2022-06-23 12:00:13.002019
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:00:14.912615
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-23 12:00:15.740488
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:00:17.286431
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 12:00:20.569331
# Unit test for constructor of class LookupModule
def test_LookupModule():
    values = ['value1', 'value2', 'value3']
    random_val = LookupModule().run(terms=values)

    assert random_val[0] in values

# Generated at 2022-06-23 12:00:23.494736
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = {"name": "random_choice", "choices": ["one", "two", "three"]}
    result = LookupModule()
    result.run(module["choices"])

# Generated at 2022-06-23 12:00:26.708573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [0, 1, 2]
    test_class = LookupModule()
    result = test_class.run(terms, inject=None, **{})
    assert result in terms

# Generated at 2022-06-23 12:00:28.362580
# Unit test for constructor of class LookupModule
def test_LookupModule():
    testObj = LookupModule()
    assert testObj.run() == [], "test_LookupModule failed"

# Generated at 2022-06-23 12:00:29.736508
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module != None

# Generated at 2022-06-23 12:00:30.582011
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

# Generated at 2022-06-23 12:00:31.088803
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-23 12:00:33.752628
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['a', 'b']
    res = lookup_module.run(terms)
    assert res[0] in terms

# Generated at 2022-06-23 12:00:37.257510
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.random_choice import LookupModule
    lookup_module = LookupModule()
    terms = ['one', 'two', 'three', 'four', 'five', 'six']
    result = lookup_module.run(terms)
    assert(len(result) == 1)
    assert(result[0] in terms)

# Generated at 2022-06-23 12:00:44.342478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a random choice plugin
    plugin = LookupModule()

    # Create a list of strings
    terms = ["zero", "one", "two", "three"]

    # Call method run
    result = plugin.run(terms, inject=None)

    # Check result
    # The result is a list which contains only one item
    assert len(result) == 1
    # The item in the list is a string
    assert isinstance(result[0], str)
    # The item in the list is in the list of the terms
    assert result[0] in terms


# Generated at 2022-06-23 12:00:46.934645
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_object = LookupModule()
    assert lookup_object.run([1,2,3]) == [1,2,3]

# Generated at 2022-06-23 12:00:51.735868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(
        ["item1", "item2", "item3"],
        inject=None,
        **{}
    )

    assert isinstance(ret, list)
    assert len(ret) == 1

    assert ret[0] in ["item1", "item2", "item3"]

# Generated at 2022-06-23 12:00:56.269002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1, 2, 3, 4, 5]
    ans_obj = LookupModule()
    ret = ans_obj.run(terms, inject={}, **{})
    if ret not in terms:
        assert 0, "Unit test for method run of class LookupModule failed"
    return

# Generated at 2022-06-23 12:01:00.108291
# Unit test for constructor of class LookupModule
def test_LookupModule():
    look = LookupModule()
    t = ['Hello', 'World']
    terms = look.run(terms = t)
    assert terms
    assert terms in t

# Generated at 2022-06-23 12:01:05.265698
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['one', 'two', 'three']

    ret = lookup.run([], None)
    assert(ret == [])

    ret = lookup.run(terms, None)
    assert(ret in terms)

    terms = []
    ret = lookup.run(terms, None)
    assert(ret == [])

# Generated at 2022-06-23 12:01:15.075081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import sys
    import json
    import pytest
    # import mock
    from mock import patch
    from mock import MagicMock
    from ansible.utils.display import Display
    from ansible.plugins.lookup.random_choice import LookupModule

    args_list = (
        (["ansible"],),
        (["ansible", "ansible-playbook", "ansible-inventory", "ansible-galaxy", "ansible-galaxy"],)
    )

    with patch.object(sys, 'argv', ['ansible']):
        display = Display()

    lookup = LookupModule(display)
    for terms in args_list:
        result = lookup.run(terms)
        assert result == terms

# Generated at 2022-06-23 12:01:25.239516
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # add a mock of random.choice() in order to test static value
    class MockRandom:
        def choice(self, terms):
            return "random_choice"

    mock_random = MockRandom()
    terms = ["exclude", "include", "random_choice"]

    # get the lookup_module() class from the lookup_module(...) function
    # __init__(self, loader=None, templar=None, **kwargs)
    # use **kwargs to avoid creating loader/templar (not needed for this test)
    # pass the mock random class for creating the random_choice value
    lookup_module = LookupModule(**{"random": mock_random})

    # test the run(self, terms, inject=None, **kwargs) function
    assert lookup_module.run(terms, []) == ["random_choice"]

# Generated at 2022-06-23 12:01:26.301880
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 12:01:30.093662
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    test_terms = ["a", "b", "c"]
    result = test.run(test_terms, inject=None, **{})
    assert result in test_terms

# Generated at 2022-06-23 12:01:39.940074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(["a","b","c"]) == ["a","b","c"]
    assert lookup.run(["a","b","c"]) == ["a","b","c"]
    assert lookup.run(["a","b","c"]) == ["a","b","c"]
    assert lookup.run(["a","b","c"]) == ["a","b","c"]
    assert lookup.run(["a","b","c"]) == ["a","b","c"]
    assert lookup.run(["a","b","c"]) == ["a","b","c"]
    assert lookup.run(["a","b","c"]) == ["a","b","c"]
    assert lookup.run(["a","b","c"]) == ["a","b","c"]

# Generated at 2022-06-23 12:01:41.388622
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random_choice = LookupModule()
    assert random_choice is not None

# Generated at 2022-06-23 12:01:43.591027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert LookupModule().run(["hello world","fooby dooby"], None, None) == ["hello world"]
# END test_LookupModule_run

# Generated at 2022-06-23 12:01:48.181019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Testing the run method of class LookupModule
    """
    terms = ['a', 'b', 'c', 'd']
    ret = LookupModule().run(terms)
    assert isinstance(ret, list)
    assert True if (ret[0] in terms) else False

# Generated at 2022-06-23 12:01:50.042015
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    return lookup_module

# Generated at 2022-06-23 12:01:52.220515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   module = LookupModule()
   data = module.run(terms=['a','b','c'])
   assert(len(data) == 1)

# Generated at 2022-06-23 12:02:02.806142
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test list of tuples
    list_of_tuple = ([tupl for tupl in zip(['a','b','c'],[1,2,3])])
    assert ([tupl for tupl in zip(['a','b','c'],[1,2,3])]) == [('a', 1), ('b', 2), ('c', 3)]
    assert len([tupl for tupl in zip(['a','b','c'],[1,2,3])]) == 3

    lookup_module = LookupModule()
    lm = lookup_module.run(terms=['a','b','c'])
    assert (lm[0] == 'a' or lm[0] == 'b' or lm[0] == 'c'), 'One of the three is expected'

# Generated at 2022-06-23 12:02:04.473194
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run(terms =[1, 2, 3, 4], inject=None, **{'Print': True})

# Generated at 2022-06-23 12:02:05.652318
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 12:02:14.759605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import sys

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.module = sys.modules['ansible.plugins.lookup.random_choice']
            self.g = globals()
            self.g['LookupModule'] = self.module.LookupModule

        def tearDown(self):
            del self.g['LookupModule']

        def test_run(self):

            terms = ['foo', 'bar']
            lookup_mod = LookupModule()
            # Check values returned
            results = lookup_mod.run(terms)
            self.assertTrue(results[0] in terms)
            # Empty values
            results = lookup_mod.run([])
            self.assertEqual(results, [])

    suite = unittest.TestLoader

# Generated at 2022-06-23 12:02:24.514293
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    terms = ['apple', 'banana', 'orange']
    random_term = lu.run(terms)
    assert random_term[0] in terms
    
    terms = ['apple', 'banana', 'orange']
    random_term = lu.run(terms)
    assert random_term[0] in terms
    
    terms = ['apple', 'banana', 'orange']
    random_term = lu.run(terms)
    assert random_term[0] in terms
    
    terms = ['apple', 'banana', 'orange']
    random_term = lu.run(terms)
    assert random_term[0] in terms    
    
    # User choose empty list of terms and None returned
    terms = []
    random_term = lu.run(terms)

# Generated at 2022-06-23 12:02:30.468815
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Test empty terms
    look = LookupModule()
    assert look.run([]) == []

    # Test one term
    assert look.run(['one']) == ['one']

    # Test multi term
    result = look.run(['one', 'two', 'three'])
    assert result == ['one'] or result == ['two'] or result == ['three']

# Generated at 2022-06-23 12:02:40.467087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    f = open('/tmp/test_LookupModule_run', 'w')
    found = 0
    # Method run should return a list of random choice from a given list
    for i in range(100):
        ret = LookupModule().run(terms=[1, 2, 3])
        if ret[0] not in [1, 2, 3]:
            found += 1
            f.write("Random Choice from [1, 2, 3] is %s.\n" % ret)
    if found > 0:
        f.write("Method run did not return a random choice from [1, 2, 3] for %d times.\n" % found)
    found = 0
    # Method run should raise AnsibleError exception if random choice fails

# Generated at 2022-06-23 12:02:44.262234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor for class LookupModule
    lookup = LookupModule()
    # test for method run
    lookup.run(terms=['a','b','c','d','e','f','g'])

# Generated at 2022-06-23 12:02:45.797269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert(x is not None)

# Generated at 2022-06-23 12:02:55.329895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    first_term = "first"
    second_term = "second"
    third_term = "third"
    test_terms = [first_term, second_term, third_term]
    expected_terms = [first_term, second_term, third_term]

    # This loop runs at most 100 iterations.
    # In a situation where the random choice happens to be the
    # same every time, one of the terms in the list would need to
    # be chosen 100 times in a row for the test to fail.
    # This is very unlikely to happen.
    for i in range(100):
        returned_term = lookup_plugin.run(test_terms)[0]
        assert returned_term in expected_terms, \
            "returned term is not in expected term list"

# Generated at 2022-06-23 12:02:56.375440
# Unit test for constructor of class LookupModule
def test_LookupModule():
    add = LookupModule()
    assert add

# Generated at 2022-06-23 12:02:57.981873
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['a', 'b', 'c']
    LookupModule().run(terms)

# Generated at 2022-06-23 12:03:02.296226
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    ret = lookup_module.run(["red", "blue", "green"])
    assert ret == ["red"], "Expected 'red' but got %s" % ret
    assert ret != ["blue"], "Expected 'red' but got %s" % ret

# Generated at 2022-06-23 12:03:03.040372
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()

    assert test is not None

# Generated at 2022-06-23 12:03:04.125621
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:03:04.939426
# Unit test for constructor of class LookupModule
def test_LookupModule():
    
    assert LookupModule(**{}) is not None

# Generated at 2022-06-23 12:03:07.023417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(['a','b','c']) == ['a','b','c']

# Generated at 2022-06-23 12:03:09.579096
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    terms = ['a', 'b', 'c']
    assert lookup.run(terms) in terms

# Generated at 2022-06-23 12:03:11.106188
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookup = LookupModule()
    assert mylookup != None

# Generated at 2022-06-23 12:03:12.629949
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    words = ["set", "of", "words"]
    lookup = LookupModule()
    result = lookup.run(terms=words)
    assert result[0] in words, "random_choice lookup did not return one of the words: {}".format(words)

# Generated at 2022-06-23 12:03:19.598302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    d = [ 'cows', 'chickens', 'ducks', 'goats', 'horses' ]
    for i in range(0,10):
        assert random.choice(d) in LookupModule(None, None).run([ d ], None, None)

    with pytest.raises(AnsibleError) as exc:
        LookupModule(None, None).run([], None, None)
    assert 'random term' in to_native(exc.value)

# Generated at 2022-06-23 12:03:20.975821
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l != None

# Generated at 2022-06-23 12:03:25.212701
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    items = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    mylookup = LookupModule()
    result = mylookup.run(items)
    print(result)
    # Expected to return 1 item
    assert len(result) == 1
    assert result[0] in items

# Generated at 2022-06-23 12:03:32.433331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = []
    exp_result = []
    exp_exception = AnsibleError
    exp_error_msg = "Unable to choose random term: list index out of range"
    # Case 1: When args is not equal to None,
    # exp_result is not equal to None,
    # exp_exception is equal to None,
    # exp_error_msg is equal to None
    # Case 2: When args is not equal to None,
    # exp_result is not equal to None,
    # exp_exception is not equal to None,
    # exp_error_msg is not equal to None
    # Case 3: When args is not equal to None,
    # exp_result is not equal to None,
    # exp_exception is equal to None,
    # exp_error_msg is not equal to None
    #

# Generated at 2022-06-23 12:03:37.286464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # behavior for empty terms
    terms = list()
    lookup_module = LookupModule()
    assert(lookup_module.run(terms)) == terms

    # behavior for empty terms
    terms = list()
    lookup_module = LookupModule()
    assert(lookup_module.run(terms)) == terms

    # behavior for non empty terms
    terms = ["one", "two", "three", "four"]
    lookup_module = LookupModule()
    assert(lookup_module.run(terms)) in terms

# Generated at 2022-06-23 12:03:40.430444
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # class LookupModule(LookupBase):
    #     def run(self, terms, inject=None, **kwargs):

    lookupModule = LookupModule()

    # call run
    res = lookupModule.run(terms=['A','B','C'])

    # testing result
    assert res in ['A','B','C']

    # end of unit test function
# end of unit test class

# Generated at 2022-06-23 12:03:41.690806
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-23 12:03:42.728153
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run()

# Generated at 2022-06-23 12:03:53.563503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_string = 'test_string'
    test_list = ['a', 'b', 'c']
    test_dict = {'a': 'b'}
    lm = LookupModule()

    def test_instance(result):
        assert isinstance(result, list), 'Should return a list'
        assert len(result) == 1, 'List should be of length 1'
        assert result[0] in test_list, 'List should contain the chosen element'

    test_instance(lm.run(test_list))
    assert lm.run(test_dict) == [test_dict], 'run should return the original dict'
    assert lm.run(test_string) == [test_string], 'run should return the original string'

# Generated at 2022-06-23 12:03:57.488333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert module.run(["a","b","c"]) == ["a"] or module.run(["a","b","c"]) == ["b"] or module.run(["a","b","c"]) == ["c"]

# Generated at 2022-06-23 12:04:01.617074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for function run of class LookupModule
    '''
    terms = [1, 2, 3, 4, 'five', 'six']
    assert(set(terms) == set(LookupModule().run(terms)))

# Generated at 2022-06-23 12:04:04.598988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [1, 2, 3]
    assert lookup.run(terms) == [1] or lookup.run(terms) == [2] or lookup.run(terms) == [3]

# Generated at 2022-06-23 12:04:14.068876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode

    lookup_plugin = LookupModule()

    # test random_choice
    result = lookup_plugin.run(terms=['a', 'b', 'c'], inject={}, **{})
    assert 1 == len(result), "random_choice must return 1 result"
    assert isinstance(result[0], AnsibleUnicode), "random_choice must return unicode result"

    # test error handling
    try:
        result = lookup_plugin.run(terms=None, inject={}, **{})
    except Exception as err:
        assert isinstance(err, AnsibleError), "random_choice must raise AnsibleError if no terms"

    # test error handling

# Generated at 2022-06-23 12:04:17.840948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    array = ['hello','world','test','test1']
    result = array[random.randint(0,len(array)-1)]
    lookup_result = []
    l = LookupModule()
    lookup_result = l.run(array)
    assert  result in array

# Generated at 2022-06-23 12:04:20.394586
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except:
        print("TEST FAILED: no object could be created")

# Unit test to test the run method

# Generated at 2022-06-23 12:04:21.617641
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run

# Generated at 2022-06-23 12:04:23.510121
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-23 12:04:28.155670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        1, 2, 3, 4, 5,
    ]
    lookup = LookupModule()

    # test with terms
    result = lookup.run(terms)
    assert len(result) == 1
    assert result[0] in terms

    # test without terms
    result = lookup.run(None)
    assert not result

# Generated at 2022-06-23 12:04:37.315322
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # execute method and test its output
    test_LookupModule = LookupModule()

    random_term = test_LookupModule.run(["foo", "bar", "baz"])
    assert random_term in ("foo", "bar", "baz")

    # execute method again and test its output
    random_term = test_LookupModule.run(["foo", "bar", "baz"])
    assert random_term in ("foo", "bar", "baz")

    # execute method again and test its output
    random_term = test_LookupModule.run(["foo", "bar", "baz"])
    assert random_term in ("foo", "bar", "baz")

# Generated at 2022-06-23 12:04:38.521553
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'LookupModule' in globals()

# Generated at 2022-06-23 12:04:39.950223
# Unit test for constructor of class LookupModule
def test_LookupModule():
    L = LookupModule()
    L.get_basedir = lambda x: ''
    assert L

# Generated at 2022-06-23 12:04:45.545852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Run a valid test
    terms = ["a", "b", "c"]
    random.seed(100)
    module = LookupModule()
    element = module.run(terms)[0]
    assert element == "c"

    # Run an invalid test
    terms = ["a", "b", 1]
    random.seed(100)
    module = LookupModule()
    assert module.run(terms) == terms

# Generated at 2022-06-23 12:04:47.426085
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-23 12:04:51.523706
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Unit test for method run of class LookupModule
    m = LookupModule()
    terms = ['a', 'b', 'c', 'd']
    random_choice = m.run(terms)[0]
    assert isinstance(random_choice, str)

# Generated at 2022-06-23 12:04:59.226105
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import lookup_loader

    # Create instance of class LookupModule
    l = lookup_loader.get('random_choice', class_only=True)()

    # Check for function run
    assert hasattr(l, 'run')

    # Check for function fail_json
    assert hasattr(l, 'fail_json')
    assert callable(l.fail_json)

    # Check for function run
    assert hasattr(l, 'run')
    assert callable(l.run)

    # Set of tests to check the features of class LookupModule
    class args:
        terms = ['hello', 'hi', 'hey']

    class kwargs:
        options = ['hello', 'hi', 'hey']

    class inject:
        random = random
        to_native = to_native

    # Test

# Generated at 2022-06-23 12:05:00.677003
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:05:08.162870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    If a list of words are given as input to run method of
    LookupModule, expected output is a list of one word
    which should be a random word from input list of words.
    """
    m = LookupModule()
    words = ['hi', 'hello']
    ret = m.run(terms=words)

    if isinstance(ret, list):
        assert len(ret) == 1
        assert ret[0] in words
    else:
        raise AssertionError("Expected a list, got %s" % (ret))


# Generated at 2022-06-23 12:05:15.817955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    LookupModule -- Test run method
    """
    a = LookupModule()
    terms = ['foo', 'bar', 'baz']
    terms1 = ['foo']
    terms2 = ['']
    assert a.run(terms) in [['foo'], ['bar'], ['baz']]
    assert a.run(terms1) == ['foo']
    assert a.run(terms2) == ['']
    assert a.run([]) == []

# Generated at 2022-06-23 12:05:17.054465
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lo = LookupModule()

# Generated at 2022-06-23 12:05:19.999212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['Red', 'Blue', 'Green', 'Yellow']
    test = LookupModule()
    test_result = test.run(terms)
    assert test_result in terms

# Generated at 2022-06-23 12:05:22.032552
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Run tests, if appropriate, here.
    print("Test of class LookupModule")
    # LookupModule()

# Generated at 2022-06-23 12:05:29.007815
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    myObj = LookupModule()
    test_data = ['a', 'b', 'c']
    num_tests = 1000
    test_result = []
    expected_result = [0, 1, 2]

    for x in range(num_tests):
        test_result.append(myObj.run(terms=test_data)[0])

    for y in range(len(test_data)):
        assert test_result.count(test_data[y]) >= expected_result[y]

# Generated at 2022-06-23 12:05:32.016508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup = LookupModule()
  terms = [
    "10",
    "20",
    "30",
    "40",
    "50",
    "60",
    "70"
  ]
  print(lookup.run(terms))

# Generated at 2022-06-23 12:05:33.159694
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('hello world')
    return False

# Generated at 2022-06-23 12:05:35.146839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = LookupModule()
    assert len(lookup_obj.run([1, 2, 3], inject={}, **{})) == 1


# Generated at 2022-06-23 12:05:37.566140
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = [1, 2, 3, 4]
    test_obj = LookupModule()
    assert test_obj.run(terms=terms)

# Generated at 2022-06-23 12:05:39.289068
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:05:46.165308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    random_choice = module.run([1,2,3])
    assert random_choice
    assert random_choice in [1, 2, 3]

    random_choice = module.run([])
    assert not random_choice

    try:
        random_choice = module.run([1,2,3], [])
    except Exception as e:
        assert "Unable to choose random term: " in str(e)

# Generated at 2022-06-23 12:05:48.515230
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)


# Generated at 2022-06-23 12:05:52.008338
# Unit test for constructor of class LookupModule
def test_LookupModule():
    res = LookupModule("LookupModule")
    assert res is not None

if __name__=="__main__":
    res = LookupModule("LookupModule")
    assert res is not None

# Generated at 2022-06-23 12:05:57.153093
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule.run(
            self = None,
            terms = ["foo", "bar"],
            inject = None,
            **kwargs)
    print("returned_value: ", ret)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:06:02.353719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    test method run of class LookupModule
    '''
    # create object of class LookupModule with terms as parameter
    lookup_plugin = LookupModule(terms=["First", "Second", "Third"])
    # call the method run of object lookup_plugin
    assert lookup_plugin.run() in [["First"], ["Second"], ["Third"]]

# Generated at 2022-06-23 12:06:07.359530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert len(LookupModule().run([1,2,3])) == 1
    assert len(LookupModule().run(["a","b","c"])) == 1
    assert len(LookupModule().run([1,2,3,4,5,6,7,8,"a","b","c","d","e","f","g","h"])) == 1
    assert len(LookupModule().run([1,2,3,4,5,6,7,8,"a","b","c","d","e","f","g","h,"])) == 1
    assert len(LookupModule().run([])) == 0

# Generated at 2022-06-23 12:06:11.669291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["term1", "term2", "term3", "term4"]
    l_module = LookupModule()
    retvalue = l_module.run(terms)
    assert (retvalue[0] in terms)


# Generated at 2022-06-23 12:06:13.186470
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(hasattr(LookupModule, 'run'))
    return

# Generated at 2022-06-23 12:06:15.287472
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert random.choice([1, 2, 3]) in [1, 2, 3]

# Generated at 2022-06-23 12:06:19.796800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    lu.run([1,2,3,4])

    try:
        lu.run("blah")
    except AnsibleError as e:
        assert "Unable to choose random term: unhashable type: 'str'" in str(e)

# Generated at 2022-06-23 12:06:29.714245
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run([1, 2, 3]) != [1, 2, 3]
    assert lm.run([1, 2, 3])[0] in [1, 2, 3]
    assert lm.run([1, 2, 3])[0] == lm.run([1, 2, 3])[0]
    assert lm.run([1, 2, 3])[0] == lm.run([1, 2, 3])[0]
    assert lm.run([1, 2, 3])[0] == lm.run([1, 2, 3])[0]
    assert lm.run([1, 2, 3])[0] == lm.run([1, 2, 3])[0]

# Generated at 2022-06-23 12:06:33.266249
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule({})

    assert lm.run(['a', 'b', 'c', 'd']) == ['c']

# Generated at 2022-06-23 12:06:38.045719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    test_list = [1, 2, 3, 5, 6, 8, 9, 10]
    test_lookup = LookupModule()
    random.seed(100)
    for i in range(0, 10):
        assert test_lookup.run(test_list) == [6]


# Generated at 2022-06-23 12:06:45.019931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = LookupModule()
    test_terms = ['a','b','c','d']
    test_terms_one = ['a']
    test_terms_none = []
    output = test.run(test_terms)
    output_one = test.run(test_terms_one)
    output_none = test.run(test_terms_none)
    assert isinstance(output, list)
    assert len(output) == 1
    assert output[0] in test_terms
    assert isinstance(output_one, list)
    assert len(output_one) == 1
    assert output_one[0] in test_terms_one
    assert isinstance(output_none, list)
    assert len(output_none) == 0

# Generated at 2022-06-23 12:06:46.180946
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_obj = LookupModule()

# Generated at 2022-06-23 12:06:48.609827
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run([["foo", "bar", "baz"]]) == ["foo"]

# Generated at 2022-06-23 12:06:50.133480
# Unit test for constructor of class LookupModule
def test_LookupModule():
   lookup_module = LookupModule()
   assert lookup_module is not None

# Generated at 2022-06-23 12:06:55.541016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class MockModule:
        def __init__(self):
            self.params = {}

    terms = [5, 7, 11, 17, 19, 23, 29]
    ret = LookupModule(MockModule()).run(terms, inject=None, **{})
    assert len(ret) == 1
    assert ret[0] in terms

# Generated at 2022-06-23 12:06:58.775570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = ["abc","def","ghi"]
    l = LookupModule()
    results = l.run(t)
    assert(len(results) == 1)
    assert(results[0] in t)
# Test method run with invalid list (no item)

# Generated at 2022-06-23 12:06:59.702674
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()

# Generated at 2022-06-23 12:07:03.443558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    test function for method run of class LookupModule
    """
    terms = ['a', 'b', 'c']
    lookup_obj = LookupModule()
    res = lookup_obj.run(terms)
    assert res != None

# Generated at 2022-06-23 12:07:04.467261
# Unit test for constructor of class LookupModule
def test_LookupModule():
    result = LookupModule()
    assert result is not None

# Generated at 2022-06-23 12:07:06.571954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["a","b","c"]
    ret = lookup_module.run(terms)
    n = len(ret)
    assert(n > 0)

# Generated at 2022-06-23 12:07:07.946819
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupBase)


# Generated at 2022-06-23 12:07:09.182633
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module

# Generated at 2022-06-23 12:07:10.041394
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(True)

# Generated at 2022-06-23 12:07:16.210625
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['one', 'two', 'three']
    lookup_obj = LookupModule()

    random.seed(1)
    for i in range(1, 6):
        ret = lookup_obj.run([terms])

        assert len(ret) == 1
        assert ret[0] in terms

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:07:19.474200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # execute the constructor
    lookup_plugin = LookupModule()
    # we expect no exceptions, if any occurs, fail the test
    assert lookup_plugin is not None

# Generated at 2022-06-23 12:07:22.679525
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ["hello", "world", "foo", "bar", "baz"]
    result = LookupModule().run(terms, [], terms=terms)

    assert len(result) == 1
    assert result in terms

# Generated at 2022-06-23 12:07:23.968434
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-23 12:07:26.035813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(["term1", "term2"])

# Test this module
if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:07:26.835686
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:07:31.526451
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None
    assert lookup_module.run(["choice_1", "choice_2"]) == ["choice_1"]
    assert lookup_module.run([]) == []

# Generated at 2022-06-23 12:07:43.487271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''Unit test for method run of class LookupModule'''

    # Note: In Python 3, must decode bytes, and encode to native str.
    #   See: http://stackoverflow.com/questions/606191/convert-bytes-to-a-string
    #        http://stackoverflow.com/questions/31342837/convert-bytes-to-string-python-3

    # Set up parameters.
    terms = [
        "go through the door",
        "drink from the goblet",
        "press the red button",
        "do nothing"
    ]
    # Perform method test.
    lu = LookupModule()
    results = lu.run(terms)

    # Check results.
    assert(len(results) == 1)
    assert(results[0] in terms)

# Generated at 2022-06-23 12:07:52.872959
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # type: () -> None
    lookup_plugin = LookupModule()
    # Test case 1
    assert lookup_plugin.run(terms=None) == []
    # Test case 2
    assert lookup_plugin.run(terms=[]) == []
    # Test case 3
    assert len(lookup_plugin.run(terms=[1, 2])) == 1
    # Test case 4
    assert len(lookup_plugin.run(terms=["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"])) == 1

# Generated at 2022-06-23 12:07:54.857332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    print(lookup.run([1, 2, 3]))

# Generated at 2022-06-23 12:08:02.936419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #mock random.choice(list)
    # random.choise(list) : Return a random element from the non-empty sequence
    # https://docs.python.org/2/library/random.html#random.choice
    class MocRandomChoice:
        _choice_list = []
        def choice(self, seq):
            return self._choice_list.pop()

    mocRandomChoice = MocRandomChoice()
    random.choice = mocRandomChoice.choice

    lookup = LookupModule()
    assert lookup.run([]).__len__() == 0
    assert lookup.run([1]).__len__() == 1

    mocRandomChoice._choice_list = []
    assert lookup.run([1, 2, 3, 4]).__len__() == 1

    mocRandomChoice._choice_list = [1]


# Generated at 2022-06-23 12:08:06.388632
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    terms = [1,2,3,4,5]
    ret = lookup.run(terms)
    assert ret[0] in terms

# Generated at 2022-06-23 12:08:07.822663
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert lu is not None

# Generated at 2022-06-23 12:08:11.508047
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create a new instance of LookupModule
    test = LookupModule()
    test.run(terms=['test1', 'test2', 'test3'], inject=None, **{'verify_ssl': False})

# Generated at 2022-06-23 12:08:14.284067
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_module = LookupModule()

    # Call the run function of class LookupModule and pass a list of terms as parameter
    lookup_module.run(terms=[1, 2])

# Generated at 2022-06-23 12:08:14.975352
# Unit test for constructor of class LookupModule
def test_LookupModule():
    h = LookupModule()
    assert h != None

# Generated at 2022-06-23 12:08:18.176497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #Unit test for method run of class LookupModule
    lookup_module = LookupModule()
    #Test for argument 'terms'
    terms = [1, 2, 3]
    assert lookup_module.run(terms) not in terms

# Generated at 2022-06-23 12:08:23.025634
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    ret = l.run(["string1", "string2", "string3"])
    if ret != ["string1"] and ret != ["string2"] and ret != ["string3"]:
        raise AssertionError("unexpected random choice returned")

# Generated at 2022-06-23 12:08:25.149353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=[1, 2, 3]) == [1]

# Generated at 2022-06-23 12:08:28.156539
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms = ['Ansible','Puppet','Chef','Salt']) == ['Ansible']

# Generated at 2022-06-23 12:08:35.960861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_terms = [
        ("term1", "term1"),
        ([], []),
        (
            ["foo", "bar", "biz", "baz"],
            ["foo", "bar", "biz", "baz"]
        ),
        (
            ["foo", "bar", "biz", "baz"],
            ["foo", "bar", "biz", "baz"]
        ),
    ]

    for terms, expected in test_terms:
        lookup_module = LookupModule()
        results = lookup_module.run(terms)

        assert results == [expected]

# Generated at 2022-06-23 12:08:38.333135
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert len(lookup) == 0

# Unit test fro run of class LookupModule

# Generated at 2022-06-23 12:08:40.885489
# Unit test for constructor of class LookupModule
def test_LookupModule():
  terms = ['a','b','c']
  inject = None
  test_runner = LookupModule(terms, inject)
  assert test_runner.run(terms, inject) != ['c']

# Generated at 2022-06-23 12:08:41.484538
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:08:43.262055
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None


# Generated at 2022-06-23 12:08:45.203269
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    terms = [1, 2]
    assert lookup_plugin.run(terms) in terms

# Generated at 2022-06-23 12:08:46.102708
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-23 12:08:52.041567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # test that it returns a term if the list contains items
    result = lm.run(terms=['a', 'b'])
    assert isinstance(result, list)
    assert len(result) == 1
    # test that it returns an empty list if the list is empty
    result = lm.run(terms=[])
    assert isinstance(result, list)
    assert result == []

# Generated at 2022-06-23 12:08:56.071257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(argument_spec=dict(terms=dict(type='list')))
    result = LookupModule().run(terms=module.params['terms'])
    assert result[0] in module.params['terms']

# Generated at 2022-06-23 12:08:59.295545
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['one', 'two', 'three']
    lm = LookupModule()
    assert lm.run(terms) in (['one'], ['two'], ['three'])

# Generated at 2022-06-23 12:09:00.717362
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:09:03.963294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    value = lookup.run(["a","b","c"])
    assert value[0] in ["a","b","c"]

# Generated at 2022-06-23 12:09:08.148779
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # test input
    terms = ['a', 'b', 'c']

    # TODO: complete unit test
    lookup_module = LookupModule()
    assert lookup_module.run(terms)

# Generated at 2022-06-23 12:09:08.916715
# Unit test for constructor of class LookupModule
def test_LookupModule():
    obj = LookupModule()
    assert obj.run is not None

# Generated at 2022-06-23 12:09:11.902521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    For now, this just tests that the function doesn't error.
    """
    lookup_module = LookupModule()
    lookup_module.run([1,2,3])

# Generated at 2022-06-23 12:09:16.683498
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    a = [1,2,3]
    assert(isinstance(test_LookupModule.run(a), list))
    assert(len(test_LookupModule.run(a)) == 1)  
    assert(test_LookupModule.run(a)[0] in a)
    return True

# Generated at 2022-06-23 12:09:21.742208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test method 'run' of class LookupModule"""
    lookup_plugin = LookupModule()
    lookup_plugin.lookup_name = 'random_choice'
    terms = ['A', 'B', 'C', 'D']
    chosen_item = lookup_plugin.run(terms)
    assert len(chosen_item) == 1
    assert chosen_item[0] in terms

# Generated at 2022-06-23 12:09:27.498751
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    terms = ['a', 'b', 'c', 'd']
    expected_values = ['a', 'b', 'c', 'd']
    lookup_module = LookupModule()

    # Act
    result_values = []
    for i in range(0, len(expected_values)):
        result_values.append(lookup_module.run(terms))

    # Assert
    for expected in expected_values:
        assert expected in result_values

# Generated at 2022-06-23 12:09:30.860356
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    first_term = 'first_term'
    second_term = 'second_term'
    terms = [first_term, second_term]
    module = LookupModule()
    result = module.run(terms)
    assert len(result) == 1
    assert result[0] == first_term or result[0] == second_term


# Generated at 2022-06-23 12:09:36.982036
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test basic case - one and only one element in list
    lm = LookupModule()
    res = lm.run([1, 2, 3, 4, 5])
    if len(res) != 1:
        raise Exception("unexpected number of elements returned")
    if res[0] not in [1,2,3,4,5]:
        raise Exception("unexpected return value")

    return True

# Generated at 2022-06-23 12:09:39.188871
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None
    return lookup_module


# Generated at 2022-06-23 12:09:41.487351
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    result = lu.run(terms=["1", "2", "3"])
    assert len(result) == 1

# Generated at 2022-06-23 12:09:42.349107
# Unit test for constructor of class LookupModule
def test_LookupModule():
    return LookupModule()

# Generated at 2022-06-23 12:09:44.912497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = [1,2,3]
    assert lm.run(terms) == [1,2,3]