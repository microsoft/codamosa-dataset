

# Generated at 2022-06-23 11:59:51.452464
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ This is a unit test for the constructor of the class LookupModule """
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Unit testing for method run() of class LookupModule

# Generated at 2022-06-23 11:59:53.788335
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    looker = LookupModule()

    assert looker.run(['a', 'b', 'c']) == ['a']

# Generated at 2022-06-23 11:59:55.411845
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:59:58.851276
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # given
    source = [1, 2, 3, 4]
    expected = [1, 2, 3, 4]

    # when
    result = LookupModule().run(source, inject=[])

    # then
    assert result == expected

# Generated at 2022-06-23 12:00:07.078378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("START LookupModule_run")
    try:
        # Create a LookupModule object
        lm = LookupModule()
        # Call method run of class LookupModule
        ret = lm.run(terms=["a", "b"])
        # Check that the return value has one of "a" or "b"
        assert(ret[0] == "a" or ret[0] == "b")
    except Exception as e:
        raise
    print("SUCCESS LookupModule_run")


# Generated at 2022-06-23 12:00:10.430871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(123)
    assert random.randrange(100) == 88
    terms = ['first', 'second', 'third']
    assert LookupModule().run(terms)[0] == 'second'

# Generated at 2022-06-23 12:00:17.371081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create sample instant
    print('Creating sample instance')
    try:
        lookupModule = LookupModule()
    except Exception as e:
        print ('Could not create instance of LookupModule. Error: %s' % e)
        return 1

    # Call method run with sample data
    print('Calling method run with sample data')
    try:
        lookupModule.run(['a', 'b'])
    except Exception as e:
        print ('Could not call method run with sample data. Error: %s' % e)
        return 1

    # Call method run with bad data
    print('Calling method run with bad data')
    try:
        lookupModule.run(['123'])
    except Exception as e:
        print ('Could not call method run with bad data. Error: %s' % e)
        # Expected result - do

# Generated at 2022-06-23 12:00:18.338594
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    print(a)

# Generated at 2022-06-23 12:00:21.547387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.basedir = '.'
    l.run(terms=['pizza','chicken','salad'], inject=None)

# Generated at 2022-06-23 12:00:24.117544
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['a', 'b', 'c']
    assert(lookup.run(terms) in terms)

# Generated at 2022-06-23 12:00:26.746305
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Unit test for class LookupModule
    """
    module = LookupModule()
    assert module



# Generated at 2022-06-23 12:00:27.611192
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()

# Generated at 2022-06-23 12:00:33.872579
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.errors import AnsibleLookupError
    
    words = ['foo', 'bar', 'baz']
    ret = LookupModule().run(terms=words)
    assert len(ret) == 1
    assert ret[0] in words
    
    # check empty list
    ret = LookupModule().run(terms=[])
    assert len(ret) == 0

    # check incorrect type of terms argument
    ret = LookupModule().run(terms=(words,))
    assert len(ret) == 0

# Generated at 2022-06-23 12:00:34.807161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule, object)

# Generated at 2022-06-23 12:00:36.941900
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Test constructor of class LookupModule
    """
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-23 12:00:40.727275
# Unit test for constructor of class LookupModule
def test_LookupModule():
    if __name__ == '__main__':
        lookup_plugin = LookupModule()
        print("Loaded %s" % lookup_plugin)

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:00:51.881389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    hostname = "192.168.1.1"
    hostvars = {}
    hostvars[hostname] = {}
    hostvars[hostname]["group_names"] = ["group1", "group2"]
    hostvars[hostname]["groups"] = {}
    hostvars[hostname]["groups"]["group1"] = {}
    hostvars[hostname]["groups"]["group1"]["hosts"] = ["192.168.1.1", "192.168.1.2"]
    hostvars[hostname]["groups"]["group2"] = {}
    hostvars[hostname]["groups"]["group2"]["hosts"] = ["192.168.1.1", "192.168.1.3"]

# Generated at 2022-06-23 12:00:54.862666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    x = l.run([1,2,3,4,5])
    assert x in [1,2,3,4,5]

# Generated at 2022-06-23 12:00:59.028636
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Values to variables
    terms = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    # Create an instance of class LookupModule and test method run
    lookup_module_instance = LookupModule()
    assert lookup_module_instance.run(terms) in terms, "Random choice is not in the list"

# Generated at 2022-06-23 12:00:59.903219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:01:01.571604
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random.choice = lambda a: a[2]
    lm = LookupModule()
    assert ["3"] == lm.run([1,2,3])



# Generated at 2022-06-23 12:01:02.755797
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert isinstance(test, LookupModule)


# Generated at 2022-06-23 12:01:03.174254
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 1 == 1

# Generated at 2022-06-23 12:01:06.166926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['one', 'two', 'three']
  lookup_class_obj = LookupModule()
  result = lookup_class_obj.run(terms)
  print(result)

# Generated at 2022-06-23 12:01:08.306629
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ['abc', 'def']
    ret = lookup.run(terms)
    assert len(ret) == 1
    assert ret[0] in terms

# Generated at 2022-06-23 12:01:11.378589
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance.run([20,30,40]) == [30]

# Generated at 2022-06-23 12:01:13.208881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    result = m.run([1,2,3])
    assert len(result) == 1 # test that we got one item
    assert result[0] in [1,2,3] # test that we got one of the three values

# Generated at 2022-06-23 12:01:19.477556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Loads parameters to pass to method run
    random_choice_lookup = LookupModule()
    terms = [1, 2, 3]
    # Checks the result obtained calling method run
    assert terms[0] == random_choice_lookup.run(terms)[0] or terms[1] == random_choice_lookup.run(terms)[0] or terms[2] == random_choice_lookup.run(terms)[0]

# Generated at 2022-06-23 12:01:22.767922
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = ["test1", "test2", "test3"]
    result = lookup_module.run(terms=terms)
    assert result[0] in terms

# Generated at 2022-06-23 12:01:27.030604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create an instance of LookupModule
    lk = LookupModule()
    # Create a list of terms to give to run
    terms = [1, 2, 3 , 4, 5]
    # Randomly select one of the terms
    assert isinstance(lk.run(terms=terms), list)

# Generated at 2022-06-23 12:01:31.898820
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Initialization of class LookupModule
    lookup = LookupModule()

    # This is the test to check the return value of the method run
    terms = [1,5,3]
    assert lookup.run(terms) in terms
    terms = None
    assert lookup.run(terms) == []

# Generated at 2022-06-23 12:01:32.945401
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing")
    assert True

# Generated at 2022-06-23 12:01:37.268108
# Unit test for constructor of class LookupModule
def test_LookupModule():

    from ansible.plugins.lookup import LookupModule
    from ansible.plugins.loader import lookup_loader
    lookup_loader.add_directory('./lookup_plugins')

    lookup = LookupModule()
    res = lookup.run([1,2,3,4,5])
    assert len(res) == 1

# Generated at 2022-06-23 12:01:38.119709
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-23 12:01:45.483601
# Unit test for constructor of class LookupModule
def test_LookupModule():
  import unittest
  import ansible.plugins.lookup.random_choice
  class TestLookupModule(unittest.TestCase):
    def setUp(self):
      self.lm = ansible.plugins.lookup.random_choice.LookupModule()

    def test_run_returns_random_element_of_list(self):
      '''The run function should return an element of the list'''
      list = ['a','b','c']
      self.assertIn(self.lm.run(list), list)

    def test_run_returns_None_for_empty_list(self):
      '''The run function should return None for an empty list'''
      self.assertIsNone(self.lm.run([]))

  unittest.main()

# Generated at 2022-06-23 12:01:46.329531
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:01:53.140297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("")
    input_value = ['a', 'b', 'c', 'd']
    output_value = []
    output_value = LookupModule().run(input_value)
    if output_value in input_value:
        print("Result: PASS")
    else:
        print("Result: FAIL")

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 12:01:56.507749
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert lookup.run(terms=["ansible", "automates", "software", "infrastructure"], inject=None) == ["software"]

# Generated at 2022-06-23 12:02:05.357449
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Testing lookup_plugin param
    lookup_plugin = LookupModule()

    # Testing choice of a single element
    terms = ["test"]
    result = lookup_plugin.run(terms)
    assert result == ["test"]

    # Testing choice of three element
    terms = ["prova","test","finale"]
    result = lookup_plugin.run(terms)
    assert result in terms

    # Testing choice of list with one element
    terms = ["test"]
    result = lookup_plugin.run(terms)
    assert result in terms

    # Testing choice of list with two element
    terms = ["prova","test"]
    result = lookup_plugin.run(terms)
    assert result in terms

    # Testing choice of list with three element
    terms = ["prova","test","finale"]

# Generated at 2022-06-23 12:02:08.074583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_class = LookupModule()
    test_terms = ['a', 'b', 'c']
    assert module_class.run(test_terms) in test_terms

# Generated at 2022-06-23 12:02:09.064205
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:02:12.172525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random_choice = LookupModule()
    terms = ['Spam', 'Eggs', 'Bacon', 'Ham']
    result = random_choice.run(terms)
    assert(result in terms)

# Generated at 2022-06-23 12:02:16.998078
# Unit test for constructor of class LookupModule
def test_LookupModule():

  lookup = LookupModule()
  lookup.run(terms = ["a", "b", "c", "d"], inject = None)
  lookup.run(terms = [], inject = None)
  lookup.run(terms = ["a", "b", "c", "d"], inject = None, kwargs = {})

# Generated at 2022-06-23 12:02:18.992183
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

# Unit tests for run method of class LookupModule

# Generated at 2022-06-23 12:02:20.348969
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-23 12:02:26.130495
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test if LookupModule() constructor exists.
    log = LookupModule()
    # Test if LookupModule() constructor exists with params.
    log = LookupModule(module_name='module_name',
                       module_path='module_path',
                       class_name='class_name',
                       class_path='class_path',
                       collection_name='collection_name')
    # Test if LookupModule() constructor exists with Nones.
    log = LookupModule(module_name=None,
                       module_path=None,
                       class_name=None,
                       class_path=None,
                       collection_name=None)

# Generated at 2022-06-23 12:02:27.985234
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    test_random_choice = [5, 7, 9]
    random_choice = lm.run(terms=test_random_choice)
    assert random_choice == [5, 7, 9]

# Generated at 2022-06-23 12:02:29.953626
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-23 12:02:32.568583
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random_choice = LookupModule()
    assert random_choice is not None
    print ('Success: test_LookupModule')
 

# Generated at 2022-06-23 12:02:35.485207
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    # check if LookupModule object is created properly
    assert lookup_module is not None

# Unit tests for function run of class LookupModule

# Generated at 2022-06-23 12:02:37.665031
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    terms = ["foo", "bar"]
    assert module.run(terms) == random.choice(terms)

# Generated at 2022-06-23 12:02:44.174562
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    import collections

    # Create a list of test items
    terms = ['cattle', 'chicken', 'sparrow', 'owl']

    # Create an instance of LookupModule
    lookup_plugin = LookupModule()

    # The result of run() method should be a list
    result = lookup_plugin.run(terms)
    assert(isinstance(result, collections.Iterable))

    # The result list should contain only one element
    assert(len(result) == 1)

    # The one element in the result list should be a string
    assert(isinstance(result[0], str))

    # The result element should be one of the original elements
    assert(result[0] in terms)

# Generated at 2022-06-23 12:02:50.161135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create the module object
    l = LookupModule()
    # Check for expected output for list of elements
    assert l.run(["apple", "banana"]) == ["apple"]
    assert l.run([1, 2, 3, 4, 5]) == [3]
    # Empty list
    assert l.run([]) == []
    # String
    assert l.run("apple") == ["apple"]

# Generated at 2022-06-23 12:02:50.777155
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-23 12:02:52.457049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run([1])
    assert result == [1]

# Generated at 2022-06-23 12:02:54.406179
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Test the constructor of class LookupModule
    '''
    assert LookupModule()

# Generated at 2022-06-23 12:02:55.789144
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run([]) # no-op

# Generated at 2022-06-23 12:02:57.255691
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random_choice = LookupModule()
    assert random_choice

# Generated at 2022-06-23 12:02:58.820601
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(callable(LookupModule))


# Generated at 2022-06-23 12:03:00.165381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        LookupModule()
    except Exception as e:
        assert(False)

# Generated at 2022-06-23 12:03:01.512674
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert callable(LookupModule)

# Generated at 2022-06-23 12:03:02.464494
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test is not None

# Generated at 2022-06-23 12:03:06.866315
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    loader = DictDataLoader({})
    variable_manager = VariableManager(loader=loader)
    variable_manager.extra_vars = {'ansible_verbosity': 2}
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    rand = LookupModule()
    terms = ['first', 'second', 'third']
    result = rand.run(terms, inject=None)
    assert result[0] in terms


# Generated at 2022-06-23 12:03:11.163484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup._loader = None
    lookup._templar = None
    lookup._display = None
    result = lookup.run(["I", "II", "III", "III", "IV"])
    assert(len(result)) == 1

# Generated at 2022-06-23 12:03:12.602366
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()
    assert lookup_mod is not None

# Generated at 2022-06-23 12:03:20.913896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # import required modules
    import sys
    # import the LookupModule class
    sys.path.insert(0, '../')
    LookupModule = __import__('LookupModule').LookupModule
    # create the LookupModule object
    lookupModule = LookupModule()
    # test a random choice
    assert lookupModule.run([1, 2, 3]) == [2]
    # test a random choice
    assert lookupModule.run([1, 2, 3]) == [2]
    # test a random choice
    assert lookupModule.run([1, 2, 3]) == [2]

# Generated at 2022-06-23 12:03:29.374805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    random.seed(0)
    lookup = LookupModule()

    # test one element
    list = ["test"]
    results = lookup.run(list)
    assert len(results) == 1
    assert results[0] == "test"

    # test two elements, one should be returned, the other not
    list = ["test1", "test2"]
    results = lookup.run(list)
    assert len(results) == 1
    assert results[0] == "test2"

    list = ["test1", "test2"]
    results = lookup.run(list)
    assert len(results) == 1
    assert results[0] == "test2"

    # test empty list, should produce an empty list as well
    list = []
    results = lookup.run(list)
    assert len(results) == 0

   

# Generated at 2022-06-23 12:03:32.036972
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    test_terms = ["I", "am", "a", "test"]
    assert(lookup_plugin.run(test_terms) in test_terms)

# Generated at 2022-06-23 12:03:36.253400
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['A','B','C']

    random.seed(0)
    assert len(terms) == 3
    print("terms = {}".format(terms))
    lm = LookupModule()
    ret = lm.run(terms, inject=None)
    assert len(ret) == 1
    print("ret = {}".format(ret))
    assert ret[0] == 'B'

# Generated at 2022-06-23 12:03:37.428127
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(None, None), LookupModule)



# Generated at 2022-06-23 12:03:46.873327
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    terms = [
  "The greatest glory in living lies not in never falling, but in rising every time we fall.",
  "The way to get started is to quit talking and begin doing.",
  "Your time is limited, so don't waste it living someone else's life. Don't be trapped by dogma – which is living with the results of other people's thinking.",
  "If life were predictable it would cease to be life, and be without flavor.",
  "If you look at what you have in life, you'll always have more. If you look at what you don't have in life, you'll never have enough.",
  "If you set your goals ridiculously high and it's a failure, you will fail above everyone else's success.",
  "Life is what happens when you're busy making other plans."
]

# Generated at 2022-06-23 12:03:47.306470
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 12:03:48.856401
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_LookupModule = LookupModule()



# Generated at 2022-06-23 12:03:49.777412
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 12:03:55.665733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Test run method of LookupModule class."""
    lookupmod = LookupModule()

    # test return value when terms provided
    assert lookupmod.run(terms=["ansible@ansible.com", "test@test.com"], inject={}, **dict()) == list(["test@test.com"])

    # test return value when terms not provided
    assert lookupmod.run(terms=None, inject={}, **dict()) == list()

# Generated at 2022-06-23 12:03:59.040891
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import ansible.plugins.lookup.random_choice
    x = ansible.plugins.lookup.random_choice.LookupModule()
    assert isinstance(x, ansible.plugins.lookup.random_choice.LookupModule)

# Generated at 2022-06-23 12:04:02.086608
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ja = LookupModule()
    assert ja.run(terms=['a', 'b']) in [['a'], ['b']]

# Generated at 2022-06-23 12:04:03.827429
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    lookup_module.run("sample")

# Generated at 2022-06-23 12:04:08.259180
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing class LookupModule')
    lookup_module = LookupModule()
    # TODO: This test needs to be improved
    print('Test successful!')

if __name__ == '__main__':
    # Test for class LookupModule
    test_LookupModule()

# Generated at 2022-06-23 12:04:09.565337
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random_choice = LookupModule()
    print(random_choice)

# Generated at 2022-06-23 12:04:12.298443
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        assert isinstance(LookupModule, object)
    except AssertionError as e:
        print("AnsibleError:",e)


# Generated at 2022-06-23 12:04:17.694730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run([])
    assert ret == []
    assert len(ret) == 0

    ret = LookupModule().run([1,2,3,4])
    assert ret[0] in [1,2,3,4]

    ret = LookupModule().run([1,2,3,4,5])
    assert ret[0] in [1,2,3,4,5]

# Generated at 2022-06-23 12:04:18.748408
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 12:04:23.988287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [
        "a", "b", "c", "d", "e"
    ]
    result = lookup.run(terms)
    assert type(result) is list
    assert result != []
    assert len(result) == 1
    assert result[0] in terms, "The returned value is not part of the supplied term"

# Generated at 2022-06-23 12:04:32.939295
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # example1:
    # run(terms, variables=None, **kwargs)
    # 
    # example2:
    # run(terms, inject, **kwargs)
    # 
    # example3:
    # run(terms, inject=None, **kwargs)
    # 
    # example4:
    # run(terms, inject=None, basedir='/foo/bar')
    # 
    # example5:
    # run(terms, inject=None, basedir='/foo/bar', variables=dict())
    
    
    module = LookupModule()
    
    
    
    
    module.run("foo")
    module.run("foo", inject=object())
    module.run("foo", inject=object(), basedir="foo")
    
    
    
    
    
    

# Generated at 2022-06-23 12:04:33.650283
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None

# Generated at 2022-06-23 12:04:34.827154
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-23 12:04:36.282396
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ test_LookupModule - constructor test """
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 12:04:37.566320
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run("test")

# Generated at 2022-06-23 12:04:38.613323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lk = LookupModule()

# Generated at 2022-06-23 12:04:39.429134
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None

# Generated at 2022-06-23 12:04:47.763510
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lm = LookupModule()
    terms = []

    terms = lm.run([['red', 'green', 'blue']])
    assert terms != []

    # test for an empty list in terms
    terms = lm.run([])
    assert terms == []

    # test for AnsibleError in case of an exception in random.choice
    # see https://stackoverflow.com/questions/2055862/random-choice-from-list-containing-objects-throws-typeerror
    terms = lm.run([[1, 'a']])
    assert terms == None

# Generated at 2022-06-23 12:04:56.793709
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()

    terms = []
    ret = lookup_plugin.run(terms)
    assert len(ret) == 0

    terms = ["First", "Second"]
    ret = lookup_plugin.run(terms)
    assert len(ret) == 1
    assert ret[0] == "First" or ret[0] == "Second"

    # Test with a non-iterable term
    terms = ["First", 1]
    try:
        lookup_plugin.run(terms)
        assert False, "Unable to choose random term"
    except Exception as e:
        # First element is "Unable to choose random term: "
        assert "['First', 1]" == e.message.split(": ")[1]

# Generated at 2022-06-23 12:04:57.409229
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-23 12:05:04.615721
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Declare dummy variables
    dummy_terms = ["item1", "item2", "item3"]
    dummy_inject = None
    dummy_kwargs = None

    # Create mock class
    lookup_module = LookupModule()
    
    # Run method
    results = lookup_module.run(dummy_terms, dummy_inject, dummy_kwargs)

    # Check results
    assert(len(results) == 1)
    assert(results[0] in dummy_terms)

# Generated at 2022-06-23 12:05:07.030294
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["one", "two", "three"]
    for i in range (1,10):
        term = LookupModule().run(terms)
        assert term in terms

# Generated at 2022-06-23 12:05:09.355906
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = [True, True, True]
    lookup_module = LookupModule()
    ret = lookup_module.run(terms=ret, inject={})
    ret[0] = ret[0] == True
    return ret

test = test_LookupModule_run()

# Generated at 2022-06-23 12:05:13.157142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo', 'bar']
    test_lookup_module = LookupModule()
    test_result = test_lookup_module.run(terms)
    assert (test_result[0] in terms)

# Generated at 2022-06-23 12:05:15.499195
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()
    assert test.get_basedir() == None


# Generated at 2022-06-23 12:05:19.023872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    terms = ['a', 'b']

    # Exercise
    result = LookupModule().run(terms, inject=None, **{})

    # Verify
    assert isinstance(result, list)
    assert len(result) == 1
    assert result[0] in terms

# Generated at 2022-06-23 12:05:27.434673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import unittest
    import tempfile

    class TestLookupModule(unittest.TestCase):
        def setUp(self):
            self.t = tempfile.mkstemp()

        def tearDown(self):
            os.remove(self.t[1])

    class TestLookupModuleFile(TestLookupModule):
        def runTest(self):
            options = {}
            l = LookupModule()
            l.get_basedir = lambda x: x[0]
            L = l.run([["test_data",]])
            # Will return all content from the file
            # - the one line, without any line-break
            self.assertEqual("this is a test\n", L[0])

    # An empty file, shall return empty list

# Generated at 2022-06-23 12:05:28.744222
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()


# Generated at 2022-06-23 12:05:32.093640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.random_choice import LookupModule
    
    lookup = LookupModule()
    
    assert [4] == lookup.run([4, 5, 6])
    assert [4] == lookup.run([4])
    assert [] == lookup.run([])

# Generated at 2022-06-23 12:05:33.965192
# Unit test for constructor of class LookupModule
def test_LookupModule():
      terms=[2, 3, 4]
      lookup_structure = LookupModule()
      assert len(lookup_structure.run(terms)) == 1

# Generated at 2022-06-23 12:05:40.288102
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    assert isinstance(lookup_plugin, LookupModule)

    # test 1
    ret = lookup_plugin.run([])
    assert isinstance(ret, list)
    assert 0 == len(ret)

    # test 2
    ret = lookup_plugin.run(["one", "two"])
    assert isinstance(ret, list)
    assert 1 == len(ret)
    assert ret[0] in ["one", "two"]

    # test 3
    ret = lookup_plugin.run(["one", "two"], inject={})
    assert isinstance(ret, list)
    assert 1 == len(ret)
    assert ret[0] in ["one", "two"]


# Generated at 2022-06-23 12:05:42.998803
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random_choice_lookup_module = LookupModule()
    assert random_choice_lookup_module is not None

# Generated at 2022-06-23 12:05:44.146400
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 12:05:51.869308
# Unit test for constructor of class LookupModule
def test_LookupModule():
  import random
  lookup = LookupModule()
  testTerms = [
    "go through the door",
    "drink from the goblet",
    "press the red button",
    "do nothing"
  ]
  # check that terms returns the given terms
  assert lookup.run(testTerms) == testTerms
  # check that terms returns the given term, a list
  assert lookup.run([testTerms[0]]) == [testTerms[0]]
  # check that terms throws an error when given invalid parameter
  try:
    lookup.run(1)
  except AnsibleError:
    assert True
  else:
    assert False

# Generated at 2022-06-23 12:05:54.628471
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    data = ['a', 'b', 'c', 'd']
    lookup_module.run(data)

# Generated at 2022-06-23 12:06:06.255836
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for "run" method that return a list of string type items
    terms = ["apple", "banana", "orange"]
    t_ansible_module_utils_text_to_native = 'to_native'
    t_ansible_errors_AnsibleError = 'AnsibleError'
    t_ansible_plugins_lookup_LookupBase = 'LookupBase'
    import sys, unittest
    sys.modules['ansible'] = unittest.mock.MagicMock()
    sys.modules['ansible.errors'] = unittest.mock.MagicMock()
    sys.modules['ansible.module_utils._text'] = unittest.mock.MagicMock()

# Generated at 2022-06-23 12:06:13.787056
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    num_call = 0
    def mock_choice(x):
        nonlocal num_call
        num_call += 1
        return x[0]

    random.choice = mock_choice
    terms = ["1","2","3"]
    expected_value = ["1"]
    # Act
    lm = LookupModule()
    actual_value = lm.run(terms)
    # Assert
    assert num_call == 1
    assert actual_value == expected_value


# Generated at 2022-06-23 12:06:25.237296
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import unittest2 as unittest
    from ansible.playbook.play_context import PlayContext

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self._terms = ["foo", "bar", "baz"]
            self._lookup_plugin = LookupModule()

        def tearDown(self):
            del self._lookup_plugin

        def test_run_returns_list(self):
            """make sure it returns a list"""
            ret = self._lookup_plugin.run(terms=self._terms)
            self.assertEqual(type(ret), list)

        def test_run_returns_one_item(self):
            """make sure it returns a list of one item"""
            ret = self._lookup_plugin.run(terms=self._terms)

# Generated at 2022-06-23 12:06:27.627414
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_class = LookupModule('')
    assert (lookup_class != None), "Failed to instantiate the LookupModule class"

# Generated at 2022-06-23 12:06:30.833540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = ["1", "2", "3"]
    ansible_result = lookup.run(terms=terms)
    assert ansible_result in terms

# Generated at 2022-06-23 12:06:33.215226
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global LookupModule
    lookup_module = LookupModule()

# Generated at 2022-06-23 12:06:39.139697
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a new instance of class LookupModule
    lookup_module = LookupModule()

    terms = ["Each keyword argument should be the name of a parameter",
             "All the parameters should be in lower case",
             "The value of each parameter should be the value of the corresponding argument."]
    expected_terms = [terms[1]]

    # Make a call to the method run of class LookupModule
    assert lookup_module.run(terms) == expected_terms

# Generated at 2022-06-23 12:06:40.057649
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:06:42.244848
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lookup = LookupModule()
    except Exception as e:
        raise AssertionError("Failed to instantiate LookupModule: %s" % to_native(e))

# Generated at 2022-06-23 12:06:43.279945
# Unit test for constructor of class LookupModule
def test_LookupModule():
  assert LookupModule.run([1,2,3]) != None

# Generated at 2022-06-23 12:06:43.877244
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-23 12:06:49.976253
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Test without entries in list
    ret = lookup_module.run(terms=[], inject={}, **{})
    assert ret == []

    # Test with entries in list
    ret = lookup_module.run(terms=['horse', 'donkey', 'cat'], inject={}, **{})
    assert ret == ['horse'], "unexpected random choice: %s" % ret

# Generated at 2022-06-23 12:06:53.788778
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_instance = LookupModule()
    assert isinstance(test_instance, LookupModule)
    assert len(test_instance.run(terms=['a', 'b', 'c'], inject=None)) == 1

# Generated at 2022-06-23 12:06:55.202344
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule() != None
    assert LookupModule() != ''

# Generated at 2022-06-23 12:07:01.084926
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test_module = LookupModule()
    assert test_module
    assert test_module.run([1]) == [1]
    assert test_module.run(["a"]) == ['a']
    assert test_module.run(["a", "b"]) in (["a"], ["b"])
    assert test_module.run(["a", "b"], test_module="a", test_module_2="b") in (["a"], ["b"])

    result = test_module.run([1, 2, 3])
    assert result in ([1], [2], [3])

# Generated at 2022-06-23 12:07:07.498589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # mock the input value
    terms = ["go through the door", "drink from the goblet", "press the red button", "do nothing"]
    lookup = LookupModule()
    # call function run of class LookupModule
    ret = lookup.run(terms)
    # test the equality
    assert (ret == ["go through the door"]) or (ret == ["drink from the goblet"]) or (ret == ["press the red button"]) or (ret == ["do nothing"])

# Generated at 2022-06-23 12:07:11.645708
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    print(lm)
    assert lm
    assert lm.run
    assert lm.run(["a", "b", "c"])
    assert lm.run([])
    assert lm.run(["a"])

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-23 12:07:12.899297
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:07:24.549150
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError

    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)
    try:
        lookup.run(terms=[])
    except Exception as e:
        assert isinstance(e, AnsibleError)
    else:
        raise RuntimeError('Expected an exception to be raised')
    try:
        lookup.run(['one', 'two', 'three'], inject={}, **{'wantlist': True})
    except Exception as e:
        assert isinstance(e, AnsibleError)

# Generated at 2022-06-23 12:07:29.563037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def random_choice_mock(seq):
        return 'choose me'

    lm = LookupModule()
    random.choice = random_choice_mock
    terms = ['a', 'b', 'c']
    assert lm.run(terms=terms) == ['choose me']

# Generated at 2022-06-23 12:07:30.999770
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:07:32.579307
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert type(x) == LookupModule

# Generated at 2022-06-23 12:07:34.181242
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupModule = LookupModule()
    assert lookupModule is not None

# Generated at 2022-06-23 12:07:37.950429
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lk = LookupModule()
  terms = [0, 1, 2, 3, 4, 5, 6, 7]
  ret = lk.run(terms)
  assert ret[0] in terms
  assert len(ret) == 1

# Generated at 2022-06-23 12:07:43.627174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        "go through the door",
        "drink from the goblet",
        "press the red button",
        "do nothing"
    ]
    assert len(terms) == 4
    result = LookupModule().run(terms)
    assert len(result) == 1
    assert result[0] in terms

# Generated at 2022-06-23 12:07:44.555271
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 12:07:48.893260
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    value = ["term1", "term2", "term3"]
    lookup_module = LookupModule()
    # run random choose on list of three elements
    random_choose = lookup_module.run(terms=value)
    assert isinstance(value, list)
    assert len(random_choose) == 1
    assert random_choose[0] in value
    # return list if run on empty list
    empty = lookup_module.run(terms=[])
    assert isinstance(empty, list)
    assert not empty

# Generated at 2022-06-23 12:07:51.301081
# Unit test for constructor of class LookupModule
def test_LookupModule():

    t_lookup_module = LookupModule()
    t_lookup_module.lookup("ABC")

# Generated at 2022-06-23 12:07:59.273210
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_dict = {
        'lookup_dict': {
            '_ansible_tmpdir': '/tmp/ansible-tmp-1525091746.33-246416231676414',
            '_ansible_no_log': False
        },
        'lookup_terms': [
            "go through the door",
            "drink from the goblet",
            "press the red button",
            "do nothing"
        ]
    }

    # Test LookupModule class exists
    assert Callable(LookupModule)

    # Test LookupModule class runs
    assert LookupModule(**lookup_dict).run(**lookup_dict)

# Generated at 2022-06-23 12:08:00.457578
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.run(['1','2','3'])


# Generated at 2022-06-23 12:08:00.885809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 12:08:09.653420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    t = []
    t.append('one')
    t.append('two')
    t.append('three')
    t.append('four')

    lm = LookupModule()
    # Test with all parameters
    ret = lm.run(t, inject=None, **kwargs)
    # Test with all parameters + kwargs
    ret = lm.run(t, inject=None)
    # Test with missing parameters
    ret = lm.run(t)

    # Test with empty terms
    ret = lm.run([])
    # Test with null terms
    ret = lm.run(None)

# Generated at 2022-06-23 12:08:14.479053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    test_module = LookupModule()

    # Tests case where array of terms are given
    test_terms = ['a', 'b', 'c']
    assert test_module.run(test_terms) in test_terms

    # Tests case where no terms are given
    assert test_module.run(None) is None


# Generated at 2022-06-23 12:08:22.479405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This is a Unit test of LookupModule.run method for Ansible return of a list.
    """
    terms = [
        "go through the door",
        "drink from the goblet",
        "press the red button"
    ]

    # Instantiate the LookupModule class
    lookup_instance = LookupModule()

    # Call the run method to execute the Ansible code
    result = lookup_instance.run(terms)

    # Assert that the result is one of the expected list
    assert result[0] in terms



# Generated at 2022-06-23 12:08:24.559738
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test1 = LookupModule()
    assert_equals(type(test1), LookupModule)


# Generated at 2022-06-23 12:08:31.352462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test pulled from examples in documentation
    args = [["go through the door", "drink from the goblet", "press the red button", "do nothing"]]
    lm = LookupModule()
    result = lm.run(terms=args[0])

    # Assert single item in list
    assert len(result) == 1

    # Assert that resulting item is a member of the original list
    assert result[0] in args[0]

# Generated at 2022-06-23 12:08:35.475521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.plugins.lookup.random
    print("Testing random_choice lookup plugin")
    terms = [1,2,3,4,5]
    lookup_plugin = ansible.plugins.lookup.random.LookupModule()
    result = lookup_plugin.run(terms, None)
    assert result in terms

# Generated at 2022-06-23 12:08:40.840891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['go through the door', 'drink from the goblet', 'press the red button', 'do nothing']
    ret = module.run(terms = terms)
    assert terms == ret or [ret] == terms
    terms = ['aaa', 'bbb', 'ccc']
    ret = module.run(terms = terms)
    assert terms == ret or [ret] == terms

# Generated at 2022-06-23 12:08:45.787205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_object = LookupModule()
    assert test_object.run(['some', 'list']) == ['some', 'list']
    assert test_object.run(['some', 'list', 'haha']) == ['some', 'list', 'haha']
    assert test_object.run(['some', 'list', 'haha', 'hoho']) == ['some', 'list', 'haha', 'hoho']

# Generated at 2022-06-23 12:08:47.764844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert ["en"] == lookup.run(["en", "de"])

# Generated at 2022-06-23 12:08:48.828096
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert (LookupModule)

# Generated at 2022-06-23 12:08:54.744673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ["term1", "term2", "term3"]
    # Test with valid terms
    lookup_obj = LookupModule()
    result = lookup_obj.run(terms=terms)
    assert(result in terms)
    # Test with empty terms
    lookup_obj = LookupModule()
    result = lookup_obj.run(terms=[])
    assert(result == [])

# Generated at 2022-06-23 12:08:58.396160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create empty instance of LookupModule
    l = LookupModule()
    # run method example 1
    l.run([])
    # run method example 2
    l.run([1,2,3,4,5])

# Generated at 2022-06-23 12:08:59.890746
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert 'random_choice' == LookupModule().run(['random_choice'],None)

# Generated at 2022-06-23 12:09:01.222938
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin


# Generated at 2022-06-23 12:09:08.754296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()

    # Test that it returns the first item in a list if there is only one
    assert lookup_instance.run(["item"]) == ["item"]

    # Retest that it returns the first item in a list if there is only one; this time using the ternary operator
    assert lookup_instance.run(["item"]) == ["item"] if True else ["Not Item"]

# Generated at 2022-06-23 12:09:16.682296
# Unit test for constructor of class LookupModule
def test_LookupModule():
    random.seed(1)
    lu = LookupModule()
    assert lu, "Creating an empty LookupModule should succeed"
    assert lu.run([1,2,3]) == [1], "First run succeeds"
    assert lu.run([1,2,3]) == [3], "Second run succeeds"
    assert lu.run([1,2,3]) == [2], "Third run succeeds"
    try:
        lu.run([])
    except AnsibleError:
        pass
    else:
        assert False, "Empty list should not succeed"

# Generated at 2022-06-23 12:09:26.687336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import random
    import mock
    import collections
    import ansible
    test_ob = mock.Mock()
    test_ob_list = [test_ob] * 4
    test_ob_str = collections.defaultdict(str, test_ob=test_ob)
    test_ob_int = collections.defaultdict(int, test_ob=test_ob)
    test_ob_dict = collections.defaultdict(dict, test_ob=test_ob)

    # expected outcome: list containing one element from the list
    with mock.patch.object(random, 'choice', return_value=test_ob) as mock_rand_choice:
        assert LookupModule().run(test_ob_list) == [test_ob]
    assert mock_rand_choice.call_count == 1

    # expected outcome: str from the dict


# Generated at 2022-06-23 12:09:30.746809
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ['one', 'two', 'three']
    lookup_obj = LookupModule()
    assert len(lookup_obj.run(terms)) == 1
    assert len(lookup_obj.run([])) == 0
    # It does not have an inject kwarg
    assert lookup_obj.run(terms) != lookup_obj.run(terms, inject={'foo': 'bar'})

# Generated at 2022-06-23 12:09:41.834854
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import sys
    import os
    from copy import copy

    sys.path.append(os.path.join(os.path.dirname(os.path.realpath(__file__)), u'..'))

    from ansible.plugins.lookup.random_choice import LookupModule

    lm = LookupModule()
    lookup_list = [u'a', u'b', u'c', u'd']
    my_list = copy(lookup_list)
    result = lm.run(terms=lookup_list)
    my_list.remove(result[0])
    assert result[0] in lookup_list
    assert result[0] not in my_list
    assert len(result) == 1

    result = lm.run(terms=[])
    assert result == []


# Generated at 2022-06-23 12:09:47.039871
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    terms = [1,2,3,4,5,6]