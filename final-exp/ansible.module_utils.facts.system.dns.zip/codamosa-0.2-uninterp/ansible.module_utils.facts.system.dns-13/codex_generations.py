

# Generated at 2022-06-17 02:06:05.804889
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:17.853885
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:06:25.262726
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:06:32.804169
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24', '192.168.2.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'

# Generated at 2022-06-17 02:06:42.847946
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1', '192.168.1.2']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:06:52.358390
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:07:01.758642
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1', '192.168.1.2']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:07:13.396432
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:07:17.147751
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:21.750031
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:37.530394
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1', '192.168.1.2']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:07:41.035467
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:43.349498
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:51.187895
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:08:01.146996
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:08:06.223149
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:08:10.469660
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:08:19.538494
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:08:22.333851
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:08:26.271177
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:08:48.146036
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:08:58.337289
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:09:05.960879
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:09:08.104280
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:12.932046
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:18.147063
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:09:27.730349
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:09:30.207144
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:41.803441
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    dns_facts = dns_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:09:51.788240
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.0.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:10:29.544210
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:31.975140
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:40.322543
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:10:51.039447
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:10:55.378744
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:58.350827
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:11:06.631564
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:11:16.140293
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:11:27.525238
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:11:31.515062
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'

# Generated at 2022-06-17 02:13:00.143242
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'

# Generated at 2022-06-17 02:13:05.296067
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:13:10.386234
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:13:18.175527
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'][0] == '192.168.1.1'
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'][0] == 'example.com'
    assert dns_facts['dns']['sortlist'][0] == '192.168.1.0/255.255.255.0'
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts

# Generated at 2022-06-17 02:13:26.752947
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.system.dns import DnsFactCollector
    from ansible.module_utils.facts.system.dns import test_DnsFactCollector_collect
    from ansible.module_utils.facts.system.dns import test_DnsFactCollector_collect_nameservers
    from ansible.module_utils.facts.system.dns import test_DnsFactCollector_collect_domain
    from ansible.module_utils.facts.system.dns import test_DnsFactCollector_collect_search
    from ansible.module_utils.facts.system.dns import test_DnsFactCollector_collect_sortlist
   

# Generated at 2022-06-17 02:13:35.364004
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    dns_facts = dns_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:13:41.169888
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:13:49.111779
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8', '192.168.0.0/16']
    assert dns_facts['dns']['options']['timeout'] == '2'

# Generated at 2022-06-17 02:13:55.058688
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:14:00.521135
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:15:39.044915
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:15:41.185061
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:15:45.633954
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:15:50.857389
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:15:56.983850
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True