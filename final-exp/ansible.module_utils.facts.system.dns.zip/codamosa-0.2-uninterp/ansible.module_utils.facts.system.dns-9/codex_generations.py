

# Generated at 2022-06-17 02:06:12.387931
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/255.0.0.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert dns_facts

# Generated at 2022-06-17 02:06:21.798717
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:06:27.524837
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:38.934826
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1', '192.168.1.2']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'
    assert dns_facts['dns']['options']['rotate']

# Generated at 2022-06-17 02:06:47.917124
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.0.1', '10.0.0.2']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:06:55.418051
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1', '192.168.1.2']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:06:58.161734
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:03.169396
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:13.040486
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['127.0.0.1']
    assert dns_facts['dns']['domain'] == 'localdomain'
    assert dns_facts['dns']['search'] == ['localdomain']
    assert dns_facts['dns']['sortlist'] == []
    assert dns_facts['dns']['options'] == {'ndots': '1'}

# Generated at 2022-06-17 02:07:15.050017
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:07:33.233307
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:37.668048
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:45.161188
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1', '192.168.1.2']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:07:47.531387
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:58.443357
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:08:07.375769
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:08:11.191403
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:08:16.889526
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns'] == {'nameservers': ['192.168.1.1'], 'domain': 'example.com', 'search': ['example.com'], 'sortlist': ['192.168.1.0/24'], 'options': {'timeout': '2', 'attempts': '3'}}

# Generated at 2022-06-17 02:08:27.533495
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:08:31.425539
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:09:16.308322
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:09:21.951208
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:09:31.646476
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:09:34.749634
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:40.037284
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:46.099996
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:50.365824
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:01.234798
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.0.1', '192.168.0.2']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.0.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:10:13.833734
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.2.3']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'redhat.com']
    assert dns_facts['dns']['sortlist'] == ['10.0.2.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'
    assert dns_facts['dns']['options']['rotate'] == True
    assert dns_

# Generated at 2022-06-17 02:10:19.491771
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:11:43.764912
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:11:55.350406
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.0.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:12:04.580210
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:12:11.824005
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:12:14.391093
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:12:22.140946
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['127.0.0.1']
    assert dns_facts['dns']['domain'] == 'localdomain'
    assert dns_facts['dns']['search'] == ['localdomain']
    assert dns_facts['dns']['sortlist'] == []
    assert dns_facts['dns']['options'] == {'timeout': '2', 'attempts': '1'}

# Generated at 2022-06-17 02:12:32.860882
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:12:40.093487
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.2.3']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.2.3']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '4'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:12:50.118173
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options'] == {'timeout': '2', 'attempts': '1'}

# Generated at 2022-06-17 02:12:53.253658
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:15:40.451781
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:15:50.870634
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:15:56.833276
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
