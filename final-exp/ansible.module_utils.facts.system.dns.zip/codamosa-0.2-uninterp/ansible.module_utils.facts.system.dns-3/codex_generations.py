

# Generated at 2022-06-17 02:06:06.933415
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']

# Generated at 2022-06-17 02:06:15.832499
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:06:24.070851
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:06:29.453154
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:06:32.439705
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:36.432093
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:39.448217
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:42.170200
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:51.747953
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    dns_facts = dns_collector.collect()
    assert dns_facts['dns']['nameservers'][0] == '192.168.1.1'
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'][0] == 'example.com'
    assert dns_facts['dns']['sortlist'][0] == '192.168.1.0/255.255.255.0'
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:06:58.704943
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.0.1', '10.0.0.2']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:07:22.753545
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:07:25.492832
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:35.671909
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:07:44.590959
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:07:46.894173
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:07:49.417228
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:07:52.317760
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:07:55.454862
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:08:04.696588
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.0.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:08:14.456364
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8', '192.168.0.0/16']
    assert dns_facts['dns']['options']['timeout'] == '2'

# Generated at 2022-06-17 02:08:58.496847
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8', '192.168.0.0/16']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_

# Generated at 2022-06-17 02:09:06.070724
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:09:12.754250
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8', '192.168.0.0/16']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '4'

# Generated at 2022-06-17 02:09:21.785083
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:09:32.674031
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.system.dns import DnsFactCollector

    # Create a new instance of DnsFactCollector
    dns_fact_collector = DnsFactCollector()

    # Create a new instance of FactsCollector
    facts_collector = FactsCollector()

    # Add the instance of DnsFactCollector to the list of fact collectors
    # of FactsCollector
    facts_collector._fact_collectors.append(dns_fact_collector)

    # Create a new instance of AnsibleModule
    from ansible.module_utils.facts import AnsibleModule

# Generated at 2022-06-17 02:09:35.648244
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:40.791241
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:51.739782
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8', '192.168.0.0/16']
    assert dns_facts['dns']['options']['timeout'] == '2'

# Generated at 2022-06-17 02:09:56.258695
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:03.776937
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:11:27.388476
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:11:35.308208
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts == {
        'dns': {
            'nameservers': ['192.168.1.1'],
            'domain': 'example.com',
            'search': ['example.com', 'example.org'],
            'sortlist': ['192.168.1.0/24'],
            'options': {
                'ndots': '2',
                'timeout': '1',
                'attempts': '2',
            }
        }
    }

# Generated at 2022-06-17 02:11:38.312115
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:11:42.886000
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:11:49.383634
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:11:52.351746
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:11:54.596322
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:11:56.593885
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:12:01.343903
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:12:06.443253
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:14:57.936971
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:15:02.478675
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:15:07.681761
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:15:17.729770
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.2.3']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'sub.example.com']
    assert dns_facts['dns']['sortlist'] == ['10.0.2.3']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '4'

# Generated at 2022-06-17 02:15:29.338950
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24', '192.168.2.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'

# Generated at 2022-06-17 02:15:37.047976
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8', '192.168.0.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:15:40.369997
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:15:45.101596
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:15:49.253599
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:15:52.436836
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()