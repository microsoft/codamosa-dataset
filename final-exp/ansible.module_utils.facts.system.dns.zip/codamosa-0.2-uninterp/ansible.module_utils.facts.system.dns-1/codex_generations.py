

# Generated at 2022-06-17 02:06:12.786407
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.0.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'sub.example.com']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '4'

# Generated at 2022-06-17 02:06:15.533184
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:18.364175
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:20.348427
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'

# Generated at 2022-06-17 02:06:26.371822
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.56.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:06:28.713791
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:31.762508
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:06:34.480370
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:06:37.672469
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:40.844299
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:07:02.997219
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:14.251182
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:07:23.045022
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:07:30.571862
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:07:37.810597
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:07:45.253799
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
   

# Generated at 2022-06-17 02:07:55.264114
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24', '10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'

# Generated at 2022-06-17 02:07:58.587062
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:08:07.376415
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    dns_facts = dns_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:08:09.374922
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:08:31.710194
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:08:41.219058
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:08:52.589921
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.0.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/255.0.0.0']
    assert dns_facts['dns']['options']['ndots'] == '1'
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns

# Generated at 2022-06-17 02:08:59.409751
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:09:02.313186
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:08.102473
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:09.877557
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:09:15.923740
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert 'dns' in dns_facts
    assert 'nameservers' in dns_facts['dns']
    assert 'domain' in dns_facts['dns']
    assert 'search' in dns_facts['dns']
    assert 'sortlist' in dns_facts['dns']
    assert 'options' in dns_facts['dns']

# Generated at 2022-06-17 02:09:26.824630
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '4'

# Generated at 2022-06-17 02:09:29.257791
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:12.353624
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:17.412781
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:19.752027
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:30.187729
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:10:38.216378
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert 'dns' in dns_facts
    assert 'nameservers' in dns_facts['dns']
    assert 'domain' in dns_facts['dns']
    assert 'search' in dns_facts['dns']
    assert 'sortlist' in dns_facts['dns']
    assert 'options' in dns_facts['dns']

# Generated at 2022-06-17 02:10:41.127285
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:49.270691
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert 'dns' in dns_facts
    assert 'nameservers' in dns_facts['dns']
    assert 'domain' in dns_facts['dns']
    assert 'search' in dns_facts['dns']
    assert 'sortlist' in dns_facts['dns']
    assert 'options' in dns_facts['dns']

# Generated at 2022-06-17 02:10:55.265851
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:11:02.747116
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['10.0.2.3']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'somewhere.com']
    assert dns_facts['dns']['sortlist'] == ['10.0.2.3']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:11:06.926802
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:12:41.427321
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8', '192.168.0.0/16']
    assert dns_facts['dns']['options']['timeout'] == '2'

# Generated at 2022-06-17 02:12:46.606435
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:12:48.950327
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:12:53.150652
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:12:55.478002
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:13:04.110932
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
   

# Generated at 2022-06-17 02:13:09.662380
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:13:17.996879
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:13:26.665696
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:13:29.350423
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()
