

# Generated at 2022-06-17 02:06:13.648505
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:06:22.617559
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '4'

# Generated at 2022-06-17 02:06:27.594345
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:34.073387
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/255.0.0.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
   

# Generated at 2022-06-17 02:06:37.904931
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:06:47.088239
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1', '192.168.1.2']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:06:49.399007
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:06:56.677269
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Test if method list_collectors returns a list
    assert isinstance(list_collectors(), list)

    # Test if method get_collector_names returns a list
    assert isinstance(get_collector_names(), list)

    # Test if method get_collector_instance returns an instance of class Collector
    assert isinstance(get_collector_instance('dns'), Collector)

    # Test if method collect returns a dictionary
    assert isinstance(get_collector_instance('dns').collect(), dict)

# Generated at 2022-06-17 02:07:03.368757
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:07:14.329426
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:07:25.493042
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:07:34.000853
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:07:37.891325
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:07:48.041316
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:07:58.924741
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['ndots'] == '1'
    assert dns_facts['dns']['options']['timeout'] == '2'

# Generated at 2022-06-17 02:08:05.803120
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert 'dns' in dns_facts
    assert 'nameservers' in dns_facts['dns']
    assert 'domain' in dns_facts['dns']
    assert 'search' in dns_facts['dns']
    assert 'sortlist' in dns_facts['dns']
    assert 'options' in dns_facts['dns']

# Generated at 2022-06-17 02:08:11.077185
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:08:15.080740
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:08:17.361668
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:08:27.727696
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:08:58.215729
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:09:02.329321
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:08.101236
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:14.111523
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['127.0.0.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'
    assert dns_facts['dns']['options']['rotate'] == True

# Generated at 2022-06-17 02:09:21.855524
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['ndots'] == '3'
    assert dns_facts['dns']['options']['timeout'] == '2'

# Generated at 2022-06-17 02:09:27.282505
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:33.238206
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:09:43.837992
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import list_collectors

    # Test that the DnsFactCollector class can be instantiated
    dns_fact_collector = DnsFactCollector()

    # Test that the DnsFactCollector class is a subclass of the Collector class
    assert issubclass(DnsFactCollector, Collector)

    # Test that the DnsFactCollector class can be added to the list of
    # available fact collectors
    list_collectors.append(DnsFactCollector)

    # Test that the DnsFactCollector class is in the list of

# Generated at 2022-06-17 02:09:46.781613
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:09:50.399876
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:10:15.684636
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:17.914244
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_collector = DnsFactCollector()
    assert dns_collector.name == 'dns'
    assert dns_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:20.171972
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:26.397383
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:28.323846
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:10:30.052532
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:32.391777
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:34.321185
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:10:36.785937
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:10:42.016259
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'][0] == '8.8.8.8'
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'][0] == 'example.com'
    assert dns_facts['dns']['sortlist'][0] == '10.0.0.0/8'
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:11:35.431991
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:11:38.355717
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-17 02:11:40.476167
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:11:43.959586
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:11:55.349564
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.0.0/255.255.0.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:12:04.569061
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.system.dns import DnsFactCollector

    # Create a new instance of DnsFactCollector
    dns_fact_collector = DnsFactCollector()

    # Create a new instance of Collector
    collector = Collector()

    # Add the DnsFactCollector instance to the Collector instance
    collector.add_collector(dns_fact_collector)

    # Create a new dictionary
    collected_facts = {}

    # Call the collect method of the Collector instance with the collected_facts
    # dictionary as argument
    collector.collect(module=None, collected_facts=collected_facts)

    # Assert that the collected_facts dictionary is

# Generated at 2022-06-17 02:12:06.733146
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:12:14.742708
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8', '192.168.0.0/16']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:12:18.437052
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:12:25.055134
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'
    assert dns_facts['dns']['options']['rotate'] == True
    assert d

# Generated at 2022-06-17 02:13:11.999892
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:13:17.816741
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:13:21.580790
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['127.0.0.1']
    assert dns_facts['dns']['domain'] == 'localdomain'
    assert dns_facts['dns']['search'] == ['localdomain']
    assert dns_facts['dns']['sortlist'] == []
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:13:23.909510
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:13:33.129408
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:13:39.868212
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['10.0.0.0/8']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'

# Generated at 2022-06-17 02:13:42.567856
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:13:47.939255
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:13:57.732233
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/255.255.255.0']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '1'

# Generated at 2022-06-17 02:14:00.875619
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:15:55.265749
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    dns_facts = dns_collector.collect()
    assert dns_facts['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    assert dns_facts['dns']['domain'] == 'example.com'
    assert dns_facts['dns']['search'] == ['example.com', 'example.org']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.0/24']
    assert dns_facts['dns']['options']['timeout'] == '2'
    assert dns_facts['dns']['options']['attempts'] == '3'