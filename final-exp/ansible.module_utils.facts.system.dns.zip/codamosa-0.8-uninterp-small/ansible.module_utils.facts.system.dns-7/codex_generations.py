

# Generated at 2022-06-25 00:03:04.769943
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    col = DnsFactCollector()
    assert type(col) == DnsFactCollector


# Generated at 2022-06-25 00:03:07.301965
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:03:16.090446
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    instance = DnsFactCollector()
    instance._read_file = lambda x: '''#ignore
nameserver 10.1.1.1
search mydomain.com
domain mydomain.com
options debug

nameserver 8.8.8.8
;test
sortlist 172.18.0.0/255.255.0.0
search mydomain2.com
'''

    res = instance.collect()
    assert res['dns']['nameservers'] == ['10.1.1.1', '8.8.8.8']
    assert res['dns']['domain'] == 'mydomain.com'
    assert res['dns']['search'] == ['mydomain.com', 'mydomain2.com']

# Generated at 2022-06-25 00:03:17.238115
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():

    dns_fact_collector = DnsFactCollector()


# Generated at 2022-06-25 00:03:18.707068
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns = DnsFactCollector()
    dns_facts = dns.collect()
    assert ('dns' in dns_facts)


# Generated at 2022-06-25 00:03:23.584437
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    dns_facts_1 = dns_fact_collector_1.collect()
    assert(dns_facts_1['dns']['nameservers'] == ['8.8.4.4', '8.8.8.8', '4.4.4.4'])
    assert(dns_facts_1['dns']['search'] == ['ansible.com', 'redhat.com'])
    assert(dns_facts_1['dns']['domain'] == 'example.com')
    assert(dns_facts_1['dns']['sortlist'] == ['192.168.1.0/24'])

# Generated at 2022-06-25 00:03:27.273428
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:03:35.082683
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()

    dns_facts = dns_fact_collector.collect(module=None, collected_facts=None)
    assert dns_facts is not None
    assert dns_facts['dns'] is not None
    assert 'nameservers' not in dns_facts['dns']
    assert 'domain' not in dns_facts['dns']
    assert 'search' not in dns_facts['dns']
    assert 'sortlist' not in dns_facts['dns']
    assert 'options' not in dns_facts['dns']



# Generated at 2022-06-25 00:03:38.045818
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()

    assert dns_fact_collector_1.name == 'dns'
    assert isinstance(dns_fact_collector_1._fact_ids, set)
    assert dns_fact_collector_1._fact_ids == set()

# Generated at 2022-06-25 00:03:42.143858
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert isinstance(dns_fact_collector_0.name, str) is True
    assert isinstance(dns_fact_collector_0._fact_ids, set) is True


# Generated at 2022-06-25 00:03:54.603550
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()



# Generated at 2022-06-25 00:04:00.448552
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_collect = DnsFactCollector()
    dns_facts_collect = dns_fact_collector_collect.collect()

    assert dns_facts_collect.get('dns') != None

# Generated at 2022-06-25 00:04:06.856985
# Unit test for method collect of class DnsFactCollector

# Generated at 2022-06-25 00:04:08.533454
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert(DnsFactCollector)


# Generated at 2022-06-25 00:04:09.775014
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:04:13.448326
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # verify subclass
    assert issubclass(DnsFactCollector, BaseFactCollector)
    # verify parent constructor
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:04:15.857909
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector().name == 'dns'



# Generated at 2022-06-25 00:04:19.661225
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Test a full assert of this method
    dns_fact_collector_0 = DnsFactCollector()
    test_case_0()
    ret = dns_fact_collector_0.collect()
    assert ret == {'dns': 'dns'}, "Expected {'dns': 'dns'}, got {0}".format(ret)

# Generated at 2022-06-25 00:04:25.117400
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    global dns_fact_collector_0
    # constructor, without params
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0 is not None
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()


if __name__ == '__main__':
    test_DnsFactCollector()

# Generated at 2022-06-25 00:04:27.736237
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_0 == dns_fact_collector_1


# Generated at 2022-06-25 00:04:39.207796
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    import json
    var_1 = DnsFactCollector()
    assert var_1.name == 'dns'
    assert isinstance(var_1._fact_ids, set)


# Generated at 2022-06-25 00:04:40.706364
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:04:44.237723
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    my_obj = DnsFactCollector()
    my_obj.collect()


# Generated at 2022-06-25 00:04:47.011003
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:04:49.669762
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()



# Generated at 2022-06-25 00:04:51.513657
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:04:59.395111
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert 'dns' in var_0
    assert isinstance(var_0['dns']['nameservers'], list)
    assert 'domain' in var_0['dns']
    assert 'search' in var_0['dns']
    assert isinstance(var_0['dns']['search'], list)
    assert 'sortlist' in var_0['dns']
    assert 'options' in var_0['dns']

# Generated at 2022-06-25 00:05:00.825340
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_0 = DnsFactCollector()
    assert (var_0.name == 'dns')
    assert (var_0._fact_ids == set())


# Generated at 2022-06-25 00:05:03.314633
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:05:04.586109
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()


# Generated at 2022-06-25 00:05:25.211367
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    res = dns_fact_collector.collect()
    assert res.get('dns') is None

# Generated at 2022-06-25 00:05:25.816975
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    pass

# Generated at 2022-06-25 00:05:28.428291
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    result = dns_fact_collector.collect()
    assert isinstance(result, dict)
    assert 'dns' in result

# Generated at 2022-06-25 00:05:30.585794
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1.collect() is not None


# Generated at 2022-06-25 00:05:35.894536
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():

    # Test method __init__
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector is not None
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()



# Generated at 2022-06-25 00:05:40.508048
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    # TODO: Implement assertions for DnsFactCollector.collect


# Generated at 2022-06-25 00:05:42.659249
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert 'dns' == dns_fact_collector_0.name
    assert isinstance(dns_fact_collector_0.name, str)


# Generated at 2022-06-25 00:05:46.960544
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert not dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:05:50.155535
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    print('dns_fact_collector_1.collect() = %r' % (var_1, ))


# Generated at 2022-06-25 00:05:57.487386
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name is None
    assert dns_fact_collector_0._fact_ids is None
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1.name == 'dns'
    assert dns_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:06:34.762924
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1.name is None
    assert dns_fact_collector_1._fact_ids == {'dns'}



# Generated at 2022-06-25 00:06:40.006680
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()



# Generated at 2022-06-25 00:06:44.819962
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert True

# Generated at 2022-06-25 00:06:45.568372
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()


# Generated at 2022-06-25 00:06:48.413809
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

    assert isinstance(var_0, dict)
    assert var_0 == {}

# Generated at 2022-06-25 00:06:52.646904
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert type(dns_fact_collector_0) == DnsFactCollector

# Generated at 2022-06-25 00:06:53.565266
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:06:57.473169
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()


# Generated at 2022-06-25 00:07:00.360078
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:07:02.793007
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    var = dns_fact_collector.collect()
    assert var is not None
    assert isinstance(var, dict)
    # TODO: test for content

# Generated at 2022-06-25 00:08:25.494911
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # => {"changed": false, "ansible_facts": {"dns": {"nameservers": ["1.2.3.4"]}}}
    res = DnsFactCollector().collect(module=None,
    collected_facts=None)
    assert res['ansible_facts']['dns']['nameservers'] == \
        ['1.2.3.4']

# Generated at 2022-06-25 00:08:27.271839
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector().name == 'dns'


# Generated at 2022-06-25 00:08:30.075798
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    # TODO: mock the following:
    # ['tokens', 'line', 'len', 'option', 'option_tokens', 'val', 'tokens', 'ansible.module_utils.facts.collector.BaseFactCollector', 'tokens', 'tokens', 'tokens', 'line']

    # Need to mock the following 2 items
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    # TODO: assert value of var_0


# Generated at 2022-06-25 00:08:32.552380
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    assert isinstance(dns_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:08:38.944767
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0 == {u'dns': {u'domain': u'example.com', u'nameservers': [u'192.168.1.1', u'192.168.1.2'], u'options': {u'debug': True, u'inet6': True, u'timeout': 1}, u'search': [u'example.com'], u'sortlist': [u'10.0.1.2/24']}}

# Generated at 2022-06-25 00:08:40.834715
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert isinstance(dns_fact_collector_1, DnsFactCollector)


# Generated at 2022-06-25 00:08:42.362274
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    assert type(dns_fact_collector_0.collect()) is dict


# Generated at 2022-06-25 00:08:45.957518
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()

    # Call method collect
    test_case_0()

    # Test case with args
    dns_fact_collector_0.collect(module=None, collected_facts=None)

    # Test case with args
    dns_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:08:52.007313
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert isinstance(dns_fact_collector, DnsFactCollector)
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:08:52.567522
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass # TODO: implement your test here

# Generated at 2022-06-25 00:11:56.078459
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    fc = DnsFactCollector()
    fc.collect()


# Generated at 2022-06-25 00:11:57.855980
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert isinstance(DnsFactCollector(), DnsFactCollector), 'Test constructor of class DnsFactCollector failed.'



# Generated at 2022-06-25 00:11:59.095345
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    test_cases = [test_case_0]
    for test_case in test_cases:
        test_case()

# Generated at 2022-06-25 00:12:01.018177
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass

# Generated at 2022-06-25 00:12:03.458055
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dnsFactCollector = DnsFactCollector()
    dnsFactCollector.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:12:04.291286
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    # Test code in method collect

    pass

# Generated at 2022-06-25 00:12:05.935984
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()

# Unit test

# Generated at 2022-06-25 00:12:07.906275
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    expected_output_0 = '_fact_ids'
    output_0 = DnsFactCollector()._fact_ids
    assert repr(output_0) == repr(expected_output_0)

# Generated at 2022-06-25 00:12:09.766482
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    """
    :precondition: None
    :return: None
    """
    # Test for class DnsFactCollector
    dns_fact_collector_0 = DnsFactCollector()



# Generated at 2022-06-25 00:12:10.381085
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()