

# Generated at 2022-06-25 00:03:07.516116
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()

    res = dns_fact_collector_0.collect()

# Test cases for class DnsFactCollector

# Generated at 2022-06-25 00:03:09.844432
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.collect() == {'dns': {}}

# Generated at 2022-06-25 00:03:16.846500
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    dns_facts_dict = {'dns': {'nameservers': ['8.8.8.8', '8.8.4.4'], 'domain': 'mock', 'search': ['mock'], 'sortlist': ['mock'], 'options': {'timeout': 'mock', 'debug': True}}}
    dns_fact_collector_0.collect()
    assert dns_facts_dict == dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:18.832983
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:26.453245
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    dns_fact_collector_0 = DnsFactCollector()
    dns_facts = dns_fact_collector_0.collect(module=None, collected_facts=None)
    dns_facts_expected = {
        'dns': {
            'options': {
                'timeout': 2,
                'attempts': 1,
            },
            'domain': 'example.com',
            'nameservers': [
                '1.1.1.1',
                '8.8.8.8',
            ],
            'search': [
                'example.com',
                'internal',
            ],
            'sortlist': [
                '192.168.1.0/24',
            ],
        },
    }


# Generated at 2022-06-25 00:03:27.364026
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass



# Generated at 2022-06-25 00:03:30.697744
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()

    assert(dns_facts['dns']['search'][0] == 'domain.tld')

# Generated at 2022-06-25 00:03:35.005520
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.collect() == {'dns': {'domain': 'e34.com', 'sortlist': [], 'search': [], 'options': {}, 'nameservers': ['192.168.1.1']}}

# Generated at 2022-06-25 00:03:41.092080
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()


# Generated at 2022-06-25 00:03:42.291932
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_collect = DnsFactCollector()


# Generated at 2022-06-25 00:03:52.366850
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0._fact_ids == set([])
    assert dns_fact_collector_0.name == 'dns'


# Generated at 2022-06-25 00:03:54.759600
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'



# Generated at 2022-06-25 00:03:55.904188
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()

# Generated at 2022-06-25 00:04:00.290188
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert hasattr(DnsFactCollector, '_fact_ids')
    assert hasattr(DnsFactCollector, 'name')
    assert hasattr(DnsFactCollector, 'collect')


# Generated at 2022-06-25 00:04:02.911921
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    if 'dns' in var_0:
        var_0['dns']

# Generated at 2022-06-25 00:04:05.212061
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns', 'incorrect value for DnsFactCollector.name'
    assert DnsFactCollector._fact_ids == set(), 'incorrect value for DnsFactCollector._fact_ids'


# Generated at 2022-06-25 00:04:07.430194
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert ("DnsFactCollector") == type(dns_fact_collector_0).__name__


# Generated at 2022-06-25 00:04:08.860331
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_0 = DnsFactCollector()


# Generated at 2022-06-25 00:04:09.473437
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    x = DnsFactCollector()


# Generated at 2022-06-25 00:04:14.550378
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0 == {'dns': {'domain': 'example.com', 'nameservers': ['ns1.example.com', 'ns2.example.com'], 'options': {}, 'search': ['internal.example.com', 'external.example.com'], 'sortlist': []}}

# Generated at 2022-06-25 00:04:33.866314
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert 'dns' in var_0.keys()

# Generated at 2022-06-25 00:04:34.839061
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()

# Generated at 2022-06-25 00:04:35.907208
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    var_1 = DnsFactCollector()
    var_1.collect()



# Generated at 2022-06-25 00:04:42.497622
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    dns_fact_collector_1.collect()

    dns_fact_collector_2 = DnsFactCollector()
    var_1 = dns_fact_collector_2.collect()
    assert var_1['dns']['nameservers'][0] == '127.0.0.1'
    assert var_1['dns']['nameservers'][1] == '127.0.0.2'
    assert var_1['dns']['domain'] == 'example.com'
    assert var_1['dns']['search'][0] == 'example.net'
    assert var_1['dns']['options']['timeout'] == '2'

# Generated at 2022-06-25 00:04:45.280685
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:04:50.281573
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    result = dns_fact_collector.collect()

# Generated at 2022-06-25 00:04:53.804436
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_obj_0 = DnsFactCollector()
    assert dns_fact_collector_obj_0.name == "dns"
    assert dns_fact_collector_obj_0._fact_ids == set()


# Generated at 2022-06-25 00:04:54.979293
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()



# Generated at 2022-06-25 00:05:05.555780
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    # Test a dictionary
    assert "dns" in var_1
    assert "nameservers" in var_1["dns"]
    assert "search" in var_1["dns"]
    # Test list
    assert var_1["dns"]["search"] == []
    assert var_1["dns"]["nameservers"] == []
    assert "domain" in var_1["dns"]
    assert "sortlist" in var_1["dns"]
    assert var_1["dns"]["sortlist"] == []
    assert "options" in var_1["dns"]

# Generated at 2022-06-25 00:05:09.570316
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:05:46.492902
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()


# Generated at 2022-06-25 00:05:47.885223
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # It should be tested !
    test_case_0()

# Generated at 2022-06-25 00:05:52.292966
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    assert dns_fact_collector_0.collect() == 'default return'


# Generated at 2022-06-25 00:05:54.045267
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns', "Expected DnsFactCollector to have name = 'dns', got %s" % dns_fact_collector_0.name

# Generated at 2022-06-25 00:05:57.395267
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    assert hasattr(DnsFactCollector(), "collect")


# Generated at 2022-06-25 00:06:08.319768
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert(var_0.get('dns').get('nameservers') == ['192.168.33.2'])
    assert(var_0.get('dns').get('domain') == 'vagrantup.com')
    assert(var_0.get('dns').get('search').__len__() == 0)
    assert(var_0.get('dns').get('sortlist').__len__() == 0)
    assert(var_0.get('dns').get('options').get('timeout') == '2')
    assert(var_0.get('dns').get('options').get('rotate') == True)

# Generated at 2022-06-25 00:06:09.060173
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:06:10.088282
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()


# Generated at 2022-06-25 00:06:11.509809
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:06:12.387143
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()


# Generated at 2022-06-25 00:07:23.877770
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    var_1 = DnsFactCollector()
    var_2 = var_1.collect()

# Generated at 2022-06-25 00:07:28.502842
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_1 = dns_fact_collector_0.collect()
    assert isinstance(var_1, dict)


# Generated at 2022-06-25 00:07:33.272871
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()

if __name__ == "__main__":
    test_DnsFactCollector()

# Generated at 2022-06-25 00:07:34.568047
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    res_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:07:40.195999
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    assert var_1 == {'dns': {'nameservers': ['127.0.0.1'], 'options': {'timeout': '2', 'attempts': '1'}}}


# Generated at 2022-06-25 00:07:43.406348
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()

    # TODO: flatten
    assert dns_fact_collector_0.collect()['dns']



# Generated at 2022-06-25 00:07:44.809666
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector is not None


# Generated at 2022-06-25 00:07:45.478216
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass


# Generated at 2022-06-25 00:07:50.219961
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'

    assert dns_fact_collector._fact_ids == set()



# Generated at 2022-06-25 00:07:53.095826
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_0 = DnsFactCollector()
    assert var_0.name == 'dns'


# Generated at 2022-06-25 00:10:59.465022
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_1 = DnsFactCollector()
    assert var_1.name == 'dns'

# Generated at 2022-06-25 00:11:02.050726
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    assert var_1 == {'dns': {'nameservers': ['127.0.0.1'], 'search': ['example.org']}}

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:11:05.432222
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:11:07.128039
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:11:10.336439
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector().name == 'dns'

# Generated at 2022-06-25 00:11:12.038870
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert isinstance(DnsFactCollector(), DnsFactCollector)


# Generated at 2022-06-25 00:11:13.163457
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = DnsFactCollector()


# Generated at 2022-06-25 00:11:16.973262
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()


# Generated at 2022-06-25 00:11:19.069026
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:11:22.439741
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    print(var_0)