

# Generated at 2022-06-25 00:03:02.789446
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'


# Generated at 2022-06-25 00:03:03.696712
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:03:08.690371
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect(None, None)
    assert isinstance(dns_facts, dict)
    assert 'dns' in dns_facts
    assert dns_facts['dns']

# Generated at 2022-06-25 00:03:09.886753
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector().name == 'dns'


# Generated at 2022-06-25 00:03:11.067116
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()


# Generated at 2022-06-25 00:03:15.207402
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:03:18.749891
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Prepare test data
    class TestModule():
        pass

    test_module_0 = TestModule()

    # Run method collect
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_0.collect(test_module_0, None)

# Generated at 2022-06-25 00:03:21.288823
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()

    facts_0 = dns_fact_collector_1.collect()
    assert 'dns' in facts_0



# Generated at 2022-06-25 00:03:26.979858
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    result = dns_fact_collector_1.collect()
    assert type(result) == dict
    assert result == {'dns': {'options': {'rotate': True, 'timeout': 2, 'attempts': 5}, 'sortlist': ['192.168.1.0/255.255.255.0'], 'nameservers': ['140.211.169.101', '8.8.8.8'], 'domain': 'example.com', 'search': ['example.com']}}, 'Test Failed'


# Generated at 2022-06-25 00:03:29.754712
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    """Test collect function of class DnsFactCollector"""
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:03:38.369498
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'


# Generated at 2022-06-25 00:03:40.634985
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
  assert callable(DnsFactCollector)



# Generated at 2022-06-25 00:03:42.486350
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Setup test case
    test_case_0()


# Execute test cases

test_DnsFactCollector_collect()

# Generated at 2022-06-25 00:03:44.640942
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:48.410101
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    _dns_fact_collector_0 = DnsFactCollector()

    # Test with empty file content
    get_file_content_mock_0 = Mock(side_effect = lambda x: '')
    with patch.object(ansible.module_utils.facts.utils, 'get_file_content', new = get_file_content_mock_0):
        assert _dns_fact_collector_0.collect() == {'dns': {}}
        get_file_content_mock_0.assert_has_calls(call('/etc/resolv.conf', ''))

# Generated at 2022-06-25 00:03:53.512682
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:03:54.598426
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    print(var_0)

# Generated at 2022-06-25 00:03:59.632390
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    dns_fact_collector_1.collect()

# Generated at 2022-06-25 00:04:06.365020
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    mock_module = MagicMock()
    mock_collected_facts = MagicMock()
    dns_fact_collector_1 = DnsFactCollector()
    dns_fact_collector_1.set_module(mock_module)
    dns_fact_collector_1.set_collected_facts(mock_collected_facts)
    dns_fact_collector_1._fact_ids = set()
    dns_fact_collector_1._file_exists = MagicMock(return_value=True)

# Generated at 2022-06-25 00:04:08.716029
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert type(DnsFactCollector()) is DnsFactCollector


# Generated at 2022-06-25 00:04:28.115570
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()

    result = dns_fact_collector.collect()

    assert type(result) is dict


# Generated at 2022-06-25 00:04:32.146954
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass


# Generated at 2022-06-25 00:04:34.061629
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:04:37.100824
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'

    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()



# Generated at 2022-06-25 00:04:37.874082
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector().collect()

# Generated at 2022-06-25 00:04:39.264564
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_fact_collector.collect()

# Generated at 2022-06-25 00:04:40.144916
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_DnsFactCollector_obj = DnsFactCollector()

# Generated at 2022-06-25 00:04:44.159741
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    if test_DnsFactCollector.__name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 00:04:49.425457
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:04:51.168283
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert True == True


# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 00:05:25.108004
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_0 = DnsFactCollector()
    assert var_0.name == 'dns'
    assert var_0._fact_ids == set([])


# Generated at 2022-06-25 00:05:29.033184
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    var_1 = dns_fact_collector_0.name
    # If assertion fails, there's a problem with name property of class DnsFactCollector
    assert(var_1 == 'dns')


# Generated at 2022-06-25 00:05:34.046175
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set([])


# Generated at 2022-06-25 00:05:39.077391
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    assert var_1 == {'dns': {'nameservers': ['192.168.56.1'], 'domain': 'ansible.com', 'search': ['ansible.com'], 'sortlist': [], 'options': {'edns0': '', 'ndots': 5}}}

# Generated at 2022-06-25 00:05:40.648411
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:05:42.547551
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    dns_fact_collector = DnsFactCollector()


# Generated at 2022-06-25 00:05:47.159627
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # FIXME: This test should pass
    # dns_fact_collector = DnsFactCollector()
    # var = dns_fact_collector.collect()
    assert False

# Generated at 2022-06-25 00:05:52.722842
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    assert type(dns_fact_collector_1.collect()) is dict

# Generated at 2022-06-25 00:05:56.104663
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    dns_facts = dns_collector.collect()
    assert 'dns' in dns_facts.keys()
    assert dns_facts['dns'] is not None
    assert 'nameservers' in dns_facts['dns'].keys()
    assert len(dns_facts['dns']['nameservers']) != 0

# Generated at 2022-06-25 00:05:58.918671
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:07:11.132078
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    var_0 = DnsFactCollector()
    var_1 = DnsFactCollector()
    var_2 = DnsFactCollector()
    var_3 = DnsFactCollector()
    var_4 = DnsFactCollector()
    var_5 = DnsFactCollector()
    var_6 = DnsFactCollector()
    var_7 = DnsFactCollector()
    var_8 = DnsFactCollector()
    var_9 = DnsFactCollector()
    var_10 = DnsFactCollector()
    var_11 = DnsFactCollector()

    var_0.collect()
    var_1.collect()
    var_2.collect()
    var_3.collect()
    var_4.collect()
    var_5.collect()
    var_6.collect()

# Generated at 2022-06-25 00:07:16.473271
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1.name == 'dns'
    assert dns_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:07:17.750878
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()


# Generated at 2022-06-25 00:07:25.954797
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0 == {'dns': {'options': {'ndots': '1'},
                             'sortlist': [],
                             'domain': 'local',
                             'nameservers': ['192.168.56.10', '192.168.56.11'],
                             'search': []}}



# Generated at 2022-06-25 00:07:33.859861
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.collect() == {'ansible_dns': {}, 'dns': {'nameservers': ['10.0.0.1', '10.0.1.1'], 'sortlist': ['10.0.0.0/8', '10.0.1.0/24'], 'options': {'timeout': 1, 'attempts': 2}, 'search': ['example.com', 'example.org', 'example.net'], 'domain': 'example.com'}}


"""
async def test_case_1(loop):
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
"""


# Generated at 2022-06-25 00:07:36.256243
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    assert var_1 == {'dns': {'domain': 'example.com', 'nameservers': ['8.8.8.8', '8.8.4.4']}}



# Generated at 2022-06-25 00:07:38.809191
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert(DnsFactCollector.name == 'dns' )

# Unit test 

# Generated at 2022-06-25 00:07:40.485351
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()


# Generated at 2022-06-25 00:07:42.470658
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    obj = DnsFactCollector()
    assert isinstance(obj, DnsFactCollector)

    assert obj.name == 'dns'
    assert obj._fact_ids == set()


# Generated at 2022-06-25 00:07:44.375575
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    try:
        dns_fact_collector = DnsFactCollector()
    except Exception:
        assert False, "class DnsFactCollector can not initialize"
    assert True

# Generated at 2022-06-25 00:10:37.238633
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_1 = dns_fact_collector_0.collect()

    dns_fact_collector_0.collect()
    dns_fact_collector_0.collect()
    dns_fact_collector_0.collect()
    dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:10:40.306733
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    # Test case 1
    var_1 = dns_fact_collector_1.collect()
    # Test case 2
    var_2 = dns_fact_collector_1.collect()


# Generated at 2022-06-25 00:10:44.488845
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert isinstance(dns_fact_collector, DnsFactCollector)
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:10:52.963423
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.collect() == {'dns': {'nameservers': ['10.16.0.1'], 'options': {'timeout': '2'}, 'domain': 'example.com', 'search': ['example.com', 'm3e.local']}}, "Failed to assert 'dns_fact_collector_0.collect() == {'dns': {'nameservers': ['10.16.0.1'], 'options': {'timeout': '2'}, 'domain': 'example.com', 'search': ['example.com', 'm3e.local']}}'"
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact

# Generated at 2022-06-25 00:11:01.167014
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()

    # After collect - 0
    var_0 = dns_fact_collector_0.collect()
    assert len(var_0) == 1
    assert 'dns' in var_0
    assert len(var_0['dns']) == 7
    assert 'nameservers' in var_0['dns']
    assert len(var_0['dns']['nameservers']) == 2
    assert var_0['dns']['nameservers'][0] == '127.0.0.1'
    assert var_0['dns']['nameservers'][1] == '127.0.1.1'
    assert 'domain' in var_0['dns']

# Generated at 2022-06-25 00:11:06.263492
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    # Test case with default values for args
    var_0 = dns_fact_collector_0.collect()
    # Test case with default values for args

# Generated at 2022-06-25 00:11:15.161265
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    var_1 = dns_fact_collector_0.collect()
    var_2 = dns_fact_collector_0.collect()
    var_3 = dns_fact_collector_0.collect()
    var_4 = dns_fact_collector_0.collect()
    var_5 = dns_fact_collector_0.collect()
    var_6 = dns_fact_collector_0.collect()
    var_7 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:11:19.179035
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Setup
    dns_fact_collector = DnsFactCollector()
    # Exercise
    dns_facts = dns_fact_collector.collect()
    # Verify
    assert dns_facts == {}

# Generated at 2022-06-25 00:11:22.431839
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'


# Generated at 2022-06-25 00:11:29.028659
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0 == {'dns': {'nameservers': ['10.1.1.1'],
                             'domain': 'my.example.com',
                             'search': ['example.com', 'my.example.com'],
                             'sortlist': ['10.1.1.0/255.255.255.0'],
                             'options': {'attempts': '5'}}}