

# Generated at 2022-06-25 00:03:08.648937
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    dns_facts = dns_fact_collector_0.collect()
    assert dns_facts['dns'] == {'nameservers': ['8.8.4.4'], 'domain': 'localdomain', 'search': ['localdomain'], 'sortlist': [], 'options': {'ndots': '1'}}

# Generated at 2022-06-25 00:03:09.886487
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()


# Generated at 2022-06-25 00:03:14.928716
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()

###############################################################################
# End of Unit Tests for class DnsFactCollector
###############################################################################


###############################################################################
# Begin of Integration Tests for class DnsFactCollector
###############################################################################

# Integration test for method collect of class DnsFactCollector

# Generated at 2022-06-25 00:03:15.756328
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    test_case_0()


# Generated at 2022-06-25 00:03:17.851370
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.collect() == {u'dns': {}}

# Generated at 2022-06-25 00:03:22.142503
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:03:23.620202
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()


# Generated at 2022-06-25 00:03:26.205613
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert 'dns' == dns_fact_collector.name


# Generated at 2022-06-25 00:03:29.352045
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1.name == 'dns'
    assert dns_fact_collector_1._fact_ids == set()



# Generated at 2022-06-25 00:03:30.281541
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector


# Generated at 2022-06-25 00:03:41.099742
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_1 = DnsFactCollector()


# Generated at 2022-06-25 00:03:41.787206
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:03:44.569933
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name is not None
    assert DnsFactCollector._fact_ids is not None

    x = DnsFactCollector()
    assert x.collect() is not None


# Generated at 2022-06-25 00:03:47.879484
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_0 = DnsFactCollector()
    var_1 = DnsFactCollector()
    if var_0 != var_1:
        print(".ctor #1 failed")
    if var_0 not in {var_1}:
        print(".ctor #2 failed")
    if var_0 == var_1:
        print(".ctor #3 failed")


# Generated at 2022-06-25 00:03:52.444076
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert isinstance(dns_fact_collector_0, DnsFactCollector) is True


# Generated at 2022-06-25 00:03:59.695285
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    #directory_0 = Fakes.fs.working_directory
    #file_0 = Fakes.fs.File('/etc/resolv.conf')
    #file_0.content = Fakes.fs.FileContent('', encoding='ascii')
    #directory_0.add(file_0)
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0 == {'dns': {'nameservers': ['8.8.8.8', '8.8.4.4'], 'search': [], 'sortlist': [], 'options': {}, 'domain': None}}

# Generated at 2022-06-25 00:04:00.721679
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector() != None


# Generated at 2022-06-25 00:04:03.019370
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:04:04.318041
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector= DnsFactCollector()
    dns_fact_collector.collect()

# Generated at 2022-06-25 00:04:11.736573
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0 == {
        'dns': {
            'nameservers': ['8.8.8.8', '8.8.4.4'],
            'search': ['example.com', 'example.net'],
            'options': {
                'timeout': 2,
                'attempts': 3,
                'rotate': True
            }
        }
    }

# Generated at 2022-06-25 00:04:27.357301
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert not isinstance(test_case_0(), dict)

# Generated at 2022-06-25 00:04:34.480238
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_0.name == dns_fact_collector_1.name
    assert dns_fact_collector_0._fact_ids == dns_fact_collector_1._fact_ids


# Generated at 2022-06-25 00:04:35.543789
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()


# Generated at 2022-06-25 00:04:37.174283
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    collector = DnsFactCollector()
    assert collector.name == "dns"
    assert collector._fact_ids == set()


# Generated at 2022-06-25 00:04:38.852591
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:04:39.898003
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector() is not None


# Generated at 2022-06-25 00:04:43.753521
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()



# Generated at 2022-06-25 00:04:45.322426
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass # TODO: implement your test here



# Generated at 2022-06-25 00:04:51.391467
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0 != None, 'Failed to assert not None'

# Generated at 2022-06-25 00:04:53.804169
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    try:
        dns_fact_collector_0 = DnsFactCollector()
    except Exception as err:
        assert False, err


# Generated at 2022-06-25 00:05:26.252709
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var = DnsFactCollector()
    assert var._fact_ids == set()
    assert var.name == 'dns'


# Generated at 2022-06-25 00:05:30.645600
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_fact_collector.collect()

# Generated at 2022-06-25 00:05:34.662734
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_dns_fact_collector = DnsFactCollector()
    assert var_dns_fact_collector


# Generated at 2022-06-25 00:05:36.029644
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var = DnsFactCollector()
    assert isinstance(var, DnsFactCollector)


# Generated at 2022-06-25 00:05:39.990664
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_0 = getattr(DnsFactCollector, 'name', "")
    var_1 = getattr(DnsFactCollector, '_fact_ids', "")

# Generated at 2022-06-25 00:05:44.490539
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_obj_0 = DnsFactCollector()
    var_0 = dns_fact_collector_obj_0.collect()
    assert var_0 == {u'dns': {u'nameservers': ['192.168.1.1']}}, 'unexpected value for "DnsFactCollector.collect()"'

# Generated at 2022-06-25 00:05:47.630978
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    r"""Test DnsFactCollector.collect.
 
    This test case asserts that for both /etc/resolv.conf
    with and without custom config, the right facts are returned.
    """
    # TODO: Implement test
    raise NotImplementedError()

# Generated at 2022-06-25 00:05:49.620890
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector().name == 'dns'
    assert DnsFactCollector()._fact_ids == set()


# Generated at 2022-06-25 00:05:52.723481
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert not dns_fact_collector is None


# Generated at 2022-06-25 00:05:59.017592
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector.network.dns import DnsFactCollector
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1.collect() == {'dns': {'nameservers': ['8.8.8.8'],
                                                      'search': ['thedomain'],
                                                      'sortlist': [],
                                                      'options': {'rotate': True},
                                                      'domain': 'thedomain'}}

# Generated at 2022-06-25 00:07:05.619842
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0 is not None


# Generated at 2022-06-25 00:07:07.025852
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert True  # TODO: implement your test here


# Generated at 2022-06-25 00:07:10.500204
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'


# Generated at 2022-06-25 00:07:14.781291
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_2 = DnsFactCollector()


# Generated at 2022-06-25 00:07:15.643452
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector


# Generated at 2022-06-25 00:07:17.469840
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:07:23.038059
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var = DnsFactCollector()
    assert(var._fact_ids == set(), None)

# Generated at 2022-06-25 00:07:26.429235
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
  assert DnsFactCollector().name == 'dns', 'Constructor fails'


# Generated at 2022-06-25 00:07:32.697028
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_1 = dns_fact_collector_0.collect()
    assert var_1 != None

    var_1 = dns_fact_collector_0.collect()
    assert var_1 != None

    var_1 = dns_fact_collector_0.collect()
    assert var_1 != None


# Generated at 2022-06-25 00:07:34.313397
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Test Case #0
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:10:30.785942
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert dns_fact_collector_0._fact_ids is not None
    assert dns_fact_collector_0._fact_ids == set([])


# Generated at 2022-06-25 00:10:35.751526
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:10:36.464517
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass


# Generated at 2022-06-25 00:10:39.610477
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Try to access the id of method collect of class DnsFactCollector
    var_1 = DnsFactCollector.collect._fact_id
    # Assert that the fact_id is the same that the previous one
    assert var_1 == 'ansible_dns'

# Generated at 2022-06-25 00:10:41.739983
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.collect() == {'dns': {}}


# Generated at 2022-06-25 00:10:43.254335
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:10:48.131796
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert isinstance(dns_fact_collector_0, DnsFactCollector)


# Generated at 2022-06-25 00:10:54.170666
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_instance_0 = DnsFactCollector()
    var_1 = dns_fact_collector_instance_0.collect()
    var_2 = dns_fact_collector_instance_0.collect()
    if var_1 == var_2:
        assert False


# Generated at 2022-06-25 00:10:56.874146
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert not dns_fact_collector_0._fact_ids
    assert dns_fact_collector_0.name == 'dns'

# Generated at 2022-06-25 00:11:03.845336
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Test 0
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()