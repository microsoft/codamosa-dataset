

# Generated at 2022-06-25 00:03:02.819283
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.collect() is not None


# Generated at 2022-06-25 00:03:04.616907
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert isinstance(DnsFactCollector(), DnsFactCollector)


# Generated at 2022-06-25 00:03:06.507003
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:03:18.046130
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    dns_facts = dns_fact_collector_1.collect()

    assert "dns" in dns_facts
    assert "domain" in dns_facts["dns"]
    assert "nameservers" in dns_facts["dns"]
    assert "search" in dns_facts["dns"]
    assert "sortlist" in dns_facts["dns"]
    assert "options" in dns_facts["dns"]

    assert len(dns_facts["dns"]["nameservers"]) == 2
    assert dns_facts["dns"]["nameservers"][0] == "11.11.12.13"

# Generated at 2022-06-25 00:03:21.683751
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_0.collect() == dns_fact_collector_1.collect()

# Generated at 2022-06-25 00:03:23.163452
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    d = DnsFactCollector()
    result = d.collect(None, None)
    assert result

# Generated at 2022-06-25 00:03:25.452034
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()


# Generated at 2022-06-25 00:03:27.451971
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:03:29.171525
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    print(dns_fact_collector.collect())

# Generated at 2022-06-25 00:03:33.134032
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    """
    Test that the constructor of class DnsFactCollector returns an object of type DnsFactCollector.
    """
    dns_fact_collector = DnsFactCollector()
    assert isinstance(dns_fact_collector, DnsFactCollector)

# Generated at 2022-06-25 00:03:43.605580
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()



# Generated at 2022-06-25 00:03:48.502125
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1.name == 'dns'


# Generated at 2022-06-25 00:03:55.903961
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1.name == 'dns'
    dns_fact_collector_1.name = 'dns_fact_collector'
    assert dns_fact_collector_1.name == 'dns_fact_collector'
    assert dns_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:03:59.742200
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:04:02.240362
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()    # instantiate object
    result = dns_fact_collector_0.collect()    # call method
    assert 'dns' in result.keys()


# Generated at 2022-06-25 00:04:04.490484
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # Test case 1: Verify that an object of type DnsFactCollector is instantiated correctly.
    test_case_0()

# Unit tests for collect() method of class DnsFactCollector

# Generated at 2022-06-25 00:04:05.700749
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    test_dns_collector_0 = DnsFactCollector()
    


# Generated at 2022-06-25 00:04:08.788837
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    try:
        test_case_0()
    except Exception as e:
        raise Exception("Constructor of class DnsFactCollector failed - %s" %e )

# Generated at 2022-06-25 00:04:12.182256
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()

    # TODO: Actual testing for the collected facts.
    assert dns_fact_collector_0.collect() is not None

# Generated at 2022-06-25 00:04:13.419223
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass


# Generated at 2022-06-25 00:04:23.546030
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector is not None


# Generated at 2022-06-25 00:04:28.161879
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    expected = {}
    actual = dns_fact_collector.collect()

    assert actual == expected


# Generated at 2022-06-25 00:04:29.960591
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    assert var_1 == {}

# Generated at 2022-06-25 00:04:36.757809
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect({})
    assert var_0 == {'dns': {'domain': 'example.com',
      'nameservers': ['192.168.0.1', '8.8.8.8'],
      'options': {'ndots': '2', 'timeout': '1'},
      'search': ['example.com']}}, var_0

# Generated at 2022-06-25 00:04:37.544647
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:04:39.520423
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    try:
        test_case_0()
    except:
        import traceback
        tb = traceback.format_exc()
        return tb
    return "success"

# Generated at 2022-06-25 00:04:45.050130
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert {} == var_0

# Generated at 2022-06-25 00:04:50.616562
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:04:59.574238
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    var_1['dns']['domain'] == 'internal.example.org'
    var_1['dns']['nameservers'] == ['8.8.8.8', '8.8.4.4']
    var_1['dns']['options']['timeout'] == '2'
    var_1['dns']['search'] == ['internal.example.org', 'example.org']
    var_1['dns']['sortlist'] == ['192.168.1.0/24']

# Generated at 2022-06-25 00:05:00.197243
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()


# Generated at 2022-06-25 00:05:19.125678
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    try:
        DnsFactCollector()
    except NameError:
        assert False


# Generated at 2022-06-25 00:05:25.060403
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    # var_0 => {'dns': {'domain': 'trusty.vagrantup.com', 'options': {'rotate': True, 'timeout': '2'}, 'nameservers': ['192.168.1.1', '192.168.1.2'], 'search': ['trusty.vagrantup.com']}}
    assert var_0 == {'dns': {'domain': 'trusty.vagrantup.com', 'options': {'rotate': True, 'timeout': '2'}, 'nameservers': ['192.168.1.1', '192.168.1.2'], 'search': ['trusty.vagrantup.com']}}
   

# Generated at 2022-06-25 00:05:27.346952
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    assert {} == var_1

if __name__ == '__main__':
    # test_case_0()
    test_DnsFactCollector_collect()

# Generated at 2022-06-25 00:05:35.547293
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # TODO: test when /etc/resolv.conf does not exist
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_0.get_file_content = lambda a, b: 'nameserver   8.8.8.8\nsortlist  127.0.0.0/255.0.0.0\n'
    var_0 = dns_fact_collector_0.collect()
    assert var_0.get('dns') == {
        'options': {},
        'nameservers': ['8.8.8.8'],
        'sortlist': ['127.0.0.0/255.0.0.0']
    }

# Generated at 2022-06-25 00:05:44.405932
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.__doc__ == "class DnsFactCollector(BaseFactCollector)\n    Collects facts about dns\n    "
    assert DnsFactCollector._fact_ids == frozenset({'dns'})
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector.collect.__doc__ == '\n        Collects the dns facts\n\n        :return: A hash containing the dns facts\n        :rtype: dict\n        '
    assert DnsFactCollector.collect() == 'pass'

# Generated at 2022-06-25 00:05:46.366190
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_1 = DnsFactCollector()
    assert var_1.name == 'dns'
    assert var_1._fact_ids == set()



# Generated at 2022-06-25 00:05:50.832816
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_2 = DnsFactCollector()
    var_2 = dns_fact_collector_2.collect()
    var_1 = {'dns': {'nameservers': ['192.168.0.1'], 'domain': 'example.org', 'search': ['example.org', 'somewhere.org']}}

    assert var_1 == var_2

# Generated at 2022-06-25 00:05:53.438814
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0['dns']['domain'] == 'Gentoo-EVRO-01'



# Generated at 2022-06-25 00:05:55.130965
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert isinstance(dns_fact_collector, DnsFactCollector)


# Generated at 2022-06-25 00:06:00.039180
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_0 = dns_fact_collector_1.collect()

# Generated at 2022-06-25 00:06:40.488444
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:06:44.549644
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()

# Generated at 2022-06-25 00:06:51.324819
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    print('Testing method collect of class DnsFactCollector')
    try:
        from ansible.module_utils.facts.collector import DnsFactCollector
    except ImportError:
        print('Could not import ansible.module_utils.facts.collector.DnsFactCollector')
        return
    dns_fact_collector_0 = DnsFactCollector()

    # Call method collect of class DnsFactCollector
    var_0 = dns_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()
    test_DnsFactCollector_collect()
    # test_DnsFactCollector_get_fact_ids()

# Generated at 2022-06-25 00:06:53.130330
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()


# Generated at 2022-06-25 00:06:53.979101
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector

# Generated at 2022-06-25 00:07:04.482419
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    var = dns_fact_collector.collect()
    assert(isinstance(var, dict))
    assert('dns' in var)
    assert(isinstance(var['dns'], dict))
    assert('nameservers' in var['dns'])
    assert(isinstance(var['dns']['nameservers'], list))
    assert(len(var['dns']['nameservers']) > 0)
    assert(isinstance(var['dns']['nameservers'][0], str))
    assert('domain' in var['dns'])
    assert(isinstance(var['dns']['domain'], str))
    assert('search' in var['dns'])

# Generated at 2022-06-25 00:07:05.681108
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert isinstance(dns_fact_collector_0, DnsFactCollector)


# Generated at 2022-06-25 00:07:09.568214
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = {'dns': {}}
    var_2 = dns_fact_collector_1.collect()
    assert var_1 == var_2


# Generated at 2022-06-25 00:07:10.474844
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector != None


# Generated at 2022-06-25 00:07:15.992563
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    try:
        dns_fact_collector_0.collect()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 00:08:41.996217
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0.collect() == {'dns': {}}

# Generated at 2022-06-25 00:08:46.901555
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    print(var_0)
    assert var_0['dns']['domain'] == 'home.lan'
    assert var_0['dns']['search'][0] == 'home.lan'
    assert var_0['dns']['nameservers'][0] == '192.168.100.1'
    assert var_0['dns']['nameservers'][1] == '8.8.8.8'

# Generated at 2022-06-25 00:08:50.942758
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass


# Generated at 2022-06-25 00:08:51.996269
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()


# Generated at 2022-06-25 00:08:53.247379
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector is not None

# Generated at 2022-06-25 00:08:59.216333
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    try:
        DnsFactCollector()
        print('dns_fact_collector is created')
    except Exception as e:
        print('Exception raised, dns_fact_collector creation failed: ' + str(e))



# Generated at 2022-06-25 00:08:59.625995
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass

# Generated at 2022-06-25 00:09:00.691713
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_1 = DnsFactCollector()
    assert isinstance(var_1, DnsFactCollector)

# Generated at 2022-06-25 00:09:04.331238
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_0 = DnsFactCollector()
    var_0_0 = var_0.collect()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:09:05.904292
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_1 = dns_fact_collector_0.collect()
    # Test assertions for method collect of class DnsFactCollector

# Generated at 2022-06-25 00:12:23.493365
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector.collect == DnsFactCollector.collect

# Generated at 2022-06-25 00:12:25.851996
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    var = dns_fact_collector.collect()

# Generated at 2022-06-25 00:12:26.849767
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert callable(DnsFactCollector)


# Generated at 2022-06-25 00:12:34.389704
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    file_content_0 = "# This is the primary configuration file for the BIND DNS server named.\n#\n# Please read /usr/share/doc/bind9/README.Debian.gz for information on the\n# structure of BIND configuration files in Debian, *BEFORE* you customize\n# this configuration file.\n#\n# If you are just adding zones, please do that in /etc/bind/named.conf.local\n\ninclude \"/etc/bind/named.conf.options\";\ninclude \"/etc/bind/named.conf.local\";\ninclude \"/etc/bind/named.conf.default-zones\";\n"
    dns_fact_collector_0 = DnsFactCollector()

# Generated at 2022-06-25 00:12:43.563964
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    var_1 = dns_fact_collector_0.collect({})
    var_2 = dns_fact_collector_0.collect({}, {})
    # TODO: what to test?
    #assert var_0 == {}
    #assert isinstance(var_0, dict)
    #assert var_1 == {}
    #assert isinstance(var_1, dict)
    #assert var_2 == {}
    #assert isinstance(var_2, dict)

# Generated at 2022-06-25 00:12:45.848466
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:12:47.604900
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()

    var_0 = dns_fact_collector_0.collect()

    assert type(var_0) is dict