

# Generated at 2022-06-25 00:03:03.742550
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:03:05.407103
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:03:08.919133
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass

# Generated at 2022-06-25 00:03:09.770786
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # FIXME: implement test
    pass

# Generated at 2022-06-25 00:03:14.251382
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert(isinstance(dns_fact_collector_1, DnsFactCollector))
    assert(dns_fact_collector_1.name == 'dns')


# Generated at 2022-06-25 00:03:16.032230
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    try:
        dns_fact_collector = DnsFactCollector()
    except Exception:
        assert False
    assert True


# Generated at 2022-06-25 00:03:19.954216
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1.name == 'dns'
    assert dns_fact_collector_1._fact_ids == set()
    assert dns_fact_collector_1.is_deprecated == False


# Generated at 2022-06-25 00:03:23.420339
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    
    result = dns_fact_collector_0.collect()
    assert type(result) is dict
    assert result.has_key('dns')
    assert type(result['dns']) is dict


# Generated at 2022-06-25 00:03:26.877772
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()

    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()



# Generated at 2022-06-25 00:03:30.017747
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_collect = DnsFactCollector()
    assert dns_fact_collector_collect != None
    username = dns_fact_collector_collect.collect()
    assert username == None


# Generated at 2022-06-25 00:03:42.253260
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    assert isinstance(var_1, dict)


# Generated at 2022-06-25 00:03:43.639341
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()


if __name__ == '__main__':
    test_DnsFactCollector()

# Generated at 2022-06-25 00:03:46.061451
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()

# Generated at 2022-06-25 00:03:51.124360
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Instantiate the object
    dns_fact_collector = DnsFactCollector()
    
    # Call the method with valid arguments
    dns_fact_collector.collect()

    # Call the method with invalid arguments
    #args = []
    #dns_fact_collector.collect(*args)

# Generated at 2022-06-25 00:03:52.573941
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_var_0 = DnsFactCollector()
    assert dns_fact_collector_var_0 is not None


# Generated at 2022-06-25 00:03:56.212333
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    # Testing without parameter 'module'
    try:
        DnsFactCollector.collect()
    except Exception:
        assert False
    # Testing with parameter 'module'
    try:
        DnsFactCollector.collect(module=None)
    except Exception:
        assert False


# Generated at 2022-06-25 00:04:03.718600
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    name = 'dns'
    expected = {'dns': {'nameservers': ['1.2.3.4', '4.3.2.1'], 'search': ['example.com', 'example.net'], 'sortlist': ['10.0.0.0/24', '1.2.3.0/24'], 'options': {'timeout': '2', 'attempts': '5', 'ndots': '1'}, 'domain': 'example.net'}}
    dns_fact_collector = DnsFactCollector()

# Generated at 2022-06-25 00:04:05.674787
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert isinstance(dns_fact_collector, DnsFactCollector)


# Generated at 2022-06-25 00:04:09.085559
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    #assigning variable(s)
    dns_fact_collector_0 = DnsFactCollector()

    #testing constructor
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:04:13.807731
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.collect() == {
        'dns': {
            'nameservers': ['8.8.8.8', '4.4.4.4'],
        }
    }



# Generated at 2022-06-25 00:04:33.856522
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert 'dns' in dns_fact_collector_0.collect()
    assert dns_fact_collector_0.name == 'dns'

# Generated at 2022-06-25 00:04:38.897783
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    out = dns_fact_collector_1.collect()
    assert isinstance(out, dict)

# Generated at 2022-06-25 00:04:41.928811
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # No exception raised
    try:
        dns_fact_collector_0 = DnsFactCollector()
        dns_fact_collector_0.collect()
    except:
        pass

    # No exception raised
    try:
        dns_fact_collector_1 = DnsFactCollector()
        dns_fact_collector_1.collect(collected_facts={})
    except:
        pass


# Generated at 2022-06-25 00:04:43.974946
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test = DnsFactCollector()
    assert not test


# Generated at 2022-06-25 00:04:46.396732
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    result_1 = dns_fact_collector_1._fact_ids


# Generated at 2022-06-25 00:04:52.007430
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0['dns']['nameservers'][0] is None

# Generated at 2022-06-25 00:04:52.925857
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:04:56.294091
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.name
    var_1 = dns_fact_collector_0._fact_ids
    assert var_0 == 'dns'
    assert var_1 == set()


# Generated at 2022-06-25 00:04:59.000653
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    assert True == True



# Generated at 2022-06-25 00:05:00.799557
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:05:34.132188
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()


# Generated at 2022-06-25 00:05:34.963017
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:05:35.506459
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    pass

# Generated at 2022-06-25 00:05:40.144945
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    var_1 = dns_fact_collector_1.collect()

# Generated at 2022-06-25 00:05:42.027959
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

# Generated at 2022-06-25 00:05:46.903358
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()


# Generated at 2022-06-25 00:05:47.760115
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    assert True == False


# Generated at 2022-06-25 00:05:51.706747
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector()

# Generated at 2022-06-25 00:05:53.472024
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()


# Generated at 2022-06-25 00:05:58.366924
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
  dns_fact_collector_0 = DnsFactCollector()
  assert dns_fact_collector_0.name == 'dns'
  assert dns_fact_collector_0._fact_ids == {'dns', 'domain', 'options', 'nameservers', 'search', 'sortlist'}

# Generated at 2022-06-25 00:07:05.131610
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_1 = DnsFactCollector()
    assert type(var_1) == DnsFactCollector, 'Expected type is "DnsFactCollector", actual type is "%s"' % str(type(var_1))


# Generated at 2022-06-25 00:07:09.297355
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
  try:
    dns_fact_collector = DnsFactCollector()

    # Test if instance is created
    assert isinstance(dns_fact_collector, DnsFactCollector)

  except Exception:
    raise AssertionError('Error in DnsFactCollector constructor')

# unit test for collect

# Generated at 2022-06-25 00:07:10.311009
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()


# Generated at 2022-06-25 00:07:14.826835
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_1 = DnsFactCollector()
    assert var_1 is not None


# Generated at 2022-06-25 00:07:19.019563
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    dns_facts_1 = dns_fact_collector_1.collect()
    assert dns_facts_1 == {'dns': {'domain': 'foo.example', 'nameservers': ['192.0.2.1', '192.0.2.2'], 'options': {}, 'search': ['bar.example']}}

# Generated at 2022-06-25 00:07:24.025144
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    skip_if_not_imported()
    dns_fact_collector_0 = DnsFactCollector()
    var_1 = dns_fact_collector_0.collect()
    var_2 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:07:33.661259
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    res = dns_fact_collector_0.collect()

if __name__ == '__main__':
    import cProfile
    cProfile.run('test_case_0()')

    from ansible.module_utils.facts.collector import Collector
    c = Collector()
    c.collect()
    c.get_facts()

# <- INCLUDE_ANSIBLE_MODULE_COMMON END ->

# <- INCLUDE_ANSIBLE_MODULE_COMMON START ->
#
# All of the following code was pulled from Ansible

import os
import re


# Generated at 2022-06-25 00:07:34.286604
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:07:34.928656
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector



# Generated at 2022-06-25 00:07:38.148104
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    try:
        result = DnsFactCollector()
        print("Success")
    except Exception:
        print("Exception: ")


# Generated at 2022-06-25 00:10:35.028386
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
  dns_fact_collector_0 = DnsFactCollector()


# Generated at 2022-06-25 00:10:36.565573
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dnsfactcollector = DnsFactCollector()
    assert isinstance(dnsfactcollector, DnsFactCollector)


# Generated at 2022-06-25 00:10:40.555283
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = ''
    try:
        assert dns_fact_collector_1.name == 'dns'
    except AssertionError as e:
        var_1 = e
    finally:
        if var_1 is None:
            print('ok 1')
        else:
            print('not ok 1')


# Generated at 2022-06-25 00:10:43.059292
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector is not None

# Generated at 2022-06-25 00:10:51.256197
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    #
    # Test cases for attributes of class DnsFactCollector
    #
    # Test case for attribute "name" of class DnsFactCollector
    assert dns_fact_collector_1.name == 'dns'
    #
    # Test cases for method "collect" of class DnsFactCollector
    #
    # Test case for positive scenario
    var_0 = dns_fact_collector_1.collect()

test_case_0()

# Generated at 2022-06-25 00:10:52.482687
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:10:55.302100
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert isinstance(dns_fact_collector, DnsFactCollector)
    assert isinstance(dns_fact_collector, BaseFactCollector)


# Generated at 2022-06-25 00:10:59.425104
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()

# Generated at 2022-06-25 00:11:02.074974
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # check that 'name' is set to 'dns'
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'


# Generated at 2022-06-25 00:11:05.670680
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
  dns_fact_collector_0 = DnsFactCollector()
  var_0 = dns_fact_collector_0.collect()

