

# Generated at 2022-06-25 00:03:07.264088
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    int_0 = 0
    dns_fact_collector_0 = DnsFactCollector(int_0)
    dns_fact_collector_0.collect()
    # This method may be called with an instance of module_utils.facts.utils.get_file_content or similar types
    # Assigning the return value of the method to a variable to avoid the pytest warning
    collect_return_value = dns_fact_collector_0.collect()




# Generated at 2022-06-25 00:03:12.433936
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    int_0 = -366
    dns_fact_collector_0 = DnsFactCollector(int_0)
    dns_fact_collector_0._init_path()
    assert dns_fact_collector_0


# Generated at 2022-06-25 00:03:22.488245
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    int_0 = -454
    dns_fact_collector_0 = DnsFactCollector(int_0)

    # Test with valid args
    dict_0 = {}
    dict_0['cell'] = 'cell'
    dict_0['dns_name'] = 'dns_name'
    dict_0['fqdn'] = 'fqdn'
    dict_0['domain'] = 'domain'
    dict_0['hostname'] = 'hostname'
    dict_0['kernel'] = 'kernel'
    dict_0['kernel_architecture'] = 'kernel_architecture'
    dict_0['kernel_release'] = 'kernel_release'
    dict_0['kernel_version'] = 'kernel_version'
    dict_0['machine'] = 'machine'

# Generated at 2022-06-25 00:03:27.586294
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    int_0 = 716
    dns_fact_collector_0 = DnsFactCollector(int_0)
    int_0 = -996
    module_0 = None
    collected_facts_0 = None
    dns_fact_collector_0.collect(module_0, collected_facts_0)


# Generated at 2022-06-25 00:03:36.793985
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_0 = DnsFactCollector()
    module_0 = 1.64450174664
    collected_facts_0 = {'dns': []}
    dns_1 = dns_0.collect(module_0, collected_facts_0)
    assert dns_1['dns']['nameservers'] == ['127.0.0.1']
    assert dns_1['dns']['options']['ndots'] == '1'
    assert dns_1['dns']['options']['timeout'] == '2'
    assert dns_1['dns']['search'] == ['c.root-servers.net', 'a.root-servers.net']

# Generated at 2022-06-25 00:03:40.784345
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():

    # AnsibleModule class object is not used inside constructor of the class DnsFactCollector
    # AnsibleModule class object is used inside the method collect of the class DnsFactCollector
    dns_fact_collector_0 = DnsFactCollector(None)
    dns_fact_collector_0_collect_0 = dns_fact_collector_0.collect(None, None)


# Generated at 2022-06-25 00:03:44.587174
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    dns_facts_0 = dns_fact_collector_0.collect()
    assert dns_facts_0 == {'dns': {'domain': None, 'nameservers': ['192.168.1.1'], 'options': {'rotate': True, 'timeout': 1}, 'search': ['192.168.56.0/24'], 'sortlist': []}}


# Generated at 2022-06-25 00:03:45.786107
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    int_0 = -454
    dns_fact_collector_0 = DnsFactCollector(int_0)

# Generated at 2022-06-25 00:03:56.249140
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    collected_facts_0 = {}
    int_0 = -2
    dns_fact_collector_0 = DnsFactCollector(int_0)
    result = dns_fact_collector_0.collect(collected_facts_0)
    assert isinstance(result, dict)
    assert len(result) == 1
    assert 'ansible_dns' in result
    dns_facts_0 = result.get('ansible_dns')
    assert isinstance(dns_facts_0, dict)
    assert 'nameservers' not in dns_facts_0
    assert 'search' not in dns_facts_0
    assert 'options' not in dns_facts_0


# Generated at 2022-06-25 00:03:58.522433
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # test 0
    # dns_fact_collector_0 = DnsFactCollector(-454)
    # TODO: implement test

    return


# Generated at 2022-06-25 00:04:11.180661
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.name
    var_1 = dns_fact_collector_0._fact_ids

# Generated at 2022-06-25 00:04:12.113407
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:04:14.450399
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:04:15.931430
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    assert True # TODO: implement your test here


# Generated at 2022-06-25 00:04:18.975212
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()


# Generated at 2022-06-25 00:04:20.787631
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector is not None


# Generated at 2022-06-25 00:04:22.983975
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()


# Generated at 2022-06-25 00:04:29.060534
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    dns_fact_collector_0.collect()
    if (dns_fact_collector_0.name == "dns"):
        assert True
    else:
        assert False


# Generated at 2022-06-25 00:04:29.587372
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    var_0 = DnsFactCollector()
    pass

# Generated at 2022-06-25 00:04:33.994850
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.name == 'dns'
    assert dns_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:04:45.864701
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert isinstance(dns_fact_collector_0, DnsFactCollector), dns_fact_collector_0


# Generated at 2022-06-25 00:04:49.251827
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass


# Generated at 2022-06-25 00:04:52.197880
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():

    var_1 = DnsFactCollector()
    assert var_1 != None
    assert isinstance(var_1, DnsFactCollector)


# Generated at 2022-06-25 00:04:54.452785
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert get_file_content.__doc__ == get_file_content.__doc__
    assert BaseFactCollector.__doc__ == BaseFactCollector.__doc__

# Generated at 2022-06-25 00:04:59.246058
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0 == {u'dns': {u'nameservers': [u'192.168.43.1'], u'domain': u'home'}}

# Generated at 2022-06-25 00:05:03.117143
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    result_0 = dns_fact_collector_0.name
    assert result_0 == 'dns'
    result_1 = dns_fact_collector_0._fact_ids
    assert result_1 == set()


# Generated at 2022-06-25 00:05:04.970483
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # TODO: Check for expected keys
    # TODO: Check for expected values
    # TODO: Check for expected types
    pass



# Generated at 2022-06-25 00:05:08.273614
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # dns_fact_collector = DnsFactCollector()
    # dns_facts = dns_fact_collector.collect()
    # assert dns_facts == dict(test=test)
    pass


# Generated at 2022-06-25 00:05:09.809655
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'

# Generated at 2022-06-25 00:05:12.779662
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_2 = DnsFactCollector()
    var_1 = DnsFactCollector()
    assert var_1._fact_ids == set()
    assert var_1.name == 'dns'


# Generated at 2022-06-25 00:05:34.660188
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0 == {'dns': {'nameservers': ['127.0.0.1'], 'domain': None, 'search': [], 'sortlist': [], 'options': {}}}

# Generated at 2022-06-25 00:05:36.293834
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector is not None


# Generated at 2022-06-25 00:05:45.996453
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = get_file_content('/etc/resolv.conf', '')
    var_1 = var_0.splitlines()
    var_2 = dns_fact_collector_0.collect()
    assert var_2 == {'dns': {'nameservers': ['10.11.12.13', '10.11.12.14'], 'domain': 'example.com', 'search': ['example.com', 'sub.example.com'], 'sortlist': ['10.0.0.0/24'], 'options': {'timeout': '2', 'rotate': True, 'attempts': '5'}}}

# Generated at 2022-06-25 00:05:48.300416
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:05:50.650115
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:05:51.931150
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Make sure the result is a list
    assert isinstance(DnsFactCollector().collect(), dict)

# Generated at 2022-06-25 00:05:53.693045
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    try:
        dns_fact_collector_0 = DnsFactCollector()
    except Exception as exception:
        assert type(exception) is TypeError


# Generated at 2022-06-25 00:05:55.129956
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    var = dns_fact_collector.collect()
    assert (var)

# Generated at 2022-06-25 00:06:00.841811
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0 is None or var_0 == {}



# Generated at 2022-06-25 00:06:06.395968
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert (dns_fact_collector_0.name == 'dns')
    assert (dns_fact_collector_0._fact_ids == set())


# Generated at 2022-06-25 00:06:45.707420
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector() is not None
# Test Case for test_case_0 method of DnsFactCollector

# Generated at 2022-06-25 00:06:48.241699
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert dns_fact_collector_0.collect() is None
    assert dns_fact_collector_0.name == 'dns'

# Generated at 2022-06-25 00:06:52.997642
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert var_0

# Generated at 2022-06-25 00:06:55.681410
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()


# Generated at 2022-06-25 00:06:57.631857
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()


# Generated at 2022-06-25 00:07:00.543141
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:07:02.452620
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()


# Generated at 2022-06-25 00:07:03.360777
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()


# Generated at 2022-06-25 00:07:04.190530
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # test_case_0
    test_case_0()

# Generated at 2022-06-25 00:07:07.417177
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    assert var_1['dns']['nameservers'][0] == '1.2.3.4'



# Generated at 2022-06-25 00:07:50.056405
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_0 = DnsFactCollector()
    assert isinstance(dns_fact_collector_0, DnsFactCollector)


# Generated at 2022-06-25 00:07:50.477530
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    assert True is True

# Generated at 2022-06-25 00:07:52.948986
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_obj = DnsFactCollector()


# Generated at 2022-06-25 00:07:57.061106
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()

# Generated at 2022-06-25 00:07:59.133144
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_1 = dns_fact_collector_0.collect()
    var_1 = dns_fact_collector_0.collect()



# Generated at 2022-06-25 00:08:02.485047
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1._fact_ids == set()
    assert dns_fact_collector_1.name == 'dns'


# Generated at 2022-06-25 00:08:06.841637
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 00:08:10.867238
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

    print(var_0)

# Generated at 2022-06-25 00:08:15.911149
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()
    nameservers = ['192.168.1.10']
    domain = 'example.org'
    search = ['example.com', 'example.net']
    sortlist = ['192.168.0.0/255.255.0.0']
    options = {'timeout': 2, 'attempts': 3}

# Generated at 2022-06-25 00:08:25.468956
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()
    assert 'dns' in var_0
    assert var_0['dns']
    assert 'domain' in var_0['dns']
    assert var_0['dns']['domain'] == 'foo.example.com'
    assert 'nameservers' in var_0['dns']
    assert 'nameserver 10.2.3.4' in var_0['dns']['nameservers']
    assert 'search' in var_0['dns']
    assert 'search foo.example.com bar.example.com' in var_0['dns']['search']
    assert 'sortlist' in var_0['dns']

# Generated at 2022-06-25 00:10:04.167393
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'

# Generated at 2022-06-25 00:10:08.841975
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_1 = DnsFactCollector()
    assert dns_fact_collector_1.name == 'dns'
    assert dns_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:10:10.719381
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_1 = DnsFactCollector()
    var_1 = dns_fact_collector_1.collect()
    assert (var_1 == {})

# Generated at 2022-06-25 00:10:14.991798
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()

# Generated at 2022-06-25 00:10:16.665075
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()


# Generated at 2022-06-25 00:10:18.055607
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector().name == 'dns'
    assert DnsFactCollector()._fact_ids == set()
    

# Generated at 2022-06-25 00:10:22.647799
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector_0 = DnsFactCollector()
    var_0 = dns_fact_collector_0.collect()

    assert  isinstance(var_0, dict)

# Generated at 2022-06-25 00:10:25.065720
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():  
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector._fact_ids == set()
    assert dns_fact_collector.name == 'dns'


# Generated at 2022-06-25 00:10:34.045846
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
  file_content_0 = 'nameserver 10.11.12.13'
  file_content_1 = 'nameserver 10.11.12.13\nnameserver 10.11.12.14'
  file_content_2 = 'nameserver 10.11.12.13\nnameserver 10.11.12.14\ndomain TEST.DOMAIN'
  file_content_3 = 'domain TEST.DOMAIN\nnameserver 10.11.12.13\nnameserver 10.11.12.14\n'
  file_content_4 = '; Comment\n\ndomain TEST.DOMAIN\nnameserver 10.11.12.13\nnameserver 10.11.12.14\n'

# Generated at 2022-06-25 00:10:35.551359
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_fact_collector.collect()