

# Generated at 2022-06-20 19:22:13.697512
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    output = DnsFactCollector()
    assert output.name == 'dns'
    assert output._fact_ids == set()


# Generated at 2022-06-20 19:22:20.334533
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == "dns"
    assert isinstance(dns_fact_collector._fact_ids, set)
    assert len(dns_fact_collector._fact_ids) == 0

# Generated at 2022-06-20 19:22:27.987156
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    output_dict = {'dns': {'nameservers': ['8.8.8.8', '8.8.4.4'], 'domain': 'cloudsigma.com', 'search': ['cloudsigma.com'], 'sortlist': ['10.152.2.0/24 10.152.1.0/24'], 'options': {'attempts': '5', 'timeout': '20'}}}
    dnsFacts = DnsFactCollector()
    output = dnsFacts.collect()
    # assert output == output_dict


# Generated at 2022-06-20 19:22:34.131522
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    """
    Test if collect method of DnsFactCollector returns a dict
    with 'dns' key.
    """
    # Setup
    dfc = DnsFactCollector()

    # Exercise
    facts = dfc.collect()

    # Verify
    assert 'dns' in facts


# Generated at 2022-06-20 19:22:40.586237
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    """ Unit test for constructor of class DnsFactCollector """
    dns_fact_collector = DnsFactCollector()
    assert isinstance(dns_fact_collector, DnsFactCollector)
    assert dns_fact_collector.name == 'dns'

# Generated at 2022-06-20 19:22:43.689536
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    myDnsFactCollector = DnsFactCollector()
    assert myDnsFactCollector.name == 'dns'
    assert myDnsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:22:47.518448
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    dns_facts = dns_collector.collect()
    assert dns_facts == 'test'

# Generated at 2022-06-20 19:22:51.107554
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    result = DnsFactCollector()
    assert result
    assert result.name == 'dns'
    assert result._fact_ids == set()


# Generated at 2022-06-20 19:22:56.229431
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    dns_facts = DnsFactCollector().collect(collected_facts=None)

    assert 'dns' in dns_facts

    dns = dns_facts['dns']

    assert 'nameservers' in dns
    assert 'search' in dns
    assert 'domain' in dns
    assert 'options' in dns
    assert 'sortlist' in dns

# Generated at 2022-06-20 19:23:01.201127
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    fact_collector = DnsFactCollector()
    assert fact_collector.name == 'dns'
    assert type(fact_collector.collect(collected_facts=dict())) == dict

# Generated at 2022-06-20 19:23:22.028019
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    
    # Run test
    assert dns_fact_collector.collect() == {
        "dns": {
            "nameservers": [
                "127.0.0.1"
            ]
        }
    }

# Generated at 2022-06-20 19:23:29.103632
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dnsFC = DnsFactCollector()
    assert dnsFC._name == "dns"
    assert isinstance(dnsFC._fact_ids, set) and len(dnsFC._fact_ids) == 0
    assert dnsFC.collect() == {'dns': {'dns': {'nameservers': ['192.168.1.254'], 'domain': 'nati.com', 'search': ['nati.com'], 'sortlist': ['10.0.0.0/255.0.0.0']}}}

# Generated at 2022-06-20 19:23:30.778464
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'

# Generated at 2022-06-20 19:23:36.254729
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector.dns import DnsFactCollector
    assert isinstance(collector.FACTS_COLLECTORS['dns'], DnsFactCollector)


# Generated at 2022-06-20 19:23:39.206591
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    obj = DnsFactCollector()
    assert obj.name == 'dns'

# Generated at 2022-06-20 19:23:46.525395
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    print("\nDns facts:\n")
    for line in str(dns_facts).splitlines():
        print("  "+line)
    assert len(dns_facts) > 0


if __name__ == '__main__':
    test_DnsFactCollector_collect()

# Generated at 2022-06-20 19:23:48.273715
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    obj = DnsFactCollector()
    assert hasattr(obj, 'collect')

# Generated at 2022-06-20 19:23:51.129500
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    x = DnsFactCollector()
    assert x.name == 'dns'

# Generated at 2022-06-20 19:23:54.781247
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():

    obj = DnsFactCollector()
    assert obj.name == 'dns'
    assert obj.collect() == {}
    assert obj.get_facts() == {}

# Generated at 2022-06-20 19:24:00.542828
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['nameservers'] == ['127.0.0.53']
    assert dns_facts['dns']['search'] == ['robertdebock.nl']
    assert dns_facts['dns']['options']['ndots'] == 1
    assert dns_facts['dns']['domain'] == 'robertdebock.nl'
    assert dns_facts['dns']['sortlist'] == ['127.0.0.1']

# Generated at 2022-06-20 19:24:17.126307
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    fact_collector = DnsFactCollector()
    assert fact_collector.name == 'dns'

# Generated at 2022-06-20 19:24:23.457920
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector
    from ansible.module_utils.facts.collector import DnsFactCollector
    import os

    dns_facts = DnsFactCollector()

    collected_facts = dns_facts.collect()
    assert isinstance(collected_facts, dict)
    assert collected_facts == {'dns': {'nameservers': ['8.8.8.8'], 'domain': 'example.com', 'search': [], 'options': {'timeout': '2'}}}

# Generated at 2022-06-20 19:24:33.587683
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()

    input_content = '''
#; generated by /usr/sbin/dhclient-script
search localdomain
nameserver 8.8.8.8
nameserver 8.8.4.4
'''

    output_facts = dns_fact_collector.collect(get_file_content=lambda x: input_content)
    assert 'dns' in output_facts
    assert 'domain' not in output_facts['dns']
    assert 'nameservers' in output_facts['dns']
    assert output_facts['dns']['nameservers'][0] == '8.8.8.8'
    assert output_facts['dns']['nameservers'][1] == '8.8.4.4'

# Generated at 2022-06-20 19:24:37.083425
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert 'dns' in dns_facts._fact_ids

# Generated at 2022-06-20 19:24:41.666706
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # Test the instantiation of class DnsFactCollector
    test_dns_fact_collector = DnsFactCollector()
    assert test_dns_fact_collector is not None
    assert test_dns_fact_collector.name == 'dns'
    assert test_dns_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:24:47.606034
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()

    dns_fact_collector = DnsFactCollector()
    assert isinstance(dns_fact_collector,DnsFactCollector)

    return True

# Generated at 2022-06-20 19:24:49.470598
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    fact_collector = DnsFactCollector()
    assert fact_collector.name == 'dns'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:24:55.760395
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()
    assert dns_fact_collector.collect() == {}

# Generated at 2022-06-20 19:24:58.824323
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fc = DnsFactCollector()
    assert dns_fc._fact_ids == set()
    assert dns_fc.name == 'dns'

# Generated at 2022-06-20 19:25:07.373815
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns = DnsFactCollector()
    facts = dns.collect()

    assert 'dns' in facts
    assert 'nameservers' in facts['dns']
    assert facts['dns']['nameservers'] is not None
    assert isinstance(facts['dns']['nameservers'], list)
    assert len(facts['dns']['nameservers']) > 0

# Generated at 2022-06-20 19:25:38.373441
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    c = DnsFactCollector()
    collected_facts = c.collect()
    assert isinstance(collected_facts, dict)
    assert 'dns' in collected_facts


# Generated at 2022-06-20 19:25:40.504482
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    DnsFactCollector.collect()

# Generated at 2022-06-20 19:25:50.608721
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector

    # instantiate a FakeModule without fail_json
    fake_module = FakeModule(None)

    # instantiate a FakeFactsCollector
    fake_factsCollector = FactsCollector(fake_module, [])

    # instantiate a DnsFactCollector
    dnsfactcollector = DnsFactCollector(fake_module, fake_factsCollector)


# Generated at 2022-06-20 19:25:53.590645
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    collector = DnsFactCollector()
    assert collector is not None

# Generated at 2022-06-20 19:25:58.495945
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    ansible_module = None
    collected_facts = { 'dns': None }
    expected_facts = { 'dns': {
        'nameservers': [ '1.2.3.4', '5.6.7.8' ],
        'sortlist': [ '1.2.3.4/16', '5.6.7.8/16' ],
        'options': { 'edns0': True, 'timeout:1': True, 'attempts:2': True },
    }}
    test_collector = DnsFactCollector()


# Generated at 2022-06-20 19:26:07.745878
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dnf = DnsFactCollector()
    dnf._module = {'fact_path': '', 'run_command': False}
    res = dnf.collect()
    assert 'dns' in res
    assert 'nameservers' in res['dns']
    assert 'domain' in res['dns']
    assert 'search' in res['dns']
    assert 'sortlist' in res['dns']
    assert 'options' in res['dns']

# Generated at 2022-06-20 19:26:10.769904
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    collector = DnsFactCollector()
    assert collector.name == 'dns'
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:26:14.134283
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns = DnsFactCollector()
    assert dns
    assert dns.name == 'dns'
    assert dns._fact_ids == set()

# Generated at 2022-06-20 19:26:17.406421
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dnsFactCollectorObj = DnsFactCollector()
    assert dnsFactCollectorObj
    assert dnsFactCollectorObj.name == 'dns'

# Generated at 2022-06-20 19:26:20.103730
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    res = DnsFactCollector()
    assert res is not None
    assert res._fact_ids == set()


# Generated at 2022-06-20 19:27:38.056738
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    test_data={
        'dns': {
            'nameservers': [ '192.168.1.1' ],
            'options': { 'edns0': True }
        }
    }

    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[], type='list')
    })
    collector = DnsFactCollector(module=module)
    test_output = collector.collect()

    assert test_output == test_data


# Generated at 2022-06-20 19:27:41.244605
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert isinstance(DnsFactCollector(None), DnsFactCollector)

# Generated at 2022-06-20 19:27:42.055540
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:27:47.383778
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    collector = DnsFactCollector()
    assert collector.name == 'dns', 'Expected name == "dns", got {0}'.format(collector.name)
    assert len(collector._fact_ids) == 0, 'Expected _fact_ids to be 0, got {0}'.format(len(collector._fact_ids))

# Generated at 2022-06-20 19:27:59.873417
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Name of function to be tested
    function_name = 'collect'

    # Create object and populate dns facts
    dnsfactcollector = DnsFactCollector()
    dns_facts = dnsfactcollector.collect()

    # Assert if nameservers are present in dns facts
    assert dns_facts['dns']['nameservers'] != None

    # Assert if domain is present in dns facts
    assert dns_facts['dns']['domain'] != None

    # Assert if search is present in dns facts
    assert dns_facts['dns']['search'] != None

    # Assert if sortlist is present in dns facts
    assert dns_facts['dns']['sortlist'] != None

    # Assert if options is present in dns facts
    assert d

# Generated at 2022-06-20 19:28:03.276402
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_collector = DnsFactCollector()
    assert dns_collector.name == 'dns'
    assert dns_collector._fact_ids == set()

# Generated at 2022-06-20 19:28:06.714584
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.FACT_NAMES == 'dns'


# Generated at 2022-06-20 19:28:11.509130
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_collector = DnsFactCollector()
    assert dns_collector.name == 'dns'
    assert dns_collector._fact_ids is not None

# Generated at 2022-06-20 19:28:18.570385
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dnsFactCollector = DnsFactCollector()
    print('dnsFactCollector.name ' + dnsFactCollector.name)
    print('dnsFactCollector._fact_ids ' + str(dnsFactCollector._fact_ids))
    assert dnsFactCollector.name == 'dns'
    assert dnsFactCollector._fact_ids == set()



# Generated at 2022-06-20 19:28:24.558730
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    fixture = None
    expected = {'dns': {'search': ['example.com'], 'nameservers': ['10.0.0.1'], 'options': {'rotate': True}, 'domain': 'example.com'}}
    with open('test/fixtures/DnsFactCollector_collect.txt') as f:
        fixture = f.read()
    fact_collector = DnsFactCollector()
    actual = fact_collector.collect(None, fixture)
    assert actual == expected

# Generated at 2022-06-20 19:31:09.240529
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector.collect(DnsFactCollector)
    assert dns_facts == {}

# Generated at 2022-06-20 19:31:11.955506
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dfc = DnsFactCollector()
    assert dfc.name == 'dns'
    assert 'dns' in dfc.collect()

# Generated at 2022-06-20 19:31:12.820950
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()

# Generated at 2022-06-20 19:31:16.567935
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    from ansible.module_utils.facts.collector import Collector

    assert not hasattr(Collector, 'dns')
    obj = DnsFactCollector()
    assert hasattr(Collector, 'dns')
    assert isinstance(Collector.dns, DnsFactCollector)


# Generated at 2022-06-20 19:31:21.751223
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    """Test DnsFactCollector.collect"""
    # Module import
    import ansible.module_utils.facts.collector

    resolvconf = '''\
# comment
;comment
nameserver 192.168.1.1
nameserver 192.168.1.2
sortlist 10.0.0.0/8
search example.com example.org
domain example.net
options attempts:5 timeout:1 rotate
'''


# Generated at 2022-06-20 19:31:29.755958
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import get_collector_class

    my_collector = get_collector_class('DnsFactCollector')
    assert issubclass(my_collector, Collector)
    assert issubclass(my_collector, BaseFactCollector)
    assert issubclass(my_collector, DnsFactCollector)

    # TODO: implement collect test

# Generated at 2022-06-20 19:31:32.218789
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collectors.dns import DnsFactCollector
    dnstest = DnsFactCollector()
    dns_facts = dnstest.collect()
    assert isinstance(dns_facts, dict)

# Generated at 2022-06-20 19:31:37.754526
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    collector = DnsFactCollector()
    facts_dict = dict()
    result = collector.collect(collected_facts=facts_dict)
    # Tests that the list of keys in the result is what we expect
    assert set(result.keys()) == set(['dns'])
    assert set(result['dns'].keys()) == set(['nameservers', 'domain', 'search',
                                             'sortlist', 'options'])
    options = result['dns']['options']
    assert set(options.keys()) == set(['ndots', 'timeout', 'attempts'])

# Generated at 2022-06-20 19:31:41.873776
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dfc = DnsFactCollector()
    assert dfc.name == 'dns'
    assert dfc._fact_ids == set()

# Generated at 2022-06-20 19:31:45.265941
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dfc = DnsFactCollector()
    assert dfc.name == 'dns'
    assert dfc._fact_ids == set()

