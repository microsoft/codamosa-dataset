

# Generated at 2022-06-20 19:22:13.736356
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    collector = DnsFactCollector()
    assert isinstance(collector, DnsFactCollector)

# Generated at 2022-06-20 19:22:21.013943
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    module = DnsFactCollector()

    results = dict(ansible_facts=dict(dns=dict(
        nameservers=[u'1.1.1.1',
                     u'8.8.8.8',
                     u'127.0.0.1']
    )))
    assert module.collect(collected_facts=results) == results

# Generated at 2022-06-20 19:22:22.452971
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    DnsFactCollector.collect()

# Generated at 2022-06-20 19:22:29.951422
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible_collections.community.general.plugins.module_utils.facts.collectors.dns.DnsFactCollector import DnsFactCollector

    # mock get_file_content
    def mock_get_file_content(filename, default):
      if filename == '/etc/resolv.conf':
        return "nameserver 10.3.10.4\nnameserver 8.8.8.8\nsearch ciscolabs.com qa.ciscolabs.com qalabs.com\ndomain ciscolabs.com\noptions timeout:1 attempts:1"

    # mock module
    class MockModule(object):
        pass

    dnsfact = DnsFactCollector()
    dnsfact.get_file_content = mock_get_file_content


# Generated at 2022-06-20 19:22:33.692110
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_collector = DnsFactCollector()
    assert dns_collector.name == 'dns'
    assert dns_collector.fact_id_map == {'dns': 'dns'}


# Generated at 2022-06-20 19:22:42.424155
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    dns_facts = dns_collector.collect()
    assert 'dns' in dns_facts
    assert dns_facts['dns'] == {'nameservers': ['8.8.8.8'], 'domain': 'gaia-7', 'search': ['gaia-7'], 'sortlist': [], 'options': {}}

# Generated at 2022-06-20 19:22:47.444270
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert BaseFactCollector.name != DnsFactCollector.name
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()
    assert DnsFactCollector.collect() == {'dns': {}}

# Generated at 2022-06-20 19:22:48.854373
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()

# Generated at 2022-06-20 19:22:56.797882
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.utils import get_file_content

    test_data_dir = 'test/unit/module_utils/facts/collector/dns/testdata'
    search_path = os.path.join(test_data_dir, 'omit*')
    omitted_files = glob.glob(search_path)

    for omitted_file in sorted(omitted_files):
        path = os.path.join(test_data_dir, omitted_file)
        result = {}
        filehandle = open(path, 'r')
        lines = filehandle.readlines()
        filehandle.close()

        data_lines = []


# Generated at 2022-06-20 19:23:07.837951
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    result = dns_collector.collect()

    # Check the results
    assert result['dns']['nameservers'][0] == '192.168.1.102'
    assert result['dns']['nameservers'][1] == '192.168.1.103'
    assert result['dns']['domain'] == 'example.com'
    assert result['dns']['search'][0] == 'sales.example.com'
    assert result['dns']['search'][1] == 'eng.example.com'
    assert result['dns']['options']['timeout'] == '2'
    assert result['dns']['options']['attempts'] == '4'

# Generated at 2022-06-20 19:23:24.909874
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dnsfact_collector = DnsFactCollector()
    res = dnsfact_collector.collect()
    print(res)

    dnsfact_collector.name

# Generated at 2022-06-20 19:23:25.967181
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()


# Generated at 2022-06-20 19:23:33.016726
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    collector = DnsFactCollector()
    assert collector.collect() == {
        'dns': {
            'nameservers': ['8.8.8.8', '8.8.4.4'],
            'domain': 'eng.ansible.com'
        }
    }


# Generated at 2022-06-20 19:23:36.874472
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:23:40.907560
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    a = DnsFactCollector()
    assert a.name == 'dns'
    assert a._fact_ids == set()


# Generated at 2022-06-20 19:23:47.946050
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.dns import DnsFactCollector
    dns_facts = {}
    dns_facts['dns'] = {}

    for line in get_file_content('/etc/resolv.conf', '').splitlines():
        if line.startswith('#') or line.startswith(';') or line.strip() == '':
            continue
        tokens = line.split()
        if len(tokens) == 0:
            continue

# Generated at 2022-06-20 19:23:52.271037
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dfc = DnsFactCollector()
    assert dfc.name == "dns"
    assert dfc.priority == 100

# Generated at 2022-06-20 19:23:56.371904
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_coll = DnsFactCollector()
    assert dns_fact_coll.name == 'dns'
    assert isinstance(dns_fact_coll._fact_ids, set)

# Generated at 2022-06-20 19:23:58.660203
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:24:06.676511
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts_class = DnsFactCollector()
    dns_facts = dns_facts_class.collect()
    assert type(dns_facts) == dict
    assert len(dns_facts) > 0

    assert type(dns_facts['dns']) == dict
    assert len(dns_facts['dns']) > 0

# Generated at 2022-06-20 19:24:39.554765
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Test construction and selectors should return the same value
    # (For a more comprehensive test of this method, see test_utils.py)
    test_obj = DnsFactCollector()
    assert test_obj.collect() == {'dns': {'nameservers': ['127.0.1.1'], 'domain': 'localdomain'}}


# Generated at 2022-06-20 19:24:45.020964
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    # Test case #1 - regular file
    test_file1 = open('test/unit/modules/test_dns_fact_collector_1.txt', 'r')
    test_content1 = test_file1.read()
    test_file1.close()

    def get_file_content_mock1(file_path, fallback=None):
        return test_content1
    # End

    # Test case #2 - empty file
    test_file2 = open('test/unit/modules/test_dns_fact_collector_2.txt', 'r')
    test_content2 = test_file2.read()
    test_file2.close()

    def get_file_content_mock2(file_path, fallback=None):
        return test_content2
    # End

    # Test

# Generated at 2022-06-20 19:24:48.634672
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    """This is a test for creating an instance of DnsFactCollector
    """
    DnsFactCollector()

# Generated at 2022-06-20 19:24:52.089981
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_collector = DnsFactCollector()

    assert dns_collector is not None

# Generated at 2022-06-20 19:25:00.517473
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts import ansible_collected_facts
    from ansible.module_utils.facts.collector import FactsCollector

    test_facts = {}
    for fact_class in FactsCollector.fact_classes:
        test_facts[fact_class.name] = fact_class.collect(ansible_collected_facts)

    assert test_facts['dns']['dns']['nameservers'] == ['10.10.11.2']
    assert test_facts['dns']['dns']['domain'] == 'example.com'

# Generated at 2022-06-20 19:25:05.330775
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == "dns"
    assert len(dns_fact_collector._fact_ids) == 0

# Generated at 2022-06-20 19:25:12.302548
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    mydns = DnsFactCollector()
    # Testing whether returned dict has expected result or not
    assert mydns.collect()['dns']['nameservers'][0] == '192.168.1.254'
    assert mydns.collect()['dns']['domain'] == 'localdomain'
    assert mydns.collect()['dns']['search'][0] == 'localdomain'
    assert mydns.collect()['dns']['sortlist'][0] == '192.168.1.0/24'
    assert mydns.collect()['dns']['options']['timeout'] == '2'

# Generated at 2022-06-20 19:25:13.672449
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    #TODO
    pass

# Generated at 2022-06-20 19:25:16.294402
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector_collection = DnsFactCollector()
    assert dns_fact_collector_collection.name == 'dns'

# Generated at 2022-06-20 19:25:19.971221
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()
    assert isinstance(DnsFactCollector._fact_ids, set)

# Generated at 2022-06-20 19:25:48.056081
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert not DnsFactCollector._fact_ids

# Generated at 2022-06-20 19:25:57.773785
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    # Execute module
    dns_fact_module = DnsFactCollector()
    facts = dns_fact_module.collect(None, None)

    assert isinstance(facts, dict)
    assert 'dns' in facts
    assert isinstance(facts['dns'], dict)

    # Check some attributes
    assert isinstance(facts['dns']['nameservers'], list)
    assert facts['dns']['nameservers'] != []

# Generated at 2022-06-20 19:26:00.927551
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    fact = DnsFactCollector()
    assert fact.name == 'dns'

# Generated at 2022-06-20 19:26:12.375122
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    test_dns_collector = DnsFactCollector()
    test_dns_collector.name = 'test_dns'
    dns_facts = test_dns_collector.collect()
    assert dns_facts['test_dns'] == {
        'domain': 'ansible.com',
        'nameservers': ['1.1.1.1', '8.8.4.4'],
        'search': ['ansible.com', 'redhat.com'],
        'sortlist': ['10.0.0.0/24 192.168.100.0/24'],
        'options': {
            'ndots': '1',
            'timeout': '1'
        }
    }


# Generated at 2022-06-20 19:26:24.299452
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    # Create an instance of DnsFactCollector
    dns_fact_collector = DnsFactCollector()

    # Test the collect method
    dns_facts = dns_fact_collector.collect()

    # Test for presence of keys
    assert 'dns' in dns_facts.keys()
    if 'nameservers' in dns_facts['dns'].keys():
        assert isinstance(dns_facts['dns']['nameservers'], list)
    if 'domain' in dns_facts['dns'].keys():
        assert isinstance(dns_facts['dns']['domain'], str)
    if 'search' in dns_facts['dns'].keys():
        assert isinstance(dns_facts['dns']['search'], list)

# Generated at 2022-06-20 19:26:27.993356
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # Instantiate the DnsFactCollector object
    dns_obj = DnsFactCollector()

    # Check if the object is correctly initialized
    assert dns_obj.name == 'dns'
    assert dns_obj.collect() == {'dns': {}}

# Generated at 2022-06-20 19:26:29.982731
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dfc = DnsFactCollector()
    assert dfc.name == 'dns'

# Generated at 2022-06-20 19:26:35.335635
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    detached_resolve_conf = '''
# this is file is managed by ansible
domain test.local
search test.local
sortlist 10.0.0.0/8
options debug
nameserver 10.0.0.5
nameserver 10.0.0.1
'''
    facts = {}
    expected = dict(
        dns=dict(
            nameservers=['10.0.0.5', '10.0.0.1'],
            domain='test.local',
            search=['test.local'],
            sortlist=['10.0.0.0/8'],
            options=dict(debug=True)
        )
    )

    collector = DnsFactCollector()
    collector.collect(dns_conf=detached_resolve_conf, facts=facts)

    assert expected

# Generated at 2022-06-20 19:26:39.689249
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    from ansible.module_utils.facts.utils import get_file_content
    collector = DnsFactCollector()
    assert collector.name == 'dns'
    assert collector._fact_ids == set()
    assert collector.collect() == { "dns": { "domain": "None", "nameservers": [ "192.168.1.254" ], "options": { "rotate": True, "timeout": "2", "attempts": "5" }, "search": [ "None" ] } }

# Generated at 2022-06-20 19:26:42.164854
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_collector = DnsFactCollector()
    assert dns_collector.name == 'dns'

# Generated at 2022-06-20 19:27:57.724245
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    assert DnsFactCollector.collect() == {'dns': {'nameservers': ['127.0.0.1'], 'options': {'attempts': '2', 'timeout': '2'}}}

DnsFactCollector()

# Generated at 2022-06-20 19:27:59.644487
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass

# Generated at 2022-06-20 19:28:06.124610
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    assert dns_facts is not None
    assert 'dns' in dns_facts
    assert 'nameservers' in dns_facts['dns']
    assert len(dns_facts['dns']['nameservers']) > 0

# Generated at 2022-06-20 19:28:09.603442
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    module = object()
    collected_facts = object()
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.collect(module, collected_facts) == {'dns': {}}

# Generated at 2022-06-20 19:28:10.447242
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:28:15.760642
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    test_obj = DnsFactCollector()
    result = test_obj.collect()
    assert 'dns' in result
    assert 'nameservers' in result['dns']
    assert 'options' in result['dns']

# Generated at 2022-06-20 19:28:16.805225
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.collect() == {'dns': {}}

# Generated at 2022-06-20 19:28:18.775522
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    collected_facts = dns_collector.collect()
    assert type(collected_facts) is dict

# Generated at 2022-06-20 19:28:26.097822
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    fc = DnsFactCollector()
    test_data = {
        "dns": {
            "nameservers": [
                "192.168.1.254",
                "192.168.1.10"
            ],
            "domain": "example.com",
            "search": [
                "example1.com",
                "example2.com"
            ],
            "sortlist": [
                "192.168.1.0"
            ],
            "options": {
                "timeout": 2
            }
        }
    }
    assert fc.collect() == test_data

# Generated at 2022-06-20 19:28:30.261509
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    c = DnsFactCollector()
    assert c.name == 'dns'
    assert not c._fact_ids

# Generated at 2022-06-20 19:31:15.837591
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:31:16.984677
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns = DnsFactCollector()
    assert dns._fact_ids == set()

# Generated at 2022-06-20 19:31:19.431605
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns = DnsFactCollector()
    assert isinstance(dns, DnsFactCollector)
    assert dns.name == 'dns'

# Generated at 2022-06-20 19:31:20.694450
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()


# Generated at 2022-06-20 19:31:31.803914
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    """
    Test method collect by class DnsFactCollector
    """

    # Create instance of class DnsFactCollector
    dns_fact_collector = DnsFactCollector()
    # Create instance of class ModuleStub
    module_stub = ModuleStub()
    # Create instance of class CollectedFactsStub
    collected_facts_stub = CollectedFactsStub()

    # Invoke method collect by class DnsFactCollector
    result = dns_fact_collector.collect(module_stub, collected_facts_stub)

    # Check expected result

# Generated at 2022-06-20 19:31:37.085676
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = dict(
        dns = dict(
            nameservers = [
                '192.168.1.1',
                '192.168.1.2',
            ],
            domain = 'example.com',
            search = [
                'example.com',
                'example.org',
            ],
            sortlist = [
                '192.168.1.0/255.255.255.0',
            ],
            options = dict(
                timeout = '1',
                attempts = '5',
            ),
        ),
    )

    module = None

    c = DnsFactCollector()
    assert c.collect(module) == dns_facts

# Generated at 2022-06-20 19:31:39.237907
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    d = DnsFactCollector()
    assert d.name == 'dns'

# Generated at 2022-06-20 19:31:50.558926
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    hostvars = {}
    dns_fact_collector = DnsFactCollector(hostvars)

    hostvars = {}
    dns_facts = dns_fact_collector.collect(hostvars)
    assert 'dns' in dns_facts
    assert len(dns_facts['dns']) == 0

    hostvars = {'ansible_facts': {'dns': {'nameservers':['10.1.1.1'],\
                                          'domain': 'demo.net',\
                                          'search':['demo.net', 'demo2.net'],\
                                          'sortlist': ['192.168.1.0'],\
                                          'options':{'ndots': '3', 'timeout': '6'}\
                                         }}}

# Generated at 2022-06-20 19:31:54.648700
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_obj=DnsFactCollector()
    assert dns_obj.name == 'dns', "dns_obj.name is not 'dns'"
    assert dns_obj._fact_ids == set(), "dns_obj._fact_ids != set()"

# Generated at 2022-06-20 19:31:57.113226
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    obj = DnsFactCollector()
    obj.collect()


# vim: set et ts=4 sw=4 :