

# Generated at 2022-06-20 19:22:13.207103
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector() is not None

# Generated at 2022-06-20 19:22:16.152836
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_facts = dns_fact_collector.collect()
    #assert dns_facts['dns']['nameservers'] == ['192.168.33.10', '8.8.8.8']
    assert isinstance(dns_facts['dns'], dict)

# Generated at 2022-06-20 19:22:17.106222
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:22:20.861273
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    collector = DnsFactCollector()
    assert collector.name == 'dns', 'Test Failed: name should be "dns" but it is %s' % collector.name

# Generated at 2022-06-20 19:22:27.957960
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dnsCollector = DnsFactCollector()
    dnsFacts = dnsCollector.collect()
    assert dnsFacts['dns']
    assert 'nameservers' in dnsFacts['dns']
    assert 'domain' in dnsFacts['dns']
    assert 'search' in dnsFacts['dns']
    assert 'sortlist' in dnsFacts['dns']
    assert 'options' in dnsFacts['dns']

# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-20 19:22:30.170451
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns = DnsFactCollector()
    assert dns.collect() == {}

# Generated at 2022-06-20 19:22:35.753868
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()
    assert dns_fact_collector.collect() is None

# Generated at 2022-06-20 19:22:42.930598
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    class MockModule(object):
        pass

    module = MockModule()
    module.params = {}

    # Test with real data (whenever possible)
    fc = DnsFactCollector()
    facts = fc.collect(module=module)
    assert facts['dns']['nameservers'] == ['127.0.0.1']
    assert facts['dns']['domain'] == 'example.com'
    assert facts['dns']['search'] == ['example.com']
    assert facts['dns']['search'] == ['example.com']
    assert facts['dns']['sortlist'] == ['10.2.3.4']
    assert facts['dns']['options'] == {'ndots': 2}

# Generated at 2022-06-20 19:22:54.943400
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dfc = DnsFactCollector()
    fact_data = dfc.collect(module=None, collected_facts=None)
    dns_facts = fact_data['dns']
    assert dns_facts['nameservers'] == ['192.168.0.1']
    assert dns_facts['domain'] == 'example.org'
    assert dns_facts['search'] == ['example.org', 'example.gov']
    assert dns_facts['sortlist'] == ['192.168.1.0/24', '10.0.0.0']
    assert dns_facts['options']['timeout'] == '2'
    assert dns_facts['options']['attempts'] == '1'
    assert dns_facts['options']['rotate'] == True

# Generated at 2022-06-20 19:22:56.168974
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:23:06.527411
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    obj = DnsFactCollector()
    assert obj.name == 'dns'

# Generated at 2022-06-20 19:23:15.094629
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    test1 = '''
options ndots:1
domain localdomain
search localdomain
nameserver 127.0.0.1
'''

    test2 = '''
options ndots:2
domain localdomain
search localdomain
nameserver 127.0.0.1
nameserver 8.8.8.8
'''

    test3 = '''
search localdomain
'''

    test4 = '''
options ndots:1
nameserver 127.0.0.1
'''

    test5 = '''
search localdomain
search localdomain2
'''

    # Reference output from test1

# Generated at 2022-06-20 19:23:16.976148
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()


# Generated at 2022-06-20 19:23:29.072178
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    #Unit test for method collect of class DnsFactCollector when
    #line starting with # or ; or blank line
    line = ['#nameserver', 'nameserver', ';nameserver', '    ',
            'nameserver', 'nameserver', 'nameserver 1.2.3.4']
    for l in line:
        res = DnsFactCollector.collect(
            DnsFactCollector(), MockModule(params={'content': l})
        )
        assert res == {}

    #Unit test for method collect of class DnsFactCollector when
    #line is empty
    res = DnsFactCollector.collect(
        DnsFactCollector(), MockModule(params={'content': ''})
    )

# Generated at 2022-06-20 19:23:31.916364
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.collect() == {}

# Generated at 2022-06-20 19:23:33.302049
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()

# Generated at 2022-06-20 19:23:34.860874
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector()

# Generated at 2022-06-20 19:23:40.625128
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.dns import DnsFactCollector

    # Set up our test double
    class_under_test = 'ansible.module_utils.facts.collector.dns.DnsFactCollector'
    mock_collector = collector.FactsCollector
    mock_collector.collect_subset = lambda self, module: {}
    mock_collector.add_fact = lambda self, k, v: None
    mock_collector.get_facts = lambda self, module, collected_facts={}: {}
    mock_base = BaseFactCollector
    mock_base.get_file_content = lambda self, path, default='': self.mock

# Generated at 2022-06-20 19:23:45.386218
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns = DnsFactCollector()
    dns_facts = dns.collect()
    assert dns_facts['dns']['nameservers'] == ['192.168.1.1']

# Generated at 2022-06-20 19:23:46.806288
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns = DnsFactCollector()
    assert dns.name == 'dns'


# Generated at 2022-06-20 19:24:04.786467
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector().name == 'dns'
    assert DnsFactCollector()._fact_ids == set()


# Generated at 2022-06-20 19:24:07.989596
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    f = DnsFactCollector()
    d = f.collect()
    assert isinstance(d, dict)
    assert 'dns' in d

# Generated at 2022-06-20 19:24:20.154970
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    content = '''# comment
    ; comment
    nameserver 192.168.1.1
    nameserver 192.168.1.2
    search example.com
    search example.net
    search example.org
    search example.edu
    sortlist 1.2.3.4 4.3.2.1
    '''

    expected = {
        'dns': {
            'domain': None,
            'nameservers': ['192.168.1.1', '192.168.1.2'],
            'options': {},
            'search': ['example.com', 'example.net', 'example.org', 'example.edu'],
            'sortlist': ['1.2.3.4', '4.3.2.1'],
        }
    }

# Generated at 2022-06-20 19:24:23.707496
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    facts = DnsFactCollector()
    assert facts.name == 'dns'
    assert facts._fact_ids == set()

# Generated at 2022-06-20 19:24:31.596802
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    resolv_file = "/etc/resolv.conf"
    resolv_file_contents = "nameserver 10.1.2.3\nnameserver 8.8.8.8\ndomain example.com\nsearch example.com example2.com example3.com\nsortlist 127.0.0.1/8 192.168.1.0/24\noptions timeout:3 attempts:5\n"
    dns_collector = DnsFactCollector()
    dns_facts = dns_collector.collect(resolv_file, resolv_file_contents)
    assert 'dns' in dns_facts
    assert 'nameservers' in dns_facts['dns']
    assert 'domain' in dns_facts['dns']
    assert 'search' in d

# Generated at 2022-06-20 19:24:34.064810
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector is not None

# Generated at 2022-06-20 19:24:35.410188
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()

# Generated at 2022-06-20 19:24:38.447663
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    fact_module = DnsFactCollector()
    assert fact_module.name == 'dns'
    assert fact_module._fact_ids == set()

# Generated at 2022-06-20 19:24:42.520519
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    fact_collector = DnsFactCollector()
    result = fact_collector.collect()
    assert result == {'dns': {'domain': 'example.com',
                              'nameservers': ['1.1.1.1', '2.2.2.2'],
                              'options': {'rotate': True, 'timeout:1': True},
                              'search': ['example.com']}}

# Generated at 2022-06-20 19:24:43.848261
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    collector = DnsFactCollector()


# Generated at 2022-06-20 19:25:26.133586
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    # Constructing a test environment for DnsFactCollector
    #
    # Setup files in /etc/ folder to be used by test
    #
    CONF_NAME='resolv_test.conf'

    TEST_CONF = """
# test file
domain mydomain.example.org
search mydomain.example.org

nameserver 192.168.0.1
nameserver 8.8.8.8
    """

    # Override 'get_file_content' method of BaseFactCollector
    #
    # Return string defined above
    #
    def get_file_content(conf_file, default):
        return TEST_CONF

    # Override '_get_file_content' method of BaseFactCollector
    #
    # Return string defined above
    #

# Generated at 2022-06-20 19:25:28.042785
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    module = None
    c_facts = None
    fact = DnsFactCollector().collect(module, c_facts)
    assert fact is not None

# Generated at 2022-06-20 19:25:39.973786
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    mock_module = MagicMock()
    mock_file_content = MagicMock()
    mock_file_content.splitlines = MagicMock(return_value = ['nameserver 10.10.10.10', 'nameserver 10.10.10.11'])
    mock_get_file_content = MagicMock(return_value = mock_file_content)

    with patch.dict('sys.modules', {'ansible.module_utils.facts.utils': MagicMock(get_file_content=mock_get_file_content)}):
        fact_collector = DnsFactCollector()
        facts = fact_collector.collect(module=mock_module)

    assert facts == {'dns': {'nameservers': ['10.10.10.10', '10.10.10.11']}}

# Generated at 2022-06-20 19:25:44.146385
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dnsCollector = DnsFactCollector()
    assert dnsCollector.name == 'dns'
    assert dnsCollector._fact_ids == set()

# Generated at 2022-06-20 19:25:50.237304
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    """ Test collector collect() returns expected dictionary """
    dns_collector = DnsFactCollector()
    dns_facts = dns_collector.collect()
    assert 'dns' in dns_facts
    assert 'nameservers' in dns_facts['dns']
    assert 'domain' in dns_facts['dns']
    assert 'search' in dns_facts['dns']
    assert 'sortlist' in dns_facts['dns']
    assert 'options' in dns_facts['dns']

# Generated at 2022-06-20 19:25:53.516536
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    fact_collector = DnsFactCollector()
    # TODO: assert values and types
    assert fact_collector.name == 'dns'

# Generated at 2022-06-20 19:25:57.418793
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts = DnsFactCollector()
    assert dns_facts.name == 'dns'
    assert dns_facts._fact_ids == set()


# Generated at 2022-06-20 19:26:10.070481
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    # instantiate the DnsFactCollector class
    collect_obj = DnsFactCollector()

    # call the method collect of the class
    # with argument resolv_file_lines
    #
    # When running on an Ubuntu machine, /etc/resolv.conf
    # has the following content:
    #
    # search lab.example.com
    # nameserver 10.88.0.11
    # nameserver 10.88.0.12
    #
    # The following value for resolv_file_lines would
    # reproduce this sample file:
    #
    # resolv_file_lines = "search lab.example.com\nnameserver 10.88.0.11\nnameserver 10.88.0.12"

# Generated at 2022-06-20 19:26:13.583788
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # Create the DnsFactCollector object
    dns_obj = DnsFactCollector()

    # Check the name of the object created
    assert dns_obj.name == 'dns'

# Generated at 2022-06-20 19:26:16.006025
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    x = DnsFactCollector()
    assert hasattr(x, 'name')


# Generated at 2022-06-20 19:27:31.439245
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Setup a mock facts object: AnsibleModule()
    class MockFactsModule:
        def __init__(self):
                self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            pass

    mock_facts_module = MockFactsModule()
    mock_facts_module.params = {'gather_subset': ['!all', 'network', 'dns']}
    dns_fact_collector = DnsFactCollector()

    # Test function with mock_facts_module.
    data = dns_fact_collector.collect(mock_facts_module)
    dns_facts = data.get('dns')
    assert dns_facts

# Generated at 2022-06-20 19:27:35.361724
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    obj = DnsFactCollector()
    facts_dns = obj.collect()
    assert 'dns' in facts_dns
    assert len(facts_dns['dns']) == 0

# Generated at 2022-06-20 19:27:39.074171
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    assert DnsFactCollector().collect()['dns'].has_key('nameservers')
    assert DnsFactCollector().collect()['dns'].has_key('domain')
    assert DnsFactCollector().collect()['dns'].has_key('search')
    assert DnsFactCollector().collect()['dns'].has_key('sortlist')
    assert DnsFactCollector().collect()['dns'].has_key('options')

# Generated at 2022-06-20 19:27:42.125964
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    dns_fact_collector.collect()

# Generated at 2022-06-20 19:27:42.907926
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert True

# Generated at 2022-06-20 19:27:51.922923
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    dns_collector.resolv_conf_content = """
#
# Mac OS X Notice
#
# This file is not used by the host name and address resolution
# or the DNS query routing mechanisms used by most processes on
# this Mac OS X system.
#
# This file is automatically generated.
#
nameserver 8.8.8.8
nameserver 8.8.4.4
domain f5demo.com
search f5demo.com
"""
    collected_facts = dns_collector.collect(collected_facts={'dns':None})

# Generated at 2022-06-20 19:27:55.364936
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_collector = DnsFactCollector()
    assert dns_collector.name == 'dns'
    assert dns_collector._fact_ids == set()

# Generated at 2022-06-20 19:27:56.440594
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    DnsFactCollector.collect()

# Generated at 2022-06-20 19:27:58.635895
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector()
    results = dns_fact_collector.collect(module=None, collected_facts=None)
    assert results['dns']['domain'] == 'example.com'

# Generated at 2022-06-20 19:28:02.122136
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    val = DnsFactCollector()
    assert val.name == 'dns'
    assert val._fact_ids == set()

# Generated at 2022-06-20 19:30:45.599911
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns = DnsFactCollector()
    assert dns._fact_ids == set()
    dns_facts = dns.collect()

    assert type(dns_facts) == dict
    assert type(dns_facts['dns']) == dict

# Generated at 2022-06-20 19:30:54.736542
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_collector = DnsFactCollector()
    resolv_conf = '\n'.join([
        'domain domain1.example.com',
        'search domain2.example.com',
        'nameserver 10.10.10.10',
        'nameserver 10.10.10.11',
        'options rotate',
        'sortlist 10.0.0.0/8,10.11.12.13',
        '# comment',
    ])

# Generated at 2022-06-20 19:30:58.205824
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():

    # Create an instance of the class 'DnsFactCollector'
    dns_object = DnsFactCollector()

    # Assert the class attributes are set properly
    assert dns_object.name == 'dns'
    assert dns_object._fact_ids == set()


# Generated at 2022-06-20 19:31:00.579669
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'



# Generated at 2022-06-20 19:31:07.472357
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = {}
            self.fail_json = {}

    facts = DnsFactCollector().collect(MockModule())
    assert 'dns' in facts
    assert 'nameservers' in facts['dns']
    assert 'search' in facts['dns']
    assert 'domain' in facts['dns']


if __name__ == '__main__':
    test_DnsFactCollector_collect()

# Generated at 2022-06-20 19:31:09.317639
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    obj1 = DnsFactCollector()
    assert obj1.name == 'dns'
    assert isinstance(obj1._fact_ids, set)

# Generated at 2022-06-20 19:31:11.996166
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    x = DnsFactCollector()
    assert x.name == 'dns'
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:31:13.883585
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns = DnsFactCollector()
    assert dns.name == 'dns'
    assert dns._fact_ids == set()

# Generated at 2022-06-20 19:31:20.645295
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils._text import to_native

    result = DnsFactCollector.collect()

    assert isinstance(result, dict), "DnsFactCollector result is not a dict: %s" % to_native(result)
    assert 'dns' in result, "DnsFactCollector result has no 'dns' key: %s" % to_native(result)
    assert isinstance(result['dns'], dict), "DnsFactCollector result['dns'] is not a dict: %s" % to_native(result['dns'])

# Generated at 2022-06-20 19:31:25.060586
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # create a DnsFactCollector instance
    dns_c = DnsFactCollector()
    assert dns_c is not None