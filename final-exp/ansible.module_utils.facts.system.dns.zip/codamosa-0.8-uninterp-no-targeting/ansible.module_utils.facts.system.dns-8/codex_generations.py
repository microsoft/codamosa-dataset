

# Generated at 2022-06-20 19:22:13.657802
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    d = DnsFactCollector()
    assert d.name == 'dns'
    assert not d.collect()

# Generated at 2022-06-20 19:22:14.813572
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    pass

# Generated at 2022-06-20 19:22:20.636741
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dfc = DnsFactCollector()
    assert isinstance(dfc, BaseFactCollector)

    assert dfc.name == 'dns'
    assert dfc._fact_ids == set()

    assert dfc.collect() == {u'dns': {}}

# Generated at 2022-06-20 19:22:22.679710
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    facts = DnsFactCollector()
    assert 'dns' == facts.name

# Generated at 2022-06-20 19:22:27.066700
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns = DnsFactCollector()
    assert dns.name == "dns"
    assert dns._fact_ids == set()
    dns_hash = {'dns': {}}
    assert dns.collect(collected_facts=dns_hash) == dns_hash
    assert dns.collect() == dns_hash

# Generated at 2022-06-20 19:22:28.841303
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact = DnsFactCollector()

# Generated at 2022-06-20 19:22:35.752820
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    fact_collector = DnsFactCollector()
    dns_facts = fact_collector.collect()
    assert 'dns' in dns_facts, 'should contain dns facts'
    assert isinstance(dns_facts['dns'], dict)
    assert 'nameservers' in dns_facts['dns'], 'should contain nameservers'

# Generated at 2022-06-20 19:22:42.124523
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    hostvars = {}
    dns_facts = DnsFactCollector(hostvars).collect()
    assert 'dns' in dns_facts.keys()
    assert 'nameservers' in  dns_facts['dns'].keys()
    assert 'domain' in  dns_facts['dns'].keys()
    assert 'search' in  dns_facts['dns'].keys()
    assert 'sortlist' in  dns_facts['dns'].keys()
    assert 'options' in  dns_facts['dns'].keys()


# Generated at 2022-06-20 19:22:44.035940
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    d = DnsFactCollector()
    assert d
    assert d.name == 'dns'


# Generated at 2022-06-20 19:22:47.911536
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():

    dns_collector = DnsFactCollector()
    assert dns_collector.name == 'dns'
    assert dns_collector._fact_ids == set()

# Generated at 2022-06-20 19:23:06.111037
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    collector = DnsFactCollector()
    ansible_facts = AnsibleFactCollector().collect()
    assert collector.collect(collected_facts=ansible_facts) == \
        {'dns': {
            'domain': 'example.com',
            'nameservers': ['192.0.2.10', '192.0.2.11'],
            'search': ['example.com', 'somewhere.else'],
            'sortlist': ['192.0.2.20/24 192.0.2.21/24']
        }}

# Generated at 2022-06-20 19:23:14.767667
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collectors.network.dns import DnsFactCollector as DnsCollector

    # Create a new instance of DnsCollector
    dns_fact_collector = DnsCollector()

    # Replace the resolv.conf file with the test data file
    open("/etc/resolv.conf", 'w').close()

# Generated at 2022-06-20 19:23:20.105463
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:23:24.839224
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()
    assert isinstance(DnsFactCollector._fact_ids, set)

# Generated at 2022-06-20 19:23:25.926082
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'

# Generated at 2022-06-20 19:23:29.213920
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    a = DnsFactCollector()
    assert isinstance(a, DnsFactCollector)

# Generated at 2022-06-20 19:23:34.584987
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():

    # test the constructor, it should return a valid object
    dfc = DnsFactCollector()
    assert dfc is not None
    assert dfc.name == "dns"
    assert len(dfc._fact_ids) == 0


# Generated at 2022-06-20 19:23:35.752000
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_facts_collector = DnsFactCollector()
    assert dns_facts_collector.name == 'dns'
    assert dns_facts_collector._fact_ids == set()


# Generated at 2022-06-20 19:23:38.000283
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_collector = DnsFactCollector()
    assert dns_collector.name == 'dns'
    assert dns_collector._fact_ids == set()

# Generated at 2022-06-20 19:23:41.700928
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    x = DnsFactCollector('')
    assert x.name == 'dns'
    assert x._fact_ids == set()