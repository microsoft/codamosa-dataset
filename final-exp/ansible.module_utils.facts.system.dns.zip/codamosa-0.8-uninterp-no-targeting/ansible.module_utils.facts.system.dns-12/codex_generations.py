

# Generated at 2022-06-20 19:22:14.661239
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    print(('Called test_DnsFactCollector for module:', __name__))
    DnsFactCollector()

# Generated at 2022-06-20 19:22:19.212829
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:22:23.054841
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dnsObj = DnsFactCollector()
    assert dnsObj
    assert dnsObj.name == "dns"
    assert dnsObj._fact_ids == set()

# Generated at 2022-06-20 19:22:25.529707
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dnsFactObj = DnsFactCollector()
    assert dnsFactObj.name == 'dns'
    assert dnsFactObj._fact_ids == set()

# Generated at 2022-06-20 19:22:33.720131
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    fact_collector = DnsFactCollector()
    dns_facts = fact_collector.collect()

    assert dns_facts
    assert dns_facts['dns']
    assert 'domain' in dns_facts['dns']
    assert 'nameservers' in dns_facts['dns']
    assert 'options' in dns_facts['dns']
    assert 'search' in dns_facts['dns']
    assert 'sortlist' in dns_facts['dns']

# Generated at 2022-06-20 19:22:45.129009
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    test_file = b"""
nameserver 10.0.1.1
nameserver 10.0.1.2
domain example.com
search foo.bar baz.qux
"""
    module = AnsibleModuleMock()
    set_module_args(dict(
        path='/etc/resolv.conf',
    ))
    import ansible.module_utils.facts.network.dns
    ansible.module_utils.facts.network.dns.get_file_content = lambda path, default: test_file

    fc = DnsFactCollector(module=module)
    facts = fc.collect()


# Generated at 2022-06-20 19:22:49.571871
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()

    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:22:52.700497
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns = DnsFactCollector()
    assert dns.name == 'dns'
    assert dns.collect() == {'dns': {}}

# Generated at 2022-06-20 19:23:00.903448
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    lines = """#nameserver 10.20.30.40
nameserver 1.2.3.4
nameserver 5.6.7.8
domain foobar.example.com
search foo.org bar.example.com
sortlist 1.2.3.0/24 1.2.3.0/255.255.255.0
options debug timeout:1 attempts:2
"""
    os_name = "my_os"
    dist_name = "my_dist"
    dns_collector = DnsFactCollector(os_name, dist_name)
    dns_facts = dns_collector.collect(lines)

# Generated at 2022-06-20 19:23:04.831212
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:23:18.624825
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    pass # FIXME: implement test

# Generated at 2022-06-20 19:23:21.888450
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector is not None


# Generated at 2022-06-20 19:23:24.982980
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    fact_collector=DnsFactCollector()
    assert fact_collector.name == 'dns'

# Generated at 2022-06-20 19:23:26.328038
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    fc = DnsFactCollector()
    fc.collect()

# Generated at 2022-06-20 19:23:34.796550
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    """Test DnsFactCollector"""

    c = DnsFactCollector()
    # Test the class is correctly initialized
    assert c.name == 'dns'
    assert isinstance(c._fact_ids,set)
    assert isinstance(c._pluginname, str)
    assert isinstance(c._excluded_facts,set)
    assert isinstance(c.collect,object)

# Generated at 2022-06-20 19:23:37.161248
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set(['dns'])

# Generated at 2022-06-20 19:23:38.390885
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:23:40.830350
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns = DnsFactCollector()
    assert dns.name == 'dns'

# Generated at 2022-06-20 19:23:47.075788
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    obj = DnsFactCollector()
    result = obj.collect()
    assert result['dns']['nameservers'] == ['192.168.1.1']
    assert result['dns']['domain'] == 'example.org'
    assert result['dns']['search'] == ['example.org']
    assert result['dns']['sortlist'] == ['192.168.99.1/255.255.255.0']
    assert result['dns']['options']['ndots'] == '3'
    assert result['dns']['options']['timeout'] == '3'

# Generated at 2022-06-20 19:23:49.220986
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    assert DnsFactCollector.name == 'dns'
    assert DnsFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:24:02.756175
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    pass

# Generated at 2022-06-20 19:24:13.995611
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    resolv_conf = '''
#    # nameserver   123.45.67.89
#    search my.domain.com other.domain.com
#    domain my.domain.com
#    nameserver 123.45.67.89 other.domain.com
#    options rotate timeout:3 attempts:3 debug
#    sortlist 123.45.67.89
    nameserver   8.8.8.8
    nameserver   8.8.4.4
    domain localdomain
    search localdomain
    options rotate
    options timeout:1
    options attempts:2
    '''

# Generated at 2022-06-20 19:24:16.985280
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector().collect()
    assert dns_facts['dns']['domain'] == 'ansibledemo.com'

# Generated at 2022-06-20 19:24:24.465732
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    ''' Unit test for method collect of class DnsFactCollector '''
    def get_file_content_mock(file_path, default):
        return '''nameserver 127.0.0.1
search example.com
options debug timeout:1
domain example.com
sortlist 1.2.3.4/255.255.0.0 5.6.7.8/255.255.255.0
'''
    def collect_mock(self, module=None, collected_facts=None):
        return self.collect()

    from ansible.module_utils.facts.collector import DnsFactCollector
    DnsFactCollector.get_file_content = get_file_content_mock
    DnsFactCollector.collect = collect_mock
    dns_fact_collector = DnsFactCollector

# Generated at 2022-06-20 19:24:31.408947
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # Instance to test
    instance = DnsFactCollector()
    assert isinstance(instance, DnsFactCollector)

    # Name of instance must be dns
    assert instance.name == 'dns'

    # Empty test
    result = instance.collect()
    assert isinstance(result, dict)
    assert 'dns' in result
    assert isinstance(result['dns'], dict)
    assert len(result['dns']) == 0
    assert 'nameservers' not in result['dns']

# Generated at 2022-06-20 19:24:42.407454
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector import add_collector
    from ansible.module_utils.facts.collector import list_collectors
    module = DnsFactCollector()
    add_collector(DnsFactCollector)
    assert DnsFactCollector in list_collectors()
    value = module.collect()
    for key in ('nameservers', 'domain', 'search', 'sortlist', 'options'):
        assert key in value['dns']
    assert isinstance(value['dns']['nameservers'], list)
    assert isinstance(value['dns']['domain'], str)
    assert isinstance(value['dns']['search'], list)
    assert isinstance(value['dns']['sortlist'], list)

# Generated at 2022-06-20 19:24:49.263763
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dfc=DnsFactCollector()
    fect_dict=dfc.collect()
    assert 'dns' in fect_dict
    assert isinstance(fect_dict['dns'],dict)
    assert 'nameservers' in fect_dict['dns']
    assert fect_dict['dns']['nameservers']==['8.8.4.4']

# Generated at 2022-06-20 19:24:52.810691
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.facts import FactManager

    # Test with default values
    fact_manager = FactManager

# Generated at 2022-06-20 19:24:54.170019
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector()

# Generated at 2022-06-20 19:24:57.217251
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    x = DnsFactCollector()
    assert x
    assert x.name == 'dns'
    assert not x._fact_ids

# Generated at 2022-06-20 19:25:23.212562
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector.collect()
    assert dns_facts
    assert isinstance(dns_facts, dict)
    assert dns_facts['dns']
    assert isinstance(dns_facts['dns'], dict)
    assert isinstance(dns_facts['dns']['domain'], basestring)
    assert isinstance(dns_facts['dns']['nameservers'], list)
    assert isinstance(dns_facts['dns']['options'], dict)
    assert isinstance(dns_facts['dns']['search'], list)
    assert isinstance(dns_facts['dns']['sortlist'], list)

# Generated at 2022-06-20 19:25:29.903074
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    collector = DnsFactCollector()
    collected_facts = collector.collect()
    assert isinstance(collected_facts['dns'], dict)
    assert isinstance(collected_facts['dns']['nameservers'], list)
    for nameserver in collected_facts['dns']['nameservers']:
        assert isinstance(nameserver, str)
    if 'domain' in collected_facts['dns']:
        assert isinstance(collected_facts['dns']['domain'], str)
    if 'search' in collected_facts['dns']:
        assert isinstance(collected_facts['dns']['search'], list)
        for suffix in collected_facts['dns']['search']:
            assert isinstance(suffix, str)

# Generated at 2022-06-20 19:25:35.961703
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    facts_list = DnsFactCollector()

    assert facts_list is not None, 'Unable to create instance of DnsFactCollector'

    assert hasattr(facts_list, 'collect'), 'DnsFactCollector does not have required collect method'

# Generated at 2022-06-20 19:25:44.303681
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # The below generated file is a copy of /etc/resolv.conf
    # when running on kvm1 for the lab environment. The file
    # contains comments at the top, and the file is non-empty.
    with open('./Test_Data/resolv.conf', 'r') as f:
        dns_data = f.readlines()

    with open('/etc/resolv.conf', 'w') as f:
        for line in dns_data:
            f.writelines(line)

    dns_collector = DnsFactCollector()
    facts = dns_collector.collect()

    # The generated file has 10 nameservers, with each having an IP address, so
    # a list of 10 IP addresses are expected in the dictionary.

# Generated at 2022-06-20 19:25:47.222215
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    fc = DnsFactCollector()
    assert fc.name == 'dns'
    assert 'dns' in fc._fact_ids

# Generated at 2022-06-20 19:25:50.407808
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    collector = DnsFactCollector()
    assert collector.name == 'dns'
    assert not collector._fact_ids

# Generated at 2022-06-20 19:25:56.888874
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    resolv_conf = """
# Dynamic resolv.conf(5) file for glibc resolver(3) generated by resolvconf(8)
#     DO NOT EDIT THIS FILE BY HAND -- YOUR CHANGES WILL BE OVERWRITTEN

nameserver 8.8.4.4
nameserver 172.16.1.8
search example.com example.net
domain example.com

"""
    from ansible.module_utils.facts.utils import get_file_content
    get_file_content = lambda *args, **kwargs: resolv_conf
    dns_facts = DnsFactCollector().collect()

    assert dns_facts.get('dns').get('nameservers') == ['8.8.4.4', '172.16.1.8']
    assert dns_facts.get

# Generated at 2022-06-20 19:26:03.334635
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns = DnsFactCollector()
    assert dns.name == 'dns', 'dns name is invalid'
    assert dns._fact_ids == set(), 'dns factids is invalid'
    assert dns.collect()['dns'] == {}, 'dns fact is invalid'

# Generated at 2022-06-20 19:26:13.201257
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_fact_collector = DnsFactCollector({})
    dns_facts = dns_fact_collector.collect()
    assert 'dns' in dns_facts
    assert len(dns_facts['dns']) > 0
    assert len(dns_facts['dns']['nameservers']) > 0
    assert dns_facts['dns']['search'][0] == 'example.com'
    assert dns_facts['dns']['sortlist'][0] == '192.168.1.0/255.255.255.0'
    assert dns_facts['dns']['options']['timeout'] == '2'

# Generated at 2022-06-20 19:26:14.586539
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
	pass



# Generated at 2022-06-20 19:26:43.239437
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    o = DnsFactCollector()
    assert o.name == "dns"
    assert o._fact_ids == set()



# Generated at 2022-06-20 19:26:46.079148
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    x = DnsFactCollector()
    assert x
    assert x.name == 'dns'

# Generated at 2022-06-20 19:26:52.138332
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    collector = DnsFactCollector()
    # Just check that the instance was created correctly
    assert(isinstance(collector, DnsFactCollector))
    assert(collector.name == 'dns')
    assert(isinstance(collector._fact_ids, set))
    assert(len(collector._fact_ids) == 0)


# Generated at 2022-06-20 19:26:54.438945
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    DnsFactCollector = DnsFactCollector()
    assert DnsFactCollector.name == "dns"

# Generated at 2022-06-20 19:26:57.164691
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    collector = DnsFactCollector()
    facts = collector.collect()
    assert facts['dns'] == {
        'nameservers': ['192.0.2.1'],
        'search': ['example.com'],
    }

# Generated at 2022-06-20 19:27:07.976029
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # prepare test data
    facts = {}
    # run test
    DnsFactCollector().collect(None, facts)
    # verify results
    assert isinstance(facts, dict)
    assert 'dns' in facts
    assert isinstance(facts['dns'], dict)
    assert len(facts['dns']) > 0
    assert 'nameservers' in facts['dns']
    assert isinstance(facts['dns']['nameservers'], list)
    assert len(facts['dns']['nameservers']) > 0
    assert isinstance(facts['dns']['nameservers'][0], str)
    assert 'search' in facts['dns']
    assert isinstance(facts['dns']['search'], list)

# Generated at 2022-06-20 19:27:12.778608
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    # This function unit tests the constructor of the class DnsFactCollector
    dns_fact_collector_object = DnsFactCollector()
    assert dns_fact_collector_object.name == 'dns'

# Generated at 2022-06-20 19:27:15.806696
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns = DnsFactCollector()
    assert dns.name == 'dns'
    assert dns._fact_ids == set()

# Generated at 2022-06-20 19:27:21.800990
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    print("BEGIN test_DnsFactCollector_collect")
    dns_facts_data = DnsFactCollector().collect()
    assert isinstance(dns_facts_data, dict)
    expected_dns_data = {
        'dns': {
            'search': ['example.net'],
            'sortlist': ['192.168.1.0/255.255.255.0'],
            'nameservers': ['172.26.0.2', '8.8.8.8'],
            'options': {},
            'domain': 'example.net'
        }
    }
    assert dns_facts_data['dns'] == expected_dns_data['dns']
    print("END test_DnsFactCollector_collect")


# Generated at 2022-06-20 19:27:24.804721
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
  retester = DnsFactCollector()
  assert retester.name == "dns"
  assert retester._fact_ids == set()

# Generated at 2022-06-20 19:28:35.627454
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    test_resolv = """
; generated by /sbin/dhclient-script
search localdomain
nameserver 10.0.2.3
"""
    resolv_collector = DnsFactCollector()
    resolv_facts = resolv_collector.collect()

    assert resolv_facts['dns']['nameservers'][0] == '10.0.2.3'

# Generated at 2022-06-20 19:28:39.116720
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():

    # Init test class
    fact_collector = DnsFactCollector()

    # Get facts
    facts = fact_collector.collect()

    # Assert if dns.nameservers is not empty
    assert 'nameservers' in facts['dns']
    assert len(facts['dns']['nameservers']) > 0

# Generated at 2022-06-20 19:28:47.219209
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    # run collect method of class DnsFactCollector with 2 arguments (module, collected facts)
    # and return a dns_facts dictionary
    dns_facts = DnsFactCollector().collect(module = None, collected_facts = None)
    # convert the dns_facts dictionary to string
    output = str(dns_facts)
    # be sure that output contains a string 'dns'
    assert 'dns' in output

# Generated at 2022-06-20 19:28:59.464211
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list')
        }
    )
    dns_fact_collector = DnsFactCollector()
    facts = dns_fact_collector.collect(module=module)

    assert facts['dns']['nameservers'] == ['114.114.114.114', '114.114.115.115']
    assert facts['dns']['domain'] == 'localdomain'
    assert facts['dns']['search'] == ['localdomain']
    assert facts['dns']['sortlist'] == ['192.168.1.0/24', '127.0.0.1/8']
    assert facts['dns']['options']['timeout'] == '2'


# Generated at 2022-06-20 19:29:04.431746
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dns_fact_collector = DnsFactCollector()
    assert dns_fact_collector.name == 'dns'
    assert dns_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:29:13.376891
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    '''Unit test for method "collect" of class "DnsFactCollector"'''
    # Set up test
    class TestModule(object):
        def __init__(self):
            self.params = {}

    class TestCollectedFacts(object):
        def __init__(self):
            self.dns = {}
            self.dns_nameservers = []
            self.dns_search = []

    test_module = TestModule()
    test_collected_facts = TestCollectedFacts()
    test_collector = DnsFactCollector(test_module)

    # Test with a valid config file
    with open('tests/unit/resources/dns_fact_collector_collect_test_1.resolv.conf') as f:
        config_text = f.read()


# Generated at 2022-06-20 19:29:21.980395
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    from ansible.module_utils.facts.collector.dns import DnsFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # First check if we get an instance of this class
    d = DnsFactCollector()
    assert isinstance(d, DnsFactCollector)

    # Get the content of the file /etc/resolv.conf in a variable content
    content = get_file_content('/etc/resolv.conf', '')

    # Lets check that we are getting the content of the file
    assert len(content) > 0

    # Get an instance of the class
    fact_collector = DnsFactCollector()

    # Call collect method of the class
    dns_facts = fact_collector.collect()

    # Check if the content of the file are

# Generated at 2022-06-20 19:29:25.104542
# Unit test for constructor of class DnsFactCollector
def test_DnsFactCollector():
    dfc = DnsFactCollector()


# Generated at 2022-06-20 19:29:30.757625
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    collected_facts = {}
    dns_fc = DnsFactCollector()
    facts_list = dns_fc.collect(None, collected_facts)
    assert facts_list == {'dns': {'domain': 'example.com',
                                  'nameservers': ['10.0.32.1', '10.0.32.2'],
                                  'options': {'debug': True,
                                              'edns0': True},
                                  'search': ['example.com', 'other.example.com'],
                                  'sortlist': ['10.0.32.0/24']}}

# Generated at 2022-06-20 19:29:40.727609
# Unit test for method collect of class DnsFactCollector
def test_DnsFactCollector_collect():
    dns_facts = DnsFactCollector.collect()

    assert dns_facts['dns']['nameservers'] == ['192.168.1.14', '192.168.1.2']
    assert dns_facts['dns']['domain'] == 'local'
    assert dns_facts['dns']['search'] == ['local']
    assert dns_facts['dns']['sortlist'] == ['192.168.1.2/255.255.255.0']
    assert dns_facts['dns']['options']['ndots'] == '1'
    assert dns_facts['dns']['options']['timeout'] == '2'