

# Generated at 2022-06-17 23:19:22.727594
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code(mask='@@@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='#') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='#') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='@') == '@@@'

# Generated at 2022-06-17 23:19:31.402156
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code() == '@###'
    assert r.custom_code('@###') == '@###'
    assert r.custom_code('@###', '@', '#') == '@###'
    assert r.custom_code('@###', '#', '@') == '@###'
    assert r.custom_code('@###', '@', '@') == '@###'
    assert r.custom_code('@###', '#', '#') == '@###'
    assert r.custom_code('@###', '@', '@') == '@###'
    assert r.custom_code('@###', '#', '#') == '@###'
    assert r.custom_code('@###', '@', '#') == '@###'
   

# Generated at 2022-06-17 23:19:41.581711
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code('@###') == '@###'
    assert rnd.custom_code('@###', '@', '#') == '@###'
    assert rnd.custom_code('@###', '#', '@') == '@###'
    assert rnd.custom_code('@###', '@', '@') == '@###'
    assert rnd.custom_code('@###', '#', '#') == '@###'
    assert rnd.custom_code('@###', '@', '@') == '@###'
    assert rnd.custom_code('@###', '#', '#') == '@###'

# Generated at 2022-06-17 23:19:51.776057
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == '@###'
    assert random.custom_code(mask='@###') == '@###'
    assert random.custom_code(mask='@###', char='@', digit='#') == '@###'
    assert random.custom_code(mask='@###', char='@', digit='#') != '@###'
    assert random.custom_code(mask='@###', char='#', digit='@') == '@###'
    assert random.custom_code(mask='@###', char='#', digit='@') != '@###'
    assert random.custom_code(mask='@###', char='#', digit='#') == '@###'
    assert random.custom_code(mask='@###', char='#', digit='#') != '@###'

# Generated at 2022-06-17 23:20:02.090633
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code('@###') == '@###'
    assert rnd.custom_code('@###', '@', '#') == '@###'
    assert rnd.custom_code('@###', '@', '#') != '@###'
    assert rnd.custom_code('@###', '@', '#') != '@###'
    assert rnd.custom_code('@###', '@', '#') != '@###'
    assert rnd.custom_code('@###', '@', '#') != '@###'
    assert rnd.custom_code('@###', '@', '#') != '@###'

# Generated at 2022-06-17 23:20:12.470946
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code('@###-@###')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isalpha()

    code = rnd.custom_code('@###-@###', '@', '#')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isalpha()

    code = rnd.custom_code('@###-@###', '#', '@')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code

# Generated at 2022-06-17 23:20:24.160161
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code(mask='@###') == 'A123'
    assert rnd.custom_code(mask='@###', char='#') == 'A123'
    assert rnd.custom_code(mask='@###', digit='#') == 'A123'
    assert rnd.custom_code(mask='@###', char='#', digit='@') == 'A123'
    assert rnd.custom_code(mask='@###', char='@', digit='#') == 'A123'
    assert rnd.custom_code(mask='@###', char='#', digit='#') == 'A123'
    assert rnd.custom_code(mask='@###', char='@', digit='@') == 'A123'

# Generated at 2022-06-17 23:20:35.553249
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() == '@AAA'
    assert Random().custom_code('@###') == '@000'
    assert Random().custom_code('@###', '@', '#') == '@000'
    assert Random().custom_code('@###', '#', '@') == '@000'
    assert Random().custom_code('@###', '#', '#') == '@000'
    assert Random().custom_code('@###', '@', '@') == '@000'
    assert Random().custom_code('@###', '#', '#') == '@000'
    assert Random().custom_code('@###', '@', '#') == '@000'
    assert Random().custom_code('@###', '#', '@') == '@000'
    assert Random().custom_code

# Generated at 2022-06-17 23:20:44.162947
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1:].isdigit()

    code = rnd.custom_code(mask='@###-@###')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code[0].isalpha()
    assert code[1:].isdigit()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code[0].isdigit()

# Generated at 2022-06-17 23:20:49.293870
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@@@###')
    assert len(code) == 7
    assert code.isalnum()

    code = rnd.custom_code(mask='@@@###', char='@', digit='#')
    assert len(code) == 7
    assert code.isalnum()

    code = rnd.custom_code(mask='@@@###', char='#', digit='@')
    assert len(code) == 7
    assert code.isalnum()

    code = rnd.custom_code(mask='@@@###', char='#', digit='#')
    assert len(code)