

# Generated at 2022-06-17 23:19:21.415823
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isupper()
    assert code.isalpha() or code.isdigit()

    code = rnd.custom_code(mask='@###-@###')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isupper()
    assert code.isalpha() or code.isdigit()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isupper()
    assert code.isalpha() or code.isdigit()

    code = rnd.custom_code

# Generated at 2022-06-17 23:19:31.018130
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code(mask='@@@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='#') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='#') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='#') == '@@@'

# Generated at 2022-06-17 23:19:41.554679
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert code.isalpha()
    assert len(code) == 4

    code = rnd.custom_code(mask='@###-@###')
    assert code.isalnum()
    assert len(code) == 9

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert code.isalnum()
    assert len(code) == 9

    code = rnd.custom_code(mask='@###-@###', char='#', digit='#')
    assert code.isalnum()
    assert len(code) == 9


# Generated at 2022-06-17 23:19:51.776814
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == '@000'
    assert random.custom_code('@###') == '@000'
    assert random.custom_code('@###', '@', '#') == '@000'
    assert random.custom_code('@###', '@', '#') != '@000'
    assert random.custom_code('@###', '@', '#') != '@000'
    assert random.custom_code('@###', '@', '#') != '@000'
    assert random.custom_code('@###', '@', '#') != '@000'
    assert random.custom_code('@###', '@', '#') != '@000'
    assert random.custom_code('@###', '@', '#') != '@000'
    assert random.custom_code

# Generated at 2022-06-17 23:20:02.095485
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code('@###') == 'A123'
    assert rnd.custom_code('@@##') == 'AA12'
    assert rnd.custom_code('@@##', char='#') == 'AA12'
    assert rnd.custom_code('@@##', digit='#') == 'AA12'
    assert rnd.custom_code('@@##', char='#', digit='@') == 'AA12'
    assert rnd.custom_code('@@##', digit='#', char='@') == 'AA12'
    assert rnd.custom_code('@@##', digit='@', char='#') == 'AA12'

# Generated at 2022-06-17 23:20:12.471055
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code('@###')
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1:].isdigit()

    code = rnd.custom_code('###@')
    assert len(code) == 4
    assert code[0:3].isdigit()
    assert code[3].isalpha()

    code = rnd.custom_code('@@##')
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1].isalpha()
    assert code[2:].isdigit()

    code = rnd.custom_code('@@##', char='#', digit='@')
    assert len(code) == 4


# Generated at 2022-06-17 23:20:24.161052
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    r = Random()
    assert r.custom_code()
    assert r.custom_code(mask='@###-@###')
    assert r.custom_code(mask='@###-@###', char='@', digit='#')
    assert r.custom_code(mask='@###-@###', char='#', digit='@')
    assert r.custom_code(mask='@###-@###', char='#', digit='#')
    assert r.custom_code(mask='@###-@###', char='@', digit='@')
    assert r.custom_code(mask='@###-@###', char='@', digit='@')
    assert r.custom_code(mask='@###-@###', char='@', digit='@')

# Generated at 2022-06-17 23:20:35.554545
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code() == 'A000'
    assert r.custom_code(mask='@@@') == 'AA0'
    assert r.custom_code(mask='@@@', char='#', digit='@') == 'A0A'
    assert r.custom_code(mask='@@@', char='@', digit='#') == 'AA0'
    assert r.custom_code(mask='@@@', char='#', digit='#') == 'A00'
    assert r.custom_code(mask='@@@', char='@', digit='@') == 'AAA'
    assert r.custom_code(mask='@@@', char='@', digit='@') == 'AAA'
    assert r.custom_code(mask='@@@', char='@', digit='@') == 'AAA'


# Generated at 2022-06-17 23:20:43.852455
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@##-@##')
    assert isinstance(code, str)
    assert len(code) == 7
    assert code.isalpha()

    code = rnd.custom_code(mask='@##-@##', char='#', digit='@')
    assert isinstance(code, str)
    assert len(code) == 7
    assert code.isdigit()

    code = rnd.custom_code(mask='@##-@##', char='@', digit='#')
    assert isinstance(code, str)
   

# Generated at 2022-06-17 23:20:54.831035
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code('@###') == '@###'
    assert rnd.custom_code('@###', '@', '#') == '@###'
    assert rnd.custom_code('@###', '@', '#') != '@###'
    assert rnd.custom_code('@###', '@', '#') != '@###'
    assert rnd.custom_code('@###', '@', '#') != '@###'
    assert rnd.custom_code('@###', '@', '#') != '@###'
    assert rnd.custom_code('@###', '@', '#') != '@###'