

# Generated at 2022-06-17 23:19:41.531141
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isupper()
    assert code.isalnum()

    code = rnd.custom_code('@###')
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isupper()
    assert code.isalnum()

    code = rnd.custom_code('@###', '@', '#')
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isupper()
    assert code.isalnum()

    code = rnd.custom_code('@###', '@', '#')

# Generated at 2022-06-17 23:19:51.728587
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code(mask='@@@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='#') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='#') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == '@@@'

# Generated at 2022-06-17 23:20:02.052181
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code(mask='@###')
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1:].isdigit()

    code = rnd.custom_code(mask='@@###')
    assert len(code) == 5
    assert code[:2].isalpha()
    assert code[2:].isdigit()

    code = rnd.custom_code(mask='@@@###')
    assert len(code) == 6
    assert code[:3].isalpha()
    assert code[3:].isdigit()

    code = rnd.custom_code(mask='@@@@###')
    assert len(code) == 7

# Generated at 2022-06-17 23:20:12.438271
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code('@###') == rnd.custom_code('@###')
    assert rnd.custom_code('@###') != rnd.custom_code('@###')
    assert rnd.custom_code('@###', '@', '#') == rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#') != rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#') != rnd.custom_code('@###', '#', '@')
    assert rnd.custom_code('@###', '@', '#') != rnd.custom_code('@###', '#', '#')


# Generated at 2022-06-17 23:20:23.749751
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###')
    assert len(code) == 9
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###-@###')
    assert len(code) == 14
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###-@###-@###')
    assert len(code) == 19
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###-@###-@###-@###')

# Generated at 2022-06-17 23:20:35.483859
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4

    code = rnd.custom_code(mask='@###-@###')
    assert isinstance(code, str)
    assert len(code) == 9

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert isinstance(code, str)
    assert len(code) == 9

    code = rnd.custom_code(mask='@###-@###', char='#', digit='#')
    assert isinstance(code, str)
    assert len(code) == 9


# Generated at 2022-06-17 23:20:44.099907
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == '@AAA'
    assert rnd.custom_code('@###') == '@000'
    assert rnd.custom_code('@###', '@', '#') == '@000'
    assert rnd.custom_code('@###', '#', '@') == '@000'
    assert rnd.custom_code('@###', '#', '#') == '@000'
    assert rnd.custom_code('@###', '@', '@') == '@000'
    assert rnd.custom_code('@###', '#', '#') == '@000'
    assert rnd.custom_code('@###', '#', '#') == '@000'


# Generated at 2022-06-17 23:20:49.256266
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code() != rnd

# Generated at 2022-06-17 23:20:54.821692
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isupper()
    assert code.isalpha() or code.isdigit()

    code = rnd.custom_code(mask='@###-@###')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isupper()
    assert code.isalpha() or code.isdigit()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isupper()
    assert code.isalpha() or code

# Generated at 2022-06-17 23:21:05.387350
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == '@###'
    assert random.custom_code('@###') == '@###'
    assert random.custom_code('@###', '@', '#') == '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code