

# Generated at 2022-06-17 23:19:18.813329
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code(mask='@@@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='#') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='#') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='@') == '@@@'
    assert rnd.custom

# Generated at 2022-06-17 23:19:30.679119
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isupper()
    assert code.isalpha() or code.isdigit()

    code = rnd.custom_code(mask='@###-@###')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isupper()
    assert code.isalpha() or code.isdigit()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isupper()
    assert code.isalpha() or code

# Generated at 2022-06-17 23:19:41.585542
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')

# Generated at 2022-06-17 23:19:51.820230
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() == '@###'
    assert Random().custom_code('@###') == '@###'
    assert Random().custom_code('@###', '@', '#') == '@###'
    assert Random().custom_code('@###', '@', '#') != '@###'
    assert Random().custom_code('@###', '@', '#') != '@###'
    assert Random().custom_code('@###', '@', '#') != '@###'
    assert Random().custom_code('@###', '@', '#') != '@###'
    assert Random().custom_code('@###', '@', '#') != '@###'
    assert Random().custom_code('@###', '@', '#') != '@###'
    assert Random().custom_code

# Generated at 2022-06-17 23:20:02.090783
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code(mask='@@@###') == '@@@###'
    assert rnd.custom_code(mask='@@@###', char='@', digit='#') == '@@@###'
    assert rnd.custom_code(mask='@@@###', char='#', digit='@') == '@@@###'
    assert rnd.custom_code(mask='@@@###', char='#', digit='#') == '@@@###'
    assert rnd.custom_code(mask='@@@###', char='@', digit='@') == '@@@###'
    assert rnd.custom_code(mask='@@@###', char='@', digit='#') == '@@@###'

# Generated at 2022-06-17 23:20:12.471132
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###', '@', '#') == 'A123'
    assert random.custom_code('@###', '@', '#') == 'B123'
    assert random.custom_code('@###', '@', '#') == 'C123'
    assert random.custom_code('@###', '@', '#') == 'D123'
    assert random.custom_code('@###', '@', '#') == 'E123'
    assert random.custom_code('@###', '@', '#') == 'F123'
    assert random.custom_code('@###', '@', '#') == 'G123'
    assert random.custom_code('@###', '@', '#') == 'H123'

# Generated at 2022-06-17 23:20:24.161059
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code() == '@###'
    assert r.custom_code('@###') == '@###'
    assert r.custom_code('@###', '@', '#') == '@###'
    assert r.custom_code('@###', '@', '#') != '@###'
    assert r.custom_code('@###', '@', '#') != '@###'
    assert r.custom_code('@###', '@', '#') != '@###'
    assert r.custom_code('@###', '@', '#') != '@###'
    assert r.custom_code('@###', '@', '#') != '@###'
    assert r.custom_code('@###', '@', '#') != '@###'
   

# Generated at 2022-06-17 23:20:35.555433
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == rnd.custom_code()
    assert rnd.custom_code('@###') == rnd.custom_code('@###')
    assert rnd.custom_code('@###', '@', '#') == rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#') != rnd.custom_code('@###', '#', '@')
    assert rnd.custom_code('@###', '@', '#') != rnd.custom_code('@###', '@', '@')

# Generated at 2022-06-17 23:20:44.191040
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code('@###')
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code('@###', '@', '#')
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code('@###', '@', '#')
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code('@###', '@', '#')
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code('@###', '@', '#')
    assert len(code) == 4
    assert code.isalpha

# Generated at 2022-06-17 23:20:49.314462
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@@@###')
    assert len(code) == 7
    assert code.isalpha()

    code = rnd.custom_code(mask='@@@###', char='#', digit='@')
    assert len(code) == 7
    assert code.isdigit()

    code = rnd.custom_code(mask='@@@###', char='#', digit='@')
    assert len(code) == 7
    assert code.isdigit()

    code = rnd.custom_code(mask='@@@###', char='#', digit='@')
    assert len(code) == 7
    assert code.isdigit()

   