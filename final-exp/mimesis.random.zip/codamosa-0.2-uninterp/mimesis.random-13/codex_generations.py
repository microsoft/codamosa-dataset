

# Generated at 2022-06-17 23:26:29.978651
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == '@AAA'
    assert rnd.custom_code('@###') == '@000'
    assert rnd.custom_code('@###', '@', '#') == '@000'
    assert rnd.custom_code('@###', '#', '@') == '@000'
    assert rnd.custom_code('@###', '#', '#') == '@000'
    assert rnd.custom_code('@###', '@', '@') == '@000'
    assert rnd.custom_code('@###', '@', '@') == '@000'
    assert rnd.custom_code('@###', '#', '#') == '@000'


# Generated at 2022-06-17 23:26:36.239002
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == rnd.custom_code()
    assert rnd.custom_code(mask='@###') == rnd.custom_code(mask='@###')
    assert rnd.custom_code(mask='@###', char='@', digit='#') == rnd.custom_code(mask='@###', char='@', digit='#')
    assert rnd.custom_code(mask='@###', char='@', digit='#') != rnd.custom_code(mask='@###', char='@', digit='#')
    assert rnd.custom_code(mask='@###', char='@', digit='#') != rnd.custom_code(mask='@###', char='@', digit='#')

# Generated at 2022-06-17 23:26:43.197000
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == rnd.custom_code()
    assert rnd.custom_code('@###') == rnd.custom_code('@###')
    assert rnd.custom_code('@###', '@', '#') == rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#') != rnd.custom_code('@###', '#', '@')
    assert rnd.custom_code('@###', '@', '#') != rnd.custom_code('@###', '#', '#')

# Generated at 2022-06-17 23:26:52.201890
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###')
    assert len(code) == 9
    assert code.isalnum()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert len(code) == 9
    assert code.isalnum()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='#')
    assert len(code) == 9
    assert code.isalnum()


# Generated at 2022-06-17 23:26:59.343291
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1:].isdigit()

    code = rnd.custom_code(mask='@###-@###')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code[0].isalpha()
    assert code[1:5].isdigit()
    assert code[5] == '-'
    assert code[6].isalpha()
    assert code[7:].isdigit()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')

# Generated at 2022-06-17 23:27:03.703035
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code of class Random."""
    rnd = Random()
    assert isinstance(rnd.custom_code(), str)
    assert isinstance(rnd.custom_code(mask='@###'), str)
    assert isinstance(rnd.custom_code(mask='@###', char='@', digit='#'), str)
    assert isinstance(rnd.custom_code(mask='@###', char='@', digit='#'), str)
    assert isinstance(rnd.custom_code(mask='@###', char='@', digit='#'), str)
    assert isinstance(rnd.custom_code(mask='@###', char='@', digit='#'), str)
    assert isinstance(rnd.custom_code(mask='@###', char='@', digit='#'), str)
    assert isinstance

# Generated at 2022-06-17 23:27:11.762633
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code('@###') == '@###'
    assert rnd.custom_code('@@##') == '@@##'
    assert rnd.custom_code('@@##', '@', '#') == '@@##'
    assert rnd.custom_code('@@##', '#', '@') == '@@##'
    assert rnd.custom_code('@@##', '#', '#') == '@@##'
    assert rnd.custom_code('@@##', '@', '@') == '@@##'
    assert rnd.custom_code('@@##', '@', '@') == '@@##'

# Generated at 2022-06-17 23:27:20.694263
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code(mask='@###-@###') == '@###-@###'
    assert rnd.custom_code(mask='@###-@###', char='@', digit='#') == '@###-@###'
    assert rnd.custom_code(mask='@###-@###', char='@', digit='#') != '@###-@###'
    assert rnd.custom_code(mask='@###-@###', char='#', digit='@') == '@###-@###'
    assert rnd.custom_code(mask='@###-@###', char='#', digit='@') != '@###-@###'

# Generated at 2022-06-17 23:27:32.142642
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    r = Random()
    assert r.custom_code() == '@AAA'
    assert r.custom_code('@###') == '@000'
    assert r.custom_code('@@##') == '@A00'
    assert r.custom_code('@@@A') == '@A0A'
    assert r.custom_code('@@@A', '@', '#') == '@A0A'
    assert r.custom_code('@@@A', '@', '#') != '@A0A'
    assert r.custom_code('@@@A', '@', '#') != '@A0A'
    assert r.custom_code('@@@A', '@', '#') != '@A0A'
    assert r.custom

# Generated at 2022-06-17 23:27:44.027918
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@@@###')
    assert isinstance(code, str)
    assert len(code) == 6
    assert code.isalpha()

    code = rnd.custom_code(mask='@@@###', char='#', digit='@')
    assert isinstance(code, str)
    assert len(code) == 6
    assert code.isdigit()

    code = rnd.custom_code(mask='@@@###', char='#', digit='@')
    assert isinstance(code, str)