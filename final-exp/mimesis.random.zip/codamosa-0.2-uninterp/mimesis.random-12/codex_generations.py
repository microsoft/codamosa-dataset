

# Generated at 2022-06-17 23:20:54.958660
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isupper()
    assert code.isalpha() or code.isdigit()

    code = rnd.custom_code('@###-@###')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isupper()
    assert code.isalpha() or code.isdigit()

    code = rnd.custom_code('@###-@###', '@', '#')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isupper()
    assert code.isalpha() or code.isdigit()



# Generated at 2022-06-17 23:20:59.193570
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@##-@##')
    assert isinstance(code, str)
    assert len(code) == 7
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###-@###')
    assert isinstance(code, str)
    assert len(code) == 13
    assert code.isalpha

# Generated at 2022-06-17 23:21:09.285522
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@###') == 'A123'
    assert Random().custom_code('@###', '@', '#') == 'A123'
    assert Random().custom_code('@###', '#', '@') == 'A123'
    assert Random().custom_code('@###', '#', '#') == 'A123'
    assert Random().custom_code('@###', '@', '@') == 'A123'
    assert Random().custom_code('@###', '@', '@') == 'A123'
    assert Random().custom_code('@###', '@', '@') == 'A123'
    assert Random().custom_code('@###', '@', '@') == 'A123'

# Generated at 2022-06-17 23:21:12.309963
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code(mask='@###', char='@', digit='#')
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1:].isdigit()

# Generated at 2022-06-17 23:21:19.831483
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###') == 'A123'
    assert random.custom_code('@###', '@', '#') == 'A123'
    assert random.custom_code('@###', '#', '@') == 'A123'
    assert random.custom_code('@###', '#', '#') == 'A123'
    assert random.custom_code('@###', '@', '@') == 'A123'
    assert random.custom_code('@###', '#', '#') == 'A123'
    assert random.custom_code('@###', '@', '@') == 'A123'
    assert random.custom_code('@###', '#', '#') == 'A123'

# Generated at 2022-06-17 23:21:25.814548
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@AAA'
    assert rnd.custom_code('@@@') == '@AA'
    assert rnd.custom_code('@###') == '@000'
    assert rnd.custom_code('@###', '@', '#') == '@000'
    assert rnd.custom_code('@@@', '@', '#') == '@AA'
    assert rnd.custom_code('@@@', '#', '@') == '#AA'
    assert rnd.custom_code('@@@', '#', '#') == '#AA'
    assert rnd.custom_code('@@@', '@', '@') == '@AA'

# Generated at 2022-06-17 23:21:34.385515
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code.isalpha()
    code = rnd.custom_code(mask='@###-@###')
    assert len(code) == 9
    assert code.isalnum()
    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert len(code) == 9
    assert code.isalnum()
    code = rnd.custom_code(mask='@###-@###', char='#', digit='#')
    assert len(code) == 9
    assert code.isalnum()

# Generated at 2022-06-17 23:21:42.769182
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code('@###') != rnd.custom_code('@###')
    assert rnd.custom_code('@###') != rnd.custom_code('@###')
    assert rnd.custom_code('@###') != rnd.custom_code('@###')
    assert rnd.custom_code('@###') != rnd.custom_code('@###')
    assert rnd.custom_code('@###') != rnd.custom_code('@###')

# Generated at 2022-06-17 23:21:52.088427
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    assert random.custom_code() == '@###'
    assert random.custom_code('@###') == '@###'
    assert random.custom_code('@###', '@', '#') == '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'

# Generated at 2022-06-17 23:21:59.637314
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code(mask='@###', char='@', digit='#') == 'A123'
    assert rnd.custom_code(mask='@@@###', char='@', digit='#') == 'ABC123'
    assert rnd.custom_code(mask='@@@###', char='@', digit='#') == 'ABC123'
    assert rnd.custom_code(mask='@@@###', char='@', digit='#') == 'ABC123'
    assert rnd.custom_code(mask='@@@###', char='@', digit='#') == 'ABC123'
    assert rnd.custom_code(mask='@@@###', char='@', digit='#') == 'ABC123'