

# Generated at 2022-06-17 23:19:13.653261
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:15.703383
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert get_random_item(Gender) in Gender

# Generated at 2022-06-17 23:19:20.987809
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == '@###'
    assert random.custom_code('@###') == '@###'
    assert random.custom_code('@###', '@', '#') == '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code('@###', '@', '#') != '@###'
    assert random.custom_code

# Generated at 2022-06-17 23:19:30.878216
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == rnd.custom_code()
    assert rnd.custom_code('@@##') == rnd.custom_code('@@##')
    assert rnd.custom_code('@@##', '@', '#') == rnd.custom_code('@@##', '@', '#')
    assert rnd.custom_code('@@##', '@', '#') != rnd.custom_code('@@##', '#', '@')
    assert rnd.custom_code('@@##', '@', '#') != rnd.custom_code('@@##', '#', '#')
    assert rnd.custom_code('@@##', '@', '#') != rnd.custom_code('@@##', '@', '@')
    assert rnd.custom

# Generated at 2022-06-17 23:19:34.474398
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:42.394450
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-###')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-###', char='#')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isdigit()

    code = rnd.custom_code(mask='@###-###', char='#', digit='@')
    assert isinstance(code, str)
    assert len(code) == 9

# Generated at 2022-06-17 23:19:44.377421
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:45.830195
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:47.254635
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:48.674998
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender

    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:53.832676
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random.Gender), str)

# Generated at 2022-06-17 23:19:55.828189
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:59.107512
# Unit test for function get_random_item
def test_get_random_item():
    class TestEnum:
        A = 1
        B = 2
        C = 3

    assert get_random_item(TestEnum) in [1, 2, 3]

# Generated at 2022-06-17 23:20:00.643052
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert get_random_item(Gender) in Gender

# Generated at 2022-06-17 23:20:02.458812
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random.Gender), str)
    assert isinstance(get_random_item(random.Gender, random), str)

# Generated at 2022-06-17 23:20:04.875065
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:20:07.833637
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:20:08.902577
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:20:09.625078
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:20:11.018645
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)