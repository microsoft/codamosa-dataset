

# Generated at 2022-06-17 23:19:32.904777
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###')
    assert len(code) == 9
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###-@###')
    assert len(code) == 14
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###-@###-@###')
    assert len(code) == 19
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###-@###-@###-@###')

# Generated at 2022-06-17 23:19:36.775526
# Unit test for function get_random_item
def test_get_random_item():
    class TestEnum:
        A = 1
        B = 2
        C = 3

    assert get_random_item(TestEnum) in [1, 2, 3]

# Generated at 2022-06-17 23:19:38.595830
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:40.621934
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:43.483568
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:52.902901
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    r = Random()
    assert r.custom_code() == '@AAA'
    assert r.custom_code(mask='@@@') == 'AAA'
    assert r.custom_code(mask='@@@', char='#') == 'AAA'
    assert r.custom_code(mask='@@@', char='#', digit='@') == 'AAA'
    assert r.custom_code(mask='@@@', char='#', digit='@') == 'AAA'
    assert r.custom_code(mask='@@@', char='#', digit='@') == 'AAA'
    assert r.custom_code(mask='@@@', char='#', digit='@') == 'AAA'

# Generated at 2022-06-17 23:19:54.415845
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-17 23:19:57.417219
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert get_random_item(Gender) in Gender

# Generated at 2022-06-17 23:20:05.192149
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code('@###', '@', '#') == 'A123'
    assert r.custom_code('@###', '@', '#') == 'B123'
    assert r.custom_code('@###', '@', '#') == 'C123'
    assert r.custom_code('@###', '@', '#') == 'D123'
    assert r.custom_code('@###', '@', '#') == 'E123'
    assert r.custom_code('@###', '@', '#') == 'F123'
    assert r.custom_code('@###', '@', '#') == 'G123'
    assert r.custom_code('@###', '@', '#') == 'H123'

# Generated at 2022-06-17 23:20:13.598755
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code[0] in string.ascii_uppercase
    assert code[1] in string.ascii_uppercase
    assert code[2] in string.digits
    assert code[3] in string.digits

    code = rnd.custom_code(mask='@##-@###')
    assert isinstance(code, str)
    assert len(code) == 7
    assert code[0] in string.ascii_uppercase
    assert code[1] in string.digits
    assert code[2] in string.digits
    assert code[3] == '-'
