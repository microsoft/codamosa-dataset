

# Generated at 2022-06-17 23:19:30.739466
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code(mask='@##') == '@##'
    assert rnd.custom_code(mask='@##', char='@', digit='#') == '@##'
    assert rnd.custom_code(mask='@##', char='@', digit='@') == '@@@'
    assert rnd.custom_code(mask='@##', char='#', digit='@') == '@@@'
    assert rnd.custom_code(mask='@##', char='#', digit='#') == '###'
    assert rnd.custom_code(mask='@##', char='#', digit='#') == '###'

# Generated at 2022-06-17 23:19:41.581911
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code() == '@###'
    assert r.custom_code('@##') == '@##'
    assert r.custom_code('@##', '@', '#') == '@##'
    assert r.custom_code('@##', '#', '@') == '@##'
    assert r.custom_code('@##', '#', '#') == '@##'
    assert r.custom_code('@##', '@', '@') == '@##'
    assert r.custom_code('@##', '@', '#') == '@##'
    assert r.custom_code('@##', '#', '#') == '@##'
    assert r.custom_code('@##', '#', '@') == '@##'
   

# Generated at 2022-06-17 23:19:51.775723
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@AAA'
    assert rnd.custom_code(mask='@@@') == 'AAA'
    assert rnd.custom_code(mask='@@@', char='#') == 'AAA'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == 'AAA'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == 'AAA'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == 'AAA'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == 'AAA'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == 'AAA'


# Generated at 2022-06-17 23:20:02.090340
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@###') == 'A123'
    assert Random().custom_code('@###', '@', '#') == 'A123'
    assert Random().custom_code('@###', '#', '@') == 'A123'
    assert Random().custom_code('@###', '@', '@') == 'A123'
    assert Random().custom_code('@###', '#', '#') == 'A123'
    assert Random().custom_code('@###', 'A', '#') == 'A123'
    assert Random().custom_code('@###', '#', 'A') == 'A123'
    assert Random().custom_code('@###', 'A', 'A') == 'A123'

# Generated at 2022-06-17 23:20:12.479030
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code(mask='@###')
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1:].isdigit()

    code = rnd.custom_code(mask='@@###')
    assert len(code) == 5
    assert code[:2].isalpha()
    assert code[2:].isdigit()

    code = rnd.custom_code(mask='@@@###')
    assert len(code) == 6
    assert code[:3].isalpha()
    assert code[3:].isdigit()

    code = rnd.custom_code(mask='@@@@###')
    assert len(code) == 7

# Generated at 2022-06-17 23:20:24.285938
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    assert Random().custom_code() == '@AAA'
    assert Random().custom_code(mask='@###') == '@AAA'
    assert Random().custom_code(mask='@###', char='@', digit='#') == '@AAA'
    assert Random().custom_code(mask='@###', char='@', digit='#') != '@AAA'
    assert Random().custom_code(mask='@###', char='@', digit='#') != '@AAA'
    assert Random().custom_code(mask='@###', char='@', digit='#') != '@AAA'
    assert Random().custom_code(mask='@###', char='@', digit='#') != '@AAA'

# Generated at 2022-06-17 23:20:35.631866
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code()
    assert rnd.custom_code(mask='@###')
    assert rnd.custom_code(mask='@###', char='@', digit='#')
    assert rnd.custom_code(mask='@###', char='@', digit='@')
    assert rnd.custom_code(mask='@###', char='#', digit='#')
    assert rnd.custom_code(mask='@###', char='#', digit='@')
    assert rnd.custom_code(mask='@###', char='#', digit='#')
    assert rnd.custom_code(mask='@###', char='#', digit='@')

# Generated at 2022-06-17 23:20:44.218786
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code('@###') == '@###'
    assert rnd.custom_code('@###', '@', '#') == '@###'
    assert rnd.custom_code('@###', '#', '@') == '####'
    assert rnd.custom_code('@###', '#', '#') == '####'
    assert rnd.custom_code('@###', '@', '@') == '@@@@'
    assert rnd.custom_code('@###', '@', '#') == '@###'
    assert rnd.custom_code('@###', '#', '@') == '####'

# Generated at 2022-06-17 23:20:49.314809
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code()
    assert rnd.custom_code('@###')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#')

# Generated at 2022-06-17 23:20:54.842161
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code(mask='@@@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='#') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='#', digit='#') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='@') == '@@@'
    assert rnd.custom_code(mask='@@@', char='@', digit='@') == '@@@'