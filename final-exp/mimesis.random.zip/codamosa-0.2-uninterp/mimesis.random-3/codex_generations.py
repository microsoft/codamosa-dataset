

# Generated at 2022-06-17 23:19:19.433394
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == '@###'
    assert random.custom_code(mask='@@@') == '@@@'
    assert random.custom_code(mask='@@@', char='@', digit='#') == '@@@'
    assert random.custom_code(mask='@@@', char='#', digit='@') == '@@@'
    assert random.custom_code(mask='@@@', char='#', digit='#') == '@@@'
    assert random.custom_code(mask='@@@', char='@', digit='@') == '@@@'
    assert random.custom_code(mask='@@@', char='@', digit='@') == '@@@'
    assert random.custom_code(mask='@@@', char='@', digit='@') == '@@@'

# Generated at 2022-06-17 23:19:30.707959
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code.isalpha()
    code = rnd.custom_code(mask='@###-@###')
    assert len(code) == 9
    assert code.isalpha()
    code = rnd.custom_code(mask='@###-@###-@###')
    assert len(code) == 14
    assert code.isalpha()
    code = rnd.custom_code(mask='@###-@###-@###-@###')
    assert len(code) == 19
    assert code.isalpha()
    code = rnd.custom_code(mask='@###-@###-@###-@###-@###')
    assert len(code) == 24
    assert code.isalpha()
    code

# Generated at 2022-06-17 23:19:41.554399
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code('@###') == 'A123'
    assert r.custom_code('@###', '@', '#') == 'A123'
    assert r.custom_code('@###', '#', '@') == 'A123'
    assert r.custom_code('@###', '#', '#') == '@123'
    assert r.custom_code('@###', '@', '@') == 'A123'
    assert r.custom_code('@###', '@', '@') == 'A123'
    assert r.custom_code('@###', '@', '@') == 'A123'
    assert r.custom_code('@###', '@', '@') == 'A123'

# Generated at 2022-06-17 23:19:51.775794
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == '@###'
    assert random.custom_code(mask='@###-@###') == '@###-@###'
    assert random.custom_code(mask='@###-@###', char='@', digit='#') == '@###-@###'
    assert random.custom_code(mask='@###-@###', char='@', digit='@') == '@###-@###'
    assert random.custom_code(mask='@###-@###', char='#', digit='#') == '@###-@###'
    assert random.custom_code(mask='@###-@###', char='#', digit='@') == '@###-@###'

# Generated at 2022-06-17 23:19:53.913496
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code(mask='@###', char='@', digit='#') == 'A123'

# Generated at 2022-06-17 23:20:03.744197
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    _random = Random()
    assert _random.custom_code() == '@###'
    assert _random.custom_code('@@@') == '@@@'
    assert _random.custom_code('@@@', '@', '#') == '@@@'
    assert _random.custom_code('@@@', '@', '@') == '@@@'
    assert _random.custom_code('@@@', '#', '#') == '@@@'
    assert _random.custom_code('@@@', '#', '@') == '@@@'
    assert _random.custom_code('@@@', '@', '#') == '@@@'
    assert _random.custom_code('@@@', '#', '@') == '@@@'


# Generated at 2022-06-17 23:20:13.053007
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###')
    assert len(code) == 9
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert len(code) == 9
    assert code.isdigit()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert len(code) == 9
    assert code.isdigit()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert len(code) == 9

# Generated at 2022-06-17 23:20:24.441256
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###') == 'A123'
    assert random.custom_code('@###', '@', '#') == 'A123'
    assert random.custom_code('@###', '#', '@') == 'A123'
    assert random.custom_code('@###', '@', '@') == 'A123'
    assert random.custom_code('@###', '#', '#') == 'A123'
    assert random.custom_code('@###', '@', '#') == 'A123'
    assert random.custom_code('@###', '#', '@') == 'A123'
    assert random.custom_code('@###', '@', '@') == 'A123'

# Generated at 2022-06-17 23:20:35.799192
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == rnd.custom_code()
    assert rnd.custom_code('@###') == rnd.custom_code('@###')
    assert rnd.custom_code('@###', '@', '#') == rnd.custom_code('@###', '@', '#')
    assert rnd.custom_code('@###', '@', '#') != rnd.custom_code('@###', '#', '@')
    assert rnd.custom_code('@###', '@', '#') != rnd.custom_code('@###', '#', '#')
    assert rnd.custom_code('@###', '@', '#') != rnd.custom_code('@###', '@', '@')
    assert rnd.custom

# Generated at 2022-06-17 23:20:44.335451
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == '@AAA'
    assert rnd.custom_code(mask='@###') == '@AAA'
    assert rnd.custom_code(mask='@###', char='@', digit='#') == '@AAA'
    assert rnd.custom_code(mask='@###', char='@', digit='#') != '@BBB'
    assert rnd.custom_code(mask='@###', char='@', digit='#') != '@111'
    assert rnd.custom_code(mask='@###', char='@', digit='#') != '@222'
    assert rnd.custom_code(mask='@###', char='@', digit='#') != '@333'
   