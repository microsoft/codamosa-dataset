

# Generated at 2022-06-17 23:19:31.591529
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code of class Random.

    :return: None
    """
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code('@###') == '@###'
    assert rnd.custom_code('@###', '@', '#') == '@###'
    assert rnd.custom_code('@@##', '@', '#') == '@@##'
    assert rnd.custom_code('@@##', '@', '#') != '@@##'
    assert rnd.custom_code('@@##', '@', '#') != '@@##'
    assert rnd.custom_code('@@##', '@', '#') != '@@##'
    assert rnd.custom_code('@@##', '@', '#')

# Generated at 2022-06-17 23:19:41.605705
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###', char='@', digit='#')
    assert isinstance(code, str)
    assert len(code) == 9
    assert code.isalpha()

    code = rnd.custom_code(mask='@###-@###', char='#', digit='@')
    assert isinstance(code, str)
    assert len

# Generated at 2022-06-17 23:19:52.150227
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == '@AAA'
    assert rnd.custom_code('@###') == '@000'
    assert rnd.custom_code('@###', '@', '#') == '@000'
    assert rnd.custom_code('@###', '#', '@') == '@000'
    assert rnd.custom_code('@###', '#', '#') == '@000'
    assert rnd.custom_code('@###', '@', '@') == '@000'
    assert rnd.custom_code('@###', '#', '#') == '@000'
    assert rnd.custom_code('@###', '#', '#') == '@000'


# Generated at 2022-06-17 23:20:02.203813
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code() == '@###'
    assert r.custom_code(mask='@###-@###') == '@###-@###'
    assert r.custom_code(mask='@###-@###', char='@', digit='#') == '@###-@###'
    assert r.custom_code(mask='@###-@###', char='#', digit='@') == '@###-@###'
    assert r.custom_code(mask='@###-@###', char='#', digit='#') == '@###-@###'
    assert r.custom_code(mask='@###-@###', char='@', digit='@') == '@###-@###'

# Generated at 2022-06-17 23:20:12.529090
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code() == '@###'
    assert r.custom_code(mask='@@@') == '@@@'
    assert r.custom_code(mask='@@@', char='@', digit='#') == '@@@'
    assert r.custom_code(mask='@@@', char='#', digit='@') == '@@@'
    assert r.custom_code(mask='@@@', char='#', digit='#') == '@@@'
    assert r.custom_code(mask='@@@', char='@', digit='@') == '@@@'
    assert r.custom_code(mask='@@@', char='@', digit='@') == '@@@'

# Generated at 2022-06-17 23:20:24.286301
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == '@###'
    assert rnd.custom_code('@###') == '@###'
    assert rnd.custom_code('@###', '@', '#') == '@###'
    assert rnd.custom_code('@###', '#', '@') == '@###'
    assert rnd.custom_code('@###', '#', '#') == '@###'
    assert rnd.custom_code('@###', '@', '@') == '@###'
    assert rnd.custom_code('@###', '#', '#') == '@###'
    assert rnd.custom_code('@###', '#', '@') == '@###'

# Generated at 2022-06-17 23:20:35.671538
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    assert Random().custom_code() == '@AAA'
    assert Random().custom_code(mask='@@@') == 'AAA'
    assert Random().custom_code(mask='@@@', char='#') == 'AAA'
    assert Random().custom_code(mask='@@@', digit='#') == 'AAA'
    assert Random().custom_code(mask='@@@', char='#', digit='@') == 'AAA'
    assert Random().custom_code(mask='@@@', char='@', digit='#') == 'AAA'
    assert Random().custom_code(mask='@@@', char='@', digit='@') == 'AAA'
    assert Random().custom_code(mask='@@@', char='#', digit='#') == 'AAA'

# Generated at 2022-06-17 23:20:44.246224
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == 'A000'
    assert rnd.custom_code('@###') == 'A000'
    assert rnd.custom_code('@@##') == 'AA00'
    assert rnd.custom_code('@@@') == 'AAA'
    assert rnd.custom_code('@@@', '@', '#') == 'AAA'
    assert rnd.custom_code('@@@', '#', '@') == '000'
    assert rnd.custom_code('@@@', '#', '#') == '000'
    assert rnd.custom_code('@@@', '@', '@') == 'AAA'
    assert rnd.custom_code('@@@', 'A', 'A') == 'AAA'

# Generated at 2022-06-17 23:20:49.356857
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code(mask='@###') in ['A123', 'B123', 'C123', 'D123', 'E123', 'F123', 'G123', 'H123', 'I123', 'J123', 'K123', 'L123', 'M123', 'N123', 'O123', 'P123', 'Q123', 'R123', 'S123', 'T123', 'U123', 'V123', 'W123', 'X123', 'Y123', 'Z123']

# Generated at 2022-06-17 23:20:54.884584
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###') == 'A123'
    assert random.custom_code('@###', '@', '#') == 'A123'
    assert random.custom_code('@###', '#', '@') == 'A123'
    assert random.custom_code('@###', '@', '@') == 'A123'
    assert random.custom_code('@###', '#', '#') == 'A123'
    assert random.custom_code('@###', '@', '#') == 'A123'
    assert random.custom_code('@###', '#', '@') == 'A123'
    assert random.custom_code('@###', '@', '@') == 'A123'