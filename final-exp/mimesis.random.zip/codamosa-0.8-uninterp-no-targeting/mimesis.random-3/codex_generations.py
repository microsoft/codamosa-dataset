

# Generated at 2022-06-21 16:50:25.378613
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(os.urandom(10)) == 10  # nosec



# Generated at 2022-06-21 16:50:27.504292
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    assert isinstance(r.generate_string('asd'), str)



# Generated at 2022-06-21 16:50:29.715334
# Unit test for constructor of class Random
def test_Random():
    # Test with no arguments
    random = Random()
    # Test with argument
    random = Random(1)
    # Test with zero value of seed
    random = Random(0)

# Generated at 2022-06-21 16:50:33.610687
# Unit test for method randstr of class Random
def test_Random_randstr():
    randstr = random.randstr()
    assert isinstance(randstr, str)
    assert randstr == random.randstr(unique=True)
    assert len(randstr) == 16
    assert isinstance(random.randstr(length=16), str)
    assert len(random.randstr(length=16)) == 16
    assert len(random.randstr(length=64)) == 64

# Generated at 2022-06-21 16:50:40.611021
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert rnd.random() == rnd.random()
    assert rnd.randrange(0, 10, 3) == rnd.randrange(0, 10, 3)
    rnd = Random(3)
    assert rnd.random() == rnd.random()
    assert rnd.randrange(0, 10, 3) == rnd.randrange(0, 10, 3)



# Generated at 2022-06-21 16:50:45.328642
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from hypothesis import given, strategies as st
    from mimesis.enums import Digit
    from . import provider

    data_provider = provider.CustomCode()

    # Repeat test 100 times
    @given(st.integers(0, 100))
    def test(i):
        assert data_provider(digit=Digit.HEXADECIMAL) == data_provider(digit=Digit.HEXADECIMAL)

# Generated at 2022-06-21 16:50:51.004282
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    length = 5
    str_seq = string.digits + 'abcdef'
    assert len(random.generate_string(str_seq, length)) == length
    assert len(random.generate_string('', length)) == length
    assert len(random.generate_string(str_seq, 0)) == 0



# Generated at 2022-06-21 16:50:55.029627
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    assert len(Random().randstr()) == 32
    assert len(Random().randstr(length=10)) == 10
    assert isinstance(Random().randstr(), str)

# Generated at 2022-06-21 16:50:59.637779
# Unit test for method randstr of class Random
def test_Random_randstr():
    print(random.randstr())
    print(random.randstr())
    assert len(random.randstr()) != len(random.randstr())
    assert len(random.randstr(unique=True)) == 32
    assert len(random.randstr(length=32)) == 32

# Generated at 2022-06-21 16:51:05.560465
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Generate random string with default parameters
    default_string = Random().randstr()

    # Generate random string with only unique values
    unique_string = Random().randstr(unique=True)

    # Generate random string with specified length
    specified_string = Random().randstr(length=50)

    # Generate random string with unique values and specified length
    unique_specified_string = Random().randstr(unique=True, length=50)

    # Generate random string with unique values and default length
    unique_default_string = Random().randstr(unique=True)

    # Generate random string with specified length and default unique value
    specified_default_string = Random().randstr(length=50)

    # Generate random string with invalid parameters


# Generated at 2022-06-21 16:51:59.812462
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)

# Generated at 2022-06-21 16:52:05.935595
# Unit test for method randstr of class Random
def test_Random_randstr():
    random.seed(1)
    assert random.randstr() == '9c87d87f7fd0f0ae8eff7a1a0a4fa7d1'
    assert random.randstr(unique=True) == '962e1ad44985434096566e5b7d5ebbb6'
    assert random.randstr(unique=True) == 'c5b5bd878c6f49dea0e0c9b9e8c2a1b0'
    assert random.randstr(unique=True) == '07d6fcf9a84b49f9978af6a82d6b3c6f'

# Generated at 2022-06-21 16:52:15.558435
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random.

    """
    from mimesis.statistics import FrequencyCounter
    number_of_tests = 1000
    test_error_msg = "There is an incorrectly generated list of integers"
    for i in range(1, number_of_tests):
        rnd = Random()
        a = rnd.randint()
        b = rnd.randint(0, 100)
        amount = rnd.randint(1, 100)
        result = rnd.randints(amount, a, b)
        assert len(result) == amount, test_error_msg
        assert FrequencyCounter(result).frequency() == amount, test_error_msg
        assert FrequencyCounter(result).min() >= a, test_error_msg
        assert FrequencyCounter(result).max() <= b, test_error_msg

# Generated at 2022-06-21 16:52:16.499327
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    assert random is not None



# Generated at 2022-06-21 16:52:18.112745
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random.randstr()
    assert len(rnd) < 129 and len(rnd) > 15
    

# Generated at 2022-06-21 16:52:20.390965
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)

# Generated at 2022-06-21 16:52:24.363043
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert (rnd.custom_code() == rnd.custom_code()) is False
    assert (rnd.custom_code() == rnd.custom_code()) is False
    assert (rnd.custom_code() == rnd.custom_code()) is False
    assert (rnd.custom_code() == rnd.custom_code()) is False

# Generated at 2022-06-21 16:52:31.870630
# Unit test for method randints of class Random
def test_Random_randints():

    rnd = Random()
    first = rnd.randints()
    second = rnd.randints(a=0, b=30)
    third = rnd.randints(amount=10)
    fourth = rnd.randints(amount=10, a=0, b=10)

    assert type(first) == list
    assert len(first) == 3
    assert first[0] <= 100 and first[0] >= 1
    assert first[1] <= 100 and first[1] >= 1
    assert first[2] <= 100 and first[2] >= 1

    assert type(second) == list
    assert len(second) == 3
    assert second[0] <= 30 and second[0] >= 0
    assert second[1] <= 30 and second[1] >= 0

# Generated at 2022-06-21 16:52:36.327376
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for method :meth:`uniform <mimesis.helpers.Random.uniform>`."""
    seed = 12345
    a = 1.00001
    b = 3

    random.seed(seed)
    assert Decimal(random.uniform(a, b)) == Decimal('1.214272380012595')

    random.seed(seed)
    assert Decimal(
        random.uniform(a, b, precision=4)) == Decimal('1.2143')

# Generated at 2022-06-21 16:52:38.503113
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(), str)