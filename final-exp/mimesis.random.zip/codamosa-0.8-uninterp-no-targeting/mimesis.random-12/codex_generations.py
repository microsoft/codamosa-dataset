

# Generated at 2022-06-21 16:44:51.004595
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(random.randints(), list)
    assert len(random.randints()) == 3
    assert random.randints(2) == [18, 42]
    assert sorted(random.randints(5, a=5, b=10)) == [5, 6, 7, 8, 9]
    assert random.randints(-10, -5) == []



# Generated at 2022-06-21 16:44:54.783164
# Unit test for method uniform of class Random
def test_Random_uniform():
    min_value = random.uniform(0, 4.25)
    assert min_value >= 0
    assert min_value <= 4.25
    max_value = random.uniform(3.99, 5)
    assert max_value >= 3.99
    assert max_value <= 5

# Generated at 2022-06-21 16:44:55.997643
# Unit test for method urandom of class Random
def test_Random_urandom():
    random = Random()
    assert random.urandom(1)

# Generated at 2022-06-21 16:45:00.917146
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test"""
    letters = string.ascii_uppercase.encode()
    digits = string.digits.encode()
    mask = b'@###'
    char = b'@'
    digit = b'#'

    assert char != digit
    code = Random.custom_code(None, mask=mask, char=char, digit=digit)
    for i in code:
        if i in char:
            assert i in letters
        elif i in digit:
            assert i in digits

# Generated at 2022-06-21 16:45:04.144720
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    r.seed(2)
    assert r.custom_code(mask='@###', char='@', digit='#') == 'B942'
    assert r.custom_code(mask='@####', char='@', digit='#') == 'A0842'
    assert r.custom_code(mask='@#@#@#@#@#', char='@', digit='#') == 'A9X5B5Z4N7'

# Generated at 2022-06-21 16:45:14.882504
# Unit test for method uniform of class Random
def test_Random_uniform():
    # precision = 15 and b = a
    r = Random()
    assert r.uniform(10, 10, 15) == 10.0

    # precision = 15 and b < a
    r = Random()
    assert r.uniform(100, 10, 15) == 55.44444444444444

    # precision = 15 and b > a
    r = Random()
    assert r.uniform(10, 100, 15) == 55.44444444444444

    # precision = 1 and b < a
    r = Random()
    assert r.uniform(100, 10, 1) == 55.4

    # precision = 1 and b > a
    r = Random()
    assert r.uniform(10, 100, 1) == 55.4

    # precision = 2 and b < a
    r = Random()
   

# Generated at 2022-06-21 16:45:15.833812
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender

    assert get_random_item(Gender) in list(Gender)

# Generated at 2022-06-21 16:45:17.574219
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    class Enum(object):
        """Test enum."""
        A = 1
        B = 2

    assert get_random_item(Enum, random) in [Enum.A, Enum.B]



# Generated at 2022-06-21 16:45:21.698766
# Unit test for method randints of class Random
def test_Random_randints():
    random = Random()
    assert random.randints(amount=-1, a=1, b=100) == []
    assert random.randints(amount=0, a=1, b=100) == []
    assert random.randints(amount=1, a=1, b=100) == [4]
    assert random.randints(amount=3, a=1, b=100) == [7, 22, 65]

# Generated at 2022-06-21 16:45:22.938318
# Unit test for function get_random_item
def test_get_random_item():
    _ = get_random_item(enum)

# Generated at 2022-06-21 16:49:18.781662
# Unit test for constructor of class Random
def test_Random():
    assert Random()
    assert Random().randstr(unique=True)
    assert Random().randints(2)[1]
    assert not Random().randstr(unique=False)
    assert Random().generate_string('ASD')
    assert Random().custom_code()
    assert Random().urandom(1)
    assert Random().uniform(1, 7)



# Generated at 2022-06-21 16:49:21.150234
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for method uniform of class Random."""
    for _ in range(1000):
        r = random.uniform(5, 10)
        assert 5 <= r < 10

    for _ in range(1000):
        r = random.uniform(5, 10, 3)
        assert 5 <= r < 10



# Generated at 2022-06-21 16:49:25.201416
# Unit test for method randints of class Random
def test_Random_randints():
    s = {
        'foo': {'amount': 3, 'a': 1, 'b': 100},
        'bar': {'amount': 25, 'a': 1, 'b': 100},
        'qux': {'amount': 15, 'a': 1, 'b': 100},
    }

    for i in s:
        t = s[i]
        amount = t['amount']
        a = t['a']
        b = t['b']
        random_list = Random().randints(amount, a, b)
        assert len(random_list) == amount
        for item in random_list:
            assert item <= b and item >= a



# Generated at 2022-06-21 16:49:30.392544
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert Random().uniform(0.0, 1.0) in [0.0, 1.0]
    assert Random().uniform(0.0, 1.0, precision=1) in [0.0, 1.0]
    assert Random().uniform(0.0, 1.0, precision=2) in [0.0, 1.0]


if __name__ == '__main__':
    test_Random_uniform()

# Generated at 2022-06-21 16:49:38.536583
# Unit test for constructor of class Random
def test_Random():
    rnd = Random(1)
    assert rnd.randstr(length=16) == 'oOJYyGYHaIkQaYmY'

# Generated at 2022-06-21 16:49:43.194668
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    class E(enum.Enum):
        A = 1
        B = 2
        C = 3
        D = 4

    assert get_random_item(E) in list(E)

# Generated at 2022-06-21 16:49:48.364085
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code(mask='@@@######', char='#', digit='@')
    assert len(code) == 10
    assert code[0:3].isalpha()
    assert code[3:].isdigit()

# Generated at 2022-06-21 16:49:50.872337
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert round(random.uniform(-1, 1, precision=1)) == 0
    assert round(random.uniform(-10, -5, precision=1)) == -7
    assert round(random.uniform(10, 15, precision=1)) == 13

# Generated at 2022-06-21 16:49:52.123905
# Unit test for method urandom of class Random
def test_Random_urandom():
    url = Random().urandom()
    assert isinstance(url, bytes)



# Generated at 2022-06-21 16:49:52.851571
# Unit test for method randstr of class Random
def test_Random_randstr():
    print(Random().randstr(length=20))

# Generated at 2022-06-21 16:50:13.436060
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == '@0@8@'
    assert len(random.custom_code()) == 5
    assert '@' in random.custom_code()
    assert '#' in random.custom_code()

# Generated at 2022-06-21 16:50:16.866315
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code(mask='@###') == '@000'
    assert r.custom_code(mask='@###', char='X', digit='X') != '@000'
    assert r.custom_code(mask='@###', char='@', digit='@') == '@000'

# Generated at 2022-06-21 16:50:17.871429
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert isinstance(rnd.custom_code(), str)

# Generated at 2022-06-21 16:50:18.758950
# Unit test for method urandom of class Random
def test_Random_urandom():
    result = Random.urandom(30)
    assert len(result) == 30

# Generated at 2022-06-21 16:50:23.092057
# Unit test for method randstr of class Random
def test_Random_randstr():
    import time
    import numpy as np
    # get 5 values
    print('Random string: %s' % str(random.randstr()))
    print('Random string: %s' % str(random.randstr()))
    print('Random string: %s' % str(random.randstr()))
    print('Random string: %s' % str(random.randstr()))
    print('Random string: %s' % str(random.randstr()))

    # get unique values
    unique_values = []
    print('Unique values:')
    t1 = time.time()
    for i in range(100):
        # get unique value
        tmp = random.randstr(unique=True)
        # save
        unique_values.append(tmp)

# Generated at 2022-06-21 16:50:26.012513
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    from mimesis.enums import Gender

    item = get_random_item(Gender)
    assert hasattr(item, 'value')
    assert hasattr(item, 'name')
    assert isinstance(item, Gender)

# Generated at 2022-06-21 16:50:30.359117
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    
    # Check whether a method generate_string return string length 3
    assert len(Random().generate_string('adc', 3)) == 3, "Fail test when value length is 3"
    print('Pass test when value length is 3')

if __name__ == '__main__':
    test_Random_generate_string()

# Generated at 2022-06-21 16:50:31.946720
# Unit test for method randstr of class Random
def test_Random_randstr():
    random_string = Random().randstr()
    assert random_string
    assert len(random_string) > 0

# Generated at 2022-06-21 16:50:35.183560
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    print(rnd.generate_string('abcd', 20))
    print(rnd.generate_string('1234', 10))



# Generated at 2022-06-21 16:50:40.474446
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() != random.custom_code()
    assert random.custom_code(mask='@@@') != random.custom_code(mask='@@@')
    assert random.custom_code(mask='@@@', char='@') != random.custom_code(mask='@@@', char='@')

