

# Generated at 2022-06-21 16:44:55.177540
# Unit test for constructor of class Random
def test_Random():
    random.seed()
    assert isinstance(random.seed(), None)
    assert isinstance(random.randint(1, 10), int)
    assert isinstance(random.randint(1, 10, None), int)
    assert isinstance(random.randints(3, 1, 200), list)
    assert isinstance(random.uniform(1.0, 2.0), float)
    assert isinstance(random.choice('test'), str)
    assert isinstance(random.generate_string('test'), str)
    assert isinstance(random.custom_code(), str)
    assert isinstance(random.urandom(), bytes)
    assert isinstance(random.random(), float)

# Generated at 2022-06-21 16:44:57.370695
# Unit test for function get_random_item
def test_get_random_item():
    # create enum object
    class Foo(random_module.Random):
        bar = 1
        baz = 2

    assert isinstance(get_random_item(Foo), int)

# Generated at 2022-06-21 16:44:59.069338
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = random.uniform(1.0, 5.0, precision=0)
    assert rnd in [1, 2, 3, 4, 5]

# Generated at 2022-06-21 16:45:01.639419
# Unit test for method uniform of class Random
def test_Random_uniform():
    s = []
    for _ in range(1000000):
        s.append(random.uniform(1.0, 2.1))

    assert sum(s) / len(s) == sum(s) / 1000000

# Generated at 2022-06-21 16:45:06.720495
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test uniform(a, b) method."""
    rnd = Random()
    c = []
    for i in range(100):
        c.append(rnd.uniform(3.14, 5.1))
    assert len(c) == 100
    assert min(c) >= 3.14
    assert max(c) <= 5.1

# Generated at 2022-06-21 16:45:09.819873
# Unit test for function get_random_item
def test_get_random_item():
    class TestEnum(object):
        TEST = 'test'

    test = get_random_item(TestEnum)
    assert test == 'test'



# Generated at 2022-06-21 16:45:15.606006
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    # The number of unique values
    unique_values = set()

    # Generate 10000 unique values
    for _ in range(10000):
        value = rnd.randstr(unique=True)
        unique_values.add(value)

    # The number of unique values - the number of iterations must be equal
    assert len(unique_values) == 10000


if __name__ == '__main__':
    test_Random_randstr()

# Generated at 2022-06-21 16:45:17.558771
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test uniform method of class Random."""
    random = Random()
    x = random.uniform(250, 251)
    assert x >= 250 and x < 251

# Generated at 2022-06-21 16:45:25.285001
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###') == 'AX24'
    assert random.custom_code('@###') == 'XB89'
    assert random.custom_code('@@##') == 'WL02'
    assert random.custom_code('@@##') == 'TT57'
    assert random.custom_code('@@##') == 'PT04'
    assert random.custom_code('@@##') == 'SF38'
    assert random.custom_code('@@##') == 'JA44'
    assert random.custom_code('@@##') == 'KH23'
    assert random.custom_code('@@##') == 'PD15'
    assert random.custom_code('@@##') == 'ZA58'
    # Test case for exception
    assert random.custom_code('@@##') == 'XD11'
   

# Generated at 2022-06-21 16:45:32.404585
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(100):
        code = Random().custom_code(mask='A##CDD-@#@#', char='A', digit='D')
        assert len(code) == 13

    code = Random().custom_code(mask='A##CDD-@#@#')
    assert len(code) == 13

    code = Random().custom_code(mask='A##CDD-@#@#', char='D', digit='A')
    assert len(code) == 13

