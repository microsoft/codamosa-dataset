

# Generated at 2022-06-21 16:44:46.063990
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3
    assert len(Random().randints(3, 1, 100)) == 3
    assert len(Random().randints(100, 1, 100)) == 100
    assert len(Random().randints(100, 1, 10)) == 100
    assert len(Random().randints(100)) == 100
    assert len(Random().randints(100, 1)) == 100
    assert len(Random().randints(100, 100, 100)) == 100
    assert len(Random().randints(100, 100, 10000)) == 100

    assert isinstance(Random().randints(), list)
    assert isinstance(Random().randints(3, 1, 100), list)
    assert isinstance(Random().randints(100, 1, 100), list)

# Generated at 2022-06-21 16:44:52.890209
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    amount = 20
    assert isinstance(random.generate_string(string.ascii_letters, amount), str)
    assert len(random.generate_string(string.ascii_letters, amount)) == amount
    assert random.generate_string(string.ascii_letters, amount).isalnum()
    assert isinstance(random.generate_string(string.ascii_letters), str)
    assert len(random.generate_string(string.ascii_letters)) == 10
    assert random.generate_string(string.ascii_letters).isalnum()


# Generated at 2022-06-21 16:44:54.811365
# Unit test for method randints of class Random
def test_Random_randints():
    random.seed(42)
    result = random.randints()
    assert result == [37, 8, 46]



# Generated at 2022-06-21 16:45:01.038894
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item.

    """
    from mimesis.enums import (
        CardIssuer,
        InsuranceType,
        OperatingSystem,
        PaymentMethod,
        TransportType,
    )

    assert get_random_item(CardIssuer) in CardIssuer
    assert get_random_item(InsuranceType) in InsuranceType
    assert get_random_item(OperatingSystem) in OperatingSystem
    assert get_random_item(PaymentMethod) in PaymentMethod
    assert get_random_item(TransportType) in TransportType
    assert get_random_item(PaymentMethod, Random()) in PaymentMethod



# Generated at 2022-06-21 16:45:03.710550
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for method uniform of class Random."""
    result = random.uniform(1, 2, precision=2)
    assert result > 1 and result < 2
    assert isinstance(result, float)

# Generated at 2022-06-21 16:45:07.376016
# Unit test for method uniform of class Random
def test_Random_uniform():
    _uniform = [random.uniform(1, 2) for _ in range(100)]
    assert _uniform.count(1.0) == 0
    assert _uniform.count(2.0) == 0

# Generated at 2022-06-21 16:45:11.628961
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    l = r.randints(1, 10)
    assert isinstance(l, list)
    for elem in l:
        assert isinstance(elem, int)
    assert max(l) <= 10
    assert min(l) >= 1

# Generated at 2022-06-21 16:45:19.960003
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    mask = '@###'
    char = '@'
    digit = '#'

    code1 = Random.custom_code(mask=mask, char=char, digit=digit)

    # Expected to create new code
    assert code1 != Random.custom_code(mask=mask)
    # Expected to create new code
    assert code1 != Random.custom_code(mask=mask, char=char, digit=digit)

    # Expected to create a new code based on the given mask
    assert len(code1) == len(mask)

    # Expected to create a new code which only contains A-Z and 0-9
    for char in code1:
        assert (65 <= ord(char) <= 90) or (48 <= ord(char) <= 57)

    # Expected to raise an exception

# Generated at 2022-06-21 16:45:25.703719
# Unit test for function get_random_item
def test_get_random_item():
    try:
        import faker
    except ImportError:
        return 0

    from mimesis.enums import Gender, Locale

    locale = get_random_item(Locale, random)
    assert type(locale.name) is str
    assert type(locale.value) is str
    assert len(locale.value) == 2

    gender = get_random_item(Gender, random)
    assert isinstance(gender, Gender)
    assert gender in Gender

    data = faker.Faker(locale.value)
    assert isinstance(data.name(gender.value), str)

# Generated at 2022-06-21 16:45:30.806874
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    r.seed(2)
    str_seq = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert r.generate_string(str_seq) == 'sijIHmkgWO'

# Generated at 2022-06-21 16:45:38.574508
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert random.randstr(unique=True) != str(uuid.uuid4().hex)



# Generated at 2022-06-21 16:45:40.363748
# Unit test for method uniform of class Random
def test_Random_uniform():
    num = Random().uniform(-100, 100, precision=100)
    assert isinstance(num, float)

# Generated at 2022-06-21 16:45:41.189433
# Unit test for constructor of class Random
def test_Random():
    assert Random()



# Generated at 2022-06-21 16:45:48.867143
# Unit test for function get_random_item
def test_get_random_item():
    # type: () -> Any
    class Const(object):
        class E(object):
            def __init__(self, x: str = '', y: str = '') -> None:
                # type: (...) -> None
                self.x = x
                self.y = y

        A = E('A', 'a')
        B = E('B', 'b')

    c = Const()
    for _ in range(10):
        rnd = get_random_item(c.E)
        assert isinstance(rnd, Const.E)

# Generated at 2022-06-21 16:45:55.085424
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random.

    """
    rnd = Random()
    a = -0.5
    b = 2
    x = rnd.uniform(a, b)
    assert a <= x <= b

    precision = 3
    x = rnd.uniform(a, b, precision=precision)
    assert a <= x <= b
    assert precision == len(str(x).split('.')[-1])

# Generated at 2022-06-21 16:45:57.516315
# Unit test for function get_random_item
def test_get_random_item():
    """Test for function get_random_item."""
    from mimesis.enums import Gender
    gender_random = get_random_item(Gender)
    assert gender_random in Gender

# Generated at 2022-06-21 16:46:08.927606
# Unit test for method randstr of class Random
def test_Random_randstr():
    from mimesis.builtins import EN
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.misc import Misc
    from mimesis.providers.address import Address

    person = Person('en')
    misc = Misc('en')
    address = Address('en')

    person_data = {}

    for _ in range(1000):
        person_data[person.full_name(gender=Gender.MALE)] = person.occupation()

    for _ in range(1000):
        person_data[person.full_name(gender=Gender.FEMALE)] = person.occupation()


# Generated at 2022-06-21 16:46:11.408264
# Unit test for method randstr of class Random
def test_Random_randstr():
    for i in range(10):
        assert isinstance(random.randstr(), str)

# Generated at 2022-06-21 16:46:13.675931
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    rnd.seed(1234567890)
    assert rnd.custom_code() == '@UYV'



# Generated at 2022-06-21 16:46:15.914330
# Unit test for method uniform of class Random
def test_Random_uniform():
    f = random.uniform(5.5, 5.5)
    assert f == 5.5

# Generated at 2022-06-21 16:46:31.012387
# Unit test for function get_random_item
def test_get_random_item():
    # Example of using enum
    class Color(object):
        RED = 'red'
        BLUE = 'blue'
        GREEN = 'green'

        @classmethod
        def choices(cls):
            return [i.value for i in cls]

    assert get_random_item(Color) in Color.choices()

# Generated at 2022-06-21 16:46:32.983033
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    _list = []
    for _ in Random().generate_string('0123456789'):
        _list.append(_)
    return _list


# Generated at 2022-06-21 16:46:40.477193
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    import pytest

    rnd = Random()
    code = rnd.custom_code('@@@###')
    assert len(code) == 7
    assert code[0].isalpha()
    assert code[1].isalpha()
    assert code[2].isalpha()
    assert code[3].isdigit()
    assert code[4].isdigit()
    assert code[5].isdigit()
    assert code[6].isdigit()

    code = rnd.custom_code('@###')
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1].isdigit()
    assert code[2].isdigit()
    assert code[3].isdigit()

    code = rnd.custom_code('@###', char='+')

# Generated at 2022-06-21 16:46:44.482168
# Unit test for method randints of class Random
def test_Random_randints():
    random_object = Random()
    # Positive test
    test_case1 = random_object.randints()
    assert isinstance(test_case1, list)
    # Negative test
    test_case2 = random_object.randints(amount=0)
    assert test_case2 == []


# Generated at 2022-06-21 16:46:50.004184
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom()

# Generated at 2022-06-21 16:46:52.092179
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = Random()
    assert isinstance(r.randstr(), str)
    assert r.randstr(unique=True).startswith('0')
    assert len(r.randstr(length=12)) == 12

# Generated at 2022-06-21 16:46:52.875181
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert b'123' != Random().urandom(3)

# Generated at 2022-06-21 16:46:54.246883
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(random.randints(), list)

# Generated at 2022-06-21 16:47:00.325392
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string('ABC'*10, 5) in ('AAAAAB', 'CCCCCB', 'BBBBBA')
    assert random.generate_string('abc'*10, 5) in ('aaaaab', 'cccccb', 'bbbbba')

    assert random.generate_string('1234567890', 5) in ('43141', '52883', '73412')
    assert random.generate_string('1234567890', 5) not in ('AAAAA', 'BBBBB', 'CCCCCC')
    assert random.generate_string('1234567890', 5) not in ('aaaaa', 'bbbbb', 'cccccc')



# Generated at 2022-06-21 16:47:03.829821
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    for i in range(10):
        print(r.randints(amount=1, a=0, b=10))


if __name__ == '__main__':
    test_Random_randints()

# Generated at 2022-06-21 16:47:19.485695
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of class Random"""
    rand = Random()
    assert rand.uniform(0, 1) in [0.0, 1.0]
    assert rand.uniform(0, 1, 0) in [0.0, 1.0]

if __name__ == '__main__':
    test_Random_uniform()

# Generated at 2022-06-21 16:47:21.205695
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    assert isinstance(rnd.randstr(), str)
    assert isinstance(rnd.randstr(unique=True), str)

# Generated at 2022-06-21 16:47:22.184976
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random.gender()), str)



# Generated at 2022-06-21 16:47:26.377870
# Unit test for method randstr of class Random
def test_Random_randstr():
    randstr = Random.randstr(unique=True)
    str_length = len(randstr)
    assert isinstance(str_length, int), AssertionError
    assert str_length > 0, AssertionError
    assert all(x != "-" for x in randstr), AssertionError

# Generated at 2022-06-21 16:47:28.273174
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.builtins import Cat
    cat = Cat()
    assert isinstance(cat.breed(), str)

# Generated at 2022-06-21 16:47:36.693081
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()  # use default seed
    rnd.seed(100)   # set a specific seed
    rnd.seed()      # reset the seed
    rnd.random()    # get random number in the range [0.0, 1.0)
    rnd.randrange(10) #get random integer in range [0, 10)
    rnd.choice([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) #get random item from list
    rnd.shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) #shuffle list items
    rnd.sample([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 3) #get list of random items
    rnd.ints(5, 1, 10) #get

# Generated at 2022-06-21 16:47:45.198623
# Unit test for constructor of class Random
def test_Random():
    assert random.randint(1, 10) in range(1, 11)
    assert random.randint(1, 10) in range(1, 11)
    assert random.randint(1, 10) in range(1, 11)
    assert random.randint(1, 10) in range(1, 11)
    assert random.randint(1, 10) in range(1, 11)

    assert random.randints(5) == random.randints(5)
    assert random.randints(5) == random.randints(5)
    assert random.randints(5) == random.randints(5)
    assert random.randints(5) == random.randints(5)
    assert random.randints(5) == random.randints(5)


# Generated at 2022-06-21 16:47:46.910764
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)



# Generated at 2022-06-21 16:47:48.257965
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(0) == []
    assert Random().randints(2) == []

# Generated at 2022-06-21 16:47:54.010727
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random.

    Method randstr of class Random generates random string value.
    This method can be especially useful when you need to generate
    only unique values in your provider. Just pass parameter unique=True.

    Basically, this method is just a simple wrapper around uuid.uuid4().

    :return: None.

    """
    _test = Random()
    _test_length = 10
    _test_str = _test.randstr(length=_test_length)
    assert len(_test_str) == _test_length

# Generated at 2022-06-21 16:48:03.842386
# Unit test for function get_random_item
def test_get_random_item():
    class Colors(object):
        RED = 1
        BLUE = 2
        GREEN = 3

    _colors = get_random_item(Colors)
    assert _colors in [1, 2, 3]


# Unit tests for class Random

# Generated at 2022-06-21 16:48:06.753926
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    assert len(rnd.generate_string('ABCD', 10)) == 10
    assert len(rnd.generate_string('ABCD', 3)) == 3
    assert len(rnd.generate_string('ABCD123', 10)) == 10

# Generated at 2022-06-21 16:48:08.008090
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    assert isinstance(random, Random)

# Generated at 2022-06-21 16:48:16.418820
# Unit test for constructor of class Random
def test_Random():
    # test: 'The class is a subclass of the class ``Random()`` from the module ' \
    #       '``random`` of the standard library'
    assert issubclass(Random, random_module.Random)
    _rnd = Random()
    _rnd.seed()

    # test: 'The class is a subclass of the class ``Random()`` from the module ' \
    #       '``random`` of the standard library, which provides the custom methods.'
    assert hasattr(_rnd, 'randints')
    assert hasattr(_rnd, 'urandom')
    assert hasattr(_rnd, 'generate_string')
    assert hasattr(_rnd, 'custom_code')
    assert hasattr(_rnd, 'uniform')



# Generated at 2022-06-21 16:48:19.430363
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(random.generate_string('qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM', 10), str)
    assert isinstance(random.generate_string('1234567890', 10), str)


# Generated at 2022-06-21 16:48:20.340159
# Unit test for constructor of class Random
def test_Random():
    print (Random().randint(1, 10))


# Generated at 2022-06-21 16:48:23.625921
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    res = random.custom_code('abc\n@###', '@', '#')
    assert(res in ['abc\n', 'abc\nABCD', 'abc\n0123'])
    res = random.custom_code('ab@@@___###', '@', '#')
    assert(res in ['ab@@@___', 'abABC@___', 'abABC@0123'])

# Generated at 2022-06-21 16:48:27.066498
# Unit test for method uniform of class Random
def test_Random_uniform():
    import math
    M = 100000
    count = 0
    a, b = -3.14, 3.14
    eps = 1e-6

    for _ in range(M):
        x = random.uniform(a, b)
        if abs(x) < eps:
            count += 1

    probability = count / M

    assert math.isclose(probability, (b - a) / (2 * max(a, b)), rel_tol=0.1)

# Generated at 2022-06-21 16:48:31.280670
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert rnd.uniform(1, 1.5, precision=5) in [
        1.0, round(1.0 + (1.5 - 1) * rnd.random(), 5),
        round(1.0 + (1.5 - 1) * rnd.random(), 5),
        round(1.0 + (1.5 - 1) * rnd.random(), 5),
        1.5, round(1.0 + (1.5 - 1) * rnd.random(), 5),
        round(1.0 + (1.5 - 1) * rnd.random(), 5),
        round(1.0 + (1.5 - 1) * rnd.random(), 5),
    ]

# Generated at 2022-06-21 16:48:36.322936
# Unit test for method uniform of class Random
def test_Random_uniform():
    for i in range(50):
        assert random.uniform(0,1)>=0
        assert random.uniform(0,1)<1
        assert random.uniform(-1,0)>-1
        assert random.uniform(-1,0)<=0
        assert random.uniform(-1,1)>=-1
        assert random.uniform(-1,1)<=1