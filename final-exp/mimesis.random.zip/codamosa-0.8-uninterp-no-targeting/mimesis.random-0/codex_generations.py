

# Generated at 2022-06-21 16:46:08.321131
# Unit test for method urandom of class Random
def test_Random_urandom():
    import pytest
    from mimesis.data import (
        SPECIAL_ASCII,
        UNICODE_ASCII,
    )

    rnd = Random()
    rnd.seed(1)  # to get a reproducible result
    random_str = rnd.urandom(10).decode()

    for i, l in zip(random_str, SPECIAL_ASCII):
        assert l in UNICODE_ASCII[i]



# Generated at 2022-06-21 16:46:10.730530
# Unit test for function get_random_item
def test_get_random_item():
    state = Random.getstate(random)
    Random.seed(0, version=2)
    result = get_random_item(random)
    Random.setstate(state)
    assert  result == 0

# Generated at 2022-06-21 16:46:17.473868
# Unit test for method uniform of class Random
def test_Random_uniform():
    # Initializing the random generator
    rd = Random(5)

    # Generating the number of float type using uniform method
    number = rd.uniform(1, 3)
    assert number == 1.2
    assert type(number) == float

    # Generating the number of float type using uniform method
    # with rounded to two digits
    number = rd.uniform(1, 3, precision=2)
    assert number == 1.20
    assert type(number) == float



# Generated at 2022-06-21 16:46:24.814998
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit tests for method uniform of class Random."""
    _random = random_module.Random()

    x = [_random.uniform(0, 10, precision=2) for _ in range(100)]
    assert all(0 < i < 10 for i in x)

    x = [_random.uniform(0, 10, precision=3) for _ in range(100)]
    assert all(0 < i < 10 for i in x)

    x = [_random.uniform(0, 10, precision=4) for _ in range(100)]
    assert all(0 < i < 10 for i in x)

    x = [_random.uniform(0, 10, precision=5) for _ in range(100)]
    assert all(0 < i < 10 for i in x)


# Generated at 2022-06-21 16:46:26.499451
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(10).__len__() == 10

# Generated at 2022-06-21 16:46:31.127099
# Unit test for function get_random_item
def test_get_random_item():
    from .datetime import DateTime
    date_time = DateTime()

    assert isinstance(date_time.date('en'), str)
    assert isinstance(date_time.date('en', future=True), str)
    assert isinstance(date_time.date(locale='ru'), str)
    assert isinstance(date_time.date(locale='ru', future=True), str)
    assert isinstance(date_time.date(locale='ru', past=True), str)
    assert isinstance(date_time.date(future=True), str)
    assert isinstance(date_time.date(past=True), str)

# Generated at 2022-06-21 16:46:33.882215
# Unit test for method randstr of class Random
def test_Random_randstr():
    ls = []
    for _ in range(100):
        str_ = random.randstr()
        if str_ in ls:
            raise AssertionError('Not unique')
        ls.append(str_)

# Generated at 2022-06-21 16:46:40.132892
# Unit test for constructor of class Random
def test_Random():
    """Test class Random.

    :return: Nothing
    """
    assert isinstance(random.randint(1, 100), int)
    assert isinstance(random.randints(1, 100), list)
    assert isinstance(random.generate_string('0123456789'), str)
    assert isinstance(random.custom_code(), str)
    assert isinstance(random.uniform(1, 100), float)
    assert isinstance(random.randstr(), str)
    if random.randint(0, 2) == 0:
        assert random.choice([0, 1, 2]) in [0, 1, 2]
    assert random.randstr(unique=True)

# Generated at 2022-06-21 16:46:44.210399
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0.1, 2.4) <= 2.4
    assert abs(0.1 - random.uniform(0.1, 0.1)) <= 0.00005
    assert abs(0.1 - random.uniform(0.1, 0.100000001)) <= 0.00005

# Generated at 2022-06-21 16:46:49.220411
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test suite for method randstr of class Random."""
    assert len(random.randstr()) > 1
    assert len(random.randstr(length=16)) == 16
    assert random.randstr(unique=True) != random.randstr(unique=True)

# Generated at 2022-06-21 16:48:35.408784
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)

# Generated at 2022-06-21 16:48:40.527283
# Unit test for method randints of class Random
def test_Random_randints():
    for _ in range(100):
        a = random.randrange(1, 100)
        b = random.randrange(a, 100)
        n = random.randrange(1, 100)
        result = random.randints(n, a, b)
        assert len(result) == n
        for i in result:
            assert a <= i <= b

# Generated at 2022-06-21 16:48:47.070059
# Unit test for function get_random_item
def test_get_random_item():
    from faker.providers import BaseProvider
    from faker.providers.lorem.en_US import Provider as EnProvider

    class MyProvider(BaseProvider):
        classes = {
            'class': EnProvider,
        }

        @classmethod
        def class_(cls, obj: Any) -> Any:
            return get_random_item(obj, random)

    f = Faker()
    f.add_provider(MyProvider)
    assert f.class_(BaseProvider)
    assert f.class_(EnProvider)

# Generated at 2022-06-21 16:48:49.320088
# Unit test for method urandom of class Random
def test_Random_urandom():
    rand = Random()
    # noinspection PyTypeChecker
    rand.urandom()

# Generated at 2022-06-21 16:48:50.232516
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    random = Random()
    assert random == random_module.Random()

# Generated at 2022-06-21 16:48:55.795701
# Unit test for method randints of class Random
def test_Random_randints():
    a = 1
    b = 100
    # Test for correct input
    lst = [random.randint(a, b) for _ in range(1000)]
    for i in lst:
        assert a <= i <= b
    # Test for incorrect input
    with pytest.raises(ValueError):
        random.randints(0)

# Generated at 2022-06-21 16:48:58.896128
# Unit test for method randints of class Random
def test_Random_randints():
    obj = random.randints()
    assert isinstance(obj, list) and obj



# Generated at 2022-06-21 16:49:01.705281
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-21 16:49:06.704863
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    rand = Random()
    randints = rand.randints(amount=3)
    assert randints is not None
    assert isinstance(randints, list)
    assert len(randints) == 3
    assert isinstance(randints[0], int)
    assert isinstance(randints[1], int)
    assert isinstance(randints[2], int)



# Generated at 2022-06-21 16:49:07.667709
# Unit test for constructor of class Random
def test_Random():
    assert Random.random


# Generated at 2022-06-21 16:50:33.670446
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert isinstance(rnd.random(), float)
    assert isinstance(rnd.randint(0, 10), int)
    assert isinstance(rnd.uniform(0, 10), float)
    assert isinstance(rnd.randstr(), str)
    assert isinstance(rnd.randstr(length=10), str)
    assert isinstance(rnd.randstr(unique=True), str)
    assert isinstance(rnd.choice(list(range(10))), int)
    assert isinstance(rnd.choices(list(range(10)), k=3), list)
    assert isinstance(rnd.choices('abc', k=3), list)
    assert isinstance(rnd.sample(list(range(10)), 3), list)

# Generated at 2022-06-21 16:50:44.404249
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    # Check that class ``Random()`` inherits from class ``random.Random()``.
    assert issubclass(Random, random_module.Random)

    # Check that class ``Random()`` has own method ``__init__()``.
    assert hasattr(Random, '__init__')

    # Check that class ``Random()`` has own method ``randints()``.
    assert hasattr(Random, 'randints')

    # Check that class ``Random()`` has own method ``urandom()``.
    assert hasattr(Random, 'urandom')

    # Check that class ``Random()`` has own method ``generate_string()``.
    assert hasattr(Random, 'generate_string')

    # Check that class ``Random()`` has own method ``custom_code()``.
   

# Generated at 2022-06-21 16:50:46.345900
# Unit test for function get_random_item
def test_get_random_item():
    import enum

    class Enum(enum.Enum):
        x = 0
        y = 1
        z = 2

    rnd = Random()
    assert get_random_item(Enum, rnd) in Enum

# Generated at 2022-06-21 16:50:48.321106
# Unit test for method urandom of class Random
def test_Random_urandom():
    random = Random()
    assert isinstance(random.urandom(10), bytes) is True

# Generated at 2022-06-21 16:50:50.335708
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random_ = random_module.Random()
    string = random_.generate_string('qwertyuiopasdfghjklzxcvbnm', 3)
    assert isinstance(string, str)
    assert len(string) == 3


# Generated at 2022-06-21 16:50:53.699726
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    s = Random(1234).generate_string(string.ascii_letters, 5)
    assert s == 'BpIqJ'



# Generated at 2022-06-21 16:50:54.654656
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(Random().generate_string(
            string.ascii_letters), str)



# Generated at 2022-06-21 16:51:03.458072
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    assert random.custom_code() == "B123"
    assert random.custom_code(mask='##ABC') == "11ABC"
    assert random.custom_code(mask='ABC') == "ABC"
    assert random.custom_code(mask='@###') == "B123"
    assert random.custom_code(mask='@###', char='@', digit='#') == "B123"
    assert random.custom_code(mask='@###', char='#', digit='@') == "8123"
    assert random.custom_code(mask='@###', char='@', digit='@') == "B123"
    assert random.custom_code(mask='1@@@', char='1', digit='@') == "1234"

# Generated at 2022-06-21 16:51:07.480143
# Unit test for constructor of class Random
def test_Random():
    # We use only one test here to test the functionality of all methods
    # at once. All of this methods was checked for the correct work
    # using the unit-tests of the module mimesis.enums.
    rnd = Random()
    for x in range(10000):
        assert isinstance(rnd.randstr(), str)

# Generated at 2022-06-21 16:51:11.578866
# Unit test for method randints of class Random
def test_Random_randints():
    v = random.randints(5)
    assert len(v) == 5
    assert v[0] >= 1 and v[0] <= 100
    assert v[1] >= 1 and v[1] <= 100
    assert v[2] >= 1 and v[2] <= 100
    assert v[3] >= 1 and v[3] <= 100
    assert v[4] >= 1 and v[4] <= 100

