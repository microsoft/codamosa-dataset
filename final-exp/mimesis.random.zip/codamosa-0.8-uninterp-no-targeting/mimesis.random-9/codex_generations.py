

# Generated at 2022-06-21 16:44:35.823058
# Unit test for method uniform of class Random
def test_Random_uniform():
    result = random.uniform(1, 5)
    assert result >= 1
    assert result <= 5

# Generated at 2022-06-21 16:44:37.524000
# Unit test for method uniform of class Random
def test_Random_uniform():
    import pytest
    random = Random()
    assert random.uniform(5,5) == 5.0

# Generated at 2022-06-21 16:44:42.826644
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Random.custom_code() test."""
    # Test
    random.seed(1)
    assert random.custom_code() == 'P827'
    assert random.custom_code('@###') == 'H702'
    assert random.custom_code('@@###') == 'PL827'
    assert random.custom_code('@@###', '@') == 'TJ827'
    assert random.custom_code('@@###', '@', '#') == 'PL827'
    assert random.custom_code('@@###', digit='#', char='@') == 'PL827'
    assert random.custom_code(char='@', digit='#') == 'PL827'
    assert random.custom_code(digit='#', char='@') == 'TL827'
    assert random.custom_code

# Generated at 2022-06-21 16:44:51.284448
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()

    # test with odd and even amount, with minimum and maximum value
    result1 = rnd.randints(amount=10, a=2, b=20)
    assert len(result1) == 10
    result2 = rnd.randints(amount=12, a=3, b=30)
    assert len(result2) == 12
    result3 = rnd.randints(amount=11, a=4, b=40)
    assert len(result3) == 11

    # test that the exception is raised when the amount is less or equal to zero
    assert len(rnd.randints()) == 3

# Generated at 2022-06-21 16:44:59.896742
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    # Calling the function with parameters that fit in the requirements.
    result = Random.custom_code('@###', '@', '#')
    assert result == 'B254' or result == 'A887' or result == 'C111' or result == 'M225' or result == 'O659' or \
           result == 'F334' or result == 'Y666' or result == 'C788' or result == 'K845' or result == 'L453' or \
           result == 'Z122' or result == 'P445' or result == 'W555' or result == 'L234'

    # Calling the function with parameters that do not match the requirements.

# Generated at 2022-06-21 16:45:02.267217
# Unit test for method randstr of class Random
def test_Random_randstr():
    value = ''.join(random.choices(string.hexdigits, k=32))
    assert random.randstr() == value
    # TODO: Remove this, when fixed in uuid4
    # assert random.randstr(unique=True) != value



# Generated at 2022-06-21 16:45:04.591965
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)
    assert isinstance(r, random_module.Random)


# Generated at 2022-06-21 16:45:09.565679
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert (32 <= len(Random().randstr()) <= 128)
    assert len(Random().randstr(length=32)) == 32
    assert len(Random().randstr(length=128)) == 128
    assert len(Random().randstr(length=0)) == 0

# Generated at 2022-06-21 16:45:11.366120
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(random.generate_string(str_seq='6', length=6), str)


# Generated at 2022-06-21 16:45:12.792241
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random.urandom(), bytes)



# Generated at 2022-06-21 16:45:17.644534
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(Random().randints(), list)
    assert not Random().randints()
    assert isinstance(Random().randints(amount=1), list)
    assert isinstance(Random().randints(amount=0), list)
    assert len(Random().randints(amount=100)) == 100



# Generated at 2022-06-21 16:45:18.524081
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom()

# Generated at 2022-06-21 16:45:24.145559
# Unit test for function get_random_item
def test_get_random_item():
    """Test for function get_random_item()."""
    from mimesis.enums import Gender
    rnd_int = random.randint(1, 10)
    assert isinstance(get_random_item(Gender), Gender) == True
    assert isinstance(get_random_item(Gender, rnd=random), Gender) == True
    assert isinstance(get_random_item(Gender, rnd=rnd_int), Gender) == False
    assert isinstance(get_random_item(Gender, rnd=None), Gender) == True

# Generated at 2022-06-21 16:45:29.029005
# Unit test for constructor of class Random
def test_Random():
    random_ = Random()
    assert isinstance(random_, random_module.Random)
    assert isinstance(random_, Random)
    assert isinstance(random_, random_module.Random)

# Generated at 2022-06-21 16:45:29.981925
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Add tests here
    pass

# Generated at 2022-06-21 16:45:33.617487
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method Random.custom_code."""
    assert random.custom_code() == random.custom_code()
    assert random.custom_code() != random.custom_code()
    assert random.custom_code(mask='@###-@###') != random.custom_code(mask='@###-@###')

# Generated at 2022-06-21 16:45:42.968112
# Unit test for function get_random_item
def test_get_random_item():
    """Test function get_random_item."""
    class _Nums(int, enum.IntEnum):
        ONE = 1
        TWO = 2
        THREE = 3

    class _Strings(str, enum.Enum):
        ONE = 'one'
        TWO = 'two'
        THREE = 'three'

    _nums_list = list(_Nums)
    _strings_list = list(_Strings)

    assert get_random_item(_Nums) in _nums_list
    assert get_random_item(_Strings) in _strings_list
    assert get_random_item(_Nums, rnd=random) in _nums_list
    assert get_random_item(_Strings, rnd=random) in _strings_list

# Generated at 2022-06-21 16:45:44.283889
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###', '@', '#') in ('F22T', 'J3S3', 'S3S2')

# Generated at 2022-06-21 16:45:46.055192
# Unit test for method urandom of class Random
def test_Random_urandom():
    random_bytes = Random(2).urandom(16)
    assert isinstance(random_bytes, bytes)
    assert len(random_bytes) == 16

# Generated at 2022-06-21 16:45:51.338765
# Unit test for function get_random_item
def test_get_random_item():
    # Note: We used old Random class as it was before (after v1.0)
    import enum
    import random as random_module

    class Currency(enum.Enum):
        """Enumeration for currencies."""
        RUB = 'RUB'
        USD = 'USD'
        EUR = 'EUR'
        JPY = 'JPY'
        GBP = 'GBP'

    random_module.seed(42)
    random.seed(42)
    assert random.get_random_item(Currency) == Currency.RUB
    assert random.get_random_item(Currency) == Currency.JPY

# Generated at 2022-06-21 16:45:58.506153
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    rand = Random()
    assert rand.uniform(0.2, 0.4, precision=7) in [0.2, 0.4]
    assert rand.uniform(0.2, 0.4, precision=15) in [0.20000000000000001, 0.4]

# Generated at 2022-06-21 16:46:02.381971
# Unit test for constructor of class Random
def test_Random():
    """Test constructor of class Random."""
    r = Random()
    assert isinstance(r, Random)
    assert isinstance(r, random_module.Random)



# Generated at 2022-06-21 16:46:11.410356
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd1 = Random()
    code1 = rnd1.custom_code()  # default
    code2 = rnd1.custom_code('@@@@@@')
    assert len(code1) == len(code2) == 6
    code3 = rnd1.custom_code('@@##')
    assert len(code3) == 4
    code4 = rnd1.custom_code('@*#', '@', '#')
    assert len(code4) == 3

    # use placeholder with the same code
    rnd = Random()
    code = rnd.custom_code('@@@', '@', '@')
    assert len(code) == 3

    # mask with spaces
    rnd = Random()
    code = rnd.custom_code('@ @@@')
    assert len(code) == 5
    code

# Generated at 2022-06-21 16:46:21.039898
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    # basic case
    assert r.custom_code('@###')
    assert r.custom_code('@@##')
    assert r.custom_code('@@@')
    # only digits
    assert r.custom_code('#')
    assert r.custom_code('##')
    assert r.custom_code('###')
    # only letters
    assert r.custom_code('@')
    assert r.custom_code('@@')
    assert r.custom_code('@@@')
    # digits and letters
    assert r.custom_code('@##')
    assert r.custom_code('@###')
    assert r.custom_code('@@#')
    assert r.custom_code('@@##')
    assert r.custom_code('###')

# Generated at 2022-06-21 16:46:24.479632
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string('1234567890')) == 10
    assert len(Random().generate_string('1234567890', 20)) == 20



# Generated at 2022-06-21 16:46:30.101503
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    n = 2
    mask = '1234567890'
    print('\n' + '-' * 20 + 'Unit test for method generate_string of class Random' + '-' * 20)
    for i in range(n):
        print('{} -> {}'.format(i+1, random.generate_string(mask)))
    print('-' * 70)



# Generated at 2022-06-21 16:46:31.637271
# Unit test for method randints of class Random
def test_Random_randints():
    test_list = Random().randints(5)
    assert len(test_list) == 5


# Generated at 2022-06-21 16:46:33.018581
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test Random.urandom()"""
    assert Random().urandom(1)


# Generated at 2022-06-21 16:46:37.625918
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for ``Random().randints()``.

    :return: True
    """
    rnd = Random()
    assert isinstance(rnd.randints(amount=1), list)
    assert isinstance(rnd.randints(amount=1)[0], int)
    assert len(rnd.randints(amount=5)) == 5
    return True



# Generated at 2022-06-21 16:46:42.274398
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    rand_object = Random()
    rand_object.randstr(unique=False) == rand_object.randstr(unique=False)


if __name__ == '__main__':
    test_Random_randstr()