

# Generated at 2022-06-21 16:44:40.253528
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    str_seq = 'a'
    s = Random().generate_string(str_seq)
    len = len(s)
    assert len == 10, f'It should be equal 10. Current value: {len}'
    str_seq = 'A'
    s = Random().generate_string(str_seq)
    len = len(s)
    assert len == 10, f'It should be equal 10. Current value: {len}'
    str_seq = '123'
    s = Random().generate_string(str_seq)
    len = len(s)
    assert len == 10, f'It should be equal 10. Current value: {len}'
    str_seq = 'aA'
    s = Random().generate_string(str_seq)
    len = len(s)

# Generated at 2022-06-21 16:44:44.608617
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    assert round(r.uniform(1, 1.1), 2) == 1.00
    assert round(r.uniform(1.00, 1.01), 2) == 1.00
    assert round(r.uniform(0, 1), 2) == 0.49
    assert round(r.uniform(0, 1.1, 3), 3) == 0.947
    assert round(r.uniform(1.5, 1.5), 2) == 1.50
    assert round(r.uniform(1.5, 1.6), 2) == 1.59

# Generated at 2022-06-21 16:44:46.238512
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Check
    random_instance = random.Random()
    assert random_instance.custom_code(mask='###') == '###'


# Generated at 2022-06-21 16:44:51.596342
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(Random().randstr()) == 32
    assert len(Random().randstr(True)) == 32
    assert len(Random().randstr(length=32)) == 32
    assert len(Random().randstr(length=128)) == 128
    assert len(Random().randstr(False, 128)) == 128



# Generated at 2022-06-21 16:44:55.147319
# Unit test for method randstr of class Random
def test_Random_randstr():
    from mimesis.providers.text import Text
    text_provider = Text()
    length = 32
    randstr = random.randstr(length=length)
    assert len(randstr) == length
    assert randstr == text_provider.string(length)

# Generated at 2022-06-21 16:44:56.710057
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test method urandom of class Random."""
    assert isinstance(Random().urandom(), bytes)

# Generated at 2022-06-21 16:44:58.127695
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert rnd.uniform(10, 15) >= 10
    assert rnd.uniform(10, 15) < 15
    assert rnd.uniform(10, 15) > 11

# Generated at 2022-06-21 16:45:03.306653
# Unit test for function get_random_item
def test_get_random_item():
    import dataclasses
    import datetime
    import enum
    import uuid

    @dataclasses.dataclass
    class DateTimeData:
        value: datetime.datetime

    @dataclasses.dataclass
    class UUIDData:
        value: uuid.UUID

    assert get_random_item(DateTimeData)
    assert get_random_item(UUIDData)
    assert get_random_item(enum.IntEnum)

# Generated at 2022-06-21 16:45:14.353437
# Unit test for constructor of class Random
def test_Random():
    assert len(Random().randints(amount=10, a=0, b=10)) == 10
    assert len(Random().randints(amount=1, a=0, b=1)) == 1
    assert len(Random().randints(amount=100, a=1, b=10)) == 100
    assert len(Random().randints(amount=10000, a=0, b=1)) == 10000
    assert len(Random().randints(amount=0, a=0, b=1)) == 0
    assert len(Random().randints(amount=-1, a=0, b=1)) == 0
    assert len(Random().randints(amount=-10, a=0, b=1)) == 0
    assert len(Random().randints(amount=None, a=0, b=1)) == 3

# Generated at 2022-06-21 16:45:16.933329
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    data = Random.urandom(10)
    assert len(data) == 10
    assert isinstance(data, bytes)



# Generated at 2022-06-21 16:45:27.369281
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    for i in range(10):
        code = random.custom_code()
        assert code
        assert type(code).__name__ == 'str'
        print('Code:', code)

        code = random.custom_code(mask='@@#', char='@', digit='#')
        assert code
        assert type(code).__name__ == 'str'
        print('Code:', code)

        code = random.custom_code(mask='@####', char='@', digit='#')
        assert code
        assert type(code).__name__ == 'str'
        print('Code:', code)

        code = random.custom_code(mask='@@###', char='@', digit='#')
        assert code
        assert type(code).__name__ == 'str'

# Generated at 2022-06-21 16:45:34.887174
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for ``Random.randstr()`` method."""

    rnd = Random()
    assert len(rnd.randstr()) == 16
    assert len(rnd.randstr(length=16)) == 16
    assert len(rnd.randstr(length=60)) == 60
    assert len(rnd.randstr(unique=True)) == 32
    assert len(rnd.randstr(unique=True, length=32)) == 64
    assert len(rnd.randstr(unique=True, length=64)) == 128
    assert rnd.randstr(unique=True) != rnd.randstr(unique=True)

# Generated at 2022-06-21 16:45:37.566161
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0, 0.8) != 0.0

# Generated at 2022-06-21 16:45:38.877379
# Unit test for function get_random_item
def test_get_random_item():
    assert str(get_random_item(random.randstr))

# Generated at 2022-06-21 16:45:44.729001
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()

    # For all random numbers.
    for _ in range(100):
        # Default precision is 15.
        assert isinstance(random.uniform(0, 10), float)
        # Custom precision.
        assert isinstance(random.uniform(0, 10, 2), float)

    # The precision is less than zero
    for _ in range(-1, 0):
        with pytest.raises(ValueError):
            random.uniform(0, 10, _)

    # The precision is greater than or equal 15.
    for _ in range(15, 100):
        with pytest.raises(ValueError):
            random.uniform(0, 10, _)

# Generated at 2022-06-21 16:45:45.872446
# Unit test for method urandom of class Random
def test_Random_urandom():
    data = random.urandom(4)
    assert len(data) == 4

# Generated at 2022-06-21 16:45:47.547687
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string(
        '0123456789abcdefghijklmnopqrstuvwxyz') is not None

# Generated at 2022-06-21 16:45:52.968754
# Unit test for method randstr of class Random
def test_Random_randstr():
    list_str_unique = list()
    for _ in range(100):
        random_str = random.randstr(unique=True, length=10)
        if random_str in list_str_unique:
            raise ValueError('Value is not unique')
        list_str_unique.append(random_str)

    list_str_not_unique = list()
    for _ in range(100):
        random_str = random.randstr(unique=False, length=10)
        if random_str in list_str_not_unique:
            continue
        list_str_not_unique.append(random_str)
    if len(list_str_not_unique) != 100:
        raise ValueError('Value is not unique')

# Generated at 2022-06-21 16:45:58.337366
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###')
    assert len(random.custom_code('@###')) == 4
    assert random.custom_code('@###', char='a', digit='b')
    assert random.custom_code('@###', char='#', digit='@') == random.custom_code('@###')



# Generated at 2022-06-21 16:46:04.313116
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    amount = r.randint(2, 100)
    a = r.randint(1, 100)
    b = r.randint(a + 1, 200)
    lst = r.randints(amount, a, b)
    for i in lst:
        assert a <= i < b
    assert len(lst) == amount



# Generated at 2022-06-21 16:46:12.676819
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random.urandom(10)) == 10
    assert len(Random.urandom(10)) == 10

# Generated at 2022-06-21 16:46:15.750228
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random().urandom(1), bytes)
    assert len(Random().urandom(1)) == 1
    assert len(Random().urandom(10)) == 10

# Generated at 2022-06-21 16:46:17.907500
# Unit test for function get_random_item
def test_get_random_item():
    enum = set([(1, 2), (3, 4), (5, 6)])
    random_item = get_random_item(enum)
    assert random_item in enum

# Generated at 2022-06-21 16:46:22.653847
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.schema import Field

    # Check the function get_random_item with custom object random
    f = Field('en', rnd=Random())
    assert isinstance(f.get_random_item()['name'], str)

    # Check the function get_random_item with default object random
    f = Field('en')
    assert isinstance(f.get_random_item()['name'], str)

# Generated at 2022-06-21 16:46:24.074821
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random().urandom(4), bytes)

# Generated at 2022-06-21 16:46:26.518330
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)
    assert isinstance(random.randints(), list)



# Generated at 2022-06-21 16:46:29.405652
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test the method generate_string of class Random."""
    result = Random().generate_string(string.digits, 3)
    assert len(result) == 3
    assert result.isdigit()



# Generated at 2022-06-21 16:46:31.529550
# Unit test for method randints of class Random
def test_Random_randints():
    random = Random()
    assert len(random.randints(10)) == 10



# Generated at 2022-06-21 16:46:32.658538
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    assert Random().custom_code() == 'A###', "Custom code test failed"

# Generated at 2022-06-21 16:46:39.135418
# Unit test for function get_random_item
def test_get_random_item():

    if 'get_random_item' in globals():
        from enum import Enum

        class Lang(Enum):
            EN = 'en'
            UA = 'ua'
            RU = 'ru'

        rnd = Random()
        rnd.seed(42)
        langs = ('en', 'ua', 'ru')

        lang_ = get_random_item(Lang)
        assert isinstance(lang_, Lang)
        assert lang_.value in langs

        lang_ = get_random_item(Lang, rnd)
        assert isinstance(lang_, Lang)
        assert lang_.value in langs

# Generated at 2022-06-21 16:46:58.725617
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Arrange
    rnd = Random()
    str_seq = string.ascii_lowercase + string.digits + '@#$%'
    length = 10

    # Act
    result = rnd.generate_string(str_seq, length)

    # Assert
    assert all(map(lambda x: x in str_seq, result))
    assert len(result) == length



# Generated at 2022-06-21 16:47:00.909743
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), str)

# Generated at 2022-06-21 16:47:01.694510
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert isinstance(rnd, Random)



# Generated at 2022-06-21 16:47:10.479804
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert rnd.uniform(-1.0, 1.0) < 1.0
    assert rnd.uniform(-1.0, 1.0) > -1.0
    assert rnd.uniform(-1.0, 1.0, precision=3) < 1.0
    assert rnd.uniform(-1.0, 1.0, precision=3) > -1.0
    assert rnd.uniform(0, 1.0, precision=3) < 1.0
    assert rnd.uniform(0, 1.0, precision=3) > 0
    assert rnd.uniform(0, 1.0, precision=0) == 0 or rnd.uniform(0, 1.0, precision=0) == 1

__all__.append('test_Random_uniform')

# Generated at 2022-06-21 16:47:11.456089
# Unit test for constructor of class Random
def test_Random():
    randomized = Random()
    assert type(randomized) == Random


# Generated at 2022-06-21 16:47:21.648073
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random(1)
    print(r.custom_code(mask='@###', char='@', digit='#'))
    print(r.custom_code(mask='@@###', char='@', digit='#'))
    print(r.custom_code(mask='###', char='#', digit='@'))
    print(r.custom_code(mask='#####', char='#', digit='@'))
    print(r.custom_code(mask='@@@@@@', char='@', digit='#'))
    print(r.custom_code(mask='@@@@@@@', char='@', digit='#'))
    print(r.custom_code(mask='@@@@@@@', char='@', digit='@'))


if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-21 16:47:25.030590
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    str = random.generate_string(string.ascii_letters, 3)
    assert len(str) == 3
    for char in str:
        assert char in string.ascii_letters

# Generated at 2022-06-21 16:47:31.701343
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints()) == 3
    assert len(random.randints(amount=10)) == 10
    assert len(random.randints(amount=2, a=5, b=10)) == 2
    assert random.randints(amount=5, a=-1, b=1)[0] <= 1
    assert random.randints(amount=5, a=-1, b=1)[0] >= -1
    try:
        random.randints(amount=0)
    except ValueError as e:
        pass
    else:
        assert False



# Generated at 2022-06-21 16:47:40.650454
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Test 1
    _Random = Random()
    result = _Random.custom_code()
    assert len(result) == 4
    assert result[0] in string.ascii_uppercase
    assert result[1:].isdigit()

    # Test 2
    result = _Random.custom_code('@@@1')
    assert len(result) == 4
    assert result[0] in string.ascii_uppercase
    assert result[1:].isdigit()

    # Test 3
    result = _Random.custom_code('AA11')
    assert len(result) == 4
    assert result[0] in string.ascii_uppercase
    assert result[1:].isdigit()

    # Test 4
    result = _Random.custom_code('1AAA11')
    assert len

# Generated at 2022-06-21 16:47:45.847415
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    from mimesis.schema import Field, Schema, create_schema

    enum = ['one', 'two', 'three']
    schema = create_schema('test', [Field('one', value='one'),
                                    Field('two', value='two'),
                                    Field('three', value='three')])
    for _ in range(100):
        assert get_random_item(enum) in enum
        assert get_random_item(schema._fields) in schema._fields