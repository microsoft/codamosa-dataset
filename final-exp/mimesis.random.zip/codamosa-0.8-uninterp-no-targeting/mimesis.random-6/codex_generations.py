

# Generated at 2022-06-21 16:44:45.004556
# Unit test for method randints of class Random
def test_Random_randints():
    random = Random()
    random_list = random.randints(3, 1, 100)
    assert len(random_list) == 3
    random_list = random.randints(3, 1, 100)
    assert isinstance(random_list, list)

# Generated at 2022-06-21 16:44:46.609406
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.data import Gender

    gender = get_random_item(Gender)
    assert gender in Gender, 'Generated item is not in enum object'

# Generated at 2022-06-21 16:44:50.341087
# Unit test for method uniform of class Random
def test_Random_uniform():
    rand = Random()
    num_of_digits = rand.uniform(1.1, 2, 1)
    assert 0 < num_of_digits < 2.2

# Generated at 2022-06-21 16:44:55.878658
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random.

    :return: None.
    :rtype: None.
    """
    rnd = Random()
    value = rnd.randstr(unique=True)
    assert isinstance(value, str)
    assert len(value) == 32

    value = rnd.randstr(length=64)
    assert isinstance(value, str)
    assert len(value) == 64

# Generated at 2022-06-21 16:44:58.720550
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    num_test = 10
    length = 100

    # Check that strings generated with different strings
    # of different length are not the same
    for _ in range(num_test):
        rnd = Random()
        a = rnd.generate_string(string.digits, length)
        b = rnd.generate_string(string.ascii_letters, length)
        assert a != b


# Generated at 2022-06-21 16:45:01.043809
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import UserAgentType
    from mimesis.enums import Gender

    get_random_item(Gender)
    get_random_item(UserAgentType)

# Generated at 2022-06-21 16:45:02.392709
# Unit test for method uniform of class Random
def test_Random_uniform():
    x = random.uniform(0.6, 0.6)
    assert x >= 0.6 and x <= 0.6

# Generated at 2022-06-21 16:45:13.646161
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    assert random.custom_code(char='A', digit='B') != random.custom_code(char='A', digit='B')
    assert random.custom_code(char='A', digit='B') != random.custom_code(char='A', digit='B')
    assert random.custom_code(char='A', digit='B') != random.custom_code(char='A', digit='B')
    assert random.custom_code(char='A', digit='B') != random.custom_code(char='A', digit='B')
    assert random.custom_code(char='A', digit='B') != random.custom_code(char='A', digit='B')
    assert random.custom_code(char='A', digit='B') != random.custom_code(char='A', digit='B')
   

# Generated at 2022-06-21 16:45:18.927524
# Unit test for method randints of class Random
def test_Random_randints():
    from hypothesis import given
    from hypothesis.strategies import integers, lists

    @given(lists(integers(min_value=0, max_value=100),
                min_size=1, max_size=100))
    def test_randints(num_list):
        rnd = Random()
        lst = rnd.randints(len(num_list))
        for i in lst:
            assert 0 <= i <= 100
            assert i in num_list

    test_randints()

# Generated at 2022-06-21 16:45:20.033234
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(random.PATTERN, random)

# Generated at 2022-06-21 16:45:37.961726
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    import random
    r = random.Random()
    assert r.custom_code('@###', '@', '#') != r.custom_code('@###', '@', '#')
    assert r.custom_code('@###', '@', '#') != r.custom_code('@###', '@', '#')
    assert r.custom_code('@###', '@', '#') != r.custom_code('@###', '@', '#')
    assert r.custom_code('@###', '@', '#') != r.custom_code('@###', '@', '#')
    assert r.custom_code('@###', '@', '#') != r.custom_code('@###', '@', '#')
    assert r.custom_code('@###', '@', '#')

# Generated at 2022-06-21 16:45:38.538891
# Unit test for function get_random_item
def test_get_random_item():
    pass

# Generated at 2022-06-21 16:45:41.541259
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test Random class."""
    a = random.uniform(0.1, 0.3)
    assert 0.1 <= a <= 0.3


if __name__ == '__main__':
    test_Random_uniform()

# Generated at 2022-06-21 16:45:45.179804
# Unit test for method urandom of class Random
def test_Random_urandom():
    isinstance(Random.urandom(), bytes)
    eq_(len(Random.urandom(1, )), 1)

# Generated at 2022-06-21 16:45:48.631306
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    r.seed(1)
    rand_ints = r.randints(5)
    assert rand_ints == [83, 82, 99, 65, 66]
    rand_ints = r.randints(5, 0, 0)
    assert rand_ints == [0, 0, 0, 0, 0]



# Generated at 2022-06-21 16:45:50.697567
# Unit test for function get_random_item
def test_get_random_item():
    class Foo:
        pass

    assert Foo() == get_random_item([Foo()])

# Generated at 2022-06-21 16:45:59.799029
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = Random(seed=42)  # seed=42 to keep test stable
    # if unique=False
    value = r.randstr(unique=False)
    assert (value == '=' or value == 'Z')
    # if unique=True
    value = r.randstr(unique=True)
    assert value == '8a4c4f4e12bb4f019188470d5175d9b1'
    # if length is set
    value = r.randstr(length=250)
    assert (value == '9bdv' or len(value) == 250)
    # if unique=True and length is set
    value = r.randstr(unique=True, length=250)
    assert value == '8a4c4f4e12bb4f019188470d5175d9b1'

# Generated at 2022-06-21 16:46:02.221827
# Unit test for method randstr of class Random
def test_Random_randstr():
    import os
    print(os.urandom(24))

if __name__ == '__main__':
    test_Random_randstr()

# Generated at 2022-06-21 16:46:04.061050
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code(mask='@##',
                         char='@',
                         digit='#') == 'ASD'

# Generated at 2022-06-21 16:46:12.359060
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from mimesis.data import CodeData
    from mimesis.enums import Gender

    rnd = Random()
    mask = '@###'
    char = '@'
    digit = '#'
    code = rnd.custom_code(mask, char, digit)
    assert code.isupper()
    assert len(code) == len(mask)
    code = rnd.custom_code(mask, digit, char)
    assert code.isdigit()
    assert len(code) == len(mask)
    code = rnd.custom_code(mask, char, char)
    assert code.isupper()
    assert len(code) == len(mask)
    code = rnd.custom_code(mask, digit, digit)
    assert code.isdigit()