

# Generated at 2022-06-21 16:44:41.484404
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    for _i in range(100):
        n = r.uniform(1.2, 3.4)
        assert n > 1.2
        assert n < 3.4

# Generated at 2022-06-21 16:44:45.905542
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    rand = Random()
    try:
        rand.uniform(0.5, 0.5)
    except ValueError:
        pass
    else:
        raise ValueError('Method uniform works incorrectly.')
    try:
        rand.uniform(0.5, 0.4)
    except ValueError:
        pass
    else:
        raise ValueError('Method uniform works incorrectly.')

# Generated at 2022-06-21 16:44:54.891009
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test custom method ``urandom()`` from the class Random.

    .. note:: For invocation the method ``urandom()`` in the class ``Random()``
       is used the same parameters as in the standard method
       ``os.urandom()``. You can read more about this method in the
       following link:
       https://docs.python.org/3/library/os.html#os.urandom
    """
    r = Random()
    result = [r.urandom(i) for i in range(1, 100)]
    assert len(result) == 99
    assert result[-1] == os.urandom(99)



# Generated at 2022-06-21 16:44:58.274170
# Unit test for constructor of class Random
def test_Random():
    """Unit-test for constructor of class Random"""
    seed = random.randint(0, 1000)
    rnd = Random(seed)
    rnd2 = Random(seed)
    assert rnd.uniform(0, 1) == rnd2.uniform(0, 1)

# Generated at 2022-06-21 16:45:00.234017
# Unit test for function get_random_item
def test_get_random_item():
    """Get random item of enum object."""
    from mimesis.enums import Gender

    gender = get_random_item(Gender)
    assert isinstance(gender, Gender)

# Generated at 2022-06-21 16:45:01.418752
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    assert len(rnd.randstr()) in range(16, 129)

# Generated at 2022-06-21 16:45:02.730392
# Unit test for method randints of class Random
def test_Random_randints():
    r = random.randints()
    assert isinstance(r, list)
    assert len(r) == 3



# Generated at 2022-06-21 16:45:03.902635
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == '@123'

# Generated at 2022-06-21 16:45:08.363877
# Unit test for method randints of class Random
def test_Random_randints():
    test_amount = 10
    test_min = 1
    test_max = 10
    assert all(
        i >= test_min and i <= test_max
        for i in random.randints(test_amount, test_min, test_max))



# Generated at 2022-06-21 16:45:17.173268
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    r.seed(123)
    random_numbers = [r.uniform(a = 0, b = 1) for i in range(10)]
    assert random_numbers == [
        0.5426498944232452,
        0.5426498944232452,
        0.9079463870036763,
        0.5426498944232452,
        0.8107187843119651,
        0.8107187843119651,
        0.8107187843119651,
        0.9079463870036763,
        0.9079463870036763,
        0.8107187843119651
    ]

# Generated at 2022-06-21 16:45:21.111803
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(random.PROVIDERS, random) in random.PROVIDERS

# Generated at 2022-06-21 16:45:24.339837
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """
    Test method ``custom_code`` of class ``Random()``.

    """
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4



# Generated at 2022-06-21 16:45:32.404996
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    s = ''.join(map(lambda i: chr(65 + i), range(26)))
    for i in range(100):
        assert len(random.generate_string(s)) == 10
        assert len(random.generate_string(s, 100)) == 100
        assert len(random.generate_string(s, 5)) == 5
        assert len(random.generate_string(s, 1)) == 1
        assert len(random.generate_string(s, 2)) == 2

# Generated at 2022-06-21 16:45:38.277027
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    for i in range(10):
        with pytest.raises(TypeError):
            random.uniform(1, 11.5, None)
    res = random.uniform(2, 3, None)
    assert res > 2.0 and res < 3.0
    res = random.uniform(5, 5, None)
    assert res == 5.0

# Generated at 2022-06-21 16:45:45.281183
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for the possibility of generating a custom code."""
    # For example, we need to generate a code that
    # consists of a random 2-digit integer, a random letter,
    # another random letter, and again a random 2-digit integer.
    r = Random()
    code = r.custom_code('##@##')
    assert len(code) == 6
    assert ''.join(code.split(code[2])).isdigit()
    assert code[2].isalpha()

    for _ in range(100):
        code = r.custom_code('##@##')
        assert len(code) == 6
        assert ''.join(code.split(code[2])).isdigit()
        assert code[2].isalpha()

    # For example, we need to generate a code that
    # consists of a random

# Generated at 2022-06-21 16:45:50.232988
# Unit test for method randstr of class Random
def test_Random_randstr():
    cases = [
        '9f85217e318e4875b5c5f5ffd8c3fb53',
        'd0e9e9cf3a3c4f189b0c2b2f197b05bc',
        '0bc9873c1ba345fa9a94c2f43b716cca',
        'd739a4c4eb4f4f88b9a9e3c3a3f3c728'
    ]
    assert random.randstr(unique=True) in cases

# Generated at 2022-06-21 16:45:58.570936
# Unit test for method uniform of class Random
def test_Random_uniform():
    def randfloat(a: float, b: float) -> float:
        return Random().uniform(a, b)
    for _ in range(10000):
        assert 0.1 <= randfloat(0.1, 1.0) <= 1.0
        assert 0 <= randfloat(0.0, 1.0) <= 1.0
        assert 0 <= randfloat(0.0, 1.1) <= 1.1
        assert 1.0 <= randfloat(1.0, 1.1) <= 1.1
        assert 1.0 <= randfloat(1.0, 2.0) <= 2.0
        assert 1 <= randfloat(1, 2) <= 2


# Generated at 2022-06-21 16:46:02.702620
# Unit test for method uniform of class Random
def test_Random_uniform():
    # Create random object
    rnd = Random()

    # Test on one random value
    assert 0 < rnd.uniform(0.01, 0.04) < 0.04



# Generated at 2022-06-21 16:46:06.115981
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item().
    """

    from .personal import Gender

    enum = Gender
    rnd = Random()
    result = get_random_item(enum, rnd)

    assert result in enum.__members__.values()

# Generated at 2022-06-21 16:46:08.403637
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    gender = get_random_item(Gender)
    assert gender in [i.name for i in Gender]

# Generated at 2022-06-21 16:46:15.613226
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Generate the sequence of letters and digits
    str_seq = string.ascii_letters + string.digits

    # Generate random string created from string sequence
    print("Random string: ", random.generate_string(str_seq, 20))


# Generated at 2022-06-21 16:46:18.791625
# Unit test for constructor of class Random
def test_Random():
    r1 = random.Random()
    r2 = random_module.Random()
    for _ in range(10):
        assert type(r1.random()) == type(r2.random())
        assert r1.random() == r2.random()



# Generated at 2022-06-21 16:46:21.344526
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    result = Random().generate_string('abc', 8)
    assert len(result) == 8
    assert result.count('a') + result.count('b') + result.count('c') == 8

# Generated at 2022-06-21 16:46:23.456998
# Unit test for method uniform of class Random
def test_Random_uniform():
    t = Random()
    x = t.uniform(1.0, 10.0)
    assert type(x) == float
    assert x >= 1.0 and x < 10.0


# Generated at 2022-06-21 16:46:32.873142
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # The equality of the expected result and the mask is passed.
    assert random.custom_code("Test mask") == "Test mask"
    # The mask does not contain the placeholders for characters or numbers.
    assert random.custom_code("TEST MASK") != "TEST MASK"
    # The length and the range of the expected result are passed.
    assert len(random.custom_code("####")) == 4
    assert int(random.custom_code("####")) <= 9999
    # The placeholders for characters and digits are the same.
    assert random.custom_code("@###", "@", "@") == "@@@@"
    assert random.custom_code("#@@@", "@", "@") == "@@@@"

# Generated at 2022-06-21 16:46:35.786457
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0.1, 1.1) >= 0.1
    assert random.uniform(0.1, 1.1) < 1.1

# Generated at 2022-06-21 16:46:36.602626
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)


# Generated at 2022-06-21 16:46:49.188570
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints of class Random."""

    # --|Test cases for values
    assert len(random.randints()) == 3
    assert len(random.randints(amount=1, a=2, b=4)) == 1
    assert len(random.randints(amount=10, a=0, b=100)) == 10
    assert len(random.randints(amount=100, a=2 ** 32, b=2 ** 64)) == 100

    # ---|Test case for an error
    try:
        random.randints(-1)
    except ValueError:
        pass
    else:
        raise AssertionError()



# Generated at 2022-06-21 16:46:50.573419
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert get_random_item(Gender) in Gender



# Generated at 2022-06-21 16:46:54.440956
# Unit test for method randints of class Random
def test_Random_randints():
    """Check if method `randints` of class `Random()` works correctly.
    """
    lst = Random().randints(amount=5, a=1, b=10)
    assert isinstance(lst, list)
    assert len(lst) == 5
    assert all(x >= 1 and x <= 10 for x in lst)

# Generated at 2022-06-21 16:47:04.087401
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random.

    Unit test for method uniform of class Random.
    In the method we call the method uniform for the random and
    for the random_module.random and compare the results.
    """
    assert random.uniform(1, 2, 15) == random_module.uniform(1, 2)

# Generated at 2022-06-21 16:47:08.893699
# Unit test for method uniform of class Random
def test_Random_uniform():
    value = random.uniform(0.99, 2.13, 2)
    assert value >= 0.99
    assert value <= 2.13
    assert type(value) is float
    assert value.is_integer() is False
    for i in range(1000):
        value = round(value, 2)
        assert value >= 0.99
        assert value <= 2.13
        assert type(value) is float
        assert value.is_integer() is False

# Generated at 2022-06-21 16:47:11.998494
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Arrange
    rnd = Random()
    
    # Act
    result = rnd.randstr()

    # Assert
    assert result is not None
    assert len(result) == 32
    assert isinstance(result, str)
    assert result[:8] == 'd0b8a5f5'

# Generated at 2022-06-21 16:47:14.563417
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() != Random().custom_code()

# Generated at 2022-06-21 16:47:25.029950
# Unit test for method uniform of class Random
def test_Random_uniform():
    example = [
        (1, 10, 15),
        (0.2, 1.2, 15),
        (0.2, 1.2, None),
        (0.2, 1.2, 1),
        (0.2, 1.2, 2),
        (0.2, 1.2, 3),
        (0.2, 1.2, 4),
        (0.2, 1.2, 5)
    ]

# Generated at 2022-06-21 16:47:29.436789
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test method ``urandom`` of class ``Random``"""
    random = Random()

    for _ in range(10):
        rnd = random.urandom(10)
        assert len(rnd) == 10

    for _ in range(10):
        rnd = random.urandom()
        assert len(rnd) == 32



# Generated at 2022-06-21 16:47:30.993269
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)
    assert random is Random()
    assert Random() is Random()

# Generated at 2022-06-21 16:47:34.945649
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method ``custom_code()`` of class ``Random()``."""
    r = Random()
    code = r.custom_code(mask='@@@###@@')
    # print(code)
    assert len(code) == 8
    assert code[:3].isalpha() and code[3:7].isdigit() and code[7].isalpha()



# Generated at 2022-06-21 16:47:36.549233
# Unit test for method urandom of class Random
def test_Random_urandom():
    ran = Random()
    assert isinstance(ran.urandom(10), bytes)


# Generated at 2022-06-21 16:47:38.800423
# Unit test for method uniform of class Random
def test_Random_uniform():
    number = 10.05

    r = Random()
    fake_float = r.uniform(10, 10.06)

    assert number == fake_float