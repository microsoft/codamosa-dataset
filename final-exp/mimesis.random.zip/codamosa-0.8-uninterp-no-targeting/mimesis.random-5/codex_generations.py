

# Generated at 2022-06-21 16:44:53.510458
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(Random.generate_string('ASDFG'), str)
    assert isinstance(Random.generate_string('ASDFG', 5), str)


# Generated at 2022-06-21 16:44:57.676506
# Unit test for method uniform of class Random
def test_Random_uniform():
    from statistics import mean, stdev, variance
    samples = [random.uniform(0, 1) for _ in range(1000)]
    assert mean(samples) == 0.5
    print("Standard deviation of samples : ", round(stdev(samples),3))
    print("Variance of samples : ", round(variance(samples),3))
    
    

# Generated at 2022-06-21 16:44:59.116578
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender

    _ = get_random_item(Gender)
    assert _ in Gender

# Generated at 2022-06-21 16:45:00.757381
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    expected = 'CYt7'
    actual = random.custom_code()
    assert actual, expected



# Generated at 2022-06-21 16:45:02.671292
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    result = Random().custom_code(mask='@####', char='@', digit='#')
    assert len(result) == 5
    assert result.isalnum()



# Generated at 2022-06-21 16:45:05.489664
# Unit test for method randstr of class Random
def test_Random_randstr():
    strings = [random.randstr() for _ in range(1_000)]

    assert len(strings) == len(set(strings))

# Generated at 2022-06-21 16:45:07.463812
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    r = Random(10, 20)
    r = Random(10)

# Generated at 2022-06-21 16:45:10.355283
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    item = get_random_item(Gender)
    assert isinstance(item, Gender)

# Generated at 2022-06-21 16:45:17.321062
# Unit test for function get_random_item
def test_get_random_item():
    """Test for function get_random_item."""
    class SomeEnum(object):
        """Just for getting random item."""
        def __init__(self, **enums):
            """Initialize an enum."""
            self.__dict__.update(enums)

    # Get random item using custom random
    _ = get_random_item(  # noqa
        SomeEnum(a='a', b='b', c='c'),
        Random(),
    )

    # Get random item using standard random
    _ = get_random_item(SomeEnum(a='a', b='b', c='c'))  # noqa

# Generated at 2022-06-21 16:45:24.869010
# Unit test for function get_random_item
def test_get_random_item():
    import unittest
    import tests

    class RandomTests(unittest.TestCase):

        @classmethod
        def setUpClass(cls):
            cls.random = Random()

        def test_randstr(self):
            """Test for function ``randstr()``."""
            size = self.random.randint(16, 128)
            result = self.random.randstr(length=size)
            self.assertEqual(len(result), size)
            self.assertIsInstance(result, str)

            # test for unique=True
            result = self.random.randstr(unique=True)
            self.assertEqual(len(result), 32)
            self.assertIsInstance(result, str)

    unittest.main(tests)

# Generated at 2022-06-21 16:45:44.535839
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method generate_code_1 with default value."""
    def test_case(rnd: Random, mask: str, char: str, digit: str, min_: int, max_: int) -> None:
        code_ = rnd.custom_code(mask, char, digit)
        assert len(code_) == len(mask)
        for symbol in code_:
            if char in mask:
                assert symbol.isalpha()
            if digit in mask:
                assert symbol.isdigit()

    for _ in range(100):
        rnd = Random(123)
        test_case(rnd, '@###', '@', '#', 0, 9)
        test_case(rnd, '###@', '@', '#', 0, 9)

# Generated at 2022-06-21 16:45:51.577549
# Unit test for method uniform of class Random
def test_Random_uniform():
    from mimesis.enums import Format

    assert random.uniform(a=0.1, b=0.4, precision=4) == 0.1254
    assert random.uniform(a=-365, b=2780, precision=4) == -121.4
    assert random.uniform(a=0.2, b=0.4, precision=4) == 0.2036
    assert random.uniform(a=0.01, b=0.3, precision=4) == 0.0424
    assert random.uniform(a=0.1, b=0.2, precision=4) == 0.1648
    assert random.uniform(a=1, b=5, precision=4) == 2.8566
    assert random.uniform(a=33, b=42, precision=4) == 37

# Generated at 2022-06-21 16:45:52.767317
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert isinstance(random.uniform(1.0, 2.0), float)

# Generated at 2022-06-21 16:46:01.687198
# Unit test for method randstr of class Random
def test_Random_randstr():
    pass
    # import unittest
    # class Test(unittest.TestCase):
    #
    #     def setUp(self):
    #         self.obj = Random()
    #
    #     def test_uniqueness(self):
    #         unique_string_values = set()
    #         for _ in range(100):
    #             unique_string = self.obj.randstr(unique=True)
    #             # Check that each random string is unique
    #             self.assertNotIn(unique_string, unique_string_values)
    #             # Add generated value to set
    #             unique_string_values.add(unique_string)
    #
    #     def test_not_uniqueness(self):
    #         length = 64
    #
    #         not_unique_string_values =

# Generated at 2022-06-21 16:46:06.088557
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    rnd.seed(5)
    result_1 = rnd.custom_code(mask='@###')
    result_2 = rnd.custom_code(mask='@###')
    assert result_1 == 'KJE7'
    assert result_2 == 'MSA0'

# Generated at 2022-06-21 16:46:08.717078
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Given random object
    # When method urandom is called
    # Then we get bytes object
    assert isinstance(Random().urandom(10), bytes)



# Generated at 2022-06-21 16:46:10.987410
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    for _ in range(100):
        assert rnd.uniform(1, 5, 3) in [round(x, 3) for x in range(1, 6, 1)]

# Generated at 2022-06-21 16:46:19.753877
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    rnd = Random()
    lst = rnd.randints(amount=10, a=1, b=100)
    assert isinstance(lst, list)
    assert len(lst) <= 10
    assert lst == sorted(lst)
    assert lst[0] >= 1
    assert lst[9] < 100

    assert rnd.randints(amount=-1, a=1, b=100) == []
    assert rnd.randints(amount=0, a=1, b=100) == []
    assert rnd.randints(amount=None, a=1, b=100) == []



# Generated at 2022-06-21 16:46:22.911870
# Unit test for method uniform of class Random
def test_Random_uniform():
    """
    Check if the method uniform of class Random
    can return valid random float.
    """
    rnd = Random()
    result = rnd.uniform(0, 5, precision=1)
    assert result >= 0.0
    assert result < 5.0
    assert isinstance(result, float)

# Generated at 2022-06-21 16:46:28.270391
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for method urandom of class Random."""
    rnd = Random()
    assert len(rnd.urandom(3)) == 3
    assert len(rnd.urandom(2)) == 2
    assert len(rnd.urandom(1)) == 1
    assert len(rnd.urandom(0)) == 0
