

# Generated at 2022-06-21 16:48:26.833795
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(16)

# Generated at 2022-06-21 16:48:30.649471
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test method for custom code.

    Also, it shows how to correctly use this method.
    """
    r = Random()
    for item in range(100):
        mask = '#X#X#X#X'
        char = 'X'
        digit = '#'
        value = r.custom_code(mask=mask, char=char, digit=digit)
        assert isinstance(value, str)
        assert len(value) == len(mask)
        assert char in value
        assert digit in value
        assert [item.isalpha() for item in value]
        assert [item.isdigit() for item in value]


# Generated at 2022-06-21 16:48:32.551529
# Unit test for function get_random_item
def test_get_random_item():
    class BasicEnum(object):
        FIRST = 1
        SECOND = 2

    assert random.choice([BasicEnum.FIRST, BasicEnum.SECOND]) == get_random_item(BasicEnum)

# Generated at 2022-06-21 16:48:35.570052
# Unit test for method randints of class Random
def test_Random_randints():
    # Test global random
    # Expected value: [66, 76, 59]
    print(random.randints(amount=3, a=1, b=100))



# Generated at 2022-06-21 16:48:45.922038
# Unit test for method uniform of class Random
def test_Random_uniform():
    random_module.seed('mimesis')
    random_module.uniform(0.38, 0.40)
    random_module.uniform(0.38, 0.40)
    random_module.uniform(0.38, 0.40)
    random_module.uniform(0.38, 0.40)
    random_module.uniform(0.38, 0.40)
    random_module.uniform(0.38, 0.40)
    random_module.uniform(0.38, 0.40)
    random_module.uniform(0.38, 0.40)
    random_module.uniform(0.38, 0.40)
    random_module.uniform(0.38, 0.40)

    random = Random('mimesis')

# Generated at 2022-06-21 16:48:47.980783
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints(1, 1, 100)) == 1
    assert random.randints(1, 1, 100)[0] in range(1, 100)

# Generated at 2022-06-21 16:48:51.749837
# Unit test for method randints of class Random
def test_Random_randints():
    """Test ``randints`` of class ``Random``."""
    random_ = Random()
    random_.seed(42)
    length = random_.randint(1, 100)
    min_ = random_.randint(1, 10)
    max_ = random_.randint(100, 1000)

    assert len(random_.randints(length, min_, max_)) == length
    assert isinstance(random_.randints(length, min_, max_), list)



# Generated at 2022-06-21 16:48:56.791110
# Unit test for method randints of class Random
def test_Random_randints():
    amount = 10
    min_value = 10
    max_value = 100
    test_result = True
    for _ in range(amount):
        result = random.randints(min_value, max_value)
        if not (min_value <= result < max_value):
            test_result = False

    assert test_result


# Generated at 2022-06-21 16:48:58.728854
# Unit test for constructor of class Random
def test_Random():
    _ = Random()

# Generated at 2022-06-21 16:49:02.994710
# Unit test for method randints of class Random
def test_Random_randints():
    print(random.randints(5))  # >>> [2, 2, 8, 1, 7]
    print(random.randints(4, 10, 15))  # >>> [11, 14, 10, 11]

