

# Generated at 2022-06-21 16:45:42.426920
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    class Test(enum.Enum):
        a = 1
        b = 2
        c = 6
    rnd = Random()
    result = get_random_item(Test, rnd)
    assert (result == Test.a or
            result == Test.b or
            result == Test.c)

# Generated at 2022-06-21 16:45:46.138809
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    assert rnd.generate_string('qwertyuiop', 10)
    assert rnd.generate_string('1234567890', 10)



# Generated at 2022-06-21 16:45:50.093110
# Unit test for function get_random_item
def test_get_random_item():
    class Example(object):
        A = 'a'
        B = 'b'
        C = 'c'
        D = 'd'
        E = 'e'

    item = get_random_item(Example)
    assert (item == Example.A or
            item == Example.B or
            item == Example.C or
            item == Example.D or
            item == Example.E)



# Generated at 2022-06-21 16:45:57.965662
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = random_module.Random(random_module.random())
    assert (Random.uniform(rnd, 1.0, 2.0, precision = 10) ==
            round(random_module.uniform(1.0, 2.0), 10))
    assert (Random.uniform(rnd, 1.0, 2.0, precision = 1) ==
            round(random_module.uniform(1.0, 2.0), 1))
    assert (Random.uniform(rnd, 1.0, 2.0, precision = 15) ==
            random_module.uniform(1.0, 2.0))

# Generated at 2022-06-21 16:46:00.830932
# Unit test for constructor of class Random
def test_Random():
    _ = Random()
    assert _ is not None


# Generated at 2022-06-21 16:46:10.585768
# Unit test for method uniform of class Random
def test_Random_uniform():
    import pytest

    rnd = Random()

    def check_result(a, b):
        result = rnd.uniform(a, b)
        assert result >= a
        assert result < b

    check_result(1, 1.1)
    check_result(1.01, 1.02)
    check_result(1.001, 1.002)
    check_result(1.0001, 1.0002)
    check_result(1.0001, 1.0003)
    check_result(1.0001, 1.0004)
    check_result(1.0001, 1.0006)
    check_result(1.0001, 1.0009)
    check_result(1.0001, 1.0011)
    check_result(1.0001, 1.0019)


# Generated at 2022-06-21 16:46:12.490741
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(-5) == []
    assert isinstance(Random().randints(), list)



# Generated at 2022-06-21 16:46:14.312515
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)

# Unit tests for the method Random.randints()

# Generated at 2022-06-21 16:46:16.699886
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    tmp = []
    for _ in range(100):
        tmp.append(random.generate_string(
            string.ascii_letters + string.digits, 10))
    assert len(tmp) == 100


# Generated at 2022-06-21 16:46:18.674438
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    r.seed(123)
    assert r.random() == 0.6964691855978616

