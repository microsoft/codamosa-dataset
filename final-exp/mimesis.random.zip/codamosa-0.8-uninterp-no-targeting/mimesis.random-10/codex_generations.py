

# Generated at 2022-06-21 16:44:45.199919
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3



# Generated at 2022-06-21 16:44:51.596835
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    from enum import Enum

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    assert random.choice(list(Color)) == get_random_item(Color, random)


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-21 16:44:53.432340
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(8)
    assert Random.urandom(8) != Random.urandom(8)

# Generated at 2022-06-21 16:45:01.241619
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code.
    """
    from random import Random

    r = Random()
    code = r.custom_code()
    assert len(code) == 4
    assert code[0].isalpha()
    assert all(map(str.isdigit, code[1:]))

    symbol = '$'
    code = r.custom_code(mask='$#', char=symbol)
    assert len(code) == 2
    assert code[0] == symbol
    assert code[1].isdigit()

    code = r.custom_code(char='&', digit='%', mask='&&&&%&&%')
    assert code.count('&') == 6
    assert code.count('%') == 2
    for s in code:
        if s != '&':
            assert s != '%'

# Generated at 2022-06-21 16:45:02.958477
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of class Random."""
    rnd = random.uniform(1, 2, 1)
    assert 1 < rnd < 2

# Generated at 2022-06-21 16:45:07.658643
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    import pytest
    from mimesis.exceptions import NonEnumerableError
    from mimesis.enums import Gender
    rnd = Random()
    with pytest.raises(NonEnumerableError):
        rnd.generate_string(Gender.MALE)

# Generated at 2022-06-21 16:45:10.864967
# Unit test for method randstr of class Random
def test_Random_randstr():
    for i in range(10):
        print(random.randstr(unique=True))

    for i in range(10):
        print(random.randstr(unique=False))

# Generated at 2022-06-21 16:45:14.869564
# Unit test for function get_random_item
def test_get_random_item():
    class EnumTest:
        ONE = 'ONE'
        TWO = 'TWO'
        THREE = 'THREE'

    enum_value = get_random_item(enum=EnumTest)
    assert enum_value in EnumTest.__dict__.values()


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-21 16:45:19.040733
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test for method randstr of class Random.

    This method was created for the ability to run unit test in IDEA.

    """
    from unittest import TestCase
    from unittest.mock import patch

    class TestCustomRandom(TestCase):
        """Test for Random class methods."""

        @patch.object(Random, '__init__', return_value=None)
        def test_get_random_string(self, _):
            """Test for `get_random_string()` method."""
            rnd = Random()
            rand_string = rnd.randstr()

            self.assertIsInstance(rand_string, str)
            self.assertGreater(len(rand_string), 0)

    TestCase.main()

# Generated at 2022-06-21 16:45:20.446410
# Unit test for method urandom of class Random
def test_Random_urandom():
    _random = Random()
    assert _random.urandom(16) == os.urandom(16)