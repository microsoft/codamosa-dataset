

# Generated at 2022-06-21 16:45:30.125192
# Unit test for constructor of class Random
def test_Random():
    assert Random()

# Generated at 2022-06-21 16:45:31.881151
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    string = random.generate_string('')
    assert isinstance(string, str)


# Generated at 2022-06-21 16:45:42.259944
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    random = Random()  # type: Random

    assert isinstance(random.randints(), list)
    assert isinstance(random.urandom(3), bytes)
    assert isinstance(random.urandom(3).hex(), str)
    assert isinstance(random.urandom(3).decode(), str)
    assert isinstance(random.uniform(1, 10), (int, float))
    assert isinstance(random.custom_code(), str)
    assert isinstance(random.generate_string(string.digits), str)
    assert isinstance(random.randstr(), str)
    assert isinstance(random.randstr(True), str)
    assert isinstance(random.randstr(False), str)
    assert isinstance(random.randstr(False, 16), str)

# Generated at 2022-06-21 16:45:44.482560
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(), bytes)

# Generated at 2022-06-21 16:45:51.516759
# Unit test for method randstr of class Random
def test_Random_randstr():
    from io import StringIO
    from unittest import TestCase, main

    rnd = Random()

    class TestCase(TestCase):
        def test_random_str(self):
            result = rnd.randstr()
            self.assertIsInstance(result, str)

        def test_unique_random_str(self):
            result_list = [rnd.randstr(unique=True) for _ in range(10000)]
            self.assertEqual(len(set(result_list)), 10000)

        def test_random_str_length(self):
            a = rnd.randint(16, 128)
            result = rnd.randstr(length=a)
            self.assertEqual(len(result), a)


# Generated at 2022-06-21 16:45:56.134313
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    assert rnd.generate_string('abc') in rnd.choice('abc')
    assert rnd.generate_string('!@#$%^&*()', 2) in rnd.choice('!@#$%^&*()')

# Generated at 2022-06-21 16:46:01.048434
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random
    """

    for _ in range(20):
        assert random.uniform(10, 100) <= 100
        assert random.uniform(10, 100) >= 10

test_Random_uniform()

# Generated at 2022-06-21 16:46:02.818071
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(0) == []
    assert Random().randints(1, 10, 20)[0] in range(10, 20)
    assert len(Random().randints(10, 10, 20)) == 10



# Generated at 2022-06-21 16:46:04.340736
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)
    assert isinstance(random, random_module.Random)

# Generated at 2022-06-21 16:46:06.889796
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(1):
        print(Random().custom_code())


# Generated at 2022-06-21 16:46:49.188649
# Unit test for method urandom of class Random
def test_Random_urandom():
    # given
    expected = os.urandom(2)

    # when
    result = Random().urandom(2)

    # then
    assert result == expected

# Generated at 2022-06-21 16:46:51.655821
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(Random().randstr(length=15), str)
    assert len(Random().randstr(length=15)) == 15
    assert len(Random().randstr()) >= 16
    assert len(Random().randstr()) <= 128
    assert isinsta

# Generated at 2022-06-21 16:46:53.440702
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    item = get_random_item(Gender)
    assert item in Gender.__members__.values()



# Generated at 2022-06-21 16:46:55.524926
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random, type)
    assert isinstance(Random(), Random)



# Generated at 2022-06-21 16:46:58.887761
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _random = Random()
    _res = _random.custom_code(mask='@@###@@', char='@', digit='#')
    assert isinstance(_res, str)
    assert len(_res) == 8
    assert all(i.isalpha() or i.isdigit()
               for i in _res)


# Generated at 2022-06-21 16:47:05.232272
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    a = 1.1
    b = 1.5
    precision = 2
    result = rnd.uniform(a, b, precision)
    assert result >= a and result <= b, (result, a, b)
    assert len(str(result).split('.')[-1]) <= precision + 1
    result = rnd.uniform(b, a, precision)
    assert result >= a and result <= b, (result, a, b)
    assert len(str(result).split('.')[-1]) <= precision + 1

# Generated at 2022-06-21 16:47:08.050610
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Check that length of urandom is equal to 16 bytes
    assert len(random.urandom(16)) == 16
    # Check that length of urandom is equal to 16 bytes
    assert not len(random.urandom(16)) == 20


# Generated at 2022-06-21 16:47:11.222261
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test method randstr of class Random."""
    rnd = random_module.Random()
    uniq_rnd = Random()
    assert len(rnd.randstr()) == len(uniq_rnd.randstr())

# Generated at 2022-06-21 16:47:17.166344
# Unit test for constructor of class Random
def test_Random():
    assert Random()
    assert Random(1)
    assert Random(None)
    assert Random(os.urandom(64))
    assert Random(random.urandom(64))
    assert Random.Random()
    assert Random.Random(1)
    assert Random.Random(None)
    assert Random.Random(os.urandom(64))
    assert Random.Random(random.urandom(64))



# Generated at 2022-06-21 16:47:18.036275
# Unit test for constructor of class Random
def test_Random():
    assert Random is not None
    assert Random() is not None