

# Generated at 2022-06-25 21:17:24.759535
# Unit test for constructor of class Random
def test_Random():
    random_0 = Random()


# Generated at 2022-06-25 21:17:29.479304
# Unit test for constructor of class Random
def test_Random():
    seed = 1234
    rnd = Random(seed)
    assert rnd.random() == 0.9664535356921388



# Generated at 2022-06-25 21:17:30.830126
# Unit test for constructor of class Random
def test_Random():
    random_1 = Random()


# Generated at 2022-06-25 21:17:36.528934
# Unit test for method custom_code of class Random
def test_Random_custom_code():


    # Define the class
    Random = random_module.Random

    # Initialize Random object
    r = Random()
    r2 = Random()
    assert(r.custom_code() in [r2.custom_code()])



# Generated at 2022-06-25 21:17:39.344037
# Unit test for constructor of class Random
def test_Random():
    random_0 = Random(1)
    assert isinstance(random_0, Random) is True
    random_1 = Random(1)
    assert random_0 == random_1


# Generated at 2022-06-25 21:17:42.556982
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_0.custom_code(mask="@###", char="@", digit="#")


# Generated at 2022-06-25 21:17:44.960288
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() is not None

# Generated at 2022-06-25 21:17:48.351678
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code.isupper()
    assert code.isalnum()


# Generated at 2022-06-25 21:17:53.480283
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Testing the method custom_code of class Random with the following inputs:
    # ['@###', '@', '#']. Expected output: "string"
    assert isinstance(random.custom_code(), str)



# Generated at 2022-06-25 21:18:02.849144
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    number_of_tests = 0
    number_of_passed = 0
    number_of_failed = 0
    passed_tests = list()
    failed_tests = list()

    # Test #1
    try:
        number_of_tests += 1
        input_mask = '@@'
        input_char = '@'
        input_digit = '#'
        expected_answer = '@@'
        answer = Random().custom_code(mask=input_mask, char=input_char, digit=input_digit)
        if answer == expected_answer:
            number_of_passed += 1
            passed_tests.append(1)
        else:
            number_of_failed += 1
            failed_tests.append(1)
    except Exception:
        answer = 10
        number_of_failed += 1
       

# Generated at 2022-06-25 21:18:11.094976
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert isinstance(random.custom_code(), str)
    assert isinstance(random.custom_code(mask='@#'), str)
    assert isinstance(random.custom_code(mask='@@#@@#@@#@@#@@#@@#'), str)
    assert len(random.custom_code(mask='@@#@@#@@#@@#@@#@@#')) == 32


# Generated at 2022-06-25 21:18:21.749016
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()

    assert random_0.custom_code() == '7Q2Q'
    assert random_0.custom_code(mask='@@@') == 'ZZC'
    assert random_0.custom_code(mask='###') == '427'
    assert random_0.custom_code('@@@') == 'SAE'
    assert random_0.custom_code('@###') == 'M487'
    assert random_0.custom_code('@###', '@', '#') == 'C463'
    assert random_0.custom_code('####') == '8671'
    assert random_0.custom_code('####') == '6616'
    assert random_0.custom_code('@@') == 'NP'
    assert random_0.custom_code('@@') == 'CI'


# Generated at 2022-06-25 21:18:24.035731
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code(mask='@###',
                           char='@',
                           digit='#')
    pass

# Generated at 2022-06-25 21:18:27.334927
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    r.random = lambda: 2
    print(r.custom_code('@###','@','#'))


# Generated at 2022-06-25 21:18:29.901677
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    result = random_0.custom_code("@###")
    assert isinstance(result, str)


# Generated at 2022-06-25 21:18:40.966065
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test case for custom_code
    """
    random_0 = Random()
    random_0.custom_code()
    random_0.custom_code()
    random_0.custom_code()
    random_0.custom_code()
    random_0.custom_code()
    random_0.custom_code()
    random_0.custom_code()
    random_0.custom_code()
    random_0.custom_code()
    random_0.custom_code()


# Generated at 2022-06-25 21:18:47.089472
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    custom_code = random.custom_code("@###")
    assert len(custom_code) == 4
    assert custom_code[0].islower()
    assert custom_code[1:].isdigit()


# Generated at 2022-06-25 21:18:50.132888
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_3 = Random()
    res = random_3.custom_code()
    assert isinstance(res, str)



# Generated at 2022-06-25 21:18:58.580442
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_0.custom_code()

    random_1 = Random()
    random_1.custom_code('@###')
    random_1.custom_code('@###', '@', '#')

    try:
        random_1.custom_code('@###', '@', '@')
    except ValueError as e:
        assert isinstance(e.__str__(), str)


# Generated at 2022-06-25 21:19:03.223420
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    res = random.custom_code(mask='@###', char='@', digit='#')
    assert len(res) == 4 and res.isupper()
    res = random.custom_code(mask='@###', char='@', digit='@')
    assert res == random.custom_code(mask='@###', char='@', digit='@')