

# Generated at 2022-06-25 21:17:17.310208
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = '@###-###'
    char = '@'
    digit = '#'
    random_0 = Random()
    random_0.seed(0)
    code = random_0.custom_code(mask, char, digit)
    assert code == 'QKDZ-TSFL'


# Generated at 2022-06-25 21:17:29.095711
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    c = Random()

    mask = 'A@###'
    char = '@'
    digit = '#'
    test_0 = c.custom_code(mask, char, digit)
    assert isinstance(test_0, str)

    char_code = ord(char)
    digit_code = ord(digit)
    if char_code == digit_code:
        raise ValueError('You cannot use the same '
                         'placeholder for digits and chars!')

    _mask = mask.encode()
    code = bytearray(len(_mask))
    for i, p in enumerate(_mask):
        if p == char_code:
            a = c.randint(65, 91)  # A-Z
        elif p == digit_code:
            a = c.randint(48, 58)  #

# Generated at 2022-06-25 21:17:40.765588
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    a = Random()
    random_0 = Random()
    random_0.seed(0)
    random_1 = Random()
    random_1.seed(0)
    random_2 = Random()
    random_2.seed(0)
    random_3 = Random()
    random_3.seed(0)
    random_4 = Random()
    random_4.seed(0)
    random_5 = Random()
    random_5.seed(0)
    random_6 = Random()
    random_6.seed(0)
    random_7 = Random()
    random_7.seed(0)
    random_8 = Random()
    random_8.seed(0)
    random_9 = Random()
    random_9.seed(0)
    random_10 = Random()

# Generated at 2022-06-25 21:17:46.413400
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code"""
    random_1 = Random()
    mask = "@#"
    char = "#"
    digits = "$"
    code = random_1.custom_code(mask, char, digits)
    assert isinstance(code, str)


# Generated at 2022-06-25 21:17:48.247606
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert random_0.custom_code() == "B578"


# Generated at 2022-06-25 21:17:52.335521
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    str_seq_0 = random_0.custom_code()
    assert len(str_seq_0) == 5



# Generated at 2022-06-25 21:18:00.174472
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###')
    assert random.custom_code(mask= '@@##')
    assert random.custom_code(mask= '@@##', char= '@')
    assert random.custom_code(mask= '@@##', char= '@', digit= '#')
    assert random.custom_code(mask= '@@##', char= '@', digit= '#')
    assert random.custom_code(mask= '@@##', char= '@', digit= '#')


# Generated at 2022-06-25 21:18:06.654073
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()
    random_1.custom_code()
    random_1.custom_code(mask='@###')
    random_1.custom_code(mask='@###', char='@')
    random_1.custom_code(mask='@###', char='@', digit='#')


# Generated at 2022-06-25 21:18:10.372550
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = '##-###-####'  # mask of code
    char = '#'  # placeholder for characters
    digit = '-'  # placeholder for digits
    random_0 = Random()
    result = random_0.custom_code(mask, char, digit)
    assert isinstance(result, str)


# Generated at 2022-06-25 21:18:19.214661
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_0.seed(0)
    assert random_0.custom_code('@###', '@', '#') == 'GKBS'
    assert random_0.custom_code() == 'LKGQ'
    assert random_0.custom_code() == 'LKGQ'
    assert random_0.custom_code('@@@@', '@', '#') == 'LKGQLKGQ'
