

# Generated at 2022-06-25 21:16:51.849776
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rand0 = Random()
    rand1 = Random()
    rand0.custom_code(mask='@###', char='@', digit='#')
    rand1.custom_code(mask='@###', char='@', digit='#')



# Generated at 2022-06-25 21:16:56.049328
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert random_0.custom_code('@###', '@', '#') == 'L039'
    assert random_0.custom_code('@###', '@', '#') == 'L039'

# Generated at 2022-06-25 21:17:05.282543
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_0.seed(857);
    str_0 = random_0.custom_code('###')
    assert str_0 == 'RUM', "Random.custom_code failed"
    str_1 = random_0.custom_code('###', '#', '@')
    assert str_1 == 'HU@', "Random.custom_code failed"
    str_2 = random_0.custom_code('#')
    assert str_2 == 'C', "Random.custom_code failed"
    str_3 = random_0.custom_code('@@@')
    assert str_3 == 'RXV', "Random.custom_code failed"
    str_4 = random_0.custom_code('@@@', '@', '#')

# Generated at 2022-06-25 21:17:11.668157
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random(1546559802)
    c = random_0.custom_code(mask = '###', char = 'A', digit = 'A')
    assert c == '827'
    c = random_0.custom_code(mask = '@@@#', char = '@', digit = '#')
    assert c == ' UNV'
    c = random_0.custom_code(mask = '@@@##', char = '@', digit = '#')
    assert c == 'QZOP9'
    c = random_0.custom_code(mask = '@@@###', char = '@', digit = '#')
    assert c == 'DRKM42'
    c = random_0.custom_code(mask = '@@@####', char = '@', digit = '#')

# Generated at 2022-06-25 21:17:18.614506
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    int_0 = random_0.randint(1, 5)
    int_1 = random_0.randint(1, 5)
    while (int_0 == int_1):
        int_1 = random_0.randint(1, 5)
    str_0 = random_0.custom_code(int_0, int_1)
    assert(len(str_0) == 5)


# Generated at 2022-06-25 21:17:22.317215
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    str_0 = random_0.custom_code()
    assert len(str_0) is 4


# Generated at 2022-06-25 21:17:28.055699
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() in ['3HK3', '3QL6', 'XLY5', '6DQ2', 'LQGZ', '6ZRB', '59Q2', 'RPDW', 'XPRT', 'N3GG', 'RW3N', 'Z8L3'], "custom_code method of class Random works incorrectly"


# Generated at 2022-06-25 21:17:32.408705
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    str_0 = random_0.custom_code('', '', '', '', '', '')
    assert str_0 is not None


# Generated at 2022-06-25 21:17:35.246415
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    custom_code_0 = random_0.custom_code()



# Generated at 2022-06-25 21:17:38.933866
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    mask = '@###'
    char = '@'
    digit = '#'
    str_0 = rnd.custom_code(mask, char, digit)
