

# Generated at 2022-06-25 21:16:57.712947
# Unit test for function get_random_item
def test_get_random_item():
    # noinspection PyUnresolvedReferences
    from mimesis.enums import Gender, Profession, Language
    from mimesis.builtins import Equipment

    # Python 3.5
    if hasattr(Profession, 'AUTHOR'):
        profession_item = get_random_item(Profession)
        assert profession_item in list(Profession)

        # Python 3.7+
        gender_item = get_random_item(Gender)
        assert gender_item in list(Gender)

        # Python 3.7+
        language_item = get_random_item(Language)
        assert language_item in list(Language)

    equipment_item = get_random_item(Equipment)
    assert equipment_item in list(Equipment)



# Generated at 2022-06-25 21:16:58.542148
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_1 = Random(4)



# Generated at 2022-06-25 21:17:09.552321
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(1):
        _mask = ''
        _char = ''
        _digit = ''
        try:
            random.custom_code(_mask=_mask, _char=_char, _digit=_digit)
        except ValueError:
            pass
        _mask = ''
        _char = ''
        _digit = ''
        random.custom_code(_mask=_mask, _char=_char, _digit=_digit)
        _mask = ''
        _char = ''
        _digit = ''
        random.custom_code(_mask=_mask, _char=_char, _digit=_digit)
        _mask = ''
        _char = ''
        _digit = ''
        random.custom_code(_mask=_mask, _char=_char, _digit=_digit)



# Generated at 2022-06-25 21:17:17.237552
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    result = rnd.custom_code(mask='@###', char='@', digit='#')
    result = result.upper()
    try:
        int(result[1:])
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-25 21:17:19.234621
# Unit test for function get_random_item
def test_get_random_item():
    get_random_item(enum=None)



# Generated at 2022-06-25 21:17:22.389936
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis import Person

    p = Person()
    print(get_random_item(Person.Gender))

# Generated at 2022-06-25 21:17:30.425917
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Case 0
    random_0 = Random()
    mask_0 = '@###'
    char_0 = '@'
    digit_0 = '#'
    rnd_0 = random_0.custom_code(mask_0, char_0, digit_0)
    assert len(rnd_0) == 4

    # Case 1
    random_1 = Random()
    mask_1 = '@@@@###'
    char_1 = '@'
    digit_1 = '#'
    rnd_1 = random_1.custom_code(mask_1, char_1, digit_1)
    assert len(rnd_1) == 7

    # Case 2
    random_2 = Random()
    mask_2 = '@@####@@##'
    char_2 = '@'
    digit_

# Generated at 2022-06-25 21:17:34.291176
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random_module), int)
    assert isinstance(get_random_item(random_module, Random()), int)


# Generated at 2022-06-25 21:17:39.697582
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    from random import choice
    gen = choice(list(Gender))
    gen1 = random.choice(list(Gender))
    gen2 = get_random_item(Gender)
    gen3 = get_random_item(Gender, Random())
    assert gen == gen1 == gen2 == gen3


# Generated at 2022-06-25 21:17:42.358398
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Currencies
    assert isinstance(get_random_item(Currencies), Currencies)