

# Generated at 2022-06-25 21:16:52.936184
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # For test
    random_0 = Random()

    # Get basic mask
    res_0 = random_0.custom_code()

    assert res_0 in random_0.custom_code.__annotations__.values()



# Generated at 2022-06-25 21:17:01.913154
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Check for the custom code."""
    code = Random().custom_code()
    code_1 = Random().custom_code('a###-c##')
    code_2 = Random().custom_code(char='a', digit='c')
    code_3 = Random().custom_code(length=12)
    assert len(code) == 4
    assert len(code_1) == 8
    assert len(code_2) == 4
    assert len(code_3) == 12
    assert len(Random().custom_code(mask='aaa')) == 3



# Generated at 2022-06-25 21:17:10.775206
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()
    random_2 = Random()
    random_3 = Random()
    random_3.seed()
    random_4 = Random()
    random_4.seed(value=1234)
    random_5 = Random()
    random_5.seed(1234)
    random_6 = Random()
    random_6.seed(1234.5)
    random_7 = Random()
    random_7.seed(b'\x1e\x1d\xad\xf0\x6f\xfd\x90\x85e\x02\xc1')
    random_8 = Random()

# Generated at 2022-06-25 21:17:13.467455
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()
    assert random_1.custom_code()



# Generated at 2022-06-25 21:17:19.273185
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    # str
    res = random_0.custom_code()
    assert len(res) == 5
    assert type(res) is str

    res = random_0.custom_code('@@@###')
    assert len(res) == 7

    res = random_0.custom_code('@#####@', '^', '*')
    assert res == '^75722^'


# Generated at 2022-06-25 21:17:29.765104
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Test 1
    random_1 = Random()
    random_1.custom_code('####', '', '#')
    
    # Test 2
    random_2 = Random()
    random_2.custom_code('##', '', '#')
    
    # Test 3
    random_3 = Random()
    random_3.custom_code('##', '', '@')
    
    # Test 4
    random_4 = Random()
    random_4.custom_code('@@', '', '#')
    
    # Test 5
    random_5 = Random()
    random_5.custom_code('###', '', '@')
    
    # Test 6
    random_6 = Random()
    random_6.custom_code('###', '', '#')
    
    # Test 7
    random

# Generated at 2022-06-25 21:17:34.157255
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()
    result = random_1.custom_code(mask='@###', char='@', digit='#')
    assert isinstance(result, str)


# Generated at 2022-06-25 21:17:38.636109
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    custom_code_expected_result = '@###'
    assert Random.custom_code(
        mask='@###') == custom_code_expected_result, 'Invalid result for custom_code function'


# Generated at 2022-06-25 21:17:49.298380
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    "Check the implementation of method custom_code."

    random_0 = Random()
    random_1 = Random()
    random_2 = Random()

    assert random_0.custom_code() != random_1.custom_code()
    assert random_0.custom_code() != random_2.custom_code()

    assert random_1.custom_code() != random_0.custom_code()
    assert random_1.custom_code() != random_2.custom_code()

    assert random_2.custom_code() != random_0.custom_code()
    assert random_2.custom_code() != random_1.custom_code()



# Generated at 2022-06-25 21:17:53.150204
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    mask = random.custom_code()
    assert len(mask) == 4, 'Method CustomCode() of class Random returns wrong result.'


# Generated at 2022-06-25 21:18:03.490430
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    def test_equal(sample_size: int = 1000) -> None:
        """Test equal length.

        :param sample_size: Size of generated samples.
        """
        result = []
        expected = []
 
        # Generate samples of random custom codes
        for _ in range(sample_size):
            result.append(random_0.custom_code())
            expected.append(random_0.custom_code())

        # Check length of generated samples
        for i in range(sample_size):
            assert len(result[i]) == len(expected[i])

        # Check that samples are different
        for i in range(sample_size):
            assert result[i] != expected[i]


# Generated at 2022-06-25 21:18:11.502085
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    num_1 = Random()
    num_2 = Random()
    num_3 = Random()
    num_4 = Random()
    assert num_1.custom_code() != num_1.custom_code()
    assert num_2.custom_code() != num_2.custom_code()
    assert num_3.custom_code() != num_3.custom_code()
    assert num_4.custom_code() != num_4.custom_code()
    assert random_0.custom_code() != random_0.custom_code()
    random_0 = Random()
    num_1 = Random()
    num_2 = Random()
    num_3 = Random()
    num_4 = Random()
    assert num_1.custom_code() != num_1.custom_code()

# Generated at 2022-06-25 21:18:21.892225
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()

    # Test default values
    random_0.custom_code()
    # Test parameter mask
    random_0.custom_code(mask='@###')
    # Test parameter char
    random_0.custom_code(char='@')
    # Test parameter digit
    random_0.custom_code(digit='#')
    # Test parameter mask and char
    random_0.custom_code(mask='@###', char='@')
    # Test parameter mask and digit
    random_0.custom_code(mask='@###', digit='#')
    # Test parameter char and digit
    random_0.custom_code(char='@', digit='#')
    # Test parameter mask, char, digit
    random_0.custom_code('@###', '@', '#')

    # Test wrong value

# Generated at 2022-06-25 21:18:24.735796
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Default params
    random_0 = Random()
    random_0.custom_code()

    # Specified params
    random_1 = Random()
    random_1.custom_code('########', '#', '#')

    # Mask with different placeholders for digits and chars
    random_2 = Random()
    random_2.custom_code('##--@@##@@--##', '@', '-')


# Generated at 2022-06-25 21:18:25.581286
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    rnd.custom_code(mask='@###')


# Generated at 2022-06-25 21:18:29.869820
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Placeholder for digits and characters are the same
    random_0 = Random()
    result_0 = random_0.custom_code("@###", '@', '@')
    assert result_0 is None


# Generated at 2022-06-25 21:18:41.153633
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    random = Random()
    random.seed(4)

    assert random.custom_code('@###', char='@', digit='#') == 'E984'
    assert random.custom_code('@@@#') == 'KBK'

    random.seed(6)

    assert random.custom_code('@@@#') == 'WMJ'
    assert random.custom_code('@@@#') == 'ZIS'

    random.seed(5)

    assert random.custom_code('@@@#') == 'LMX'

    random.seed(3)

    assert random.custom_code('@@@#') == 'KQE'


# Generated at 2022-06-25 21:18:55.970062
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_1 = Random()

    assert random_0.custom_code(mask='@###', char='@', digit='#') != \
           random_1.custom_code(mask='@###', char='@', digit='#')
    assert random_0.custom_code(mask='@###', char='@', digit='#') != \
           random_1.custom_code(mask='@@@###', char='@', digit='#')
    assert random_0.custom_code(mask='@@@###', char='@', digit='#') != \
           random_1.custom_code(mask='@###', char='@', digit='#')
    assert random_0.custom_code(mask='@@@###', char='@', digit='#') != \
           random_1.custom_

# Generated at 2022-06-25 21:19:02.102668
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert random_0.custom_code() == '5BMR'
    assert random_0.custom_code(mask='@#@#@#@#@#@#') == 'W8B5I5M5R5'
    assert random_0.custom_code(mask='@#@#@#@#') == 'W8B5I5M5'


# Generated at 2022-06-25 21:19:04.908924
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    new_var = Random()
    new_var.seed(1.4)
    random.seed(1.4)
    assert new_var.custom_code(mask="@###", char="@", digit="#") == "X414"
    assert random.custom_code(mask="@###", char="@", digit="#") == "X414"