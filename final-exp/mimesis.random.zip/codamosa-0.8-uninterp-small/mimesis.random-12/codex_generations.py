

# Generated at 2022-06-25 21:18:37.225071
# Unit test for function get_random_item

# Generated at 2022-06-25 21:18:41.430711
# Unit test for function get_random_item
def test_get_random_item():
    enum = {0, 1, 2, 3, 4, 5}
    random_item_0 = get_random_item(enum)
    random_item_1 = get_random_item(enum, random)
    assert random_item_0 in enum
    assert random_item_1 in enum



# Generated at 2022-06-25 21:18:48.769241
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd_0 = Random()
    code_0 = rnd_0.custom_code()
    code_1 = rnd_0.custom_code(mask='###')
    code_2 = rnd_0.custom_code(mask='@###', char='@', digit='#')


# Generated at 2022-06-25 21:18:56.093412
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    random_0 = Random()
    r_0 = random_0.custom_code()
    r_1 = random_0.custom_code(mask="@###")
    r_2 = random_0.custom_code(mask="@###", char="@")
    r_3 = random_0.custom_code(mask="@###", char = "@", digit = "#")
    print(r_0, r_1, r_2, r_3)



# Generated at 2022-06-25 21:18:57.600192
# Unit test for function get_random_item
def test_get_random_item():
    return get_random_item()



# Generated at 2022-06-25 21:19:04.765307
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    # Create an instance of Random()
    r_0 = Random()

    # Call method custom_code to generate custom code
    # using default mask and placeholders
    assert r_0.custom_code() is not None, \
        'Method custom_code return None. ' \
        'Maybe you should check parameter mask and default placeholders'

    # Call method custom_code to generate custom code
    # using custom mask and placeholders
    assert r_0.custom_code('#@@#@@#@@#@@', '#', '@') is not None, \
        'Method custom_code return None. ' \
        'Maybe you should check parameter mask and custom placeholders'


# Generated at 2022-06-25 21:19:07.684386
# Unit test for function get_random_item
def test_get_random_item():
    class MyEnum(object):
        FOO = 'foo'
        BAR = 'bar'
        BAZ = 'baz'
    print(get_random_item(MyEnum))

# Generated at 2022-06-25 21:19:10.246948
# Unit test for function get_random_item
def test_get_random_item():
    random_0 = Random()


if __name__ == '__main__':
    test_case_0()
    test_get_random_item()

# Generated at 2022-06-25 21:19:14.203766
# Unit test for function get_random_item
def test_get_random_item():
    _test_enum = type('test_enum', (object,), {'test_1': 1, 'test_2': 2})
    _test_rnd = Random()
    assert get_random_item(_test_enum, _test_rnd) in (1, 2)

# Generated at 2022-06-25 21:19:24.053072
# Unit test for function get_random_item
def test_get_random_item():
    # Define obj
    class Obj:
        def __init__(self, name, val):
            self.name = name
            self.value = val

        def __repr__(self):
            return self.name

        def __eq__(self, other):
            return self.value == other

        def __ne__(self, other):
            return not self.value == other

    # fake enum
    ENUM_0 = [
        Obj('ONE', 1),
        Obj('TWO', 2),
        Obj('THREE', 3),
    ]

    # random_0 = Random()

    o = get_random_item(ENUM_0, random_0)
    assert o in ENUM_0
    assert o in {Obj('ONE', 1), Obj('TWO', 2), Obj('THREE', 3)}
   

# Generated at 2022-06-25 21:21:51.854765
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    rnd.custom_code() # 'B642' expected
    rnd.custom_code(mask='@###-@###', char='@', digit='#') # 'S638-S638' expected



# Generated at 2022-06-25 21:21:53.336854
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()
    custom_code=random_1.custom_code('@###')
    assert len(custom_code) == 4
    assert custom_code.isalnum()


# Generated at 2022-06-25 21:21:56.252436
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for method custom_code of class Random"""
    _mask = '@###'
    _char = '@'
    _digit = '#'
    rnd = Random()
    _res = rnd.custom_code(_mask, _char, _digit)
    assert isinstance(_res, str)
    assert _res.isalnum()


# Generated at 2022-06-25 21:21:59.164979
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = '@@###'
    char = '@'
    digit = '#'
    custom_code = random.custom_code(mask, char, digit)
    assert isinstance(custom_code, str)



# Generated at 2022-06-25 21:22:00.486477
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert 'test' != rnd.custom_code(mask='test')


# Generated at 2022-06-25 21:22:03.066104
# Unit test for method custom_code of class Random
def test_Random_custom_code():
  random = Random()
  expected = "BVMG"
  actual = random.custom_code("@###", "B", "V")
  assert expected == actual


# Generated at 2022-06-25 21:22:06.590019
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert(re.match('^[A-Z]{1}[0-9]{1}[A-Z]{1}[0-9]{1}[A-Z]{1}[0-9]{1}$', Random().custom_code('@###')))



# Generated at 2022-06-25 21:22:08.319091
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    custom_code_0 = random_0.custom_code('#@##')


# Generated at 2022-06-25 21:22:10.482816
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()
    random_1.random = lambda: 0.8444444444444444
    assert random_1.custom_code('@###', '@', '#') == 'Q847'



# Generated at 2022-06-25 21:22:12.476631
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Testing custom_code."""
    mask = '@###'
    char = '@'
    digit = '#'
    random_0 = Random()
    random_0.custom_code(mask, char, digit)
