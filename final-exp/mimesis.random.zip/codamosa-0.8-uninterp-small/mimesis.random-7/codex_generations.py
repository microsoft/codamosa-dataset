

# Generated at 2022-06-25 21:16:54.855800
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(enum=None) == None
    assert get_random_item(enum=bool) == True or False


# Generated at 2022-06-25 21:16:56.815012
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()
    random_1.seed(0)

    actual = random_1.custom_code()

    expected = 'R9B0'
    assert actual == expected


# Generated at 2022-06-25 21:16:58.873323
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender, PaymentMethod
    gender = get_random_item(enum=Gender)
    payment_method = get_random_item(enum=PaymentMethod)


# Generated at 2022-06-25 21:17:01.154780
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Try basic
    assert random_0.custom_code('@@@@@@@', '@', '#')


# Generated at 2022-06-25 21:17:03.535140
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(enum=None), Any)


# Generated at 2022-06-25 21:17:08.730465
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender, DayOfWeek
    random_0 = Random()
    gender = get_random_item(Gender, rnd=random_0)
    assert gender in [Gender.MALE, Gender.FEMALE]
    day = get_random_item(DayOfWeek, rnd=random_0)
    assert day in list(DayOfWeek)



# Generated at 2022-06-25 21:17:11.092367
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert(random_0.custom_code() == 'T455')


# Generated at 2022-06-25 21:17:15.882332
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import MimeType
    enum_item = get_random_item(MimeType)
    assert isinstance(enum_item, MimeType)

# Generated at 2022-06-25 21:17:20.255470
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    _random = Random()
    g = _random.choice(list(Gender))
    assert isinstance(g, Gender)

    g = _random.choice(list(Gender))
    assert isinstance(g, Gender)

    g = get_random_item(Gender, _random)
    assert isinstance(g, Gender)

    p = Person()
    g_new = p.gender()
    assert isinstance(g_new, Gender)


# Generated at 2022-06-25 21:17:27.015678
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    result1 = get_random_item(Gender)
    result2 = get_random_item(Gender, random_0)

    random_0.choice(list(Gender))

       
if __name__ == '__main__':
    test_case_0()
    test_get_random_item()

# Generated at 2022-06-25 21:17:39.432891
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_1 = Random()
    if random_0.custom_code(int(), int()) == random_1.custom_code(int(), int()):
        raise Exception('Ошибка!')


# Generated at 2022-06-25 21:17:50.523795
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from mimesis.enums import HashAlgorithm
    algorithm = HashAlgorithm

    rnd = Random()
    for _ in range(10):
        code = rnd.custom_code(mask='AA-####')
        assert code[3:5].isdigit()
        assert code[0:3].isalpha()
        assert code[2] == '-'

    for _ in range(10):
        code = rnd.custom_code(mask='@AaA-@@@A-##@#')
        assert code[5:9].isalnum()
        assert code[0:5].isalpha()
        assert code[5:10].isalpha()
        assert code[10:12].isdigit()
        assert code[12:14].isalpha()
        assert code[12] == '-'
        assert code[14]

# Generated at 2022-06-25 21:17:58.693633
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_0.seed(0)
    random_1 = Random()
    random_1.seed(2)

    assert random_0.custom_code() == random_0.custom_code()
    assert random_1.custom_code() == random_1.custom_code()
    assert random_0.custom_code() != random_1.custom_code()



# Generated at 2022-06-25 21:18:02.635161
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from mimesis.random import Random
    random = Random()
    random.custom_code()


# Generated at 2022-06-25 21:18:11.382097
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from mimesis.enums import Gender

    a = random.custom_code('@###@@@')
    assert isinstance(a, str)
    assert len(a) == 8
    
    b = random.custom_code('@@##@@##')
    assert isinstance(b, str)
    assert len(b) == 8
    
    c = random.custom_code()
    assert isinstance(c, str)
    assert len(c) == 4
    assert all(ch in '@ABCDEFGHIJKLMNOPQRSTUVWXYZ' for ch in c)


# Generated at 2022-06-25 21:18:21.847613
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert random_0.custom_code('@###', '@', '#') == '@1@@@'
    assert random_0.custom_code() == '@1@@@'
    assert random_0.custom_code() == '@9@@@'
    assert random_0.custom_code('###', '@', '#') == '1@@@'
    assert random_0.custom_code('###', '@', '#') == '@@@@'
    assert random_0.custom_code('###', '@', '#') == '9@@@'
    assert random_0.custom_code() == '@@1@@'
    assert random_0.custom_code() == '@@9@@'

# Generated at 2022-06-25 21:18:24.861411
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()

    # Test for method custom_code of class Random
    # Input arguments
    _mask = '@###'
    _char = '@'
    _digit = '#'

    # Expected exception
    _exception = ValueError

    # Call method
    args = [_mask, _char, _digit]
    response = random_0.custom_code(*args)

    # Check result
    assert isinstance(response, str) is True

# Generated at 2022-06-25 21:18:30.557809
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from hypothesis import given
    from hypothesis.strategies import integers

    @given(integers(), integers(), integers())
    def test_custom_code(a: int, b: int, c: int):
        rnd = Random()
        rnd.seed(1)
        rnd.custom_code(a, b, c)

    test_custom_code()



# Generated at 2022-06-25 21:18:40.975349
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    try:
        assert random_0.custom_code() == 'M157'
        assert random_0.custom_code('@@#@') == 'S3L3'
        assert random_0.custom_code('@###', '@', '#') == 'N693'
        assert random_0.custom_code('####', '@', '#') == '3693'
    except AssertionError:
        print("The assertion has failed.")
        return False
    return True


# Generated at 2022-06-25 21:18:55.970343
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert random_0.custom_code() == "8TW0" or "A4C4" or "I2T0" or "Y7Y4" or "E1A0" or "I2Q2" or "A2D0" or "G3W3" or "J1H0" or "V5J3" or "D3H3" or "X6V3" or "Q2R2" or "H2E2" or "W2D1" or "G6H1" or "E8W0" or "V5P2" or "L7U2" or "M0L2" or "X9M1" or "W0Y0" or "P6U0" or "P8W3" or "U1G3" or "X8W2"