

# Generated at 2022-06-25 21:16:55.196796
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random0 = Random()
    str0 = random0.custom_code()
    assert len(str0) == 4
    assert re.match('^[A-Z]{1}[0-9]{3}$', str0)



# Generated at 2022-06-25 21:17:00.302635
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert random_0.custom_code('####')
    assert random_0.custom_code('@###')
    assert random_0.custom_code('@@##')
    assert random_0.custom_code('@@@A')
    assert random_0.custom_code('@A@B')
    assert random_0.custom_code('A@@B')
    assert random_0.custom_code('AA@@')
    assert not random_0.custom_code('AAA@')
    assert not random_0.custom_code('AAAA')
    assert not random_0.custom_code('AABA')
    assert not random_0.custom_code('AAA')
    assert not random_0.custom_code('AA')
    assert not random_0.custom_code('A')
    assert not random

# Generated at 2022-06-25 21:17:03.999787
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert Random.custom_code(random_0, mask='@###') == '@000'


# Generated at 2022-06-25 21:17:05.990552
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    str_0 = random_0.custom_code()


# Generated at 2022-06-25 21:17:09.310038
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Initialize class
    random_0 = Random()
    str_1 = random_0.custom_code()
    str_0 = random_0.custom_code(mask='@@@###', digit='#')
    # Raise exception
    try:
        random_0.custom_code(mask='@@@###', digit='@')
    except ValueError:
        pass
    str_0 = random_0.custom_code(mask='@@@###', char='@')



# Generated at 2022-06-25 21:17:20.135260
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    str_0 = random_0.custom_code()
    assert '@###' == str_0

    str_1 = random_0.custom_code('@##')
    assert '@##' != str_1

    str_2 = random_0.custom_code('@###', '@', '#')
    assert '@' in str_2

    str_3 = random_0.custom_code('@@@###', '@', '#')
    assert '@' in str_3
    assert '#' in str_3

    str_4 = random_0.custom_code('@@##@@@')
    assert '@' in str_4

    str_5 = random_0.custom_code(char='')
    assert '@' not in str_5


# Unit

# Generated at 2022-06-25 21:17:24.758844
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()
    str_1 = random_1.custom_code(mask='@@@###', char='@', digit='#')
    assert len(str_1) == 7



# Generated at 2022-06-25 21:17:30.736834
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Case 1
    s = random.custom_code()
    result = isinstance(s, str)
    assert result == True

    # Case 2
    s = random.custom_code(mask='@@@@@@##', char='@', digit='#')
    result = isinstance(s, str)
    assert result == True


# Generated at 2022-06-25 21:17:41.268937
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    random_0 = Random()
    str_0 = random_0.custom_code()
    assert str_0 != '@###'

    random_1 = Random()
    str_1 = random_1.custom_code()
    assert str_1 != '@###'

    random_2 = Random()
    str_2 = random_2.custom_code()
    assert str_2 != '@###'

    random_3 = Random()
    str_3 = random_3.custom_code()
    assert str_3 != '@###'

    random_4 = Random()
    str_4 = random_4.custom_code()
    assert str_4 != '@###'

    random_5 = Random()
    str_5 = random_5.custom_code()
    assert str_5 != '@###'

   

# Generated at 2022-06-25 21:17:45.297890
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    str_0 = random_0.custom_code()
    assert str_0 == 'R843', 'Method custom_code of class Random failed.'

