

# Generated at 2022-06-25 21:16:53.273936
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    result = random_0.custom_code()
    assert(len(result) == 4)
    assert(result.isalnum())


# Generated at 2022-06-25 21:16:59.685596
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Checking of method custom_code for class Random."""
    random_0 = Random()
    _mask: str = 'A###'
    _char: str = '@'
    _digit: str = '#'
    _custom_code: str = random_0.custom_code(mask=_mask, char=_char, digit=_digit)
    _custom_code.isdigit() == True

    _mask: str = 'A###'
    _char: str = '@'
    _digit: str = '@'
    random_0.custom_code(mask=_mask, char=_char, digit=_digit)
    # assert random_0.custom_code(mask=_mask, char=_char, digit=_digit) == 'A@3#'


# Generated at 2022-06-25 21:17:03.737126
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_0.custom_code(mask='@###', char='@', digit='#')


# Generated at 2022-06-25 21:17:07.317983
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    r.custom_code()
    assert r.custom_code('@####', '@', '#') == 'ZZZZ'



# Generated at 2022-06-25 21:17:18.696727
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for i in range(1000):
        random_0 = Random()
        mask_0 = random_0.generate_string(str_seq='@###')
        result = Random.custom_code(random_0, mask=mask_0, char='@', digit='#')
        assert isinstance(result, str)

    # Actually, we should get this test failed because the same placeholder
    # used for digits and chars
    try:
        Random.custom_code(random=random_0, mask='@@##', char='@', digit='@')
    except ValueError as exc:
        assert str(exc) == 'You cannot use the same placeholder for digits and chars!'


# Generated at 2022-06-25 21:17:29.556842
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random(2)

    assert random_1.custom_code('@##') == 'M89'
    assert random_1.custom_code('###') == '332'
    assert random_1.custom_code() == 'UZF2'
    assert random_1.custom_code('@##', '#', '@') == 'RUQ'
    assert random_1.custom_code('@##') == 'M89'
    assert random_1.custom_code('@##') == 'M89'
    assert random_1.custom_code('@##') == 'M89'
    assert random_1.custom_code('@##') == 'M89'
    assert random_1.custom_code('@##') == 'M89'

# Generated at 2022-06-25 21:17:31.464195
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for i in range(100):
        print(Random().custom_code('####'))

# Generated at 2022-06-25 21:17:38.528972
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()
    code_1 = random_1.custom_code(mask='@###', char='@', digit='#')
    random_2 = Random()
    code_2 = random_2.custom_code(mask='@###', char='@', digit='#')
    assert code_1 != code_2


# Generated at 2022-06-25 21:17:50.175383
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_1 = Random()
    random_2 = Random()
    random_3 = Random()
    random_4 = Random()
    random_5 = Random()
    random_6 = Random()
    random_7 = Random()
    random_8 = Random()
    try:
        random_0.custom_code()
        assert False
    except ValueError:
        assert True
    try:
        random_1.custom_code('@##')
        assert False
    except ValueError:
        assert True
    try:
        random_2.custom_code('@###', '@', '@')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-25 21:18:00.079419
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    mask = '@###'
    char = '@'
    digit = '#'
    code = random_0.custom_code(mask, char, digit)
    # code should contains letters AND digits
    assert code.isalnum()
    assert code.isascii()
    assert len(code) == len(mask)

    mask = '###'
    char = '#'
    digit = '#'
    try:
        random_0.custom_code(mask, char, digit)
    except ValueError:
        pass
    else:
        assert False