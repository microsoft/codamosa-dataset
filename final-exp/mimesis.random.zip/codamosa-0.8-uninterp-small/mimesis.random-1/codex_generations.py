

# Generated at 2022-06-25 21:17:49.214059
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    mask = '@###'
    char = '@'
    digit = '#'

    random_0.custom_code(mask, char, digit)


# Generated at 2022-06-25 21:17:56.968900
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    random_mask = '@##'
    random_char = '@'
    random_digit = '#'
    custom_code_value = rnd.custom_code(random_mask,random_char,random_digit)
    assert len(random_mask) == len(custom_code_value)



# Generated at 2022-06-25 21:18:00.088225
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    try:
        random_0 = Random()
        random_0.custom_code('AAAA')
        assert False
    except ValueError as exc:
        assert "You cannot use the same placeholder for digits and chars!" in str(exc)
    else:
        assert False


# Generated at 2022-06-25 21:18:03.583197
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random.seed(1)
    code = random.custom_code()
    assert code == 'UCBR', 'Method custom_code() failed'



# Generated at 2022-06-25 21:18:14.593966
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd_0 = Random()
    rnd_0.seed(0)
    assert rnd_0.custom_code() == '0F00'
    assert rnd_0.custom_code() == '5P51'
    assert rnd_0.custom_code() == '7G57'
    assert rnd_0.custom_code() == '9R23'
    assert rnd_0.custom_code() == '3990'
    assert rnd_0.custom_code() == 'Y055'
    assert rnd_0.custom_code() == 'O495'
    assert rnd_0.custom_code() == 'V166'
    assert rnd_0.custom_code() == 'U832'
    assert rnd_0.custom_code() == 'T478'
    assert rnd

# Generated at 2022-06-25 21:18:22.721534
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r1 = Random()
    code1 = r1.custom_code()
    # 'Q224' <= code1 <= 'Z999'
    assert code1.isupper() and code1.isalpha() and code1.isdigit()

    r2 = Random()
    code2 = r2.custom_code(mask='@###')
    # 'Q224' <= code2 <= 'Z999'
    assert code2.isupper() and code2.isalpha() and code2.isdigit()

    r3 = Random()
    code3 = r3.custom_code(mask='###.###')
    # '1.021' <= code3 <= '9.999'
    assert code3.isdigit() and code3.count('.') == 1

    r4 = Random()
    code4 = r4.custom_

# Generated at 2022-06-25 21:18:30.827627
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    code_0 = random_0.custom_code()
    code_1 = random_0.custom_code('@###')
    code_2 = random_0.custom_code('@###', '@', '#')
    code_3 = random_0.custom_code('@##%')
    code_4 = random_0.custom_code('@##%', '@', '#')
    code_5 = random_0.custom_code('@##', '@', '#')


# Generated at 2022-06-25 21:18:42.125529
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    string_seq = '0123456789'
    length = 10
    seed = 10
    test_random = Random(seed)
    # This list contains generated strings which are all equal because
    # their seeds are equal
    list_str = ['0123456789'.join(test_random.choice(string_seq) for _ in range(length)) for _ in range(10)]
    assert(list_str[0] == list_str[1])
    assert(list_str[3] == list_str[4])
    assert(list_str[2] == list_str[5])
    assert(list_str[7] == list_str[8])
    assert(list_str[6] == list_str[9])

# Generated at 2022-06-25 21:18:46.789427
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_1 = Random()
    random_1.custom_code() == random_0.custom_code() == '@###'
    random_2 = Random()
    random_2.custom_code(mask='@@#') == random_1.custom_code(mask='@@#')
    random_3 = Random()
    assert random_3.custom_code(mask='@@#', digit='$') == \
           random_2.custom_code(mask='@@#', digit='$')
    random_4 = Random()
    assert random_4.custom_code(mask='#*#') == \
           random_3.custom_code(mask='#*#')
    random_5 = Random()

# Generated at 2022-06-25 21:18:48.915718
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    rnd.custom_code()