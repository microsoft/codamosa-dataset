

# Generated at 2022-06-25 21:17:01.467932
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    try:
        random_0 = Random()
        random_0.custom_code("@###", '@', '#')
    except TypeError as ex:
        assert True
    except:
        assert False
    else:
        assert False

# Generated at 2022-06-25 21:17:09.303190
# Unit test for function get_random_item
def test_get_random_item():
    class EnumExample:
        def __iter__(self):
            yield self.Item1
            yield self.Item2

        def __getitem__(self, index: int) -> 'EnumExample':
            obj = self()
            obj.value = index
            return obj

        class Item1:
            value = 1
            name = 'item_1'

        class Item2:
            value = 2
            name = 'item_2'

    enum = EnumExample()
    for i in range(5):
        assert isinstance(get_random_item(enum), EnumExample)

# Generated at 2022-06-25 21:17:15.097122
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """testing method custom_code of class Random"""
    random_1 = Random()
    assert 'T@835T' == random_1.custom_code(mask='@@@@@@')


# Generated at 2022-06-25 21:17:16.980353
# Unit test for function get_random_item
def test_get_random_item():
    get_random_item()
#     assert False


# Generated at 2022-06-25 21:17:20.790186
# Unit test for function get_random_item
def test_get_random_item():
    """Test case for the function get_random_item."""
    # TODO: Implement test case
    raise NotImplementedError()

# Generated at 2022-06-25 21:17:24.104847
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(enum=list(range(10)), rnd=random_0) in list(range(10))
    

# Generated at 2022-06-25 21:17:33.016932
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()

    random_1.seed(11280)
    assert random_1.custom_code(mask='@###') == 'M1K3', "Should be 'M1K3'"

    random_1.seed(18662)
    assert random_1.custom_code(mask='@#@#@#@#@#@#@#@#@#@#') == 'F5F5F5F5F5F5F5F5F5F5', "Should be 'F5F5F5F5F5F5F5F5F5F5'"

    random_1.seed(1192)
    assert random_1.custom_code(mask='A###') == 'A664', "Should be 'A664'"

    random_1.seed(27372)

# Generated at 2022-06-25 21:17:35.246126
# Unit test for function get_random_item
def test_get_random_item():
    """Coverage.
    """
    random_1 = Random()

# Generated at 2022-06-25 21:17:39.667756
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis import locales, Person

    person = Person(locales.RU)

    # We can use random object for this function.
    person_0 = person.full_name()
    # and also.
    person_1 = person.full_name()

    assert person_0 != person_1

# Generated at 2022-06-25 21:17:50.623320
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Generate random code using char placeholders and '-' as a delimiter
    code = random.custom_code('@##-@##-@##-@##', '@', '#')
    assert isinstance(code, str)
    assert len(code.split('-')) == 4
    assert len('-'.join(code.split('-')).replace('@', '')) == 16

    # Generate random code using digit placeholders and '_' as a delimiter
    code = random.custom_code('#_#_#_#_#_#_#', '@', '#')
    assert isinstance(code, str)
    assert len(code.split('_')) == 7
    assert '@' not in code
    assert len('_'.join(code.split('_')).replace('#', '')) == 7



# Generated at 2022-06-25 21:18:09.349186
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(1, 2) == 1
    assert isinstance(get_random_item(1, 2, 3), int)
    assert get_random_item(list({1, 2, 3})) in [1, 2, 3]



# Generated at 2022-06-25 21:18:14.226515
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()

    # Assert
    for _ in range(10):
        assert len(random_0.custom_code()) >= 5



# Generated at 2022-06-25 21:18:16.165317
# Unit test for function get_random_item
def test_get_random_item():
    rnd = Random()
    get_random_item(rnd.custom_code())

# Generated at 2022-06-25 21:18:23.356733
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()

    assert random_0.custom_code(mask=u'ABCDEFGHIJKLMNOPQRSTUVWXYZ') == u'HZGXTXZWI'
    assert random_0.custom_code(mask=u'TESTTESTTESTTESTTESTTESTTEST') == u'TESTTESTTESTTESTTESTTESTTEST'
    assert random_0.custom_code(mask=u'@###') == u'GBDU'
    assert random_0.custom_code(mask=u'ABCDEFG##@') == u'DXHS'
    assert random_0.custom_code(mask=u'ABCDEFGHIJKLMNOPQRSTUVWXYZ') == u'GPBZT'

# Generated at 2022-06-25 21:18:26.604832
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Sex, State
    get_random_item(Sex)
    get_random_item(State)

# Generated at 2022-06-25 21:18:30.703240
# Unit test for function get_random_item
def test_get_random_item():
    class Color(object):
        RED = 'Red'
        BLUE = 'Blue'
        GREEN = 'Green'
        YELLOW = 'Yellow'

    color = get_random_item(Color)
    assert color in [Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW]



# Generated at 2022-06-25 21:18:37.799669
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code('@###')
    code_1 = rnd.custom_code('@@##')
    code_2 = rnd.custom_code('###@')
    code_3 = rnd.custom_code('####')


# Generated at 2022-06-25 21:18:40.925831
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    print(rnd.custom_code('@@##'))
    # print(rnd.custom_code('@@##', char='#', digit='@'))


# Generated at 2022-06-25 21:18:45.394196
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert random_0.custom_code('@###', '@', '#') != ''


# Generated at 2022-06-25 21:18:47.290245
# Unit test for function get_random_item
def test_get_random_item():
    enum_0 = get_random_item(list)
