

# Generated at 2022-06-25 21:17:08.730160
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from unittest import TestCase, main
    from . import random_module
    import re

    class test_Random(TestCase):
        def setUp(self):
            self.random = random_module.Random()

        def test_custom_code_for_digit_placeholder(self):
            pattern = re.compile(r'^\d{3}$')

            for _ in range(100):
                code = self.random.custom_code(mask='###')
                self.assertRegex(code, pattern)

        def test_custom_code_for_letter_placeholder(self):
            pattern = re.compile(r'^[A-Z]{3}$')

            for _ in range(100):
                code = self.random.custom_code(mask='@@@')
                self.assertRegex

# Generated at 2022-06-25 21:17:17.649539
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(random.custom_code('@@@@@@@')) == 7
    assert random.custom_code('@@@@@@@') == None
    assert len(random.custom_code('@@@@@@@', 'a', 'b')) == 7
    assert random.custom_code('@@@@@@@', 'a', 'b') == None
    assert random.custom_code('@@@@@@@@', '@', '@') == None


# Generated at 2022-06-25 21:17:21.243846
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert isinstance(random_0.custom_code('@###', '@', '#'), str)



# Generated at 2022-06-25 21:17:30.141394
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert code == '@###'
    code = rnd.custom_code(mask='@@@')
    assert code == '@@@'
    code = rnd.custom_code(mask='##')
    assert code == '##'
    code = rnd.custom_code(mask='@@@@@##')
    assert code == '@@@@@##'
    code = rnd.custom_code(mask='@@@@@@##')
    assert code == '@@@@@@##'
    code = rnd.custom_code(mask='@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
    assert code == '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'
    code = rnd.custom_code(mask='@@')
    assert code == '@@'

# Generated at 2022-06-25 21:17:41.091721
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@###') == Random().custom_code('@###', '@', '#')
    assert len(Random().custom_code('@###')) == 4
    assert Random().custom_code('@@#####') == Random().custom_code('@@#####', '@', '#')
    assert len(Random().custom_code('@@#####')) == 7
    assert Random().custom_code() == Random().custom_code(mask='@###', char='@', digit='#')
    assert len(Random().custom_code()) == 10
    assert len(Random().custom_code('@@##')) == 4
    assert Random().custom_code('@CCC@') == Random().custom_code('@CCC@', '@', '#')
    assert len(Random().custom_code('@CCC@')) == 5

# Generated at 2022-06-25 21:17:51.023817
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Case 0:
    # Code length = 6
    # Code pattern = A###A##
    code = random_0.custom_code(mask='@###@##',
                                char='@',
                                digit='#')
    assert 6 == len(code)

    # Case 1:
    # Code length = 8
    # Code pattern = A###A##
    code = random_0.custom_code(mask='@####@##',
                                char='@',
                                digit='#')
    assert 8 == len(code)

    # Case 2:
    # Code length = 8
    # Code pattern = A#AA###
    code = random_0.custom_code(mask='@#@@###',
                                char='@',
                                digit='#')
    assert 8 == len(code)

    # Case 3

# Generated at 2022-06-25 21:17:58.409174
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    # Create a random object
    random_1 = Random()

    # Setup arguments
    mask_0 = '@###'
    char_0 = '@'
    digit_0 = '#'

    result = random_1.custom_code(mask_0, char_0, digit_0)

    assert isinstance(result, str)



# Generated at 2022-06-25 21:18:10.397442
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(Random().custom_code()) == 4

    assert len(Random().custom_code('@##')) == 3

    assert len(Random().custom_code('@##', char='#', digit='@')) == 3

    assert len(Random().custom_code('#@@')) == 3

    assert Random().custom_code() != Random().custom_code()

    assert Random().custom_code('#@@') != Random().custom_code('#@@')

    assert Random().custom_code('@##') != Random().custom_code('@##')

    assert len(Random().custom_code('@###', char='@')) == 4

    assert len(Random().custom_code('####')) == 4

    assert Random().custom_code('@###') != Random().custom_code('@###')

    assert Random().custom_code

# Generated at 2022-06-25 21:18:13.768751
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()

    assert type(random_1.custom_code()) is str



# Generated at 2022-06-25 21:18:16.779197
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    result = random_0.custom_code()

    assert isinstance(result, str)



# Generated at 2022-06-25 21:18:29.102495
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    number_of_tests = 1000
    random_0 = Random()
    for i in range(number_of_tests):
        random_0.custom_code()



# Generated at 2022-06-25 21:18:29.901013
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    Random().custom_code()


# Generated at 2022-06-25 21:18:31.998064
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code('@###')
    assert code



# Generated at 2022-06-25 21:18:42.688956
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    # The custom random code method is tested here
    random_0 = Random()
    code = random_0.custom_code()
    assert code[0] in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert code[1] in '0123456789'
    assert code[2] in '0123456789'
    assert code[3] in '0123456789'
    code = random_0.custom_code('@####')
    assert code[1] in  '0123456789'
    assert code[2] in  '0123456789'
    assert code[3] in  '0123456789'
    assert code[4] in  '0123456789'

# Generated at 2022-06-25 21:18:46.308879
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(Random().custom_code(mask='@###', char='@', digit='#')) == 4



# Generated at 2022-06-25 21:18:55.971300
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(random.custom_code()) == 4
    assert len(random.custom_code()) == 4
    assert len(random.custom_code('@###')) == 4
    assert len(random.custom_code('@##')) == 3
    assert len(random.custom_code('@##', char='*')) == 3
    assert len(random.custom_code('@##', char='*')) == 3
    assert len(random.custom_code('@##', char='*', digit='&')) == 3
    assert len(random.custom_code('@##', char='*', digit='&')) == 3
    assert len(random.custom_code()) == 4
    assert len(random.custom_code()) == 4
    assert len(random.custom_code('@####')) == 5

# Generated at 2022-06-25 21:19:02.132979
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code(mask='@###', char='@', digit='#')
    assert len(code) == 4
    assert code[0] in string.ascii_uppercase
    assert code[1] in string.ascii_uppercase
    assert code[2] in string.digits
    assert code[3] in string.digits



# Generated at 2022-06-25 21:19:06.339630
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert 'H4E1' == random_0.custom_code()
    assert '3V8W' == random_0.custom_code('@@##')
    assert 'A1' == random_0.custom_code('@##', '@', '#')
    assert 'B3' == random_0.custom_code('@#@', '@', '#')


# Generated at 2022-06-25 21:19:13.472916
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Initialization of the object.
    rand_0_obj = Random()
    # Assert result.
    assert rand_0_obj.custom_code(mask='@###', char='@', digit='#') is not None
    # Assert type.
    assert isinstance(rand_0_obj.custom_code(mask='@###', char='@', digit='#'), str)
    # Assert length
    assert len(rand_0_obj.custom_code(mask='@###', char='@', digit='#')) == 4


# Generated at 2022-06-25 21:19:24.052451
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert random_0.custom_code('@###', '@', '#') == 'A123' or \
           random_0.custom_code('@###', '@', '#') == 'B123' or \
           random_0.custom_code('@###', '@', '#') == 'C123' or \
           random_0.custom_code('@###', '@', '#') == 'D123' or \
           random_0.custom_code('@###', '@', '#') == 'E123'



# Generated at 2022-06-25 21:20:54.523709
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    assert random_0.custom_code() == "HN6O",\
        "Not correct value in custom_code method."



# Generated at 2022-06-25 21:20:58.245778
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    r = Random()
    r.custom_code(mask='@###', char='@', digit='#')
    r.custom_code(mask='@@##@@', char='@', digit='#')
    r.custom_code(mask='@@##@@', char='#', digit='@') # ValueError
    r.custom_code(mask='@@##@@', char='#')

# Generated at 2022-06-25 21:21:03.501979
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Case 0
    random_0 = Random()
    # Assertion
    assert random_0.custom_code('@###')
    assert random_0.custom_code('@###')
    assert not random_0.custom_code('@###')
    assert random_0.custom_code()
    assert random_0.custom_code()
    assert random_0.custom_code()
    assert random_0.custom_code()
    assert random_0.custom_code()
    assert random_0.custom_code()
    assert random_0.custom_code()
    assert random_0.custom_code()

    # Case 1
    random_0 = Random()
    # Assertion
    assert random_0.custom_code('@###')
    assert random_0.custom_code('@###')

# Generated at 2022-06-25 21:21:09.192722
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Test with empty value
    assert Random().custom_code() == 'A001'

    # Test with parameters
    assert Random().custom_code('@-##') == 'A-01'
    assert Random().custom_code('@-##', '@', '#') == 'A-01'

    # Test with wrong parameters
    try:
        Random().custom_code('@_##', '@', '#')
    except ValueError:
        pass

    # Test with wrong parameters
    try:
        Random().custom_code('@_##', char='@', digit='#')
    except ValueError:
        pass



# Generated at 2022-06-25 21:21:11.099010
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert isinstance(random.custom_code(), str)


# Generated at 2022-06-25 21:21:15.969754
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    mask_0 = random_0.generate_string('123')
    char_0 = random_0.generate_string('123')
    digit_0 = random_0.generate_string('123')
    result_0 = random_0.custom_code(mask_0, char_0, digit_0)
    assert isinstance(result_0, str)
    assert isinstance(result_0, str)
    assert isinstance(result_0, str)
    assert isinstance(result_0, str)
    assert not isinstance(result_0, str)



# Generated at 2022-06-25 21:21:21.197514
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_1 = Random()
    random_2 = Random()
    random_3 = Random()
    random_4 = Random()
    random_5 = Random()
    random_6 = Random()
    random_7 = Random()
    random_8 = Random()
    random_9 = Random()
    random_10 = Random()
    random_11 = Random()
    random_12 = Random()
    random_13 = Random()
    random_14 = Random()
    random_15 = Random()

    random_1.custom_code('@@##')


# Generated at 2022-06-25 21:21:22.557435
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    to_test_0 = random_0.custom_code()
    assert isinstance(to_test_0, str)


# Generated at 2022-06-25 21:21:28.115061
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code() == 'C626'
    assert rnd.custom_code('@###') == 'H701'
    assert rnd.custom_code('@###') == 'J372'
    assert rnd.custom_code('@###') == 'F902'
    assert rnd.custom_code('@') == 'N'
    assert rnd.custom_code('A###', 'A', '#') == 'A982'
    assert rnd.custom_code('@@@#', '@', '#') == 'JY21'
    assert rnd.custom_code('@@@-#') == 'PXU-7'

# Generated at 2022-06-25 21:21:28.706160
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    pass
