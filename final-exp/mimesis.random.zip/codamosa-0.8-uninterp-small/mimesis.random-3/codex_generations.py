

# Generated at 2022-06-25 21:16:53.603454
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender, Locale

    assert get_random_item(Gender) in list(Gender)
    assert get_random_item(Gender, random_module) in list(Gender)

    my_random = Random()
    assert get_random_item(Locale, my_random) in list(Locale)

# Generated at 2022-06-25 21:16:56.867156
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(enum=1) == 1
    assert get_random_item(enum=map(lambda x: x**2, range(5))) == 16

# Generated at 2022-06-25 21:17:01.719967
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender, Locale
    assert type(get_random_item(Gender)) is Gender
    assert type(get_random_item(Locale)) is Locale
    assert type(get_random_item(Locale, random)) is Locale


# Generated at 2022-06-25 21:17:06.422305
# Unit test for function get_random_item
def test_get_random_item():
    # assert get_random_item(1) == 1
    # assert get_random_item([1]) == 1
    assert get_random_item((1,)) == 1
    assert get_random_item({1}) == 1
    assert get_random_item({1, 2}) == 2
    r = Random()
    assert get_random_item((1,), r) == 1
    assert get_random_item({1, 2}, r) == 1

"""DisabledContent
"""

# Generated at 2022-06-25 21:17:08.773476
# Unit test for function get_random_item
def test_get_random_item():
    random_0 = Random()
    random_0.randints


# Generated at 2022-06-25 21:17:13.536195
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    random_1 = Random()
    gen = get_random_item(Gender)
    assert gen in Gender.female, Gender.male


# Generated at 2022-06-25 21:17:17.782337
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_1 = Random()
    result_custom_code_0 = random_1.custom_code(mask='@###',
                                                char='@',
                                                digit='#')


# Generated at 2022-06-25 21:17:24.475509
# Unit test for function get_random_item
def test_get_random_item():
    enum_0 = (1, 2, 3)
    Random.choice = lambda self, x: 3
    rnd_0 = Random()
    result_0 = get_random_item(enum_0, rnd_0)
    if result_0 == 3:
        return 0
    return 1


# Generated at 2022-06-25 21:17:31.320671
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import BloodType

    class BloodTypeEnum:
        """Enum with fake blood types."""

        A = BloodType.A
        B = BloodType.B
        AB = BloodType.AB
        O = BloodType.O

    # item should be BloodTypeEnum's attribute
    for _ in range(100):
        assert hasattr(BloodTypeEnum, get_random_item(BloodTypeEnum))

# Generated at 2022-06-25 21:17:36.529522
# Unit test for function get_random_item
def test_get_random_item():
    rnd = Random()
    item = get_random_item(rnd, rnd)
    print(item)
    item = get_random_item(rnd)
    print(item)



# Generated at 2022-06-25 21:17:48.956315
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()

    assert random_0.custom_code(mask="@###", char="@", digit="#") == "@04F" or \
        random_0.custom_code(mask="@###", char="@", digit="#") == "@511" or \
        random_0.custom_code(mask="@###", char="@", digit="#") == "@FZB"


# Generated at 2022-06-25 21:17:51.905762
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = random.custom_code(mask='@###')
    assert len(r) == 4 and r[0].isalpha()

# Generated at 2022-06-25 21:17:56.017803
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r1 = Random()
    r1.custom_code(mask='@###')


# Generated at 2022-06-25 21:17:58.519399
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    random_0.custom_code("@###", '@', '#')



# Generated at 2022-06-25 21:18:03.029202
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    result_0 = random_0.custom_code(mask=None)
    pass


# Generated at 2022-06-25 21:18:11.360333
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    random_1 = Random()
    mask = '@###'
    char = '@'
    digit = '#'
    value_1 = random_1.custom_code(mask=mask, char=char, digit=digit)
    assert isinstance(value_1, str)
    assert len(value_1) == len(mask)

    random_2 = Random()
    mask_1 = '@#@#@#@#'
    char_1 = '@'
    digit_1 = '#'
    value_2 = random_2.custom_code(mask=mask_1, char=char_1, digit=digit_1)
    assert isinstance(value_2, str)
    assert len(value_2) == len(mask_1)

    random_3 = Random()
    mask_2 = '$$$'
   

# Generated at 2022-06-25 21:18:19.873691
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # case 1
    random_1 = Random()
    my_code = random_1.custom_code()
    print(my_code)
    # case 2
    random_2 = Random()
    my_code = random_2.custom_code(mask='@######')
    print(my_code)
    # case 3
    random_3 = Random()
    my_code = random_3.custom_code(mask='####@', char='#', digit='@')
    print(my_code)


# Generated at 2022-06-25 21:18:24.550533
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    lst = [random_0.custom_code() for _ in range(100)]
    assert len(set(lst)) == len(lst)
    assert len(lst[0]) == 4


# Generated at 2022-06-25 21:18:29.481161
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random0 = Random()
    mask = '@###'
    char = '@'
    digit = '#'
    result = random0.custom_code(mask, char, digit)
    assert isinstance(result, str)


# Generated at 2022-06-25 21:18:42.047812
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()