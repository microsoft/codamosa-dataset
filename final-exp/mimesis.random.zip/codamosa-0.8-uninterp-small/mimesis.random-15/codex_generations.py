

# Generated at 2022-06-25 21:16:54.541193
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code(mask='@###-##-##---S-S-S',
                              char='@', digit='#')
    assert len(code) == 12


# Generated at 2022-06-25 21:17:00.099436
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Unit test for method custom_code of class Random
    import random as r

    _1 = r.custom_code(mask='@###')
    _2 = r.custom_code(mask='@###', char='$', digit='#')
    _3 = r.custom_code(mask='@###', char='$')
    _4 = r.custom_code(mask='@###', digit='$')
    _5 = r.custom_code(mask='@###', char='@', digit='#')
    _6 = r.custom_code(mask='@@@@')
    _7 = r.custom_code(mask='@@##')
    _8 = r.custom_code(mask='#@@@')
    _9 = r.custom_code(mask='##@@')

# Generated at 2022-06-25 21:17:04.769780
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    rnd.seed(35)
    code = rnd.custom_code(mask='@@###@@@@', char='@', digit='#')
    assert code in ['AL5238SZS', 'XV1266RVD']


# Generated at 2022-06-25 21:17:11.517114
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_0 = Random()
    str_mask_0 = '-###-#@-#@@@'
    str_char_0 = '@'
    str_digit_0 = '#'
    str_result_0 = random_0.custom_code(str_mask_0, str_char_0, str_digit_0)
    assert str_result_0 == str_result_0
    # str_mask_0 = '--@@-@@@-@##'
    # str_char_0 = '-'
    # str_digit_0 = '@'
    # # str_result_0 = random_0.custom_code(str_mask_0, str_char_0, str_digit_0)
    # assert str_result_0 == str_result_0


# Generated at 2022-06-25 21:17:15.011061
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Expected True"""
    assert random.custom_code() == 'A###'



# Generated at 2022-06-25 21:17:20.500934
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    # Create a object (but not used)
    obj = Random()

    # All forms of call of method custom_code
    obj.custom_code(mask = '@###')
    obj.custom_code(mask = '@###', char = '@')
    obj.custom_code(mask = '@###', char = '@', digit = '#')
    obj.custom_code()
    obj.custom_code(mask = '@###')
    obj.custom_code(mask = '@###', digit = '#')
    obj.custom_code(mask = '@###', char = '@', digit = '#')


# Generated at 2022-06-25 21:17:21.960118
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Not implemented
    pass


# Generated at 2022-06-25 21:17:27.470919
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code(mask='@###', digit='@', char='#')
    print(code)


if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-25 21:17:33.884932
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rand = Random()
    rand.seed(123456789)
    mask = '@###'
    char = '@'
    digit = '#'
    exc_res = rand.custom_code(mask, char, digit)
    assert exc_res == 'A120'

# Tests for method generate_string

# Generated at 2022-06-25 21:17:39.033297
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    mask = '@###'
    expected = rnd.custom_code(mask)
    assert rnd.custom_code(mask) == rnd.custom_code(mask)
    assert rnd.custom_code(mask) == expected
