

# Generated at 2022-06-23 21:51:31.487414
# Unit test for method uniform of class Random
def test_Random_uniform():
    """
    Test method uniform of class Random.
    """
    r = Random()
    assert isinstance(r.uniform(1, 2), float)
    assert r.uniform(1, 2) >= 1.0 and r.uniform(1, 2) < 2.0

# Generated at 2022-06-23 21:51:39.090594
# Unit test for method uniform of class Random
def test_Random_uniform():
    values_and_expected = [
        (1, 2, 1.27027),
        (7, 8, 7.30382),
        (-6, -5, -5.91086),
        (-4, 5, 0.46041),
        (1, 1, 1),
        (-5, -5, -5),
        (0, 1, 0.65609),
        (0, 0, 0),
    ]

    for a, b, expected in values_and_expected:
        random_result = random.uniform(a, b)
        assert round(random_result, 5) == expected

# Generated at 2022-06-23 21:51:44.975168
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    m = '@@##@@@!@#'
    char, digit = '@', '#'
    code = random.custom_code(mask=m, char=char, digit=digit)
    assert len(code) == len(m)

    for i in range(5):
        print(random.custom_code(mask=m, char=char, digit=digit))


# Generated at 2022-06-23 21:51:47.926281
# Unit test for method uniform of class Random
def test_Random_uniform():
    a = 0.25
    b = 0.75
    precision = 15
    random = Random()
    result = random.uniform(a, b, precision)
    print(result)


# Generated at 2022-06-23 21:51:51.487690
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    output = Random().custom_code()
    assert len(output) == 4
    for i in range(4):
        assert (output[i] >= 'A' and output[i] <= 'Z') or \
               (output[i] >= '0' and output[i] <= '9')

# Generated at 2022-06-23 21:51:56.214822
# Unit test for method custom_code of class Random
def test_Random_custom_code(): # NOQA
    c = Random()
    assert c.custom_code() == '@###'
    assert c.custom_code(mask='@##') == '@##'
    assert c.custom_code(mask='@@@') == '@@@'
    assert c.custom_code(mask='@@@###') == '@@@###'
    assert c.custom_code(mask='@@@###', char='!', digit='#') == '!!####'

# Generated at 2022-06-23 21:51:58.854518
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    r = Random()
    assert isinstance(r.urandom(100), bytes)



# Generated at 2022-06-23 21:52:00.181084
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert type(Random().urandom()) == bytes

# Generated at 2022-06-23 21:52:11.457873
# Unit test for constructor of class Random
def test_Random():
    """Test method for constructor of class Random."""
    r = Random()

    for _ in range(10):
        assert r.randint(0, 10) < 10

    for _ in range(10):
        assert r.randint(0, 10) > 0

    for _ in range(10):
        assert r.randint(10, 10) == 10

    for _ in range(10):
        assert r.randint(-10, 10) < 10

    for _ in range(10):
        assert r.randint(-10, 10) > -10

    for _ in range(10):
        assert r.randint(-10, 10) != 10

    for _ in range(10):
        assert r.randint(-10, 10) != -10

# Generated at 2022-06-23 21:52:13.779003
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method ``urandom()`` of class ``Random()``."""
    assert isinstance(Random().urandom(16), bytes)

# Generated at 2022-06-23 21:52:17.667008
# Unit test for function get_random_item
def test_get_random_item():
    import enum as enum_module
    class Enum(enum_module.Enum):
        """Class Enum"""
        one = 1  # pylint: disable=invalid-name
        two = 2  # pylint: disable=invalid-name
    #
    rnd_item = get_random_item(Enum)
    assert isinstance(rnd_item, Enum)

# Generated at 2022-06-23 21:52:20.343970
# Unit test for method randints of class Random
def test_Random_randints():
    a = random.randints(amount=5, a=0, b=10)
    assert len(a) == 5
    assert all(i >= 0 and i <= 10 for i in a)

# Generated at 2022-06-23 21:52:26.095597
# Unit test for function get_random_item
def test_get_random_item():
    # Create a new instance of Random() class.
    rnd = Random()
    # Create a set of test data.
    enum_data = ['item1', 'item2', 'item3']
    # Call function get_random_item passing test data.
    result = get_random_item(enum_data, rnd)
    # Assertion that all the items in the set are in the result.
    assert all(x in result for x in enum_data)

# Generated at 2022-06-23 21:52:27.802367
# Unit test for function get_random_item
def test_get_random_item():
    from .enums import UnitSystem

    assert get_random_item(UnitSystem) in list(UnitSystem)

# Generated at 2022-06-23 21:52:32.559223
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test Random.urandom(k=None)."""
    if not isinstance(random.urandom(), bytes):
        raise Exception('Incorrect type of result.')
    if random.urandom(10) == random.urandom(10):
        raise Exception('Incorrect result.')


# Generated at 2022-06-23 21:52:38.711375
# Unit test for method randstr of class Random
def test_Random_randstr():
    _rnd = Random()
    _random_str = _rnd.randstr(unique=True)
    assert isinstance(_random_str, str)
    assert len(_random_str) == 32

    _random_str = _rnd.randstr(unique=True)
    assert isinstance(_random_str, str)
    assert len(_random_str) == 32



# Generated at 2022-06-23 21:52:42.026601
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    # length = 10
    s = r.generate_string('0123456789')
    assert len(s) == 10
    # length = 20
    s = r.generate_string(string.ascii_letters, 20)
    assert len(s) == 20
    # length = 4
    s = r.generate_string(string.hexdigits, 4)
    assert len(s) == 4

# Generated at 2022-06-23 21:52:44.587626
# Unit test for function get_random_item
def test_get_random_item():
    class MyEnum(object):
        one = 1
        two = 2
    my_enum = MyEnum()
    assert random.choice([my_enum.one, my_enum.two]) == get_random_item(my_enum)

# Generated at 2022-06-23 21:52:48.650268
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender, Transport

    for _ in range(3):
        assert get_random_item(Gender) in Gender
        assert get_random_item(Transport) in Transport

# Generated at 2022-06-23 21:52:52.598498
# Unit test for method randints of class Random
def test_Random_randints():
    for _ in range(100):
        _list = random.randints(
            amount=10, a=1, b=100
        )

        assert len(_list) == 10

        assert all(_list) >= 1
        assert all(_list) <= 100

# Generated at 2022-06-23 21:52:56.424033
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints()) == 3
    assert len(random.randints(amount=6)) == 6
    assert len(random.randints(a=1000, b=2000)) == 3


# Generated at 2022-06-23 21:53:06.558332
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    for _ in range(10):
        assert len(rnd.randstr()) == 32
    for _ in range(10):
        assert len(rnd.randstr(unique=True)) == 32
    assert len(rnd.randstr(length=5)) == 5
    assert len(rnd.randstr(length=7)) == 7
    assert len(rnd.randstr(length=9)) == 9
    assert len(rnd.randstr(length=16)) == 16
    assert len(rnd.randstr(length=20)) == 20
    assert len(rnd.randstr(length=50)) == 50
    assert len(rnd.randstr(length=64)) == 64

# Generated at 2022-06-23 21:53:07.906372
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Random."""
    assert Random().urandom()


# Generated at 2022-06-23 21:53:13.440049
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    class TestRandom(Random):
        def __init__(self, seed: int = 123456):
            super(TestRandom, self).__init__(seed)

    r = TestRandom()
    assert r.generate_string(string.ascii_letters) == 'onJHXxco'
    assert r.generate_string(string.digits) == '56450270'
    assert r.generate_string('!' * 10, 5) == '!!!!!'



# Generated at 2022-06-23 21:53:24.303198
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Single test
    test_mask = "@$$"
    char = "@"
    digit = "$"
    custom_code = random.custom_code(test_mask, char, digit)

    if len(custom_code) != len(test_mask):
        raise AssertionError(
            "The length of the generated code does not match the length "
            "of the mask.")

    for i, code_symbol in enumerate(custom_code):
        if test_mask[i] == char:
            if not code_symbol.isalpha():
                raise AssertionError(
                    "The character in the code is not"
                    " a letter of the Latin alphabet.")

# Generated at 2022-06-23 21:53:28.617078
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert rnd.uniform(1, 1.1, 10) >= 1
    assert rnd.uniform(1, 1.1, 10) < 1.1
    assert rnd.uniform(1, 1.1) >= 1
    assert rnd.uniform(1, 1.1) < 1.1

# Generated at 2022-06-23 21:53:35.653589
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test Random_uniform method."""
    random = Random()
    assert random.uniform(a=0.0, b=10.0, precision=15)
    assert random.uniform(a=0.0, b=10.0, precision=1)
    assert random.uniform(a=0.0, b=10.0, precision=3)
    assert random.uniform(a=0.0, b=10.0, precision=100)
    return True

# Generated at 2022-06-23 21:53:37.360116
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(), bytes)
    assert isinstance(random.urandom(6), bytes)

# Generated at 2022-06-23 21:53:41.744177
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    _rnd = Random()
    _rnd.seed(_rnd.SEED)
    array1 = [_rnd.randstr() for _ in range(100)]
    array2 = [_rnd.randstr() for _ in range(100)]
    assert array1 != array2
    array3 = [_rnd.randstr(unique=True) for _ in range(100)]
    array4 = [_rnd.randstr(unique=True) for _ in range(100)]
    assert array3 == array4

# Generated at 2022-06-23 21:53:43.902906
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    custom_code = Random().custom_code('NNN', 'N', 'N')
    assert len(custom_code) == 3
    assert custom_code.isalpha()

# Generated at 2022-06-23 21:53:47.036619
# Unit test for method randstr of class Random
def test_Random_randstr():
    for i in range(100):
        r = random.randstr(length=25)
        assert isinstance(r, str)
        assert len(r) == 25

# Generated at 2022-06-23 21:53:49.169489
# Unit test for constructor of class Random
def test_Random():
    r = Random(1)
    assert r.random() == 0.13436424411240122



# Generated at 2022-06-23 21:53:54.766767
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    from mimesis.builtins import Integer

    random = Random()
    integer = Integer()
    str_seq = integer.numerals(20)
    length = integer.between(0, 100)
    random_str = random.generate_string(str_seq, length)
    for symbol in random_str:
        assert symbol in str_seq

# Generated at 2022-06-23 21:53:58.694558
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    a = r.generate_string('1234567890')
    assert isinstance(a, str)

    # for i in range(20):
    #     print(r.generate_string('0123456789ABCDEF'))


# Generated at 2022-06-23 21:54:04.486161
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random.
    :returns: Boolean
    """
    r = Random()
    str_list = [r.randstr() for _ in range(1000)]
    # print(str_list)
    print(any(str_list))
    return len(str_list) == len(set(str_list))


# Generated at 2022-06-23 21:54:16.490623
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('A###', char='A', digit='#') == 'A212'
    assert random.custom_code('####', char='@', digit='#') == '1234'
    assert random.custom_code('@@@@', char='@', digit='#') == 'AAAA'
    assert random.custom_code('ABCD') == 'ABCD'
    assert random.custom_code('') == ''
    assert random.custom_code('##') == '16'
    assert random.custom_code('@@') == 'AA'
    assert random.custom_code('<@@>') == '<AA>'
    assert random.custom_code('<@@>') == '<AA>'
    assert random.custom_code('<@@@>') == '<AAA>'



# Generated at 2022-06-23 21:54:19.364925
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Arrange
    rnd = Random()
    amount = 8
    # Act
    result = rnd.urandom(amount)

    # Assert
    assert isinstance(result, type(b''))
    assert len(result) == amount

# Generated at 2022-06-23 21:54:21.978918
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    # test for method uniform of class Random
    assert r.uniform(1.5, 2.5, 10) >= 1.5 and r.uniform(1.5, 2.5, 10) < 2.5

# Generated at 2022-06-23 21:54:25.926032
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test method randstr()."""
    assert isinstance(random.randstr(), str)
    assert isinstance(random.randstr(unique=True), str)
    assert isinstance(random.randstr(length=random.randint(64, 128)), str)



# Generated at 2022-06-23 21:54:28.018471
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = random.uniform(10, 15)
    assert rnd >= 10 and rnd < 15

# Generated at 2022-06-23 21:54:30.622077
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    random = Random()
    assert isinstance(random.randstr(), str)
    assert isinstance(random.randstr(length=10), str)
    assert isinstance(random.randstr(unique=True), str)

# Generated at 2022-06-23 21:54:31.422879
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(int), int)



# Generated at 2022-06-23 21:54:33.008814
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(string.ascii_letters), str)

# Generated at 2022-06-23 21:54:41.197987
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert round(random.uniform(0.0, 1.0), 10) != round(random.uniform(0.0, 1.0), 10)
    assert round(random.uniform(0.0, 1.0, 10), 10) != round(random.uniform(0.0, 1.0, 10), 10)
    assert round(random.uniform(0.0, 1.0), 10) != round(random.uniform(0.0, 1.0, 10), 10)

# Generated at 2022-06-23 21:54:42.541198
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    s = random.generate_string('123')
    assert len(s) == 10

# Generated at 2022-06-23 21:54:44.628074
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    assert isinstance(get_random_item(random.generators), str)

# Generated at 2022-06-23 21:54:46.166722
# Unit test for function get_random_item
def test_get_random_item():
    assert type(get_random_item(enum=random.VERB_FORMS)) == str


# Generated at 2022-06-23 21:54:47.369017
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random.urandom(), bytes)



# Generated at 2022-06-23 21:54:51.504818
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Check method generate_string in class Random."""
    rnd = Random()
    result = rnd.generate_string("123456789", 3)
    assert len(result) == 3
    assert result.isdigit()

# Generated at 2022-06-23 21:54:51.843815
# Unit test for constructor of class Random
def test_Random():
    pass

# Generated at 2022-06-23 21:54:55.876192
# Unit test for method randstr of class Random
def test_Random_randstr():
    print(random.randstr(unique=True))
    print(random.randstr(unique=True))
    print(random.randstr(unique=True))
    print('Test Passed!')

if __name__ == '__main__':
    test_Random_randstr()
    pass

# Generated at 2022-06-23 21:55:04.244649
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(Random().custom_code()) == 10
    assert len(Random().custom_code('####')) == 4
    assert len(Random().custom_code('##', '#', '$')) == 2
    assert len(Random().custom_code('##', '$', '*')) == 2
    assert len(Random().custom_code('##', '*', '$')) == 2
    assert len(Random().custom_code('##', '$', '$')) == 2
    assert len(Random().custom_code('##', '*', '*')) == 2
    assert len(Random().custom_code('##', '#', '#')) == 2

# Generated at 2022-06-23 21:55:10.547151
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert all(len(random.randstr()) == 32 for _ in range(100))
    assert all(len(random.randstr(unique=False, length=20)) == 20 for _ in range(100))
    assert len(random.randstr(unique=True)) == 32
    _set = set()
    for _ in range(100):
        _set.add(random.randstr(unique=True))
    assert len(_set) == 100

# Generated at 2022-06-23 21:55:13.754508
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = random.randstr(unique=True)
    assert len(r) == 32

    r = random.randstr(length=16)
    assert len(r) == 16

    with pytest.raises(ValueError):
        r = random.randstr(length=0)  # noqa

# Generated at 2022-06-23 21:55:22.989458
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    global random
    random = Random()

    # checks of works method with placeholders '@' and '#'
    assert random.custom_code('@###')
    assert random.custom_code('@###', char='@', digit='#')
    assert random.custom_code('@@##@@')
    assert random.custom_code('@@##@@', char='@', digit='#')

    # checks of works method with placeholders 'a' and 'b'
    assert random.custom_code('a###')
    assert random.custom_code('a###', char='a', digit='#')
    assert random.custom_code('aa##aa')
    assert random.custom_code('aa##aa', char='a', digit='#')

    # checks of works method with placeholders '1' and '2'
    assert random.custom_

# Generated at 2022-06-23 21:55:25.578989
# Unit test for method urandom of class Random
def test_Random_urandom():
    _random = Random()

    assert _random.urandom()
    assert _random.urandom(10)
    assert _random.urandom(100)



# Generated at 2022-06-23 21:55:29.226048
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(random.generate_string(str_seq='abcdefghijklmnopqrstuvwxyz', length=12)) == 12

# Generated at 2022-06-23 21:55:31.679825
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    integers = r.randints(10, 1, 50)
    for i in integers:
        assert 1 <= i <= 50

# Generated at 2022-06-23 21:55:33.542001
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code(mask='@###') in ('A123', 'Z123', 'A987', 'Z987')

# Generated at 2022-06-23 21:55:39.365255
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1, 2, 10) in [1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9]
    assert random.uniform(1, 1.1, 10) in [1.0, 1.1]
    assert random.uniform(1, 1, 10) == 1
    assert random.uniform(1, 2) in [1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9]
    assert random.uniform(1, 1.1) in [1.0, 1.1]
    assert random.uniform(1, 1) == 1

# Generated at 2022-06-23 21:55:41.709838
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 21:55:44.426241
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    result = random.custom_code('@###')
    assert result[0].isalpha() and result[1:].isdigit()

# Generated at 2022-06-23 21:55:49.396128
# Unit test for function get_random_item
def test_get_random_item():
    class Test:
        test = "test"
        test1 = "test1"
        test2 = "test2"

    assert get_random_item(Test) in ["test", "test1", "test2"]



# Generated at 2022-06-23 21:55:53.370292
# Unit test for method uniform of class Random
def test_Random_uniform():
    random_ = Random()
    random_.random = lambda: 0.123456789
    assert random_.uniform(1.0, 2.0) == 1.123456789
    assert random_.uniform(1.0, 2.0, precision=3) == 1.123

# Generated at 2022-06-23 21:56:00.857061
# Unit test for method uniform of class Random
def test_Random_uniform():
    new_random = Random()
    result = new_random.uniform(0, 1)
    assert isinstance(result, float)
    assert 0 <= result <= 1, f'Result is: {result}'

    result = new_random.uniform(0, 1, precision=5)
    assert isinstance(result, float)
    assert 0 <= result <= 1, f'Result is: {result}'

    result = new_random.uniform(0, 1, precision=0)
    assert isinstance(result, int)
    assert 0 <= result <= 1, f'Result is: {result}'

# Generated at 2022-06-23 21:56:06.124876
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for ``Random.randints()``
    """
    r = Random()
    rand = r.randints(10, 1, 22)

    for i, item in enumerate(rand):
        if item < 1 or item > 21:
            print(i, item)
            return False

    return True

# Generated at 2022-06-23 21:56:09.468947
# Unit test for method randstr of class Random
def test_Random_randstr():
    if len(random.randstr(unique=True)) != 32:
        raise AssertionError
    if len(random.randstr(length=10)) != 10:
        raise AssertionError

# Generated at 2022-06-23 21:56:11.450773
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random.
    """
    assert isinstance(random, Random)

# Generated at 2022-06-23 21:56:14.552761
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    random.seed(1)

    assert random.seed(1)

    assert [14, 41, 51] == random.randints(3, 1, 100)



# Generated at 2022-06-23 21:56:17.672842
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    obj = Random()
    s = obj.generate_string(str_seq='abcdefghijklmnopqrstuvwxyz')
    assert len(s) == 10 and s.isalnum()



# Generated at 2022-06-23 21:56:20.260576
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1, 2) == random.uniform(1.0, 2.0)

# Generated at 2022-06-23 21:56:23.336053
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    assert r.uniform(2.1, 4.0) >= 2.1
    assert r.uniform(2.1, 4.0) < 4.0

# Generated at 2022-06-23 21:56:24.638441
# Unit test for function get_random_item
def test_get_random_item():
    assert random == get_random_item(
        enum=None)

# Generated at 2022-06-23 21:56:30.984283
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert random.randstr()
    assert random.randstr(unique=True)
    assert random.randstr(length=100)

    assert isinstance(random.randstr(), str)
    assert isinstance(random.randstr(unique=True), str)

    assert len(random.randstr()) == 16
    assert len(random.randstr(length=100)) == 100
    assert len(random.randstr(unique=True)) == 32
    assert len(random.randstr(unique=True, length=100)) == 64

    assert random.randstr() != random.randstr()
    assert random.randstr(unique=True) != random.randstr(unique=True)
    assert random.randstr(length=100) != random.randstr(length=100)
    assert random.randstr(unique=True, length=100)

# Generated at 2022-06-23 21:56:31.972506
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    random.randstr()

# Generated at 2022-06-23 21:56:34.801519
# Unit test for method randints of class Random
def test_Random_randints():
    assert random.randints() == [2, 3, 8]

# Generated at 2022-06-23 21:56:36.417264
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rand = Random()
    rand.seed(0)
    s = rand.generate_string('abcd', 5)
    assert s == 'dcbcd'

# Generated at 2022-06-23 21:56:41.622480
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = Random().custom_code()
    assert len(code) == 4
    assert code[0].isalpha()
    assert code.isalnum()

    code = Random().custom_code(mask='##-A')
    assert len(code) == 4
    assert code[1] == '-'
    assert code.isalnum()

    code = Random().custom_code(mask='A@###')
    assert len(code) == 6
    assert code[1].isdigit()
    assert code.isalnum()

    code = Random().custom_code(mask='@######@')
    assert len(code) == 8
    assert code.isalnum()

# Generated at 2022-06-23 21:56:46.230002
# Unit test for method urandom of class Random
def test_Random_urandom():
    rng = Random()
    assert len(rng.urandom(20)) == 20
    assert len(rng.urandom(1)) == 1
    assert len(rng.urandom(5)) == 5
    assert len(rng.urandom(99)) == 99

# Generated at 2022-06-23 21:56:48.818899
# Unit test for method randints of class Random
def test_Random_randints():
    """Test the method ``randints()``.

    The method ``randints()`` is used in the class provider ``File()``.
    """
    rnd = Random()
    for _ in range(10):
        assert len(rnd.randints()) == 3

# Generated at 2022-06-23 21:56:50.527315
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(Random().randstr()) == 32
    assert len(Random().randstr(length=3)) == 3
    assert len(Random().randstr(unique=True)) == 32

# Generated at 2022-06-23 21:56:54.352632
# Unit test for function get_random_item
def test_get_random_item():
    class Status(object):
        NEW = 1
        IN_PROGRESS = 2
        DONE = 3

    status = get_random_item(Status)
    assert isinstance(status, int)


# Generated at 2022-06-23 21:56:57.434763
# Unit test for method randints of class Random
def test_Random_randints():
    random = Random()
    assert random.randints() == [39, 99, 74]
    assert random.randints(amount=5, a=2, b=5) == [5, 4, 3, 3, 3]

# Generated at 2022-06-23 21:56:59.507906
# Unit test for method randints of class Random
def test_Random_randints():
    assert random.randints(amount=7) == [70, 71, 74, 87, 74, 92, 74]



# Generated at 2022-06-23 21:57:00.146411
# Unit test for method randstr of class Random
def test_Random_randstr():
    pass

# Generated at 2022-06-23 21:57:01.051929
# Unit test for constructor of class Random
def test_Random():
    assert random.randint(1, 10) <= 10

# Generated at 2022-06-23 21:57:05.120630
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random = Random()
    str1 = random.generate_string(str_seq="abc")
    str2 = random.generate_string(str_seq="123")
    assert any([i in "abc" for i in str1])
    assert any([i in "123" for i in str2])

# Generated at 2022-06-23 21:57:09.025741
# Unit test for method randints of class Random
def test_Random_randints():
    # arrange
    rnd = Random()

    # act
    randints_array = rnd.randints(amount=10, a=1, b=100)

    # assert
    for rand_int in randints_array:
        assert rand_int in range(1, 101)



# Generated at 2022-06-23 21:57:11.322842
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    gender = get_random_item(Gender)
    assert isinstance(gender, Gender)

# Generated at 2022-06-23 21:57:22.046037
# Unit test for method randstr of class Random
def test_Random_randstr():
    a = random.randstr()
    b = random.randstr(unique=True)
    c = random.randstr(unique=False)
    # print(a)
    # print(b)
    # print(c)
    # print(len(a))
    # print(len(b))
    # print(len(c))
    assert len(a) <= 128
    assert len(b) == 32
    assert len(c) <= 128
    # print(a)
    # print(b)
    # print(c)
    assert isinstance(a, str)
    assert isinstance(b, str)
    assert isinstance(c, str)


if __name__ == '__main__':
    test_Random_randstr()

# Generated at 2022-06-23 21:57:26.015243
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test method ``generate_string()`` of class ``Random()``.
    """
    assert len(random.generate_string('0123456789')) == 10
    assert len(random.generate_string('abcd')) == 10
    assert len(random.generate_string('abcd', length=6)) == 6



# Generated at 2022-06-23 21:57:30.477873
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    rnd = Random()
    assert len(rnd.generate_string('a')) == 10
    assert len(rnd.generate_string('a', 5)) == 5



# Generated at 2022-06-23 21:57:34.034544
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

        def __str__(self):
            return 'Color: {}'.format(self.name)

    assert isinstance(get_random_item(Color), Color)



# Generated at 2022-06-23 21:57:36.809693
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test method urandom.
    """
    rnd = Random()
    rnd.random()
    rnd.urandom(5)

# Generated at 2022-06-23 21:57:38.258124
# Unit test for constructor of class Random
def test_Random():
    """Test constructor of class Random()."""
    assert Random() is not None



# Generated at 2022-06-23 21:57:41.944117
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Currencies, Gender

    curr = get_random_item(Currencies)
    assert isinstance(curr, Currencies)

    gender = get_random_item(Gender)
    assert isinstance(gender, Gender)

# Generated at 2022-06-23 21:57:47.698637
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    assert isinstance(
        Random().uniform(1, 100),
        float
    )
    assert Random().uniform(0, 1) < 1
    # Exception should be raised in this case
    try:
        assert round(Random().uniform(0, 3.2, 1), 1) != 1.5
    except TypeError:
        pass

# Generated at 2022-06-23 21:57:52.740223
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random.

    :Return:
        True if all assertions passed
    """
    data = Random().urandom(12)

    # test by length
    assert len(data) == 12

    # test by type
    assert isinstance(data, bytes)

    return True

# Generated at 2022-06-23 21:57:54.544979
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code.isalpha()

# Generated at 2022-06-23 21:57:57.089382
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(16) == os.urandom(16)

# Generated at 2022-06-23 21:57:59.860134
# Unit test for function get_random_item
def test_get_random_item():
    # pylint: disable=protected-access
    assert get_random_item(random_module._randbelow.__code__)
    # pylint: enable=protected-access

# Generated at 2022-06-23 21:58:03.179153
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test Random.urandom() method.
    """
    result = Random().urandom(10)
    assert result
    assert len(result) == 10
    assert isinstance(result, bytes)

# Generated at 2022-06-23 21:58:06.940292
# Unit test for method uniform of class Random
def test_Random_uniform():
    precision = 15
    a = 100.0
    b = 123.45
    res = Random().uniform(a, b, precision)
    assert res >= a
    assert res < b
    assert round(res, precision) == res

# Generated at 2022-06-23 21:58:08.549066
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    assert len(Random().urandom(20)) == 20

# Generated at 2022-06-23 21:58:10.094985
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    r = rnd.randints(amount=10)
    assert len(r) == 10

# Generated at 2022-06-23 21:58:14.165967
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random"""
    string = Random().generate_string('azertyuiopasdf')
    assert len(string) <= 10
    assert string.isalpha()
    assert string.islower()

    string = Random().generate_string('QWERTYUIOPASDF', 5)
    assert len(string) == 5
    assert string.isalpha()
    assert string.isupper()



# Generated at 2022-06-23 21:58:16.893859
# Unit test for method randstr of class Random
def test_Random_randstr():
    str_random = Random().randstr(length=5)
    assert_msg = "method 'randstr' returns not a string"
    assert isinstance(str_random, str), assert_msg
    assert_msg = "method 'randstr' returns a string which is not equal 5"
    assert len(str_random) == 5, assert_msg

# Generated at 2022-06-23 21:58:23.795002
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Assert that the method throws an exception
    # if the same values are passed for the argument char and digit
    rnd = Random()
    rnd.seed(1234)

    # Generate custom code
    code = rnd.custom_code(mask='@###', char='@', digit='#')

    # Check that the code is a string
    assert isinstance(code, str)

    # Check that the code has a length of 5 characters
    assert len(code) == 5



# Generated at 2022-06-23 21:58:27.920819
# Unit test for method uniform of class Random
def test_Random_uniform():
    import pytest
    r = Random()
    l = list(r.uniform(50, 51) for _ in range(10))
    assert min(l) >= 50
    assert max(l) < 51
    assert all(isinstance(x, float) for x in l)



# Generated at 2022-06-23 21:58:33.726888
# Unit test for constructor of class Random
def test_Random():
    """Test for constructor of class Random."""
    r = Random(42)
    assert r.randint(1, 2) == 1
    assert r.uniform(0.0, 1.0) == 0.6394267984578837
    assert r.randstr() == 'd3gco3ref0ljf8id'


# Unit tests for method ``randints()``

# Generated at 2022-06-23 21:58:40.054738
# Unit test for constructor of class Random
def test_Random():

    # amount
    assert len(Random().randints(amount=3)) == 3

    # a
    assert Random().randints(amount=3, a=3)[0] == 3

    # b
    assert Random().randints(amount=3, b=10)[0] < 10

    # char
    assert Random().custom_code(char='T').startswith('T')

    # digit
    assert Random().custom_code(digit='T').endswith('T')

    # mask
    assert Random().custom_code(mask='###').startswith('###')

    # unique
    assert Random().randstr(unique=True)

    # length
    assert len(Random().randstr()) == 16



# Generated at 2022-06-23 21:58:48.780013
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random_1 = Random()
    assert isinstance(random_1.generate_string('abc', 20), str)
    assert isinstance(random_1.generate_string('123', 20), str)
    assert len(random_1.generate_string('abc', 20)) == 20
    random_2 = Random()
    assert isinstance(random_2.generate_string('abc', 20), str)
    assert isinstance(random_2.generate_string('123', 20), str)
    assert len(random_2.generate_string('abc', 20)) == 20

# Generated at 2022-06-23 21:58:50.339999
# Unit test for method urandom of class Random
def test_Random_urandom():
    random = Random()
    assert random.urandom(30)

# Generated at 2022-06-23 21:58:55.237933
# Unit test for method randints of class Random
def test_Random_randints():
    rand = Random()
    assert len(rand.randints(amount=0)) == 0
    assert len(rand.randints(amount=10)) == 10
    assert len(rand.randints(amount=30, a=0, b=999)) == 30
    for n in rand.randints():
        assert n > 0 and n < 100



# Generated at 2022-06-23 21:58:59.823185
# Unit test for constructor of class Random
def test_Random():
    """Unit-test for Random."""
    r = Random()
    assert isinstance(r.randint(1, 10), int)
    assert isinstance(r.choice(range(10)), int)
    assert isinstance(r.randints(10), list)



# Generated at 2022-06-23 21:59:00.943474
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random().urandom(16), bytes)

# Generated at 2022-06-23 21:59:04.325909
# Unit test for method randints of class Random
def test_Random_randints():
    numbers = Random().randints(10)
    assert isinstance(numbers, list)
    assert len(numbers) == 10
    for number in numbers:
        assert isinstance(number, int)
        assert 1 <= number <= 100



# Generated at 2022-06-23 21:59:06.036922
# Unit test for function get_random_item
def test_get_random_item():
    class EnumExample(object):
        value1 = 1
        value2 = 2
        value3 = 3

    assert get_random_item(EnumExample) in (1, 2, 3)

# Generated at 2022-06-23 21:59:12.629913
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(random.randints(), list)
    assert isinstance(random.randints(3), list)
    assert random.randints(3) == [76, 91, 21]
    assert random.randints(amount=3) == [76, 91, 21]
    assert random.randints(amount=3, a=1, b=10) == [6, 3, 3]
    assert random.randints(3, 1, 10) == [6, 3, 3]



# Generated at 2022-06-23 21:59:16.900289
# Unit test for method urandom of class Random
def test_Random_urandom():
    """ Unit test for method urandom of class Random.
    """
    my_random = Random()
    myresult = my_random.urandom(8)
    testresult = b'\x01\x14\x17\x1c\x0f\x13\x07\x0c'
    assert myresult == testresult

# Generated at 2022-06-23 21:59:20.128248
# Unit test for constructor of class Random
def test_Random():
    randomRandint = Random()
    assert randomRandint.randint(1, 2) == random_module.randint(1, 2)
    assert randomRandint.randint(1, 100) == random_module.randint(1, 100)

# Generated at 2022-06-23 21:59:21.945658
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Create the object of the class Random
    r = Random()
    # Create sample of size 16
    sample = r.urandom(16)
    # Check the size of sample
    assert len(sample) == 16


# Generated at 2022-06-23 21:59:23.333932
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    random = Random()
    assert random.randstr()

# Generated at 2022-06-23 21:59:25.771193
# Unit test for method urandom of class Random
def test_Random_urandom():
    random = Random()
    print(random.urandom())



# Generated at 2022-06-23 21:59:34.704114
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    rnd = Random()

    @random.custom_code
    class Code(random.Generator):
        pass

    # str_seq = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    # print(rnd.generate_string(str_seq, 10))

    # res = Code().code_3
    # print(res)
    res = Code()
    print(res.code_3)


if __name__ == '__main__':
    test_Random_generate_string()

# Generated at 2022-06-23 21:59:36.950599
# Unit test for method randstr of class Random
def test_Random_randstr():
    randstr = random.randstr()
    assert len(randstr) <= 128
    assert isinstance(randstr, str)

# Generated at 2022-06-23 21:59:42.702729
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string('a', 0) == ''
    assert Random().generate_string('a', 1) == 'a'
    assert Random().generate_string('abc', 2) in ('ab', 'bc', 'ca')
    assert Random().generate_string('abcd', 2) in ('ab', 'bc', 'cd', 'da')
    assert len(Random().generate_string('a', 10)) == 10
    assert len(Random().generate_string('abcdefghijklmnopqrstuvwxyz', 10)) == 10



# Generated at 2022-06-23 21:59:46.742972
# Unit test for function get_random_item
def test_get_random_item():
    class TestEnum(object):
        A = 1
        B = 2
        C = 3
        D = 4

    assert get_random_item(TestEnum) in (1, 2, 3, 4)

# Generated at 2022-06-23 21:59:49.987374
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    test_list = ['abcdefghijklmnopqrstuvwxyz', '0123456789']
    r = Random()
    for item in test_list:
        r.generate_string(item) # Does not raise exception


# Generated at 2022-06-23 21:59:57.532651
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == 'B652'
    assert random.custom_code(mask='@###') == 'B652'
    assert random.custom_code(mask='@@###') == 'BJ652'
    assert random.custom_code(mask='@@##') == 'CS65'
    assert random.custom_code(mask='A###') == 'A652'
    assert random.custom_code(mask='@###', char='B', digit='#') == 'B652'
    assert random.custom_code(mask='@###', char='@', digit='#') == 'B652'

# Generated at 2022-06-23 22:00:07.922902
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints(amount=20, a=1, b=10)) == 20
    assert len(random.randints(amount=50, a=1, b=10)) == 50
    assert len(random.randints(amount=80, a=1, b=10)) == 80
    assert len(random.randints(amount=100, a=1, b=10)) == 100
    assert len(random.randints(amount=130, a=1, b=10)) == 130
    assert len(random.randints(amount=500, a=1, b=10)) == 500
    assert len(random.randints(amount=700, a=1, b=10)) == 700
    assert len(random.randints(amount=1000, a=1, b=10)) == 1000


# Generated at 2022-06-23 22:00:18.441256
# Unit test for method urandom of class Random
def test_Random_urandom():
    from mimesis.typing import Bytes
    from mimesis.exceptions import SizeOutOfRange

    rnd = Random()

    size = None
    output: Bytes = rnd.urandom(size)
    assert len(output) > 0

    size = -4
    with pytest.raises(SizeOutOfRange):
        rnd.urandom(size)

    size = -20
    with pytest.raises(SizeOutOfRange):
        rnd.urandom(size)

    size = 'test'
    with pytest.raises(TypeError):
        rnd.urandom(size)

    size = '899'
    with pytest.raises(TypeError):
        rnd.urandom(size)



# Generated at 2022-06-23 22:00:25.609123
# Unit test for method urandom of class Random
def test_Random_urandom():
    print('Testing new added method urandom()\n'
          'of the class Random()...')
    rnd = Random()
    print('Type of the result: ', type(rnd.urandom()))
    print('Result: ', rnd.urandom())
    check = input('Do you want to check this method?\n'
                  'If yes, please type Y: ')
    while check.lower() == 'y':
        print('Generate new bytes: ', rnd.urandom())
        check = input('Do you want to check this method?\n'
                      'If yes, please type Y: ')



# Generated at 2022-06-23 22:00:29.037054
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # check if a code is generated as we expect
    r = random.custom_code('@###', '@')
    assert isinstance(r, str)
    assert r[0].isupper()
    assert r[1:].isdigit()
    # check if a code is generated as we expect
    r = random.custom_code('@### @###', '@', '!')
    assert isinstance(r, str)

# Generated at 2022-06-23 22:00:39.887220
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test randstr method."""
    rand = Random()

    res = rand.randstr(unique=True)
    assert len(res) == 32
    assert res == 'd5d5e5de55c6432a8b77c2bb3d6f68e6'

    res = rand.randstr(unique=False)
    assert len(res) == 16
    assert res == 'uXCycUj7VhEZRpJb'

    res = rand.randstr(unique=False, length=32)
    assert len(res) == 32
    assert res == 'jKQ2mz7wPjToOQLVGDcp9XlQtF7v16Oj'

    res = rand.randstr(unique=False, length=0)
    assert len(res) == 16


# Generated at 2022-06-23 22:00:42.083505
# Unit test for method uniform of class Random
def test_Random_uniform():
    res = random.uniform(0, 4, precision=1)
    assert 0 <= res < 4
    assert(isinstance(res, float))

# Generated at 2022-06-23 22:00:46.961908
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    string = random.randstr(length=None)
    string_1 = random.randstr(length=10)
    assert isinstance(string, str)
    assert isinstance(string_1, str)
    assert len(string) >= 16
    assert len(string) <= 128
    assert len(string_1) == 10

# Generated at 2022-06-23 22:00:49.413910
# Unit test for function get_random_item
def test_get_random_item():
    class MyEnum:
        A = 1
        B = 2
        C = 3

    assert get_random_item(MyEnum) in (1, 2, 3)

# Generated at 2022-06-23 22:00:53.284315
# Unit test for method randints of class Random
def test_Random_randints():
    result = random.randints(10, 10, 81)
    assert len(result) == 10
    assert isinstance(result, list)
    assert all(i > 9 and i < 82 for i in result)

# Generated at 2022-06-23 22:01:00.115152
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test custom_code.

    Code style:
    AAA123
    A1A2A3
    1AA12
    """
    #  Test cases
    masks = (('@###', '@', '#'), ('@@@##', '@', '#'), ('#@@@', '#', '@'))

    #  Test
    for mask in masks:
        assert len(random.custom_code(*mask)) == len(mask[0])



# Generated at 2022-06-23 22:01:02.039709
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = random.uniform(1, 2, precision=2)
    assert 1 <= r < 2
    assert isinstance(r, float)

# Generated at 2022-06-23 22:01:07.448585
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    r_list = r.randints(10, 1, 100)
    assert len(r_list) == 10
    assert len(r.randints(0, 1, 100)) == 0
    assert r.randints(0, 1, 100) == []
    assert r.randints(1, 1, 100) == [44]



# Generated at 2022-06-23 22:01:11.474175
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    expected = {
        'letters': 'ssssssssss',
        'digits': '6666666666',
        'hex_digits': 'dddddddddd'
    }
    for key, value in expected.items():
        assert Random(version=2).generate_string(key) == value



# Generated at 2022-06-23 22:01:13.252057
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    for _ in range(100):
        r.custom_code()


# Generated at 2022-06-23 22:01:16.950508
# Unit test for method randints of class Random
def test_Random_randints():
    _rand = Random()
    _test_list = _rand.randints(1000)
    assert len(_test_list) == 1000
    assert all(1 <= i <= 100 for i in _test_list)



# Generated at 2022-06-23 22:01:19.417163
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = random.Random()
    rnd.custom_code()

if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-23 22:01:23.054851
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(random.randstr()) == 36
    assert len(random.randstr(length=None)) >= 16
    assert len(random.randstr(length=None)) <= 128
    assert len(random.randstr(length=36)) == 36
    assert random.randstr(unique=True) != random.randstr(unique=True)


# Generated at 2022-06-23 22:01:27.523561
# Unit test for function get_random_item
def test_get_random_item():
    class Animal(object):
        DOG = "dog"
        CAT = "cat"

    assert get_random_item(Animal) in [Animal.DOG, Animal.CAT]


if __name__ == '__main__':
    test_get_random_item()