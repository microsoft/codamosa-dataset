

# Generated at 2022-06-23 21:51:34.647493
# Unit test for function get_random_item
def test_get_random_item():

    assert isinstance(get_random_item(Language), Language)
    assert isinstance(get_random_item(Language, random_module), Language)
    assert isinstance(get_random_item(Language, Random()), Language)

    assert isinstance(get_random_item(Person.Gender), Person.Gender)

    assert isinstance(get_random_item(Text.HtmlTags), Text.HtmlTags)

# Generated at 2022-06-23 21:51:42.450987
# Unit test for constructor of class Random
def test_Random():
    import random
    from hypothesis import given, strategies as st
    from . import utils

    @given(st.integers(min_value=1, max_value=100))
    @utils.settings
    def test_randints(a: int, b: int, seed: int):
        with utils.assert_raises(ValueError):
            random.randints(amount=0, a=a, b=b)

        with utils.assert_raises(ValueError):
            random.randints(amount=-1, a=a, b=b)

        with utils.assert_raises(ValueError):
            random.randints(amount=-5, a=a, b=b)



# Generated at 2022-06-23 21:51:44.065444
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    _random = Random()
    urandom = _random.urandom()
    assert len(urandom) > 0



# Generated at 2022-06-23 21:51:53.748513
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code of class Random."""
    r = Random()
    code = r.custom_code()
    assert isinstance(code, str), 'Result is not a string.'
    assert len(code) == 4, 'Length of code not equal to 4.'
    code = r.custom_code(mask='@#####')
    assert len(code) == 6, 'Length of code not equal to 6.'
    code = r.custom_code(mask='@@####@@####')
    assert len(code) == 12, 'Length of code not equal to 12.'
    code = r.custom_code(mask='@#############')
    assert len(code) == 13, 'Length of code not equal to 13.'
    code = r.custom_code(mask='@#############', char='*')
    assert len(code)

# Generated at 2022-06-23 21:52:00.980434
# Unit test for function get_random_item
def test_get_random_item():
    class Day(object):
        SUNDAY = 0
        MONDAY = 1
        TUESDAY = 2
        WEDNESDAY = 3
        THURSDAY = 4
        FRIDAY = 5
        SATURDAY = 6

    assert(get_random_item(Day) in [
        Day.SUNDAY,
        Day.MONDAY,
        Day.TUESDAY,
        Day.WEDNESDAY,
        Day.THURSDAY,
        Day.FRIDAY,
        Day.SATURDAY])

# Generated at 2022-06-23 21:52:03.528293
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code('@###@')

    assert isinstance(code, str)
    assert len(code) == 5


# Generated at 2022-06-23 21:52:05.777048
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    result = rnd.randints()
    assert isinstance(result, list)
    assert len(result) == 3

# Generated at 2022-06-23 21:52:16.756913
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function ``get_random_item()``."""
    # Create custom enum
    Enum = type('Enum', (object,), {
        '__getattr__': lambda s, n: n,
        '__iter__': lambda s: iter([n for n in s.__dict__.keys()
                                    if n[:2] != '__']),
    })
    color_enum = Enum()
    color_enum.RED = 1
    color_enum.GREEN = 2
    color_enum.BLUE = 3
    color_enum.PURPLE = 4

    # Random ints
    assert get_random_item(list(range(10))) in range(10)

    # Random keys of dict

# Generated at 2022-06-23 21:52:21.741480
# Unit test for function get_random_item
def test_get_random_item():
    class Enum(int, enum.Enum):
        ONE = 1
        TWO = 2
        THREE = 3

    random_objects = [
        random_module.Random(),
        Random(),
        None,
    ]

    for r in random_objects:
        for _ in range(1000):
            assert isinstance(get_random_item(Enum, r), Enum)

# Generated at 2022-06-23 21:52:23.160535
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    s = Random().generate_string('ABDAHKK')
    assert len(s) <= 10
    assert all(i.upper() in 'ABDAHKK' for i in s)

# Generated at 2022-06-23 21:52:24.629861
# Unit test for method urandom of class Random
def test_Random_urandom():
    rnd = Random()
    assert isinstance(rnd.urandom(), bytes)

# Generated at 2022-06-23 21:52:28.016273
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random_string = random.generate_string('1abc')
    assert isinstance(random_string, str)
    assert random_string.isalpha() or random_string.isdigit()

# Generated at 2022-06-23 21:52:32.774955
# Unit test for method randints of class Random
def test_Random_randints():
    faker = Random()
    amount = faker.randint(1)
    a = faker.randint(1)
    b = faker.randint(2)
    value = faker.randints(amount, a, b)
    assert len(value) == amount



# Generated at 2022-06-23 21:52:41.281190
# Unit test for function get_random_item
def test_get_random_item():
    import pytest
    from mimesis.data import CitizenshipCode, Gender

    enum = Gender.FEMALE

    assert get_random_item(enum) in Gender
    assert get_random_item(enum) in Gender

    enum = CitizenshipCode.US

    assert get_random_item(enum) in CitizenshipCode
    assert get_random_item(enum) in CitizenshipCode

    # Check that custom random object is working
    assert get_random_item(enum, rnd=random) in CitizenshipCode
    assert get_random_item(enum, rnd=random) in CitizenshipCode

# Generated at 2022-06-23 21:52:44.900747
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Check the method urandom of the class Random."""
    assert isinstance(random.urandom(), bytes)



# Generated at 2022-06-23 21:52:52.558003
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method randints of class Random."""
    rnd = Random()
    for i in range(10):
        randint_tuple = rnd.randints(amount=10, a=1, b=10)
        assert isinstance(randint_tuple, list)
        assert len(randint_tuple) == 10
        assert min(randint_tuple) >= 1
        assert max(randint_tuple) <= 10



# Generated at 2022-06-23 21:52:53.564051
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert not Random().urandom()

# Generated at 2022-06-23 21:53:04.616025
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    import pytest

    class TestEnum(enum.Enum):
        test_a = 1
        test_b = 2

    assert get_random_item(TestEnum) in [TestEnum.test_a, TestEnum.test_b]
    assert get_random_item(TestEnum, rnd=Random()) in [TestEnum.test_a, TestEnum.test_b]

    with pytest.raises(ValueError):
        get_random_item(TestEnum, rnd=[])

    assert random.choice([TestEnum.test_a, TestEnum.test_b]) in [TestEnum.test_a, TestEnum.test_b]

# Generated at 2022-06-23 21:53:10.497404
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    custom_code = random.custom_code('@@###', char='@', digit='#')
    assert len(custom_code) == 5
    assert custom_code[0] in string.ascii_uppercase
    assert custom_code[1] in string.ascii_uppercase
    assert custom_code[2] in string.digits
    assert custom_code[3] in string.digits
    assert custom_code[4] in string.digits

# Generated at 2022-06-23 21:53:14.086385
# Unit test for function get_random_item
def test_get_random_item():
    # Create new custom random object
    rnd = Random()
    # Get random item from Colors enum
    random_color = get_random_item(Colors, rnd)
    for color in Colors:
        # Compare this item with an item from enum
        if random_color == color:
            # If equal, then everything is ok
            assert random_color == color



# Generated at 2022-06-23 21:53:19.340383
# Unit test for method uniform of class Random
def test_Random_uniform():
    _min = -100.0
    _max = 100.0
    _precision = 50

    rnd = random.Random()  # seed = None
    random_number = rnd.uniform(_min, _max, _precision)
    assert (_min <= random_number and random_number < _max)

# Generated at 2022-06-23 21:53:24.040858
# Unit test for method randints of class Random
def test_Random_randints():
    _r = Random()
    assert _r.randint(1, 2) == 1 or _r.randint(1, 2) == 2
    assert isinstance(_r.randints(10, 1, 2)[0], int)
    assert len(_r.randints(10, 1, 2)) == 10
    assert _r.randints(0, 1, 2) == []


# Generated at 2022-06-23 21:53:28.863248
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random(20)
    custom_code_1 = rnd.custom_code('##-###')
    custom_code_2 = rnd.custom_code('@@-@@@')
    custom_code_3 = rnd.custom_code('@##-@@@')
    custom_code_4 = rnd.custom_code('@@@-@##', '@', '#')
    assert custom_code_1 == '99-985'
    assert custom_code_2 == 'SV-SZO'
    assert custom_code_3 == '917-SZO'
    assert custom_code_4 == 'SZO-917'
    try:
        rnd.custom_code('@@-@@@', '@', '@')
    except ValueError:
        pass

# Generated at 2022-06-23 21:53:39.489391
# Unit test for function get_random_item
def test_get_random_item():
    """"Unit test for function get_random_item"""

    class Enum(object):
        """Enum class."""
        def __init__(self, items: List[Any]) -> None:
            """Initialize.

            :param items: List of items.
            """
            self._items = items

        def __iter__(self) -> Any:
            """Generator of enum.

            :return: Iterator.
            """
            for item in self._items:
                yield item

    enum_obj = Enum([1, 2, 3])
    rnd_obj = Random()
    result1 = get_random_item(enum_obj, rnd=rnd_obj)
    result2 = get_random_item(enum_obj, rnd=None)
    assert result1 in enum_obj

# Generated at 2022-06-23 21:53:40.910711
# Unit test for method randints of class Random
def test_Random_randints():
    lst = random.randints(10, 1, 100)
    assert isinstance(lst, list)



# Generated at 2022-06-23 21:53:42.806986
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom()

# Generated at 2022-06-23 21:53:44.786855
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() == Random().custom_code()
    assert Random().custom_code('@@##') == Random().custom_code('@@##')

# Generated at 2022-06-23 21:53:46.815522
# Unit test for constructor of class Random
def test_Random():
    _random = Random()
    assert isinstance(_random, Random)


# Generated at 2022-06-23 21:53:50.866914
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    r.seed(1234567890)
    lst = r.randints(amount=5, a=1, b=10)
    assert lst == [1, 9, 1, 6, 5]



# Generated at 2022-06-23 21:53:57.063415
# Unit test for constructor of class Random
def test_Random():
    # The constructor is fairly simple so I can test it.
    # For testing of methods of this class I need to write
    # a separate test file because of it is quite difficult
    # to cover each possible case here.
    rnd = Random()
    assert isinstance(rnd, Random)
    assert not isinstance(rnd, random_module.Random)



# Generated at 2022-06-23 21:53:59.148408
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method ``custom_code`` of class ``Random``."""

    r = Random()
    res = r.custom_code('@###')
    assert res, res

# Generated at 2022-06-23 21:54:03.843597
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method randints."""
    from mimesis.compat import randint

    r = randint(1, 10)
    assert r >= 1 and r <= 10

    r = randint()
    assert r >= 1 and r <= 100



# Generated at 2022-06-23 21:54:11.728426
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    res = Random().custom_code()
    assert len(res) == 4
    assert Random().custom_code()[3].isdigit()
    assert Random().custom_code('@##', '@', '#')[2].isdigit()
    assert Random().custom_code('@##', '@', '#')[3].isdigit()
    assert Random().custom_code('@@##', '@', '#')[4].isdigit()
    assert Random().custom_code('@@####', '@', '#')[6].isdigit()
    assert Random().custom_code('@@####', '@', '#')[5].isdigit()
    assert Random().custom_code('@@####', '@', '#')[4].isdigit()

# Generated at 2022-06-23 21:54:19.540613
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random.
    Args:
        None
    Returns:
        None
    Raises:
        None
    Examples:
        >>> test_Random_custom_code()
    """
    from mimesis.tests.data.test_random import TestRandomCustomCode

    test_obj = TestRandomCustomCode()

    for i in range(len(test_obj.any_code_mask)):
        code = random.custom_code(test_obj.any_code_mask[i],
                                  test_obj.any_code_mask_char[i],
                                  test_obj.any_code_mask_digit[i])
        assert  len(code) == len(test_obj.any_code_mask[i])


# Generated at 2022-06-23 21:54:28.282615
# Unit test for constructor of class Random
def test_Random():
    assert(isinstance(Random().random(), float))
    assert(isinstance(Random().randint(1, 10), int))
    assert(isinstance(Random().randints(10, 1, 10), list))
    assert(isinstance(Random().uniform(1, 10, 2), float))
    assert(isinstance(Random().urandom(1), bytes))
    assert(isinstance(Random().randstr(unique=True), str))
    assert(isinstance(Random().generate_string('abc', length=10), str))
    assert(isinstance(Random().custom_code(mask='@###', char='@', digit='#'), str))

# Generated at 2022-06-23 21:54:29.425044
# Unit test for method randstr of class Random
def test_Random_randstr():
    string = random.randstr()
    assert string



# Generated at 2022-06-23 21:54:35.059157
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test custom random code."""
    code = random.custom_code()
    assert len(code) == 4

    code = random.custom_code(mask="@@@")
    assert len(code) == 3

    code = random.custom_code(mask="@@####@")
    assert len(code) == 7

    code = random.custom_code(mask="###-###")
    assert len(code) == 7

    code = random.custom_code(mask="##-###")
    assert len(code) == 6

    code = random.custom_code(mask="##-#####")
    assert len(code) == 8

    code = random.custom_code(mask="@### @##")
    assert len(code) == 8

    code = random.custom_code(mask="@#### @###")
    assert len

# Generated at 2022-06-23 21:54:39.162960
# Unit test for function get_random_item
def test_get_random_item():
    # pylint: disable=import-outside-toplevel
    from mimesis.enums import Gender
    gender = get_random_item(enum=Gender, rnd=random)
    assert gender in list(Gender)

# Generated at 2022-06-23 21:54:45.005899
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for the method ``randints()`` of class ``Random()``."""
    assert isinstance(random.randints(3, 1, 100), list)
    assert len(random.randints(3, 1, 100)) == 3
    assert all(1 <= el <= 100 for el in random.randints(3, 1, 100))
    assert all(isinstance(el, int) for el in random.randints(3, 1, 100))

# Generated at 2022-06-23 21:54:54.976579
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code() != r.custom_code()
    assert r.custom_code(mask='###') != r.custom_code(mask='###')
    assert r.custom_code(mask='@###') != r.custom_code(mask='@###')
    assert r.custom_code(mask='###', char='@', digit='#') != r.custom_code(mask='###', char='@', digit='#')
    assert r.custom_code(mask='@###', char='@', digit='#') != r.custom_code(mask='@###', char='@', digit='#')

if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-23 21:54:59.362587
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(random.custom_code()) == 4
    assert len(random.custom_code('@###')) == 4
    assert random.custom_code('@##').isalpha()
    assert random.custom_code('###').isdigit()
    assert random.custom_code('@##', 'A', 'a').isalpha()
    assert random.custom_code('###', 'B', 'b').isdigit()

# Generated at 2022-06-23 21:55:08.423488
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random.

    :return: None.
    """
    rnd = random_module.Random()
    obj = Random()
    a = 1.0
    b = 10.0

    def test(precision: int = 15):
        """Test function.

        :param precision: Rounding precision.
        """
        r = obj.uniform(a, b, precision)
        rnd.uniform(a, b)
        if r < a or r > b:
            raise ValueError(
                'The result is outside the specified range!')

    for i in range(1, 100):
        test(i)

# Generated at 2022-06-23 21:55:10.965227
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    custom_code = Random().custom_code("How are you, Mr. @####### ?",
    char="#", digit="@")
    assert len(custom_code) == 19

# Generated at 2022-06-23 21:55:18.008771
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Generate custom code
    random = Random()
    code = random.custom_code()

    assert len(code) == 4
    assert code[0] in string.ascii_uppercase
    for i in range(1, len(code)):
        assert code[i] in string.digits

    # Generate custom code
    code = random.custom_code('###')

    assert len(code) == 3
    for i in range(0, len(code)):
        assert code[i] in string.digits

    # Generate custom code
    code = random.custom_code('@@@')

    assert len(code) == 3
    for i in range(0, len(code)):
        assert code[i] in string.ascii_uppercase

# Generated at 2022-06-23 21:55:23.952608
# Unit test for constructor of class Random
def test_Random():
    """Test ``Random()`` class.

    There are implemented unit tests for all methods of class ``Random()``.

    Testing of the methods which return a single integer value
    is performed by checking the simple condition:
        the method must return a value that is contained within certain limits.

    Testing of the methods which return a sequence of values
    is performed by checking the simple condition:
        the method must return a value that is a list of integers.

    Testing of the method ``randstr()`` is performed by checking
    the simple condition:
        the method must return a value that is a string and its length
        is contained within certain limits.

    Testing of the method ``custom_code()`` is performed by checking
    the simple condition:
        the method must return a value that is a string
        with the length from 2 to 5 characters.

    """

    m = Random()


# Generated at 2022-06-23 21:55:31.361403
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    r.seed(0)
    test = []
    for i in range(100):
        test.append(r.generate_string(string.ascii_letters, 6))
    control_set = {'oqzUVa', 'dQbpyR', 'IYgYKj', 'LlGKmq', 'qPqmPU'}
    assert control_set == set(test)

# Generated at 2022-06-23 21:55:39.674101
# Unit test for method randstr of class Random
def test_Random_randstr():
    random_obj = Random()
    assert random_obj.randstr() is not random_obj.randstr()
    assert random_obj.randstr(unique=True) is not random_obj.randstr(unique=True)
    assert random_obj.randstr(length=20) != random_obj.randstr(length=20)
    assert len(random_obj.randstr(length=20)) == 20
    assert random_obj.randstr(length=20) != random_obj.randstr(length=20)
    assert len(random_obj.randstr(length=100)) == 100
    assert len(random_obj.randstr(unique=True)) == 32

# Generated at 2022-06-23 21:55:48.184647
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(random.generate_string('qwertyuiopasdfghjklzxcvbnm')) == 10
    assert len(random.generate_string('qwertyuiopasdfghjklzxcvbnm',7)) == 7
    assert len(random.generate_string('56784')) == 10
    assert len(random.generate_string('56784',7)) == 7
    assert random.generate_string('qwertyuiopasdfghjklzxcvbnm',0) == ''
    assert random.generate_string('qwertyuiopasdfghjklzxcvbnm',-3) == ''
    assert random.generate_string('56784',0) == ''
    assert random.generate_string('56784',-3) == ''

# Generated at 2022-06-23 21:55:49.985508
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test the method custom_code of the class Random."""
    mask = '@###'
    char = '@'
    digit = '#'
    try:
        assert len(Random().custom_code(mask, char, digit)) == len(mask)
    except ValueError:
        pass

# Generated at 2022-06-23 21:55:51.609631
# Unit test for method urandom of class Random
def test_Random_urandom():
    data = Random().urandom(10)
    assert len(data) == 10

# Generated at 2022-06-23 21:55:54.166938
# Unit test for method randints of class Random
def test_Random_randints():
    a, b = -8, 10
    r = Random.randints(a=a, b=b)
    assert r[0] >= a and r[0] <= b

# Generated at 2022-06-23 21:56:03.174027
# Unit test for constructor of class Random
def test_Random():
    """Test for custom random class."""
    assert len(Random().randstr()) == 16
    assert len(Random().randstr(length=5)) == 5
    assert len(Random().randstr(length=24)) == 24
    assert Random().randstr(length=4, unique=True) \
        != Random().randstr(length=4, unique=True)
    assert len(Random().custom_code()) == 4
    assert len(Random().custom_code(mask='@@@@')) == 4
    assert len(Random().custom_code(mask='@@@')) == 3
    assert len(Random().custom_code(mask='@')) == 1
    assert len(Random().custom_code(mask='@@@@@')) == 5
    assert len(Random().custom_code(mask='@@@@@@')) == 6

# Generated at 2022-06-23 21:56:06.348206
# Unit test for method urandom of class Random
def test_Random_urandom():
    random = Random()
    random_bytes = random.urandom(4)
    assert len(random_bytes) == 4
    assert isinstance(random_bytes, bytes)

# Generated at 2022-06-23 21:56:09.363717
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    # No seeds, no random values
    rnd = Random()

    # Seeds are equal
    rnd.seed(42)
    rnd2 = Random(42)

    assert rnd2.randint(0, 10) == rnd.randint(0, 10)

    # The same with seeds
    rnd3 = Random(42)
    assert rnd3.randint(0, 10) == rnd.randint(0, 10)

# Generated at 2022-06-23 21:56:13.820723
# Unit test for method randstr of class Random
def test_Random_randstr():
    length = 16

    # Test for unique = True
    value = Random().randstr(unique=True)
    assert len(value) == 32

    # Test for length = 16
    value = Random().randstr(length=length)
    assert len(value) == length

    # Test for unique = True and length = 16
    value = Random().randstr(unique=True, length=length)
    assert len(value) == length

# Generated at 2022-06-23 21:56:15.109246
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    get_random_item(Gender)

# Generated at 2022-06-23 21:56:18.026059
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3
    assert len(Random().randints(a=3, b=9)) == 3
    assert len(Random().randints(amount=1)) == 1

# Generated at 2022-06-23 21:56:19.381550
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@@@#') == 'K531'

# Generated at 2022-06-23 21:56:27.124947
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    expected_digits = "11146301"
    expected_letters = "wWpVuNDZ"

    digits_string = "0123456789"
    letters_string = "wWpVuNDZ"
    rand_string_letters = random.generate_string(letters_string, 8)
    rand_string_digits = random.generate_string(digits_string, 8)

    assert rand_string_letters == expected_letters, \
        "Expected: {}, but got {}".format(expected_letters, rand_string_letters)
    assert rand_string_digits == expected_digits, \
        "Expected: {}, but got {}".format(expected_digits, rand_string_digits)



# Generated at 2022-06-23 21:56:31.972326
# Unit test for function get_random_item
def test_get_random_item():
    pl = ["первый", "второй", "третий", "четвертый", "пятый"]
    assert get_random_item(pl, rnd=random) in pl

# Generated at 2022-06-23 21:56:34.465352
# Unit test for method randints of class Random
def test_Random_randints():
    for i in range(10):
        assert len(Random().randints()) == 3
        assert len(Random().randints(5, a=10, b=100)) == 5

# Generated at 2022-06-23 21:56:41.531606
# Unit test for method uniform of class Random
def test_Random_uniform():
    def generate_random_values(method, a, b, precision=15, count=100000):
        rnd = random.Random()
        values = []
        for _ in range(count):
            value = method(rnd, a, b, precision)
            values.append(value)

        return values

    def assert_uniform_values(values, a, b, precision=15):
        assert values
        assert 0 < precision <= 12, 'Precision must be in range (0, 12]'
        for value in values:
            assert round(a, precision) <= round(value, precision) <= round(b, precision), value

    values = generate_random_values(Random.uniform, a=0, b=1, precision=15)
    assert_uniform_values(values, a=0, b=1)


# Generated at 2022-06-23 21:56:49.880171
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code()
    assert code.isalnum() is True
    assert len(code) == 4
    assert code.startswith('@')

    code = random.custom_code(mask='@@@')
    assert code.isalnum() is True
    assert len(code) == 3
    assert code.startswith('@')

    code = random.custom_code(mask='@@')
    assert code.isalnum() is True
    assert len(code) == 2
    assert code.startswith('@')

    code = random.custom_code(mask='@0@')
    assert len(code) == 3
    assert code.isalnum() is True

    code = random.custom_code(mask='#0#')
    assert len(code) == 3
    assert code.isalnum() is True



# Generated at 2022-06-23 21:56:53.260180
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(random.custom_code()) == 4
    assert len(random.custom_code(mask='@####')) == 5
    assert len(random.custom_code(mask='@@@@')) == 4
    assert len(random.custom_code(mask='####')) == 4
    assert len(random.custom_code(mask='######')) == 6
    assert len(random.custom_code(mask='######', char='?')) == 6
    assert len(random.custom_code(mask='######', digit='!')) == 6



# Generated at 2022-06-23 21:57:01.929195
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method randints in class Random."""
    rnd = Random()
    result = rnd.randints(1)
    assert isinstance(result, list)
    assert len(result) == 1

    result = rnd.randints(0)
    assert isinstance(result, list)
    assert len(result) == 0

    result = rnd.randints(10)
    assert isinstance(result, list)
    assert len(result) == 10

    result = rnd.randints(10, 1, 100)
    assert isinstance(result, list)
    assert len(result) == 10
    assert all(i < 100 and i >= 1 for i in result)



# Generated at 2022-06-23 21:57:10.271170
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    from mimesis.exceptions import NonEnumerableError

    r = Random()
    code = r.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code[0].isalpha() and code[1:].isdigit()

    code = r.custom_code(mask='abcde')
    assert len(code) == 5
    assert code.isalpha()

    code = r.custom_code(mask='@##')
    assert len(code) == 3
    assert code[0].isalpha() and code[1:].isdigit()

    code = r.custom_code(mask='@@#')
    assert len(code) == 3

# Generated at 2022-06-23 21:57:10.957261
# Unit test for function get_random_item
def test_get_random_item():
    pass

# Generated at 2022-06-23 21:57:18.415195
# Unit test for constructor of class Random
def test_Random():
    # Test that create new object with default seed = 42
    assert random.randint(1, 100) == 48
    rnd = random_module.Random()
    rnd.seed(42)
    assert random.randint(1, 100) == rnd.randint(1, 100)
    # Test generate random integers
    rnd = Random(42)
    assert rnd.randints(amount=3, a=1, b=100) == [48, 68, 98]


# Generated at 2022-06-23 21:57:19.047755
# Unit test for method urandom of class Random
def test_Random_urandom():
    random.urandom()

# Generated at 2022-06-23 21:57:22.394506
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert isinstance(rnd.randints(), list)
    assert len(rnd.randints(amount=10)) == 10



# Generated at 2022-06-23 21:57:24.017156
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert (
        Random().urandom(10)
        == os.urandom(10)
    )



# Generated at 2022-06-23 21:57:27.646053
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    sizes = [1, 7, 12, 32, 64, 96, 128, 256, 512, 1024, 2048]
    for size in sizes:
        assert len(random.randstr(length=size)) == size
        assert len(random.randstr(unique=True)) == 32

# Generated at 2022-06-23 21:57:30.386072
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4


# Generated at 2022-06-23 21:57:35.418472
# Unit test for method uniform of class Random
def test_Random_uniform():
    r1 = random.uniform(1, 2)
    assert r1 > 1 and r1 < 2
    r2 = random.uniform(1, 2, 2)
    assert r2 > 1 and r2 < 2 and '.' in str(r2) and len(str(r2)) == 4
    r3 = random.uniform(2, 3, 3)
    assert r3 > 2 and r3 < 3 and '.' in str(r3) and len(str(r3)) == 5

# Generated at 2022-06-23 21:57:42.895965
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert not random.randstr(unique=True) == randstr(unique=True)
    assert len(random.randstr()) == len(randstr())
    assert len(random.randstr(length=10000)) == 10000
    assert len(randstr(length=10000)) == 10000
    assert len(random.randstr(length=1)) == 1
    assert len(randstr(length=1)) == 1
    assert len(random.randstr(length=0)) == 0
    assert len(randstr(length=0)) == 0

# Generated at 2022-06-23 21:57:49.132819
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method ``randints`` of class ``Random``.

    """
    random_int: list = random.randints()
    assert len(random_int) == 3
    assert len(random.randints(50)) == 50
    assert min(random.randints(100000)) == 1
    assert max(random.randints(100000)) == 100

    with pytest.raises(ValueError):
        random.randints(0)

    with pytest.raises(ValueError):
        random.randints(-1)



# Generated at 2022-06-23 21:57:53.694624
# Unit test for method randstr of class Random
def test_Random_randstr():
    _string = ''.join(
        secrets.choice(string.ascii_letters + string.digits)
        for _ in range(64)
    )
    assert str(uuid.uuid4().hex) != _string
    assert len(str(uuid.uuid4().hex)) == 128

# Generated at 2022-06-23 21:57:57.808573
# Unit test for function get_random_item
def test_get_random_item():
    random_list = [1, 2, 5, 9]
    random_item = get_random_item(random_list)
    assert random_item in random_list

# Generated at 2022-06-23 21:58:02.391472
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###') != random.custom_code('@###')
    assert random.custom_code('@###', '@', '@') is ValueError
    assert random.custom_code('@###') in [random.custom_code('@###') for _ in range(100)]


# Generated at 2022-06-23 21:58:06.137089
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    from mimesis.builtins.enums import StringSequence
    random = Random()
    str_seq = StringSequence.NUMBERS.value
    length = 100
    assert len(random.generate_string(str_seq, length)) == length



# Generated at 2022-06-23 21:58:09.086182
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method randints of class Random."""
    assert Random().randints(4, 5, 10) == [6, 5, 8, 6]
    assert Random(0).randints(4, 5, 10) == [5, 5, 5, 5]

# Generated at 2022-06-23 21:58:15.270031
# Unit test for method randints of class Random
def test_Random_randints():
    # Positive tests
    assert Random().randints(3, 1, 100) == [25, 53, 48]
    assert Random().randints(1, -10, 10) == [0]
    assert Random().randints(10, -100, -50) == [-68, -74, -51, -82, -75, -99, -91, -69, -86, -77]

    # Negative tests
    try:
        Random().randints()
    except ValueError:
        pass
    else:
        assert False, 'ValueError should be raised'

    try:
        Random().randints(-5)
    except ValueError:
        pass
    else:
        assert False, 'ValueError should be raised'



# Generated at 2022-06-23 21:58:17.471195
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Currency

    currency = get_random_item(Currency)
    assert currency in Currency



# Generated at 2022-06-23 21:58:20.333264
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0.0, 1.0) == 0.5
    assert random.uniform(0.0, 1.0, 1) == 0.5

# Generated at 2022-06-23 21:58:28.553534
# Unit test for constructor of class Random
def test_Random():
    _random = Random()
    assert _random.random() > 0
    assert _random.random() < 1
    assert isinstance(_random.randstr(), str)
    assert len(_random.randstr()) >= 16
    assert len(_random.randstr()) <= 128
    assert len(_random.randstr(length=5)) == 5
    #
    assert _random.custom_code().__class__.__name__ == 'str'
    assert len(_random.custom_code()) == 4
    #
    assert isinstance(_random.randints(1, 100), list)
    assert len(_random.randints(1, 100)) == 3
    assert len(_random.randints(amount=2, a=1, b=100)) == 2

# Generated at 2022-06-23 21:58:31.317631
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    assert r.uniform(1, 100, 5) == r.uniform(1, 100, 5)

# Generated at 2022-06-23 21:58:32.707480
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    random.urandom()

# Generated at 2022-06-23 21:58:34.468021
# Unit test for method urandom of class Random
def test_Random_urandom():
    for i in range(100):
        assert len(Random().urandom(1024)) == 1024



# Generated at 2022-06-23 21:58:37.952600
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert r.randint(10, 100) == r.randint(10, 100)
    assert r.randint(100, 1000) == r.randint(100, 1000)
    assert r.randinter(5, 10, 2) == r.randinter(5, 10, 2)

# Generated at 2022-06-23 21:58:41.370541
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert isinstance(random.custom_code(mask='@###'), str)
    assert isinstance(random.custom_code(mask='####'), str)

    with pytest.raises(ValueError):
        assert random.custom_code(mask='False mask')

# Generated at 2022-06-23 21:58:45.984728
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(enum=0) == 0
    assert get_random_item(enum={'key': 'value'}) == 'key'
    assert get_random_item(enum=['foo', 'bar', 'lorem']) == 'foo'

# Generated at 2022-06-23 21:58:47.550633
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = Random().custom_code()
    assert code


# Generated at 2022-06-23 21:58:53.465823
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    assert isinstance(random.uniform(1, 1), float)
    assert isinstance(random.uniform(1, 1.1), float)
    assert isinstance(random.uniform(1.7, 2), float)
    assert isinstance(random.uniform(1.1, 1.7), float)
    assert isinstance(random.uniform(1.7, 2.1), float)

# Generated at 2022-06-23 21:58:55.806655
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test method generate_string of class Random."""
    rnd = Random()
    list_of_str = rnd.generate_string(str_seq='abcd', amount=100, length=100)
    assert len(list_of_str) == 100


# Generated at 2022-06-23 21:58:58.656612
# Unit test for method urandom of class Random
def test_Random_urandom():
    bytesObj = random.urandom()
    assert isinstance(bytesObj, bytes)

# Generated at 2022-06-23 21:59:04.030660
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    seed = random.randint(0, 100)
    random.seed(seed)
    assert (len(random.generate_string(string.digits)) == 10
            and (len(random.generate_string(10))) == 10
            and (len(random.generate_string(string.ascii_letters +
                                            string.digits + "!@#$%^&*()"))) == 10)

# Generated at 2022-06-23 21:59:07.906949
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method randints of class Random.

    This method generates a list of random integers.
    The amount of elements can vary from one to one milliard,
    and the range of integers also can vary.

    """

    assert isinstance(random.randints(), list)
    assert isinstance(random.randints(5, 100, 1000), list)
    assert isinstance(random.randints(amount=5), list)


# Generated at 2022-06-23 21:59:14.057147
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    result = rnd.randints(10, 0, 10)
    assert(0 in result)
    assert(10 not in result)
    result = rnd.randints(10, 0, 11)
    assert(0 in result)
    assert(10 in result)
    result = rnd.randints(0, 0, 0)
    assert(result == list())
    result = rnd.randints(10, 0, 10)
    assert(result != list())


# Generated at 2022-06-23 21:59:18.681134
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    rnd = Random()
    result = rnd.randstr()
    # test length of string
    assert len(result) >= 16
    assert len(result) <= 128
    # test if method returns only unique values
    result2 = rnd.randstr(unique=True)
    assert result != result2

# Generated at 2022-06-23 21:59:20.036772
# Unit test for function get_random_item
def test_get_random_item():
    assert len(get_random_item(Random(0.5))) > 0

# Generated at 2022-06-23 21:59:22.465064
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method randints of class Random."""
    result = random.randints(4, 10, 20)
    assert len(result) == 4
    assert all([10 <= x <= 20 for x in result])

# Generated at 2022-06-23 21:59:24.630577
# Unit test for function get_random_item
def test_get_random_item():
    assert random.choice(list(data.Gender)) == get_random_item(data.Gender, random)

# Generated at 2022-06-23 21:59:27.111398
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 21:59:29.457135
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(random.urandom(32)) == 32


# Generated at 2022-06-23 21:59:34.085181
# Unit test for method randints of class Random
def test_Random_randints():
    lst = random.randints(amount=10, a=0, b=20)
    assert isinstance(lst, list)
    assert len(lst) == 10
    assert lst == sorted(lst)
    assert 0 <= lst[0] < 20
    assert 0 <= lst[len(lst) - 1] < 20



# Generated at 2022-06-23 21:59:36.973135
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code of class Random.

    :return: True if test passed.
    """
    _rand = Random()
    _code1 = _rand.custom_code('@###')
    _code2 = _rand.custom_code()

    print(_code1, _code2)
    return _code1 != _code2

# Generated at 2022-06-23 21:59:38.383329
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() != random.custom_code()


if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-23 21:59:41.189788
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    code = r.custom_code('@###', '@', '#')
    assert len(code) == 4
    assert code[0].isupper()
    assert code[1].isupper()
    assert code[2].isdigit()
    assert code[3].isdigit()
    code = r.custom_code()
    assert len(code) == 4

# Generated at 2022-06-23 21:59:48.897230
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    import enum
    class UnitTestEnum(enum.Enum):
        TEST_ONE = 1
        TEST_TWO = 2

    # It will not raise any exceptions
    get_random_item(UnitTestEnum)

    # A TypeError is raised if there are another data type
    try:
        get_random_item(1)
    except TypeError:
        pass
    else:
        raise ValueError('This method has to raise TypeError.')

# Generated at 2022-06-23 21:59:53.055853
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method ``custom_code()`` of the class ``Random``."""
    assert len(random.custom_code()) == 4
    random.custom_code(mask='@###-@##')
    random.custom_code(mask='@###-@##', char='#', digit='@')

# Generated at 2022-06-23 21:59:58.222448
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    class Color(enum.Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    #  Simple usage
    random_item = get_random_item(Color)
    assert random_item in list(Color)

    #  Custom random object
    custom_random = Random()
    random_item = get_random_item(Color, custom_random)
    assert random_item in list(Color)

# Generated at 2022-06-23 21:59:58.806526
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random().urandom(10)) == 10

# Generated at 2022-06-23 22:00:00.773729
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    class Color(enum.Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    assert get_random_item(Color) in list(Color)

# Generated at 2022-06-23 22:00:02.834295
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    for x in random.randints(12, 100, 1000):
        assert x <= 1000
        assert x >= 100


# Generated at 2022-06-23 22:00:04.604460
# Unit test for method randints of class Random
def test_Random_randints():
    r = random.randints(1, 1, 1)
    assert len(r) == 1
    assert r[0] == 1


if __name__ == '__main__':
    test_Random_randints()

# Generated at 2022-06-23 22:00:08.874260
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(random.randstr(unique=False)) == 128
    assert len(random.randstr(unique=False, length=10)) == 10
    assert len(random.randstr(unique=True)) == 32
    assert len(random.randstr(unique=True, length=15)) == 32

# Generated at 2022-06-23 22:00:10.579226
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)

# Generated at 2022-06-23 22:00:15.959763
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(Random().randstr(), str)
    assert isinstance(Random().randstr(length=5), str)
    assert len(Random().randstr(length=5)) == 5
    assert len(Random().randstr(length=5)) <= 5
    assert len(Random().randstr(length=5)) >= 5
    assert len(Random().randstr(unique=True)) >= 32

# Generated at 2022-06-23 22:00:17.858697
# Unit test for method randints of class Random
def test_Random_randints():
    # check Error
    r = Random()
    r.randints(0)  

test_Random_randints()

# Generated at 2022-06-23 22:00:24.224383
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    rnd = Random()
    for _ in range(100):
        amount = rnd.randint(1, 100)
        _min = rnd.randint(0, 100)
        _max = rnd.randint(_min, 100)
        result = rnd.randints(amount=amount, a=_min, b=_max)
        assert len(result) == amount
        assert all(data >= _min and data < _max for data in result)



# Generated at 2022-06-23 22:00:31.653695
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(random.randints(), list)
    assert isinstance(random.randints(5), list)
    assert isinstance(random.randints(5, 10), list)
    assert isinstance(random.randints(5, 10, 20), list)
    assert len(random.randints(5, 10, 20)) == 5
    assert len(random.randints(5)) == 5



# Generated at 2022-06-23 22:00:35.272776
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    print(r.custom_code())
    print(r.custom_code())
    print(r.custom_code())
    print(r.custom_code())


if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-23 22:00:41.501211
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    code = random.custom_code(mask='####')
    code_ = random.custom_code(mask='@###@')
    code__ = random.custom_code(mask='#@@#@@@')
    code___ = random.custom_code(mask='@@@@@@@')
    assert isinstance(code, str)
    assert isinstance(code_, str)
    assert isinstance(code__, str)
    assert isinstance(code___, str)

# Generated at 2022-06-23 22:00:44.842651
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    str_seq = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    output = rnd.generate_string(str_seq, 20)
    assert output != None
    assert len(output) == 20

# Generated at 2022-06-23 22:00:51.679765
# Unit test for method randints of class Random
def test_Random_randints():
    """Generate list of random integers from 1 to 100."""
    assert (random.randints() == [93, 78, 35])
    assert (random.randints(10, 15) == [11, 13, 13, 15, 13, 13, 11, 13, 15, 11])
    assert (random.randints(1, 2) == [1, 1, 1])
    assert (random.randints(10, -10) == [0, -10, -10, -10, 0, 0, -10, 0, -10, 0])

# Generated at 2022-06-23 22:00:54.860644
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = Random()
    value = r.randstr(unique=True, length=24)
    assert len(value) == 24

# Generated at 2022-06-23 22:01:00.025711
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    class Week(enum.IntEnum):
        MONDAY = 0
        TUESDAY = 1
        WEDNESDAY = 2
        THURSDAY = 3
        FRIDAY = 4
        SATURDAY = 5
        SUNDAY = 6

    Week = get_random_item(Week)
    assert isinstance(Week, Week)

# Generated at 2022-06-23 22:01:05.972243
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    rnd = Random()
    for _ in range(10):
        str_seq = rnd.custom_code('@###')
        assert rnd.generate_string(str_seq) == ''.join(['0' for _ in range(len(str_seq))])

    assert rnd.generate_string('ABCDEF') in ['ABCDEF', 'ABCDEF', 'ABDCEF']

# Generated at 2022-06-23 22:01:16.905086
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    obj = Random()
    for _ in range(10):
        rnd_code = obj.custom_code(mask='@###', char='@', digit='#')
        parts = rnd_code.split()
        assert len(parts) == 1
        assert len(parts[0]) == len(mask)
        assert parts[0][0].isalpha()
        assert all(c.isdigit() for c in parts[0][1:])

    for _ in range(10):
        rnd_code = obj.custom_code(mask='###', char='@', digit='#')
        parts = rnd_code.split()
        assert len(parts) == 1
        assert len(parts[0]) == len(mask)
        assert all(c.isdigit() for c in parts[0][:])


# Generated at 2022-06-23 22:01:22.383601
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert(len(random.generate_string(string.digits, 5)) == 5)
    assert(random.generate_string('AaB1cD') == 'BcDcDB')
    assert(random.generate_string('ABC', 0) == '')
    assert(random.generate_string('ABC') == 'BAA')
    assert(random.generate_string('ABC', 1) == 'B')



# Generated at 2022-06-23 22:01:27.522587
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _random = Random()
    code_a = _random.custom_code('@###')
    code_b = _random.custom_code('@###')
    code_c = _random.custom_code('@###')
    code_d = _random.custom_code('@###')
    code_e = _random.custom_code('@###')
    code_f = _random.custom_code('@###')
    assert code_a != code_b != code_c != code_d != code_e != code_f

# Generated at 2022-06-23 22:01:28.767795
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(10) and isinstance(Random().urandom(10), bytes)

# Generated at 2022-06-23 22:01:35.084376
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum
    from mimesis.builtins import EnumBase

    # Case 1: when the module is loaded
    assert isinstance(
        get_random_item(EnumBase),
        Enum,
    )

    # Case 2: when the module is imported for the second time
    import sys

    if 'mimesis.data' in sys.modules:
        sys.modules.pop('mimesis.data')

    from mimesis.data import get_random_item

    assert isinstance(
        get_random_item(EnumBase),
        Enum,
    )