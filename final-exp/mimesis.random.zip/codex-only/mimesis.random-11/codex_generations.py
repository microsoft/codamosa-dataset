

# Generated at 2022-06-23 21:51:38.045580
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method ``randints()`` of the class ``Random()``.

    """
    rand_ = Random(1)
    rand_.seed(1)
    rand_.randints(amount=3)
    rand_.randints(amount=3, a=1, b=100)
    rand_.randints(amount=3, a=10, b=100)
    rand_.randints(amount=3, a=100, b=150)
    rand_.randints(amount=3, a=150, b=170)
    rand_.randints(amount=3, a=100, b=150)
    rand_.randints(amount=3, a=150, b=170)
    rand_.randints(amount=3, a=10, b=100)

# Generated at 2022-06-23 21:51:44.794727
# Unit test for method randints of class Random
def test_Random_randints():
    a = 1
    b = 100
    rnd = Random()
    assert len(rnd.randints(5)) == 5
    for i in rnd.randints(100):
        assert i >= a and i <= b
    for j in rnd.randints(100, a=b, b=a):
        assert j >= a and j <= b
    for j in rnd.randints(100, a=0, b=0):
        assert j == 0



# Generated at 2022-06-23 21:51:54.401849
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    r.seed(0)
    assert r.uniform(0,3.3) == 0.5791127014533705
    assert r.uniform(0,2.2) == 1.3375782587030593
    assert r.uniform(0,4.4) == 2.8243299186536427
    assert r.uniform(0,5.5) == 3.611739953279037
    assert r.uniform(0,3.3,precision=20) == 0.5791127014533706
    assert r.uniform(0,2.2,precision=20) == 1.3375782587030593
    assert r.uniform(0,4.4,precision=20) == 2.8243299186536427
   

# Generated at 2022-06-23 21:51:57.239821
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Arrange
    r = Random()

    # Act
    result = r.generate_string(str_seq='abc', length=2)

    # Assert
    assert isinstance(result, str)

# Generated at 2022-06-23 21:52:00.979549
# Unit test for method randints of class Random
def test_Random_randints():
    # Assert
    assert len(Random().randints(10, 1, 10)) == 10
    assert sum(Random().randints(10, 1, 10)) > 30 and sum(Random().randints(10, 1, 10)) < 300


# Generated at 2022-06-23 21:52:04.791332
# Unit test for method randstr of class Random
def test_Random_randstr():
    for _ in range(100):
        assert len(random.randstr(unique=False)) in range(16, 129)
    for _ in range(100):
        assert len(random.randstr(unique=False, length=8)) == 8

# Generated at 2022-06-23 21:52:08.282587
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import CardType
    for _ in range(30):
        assert isinstance(
            get_random_item(CardType),
            CardType
        )



# Generated at 2022-06-23 21:52:13.597776
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test Random urandom method."""
    _rnd = Random()
    _bytes = _rnd.urandom(32)
    assert isinstance(_bytes, bytes)
    assert len(_bytes) == 32
    assert all(isinstance(_byte, int) for _byte in _bytes)



# Generated at 2022-06-23 21:52:14.860003
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)



# Generated at 2022-06-23 21:52:25.766446
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()

    # amount > 0
    # a < b, a, b > 0
    assert rnd.randints(10, 2, 10)

    # amount <= 0
    # a < b, a, b > 0
    try:
        rnd.randints(0, 2, 10)
    except ValueError as e:
        assert e

    # amount > 0
    # a < b, a < 0, b > 0
    assert rnd.randints(10, -10, 10)

    # amount > 0
    # a < b, a, b < 0
    try:
        rnd.randints(10, -10, -1)
    except ValueError as e:
        assert e



# Generated at 2022-06-23 21:52:31.542340
# Unit test for function get_random_item
def test_get_random_item():
    enum = [10, 20, 30]

    assert get_random_item(enum) in enum
    assert get_random_item(enum, random_module) in enum
    assert get_random_item(enum, Random()) in enum

    _randint = lambda: random_module.randint(0, 100)

    assert get_random_item(_randint) in range(100)
    assert get_random_item(_randint, random_module) in range(100)
    assert get_random_item(_randint, Random()) in range(100)

# Generated at 2022-06-23 21:52:35.027225
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    from mimesis.enums import Weekday

    gender = get_random_item(Gender)
    assert isinstance(gender, str)

    weekday = get_random_item(Weekday)
    assert isinstance(weekday, str)



# Generated at 2022-06-23 21:52:39.067445
# Unit test for method randstr of class Random
def test_Random_randstr():
    _rnd = Random()

    for _ in range(100):
        rand_string = _rnd.randstr()
        assert isinstance(rand_string, str)

test_Random_randstr()

# Generated at 2022-06-23 21:52:44.620080
# Unit test for function get_random_item
def test_get_random_item():
    # After adding unit test functions,
    # you can run all unit tests using the command:
    # python -m unittest -v unit_tests.test_helpers
    import unittest
    from mimesis.enums import Gender

    class TestHelpers(unittest.TestCase):
        def test_get_random_item(self):
            enum = Gender
            item = get_random_item(enum)
            self.assertIn(item, list(enum))
    unittest.main()

# Generated at 2022-06-23 21:52:47.199087
# Unit test for method urandom of class Random
def test_Random_urandom():
    urand = Random.urandom(10)
    assert len(urand) == 10



# Generated at 2022-06-23 21:52:49.263030
# Unit test for constructor of class Random
def test_Random():
    # noinspection PyUnusedLocal
    r = Random()
    assert r is not None


# Generated at 2022-06-23 21:52:53.242655
# Unit test for method randstr of class Random
def test_Random_randstr():
    for i in range(10000):
        rnd = Random()
        assert len(rnd.randstr(unique=True)) == 32
        assert len(rnd.randstr(unique=False)) == rnd.randint(16, 128)

# Generated at 2022-06-23 21:52:58.736412
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random.
    """
    str_seq = 'abcdefghijklmnopqrstuvwxyz'
    test_str = random.generate_string(str_seq, length=8)
    assert len(test_str) == 8
    assert test_str in str_seq



# Generated at 2022-06-23 21:53:06.836547
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = Random()
    r.seed(1)
    out = r.randstr(length=32)
    assert len(out) == 32
    assert out == 'VuXn3faZ7MFDaA6dhZ7w1otvJ1zT6TgT'
    out = r.randstr(length=32, unique=True)
    assert len(out) == 32
    assert out == '8edc274b9dc34a0eba5b5d5e5dd5a073'

# Generated at 2022-06-23 21:53:09.289536
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    rnd = Random()
    item = get_random_item(Gender, rnd)
    assert isinstance(item, Gender)

# Generated at 2022-06-23 21:53:11.817011
# Unit test for function get_random_item
def test_get_random_item():
    class DayOfWeek(Random):
        MONDAY = 0
        TUESDAY = 1
        WEDNESDAY = 2
        THURSDAY = 3
        FRIDAY = 4
        SATURDAY = 5
        SUNDAY = 6

    random1 = Random()
    random2 = Random()
    assert get_random_item(DayOfWeek) == get_random_item(DayOfWeek)
    assert get_random_item(DayOfWeek, rnd=random1) != get_random_item(DayOfWeek, rnd=random2)

# Generated at 2022-06-23 21:53:17.189349
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    # 10 tests
    for _ in range(10):
        assert r.uniform(1, 1.1)
        assert r.uniform(2, 3.2)
        assert r.uniform(1, 100)

# Generated at 2022-06-23 21:53:23.594883
# Unit test for method randstr of class Random
def test_Random_randstr():
    res1 = random.randstr(unique=True, length=None) # unique = True, length = None
    res2 = random.randstr(False, None) # unique = False, length = None
    res3 = random.randstr(False, 20) # unique = False, length = 20

    assert len(res1) == 32 and res1.isalnum()
    assert len(res2) > 16 and res2.isalnum()
    assert len(res3) == 20 and res3.isalnum()

# Generated at 2022-06-23 21:53:27.472481
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Unit test for method randstr
    str_max_length = 128
    str_min_length = 16

    for i in range(1000):
        rnd_str = random.randstr()
        assert len(rnd_str) <= str_max_length and len(rnd_str) >= str_min_length

# Generated at 2022-06-23 21:53:38.755288
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method ``uniform()`` of class ``Random()``."""
    n1, n2 = 0.5, 5.5
    n3, n4 = 2.345678, 5.56789
    n5, n6 = 0.123456, 9.87654

    assert Random().uniform(n1, n2, precision=5) == 5.00000
    assert Random().uniform(n1, n2, precision=7) == 5.0000000
    assert Random().uniform(n3, n4, precision=3) == 4.901
    assert Random().uniform(n3, n4, precision=2) == 4.90
    assert Random().uniform(n5, n6, precision=4) == 2.5931
    assert Random().uniform(n5, n6, precision=3) == 2.

# Generated at 2022-06-23 21:53:41.266906
# Unit test for function get_random_item
def test_get_random_item():
    class TestEnum:
        item_1 = 1
        item_2 = 2
        item_3 = 3
        item_4 = 4
        item_5 = 5

    for _ in range(100):
        assert get_random_item(TestEnum) in [1, 2, 3, 4, 5]

# Generated at 2022-06-23 21:53:49.828894
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    for _ in range(100):
        randstr = random.randstr()
        assert len(randstr) >= 16
        assert len(randstr) <= 64
    for _ in range(100):
        randstr = random.randstr(length=128)
        assert len(randstr) >= 16
        assert len(randstr) <= 128
    for _ in range(100):
        randstr = random.randstr(unique=True)
        assert len(randstr) == 32

# Generated at 2022-06-23 21:53:56.700871
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3
    assert len(Random().randints(5)) == 5
    assert len(Random().randints(5, 0, 1)) == 5
    assert len(Random().randints(5, 100, 200)) == 5
    assert len(Random().randints(amount=5, a=100, b=200)) == 5
    assert len(Random().randints(a=100, b=200, amount=5)) == 5



# Generated at 2022-06-23 21:54:01.026892
# Unit test for method randstr of class Random
def test_Random_randstr():
    rand_str = Random().randstr()
    rand_str_unique = Random().randstr(True)
    rand_str_len = Random().randstr(length=16)

    assert len(rand_str) == 128
    assert len(rand_str_unique) == 32
    assert len(rand_str_len) == 16
    assert all(i in string.ascii_letters + string.digits for i in rand_str_len)

# Generated at 2022-06-23 21:54:03.699274
# Unit test for method uniform of class Random
def test_Random_uniform(): #Test method uniform of class Random
    rand = Random()     # Creating new object rand from class Random
    rand_uniform = rand.uniform(10, 100)
    assert rand_uniform >= 10
    assert rand_uniform < 100


# Generated at 2022-06-23 21:54:07.259819
# Unit test for method urandom of class Random
def test_Random_urandom():
    rnd = Random()
    assert rnd.urandom(5) != rnd.urandom(5)

# Generated at 2022-06-23 21:54:17.339119
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert isinstance(rnd.randstr(), str)
    assert isinstance(rnd.randstr(unique=True), str)
    assert isinstance(rnd.randstr(length=8), str)
    assert isinstance(rnd.randstr(length=8, unique=True), str)
    assert len(rnd.randstr(length=8)) == 8
    for _ in range(10):
        assert len(rnd.randstr(length=8, unique=True)) == 32
    assert isinstance(rnd.custom_code(), str)
    assert isinstance(rnd.custom_code(char='$', digit='*'), str)
    assert isinstance(rnd.uniform(1, 100), float)

# Generated at 2022-06-23 21:54:19.860426
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _mask = ['@@###', '@@@###', '@@@@###', '@@@@@###']
    for mask in _mask:
        print(f'{mask}: {random.custom_code(mask)}')


# Generated at 2022-06-23 21:54:21.702372
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(random)

# Generated at 2022-06-23 21:54:25.689702
# Unit test for method randstr of class Random
def test_Random_randstr():
    print(random.randstr(unique=True))
    print(random.randstr())
    print(random.randstr(length=10))
    print(random.randstr(length=10, unique=True))

test_Random_randstr()


# Generated at 2022-06-23 21:54:27.966127
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    from mimesis.enums import Cards

    rnd = Random()
    assert get_random_item(Cards)
    assert get_random_item(Cards, rnd)



# Generated at 2022-06-23 21:54:30.404277
# Unit test for method uniform of class Random
def test_Random_uniform():
    _random = Random()
    assert _random.uniform(1, 2) == 1.5

    results = [_random.uniform(1, 2) for i in range(10)]
    assert all([0 <= x < 2 for x in results])
    assert all([x != 1.5 for x in results])

# Generated at 2022-06-23 21:54:33.229424
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(), str)
    assert isinstance(random.randstr(unique=True), str)
    assert isinstance(random.randstr(length=4), str)
    assert len(random.randstr(length=4)) == 4

# Generated at 2022-06-23 21:54:38.751070
# Unit test for method randints of class Random
def test_Random_randints():
    for a in range(0, 100):
        assert sum([1 for i, v in enumerate(random.randints(a, 1, 10))
                    if v < 10 and v >= 1]) == a, \
            'The sum of values from 1 to 9 is not equal to the number of elements in the list.'

# Generated at 2022-06-23 21:54:48.198568
# Unit test for constructor of class Random
def test_Random():
    items = [1, 2, 3]
    print(f'Random(): {Random()}')
    print(f'choice(): {Random().choice(items)}')
    print(f'randint(): {Random().randint(1, 2, 3)}')
    print(f'random(): {Random().random()}')
    print(f'randints(): {Random().randints(amount=5, a=4, b=9)}')
    print(f'urandom(): {Random().urandom(8)}')
    print(f'generate_string(): {Random().generate_string(str_seq="AbcD", length=3)}')
    print(f'custom_code(): {Random().custom_code(mask="@####", char="@", digit="#")}')

# Generated at 2022-06-23 21:54:57.002404
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    r = Random()
    random_string = r.randstr()
    assert len(random_string) < 128
    random_string = r.randstr(length=256)
    assert len(random_string) == 256
    random_string = r.randstr(length=65)
    assert len(random_string) == 65
    random_string = r.randstr(length=16)
    assert len(random_string) == 16
    random_string = r.randstr(unique=True)
    assert len(random_string) == 32

# Generated at 2022-06-23 21:54:58.366560
# Unit test for method randints of class Random
def test_Random_randints():
    print(random.randints(amount=5, a=1, b=10))


# Generated at 2022-06-23 21:55:06.201040
# Unit test for method generate_string of class Random
def test_Random_generate_string():

    result = random.generate_string('abc')
    assert len(result) == 10
    assert isinstance(result, str)

    result = random.generate_string('abc', 5)
    assert len(result) == 5
    assert isinstance(result, str)

    result = random.generate_string('a1')
    assert len(result) == 10
    assert isinstance(result, str)

    result = random.generate_string('')
    assert len(result) == 10
    assert isinstance(result, str)


# Generated at 2022-06-23 21:55:14.195069
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == 'A123'
    assert random.custom_code('@@#') == 'A1#'
    assert random.custom_code('@@@#') == 'A1#9'
    assert random.custom_code('@###') == 'A123'
    assert random.custom_code('@@##') == 'A1#1'
    assert random.custom_code('@##') == 'A12'
    assert random.custom_code('@###', '$') == 'A123'
    assert random.custom_code('@@##', '@', '%') == 'A1%1'
    assert random.custom_code('@@##', '@', '#') == 'A1#1'


# Generated at 2022-06-23 21:55:17.902662
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(Random().randstr()) == 36
    assert len(Random().randstr(unique=True)) == 32
    assert len(Random().randstr(length=10)) == 10
    assert len(Random().randstr(length=10, unique=True)) == 36

# Generated at 2022-06-23 21:55:20.747404
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of custom class Random.

    :return: AssertionError if test failed, otherwise pass.
    """
    a = random.uniform(0.0, 0.5)
    assert 0.0 <= a < 0.5
    b = random.uniform(0.1, 0.99, 1)
    assert 0.1 <= b < 0.99

# Generated at 2022-06-23 21:55:22.677410
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    rnd = get_random_item(Gender)

# Generated at 2022-06-23 21:55:26.602837
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    rn = random.randstr
    assert isinstance(rn(), str)
    assert len(rn()) == 32
    assert isinstance(rn(unique=True), str)
    assert len(rn(unique=True)) == 32
    assert len(rn(length=100)) == 100
    assert len(rn(length=0)) == 0

# Generated at 2022-06-23 21:55:29.522051
# Unit test for method urandom of class Random
def test_Random_urandom():
    r = Random()
    r.urandom()


# Generated at 2022-06-23 21:55:34.757015
# Unit test for method randints of class Random
def test_Random_randints():
    """Tracking methods that return random values.

    :return: bool.
    """
    tst_random = Random()
    num = tst_random.randints()
    assert isinstance(num, list)
    assert all(isinstance(n, int) for n in num)
    return True


# Unit tests for method custom_code of class Random

# Generated at 2022-06-23 21:55:40.264279
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test the method of generating random strings in the class Random."""
    rnd = random.Random()
    rstr = rnd.randstr()
    assert rstr and isinstance(rstr, str)
    rstr = rnd.randstr(length=5)
    assert len(rstr) == 5
    rstr = rnd.randstr(unique=True)
    assert rstr and isinstance(rstr, str)
    assert len(rstr) == 32



# Generated at 2022-06-23 21:55:46.586146
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(a = 0, b = 100) == Random().randints(b = 100)
    assert Random().randints(a = 0, b = 100) == Random().randints(a = 0, b = 100)
    assert Random().randints(a = 0) == Random().randints(a = 0)
    assert Random().randints(b = 100) == Random().randints(b = 100)


if __name__ == '__main__':
    test_Random_randints()

# Generated at 2022-06-23 21:55:47.199546
# Unit test for constructor of class Random
def test_Random():
    assert Random()

# Generated at 2022-06-23 21:55:51.943857
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code() of class Random."""
    rnd = Random()
    code = rnd.custom_code("@### - #@##", "@", "#")
    assert len(code) == 8
    assert code[3] == ' '



# Generated at 2022-06-23 21:55:52.953339
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)

# Generated at 2022-06-23 21:56:02.355472
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() != Random().custom_code()
    assert Random().custom_code() != Random().custom_code()
    assert Random().custom_code() != Random().custom_code()

    assert Random().custom_code('@@@', '@') != Random().custom_code('@@@', '@')
    assert Random().custom_code('@@@', '@') != Random().custom_code('@@@', '@')
    assert Random().custom_code('@@@', '@') != Random().custom_code('@@@', '@')

    assert Random().custom_code('@@@', '@', '1') != Random().custom_code('@@@', '@', '1')
    assert Random().custom_code('@@@', '@', '1') != Random().custom_code('@@@', '@', '1')

# Generated at 2022-06-23 21:56:06.866155
# Unit test for method randstr of class Random
def test_Random_randstr():
    for i in range(5000):
        s = random.randstr(True)
        assert len(s) == 32, "length of string isn't 32 characters"
        assert isinstance(s, str), "input data isn't a str"


# Generated at 2022-06-23 21:56:16.671288
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    lst = rnd.randints(5, 1, 100)
    assert len(lst) == 5
    assert lst[0] < 101
    assert lst[0] > 0
    assert lst[1] < 101
    assert lst[1] > 0
    assert lst[2] < 101
    assert lst[2] > 0
    assert lst[3] < 101
    assert lst[3] > 0
    assert lst[4] < 101
    assert lst[4] > 0
    try:
        rnd.randints(0, 1, 100)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-23 21:56:17.650745
# Unit test for method urandom of class Random
def test_Random_urandom():
    Random().urandom(20)

# Generated at 2022-06-23 21:56:26.191662
# Unit test for function get_random_item
def test_get_random_item():
    class Test:
        TEST = 'TEST'
        TEST_2 = 'TEST_2'
        TEST_3 = 'TEST_3'

    assert Test.TEST in [Test.TEST, Test.TEST_2, Test.TEST_3]
    assert Test.TEST_2 in [Test.TEST, Test.TEST_2, Test.TEST_3]
    assert Test.TEST_3 in [Test.TEST, Test.TEST_2, Test.TEST_3]

    assert get_random_item(Test) in [Test.TEST, Test.TEST_2, Test.TEST_3]
    assert get_random_item(Test, rnd=random.choice) in [Test.TEST, Test.TEST_2, Test.TEST_3]

# Generated at 2022-06-23 21:56:37.006424
# Unit test for method generate_string of class Random

# Generated at 2022-06-23 21:56:45.398357
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender

    # random_module.choice
    random_module.seed(42)
    assert get_random_item(Gender) == Gender.MALE

    # random_module.choice
    random_module.seed(42)
    assert get_random_item(Gender) == Gender.MALE

    # custom random object
    rnd1 = Random(seed=42)
    assert get_random_item(Gender, rnd1) == Gender.MALE

    # custom random object
    rnd2 = Random(seed=42)
    assert get_random_item(Gender, rnd2) == Gender.MALE

# Generated at 2022-06-23 21:56:46.509901
# Unit test for method urandom of class Random
def test_Random_urandom():
    r = Random()
    r.urandom()

# Generated at 2022-06-23 21:56:53.724002
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    import random

    random.seed(0)
    assert (get_random_item(random.Random) == random.Random.DEGREES)
    assert (get_random_item(random.Random) == random.Random.DEGREES)
    assert (get_random_item(random.Random, rnd=Random()) == random.Random.RADIANS)
    assert (get_random_item(random.Random, rnd=Random()) == random.Random.RADIANS)
    assert (get_random_item(random.Random, rnd=Random()) == random.Random.DEGREES)
    assert (get_random_item(random.Random, rnd=Random()) == random.Random.DEGREES)

# Generated at 2022-06-23 21:56:55.452890
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random.urandom(length=48)) == 48

# Generated at 2022-06-23 21:57:01.885909
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(enum=0) == 0
    assert get_random_item(enum=0.0) == 0.0
    assert get_random_item(enum=True) is True
    assert get_random_item(enum=()) == ()
    assert get_random_item(enum={}) == {}
    assert get_random_item(enum=[]) == []
    assert get_random_item(enum='') == ''
    assert get_random_item(enum='mimesis') == 'm'

# Generated at 2022-06-23 21:57:05.700125
# Unit test for function get_random_item
def test_get_random_item():
    class SomeEnum(int, enum.Enum):
        ONE = 1
        TWO = 2
        THREE = 3

    assert isinstance(get_random_item(SomeEnum), SomeEnum)
    assert get_random_item(SomeEnum) in list(SomeEnum)

# Generated at 2022-06-23 21:57:07.712765
# Unit test for constructor of class Random
def test_Random():
    """Random constructor."""
    rnd = Random()
    for i in range(10):
        assert 1 <= rnd.randint(1, 100) <= 100

# Generated at 2022-06-23 21:57:17.828299
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    _str = rnd.randstr()
    assert isinstance(_str, str)
    assert len(_str) > 1

    _str = rnd.randstr(length=100)
    assert isinstance(_str, str)
    assert len(_str) == 100

    _str = rnd.randstr(length=128)
    assert isinstance(_str, str)
    assert len(_str) == 128

    _str = rnd.randstr(unique=True)
    assert isinstance(_str, str)
    assert len(_str) == 32

    _str = rnd.randstr(unique=True, length=128)
    assert isinstance(_str, str)
    assert len(_str) == 128

# Generated at 2022-06-23 21:57:21.177104
# Unit test for method randints of class Random
def test_Random_randints():
    amount = 3
    a = 1
    b = 100
    answer = random.randints(amount, a, b)
    assert len(answer) == amount
    assert min(answer) >= a
    assert max(answer) < b



# Generated at 2022-06-23 21:57:23.977241
# Unit test for method randints of class Random
def test_Random_randints():
    test_list = Random().randints(10, 0, 100)
    assert len(test_list) == 10



# Generated at 2022-06-23 21:57:28.217327
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    random = Random()
    res1 = random.randints(amount=1)
    res2 = random.randints(amount=20)
    assert isinstance(res1, list) and len(res1) == 1
    assert isinstance(res2, list) and len(res2) == 20
    for r in res2:
        assert isinstance(r, int)



# Generated at 2022-06-23 21:57:31.471460
# Unit test for method randints of class Random
def test_Random_randints():
    assert random.randints(a=1, b=10, amount=4) != random.randints(a=1, b=10, amount=4)


# Generated at 2022-06-23 21:57:34.270217
# Unit test for function get_random_item
def test_get_random_item():
    for i in range(10):
        assert get_random_item(enum=random.choice(['code1', 'code2']))

# Generated at 2022-06-23 21:57:37.068551
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    string = Random().custom_code(mask='@@#@')
    assert len(string) == 4
    assert string.isalpha()

# Generated at 2022-06-23 21:57:44.243506
# Unit test for method randints of class Random
def test_Random_randints():
    random_ = Random()
    assert len(random_.randints()) == 3
    assert len(random_.randints(amount=20)) == 20
    assert len(random_.randints(amount=20, a=1, b=10)) == 20
    assert len(random_.randints(a=1, b=10)) == 3
    assert len(random_.randints(b=5)) == 3
    assert len(random_.randints(amount=100, a=100)) == 100



# Generated at 2022-06-23 21:57:48.960646
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string('abc')) == 10
    assert len(Random().generate_string('abc', 20)) == 20
    assert len(Random().generate_string('abc', 3)) == 3
    assert Random().generate_string('abc') == 'abcabcabca'
    assert Random().generate_string('abcd', 4) == 'ddad'


# Generated at 2022-06-23 21:57:52.514001
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(1, 2, 3) in (1, 2, 3)
    assert get_random_item(1, 2, 3, rnd=random) in (1, 2, 3)

# Generated at 2022-06-23 21:57:54.050711
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for method urandom of class Random."""
    assert isinstance(Random().urandom(), bytes)

# Generated at 2022-06-23 21:58:04.178737
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of the class Random.
    """
    # Test 1. If a is greater than b, uniform should either
    # return a with probability 1 or raise an error.
    assert Random().uniform(100, 1) in (1, 100)

    # Test 2. If a is less than b, uniform should return
    # a random number in the range [a, b) or [a, b]
    # depending on rounding.
    for i in range(10):
        x = Random().uniform(0.123456789, 10.123456789)
        assert x >= 0.123456789
        assert x < 10.123456789

# Generated at 2022-06-23 21:58:05.897490
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    custom_code = random.custom_code()
    assert len(custom_code) == 4


# Generated at 2022-06-23 21:58:07.940195
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    a = random.custom_code('@###')
    b = random.custom_code('@###')
    assert a != b


# Generated at 2022-06-23 21:58:10.808729
# Unit test for method randstr of class Random
def test_Random_randstr():
    # TODO: you can try testing other class methods
    for i in range(0, 10000):
        r = random.randstr(length=50)
        assert isinstance(r, str)
        assert len(r) == 50

# Generated at 2022-06-23 21:58:12.290238
# Unit test for method urandom of class Random
def test_Random_urandom():
    testing_object = Random()
    result = testing_object.urandom(8)
    assert len(result) == 8

# Generated at 2022-06-23 21:58:15.959168
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from mimesis.enums import Gender
    r = Random(seed=123)
    assert r.custom_code(mask='@###',
                         char='@', digit='#') == 'R928'



# Generated at 2022-06-23 21:58:18.781064
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert 20 == len(Random().generate_string(string.digits, 20))
    assert 10 == len(Random().generate_string(string.ascii_letters, 10))

# Generated at 2022-06-23 21:58:22.465143
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    custom_rand = Random()
    assert len(custom_rand.randints(10)) == 10
    assert len(custom_rand.randints(10, b=1)) == 10



# Generated at 2022-06-23 21:58:26.746666
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert len(rnd.randints(amount=2)) == 2
    assert len(rnd.randints(amount=10, a=0, b=2)) == 10
    assert len(rnd.randints(amount=15, a=5, b=7)) == 15


# Unit tests for method randstr of class Random

# Generated at 2022-06-23 21:58:34.466320
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test for method randstr of class Random.

    :return: None.
    """
    # Standard function
    assert isinstance(random.randstr(), str)
    assert len(random.randstr()) in range(16, 128 + 1)

    # Unique function
    assert isinstance(random.randstr(unique=True), str)
    assert len(random.randstr(unique=True)) == 32

    # Define length of string
    assert isinstance(random.randstr(length=32), str)
    assert len(random.randstr(length=32)) == 32



# Generated at 2022-06-23 21:58:35.622928
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 21:58:37.448430
# Unit test for method uniform of class Random
def test_Random_uniform():
    for _ in range(100):
        assert random.uniform(-4.2, 3.2) in range(-4, 4)
        assert random.uniform(0.0, 100.0) in range(1, 100)



# Generated at 2022-06-23 21:58:40.449762
# Unit test for method randints of class Random
def test_Random_randints():
    amount, a, b = 3, 1, 100
    result = random.randints(amount, a, b)
    assert isinstance(result, list)
    assert len(result) == amount



# Generated at 2022-06-23 21:58:47.907034
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for ``Random.uniform()`` method."""
    assert random.uniform(0, 0.2) < 0.2
    assert random.uniform(0, 0.2) >= 0
    assert random.uniform(0, 0.2) < 0.2
    assert random.uniform(0, 0.2) >= 0
    assert random.uniform(0, 0.2) < 0.2
    assert random.uniform(0, 0.2) >= 0

# Generated at 2022-06-23 21:58:57.250351
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code(mask='@##-@@##')
    assert len(code) == 9
    assert code[3] == '-'
    assert code[0].isalpha() == True
    assert code[4].isalpha() == True
    assert code[1].isdigit() == True
    assert code[5].isdigit() == True
    assert code[2].isdigit() == True
    assert code[6].isdigit() == True
    assert code[7].isalpha() == True
    assert code[8].isalpha() == True
    assert code[1:4] == code[1:4].upper()
    assert code[5:7] == code[5:7].upper()


# Generated at 2022-06-23 21:59:00.755869
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test method randstr of class Random."""
    rnd = Random()
    assert len(rnd.randstr(length=10)) == 10
    assert type(rnd.randstr(length=10)) == str



# Generated at 2022-06-23 21:59:02.343134
# Unit test for method randstr of class Random
def test_Random_randstr():
    result = Random.randstr()
    assert isinstance(result, str)

# Generated at 2022-06-23 21:59:04.371844
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    random = Random()
    assert random.urandom()



# Generated at 2022-06-23 21:59:09.833674
# Unit test for method randstr of class Random
def test_Random_randstr():
    randstr = []
    randstr1 = []

    for _ in range(5):
        randstr.append(random.randstr())
        randstr1.append(random.randstr(unique = True))

    test = (randstr1[0] != randstr1[1] == randstr1[2] != randstr1[3]) == randstr1[4]
    print("Test for unique random strings passed? " + str(test))

    test = (randstr[0] != randstr[1] == randstr[2] != randstr[3]) == randstr[4]
    print("Test for usual random strings passed? " + str(test))

if __name__ == '__main__':
    test_Random_randstr()

# Generated at 2022-06-23 21:59:12.272690
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random"""
    random_str = Random().randstr()
    print(random_str)
    print(len(random_str))



# Generated at 2022-06-23 21:59:15.347004
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    rnd = Random()
    s = rnd.generate_string('abc')
    assert len(s) == 10
    assert isinstance(s, str)



# Generated at 2022-06-23 21:59:19.996857
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Generate string of letters.
    assert isinstance(random.generate_string(str_seq=string.ascii_letters,
                                             length=10), str)

    # Generate string of digits
    assert isinstance(random.generate_string(str_seq=string.digits,
                                             length=10), str)



# Generated at 2022-06-23 21:59:21.820104
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    r.seed(0)
    code = r.custom_code()
    assert code == 'G897'

# Generated at 2022-06-23 21:59:22.572035
# Unit test for method urandom of class Random
def test_Random_urandom():
    r = Random()
    r.urandom(16)

# Generated at 2022-06-23 21:59:33.260202
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method ``Random().randstr()``."""
    # I create instance of the custom class.
    rnd = Random()
    # Generate only unique values.
    assert rnd.randstr(True, 16) == rnd.randstr(True, 16)
    # Check if the length of the string is equal to 16.
    assert len(rnd.randstr()) == 16
    assert len(rnd.randstr(length=32)) == 32

    print('All tests for method '
          '``randstr()`` of class ``Random()`` is done successfully!')


__author__ = 'Mehrdad Arshad Rad'
__email__ = 'arshad.rad@gmail.com'

# Generated at 2022-06-23 21:59:35.787287
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    random.seed(1)
    for i in range(10):
        assert random.uniform(0, 1, 3) == 0.945

# Generated at 2022-06-23 21:59:38.660976
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert(len(random.generate_string()) == 10)
    assert(len(random.generate_string(length=5)) == 5)


# Generated at 2022-06-23 21:59:40.467031
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    expected = 'AA2019'
    result = Random().custom_code(mask='@@####', char='@', digit='#')
    assert expected == result

# Generated at 2022-06-23 21:59:49.779189
# Unit test for method randints of class Random
def test_Random_randints():
    """Method tests if the method ``randints`` works."""
    rnd = Random()
    integers = rnd.randints()

    assert isinstance(integers, list)
    assert len(integers) == 3

    integers = rnd.randints(amount=5)

    assert isinstance(integers, list)
    assert len(integers) == 5

    integers = rnd.randints(a=10, b=20)

    assert isinstance(integers, list)
    assert len(integers) == 3

    for i in integers:
        assert isinstance(i, int)
        assert 10 <= i <= 20



# Generated at 2022-06-23 21:59:54.450563
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test method generate_string of class Random."""
    assert Random().generate_string("abcABC", 2) in ("ab", "ba", "ac", "ca", "bc", "cb",
        "aB", "Ba", "AC", "Ca", "BC", "Cb", "Ab", "AB", "ac", "ac", "Bc", "CB")


# Generated at 2022-06-23 21:59:58.465742
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('AAAA') == 'AAAA'
    assert random.custom_code('@@@@') == 'AAAA'
    assert random.custom_code('####') == '0000'
    assert random.custom_code('@@##') == 'AA00'
    assert random.custom_code('@@##', char='@', digit='#') == 'AA00'

# Generated at 2022-06-23 22:00:01.442853
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    mask = '#@###'
    code = rnd.custom_code(mask=mask)
    assert code[0].isdigit(), 'The first character must be digit.'
    assert code[1].isalpha(), 'The second character must be a letter.'

# Generated at 2022-06-23 22:00:04.467815
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    a = r.randints()
    assert a
    assert isinstance(a, list)
    assert len(a) == 3

# Generated at 2022-06-23 22:00:06.375110
# Unit test for method randstr of class Random
def test_Random_randstr():
    s = random.randstr()
    assert len(s) == 16
    assert isinstance(s, str)



# Generated at 2022-06-23 22:00:13.029673
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method ``uniform()`` of class ``Random()``."""
    rnd = Random()
    precision = 15
    a = rnd.uniform(1, 2, precision)
    b = rnd.uniform(1, 2, precision)
    assert 1 < a <= 2, '{} is not in the 1..2 range!'.format(a)
    assert 1 < b <= 2, '{} is not in the 1..2 range!'.format(b)



# Generated at 2022-06-23 22:00:15.473463
# Unit test for method randstr of class Random
def test_Random_randstr():
    for _ in range(10):
        uuid_length = len(str(random.randstr(unique=True)))
        assert uuid_length == 32

# Generated at 2022-06-23 22:00:17.522860
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@453', char='@', digit='#')
    assert random.custom_code()

# Generated at 2022-06-23 22:00:20.406039
# Unit test for function get_random_item
def test_get_random_item():
    random.seed(12345)
    from mimesis.enums import Currency
    random.choice = lambda x: x[9]
    assert get_random_item(Currency) == Currency.CZK

# Generated at 2022-06-23 22:00:26.750280
# Unit test for method uniform of class Random
def test_Random_uniform():
    _r = Random()
    _random_numbers_for_uniform = []

    for _ in range(1000):
        _random_uniform = _r.uniform(0.0, 0.3, 3)
        _random_numbers_for_uniform.append(_random_uniform)

    assert set(map(type, _random_numbers_for_uniform)) == {float}
    assert all(map(lambda x: 0.000 <= x < 0.300, _random_numbers_for_uniform))
    assert len(_random_numbers_for_uniform) == 1000

# Generated at 2022-06-23 22:00:31.856717
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random.

    Returns:
        None.

    """
    for _ in range(0, 50):
        length = random.randint(16, 128)
        s = random.randstr(length=length)
        assert len(s) == length

# Generated at 2022-06-23 22:00:33.239536
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    pass

# Generated at 2022-06-23 22:00:38.541576
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random.

    :return: None.
    """
    for _ in range(10):
        x = random.randints(1)
        assert len(x) == 1

        y = random.randints(2)
        assert len(y) == 2

        z = random.randints(3)
        assert len(z) == 3



# Generated at 2022-06-23 22:00:43.551919
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = random_module.Random(3)
    # Possible string
    str_seq = string.ascii_letters + string.digits
    res = rnd.generate_string(str_seq, 10)
    assert res == '0y0w4k4c4'
    res = rnd.generate_string(str_seq, 10)
    assert res == 'fzkx0kcbxj'

# Generated at 2022-06-23 22:00:47.786746
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(Random().randstr()) == 128
    assert len(Random().randstr()) == 128
    assert len(Random().randstr()) == 128
    assert len(Random().randstr(unique=True)) == 64
    assert len(Random().randstr(unique=True)) == 64
    assert len(Random().randstr(unique=True)) == 64

# Generated at 2022-06-23 22:00:49.836761
# Unit test for method randstr of class Random
def test_Random_randstr():
    random_string = random.randstr()
    assert isinstance(random_string, str)
    assert len(random_string) > 0

# Generated at 2022-06-23 22:00:50.718995
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)

# Generated at 2022-06-23 22:00:56.986812
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Custom random object
    rnd = Random()
    # Generate string of length 10
    string = rnd.generate_string(str_seq=string.digits,
                                 length=10)
    assert len(string) == 10
    for x in string:
        assert int(x) in range(0, 10)



# Generated at 2022-06-23 22:01:05.211060
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1, 2, 1) == 1.5
    assert abs(random.uniform(1, 2, 2) - 1.5) == 0.25
    assert abs(random.uniform(1, 2, 3) - 1.5) == 0.125
    assert abs(random.uniform(1, 2, 4) - 1.5) == 0.0625
    assert abs(random.uniform(1, 2, 5) - 1.5) == 0.03125
    assert abs(random.uniform(1, 2, 6) - 1.5) == 0.015625

# Generated at 2022-06-23 22:01:07.008444
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(10, 20) >= 10 and random.uniform(10, 20) <= 20

# Generated at 2022-06-23 22:01:08.967358
# Unit test for method randints of class Random
def test_Random_randints():
    _random = Random()
    _randint = _random.randints()
    assert len(_randint) == 3



# Generated at 2022-06-23 22:01:15.788584
# Unit test for method uniform of class Random
def test_Random_uniform():
    pass
    # # Test cases:
    # # 1) Test where a == b
    # r = Random()
    # assert r.uniform(a = -10, b = -10) == -10

    # # 2) Test when a < b
    # r = Random()
    # assert (-10 <= r.uniform(a = -10, b = -9) <= -9) is True

    # # 3) Test when a > b
    # r = Random()
    # assert (-10 <= r.uniform(a = -9, b = -10) <= -9) is True

    # # 4) Test when a and b < 0
    # r = Random()
    # assert (-10 <= r.uniform(a = -10, b = -5) <= -5) is True

    # # 5) Test when a and

# Generated at 2022-06-23 22:01:18.155616
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(100), bytes)

if __name__ == '__main__':
    test_Random_urandom()

# Generated at 2022-06-23 22:01:26.927775
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code(mask='@@@@')
    assert rnd.custom_code(mask='@@@@', char='@', digit='#')
    assert rnd.custom_code(mask='####')
    assert rnd.custom_code(mask='####', char='@', digit='#')
    assert rnd.custom_code(mask='@@@@####', char='@', digit='#')
    assert rnd.custom_code(mask='@@@@####@@@@', char='@', digit='#')
    assert rnd.custom_code(mask='@@@@####@@@@', char='@@', digit='##')
    assert rnd.custom_code(mask='1234', char='@', digit='#')
    assert rnd.custom_code(mask='1234')