

# Generated at 2022-06-23 21:51:31.486506
# Unit test for method randints of class Random
def test_Random_randints():

    # If amount less or equal to zero
    with pytest.raises(ValueError):
        get_random_item(random_module.randints(amount=-1))

    # If amount more than zero
    assert len(random_module.randints())



# Generated at 2022-06-23 21:51:34.736032
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    class Test(enum.Enum):
        a = 1
        b = 2
        c = 3
        d = 4
        e = 5

    item = get_random_item(Test)

    assert isinstance(item, Test)

# Generated at 2022-06-23 21:51:36.266887
# Unit test for method urandom of class Random
def test_Random_urandom():
    rnd = Random()
    assert len(rnd.urandom()) > 0

# Generated at 2022-06-23 21:51:39.135682
# Unit test for function get_random_item
def test_get_random_item():
    class Color(enum.Enum):
        RED = enum.auto()
        BLUE = enum.auto()
        GREEN = enum.auto()

    assert get_random_item(Color) in Color


random = Random()

# Generated at 2022-06-23 21:51:41.037598
# Unit test for method randstr of class Random
def test_Random_randstr():
    arr = [random.randstr() for _ in range(0, 100)]
    assert len(arr) == len(set(arr))

# Generated at 2022-06-23 21:51:44.145433
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis import Person
    assert isinstance(get_random_item(Person.Gender), Person.Gender)

# Generated at 2022-06-23 21:51:48.206297
# Unit test for method randstr of class Random
def test_Random_randstr():
    try:
        random_str = random.randstr()
        if random_str.isalnum():
            print('Ok: Generated string is alphanumeric ')
        else:
            print('Error: Generated string is not alphanumeric')
    except Exception as _:
        print('Error: ' + str(_))

# Generated at 2022-06-23 21:51:51.599956
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Docstring."""
    r = Random()
    assert isinstance(r.randstr(), str)
    assert len(r.randstr()) == random.randint(16, 128)
    assert isinstance(r.randstr(unique=True), str)
    assert len(r.randstr(unique=True)) == 32
    assert isinstance(r.randstr(length=4), str)
    assert len(r.randstr(length=4)) == 4

# Generated at 2022-06-23 21:51:56.065907
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    r.seed(1)
    assert r.randints() == [31, 87, 1]
    assert r.randints(amount=10, a=2, b=3) == [2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
    assert r.randints(amount=2, a=-100, b=-1) == [-100, -100]



# Generated at 2022-06-23 21:51:58.718414
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    random_bytes = Random().urandom(1024)
    assert isinstance(random_bytes, bytes)



# Generated at 2022-06-23 21:52:03.121774
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rs = Random().custom_code(mask='@###')
    assert len(rs) == 4
    assert rs[0].isalpha()
    assert rs[1].isdigit()
    assert rs[2].isdigit()
    assert rs[3].isdigit()

# Generated at 2022-06-23 21:52:14.819696
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    t = Random()
    x = t.custom_code()
    assert len(x) == 4
    y = x[0]
    assert 65 <= ord(y) <= 90
    x = t.custom_code(length=3)
    assert len(x) == 3

    def test_x(x, mask):
        _mask = mask.encode()
        code = bytearray(len(_mask))
        for i, p in enumerate(_mask):
            if p == 64:  # @
                a = ord(x[i])
                assert 65 <= a <= 90
            elif p == 35:  # #
                a = ord(x[i])
                assert 48 <= a <= 57
            else:
                a = p
            code[i] = a


# Generated at 2022-06-23 21:52:26.519113
# Unit test for constructor of class Random
def test_Random():
    # Unit test for method randints()
    assert len(Random().randints()) == 3
    assert len(Random().randints(10)) == 10
    assert len(Random().randints(b=10, a=0)) == 3

    # Unit test for method generate_string()
    assert (
        len(Random().generate_string(string.ascii_letters)) == 10
    )
    assert (
        len(Random().generate_string(string.digits, 20)) == 20
    )
    assert (
        len(Random().generate_string('abc')) == 10
    )

    # Unit test for method custom_code()
    code = Random().custom_code()
    assert len(code) == 5
    assert code[0].isalpha() and code[1:4].isdigit()

    # Unit

# Generated at 2022-06-23 21:52:32.108542
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    code = random.custom_code(mask='@###-###')
    assert code == ''
    code = random.custom_code(mask='@###-@@@')
    assert code == ''
    code = random.custom_code(mask='@@@-###')
    assert code == ''

# Generated at 2022-06-23 21:52:37.859071
# Unit test for method randstr of class Random
def test_Random_randstr():
    """
    This test verify that method randstr of class Random
    will generate a string with a fixed length.
    """
    i = 0
    while i < 5:
        random_str = random.randstr(length=8)
        if len(random_str) == 8:
            i += 1
            continue

    assert i == 5

# Generated at 2022-06-23 21:52:43.825445
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    assert len(Random().randints(amount=10)) == 10
    assert len(Random().randints(amount=10, a=0, b=1)) == 10
    assert len(Random().randints(amount=11, a=-11, b=-10)) == 11

    try:
        Random().randints(amount=-1)
    except ValueError as e:
        assert str(e) == 'Amount out of range.'



# Generated at 2022-06-23 21:52:53.063278
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method ``uniform()`` of class ``Random()``.

    :return:
    """
    r = random.uniform(1234567890, precision=2)
    assert r >= 1234567000
    assert r <= 1234568000

    r = random.uniform(1234567890, precision=0)
    assert r >= 1234567000
    assert r <= 1234568000

    r = random.uniform(10.123, precision=1)
    assert r >= 10.0
    assert r <= 11.0

# Generated at 2022-06-23 21:53:05.226571
# Unit test for method randstr of class Random
def test_Random_randstr():
    from mimesis.providers.code import Code

    c = Code().custom_code(mask='@###')
    print(c)
    assert len(c) == 5
    assert 64 < ord(c[0]) < 91  # A-Z
    assert 47 < ord(c[1]) < 58  # 0-9

    c = Code().custom_code(mask='@###', char='#', digit='@')
    print(c)
    assert len(c) == 5
    assert 64 < ord(c[0]) < 91  # A-Z
    assert 47 < ord(c[1]) < 58  # 0-9

    random = Random()

# Generated at 2022-06-23 21:53:06.742713
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string(string.ascii_letters, 10)
    assert random.generate_string(string.digits, 5)
    assert random.generate_string(string.ascii_letters + string.digits, 10)


# Generated at 2022-06-23 21:53:14.633614
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    for _ in range(100):
        assert len(random.custom_code()) == 4
        assert len(random.custom_code(mask='@##@###')) == 8
        assert len(random.custom_code(mask='######')) == 6
        assert len(random.custom_code(mask='AAAAAA')) == 6
        assert len(random.custom_code(mask='123456')) == 6
        assert len(random.custom_code(mask='123AA56')) == 7
        assert len(random.custom_code(mask='123AAAA56')) == 9
        assert len(random.custom_code(mask='123AAAAAA56')) == 11
        assert len(random.custom_code(mask='123AAAAA56')) == 10

# Generated at 2022-06-23 21:53:18.650362
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom() of class Random."""
    random_obj = Random()
    result = random_obj.urandom(16)

    assert isinstance(result, bytes)
    assert len(result) == 16

# Generated at 2022-06-23 21:53:20.368722
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(random.urandom(10)) == 10
    assert isinstance(random.urandom(10), bytes)

# Generated at 2022-06-23 21:53:21.691288
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    assert isinstance(rnd.randstr(), str)

# Generated at 2022-06-23 21:53:25.878694
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    str_seq = 'abcdefghijklmnopqrstuvwxyz'
    length = 10

    import random

    rnd = random.Random()
    res = True

    for _ in range(1000):
        generated_str = rnd.generate_string(str_seq, length)
        res = res and len(generated_str) == length

    assert res == True

# Generated at 2022-06-23 21:53:30.173290
# Unit test for method randints of class Random
def test_Random_randints():
    random_module = Random()

    def check_size(size: int) -> bool:
        x = random_module.randints(size)
        return isinstance(x, list) and len(x) == size

    assert check_size(10)
    assert check_size(50)
    assert check_size(100)
    assert check_size(1000)



# Generated at 2022-06-23 21:53:36.429024
# Unit test for method uniform of class Random
def test_Random_uniform():
    random_obj = Random()
    # Case 1
    assert random_obj.uniform(1.10, 1.11) == 1.10
    # Case 2
    assert round(random_obj.uniform(1.10, 1.11, precision=2), 2) == 1.10
    # Case 3
    assert round(random_obj.uniform(1.1, 1.11, precision=1), 1) == 1.1

# Generated at 2022-06-23 21:53:40.498125
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    r.seed()
    r.seed(12345)
    r.seed(b'bytedata')
    r.getstate()
    r.setstate((3, (1234, 5678, 9012, 3456, 7890, 1234, 5678, 9012, 3456, 7890), None))


# Generated at 2022-06-23 21:53:46.047088
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Initialize the custom class Random
    rnd = Random()

    # Amount of elements to generate
    amount = 10

    # Generate list of random integers
    items = rnd.randints(amount)

    # Generate list of random strings
    strings = [rnd.generate_string('abcdef', item)
               for item in items]

    # Generate list of numbers
    numbers = ['{:03d}'.format(item) for item in items]

    # Mix strings and numbers
    mixed = [n for i in range(amount) for n in zip(strings[i], numbers[i])]

    # Check that all lists have the same length
    assert len(set([len(lst) for lst in mixed])) == 1

    # Check that the count of each element is equal to amount

# Generated at 2022-06-23 21:53:57.279706
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    digits = '0123456789'
    message = 'The method should return a random string.'

    r = Random()
    result = r.custom_code()
    assert isinstance(result, str)

    mask = 'AA@@@###AA'
    result = r.custom_code(mask, 'A', '#')
    assert len(result) == 9, message
    assert all([i in letters for i in result]), message
    assert all([i in digits for i in result[4:7]]), message
    assert all([i in letters for i in result[:3]]), message
    assert all([i in letters for i in result[7:]]), message

    mask = 'AA@@@###AA@@@'
    result = r.custom

# Generated at 2022-06-23 21:53:59.307322
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    

# Generated at 2022-06-23 21:54:04.649619
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    class Color(enum.Enum):
        GREEN = "#008000"
        RED = "#FF0000"
        WHITE = "#FFFFFF"
        YELLOW = "#FFFF00"
        BLACK = "#000000"
    rnd = Random()
    assert get_random_item(Color, rnd) in Color



# Generated at 2022-06-23 21:54:16.533200
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test method randstr of class Random."""
    rnd = Random()

    assert isinstance(rnd.randstr(), str)
    assert len(rnd.randstr()) >= 16
    assert len(rnd.randstr()) <= 128

    assert isinstance(rnd.randstr(unique=True), str)
    assert len(rnd.randstr(unique=True)) == 64

    assert isinstance(rnd.randstr(length=10), str)
    assert len(rnd.randstr(length=10)) == 10

    assert isinstance(rnd.randstr(length=1), str)
    assert len(rnd.randstr(length=1)) == 1

    assert isinstance(rnd.randstr(length=128), str)
    assert len(rnd.randstr(length=128)) == 128

# Generated at 2022-06-23 21:54:19.741013
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints."""
    rnd = Random()
    assert rnd.randints(5, 10, 20) == [15, 19, 17, 17, 12]
    assert rnd.randints(1, 10, 20) == [13]

# Generated at 2022-06-23 21:54:26.380448
# Unit test for method randstr of class Random
def test_Random_randstr():
    from itertools import islice, combinations

    assert isinstance(random.randstr(), str)
    assert len(random.randstr()) > 0
    assert isinstance(random.randstr(unique=True), str)
    assert len(random.randstr(unique=True)) > 0
    assert isinstance(random.randstr(unique=True, length=8), str)
    assert len(random.randstr(unique=True, length=8)) == 8

    _rnd = Random()
    _result = tuple(random.randstr(length=16) for _ in range(1024))
    _result_2 = tuple(islice(_rnd.permutation(_result), 0, len(_result)))

    assert _result == _result_2

    # Duplicate

# Generated at 2022-06-23 21:54:33.749695
# Unit test for method randstr of class Random
def test_Random_randstr():
    s = random.randstr(unique=True)
    assert len(s) == 32
    t = random.randstr(unique=True)
    assert s != t
    s = random.randstr(unique=False)
    assert len(s) >= 16
    assert len(s) < 128
    t = random.randstr(unique=False, length=64)
    assert len(t) == 64
    t = random.randstr(unique=False, length=16)
    assert len(t) == 16
    s = random.randstr(unique=False, length=0)
    assert len(s) == 0
    s = random.randstr(unique=False, length=1)
    assert len(s) == 1
    s = random.randstr(unique=False, length=10)
    assert len(s)

# Generated at 2022-06-23 21:54:42.794621
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    r = Random()
    # It should return 3 random integers
    assert len(r.randints()) == 3
    # It should return 5 random integers
    assert len(r.randints(amount=5)) == 5
    # It should return list of random integers from [1, 10)
    assert len(r.randints(a=1, b=10)) == 3
    # It should return list of random integers from [10, 100)
    assert len(r.randints(a=10, b=100, amount=5)) == 5



# Generated at 2022-06-23 21:54:48.122822
# Unit test for function get_random_item
def test_get_random_item():
    class TestEnum:
        ENUM_A = 1
        ENUM_B = 2
        ENUM_C = 3
        ENUM_D = 4

    class TestRandom(Random):
        def choice(self, seq):
            return TestEnum.ENUM_D

    assert get_random_item(TestEnum) is TestEnum.ENUM_D
    assert get_random_item(TestEnum, rnd=TestRandom()) is TestEnum.ENUM_D

# Generated at 2022-06-23 21:54:49.867013
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    print(Random().generate_string(str_seq='abcdefg', length=8))


# Generated at 2022-06-23 21:54:55.948532
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test that method ``uniform()`` has precision equals to 15.

    """
    rnd = Random()
    precision = 15
    a, b = 0, 1

    for _ in range(precision):
        result = rnd.uniform(a, b, precision)
        assert round(result, len(str(result)) - 2) == result

# Generated at 2022-06-23 21:54:59.258840
# Unit test for method uniform of class Random
def test_Random_uniform():
    import math
    cnt = 1000000
    res = [random.uniform(0.0, 100.0) for _ in range(cnt)]
    assert math.ceil(res[cnt - 1]) == 100
    assert math.floor(res[cnt - 1]) == 99

# Generated at 2022-06-23 21:55:07.631359
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for custom code."""
    str_ = "ASDF123"
    len_ = 100000
    rand = Random()

    # Generate a list of 100000 random code.
    code_list = [rand.custom_code() for _ in range(len_)]
    assert len(code_list) == len_

    # Check that there are no empty strings in the list.
    assert '' not in code_list

    # Check that the string contains only uppercase ASCII characters
    # and numbers.
    assert all(set(_).issubset(set(str_)) for _ in code_list)

# Generated at 2022-06-23 21:55:15.807219
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random.

    :return: None.
    """
    r = Random()
    assert len(r.randstr()) == 16

    assert len(r.randstr(length=32)) == 32
    assert len(r.randstr(length=16)) == 16

    assert len(r.randstr(unique=True)) == 32

    # Test string created with only alphabetic letters
    assert r.randstr(alphabetic_only=True).isalpha()

    # Test string created with only alphabetic letters and digits
    assert r.randstr(alphanumeric_only=True).isalnum()

    # Test string created with only digits
    assert r.randstr(digits_only=True).isdigit()

# Generated at 2022-06-23 21:55:24.383104
# Unit test for constructor of class Random
def test_Random():
    _rnd = Random()
    assert isinstance(_rnd, random_module.Random)
    assert _rnd.random() > 0
    assert _rnd.random() < 1
    assert _rnd.randrange(5, 10) in range(5, 10)
    assert _rnd.randint(-1, 10) in range(-1, 10)
    assert _rnd.randitem([1, 2, 3]) in [1, 2, 3]
    assert _rnd.randitems([1, 2, 3], 2) in (1, 2, 3)
    assert _rnd.randfloat(1, 10) > 0
    assert _rnd.randfloat(1, 10) < 10
    assert _rnd.randfloat(1, 10, 20) > 0

# Generated at 2022-06-23 21:55:26.729165
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    r = Random()
    rand_str = r.randstr()
    rand_str_len = len(rand_str)
    assert rand_str_len >= 16
    assert rand_str_len <= 128

# Generated at 2022-06-23 21:55:30.158720
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    print(rnd.uniform(1.1, 1.9))

# Generated at 2022-06-23 21:55:36.641134
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    assert random.urandom() != random.urandom()
    assert random.urandom(5) != random.urandom(5)
    assert random.urandom(5) != random.urandom(6)
    assert len(random.urandom(5)) == 5
    for _ in range(100):
        length = random.randint(1, 100)
        assert len(random.urandom(length)) == length

# Generated at 2022-06-23 21:55:41.221752
# Unit test for method uniform of class Random
def test_Random_uniform():
    # Testing precision
    result = random.uniform(1,2)
    precision_3 = round(result, 3)
    precision_15 = round(result, 15)
    assert(precision_3 == 1.5 and precision_15 == 1.5)
    # Testing range
    for _ in range(50):
        result = random.uniform(1, 2)
        assert(1 <= result < 2)

test_Random_uniform()

# Generated at 2022-06-23 21:55:44.344749
# Unit test for function get_random_item
def test_get_random_item():
    import pytest
    from ..core.providers import Gender

    enum_item = get_random_item(Gender)
    assert isinstance(enum_item, Gender)

# Generated at 2022-06-23 21:55:47.734101
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints(amount=10)) == 10
    assert len(Random().randints()) == 3



# Generated at 2022-06-23 21:55:50.330264
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert rnd.uniform(1, 2, precision=15) in [1.4999999999999999, 1.5]

# Generated at 2022-06-23 21:55:53.141149
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test functionality of Random class."""
    _bytes = Random().urandom(10)
    assert isinstance(_bytes, bytes)
    assert len(_bytes) == 10



# Generated at 2022-06-23 21:55:55.184378
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    s = Random().custom_code('####@@#')
    assert len(s) == 7
    assert s.isalpha()

# Generated at 2022-06-23 21:55:56.601227
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 21:56:01.134394
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(Random().randstr(length=3), str)
    assert isinstance(Random().randstr(unique=False), str)
    assert isinstance(Random().randstr(unique=True), str)
    assert isinstance(Random().randstr(), str)
    assert isinstance(Random().randstr(length=133), str)


test_Random_randstr()

# Generated at 2022-06-23 21:56:02.218838
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(random.urandom(10)) == 10

# Generated at 2022-06-23 21:56:08.481807
# Unit test for method randstr of class Random
def test_Random_randstr():

    # Unique
    assert random.randstr(unique=True) != random.randstr(unique=True)

    # Length
    assert random.randstr(length=4)
    assert random.randstr(length=4)

    # Length and unique
    assert random.randstr(unique=True, length=4)
    assert random.randstr(unique=True, length=4)

# Generated at 2022-06-23 21:56:13.498449
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender

    g = get_random_item(Gender)
    first_name, last_name = g.value
    assert g.name == 'MALE' and first_name == 'Олег' and last_name == 'Иванов'

# Generated at 2022-06-23 21:56:14.879164
# Unit test for method urandom of class Random
def test_Random_urandom():

    assert isinstance(Random().urandom(), bytes)



# Generated at 2022-06-23 21:56:17.424861
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    result = random.generate_string('abcdefghijklmnopqrstuvwxyz', 8)
    assert result == 'gutshyxj'


# Generated at 2022-06-23 21:56:19.520827
# Unit test for method urandom of class Random
def test_Random_urandom():
    random = Random()
    value = random.urandom(15)
    assert isinstance(value, bytes)



# Generated at 2022-06-23 21:56:20.846205
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)

# Generated at 2022-06-23 21:56:30.511369
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    assert Random().randints()
    assert len(Random().randints()) == 3
    assert len(Random().randints(12, 0, 100)) == 12
    assert len(Random().randints(12, 1, 1)) == 12

    with pytest.raises(ValueError):
        # Generate list with length 0
        Random().randints(0, 0, 100)
        # Generate list with length 0
        Random().randints(1, 0, 0)
        # Generate list with invalid range
        Random().randints(1, 1, 0)
        # Generate list with invalid range
        Random().randints(1, 1, 0)
        # Generate list with negative length
        Random().randints(-1, 1, 10)



# Generated at 2022-06-23 21:56:39.283456
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random
    """
    random.seed(1000)
    for _ in range(20):
        assert type(random.uniform(1, 100)) == float
        assert 1 <= random.uniform(1, 100) < 100
        assert type(random.uniform(1, 100, 2)) == float
        assert 1 <= random.uniform(1, 100, 2) < 100
        assert type(random.uniform(1, 100, 6)) == float
        assert 1 <= random.uniform(1, 100, 6) < 100
    random.seed(1001)
    assert type(random.uniform(1, 100)) == float
    assert 1 <= random.uniform(1, 100) < 100
    assert type(random.uniform(1, 100, 2)) == float

# Generated at 2022-06-23 21:56:47.938425
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    amount = 1000
    length = 10
    random_strings = []
    letters = string.digits + string.ascii_uppercase
    for i in range(amount):
        random_string = Random().generate_string(letters, length)
        if random_string == None:
            print('None')
        assert len(random_string) == length
        random_strings.append(random_string)

    for i in range(amount):
        for j in range(i + 1, amount):
            assert random_strings[i] != random_strings[j]



# Generated at 2022-06-23 21:56:50.178007
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    for _ in range(10):
        assert 0.2 <= r.uniform(0.1, 0.3) <= 0.3


# Generated at 2022-06-23 21:56:58.933644
# Unit test for method randints of class Random
def test_Random_randints():
    # Success
    assert len(random.randints()) == 3
    assert len(random.randints(amount=10)) == 10
    assert len(random.randints(amount=10, a=1, b=4)) == 10
    assert len(random.randints(amount=10, a=1, b=2)) == 10
    assert len(random.randints(amount=10, a=1, b=1)) == 10
    # Fail
    try:
        random.randints(amount=0, a=1, b=1)
    except ValueError:
        pass



# Generated at 2022-06-23 21:57:02.005757
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    a = 1.0
    b = 2.0
    precision = 2
    assert r.uniform(a, b, precision) >= 1.00
    assert r.uniform(a, b, precision) < 1.99

# Generated at 2022-06-23 21:57:04.197079
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints(3, 1, 10)) == 3
    assert len(random.randints(1)) == 1



# Generated at 2022-06-23 21:57:07.558189
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = random
    rnd.seed(123)
    assert rnd.randints(4, 1, 10) == [4, 1, 6, 4]
    assert rnd.randints(4, 1, 10) == [10, 4, 4, 9]

# Generated at 2022-06-23 21:57:12.058992
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random.
    """
    s = '1234567890'
    c = random.generate_string(s, 10)
    assert len(c) == 10
    assert isinstance(c, str)
    assert all(c[i] in s for i in range(10))



# Generated at 2022-06-23 21:57:13.114244
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(5)

# Generated at 2022-06-23 21:57:17.460501
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.schema import FieldName
    field_name = get_random_item(FieldName)
    assert isinstance(field_name, FieldName)
    assert field_name.name()
    assert field_name.value

# Generated at 2022-06-23 21:57:24.423544
# Unit test for method randstr of class Random
def test_Random_randstr():
    _random = Random()
    _str1 = _random.randstr()
    _str2 = _random.randstr()
    assert _str1 != _str2
    _str3 = _random.randstr(unique=True)
    _str4 = _random.randstr(unique=True)
    assert _str3 != _str4
    assert isinstance(_str1, str)
    assert isinstance(_str2, str)
    assert isinstance(_str3, str)
    assert isinstance(_str4, str)

# Generated at 2022-06-23 21:57:27.430586
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    rnd.seed(42)
    random_list = sorted(rnd.randints(amount=5, a=0, b=10))
    assert random_list == [0, 5, 7, 9, 9]


# Generated at 2022-06-23 21:57:32.156612
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    string_seq = 'ABC'
    length = 3
    result = Random().generate_string(string_seq, length)
    result = result.replace(' ', '')
    if len(result) != length:
        raise ValueError('The length of the result is not equal to the desired value')


# Generated at 2022-06-23 21:57:35.614509
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    for _ in range(64):
        _random = Random()
        _str = _random.generate_string(str_seq=_random.digits)
        assert isinstance(_str, str)

        _str = _random.generate_string(str_seq=_random.letters)
        assert isinstance(_str, str)

# Generated at 2022-06-23 21:57:39.103118
# Unit test for method uniform of class Random
def test_Random_uniform():
    # First requirement
    assert 1.0 <= Random().uniform(1.0, 2.0) < 2.0
    # Second requirement
    assert 1 <= Random().uniform(1, 2) < 2


# Generated at 2022-06-23 21:57:46.315621
# Unit test for method randstr of class Random
def test_Random_randstr():
    cases = [
        (False, None, 16, 128),
        (False, 10, 10, 10),
        (False, 50, 50, 50),
        (False, 80, 80, 80),
        (True, None, 32, 32),
    ]
    for unique, length, min_len, max_len in cases:
        x = Random.randstr(unique=unique, length=length)
        assert len(x) >= min_len and len(x) <= max_len

# Generated at 2022-06-23 21:57:49.885629
# Unit test for constructor of class Random
def test_Random():
    """Test custom class Random for generating random values."""
    r = random_module.Random()
    new_r = Random()

    assert r.randint(1, 10) == new_r.randint(1, 10)



# Generated at 2022-06-23 21:57:54.548678
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random.

    """
    a = random.uniform(5.5, 5.55, precision=2)
    b = random.uniform(5.5, 5.55, precision=4)

    assert 5.5 <= a <= 5.55
    assert 5.5 <= b <= 5.55

# Generated at 2022-06-23 21:57:57.967623
# Unit test for method urandom of class Random
def test_Random_urandom():
    random_bytes = random.urandom(16)
    assert random_bytes is not None
    assert type(random_bytes) == bytes

# Generated at 2022-06-23 21:57:58.570654
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3

# Generated at 2022-06-23 21:58:03.131950
# Unit test for constructor of class Random
def test_Random():
    seed = '1234567890'
    random_obj = Random(seed)
    randints = random_obj.randints(10)
    random_str = random_obj.randstr()
    assert len(randints) == 10
    assert len(random_str) == 43  # It's not the actual length

# Generated at 2022-06-23 21:58:04.674758
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom() != Random().urandom()


# Generated at 2022-06-23 21:58:06.940269
# Unit test for function get_random_item
def test_get_random_item():
    from .enums import Gender

    gender = get_random_item(Gender)
    assert gender in Gender._member_names_

# Generated at 2022-06-23 21:58:14.131178
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    for i in range(5):
        assert r.uniform(1.23, 10.67, 1) >= 1.23
        assert r.uniform(1.23, 10.67, 1) <= 10.67
        assert r.uniform(1.23, 10.67, 1) >= r.uniform(1.23, 10.67, 1)
        assert r.uniform(1.23, 10.67, 1) <= r.uniform(1.23, 10.67, 1)
        assert r.uniform(1.23, 10.67, 1) >= r.uniform(1.23, 10.67, 1)
        assert r.uniform(1.23, 10.67, 1) <= r.uniform(1.23, 10.67, 1)

# Generated at 2022-06-23 21:58:14.712930
# Unit test for constructor of class Random
def test_Random():
    assert Random()

# Generated at 2022-06-23 21:58:17.281792
# Unit test for constructor of class Random
def test_Random():
    """Unit test for class Random."""
    _r = Random()
    assert _r.random() < 1
    assert _r.random() >= 0



# Generated at 2022-06-23 21:58:18.878029
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(10) == os.urandom(10)

# Generated at 2022-06-23 21:58:22.604143
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Arrange
    r = random

    # Act
    random_byte_array = r.urandom(16)
    length = len(random_byte_array)

    # Assert
    assert length == 16



# Generated at 2022-06-23 21:58:29.579236
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert isinstance(rnd.custom_code(), str)
    assert isinstance(rnd.custom_code('@###'), str)
    assert isinstance(rnd.custom_code('@@##'), str)
    assert isinstance(rnd.custom_code('###@'), str)
    assert isinstance(rnd.custom_code('@@##'), str)
    assert isinstance(rnd.custom_code('@@@@'), str)
    assert isinstance(rnd.custom_code('####'), str)
    assert isinstance(rnd.custom_code('@#@#@#@#@#@#@#@#@'), str)
    assert isinstance(rnd.custom_code('###@@@######@@@@'), str)
    assert isinstance(rnd.custom_code('@###@@@######@@@@'), str)
   

# Generated at 2022-06-23 21:58:35.860709
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test the uniform method of Random class."""
    r = Random()
    assert r.uniform(1, 2.5) == 1.0
    assert r.uniform(1, 2.5, 15) == 1.0
    assert r.uniform(1, 2.5) == 1.0
    assert r.uniform(1, 2.5, 15) == 1.0
    assert r.uniform(0, 0) == 0.0
    assert r.uniform(0, 0) == 0.0

# Generated at 2022-06-23 21:58:40.278126
# Unit test for method uniform of class Random
def test_Random_uniform():
    from array import array

    def float_cmp(x, y):
        return abs(x - y) <= rounded

    rounded = 1e-4

    assert float_cmp(Random().uniform(1, 10), Random().uniform(1, 10))
    assert not float_cmp(Random().uniform(1, 10), Random().uniform(10, 20))

    # Test custom precision
    assert float_cmp(Random().uniform(1, 10, 1), Random().uniform(1, 10, 1))
    assert not float_cmp(Random().uniform(1, 10, 1),
                         Random().uniform(10, 20, 1))

    # Test non-integer values
    assert float_cmp(Random().uniform(0.5, 0.75), Random().uniform(0.5, 0.75))
    assert not float

# Generated at 2022-06-23 21:58:42.515716
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random(0.134555)
    assert rnd.custom_code('@@##', '@') == 'IT4'

# Generated at 2022-06-23 21:58:45.572784
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    elements = len(rnd.randints())
    assert elements == 3



# Generated at 2022-06-23 21:58:48.710388
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code(mask='@@@###')
    assert len(code) == 7
    assert code[:3].isalpha()
    assert code[3:].isdigit()

# Generated at 2022-06-23 21:58:51.032591
# Unit test for method urandom of class Random
def test_Random_urandom():
    lst = Random().urandom(10)
    assert len(lst) == 10
    assert isinstance(lst, bytes)

# Generated at 2022-06-23 21:58:53.666209
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    assert Random().uniform(0.00, 0.75) == 0.00

# Generated at 2022-06-23 21:59:01.222462
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    length = random.randint(1,100)
    letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    digits = '0123456789'
    print("Random sequence of letters and digits with length " + str(length) + ":")
    print("Sequence generated by method generate_string of class Random:")
    string = Random().generate_string(letters + digits, length)
    print(string)
    print("Sequence generated by method generate_string of class Random:")
    string = Random().generate_string(letters + digits, length)
    print(string)
    print("Sequence generated by method generate_string of class Random:")
    string = Random().generate_string(letters + digits, length)
    print(string)


# Generated at 2022-06-23 21:59:06.510095
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    for _ in range(10):
        # By default, we use @ for chars and # for digits
        code = r.custom_code()
        assert code.isalpha() or code.isdigit()

        # If you want to use another placeholder, you can specify it
        # via char and digit arguments.
        code = r.custom_code(char='*', digit='%', mask='*%%%')
        assert code.isalpha() or code.isdigit()

# Generated at 2022-06-23 21:59:08.021289
# Unit test for constructor of class Random
def test_Random():
  result = Random()
  assert(isinstance(result, Random))


# Generated at 2022-06-23 21:59:13.233952
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints(amount=3)) == 3
    assert len(random.randints(amount=3, a=1, b=10)) == 3

    def a():
        random.randints(amount=-1)
    def b():
        random.randints(amount=0)

    assert len(random.randints()) == 3
    assert len(random.randints(1)) == 1
    assert len(random.randints(1, 1, 10)) == 1
    assert random.randints(1, 1, 10)[0] <= 10
    assert random.randints(1, 1, 10)[0] >= 1
    assert random.randints(-1, 1, 10) is None
    assert random.randints(0, 1, 10) == []

    assert len(random.randints(3)) == 3
   

# Generated at 2022-06-23 21:59:19.870656
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    assert len(Random().randstr()) == 32

    rnd = Random()
    unique = True
    assert isinstance(rnd.randstr(unique=unique), str)
    assert len(rnd.randstr(unique=unique)) == 32

    unique = False
    assert isinstance(rnd.randstr(unique=unique), str)
    assert len(rnd.randstr(unique=unique)) > 0
    assert len(rnd.randstr(unique=unique)) <= 128

# Generated at 2022-06-23 21:59:22.016052
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints()) == 3
    assert isinstance(random.randints(), list)
    assert isinstance(random.randints()[0], int)



# Generated at 2022-06-23 21:59:23.717065
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    custom_code = random.custom_code()
    assert isinstance(custom_code, str)
    assert len(custom_code) == 4

# Generated at 2022-06-23 21:59:25.818454
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code()
    assert isinstance(code, str)



# Generated at 2022-06-23 21:59:35.837907
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    r.seed(1)

    strings = []
    for i in range(10):
        strings.append(r.generate_string('Aaa', 6))
    assert ''.join(strings) == 'AaaAAaAaAaAaAa'

    strings = []
    for i in range(10):
        strings.append(r.generate_string('0123456789', 3))
    assert ''.join(strings) == '2014507614'

    strings = []
    for i in range(10):
        strings.append(r.generate_string('!@#$%^&*'))
    assert ''.join(strings) == '^!$%!&!$&&%!&^'

# Generated at 2022-06-23 21:59:43.287220
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test Random.custom_code()."""
    from mimesis.providers.code import Code

    code = Code()
    assert code.code(mask='@#A#1') == ''
    assert code.code(mask='<@>') == '<@>'
    assert code.code(mask='@1') == 'A1'
    assert code.code(mask='AA1') == 'AA1'
    assert code.code(mask='@1@1@1') == 'A1A1A1'
    assert code.code(mask='@###') == 'A001'
    assert code.code(mask='<@###>') == '<A001>'



# Generated at 2022-06-23 21:59:45.051338
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    sample_string = 'abc'
    sample_length = 10
    result = Random().generate_string(sample_string, sample_length)
    assert len(result) == sample_length



# Generated at 2022-06-23 21:59:47.822778
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test the ``randstr`` method of the :class:`Random` class.
    """
    rnd = Random()
    for _ in range(0, 100):
        assert len(rnd.randstr()) > 0

# Generated at 2022-06-23 21:59:53.903319
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = random_module.Random()
    rnd1 = random_module.Random()
    rnd2 = random_module.Random()

    x = rnd.randints(10)
    y = rnd1.randints(10)
    z = rnd2.randints(10)

    x_s = set(x)
    y_s = set(y)
    z_s = set(z)

    assert len(x_s) == len(x)
    assert len(y_s) == len(y)
    assert len(z_s) == len(z)



# Generated at 2022-06-23 21:59:56.048172
# Unit test for constructor of class Random
def test_Random():
    """Test for constructor of class Random."""
    # Test
    random = Random()

    # Check result
    assert random is not None

# Generated at 2022-06-23 22:00:00.494295
# Unit test for method uniform of class Random
def test_Random_uniform():
    upper, lower = 100.12, 20.34
    assert random.uniform(upper, lower) < upper and random.uniform(upper, lower) >= lower
    assert random.uniform(upper, lower) < upper and random.uniform(upper, lower) >= lower
    assert random.uniform(upper, upper + 0.1) < upper + 0.1 and random.uniform(upper, upper + 0.1) >= upper

# Generated at 2022-06-23 22:00:00.987521
# Unit test for function get_random_item
def test_get_random_item():
    # ...
    pass

# Generated at 2022-06-23 22:00:03.006745
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(10)

# Generated at 2022-06-23 22:00:13.129927
# Unit test for method uniform of class Random
def test_Random_uniform():
    for _ in range(10):
        f = random.uniform(-0.1, 0.1)
        assert -0.1 <= f <= 0.1
        assert isinstance(f, float)

        f = random.uniform(2.5, 3.5)
        assert 2.5 <= f <= 3.5
        assert isinstance(f, float)

        f = random.uniform(4, 5)
        assert 4 <= f <= 5
        assert isinstance(f, float)

        f = random.uniform(7, 7.5)
        assert 7 <= f <= 7.5
        assert isinstance(f, float)

        f = random.uniform(13, 12)
        assert 12 <= f <= 13
        assert isinstance(f, float)

# Generated at 2022-06-23 22:00:23.316067
# Unit test for method urandom of class Random
def test_Random_urandom():
    # assert isinstance(random.urandom(), bytes)
    assert issubclass(random.urandom(), bytes)

    # Positive case

# Generated at 2022-06-23 22:00:24.777030
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test method urandom from class Random."""
    _ = Random.urandom(16)
    assert isinstance(_, bytes)



# Generated at 2022-06-23 22:00:29.322878
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()

    assert abs(rnd.uniform(1, 10) - 5.0) < 1.0
    assert abs(rnd.uniform(0, 1, 8) - 0.5) < 0.5

# Generated at 2022-06-23 22:00:34.884967
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert(rnd.uniform(1.0, 1.4) == 1.0)
    assert(rnd.uniform(1.0, 2.5) == 1.0)
    assert(rnd.uniform(1.0, 2.5) == 1.0)
    assert(rnd.uniform(1.0, 2.0) == 1.0)
    assert(rnd.uniform(1.0, 3.0) == 1.0)
    assert(rnd.uniform(2.0, 2.5) == 2.0)
    assert(rnd.uniform(4.0, 4.5) == 4.0)
    assert(rnd.uniform(5.0, 5.5) == 5.0)

# Generated at 2022-06-23 22:00:35.716807
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    _ = Random()
    assert _ is not None

# Generated at 2022-06-23 22:00:39.534063
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    cs = string.ascii_letters + string.digits
    string_list = [random.custom_code('@###', '@', '#') for _ in range(10)]

# Generated at 2022-06-23 22:00:41.965303
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    print(', '.join(str(Random().generate_string('aA0')) for _ in range(10)))


# Generated at 2022-06-23 22:00:46.878441
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() == 'R891'
    assert random.custom_code(mask='@@@', char='@') == 'ZLN'
    assert random.custom_code(mask='@@@', char='@') == 'ZLN'
    assert len(random.custom_code(mask='@@@@@@@', char='@')) == 7

# Generated at 2022-06-23 22:00:49.627369
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert(len(Random().generate_string('abcd')) == 10)
    assert(len(Random().generate_string('abcd', 5)) == 5)
    assert(len(Random().generate_string('')) == 10)
    assert(len(Random().generate_string('', 10)) == 10)


# Generated at 2022-06-23 22:00:52.553109
# Unit test for method randstr of class Random
def test_Random_randstr():
    _randstr = random.randstr()

    assert isinstance(_randstr, str)
    assert len(_randstr) > 0
    assert len(_randstr) <= 128



# Generated at 2022-06-23 22:00:55.112036
# Unit test for method urandom of class Random
def test_Random_urandom():
    sample = Random().urandom(50)
    assert len(sample) == 50
    assert type(sample) is bytes

# Generated at 2022-06-23 22:00:57.345025
# Unit test for method urandom of class Random
def test_Random_urandom():
    _bytes = Random.urandom(16)
    assert isinstance(_bytes, bytes)
    assert len(_bytes) == 16

# Generated at 2022-06-23 22:01:04.436672
# Unit test for method uniform of class Random
def test_Random_uniform():
    """The unit tests for method uniform() of class Random.

    :return: None
    """
    a = 0.0
    b = 1.0
    c = 0.0
    d = 0.0
    eps = 1e-9
    n = 10**4

    for _ in range(n):
        x = random.uniform(a, b)
        assert a <= x < b
        c += x
        d += x ** 2
    c /= n
    d /= n
    assert abs(c - (a + b) / 2) < eps
    assert abs(d - (a ** 2 + b ** 2) / 3) < eps

# Generated at 2022-06-23 22:01:12.959180
# Unit test for function get_random_item
def test_get_random_item():
    """Test for function get_random_item."""
    class TestEnum(object):
        """Test enum."""

        __FIRST_ITEM = 'First'
        __SECOND_ITEM = 'Second'
        __THIRD_ITEM = 'Third'
        __FOURTH_ITEM = 'Fourth'

    assert get_random_item(TestEnum) in [
        TestEnum.__FIRST_ITEM,
        TestEnum.__SECOND_ITEM,
        TestEnum.__THIRD_ITEM,
        TestEnum.__FOURTH_ITEM,
    ]

    rnd = Random()

# Generated at 2022-06-23 22:01:18.109062
# Unit test for method randints of class Random
def test_Random_randints():
    # Positive
    result = random.randints(3, 1, 3)
    assert len(result) == 3
    assert all(elem in [1, 2, 3] for elem in result)

    # Negative
    try:
        random.randints(-5)
    except ValueError as e:
        assert 'Amount out of range' in str(e)



# Generated at 2022-06-23 22:01:20.909823
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    test_sample = rnd.randints(10)
    b = rnd.custom_code()
    assert isinstance(test_sample, list)
    assert isinstance(b, str)

# Generated at 2022-06-23 22:01:23.677187
# Unit test for constructor of class Random
def test_Random():
    rnd = Random(1)
    assert isinstance(rnd, Random)
    assert rnd.random() == 0.13436424411240122
    assert rnd.randint(0, 10) == 7
    assert rnd.randint(0, 100) == 73
    
    

# Generated at 2022-06-23 22:01:24.465930
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.Random().urandom(10), bytes)


# Generated at 2022-06-23 22:01:34.233476
# Unit test for method custom_code of class Random