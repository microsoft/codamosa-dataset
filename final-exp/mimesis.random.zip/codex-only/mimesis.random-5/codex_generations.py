

# Generated at 2022-06-23 21:51:28.947570
# Unit test for constructor of class Random
def test_Random():
    """Test constructor of class Random."""
    assert isinstance(random, Random)

# Generated at 2022-06-23 21:51:30.129069
# Unit test for constructor of class Random
def test_Random():
    try:
        Random()
    except:
        print("Error at constructor of class Random")
        assert False


# Generated at 2022-06-23 21:51:35.336249
# Unit test for method randstr of class Random
def test_Random_randstr():
    rand = Random()
    rand_str = rand.randstr(length=16)
    rand_str2 = rand.randstr()
    rand_str3 = rand.randstr(unique=True)
    assert len(rand_str) == 16
    assert len(rand_str2) >= 16
    assert len(rand_str3) == 32
    assert rand_str != rand_str2

# Generated at 2022-06-23 21:51:39.486123
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender, WeekDay

    _ = get_random_item(enum=Gender, rnd=random)
    _ = get_random_item(enum=WeekDay, rnd=random)
    _ = get_random_item(enum=WeekDay, rnd=random)

# Generated at 2022-06-23 21:51:50.392471
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    rand_list = r.randints()
    assert isinstance(rand_list, list)

    rand_list = r.randints(amount=10)
    assert isinstance(rand_list, list)
    assert len(rand_list) == 10

    rand_list = r.randints(amount=10, a=10, b=20)
    assert isinstance(rand_list, list)
    assert len(rand_list) == 10
    assert all(i >= 10 for i in rand_list)
    assert all(i <= 20 for i in rand_list)

    rand_list = r.randints(amount=10, a=10)
    assert isinstance(rand_list, list)
    assert len(rand_list) == 10
    assert all(i >= 10 for i in rand_list)

# Generated at 2022-06-23 21:51:52.764781
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0, 1.0) == 0.5248444844444444
    assert random.uniform(10, 100.0) == 53.4047661185874

# Generated at 2022-06-23 21:51:54.115482
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random.providers.Gender), str)

# Generated at 2022-06-23 21:52:04.729835
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    import string
    import unittest

    class TestRand(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            """Set up class method."""
            cls.rnd = Random()
            cls.str_seq = string.ascii_letters + string.digits

        def test_custom_code(self):
            """Test custom code."""
            # Generate custom code using ascii uppercase and random integers.
            code = self.rnd.custom_code(mask='@###', char='@', digit='#')
            # Check the length of generated code is equal to mask
            self.assertEqual(len(code), 4)

            # Check if generated code contains only ascii uppercase and integers

# Generated at 2022-06-23 21:52:09.784392
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for method ``custom_code()`` of class ``Random()``."""
    a = Random()
    if a.custom_code(mask='123', char='1', digit='2') == '123':
        raise ValueError('You cannot use the same '
                         'placeholder for digits and chars!')

# Generated at 2022-06-23 21:52:12.182089
# Unit test for method randints of class Random
def test_Random_randints():
    random.seed(0)
    assert random.randints() == [1, 1, 2]


# Generated at 2022-06-23 21:52:15.108625
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)
    assert isinstance(get_random_item(Gender, rnd=Random()), Gender)

# Generated at 2022-06-23 21:52:26.518696
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    class TestVal:
        def __init__(self, code, mask, num):
            self.code = code
            self.mask = mask
            self.num = num

    test_values = list()
    test_values.append(TestVal('A12B', 'A##B', 2))
    test_values.append(TestVal('AA12B', 'AA##B', 2))
    test_values.append(TestVal('AA12B', 'AA##B', 2))
    test_values.append(TestVal('AA12BB', 'AA##BB', 2))
    test_values.append(TestVal('AbCd01E', 'AbCd##E', 2))
    test_values.append(TestVal('AbCd01Ef', 'AbCd##Ef', 2))

    r = Random()
   

# Generated at 2022-06-23 21:52:28.182975
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    x = Random()
    print(x.custom_code('@###', '@', '#'))

# Generated at 2022-06-23 21:52:33.800671
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert(rnd.custom_code(mask='@###', char='@', digit='#') == 'B902')
    assert(rnd.custom_code(mask='@@###', char='@', digit='#') == 'KL902')
    assert(rnd.custom_code(mask='@@####', char='@', digit='#') == 'KL4902')

# Generated at 2022-06-23 21:52:37.556970
# Unit test for method uniform of class Random
def test_Random_uniform():
    for i in range(10):
        a = random_module.random()
        b = random.uniform(0, 1)
        assert abs(a - b) < 0.000001

# Generated at 2022-06-23 21:52:42.361969
# Unit test for method randints of class Random
def test_Random_randints():
    assert(len(Random().randints()) == 3)
    assert(len(Random().randints(amount=5)) == 5)
    assert(len(Random().randints(amount=2)) == 2)
    assert(len(Random().randints(amount=1)) == 1)
    assert(len(Random().randints(amount=0)) == 0)


# Generated at 2022-06-23 21:52:45.389048
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    assert r.uniform(4, 9) < 9
    assert r.uniform(4, 9) > 4

# Generated at 2022-06-23 21:52:46.004813
# Unit test for constructor of class Random
def test_Random():
    assert Random(3)



# Generated at 2022-06-23 21:52:50.882445
# Unit test for method randstr of class Random
def test_Random_randstr():
    length = random.randint(16, 128)
    randstr = random.randstr()
    assert len(randstr) == length
    rand_str_uniq = random.randstr(unique=True)
    assert rand_str_uniq.isalnum()

# Generated at 2022-06-23 21:53:02.375930
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    expected_result1 = "M"
    expected_result2 = "1A1"
    expected_result3 = "5B5"

    random1 = Random(1)
    random2 = Random(2)
    random3 = Random(3)

    result1 = random1.custom_code()
    result2 = random2.custom_code()
    result3 = random3.custom_code()

    assert (result1 == expected_result1), \
        "Expected result is {0}, but actual result is {1}".format(
            expected_result1, result1
        )

    assert (result2 == expected_result2), \
        "Expected result is {0}, but actual result is {1}".format(
            expected_result2, result2
        )


# Generated at 2022-06-23 21:53:05.998752
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    rnd = Random()
    result = rnd.randints(3)
    assert isinstance(result, list)
    assert len(result) == 3

# Generated at 2022-06-23 21:53:06.975351
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random.urandom(100), bytes)

# Generated at 2022-06-23 21:53:09.800037
# Unit test for method randstr of class Random
def test_Random_randstr():
    for _ in range(100):
        assert len(Random().randstr()) >= 16
        assert len(Random().randstr(length=10)) == 10
        assert isinstance(Random().randstr(), str)

# Generated at 2022-06-23 21:53:13.215498
# Unit test for function get_random_item
def test_get_random_item():
    class C(object):
        A = 1
        B = 2
        C = 3


# Generated at 2022-06-23 21:53:19.097071
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    assert isinstance(r.randints(1), list)
    assert len(r.randints(10)) == 10

    with Random.seed(1):
        assert r.randint(a=10, b=50) == r.randints(10)[0]



# Generated at 2022-06-23 21:53:19.916272
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random().urandom(16), bytes)


# Generated at 2022-06-23 21:53:22.762306
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    mask = '@###-@@@'
    code = rnd.custom_code(mask)
    mask = '###-@@@-###'
    code = rnd.custom_code(mask, '@', '#')

# Generated at 2022-06-23 21:53:25.277048
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string('1234567890')) == 10
    assert len(Random().generate_string('1234567890', length=3)) == 3



# Generated at 2022-06-23 21:53:29.154897
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for ``Random.urandom()``.

    Test checks for the correct return type of ``Random.urandom()``.
    """
    random_class = Random()
    urandom = random_class.urandom(5)

    assert isinstance(urandom, bytes)
    assert len(urandom) == 5

# Generated at 2022-06-23 21:53:39.699574
# Unit test for function get_random_item
def test_get_random_item():
    # When enum object is passed.
    get_random_item(enum=0)
    get_random_item(enum=0, rnd=random_module)
    get_random_item(enum=0, rnd=Random())
    get_random_item(enum=0, rnd=random)

    # When non-enum object is passed.
    try:
        get_random_item(enum=None)
    except TypeError as e:
        assert(str(e) == '\'NoneType\' object is not iterable')

    # When no object is passed.
    try:
        get_random_item()
    except TypeError as e:
        assert(str(e) == 'get_random_item() missing 1 required positional '
                         'argument: \'enum\'')


test_get_random_item()

# Generated at 2022-06-23 21:53:40.629152
# Unit test for function get_random_item
def test_get_random_item():
    assert type(get_random_item(enum=string.digits)) is str

# Generated at 2022-06-23 21:53:48.956135
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(random.custom_code(mask='@@@')) == 3
    assert len(random.custom_code(mask='@@@###')) == 6
    assert len(random.custom_code(mask='@@@@@@@')) == 7
    assert len(random.custom_code(mask='@@@@@@@####')) == 11
    assert len(random.custom_code(mask='@@@###')) == 6
    assert len(random.custom_code(mask='@@@###',
                                  char='X', digit='Y')) == 6

# Generated at 2022-06-23 21:53:59.071234
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()

    # Basic usage
    assert rnd.custom_code('BBB-#-###')

    # Mask with only chars
    assert rnd.custom_code('@@@')

    # Mask with only digits
    assert rnd.custom_code('###')

    # Mask which contains only one char
    assert rnd.custom_code('B###')

    # Mask which contains only one digit
    assert rnd.custom_code('B##B')

    # Mask with only one digit or char
    assert rnd.custom_code('B')

    # Mask contains only several digits or chars
    assert rnd.custom_code('BB-B')

    # Mask contains digits and chars are equal

# Generated at 2022-06-23 21:54:00.872996
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random().urandom(5)) == 5
    assert len(Random().urandom(100)) == 100
    assert len(Random().urandom(100)) == 100

# Generated at 2022-06-23 21:54:05.796241
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints of class Random."""
    rnd = Random()
    _range = rnd.randint(25, 100)
    actual = rnd.randints(amount=10, a=25, b=_range)
    len_list = len(actual)
    assert (len_list == 10 and
            all(25 <= item < _range for item in actual) is True)
    # test for exception
    try:
        rnd.randints(amount=-5)
    except ValueError:
        pass
    else:
        raise AssertionError('There is no exception!')



# Generated at 2022-06-23 21:54:07.987122
# Unit test for constructor of class Random
def test_Random():
    instance = Random()
    assert isinstance(instance, Random)

# Generated at 2022-06-23 21:54:09.538755
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert isinstance(random.uniform(5.5, 10.5), float)

# Generated at 2022-06-23 21:54:12.693678
# Unit test for method uniform of class Random
def test_Random_uniform():
    for i in range(100):
        r = random.uniform(1, 2)
        if r < 1 or r >= 2:
            raise Exception('Error')

test_Random_uniform()

# Generated at 2022-06-23 21:54:13.776367
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    s = Random().generate_string('ABCD123')
    assert len(s) == 10
    assert isinstance(s, str)

# Generated at 2022-06-23 21:54:17.290626
# Unit test for method randints of class Random
def test_Random_randints():
    assert(len(Random().randints()) > 0)
    assert(isinstance(Random().randints(), list))
    assert(len(Random().randints(amount=0)) == 0)
    assert(len(Random().randints(amount=1, a=10, b=20)) == 1)


# Generated at 2022-06-23 21:54:18.496409
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string('abcdef', 10) == 'bfbfdefaef'

# Generated at 2022-06-23 21:54:19.751622
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    assert len(random.rndstr()) == 32

# Generated at 2022-06-23 21:54:21.559207
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom()

# Generated at 2022-06-23 21:54:27.070439
# Unit test for method uniform of class Random
def test_Random_uniform():
    from decimal import getcontext, Decimal
    from test.utils import consts

    getcontext().prec = consts.PRECISION_UNIT_TEST
    rnd = Random()
    value = Decimal(rnd.uniform(0, 1, precision=15))
    value = Decimal(value).quantize(Decimal('0.00000000000001'))
    assert 0 < value < 1

# Generated at 2022-06-23 21:54:28.935447
# Unit test for function get_random_item
def test_get_random_item():
    _list = [random.randstr(), random.randstr()]
    assert get_random_item(_list) in _list

# Generated at 2022-06-23 21:54:30.425785
# Unit test for method randints of class Random
def test_Random_randints():
    random.seed(1)
    assert random.randints(0, 10, 100) == [44, 96, 96]


# Generated at 2022-06-23 21:54:33.228688
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert isinstance(random.uniform(0, 1), float)
    assert isinstance(random.uniform(0, 1, 5), float)
    assert isinstance(random.uniform(0, 1, precision=5), float)

# Generated at 2022-06-23 21:54:34.401943
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)



# Generated at 2022-06-23 21:54:36.601513
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert round(random.uniform(2.718, 3.141), 5) == round(3.0147, 5)

# Generated at 2022-06-23 21:54:41.147234
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    assert all(isinstance(r.generate_string('01'), str) for _ in range(10))
    assert all(isinstance(r.generate_string('01', 20), str) for _ in range(10))



# Generated at 2022-06-23 21:54:42.808382
# Unit test for constructor of class Random
def test_Random():
    rnd = random_module.Random()
    assert random_module.Random().random() == rnd.random()
    rnd = Random()
    assert Random().random() == rnd.random()



# Generated at 2022-06-23 21:54:51.180436
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random"""
    # Get random string without parameters
    rand_str = Random().randstr()
    # Check the length of string
    assert len(rand_str) >= 16 and len(rand_str) <= 128
    # Get random string with length=32
    rand_str = Random().randstr(length=32)
    # Check the length of string
    assert len(rand_str) == 32
    # Get unique random string
    rand_str = Random().randstr(unique=True)
    # Check the length of string
    assert len(rand_str) == 32
    # Get unique random string
    rand_str = Random().randstr(unique=True, length=32)
    # Check the length of string
    assert len(rand_str) == 32



# Generated at 2022-06-23 21:54:56.535295
# Unit test for constructor of class Random
def test_Random():
    #: Random object.
    rnd = random
    assert isinstance(rnd, Random)
    assert isinstance(rnd.randstr(length=15), str)
    assert isinstance(rnd.randstr(), str)
    assert isinstance(rnd.custom_code(), str)
    assert isinstance(rnd.generate_string(str_seq='0123456789'), str)
    assert len(rnd.generate_string(str_seq='0123456789', length=50)) == 50
    assert isinstance(rnd.randints(), list)
    assert len(rnd.randints(amount=20)) == 20
    assert isinstance(rnd.randint(), int)
    assert rnd.uniform(a=1.0, b=25.0) <= 25.0

# Generated at 2022-06-23 21:54:58.100663
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)
    assert isinstance(Random(1), Random)


# Generated at 2022-06-23 21:54:59.928906
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(Random().generate_string('abc'), str)



# Generated at 2022-06-23 21:55:05.974179
# Unit test for function get_random_item
def test_get_random_item():
    try:
        from enum import Enum
        class TestEnum(Enum):
            a = 1
            b = 2
            c = 3
            d = 4
            e = 5
        print(get_random_item(TestEnum))
        print(get_random_item(TestEnum, random.Random()))
    except ImportError:
        pass


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-23 21:55:11.482901
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints()) == 3
    assert len(random.randints(amount=2, a=1, b=1)) == 2
    assert len(random.randints(amount=4, a=1, b=1)) == 4

    # Assert for ValueError
    try:
        random.randints(amount=0)
    except ValueError:
        pass

# Generated at 2022-06-23 21:55:12.308006
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)

# Generated at 2022-06-23 21:55:16.449013
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.builtins import EnumField

    _enum = EnumField.__members__
    _random_item = get_random_item(_enum)
    assert isinstance(_random_item, EnumField)


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-23 21:55:17.796204
# Unit test for constructor of class Random
def test_Random():
    assert Random().randint(1, 1000)
    assert Random().randint(1, 1000)
    assert Random().randint(1, 1000)

# Generated at 2022-06-23 21:55:21.201736
# Unit test for method randints of class Random
def test_Random_randints():
    a = 1
    b = 10
    rnd = random.randints(amount=10, a=a, b=b)
    assert len(rnd) == 10
    assert all(elem >= a and elem <= b for elem in rnd)


# Generated at 2022-06-23 21:55:23.023076
# Unit test for function get_random_item
def test_get_random_item():
    from .enums import Profession
    result = get_random_item(enum=Profession)
    assert isinstance(result, Profession)

# Generated at 2022-06-23 21:55:26.340634
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert b'\xe1\xb5\x19\xed\xbb\xf5\xcc\xe1\x85\x1d\xe4\x83\x95' == random.urandom(16)


# Generated at 2022-06-23 21:55:28.949499
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert isinstance(random.custom_code('@###'), str)
    assert len(random.custom_code('@###')) == 4
    assert isinstance(random.custom_code(), str)
    assert isinstance(random.custom_code('@@###'), str)
    assert len(random.custom_code('@@###')) == 5


# Generated at 2022-06-23 21:55:30.158755
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(16) > 0

# Generated at 2022-06-23 21:55:32.852709
# Unit test for method uniform of class Random
def test_Random_uniform():
    random_module.seed(1)
    result = round(sum([random.uniform(1, 2) for _ in range(1000)]), 3)
    assert result == 1000.0

# Generated at 2022-06-23 21:55:35.057985
# Unit test for constructor of class Random
def test_Random():
    from mimesis.builtins.enums import Gender
    rnd = Random()  # noqa
    assert Gender.MALE.name == get_random_item(Gender)
    assert Gender.MALE.name == get_random_item(Gender, rnd)

# Generated at 2022-06-23 21:55:38.082366
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test for method ``generate_string()`` of class ``Random()``."""
    sequence = 'string sequence'
    assert len(random.generate_string(sequence)) == 10


# Generated at 2022-06-23 21:55:44.048328
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender, OperatingSystem
    gender = get_random_item(Gender)
    os = get_random_item(OperatingSystem)

    assert gender in Gender
    assert os in OperatingSystem
    assert isinstance(gender, str)
    assert isinstance(os, str)



# Generated at 2022-06-23 21:55:55.909066
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    test_Random = Random()
    

# Generated at 2022-06-23 21:55:56.912599
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    assert random is not None

# Generated at 2022-06-23 21:56:00.424476
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string('BCDFGHJKLMNPQRSTVWXYZbcdfghjklmnpqrstvwxyz2345678') == 'fjK5vX8W93'



# Generated at 2022-06-23 21:56:12.243275
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method ``randints`` of class ``Random``.

    Unit test for method ``randints`` of class ``Random``.
    Method ``randints`` must return list of random integers
    with the length equal to the given parameter amount.
    If the amount parameter is less than or equal to zero,
    it must raise ``ValueError``.
    """
    rnd = random_module.Random()
    r = Random()

    for i in range(10000):
        amount = rnd.randint(1, 100)
        min_value = rnd.randint(1, 100)
        max_value = rnd.randint(min_value, 100)

        expected = [rnd.randint(min_value, max_value)
                    for _ in range(amount)]

# Generated at 2022-06-23 21:56:13.135051
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)



# Generated at 2022-06-23 21:56:21.142550
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    from mimesis.builtins import enums

    def test_get_with_enum(g: Gender, e: Any) -> None:
        item = get_random_item(g)
        assert item in e
        assert isinstance(item, e)

    def test_get_with_custom_random(g: Gender) -> None:
        custom_random = Random()
        item = get_random_item(g, custom_random)
        assert item in Gender.__members__.values()

    test_get_with_enum(Gender, enums.GENDERS)
    test_get_with_custom_random(Gender)

# Generated at 2022-06-23 21:56:29.948437
# Unit test for method randints of class Random
def test_Random_randints():
    """Test function for method ``randints()`` of class ``Random()``."""
    a = [random.randints() for _ in range(1000)]
    b = [random.randints(a=0) for _ in range(1000)]
    c = [random.randints(b=500) for _ in range(1000)]
    d = [random.randints(amount=10) for _ in range(1000)]

    assert all(0 <= x[0] <= 100 for x in a)
    assert all(0 <= x[0] <= 100 for x in b)
    assert all(0 <= x[0] <= 500 for x in c)
    assert all(10 == len(x) for x in d)



# Generated at 2022-06-23 21:56:34.791024
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Test 1: Only unique values
    values = [random.randstr(unique=True) for _ in range(5)]
    assert len(set(values)) == len(values)

    # Test 2: Test length of string
    for _ in range(5):
        _len = random.randint(16, 128)
        assert len(random.randstr(length=_len)) == _len

# Generated at 2022-06-23 21:56:38.031601
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(random.generate_string(length=10), str)
    assert isinstance(random.generate_string(str_seq=string.digits), str)
    assert isinstance(random.generate_string(length=1), str)



# Generated at 2022-06-23 21:56:40.101709
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import DataType

    rnd = random.choice(list(DataType))
    assert isinstance(rnd, DataType)

# Generated at 2022-06-23 21:56:47.363892
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert rnd.uniform(0, 0.5) > 0
    assert rnd.uniform(0, 0.5) < 0.5
    assert rnd.uniform(1, 5) > 1
    assert rnd.uniform(1, 5) < 5
    assert rnd.uniform(-1, -0.5) > -1
    assert rnd.uniform(-1, -0.5) < -0.5

# Generated at 2022-06-23 21:56:50.893405
# Unit test for function get_random_item
def test_get_random_item():
    class TestEnum(object):
        def __init__(self):
            self.A = 0
            self.B = 1
            self.C = 2

    assert get_random_item(TestEnum()) in (0, 1, 2)



# Generated at 2022-06-23 21:57:01.267587
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item"""
    # pylint: disable=import-outside-toplevel
    import pytest
    from mimesis.enums import Gender, Locale
    test_locales = [Locale, Gender]
    test_rnd = Random()

    for test_locale in test_locales:
        locale1 = get_random_item(test_locale, test_rnd)
        locale2 = get_random_item(test_locale)
        assert isinstance(locale1, test_locale)
        assert isinstance(locale2, test_locale)

    with pytest.raises(TypeError):
        get_random_item(None)

    with pytest.raises(ValueError):
        get_random_item(None, test_rnd)

# Generated at 2022-06-23 21:57:06.062804
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    r.seed(1)
    data = ['TQQRV','TQQR','TQQ','TQ','T','','','','','','','','','','','']
    for i, val in enumerate(data):
        assert r.generate_string('TQQRV', i) == val


# Generated at 2022-06-23 21:57:11.451675
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum

    class MyEnum(Enum):
        """Simple enum for testing."""

        A = 'A'
        B = 'B'
        C = 'C'

    def test_get_random_item(random: Random):
        """Function-test for get_random_item()."""
        assert isinstance(random, Random)
        assert get_random_item(MyEnum) in MyEnum
        my_random = Random()
        assert get_random_item(MyEnum, my_random) in MyEnum

    test_get_random_item(Random())

# Generated at 2022-06-23 21:57:18.099987
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = random.uniform(a=0, b=2)
    assert rnd >= 0
    assert rnd <= 2

    rnd = random.uniform(a=10, b=20)
    assert rnd >= 10
    assert rnd <= 20

    rnd = random.uniform(a=0.5, b=1.5)
    assert rnd >= 0.5
    assert rnd <= 1.5



# Generated at 2022-06-23 21:57:21.090668
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    string = Random().custom_code()
    assert type(string) is str
    assert len(string) == 4
    assert '@' not in string
    assert '#' not in string

# Generated at 2022-06-23 21:57:22.858396
# Unit test for constructor of class Random
def test_Random():
    assert Random() is not None

# Generated at 2022-06-23 21:57:27.128672
# Unit test for constructor of class Random
def test_Random():
    '''
    user_inp = float(input('Введите число: '))
    rnd = Random()
    assert rnd.uniform(0.0, 1.0) == user_inp
    '''
    rnd = Random()
    assert rnd.randstr() != rnd.randstr()

# Generated at 2022-06-23 21:57:31.057290
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test of method randints."""
    _random = Random(13)
    _ints = _random.randints(amount=5, a=2, b=11)
    assert _ints == [2, 6, 10, 7, 8]

# Generated at 2022-06-23 21:57:34.680651
# Unit test for method randints of class Random
def test_Random_randints():
    assert random.randints(-10, -1) == []
    assert len(random.randints(3, 1, 100)) == 3
    assert random.randints()[0] <= 100



# Generated at 2022-06-23 21:57:37.495451
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    print(random.custom_code('@###', '@', '#'))

# Generated at 2022-06-23 21:57:41.615274
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    str_seq = rnd.generate_string(str_seq='qwertyuiop123456789!@#$%^&*()_+-=', length=10)
    assert isinstance(str_seq, str)



# Generated at 2022-06-23 21:57:49.156060
# Unit test for constructor of class Random
def test_Random():
    # todo: finish this test
    assert isinstance(Random(), Random)
    assert isinstance(Random(1), Random)
    assert isinstance(Random(1.2), Random)
    assert isinstance(Random([]), Random)
    assert isinstance(Random('string'), Random)
    assert isinstance(Random(()), Random)
    assert isinstance(Random(object), Random)
    assert isinstance(Random(Random), Random)
    assert isinstance(Random(Random.random), Random)
    assert isinstance(Random(lambda: None), Random)
    assert isinstance(Random(Random.random()), Random)



# Generated at 2022-06-23 21:57:52.334015
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    a = 0.0
    b = 0.5
    res = rnd.uniform(a, b)
    assert res >= a
    assert res <= b

# Generated at 2022-06-23 21:58:04.423299
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of class Random."""

    # Format: (boundary_1, boundary_2, precision, rnd)
    data = [
        (0, 10, 1, 4.3),
        (-25, 0, 1, -13.1),
        (0.2, 3.3, 4, 1.3107),
        (0.0, 1.0, 4, 0.8685),
        (12.323, 51.34, 5, 47.894)
    ]


# Generated at 2022-06-23 21:58:05.388757
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() is not None

# Generated at 2022-06-23 21:58:08.424080
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    rnd = Random()
    assert isinstance(get_random_item(Gender, rnd), Gender)
    assert isinstance(get_random_item(Gender), Gender) # noqa: F821

# Generated at 2022-06-23 21:58:09.660722
# Unit test for method urandom of class Random
def test_Random_urandom():
    urandom = random.urandom(2)
    assert len(urandom) == 2

# Generated at 2022-06-23 21:58:15.875053
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """
    1. Clear the data directory (no previously generated data)
    2. Generate a set of test data
    3. Make a dictionary for the test data (key: hash(code), value: code)
    4. Check for the uniqueness of generated data
    """
    import os
    import hashlib
    import shutil
    import functools

    dir_name = 'data/'
    dir_name_test = 'data_test'
    r = Random()
    n = 1000
    codes = set()

    if os.path.exists(dir_name_test):
        shutil.rmtree(dir_name_test)
    os.makedirs(dir_name_test)

    for i in range(n):
        code = r.custom_code()
        codes.add(code)

# Generated at 2022-06-23 21:58:20.044868
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints()) == 3
    assert len(random.randints(5)) == 5
    assert len(random.randints(5, 2)) == 5
    assert len(random.randints(5, 2, 10)) == 5



# Generated at 2022-06-23 21:58:23.171807
# Unit test for method uniform of class Random
def test_Random_uniform():
    """
    Unit test for method uniform of class Random.
    :return:
    """
    rnd = random.uniform(0, 1, precision=3)
    assert 0 <= rnd < 1

# Generated at 2022-06-23 21:58:30.676700
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    sz = random.generate_string(string.digits)
    res = True
    for ch in sz:
        if ch not in string.digits:
            res = False
    assert(res == True)

    sz = random.generate_string(string.ascii_letters)
    res = True
    for ch in sz:
        if ch not in string.ascii_letters:
            res = False
    assert(res == True)



# Generated at 2022-06-23 21:58:34.005043
# Unit test for method uniform of class Random
def test_Random_uniform():
    a = random.uniform(1, 5)
    assert a < 5 and a >= 1
    b = random.uniform(1, 5, 1)
    assert b < 5 and b >= 1
    assert len(str(abs(a-b))) == 4

# Generated at 2022-06-23 21:58:39.047580
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for ``Random.custom_code()``."""
    rnd = Random()
    result = rnd.custom_code()
    assert result.startswith('M')
    result = rnd.custom_code('@###')
    assert result.startswith('M')
    result = rnd.custom_code('@##')
    assert result.startswith('M')
    result = rnd.custom_code('@##$')
    assert result.startswith('M')
    result = rnd.custom_code('@##$##')
    assert result.startswith('M')
    result = rnd.custom_code('@##$##', '@', '#')
    assert result.startswith('M')

# Generated at 2022-06-23 21:58:41.178809
# Unit test for method randstr of class Random
def test_Random_randstr():
    # All of the next results have to be unique
    for _ in range(10):
        print(random.randstr(True))

# Generated at 2022-06-23 21:58:44.458056
# Unit test for function get_random_item
def test_get_random_item():
    class RandomChoice:
        NONE = 0
        SOME = 1
        ALL = 2

    assert isinstance(get_random_item(RandomChoice), int)

# Generated at 2022-06-23 21:58:47.380925
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Тестовый автоматизированный тест для метода custom_code класса Random
    rnd = Random(1)
    code = rnd.custom_code(mask='@@@-##-###', char='@', digit='#')
    assert code == 'HXV-76-922'

# Generated at 2022-06-23 21:58:51.734819
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Arrange
    value_one = random.generate_string("ABCDEFGH")
    value_two = random.generate_string("12345678")

    # Assert
    assert isinstance(value_one, str)
    assert isinstance(value_two, str)


# Generated at 2022-06-23 21:59:00.286292
# Unit test for method randints of class Random
def test_Random_randints():
    for _ in range(200):
        a = -150
        b = 250
        items = random.randints(amount=15, a=a, b=b)
        # check that all the items are within the range [a, b)
        for item in items:
            assert a <= item < b
    for i in range(2, 6):
        # 6x6=36 variants
        random.randints(amount=5, a=i, b=i)
    for _ in range(200):
        a = -150
        b = 250
        items = random.randints(a=a, b=b)
        # check that all the items are within the range [a, b)
        for item in items:
            assert a <= item < b

# Generated at 2022-06-23 21:59:04.071386
# Unit test for method uniform of class Random
def test_Random_uniform():
    # Test with value zero as a
    assert 0 <= random.uniform(0, 1) <= 1
    # Test with default precision
    assert (random.uniform(0, 1) - random.uniform(0, 1)) < 0.000000000000001



# Generated at 2022-06-23 21:59:09.496524
# Unit test for method randints of class Random
def test_Random_randints():
    # test with default values
    result = random.randints()
    assert len(result) == 3
    assert type(result[0]) is int
    for element in result:
        assert 1 <= element <= 100
    # test with custom values
    result = random.randints(amount=5, a=10, b=15)
    assert len(result) == 5
    assert type(result[0]) is int
    for element in result:
        assert 10 <= element <= 15
    # test with bad values
    try:
        result = random.randints(amount=0, a=1, b=10)
    except ValueError:
        assert True
    else:
        assert False



# Generated at 2022-06-23 21:59:11.599381
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(Random().randstr(unique=False), str)
    assert isinstance(Random().randstr(unique=True), str)

# Generated at 2022-06-23 21:59:13.280883
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr(unique=True) of class Random."""
    assert len(random.randstr(unique=True)) == 32



# Generated at 2022-06-23 21:59:15.053428
# Unit test for method urandom of class Random
def test_Random_urandom():
    r = random.urandom(16)
    assert type(r) is bytes
    assert len(r) == 16

# Generated at 2022-06-23 21:59:17.158317
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # result = random.custom_code()
    # assert result
    # assert len(result) == 4
    assert random.custom_code()

# Generated at 2022-06-23 21:59:25.245738
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    import unittest

    def check(str_seq, length):
        for i in range(10):
            res = list(random.generate_string(str_seq, length))
            for x in res:
                if x not in str_seq:
                    return False
        return True

    class TestRandom(unittest.TestCase):
        def test_seq_letters(self):
            self.assertTrue(check('abcdefghijklmnopqrstuvwxyz', 16))

        def test_seq_digits(self):
            self.assertTrue(check('1234567890', 5))

        def test_seq_mixed(self):
            self.assertTrue(check('abcdefghijklmnopqrstuvwxyz1234567890', 16))

    unittest.main()

# Generated at 2022-06-23 21:59:29.315353
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert isinstance(random.uniform(0, 1), float)
    assert random.uniform(0, 1) <= 1
    assert random.uniform(0, 1) >= 0


# Generated at 2022-06-23 21:59:34.422843
# Unit test for function get_random_item
def test_get_random_item():
    from collections import namedtuple

    Color = namedtuple('Color', 'red, green, blue')
    Colors = Color(red='red', green='green', blue='blue')

    assert get_random_item(Colors) in ['red', 'green', 'blue']
    assert get_random_item(
        Colors, rnd=Random(1)
    ) in ['red', 'green', 'blue']

# Generated at 2022-06-23 21:59:36.364597
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    _random_obj = Random()
    assert _random_obj.uniform(a=0.1, b=1.0) in range(0.1, 1)

# Generated at 2022-06-23 21:59:37.239848
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(Random().randints(), list)



# Generated at 2022-06-23 21:59:44.487263
# Unit test for constructor of class Random
def test_Random():
    # Test sequence of letters
    assert Random(12345).generate_string(str_seq=string.ascii_letters) != ''
    # Test sequence of digits
    assert Random(12345).generate_string(str_seq=string.digits) != ''

    # Test code
    assert Random(12345).custom_code() != ''
    assert Random(12345).custom_code(mask='@@@') != ''
    assert Random(12345).custom_code(mask='***') != ''
    assert Random(12345).custom_code(mask='@@') != ''
    assert Random(12345).custom_code(mask='&&') != ''
    assert Random(12345).custom_code(mask='@@') != ''

    # Test randstr()
    assert Random(12345).randstr() != ''

# Generated at 2022-06-23 21:59:46.239983
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(['1', '2', '3']) in ['1', '2', '3']

# Generated at 2022-06-23 21:59:49.788584
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    random.randstr()
    random.generate_string(str_seq='abc', length=1)

# Generated at 2022-06-23 21:59:51.450142
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test urandom method of the class Random."""
    r = Random()
    r.urandom(10)

# Generated at 2022-06-23 21:59:54.300384
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code()
    assert code[0].isupper()
    assert code[1].isdigit()
    assert code[2].isdigit()
    assert code[3].isdigit()

# Generated at 2022-06-23 21:59:55.683186
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(0, 1, 100) == [1, 2, 3]

# Generated at 2022-06-23 21:59:57.964734
# Unit test for method urandom of class Random
def test_Random_urandom():
    import os
    import random as random_module
    random = Random()
    rand_mod = random_module.Random()
    assert random.urandom() == rand_mod.urandom()

# Generated at 2022-06-23 22:00:00.851684
# Unit test for method randstr of class Random
def test_Random_randstr():
    _unique_value = random.randstr(unique=True)
    _value = random.randstr()

    assert isinstance(_unique_value, str)
    assert isinstance(_value, str)
    assert len(_unique_value) == 32
    assert len(_value) in range(16, 128 + 1)

# Generated at 2022-06-23 22:00:04.991109
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Testing of method custom_code of class Random.

    Define the mask for the code to be generated, the method generate
    a code, which contains only the symbols from the mask.
    """
    rnd = Random()
    mask = '####-####-##'
    code = rnd.custom_code(mask=mask)
    assert type(code) == str
    for c in mask:
        assert code.find(c) >= 0



# Generated at 2022-06-23 22:00:06.061537
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)

# Generated at 2022-06-23 22:00:08.629747
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Create random instance
    _rnd = Random()
    # Test value of random string
    _data = _rnd.randstr(length=16)
    assert len(_data) == 16

# Generated at 2022-06-23 22:00:11.877128
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    print(rnd.uniform(1.0, 2.0, 3))


if __name__ == '__main__':
    test_Random_uniform()

# Generated at 2022-06-23 22:00:13.545241
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    assert random.uniform(a=0, b=10, precision=2) in map(lambda x: round(x, 2), range(0, 10.01, 0.01))

# Generated at 2022-06-23 22:00:20.221800
# Unit test for function get_random_item
def test_get_random_item():
    import os
    import random
    import pytest

    class EnumTest:
        item1 = 1
        item2 = 2

    rnd = random.Random()
    rnd.seed(os.urandom(8))

    assert get_random_item(EnumTest, rnd) in list(EnumTest)
    assert get_random_item(EnumTest) in list(EnumTest)
    assert get_random_item(EnumTest, rnd=None) in list(EnumTest)
    with pytest.raises(TypeError, match=r"Provide enum object!"):
        get_random_item(5)
    with pytest.raises(TypeError, match=r"Provide enum object!"):
        get_random_item('string')

# Generated at 2022-06-23 22:00:24.913574
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code(mask='@###') == '@###'
    assert Random().custom_code(mask='@###', char='$', digit='%') == '$###'
    assert Random().custom_code(mask='@@@###') == '@@@###'
    assert Random().custom_code(mask='@@@###', char='$', digit='&') == '$$$###'
    return True

# Generated at 2022-06-23 22:00:36.850268
# Unit test for constructor of class Random
def test_Random():

    # Unit test for method randints()
    def test_randints():
        assert isinstance(Random().randints(), list)

    # Unit test for method urandom()
    def test_urandom():
        assert isinstance(Random().urandom(16), bytes)

    # Unit test for method generate_string()
    def test_generate_string():
        assert isinstance(Random().generate_string('abc'), str)

    # Unit test for method custom_code()
    def test_custom_code():
        assert isinstance(Random().custom_code(), str)

    # Unit test for method uniform()
    def test_uniform():
        assert isinstance(Random().uniform(1000, 2000), float)

    # Unit test for method randstr()

# Generated at 2022-06-23 22:00:38.450728
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print(Random().custom_code('###-@', '@', '#'))

# Generated at 2022-06-23 22:00:41.149657
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test method randstr of class Random.

    Run unit test for generation of random string value.
    """
    r = Random()
    assert len(r.randstr()) in range(16, 128)

# Generated at 2022-06-23 22:00:43.222671
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('%###', '%', '#') == '1AA0'



# Generated at 2022-06-23 22:00:49.962338
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(random.randstr()) == 32
    assert len(random.randstr()) == 32
    assert random.randstr(unique=True) != random.randstr(unique=True)

    assert len(random.randstr(length=10)) == 10
    assert len(random.randstr(length=64)) == 64
    assert not len(random.randstr(length=1000)) == 1000

    assert len(random.randstr(length=random.randint(1, 10000)))
    assert len(random.randstr(unique=True, length=random.randint(1, 10000)))

# Generated at 2022-06-23 22:00:56.465441
# Unit test for constructor of class Random
def test_Random():
    # Test `custom_code`
    assert random.custom_code() == '###@'
    assert random.custom_code('@@@') == '@@@'
    assert random.custom_code('#') == '#'
    assert random.custom_code('@@@@@@@') == '@@@@@@@'
    assert random.custom_code('@@@,@') == '@@@,@'
    assert random.custom_code('@@@,@,@') == '@@@,@,@'
    assert random.custom_code('@##,@##') == '@##,@##'
    assert random.custom_code('#,@,#,@') == '#,@,#,@'
    assert random.custom_code(None) == ''
    assert random.custom_code('') == ''
    assert random

# Generated at 2022-06-23 22:00:59.291133
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(-180, 180) <= 180 and random.uniform(-180, 180) >= -180 , "Method uniform of class Random doesn't return value between -180 and 180"

# Generated at 2022-06-23 22:01:01.711671
# Unit test for function get_random_item
def test_get_random_item():
    class Test:
        def __init__(self, *args, **kwargs):
            ...

    assert type(get_random_item(Test)) is Test
    assert isinstance(get_random_item(Test), Test)

# Generated at 2022-06-23 22:01:03.763819
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert get_random_item(Gender) in Gender

# Generated at 2022-06-23 22:01:11.576238
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(), str)
    assert 16 <= len(random.randstr()) <= 32
    assert isinstance(random.randstr(length=48), str)
    assert len(random.randstr(length=48)) == 48
    assert isinstance(random.randstr(unique=True), str)
    assert 32 == len(random.randstr(unique=True))
    assert isinstance(random.randstr(unique=True, length=32), str)
    assert isinstance(random.randstr(unique=True, length=32), str)
    # assert 32 == len(random.randstr(unique=True, length=32))



# Generated at 2022-06-23 22:01:13.894816
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string('abcdefg')) == 10
    assert len(Random().generate_string('abcdefg', 5)) == 5
    assert Random().generate_string('123456789') != ''



# Generated at 2022-06-23 22:01:19.046378
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    name = 'RANDOM_CODE'
    mask_code = 'F###'
    mask_varchar = 'W###'
    result_code = rnd.custom_code(mask=mask_code, char='F', digit='#')
    result_varchar = rnd.custom_code(mask=mask_varchar, char='W', digit='#')
    assert rnd.custom_code() == '@000', "Incorrect result!"
    assert len(result_code) == len(mask_code), "Incorrect result!"
    assert len(result_varchar) == len(mask_varchar), "Incorrect result!"
    assert result_code.isnumeric(), "Incorrect result!"
    assert not result_varchar.isnumeric(), "Incorrect result!"

# Generated at 2022-06-23 22:01:22.304028
# Unit test for function get_random_item
def test_get_random_item():
    class ExampleEnum:
        ONE = 'first'
        TWO = 'second'
        THREE = 'third'
    assert get_random_item(ExampleEnum) in [ExampleEnum.ONE, ExampleEnum.TWO, ExampleEnum.THREE]

# Generated at 2022-06-23 22:01:23.920275
# Unit test for constructor of class Random
def test_Random():
    """Test that random object extends ``Random()``."""
    assert isinstance(random, Random)

# Generated at 2022-06-23 22:01:27.867773
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    gen = Random()
    assert gen.generate_string(string.ascii_lowercase, 10) == 'qwwmkqpqaf'
    assert len(gen.generate_string(string.digits, 10)) == 10

# Generated at 2022-06-23 22:01:31.652293
# Unit test for method urandom of class Random
def test_Random_urandom():
    bytes1 = Random().urandom(32)
    bytes2 = Random().urandom(32)

    assert bytes1 != bytes2
    assert type(bytes1) is bytes
    assert len(bytes1) == 32
    assert len(bytes2) == 32

