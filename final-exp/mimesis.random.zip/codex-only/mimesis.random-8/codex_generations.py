

# Generated at 2022-06-23 21:51:29.442444
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    assert isinstance(rnd.generate_string(str_seq='abc'), str)


# Generated at 2022-06-23 21:51:32.517200
# Unit test for function get_random_item
def test_get_random_item():
    """Test function get_random_item()."""
    from mimesis.enums import Gender

    assert get_random_item(Gender) == Gender.MALE



# Generated at 2022-06-23 21:51:41.824483
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    import logging

    logger = logging.getLogger(__name__)
    # logger.setLevel(logging.DEBUG)
    # sh = logging.StreamHandler()
    # sh.setFormatter(logging.Formatter('%(levelname)s - %(message)s'))
    # logger.addHandler(sh)
    logger.debug('TEST FOR FUNCTION get_random_item.')
    rnd = Random()
    for _ in range(10):
        logger.debug(random.choice(list(enum)))
        logger.debug(get_random_item(enum, rnd))
        logger.debug('-' * 79)
    logger.debug('TEST for get_random_item() is successful.')



# Generated at 2022-06-23 21:51:47.783054
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###') == 'UBX9'
    assert random.custom_code('@###', '@') == 'MMQY'
    assert random.custom_code('@###', '@', '#') == 'LNQ8'
    assert random.custom_code('##@@', '@', '#') == '83LN'

# Generated at 2022-06-23 21:51:54.635107
# Unit test for constructor of class Random
def test_Random():
    """Unit test for ``Random()``."""
    rnd = Random()
    assert isinstance(rnd, random_module.Random)
    assert isinstance(rnd.uniform(1, 10), float)
    assert isinstance(rnd.randints(10), list)
    assert isinstance(rnd.custom_code(), str)
    assert isinstance(rnd.randstr(), str)
    assert rnd.urandom(1)
    assert rnd.random()
    assert rnd.uniform(0, 1)
    assert rnd.randrange(1, 10)

# Generated at 2022-06-23 21:51:57.091775
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string('@#$%^&*')) == 10
    assert len(Random().generate_string('@#$%^&*', 20)) == 20

# Generated at 2022-06-23 21:52:07.779143
# Unit test for method randints of class Random
def test_Random_randints():
    assert random.randints(amount=1,
                           a=0, b=2) == [1], 'randints must return [1]'

    assert random.randints(amount=2,
                           a=0, b=2) == [1, 0], 'randints must return [1, 0]'

    assert random.randints(amount=3,
                           a=0, b=2) == [1, 0, 0], 'randints must return [1, 0, 0]'

    assert len(random.randints(amount=10,
                               a=1, b=101)) == 10, 'randints must return list with length 10'

    assert random.randints(amount=0) == [], 'randints must return []'



# Generated at 2022-06-23 21:52:17.782243
# Unit test for function get_random_item
def test_get_random_item():
    class Test:
        A = 'A'
        B = 'B'
        C = 'C'

    def count_item(item: str, items: List[str]) -> int:
        res = 0
        for i in items:
            if i == item:
                res += 1
        return res

    rnd = Random()
    test_list = ['A', 'B', 'C']

    for _ in range(100):
        item = get_random_item(Test, rnd)
        assert item in test_list

    for _ in range(100):
        item = get_random_item(Test)
        assert item in test_list

    for _ in range(100):
        item = get_random_item(Test, random_module)
        assert item in test_list


# Generated at 2022-06-23 21:52:27.846370
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    str_mask = '##a-###'
    char = 'a'
    digit = '#'
    new_custom_code(str_mask, char, digit)

    str_mask = '##@-###'
    char = '@'
    digit = '#'
    new_custom_code(str_mask, char, digit)

    str_mask = '##A-###'
    char = 'A'
    digit = '#'
    new_custom_code(str_mask, char, digit)

    str_mask = '##@-###'
    char = 'a'
    digit = '#'
    new_custom_code(str_mask, char, digit)

    str_mask = '##a-###'
    char = '@'
    digit = '#'
    new_custom_

# Generated at 2022-06-23 21:52:36.651724
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    from mimesis.test import MockEnum
    from mimesis.typing import Enum

    gender = get_random_item(Gender)
    assert isinstance(gender, Gender)
    assert gender in Gender

    mock_enum = MockEnum()
    _ = get_random_item(mock_enum)
    _ = get_random_item(mock_enum)
    _ = get_random_item(mock_enum)
    _ = get_random_item(mock_enum)
    _ = get_random_item(mock_enum)
    _ = get_random_item(mock_enum)
    _ = get_random_item(mock_enum)

    mock_enum = MockEnum()

# Generated at 2022-06-23 21:52:38.711070
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    if __name__ == '__main__':
        import doctest
        doctest.testmod()

# Generated at 2022-06-23 21:52:40.861271
# Unit test for method urandom of class Random
def test_Random_urandom():
    result = random.urandom(20)
    assert isinstance(result, bytes)
    assert len(result) == 20


# Generated at 2022-06-23 21:52:42.799017
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    assert Random().getstate() == random_module.getstate()  # nosec



# Generated at 2022-06-23 21:52:43.771885
# Unit test for constructor of class Random
def test_Random():
    # TODO
    pass


# Generated at 2022-06-23 21:52:46.984587
# Unit test for method urandom of class Random
def test_Random_urandom():
    # TODO: Add unit test for method urandom of class Random
    assert True


# Generated at 2022-06-23 21:52:58.838633
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert isinstance(r.custom_code('@###'), str)
    assert isinstance(r.custom_code('A###'), str)
    assert isinstance(r.custom_code('@###', 'A', 'B'), str)
    assert isinstance(r.custom_code('A###', 'A', 'B'), str)
    assert isinstance(r.custom_code('??##'), str)
    assert isinstance(r.custom_code('@@@@'), str)
    assert isinstance(r.custom_code('ABCD'), str)
    assert isinstance(r.custom_code('0123'), str)
    assert isinstance(r.custom_code('!!!!'), str)
    assert isinstance(r.custom_code('####'), str)
    assert isinstance(r.custom_code(), str)


# Generated at 2022-06-23 21:53:02.418230
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(random.generate_string(string.punctuation), str)
    assert isinstance(random.generate_string(string.ascii_letters), str)



# Generated at 2022-06-23 21:53:12.485131
# Unit test for function get_random_item
def test_get_random_item():
    from random import Random
    from mimesis import Person, Datetime, Number
    from mimesis.enums import Gender
    from mimesis.enums import Month, Weekday
    from mimesis.enums import Unit, WeightUnit, Currency


    rnd = Random()
    person = Person()
    number = Number()
    dt = Datetime()

    gender = get_random_item(Gender, rnd=rnd)  # noqa
    month = get_random_item(Month, rnd=rnd)  # noqa
    weekday = get_random_item(Weekday, rnd=rnd)  # noqa
    unit = get_random_item(Unit, rnd=rnd)  # noqa
    weight_unit = get_random_item(WeightUnit, rnd=rnd)  #

# Generated at 2022-06-23 21:53:16.408349
# Unit test for method urandom of class Random
def test_Random_urandom():
    print(random.urandom(16))

if __name__ == '__main__':
    test_Random_urandom()

# Generated at 2022-06-23 21:53:22.708109
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@###') != Random().custom_code('@###')
    assert len(Random().custom_code('@###')) == 4
    assert len(Random().custom_code('@@##')) == 4
    assert len(Random().custom_code('@###@')) == 5
    assert len(Random().custom_code('@###@###')) == 8
    assert len(Random().custom_code('#@##')) == 4


# Generated at 2022-06-23 21:53:25.190156
# Unit test for method randints of class Random
def test_Random_randints():
    # Test the function with default parameters
    assert len(Random().randints()) == 3

    # Test the function with custom parameters
    assert len(Random().randints(amount=5)) == 5



# Generated at 2022-06-23 21:53:32.455624
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    rnd.random()
    rnd.randint()
    rnd.randrange()
    rnd.choice()
    rnd.sample()
    rnd.shuffle()
    rnd.normalvariate()
    rnd.lognormvariate()
    rnd.expovariate()
    rnd.vonmisesvariate()
    rnd.gammavariate()
    rnd.gauss()
    rnd.betavariate()
    rnd.paretovariate()
    rnd.weibullvariate()
    rnd.getstate()
    rnd.setstate()
    rnd.jumpahead()
    rnd.getrandbits()



# Generated at 2022-06-23 21:53:35.973223
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    string = r.generate_string(str_seq='ABCD1234', length=4)

    assert len(string) == 4
    assert string in ['ABCD', '1234']



# Generated at 2022-06-23 21:53:38.318982
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(Random().randstr(length=16)) == 16
    assert len(Random().randstr(length=32)) == 32
    assert len(Random().randstr(length=128)) == 128
    assert len(Random().randstr(length=4096)) == 4096

# Generated at 2022-06-23 21:53:39.397594
# Unit test for constructor of class Random
def test_Random():
    rand = Random()
    rand0 = rand.random()
    rand1 = random_module.random()
    assert rand0 == rand1

# Generated at 2022-06-23 21:53:41.492796
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1.0, 1.0) == 1.0
    assert random.uniform(1.0, 1.5) < 1.5

# Generated at 2022-06-23 21:53:48.514690
# Unit test for method randstr of class Random
def test_Random_randstr():
    text: str = random.randstr(unique=False, length=None)
    assert (text, type(text)) == ('y7VzJPbHJhVtYr1rYnZ7', str)

    text: str = random.randstr(unique=True, length=32)
    assert (text, type(text) == ('1c56ab7f91754742a3a7fcd8012d5971', str))

# Generated at 2022-06-23 21:53:52.408884
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    assert len(rnd.generate_string('1234567890')) == 10
    assert rnd.generate_string('1234567890', 3) == '561'


# Generated at 2022-06-23 21:53:56.769293
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Data
    _values = [random.randstr() for _ in range(1000)]

    # Test
    assert all(_values), 'Method randstr() returns empty string.'
    assert isinstance(_values[0], str), 'Method randstr() returns a wrong type.'

# Generated at 2022-06-23 21:54:02.248579
# Unit test for method randints of class Random
def test_Random_randints():
    rand = Random()
    random_list = rand.randints(13, 3, 7)
    assert len(random_list) == 13, 'Invalid length'
    assert all([number in [3, 4, 5, 6, 7] for number in random_list]), \
        'Invalid set'
    random_list = rand.randints(a=3, b=7)
    assert len(random_list) == 3, 'Invalid length'
    assert all([number in [3, 4, 5, 6, 7] for number in random_list]), \
        'Invalid set'

# Generated at 2022-06-23 21:54:05.392386
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method ``generate_string`` of class ``Random()``.
    """
    assert isinstance(Random().generate_string(string.digits), str)
    assert len(Random().generate_string(string.digits)) == 10
    assert len(Random().generate_string(string.digits, length=20)) == 20



# Generated at 2022-06-23 21:54:08.813235
# Unit test for method randints of class Random
def test_Random_randints():
    items = Random().randints(5, 1, 8)
    assert all(i in range(1, 8) for i in items)

# Generated at 2022-06-23 21:54:12.442082
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.builtins import Person

    item = get_random_item(Person.Gender)
    assert isinstance(item, Person.Gender)

if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-23 21:54:13.453982
# Unit test for constructor of class Random
def test_Random():
  r = Random()
  assert isinstance(r, Random)


# Generated at 2022-06-23 21:54:16.922330
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string('ABCD', 5) in (
        'ABBAB', 'DCCCB', 'CACDC', 'AADCA', 'BDBBD',
        'ADDAB', 'BCBAC', 'DADBB', 'CADBA', 'BABAB'
    )



# Generated at 2022-06-23 21:54:21.882881
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.builtins import (
        Person,
        Address,
        Datetime,
        Internet,
    )

    # Get random item from enum
    Person.avatar.random()
    Address.region.random()
    Datetime.month.random()
    Internet.domain_name.random()
    # Get random item from enum
    Person.avatar.random()
    Address.region.random()
    Datetime.month.random()
    I

# Generated at 2022-06-23 21:54:24.367006
# Unit test for method randints of class Random
def test_Random_randints():
    res = Random().randints(50)
    print(res)


if __name__ == "__main__":
    test_Random_randints()

# Generated at 2022-06-23 21:54:27.837460
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert Random().randstr(unique=False,length=8) == 'IFgBFYa1'
    assert Random().randstr(unique=True) == 'c6afc52f8edc4f7da4f4c6e0d6f3dc6d'

# Generated at 2022-06-23 21:54:28.548213
# Unit test for method urandom of class Random
def test_Random_urandom():
    data = random.urandom(5)
    assert len(data) == 5

# Generated at 2022-06-23 21:54:30.710493
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random_string = Random().generate_string(
        string.ascii_letters + string.digits,
        Random().randint(1, 128)
    )
    assert isinstance(random_string, str)
    assert len(random_string) > 0

# Generated at 2022-06-23 21:54:32.649342
# Unit test for function get_random_item
def test_get_random_item():
    class Foo(object):
        A = 1
        B = 2
        C = 3

    assert get_random_item(Foo) in [1, 2, 3], (
        'Wrong random item'
    )

# Generated at 2022-06-23 21:54:44.227404
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Test a valid mask of code
    assert (repr(random.custom_code(mask='@###')) in
        ['AS90', 'BD32', 'CR61', 'DZ20']
    )
    assert (repr(random.custom_code(mask='@###', char='@', digit='#')) in
        ['AS90', 'BD32', 'CR61', 'DZ20']
    )
    # Test a mask with only digits
    assert (repr(random.custom_code(mask='###')) in
        ['699', '725', '596', '194']
    )
    # Test a mask with only chars
    assert (repr(random.custom_code(mask='@@@')) in
        ['KHS', 'ERV', 'JON', 'ITN']
    )
    # Test

# Generated at 2022-06-23 21:54:52.134616
# Unit test for function get_random_item
def test_get_random_item():
    '''
    Testing the function `get_random_item`
    '''
    import pytest
    from hypothesis import given
    from hypothesis.strategies import integers

    class TestEnum:
        '''
        Test class
        '''
        YES = 'yes'
        NO = 'no'

    @given(integers(min_value=1, max_value=100))
    def test_get_random_item_strategy(seed: int):
        '''
        Test function
        '''
        random.seed(seed)
        assert get_random_item(TestEnum) in [TestEnum.YES, TestEnum.NO]

    def test_get_random_item_enums():
        '''
        Test function
        '''
        random.seed(0)
        assert get_random_

# Generated at 2022-06-23 21:54:53.134529
# Unit test for constructor of class Random
def test_Random():
    assert callable(Random)

# Generated at 2022-06-23 21:54:58.684946
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method ``randints()`` of class Random.

    """
    rnd = Random()
    numbers = rnd.randints(amount=5, a=1, b=10)
    assert isinstance(numbers, list)
    assert len(numbers) == 5
    for number in numbers:
        assert number > 0 and number < 10

    with pytest.raises(ValueError):
        rnd.randints(amount=0)



# Generated at 2022-06-23 21:55:02.332868
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rand = Random()
    assert rand.generate_string(
        string.ascii_letters,
        10
    )

    assert rand.generate_string(
        string.digits,
        10
    )



# Generated at 2022-06-23 21:55:06.499050
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method randints of class Random"""
    rnd = Random()
    result = rnd.randints(2, 9, 10)
    assert (len(result) == 2)
    for item in result:
        assert (item >= 9)
        assert (item < 10)


# Generated at 2022-06-23 21:55:10.965250
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for the ``Random.custom_code()`` method."""
    for _ in range(10):
        c = Random(version=2).custom_code(mask='@###-###')
        assert isinstance(c, str)
        assert len(c) == 9

# Generated at 2022-06-23 21:55:13.785620
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    a = Random(42)
    b = Random(42)
    assert a.random() != b.random()

# Generated at 2022-06-23 21:55:16.347769
# Unit test for method randstr of class Random
def test_Random_randstr():
    for _ in range(10):
        assert 1 <= len(random.randstr()) <= 128
    for _ in range(10):
        assert 1 <= len(random.randstr(length=10)) <= 10

# Generated at 2022-06-23 21:55:19.192158
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method."""
    rnd = Random()
    assert isinstance(rnd.uniform(0, 100), float)
    assert isinstance(rnd.uniform(0, 100, precision=3), float)

# Generated at 2022-06-23 21:55:22.074853
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum

    class Direction(Enum):
        LEFT = "left"
        RIGHT = "right"

    value = get_random_item(Direction)
    assert isinstance(value, Direction)

# Generated at 2022-06-23 21:55:23.879588
# Unit test for method randstr of class Random
def test_Random_randstr():
    # generate random string and check length
    assert len(Random().randstr(length=1)) == 1

# Generated at 2022-06-23 21:55:25.721092
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, random_module.Random)


# Generated at 2022-06-23 21:55:31.159916
# Unit test for method uniform of class Random
def test_Random_uniform():
    '''
    In the random.py, the method uniform of class Random has a bug:
    rnd = Random()
    assert(rnd.uniform(1, 1) in (1, 2))
    The uniform method should return a random number in the range [a, b) or [a, b] depending on rounding.
    Every time we call the method uniform, the result should be different and in the range [a, b).
    The probability to get the result equals to 1 or 2 is 0.
    Example:
    rnd = Random()
    assert(rnd.uniform(1, 1) in (1, 2))
    The probability of this result is 0.
    '''
    rnd = Random()
    assert(rnd.uniform(1, 1) == 1)

# Generated at 2022-06-23 21:55:40.069745
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Tests for Random.uniform method."""
    rng = Random()

    # Result is a float, not int
    assert isinstance(rng.uniform(0, 100), float)

    # Test for value 0
    assert rng.uniform(0, 100) != 0

    # Upper bound is either less than or equal to result
    assert rng.uniform(-10, 10) <= 10

    # Lower bound is either greater than or equal to result
    assert rng.uniform(-10, 10) >= -10

    # Upper bound is always greater than result
    assert rng.uniform(10, 0) >= 0

    # Lower bound is always less than the result
    assert rng.uniform(10, 0) <= 10

# Generated at 2022-06-23 21:55:45.081007
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    str_seq1 = 'abcde'
    str_seq2 = '12345'
    INST1 = random.generate_string(str_seq1)
    INST2 = random.generate_string(str_seq2)
    assert INST1 == INST1
    assert INST2 == INST2



# Generated at 2022-06-23 21:55:56.731470
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    r.seed(1)
    assert r.randints() == [67, 62, 83]
    r.seed(1)
    assert r.randints(4) == [67, 62, 83, 16]
    r.seed(2)
    assert r.randints(b=200) == [100, 108, 98]
    r.seed(3)
    assert r.randints(b=200, a=100) == [114, 100, 125]
    r.seed(4)
    assert r.randints(a=100, b=200) == [161, 186, 116]
    r.seed(5)
    assert r.randints(amount=5, a=100, b=200) == [199, 112, 115, 152, 183]
    r.seed(6)
   

# Generated at 2022-06-23 21:56:00.757091
# Unit test for function get_random_item
def test_get_random_item():
    """Test get_random_item."""
    import enum
    class TestEnum(enum.Enum):
        a = 0
        b = 1
        c = 2

        def __str__(self):
            return self.name

    assert get_random_item(TestEnum) in TestEnum

# Generated at 2022-06-23 21:56:05.102321
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    string_length = 10
    string_seq = string.digits
    str = Random().generate_string(string_seq, string_length)
    assert len(str) == string_length
    assert str.isdigit()

# Generated at 2022-06-23 21:56:16.353727
# Unit test for function get_random_item
def test_get_random_item():
    #: Fixture for pytest
    class Color(object):
        """Colors."""
        RED = 1
        GREEN = 2
        BLUE = 3
        YELLOW = 4
        ORANGE = 5
        BLACK = 6
        PINK = 7
        PURPLE = 8

    #: Fixture for pytest
    class Shape(object):
        """Shapes."""
        CIRCLE = 1
        SQUARE = 2
        TRIANGLE = 3
        RECTANGLE = 4
        DIAMOND = 5
        PENTAGON = 6
        HEXAGON = 7
        OCTAGON = 8

    assert get_random_item(Color)
    assert get_random_item(Shape)

    rnd = Random()
    rnd_col = get_random_item(Color, rnd)
    r

# Generated at 2022-06-23 21:56:25.273609
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    for i in range(100):
        s = random.generate_string(string.digits, 10)
        assert len(s) == 10
        assert all(i.isdigit() for i in s)

    for i in range(100):
        s = random.generate_string(string.ascii_lowercase, 10)
        assert len(s) == 10
        assert all(i.islower() for i in s)

    for i in range(100):
        s = random.generate_string(string.ascii_uppercase, 10)
        assert len(s) == 10
        assert all(i.isupper() for i in s)

    for i in range(100):
        s = random.generate_string(string.ascii_letters, 10)
        assert len(s)

# Generated at 2022-06-23 21:56:29.005358
# Unit test for function get_random_item
def test_get_random_item():
    from random import choice
    from enum import Enum
    from .enums import Gender

    random_item = get_random_item(Gender)
    assert random_item in Gender
    assert get_random_item(Gender, random_module) == choice(list(Gender))

# Generated at 2022-06-23 21:56:35.028847
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert len(rnd.custom_code()) == 4
    assert len(rnd.custom_code(mask='##/@')) == 4
    assert len(rnd.custom_code(mask='@###')) == 4
    assert len(rnd.custom_code(mask='@##', char='#')) == 4
    assert len(rnd.custom_code(mask='@##', digit='#')) == 4


# Generated at 2022-06-23 21:56:36.138733
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for method urandom of class Random.

    """
    assert isinstance(Random.urandom(), bytes)



# Generated at 2022-06-23 21:56:37.426526
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    gender = get_random_item(Gender)
    assert gender in Gender

# Generated at 2022-06-23 21:56:47.301356
# Unit test for method randstr of class Random
def test_Random_randstr():
    import re
    import time
    import unittest

    from mimesis.builtins import Datetime
    from mimesis.schema import Field

    pattern = re.compile('[a-zA-Z0-9]{16,128}')

    class TestRandom(unittest.TestCase):

        def setUp(self) -> None:
            self.field = Field('en')
            self.rand = self.field._rnd
            self.dt = self.field.datetime
            self.dt.seed(42)

        def test_randstr_short_string(self):
            now = int(time.time())

            self.dt.seed(now)
            rand_1 = self.rand.randstr(length=32)
            self.dt.seed(now)

# Generated at 2022-06-23 21:56:50.859158
# Unit test for method randints of class Random
def test_Random_randints():
    amount = 10
    a = -3
    b = 3
    this = Random()
    result = this.randints(amount, a, b)
    assert len(result) == amount
    assert all(i in range(a, b) for i in result)



# Generated at 2022-06-23 21:56:57.250690
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rand_module = Random()

    str_seq = 'abcd'
    result = rand_module.generate_string(str_seq)
    assert len(result) == 10
    assert result.isalnum()

    str_seq = '0123456789'
    result = rand_module.generate_string(str_seq, length=5)
    assert len(result) == 5
    assert result.isdigit()


# Generated at 2022-06-23 21:57:00.442494
# Unit test for function get_random_item
def test_get_random_item():
    import enum

    class E(enum.Enum):
        A = 1
        B = 2
        C = 3
        D = 4
        F = 5

    _ = get_random_item(E, Random())
    assert isinstance(_, E)

# Generated at 2022-06-23 21:57:09.159577
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print('Test Random.custom_code():')
    m = 'A###'
    c = 'A'
    d = '#'
    assert m == Random().custom_code(mask=m, char=c, digit=d)
    try:
        Random().custom_code(mask=m, char=c, digit=c)
    except ValueError:
        print('OK: The method does not allow you to use the same placeholder for digits and chars!')
    else:
        print('FAIL: The method should not allow you to use the same placeholder for digits and chars!')
    try:
        Random().custom_code(mask=m, char='', digit=d)
    except ValueError:
        print('OK: The method does not allow you to use empty string as placeholder.')

# Generated at 2022-06-23 21:57:13.904020
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Generate a random string
    random.seed(0)
    assert random.generate_string('abc', 4) == 'aabb'

    # Generate a random string
    random.seed(0)
    assert random.generate_string('abcabcabcabcabcabcabcabc', 4) == 'cacc'

# Generated at 2022-06-23 21:57:15.544732
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(random.randstr()) <= 128, 'Failed to generate random string.'

# Generated at 2022-06-23 21:57:19.381076
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(random.generate_string('abcABC')) == 10
    assert (len(random.generate_string('abcABC', length=5)) == 5)
    assert (len(random.generate_string('123456', length=0)) == 0)


# Generated at 2022-06-23 21:57:24.424209
# Unit test for method uniform of class Random
def test_Random_uniform():
    res = []
    rnd = Random()
    for i in range(0, 5):
        res.append(rnd.uniform(0, 5, precision = i))
    expected = [0.8, 0.88, 0.877, 0.8777, 0.87777]
    assert res == expected, "Wrong result"

# Generated at 2022-06-23 21:57:26.900371
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    a = input("Input mask: ")
    b = input("Input char: ")
    c = input("Input digit: ")
    print(r.custom_code(a, b, c))

# Generated at 2022-06-23 21:57:31.828418
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3
    assert len(Random().randints(10)) == 10
    assert len(Random().randints(50)) == 50

    assert len(Random().randints(0)) == 0
    assert len(Random().randints(1, 2, 3)) == 1



# Generated at 2022-06-23 21:57:34.306377
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random = Random()
    for i in range(3):
        assert_equal(len(random.generate_string()), 10)

# Generated at 2022-06-23 21:57:41.836897
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from mimesis.enums import Gender

    class Foo:
        def __init__(self, gender: Gender) -> None:
            self.gender = gender

        @property
        def code(self) -> str:
            rnd = Random()
            return rnd.custom_code(mask='A###', char='A', digit='#')

    foo = Foo(gender=Gender.MAN)
    code = foo.code
    assert code[:1].isalnum()
    assert code[1:].isdigit()

# Generated at 2022-06-23 21:57:42.466839
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)

# Generated at 2022-06-23 21:57:50.332150
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Generate random values
    code_1 = random.randstr()
    code_2 = random.randstr(unique=True)
    code_3 = random.randstr(length=8)
    code_4 = random.randstr(unique=True, length=16)

    # Create set of all generated values
    codes = set()
    codes.add(code_1)
    codes.add(code_2)
    codes.add(code_3)
    codes.add(code_4)

    # Test unique param
    assert len(codes) == 4

    # Test length param
    assert len(code_3) == 8
    assert len(code_4) == 16

    # Test other values
    assert code_1 != code_2
    assert code_3 != code_4


# Generated at 2022-06-23 21:58:00.661003
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test method generate_string of class Random.

    :return: None
    """
    rnd = Random()
    chars = 'abcdefghijklmnopqrstuvwxyz'
    assert rnd.generate_string(chars)

    digits = '0123456789'
    assert rnd.generate_string(digits)

    alphanumeric = 'abcdefghijklmnopqrstuvwxyz0123456789'
    assert rnd.generate_string(alphanumeric)


# Generated at 2022-06-23 21:58:08.488452
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string('123456789')) == 10
    assert len(Random().generate_string('123456789', 6)) == 6
    random = Random()
    random.seed(2)
    assert random.generate_string('123456789', 7) == '6388877'
    random.seed(2)
    assert random.generate_string('123456789', 7) == '6388877'
    random.seed(2)
    assert random.generate_string('123456789', 7) == '6388877'



# Generated at 2022-06-23 21:58:13.319304
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item.

    :return: bool

    """
    class Foo(object):
        def __getitem__(self, key):
            return key

        def __len__(self):
            return 10

    assert isinstance(get_random_item(Foo()), int)

    class Bar(Random):
        def __len__(self):
            return 1

    assert isinstance(get_random_item(Bar()), Bar)

# Generated at 2022-06-23 21:58:17.234310
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test method generate_string of class Random."""
    assert isinstance(random.generate_string(str_seq="abcd", length=10), str)
    assert isinstance(random.custom_code(mask='@###'), str)

# Generated at 2022-06-23 21:58:27.016477
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = random.randstr()
    assert isinstance(r, str)
    assert len(r) > 0

    r = random.randstr(unique=True)
    assert isinstance(r, str)
    assert len(r) > 0

    r = random.randstr(unique=False)
    assert isinstance(r, str)
    assert len(r) > 0

    r = random.randstr(unique=True, length=None)
    assert isinstance(r, str)
    assert len(r) > 0

    r = random.randstr(unique=False, length=None)
    assert isinstance(r, str)
    assert len(r) > 0

    r = random.randstr(unique=False, length=100)
    assert isinstance(r, str)
    assert len(r) == 100

# Generated at 2022-06-23 21:58:33.168144
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    class EnumT(enum.Enum):
        A = 'A'
        B = 'B'
        C = 'C'

    assert get_random_item(EnumT) in [EnumT.A, EnumT.B, EnumT.C]
    assert get_random_item(EnumT.A, random) in [EnumT.A, EnumT.B, EnumT.C]

# Generated at 2022-06-23 21:58:38.776464
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    _random = Random()
    _str = "0123456789"
    result = _random.generate_string(_str)
    assert isinstance(result, str)
    assert len(result) == 10

    result = _random.generate_string(_str, 11)
    assert isinstance(result, str)
    assert len(result) == 11

    result = _random.generate_string("@#$Z?", length=10)
    assert isinstance(result, str)
    assert len(result) == 10



# Generated at 2022-06-23 21:58:43.227009
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender, Locale

    assert get_random_item(Gender) in Gender
    assert get_random_item(Locale) in Locale
    assert isinstance(get_random_item(Locale), str)
    assert get_random_item(Locale, random) in Locale

# Generated at 2022-06-23 21:58:47.451141
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random.seed(1234567890)
    # Generate string with lower case
    generated_string = random.generate_string(string.ascii_lowercase)
    assert generated_string == 'djiqowdqgz'


# Generated at 2022-06-23 21:58:52.288722
# Unit test for function get_random_item
def test_get_random_item():
    from .time import Time
    from .text import Text
    from .enums import Quantity, MimeType, CodeLanguage, Gender, DatasetType

    # Test for Quantity
    for _ in range(10):
        quantity = get_random_item(Quantity)
        assert isinstance(quantity, Quantity)

    # Test for MimeType
    for _ in range(10):
        mime_type = get_random_item(MimeType)
        assert isinstance(mime_type, MimeType)

    # Test for CodeLanguage
    for _ in range(10):
        code_language = get_random_item(CodeLanguage)
        assert isinstance(code_language, CodeLanguage)

    # Test for Gender
    for _ in range(10):
        gender = get_random_item(Gender)

# Generated at 2022-06-23 21:58:57.757008
# Unit test for method randstr of class Random
def test_Random_randstr():
    from mimesis.mimesis import Mimesis
    mimesis = Mimesis()
    # Test for unique option
    value1 = mimesis.random.randstr(unique=True)
    value2 = mimesis.random.randstr(unique=True)
    assert value1 != value2
    # Test for length option
    value3 = mimesis.random.randstr(unique=False, length=5)
    assert len(value3) == 5

# Generated at 2022-06-23 21:59:00.336619
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test with param ``unique=True``."""
    r = Random()
    assert r.randstr(unique=False) != r.randstr(unique=False)



# Generated at 2022-06-23 21:59:08.247798
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.generic import Enum

    class TestProvider(BaseProvider):
        """Class for testing."""

        @property
        def surnames(self) -> List[str]:
            return [
                'Arnold', 'Borden', 'Chan', 'Derrickson', 'Gersten',
                'Hook', 'Krol', 'Loft', 'Mallo', 'Ozerov',
            ]

        gender = Enum('male', 'female')

        def get_full_name(self, gender: Optional[str] = None) -> str:
            """Get full name of the person.

            :param gender: Gender.
            :return: Full name of the person.
            """
            gender = self

# Generated at 2022-06-23 21:59:09.992700
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit testing method."""
    assert random.generate_string('', 3) == ''



# Generated at 2022-06-23 21:59:13.103981
# Unit test for method randints of class Random
def test_Random_randints():
    _rand = Random()
    _int_list = _rand.randints(a=1, b=2)
    assert len(_int_list) == 3 and all(i == 1 for i in _int_list)



# Generated at 2022-06-23 21:59:22.317932
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_object = Random()

    actual_result = random_object.custom_code()
    length = len(actual_result)
    assert length == 10, f'Expected length 10, got {length}.'

    actual_result = random_object.custom_code(mask='@@###@@')
    length = len(actual_result)
    assert length == 8, f'Expected length 8, got {length}.'

    actual_result = random_object.custom_code(mask='@@@@@@')
    length = len(actual_result)
    assert length == 6, f'Expected length 6, got {length}.'

    actual_result = random_object.custom_code(mask='@###@')
    length = len(actual_result)
    assert length == 5, f'Expected length 5, got {length}.'

    actual

# Generated at 2022-06-23 21:59:23.920218
# Unit test for function get_random_item
def test_get_random_item():
    class MyEnum:
        Foo = 1
        Bar = 2

    x = get_random_item(MyEnum)
    assert x == MyEnum.Foo or x == MyEnum.Bar



# Generated at 2022-06-23 21:59:31.666015
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    from mimesis.enums import PaymentSystem
    from mimesis.enums import Currency

    assert Gender.MALE in [get_random_item(Gender) for _ in range(10)]
    assert PaymentSystem.VISA in [
        get_random_item(PaymentSystem) for _ in range(10)]
    assert Currency.EUR in [get_random_item(Currency) for _ in range(10)]

# Generated at 2022-06-23 21:59:32.728266
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom() is bytes

# Generated at 2022-06-23 21:59:35.185890
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    rnd.seed(0)
    s = rnd.randstr()
    assert s == '5z5dLg1t'

# Generated at 2022-06-23 21:59:41.812625
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import DayOfWeek
    from mimesis.providers.date import DateTimeProvider

    day_of_week = get_random_item(DayOfWeek)
    assert isinstance(day_of_week, DayOfWeek)
    assert isinstance(day_of_week, int)
    assert day_of_week in DateTimeProvider._days_of_week

    day_of_month = random.random.choice(range(1, 32))
    assert isinstance(day_of_month, int)
    assert 1 <= day_of_month <= 31

# Generated at 2022-06-23 21:59:45.888051
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert type(random.urandom()) is bytes

    assert len(random.urandom(10)) == 10

    assert len(random.urandom(7, 1)) == 7



# Generated at 2022-06-23 21:59:48.700034
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of class Random."""
    rnd = Random()
    assert rnd.uniform(1, 2) <= 2 and rnd.uniform(1, 2) >= 1
    assert rnd.uniform(1, 2, precision=10) <= 2 and rnd.uniform(1, 2, precision=10) >= 1


# Generated at 2022-06-23 21:59:55.361508
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints of custom class."""
    rnd = Random()
    result = rnd.randints(3, 1, 100)
    assert isinstance(result, list)
    assert len(result) == 3
    assert all(x in range(1, 101) for x in result)

    result = rnd.randints(3, 1, 1)
    assert isinstance(result, list)
    assert len(result) == 3
    assert all(x == 1 for x in result)



# Generated at 2022-06-23 21:59:59.360997
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random.

    :return: Nothing.
    """
    assert all(len(Random().generate_string('1234567890', length=i)) == i
               for i in range(11))
    assert all(len(Random().generate_string('0123456789')) == 10
               for _ in range(10))



# Generated at 2022-06-23 22:00:01.137202
# Unit test for method randstr of class Random
def test_Random_randstr():
    for _ in range(1000):
        s = random.randstr(length=10)

        if len(s) != 10:
            print(s)
            assert False


# Generated at 2022-06-23 22:00:05.567752
# Unit test for method randstr of class Random
def test_Random_randstr():
	random.seed(4)
	for i in range(20):
		print(random.randstr(unique=False,length=10))


if __name__ == '__main__':
	test_Random_randstr()

# Generated at 2022-06-23 22:00:09.720889
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random = Random()
    print(random.generate_string(str_seq = 'abc', length = 10))
    print(random.generate_string(str_seq = '1234567890', length = 8))
    print(random.generate_string(str_seq = '1234567890', length = 0))

# Generated at 2022-06-23 22:00:14.484808
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    assert Random().randints(0, 10) == [7, 2, 5]
    assert Random().randints(amount=7, a=1, b=7) == [6, 2, 6, 3, 3, 4, 6]



# Generated at 2022-06-23 22:00:21.574489
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert Random().uniform(5, 5.5) == 5.0
    assert Random().uniform(5, 5.5) == 5.0
    assert Random().uniform(5, 7.5) == 6.0
    assert Random().uniform(5, 5) == 5.0
    assert Random().uniform(5, 5.5, precision=None) == 5.5
    assert Random().uniform(5, 7.5, precision=None) == 6.5
    assert Random().uniform(5, 5) == 5.0



# Generated at 2022-06-23 22:00:24.762858
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    assert random.uniform(0, 1, 7) in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

# Generated at 2022-06-23 22:00:35.959201
# Unit test for method randstr of class Random
def test_Random_randstr():
    res = random.randstr()
    assert len(res) > 0
    res = random.randstr(unique=True)
    assert res != random.randstr(unique=True)
    res = random.randstr(unique=True)
    assert res != random.randstr(unique=True)
    res = random.randstr(length=10)
    assert len(res) == 10
    res = random.randstr(length=20)
    assert len(res) == 20
    res = random.randstr(length=5)
    assert len(res) == 5
    res = random.randstr(length=128)
    assert len(res) == 128
    res = random.randstr(length=16)
    assert len(res) == 16

# Generated at 2022-06-23 22:00:41.903723
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert 1 <= rnd.uniform(1, 2, 2) < 2
    assert rnd.uniform(1, 2) >= 1
    assert rnd.uniform(1, 2) < 2
    assert 5 <= rnd.uniform(1, 6, 0) < 6
    assert 0 <= rnd.uniform(0, 1, 2) < 1
    assert 0 <= rnd.uniform(0, 1, 0) < 1
    assert rnd.uniform(0, 1, 1) <= 1
    assert rnd.uniform(0, 1, 1) >= 0
    assert rnd.uniform(2, 2) == 2
    assert rnd.uniform(2, 2, 0) == 2
    assert rnd.uniform(2, 2, 1) == 2
    assert r

# Generated at 2022-06-23 22:00:43.914976
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert round(random.uniform(1.0, 2.0), 2) == 1.57

# Generated at 2022-06-23 22:00:48.908122
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random(2)
    assert r.generate_string('0123456789') == '1411429654'
    assert r.generate_string('Oo0oOo0o', 10) == 'OoOoOoOoO0'
    assert r.generate_string('Oo0oOo0o', 6) == 'OoO0oO'



# Generated at 2022-06-23 22:00:50.522193
# Unit test for method urandom of class Random
def test_Random_urandom():
    num_bytes = 16
    result = Random.urandom(num_bytes)
    assert len(result) == num_bytes

# Generated at 2022-06-23 22:00:52.979308
# Unit test for constructor of class Random
def test_Random():
    global random

    # Checks if variable "random" is instance of class Random
    assert isinstance(random, Random),\
        f'Constructor of class Random failed'


# Generated at 2022-06-23 22:00:58.961015
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string('ABCDEFGHIJKLMNOPQRSTUVWXYZ')) == 10
    assert len(Random().generate_string('ABCDEFGHIJKLMNOPQRSTUVWXYZ', 20)) == 20
    assert isinstance(Random().generate_string('ABCDEFGHIJKLMNOPQRSTUVWXYZ'), str)

# Generated at 2022-06-23 22:01:04.018565
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    lst = rnd.randints(amount=5)
    assert lst
    assert len(lst) == 5

    lst_int = rnd.randints(amount=5, a=5, b=10)
    assert lst_int
    assert min(lst_int) >= 5
    assert max(lst_int) <= 10

    raised = False
    try:
        rnd.randints(amount=0)
    except ValueError:
        raised = True

    assert raised is True



# Generated at 2022-06-23 22:01:05.620498
# Unit test for method urandom of class Random
def test_Random_urandom():
    """ Unit test for method urandom of class Random """
    assert type(random.urandom(100)) == bytes

# Generated at 2022-06-23 22:01:13.751811
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Locales
    from mimesis.providers.base import BaseProvider
    from mimesis.providers.internet import Internet

    class Test(BaseProvider):
        @classmethod
        def init_provider(cls):
            cls._locales = Locales
            cls.n = Internet(cls.__config__.locales)

        def test_func(self):
            # ...
            locale = self._random.choice(self.__locales)
            locale = self.__random.choice(self.__locales)
            locale = self.random.choice(self.__locales)
            locale = self.random.choice(self._locales)

            self.get_random_item(self.__locales)
            self.get_random_item(self._locales)

# Generated at 2022-06-23 22:01:23.811425
# Unit test for method uniform of class Random
def test_Random_uniform():
    import numpy.random

    def generate_data(count):
        rnd = Random()
        data = []
        for _ in range(count):
            data.append(rnd.uniform(-120, 120, precision=5))
        return data

    def get_stats(data):
        arr = numpy.array(data)
        mu = arr.mean()
        sigma = arr.std()
        stats = {
            "min": data.min(),
            "max": data.max(),
            "mean": mu,
            "mid": (data.min() + data.max()) / 2.0,
            "mode": max(set(data), key=data.count),
            "deviation": (data.max() - data.min()) / 2.0,
            "standard deviation": sigma
        }
        return

# Generated at 2022-06-23 22:01:25.988781
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints(4, 1, 100)) == 4

# Generated at 2022-06-23 22:01:29.357829
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rand_seq = string.ascii_uppercase + string.digits
    result = random.generate_string(rand_seq)
    assert isinstance(result, str)
    assert len(result) <= 10
    assert result.isalnum()
