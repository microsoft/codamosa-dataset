

# Generated at 2022-06-23 21:51:37.064002
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Arrange
    # 1st parameter: string sequence
    # 2nd parameter: length of string
    data = [('abcdefghijklmnopqrstuvwxyz',10),
            ('0123456789',15),
            ('abcdefghijklmnopqrstuvwxyz0123456789',20)]

    rnd = Random()

    # Act
    result = []
    for data_ in data:
        result.append(rnd.generate_string(data_[0], data_[1]))

    # Assert
    assert len(result[0]) == 10
    assert len(result[1]) == 15
    assert len(result[2]) == 20

# Generated at 2022-06-23 21:51:38.444703
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(100) == os.urandom(100)



# Generated at 2022-06-23 21:51:41.186015
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    print(random.custom_code(mask='@###'))
    print(random.custom_code(mask='@###', char='#', digit='@'))


# Generated at 2022-06-23 21:51:44.695793
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert isinstance(rnd, random_module.Random)
    assert isinstance(rnd, Random)

# Generated at 2022-06-23 21:51:48.017373
# Unit test for function get_random_item
def test_get_random_item():
    """Test for a get_random_item() function."""
    from .enums import Gender
    assert get_random_item(Gender) in Gender
    # Test for a custom random object
    assert get_random_item(Gender, random) in Gender

# Generated at 2022-06-23 21:51:52.680284
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    def test_function(mask: str, value: str) -> None:
        assert random.custom_code(mask=mask) == value

    test_function('@###', 'K856')
    test_function('@@@', 'EAU')
    test_function('@ @ @', 'R R V')
    test_function('@##-@##', 'V899-Y266')

# Generated at 2022-06-23 21:51:53.701695
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(10), bytes)

# Generated at 2022-06-23 21:51:54.878611
# Unit test for method urandom of class Random
def test_Random_urandom():
    result = Random.urandom()
    assert result is not None

# Generated at 2022-06-23 21:51:57.615108
# Unit test for function get_random_item
def test_get_random_item():
    import enum

    @enum.unique
    class Person(enum.Enum):
        Janis = 12
        Peter = 14
        Andrew = 5

    assert get_random_item(Person) in Person

# Generated at 2022-06-23 21:51:59.135269
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for the class Random."""
    assert Random.urandom()

# Generated at 2022-06-23 21:52:04.408623
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(
        10
    ) == b'\xde\x92\x1b\xea\xe7\xba\x0c\xc9\xa4}\x14\xce\xfa\x8d\xea\xda\xb0\xfb\xb9\x9cQ'


# Generated at 2022-06-23 21:52:07.244455
# Unit test for method randints of class Random
def test_Random_randints():
    numbers = Random().randints(5)
    assert len(numbers) == 5
    assert isinstance(numbers, list)

# Generated at 2022-06-23 21:52:17.432717
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    import string
    import random as random_module
    import pytest

    str_seq = string.ascii_uppercase + string.digits
    mask_1 = '@###'
    mask_2 = '@####'
    mask_3 = '@###@@'
    mask_4 = '@###@#'
    mask_5 = '###@@#'
    char = '@'
    digit = '#'
    rng = random_module.Random()

    def create_random_char():
        return rng.choice(str_seq)

    def create_random_int(amount: int = 3,
                          a: int = 1, b: int = 100) -> str:
        return rng.randints(amount, a, b)

    def check_custom_code(code, mask):
        code

# Generated at 2022-06-23 21:52:21.649690
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(Random().generate_string('ABCDEF'), str)
    assert isinstance(Random().generate_string('12345'), str)
    assert len(Random().generate_string('12345')) == 10
    assert len(Random().generate_string('12345', 5)) == 5


# Generated at 2022-06-23 21:52:23.463268
# Unit test for constructor of class Random
def test_Random():
    assert Random is not None
    assert Random.randint(1, 12) is not None


# Generated at 2022-06-23 21:52:24.935432
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert len(str(Random().uniform(1, 3))) == 3

# Generated at 2022-06-23 21:52:30.384997
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = Random().custom_code('AA###*', char='A', digit='*')
    assert len(code) == 5
    assert code[0] in string.ascii_uppercase
    assert code[1] in string.ascii_uppercase
    assert code[2] in string.digits
    assert code[3] in string.digits
    assert code[4] in string.digits
    assert code[5] == '*'

# Generated at 2022-06-23 21:52:31.386374
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random, random.languages), str)

# Generated at 2022-06-23 21:52:33.373064
# Unit test for constructor of class Random
def test_Random():
    test_obj = Random()
    assert isinstance(test_obj, random_module.Random)
    assert isinstance(test_obj, Random)

# Generated at 2022-06-23 21:52:39.211905
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function ``get_random_item()``.
    """
    from mimesis.enums import Gender, PersonPrefix
    gender = get_random_item(Gender)
    assert isinstance(gender, Gender)
    prefix = get_random_item(PersonPrefix)
    assert isinstance(prefix, PersonPrefix)



# Generated at 2022-06-23 21:52:42.400961
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for method uniform of the class Random."""
    random_obj = Random()
    assert isinstance(random_obj.uniform(1, 2, 4), float)
    assert isinstance(random_obj.uniform(1, 2), float)

# Generated at 2022-06-23 21:52:50.925312
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    r.seed(0)
    assert r.randints(3, 1, 100) == [85, 88, 88]
    r.seed(0)
    assert r.randints(0, 1, 100) == []
    with pytest.raises(ValueError):
        r.randints(-1, 1, 100)
    with pytest.raises(ValueError):
        r.randints(3, 100, 1)


# Generated at 2022-06-23 21:52:52.234485
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@@@###', '@', '#') == 'JKH847'


# Generated at 2022-06-23 21:52:56.377775
# Unit test for constructor of class Random
def test_Random():
    print('Test class Random.')

    r = Random()

    assert isinstance(r.random(), float)

    assert isinstance(r.randint(0, 10), int)
    assert r.randint(-10, 15) in range(-10, 15)

    assert isinstance(r.random_number(5), int)
    assert r.random_number(0) == 0
    assert r.random_number(5) in range(0, 100000)

    assert isinstance(r.randints(10), list)
    assert len(r.randints(0, -10, 10)) == 0

    assert isinstance(r.choice(['a', 'b']), str)

    assert isinstance(r.choices(['a', 'b'], k=2), list)


# Generated at 2022-06-23 21:53:00.236717
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test generation of random string."""
    rnd = Random()
    result = rnd.generate_string('ABC', 5)
    assert result
    assert isinstance(result, str)
    assert len(result) == 5

# Generated at 2022-06-23 21:53:03.403956
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    class Unit(enum.Enum):
        METER = 1
        SECOND = 2
        KELVIN = 3

    assert isinstance(get_random_item(Unit), Unit)

# Generated at 2022-06-23 21:53:10.307700
# Unit test for function get_random_item
def test_get_random_item():
    import unittest.mock as mock
    from mimesis.enums import Sex, Sport

    class RandomMock(Random):
        @staticmethod
        def choice(value):
            return value[1]

    r = RandomMock()
    assert get_random_item(Sex, r) == Sex.FEMALE
    assert get_random_item(Sport, r) == Sport.BASEBALL


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-23 21:53:16.407171
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3
    assert len(Random().randints(amount=3)) == 3
    assert len(Random().randints(amount=4)) == 4
    assert len(Random().randints(amount=4, a=0, b=10)) == 4
    assert len(Random().randints(amount=4, a=0, b=1)) == 4


# Generated at 2022-06-23 21:53:18.748603
# Unit test for method urandom of class Random
def test_Random_urandom():
    size = 10
    data = random.urandom(size)
    assert len(data) == size

# Generated at 2022-06-23 21:53:21.910051
# Unit test for method randstr of class Random
def test_Random_randstr():
    _rnd_str_1 = random.randstr(unique=True)
    _rnd_str_2 = random.randstr(unique=True)
    assert _rnd_str_1 != _rnd_str_2

# Generated at 2022-06-23 21:53:26.224540
# Unit test for method randstr of class Random
def test_Random_randstr():
    random_string = random.randstr()
    random_string_unique = random.randstr(unique=True)
    random_string_length_9 = random.randstr(length=9)
    assert len(random_string) == random._randbelow(128 - 16 + 1) + 16
    assert len(random_string_length_9) == 9
    assert len(random_string_unique) == 32

# Generated at 2022-06-23 21:53:26.996222
# Unit test for method randints of class Random
def test_Random_randints():
    assert sum(random.randints(4), 0) == 10


# Generated at 2022-06-23 21:53:28.641540
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert 28.4 <= random.uniform(27.6, 28.6) <= 28.5

# Generated at 2022-06-23 21:53:32.708483
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item.

    :return: None.
    """
    from mimesis.builtins.enums import Book

    book = get_random_item(Book)
    assert book in Book.__members__.values()

# Generated at 2022-06-23 21:53:41.937760
# Unit test for method randints of class Random
def test_Random_randints():
    import random

    # test 1
    random_object = Random()
    a = -2
    b = -1
    random_list = random_object.randints(a=a, b=b)
    assert not len(random_list)
    assert all(a <= i <= b for i in random_list)

    # test 2
    a = 5
    b = 10
    random_list = random_object.randints(a=a, b=b)
    assert len(random_list) == 3
    assert all(a <= i <= b for i in random_list)

    # test 3
    a = 5
    b = 10
    amount = random.randint(1, 10)
    random_list = random_object.randints(amount=amount, a=a, b=b)

# Generated at 2022-06-23 21:53:47.145195
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    random.custom_code('@###')
    random.uniform(1, 100)
    random.randint(1, 100)
    random.random()
    random.randstr()
    random.randstr(length=128)
    random.randstr(unique=True, length=128)


# Generated at 2022-06-23 21:53:50.760242
# Unit test for method randstr of class Random
def test_Random_randstr():
    for _ in range(100):
        s = random.randstr()
        assert isinstance(s, str) and len(s) > 0


__all__.append('test_Random_randstr')

# Generated at 2022-06-23 21:53:59.973626
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Generate a string with default value of length
    # should not be less than 16 or greater than 128
    rnd = random.randstr()
    assert len(rnd) >= 16 and len(rnd) <= 128

    # Generate string with length = 50
    rnd = random.randstr(length=50)
    assert len(rnd) == 50

    # Generate only unique values
    rnd1 = random.randstr(unique=True)
    rnd2 = random.randstr(unique=True)
    assert rnd1 != rnd2

    # By default, a rnd object is created, so you can use
    # random.randstr() instead of random.randstr(rnd=random)
    rnd = random.randstr(rnd=random)

    # But you can pass a custom rnd object


# Generated at 2022-06-23 21:54:02.901952
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    item = get_random_item(Gender, rnd=None)
    assert item in list(Gender)

# Generated at 2022-06-23 21:54:06.097577
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random.

    For test coverage > 100%.
    """
    rnd = Random()
    rnd.seed(123)
    assert rnd.uniform(0, 1) == 0.5488135039273248


# Generated at 2022-06-23 21:54:16.822054
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    _rnd = Random()
    _list = _rnd.randints(amount=3)
    _list2 = _rnd.randints(amount=3, a=10, b=100)
    _list3 = _rnd.randints(amount=30, a=-1000, b=1000)

    assert len(_list) == 3
    assert len(_list2) == 3
    assert len(_list3) == 30

    for elem in _list:
        assert elem >= 1
        assert elem < 100

    for elem in _list2:
        assert elem >= 10
        assert elem < 100

    for elem in _list3:
        assert elem >= -1000
        assert elem < 1000



# Generated at 2022-06-23 21:54:18.369403
# Unit test for constructor of class Random
def test_Random():
    r = Random()

    assert r.randints(1) == [1]



# Generated at 2022-06-23 21:54:21.114866
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert isinstance(rnd.randints(), list)
    for number in rnd.randints():
        assert isinstance(number, int)

# Generated at 2022-06-23 21:54:25.883419
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of the class ``Random()``."""
    _random = random_module.Random()
    x = _random.urandom(30)

    _random = Random()
    y = _random.urandom(30)

    assert x == y
    assert isinstance(x, bytes)
    assert isinstance(y, bytes)

# Generated at 2022-06-23 21:54:30.014430
# Unit test for method urandom of class Random
def test_Random_urandom():
    random.urandom(16)
    random.urandom(16, b'')
    random.urandom(16, b'\x00')
    random.urandom(16, b'\x00' * 16)
    random.urandom(16, b'\x00' * 17)
    random.urandom(16, b'\x00' * 1000)


# Generated at 2022-06-23 21:54:31.281851
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert random.randstr(length=0) == ''
    assert random.randstr(length=1) == 'x'



# Generated at 2022-06-23 21:54:32.558018
# Unit test for method urandom of class Random
def test_Random_urandom():
    random.urandom(10)

# Generated at 2022-06-23 21:54:37.198737
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test of the function Random.randstr."""
    assert len(random.randstr()) == 16
    assert len(random.randstr(length=15)) == 15
    assert len(random.randstr(unique=True)) == 32
    assert len(random.randstr(length=15, unique=True)) == 32

# Generated at 2022-06-23 21:54:41.605550
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random(2)
    assert r.custom_code('@###') == 'AB01'
    assert r.custom_code('@@##') == 'AA02'
    assert r.custom_code('#@#@#') == '1B2B3'

# Generated at 2022-06-23 21:54:50.312025
# Unit test for method uniform of class Random
def test_Random_uniform():
    # The method returns a float number from a range
    # (a - minimum value, b - maximum value)
    # with a certain precision, which is determined by
    # the precision parameter (default is 15).

    # step 1.
    # Create the instance of the Random class.
    r = Random()

    # step 2.
    # Call the method uniform of the instance r with
    # a = 0.25 and b = 0.3
    # and without passing the parameter precision.
    # (default is 15).
    r.uniform(0.25, 0.3)

    # step 3.
    # Call the method uniform of the instance r with
    # a = 0.25 and b = 0.3
    # and with passing the parameter precision = 4.
    r.uniform(0.25, 0.3, 4)

# Generated at 2022-06-23 21:54:52.546973
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert(Random.urandom(size=16) == os.urandom(size=16))

# Generated at 2022-06-23 21:54:56.708325
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    randstr = Random().randstr()
    assert randstr
    randstr = Random().randstr(unique=True)
    assert randstr
    randstr = Random().randstr(length=32)
    assert isinstance(randstr, str)



# Generated at 2022-06-23 21:55:06.808282
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(10):
        rnd = Random()
        assert ''.join(map(str, [13, 15, 12, 12])) == rnd.custom_code(
            mask='@###',
            char='@',
            digit='#',
        )
        assert ''.join(map(str, [6, 10, 3, 8, 7])) == rnd.custom_code(
            mask='@#####',
            char='@',
            digit='#',
        )
        assert ''.join(map(str, [1, 9, 9, 0, 5])) == rnd.custom_code(
            mask='@@XXX@',
            char='@',
            digit='X',
        )
        assert ''.join(map(str, [3, 10, 10, 1, 6])) == r

# Generated at 2022-06-23 21:55:09.321785
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)



# Generated at 2022-06-23 21:55:17.321221
# Unit test for method randints of class Random
def test_Random_randints():
    ran = Random()
    lst = ran.randints(5)
    assert len(lst) == 5
    assert lst != sorted(lst)

    lst = ran.randints(-5)
    assert not lst

    lst = ran.randints(5, 5)
    assert len(lst) == 5
    for item in lst:
        assert item == 5

    lst = ran.randints(5, -10, -5)
    assert len(lst) == 5
    for item in lst:
        assert item >= -10 and item <= -5

    # Unit test for method urandom of class Random
    def test_Random_urandom():
        ran = Random()
        assert len(ran.urandom(10)) == 10
        assert len(ran.urandom(0)) == 0



# Generated at 2022-06-23 21:55:22.045683
# Unit test for method urandom of class Random
def test_Random_urandom():
    rnd = Random()
    assert isinstance(rnd.urandom(16), bytes)
    assert rnd.urandom(16) == os.urandom(16)
    assert len(rnd.urandom(
        16)) == 16
    assert len(rnd.urandom(
        16, 16)) == 16
    assert len(rnd.urandom(
        16, 32)) == 32


# Generated at 2022-06-23 21:55:33.935275
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random.

    :return: ``None``

    """
    random = Random()

    pair_test = [
        (0, 1),
        (1, 2),
        (-2, 2),
        (100, 200),
        (-100, -200),
        (0, 3.0),
        (1, 2.0),
        (-2, 2.0),
        (100, 200.0),
        (-100, -200.0),
        (0.0, 3),
        (1.0, 2),
        (-2.0, 2),
        (100.0, 200),
        (-100.0, -200),
    ]

    for args in pair_test:
        a, b = args
        assert random.uniform(a, b) >= a

# Generated at 2022-06-23 21:55:36.737451
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = Random()
    if r.randstr() is None or r.randstr(2) is None:
        raise AssertionError('None instead of random string')

# Generated at 2022-06-23 21:55:43.418339
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for Random.uniform with constant seed.
    """
    r = Random(42)
    for i in range(10):
        assert r.uniform(-1, 1, precision=1) == 0.8
        assert r.uniform(-1, 1, precision=2) == 0.36
        assert r.uniform(-1, 1, precision=3) == 0.715
        assert r.uniform(-1, 1, precision=4) == 0.9757
        assert r.uniform(-1, 1, precision=5) == 0.28435
        assert r.uniform(-1, 1, precision=6) == -0.455944
        assert r.uniform(-1, 1, precision=7) == -0.203607

# Generated at 2022-06-23 21:55:55.681743
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints of class Random."""
    random = Random()
    assert random.randints() == random.randints(3)
    assert len(random.randints(amount=5)) == 5
    r_list = random.randints(amount=1)
    assert r_list[0] >= 1 and r_list[0] <= 100
    r_list = random.randints(a=-100, b=-1)
    assert r_list[0] >= -100 and r_list[0] <= -1
    r_list = random.randints(a=100, b=1000)
    assert r_list[0] >= 100 and r_list[0] <= 1000
    assert random.randints(amount=0) == []
    assert random.randints(amount=-1) == []


# Generated at 2022-06-23 21:56:00.292512
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert rnd.random()
    assert rnd.uniform(0, 10)
    assert rnd.randstr()
    assert rnd.randstr(unique=True)
    assert rnd.custom_code()
    assert rnd.custom_code(mask='@@@###')
    assert rnd.randint(0, 10)


# Generated at 2022-06-23 21:56:12.143172
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3
    assert len(Random().randints(2)) == 2
    assert 0 < len(Random().randints(5, 1, 10)) <= 5
    assert all(0 < x <= 10 for x in Random().randints(5, 1, 10))
    assert all(0 <= x < 10 for x in Random().randints(5, 0, 10))
    assert all(0 < x <= 10 for x in Random().randints(5, 1, 10))
    assert all(0 <= x < 10 for x in Random().randints(5, 0, 10))
    assert all(-10 < x <= 0 for x in Random().randints(5, -10, 0))
    assert all(-10 <= x < 0 for x in Random().randints(5, -10, 0, True))

# Generated at 2022-06-23 21:56:13.775292
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 21:56:14.692770
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(1024), bytes)

# Generated at 2022-06-23 21:56:16.036772
# Unit test for method randstr of class Random
def test_Random_randstr():
    random = Random()
    assert random.randstr()



# Generated at 2022-06-23 21:56:20.452541
# Unit test for constructor of class Random
def test_Random():
    x = Random(1)
    y = Random(1)
    assert x.randint(1, 10) == y.randint(1, 10)

    x = Random(1)
    y = Random(2)
    assert x.randint(1, 10) != y.randint(1, 10)


# Generated at 2022-06-23 21:56:24.986805
# Unit test for method urandom of class Random
def test_Random_urandom():
    urandom = Random()
    assert urandom.urandom(1) == os.urandom(1)

    urandom = Random()
    assert urandom.urandom(2) == os.urandom(2)

    urandom = Random()
    assert urandom.urandom(3) == os.urandom(3)

# Generated at 2022-06-23 21:56:27.344744
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random_string = random.generate_string("1234567890")
    assert isinstance(random_string, str)


# Generated at 2022-06-23 21:56:36.465939
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    r.seed(1)
    assert r.custom_code(mask='@@####', char='@', digit='#') == 'ZW8786'
    assert r.custom_code(mask='@#####', char='@', digit='#') == 'A79406'
    assert r.custom_code(mask='###@@@', char='@', digit='#') == '989CYF'
    assert r.custom_code(mask='###@@@', char='#', digit='@') == '6Q24YZ'
    assert r.custom_code(mask='###@@@', char='#', digit='#') == '6Q24YZ'

# Generated at 2022-06-23 21:56:40.176515
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    rnd.seed(1234)
    assert rnd.randints(3, 5, 10) == [6, 5, 9]
    assert rnd.randints() == [91, 83, 14]
    assert rnd.randints(1) == [6]

# Generated at 2022-06-23 21:56:44.900079
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test method randstr of class Random.
    """
    # Explicitly requesting random string
    assert len(random.randstr()) >= 16

    # Now we will generate only unique values
    assert random.randstr(unique=True) != random.randstr(unique=True)

# Generated at 2022-06-23 21:56:47.631069
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    c_code = rnd.generate_string('abCDeF', length=20)
    assert c_code



# Generated at 2022-06-23 21:56:50.820404
# Unit test for method randints of class Random
def test_Random_randints():
    a = 1
    b = 100
    rnd = Random()
    numlist = rnd.randints(a=a, b=b)
    for num in numlist:
        assert a <= num <= b


# Generated at 2022-06-23 21:57:00.224967
# Unit test for constructor of class Random
def test_Random():
    value = random.randint(1, 100)  # type: int
    assert isinstance(value, int)
    assert value >= 1 and value <= 100

    value = random.randints(3, 1, 100)  # type: List[int]
    assert isinstance(value, list)
    assert len(value) == 3

    value = random.uniform(1, 10)  # type: float
    assert isinstance(value, float)
    assert value >= 1 and value <= 10

    value = random.randstr()  # type: str
    assert isinstance(value, str)

    value = random.custom_code()  # type: str
    assert isinstance(value, str)



# Generated at 2022-06-23 21:57:07.831271
# Unit test for constructor of class Random
def test_Random():
    """Testing Random class."""
    random = Random()
    random_int = random.randint(1, 100)
    assert isinstance(random_int, int), 'Type is not int.'
    assert random_int <= 100, 'Random int more than 100.'
    assert random_int >= 0, 'Random int less than 0.'

    random_floats = random.uniform(1, 100, 15)
    assert float(random_floats), 'Type is not float.'
    assert random_floats <= 100, 'Random float more than 100.'
    assert random_floats >= 0, 'Random float less than 0.'

    codes = random.custom_code()
    assert isinstance(codes, str)

# Generated at 2022-06-23 21:57:12.798090
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Simple unit test for method generate_string of class Random."""
    r = Random()
    string_length = 10
    string = r.generate_string(string_seq=string.ascii_uppercase + string.digits,
                               length=string_length)

    assert len(string) == string_length
    assert string.isalnum()



# Generated at 2022-06-23 21:57:17.421802
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender, Profession
    g = get_random_item(Gender)
    p = get_random_item(Profession)
    assert g in list(Gender)
    assert p in list(Profession)

# Test function generate_string()

# Generated at 2022-06-23 21:57:23.400471
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string(string.digits, 6) in string.digits
    assert Random().generate_string() in string.ascii_letters
    assert Random().generate_string(string.digits, 6) in string.digits
    assert len(Random().generate_string()) == 10
    assert len(Random().generate_string(string.digits, 6)) == 6

# Generated at 2022-06-23 21:57:24.927996
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string(string.ascii_letters)) == 10


# Generated at 2022-06-23 21:57:30.668560
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code().isupper()
    assert len(rnd.custom_code()) == 4
    assert rnd.custom_code('@##') == rnd.custom_code('@##')
    assert rnd.custom_code('@##') != rnd.custom_code('@@#')
    assert rnd.custom_code('@@#', '@', '#') == rnd.custom_code('@@#', '@', '#')
    assert rnd.custom_code('@@#', '@', '#') != rnd.custom_code('@@#', '$', '#')
    assert rnd.custom_code('@@#', '@', '#') != rnd.custom_code('@@#', '@', '*')

# Generated at 2022-06-23 21:57:34.610619
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    assert Random.randstr()
    assert len(Random.randstr()) >= 16

    assert Random.randstr(length = 8)
    assert len(Random.randstr(length = 8)) == 8

    assert Random.randstr(unique = True)
    assert len(Random.randstr(unique = True)) == 32

# Generated at 2022-06-23 21:57:38.631182
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Verify that method urandom can be called without arguments.
    assert isinstance(Random().urandom(), bytes)
    # Verify that method urandom can be called with positional argument.
    assert isinstance(Random().urandom(10), bytes)

# Generated at 2022-06-23 21:57:46.614051
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()

    assert isinstance(r.randints(), list)
    assert len(r.randints()) == 3
    assert len(r.randints(10)) == 10
    assert len(r.randints(5, -10, 10)) == 5
    assert len(r.randints(a=5, b=10)) == 3
    assert len(r.randints(amount=5, a=10, b=100)) == 5
    assert len(r.randints(5, 100, b=200)) == 5



# Generated at 2022-06-23 21:57:48.971850
# Unit test for method randints of class Random
def test_Random_randints():
    _random = Random()
    assert _random.randints(a=5, b=8) == [5, 6, 7]



# Generated at 2022-06-23 21:57:51.038561
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string('aab') == 'bba'


# Generated at 2022-06-23 21:57:52.378394
# Unit test for constructor of class Random
def test_Random():
    obj = Random()
    assert isinstance(obj, Random)


# Generated at 2022-06-23 21:57:55.317535
# Unit test for method urandom of class Random
def test_Random_urandom():
    byte_str = Random().urandom(50)
    assert len(byte_str) == 50
    assert isinstance(byte_str, bytes)


# Generated at 2022-06-23 21:57:57.653876
# Unit test for constructor of class Random
def test_Random():
    """Unit test for the class constructor."""
    r = Random()
    assert isinstance(r, Random)

# Generated at 2022-06-23 21:58:08.076947
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    string_format1 = '@###'
    string_format2 = '@@@'
    string_format3 = '###'
    string_format4 = '@###-@@@'
    string_format5 = '##$-@###'
    string_format6 = '###@#$%^**'
    string_format7 = '@###%$#@'
    string_format8 = '@$$@###'
    string_format9 = '#@$$-@###'
    string_format10 = '@$$-@###'
    string_format11 = '&&@###'
    string_format12 = '@@@A$A'
    string_format13 = 'A###'
    string_format14 = 'A##'
    string_format15 = '@###A'

# Generated at 2022-06-23 21:58:15.117211
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print("\nUnit test for method custom_code of class Random")
    print("\tTest 1: custom_code()")
    assert Random().custom_code()
    print("\tResult: OK")
    print("\tTest 2: custom_code('@##-###')")
    assert Random().custom_code('@##-###')
    print("\tResult: OK")
    print("\tTest 3: custom_code('@@0##-###')")
    assert Random().custom_code('@@0##-###')
    print("\tResult: OK")
    print("\tTest 4: custom_code('NOT-VALID')")
    try:
        Random().custom_code('NOT-VALID')
    except ValueError:
        print("\tResult: OK")


# Generated at 2022-06-23 21:58:25.304575
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints of class Random."""
    # Random

    rnd = Random()

    # When value which passed as first argument is None
    # Then
    #       it should raise an exception
    try:
        rnd.randints(None)
    except ValueError:
        pass
    else:
        raise AssertionError(
            'Incorrect first argument value, it should raise an exception'
        )

    # When value which passed as first argument is 0
    # Then
    #       it should raise an exception
    try:
        rnd.randints(0)
    except ValueError:
        pass
    else:
        raise AssertionError(
            'Incorrect first argument value, it should raise an exception'
        )

    # When value which passed as first argument is negative
    # Then
    #       it

# Generated at 2022-06-23 21:58:26.815403
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 21:58:36.955762
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _mask = "ABC-@##"
    for _ in range(1000):
        code = Random(seed=_).custom_code(_mask)
        if not code.endswith('0') and len(code) == 7:
            print(code)
assert 'ABC-L70' == Random(seed=243).custom_code(_mask)
assert 'ABC-L71' == Random(seed=244).custom_code(_mask)
assert 'ABC-L72' == Random(seed=245).custom_code(_mask)
assert 'ABC-L73' == Random(seed=246).custom_code(_mask)
assert 'ABC-L74' == Random(seed=247).custom_code(_mask)
assert 'ABC-L75' == Random(seed=248).custom_code(_mask)

# Generated at 2022-06-23 21:58:40.650339
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    password = random.generate_string(string.ascii_letters + string.digits, 10)
    assert len(password) == 10
    assert all(x in string.ascii_letters + string.digits for x in password)


# Generated at 2022-06-23 21:58:45.281723
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.builtins import Person
    p = Person()
    gen_items = []
    for i in range(100):
        gen_items.append(p.gender())
    assert len(set(gen_items)) == 2

# Generated at 2022-06-23 21:58:55.898960
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    random = Random()
    assert len(random.custom_code()) == 7
    assert len(random.custom_code('@@#')) == 4
    assert len(random.custom_code('@##', '#', '@')) == 4
    assert len(random.custom_code('@##', '@', '@')) == 3
    assert random.custom_code().isalpha()
    assert not random.custom_code('@@##').isalpha()
    assert not random.custom_code('@@##').isnumeric()
    assert not random.custom_code('@@@@').isnumeric()
    assert random.custom_code('@@##').isalpha()
    assert random.custom_code('@@##').isnumeric()

# Generated at 2022-06-23 21:58:57.868962
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(5), bytes)

# Generated at 2022-06-23 21:59:05.616226
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    assert isinstance(r.generate_string('#*@!'), str)
    assert len(r.generate_string('#*@!')) == 10
    assert len(r.generate_string('#*@!', 20)) == 20
    assert len(r.generate_string('#*@!', 30)) == 30
    assert len(r.generate_string('#*@!', 40)) == 40
    assert len(r.generate_string('#*@!', 50)) == 50


if __name__ == '__main__':
    test_Random_generate_string()

# Generated at 2022-06-23 21:59:10.856726
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    # For example, we need 100000 random string
    _hash = set()
    for _ in range(100000):
        # If we need only unique strings
        s = Random().randstr(unique=True)
        assert s not in _hash
        _hash.add(s)



# Generated at 2022-06-23 21:59:20.169187
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of class Random."""

    print("Test case 1: a < 0 and b > 0")
    rnd = Random()
    a = rnd.uniform(-1, 1, precision=1)
    assert a < 1 and a > -1 and a != 0.0

    print("Test case 2: a > 0 and b > 0")
    rnd = Random()
    a = rnd.uniform(0.0, 1, precision=1)
    assert a < 1 and a > 0 and a != 0.0

    print("Test case 3: a == b")
    rnd = Random()
    a = rnd.uniform(1, 1, precision=1)
    assert a == 1.0

if __name__ == "__main__":
    test_Random_uniform()

# Generated at 2022-06-23 21:59:23.091105
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    for i in range(1000):
        result = rnd.generate_string('ABCDEFGHIJKLMNOPQRSTUVWZYZ' \
                                     'abcdefghijklmnopqrstuvwzyz' \
                                     '0123456789', 8)
        assert len(result) == 8
        assert result.isalnum()


# Generated at 2022-06-23 21:59:25.198458
# Unit test for method urandom of class Random
def test_Random_urandom():
    _ = Random.urandom()

# Generated at 2022-06-23 21:59:30.209257
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    result = r.uniform(1, 10)
    assert 1 <= result and result < 10, \
        f'Random class has method uniform ' \
        f'which generates random float number in the range [a, b) or [a, b].'

# Generated at 2022-06-23 21:59:34.425011
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for ``test_Random_randints()``."""
    for i in range(1, 10):
        li = random.randints(i, 1, 2)
        assert len(li) == i

    with pytest.raises(ValueError):
        random.randints(-1)
        random.randints(0)

# Generated at 2022-06-23 21:59:43.122937
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test the method uniform of class Random.

    """
    r = random
    _rand = random.uniform
    # Test uniform distribution
    assert _rand(0, 1) > _rand(0, 1)
    assert _rand(0, 1) > _rand(0, 1)
    assert _rand(0, 1) > _rand(0, 1)
    assert _rand(0, 1) > _rand(0, 1)
    assert _rand(0, 1) > _rand(0, 1)
    # Test random distribution
    assert _rand(0, 1) < _rand(0, 1)
    assert _rand(0, 1) < _rand(0, 1)
    assert _rand(0, 1) < _rand(0, 1)

# Generated at 2022-06-23 21:59:46.468794
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    print(r.uniform(0.5, 0.5, 1))

if __name__ == '__main__':
    test_Random_uniform()

# Generated at 2022-06-23 21:59:53.279428
# Unit test for function get_random_item
def test_get_random_item():
    assert 0 == get_random_item([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert 0 == get_random_item([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], Random())
    assert 0 == get_random_item([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], random)
    assert 0 == get_random_item([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], Random)
    assert 0 == get_random_item([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], random)


# Generated at 2022-06-23 21:59:59.848412
# Unit test for constructor of class Random
def test_Random():
    assert random.random()
    assert random.seed()
    assert random.urandom()
    assert random.randstr()
    assert random.randint(1, 100)
    assert random.randints(0, 100, 200)
    assert random.choice(['a', 'b', 'z'])
    assert random.choice([1, 2, 3])
    assert random.generate_string('qwertyuiopasdfghjkl;zxcvbnm')
    assert random.custom_code('@###')
    assert random.uniform(1, 2)


# Generated at 2022-06-23 22:00:02.705800
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.builtins import Person

    person = Person()
    assert person.sex() in (get_random_item(Person.Gender))
    assert person.sex(rnd=Random()) in (get_random_item(Person.Gender, Random()))

# Generated at 2022-06-23 22:00:05.869227
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random = Random()
    result = random.generate_string(str_seq=string.digits, length=3)
    assert len(result) == 3 and result.isdigit()



# Generated at 2022-06-23 22:00:08.473097
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    result = rnd.uniform(0.2, 0.5, precision=1)
    
    assert result >= 0.2
    assert result < 0.5

# Generated at 2022-06-23 22:00:16.170690
# Unit test for method uniform of class Random
def test_Random_uniform():
    value = random.uniform(2.12345678901234, 5.98765432101234)
    assert value >= 2.12345678901234 and value <= 5.98765432101234, \
        'Метод uniform класса Random выдал значение %f, а оно не входит в заданный интервал' % value

# Generated at 2022-06-23 22:00:25.407173
# Unit test for function get_random_item
def test_get_random_item():
    # Test for all enum.Gender
    assert get_random_item(enum.Gender) in list(enum.Gender)
    # Test for all enum.Finance
    assert get_random_item(enum.Finance) in list(enum.Finance)
    # Test for all enum.Transport
    assert get_random_item(enum.Transport) in list(enum.Transport)
    # Test for all enum.CryptoCoin
    assert get_random_item(enum.CryptoCoin) in list(enum.CryptoCoin)
    # Test for all enum.City
    assert get_random_item(enum.City) in list(enum.City)
    # Test for all enum.Currency
    assert get_random_item(enum.Currency) in list(enum.Currency)
    # Test for all enum.Game
   

# Generated at 2022-06-23 22:00:33.374130
# Unit test for method randstr of class Random
def test_Random_randstr():
    amount = 50
    rnd = Random()
    strs = [rnd.randstr(unique=True) for _ in range(amount)]
    strs_set = set(strs)
    assert len(strs) == len(strs_set)
    assert len(strs_set) == amount
    assert len(list(set([len(x) for x in strs]))) == 1
    assert len(strs[0]) == 32

# Generated at 2022-06-23 22:00:42.604622
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert 'R' == Random(0).custom_code('R')
    assert 'R' == Random(1).custom_code('R')
    assert 'N' == Random(100).custom_code('R')

    assert '@' == Random(0).custom_code('@')
    assert 'Z' == Random(100).custom_code('@')

    assert '@2' == Random(0).custom_code('@2')
    assert 'Z2' == Random(100).custom_code('@2')
    assert '4@' == Random(0).custom_code('4@')
    assert '42' == Random(100).custom_code('4@')

    assert 'R2' == Random(0).custom_code('@##', '@', '#')
    assert 'N2' == Random(100).custom_code

# Generated at 2022-06-23 22:00:43.169642
# Unit test for constructor of class Random
def test_Random():
    pass

# Generated at 2022-06-23 22:00:49.230491
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    for _ in range(10):
        assert len(r.custom_code()) == 4
        assert len(r.custom_code('@@@', char='@')) == 3
        assert len(r.custom_code('@@@###', char='@', digit='#')) == 7
        assert len(r.custom_code('@@@###', digit='#')) == 7
        assert len(r.custom_code('@@@@@@', char='@')) == 6

# Generated at 2022-06-23 22:00:54.014039
# Unit test for method urandom of class Random
def test_Random_urandom():
    r = Random()
    r.seed(42)
    assert r.urandom(10) == b'\x94\x9d\xbc\x8c\x95\xd6\xbb\xf7\x87\xa6'


# Generated at 2022-06-23 22:01:00.353028
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints of class Random.

    :return: None
    """
    amount = random.randint(1, 100)
    a = random.randint(-100, 100)
    b = random.randint(-100, 100)
    if a > b:
        a, b = b, a
    result_list = Random().randints(amount, a, b)
    for element in result_list:
        assert (a <= element <= b)

# Generated at 2022-06-23 22:01:01.945941
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random(10)
    assert random.custom_code('###-XY') == '086-EU'

# Generated at 2022-06-23 22:01:07.008769
# Unit test for method randints of class Random
def test_Random_randints():
    first_list = random.randints(4, 0, 10)
    
    for i in first_list:
        assert i <= 10
        assert i >= 0

    second_list = random.randints(1, -5, 5)
    
    for i in second_list:
        assert i <= 5
        assert i >= -5

# Generated at 2022-06-23 22:01:11.903094
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for urandom method."""
    bytes_1 = Random().urandom(10)
    bytes_2 = Random().urandom(10)
    assert bytes_1 != bytes_2
    assert len(bytes_1) == 10
    assert len(bytes_2) == 10
    assert isinstance(bytes_1, bytes)
    assert isinstance(bytes_2, bytes)

# Generated at 2022-06-23 22:01:17.621102
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Setup
    size1, size2, size3 = 5, 10, 15
    line1 = 'a'
    line2 = 'abcd'
    line3 = 'abcdefghij'
    str_seq = 'abcd'

    # Assert
    assert len(random.generate_string(str_seq, size1)) == size1
    assert len(random.generate_string(str_seq, size2)) == size2
    assert len(random.generate_string(str_seq, size3)) == size3
    assert random.generate_string(line1, size1) == line1
    assert random.generate_string(line2, size1) == line2
    assert random.generate_string(line3, size1) == line3

# Generated at 2022-06-23 22:01:26.626642
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random.
    """
    from mimesis.enums import Gender

    random = Random()
    gender = get_random_item(Gender)
    random_gender = random.randstr()
    assert isinstance(random_gender, str)
    assert len(random_gender) >= 16
    assert len(random_gender) <= 128
    assert random_gender != gender.value

    # Testing with unique=True
    gender = get_random_item(Gender)
    random_gender = random.randstr(unique=True)
    assert isinstance(random_gender, str)
    assert len(random_gender) == 32
    assert random_gender != gender.value

    # Testing with length=32
    gender = get_random_item(Gender)

# Generated at 2022-06-23 22:01:31.206110
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(unique=True), str)
    assert isinstance(random.randstr(unique=False), str)
    assert isinstance(random.randstr(), str)
    assert isinstance(random.randstr(length=32), str)
    assert len(random.randstr(length=32)) == 32