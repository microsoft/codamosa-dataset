

# Generated at 2022-06-23 21:51:33.777800
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of class Random."""
    r = Random()

    assert r.uniform(7.4, 0.1, 3) == 3.849
    assert r.uniform(7.4, 0.1, 2) == 4.07
    assert r.uniform(7.4, 0.1, 1) == 4.1

# Generated at 2022-06-23 21:51:37.100088
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code(mask='@###', char='@', digit='#')
    assert len(code) == 4
    assert all([str(n).isdigit() for n in code])

    code = rnd.custom_code(mask='###', char='@', digit='#')
    assert len(code) == 3
    assert all([str(n).isdigit() for n in code])

    code = rnd.custom_code(mask='@@@@', char='@', digit='#')
    assert len(code) == 4
    assert all([c.isalpha() for c in code])

# Generated at 2022-06-23 21:51:42.215350
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(a=1, b=100, amount=10) == Random().randints(1, 100, 10)
    assert type(Random().randints()) == list
    assert type(Random().randints()[0]) == int
    assert len(Random().randints(a=1, b=100, amount=10)) == 10
    assert all(1 <= i <= 100 for i in Random().randints(a=1, b=100, amount=10))


# Generated at 2022-06-23 21:51:46.303546
# Unit test for function get_random_item
def test_get_random_item():
    class Colors(object):
        RED = 'red'
        GREEN = 'green'
        BLUE = 'blue'

    assert get_random_item(Colors) in (Colors.RED, Colors.GREEN, Colors.BLUE)

# Generated at 2022-06-23 21:51:48.067241
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for ``Random().urandom()`` method."""
    assert isinstance(random.urandom(100), bytes)

# Generated at 2022-06-23 21:51:48.671895
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random().urandom(), bytes)

# Generated at 2022-06-23 21:51:50.389734
# Unit test for method urandom of class Random
def test_Random_urandom():
    random = Random()
    assert len(random.urandom(16)) == 16


# Generated at 2022-06-23 21:51:52.450332
# Unit test for method uniform of class Random
def test_Random_uniform():
    x = random.uniform(a=1, b=2)
    assert isinstance(x, float)
    assert x >= 1 and x < 2

# Generated at 2022-06-23 21:51:55.077889
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert len(rnd.randints(3)) == 3
    assert len(rnd.randints(amount=1)) == 1
    assert len(rnd.randints()) == 3

# Generated at 2022-06-23 21:51:55.988795
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(1)



# Generated at 2022-06-23 21:52:02.415865
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    import collections
    d = collections.defaultdict(int)
    for i in range(1000):
        r = random.custom_code(mask='@###')
        assert r.isalpha()
        assert r.islower()
        d[r] += 1
        if i in [10, 100, 1000]:
            print(d)
    assert len(d) == 1000
    assert d[r] == 1


# Generated at 2022-06-23 21:52:05.086687
# Unit test for function get_random_item
def test_get_random_item():
    data1 = ('foo', 'bar')
    actual_result1 = get_random_item(data1)
    assert actual_result1 in data1



# Generated at 2022-06-23 21:52:10.139959
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    assert len(Random().urandom(1)) == 1
    assert len(Random().urandom(10)) == 10
    assert len(Random().urandom(20)) == 20
    assert Random().urandom(10) == os.urandom(10)


# Generated at 2022-06-23 21:52:18.917608
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    assert Random().custom_code() == '@PJN'
    assert Random().custom_code() == '@X9G'
    assert Random().custom_code('@##') == '@54'
    assert Random().custom_code('@###', char='#') == '@012'
    assert Random().custom_code('@##', digit='%') == '@EM'

    str_seq_1 = 'abcdefghijklmnopqrstuvwxyz1234567890@#$%&'
    assert Random().generate_string(str_seq_1, 6) == '@%U6hd'
    assert Random().generate_string(str_seq_1, 6) == 'S%twDp'



# Generated at 2022-06-23 21:52:21.418225
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test a method to make sure it works correctly."""
    r = Random().uniform(5, 10, precision=5)
    assert 5 <= r < 10



# Generated at 2022-06-23 21:52:26.049091
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string(str_seq='abcdefghijklmnopqrstuvwxyz', length=5) == 'kwbjw'
    assert Random().generate_string(str_seq='abcdefghijklmnopqrstuvwxyz', length=50) != 'kwbjw'


# Generated at 2022-06-23 21:52:33.625119
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method ``custom_code()`` of class ``Random()``."""
    rnd = Random()

    assert rnd.custom_code() == 'SMOF'
    assert rnd.custom_code(mask='@###') == 'EMED'
    assert rnd.custom_code('@###') == 'QQIZ'
    assert rnd.custom_code('@###', '$', '!') == '$I!!'
    assert rnd.custom_code(digit='&', char='~') == '~G&E'
    assert rnd.custom_code(digit='&', char='~', mask='~&~&') == '~&~&'
    assert rnd.custom_code(digit='&', char='@', mask='@**&*') == '@**&*'
    assert r

# Generated at 2022-06-23 21:52:37.288579
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(random.randstr(length=20)) == 20
    assert len(random.randstr()) != 0
    assert len(random.randstr(unique=True)) != 0

# Generated at 2022-06-23 21:52:38.406936
# Unit test for constructor of class Random
def test_Random():
    assert Random() != Random()

# Generated at 2022-06-23 21:52:39.755067
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _random = Random()
    assert _random.custom_code()



# Generated at 2022-06-23 21:52:44.299504
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    print(Random().generate_string(str(string.ascii_letters + string.digits), 5))
    print(Random().generate_string(str(string.ascii_letters), 5))
    print(Random().generate_string(str(string.digits), 5))
    print(Random().generate_string(str(string.hexdigits), 5))

test_Random_generate_string()

# Generated at 2022-06-23 21:52:47.145696
# Unit test for method urandom of class Random
def test_Random_urandom():
    r = Random()
    assert r.urandom()
    assert isinstance(r.urandom(), bytes)

# Generated at 2022-06-23 21:52:52.211887
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random.

        >>> import mimesis.data
        >>> random = mimesis.data.Random()
        >>> x = random.uniform(1, 10)
        >>> isinstance(x, float)
        True
        >>> assert x >= 1 and x < 10
    """
    pass

# Generated at 2022-06-23 21:52:54.998073
# Unit test for method uniform of class Random
def test_Random_uniform():
    import sys
    import pytest
    numbers = []
    r = Random(1)
    r.uniform(0.5, 0.5)
    for _ in range(10):
        res = r.uniform(0.5, 0.5, precision=15)
        numbers.append(res)
    assert numbers == [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]

# Generated at 2022-06-23 21:52:56.895283
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = random.Random()
    print(rnd.custom_code())

# Generated at 2022-06-23 21:52:58.737432
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Test that method urandom is inherited from os.urandom
    assert Random.urandom == os.urandom



# Generated at 2022-06-23 21:53:02.273427
# Unit test for function get_random_item
def test_get_random_item():
    """Test method with random values."""
    assert isinstance(get_random_item(random, random), int)
    assert isinstance(get_random_item(random.random, random), float)

# Generated at 2022-06-23 21:53:05.428714
# Unit test for function get_random_item
def test_get_random_item():
    enum = [1, 2, 3]
    get_random_item(enum)


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-23 21:53:08.945238
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test method randstr.

    Method randstr should generate random string of 16 characters
    by default, but you can specify the length of result
    string via first parameter.

    """
    # Simple without characters
    result = Random().randstr(False)
    assert result is not None
    assert len(result) == 16

    # Simple with characters
    result = Random().randstr(False, 128)
    assert result is not None
    assert len(result) == 128

    # Unique
    result = [Random().randstr(True) for _ in range(100)]
    assert len(result) == len(set(result))

# Generated at 2022-06-23 21:53:11.980319
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test method generate_string of class Random."""
    r = Random(123)
    assert r.generate_string(string.ascii_letters, length=10) == \
        'lZmDdZpwTJ'

# Generated at 2022-06-23 21:53:23.634622
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random"""
    custom_code_01 = random.custom_code()
    assert isinstance(custom_code_01, str)
    assert len(custom_code_01) == 4
    assert custom_code_01[-1].isdigit()
    custom_code_02 = random.custom_code(mask="######", char="@", digit="#")
    assert isinstance(custom_code_02, str)
    assert len(custom_code_02) == 6
    custom_code_03 = random.custom_code(mask="@@@##", char="1", digit="2")
    assert isinstance(custom_code_03, str)
    assert len(custom_code_03) == 5


# Generated at 2022-06-23 21:53:25.556371
# Unit test for function get_random_item
def test_get_random_item():
    random.seed(13)
    assert get_random_item(enum=["F", "L", "D"], rnd=random) == "F"

# Generated at 2022-06-23 21:53:28.804549
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    assert r.randints(a=10, b=100) == [20, 18, 64]
    assert r.randints(amount=0, a=10, b=100) == []


# Generated at 2022-06-23 21:53:30.533753
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(32) == os.urandom(32)

# Generated at 2022-06-23 21:53:35.243531
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    result = set()
    r = Random()
    r.seed(1)
    for _ in range(10):
        result.add(r.generate_string(length=10, str_seq='abc'))

    assert len(result) == 1
    assert result == {'aaaaaaaaaa'}

# Generated at 2022-06-23 21:53:37.682565
# Unit test for method randints of class Random
def test_Random_randints():
    num = random.randints(3, 1, 100)
    assert len(num) == 3
    for _ in num:
        assert _ in range(1, 100)

# Generated at 2022-06-23 21:53:39.681731
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    assert len(r.randints()) == 3
    assert len(r.randints(amount=2)) == 2
    assert len(r.randints(amount=1)) == 1

    for i in r.randints():
        assert isinstance(i, int)



# Generated at 2022-06-23 21:53:43.135058
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test method ``urandom`` of class ``Random()``.

    """
    _random = Random()
    _bytes = _random.urandom(10)
    assert len(_bytes) == 10
    assert isinstance(_bytes, bytes)



# Generated at 2022-06-23 21:53:45.162957
# Unit test for method urandom of class Random
def test_Random_urandom():
    a = Random.urandom(10)
    assert type(a) == bytes
    assert len(a) == 10


# Generated at 2022-06-23 21:53:47.035992
# Unit test for method urandom of class Random
def test_Random_urandom():
    r = Random()
    r.urandom(10)


# Generated at 2022-06-23 21:53:58.005702
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    actual_result = rnd.custom_code()
    print(actual_result)
    assert actual_result is not None
    assert len(actual_result) == 4
    assert actual_result[0].isalpha()
    assert actual_result[1].isdigit()
    assert actual_result[2].isdigit()
    assert actual_result[3].isdigit()
    assert actual_result[0] != actual_result[1]
    assert actual_result[0] != actual_result[2]
    assert actual_result[0] != actual_result[3]
    assert actual_result[1] != actual_result[2]
    assert actual_result[1] != actual_result[3]
    assert actual_result[2] != actual_result[3]
    assert actual_

# Generated at 2022-06-23 21:53:58.852799
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)



# Generated at 2022-06-23 21:54:01.979173
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    import pytest

    with  pytest.raises(ValueError):
        Random.custom_code(char='@', digit='#')


# Generated at 2022-06-23 21:54:05.090684
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    test_string = 'dsada'
    rnd = Random()
    result = rnd.custom_code()
    assert len(result) == len(test_string)
    for i in result:
        assert i in test_string


# Generated at 2022-06-23 21:54:16.657949
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    code = r.custom_code()
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1:].isdigit()

    # Another way
    code = r.custom_code('@@@@-@@@@')
    assert len(code) == 9
    assert code[:4].isalpha()
    assert code[4] == '-'
    assert code[5:].isalpha()

    code = r.custom_code('@@@@-@@@')
    assert len(code) == 8
    assert code[:4].isalpha()
    assert code[4] == '-'
    assert code[5:].isalpha()

    code = r.custom_code('@@@@-@@@', char='@')
    assert len(code) == 8

# Generated at 2022-06-23 21:54:17.543544
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)

# Generated at 2022-06-23 21:54:18.770975
# Unit test for function get_random_item
def test_get_random_item():
    rnd = Random()
    for _ in range(20):
        print(get_random_item(rnd))

# Generated at 2022-06-23 21:54:20.938150
# Unit test for method randints of class Random
def test_Random_randints():
    assert random.randints(30) == [77, 75, 73]
    assert random.randints(2, 1, 6) == [4, 4]


# Generated at 2022-06-23 21:54:22.917541
# Unit test for constructor of class Random
def test_Random():
    a = Random()
    b = Random()
    assert a.getstate() == b.getstate()

# Generated at 2022-06-23 21:54:30.689829
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert -0.85 < random.uniform(-1, 0) < 0
    assert 0 < random.uniform(0, 1) < 1
    assert 1 < random.uniform(1, 2) < 2
    assert 2.85 < random.uniform(2, 3) < 3
    assert random.uniform(-1, 1, 5) == -0.85
    assert random.uniform(-1, 1, 4) == -0.855
    assert random.uniform(-1, 1, 3) == -0.859
    assert random.uniform(-1, 1, 2) == -0.87
    assert random.uniform(-1, 1, 1) == -0.9

# Generated at 2022-06-23 21:54:31.903784
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0.00934, 0.01) == 0.01001868955

# Generated at 2022-06-23 21:54:33.114239
# Unit test for constructor of class Random
def test_Random():
    _ = Random()
    assert isinstance(_, Random)



# Generated at 2022-06-23 21:54:40.905509
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random.
    """
    print('------------UNIT TEST RANDOM---------------')
    random = Random()
    for i in range(100):
        a, b, precision = 0, 1, 10
        n = random.uniform(a, b, precision)
        assert isinstance(n, float)
        assert n >= a and n < b
    print('UNIT TEST RANDOM IS OK')
    print('-------------------------------------------')

test_Random_uniform()

# Generated at 2022-06-23 21:54:42.233361
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)

# Generated at 2022-06-23 21:54:43.781141
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    assert len(random.generate_string('ABCDEFGHIJKLMNOPQRSTUVWXYZ', 10)) == 10

# Generated at 2022-06-23 21:54:45.231774
# Unit test for method urandom of class Random
def test_Random_urandom():
    urandom = Random().urandom
    assert isinstance(urandom(), bytes)
    assert len(urandom()) == 16

# Generated at 2022-06-23 21:54:52.379501
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method ``randstr`` of class ``Random()``.
    """
    r = Random()

    actual = r.randstr(unique=True)
    expected = uuid.uuid4().hex

    assert len(actual) == len(expected)

    actual = r.randstr()
    assert len(actual) >= 16
    assert len(actual) <= 128

    assert isinstance(r.randstr(length=10), str)
    assert len(r.randstr(length=10)) == 10

    for _a, _b in zip(actual, expected):
        assert _a.isdigit() == _b.isdigit()
        assert _a.isalpha() == _b.isalpha()


# Generated at 2022-06-23 21:54:59.676478
# Unit test for method randstr of class Random
def test_Random_randstr():
    # create random object with fixed seed
    random_seed = 100
    random = Random(random_seed)

    # check if string length is correct
    len_correct_string = 16
    correct_string = 'CgwI8KlZOlQ2H1Bx'

    assert len(random.randstr(length=len_correct_string)) == len_correct_string
    assert random.randstr(length=len_correct_string) == correct_string

    # check if unique string is unique
    unique_string_1 = random.randstr(unique=True)
    unique_string_2 = random.randstr(unique=True)
    assert unique_string_1 != unique_string_2

# Generated at 2022-06-23 21:55:10.644919
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    list_1 = rnd.randints()
    assert len(list_1) == 3
    assert isinstance(list_1[0], int)
    assert isinstance(list_1[1], int)
    assert isinstance(list_1[2], int)

    list_2 = rnd.randints(3)
    assert len(list_2) == 3
    assert isinstance(list_2[0], int)
    assert isinstance(list_2[1], int)
    assert isinstance(list_2[2], int)

    list_3 = rnd.randints(3, 1, 10)
    assert len(list_3) == 3
    assert isinstance(list_3[0], int)
    assert isinstance(list_3[1], int)

# Generated at 2022-06-23 21:55:12.748294
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string(str_seq='QWERTY')) > 0


# Generated at 2022-06-23 21:55:16.500992
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    r.seed(1)
    assert round(r.uniform(-10, 10), 14) == 4.955532033675931
    assert round(r.uniform(-10, 10, precision=4), 3) == 4.956


# Generated at 2022-06-23 21:55:18.962774
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    rnd_str=rnd.randstr(unique=True,length=24)
    print(rnd_str)


# Generated at 2022-06-23 21:55:21.311675
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    codes = [rnd.custom_code(mask='@###') for x in range(100000)]
    for code in codes:
        assert len(code) == 4
    rnd.custom_code(mask='@###', char='@', digit='#')

# Generated at 2022-06-23 21:55:24.172314
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code."""
    rnd = Random()
    assert len(rnd.custom_code()) == 4
    assert len(rnd.custom_code('@##')) == 3
    assert len(rnd.custom_code('@##', '$')) == 3

# Generated at 2022-06-23 21:55:32.094036
# Unit test for method uniform of class Random
def test_Random_uniform():
    TIMEOUT = 20
    rnd = Random()
    try:
        import threading
        timer = threading.Timer(TIMEOUT, lambda: None)
        timer.start()
        for i in range(1, 1000):
            x = rnd.uniform(0, 100)
            if not 0 <= x < 100:
                raise AssertionError
    except AssertionError:
        print('Test failed')
    finally:
        timer.cancel()

# Generated at 2022-06-23 21:55:41.255884
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(Random().randints(), list)
    assert isinstance(Random().randints(1, 1, 100), list)
    assert isinstance(Random().randints(2, 1, 100), list)
    assert isinstance(Random().randints(3, 1, 100), list)
    assert isinstance(Random().randints(10, 1, 100), list)
    assert isinstance(Random().randints(100, 1, 100), list)
    assert isinstance(Random().randints(1000, 1, 100), list)
    assert isinstance(Random().randints(-1, 1, 100), list)
    assert isinstance(Random().randints(0, 1, 100), list)
    assert isinstance(Random().randints(1, 100), list)
    assert isinstance(Random().randints(2, 100), list)


# Generated at 2022-06-23 21:55:45.307859
# Unit test for method randints of class Random
def test_Random_randints():
    space = [0]
    
    for _ in range(100):
        limit = random.randint(1, 5)
        space = []
        for i in range(limit):
            space.append(random.randint(1, 10))
        assert len(space) == limit

# Generated at 2022-06-23 21:55:48.926721
# Unit test for constructor of class Random
def test_Random():
    assert Random()
    assert Random(0)
    assert Random(1)
    assert Random(123)
    assert Random(1234)



# Generated at 2022-06-23 21:55:50.973436
# Unit test for method urandom of class Random
def test_Random_urandom():
    _random = Random()
    x = _random.urandom(16)
    assert x != None


# Generated at 2022-06-23 21:55:54.712161
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    assert Random().custom_code()
    assert Random().custom_code(mask='@@@')
    assert Random().custom_code(mask='@@@', char='#')
    assert Random().custom_code(mask='@@@', char='#', digit='$')

# Generated at 2022-06-23 21:55:59.932202
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    assert random.choice([1, 2, 3]) in [1, 2, 3]
    assert random.randint(1, 100) in range(1, 100)
    assert len(random.randints(2, 1, 10)) == 2
    assert isinstance(random.generate_string('abcde'), str)
    assert isinstance(random.custom_code(), str)

# Generated at 2022-06-23 21:56:01.509660
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(enum=object, rnd=Random()) is not None

# Generated at 2022-06-23 21:56:07.324544
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)
    assert isinstance(Random(1), Random)
    assert isinstance(Random(1, 2), Random)
    assert isinstance(Random(seed=1), Random)
    assert isinstance(Random(version=1), Random)
    assert isinstance(Random(version=1, seed=2), Random)

# Generated at 2022-06-23 21:56:15.160769
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random"""
    rnd = Random(seed=0)
    assert rnd.random() == 0.8444218515250481
    assert rnd.randint(5, 10) == 8
    assert rnd.randrange(5, 10) == 7
    assert rnd.randrange(0, 101, 5) == 95
    assert rnd.choice('abcdefghij') == 'i'
    assert rnd.sample([1, 2, 3, 4, 5],  4) == [4, 5, 1, 2]

# Generated at 2022-06-23 21:56:16.538302
# Unit test for method randints of class Random
def test_Random_randints():
    rand_num = Random.randints()
    assert len(rand_num) == 3

# Generated at 2022-06-23 21:56:20.890683
# Unit test for function get_random_item
def test_get_random_item():
    """
    Test function ``get_random_item()``.
    """
    from mimesis.enums import Gender

    gender = get_random_item(Gender)
    assert gender in Gender

    genders = [get_random_item(Gender) for _ in range(100)]
    assert len(genders) == len(set(genders))

# Generated at 2022-06-23 21:56:25.030059
# Unit test for function get_random_item
def test_get_random_item():
    class Enum(object):
        First = 'First'
        Second = 'Second'

        def __init__(self, name: str) -> None:
            self.name = name

    assert get_random_item(Enum, Random()).name in ['First', 'Second']

# Generated at 2022-06-23 21:56:28.660633
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)
    assert isinstance(Random(), Random)
    assert isinstance(random, random_module.Random)
    assert isinstance(Random(), random_module.Random)
    assert type(random) is Random
    assert type(Random()) is Random

# Generated at 2022-06-23 21:56:30.720467
# Unit test for method randstr of class Random
def test_Random_randstr():
    random.seed(1)
    data = random.randstr()
    condition = len(data) <= 128
    assert condition

# Generated at 2022-06-23 21:56:33.523921
# Unit test for method randints of class Random
def test_Random_randints():
    count = 100
    for _ in range(count):
        i = random.randint(1, 100)
        assert i in random.randints(a=1, b=101)


# Generated at 2022-06-23 21:56:34.565471
# Unit test for method randints of class Random
def test_Random_randints():
    # code
    pass  # TODO
    # code

# Generated at 2022-06-23 21:56:36.446321
# Unit test for method uniform of class Random
def test_Random_uniform():
    for _ in range(100):
        number = random.uniform(10.0, 20.0)
        assert 10.0 <= number <= 20.0
        assert isinstance(number, float)

# Generated at 2022-06-23 21:56:41.180032
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Make sure it works as expected."""
    assert random.generate_string(
        str_seq=string.digits, length=5
    )
    assert random.generate_string(
        str_seq=string.ascii_letters, length=5
    )
    assert random.generate_string(
        str_seq=string.ascii_letters + string.digits, length=5
    )


# Generated at 2022-06-23 21:56:50.082052
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)

    code = rnd.custom_code('AD#')
    assert isinstance(code, str)
    assert len(code) == 3

    code = rnd.custom_code('(###)')
    assert isinstance(code, str)
    assert len(code) == 5

    code = rnd.custom_code('A-(###)-#')
    assert isinstance(code, str)
    assert len(code) == 9



# Generated at 2022-06-23 21:56:52.278005
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert type(random.randstr()) == str


# Generated at 2022-06-23 21:56:58.713318
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    '''
    Test for method custom_code of class Random
    '''
    assert len(Random().custom_code()) == 4
    assert len(Random().custom_code(mask='@@12@@')) == 6
    assert len(Random().custom_code(mask='@####')) == 5
    assert len(Random().custom_code(mask='@@', char='@', digit='@')) == 0
    assert len(Random().custom_code(mask='@')) == 1

# Generated at 2022-06-23 21:57:07.832554
# Unit test for constructor of class Random
def test_Random():
    assert Random()
    assert Random().random() in [round(i, 1) for i in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]]
    assert Random().randint in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-23 21:57:09.048590
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random), Random)



# Generated at 2022-06-23 21:57:13.061983
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    gen = Random()
    code = gen.custom_code()
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1].isalpha()
    assert code[2].isalpha()
    assert code[3].isdigit()

# Generated at 2022-06-23 21:57:24.380514
# Unit test for constructor of class Random
def test_Random():
    # test rand pattern
    # test generate_numbers
    # assert(len(Random().generate_numbers()) > 0)
    assert (len(Random().
               generate_string(string.ascii_lowercase, 10)) == 10)
    assert (len(Random().
               generate_string(string.digits, 10)) == 10)
    assert (len(Random().
               generate_string(string.ascii_lowercase + string.digits, 10)) == 10)
    assert (len(Random().custom_code()) >= 4)
    assert (len(Random().custom_code(mask='@###@')) >= 5)
    # test int
    assert (isinstance(Random().int(), int))
    # test float
    assert (isinstance(Random().float(), float))

# Generated at 2022-06-23 21:57:25.868341
# Unit test for method uniform of class Random
def test_Random_uniform():
    a = random.uniform(0, 0.2)
    assert 0 <= a < 0.2

# Generated at 2022-06-23 21:57:32.709939
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(random.randints(), list)
    assert len(random.randints()) == 3
    assert len(random.randints(amount=7)) == 7

    random.seed(42)
    assert random.randints(0, 0, 100) == [90, 90, 90]
    random.seed(42)
    assert random.randints(0, 100, 0) == [90, 90, 90]



# Generated at 2022-06-23 21:57:38.275775
# Unit test for method uniform of class Random
def test_Random_uniform():
    random_objects = [
        Random(), random_module, random,
    ]
    for random_object in random_objects:
        assert isinstance(random_object.uniform(1.0, 1.1), float)
        assert 1.0 <= random_object.uniform(1.0, 1.1) < 1.1
        assert 1.00 <= random_object.uniform(1.0, 1.1, precision=2) < 1.1
        assert 1.000 <= random_object.uniform(1.0, 1.1, precision=3) < 1.1
        assert 1.0000 <= random_object.uniform(1.0, 1.1, precision=4) < 1.1

        assert isinstance(random_object.uniform(1, 1.1), float)
        assert 1.0 <= random_

# Generated at 2022-06-23 21:57:48.600453
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # GIVEN
    rnd = Random()
    s = string.ascii_letters + string.digits
    # THEN
    s = rnd.generate_string(str_seq=s, length=10)
    assert len(s) == 10
    # THEN
    s = rnd.generate_string(str_seq=string.digits, length=10)
    assert len(s) == 10
    # THEN
    with pytest.raises(TypeError):
        rnd.generate_string(123, length=10)
    # THEN
    with pytest.raises(ValueError):
        rnd.generate_string(s, -10)
    # THEN
    with pytest.raises(TypeError):
        rnd.generate_string(s, length=1.1)



# Generated at 2022-06-23 21:57:50.078512
# Unit test for method urandom of class Random
def test_Random_urandom():
    result = random.urandom(4)
    assert (len(result) == 4)

# Generated at 2022-06-23 21:57:53.458944
# Unit test for function get_random_item
def test_get_random_item():
    import enum

    class Animal(enum.Enum):
        DOG = 'Dog'
        CAT = 'Cat'
        MOUSE = 'Mouse'

    assert get_random_item(Animal) in Animal

# Generated at 2022-06-23 21:57:57.912023
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Generate some random values
    values = [random.randstr() for _ in range(1, 10)]
    # Test if all values are unique
    assert len(values) == len(set(values))

# Generated at 2022-06-23 21:58:01.077305
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    a = random.custom_code(mask='@###')
    b = random.custom_code(mask='@###')
    c = random.custom_code(mask='@###')
    assert a != b != c

# Generated at 2022-06-23 21:58:04.326162
# Unit test for function get_random_item
def test_get_random_item():
    """Test function get_random_item."""
    # more informative error msg for assertion
    assert get_random_item(Random) 


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-23 21:58:05.690881
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)

# Generated at 2022-06-23 21:58:10.417102
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(10)
    assert len(Random().urandom(10)) == 10
    assert len(Random().urandom(10)) != 9
    assert len(Random().urandom(10)) <= 10
    assert len(Random().urandom(10)) >= 10
    assert type(Random().urandom(10)) == bytes
    assert type(Random().urandom(10)) != str



# Generated at 2022-06-23 21:58:13.497856
# Unit test for constructor of class Random
def test_Random():
    assert Random()
    assert Random(1)
    assert Random(2).random.random()
    assert Random(2).random.random()
    assert Random(2).random.random()
    assert Random(2).random.random()
    assert Random(2).random.random()



# Generated at 2022-06-23 21:58:16.207886
# Unit test for function get_random_item
def test_get_random_item():
    from .enums import Currencies

    c = get_random_item(Currencies)
    assert isinstance(c, Currencies)

# Generated at 2022-06-23 21:58:20.747304
# Unit test for constructor of class Random
def test_Random():
    rand = Random()
    rand.randints()
    rand.randstr
    rand.generate_string('abc')
    rand.custom_code()
    rand.urandom(10)
    rand.uniform(3, 5)

# Test for function get_random_item()

# Generated at 2022-06-23 21:58:22.843240
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method ``uniform()`` of class Random."""
    rnd = Random()
    assert rnd.uniform(a=0, b=5, precision=5) == round(rnd.random() * 5, 5)



# Generated at 2022-06-23 21:58:32.523675
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = random.uniform(0.12345678, 0.87654321)
    r1 = round(r, 8)
    assert r1 >= 0.12345678 and r1 <= 0.87654321
    r2 = random.uniform(0.12345678, 0.87654321, precision=4)
    r2 = round(r2, 4)
    assert r2 >= 0.12345678 and r2 <= 0.87654321
    random.seed(5)
    assert random.uniform(0.12345678, 0.87654321, precision=3) == 0.6665
    print("Ok")

# Generated at 2022-06-23 21:58:37.352209
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    expected_result_1 = 'e'*30
    expected_result_2 = 'e'*3

    actual_result_1 = random.generate_string('e', 30)
    actual_result_2 = random.generate_string('e')

    assert expected_result_1 == actual_result_1
    assert expected_result_2 == actual_result_2




# Generated at 2022-06-23 21:58:42.275280
# Unit test for constructor of class Random
def test_Random():
    """Test for constructor of class Random."""
    seed = random.getrandbits(2048)
    rnd = Random()
    print(rnd.random())
    rnd = Random(seed)
    print(rnd.random())
    rnd = Random(seed)
    print(rnd.random())
    rnd = Random(0)
    print(rnd.random())

# Generated at 2022-06-23 21:58:54.320950
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    try:
        rnd = Random(123)
    except TypeError:
        pass
    else:
        raise AssertionError('Random() class can be instantiated without args.')

    rnd = Random()
    assert rnd.custom_code() == '@AAA'
    assert rnd.custom_code('@@@#') == '@AA#'
    assert rnd.custom_code('#', '*') == '###'
    assert rnd.custom_code('#', digit='*') == '###'
    assert rnd.custom_code('*', char='#') == '###'
    assert rnd.custom_code(mask='#', char='*', digit='*') == '###'
    assert rnd.custom_code(mask='*', char='*', digit='#') == '###'

# Generated at 2022-06-23 21:58:58.083714
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(string.digits), str)
    assert isinstance(get_random_item(string.digits, random_module), str)
    assert len(get_random_item(string.digits)) == 1
    assert len(get_random_item(string.digits, random_module)) == 1


# Generated at 2022-06-23 21:58:59.779606
# Unit test for constructor of class Random
def test_Random():
    random.seed(1)
    assert random.random() == random.random(1)



# Generated at 2022-06-23 21:59:02.999315
# Unit test for method uniform of class Random
def test_Random_uniform():
    for _ in range(0, 100):
        assert (random.uniform(0, 1, 4) >= 0)
        assert (random.uniform(0, 1, 4) < 1)



# Generated at 2022-06-23 21:59:07.059619
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert len(rnd.randints()) == 3
    assert len(rnd.randints(amount=3)) == 3
    assert len(rnd.randints(4)) == 4
    assert len(rnd.randints(amount=4)) == 4



# Generated at 2022-06-23 21:59:08.021298
# Unit test for constructor of class Random
def test_Random():
    random = Random()


# Generated at 2022-06-23 21:59:14.148712
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    assert random.uniform(1.0, 2.0, precision=1) == 1.0
    assert random.uniform(1.0, 2.0, precision=2) == 1.5
    assert random.uniform(1.0, 2.0, precision=3) == 1.5
    assert random.uniform(1.0, 2.0, precision=4) == 1.5
    assert random.uniform(1.0, 3.0, precision=4) == 2.5

# Generated at 2022-06-23 21:59:15.834424
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert all(isinstance(Random().urandom(8), bytes) for _ in range(3))

# Generated at 2022-06-23 21:59:17.515829
# Unit test for method uniform of class Random
def test_Random_uniform():
    value = random.uniform(4, 10)
    assert isinstance(value, float)
    assert value >= 4

# Generated at 2022-06-23 21:59:20.333285
# Unit test for method randstr of class Random
def test_Random_randstr():
    from mimesis.typing import Seed
    rnd = Random(seed=Seed(1))
    assert rnd.randstr() == 'h2lgt5zc9ovrk1r'

# Generated at 2022-06-23 21:59:21.512574
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(Random().randints(), list)



# Generated at 2022-06-23 21:59:23.886897
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    a = r.custom_code()
    b = r.custom_code()
    print(a, b)
    assert a != b


# Generated at 2022-06-23 21:59:26.092550
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    l = []
    for i in range(0, 20):
        l.append(r.uniform(0, 1))
    l.sort()

    assert l[-1] <= 1
    assert l[0] >= 0

# Generated at 2022-06-23 21:59:29.704135
# Unit test for constructor of class Random
def test_Random():
    r = Random(random=random_module.random)
    assert isinstance(r, Random), 'Random() instance is not ' \
                                  'instance of Random class.'

# Generated at 2022-06-23 21:59:30.297524
# Unit test for method randints of class Random
def test_Random_randints():
    assert random.randints() != random.randints()

# Generated at 2022-06-23 21:59:34.087019
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    rnd = Random()
    assert rnd.uniform(1, 5) == 4.8
    assert rnd.uniform(1, 5, precision=1) == 4.8
    assert rnd.uniform(1, 5, precision=0) == 5.0

# Generated at 2022-06-23 21:59:35.463833
# Unit test for method urandom of class Random
def test_Random_urandom():
    from os import urandom
    assert Random().urandom(10) == urandom(10)

# Generated at 2022-06-23 21:59:37.817808
# Unit test for method urandom of class Random
def test_Random_urandom():
    """A unit test for method urandom of class Random."""
    assert Random.urandom()



# Generated at 2022-06-23 21:59:39.989652
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    _bytes = random.urandom(10)
    assert len(_bytes) == 10
    assert isinstance(_bytes, bytes)

# Generated at 2022-06-23 21:59:41.951064
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints."""
    rand_int = Random().randints(amount=3, a=1, b=10)
    assert len(rand_int) == 3

# Generated at 2022-06-23 21:59:46.026265
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    assert len(Random().urandom(20)) == 20
    assert len(Random().urandom(30)) == 30

# Generated at 2022-06-23 21:59:50.745110
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random.urandom(), bytes)
    assert isinstance(Random.urandom(10), bytes)
    assert isinstance(Random.urandom(10, 10), bytes)
    assert isinstance(Random.urandom(10, 10, 10), bytes)
    assert isinstance(Random.urandom(10, 10, 10, 10), bytes)
    assert isinstance(Random().urandom(), bytes)
    assert isinstance(Random().urandom(10), bytes)
    assert isinstance(Random().urandom(10, 10), bytes)
    assert isinstance(Random().urandom(10, 10, 10), bytes)
    assert isinstance(Random().urandom(10, 10, 10, 10), bytes)

# Generated at 2022-06-23 21:59:57.571363
# Unit test for method randstr of class Random
def test_Random_randstr():
    # assert len(random.randstr(False)) == 64
    # assert len(random.randstr(True)) == 32
    # assert len(random.randstr(False, 128)) == 128
    # assert len(random.randstr(False)) != 128
    assert len(random.randstr(False)) >= 16
    assert len(random.randstr(False)) <= 128
    assert len(random.randstr(True)) == 32
    assert len(random.randstr(False, 10)) == 10
    assert len(random.randstr(False, 10000)) == 10000

# Generated at 2022-06-23 21:59:58.909617
# Unit test for constructor of class Random
def test_Random():
    res = Random()
    assert isinstance(res, Random)



# Generated at 2022-06-23 22:00:01.715294
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints of class Random."""
    random_int = list(random.randints(a=10, b=21))
    assert all(e in range(10, 22) for e in random_int)

    # Test of the exception
    try:
        random_int = list(random.randints(amount=-10))
    except ValueError as err:
        assert err.args[0] == 'Amount out of range.'



# Generated at 2022-06-23 22:00:03.111004
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert round(random.uniform(12, 20), 0) == round(random_module.uniform(12, 20), 0)

# Generated at 2022-06-23 22:00:05.668374
# Unit test for method uniform of class Random
def test_Random_uniform():
    A = Random().uniform(0, 1, 10)
    print(A)
    assert round(A, 10) >= 0
    assert round(A, 10) < 1

# Generated at 2022-06-23 22:00:11.309676
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random"""
    a = random.uniform(1, 10, precision=2)
    assert 1 <= a <= 10
    assert round(a, 2) == a
    assert type(a) == float

    a = random.uniform(1, 10, precision=4)
    assert 1 <= a <= 10
    assert round(a, 4) == a
    assert type(a) == float

# Generated at 2022-06-23 22:00:13.672691
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    r.seed(0)
    assert 0.0 < r.uniform(3.14, 10.0) < 10.0

# Generated at 2022-06-23 22:00:16.167824
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(), str)
    assert isinstance(random.randstr(unique=True), str)



# Generated at 2022-06-23 22:00:19.052525
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(Random().randstr(), str)
    assert isinstance(Random().randstr(8), str)
    assert len(Random().randstr(8)) == 8
    assert isinstance(Random().randstr(unique=True), str)

# Generated at 2022-06-23 22:00:21.893552
# Unit test for method urandom of class Random
def test_Random_urandom():
    first_bytes = random.urandom(10)
    next_bytes = random.urandom(10)
    assert first_bytes != next_bytes
    assert len(first_bytes) == len(next_bytes) == 10

# Generated at 2022-06-23 22:00:25.303143
# Unit test for method urandom of class Random
def test_Random_urandom():
    from mimesis.enums import HashAlgorithm

    assert Random.urandom is os.urandom

    r = Random(seed=1632)
    assert r.urandom(HashAlgorithm.SHA1.value.encode())
    r.set_seed(1, 2, 3)
    assert r.urandom(HashAlgorithm.SHA1.value.encode())

# Generated at 2022-06-23 22:00:36.182472
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    r.seed(21)
    assert r.uniform(a=1.11, b=1.12, precision=3) == 1.114
    assert r.uniform(a=1.11, b=1.12, precision=3) == 1.115
    assert r.uniform(a=1.11, b=1.12, precision=3) == 1.114
    assert r.uniform(a=1.11, b=1.12, precision=3) == 1.116
    assert r.uniform(a=1.11, b=1.12, precision=3) == 1.113


if __name__ == '__main__':
    test_Random_uniform()

# Generated at 2022-06-23 22:00:37.486494
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(random_module.random()), Random)

# Generated at 2022-06-23 22:00:39.931076
# Unit test for method randstr of class Random
def test_Random_randstr():
    """ Unit test for method randstr of class Random """
    rr = Random()
    s = rr.randstr()
    assert isinstance(s, str) == True

# Generated at 2022-06-23 22:00:43.872570
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###') == 'A000'
    assert random.custom_code('@###') == 'A000'
    assert random.custom_code('@###') == 'A000'
    assert random.custom_code('@###') == 'A000'

# Generated at 2022-06-23 22:00:46.255053
# Unit test for method urandom of class Random
def test_Random_urandom():
    urandom_test = Random.urandom(1)
    assert isinstance(urandom_test, bytes)


# Unit tests for method randints of class Random

# Generated at 2022-06-23 22:00:54.566322
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    custom_code_1 = '@###'
    custom_code_2 = '##A#'
    custom_code_3 = '@@@A'

    assert len(random.custom_code(custom_code_1)) == 4
    assert len(random.custom_code(custom_code_2)) == 4
    assert len(random.custom_code(custom_code_3)) == 4

    assert random.custom_code(custom_code_1).startswith('@')
    assert random.custom_code(custom_code_2).startswith('#')
    assert random.custom_code(custom_code_3).startswith('@')

    assert len([i for i in random.custom_code(custom_code_1) if i.isalpha()]) == 1

# Generated at 2022-06-23 22:01:03.677498
# Unit test for method randstr of class Random
def test_Random_randstr():
    random = Random()
    randstr = random.randstr()
    assert randstr
    assert isinstance(randstr, str)
    assert not randstr.startswith('0x')
    assert len(randstr) >= 16
    assert len(randstr) <= 128

    randstr = random.randstr(unique=True)
    assert randstr
    assert isinstance(randstr, str)
    assert not randstr.startswith('0x')
    assert len(randstr) >= 32
    assert len(randstr) <= 32

    randstr = random.randstr(length=12)
    assert randstr
    assert isinstance(randstr, str)
    assert not randstr.startswith('0x')
    assert len(randstr) == 12


# Generated at 2022-06-23 22:01:12.349031
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random.randints(), list)
    assert isinstance(random.generate_string('qwertyuiopasdfghjklzxcvbnm'), str)
    assert isinstance(random.custom_code(), str)
    assert isinstance(random.urandom(), bytes)
    assert isinstance(random.uniform(1, 10), float)
    assert isinstance(random.choice([1, 2, 3]), int)
    assert isinstance(random.choices([1, 2, 3]), list)
    assert isinstance(random.sample([1, 2, 3], k=2), list)
    assert isinstance(random.randstr(unique=True), str)
    assert isinstance(get_random_item(random), Random)

test_Random()

# Generated at 2022-06-23 22:01:18.248128
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = '@@@'
    char = '@'
    digit = '#'
    result = Random().custom_code(mask,char,digit)
    assert isinstance(result,str)
    assert len(result) == len(mask)
    assert result[0] in string.ascii_uppercase
    assert result[1] in string.ascii_uppercase
    assert result[2] in string.digits

# Generated at 2022-06-23 22:01:19.229320
# Unit test for method urandom of class Random
def test_Random_urandom():
    random = Random()
    random.urandom()

# Generated at 2022-06-23 22:01:27.498680
# Unit test for method uniform of class Random
def test_Random_uniform():
    # default precision is 15
    # result should be 14.61668692375099
    precision = 15
    a = 10
    b = 20
    val = random.uniform(a=a, b=b)
    assert len(str(val).split('.')[1]) <= precision
    assert a < val < b

    # precision is 10
    # result should be 17.7533784388
    precision = 10
    val = random.uniform(a=a, b=b, precision=precision)
    assert len(str(val).split('.')[1]) <= precision

    # precision is 8
    # result should be 17.75337843
    precision = 8
    val = random.uniform(a=a, b=b, precision=precision)
    assert len(str(val).split('.')[1])

# Generated at 2022-06-23 22:01:33.388744
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for the possibility of values for method randints of class Random.

    """

    class TestRandom(Random):
        def random(self):
            return 1

    rnd = TestRandom()
    randints = rnd.randints(amount=0)
    assert randints == [], 'Amount of elements is not zero.'
    randints = rnd.randints(amount=3, a=1, b=100)
    assert randints == [1, 1, 1], 'Unexpected result.'

