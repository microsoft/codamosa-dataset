

# Generated at 2022-06-23 21:51:27.452384
# Unit test for method urandom of class Random
def test_Random_urandom():
    Random().urandom()
test_Random_urandom()

# Generated at 2022-06-23 21:51:39.000361
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.builtins import Internet
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender
    from mimesis.providers import Address
    from mimesis.providers import Education
    from mimesis.providers import Personal
    from mimesis.providers import Payment
    from mimesis.providers import Person
    from mimesis.providers import Science
    from mimesis.providers import Transport
    ru = RussiaSpecProvider()

    # Unit test for method custom_code of class Random
    def test_Random_custom_code():
        ru = RussiaSpecProvider()
        internet = Internet('ru')
        gender = Gender.FEMALE
        name = Person('ru').name(gender)

# Generated at 2022-06-23 21:51:39.537403
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()

# Generated at 2022-06-23 21:51:43.221069
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    for _ in range(100):
        a = random.uniform(1.0, 5.0)
        assert 1 <= a < 5

# Generated at 2022-06-23 21:51:44.607048
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3



# Generated at 2022-06-23 21:51:46.792496
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    random = Random()
    random.uniform(0, 1, 8)

# Generated at 2022-06-23 21:51:48.114231
# Unit test for function get_random_item
def test_get_random_item():
    from .data import Gender
    assert get_random_item(Gender) in Gender

# Generated at 2022-06-23 21:51:50.210492
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    x = rnd.uniform(0, 1, precision=0)
    assert x >= 0 and x <= 1

# Generated at 2022-06-23 21:51:52.632397
# Unit test for method randstr of class Random
def test_Random_randstr():
    tmp = random.randstr()
    assert isinstance(tmp, str)
    assert random.randstr(unique=True) != random.randstr(unique=True)


# Generated at 2022-06-23 21:51:56.948075
# Unit test for method urandom of class Random
def test_Random_urandom():
    import hashlib
    import random as random_module

    a = Random().urandom(2)
    b = os.urandom(2)
    c = random_module.Random().urandom(2)

    hash_a = hashlib.sha256(a).hexdigest()
    hash_b = hashlib.sha256(b).hexdigest()
    hash_c = hashlib.sha256(c).hexdigest()

    assert hash_a == hash_b == hash_c



# Generated at 2022-06-23 21:51:58.479975
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert r is not None
    assert isinstance(r, Random)

# Generated at 2022-06-23 21:52:07.097613
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    ma = '@@@###'
    res = Random().custom_code(ma, '@', '#')
    assert len(res) == len(ma)
    assert res[0] in string.ascii_uppercase
    assert res[1] in string.ascii_uppercase
    assert res[2] in string.ascii_uppercase
    assert res[3] in string.digits
    assert res[4] in string.digits
    assert res[5] in string.digits
    assert res[6] in string.digits


# Generated at 2022-06-23 21:52:17.342846
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    from mimesis.builtins import EnumGender
    from mimesis.enums import Gender
    from mimesis.exceptions import NonEnumerableError
    from mimesis.typing import RandomGenerator

    rg: RandomGenerator = random
    assert rg.get_random_item(EnumGender) in Gender.__members__
    assert rg.get_random_item(EnumGender) in Gender.__members__
    assert rg.get_random_item(EnumGender) in Gender.__members__
    assert rg.get_random_item(EnumGender) in Gender.__members__
    assert rg.get_random_item(None) is None
    assert rg.get_random_item([1, 2, 3]) == 1
    assert rg.get_random

# Generated at 2022-06-23 21:52:26.336288
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    try:
        r = Random()
        assert r.custom_code(mask='@###', char='@', digit='#')
        assert r.custom_code(mask='*@###', char='@', digit='#')
        assert r.custom_code(mask='*@##$', char='@', digit='#')
        assert r.custom_code(mask='@###@', char='@', digit='#')
        assert r.custom_code(mask='@#######@', char='@', digit='#')
        assert r.custom_code(mask='!@###@', char='@', digit='#')
    except ValueError:
        raise ValueError("Error: method custom_code of class Random")

# Generated at 2022-06-23 21:52:33.774134
# Unit test for method randints of class Random
def test_Random_randints():
    a = Random().randints(5, 1, 3)
    b = [1, 1, 1, 1, 1]
    c = [2, 2, 2, 2, 2]
    d = [1, 1, 1, 2, 1]
    e = [1, 1, 2, 1, 2]
    f = [1, 2, 1, 2, 1]
    g = [1, 2, 1, 2, 2]
    h = [1, 2, 2, 1, 2]
    k = [2, 1, 1, 1, 2]
    l = [2, 1, 2, 1, 1]
    m = [2, 1, 2, 2, 1]
    n = [2, 2, 1, 2, 1]
    o = [2, 2, 1, 1, 2]

# Generated at 2022-06-23 21:52:38.812275
# Unit test for method urandom of class Random
def test_Random_urandom():
    """This unit test will be run only if you run this module.

    Test that the return value is of type bytes.

    """
    assert isinstance(Random().urandom(), bytes)


if __name__ == "__main__":
    test_Random_urandom()

# Generated at 2022-06-23 21:52:41.921310
# Unit test for method randints of class Random
def test_Random_randints():
    my_rand = Random()
    assert  my_rand.randints(a=0, b=0) == [0]
    assert my_rand.randints(amount=2, a=0, b=0) == [0, 0]
    assert isinstance(my_rand.randints(amount=2), list)
    assert  len(my_rand.randints(amount=20)) == 20

# Generated at 2022-06-23 21:52:45.945526
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Tests the method uniform of class Random."""
    rnd = Random()
    assert rnd.uniform(0, 1) == random.uniform(0, 1)

# Generated at 2022-06-23 21:52:57.936024
# Unit test for method randstr of class Random
def test_Random_randstr():
    for i in range(1000):
        # Generate random string with length = 1
        # assert len(random.randstr(length=1)) == 1
        # assert random.randstr(length=1) != random.randstr(length=2)

        # Generate 1000 random strings with length = 4
        assert len(random.randstr(length=4)) == 4

        # Generate random string with length = 10
        # assert len(random.randstr(length=10)) == 10
        # assert random.randstr(length=10) != random.randstr(length=10)

        # Generate random string with length = 64
        assert len(random.randstr(length=64)) == 64

        # Generate random string with length = 128
        assert len(random.randstr(length=128)) == 128

        # Generate unique values

# Generated at 2022-06-23 21:53:00.137164
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(random.generate_string(string.ascii_letters)) == 10


# Generated at 2022-06-23 21:53:05.090974
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    assert Random().generate_string('abc', 7)
    assert Random().randints(10)
    assert Random().randstr(length=10)
    assert Random().uniform(1, 2, 3)
    Random().custom_code(mask='###-@@@')

# Generated at 2022-06-23 21:53:13.802707
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r1 = Random()
    r2 = Random()
    r3 = Random()
    assert r1.custom_code() == r2.custom_code() == r3.custom_code()
    assert r1.custom_code('#@@#') != r2.custom_code('#@@#') != r3.custom_code('#@@#')
    assert r1.custom_code('#@@#', '@', '#') != r2.custom_code('#@@#', '@', '#') != r3.custom_code('#@@#', '@', '#')
    assert r1.custom_code('#@@#', '@', '#') != r2.custom_code('#@@#', '#', '@') != r3.custom_code('#@@#', '@', '#')

# Generated at 2022-06-23 21:53:17.968349
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    # Example of class as enum object
    class Fruit(enum.Enum):
        apple = 1
        banana = 2
        cherry = 3

    assert isinstance(get_random_item(Fruit), Fruit)



# Generated at 2022-06-23 21:53:25.802957
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) >= 1
    assert len(Random().randints(amount=1)) == 1
    assert Random().randints()[0] in range(1, 101)
    assert Random().randints(amount=1, a=5, b=5)[0] == 5
    assert Random().randints(a=5, b=5)[0] == 5
    assert Random().randints(a=5, b=5)[0] in range(5, 5)
    assert Random().randints(amount=1, a=10, b=20)[0] in range(10, 20)
    assert Random().randints(a=10, b=20)[0] in range(10, 20)
    assert Random().randints(amount=10, a=10, b=20)[-1] in range(10, 20)


# Generated at 2022-06-23 21:53:33.537242
# Unit test for method randints of class Random
def test_Random_randints():
    # Testing generation of list with amount of elements
    # less or equal to zero.
    for _ in range(100):
        _amount = random.randint(-10000, -1)
        assert Random().randints(_amount) == []
        assert Random().randints(_amount, 1, 2) == []
        assert Random().randints(_amount, -2, -1) == []

    assert Random().randints(0) == []
    assert Random().randints(0, 1, 2) == []
    assert Random().randints(0, -2, -1) == []

    # Testing generation of list with different amount of
    # elements with different range of values.
    for _ in range(100):
        _amount = random.randint(1, 100)
        assert len(Random().randints(_amount, -100, 100)) == _amount

# Generated at 2022-06-23 21:53:36.112853
# Unit test for method randstr of class Random
def test_Random_randstr():
    t1 = random.randstr(length=18, unique=True)
    t2 = random.randstr(length=18, unique=False)
    return t1, t2

# Generated at 2022-06-23 21:53:43.982043
# Unit test for method randints of class Random
def test_Random_randints():
    c = Random()
    a = c.randints()
    assert isinstance(a, list), 'it must be list, but it %s' % str(type(a))
    assert len(a) == 3, 'it must be len(a) == 3, but it %s' % str(len(a))
    for i in a:
        assert isinstance(i, int), 'it must be integer, but it %s' % str(type(i))

    b = c.randints(amount=5, a=1, b=10)
    assert isinstance(b, list), 'it must be list, but it %s' % str(type(b))
    assert len(b) == 5, 'it must be len(b) == 5, but it %s' % str(len(b))

# Generated at 2022-06-23 21:53:47.145355
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for method uniform of class Random.

    :return: True if test passed.
    """
    return Random().uniform(0, 11, precision=0) == 10

# Generated at 2022-06-23 21:53:58.031881
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert code[0] in string.ascii_uppercase
    assert code[1] in string.ascii_uppercase
    assert code[2] in string.digits
    assert code[3] in string.digits

    assert type(rnd.randstr()) == str
    assert len(rnd.randstr()) == 32
    assert type(rnd.randstr(length=0)) == str
    assert len(rnd.randstr(length=12)) == 12

    assert type(rnd.randstr(unique=True)) == str
    assert len(rnd.randstr(unique=True)) == 32

# Generated at 2022-06-23 21:54:02.218370
# Unit test for method urandom of class Random
def test_Random_urandom():
    bytes_from_Random = Random().urandom(10)
    bytes_from_os = os.urandom(10)
    assert bytes_from_Random == bytes_from_os

# Generated at 2022-06-23 21:54:07.389664
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0, 1) == 0.9793452847960665, "1st try"
    assert random.uniform(0, 1) == 0.9625023759014119, "2nd try"
    assert random.uniform(0, 1) == 0.9479742029043372, "3rd try"
    assert random.uniform(0, 1, precision=6) == 0.947974, "4th try"
    pass

# Generated at 2022-06-23 21:54:09.429766
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert (10 == len(Random().generate_string('abcd')))


# Generated at 2022-06-23 21:54:13.732724
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    str_seq = string.ascii_letters + string.digits
    str1 = rnd.generate_string(str_seq = str_seq)
    assert len(str1) == 10
    str2 = rnd.generate_string(str_seq = str_seq, length = 6)
    assert len(str2) == 6


# Generated at 2022-06-23 21:54:15.927359
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert 0.0 < Random().uniform(0, 1) < 1.0

if __name__ == '__main__':
    test_Random_uniform()

# Generated at 2022-06-23 21:54:18.784062
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    class TestEnum:
        FIRST = 1
        SECOND = 2
        THIRD = 3

    assert get_random_item(TestEnum, random) in [1, 2, 3]

# Generated at 2022-06-23 21:54:22.622026
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(random.custom_code()) > 0
    assert random.custom_code(mask='@###', char='@', digit='#')
    assert random.custom_code(mask='@###', char='#', digit='@')



# Generated at 2022-06-23 21:54:28.166801
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method ``uniform`` of class ``Random``."""
    r = Random()
    assert r.uniform(10.2, 11.3) >= 10.2
    assert r.uniform(10.2, 11.3) < 11.3
    assert r.uniform(10.2, 11.3, 5) >= 10.2
    assert r.uniform(10.2, 11.3, 5) < 11.3

# Generated at 2022-06-23 21:54:34.176787
# Unit test for function get_random_item
def test_get_random_item():
    class Enum(object):
        a = 1
        b = 2
        c = 3

    assert get_random_item(Enum) in (1, 2, 3)
    assert get_random_item(Enum, random) in (1, 2, 3)
    assert get_random_item(Enum, Random()) in (1, 2, 3)

    class Enum(object):
        a = 'foo'
        b = 'bar'
        c = 'baz'

    assert get_random_item(Enum) in ('foo', 'bar', 'baz')
    assert get_random_item(Enum, random) in ('foo', 'bar', 'baz')
    assert get_random_item(Enum, Random()) in ('foo', 'bar', 'baz')

# Generated at 2022-06-23 21:54:39.499285
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    print(rnd.generate_string("1234567890") + '\n')
    print(rnd.generate_string("1234567890") + '\n')
    print(rnd.generate_string("1234", length=20))


# Generated at 2022-06-23 21:54:43.623795
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string('@', length=0)) == 0
    assert len(Random().generate_string('@', length=1)) == 1
    assert len(Random().generate_string('@', length=5)) == 5



# Generated at 2022-06-23 21:54:44.645767
# Unit test for method randints of class Random
def test_Random_randints():
    print(Random().randints(5))


# Generated at 2022-06-23 21:54:52.432939
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Test 1
    assert len(random.randstr(unique=False)) in range(16, 128)
    assert len(random.randstr(unique=True)) == 32
    # Test 2
    assert len(random.randstr(unique=False, length=32)) == 32
    # Test 3
    random.seed(123)
    assert random.randstr(unique=False) == 'S0BcQ2KZoG8eoU4gCk6ixvKzXE4p'
    # Test 4
    assert len(random.randstr(unique=False, length=100)) == 100
    # Test 5
    random.seed(123)

# Generated at 2022-06-23 21:54:58.928079
# Unit test for method randints of class Random
def test_Random_randints():
    amount = random_module.randint(1, 10)
    a = random_module.randint(-10, 0)
    b = random_module.randint(1, 10)

    result_1 = random.randints(amount=amount, a=a, b=b)
    result_2 = Random().randints(amount=amount, a=a, b=b)
    result_3 = Random(100).randints(amount=amount, a=a, b=b)

    assert result_1 == result_2
    assert result_2 == result_3

# Generated at 2022-06-23 21:55:02.146696
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for method ``urandom()`` of class ``Random()``."""
    random_object = Random()
    assert isinstance(random_object.urandom(50), bytes)



# Generated at 2022-06-23 21:55:11.606634
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints(100)) == 100
    assert all([random.randints(4)[i] < 100 for i in range(4)])
    assert all([random.randints(4)[i] > 1 for i in range(4)])
    assert random.randints(a=0, b=5)[0] < 5
    assert random.randints(a=0, b=5)[0] > 0
    assert all([random.randints(3, a=-10, b=-1)[i] < -1 for i in range(3)])
    assert all([random.randints(3, a=-10, b=-1)[i] > -10 for i in range(3)])


# Generated at 2022-06-23 21:55:15.211851
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(4, 1, 5) == [4, 4, 4, 3]
    assert Random().randints(4, 1, 5) != [4, 4, 4, 3]

# Generated at 2022-06-23 21:55:24.001123
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random(12345)
    rnd.custom_code('##-###', char='@', digit='#')
    # 'SZ-SZW'

    rnd.custom_code('##-###', char='#', digit='@')
    # '06-06A'

    rnd.custom_code('##-###')
    # '81-810'

    rnd.custom_code(length=10, char='@')
    # '@@@@MZWIJ@U@'

    rnd.custom_code(char='Y')
    # 'YYYY'

    rnd.custom_code(char='%%', digit='%%')
    # '%%%%%%%%%'

    rnd.custom_code(char='@', digit='@')
    # ''

    rnd.custom_code

# Generated at 2022-06-23 21:55:25.015677
# Unit test for method urandom of class Random
def test_Random_urandom():
    random.urandom(12)

# Generated at 2022-06-23 21:55:26.339729
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(128), bytes)



# Generated at 2022-06-23 21:55:29.169862
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(unique=True), str)



# Generated at 2022-06-23 21:55:30.883816
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    result = r.generate_string('asdfghjk', 10)
    assert type(result) == str
    assert len(result) == 10


# Generated at 2022-06-23 21:55:32.803534
# Unit test for constructor of class Random
def test_Random():
    cls_random = Random()
    assert isinstance(cls_random, random_module.Random)


# Generated at 2022-06-23 21:55:38.567076
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Test raises
    _Random = Random()
    _bad_size = 'adf'
    try:
        bytes_ = _Random.urandom(size=_bad_size)
    except TypeError:
        assert True
    else:
        assert False

    # Test returns
    _good_size = 6
    _bytes = _Random.urandom(size=_good_size)
    assert len(_bytes) == _good_size



# Generated at 2022-06-23 21:55:44.625115
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test."""
    rnd = Random()

    assert rnd.uniform(3, 7) >= 3
    assert rnd.uniform(3, 7) <= 7
    assert rnd.uniform(0, 1, precision=6) <= 1
    assert rnd.uniform(0, 1, 5) >= 0

# Generated at 2022-06-23 21:55:49.606164
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender

    item = get_random_item(Gender)
    assert item in Gender

    for _ in range(10):
        item = get_random_item(Gender)
        assert item in Gender



# Generated at 2022-06-23 21:55:51.609241
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints(amount=2, a=1, b=10)) == 2

# Generated at 2022-06-23 21:55:54.562696
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    rnd = Random()
    assert 0.123 <= rnd.uniform(0.12, 0.13) <= 0.124



# Generated at 2022-06-23 21:56:02.106716
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    # check generation of list of integers
    assert isinstance(random.randints(3), list)
    # check generation of integer
    assert isinstance(random.randint(1, 2), int)
    # check generation of float
    assert isinstance(random.uniform(0, 2), float)
    # check generation of string
    assert isinstance(random.generate_string('abc'), str)
    # check generation of custom code
    assert isinstance(random.custom_code(mask='@###'), str)
    # check generation of random string
    assert isinstance(random.randstr(length=10), str)

# Generated at 2022-06-23 21:56:04.310616
# Unit test for method randstr of class Random
def test_Random_randstr():
    s = random.randstr(length=16)
    assert len(s) == 16

# Generated at 2022-06-23 21:56:11.231636
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(list(range(10))), int)
    assert isinstance(get_random_item(tuple(map(chr, list(range(97, 123))))), str)
    rnd = random_module.Random()
    assert isinstance(get_random_item(range(10), rnd), int)
    assert isinstance(get_random_item(tuple(map(chr, range(97, 123))), rnd), str)

# Generated at 2022-06-23 21:56:12.532948
# Unit test for function get_random_item
def test_get_random_item():
    result = get_random_item(enum=random)
    assert result



# Generated at 2022-06-23 21:56:13.466066
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    assert random


# Generated at 2022-06-23 21:56:22.715622
# Unit test for method randints of class Random
def test_Random_randints():
    for _ in range(5):
        result = random.randints(20)
        assert isinstance(result, list)
        assert len(result) == 20
        assert all(isinstance(i, int) for i in result)
        assert min(result) >= 1
        assert max(result) <= 100

    for _ in range(5):
        result = random.randints(20, a=100, b=200)
        assert isinstance(result, list)
        assert len(result) == 20
        assert all(isinstance(i, int) for i in result)
        assert min(result) >= 100
        assert max(result) <= 200

    try:
        random.randints(0)
    except ValueError:
        pass
    else:
        assert False, 'Amount out of range.'



# Generated at 2022-06-23 21:56:31.276813
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Тестирование функции генерации кода на основе шаблона
    mask = '@###'
    char = '@'
    digit = '#'
    random_module_ = random_module.Random()

    # Создание нового объекта класса Random
    _random = Random()
    for _ in range(100):
        _code = _random.custom_code(mask, char, digit)

        if char != '@' and char != '#':
            raise ValueError('Char must be @ or #')

# Generated at 2022-06-23 21:56:34.888851
# Unit test for function get_random_item
def test_get_random_item():
    """Test the function get_random_item."""
    class Type(int, enum.Enum):
        one = 1
        two = 2
        three = 3

    random_item = get_random_item(Type)
    assert isinstance(random_item, Type)

# Generated at 2022-06-23 21:56:41.730940
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()

    # Тестирование метода с параметром unique=False
    assert len(rnd.randstr()) >= 16
    assert len(rnd.randstr()) <= 128
    assert len(rnd.randstr(length=10)) == 10

    # Тестирование метода с параметром unique=True
    assert isinstance(rnd.randstr(unique=True), str)
    assert len(rnd.randstr(unique=True)) == 32

    # Тестирование со значением length, равн

# Generated at 2022-06-23 21:56:45.115460
# Unit test for method randints of class Random
def test_Random_randints():
    a, b, c = random.randints(3, 1, 5)
    assert a != b != c
    assert a != c != b
    assert b != a != c

# Generated at 2022-06-23 21:56:46.129006
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom()

# Generated at 2022-06-23 21:56:49.869692
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(random.provider('en'))
    assert get_random_item(random.provider('ru'))
    assert get_random_item((1, 2, 3))
    assert get_random_item(('a', 'b', 'c'))

# Generated at 2022-06-23 21:56:50.674512
# Unit test for function get_random_item
def test_get_random_item():
    from .enums import Gender

    get_random_item(Gender)

# Generated at 2022-06-23 21:57:01.220337
# Unit test for function get_random_item
def test_get_random_item():
    import os
    import random
    import unittest
    from enum import Enum

    from mimesis.providers.base import BaseEnumProvider
    from mimesis.providers.filesystem import FileSystem
    from mimesis.providers.generic import Generic

    fs = FileSystem()
    g = Generic()

    class EnumTest(Enum):
        A = 1
        B = 2
        C = 3
        D = 4

    et = EnumTest

    class CustomProvider(BaseEnumProvider):

        class Meta(BaseEnumProvider.Meta):
            enum = et
            qualname = 'EnumTest'

    provider = CustomProvider()
    self = provider

    class BaseTestCase(unittest.TestCase):

        def setUp(self):
            self.rnd = random.Random()
           

# Generated at 2022-06-23 21:57:09.732499
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    r.seed(0)

    res = r.randints(amount=5)
    assert res == [17, 76, 15, 84, 49]

    res = r.randints(amount=10)
    assert res == [19, 79, 79, 47, 44, 69, 33, 4, 10, 77]

    res = r.randints(amount=10, a=0, b=10)
    assert res == [2, 6, 2, 0, 9, 5, 2, 4, 9, 5]

    res = r.randints(amount=100, a=-100, b=100)
    assert len(res) == 100

    # Even and positive
    second = [n for n in res if not n % 2 and n >= 0]
    assert len(second) == len(res) // 2



# Generated at 2022-06-23 21:57:11.640740
# Unit test for function get_random_item
def test_get_random_item():
    """Test for function get_random_item()."""
    assert callable(get_random_item)

# Generated at 2022-06-23 21:57:15.808299
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    string_test = random.generate_string('abcd', 10)
    assert len(string_test) == 10
    assert isinstance(string_test, str)
    assert string_test != 'abcd'


# Generated at 2022-06-23 21:57:18.050059
# Unit test for method uniform of class Random
def test_Random_uniform():
    import mimesis
    assert len(set(random.uniform(2.0, 2.0) for _ in range(1000))) == 1

# Generated at 2022-06-23 21:57:27.673598
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random()."""
    assert Random().custom_code('####', '@') == '####'
    assert Random().custom_code('@@##', '@') == '@@##'
    assert Random().custom_code('@##') == '@##'
    assert Random().custom_code('##@@') == '##@@'
    assert Random().custom_code('@@@') == '@@@'
    assert Random().custom_code('@@@', 'a') == '@@@'
    assert Random().custom_code('@@@', '@', '@') == '@@@'
    assert Random().custom_code('@@@', '@', '#') == '@@@'
    assert Random().custom_code('@##', '#') == '@##'

# Generated at 2022-06-23 21:57:33.268476
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    assert Random().randstr(unique=True) == Random().randstr(unique=True)
    assert len(Random().randstr(unique=True)) == 32
    assert len(Random().randstr()) == 16
    assert len(Random().randstr(length=3)) == 3
    assert len(Random().randstr(length=500)) == 500

# Generated at 2022-06-23 21:57:35.467479
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert 0.1 <= rnd.uniform(0.1, 0.6) <= 0.6
    assert 10.1 <= rnd.uniform(0.1, 0.6, precision=2) <= 10.6

# Generated at 2022-06-23 21:57:47.019129
# Unit test for method urandom of class Random
def test_Random_urandom():
    class Shuffle:
        def __init__(self, iterable):
            self.iterable = list(iterable)
            self.len = len(iterable)

        def __call__(self):
            random.shuffle(self.iterable)
            return self.iterable

    class Sample:
        def __init__(self, iterable):
            self.iterable = list(iterable)
            self.len = len(iterable)

        def __call__(self):
            return random.sample(self.iterable, self.len)

    class Get_Random_Item:
        def __init__(self, enum):
            self.enum = enum

        def __call__(self):
            return get_random_item(self.enum)


# Generated at 2022-06-23 21:57:48.615021
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random.urandom(), bytes)


# Generated at 2022-06-23 21:57:50.125232
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints."""
    assert len(Random().randints()) == 3

# Generated at 2022-06-23 21:57:50.773465
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom() == os.urandom()

# Generated at 2022-06-23 21:57:58.896478
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Init instances
    rs1 = random.randstr()
    rs2 = random.randstr()

    # Check 1: Function randstr returns random lowered string.
    # Check 2: Function randstr returns random uppered string.
    assert rs1.islower() and rs2.isupper() or rs1.isupper() and rs2.islower()

    # Check 3: Function randstr returns random length string between
    # (min=16, max=128).
    assert len(rs1) >= 16 and len(rs2) <= 128 or len(rs1) <= 128 and len(rs2) >= 16

# Generated at 2022-06-23 21:58:01.780527
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    value = random.uniform(0.72, 0.84, 4)
    assert 0.72 <= value <= 0.84

# Generated at 2022-06-23 21:58:06.059110
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    # Setup
    rnd = Random()

    # Exercise
    result = rnd.uniform(1.0, 2.0)

    # Verify
    assert result is not None
    assert result >= 1.0 and result <= 2.0



# Generated at 2022-06-23 21:58:13.654458
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 5
    for i in code:
        assert i.isdigit()

    code = rnd.custom_code('@')
    assert len(code) == 1
    assert code.isalpha()
    assert code.isupper()

    code = rnd.custom_code('@@')
    assert len(code) == 2
    for i in code:
        assert i.isalpha()
        assert i.isupper()

    code = rnd.custom_code('###')
    assert len(code) == 3
    for i in code:
        assert i.isdigit()

    code = rnd.custom_code('@###')
    assert len(code) == 5
    assert code[0].isalpha()

# Generated at 2022-06-23 21:58:15.265856
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random().urandom(), bytes)

# Generated at 2022-06-23 21:58:17.472121
# Unit test for method uniform of class Random
def test_Random_uniform():
    random_num = Random().uniform(1, 100)
    print(str(random_num))
    assert isinstance(random_num, float)

# Generated at 2022-06-23 21:58:22.853921
# Unit test for function get_random_item
def test_get_random_item():
    class Enum(object):
        A = 1
        B = 2
        C = 3

    assert isinstance(Enum, type)

    enum = Enum()
    assert isinstance(enum, Enum)
    assert isinstance(get_random_item(enum), int)
    assert isinstance(get_random_item(enum, rnd=Random()), int)

# Generated at 2022-06-23 21:58:25.612360
# Unit test for method urandom of class Random
def test_Random_urandom():
    print('Method: urandom.')
    random.urandom(16)
    print('Test passed.')



# Generated at 2022-06-23 21:58:27.966694
# Unit test for constructor of class Random
def test_Random():
  rnd = Random()
  assert isinstance(rnd, Random) and isinstance(rnd, random_module.Random)


# Generated at 2022-06-23 21:58:32.615231
# Unit test for method uniform of class Random
def test_Random_uniform():
    n = random.uniform(0, 1)
    print("random.uniform(0, 1) = %f" % n)
    n = random.uniform(0, 1, 2)
    print("random.uniform(0, 1, 2) = %.2f" % n)

# Generated at 2022-06-23 21:58:37.137513
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    import enum

    class MyEnum(enum.Enum):
        """Example of enum class."""

        a = 1
        b = 2
        c = 3

    item = get_random_item(MyEnum)
    assert item in (MyEnum.a, MyEnum.b, MyEnum.c)

# Generated at 2022-06-23 21:58:39.362504
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random_string = Random().generate_string(str_seq='abc123')
    assert isinstance(random_string, str)


# Generated at 2022-06-23 21:58:45.137836
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender

    # Generate random integer
    rnd = get_random_item(Gender)
    assert isinstance(rnd, Gender)

    # Generate random integer using custom Random-object
    rnd = get_random_item(Gender, random)
    assert isinstance(rnd, Gender)

# Generated at 2022-06-23 21:58:47.014209
# Unit test for method randstr of class Random
def test_Random_randstr():
    for i in range(10):
        result = random.randstr(False, 10)
        assert len(result) == 10

# Generated at 2022-06-23 21:58:47.822280
# Unit test for method randstr of class Random
def test_Random_randstr():
    a = random.randstr()
    print(a)
    a = random.randstr()
    print(a)

# Generated at 2022-06-23 21:58:57.791477
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    from mimesis.exceptions import NonEnumerableError

    class TestClass:
        pass

    rnd = Random()

    # Test with non-enumerable object
    try:
        rnd.generate_string(TestClass())
    except NonEnumerableError:
        pass
    else:
        raise AssertionError('The method generate_string does not handle '
                             'non-enumerable objects.')

    # Test with wrong type of length
    try:
        rnd.generate_string('', length='a')
    except TypeError:
        pass
    else:
        raise AssertionError('The method generate_string does not handle '
                             'wrong type of length.')

    # Test with negative length

# Generated at 2022-06-23 21:59:01.674555
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    _string = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    for _ in range(100):
        assert random.generate_string(_string, 10)


# Generated at 2022-06-23 21:59:05.096935
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.builtins import EnumField

    class Color(EnumField):
        RED = 'red'
        BLUE = 'blue'
        YELLOW = 'yellow'
        WHITE = 'white'

    assert get_random_item(Color) in Color()

# Generated at 2022-06-23 21:59:09.513195
# Unit test for method uniform of class Random
def test_Random_uniform():
    for _ in range(1000):
        assert 0.25 <= random.uniform(0.25, 0.26, precision=2) < 0.26


if __name__ == '__main__':
    # Just run test function
    test_Random_uniform()

# Generated at 2022-06-23 21:59:13.402075
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    print("Test for method generate_string of class Random")
    _string = random.generate_string(string.ascii_letters)
    assert len(_string) <= 10, "Generated string is too long. \
                                It length is greater than 10"
    assert len(_string) >= 1, "Generated string is too short. \
                               It length is less than 10"


# Generated at 2022-06-23 21:59:17.034026
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr() of class Random."""
    list_of_values = [Random().randstr() for _ in range(50)]
    print(len(list_of_values))
    assert len(list_of_values) == 50


test_Random_randstr()

# Generated at 2022-06-23 21:59:19.441660
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for urandom of class Random."""
    _random = Random()
    _bytes = _random.urandom(32)
    assert isinstance(_bytes, bytes)



# Generated at 2022-06-23 21:59:22.964809
# Unit test for function get_random_item
def test_get_random_item():
    """Test function get_random_item."""
    # TODO: add more test cases
    enum_a = [1, 2, 3]
    assert isinstance(get_random_item(enum_a), int)
    assert get_random_item(enum_a) in enum_a

# Generated at 2022-06-23 21:59:31.435681
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    rnd.randstr(length=4)
    rnd.generate_string('abcdef', 5)
    rnd.randstr(unique=True)
    rnd.choice(range(10))
    rnd.custom_code()
    rnd.randints(4)
    rnd.urandom(4)
    assert rnd.uniform(1, 5)
    assert rnd.uniform(1, 5, precision=5)

# Generated at 2022-06-23 21:59:32.692933
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(), bytes)


# Generated at 2022-06-23 21:59:34.597122
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = random.Random()
    assert rnd.custom_code("@###") in ["X500", "F123", "H098", "S123", "E234"]

# Generated at 2022-06-23 21:59:39.553303
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    rnd.randint(0, 1000)
    rnd.randints(3, 0, 1000)
    rnd.generate_string('sdfsdfsdfsdfsdfsdfsdfsdfsdfdfsdf')
    rnd.custom_code()
    rnd.uniform(0, 1)
    rnd.randstr()

# Generated at 2022-06-23 21:59:40.286687
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random().urandom(15)) == 15

# Generated at 2022-06-23 21:59:45.705277
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Input
    inp = '@###-###-##-#'
    # Expected
    exp = 'DSB1-623-D2-T'

    # Result
    res = random.custom_code(inp)

    # Check
    assert res == exp

# Generated at 2022-06-23 21:59:50.321141
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    str_seq = 'aeflkmslkdsjf'
    length = 4
    result = random.generate_string(str_seq, length)
    assert len(result) == length

    str_seq = '0123456789'
    length = 5
    result = random.generate_string(str_seq, length)
    assert len(result) == length



# Generated at 2022-06-23 21:59:59.475446
# Unit test for method randints of class Random
def test_Random_randints():
    seed = random.randint(1, 100)
    _random = random.Random(seed)
    assert _random.randints() == [46, 67, 41]
    assert _random.randints(2) == [50, 17]
    assert _random.randints(a=25, b=110) == [93, 45, 93]
    _random = random.Random(seed)
    assert _random.randints(a=25, b=110) == [93, 45, 93]
    _random = random.Random(seed)
    assert _random.randints(a=25, b=110) == [93, 45, 93]
    _random = random.Random(seed)
    assert _random.randints(a=25, b=110) == [93, 45, 93]

# Generated at 2022-06-23 22:00:00.843693
# Unit test for method randints of class Random
def test_Random_randints():
    for i in range(3):
        print(random.randints(5))



# Generated at 2022-06-23 22:00:03.343411
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)

# Generated at 2022-06-23 22:00:07.534089
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    assert random.uniform(0, 2, 10) > 0 and random.uniform(0, 2, 10) < 2
    assert random.uniform(0, 2, 10) == round(random.uniform(0, 2, 10), 10)



# Generated at 2022-06-23 22:00:13.020679
# Unit test for function get_random_item
def test_get_random_item():
    from .numbers import Gender
    from .text import Text
    from .internet import Internet
    from .datetime import Datetime
    from .business import Business
    from .science import Science
    from .personal import Personal
    from .food import Food
    from .telephony import Telephony
    from .address import Address
    from .system import System
    from .file import File
    from .other import _hash_funcs, hashlib
    from .codec import Codec

    assert get_random_item(Gender) in list(Gender)
    assert get_random_item(Text) in list(Text)
    assert get_random_item(Internet) in list(Internet)
    assert get_random_item(Datetime) in list(Datetime)
    assert get_random_item(Business) in list(Business)
    assert get_random_

# Generated at 2022-06-23 22:00:15.853073
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import OperatingSystem

    random_item = get_random_item(OperatingSystem)
    assert isinstance(random_item, OperatingSystem)

# Generated at 2022-06-23 22:00:17.421691
# Unit test for constructor of class Random
def test_Random():
    assert random_module != Random()
    assert random_module != random

# Generated at 2022-06-23 22:00:18.774437
# Unit test for function get_random_item
def test_get_random_item():
    _enum = get_random_item(enum=random, rnd=random)

# Generated at 2022-06-23 22:00:21.668629
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()

    assert (rnd.uniform(0.1, 0.9) >= 0.1)
    assert (rnd.uniform(0.1, 0.9) <= 0.9)

# Generated at 2022-06-23 22:00:23.731950
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    custom_string = Random().generate_string('teststring', 3)
    assert len(custom_string) == 3
    assert isinstance(custom_string, str)


# Generated at 2022-06-23 22:00:27.719979
# Unit test for function get_random_item
def test_get_random_item():
    import pytest
    from mimesis.enums import Gender, PersonTitle

    rnd = Random()
    assert isinstance(get_random_item(Gender), Gender)
    assert isinstance(get_random_item(PersonTitle, rnd), PersonTitle)

    with pytest.raises(TypeError):
        get_random_item(PersonTitle)

    with pytest.raises(TypeError):
        get_random_item(PersonTitle, 2)

# Generated at 2022-06-23 22:00:34.540295
# Unit test for method uniform of class Random
def test_Random_uniform():
	random_object = Random()
	print(random_object.uniform(0.0001, 0.0001, 2))
	print(random_object.uniform(0.0001, 0.0001, 4))
	print(random_object.uniform(-2, 3, 3))
	print(random_object.uniform(-3, 3, 3))
	print(random_object.uniform(-3, 3, 2))


# Generated at 2022-06-23 22:00:43.262553
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1.0, 1.2) < 1.2
    assert random.uniform(1.0, 1.2) > 1.0
    assert random.uniform(1.0, 1.2) != 1.0
    assert random.uniform(1.0, 1.2) != 1.2
    assert random.uniform(1.0, 1.2, precision=3) < 1.2
    assert random.uniform(1.0, 1.2, precision=3) > 1.0
    assert random.uniform(1.0, 1.2, precision=3) != 1.0
    assert random.uniform(1.0, 1.2, precision=3) != 1.2

# Generated at 2022-06-23 22:00:46.779226
# Unit test for method randints of class Random
def test_Random_randints():
    t_list = [random.randints(a=1, b=11) for _ in range(10)]
    for a in t_list:
        assert all(c in [i for i in range(1, 11)] for c in a)


# Generated at 2022-06-23 22:00:51.756303
# Unit test for method generate_string of class Random
def test_Random_generate_string():

    # Arrange
    random_ = Random()
    seq = [string.ascii_letters, string.digits]
    length = 10

    # Act
    for s in seq:
        res = random_.generate_string(s, length)
        assert len(res) == length
        for c in res:
            assert str(c) in s



# Generated at 2022-06-23 22:00:56.986639
# Unit test for method uniform of class Random
def test_Random_uniform():
    _random = Random()
    _random.seed(123456)
    nums = [int(_random.uniform(1, 100)) for _ in range(10)]
    assert nums == [81, 53, 42, 94, 71, 65, 46, 62, 48, 80]

# Generated at 2022-06-23 22:01:05.272122
# Unit test for constructor of class Random
def test_Random():
    """Test ``Random()`` class.

    All 25 test cases (for all methods) are here.

    """
    rnd = Random()

    # <Test 1>
    assert rnd.randstr()
    assert isinstance(rnd.randstr(), str)
    assert len(rnd.randstr()) >= 16 and len(rnd.randstr()) <= 128

    assert rnd.randstr(False)
    assert isinstance(rnd.randstr(False), str)
    assert len(rnd.randstr(False)) >= 16 and len(rnd.randstr(False)) <= 128
    length = rnd.randint(10, 20)
    assert rnd.randstr(False, length)
    assert isinstance(rnd.randstr(False, 20), str)

# Generated at 2022-06-23 22:01:06.705949
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), random_module.Random) is True

# Generated at 2022-06-23 22:01:11.502490
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    random_item = get_random_item(Gender, Random())
    assert random_item == Gender.MALE or Gender.FEMALE
    random_item = get_random_item(Gender, random)
    assert random_item == Gender.MALE or Gender.FEMALE
    random_item = get_random_item(Gender)
    assert random_item == Gender.MALE or Gender.FEMALE

# Generated at 2022-06-23 22:01:21.679414
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    NUMBER_ITERATIONS = 1_000_000
    results = []

    # Test 1
    for _ in range(NUMBER_ITERATIONS):
        results.append(r.custom_code('####'))

    assert len(set(results)) == NUMBER_ITERATIONS

    # Test 2
    results.clear()
    for _ in range(NUMBER_ITERATIONS):
        results.append(r.custom_code('###-##'))

    assert len(set(results)) == NUMBER_ITERATIONS

    # Test 3
    results.clear()
    for _ in range(NUMBER_ITERATIONS):
        results.append(r.custom_code('###@##'))

    assert len(set(results)) == NUMBER_ITERATIONS

    # Test 4

# Generated at 2022-06-23 22:01:23.076621
# Unit test for constructor of class Random
def test_Random():
    """Create instances of class Random."""
    Random()
    Random(0)

# Generated at 2022-06-23 22:01:31.761070
# Unit test for constructor of class Random
def test_Random():
    assert Random()
    assert Random().random()
    assert Random().randint(2, 90)
    assert Random().randitem(['a', 'b', 'c'])
    assert Random().choice(['a', 'b', 'c'])
    assert Random().choice(['a', 'b', 'c'])
    assert Random().randstr(False, 8)
    assert Random().randstr(True)
    assert Random().uniform(0.1, 1.1)
    assert Random().uniform(0.1, 1.1, 14)
    assert Random().randints(amount=2, a=1, b=2)