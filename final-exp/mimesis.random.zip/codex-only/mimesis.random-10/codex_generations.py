

# Generated at 2022-06-23 21:51:32.333107
# Unit test for method uniform of class Random
def test_Random_uniform():
    for _ in range(100):
        a = random.uniform(0.1234567, 9.87654321)
        assert a >= 0.1234567 and a <= 9.87654321

# Generated at 2022-06-23 21:51:35.599824
# Unit test for constructor of class Random
def test_Random():
    """Perform unit test to constructor of class Random."""
    r = Random(2)
    assert r.random() == r.random()
    r = Random(Random(2).randint())
    Random(r.random()).random()

# Generated at 2022-06-23 21:51:41.854828
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints of class Random."""
    assert len(random.randints()) == 3
    assert len(random.randints(amount=2)) == 2
    assert len(random.randints(amount=1)) == 1
    assert len(random.randints(amount=0)) == 0
    assert 100 >= random.randints(a=100, b=100)[0] >= 100
    assert 100 >= random.randints(a=100)[0] >= 1
    assert 100 >= random.randints()[0] >= 1



# Generated at 2022-06-23 21:51:43.922346
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(10)

# Generated at 2022-06-23 21:51:49.527916
# Unit test for method uniform of class Random
def test_Random_uniform():
    # test uniform method
    for i in range(1000):
        rnd = random.uniform(1, 10)
        assert 1 <= rnd < 10, 'uniform(1, 10) != 1 <= x < 10'

    for i in range(1000):
        rnd = random.uniform(1, 10, 0)
        assert 1 <= rnd <= 10, 'uniform(1, 10) != 1 <= x <= 10'



# Generated at 2022-06-23 21:51:50.580379
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender

    assert get_random_item(Gender) in Gender

# Generated at 2022-06-23 21:51:51.823245
# Unit test for method uniform of class Random
def test_Random_uniform():
    value = random.uniform(1.0, 1.1, precision=4)
    assert value <= 1.1 and value >= 1.0

# Generated at 2022-06-23 21:51:54.592253
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test the method randstr of class Random."""
    rnd = Random()
    value = rnd.randstr()
    assert isinstance(value, str)
    assert len(value) >= 16

# Generated at 2022-06-23 21:51:56.299525
# Unit test for method urandom of class Random
def test_Random_urandom():
    _random = Random()
    assert _random.urandom(1) == os.urandom(1)


# Generated at 2022-06-23 21:52:02.744559
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert len(rnd.custom_code(mask='@@###')) == len('AA111')
    assert len(rnd.custom_code(mask='@@###@@')) == len('AA111AA')
    assert len(rnd.custom_code(mask='@###@')) == len('A111A')
    assert len(rnd.custom_code(mask='@@12')) == len('AA12')

# Generated at 2022-06-23 21:52:03.825946
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)

# Generated at 2022-06-23 21:52:07.398762
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum

    class Color(Enum):
        RED = 1
        BLUE = 2
        GREEN = 3

    assert get_random_item(Color) in list(Color)



# Generated at 2022-06-23 21:52:08.373741
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)



# Generated at 2022-06-23 21:52:11.617098
# Unit test for constructor of class Random
def test_Random():
    r: Random = Random()

    assert isinstance(r, Random) and isinstance(r, random_module.Random)



# Generated at 2022-06-23 21:52:14.791877
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    rnd = Random()
    lst = rnd.randints(amount=10, a=3, b=15)
    is_correct = all([3 <= x <= 14 for x in lst])
    assert is_correct



# Generated at 2022-06-23 21:52:17.633313
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert rnd.custom_code('@###@###@') == rnd.custom_code('@###@###@')
    assert rnd.generate_string('abcd1234') == rnd.generate_string('abcd1234')

# Generated at 2022-06-23 21:52:22.212036
# Unit test for method urandom of class Random
def test_Random_urandom():
    count = 10000

    # If first 10 bytes of os.urandom() is equal to
    # the first 10 bytes from random.urandom(),
    # then everything is ok.
    assert not all(
        os.urandom(10) == random.urandom(10)
        for _ in range(count)
    )

# Generated at 2022-06-23 21:52:24.110460
# Unit test for method urandom of class Random
def test_Random_urandom():
    _random = Random()
    assert _random.urandom(5) == os.urandom(5)



# Generated at 2022-06-23 21:52:29.752452
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    MIN = 0.
    MAX = 1.
    NUM = 100
    PRECISION = 2
    assert 0.01 <= random.uniform(MIN, MAX, PRECISION) <= 0.99
    lst_uniform = [random.uniform(MIN, MAX, PRECISION) for _ in range(NUM)]
    for i in lst_uniform:
        assert 0.01 <= i <= 0.99
    assert len(lst_uniform) == NUM

# Generated at 2022-06-23 21:52:32.662625
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints()."""
    assert Random().randints(1, 1, 10) == [8]
    assert Random().randints(2, 1, 10) == [8, 7]
    assert Random().randints(3, 1, 10) == [8, 7, 4]

# Generated at 2022-06-23 21:52:38.813065
# Unit test for method randints of class Random
def test_Random_randints():
    number_of_elements = random.randint(10, 100)
    result = random.randints(number_of_elements, -100, 100)
    assert type(result) is list
    assert len(result) == number_of_elements
    assert set(result).issubset(range(-100, 100)) and len(set(result)) == len(result)

# Generated at 2022-06-23 21:52:46.328188
# Unit test for method randstr of class Random
def test_Random_randstr():
    r1 = random.randstr()
    r2 = random.randstr()
    assert len(r1) == len(r2)
    assert r1 != r2

    r1 = random.randstr(unique=True)
    r2 = random.randstr(unique=True)
    assert len(r1) == len(r2)
    assert r1 != r2

    r1 = random.randstr(length=15)
    assert len(r1) == 15

    r1 = random.randstr(length=256)
    assert len(r1) == 256

    r1 = random.randstr(length=256, unique=True)
    assert len(r1) == 256

    r1 = random.randstr(length=15, unique=True)
    assert len(r1) == 32

# Generated at 2022-06-23 21:52:51.170704
# Unit test for method uniform of class Random
def test_Random_uniform():
    UPPER = 0.7
    LOWER = 0.7

    assert UPPER > LOWER
    number = random.uniform(LOWER, UPPER)
    assert isinstance(number, float)
    assert number >= LOWER
    assert number < UPPER

# Generated at 2022-06-23 21:52:58.882476
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    test_cases = [
        {
            'unique': False,
            'length': None
        },
        {
            'unique': False,
            'length': 128
        },
        {
            'unique': True,
            'length': None
        },
        {
            'unique': True,
            'length': 128
        }
    ]

    for t in test_cases:
        assert len(rnd.randstr(**t)) == t.get('length')



# Generated at 2022-06-23 21:53:01.152356
# Unit test for method urandom of class Random
def test_Random_urandom():
    result = random.urandom(10)
    assert len(result) == 10



# Generated at 2022-06-23 21:53:06.090856
# Unit test for method randstr of class Random
def test_Random_randstr():
    ss = random_module.randstr()
    assert len(ss) < 128, ValueError("Less than 128")
    assert len(ss) > 16, ValueError("More than 16")

    uq = random_module.randstr(unique=True)
    assert len(uq) == 32, ValueError("Not equal 32")

# Generated at 2022-06-23 21:53:11.440596
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    rnd.seed(1)
    assert rnd.custom_code() == 'Q2Q0'
    assert rnd.randints(5, -2, 3) == [2, -1, 1, 0, 0]
    assert rnd.randints(1, -2, 3) == [0]
    assert rnd.uniform(2.44, 85.83) in [3.81, 3.82]

# Generated at 2022-06-23 21:53:12.136391
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random().urandom(10)) == 10

# Generated at 2022-06-23 21:53:21.515433
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # If a user entered a string of symbols that are not letters or digits
    # the exception ValueError will be thrown.
    random.generate_string('%')
    # The length of the resulting string should be 10.
    random.generate_string('@!')
    # Quick test.
    random.generate_string('ac')
    # If the user enters a length of 0 or less than 0
    # the exception ValueError will be thrown.
    random.generate_string('abc', 0)
    random.generate_string('abc', -2)

# Generated at 2022-06-23 21:53:25.618339
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    res = rnd.uniform(1, 10)
    assert 1 <= res <= 10

    res = rnd.uniform(1.15, 10.25)
    assert 1.15 <= res <= 10.25

    res = rnd.uniform(-10.25, -1.15)
    assert -10.25 <= res <= -1.15

    res = rnd.uniform(-10.25, -1.15, 3)
    assert -10.25 <= res <= -1.15

    res = rnd.uniform(-10.25, -1.15, precision=-3)
    assert -10.25 <= res <= -1.15

# Generated at 2022-06-23 21:53:27.787661
# Unit test for method uniform of class Random
def test_Random_uniform():
    rand = Random()
    assert rand.uniform(a = 1, b = 12) in list(range(1, 12))


# Generated at 2022-06-23 21:53:29.343435
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender

    assert get_random_item(Gender) in Gender.__members__.values()

# Generated at 2022-06-23 21:53:31.647918
# Unit test for method randstr of class Random
def test_Random_randstr():
    x = random.randstr(unique=False, length=5)
    assert isinstance(x, str)
    assert len(x) == 5

# Generated at 2022-06-23 21:53:34.034485
# Unit test for method uniform of class Random
def test_Random_uniform():
    result = random.uniform(5.5, 7.5)
    assert result >= 5.5 and result < 7.5

# Generated at 2022-06-23 21:53:37.681424
# Unit test for method urandom of class Random
def test_Random_urandom():
    random1 = Random()
    random2 = Random()
    assert random1.urandom() == random_module.urandom()
    assert random2.urandom() == random_module.urandom()
    assert random1.urandom() != random2.urandom()


# Generated at 2022-06-23 21:53:38.614830
# Unit test for method urandom of class Random
def test_Random_urandom():
    rnd = Random()
    assert isinstance(rnd.urandom(), bytes)

# Generated at 2022-06-23 21:53:44.695798
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test functionality for custom code."""
    assert Random().custom_code() == '@000'
    assert Random().custom_code('@###', char='@', digit='#') == '@000'
    assert Random().custom_code('@@@##', char='@', digit='#') == '@@@00'
    assert Random().custom_code('@@###', char='@', digit='#') == '@@000'
    assert Random().custom_code('####', char='@', digit='#') == '0000'
    assert Random().custom_code('@###', char='@', digit='#') == '@000'
    assert Random().custom_code('####', char='@', digit='#') == '0000'

# Generated at 2022-06-23 21:53:49.937048
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    a, b = 1, 5
    assert len(rnd.randints(a, b)) == a
    assert len(rnd.randints(amount=b)) == b
    assert rnd.randint(*rnd.randints(1, 2)) in range(2)



# Generated at 2022-06-23 21:53:53.388498
# Unit test for function get_random_item
def test_get_random_item():
    class WeekDay(object):
        Mon, Tue, Wed, Thu, Fri, Sat, Sun = range(7)

    day = get_random_item(WeekDay)

# Generated at 2022-06-23 21:54:01.111508
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(random.generate_string(string.digits)) == 10
    assert len(random.generate_string(string.digits, length=20)) == 20
    assert len(random.generate_string(string.digits, length=30)) == 30
    assert len(random.generate_string(string.digits, length=40)) == 40
    assert len(random.generate_string(string.digits, length=50)) == 50
    assert len(random.generate_string(string.digits, length=60)) == 60
    assert len(random.generate_string(string.digits, length=70)) == 70
    assert len(random.generate_string(string.digits, length=80)) == 80

# Generated at 2022-06-23 21:54:06.827478
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()

# Generated at 2022-06-23 21:54:17.119984
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test custom code."""
    ans = random.custom_code()
    assert len(ans) == 4
    assert '@' not in ans

    ans = random.custom_code("@###")
    assert len(ans) == 4
    assert '@' not in ans

    ans = random.custom_code("@@###")
    assert ans[0] == ans[1]
    assert '@' not in ans[2:]

    ans = random.custom_code("@@@###")
    assert ans[0] == ans[1]
    assert ans[1] == ans[2]
    assert '@' not in ans[3:]

    ans = random.custom_code("A###")
    assert ans[0] == 'A'
    assert len(ans) == 4
    assert '@' not in ans


# Generated at 2022-06-23 21:54:21.238350
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    import math

    rnd = Random()
    a = 2.13
    b = 5.37
    precision = 3

    result = rnd.uniform(a, b, precision)
    assert b > result > a
    assert math.isclose(result, rnd.uniform(a, b, precision))

# Generated at 2022-06-23 21:54:27.098644
# Unit test for method randstr of class Random
def test_Random_randstr():
    randstr = random.randstr()
    assert isinstance(randstr, str) is True
    assert len(randstr) == 32

    randstr = random.randstr(unique=True)
    assert isinstance(randstr, str) is True
    assert len(randstr) == 32

    randstr = random.randstr(length=64)
    assert isinstance(randstr, str) is True
    assert len(randstr) == 64

# Generated at 2022-06-23 21:54:30.653515
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(), str)
    assert isinstance(random.randstr(unique=True), str)

    for i in range(100):
        assert len(random.randstr()) == 16
        assert len(random.randstr(length=16)) == 16
        assert len(random.randstr(length=128)) == 128

# Generated at 2022-06-23 21:54:32.581073
# Unit test for function get_random_item
def test_get_random_item():
    # Just for example
    class TestEnum:
        A = 1
        B = 2
        C = 3

    assert get_random_item(TestEnum) in [1, 2, 3]

# Generated at 2022-06-23 21:54:35.292530
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    res = r.randints(3)
    assert len(res) == 3
    assert all([isinstance(i, int) for i in res])



# Generated at 2022-06-23 21:54:38.598196
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0, 1.1) > 0.1
    assert random.uniform(0, 1.1) < 1.1

# Generated at 2022-06-23 21:54:40.245435
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(10) == os.urandom(10)



# Generated at 2022-06-23 21:54:49.320045
# Unit test for method urandom of class Random

# Generated at 2022-06-23 21:54:58.101782
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(random.generate_string(str_seq='xyz'), str)
    assert all(chr in 'xyz' for chr in random.generate_string(str_seq='xyz'))
    assert isinstance(random.generate_string(str_seq='123'), str)
    assert all(chr in '123' for chr in random.generate_string(str_seq='123'))
    assert len(random.generate_string(length=3)) == 3
    assert len(random.generate_string(str_seq='xyz', length=5)) == 5



# Generated at 2022-06-23 21:55:01.419726
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    numbers = r.randints(3, 6, 10)
    assert all(x >= 6 and x < 10 for x in numbers)


# Generated at 2022-06-23 21:55:04.145142
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert round(random.uniform(1, 2), 4) == 1.009
    assert round(random.randrange(1, 2), 4) == 1.009

# Generated at 2022-06-23 21:55:07.963769
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender

    gender = get_random_item(Gender)
    assert isinstance(gender, Gender)

    random = Random()
    gender = get_random_item(Gender, random)
    assert isinstance(gender, Gender)

# Generated at 2022-06-23 21:55:09.671603
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0.4, 0.6, precision=2) == 0.5

# Generated at 2022-06-23 21:55:13.256560
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    qnt = 5
    rnd_str = random.generate_string
    assert len(rnd_str('j')) == qnt

    random.seed(1)
    for i in range(10):
        assert rnd_str('f') == 'ffffffffff'



# Generated at 2022-06-23 21:55:15.481142
# Unit test for constructor of class Random
def test_Random():
    """Unit test for Random."""
    r = Random()
    assert r is not None
    assert isinstance(r, Random)


# Generated at 2022-06-23 21:55:19.147832
# Unit test for function get_random_item
def test_get_random_item():
    """
    Test for function get_random_item
    :return:
    """
    from datetime import date
    from mimesis.enums import Weekday
    date.today()
    day = get_random_item(Weekday)
    assert day in Weekday

# Generated at 2022-06-23 21:55:20.741849
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    assert Random().randint(1, 10) in range(1, 10)

# Generated at 2022-06-23 21:55:22.559196
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    print(rnd.uniform(2.98, 3.98))
    print(rnd.uniform(0, 1))

# Generated at 2022-06-23 21:55:24.382227
# Unit test for method urandom of class Random
def test_Random_urandom():
    _ = [
        Random().urandom(32),
        Random().urandom(64),
        Random().urandom(128),
    ]



# Generated at 2022-06-23 21:55:25.088949
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random().urandom(), bytes)

# Generated at 2022-06-23 21:55:30.831696
# Unit test for method randints of class Random
def test_Random_randints():
    # import ipdb; ipdb.set_trace()
    assert type(Random().randints()) == list
    assert type(Random().randints(1)) == list
    assert type(Random().randints(1, 1, 2)) == list

    try:
        assert type(Random().randints(0)) == list
    except ValueError:
        pass

    _random = Random()
    _random.seed(1)
    _random.randints(amount=6, a=1, b=10) == [6, 9, 4, 3, 5, 6]
    _random.seed(2)
    assert _random.randints(amount=6, a=1, b=10) == [7, 4, 5, 1, 6, 3]

    _random = Random()
    _random.seed(3)
    assert _random

# Generated at 2022-06-23 21:55:32.752620
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    assert r.randints() == [11, 98, 98]



# Generated at 2022-06-23 21:55:35.163772
# Unit test for method urandom of class Random
def test_Random_urandom():  # noqa: D103
    """Test for the class ``Random()`` and method ``urandom()``."""
    _urandom = Random().urandom(1).hex()
    assert len(_urandom) == 2
    assert len(Random().urandom(2).hex()) == 4



# Generated at 2022-06-23 21:55:39.710611
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    rnd.seed(1)
    seq = string.ascii_letters + string.digits
    res = rnd.generate_string(str_seq=seq, length=randint(5, 25))
    assert len(res) in range(5, 25, 1)
    assert all(n in seq for n in res)



# Generated at 2022-06-23 21:55:43.452923
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(3):
        generated_code = random.custom_code()
        assert isinstance(generated_code, str)
        assert len(generated_code) == 4

# Generated at 2022-06-23 21:55:55.677769
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    r = rnd.randints()
    assert len(r) == 3
    assert r[0] != r[1] and r[1] != r[2] and r[0] != r[2]
    assert isinstance(r[0], int) and isinstance(r[1], int) and isinstance(r[2], int)
    assert 0 < r[0] and r[0] < 100 and 0 < r[1] and r[1] < 100 \
        and 0 < r[2] and r[2] < 100
    r = rnd.randints(5)
    assert len(r) == 5
    assert r[0] != r[1] and r[1] != r[2] and r[0] != r[2] \
        and r[2] != r

# Generated at 2022-06-23 21:55:57.614014
# Unit test for constructor of class Random
def test_Random():
    # Initialize empty object of class Random
    rnd = Random()
    # Check  if the id of object is not None
    assert rnd.random() is not None


# Generated at 2022-06-23 21:55:59.254315
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)



# Generated at 2022-06-23 21:56:02.703507
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    class TestEnum(object):
        FIRST = 1
        SECOND = 2

    assert get_random_item(TestEnum) in TestEnum


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-23 21:56:14.879566
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    # Test 1
    assert r.randints(amount=0) == []
    # Test 2
    assert r.randints(amount=3, a=-10, b=-10) == [-10, -10, -10]
    # Test 3
    assert r.randints(amount=3, a=0, b=10) == [1, 2, 4]
    # Test 4
    assert r.randints(amount=3, a=50, b=50) == [50, 50, 50]
    # Test 5
    assert r.randints(amount=3, a=0, b=3) == [1, 1, 1]
    # Test 6
    assert r.randints(amount=2, a=1, b=10) == [7, 8]
    # Test 7

# Generated at 2022-06-23 21:56:16.959571
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints of class Random."""
    assert Random().randints(amount=4) == [48, 62, 72, 69]



# Generated at 2022-06-23 21:56:25.648796
# Unit test for function get_random_item
def test_get_random_item():
    import enum

    class FakeEnum(enum.Enum):
        """Fake enum values."""

        ONE = 1
        TWO = 2
        THREE = 3
        FOUR = 4
        FIVE = 5
        SIX = 6
        SEVEN = 7
        EIGHT = 8
        NINE = 9
        TEN = 10

        @classmethod
        def random(cls, rnd: Random) -> Any:
            """Get random enumeration value.

            :return: Random enumeration value.
            """
            return get_random_item(cls, rnd)
    #
    # Unknown exception (probably, incorrect work of `random.choice()`).
    # See: https://github.com/lk-geimfari/mimesis/issues/469
    #
    # assert FakeEnum.ONE == Fake

# Generated at 2022-06-23 21:56:31.553083
# Unit test for method randints of class Random
def test_Random_randints():
    _lst = random.randints()
    assert len(_lst) == 3
    assert max(_lst) <= 100
    assert min(_lst) >= 1
    assert all(isinstance(element, int) for element in _lst)

    _lst = random.randints(amount=10, a=2, b=150)
    assert len(_lst) == 10
    assert max(_lst) <= 150
    assert min(_lst) >= 2
    assert all(isinstance(element, int) for element in _lst)

    _lst = random.randints(amount=-11)
    assert len(_lst) == 0
    assert _lst == []
    assert all(isinstance(element, int) for element in _lst)



# Generated at 2022-06-23 21:56:39.975145
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Code for normal use
    for _ in range(10):
        code = random.custom_code('@###')
        assert 0 < len(code) <= 7
        assert code[0].isalpha()

    # Code for normal use
    for _ in range(10):
        code = random.custom_code('#@###')
        assert 0 < len(code) <= 7
        assert code[0].isnumeric()

    # Code for normal use
    for _ in range(10):
        code = random.custom_code('#@@##')
        assert 0 < len(code) <= 7
        assert code[1].isalpha()
        assert code[0].isnumeric()

    # Code for normal use
    for _ in range(10):
        code = random.custom_code('##@##')
        assert 0 < len

# Generated at 2022-06-23 21:56:42.910960
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    print("uniform ", rnd.uniform(a=1, b=2, precision=15))  # 1.6666666666666665



# Generated at 2022-06-23 21:56:51.806586
# Unit test for method uniform of class Random
def test_Random_uniform():
    random.seed(None)
    assert isinstance(random.uniform(0, 1), float)
    assert isinstance(random.uniform(0, 1, 2), float)
    assert isinstance(random.uniform(1, 2), float)
    assert isinstance(random.uniform(1, 2, 2), float)
    assert isinstance(random.uniform(1.1, 2.1), float)
    assert isinstance(random.uniform(1.1, 2.1, 2), float)
    assert isinstance(random.uniform(1, 2.1), float)
    assert isinstance(random.uniform(1, 2.1, 2), float)



# Generated at 2022-06-23 21:56:54.690608
# Unit test for method randstr of class Random
def test_Random_randstr():
    string_len = random.randint(16, 128)
    random_str = random.randstr(length=string_len)
    assert len(random_str) == string_len

# Generated at 2022-06-23 21:56:59.552958
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code(mask='@## @##') == 'F55 F55'
    assert random.custom_code(mask='@## @@#') == 'P47 POT'
    assert random.custom_code(mask='@## @@@') == 'B77 BUG'
    assert random.custom_code(mask='@###') == 'G157'

# Generated at 2022-06-23 21:57:08.524782
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random.

    Result:
        --------
        .
        ----------------------------------------------------------------------
        Ran 1 test in 0.001s

        OK
    """
    from unittest import TestCase, main
    from mimesis.compat import patch

    with patch('uuid.uuid4') as _uuid4:
        _uuid4.return_value = 16 * b'\x00'

        class RandstrTestCase(TestCase):

            @patch('string.ascii_letters')
            @patch('secrets.choice')
            def test_randstr(self, _choice, _ascii_letters):
                _ascii_letters.return_value = 'abcdefghijklmnopqrstuvwxyz'
                _choice.return_value = 'a'
                _

# Generated at 2022-06-23 21:57:11.167174
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    r = Random()
    assert isinstance(r, Random)
    assert r.urandom(10)



# Generated at 2022-06-23 21:57:14.504564
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random.
    """
    rnd = Random()
    assert rnd.custom_code() == rnd.custom_code()

# Generated at 2022-06-23 21:57:21.177404
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Create two objects of class Random
    random_obj = Random()
    random_obj_two = Random()
    # Create two lists of 1000 random strings
    list_random_string = [random_obj.generate_string() for _ in range(1000)]
    list_random_string_two = [random_obj_two.generate_string() for _ in range(1000)]
    # Check that the lists are not identical
    assert list_random_string != list_random_string_two



# Generated at 2022-06-23 21:57:25.905263
# Unit test for function get_random_item
def test_get_random_item():
    class SomeEnum:
        a = 1
        b = 2
        c = 3

    enum = SomeEnum
    assert enum[get_random_item(enum)]
    assert enum[get_random_item(enum, Random())]
    #  check if the function works correctly for the wrong argument
    assert not get_random_item(1)

# Generated at 2022-06-23 21:57:34.134918
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    unique_str = random.randstr(unique=True)
    assert not unique_str.isalnum()
    assert len(unique_str) == 32

    non_unique_str = random.randstr()
    assert non_unique_str.isalnum()
    assert len(non_unique_str) <= 128

    length = random.randint(16, 128)
    non_unique_str = random.randstr(length=length)
    assert non_unique_str.isalnum()
    assert len(non_unique_str) == length

# Generated at 2022-06-23 21:57:37.802636
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    res = rnd.generate_string(str_seq='123456789', length=5)
    assert isinstance(res, str)
    assert len(res) == 5

# Generated at 2022-06-23 21:57:45.907729
# Unit test for method urandom of class Random
def test_Random_urandom():
    from mimesis.constants import TEST_STRING_ASCII
    s = Random().urandom(100)
    assert len(s) == 100
    assert isinstance(s, bytes)
    rnd = Random()
    assert isinstance(rnd.urandom(), bytes)
    assert isinstance(rnd.urandom(100), bytes)
    rnd.seed(TEST_STRING_ASCII)
    assert isinstance(rnd.urandom(), bytes)
    assert isinstance(rnd.urandom(100), bytes)

# Generated at 2022-06-23 21:57:48.505329
# Unit test for method randstr of class Random
def test_Random_randstr():
    generated_string = random.randstr()
    assert len(generated_string) >= 16, "String length should be at least 16"

# Generated at 2022-06-23 21:57:52.823771
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test method ``randstr`` of class ``Random``."""
    _random = Random()
    _unique = _random.randstr(unique=True)
    assert len(_unique) == 32
    _string = _random.randstr(unique=False)
    assert len(_string) > 16

# Generated at 2022-06-23 21:57:54.903449
# Unit test for method urandom of class Random
def test_Random_urandom():
    r = Random()
    assert isinstance(r.urandom(), bytes)


# Generated at 2022-06-23 21:58:01.462354
# Unit test for method randints of class Random
def test_Random_randints():
    _amount = random_module.randint(1, 5)
    _minimum = random_module.randint(-1000, -100)
    _maximum = random_module.randint(100, 1000)

    _ints = random.randints(amount=_amount,
                            a=_minimum, b=_maximum)

    assert len(_ints) == _amount
    assert _ints == sorted(_ints)



# Generated at 2022-06-23 21:58:03.395707
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), str)

# Generated at 2022-06-23 21:58:09.329989
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert all([len(i) == 5 for i in Random().generate_string(string.ascii_letters + string.digits, 5)])
    assert all([len(i) == 5 for i in Random().generate_string(string.digits * 5, 5)])
    assert all([len(i) == 1 for i in Random().generate_string(string.digits, 1)])
    print("testing Random_generate_string was successful")

# Generated at 2022-06-23 21:58:10.176905
# Unit test for constructor of class Random
def test_Random():
    assert Random() is not None

# Generated at 2022-06-23 21:58:11.381400
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = random.generate_string(str_seq='ABC')
    assert len(r) == 10



# Generated at 2022-06-23 21:58:16.393420
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    lst = []
    for i in range(10000):
        lst.append(r.uniform(1, 2, 3))
    lst1 = lst.copy()
    lst1.sort()
    # All numbers should be between 1 and 2
    assert (lst1[0] <= 1) and (lst1[-1] >= 2)

# Generated at 2022-06-23 21:58:19.146586
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(random.generate_string('asdf')) == 10
    assert type(random.generate_string('asdf')) == str
    

# Generated at 2022-06-23 21:58:23.126780
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Arrange
    _random = Random()

    # Act
    string = _random.generate_string("abcdefg", 10)

    # Assert
    assert(len(string) == 10)
    assert(all(letter in string for letter in "abcdefg"))

# Generated at 2022-06-23 21:58:27.831752
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random.
    """
    _random = Random()
    assert _random.randstr() == _random.randstr(unique=False)
    assert len(_random.randstr()) == len(_random.randstr(length=10))

# Generated at 2022-06-23 21:58:35.101876
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for method custom_code of class Random."""
    from mimesis.enums import Gender
    from mimesis.providers.person import Person

    p = Person()
    pattern = '@@###'
    gender = get_random_item(Gender)

    custom_code = random.custom_code(pattern, char='@', digit='#')

    assert isinstance(custom_code, str)
    assert len(custom_code) == len(pattern)
    assert custom_code[0] == gender.value[0].upper()

# Generated at 2022-06-23 21:58:35.946458
# Unit test for method urandom of class Random
def test_Random_urandom():
    x = Random.urandom()
    assert x


# Generated at 2022-06-23 21:58:37.740834
# Unit test for function get_random_item
def test_get_random_item():
    class Test(object):
        def __init__(self):
            self.sent = True

    rnd = Random()
    test = Test()
    assert random.get_random_item(test) == 'sent'

# Generated at 2022-06-23 21:58:39.727956
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert rnd.uniform(1, 2, precision=0) == 1


# Generated at 2022-06-23 21:58:49.236142
# Unit test for method randints of class Random
def test_Random_randints():
    test_random = Random()
    for i in range(50):
        res = test_random.randints()
        assert len(res) == 3
        assert all(x >= 1 and x <= 100 for x in res)
        res = test_random.randints(amount=2, a=10, b=30)
        assert len(res) == 2
        assert all(x >= 10 and x <= 30 for x in res)
        res = test_random.randints(amount=4, a=20, b=40)
        assert len(res) == 4
        assert all(x >= 20 and x <= 40 for x in res)



# Generated at 2022-06-23 21:58:58.821135
# Unit test for method randstr of class Random
def test_Random_randstr():

    # Test 1
    # not unique values
    assert random.randstr() != random.randstr()
    assert random.randstr() != random.randstr()
    assert random.randstr() != random.randstr()
    assert random.randstr() != random.randstr()

    # Test 2
    # unique values
    assert random.randstr(unique=True) != random.randstr(unique=True)
    assert random.randstr(unique=True) != random.randstr(unique=True)
    assert random.randstr(unique=True) != random.randstr(unique=True)
    assert random.randstr(unique=True) != random.randstr(unique=True)

    # Test 3
    # length value
    assert len(random.randstr(length=5)) == 5

# Generated at 2022-06-23 21:59:01.546430
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert len(rnd.randints()) == 3
    assert len(rnd.randints(amount=4)) == 4


# Generated at 2022-06-23 21:59:02.998702
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(Random().generate_string('x'), str)



# Generated at 2022-06-23 21:59:05.482244
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(random.randstr(unique=False)) <= 128
    assert len(random.randstr(unique=False, length=10)) == 10
    assert isinstance(random.randstr(unique=True), str)



# Generated at 2022-06-23 21:59:15.835458
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test custom_code method."""
    rnd = Random()
    
    # expected result
    assert rnd.custom_code() in ['@W#7', '@5##', '@V5#', '@2##', '@5##']
    
    # different placeholders
    assert rnd.custom_code('&###', char='&') in ['&W#7', '&5##', '&V5#', '&2##', '&5##']
    assert rnd.custom_code('&###', digit='&') in ['W&7', '5&', 'V5', '2&', '5&']
    
    # should raise an exception
    rnd = Random()

# Generated at 2022-06-23 21:59:20.780583
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random"""
    _r = Random()
    assert isinstance(_r.generate_string('1234567890', 5), str) is True
    assert _r.generate_string('AaBbCc', 5).isalpha() is True
    assert _r.generate_string('1234567890', 5).isdigit() is True


# Generated at 2022-06-23 21:59:27.486759
# Unit test for function get_random_item
def test_get_random_item():
    from .file import FileExtension
    from .text import Text
    from .schema import FieldType

    result = get_random_item(FileExtension)
    assert result in FileExtension

    result = get_random_item(Text)
    assert result in Text

    result = get_random_item(FieldType)
    assert result in FieldType

    from . import file
    result = get_random_item(file.FileExtension)
    assert result in file.FileExtension

    from . import text
    result = get_random_item(text.Text)
    assert result in text.Text

    from . import schema
    result = get_random_item(schema.FieldType)
    assert result in schema.FieldType

    result = get_random_item(schema.FieldType, random)
    assert result in schema

# Generated at 2022-06-23 21:59:31.619532
# Unit test for method uniform of class Random
def test_Random_uniform():
    foreign = Random()
    numbers = []
    for _ in range(10000):
        numbers.append(foreign.uniform(0.5, 1.5))
    assert min(numbers) >= 0.5 and max(numbers) <= 1.5

# Generated at 2022-06-23 21:59:34.352809
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test for method generate_string of class Random."""
    rnd = Random()
    result = rnd.generate_string(string.ascii_uppercase + string.digits)
    assert len(result) <= 10


# Generated at 2022-06-23 21:59:36.034979
# Unit test for constructor of class Random
def test_Random():
    test_random = Random()
    test_random.randint()

    assert(isinstance(test_random, Random))

# Generated at 2022-06-23 21:59:37.880852
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(4), bytes)



# Generated at 2022-06-23 21:59:42.892605
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    random_obj = Random()
    assert random_obj.uniform(1, 1) == 1
    assert random_obj.uniform(0.5, 1) == 0.5
    assert round(random_obj.uniform(0, 1), 15) > 0.000000000000001
    assert round(random_obj.uniform(0, 1), 15) < 0.999999999999999
    assert random_obj.uniform(0, 1, 1) == 0.0

# Generated at 2022-06-23 21:59:45.997989
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum

    class TestEnum(Enum):
        A = 1
        B = 2
        C = 3

    test_enum = TestEnum.A
    assert get_random_item(TestEnum, random) == test_enum

    test_enum = TestEnum.B
    assert get_random_item(TestEnum, random) == test_enum

    test_enum = TestEnum.C
    assert get_random_item(TestEnum, random) == test_enum

# Generated at 2022-06-23 21:59:54.179589
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _ = 'testing_custom_code'

    # Default mask
    assert _ == Random().custom_code(mask='testing_custom_code')

    # Default mask
    assert _ == Random().custom_code(mask='testing_custom_code')

    # Change placeholder
    assert _ == Random().custom_code(mask='testing_custom_code',
                                     char='t', digit='_')

    # Change placeholder
    assert _ == Random().custom_code(mask='testing_custom_code',
                                     char='t', digit='_')

    # Wrong mask
    assert 'test_test' != Random().custom_code(mask='testing_custom_code')

    # Wrong mask
    assert 'test_test' != Random().custom_code(mask='testing_custom_code',
                                               char='t', digit='_')

    #

# Generated at 2022-06-23 21:59:56.988925
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(1, 2, 3) == [2]
    assert Random().randints(5, 2, 3) == [2, 2, 2, 2, 2]



# Generated at 2022-06-23 21:59:58.917282
# Unit test for constructor of class Random
def test_Random():
    rand = Random()
    expected = rand.uniform(-1, 1.5, 2)
    assert isinstance(expected, float)

# Generated at 2022-06-23 22:00:00.362973
# Unit test for method urandom of class Random
def test_Random_urandom():
    res = Random.urandom(10)
    assert len(res) == 10


# Generated at 2022-06-23 22:00:07.480687
# Unit test for method randints of class Random
def test_Random_randints():
    number_of_numbers = random.randint(1, 1000)
    a, b = random.randint(-1000, -1), random.randint(1, 1000)
    generated_list = random.randints(number_of_numbers, a, b)

    assert len(generated_list) == number_of_numbers
    assert all(a < number < b for number in generated_list), \
        "Numbers should be in the range [a, b)."

# Generated at 2022-06-23 22:00:10.693654
# Unit test for method randints of class Random
def test_Random_randints():
    for _ in range(100):
        nums = random.randints(amount=5, a=10, b=100)
        assert len(nums) == 5
        for n in nums:
            assert n >= 10 and n < 100
        nums = random.randints(amount=5, a=1, b=5)
        assert len(nums) == 5
        for n in nums:
            assert n >= 1 and n < 5

# Generated at 2022-06-23 22:00:13.029268
# Unit test for function get_random_item
def test_get_random_item():
    if isinstance(Item.random(), Item):
        print("Success!")
    else:
        print("Error!")


# Generated at 2022-06-23 22:00:16.824744
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(amount=12, a=1, b=100)
    assert Random().randints(amount=5)

    with pytest.raises(ValueError):
        Random().randints(amount=0)



# Generated at 2022-06-23 22:00:20.544263
# Unit test for method uniform of class Random
def test_Random_uniform():
    values = [
        *random.uniform(1, 10, 10000),
        *random.uniform(1, 100, 10000)
    ]
    assert min(values) >= 1
    assert max(values) <= 100
    assert len(values) == 20000

# Generated at 2022-06-23 22:00:22.925754
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    # Just enough to check if there's no exception,
    # and the first condition is fulfilled.
    assert rnd.uniform(1, 2) >= 1

# Generated at 2022-06-23 22:00:25.001459
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Check if the method Random.randstr() works correctly."""
    for number in range(10):
        length = random.randint(16, 128)
        assert len(random.randstr(length=length)) == length

# Generated at 2022-06-23 22:00:27.966898
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit tests for method generate_string of class Random."""
    assert len(Random().generate_string(string.digits, 20)) == 20
    assert len(Random().generate_string(string.ascii_letters, length=5)) == 5
    assert len(Random().generate_string(string.punctuation, amount=7)) == 7

# Generated at 2022-06-23 22:00:39.099526
# Unit test for method randints of class Random
def test_Random_randints():
    test = Random()
    random_ints = test.randints(amount=3, a=1, b=100)
    assert len(random_ints) == 3
    for i in random_ints:
        assert type(i) == int

    test1 = Random()
    for _ in range(1000):
        # Amount between 5 and 20
        random_int_amount = test1.randint(5, 20)
        random_ints = test1.randints(amount=random_int_amount, a=1, b=100)
        assert len(random_ints) == random_int_amount
        for i in random_ints:
            assert type(i) == int


# Generated at 2022-06-23 22:00:46.416453
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random.
    """
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1:].isdigit()

    rnd = Random()
    code = rnd.custom_code(mask='@#@@@')
    assert len(code) == 5
    assert code[:2].isalpha()
    assert code[2].isdigit()
    assert code[3:].isalpha()

    rnd = Random()
    code = rnd.custom_code(mask='@#@#@#@#@#@#@#@#@#@#@#@#@#')
    assert len(code) == 23
    assert code[:2].isalpha()
    assert code[2].isdigit()

# Generated at 2022-06-23 22:00:50.055896
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Check that method custom_code of class Random
    correctly generates a string of the format @###.
    """
    assert len(random.custom_code()) == 4
    assert len(random.custom_code('@@@###')) == 7
    assert random.custom_code().startswith('@')
    assert random.custom_code().endswith('#')
    assert random.custom_code()[-4:].isdigit()
    assert random.custom_code()[1:-4].isalpha()


# Unit tests for randints method of class Random

# Generated at 2022-06-23 22:01:01.571455
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for Random.randints.
    """
    for _ in range(1, 100):
        r = list(random.randints())
        assert len(r) == 3
        assert r[0] in range(1, 100)
        assert r[1] in range(1, 100)
        assert r[2] in range(1, 100)
        r = list(random.randints(2))
        assert len(r) == 2
        assert r[0] in range(1, 100)
        assert r[1] in range(1, 100)
        r = list(random.randints(100, a=0, b=100))
        assert len(r) == 100
        assert r[0] in range(0, 100)
        assert r[-1] in range(0, 100)

# Generated at 2022-06-23 22:01:10.975328
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    string = Random().generate_string(str_seq="ABCDEFghi", length=4)
    assert len(string) == 4
    for i in range(4):
        if (string[i] == 'A' or string[i] == 'B' or string[i] == 'C' or
            string[i] == 'D' or string[i] == 'E' or string[i] == 'F' or
            string[i] == 'g' or string[i] == 'h' or string[i] == 'i'):
            continue
        else:
            print("Not a letter from string sequence")
            break
    else:
        print("Correctly generated random string")

if __name__ == '__main__':
    test_Random_generate_string()

# Generated at 2022-06-23 22:01:12.488076
# Unit test for method randstr of class Random
def test_Random_randstr():
    # TODO: Write unit test
    pass

# Generated at 2022-06-23 22:01:13.470354
# Unit test for method urandom of class Random
def test_Random_urandom():
    bytes_ = Random().urandom(3)
    assert isinstance(bytes_, bytes)

# Generated at 2022-06-23 22:01:15.033353
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test ``urandom()`` method."""
    result = Random.urandom(256)
    assert len(result) == 256
    assert isinstance(result, bytes)

# Generated at 2022-06-23 22:01:16.050484
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Test 1
    for i in range(0, 100):
        assert len(random.randstr()) == 36

# Generated at 2022-06-23 22:01:18.866773
# Unit test for constructor of class Random
def test_Random():
    """Check that the constructor for class Random works correctly.

    :return: Test passed or failed,
             expected and actual results.
    """
    randomer = Random()
    randomer.random()
    randomer.randint(2, 3)
    randomer.randrange(2, 3)

    from mimesis.random import DEFAULT_RANDOM
    assert randomer is DEFAULT_RANDOM
    return (True, None, None)

# Generated at 2022-06-23 22:01:25.995420
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert len(rnd.randints()) == 3
    assert len(rnd.randints(amount=7)) == 7
    assert len(rnd.randints(a=3, b=5)) == 3
    assert len(rnd.randints(amount=3, a=3, b=5)) == 3
    assert rnd.randints(amount=2, a=1, b=5) == rnd.randints(2, 1, 5)
    assert rnd.randints(amount=-1, a=-1, b=-2) == []


# Generated at 2022-06-23 22:01:27.650379
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    obj = Random()
    code = obj.custom_code()
    assert isinstance(code, str)

# Generated at 2022-06-23 22:01:30.851404
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    assert get_random_item(random_module.__dict__)
    assert get_random_item(random_module.__dict__, random)