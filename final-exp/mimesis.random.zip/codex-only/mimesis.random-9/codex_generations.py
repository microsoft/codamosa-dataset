

# Generated at 2022-06-23 21:51:31.779356
# Unit test for method uniform of class Random
def test_Random_uniform():
    print("Hello world")
    assert random.uniform(1, 10) == 5.5

test_Random_uniform()

# Generated at 2022-06-23 21:51:33.119411
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(42) == os.urandom(42)

# Generated at 2022-06-23 21:51:38.634840
# Unit test for constructor of class Random
def test_Random():
    """Test constructor of class Random.

    :return: None.
    """
    r = Random()
    print(r.randints(10))
    print(r.randstr(unique=True))
    print(r.custom_code(mask='@##-@##'))
    print(r.custom_code(mask='@@###@@'))
    print(r.randstr(unique=False))
    print(r.randstr(unique=False, length=5))
    print(r.generate_string('abc'))

    # Test unicode mask
    print(r.custom_code(mask='@##-@##', digit=r'\u0023'))
    print(r.custom_code(mask='@@###@@', char=r'\u0040'))



# Generated at 2022-06-23 21:51:45.460022
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###').isalnum()
    assert len(random.custom_code('@###@')) == 5
    assert len(random.custom_code('@###@', '%', '#')) == 5
    assert len(random.custom_code('@###@', '%', '%')) == 5
    assert len(random.custom_code('%%%%', '%', '%')) == 4

# Generated at 2022-06-23 21:51:51.705635
# Unit test for constructor of class Random
def test_Random():
    used_methods = list()

    class RandomTest(Random):
        def __init__(self):
            super().__init__()
            for attr in dir(Random):
                if not attr.startswith('_'):
                    used_methods.append(attr)

    rnd = RandomTest()
    for attr in dir(rnd):
        if not attr.startswith('_'):
            used_methods.remove(attr)

    assert not used_methods



# Generated at 2022-06-23 21:51:52.632515
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(10)

# Generated at 2022-06-23 21:51:55.420809
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert isinstance(rnd, Random)
    assert 1 <= rnd.randint(1, 2) <= 2
    assert 3 <= rnd.randint(3, 4) <= 4



# Generated at 2022-06-23 21:51:58.385629
# Unit test for method uniform of class Random
def test_Random_uniform():
    rand = Random()
    assert rand.uniform(a=0.0, b=1.0) == 0.5
    assert rand.uniform(a=0.0, b=2.0) == 1.0

# Generated at 2022-06-23 21:52:00.481447
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert Random().uniform(1, 5) == Random().uniform(1, 5) # no coverage

# Generated at 2022-06-23 21:52:02.599498
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert r.random()
    r = Random()
    assert r.random()

# Generated at 2022-06-23 21:52:03.676883
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)

# Generated at 2022-06-23 21:52:11.356483
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom()
    assert isinstance(Random.urandom(), bytes)

    _bytes = [1, 10, 100, 1000]
    for _byte in _bytes:
        _result = Random.urandom(_byte)
        assert isinstance(_result, bytes)
        assert len(_result) == _byte

    _byte = 123
    _result = Random.urandom(_byte)
    assert isinstance(_result, bytes)
    assert len(_result) == _byte



# Generated at 2022-06-23 21:52:12.685759
# Unit test for method randstr of class Random
def test_Random_randstr():
    for i in range(0,10):
        print(random.randstr())

# Generated at 2022-06-23 21:52:15.228247
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rs = Random().generate_string('0123456789', 10)
    assert isinstance(rs, str)
    assert len(rs) == 10


# Generated at 2022-06-23 21:52:25.813742
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    random = Random()
    assert get_random_item(Gender) in list(Gender)
    assert get_random_item(Gender, random) in list(Gender)
    assert get_random_item(Gender, random) in list(Gender)
    assert get_random_item(Gender, random) in list(Gender)
    assert get_random_item(Gender, random) in list(Gender)
    assert get_random_item(Gender, random) in list(Gender)
    assert get_random_item(Gender, random) in list(Gender)
    assert get_random_item(Gender, random) in list(Gender)
    assert get_random_item(Gender, random) in list(Gender)

# Generated at 2022-06-23 21:52:30.501867
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    res1 = Random().generate_string('12345')
    res2 = Random().generate_string('12345', 100)
    res3 = Random().generate_string('qwertyuiopasdfghjklzxcvbnm', 6)
    assert isinstance(res1, str)
    assert isinstance(res2, str)
    assert isinstance(res3, str)



# Generated at 2022-06-23 21:52:31.586689
# Unit test for method urandom of class Random
def test_Random_urandom():
    rand = Random()
    rand.urandom()

# Generated at 2022-06-23 21:52:32.562944
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), random_module.Random)



# Generated at 2022-06-23 21:52:41.045811
# Unit test for method randints of class Random
def test_Random_randints():
    # Test amount = 1
    a = 1
    b = 1
    rnd = Random()
    assert len(rnd.randints(a, a, b)) == 1

    # Test amount = 2
    a = 5
    b = 100
    rnd = Random()
    assert len(rnd.randints(a, a, b)) == 2

    # Test amount = 2, a > b
    a = 100
    b = 5
    rnd = Random()
    assert len(rnd.randints(a, a, b)) == 2


# Generated at 2022-06-23 21:52:41.995019
# Unit test for constructor of class Random
def test_Random():
    rand = random.Random()
    rand.Random()

# Generated at 2022-06-23 21:52:46.425253
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    text1 = rnd.custom_code('@###')
    text2 = rnd.custom_code()
    text3 = rnd.custom_code(digit='#', char='@')
    text4 = rnd.custom_code(mask='@###', digit='#', char='@')
    assert isinstance(text1, str)
    assert isinstance(text2, str)
    assert isinstance(text3, str)
    assert isinstance(text4, str)


# Generated at 2022-06-23 21:52:48.552166
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0.3, 0.4) == random.uniform(0.3, 0.4)

# Generated at 2022-06-23 21:52:51.415217
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = random_module.Random()

    a = random.uniform(25, 26)

    assert 25.0 <= a < 26.0

# Generated at 2022-06-23 21:52:55.761948
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    str_seq = '#'
    length = 10

    string = rnd.generate_string(str_seq, length)
    assert len(string) == length
    assert not any(s for s in string if s != str_seq)



# Generated at 2022-06-23 21:53:01.878530
# Unit test for constructor of class Random
def test_Random():
    """Test for constructor of class ``Random()``."""
    # Test for constructor
    random = Random(1)
    assert random.seed(1) == random_module.Random(1).seed(1)
    random = Random()
    assert random.seed() == random_module.Random().seed()
    random = Random(2)
    assert random.seed() == random_module.Random(2).seed()

# Generated at 2022-06-23 21:53:02.908153
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(100)



# Generated at 2022-06-23 21:53:08.327057
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum

    class TestEnum(Enum):
        A = 1
        B = 2
        C = 3
        D = 4

    enum = TestEnum.B
    assert isinstance(enum, TestEnum)
    assert get_random_item(TestEnum) != enum
    assert get_random_item(TestEnum, rnd=random) != enum

# Generated at 2022-06-23 21:53:11.441089
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    a = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    result = random.generate_string(a)
    assert isinstance(result, str)



# Generated at 2022-06-23 21:53:13.379167
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    rnd.seed()
    assert rnd.custom_code(mask='@@@###', char='@', digit='#') == 'OKEC14'

# Generated at 2022-06-23 21:53:19.096650
# Unit test for function get_random_item
def test_get_random_item():
    class MyEnum(tuple):
        def __new__(cls, *args):
            return super().__new__(cls, args)

    enum = MyEnum('item1', 'item2',)
    assert random.choice(list(enum)) in get_random_item(enum)

# Generated at 2022-06-23 21:53:21.910453
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    max_random = random.custom_code('@###')
    min_random = random.custom_code('@###')
    if max_random < min_random:
        raise ValueError('Generate error.')

# Generated at 2022-06-23 21:53:30.498620
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    random.seed(777)
    assert random.custom_code(mask='@###') == 'X917'
    assert random.custom_code(mask='@###', char='%') == 'U917'
    assert random.custom_code(mask='@###', char='%', digit='$') == 'U917'
    assert random.custom_code(mask='@###', char='%', digit='%') == 'U917'
    assert random.custom_code(mask='@###', char='$', digit='%') == '%917'
    assert random.custom_code(mask='@###', char='@', digit='#') == 'X917'
    assert random.custom_code(mask='@###', char='%', digit='#') == 'C917'

   

# Generated at 2022-06-23 21:53:34.085514
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert len(rnd.randints(3)) == 3
    with pytest.raises(ValueError):
        rnd.randints(0)



# Generated at 2022-06-23 21:53:37.681727
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    res = r.randints()
    assert type(res) == list
    assert len(res) == 3
    assert type(res[0]) == int
    assert type(res[1]) == int
    assert type(res[2]) == int

# Generated at 2022-06-23 21:53:44.031070
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    import pytest
    m = Random(11)

    c = m.custom_code(mask='@###')
    assert c == 'C867'

    c = m.custom_code(mask='@#####')
    assert c == 'F44888'

    c = m.custom_code(mask='@####-D##')
    assert c == 'N1972-C39'

    c = m.custom_code(mask='@##-E###-@##')
    assert c == 'P18-K4371-P69'

    with pytest.raises(ValueError):
        m.custom_code(mask='@#####', char='@', digit='@')

# Generated at 2022-06-23 21:53:56.023457
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    from nose.tools import assert_true, assert_equals, assert_raises

    # Testing with default values
    rnd = Random()
    assert_equals(type(rnd.generate_string()), str)
    assert_equals(len(rnd.generate_string()), 10)

    # Testing with numbers
    string_of_digits = rnd.generate_string(string.digits)
    assert_true(all(x in string.digits for x in string_of_digits))

    # Testing with ASCII characters
    string_of_letters = rnd.generate_string(string.ascii_letters)
    assert_true(all(x in string.ascii_letters for x in string_of_letters))

    # Testing with custom values
    string_of_digits = r

# Generated at 2022-06-23 21:53:57.469043
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom()
    assert isinstance(Random.urandom(), bytes)



# Generated at 2022-06-23 21:53:58.845072
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    for i in range(10):
        print(Random().generate_string('1234567890'))


# Generated at 2022-06-23 21:53:59.629918
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)


# Generated at 2022-06-23 21:54:00.872942
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of class Random."""
    assert 0.5 <= random.uniform(0, 1) <= 1.0

# Generated at 2022-06-23 21:54:05.402575
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for method ``custom_code()`` of class ``Random()``."""
    from mimesis.constants import UNIX_EPOCH

    random = Random()
    random.seed(UNIX_EPOCH)
    custom = random.custom_code(mask='#@@#@')
    assert custom == 'A0A0A'

# Generated at 2022-06-23 21:54:08.167983
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert random.randstr(unique=True)
    assert isinstance(random.randstr(), str)
    assert random.randstr(length=6)
    assert random.randstr(length=6) != random.randstr(length=6)



# Generated at 2022-06-23 21:54:15.074162
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    r = Random()

    # Default params
    res_1 = r.randstr(False)
    assert isinstance(res_1, str)

    # Specify params
    res_2 = r.randstr(False, 13)
    assert isinstance(res_2, str)

    # Default params
    res_3 = r.randstr(True)
    assert isinstance(res_3, str)
    assert len(res_3) == 32

# Generated at 2022-06-23 21:54:17.961056
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_obj = Random()
    custom_code = random_obj.custom_code('@###')
    assert len(custom_code) == 4 and custom_code[0].isalpha() and custom_code[1:].isdigit()

# Generated at 2022-06-23 21:54:20.169152
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    for i in range(10):
        res = random.generate_string('')
        assert isinstance(res, str), "The random string must be a string."

# Generated at 2022-06-23 21:54:28.320151
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    # assert random.uniform(1.0, 3.0) == 2.0
    assert random.uniform(1.0, 3.0) >= 1.0
    assert random.uniform(1.0, 3.0) <= 3.0

    # assert random.uniform(1.0, 3.0, precision=1) == 2.0
    assert random.uniform(1.0, 3.0, precision=1) >= 1.0
    assert random.uniform(1.0, 3.0, precision=1) <= 3.0


# Generated at 2022-06-23 21:54:34.485590
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    pass
    # rnd = Random()
    # string_values = [rnd.generate_string(string.printable)
    #                  for _ in range(100)]
    # assert len(set(string_values)) == len(string_values)

    # for length in range(1, 100):
    #     string_values = [rnd.generate_string(string.ascii_letters, length)
    #                      for _ in range(100)]
    #     assert len(set(string_values)) == len(string_values)
    #     assert all(len(i) == length for i in string_values)

    # assert len(rnd.generate_string('01', 255)) == 255
    # assert len(rnd.generate_string(string.printable, 1)) == 1


# Unit test

# Generated at 2022-06-23 21:54:37.158128
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = random.custom_code()
    # TODO: Add more tests.

# Generated at 2022-06-23 21:54:41.246661
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = '###@##'
    custom_code = Random().custom_code(mask)
    assert isinstance(custom_code, str)
    assert len(custom_code) == len(mask)



# Generated at 2022-06-23 21:54:46.746455
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method ``custom_code()`` of class ``Random()``."""
    assert isinstance(random.custom_code(), str)
    assert len(random.custom_code()) == 4
    assert isinstance(random.custom_code('@###'), str)
    assert len(random.custom_code('@###')) == 4
    assert isinstance(random.custom_code(mask='@###'), str)
    assert len(random.custom_code(mask='@###')) == 4
    assert isinstance(random.custom_code(mask='@###', char='#'), str)
    assert len(random.custom_code(mask='@###', char='#')) == 4
    assert isinstance(random.custom_code(mask='@###', digit='#'), str)

# Generated at 2022-06-23 21:54:49.608879
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    result = rnd.randints()
    assert len(result) == 3
    assert isinstance(result, list)
    for item in result:
        assert isinstance(item, int)
        assert 1 <= item <= 100

# Generated at 2022-06-23 21:54:52.887039
# Unit test for constructor of class Random
def test_Random():
    """Test class Random."""
    rand = Random()
    rand.random()
    rand.uniform(1, 2)


# Generated at 2022-06-23 21:54:56.516987
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = Random()
    for i in range(1, 100):
        s = r.randstr(False)
        if len(s) == 0:
            raise AssertionError("Expected s is Null")
    return True



# Generated at 2022-06-23 21:54:58.599823
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test for method randstr"""
    _random = Random()
    _result = _random.randstr(unique=True)
    assert isinstance(_result, str)

# Generated at 2022-06-23 21:55:05.146338
# Unit test for method urandom of class Random
def test_Random_urandom():
    class FakeRandom(Random):
        def urandom(self, *args, **kwargs):
            return super().urandom(*args, **kwargs)

    r = FakeRandom()

    if os.name == 'nt':
        with open(os.path.join('tests', 'utility', 'data', 'urandom.dat'), 'rb') as f:
            data = f.read()
        assert r.urandom() == data
    else:
        assert r.urandom()

# Generated at 2022-06-23 21:55:13.475228
# Unit test for method uniform of class Random
def test_Random_uniform():
    for i in range(10):
        with pytest.raises(ValueError):
            rnd = Random()
            rnd.uniform(100, 1)
        with pytest.raises(ValueError):
            rnd = Random()
            rnd.uniform(1, 1)
        with pytest.raises(ValueError):
            rnd = Random()
            rnd.uniform(-1, -1)
        with pytest.raises(ValueError):
            rnd = Random()
            rnd.uniform(-1, 0)
        with pytest.raises(ValueError):
            rnd = Random()
            rnd.uniform(0, -1)

# Generated at 2022-06-23 21:55:15.701095
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    print(len(Random().urandom(4)))


# Generated at 2022-06-23 21:55:17.902090
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    result = rnd.randints(1, 6, 10)
    assert len(result) == 10

# Generated at 2022-06-23 21:55:19.237172
# Unit test for method urandom of class Random
def test_Random_urandom():
    rand = Random()
    rand.urandom(16)



# Generated at 2022-06-23 21:55:21.706049
# Unit test for method uniform of class Random
def test_Random_uniform():
    _random = Random()
    result = _random.uniform(1.1, 2.3)
    assert result >= 1.1
    assert result <= 2.3



# Generated at 2022-06-23 21:55:33.538942
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert 1.0 <= rnd.uniform(1, 2) < 2.0
    assert 1.0 <= rnd.uniform(1, 1.5) < 1.5
    assert 1.1 <= rnd.uniform(1.1, 1.2) < 1.2
    assert 0 <= rnd.uniform(0, 0.5) < 0.5
    assert 0 <= rnd.uniform(0.0, 0.5) < 0.5
    assert 0.5 <= rnd.uniform(0, 1) < 1
    assert 0.5 <= rnd.uniform(0, 1.0) < 1.0
    assert 1.5 <= rnd.uniform(1, 2.5) < 2.5

# Generated at 2022-06-23 21:55:40.505053
# Unit test for method randints of class Random
def test_Random_randints():
    class TestRandom(Random):
        def random(self):
            return 0.1

    test_random = TestRandom()
    assert test_random.randints() == [10, 10, 10]
    assert len(test_random.randints(amount=10)) == 10
    assert test_random.randints(amount=15, a=20, b=200) == [20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20]
    assert test_random.randints(a=20, b=200) == [20, 20, 20]


# Generated at 2022-06-23 21:55:42.669259
# Unit test for method randstr of class Random
def test_Random_randstr():
    s = random.randstr()
    assert isinstance(s, str), 'Method return not a str.'

# Generated at 2022-06-23 21:55:45.413563
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(), str)
    assert isinstance(random.randstr(unique=False), str)
    assert isinstance(random.randstr(unique=True), str)

# Generated at 2022-06-23 21:55:49.450540
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert Random().randstr(unique=True) != Random().randstr(unique=True)
    assert len(Random().randstr(unique=True)) == 32



# Generated at 2022-06-23 21:55:51.463333
# Unit test for method uniform of class Random
def test_Random_uniform():
    my_r = Random()
    my_r.uniform(.1, 1.2, precision=2)

# Generated at 2022-06-23 21:55:57.796107
# Unit test for method randints of class Random
def test_Random_randints():
    """Check correctness of function randints().

    :raise AssertionError: if randints() is failed.
    """
    my_rand = Random()
    amount = 3
    a, b = 1, 100
    assert len(my_rand.randints(amount=amount, a=a, b=b)) == amount
    try:
        my_rand.randints(amount=0, a=a, b=b)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-23 21:56:00.991456
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random_random = Random()
    value = random_random.generate_string()
    assert isinstance(value, str)
    assert len(value) == 10
    assert value[0] in string.ascii_letters + string.digits

# Generated at 2022-06-23 21:56:09.857622
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints()) == 3
    assert len(random.randints(5)) == 5
    assert len(random.randints(5, 1, 5)) == 5

    for _ in range(100):
        r = random.randints(5, 1, 5)
        assert isinstance(r, list)
        for i in r:
            assert 1 <= i <= 5

    for _ in range(100):
        r = random.randints(5, 0, 40)
        assert isinstance(r, list)
        for i in r:
            assert 0 <= i <= 40

# Generated at 2022-06-23 21:56:13.005067
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for the method urandom of class Random."""
    obj = Random()
    assert isinstance(obj.urandom(1000), bytes)



# Generated at 2022-06-23 21:56:22.340874
# Unit test for method randints of class Random
def test_Random_randints():
    _randints_1 = Random().randints()
    _randints_2 = Random().randints(1)

    _max = 100
    _randints_3 = Random().randints(amount=2, a=2, b=_max)
    _randints_4 = Random().randints(amount=4, a=-_max, b=_max)

    _floats = [float(i) for i in _randints_1]
    _floats += [float(i) for i in _randints_2]
    _floats += [float(i) for i in _randints_3]
    _floats += [float(i) for i in _randints_4]

    _max = max(_floats)
    _min = min(_floats)

    assert _max == 100

# Generated at 2022-06-23 21:56:31.113239
# Unit test for constructor of class Random
def test_Random():
    item = Random().randint(1, 16)
    assert isinstance(item, int)

    item = Random().randints(5)
    assert isinstance(item, list)
    assert len(item) == 5

    item = Random().urandom(16)
    assert isinstance(item, bytes)
    assert len(item) == 16

    item = Random().generate_string('abc123', 16)
    assert isinstance(item, str)
    assert len(item) == 16

    item = Random().custom_code('AAAA-####')
    assert isinstance(item, str)

    item = Random().uniform(100, 200)
    assert isinstance(item, float)
    assert item >= 100
    assert item <= 200

    item = Random().randstr(length=32)
    assert isinstance(item, str)

# Generated at 2022-06-23 21:56:34.751216
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test if method randstr generates unique value.
    
    """
    value_list = []
    for _ in range(10):
        value = Random().randstr(unique=True)
        value_list.append(value)
        assert value not in value_list

# Generated at 2022-06-23 21:56:37.121736
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3
    assert len(Random().randints(10)) == 10
    assert len(Random().randints(amount=50)) == 50
    assert len(Random().randints(a=1, b=10_000)) == 3



# Generated at 2022-06-23 21:56:44.336145
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random().urandom(10)) == 10
    assert len(Random().urandom(20)) == 20
    assert len(Random().urandom(50)) == 50
    assert len(Random().urandom(100)) == 100
    assert len(Random().urandom(1000)) == 1000
    assert len(Random().urandom(2000)) == 2000
    assert len(Random().urandom(5000)) == 5000
    assert len(Random().urandom(10000)) == 10000
test_Random_urandom()


# Generated at 2022-06-23 21:56:48.741750
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(random.custom_code('@@@')) == 3
    assert len(random.custom_code('@@@', '@', '#')) == 3
    assert len(random.custom_code('###')) == 3
    assert len(random.custom_code('###', '@', '#')) == 3

# Generated at 2022-06-23 21:56:51.510695
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(random.randstr()) == 36
    assert len(random.randstr(length=1)) == 1
    assert len(random.randstr(length=2)) == 2
    assert random.randstr(length=4) == '4' * 4

# Generated at 2022-06-23 21:56:52.447197
# Unit test for function get_random_item
def test_get_random_item():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-23 21:57:02.367666
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random.

    The test is a constructor of the class ``Random()``.
    The class is tested for choice method from ``random`` module of the
    standard library.

    """
    # Test Random
    assert Random().choice([0, 1, 2, 3, 4, 5]) in [0, 1, 2, 3, 4, 5]
    # Test randstr()
    assert isinstance(Random().randstr(), str)
    # Test generate_string()
    assert isinstance(Random().generate_string("a"), str)
    # Test custom_code()
    assert isinstance(Random().custom_code(), str)
    # Test uniform()
    assert isinstance(Random().uniform(1, 2), float)
    # Test randints()
    assert isinstance(Random().randints(), list)
   

# Generated at 2022-06-23 21:57:05.498697
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test method generate_string of class Random.

    :return: Nothing
    """
    str_ = random.generate_string('123')
    print(str_)
    assert len(str_) == 3

# Generated at 2022-06-23 21:57:08.412597
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    res = r.randints(amount=5)
    assert len(res) == 5, 'Error: size of the array of random numbers is not 5.'



# Generated at 2022-06-23 21:57:11.481214
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random"""
    output = random.uniform(1, 1.5)
    assert random_module.uniform(1, 1.5) <= output <= 1.5

# Generated at 2022-06-23 21:57:12.345600
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)

# Generated at 2022-06-23 21:57:13.015075
# Unit test for function get_random_item
def test_get_random_item():
    pass

# Generated at 2022-06-23 21:57:18.761307
# Unit test for method randints of class Random
def test_Random_randints():
    random_obj = Random()
    for x in range(10):
        for y in range(10):
            if (x < y):
                if random_obj.randints(a=x, b=y):
                    pass
            else:
                try:
                    random_obj.randints(a=x, b=y)
                except ValueError:
                    pass


# Generated at 2022-06-23 21:57:20.147375
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0, 1) < 1.0

# Generated at 2022-06-23 21:57:28.929922
# Unit test for method randstr of class Random
def test_Random_randstr():
    test_random = Random()

    test_random.seed(1)
    assert test_random.randstr() == 'NzcyMWM0NjNiNjg1ZjY5ZD'

    test_random.seed(2)
    assert test_random.randstr() == 'NzcyMWM0NjNiNjg1ZjY5ZD'

    test_random.seed(3)
    assert test_random.randstr() == 'NzcyMWM0NjNiNjg1ZjY5ZD'

    test_random.seed(4)
    assert test_random.randstr() == 'NzcyMWM0NjNiNjg1ZjY5ZD'

    test_random.seed(5)

# Generated at 2022-06-23 21:57:30.988587
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1, 5) == random.uniform(1, 5)
    # test of equality of numbers where the difference is less than 1e-15:
    assert random.uniform(1, 101) == random.uniform(1, 101)
    # test of inequality of numbers:
    assert random.uniform(1, 10.1) != random.uniform(1, 10.1)

# Generated at 2022-06-23 21:57:33.268325
# Unit test for method randstr of class Random
def test_Random_randstr():
    obj = Random(42)
    random_string = obj.randstr()
    assert isinstance(random_string, str)
    assert len(random_string) >= 16

# Generated at 2022-06-23 21:57:34.372868
# Unit test for constructor of class Random
def test_Random():
    assert Random()

if __name__ == '__main__':
    test_Random()

# Generated at 2022-06-23 21:57:38.417284
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    uniq_str = [random.randstr(True) for _ in range(1000)]
    assert len(uniq_str) == len(set(uniq_str))

# Generated at 2022-06-23 21:57:39.482701
# Unit test for constructor of class Random
def test_Random():
    assert Random()



# Generated at 2022-06-23 21:57:48.798463
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    for _ in range(10):
        assert -10 < rnd.uniform(-10, 10) < 10
        assert 0 <= rnd.uniform(0, 10) < 10
        assert 0 <= rnd.uniform(0, 10, precision=1) < 10
        assert 0 <= rnd.uniform(0, 10, precision=2) < 10
        assert 0 <= rnd.uniform(0, 10, precision=3) < 10
        assert 0 <= rnd.uniform(0, 10, precision=4) < 10
        assert 0 <= rnd.uniform(0, 10, precision=5) < 10
        assert 0 <= rnd.uniform(0, 10, precision=6) < 10

# Generated at 2022-06-23 21:57:57.315537
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method ``randints()``,
    raises value error if amount less or equal to zero.
    """
    _rand = random.Random()

    # return list[int]
    _ = _rand.randints()
    assert isinstance(_, list)
    assert isinstance(_[0], int)

    # return list[int]
    _ = _rand.randints(amount=3)
    assert isinstance(_, list)
    assert isinstance(_[0], int)

    # return list[int]
    _ = _rand.randints(amount=3, a=1, b=100)
    assert isinstance(_, list)
    assert isinstance(_[0], int)

    # ValueError if amount less or equal to zero

# Generated at 2022-06-23 21:58:00.190122
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Check whether method generate_string() works as expected."""
    result = Random().generate_string('qwerty', 6)
    assert len(result) == 6
    result = Random().generate_string('qwerty')
    assert len(result) == 10
    result = Random().generate_string('qwerty', 1)
    assert len(result) == 1
    assert len(Random().generate_string('qwerty', 0)) == 0


# Generated at 2022-06-23 21:58:03.146730
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    from mimesis.enums import CreditCard, Gender
    assert isinstance(get_random_item(CreditCard), CreditCard)
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 21:58:07.542502
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test the functionality of the method randstr."""
    _ = random.randstr(unique=False, length=32)
    assert isinstance(_, str)
    assert len(_) == 32

    _ = random.randstr()
    assert isinstance(_, str)
    assert len(_) in range(16, 128)

# Generated at 2022-06-23 21:58:09.199585
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code()
    assert isinstance(random.custom_code(), str)



# Generated at 2022-06-23 21:58:12.126064
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    for i in range(0,1000):
        test_str = rnd.randstr()
        assert(isinstance(test_str,str))
        assert(len(test_str) >= 16 and len(test_str) <= 128)

# Generated at 2022-06-23 21:58:15.406767
# Unit test for method randints of class Random
def test_Random_randints():
    number = Random().randints()
    assert number
    assert isinstance(number, list)
    assert len(number) == 3
    assert all(isinstance(n, int) for n in number)



# Generated at 2022-06-23 21:58:18.215394
# Unit test for function get_random_item
def test_get_random_item():
    """Test for get_random_item function."""
    from mimesis.enums import Gender

    result = get_random_item(Gender)
    assert isinstance(result, Gender)

# Generated at 2022-06-23 21:58:27.257037
# Unit test for method uniform of class Random
def test_Random_uniform():
    nums = {
        "0": 0.2,
        "1": 0.35,
        "2": 0.8,
        "3": 0.45,
        "4": 0.63,
        "5": 0.09,
        "6": 0.95,
        "7": 0.55,
        "8": 0.51,
        "9": 0.61,
    }
    for i in range(10):
        assert random.uniform(0, 1, 1) == nums[str(i)], \
            "Числа не равны: {} не равно {}".format(random.uniform(0, 1, 1), nums[str(i)])

# Generated at 2022-06-23 21:58:30.345550
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    print(rnd.custom_code())
    #print(rnd.custom_code('1234', '1', '2'))

# Generated at 2022-06-23 21:58:37.744405
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test randstr method of Random class."""
    random = Random()
    actual = random.randstr()
    assert isinstance(actual, str) and not actual.isdigit()

    actual = random.randstr(unique=True)
    assert isinstance(actual, str) and actual.isdigit()

    actual = random.randstr(length=5)
    assert isinstance(actual, str) and not actual.isdigit() and len(actual) == 5

    actual = random.randstr(length=5, unique=True)
    assert isinstance(actual, str) and actual.isdigit() and len(actual) == 32

# Generated at 2022-06-23 21:58:49.373861
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    # Check some random values
    assert len(str(random.uniform(1, 10000))) == 8
    assert isinstance(random.randstr(), str)
    assert isinstance(random.uuid4(), uuid.UUID)
    assert isinstance(random.randint(1, 10000), int)
    assert isinstance(random.choice(list(range(100))), int)
    assert isinstance(random.gauss(1, 10000), float)
    assert isinstance(random.select_random_element(), int)
    assert isinstance(random.random_element(), int)
    assert isinstance(random.randstr(length=64), str)
    assert len(random.randstr(length=64)) == 64

# Generated at 2022-06-23 21:58:58.919407
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform."""
    # import pytest
    # import numpy as np
    #
    # res = Random().uniform(0, 1)
    # assert isinstance(res, np.float64)
    # assert 0 <= res <= 1
    #
    # res = [Random().uniform(0, 1) for _ in range(100_000)]
    # res = np.array(res)
    # assert np.all(res >= 0) and np.all(res <= 1)
    #
    # res = Random().uniform(0, 1, precision=20)
    # assert isinstance(res, float)
    # assert 0 <= res <= 1
    #
    # with pytest.raises(ValueError) as exc_info:
    #     Random().uniform(1, 0, precision=20)

# Generated at 2022-06-23 21:59:02.488469
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    seed = Random().getrandbits(32)
    r = Random(seed)
    assert isinstance(r, Random)
    assert isinstance(r.seed(), int)

test_Random()

# Generated at 2022-06-23 21:59:06.021434
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _dict = {
        '@###_@': 'H677_O',
        '@###-@': 'G264-D',
    }
    for mask, code in _dict.items():
        custom_code = random.custom_code(mask=mask)
        assert code == custom_code, custom_code

# Generated at 2022-06-23 21:59:11.641937
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string(
        str_seq='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',
        length=10
    )
    assert len(Random().generate_string(
        str_seq='1234567890',
        length=10
    )) == 10



# Generated at 2022-06-23 21:59:14.179511
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    str_seq = string.ascii_uppercase + string.digits
    for i in range(100):
        assert len(r.generate_string(str_seq)) == 10
        assert all(x in str_seq for x in r.generate_string(str_seq))


# Generated at 2022-06-23 21:59:23.076606
# Unit test for function get_random_item
def test_get_random_item():
    import unittest
    from mimesis.data import (ALPHABET, LANGUAGES, MIMETYPES, OPERATING_SYSTEMS,
                              USER_AGENTS)
    from mimesis.enums import Currency, Gender, Language, MimeType, OperatingSystem, UserAgent

    class TestGetRandomItem(unittest.TestCase):
        """Tests for the function get_random_item()."""

        def test_get_random_item_with_rnd(self):
            """Check if get_random_item() works fine."""
            r = random.Random()
            value = get_random_item(OPERATING_SYSTEMS, rnd=r)
            self.assertIsInstance(value, OperatingSystem)

            value = get_random_item(LANGUAGES, rnd=r)

# Generated at 2022-06-23 21:59:27.005344
# Unit test for method randints of class Random
def test_Random_randints():
    rand_obj = Random()

    rand_ints_single_value = rand_obj.randints(3)
    assert len(rand_ints_single_value) == 3

    rand_ints_range_value = rand_obj.randints(5, 1, 1000)
    assert len(rand_ints_range_value) == 5

    rand_ints_wrong_amount = rand_obj.randints(0)
    assert 0 not in rand_ints_wrong_amount



# Generated at 2022-06-23 21:59:30.574635
# Unit test for method urandom of class Random
def test_Random_urandom():
    size = 64
    assert len(random.urandom(size)) == size
    assert len(Random.urandom(size)) == size
    assert type(random.urandom(size)) == bytes

# Generated at 2022-06-23 21:59:32.930730
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _code = random.custom_code()
    assert len(_code) == 4
    assert isinstance(_code, str)
    assert _code.upper() == _code



# Generated at 2022-06-23 21:59:35.823201
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string("ABCDEF")) == 10
    assert len(Random().generate_string("ABCDEF", 0)) == 0
    assert len(Random().generate_string("ABCDEF", 5)) == 5
    assert len(Random().generate_string("ABCDEF", 1000)) == 1000


# Generated at 2022-06-23 21:59:38.365201
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    generated_value = rnd.randstr(unique=True)
    assert isinstance(generated_value, str) is True

# Generated at 2022-06-23 21:59:38.907737
# Unit test for method randints of class Random
def test_Random_randints():
    pass

# Generated at 2022-06-23 21:59:40.695877
# Unit test for constructor of class Random
def test_Random():
    """Unit test for class Random."""
    rnd = Random()
    assert rnd.seed(0) == None



# Generated at 2022-06-23 21:59:41.923218
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert type(Random().urandom(1)) == bytes

# Generated at 2022-06-23 21:59:47.822128
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    for __ in range(100):
        assert len(random.generate_string(string.ascii_letters, 7)) == 7
        assert len(random.generate_string(string.digits, 5)) == 5
        assert len(random.generate_string(string.ascii_letters + string.digits, 11)) == 11

# Generated at 2022-06-23 21:59:54.894433
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    from mimesis.enums import Transport
    from mimesis.enums import UnitSystem
    from mimesis import random
    """Test get_random_item()"""
    assert isinstance(get_random_item(Gender), Gender)
    assert isinstance(get_random_item(Transport), Transport)
    assert isinstance(get_random_item(UnitSystem), UnitSystem)
    assert isinstance(get_random_item(Gender, random), Gender)

# Generated at 2022-06-23 22:00:02.870257
# Unit test for constructor of class Random
def test_Random():
    """Tests for random module."""
    base = 9
    upper = 17
    r = random.randint(base, upper)
    assert base <= r <= upper

    base = 9.0
    upper = 17.0
    r = random.uniform(base, upper)
    assert base <= r <= upper

    items = [1, 2, 3]
    r = random.choice(items)
    assert r in items

    n = 10
    items = [random.randint(1, 20) for _ in range(n)]
    r = random.sample(items, n)
    assert len(r) == n

    items = [1, 2, 3]
    random.shuffle(items)
    assert items != [1, 2, 3]

# Generated at 2022-06-23 22:00:04.380883
# Unit test for method randstr of class Random
def test_Random_randstr():
    res = Random().randstr()
    assert len(res) <= 128

# Generated at 2022-06-23 22:00:11.262674
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method ``randstr`` of class ``Random``."""

    class UniqueString:

        def __init__(self, rnd: Optional[Random] = None) -> None:
            self.rnd = rnd or Random()
            self.unique_string = self.rnd.randstr(unique=True)

    uniques_strings = [UniqueString() for _ in range(1000)]
    assert len(set(x.unique_string for x in uniques_strings)) == \
        len(uniques_strings)

# Generated at 2022-06-23 22:00:19.571510
# Unit test for constructor of class Random
def test_Random():
    rand = Random()
    rand.randint(5, 5)
    rand.randint(5, 7)
    rand.randint(7, 5)
    rand.randints(3, 1, 100)
    rand.randint(3)
    rand.uniform(3, 5)
    rand.randstr(True)
    rand.randstr()
    rand.randstr(length=10)
    rand.custom_code()
    rand.random()
    rand.getstate()
    rand.setstate((3, (3,)))
    rand.seed()


# Generated at 2022-06-23 22:00:21.299171
# Unit test for function get_random_item
def test_get_random_item():
    _random = Random()
    assert _random.choice(list(random.Enum))



# Generated at 2022-06-23 22:00:22.582326
# Unit test for constructor of class Random
def test_Random():
    my_instance = Random()
    assert isinstance(my_instance, Random)

# Generated at 2022-06-23 22:00:23.811665
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random), Random)

# Generated at 2022-06-23 22:00:28.570544
# Unit test for function get_random_item
def test_get_random_item():
    """Test for getting random items.
    :return:
    """
    from . import enums

    item = get_random_item(enum=enums.Bool)
    assert isinstance(item, enums.Bool)

    item = get_random_item(
        enum=enums.Bool,
        rnd=None
    )
    assert isinstance(item, enums.Bool)

    item = get_random_item(
        enum=enums.Bool,
        rnd=random
    )
    assert isinstance(item, enums.Bool)

# Generated at 2022-06-23 22:00:32.724601
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(Random().randstr()) == 32
    assert len(Random().randstr(length=10)) == 10
    assert len(Random().randstr(length=10, unique=True)) == 10

# Generated at 2022-06-23 22:00:42.136743
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert isinstance(random.custom_code(), str)
    assert isinstance(random.custom_code(mask='@'), str)
    assert isinstance(random.custom_code(mask='@@'), str)
    assert isinstance(random.custom_code(mask='@@@'), str)
    assert isinstance(random.custom_code(mask='@@##'), str)
    assert isinstance(random.custom_code(mask='@@@@@@@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#@#'), str)
    assert isinstance(random.custom_code(length=1), str)
    assert isinstance(random.custom_code(length=2), str)
    assert isinstance(random.custom_code(length=10), str)
    assert isinstance(random.custom_code(length=16), str)


# Generated at 2022-06-23 22:00:52.021078
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random.custom_code(Random(), mask='@@@') in ['AAA', 'BBB']
    assert Random.custom_code(Random(), mask='@@@###') in ['AAA000', 'BBB000']
    assert Random.custom_code(Random(), mask='@@@###', digit='*') in ['AAA***', 'BBB***']
    assert Random.custom_code(Random(), mask='@@@###', digit = '*') in ['AAA***', 'BBB***']
    assert Random.custom_code(Random(), mask='@@@###', char = 'A') in ['AAA000', 'BBB000']
    assert Random.custom_code(Random(), mask='@@@###', char = 'A', digit='*') in ['AAA***', 'BBB***']

# Generated at 2022-06-23 22:00:55.112126
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random.
    """
    rnd_test = Random()
    assert isinstance(rnd_test, Random)

# Generated at 2022-06-23 22:01:03.936545
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    assert all(
        len(Random().generate_string(str_seq=string.ascii_letters,
                                     length=10)) == 10
        for _ in range(1000)
    )
    assert all(
        len(Random().generate_string(str_seq=string.ascii_letters,
                                     length=20)) == 20
        for _ in range(1000)
    )
    assert all(
        len(Random().generate_string(str_seq=string.digits,
                                     length=10)) == 10
        for _ in range(1000)
    )

# Generated at 2022-06-23 22:01:06.493342
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function ``get_random_item()``."""
    from mimesis.enums import Gender

    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 22:01:14.210544
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Method custom_code of class Random should return random code
    with a given mask.

    :return: random code
    :raises ValueError: if char_code == digit_code
    """
    mask = '@###'
    char = '@'
    digit = '#'

    char_code = ord(char)
    digit_code = ord(digit)

    if char_code == digit_code:
        raise ValueError('You cannot use the same '
                         'placeholder for digits and chars!')

    def random_int(a, b):
        b = b - a
        return int(random.random() * b) + a

    _mask = mask.encode()
    code = bytearray(len(_mask))

# Generated at 2022-06-23 22:01:19.271387
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)
    assert isinstance(r, random_module.Random)
    assert isinstance(r, random.Random)
    assert isinstance(r.uniform(1, 2), float)
    assert len(r.randints(3)) == 3
    assert r.generate_string('123')
    assert r.custom_code()
    assert r.custom_code(mask='@@###@')
    assert r.custom_code(mask='#####@')
    assert r.custom_code(mask='@#@#@#')
    assert r.custom_code(mask='@##')
    assert r.custom_code(mask='###', char='#')
    assert r.custom_code(mask='#@#', char='#')

# Generated at 2022-06-23 22:01:24.185771
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import OperatingSystem

    rand_os_1 = get_random_item(OperatingSystem, None)
    rand_os_2 = get_random_item(OperatingSystem, random)

    assert isinstance(rand_os_1, str)
    assert isinstance(rand_os_2, str)
    assert rand_os_1 != rand_os_2


# Generated at 2022-06-23 22:01:28.462403
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    str_seq = 'hello world!'
    test_str = random.generate_string(str_seq, length = 10)
    assert len(test_str) == 10
    for letter in test_str:
        assert letter in str_seq


# Generated at 2022-06-23 22:01:36.140170
# Unit test for function get_random_item
def test_get_random_item():
    class Animal(enum.Enum):
        Cat = 'cat'
        Dog = 'dog'
        Mouse = 'mouse'
        Elephant = 'elephant'

    class Status(enum.Enum):
        Grey = 'grey'
        Yellow = 'yellow'
        Green = 'green'
        Blue = 'blue'

    class Language(enum.Enum):
        Python = 'python'
        Ruby = 'ruby'
        Go = 'go'
        R = 'r'

    non_fixed = random.choice([Animal, Status, Language])
    non_fixed_data = get_random_item(non_fixed)
    assert non_fixed_data in list(non_fixed)

    fixed_animal = get_random_item(Animal)
    assert fixed_animal in list(Animal)

    fixed_status = get_random_item