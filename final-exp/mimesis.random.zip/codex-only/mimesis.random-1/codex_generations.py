

# Generated at 2022-06-23 21:51:32.579594
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    rnd.seed(5)
    assert rnd.generate_string(string.digits, 10) == '1296779320'
    assert rnd.generate_string(string.ascii_lowercase, 100) == 'qyepwvtmztqmsiidgfbzanuvpfxxppxheklrjgizlugrzmhvwvfjrvbewmfgkby'
    rnd.seed(7)
    assert rnd.generate_string(string.ascii_uppercase, 15) == 'XHDXHQFVNOKIXGU'



# Generated at 2022-06-23 21:51:41.854742
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random = Random()
    test_str = random.generate_string("QWERTYU12345")
    assert len(test_str) == 10
    assert test_str[0] in "QWERTYU12345"
    assert test_str[1] in "QWERTYU12345"
    assert test_str[2] in "QWERTYU12345"
    assert test_str[3] in "QWERTYU12345"
    assert test_str[4] in "QWERTYU12345"
    assert test_str[5] in "QWERTYU12345"
    assert test_str[6] in "QWERTYU12345"
    assert test_str[7] in "QWERTYU12345"
    assert test_str[8] in "QWERTYU12345"


# Generated at 2022-06-23 21:51:50.031896
# Unit test for function get_random_item
def test_get_random_item():
    import unittest
    import enum

    class CustomEnum(enum.Enum):
        """Example of custom enum."""

        RUB = 'RUB'
        USD = 'USD'
        EUR = 'EUR'

    class TestGetRandomItem(unittest.TestCase):
        """Testing methods of the class TestGetRandomItem."""

        def test_get_random_item(self):
            """Test for get_random_item()."""
            result = get_random_item(CustomEnum)
            assert result in CustomEnum

    unittest.main()

# Generated at 2022-06-23 21:51:53.203697
# Unit test for function get_random_item
def test_get_random_item():
    class E(enum.Enum):
        A = 'a'
        B = 'b'
        C = 'c'

        def __str__(self):
            return self.value

    assert get_random_item(E) in E

# Generated at 2022-06-23 21:51:55.078792
# Unit test for method urandom of class Random
def test_Random_urandom():
    byte_ = Random.urandom(10)
    assert isinstance(byte_, bytes)
    assert len(byte_) == 10



# Generated at 2022-06-23 21:51:57.091998
# Unit test for method urandom of class Random
def test_Random_urandom():
    random = Random()
    strings = random.urandom(100)
    assert len(strings) == 100
    assert type(strings) is bytes

# Generated at 2022-06-23 21:52:06.598592
# Unit test for function get_random_item
def test_get_random_item():
    """Test get_random_item()."""
    # pylint: disable=unused-import
    from mimesis.enums import CustomEnum

    class Enum(CustomEnum):
        """Unit test."""

        ITEM_1 = 1
        ITEM_2 = 2

    class Enum2(Enum):
        """Unit test."""

        ITEM_3 = 3

    enum_item = get_random_item(Enum)
    assert enum_item in [1, 2]

    enum_item = get_random_item(Enum2)
    assert enum_item in [1, 2, 3]

# Generated at 2022-06-23 21:52:08.328115
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 21:52:09.732041
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random().urandom(), bytes)

# Generated at 2022-06-23 21:52:14.185151
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    result = r.custom_code("@###")
    assert len(result) == 4
    assert type(result) == str
    assert result[0] in string.ascii_letters
    assert result[1:] in string.digits

# Generated at 2022-06-23 21:52:20.653207
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random(123)
    assert rnd.custom_code(mask='@###', char='@', digit="#") == "R187"
    assert rnd.custom_code(mask='@###', char='#', digit="@") == "J816"
    assert rnd.custom_code(mask='@###', char='@', digit="@") == "J816"
    assert rnd.custom_code(mask='@###', char='#', digit="#") == "R187"
    assert rnd.custom_code(mask="@###") == "R187"
    assert rnd.custom_code("@###", char="#", digit="@") == "J816"
    assert rnd.custom_code("@###", char="@") == "R187"

# Generated at 2022-06-23 21:52:24.008023
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    some_dict = dict()

    for i in range(1000):
        code = random.custom_code('@###')
        assert len(code) == 4
        some_dict[code] = 1

    assert len(some_dict) is 1000

# Generated at 2022-06-23 21:52:28.348511
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Tests method custom_code."""
    rnd = Random()
    res = rnd.custom_code(mask='@@@ ###', char='@', digit='#')
    assert type(res) is str and res.isalnum()


if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-23 21:52:32.381243
# Unit test for method randstr of class Random
def test_Random_randstr():
    values_set = set()
    for i in range(100):
        test = random.randstr()
        val = values_set.add(test)
        assert val is not None
        assert len(values_set) == i + 1

# Generated at 2022-06-23 21:52:35.135090
# Unit test for method randints of class Random
def test_Random_randints():
    arr = Random().randints(3, 1, 7)
    assert len(arr) == 3
    for i in arr:
        assert i <= 7
        assert i >= 1


# Generated at 2022-06-23 21:52:38.761122
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Testing method to urandom."""
    _value = Random.urandom(32)
    assert isinstance(_value, bytes)
    assert len(_value) == 32



# Generated at 2022-06-23 21:52:43.900413
# Unit test for method uniform of class Random
def test_Random_uniform():
    from datetime import datetime
    start_time = datetime.now()

    a = 0
    b = 1.42
    for _ in range(1000000):
        random.uniform(a, b)

    end_time = datetime.now()
    total_time = (end_time - start_time).microseconds

    print(f'Uniform time: {total_time / 1000} ms')



# Generated at 2022-06-23 21:52:53.784462
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    random._setstate((random.VERSION, random.MT, random.index))
    random.setstate((1, (1,), 0))
    a = random.custom_code(mask='@@@@@###')
    assert(len(a) == 9)
    assert(a[:5].isalpha())
    assert(a[5:].isnumeric())

    a = random.custom_code(mask='@@@@@@@@@@@@@@@@@@@@@@###')
    assert(len(a) == 31)
    assert(a[:31].isalpha())


# Generated at 2022-06-23 21:53:01.343380
# Unit test for function get_random_item
def test_get_random_item():
    # Define an enum
    class SampleEnum(Enum):
        a = 'a'
        c = 'c'
        b = 'b'
        d = 'd'
    enum = SampleEnum
    # Get random item of enum
    assert get_random_item(enum) in list(enum)
    # Get random item of enum using custom random object
    random_object = Random()
    assert get_random_item(enum, rnd=random_object) in list(enum)

# Generated at 2022-06-23 21:53:02.907908
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert r.seed(1) == None


# Generated at 2022-06-23 21:53:10.166315
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert(Random().custom_code('ab##') == 'a0##')
    assert(Random().custom_code('@##') == '@##')
    assert(Random().custom_code('@@#') == '@@9')
    assert(Random().custom_code('@###', '&') == '&&##')
    assert(Random().custom_code('@###', '&', '$') == '&$##')
    assert(Random().custom_code('@###', '&', '$') != '&$$#')



# Generated at 2022-06-23 21:53:11.440693
# Unit test for constructor of class Random
def test_Random():
    obj = Random()
    assert isinstance(obj, Random)

# Generated at 2022-06-23 21:53:22.628350
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    result = random.custom_code('$@@@', '@', '$')
    assert len(result) == 4
    assert result[0].isnumeric() is True
    assert result[1].isalpha() is True
    assert result[2].isalpha() is True
    assert result[3].isalpha() is True
    assert result[0] in '0123456789'
    assert result[1] in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert result[2] in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert result[3] in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert isinstance(result, str) is True

# Generated at 2022-06-23 21:53:27.889301
# Unit test for method randints of class Random
def test_Random_randints():
    random = Random()
    assert len(random.randints()) == 3
    assert len(random.randints(10)) == 10
    assert len(random.randints(10, 100, 200)) == 10
    assert random.randints(10, 100, 200)[0] >= 100
    assert random.randints(10, 100, 200)[0] <= 200
    assert set(random.randints(3, 1, 2)) == {1, 2}

# Generated at 2022-06-23 21:53:31.274826
# Unit test for method randints of class Random
def test_Random_randints():
    # You can test with this method any other of the methods of this class
    assert len(Random(42).randints(2, 2, 6)) == 2
    assert Random(42).randints(2, 2, 6) == [3, 5]
    assert Random(42).randints(2, 2, 3) == [2, 2]

# Generated at 2022-06-23 21:53:35.972879
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert isinstance(random.generate_string(
        'abcdefghijklmnopqrstuvyxwz'
    ), str) == True
    assert isinstance(random.generate_string(
        '0123456789'
    ), str) == True


# Generated at 2022-06-23 21:53:40.099122
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string('X', 3) == 'XXX'
    assert Random().generate_string('01', 10) == '0101010101'
    assert Random().generate_string('abcdefghijklmnopqrstuvwxyz', 10) == 'zyxwvutsrqp'


# Generated at 2022-06-23 21:53:44.072918
# Unit test for function get_random_item
def test_get_random_item():
    """Testing function get_random_item."""
    assert get_random_item('my_string')
    assert get_random_item(1)
    assert get_random_item(1.0)


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-23 21:53:46.354941
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    assert Random.urandom(1000)

# Generated at 2022-06-23 21:53:48.007602
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(enum=random, rnd=random) == random

# Generated at 2022-06-23 21:53:53.213450
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    for _ in range(1):
        assert len(Random().generate_string('abcdefghijklmnopqrstuvwxyz')) == 10
        assert len(Random().generate_string('abcdefghijklmnopqrstuvwxyz', 20)) == 20


# Generated at 2022-06-23 21:53:58.569527
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    c_code = random.custom_code()
    assert len(c_code) == 4
    assert c_code[:1].isalpha() and c_code[1:].isdigit()

    c_code2 = random.custom_code(mask='@@####', digit='#')
    assert len(c_code2) == 6
    assert c_code2[:2].isalpha() and c_code2[2:].isdigit()



# Generated at 2022-06-23 21:54:03.443111
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    _random = Random()
    string_digits = '0123456789'
    string_letters = 'abcdefghijklmnopqrstuvwxyz'
    string_letters_and_digits = string_letters + string_digits
    assert len(_random.generate_string(string_digits)) == 10
    assert len(_random.generate_string(string_letters)) == 10
    assert len(_random.generate_string(string_letters_and_digits)) == 10


# Generated at 2022-06-23 21:54:10.036218
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    r.seed(123456)

    # Expected required output
    expected = 2.7290514120327997
    # Setting precision variable
    precision = 15

    # Result of method is called
    result = r.uniform(1.1, 4, precision)

    # Testing
    assert result == expected

# Generated at 2022-06-23 21:54:17.608644
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random"""
    random_generator = Random(42)
    random_generator2 = Random(2**63)
    random_generator3 = Random(2**64)
    random_generator4 = Random(2**127)
    random_generator5 = Random(2**128)
    random_generator6 = Random(2**129)
    random_generator7 = Random(3.14)
    random_generator8 = Random(float('inf'))
    random_generator9 = Random(str)
    random_generator10 = Random(list)
    random_generator11 = Random(dict)

# Generated at 2022-06-23 21:54:19.820491
# Unit test for method uniform of class Random
def test_Random_uniform():
    for _ in range(10):
        c = random.uniform(0.10, 0.15)
        assert 0.10 < c < 0.15

# Generated at 2022-06-23 21:54:24.693625
# Unit test for method uniform of class Random
def test_Random_uniform():
    _rnd = random_module.Random(seed=1)
    _rnd.seed(1)
    _rnd.random()
    assert _rnd.uniform(1.005, 1.009) == 1.005027785938857



# Generated at 2022-06-23 21:54:29.832620
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    pass
    # mask = '@#@#@#@#'
    # char = '@'
    # digit = '#'
    # rnd = Random()
    #
    # for _ in range(100):
    #     code = rnd.custom_code(mask, char, digit)
    #     assert re.fullmatch(mask, code)

    # mask = '@ @ @ #'
    # char = '@'
    # digit = '#'
    # rnd = Random()
    #
    # for _ in range(100):
    #     code = rnd.custom_code(mask, char, digit)
    #     assert re.fullmatch(mask, code)

# Generated at 2022-06-23 21:54:30.631480
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert isinstance(rnd.random(), float)



# Generated at 2022-06-23 21:54:31.253866
# Unit test for method urandom of class Random
def test_Random_urandom():
    Random().urandom(1)


# Generated at 2022-06-23 21:54:34.485615
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    assert len(random.randstr()) == 32
    assert random.randstr(length=32)
    assert len(random.randstr(length=32)) == 32

# Generated at 2022-06-23 21:54:37.151540
# Unit test for method randints of class Random
def test_Random_randints():
    # Test for exception
    _ = Random().randints(a=-5, b=5, amount=5)



# Generated at 2022-06-23 21:54:39.913103
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random) is True, 'Not constructor of class Random'

# Generated at 2022-06-23 21:54:44.431617
# Unit test for method randints of class Random
def test_Random_randints():
    amount = 3
    a = 1
    b = 100
    rand_obj = Random()
    result = [1, 16, 83]
    assert rand_obj.randints(amount) == result
    assert rand_obj.randints(amount, a) == result
    assert rand_obj.randints(amount, a, b) == result



# Generated at 2022-06-23 21:54:52.273554
# Unit test for function get_random_item
def test_get_random_item():
    """Test for function get_random_item."""
    class DummyEnum(object):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            self.__dict__.update(kwargs)

        def __getitem__(self, key: Any) -> Any:
            return self.__dict__[key]

        def __iter__(self) -> Any:
            return iter(self.__dict__)

    DUMMY_ENUM = DummyEnum(
        a=0,
        b=1,
        c=2,
        d=3,
        e=4,
        f=5
    )

    _item = get_random_item(DUMMY_ENUM, random)

    assert isinstance(_item, int)

# Generated at 2022-06-23 21:54:54.526266
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = '@                    '
    my_random = Random()
    my_random.custom_code(mask=mask)

# Generated at 2022-06-23 21:54:58.030683
# Unit test for constructor of class Random
def test_Random():
    r = Random(1)
    assert isinstance(r, Random)
    assert r.random() == 0.13436424411240122
    assert r.uniform(1, 10) == 5.395641247668913


if __name__ == '__main__':
    test_Random()

# Generated at 2022-06-23 21:55:01.317289
# Unit test for method randstr of class Random
def test_Random_randstr():
    length = random.randint(16, 128)
    string = random.randstr(False, length)

    assert isinstance(string, str)
    assert len(string) == length

# Generated at 2022-06-23 21:55:04.057252
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    for digit in (1,):
        assert len(Random().generate_string('ABC', digit)) == digit



# Generated at 2022-06-23 21:55:08.071475
# Unit test for constructor of class Random
def test_Random():

    assert isinstance(random, Random)
    assert isinstance(random.generate_string('123456789', 10), str)
    assert isinstance(random.custom_code('@###', '@', '#'), str)
    assert isinstance(random.uniform(1.0, 2.0), float)
    assert isinstance(random.randstr(), str)
    assert isinstance(random.randints(), List)
    assert len(random.randints()) == 3
    assert isinstance(random.urandom(), bytes)


# Generated at 2022-06-23 21:55:09.715600
# Unit test for method urandom of class Random
def test_Random_urandom():
    random_bytes = random.urandom(16)
    assert random_bytes


# Generated at 2022-06-23 21:55:12.708848
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert random.randstr()
    assert random.randstr(length=32)
    assert random.randstr(length=32, unique=True)

# Generated at 2022-06-23 21:55:22.089005
# Unit test for constructor of class Random
def test_Random():
    # pylint: disable=no-member
    obj = Random()
    assert isinstance(obj.randints(), list)
    assert isinstance(obj.randints(5, 1, 10), list)
    assert obj.randints(5, 10, 1) == []
    assert obj.randints(0, 1, 10) == []
    assert obj.randints(-1, 1, 10) == []
    assert isinstance(obj.generate_string('@'), str)
    assert obj.generate_string('@', 0) == ''
    assert obj.generate_string('@', -1) == ''
    assert isinstance(obj.generate_string('@', 10), str)
    assert isinstance(obj.randstr(), str)
    assert len(obj.randstr()) >= 16

# Generated at 2022-06-23 21:55:33.984247
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum
    # test enum
    class TestEnum(Enum):
        ONE = 1
        TWO = 2
        THREE = 3

    # Create instance of random
    rnd = Random()

    # get random value from TestEnum
    tt = get_random_item(TestEnum, rnd)

    # check is TestEnum.ONE
    assert isinstance(tt, TestEnum)

    # get random value from TestEnum
    tt = get_random_item(TestEnum)

    # check is TestEnum.ONE
    assert isinstance(tt, TestEnum)

    # get random value from TestEnum
    tt = random.choice(list(TestEnum))

    # check is TestEnum.ONE
    assert isinstance(tt, TestEnum)

    # get random

# Generated at 2022-06-23 21:55:40.054815
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random.

    Methods tested:
        - generate_string

    Bugs:
        - https://github.com/lk-geimfari/mimesis/issues/40

    """
    result = Random().generate_string('abcdef', 5)
    assert len(result) == 5
    assert all(c in 'abcdef' for c in result)
    assert all(not c in '123456789' for c in result)



# Generated at 2022-06-23 21:55:47.422900
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    l = rnd.randints(1, 10, 20)
    assert len(l) == 1
    assert l[0] <= 20
    assert l[0] >= 10
    assert l[0].__class__ is int
    l = rnd.randints(10, 10, 20)
    assert len(l) == 10
    assert l[0] <= 20
    assert l[0] >= 10
    assert l[0].__class__ is int
    assert rnd.randints(2, 3, 4) == [3, 3]
    assert rnd.randints(0) == []



# Generated at 2022-06-23 21:55:57.376533
# Unit test for method randints of class Random
def test_Random_randints():
    input_data = [
        {
            'amount': 1,
            'a': 1,
            'b': 100,
            'expectation': [1]
        },
        {
            'amount': 2,
            'a': 1,
            'b': 10,
            'expectation': [1, 9]
        },
        {
            'amount': 6,
            'a': 1,
            'b': 10,
            'expectation': [8, 9, 8, 8, 2, 9]
        },
        {
            'amount': 0,
            'a': 1,
            'b': 10,
            'expectation': None
        }
    ]

    for data in input_data:
        rnd = Random()
        rnd.seed(5)

# Generated at 2022-06-23 21:56:02.738644
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints(10, 9, 1)) == 10
    assert all(Random().randints(1, 5, 1) == [1])
    assert all(Random().randints(10, 1, 6) == [1, 1, 1, 1, 1, 1, 1, 1, 1, 1])

    res = list(Random(9).randints(10, 9, 1))  # This seed always gives [1]
    assert 9 in res



# Generated at 2022-06-23 21:56:13.731862
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    rnd.seed(100)
    _ = rnd.randints(1)
    assert _ == [97]
    _ = rnd.randints(amount=2)
    assert _ == [95, 96]
    _ = rnd.randints(amount=3, a=0, b=10)
    assert _ == [4, 4, 3]
    _ = rnd.randints(amount=4, a=0, b=10)
    assert _ == [1, 5, 4, 6]
    _ = rnd.randints(amount=5, a=0, b=10)
    assert _ == [7, 6, 5, 1, 6]


# Generated at 2022-06-23 21:56:19.570850
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test random generate string class method."""
    random_class_instance = Random()
    generated_string = random_class_instance.generate_string('abcdefghij')
    assert generated_string != random_class_instance.generate_string('abcdefghij')
    assert isinstance(generated_string, str)
    assert len(generated_string) == 10
    assert all(i in generated_string for i in 'abcdefghij')



# Generated at 2022-06-23 21:56:25.725637
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum
    from decimal import Decimal

    class Nums(Enum):
        a = 1
        b = 2
        c = 3

    a = get_random_item(Nums)
    assert isinstance(a, Nums)
    assert isinstance(a.value, int)
    assert a is not Nums.a
    

    assert get_random_item(Nums, rnd=random) is not None

# Generated at 2022-06-23 21:56:30.726437
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0.0, 1.0, 4) == 0.0
    assert random.uniform(1.0, 0.0, 4) == 0.0
    assert random.uniform(0.0, 0.1, 2) == 0.0
    assert random.uniform(1.0, 0.5, 2) == 0.5
    assert random.uniform(0.5, 0.5, 2) == 0.5
    assert random.uniform(0.0, 0.0, 2) == 0.0
    assert random.uniform(1.0, 1.0, 2) == 1.0

# Generated at 2022-06-23 21:56:33.817266
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    random_ints = r.randints(amount=3, a=1, b=100)
    assert random_ints == [r.randint(a=1, b=100) for _ in range(3)]
    assert isinstance(random_ints, list)
    assert isinstance(random_ints[0], int)
    assert isinstance(random_ints[1], int)
    assert isinstance(random_ints[2], int)

# Generated at 2022-06-23 21:56:41.377048
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method Random.randints()."""
    rnd = Random()
    try:
        rnd.randints(amount=0, a=1, b=10)
    except ValueError:
        pass
    else:
        raise AssertionError('Amount cannot be less or equal to zero!')

    res = rnd.randints(amount=1, a=1, b=10)
    assert isinstance(res, list)

    res = rnd.randints(amount=10, a=1, b=1)
    for i in res:
        assert i == 1

    answers = [10, 44, 53, 62, 86, 40, 63, 12, 87, 62]
    res = rnd.randints(10, 10, 100)
    assert res == answers

# Generated at 2022-06-23 21:56:47.419037
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum

    class E(Enum):
        A = 'foo'
        B = 'bar'
        C = 'baz'

    actual = get_random_item(E)

    assert actual in E
    assert actual.name in ('A', 'B', 'C')
    assert actual.value in ('foo', 'bar', 'baz')

# Generated at 2022-06-23 21:56:51.797935
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    class TestArgs:
        def __init__(self):
            self.str_seq = '0123456789'
            self.length = 5
        def __iter__(self):
            return iter([self.str_seq, self.length])
    test_args = TestArgs()
    rnd = Random()
    assert len(rnd.generate_string(*test_args)) == test_args.length
    assert rnd.generate_string(*test_args).isdigit() == True


# Generated at 2022-06-23 21:56:53.347864
# Unit test for method urandom of class Random
def test_Random_urandom():
    for _ in range(1000):
        assert len(Random().urandom(1000)) == 1000

# Generated at 2022-06-23 21:56:58.080178
# Unit test for method randstr of class Random
def test_Random_randstr():
    _length = random.randint(16, 128)
    _randstr = random.randstr(length=_length)
    assert len(_randstr) == _length, (
        f'Random string does not match the length'
    )
    assert type(_randstr) is str, (
        f'Random string is not of str type'
    )

# Generated at 2022-06-23 21:57:00.634792
# Unit test for constructor of class Random
def test_Random():
    assert Random().position_picker()
    assert Random().position_picker()
    assert Random().position_picker()
    assert Random().choice([1, 2, 3])
    assert Random().choice([1, 2, 3])
    assert Random().choice([1, 2, 3])


# Generated at 2022-06-23 21:57:03.652528
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    random = Random()
    assert isinstance(get_random_item(Gender.GENDERS, rnd=random), Gender),\
        'get_random_item() failed.'

# Generated at 2022-06-23 21:57:06.142928
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    class Demo(enum.Enum):
        A = 'a'
        B = 'b'
    assert get_random_item(Demo) in list(Demo)

# Generated at 2022-06-23 21:57:07.749796
# Unit test for constructor of class Random
def test_Random():
    obj = Random()
    assert isinstance(obj, Random)
    assert isinstance(obj, random_module.Random)

# Generated at 2022-06-23 21:57:18.662426
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    def compare_fn(mask, char, digit, length):
        r = Random()
        code = r.custom_code(mask, char, digit)

        for s in code:
            ords = ord(s)
            assert (65 <= ords <= 90) or (48 <= ords <= 57)
        assert len(code) == length
        return code
    assert compare_fn('@@0@@@', '@', '0', 6)
    assert compare_fn('@@A@@@', '@', 'A', 6)
    assert compare_fn('000', '0', '0', 3)
    assert compare_fn('AAA', 'A', 'A', 3)
    assert compare_fn('0A0', '0', 'A', 3)
    assert compare_fn('00', '0', '0', 2)
    assert compare

# Generated at 2022-06-23 21:57:23.488040
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    rnd = Random()
    assert isinstance(rnd, Random)

    for _ in range(100):
        amount = rnd.randint(16, 128)
        assert len(rnd.randstr(unique=True)) == amount



# Generated at 2022-06-23 21:57:28.445570
# Unit test for method randstr of class Random
def test_Random_randstr():
    # test for len of string
    for length in range(16, 128):
        _str = random.randstr(length=length)
        assert len(_str) == length

    # test for uniqueness
    _str1 = random.randstr(unique=True)
    _str2 = random.randstr(unique=True)
    assert _str1 != _str2

# Generated at 2022-06-23 21:57:32.937962
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3
    assert len(Random().randints(amount=5)) == 5
    assert len(Random().randints(a=1, b=10)) == 3
    assert len(Random().randints(amount=8, a=10, b=20)) == 8

# Generated at 2022-06-23 21:57:35.220392
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert type(random.generate_string(str_seq='qwerty',
                                       length=10)) == str

# Generated at 2022-06-23 21:57:38.790162
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    for length in range(1, 20):
        str_seq = r.generate_string(str_seq='01', length=length)
        assert len(str_seq) == length

# Generated at 2022-06-23 21:57:39.303794
# Unit test for function get_random_item
def test_get_random_item():
    get_random_item()

# Generated at 2022-06-23 21:57:43.518603
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    a = 1.100101
    b = 99.101010
    precision = 6
    result = round(a + (b - a) * rnd.random(), precision)
    assert rnd.uniform(a, b, precision) == result

# Generated at 2022-06-23 21:57:45.953632
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, random_module.Random)



# Generated at 2022-06-23 21:57:46.816010
# Unit test for constructor of class Random
def test_Random():
    Random()

# Generated at 2022-06-23 21:57:48.351538
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random().urandom(100)) == 100

# Generated at 2022-06-23 21:57:55.207336
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _code = Random().custom_code(mask='@###', char='@')
    assert len(_code) == 4
    assert _code[0].isalpha()
    assert _code.isalnum()
    assert _code is not Random().custom_code(mask='@###', char='@')

    # Test that show error
    # if we use the same placeholder
    # for digits and chars
    try:
        _ = Random().custom_code(mask='####', char='#')
    except ValueError:
        pass
    else:
        assert False

# Generated at 2022-06-23 21:57:59.712855
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    str_seq = 'qwertyuiopasdfghjklzxcvbnm'
    instance = Random()
    result = instance.generate_string(str_seq, length=5)
    assert len(result) == 5
    assert isinstance(result, str)

# Generated at 2022-06-23 21:58:02.178519
# Unit test for method urandom of class Random
def test_Random_urandom():
    out = random.urandom(32)
    assert isinstance(out, bytes)
    assert len(out) == 32


# Generated at 2022-06-23 21:58:05.649205
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    random_value = r.uniform(1.0, 2.0, precision=2)
    assert type(random_value) == float
    assert random_value >= 1.0
    assert random_value < 2.0

# Generated at 2022-06-23 21:58:11.003445
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert code.isalpha()

    code1 = rnd.custom_code(char='@')
    assert code1[:1] in string.ascii_uppercase

    code2 = rnd.custom_code(char='@', digit='#')
    assert code2[:1] in string.ascii_uppercase
    assert code2[1] == '#'



# Generated at 2022-06-23 21:58:13.526130
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    str_seq = 'abcde'
    expected = 'edcba'
    actual = random.generate_string(str_seq, length=5)[::-1]
    assert actual == expected


# Generated at 2022-06-23 21:58:18.829768
# Unit test for method randstr of class Random
def test_Random_randstr():
    random = Random()
    _string = random.randstr(length=None)
    for _ in range(10):
        assert _string == random.randstr(length=None)

    _string = random.randstr(unique=True)
    for _ in range(10):
        assert _string != random.randstr(unique=True)

# Generated at 2022-06-23 21:58:27.850127
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print('\nTest: custom_code of Random class\n')

    def test_equal(mask: str, rnd: Random) -> None:
        result = rnd.custom_code(mask=mask)
        print(f'\t{mask} -> {result}')
        assert len(result) == len(mask)

    # Generator for symbols
    symbols = string.ascii_letters + string.digits

    rnd = Random()
    print('\n\tPositive tests\n')

    # Mask '@@@@#'
    test_equal('@@@@#', rnd)

    # Mask '#@@@@'
    test_equal('#@@@@', rnd)

    # Mask '@##@@'
    test_equal('@##@@', rnd)

    # Mask '@@@@@@'

# Generated at 2022-06-23 21:58:29.764891
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0, 1) == random.random()

# Generated at 2022-06-23 21:58:30.770430
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert Random().randstr()

# Generated at 2022-06-23 21:58:33.680305
# Unit test for function get_random_item
def test_get_random_item():
    class test_enum:
        a = 1
        b = 2
        c = 3
        d = 4

    result = get_random_item(test_enum)
    assert result in list(test_enum)



# Generated at 2022-06-23 21:58:40.578403
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() == 'V732'
    assert Random().custom_code(mask='#####--@##') == '67761--A74'
    assert Random().custom_code(mask='#####--@@##') == '35996--CV47'
    assert Random().custom_code(mask='@@##--#####') == 'GP55--08593'
    assert Random().custom_code(mask='@@##--@@@@@@##') == 'EH36--GEVTHX12'
    assert Random().custom_code(mask='@@@@@@##--@@##') == 'BNWJLX26--TH16'
    assert Random().custom_code(mask='@@##--@@@@@@##', digit='@') == 'EH36--GEVTHX12'

# Generated at 2022-06-23 21:58:44.136903
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()

    for _ in range(10):
        lst = rnd.randints()
        assert lst[0] < lst[1] < lst[2]

# Generated at 2022-06-23 21:58:46.079714
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(amount=3, a=1, b=100) == [45, 52, 14]

# Generated at 2022-06-23 21:58:52.962868
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform(a: float, b: float, precision: int) -> float of class random."""
    rnd = Random()
    assert rnd.uniform(0, 4) == rnd.uniform(0, 4, 0)
    assert rnd.uniform(2, 2) == 2
    assert rnd.uniform(2, 2, 10) == 2.0
    assert rnd.uniform(2, 2, 1) == 2.0

# Generated at 2022-06-23 21:58:58.854451
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method ``generate_string()`` of class ``Random()``."""
    from mimesis.data import ALL_SYMBOLS, ALL_NUMBERS
    rnd = Random()
    assert len(rnd.generate_string(ALL_SYMBOLS, 10)) == 10
    assert len(rnd.generate_string(ALL_NUMBERS, 20)) == 20
    assert len(rnd.generate_string(ALL_NUMBERS + ALL_SYMBOLS, 15)) == 15



# Generated at 2022-06-23 21:59:03.123333
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    _random = Random()
    _random.seed(5)
    _string = _random.randstr()
    assert _string == 'a1a8f5e5f5b5a747b15f3623e8f8d6f2'

# Generated at 2022-06-23 21:59:05.021585
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    result = Random().generate_string(string.ascii_letters)
    assert isinstance(result, str)



# Generated at 2022-06-23 21:59:15.143998
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    assert set(Random.custom_code()) == {'A', 'B', 'C', 'D', 'E',
                                         'F', 'G', 'H', 'I', 'J'}
    assert set(Random.custom_code(length=20)) == {'A', 'B', 'C', 'D', 'E',
                                                  'F', 'G', 'H', 'I', 'J'}
    assert set(Random.custom_code(length=15, mask='@@@#@#@#@#@#@#')) == {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'}
    assert len(Random.custom_code()) == 10

# Generated at 2022-06-23 21:59:17.961013
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    data = random.generate_string(str_seq='0123456789', length=6)
    assert len(data) == 6
    assert type(data) is str


# Generated at 2022-06-23 21:59:21.061471
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random().urandom(10)) == 10
    assert len(Random().urandom(100)) == 100
    assert len(Random().urandom(1000)) == 1000
    assert len(Random().urandom(10000)) == 10000


# Generated at 2022-06-23 21:59:23.636189
# Unit test for function get_random_item
def test_get_random_item():
    from enum import Enum

    class Foo(Enum):
        bar = 1
        baz = 2
        qux = 3

    foo = get_random_item(Foo)
    assert isinstance(foo, Foo)
    assert foo in Foo

# Generated at 2022-06-23 21:59:27.157956
# Unit test for method urandom of class Random
def test_Random_urandom():
    first_bytes = int.from_bytes(
        Random().urandom(4),
        byteorder='big', signed=False
    )
    assert first_bytes > 0

# Generated at 2022-06-23 21:59:31.435696
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints() == [79, 27, 62]
    assert Random().randints(amount=1) == [63]
    assert Random().randints(a=0, b=10) == [1, 2, 8]

# Generated at 2022-06-23 21:59:34.635317
# Unit test for method randstr of class Random
def test_Random_randstr():
    randstr_0 = random.randstr(length=None)
    randstr_1 = random.randstr(unique=False,length=None)

    assert len(randstr_0) >= len(randstr_1)
    assert len(randstr_1) >= 16
    assert len(randstr_0) <= 128

# Generated at 2022-06-23 21:59:43.233976
# Unit test for method uniform of class Random
def test_Random_uniform():
    from mimesis.data import PROPERNOUNS, LOREM_IPSUM

    class Enum(object):
        def __init__(self):
            self.item1 = 1
            self.item2 = 2
            self.item3 = 3

    enum = Enum()

    rnd = Random()

    assert isinstance(rnd.randstr(), str)
    assert isinstance(rnd.randstr(unique=True), str)
    assert isinstance(rnd.randstr(length=20), str)
    assert isinstance(rnd.custom_code(), str)
    assert isinstance(rnd.custom_code(mask="@@@@"), str)
    assert len(rnd.randints()) == 3
    assert len(rnd.randints(amount=10)) == 10

# Generated at 2022-06-23 21:59:46.834036
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Testing for Random.generate_string()."""
    r = random.generate_string('abc')
    assert isinstance(r, str)
    # Unit test for method custom_code of class Random

# Generated at 2022-06-23 21:59:52.778507
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method ``generate_string()`` of class ``Random()``."""
    assert len(Random().generate_string(str_seq='abcdefghijklmnop',
                                        length=6)) == 6
    assert len(Random().generate_string(str_seq='0123456789',
                                        length=7)) == 7
    assert len(Random().generate_string(str_seq='0123456789',
                                        length=1)) == 1
    assert len(Random().generate_string(str_seq='qwertyuiopasdfgh',
                                        length=10)) == 10



# Generated at 2022-06-23 21:59:57.772147
# Unit test for method urandom of class Random
def test_Random_urandom():
    def assertion(r1, r2): assert r1 == r2

    r1 = Random().urandom(100)
    r2 = os.urandom(100)
    assertion(r1, r2)

    r1 = Random(random_module.seed(random_module.random())).urandom(100)
    r2 = os.urandom(100)
    assertion(r1, r2)

# Generated at 2022-06-23 22:00:00.244242
# Unit test for function get_random_item
def test_get_random_item():
    import sys
    if sys.version_info[0] == 2:
        import unittest2 as unittest
    else:
        import unittest

    from mimesis.builtins.enums import Gender

    test = unittest.TestCase()
    res = get_random_item(Gender)
    test.assertIn(res, Gender)

# Generated at 2022-06-23 22:00:05.218238
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code() of class Random.

    Method will raise exception if parameter char and parameter digit
    will be same.
    """
    try:
        rnd = Random()
        rnd.custom_code()
    except ValueError:
        return False
    raise NotImplementedError('Test not implemented.')

# Generated at 2022-06-23 22:00:08.244956
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random = Random()
    string = random.generate_string(str_seq='abcde', length=50)
    assert len(string) == 50 and string.isalnum()


# Generated at 2022-06-23 22:00:18.394281
# Unit test for method randints of class Random
def test_Random_randints():
    x = Random().randints()
    assert isinstance(x, list) and len(x) == 3
    x = Random().randints(a=10, b=15)
    assert isinstance(x, list) and len(x) == 3
    x = Random().randints(amount=2, a=15, b=20)
    assert isinstance(x, list) and len(x) == 2
    x = Random().randints(amount=0, a=10, b=20)
    assert isinstance(x, list) and len(x) == 0
    x = Random().randints(amount=-10, a=-15, b=-10)
    assert isinstance(x, list) and len(x) == 0



# Generated at 2022-06-23 22:00:23.057752
# Unit test for function get_random_item
def test_get_random_item():
    # Creating custom class for testing
    class Enum:
        a = 1
        b = 2
        c = 3
        d = 4

    # Creating random object
    rnd = Random()

    # Testing for not giving custom random object
    assert get_random_item(Enum)

    # Testing for giving custom random object
    assert get_random_item(Enum, rnd)

# Generated at 2022-06-23 22:00:25.210693
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    _random = Random()
    _str = 'hello world'
    _string_ = _random.generate_string(_str, 5)
    assert len(_string_) == 5
    assert _string_ in _str.split(' ')


# Generated at 2022-06-23 22:00:29.067217
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1.0, 2.0) >= 1.0
    assert random.uniform(1.0, 2.0) < 2.0

# Generated at 2022-06-23 22:00:33.711186
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    for _ in range(1_000):
        length = random.randint(16, 128)
        result = random.generate_string(string.ascii_letters, length)
        assert isinstance(result, str)
        assert len(result) == length

# Generated at 2022-06-23 22:00:38.244146
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    x = random.custom_code(mask='@@@-###')
    assert x[0].isalpha() and x[1].isalpha() and \
           x[3].isdigit() and x[4].isdigit() and x[5].isdigit()

# Generated at 2022-06-23 22:00:41.578993
# Unit test for function get_random_item
def test_get_random_item():
    """Test function get_random_item with randomizer and without."""
    from mimesis.enums import Gender

    rnd = Random()

    assert get_random_item(Gender) in list(Gender)
    assert get_random_item(Gender, rnd) in list(Gender)

# Generated at 2022-06-23 22:00:46.390245
# Unit test for method randstr of class Random
def test_Random_randstr():
    result_randstr_default = random.randstr()
    result_randstr_bool = random.randstr(True)
    result_randstr_length = random.randstr(length=10)
    assert len(result_randstr_default) <= 128
    assert len(result_randstr_length) == 10
    assert len(result_randstr_bool) == 32

# Generated at 2022-06-23 22:00:48.105134
# Unit test for method urandom of class Random
def test_Random_urandom():
    _random = Random()
    assert _random.urandom(10) != _random.urandom(10)

# Generated at 2022-06-23 22:00:53.299190
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test Random.uniform method."""
    rnd = Random()
    min_val = 1.0
    max_val = 2.0
    precision = 10
    res = rnd.uniform(min_val, max_val, precision)
    assert isinstance(res, float)
    assert res >= min_val
    assert res <= max_val
    assert abs(res - round(res, precision)) < 0.1 ** precision

# Generated at 2022-06-23 22:00:56.016460
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    assert r.uniform(1, 10, 2) <= 10
    assert r.uniform(1, 10, 2) >= 1

# Generated at 2022-06-23 22:01:00.019587
# Unit test for method randints of class Random
def test_Random_randints():
    rng = Random()
    arr = rng.randints()
    assert len(arr) == 3
    arr = rng.randints(a=1, b=10)
    assert all(map(lambda x: x >= 1 and x <= 10, arr))
    arr = rng.randints(amount=2, a=1, b=10)
    assert all(map(lambda x: x >= 1 and x <= 10, arr))
    arr = rng.randints(amount=2, a=0, b=10)
    assert all(map(lambda x: x >= 0 and x <= 10, arr))
    arr = rng.randints(amount=2, a=1, b=10)
    assert all(map(lambda x: x >= 1 and x <= 10, arr))


# Generated at 2022-06-23 22:01:09.548599
# Unit test for method uniform of class Random
def test_Random_uniform():
    values_testing = [(-2, 2, 1), (0, 10, 0.4), (-2, 2, -1)]
    expected_results = [1.718, 2.6, -1.718]

    for i, value in enumerate(values_testing):
        # Запускаем функцию с различными аргументами
        result = Random().uniform(*value)
        # Проверяем результат и ожидаемое значение
        assert result == expected_results[i]

# Generated at 2022-06-23 22:01:16.284722
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    code = rnd.custom_code('@###-@@@')
    assert code[0].isalpha()
    assert code[1].isdigit()
    assert code[2].isdigit()
    assert code[3].isdigit()
    assert code[4] == '-'
    assert code[5].isalpha()
    assert code[6].isalpha()
    assert code[7].isalpha()

# Generated at 2022-06-23 22:01:18.524308
# Unit test for method uniform of class Random
def test_Random_uniform():
    expected_value = Random().uniform(89.63729, 89.63737)
    assert expected_value == 89.6373

# Generated at 2022-06-23 22:01:20.251848
# Unit test for method uniform of class Random
def test_Random_uniform():
    result = random.uniform(-1, 1, 10)
    assert random.uniform(-1, 1, 10) == result

# Generated at 2022-06-23 22:01:23.226044
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    i = r.randint(0,10)
    assert i >= 0
    assert i <= 10
    assert i == r.randint(0,10)
    # TODO add more tests

# Generated at 2022-06-23 22:01:33.357578
# Unit test for method uniform of class Random
def test_Random_uniform():
    # ValueError: min > max
    try:
        random.uniform(b=1.1, a=2.2)
    except ValueError as exc:
        assert 'max must be greater' in str(exc)
    # ValueError: precision must be >= 0
    try:
        random.uniform(precision=-1)
    except ValueError as exc:
        assert 'precision must be greater' in str(exc)

    assert random.uniform(b=0.9, a=0.5, precision=1) == 0.5
    assert random.uniform(b=0.9, a=0.5, precision=2) == 0.55
    assert random.uniform(b=0.9, a=0.5, precision=3) == 0.593