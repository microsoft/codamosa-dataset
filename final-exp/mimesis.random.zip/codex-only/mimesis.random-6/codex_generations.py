

# Generated at 2022-06-23 21:51:32.985534
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print(random.custom_code(mask='@#@#'))
    print(random.custom_code(mask='@###', char='@', digit='#'))



# Generated at 2022-06-23 21:51:35.877038
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(Random().custom_code(mask='@###')) == 4

if __name__ == '__main__':
    test_Random_custom_code()
    print("Everything passed")

# Generated at 2022-06-23 21:51:39.933770
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random().urandom(10), bytes)
    assert isinstance(Random().urandom(10, b'string'), bytes)
    assert len(Random().urandom(10)) == 10
    assert len(Random().urandom(10, b'string')) == 10



# Generated at 2022-06-23 21:51:40.876505
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(10)



# Generated at 2022-06-23 21:51:43.549595
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom(10) == os.urandom(10)

# Generated at 2022-06-23 21:51:50.256534
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(Random().custom_code()) == 10
    assert Random().custom_code(mask='@@@') == 'FFG'
    assert Random().custom_code(mask='@') == '7'
    assert Random().custom_code(mask='@@') == 'QK'
    assert Random().custom_code(mask='@@@@') == 'YUIG'
    assert len(Random().custom_code(mask='@' * 1000)) == 1000
    assert Random().custom_code(mask='@', digit='d') == '7'

# Generated at 2022-06-23 21:51:52.225465
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1, 2) == 1.0 + (2.0 - 1.0) * random.random()



# Generated at 2022-06-23 21:51:58.256006
# Unit test for constructor of class Random
def test_Random():
    random = Random(2)
    assert random.random() == 0.6170041866839221
    assert random.choice(['foo', 'bar'] == 'foo')
    assert random.choice(('foo', 'bar') == 'foo')
    assert random.choice(('foo', 'bar')) == 'foo'
    assert random.randint(0, 100) == 32
    assert random.randint(0, 100) == 61
    assert random.randint(0, 100) == 16
    assert random.randint(0, 100) == 72
    assert random.randint(0, 100) == 77
    assert random.randint(0, 100) == 69
    assert random.randint(0, 100) == 75
    assert random.randint(0, 100) == 69
    assert random.randint(0, 100)

# Generated at 2022-06-23 21:52:00.320620
# Unit test for method urandom of class Random
def test_Random_urandom():
    result = Random().urandom(20)
    assert isinstance(result, bytes)
    assert len(result) == 20

# Generated at 2022-06-23 21:52:04.456117
# Unit test for method randints of class Random
def test_Random_randints():
    # test with default arguments
    assert len(Random().randints()) == 3
    # test with custom arguments
    assert len(Random().randints(3, 1, 10)) == 3
    # test exception
    try:
        Random().randints(0)
    except ValueError:
        pass

# Generated at 2022-06-23 21:52:07.243880
# Unit test for method randstr of class Random
def test_Random_randstr():
    print(Random().randstr())
    print(Random().randstr(unique=True))
    print(Random().randstr(length=5))

# Generated at 2022-06-23 21:52:09.419346
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for method uniform of class Random"""
    _1 = random.uniform(0, 1)
    _2 = random.uniform(0, 1)
    _3 = random.uniform(0, 1)
    # Check that 3 generated values are different
    assert _1 != _2 and _1 != _3 and _2 != _3


['test_Random_uniform']

# Generated at 2022-06-23 21:52:12.225925
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(3, 3.5) > 3 and random.uniform(3, 3.5) < 3.5

# Generated at 2022-06-23 21:52:16.419999
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    rnd = Random()
    a = 10
    b = 20
    assert rnd.uniform(a, b) in [a, b], 'Uniform must return a or b'
    assert a < rnd.uniform(a, b) < b, 'Uniform must return in [a, b)'

# Generated at 2022-06-23 21:52:21.692833
# Unit test for method randstr of class Random
def test_Random_randstr():
    str_1 = random.randstr()
    str_2 = random.randstr(False)
    str_3 = random.randstr(False, 37)
    str_4 = random.randstr(True)
    str_5 = random.randstr(True, 37)
    assert isinstance(str_1, str)
    assert len(str_1) == 16
    assert isinstance(str_2, str)
    assert len(str_2) == 16
    assert isinstance(str_3, str)
    assert len(str_3) == 37
    assert isinstance(str_4, str)
    assert len(str_4) == 32
    assert isinstance(str_5, str)
    assert len(str_5) == 32

# Generated at 2022-06-23 21:52:30.998123
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    random = Random()
    exclusion = [
        'a, -1',
        'a, 0',
        'a, b, -1',
        'a, b, 0',
    ]
    for case in exclusion:
        try:
            random.randints(*case)
        except ValueError:
            pass
        else:
            raise ValueError('An exception is expected!')

    assert random.randints() == [2, 3, 7]
    assert random.randints(0) == []
    assert random.randints(1) == [1]
    assert random.randints(2) == [2, 3]
    assert random.randints(2, 3, 4) == [3, 3]

# Generated at 2022-06-23 21:52:32.425316
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(random.randstr(length=5)) == 5

# Generated at 2022-06-23 21:52:35.586408
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform."""
    rnd = Random()
    a_values = rnd.uniform(0.0, 1.0, precision=1)
    assert isinstance(a_values, float)

# Generated at 2022-06-23 21:52:39.625543
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for method urandom of class Random."""
    size = 5
    random.urandom(size)
    assert list(map(lambda x: x in range(0, 256), random.urandom(size)))

# Generated at 2022-06-23 21:52:41.442762
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code(mask="@####", char="@", digit="#")

# Generated at 2022-06-23 21:52:43.823913
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert random.urandom().decode() != random.urandom().decode()


# Generated at 2022-06-23 21:52:51.954762
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    assert random.uniform(5.2345, 9.8765) >= 5.2345
    assert random.uniform(5.2345, 9.8765) <= 9.8765
    assert random.uniform(5.2345, 9.8765, 10) >= 5.2345
    assert random.uniform(5.2345, 9.8765, 10) <= 9.8765

# Generated at 2022-06-23 21:52:53.286953
# Unit test for function get_random_item
def test_get_random_item():
    assert random.choice(list(random)) == get_random_item(random)

# Generated at 2022-06-23 21:52:59.304173
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit tests for method ``generate_string()``.
    """
    assert random.generate_string('1234567890')
    assert random.generate_string('1234567890', 5)
    assert random.generate_string('1234567890', -5)
    assert random.generate_string('1234567890', 1)



# Generated at 2022-06-23 21:53:03.010553
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    r.randint(1, 2)
    r.randints(amount=2, a=1, b=2)
    r.uniform(1, 2)
    r.urandom(100)

# Generated at 2022-06-23 21:53:06.223108
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    _random = Random()
    _random.seed(0)
    _string = _random.generate_string('abcd')
    assert _string == 'dbdacc'

# Generated at 2022-06-23 21:53:09.062974
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random.urandom(5)) == 5
    assert len(Random.urandom(5)) == 5
    assert not len(Random.urandom(5)) == 10



# Generated at 2022-06-23 21:53:10.410028
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert len(rnd.randints()) == 3
    assert len(rnd.randints(2, 10, 20)) == 2
    assert len(rnd.randints(5)) == 5


# Generated at 2022-06-23 21:53:12.598888
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test uniform method of class Random."""
    r = Random()
    assert r.uniform(20, 30) >= 20 and r.uniform(20, 30) < 30

# Generated at 2022-06-23 21:53:16.882085
# Unit test for method randints of class Random
def test_Random_randints():
    obj = Random()
    assert isinstance(obj.randints(amount=3), list)
    assert len(obj.randints(amount=3)) == 3



# Generated at 2022-06-23 21:53:21.780060
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    n = random.randints(amount=10)
    assert len(n) == 10
    n = random.randints(amount=10, a=2, b=11)
    assert max(n) == 10
    assert min(n) == 2



# Generated at 2022-06-23 21:53:26.843523
# Unit test for function get_random_item
def test_get_random_item():
    """
    This is a unit test for function get_random_item().
    """
    import unittest
    import enum as enum
    
    class Numbers(enum.Enum):
        ONE = 1
        TWO = 2
        THREE = 3
        FOUR = 4
        FIVE = 5
    
    class TestCase(unittest.TestCase):
        def test(self):
            item = get_random_item(Numbers)
            assert item in list(Numbers)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-23 21:53:30.576249
# Unit test for function get_random_item
def test_get_random_item():
    enum = random.custom_enum(names=('Alice', 'Bob', 'Carol'))
    print(get_random_item(enum))


# Generated at 2022-06-23 21:53:34.493309
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    for i in range(100):
        assert rnd.uniform(1, 1, 7) == 1
        assert rnd.uniform(1, 2) == 1 or rnd.uniform(1, 2) == 2

# Generated at 2022-06-23 21:53:37.682080
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = random_module.Random(1)
    assert Random(1).custom_code() == rnd.custom_code() == 'J937'
    assert Random(1).custom_code('###', '#', '%%') == '%%0'

# Generated at 2022-06-23 21:53:39.275975
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code(mask='@@###') == 'AB123'
    assert random.custom_code(mask='@@###') != 'AB123'
    assert random.custom_code(mask='@@##@') != 'ABBC3'

# Generated at 2022-06-23 21:53:43.547432
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test Random class method uniform."""
    random = Random()
    x = random.uniform(0.05, 0.15)
    assert 0.05 < x < 0.15

    random.seed(5)
    x = random.uniform(0.05, 0.15)
    assert 0.13 <= x <= 0.14

# Generated at 2022-06-23 21:53:55.531102
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)
    assert isinstance(random.randint, random_module.randint)
    assert isinstance(random.random, random_module.random)
    assert isinstance(random.choices, random_module.choices)
    assert isinstance(random.ranf, random_module.ranf)
    assert isinstance(random.randrange, random_module.randrange)
    assert isinstance(random.randints, random_module.randint)
    assert isinstance(random.urandom, random_module.urandom)
    assert isinstance(random.generate_string, random_module.generate_string)
    assert isinstance(random.custom_code, random_module.custom_code)
    assert isinstance(random.uniform, random_module.uniform)

# Generated at 2022-06-23 21:53:57.299083
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, random_module.Random) and random.random()


# Generated at 2022-06-23 21:54:03.524601
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code(mask='@###') == '@###'
    assert Random().custom_code(mask='@@##') == '@@##'
    assert Random().custom_code(mask='@@@@') == '@@@@'
    assert Random().custom_code(mask='####') == '####'
    assert Random().custom_code(mask='@@##') == '@@##'
    assert Random().custom_code(mask='@@@@') == '@@@@'
    assert Random().custom_code(mask='@@##') == '@@##'
    assert Random().custom_code(mask='@@@@') == '@@@@'
    assert len(Random().custom_code(mask='@###')) == 4
    assert len(Random().custom_code(mask='@@##')) == 4
    assert len(Random().custom_code(mask='@@@@')) == 4

# Generated at 2022-06-23 21:54:10.567295
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test function test_Random_custom_code."""
    rnd = Random()
    code = rnd.custom_code('@###', char='@', digit='#')
    assert len(code) == 4
    assert all(x.isalpha() for x in code[0])
    assert all(x.isdigit() for x in code[1:])

# Generated at 2022-06-23 21:54:11.657273
# Unit test for constructor of class Random
def test_Random():
    rand = Random()
    assert isinstance(rand, random_module.Random)

# Generated at 2022-06-23 21:54:15.074094
# Unit test for method urandom of class Random
def test_Random_urandom():
    for i in range(5):
        lenght = random_module.randint(1, 100)
        gen = Random.urandom(lenght)
        assert isinstance(gen, bytes)
        assert len(gen) == lenght

# Generated at 2022-06-23 21:54:22.949925
# Unit test for method urandom of class Random
def test_Random_urandom():
    _ = Random()
    _.urandom()
    _.urandom(100)
    _.urandom(100, 100)
    _.urandom(100, 100, b'100')
    _.urandom(100, 100, b'100', 100)
    _.urandom(100, 100, b'100', 100, '100')
    _.urandom(100, 100, b'100', 100, '100', 100)
    _.urandom(100, 100, b'100', 100, '100', 100, '100')
    _.urandom(100, 100, b'100', 100, '100', 100, '100', 100)
    _.urandom(100, 100, b'100', 100, '100', 100, '100', 100, '100')

# Generated at 2022-06-23 21:54:25.239164
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert rnd.randints(3) == rnd.randints(amount=3)



# Generated at 2022-06-23 21:54:27.342796
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints()) == 3
    assert len(random.randints(10)) == 10

    try:
        random.randints(0)
        assert 1 == 0
    except ValueError:
        assert 1 == 1



# Generated at 2022-06-23 21:54:33.906880
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    s = r.custom_code('@###@')
    assert len(s) == 5
    assert (s.isupper() and s.isdigit())
    s = r.custom_code('@###-@')
    assert len(s) == 6
    assert (s.isupper() and s[:4].isdigit() and s[4].isalpha() and s[5].isalpha())
    s = r.custom_code('@###-@###')
    assert len(s) == 10
    assert (s.isupper() and s[:5].isdigit() and s[5].isalpha() and s[6:].isdigit())
    s = r.custom_code('-@###-@###')
    assert len(s) == 11

# Generated at 2022-06-23 21:54:35.337618
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string('1234567890', 10)

# Generated at 2022-06-23 21:54:46.358330
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Test 1:
    # Test result: @###-@@@@-@@##
    # mask = '@###-@@@@-@@##'
    # Code - VALA-USEN-SC56 (some example)
    assert random.custom_code('@###-@@@@-@@##')

    # Test 2:
    # Test result: @###-@@@@-@@##
    # mask = '@###-@@@@-@@##'
    # Code - UMLO-PYZI-RL56 (some example)
    assert random.custom_code('@###-@@@@-@@##')

    # Test 3:
    # Test result: @###-@@@@-@@##
    # mask = '@###-@@@@-@@##'
    # Code - YVZK-VCZW-MB56 (some example)

# Generated at 2022-06-23 21:54:48.000309
# Unit test for method uniform of class Random
def test_Random_uniform():
    v = Random().uniform(1, 2, 5)
    assert v >= 1 and v <= 2



# Generated at 2022-06-23 21:54:51.312476
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test method urandom of class Random."""
    assert Random().urandom(8)
    assert Random().urandom(13)
    assert Random().urandom(18)
    assert Random().urandom(22)
    assert Random().urandom(27)
    assert Random().urandom(32)



# Generated at 2022-06-23 21:54:52.743145
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random_module.uniform(1.0, 2.0) < 2.0

# Generated at 2022-06-23 21:54:55.949389
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string(string.digits)) == 10
    assert len(Random().generate_string(string.ascii_letters, 13)) == 13



# Generated at 2022-06-23 21:54:58.084862
# Unit test for function get_random_item
def test_get_random_item():
    class Item(enum.Enum):
        FOO = 111
        BAR = 222
        BAZ = 333
    item = get_random_item(Item)
    assert isinstance(item, Item)

# Generated at 2022-06-23 21:55:00.242805
# Unit test for method urandom of class Random
def test_Random_urandom():
    _bytes = random.urandom(12)
    assert isinstance(_bytes, bytes)
    assert len(_bytes) == 12

# Generated at 2022-06-23 21:55:01.556006
# Unit test for method urandom of class Random
def test_Random_urandom():
    print(random.urandom())


# Generated at 2022-06-23 21:55:03.499669
# Unit test for method randstr of class Random
def test_Random_randstr():
    randstr = Random().randstr()
    assert isinstance(randstr, str)



# Generated at 2022-06-23 21:55:13.385481
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    random_symbol = Random(1)
    digit_only = '01234567890'
    expected_result = '472619902'
    actual_result = random_symbol.generate_string(digit_only)
    assert expected_result == actual_result

    random_symbol = Random(2)
    digit_only = '01234567890'
    expected_result = '787485522'
    actual_result = random_symbol.generate_string(digit_only)
    assert expected_result == actual_result

    random_symbol = Random(3)
    digit_only = '01234567890'
    expected_result = '495983916'
    actual_result = random_symbol.generate_string(digit_only)
    assert expected_result == actual_result

# Generated at 2022-06-23 21:55:19.786225
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    _random_number_generator = random.generate_string
    # Check if method returns sting with required length
    assert len(_random_number_generator(4)) == 4
    # Check if method returns sting with required length
    assert len(_random_number_generator(10)) == 10
    # Check if method returns sting which contains only letters
    assert _random_number_generator(10, 'лорнорп') == 'рлпооорр'


# Generated at 2022-06-23 21:55:25.710526
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Test mask using different placeholders
    assert len(random.custom_code('A@###', char='@')) == 5
    assert len(random.custom_code('A@@###', char='@')) == 6
    assert len(random.custom_code('@@###', char='@')) == 4
    assert len(random.custom_code('@@###', char='@')) == 4

    # Test mask using the same placeholders
    with pytest.raises(ValueError) as err:
        random.custom_code('A@@###', char='@', digit='@')
    assert 'digits and chars' in str(err.value)

# Generated at 2022-06-23 21:55:37.740989
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    seed = 'Seed'
    rnd = Random()
    rnd.seed(seed)
    mask = 'A###'
    char = 'A'
    digit = '#'

    if char == digit:
        raise ValueError('You cannot use the same '
                         'placeholder for digits and chars!')

    def random_int(a: int, b: int) -> int:
        b = b - a
        return int(rnd.random() * b) + a

    _mask = mask.encode()
    code = bytearray(len(_mask))
    for i, p in enumerate(_mask):
        if p == ord(char):
            a = random_int(65, 91)  # A-Z

# Generated at 2022-06-23 21:55:40.083823
# Unit test for method urandom of class Random
def test_Random_urandom():
    random_ = random
    assert isinstance(random_.urandom(size=32), bytes)

# Generated at 2022-06-23 21:55:48.349277
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for method custom_code of class Random."""

    # Test for mask @###
    s = random.custom_code()

    assert len(s) == 4
    assert s[0] in string.ascii_uppercase
    assert all(x in string.digits for x in s[1:])

    # Test for mask @@### with one char
    s = random.custom_code(mask='@@###')
    assert len(s) == 5
    assert all(x in string.ascii_uppercase for x in s[:2])
    assert all(x in string.digits for x in s[2:])

    # Test for mask @## with one symbol
    s = random.custom_code(mask='@##')
    assert len(s) == 3

# Generated at 2022-06-23 21:55:49.373658
# Unit test for constructor of class Random
def test_Random():
    """Test constructor of class Random."""
    rnd = Random(123)
    assert rnd.random() == 0.4030881838773142

# Generated at 2022-06-23 21:55:58.164680
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints(0, a=6, b=6)) == 0
    assert len(random.randints(1000)) == 1000
    assert len(random.randints(1, a=6, b=6)) == 1
    assert len(random.randints(5, a=10, b=15)) == 5
    assert len(random.randints(5, a=0, b=10)) == 5
    assert len(random.randints(5, a=10, b=0)) == 5
    assert len(random.randints(5, a=-5, b=-5)) == 5
    assert 6 in random.randints(5, a=6, b=6)
    assert 0 in random.randints(5, a=0, b=10)

# Generated at 2022-06-23 21:55:59.968148
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string(string_sequence='aZ1')


# Generated at 2022-06-23 21:56:02.163297
# Unit test for method uniform of class Random
def test_Random_uniform():
    for i in range(1, 100):
        r = random.uniform(1, 3)
        assert 1 <= r < 3

# Generated at 2022-06-23 21:56:13.262080
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    generated_code = random.custom_code('@###', '@', '#')
    assert len(generated_code) == 4, 'Количество символов не равно 4'
    assert generated_code.isalpha(), 'Сгенерированный код не содержит буквы'
    assert generated_code.isdigit(), 'Сгенерированный код не содержит цифры'

# Generated at 2022-06-23 21:56:17.176550
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random"""
    r = Random()
    for i in range(10000):
        result = r.uniform(1, 3)
        assert 1 <= result < 3
        result = r.uniform(1, 3, 2)
        assert 1 <= result < 3



# Generated at 2022-06-23 21:56:22.600167
# Unit test for method uniform of class Random
def test_Random_uniform():
    # Test case #1
    r = Random()
    a = r.uniform(3, 6)
    assert (a >= 3) and (a < 6)

    # Test case #2
    r = Random()
    a = r.uniform(3, 6, precision=1)
    assert (a >= 3) and (a < 6)
    assert type(a) == float

    # Test case #3
    r = Random()
    a = r.uniform(3, 3)
    assert a == 3

    # Test case #4
    r = Random()
    a = r.uniform(3, 6, precision=0)
    assert (a >= 3) and (a < 6)
    assert type(a) == int

# Generated at 2022-06-23 21:56:25.100878
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    while True:
        x = input("Please enter mask of code: ")
        if x:
            print(random.custom_code(x))
            break
        else:
            print("Error: You didn't enter anything.")

# Generated at 2022-06-23 21:56:29.435095
# Unit test for method randints of class Random
def test_Random_randints():
    _amount = 5
    _a = 0
    _b = 10
    values = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    rnd = Random()
    lst = rnd.randints(_amount, _a, _b)
    assert all(i in values for i in lst) is True

# Generated at 2022-06-23 21:56:31.356438
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random.urandom(2), bytes)
    assert isinstance(Random().urandom(2), bytes)

# Generated at 2022-06-23 21:56:33.438740
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random(101)
    assert r.custom_code() == 'T6HO', "custom_code method of Random class failed."

# Generated at 2022-06-23 21:56:40.004343
# Unit test for constructor of class Random
def test_Random():
    print(random.randint(15, 20))
    print(random.randrange(10, 20, 2))
    print(random.randrange(10, 30, 2))
    print(random.generate_string("abcde"))
    print(random.custom_code("@@###"))
    print(random.uniform(20, 30))
    print(random.randstr())
    print(random.randstr(True))
    print(random.randstr(length=20))
    print(random.urandom(4))
    print(random.randints(10))
    print(get_random_item(random.get_providers(), random))

# Generated at 2022-06-23 21:56:42.515771
# Unit test for method urandom of class Random
def test_Random_urandom():
    _bytes = Random.urandom(16)
    assert isinstance(_bytes, bytes) and len(_bytes) == 16



# Generated at 2022-06-23 21:56:47.057930
# Unit test for function get_random_item
def test_get_random_item():
    print(get_random_item(string.ascii_uppercase))
    print(get_random_item(string.ascii_uppercase, Random()))


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-23 21:56:48.490097
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert isinstance(rnd, Random)


# Generated at 2022-06-23 21:56:49.696510
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    """Test that random object works."""
    assert random.random()

# Generated at 2022-06-23 21:56:52.588296
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    expected_result = 'gW8XKjpcYq'
    actual_result = Random().generate_string('abcdefghijklmnopqrstuvwxyz'
                                             'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                                             '0123456789')
    assert len(actual_result) == 10, 'Result has different length.'
    assert expected_result == actual_result, 'Result is not valid.'



# Generated at 2022-06-23 21:56:54.998659
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    assert isinstance(r.randints(), list)
    assert len(r.randints(100)) == 100


# Generated at 2022-06-23 21:56:56.785146
# Unit test for constructor of class Random
def test_Random():
    a = 'test' + Random.generate_string('test')
    assert a is not None

# Generated at 2022-06-23 21:56:57.645181
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom()

# Generated at 2022-06-23 21:56:59.806243
# Unit test for method randints of class Random
def test_Random_randints():
    """Test method randints() of class Random."""
    r = Random()
    assert r.randints(amount=3) == [58, 57, 19]


if __name__ == '__main__':
    test_Random_randints()

# Generated at 2022-06-23 21:57:02.982328
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    for _ in range(20):
        _string = random.generate_string(string.ascii_uppercase, 5)
        assert len(_string) == 5
        assert _string.isalpha()
        assert _string.isupper()


# Generated at 2022-06-23 21:57:06.565348
# Unit test for method randints of class Random
def test_Random_randints():
    rs = Random()
    lst = rs.randints(amount=5)
    for i in lst:
        assert isinstance(i, int), 'Failed randints'
    assert len(lst) == 5, 'Got wrong length of list'


# Generated at 2022-06-23 21:57:13.356579
# Unit test for method randstr of class Random
def test_Random_randstr():
    from mimesis.enums import Gender
    from mimesis.providers.person import Person
    from mimesis.providers.address import Address
    from datetime import datetime

    rnd = Random()
    p = Person('en')
    for i in range(1000):
        # name = p.full_name(gender=Gender.MALE)
        # print(name)
        name = p.full_name(gender=Gender.MALE)
        address = Address('en')
        str_time = datetime.now().strftime('%Y-%m-%d-%H-%M-%S-%f')
        print(str_time)
        print(name)
        print(address.zip_code())
        print(rnd.randstr(unique=False, length=10))



# Generated at 2022-06-23 21:57:16.997698
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    assert len(rnd.generate_string('abcd')) == 10
    assert isinstance(rnd.generate_string('abcd', length=100), str)



# Generated at 2022-06-23 21:57:17.959072
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert type(random.randstr()) == str

# Generated at 2022-06-23 21:57:19.381143
# Unit test for function get_random_item
def test_get_random_item():
    print(get_random_item(enum=random_module.random))

# Generated at 2022-06-23 21:57:22.353551
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """ Test generate_string."""
    r = Random()
    l = 10
    r.generate_string(r.ascii_letters, l)

# Generated at 2022-06-23 21:57:24.636046
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(random.Formats()) == get_random_item(random.Formats(), random) == get_random_item(random.Formats(), Random())

# Generated at 2022-06-23 21:57:26.826700
# Unit test for method randstr of class Random
def test_Random_randstr():
    result = Random().randstr()
    assert len(result) <= 128, 'Random string is too long'
    assert len(result) >= 16, 'Random string is too short'

# Generated at 2022-06-23 21:57:30.872347
# Unit test for function get_random_item
def test_get_random_item():
    """Test get random item of enum object."""
    from mimesis.enums import Gender

    item = get_random_item(Gender, rnd=Random())
    assert isinstance(item, Gender), 'Type of item is not Gender'



# Generated at 2022-06-23 21:57:33.758834
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    res = rnd.generate_string(
        str_seq=string.ascii_lowercase, length=16
    )
    assert len(res) == 16
    assert isinstance(res, str)

# Generated at 2022-06-23 21:57:38.575861
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random().randints()) == 3
    assert len(Random().randints(5)) == 5
    assert isinstance(Random().randints(), list)
    assert isinstance(Random().randints(), list)
    assert all(isinstance(x, int) for x in Random().randints())

# Generated at 2022-06-23 21:57:41.013086
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import CardType
    item = get_random_item(CardType)
    assert item in list(CardType)

# Generated at 2022-06-23 21:57:47.934392
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    assert r.generate_string('abcde', length=5) == 'edeca'
    assert r.generate_string('0123456789', length=10) == '5723495964'
    assert len(r.generate_string('fghijklmnopqrst', length=15)) == 15
    assert r.generate_string('fghijklmnopqrst', length=15) != 'fghijklmnopqrst'

# Generated at 2022-06-23 21:57:55.777928
# Unit test for method randstr of class Random
def test_Random_randstr():
    """ Random_randstr test """
    for _ in range(1000):
        assert not random.randstr(unique=True, length=None) == random.randstr(unique=True, length=None)
    for _ in range(100):
        assert not random.randstr(unique=False, length=32) == random.randstr(unique=False, length=32)
    for _ in range(100):
        assert not random.randstr(unique=False, length=10) == random.randstr(unique=False, length=10)
    for _ in range(100):
        assert not random.randstr(unique=False, length=16) == random.randstr(unique=False, length=16)
    for _ in range(100):
        assert not random.randstr(unique=False, length=128) == random.randstr

# Generated at 2022-06-23 21:57:59.609441
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    r = Random()
    result = r.generate_string("ASDF", 10)
    assert len(result) <= 10
    assert set(result).issubset(set("ASDF"))

# Generated at 2022-06-23 21:58:01.256430
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, random_module.Random)


# Generated at 2022-06-23 21:58:10.660085
# Unit test for method randstr of class Random
def test_Random_randstr():
    rnd = Random()
    assert isinstance(rnd.randstr(False), str)
    assert isinstance(rnd.randstr(True), str)
    assert isinstance(rnd.randstr(False, 100), str)
    assert isinstance(rnd.randstr(True, 100), str)
    # Test that string contains only letters and numbers
    s = rnd.randstr(False, 100)
    assert all([(c in string.ascii_letters + string.digits) for c in s])
    assert len(s) == 100
    # Test that string length is between 16 and 128
    for _ in range(100):
        s = rnd.randstr(False)
        assert (16 <= len(s) <= 128)


# Generated at 2022-06-23 21:58:16.356923
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method ``custom_code`` of class ``Random()``."""

    def random_code(mask: str = '@###',
                    char: str = '@', digit: str = '#') -> str:
        """Generate random code using a given format.

        :param mask: Mask of code.
        :param char: Placeholder for characters.
        :param digit: Placeholder for digits.
        :return: Custom code.
        """
        #  Unicode code of ``A`` letter.
        _A = 65
        #  Unicode code of ``Z`` letter.
        _Z = 90
        #  Unicode code of ``0`` digit.
        _0 = 48
        #  Unicode code of ``9`` digit.
        _9 = 58

        char_code = ord(char)

# Generated at 2022-06-23 21:58:17.423824
# Unit test for method uniform of class Random
def test_Random_uniform():
    __test_Random_uniform(random)


# Generated at 2022-06-23 21:58:24.189136
# Unit test for method randints of class Random
def test_Random_randints():
    """Test function randints() of class Random.
    """
    rnd = Random()
    assert len(rnd.randints(amount=10, a=1, b=100)) == 10
    assert len(rnd.randints(amount=100, a=1, b=1000)) == 100
    assert len(rnd.randints(amount=1000, a=1, b=10000)) == 1000
    assert len(rnd.randints(amount=10000, a=1, b=100000)) == 10000

# Generated at 2022-06-23 21:58:24.869066
# Unit test for constructor of class Random
def test_Random():
    r = Random()

# Generated at 2022-06-23 21:58:26.316155
# Unit test for method urandom of class Random
def test_Random_urandom():
    #: :type: Random
    r = Random()
    r.urandom(100)

# Generated at 2022-06-23 21:58:29.813279
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    lst = r.randints()
    assert len(lst) == 3
    for e in lst:
        assert e > 0 and e < 100



# Generated at 2022-06-23 21:58:32.755214
# Unit test for method urandom of class Random
def test_Random_urandom():
    amount = 5
    length = 128
    print('\nRandom byte sequence of length {0} bytes:')
    for _ in range(amount):
        print(Random().urandom(length))



# Generated at 2022-06-23 21:58:33.773173
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(discipline)

# Generated at 2022-06-23 21:58:37.706779
# Unit test for method randints of class Random
def test_Random_randints():
    arr1 = random.randints(10)
    assert len(arr1) == 10
    arr2 = random.randints(a=0, b=10, amount=15)
    assert len(arr2) == 15
    arr3 = random.randints(0, 100, 10)
    assert len(arr3) == 10

# Generated at 2022-06-23 21:58:49.326664
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random(123)
    assert rnd.randints(5, 1, 2) == [1, 1, 2, 1, 2]
    assert rnd.randints(10, -100, -50) == [-100, -100, -100, -100, -54,
                                           -100, -56, -100, -100, -54]
    assert rnd.randints(amount=5, b=5, a=5) == [5, 5, 5, 5, 5]
    assert rnd.randints(a=1, b=1, amount=5) == [1, 1, 1, 1, 1]
    assert rnd.randints(3, 1, 15) == [9, 3, 8]
    assert rnd.randints(3, 15, 1) == [8, 12, 8]

# Generated at 2022-06-23 21:58:50.882148
# Unit test for method urandom of class Random
def test_Random_urandom():
    result = random.urandom(3)
    assert len(result) == 3

# Generated at 2022-06-23 21:58:53.859561
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    rand_ints = rnd.randints(amount=10)
    assert rand_ints
    assert len(rand_ints) == 10

# Generated at 2022-06-23 21:58:55.192769
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(2) == os.urandom(2)

# Generated at 2022-06-23 21:58:57.651182
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for correctness of the method randints of class Random."""
    rnd = Random()
    lst = rnd.randints(amount=5)
    assert len(lst) == 5



# Generated at 2022-06-23 21:59:01.956262
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    if random.generate_string(str_seq="abcdefghijklmnopqrstuvwxyz",
                              length=10) not in "abcdefghijklmnopqrstuvwxyz":
        raise AssertionError("Test failed: generate_string")


# Generated at 2022-06-23 21:59:06.197117
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test for the method randstr from class Random."""
    # This test is used to check that method randstr returns only
    # unique strings when parameter unique is True.
    res = []
    r = Random()
    for i in range(100):
        res.append(r.randstr(unique=True))

    assert len(set(res)) == len(res)

# Generated at 2022-06-23 21:59:14.150816
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test the ``randstr`` method for class ``Random``."""
    rnd = Random()
    s = rnd.randstr()
    assert isinstance(s, str)

    s1 = rnd.randstr()
    s2 = rnd.randstr()
    assert s1 != s2

    s1 = rnd.randstr(length=32)
    assert isinstance(s1, str)
    assert len(s1) == 32

    s1 = rnd.randstr(unique=True)
    assert isinstance(s1, str)
    s2 = rnd.randstr(unique=True)
    assert s1 != s2

# Generated at 2022-06-23 21:59:20.796526
# Unit test for function get_random_item
def test_get_random_item():
    import unittest
    from unittest.mock import patch

    class TestCase(unittest.TestCase):

        @patch('mimesis.helpers.random_module')
        def test_get_random_item(self, random_module):
            enum = ['a', 'b', 'c', 'd']
            random_module.choice.return_value = 'd'

            result = get_random_item(enum)

            random_module.choice.assert_called_once_with(enum)
            self.assertEqual(result, 'd')

        def test_get_random_item_custom_rand(self):
            enum = ['a', 'b', 'c', 'd']
            rnd = Random()
            result = get_random_item(enum, rnd=rnd)
            # random.

# Generated at 2022-06-23 21:59:21.708561
# Unit test for constructor of class Random
def test_Random():
    assert type(Random()) is Random


# Generated at 2022-06-23 21:59:29.089750
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    import random
    import numpy as np
    random_item = get_random_item(Gender)
    random.seed(0)
    random_item1 = get_random_item(Gender, rnd=random)
    random.seed(0)
    random_item2 = get_random_item(Gender, rnd=random)
    assert random_item==random_item1==random_item2

# Generated at 2022-06-23 21:59:32.002835
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    _random = Random()
    _list_of_ints = _random.randints(amount=5, a=40, b=50)
    assert len(_list_of_ints) == 5
    assert all(i >= 40 and i < 50 for i in _list_of_ints)



# Generated at 2022-06-23 21:59:33.838284
# Unit test for method urandom of class Random
def test_Random_urandom():  # noqa: D103
    assert Random().urandom(10) == \
           os.urandom(10)



# Generated at 2022-06-23 21:59:38.701066
# Unit test for method uniform of class Random
def test_Random_uniform():
    # given
    a = 0.0
    b = 10.0
    precision = 15
    c = random.uniform(a, b)
    d = precision
    
    # and
    assert(a <= c <= b)
    
    # and
    assert(len(str(c).split('.')[1]) == d)

# Generated at 2022-06-23 21:59:49.025364
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import CardType
    from mimesis.enums import Gender
    from mimesis.enums import ProcessType
    from mimesis.exceptions import NonEnumerableError
    from mimesis.exceptions import NonExistent

    random_ = Random()

    assert isinstance(get_random_item(CardType), CardType)
    assert isinstance(get_random_item(Gender), Gender)
    assert isinstance(get_random_item(ProcessType), ProcessType)

    try:
        get_random_item(int)
    except NonEnumerableError as error:
        assert error

    try:
        get_random_item(str)
    except NonEnumerableError as error:
        assert error


# Generated at 2022-06-23 21:59:54.299993
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    _random = Random(seed=42)
    res = _random.generate_string("abcdefg")
    assert res == "dfgecbb", "Random.generate_string(string) failed"

    res = _random.generate_string("123456789", 4)
    assert res == "3215", "Random.generate_string(string, int) failed"



# Generated at 2022-06-23 21:59:55.427620
# Unit test for method urandom of class Random
def test_Random_urandom():
    data = random.urandom(10)
    assert len(data) == 10

# Generated at 2022-06-23 21:59:58.010607
# Unit test for method randstr of class Random
def test_Random_randstr():
    result = random.randstr()
    assert len(result) >= 16

    result = random.randstr(unique=False, length=15)
    assert len(result) == 15



# Generated at 2022-06-23 21:59:59.481572
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(amount=10, a=1, b=10) == [5, 1, 4, 4, 1, 3, 3, 5, 5, 6]

# Generated at 2022-06-23 22:00:01.012418
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r.random(), float)
    assert isinstance(r.getrandbits(7), int)



# Generated at 2022-06-23 22:00:07.682442
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random(256)

    rnd.random()
    rnd.random()
    rnd.custom_code(mask='###-@##')
    rnd.custom_code(mask='###-#@#')
    rnd.custom_code(mask='###-#@X')
    rnd.custom_code(mask='###-#@X')
    rnd.custom_code(mask='###X#@X')
    rnd.custom_code(mask='###-#@#')
    rnd.custom_code(mask='###X#@X')
    rnd.custom_code(mask='###-#@#')
    rnd.custom_code(mask='###-#@#')
    rnd.custom_code(mask='###-#@#')

# Generated at 2022-06-23 22:00:17.025317
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    data=['1234567890','!@#$%^&*()','qwertyuio','rtyuiop','azxcvbnm','AQWSEDRF','|}{POIUY','eiuop','mjhgfd','lkjhnb']
    result=[]
    for i in range(0,len(data)):
        r=Random()
        result.append(r.generate_string(data[i]))
    print("\n")
    print("Testing result for methos generate_string of class Random:\n")
    for i in range(0,len(result)):
        print("\t",data[i],"-->",result[i])


# Generated at 2022-06-23 22:00:19.623341
# Unit test for method urandom of class Random
def test_Random_urandom():
    _len = 1024
    data = random.urandom(_len)
    assert len(data) == _len
    assert isinstance(data, bytes)



# Generated at 2022-06-23 22:00:21.343158
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert type(Random().uniform(0.0, 1.0)) == float


# Generated at 2022-06-23 22:00:22.622954
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(), bytes)



# Generated at 2022-06-23 22:00:25.405321
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    digits = '0123456789'
    result = random.generate_string(digits, length=5)
    assert len(result) == 5
    assert result.isdigit()
    assert result.isnumeric()

# Generated at 2022-06-23 22:00:36.693986
# Unit test for method randstr of class Random
def test_Random_randstr():
    s = random.randstr()
    assert len(s) >= 16 and len(s) <= 128
    assert isinstance(s, str)
    s = random.randstr(unique=False)
    assert len(s) >= 16 and len(s) <= 128
    assert isinstance(s, str)
    s = random.randstr(unique=True)
    assert isinstance(s, str)
    assert len(s) == 32
    s = random.randstr(unique=True, length=None)
    assert isinstance(s, str)
    assert len(s) == 32
    s = random.randstr(unique=True, length=64)
    assert isinstance(s, str)
    assert len(s) == 64

# Generated at 2022-06-23 22:00:39.376360
# Unit test for method uniform of class Random
def test_Random_uniform():
    my_rnd = Random()
    assert my_rnd.uniform(5, 10) == 5.0
    assert my_rnd.uniform(10, 5) == 5.0

# Generated at 2022-06-23 22:00:41.928778
# Unit test for function get_random_item
def test_get_random_item():
    class E(object):
        class Test(object):
            a = 'a'
            b = 'b'

    assert get_random_item(E.Test) in (E.Test.a, E.Test.b)

# Generated at 2022-06-23 22:00:45.700410
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    assert random.uniform(1.22, 1.23) == 1.22
    assert random.uniform(1.22, 1.23, 1) == 1.22
    assert random.uniform(1.22, 1.23, 3) == 1.229

# Generated at 2022-06-23 22:00:48.147706
# Unit test for function get_random_item
def test_get_random_item():
    class Test(object):
        ONE = 1
        TWO = 2
    assert get_random_item(Test) in [Test.ONE, Test.TWO]


# Generated at 2022-06-23 22:00:55.652448
# Unit test for method uniform of class Random
def test_Random_uniform():
    precision = 5
    r1 = random.uniform(1.2574, 5.1451, precision)
    r2 = random.uniform(1.2574, 5.1451, precision)
    r3 = random.uniform(1.2574, 5.1451, precision)
    assert (1.2574 <= r1 < 5.1451) and (1.2574 <= r2 < 5.1451) and (1.2574 <= r3 < 5.1451)
    assert isinstance(r1, float) and isinstance(r2, float) and isinstance(r3, float)

# Generated at 2022-06-23 22:00:59.618319
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)
    assert isinstance(Random(42), Random)
    assert isinstance(Random('42'), Random)
    assert isinstance(Random(42), Random)
    assert isinstance(Random(b'42'), Random)


# Generated at 2022-06-23 22:01:02.462318
# Unit test for method urandom of class Random
def test_Random_urandom():
    # if not isinstance(random.urandom(10), bytes):
    if not isinstance(Random.urandom(10), bytes):
        raise ValueError('Method Random.urandom not work!')

# Generated at 2022-06-23 22:01:05.115323
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of class Random()."""
    r = random.uniform(1, 2)
    assert r >= 1 and r < 2

# Generated at 2022-06-23 22:01:07.439837
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for the method ``urandom()`` of the class ``Random()``."""
    rnd = Random()
    res = rnd.urandom()
    assert isinstance(res, bytes)



# Generated at 2022-06-23 22:01:09.704042
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string(string.digits + string.ascii_letters, 10) == 'Dz7VuEaNbF'


# Generated at 2022-06-23 22:01:13.595286
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    result1 = rnd.generate_string('12345')
    result2 = rnd.generate_string('ABCDE', 3)
    result3 = rnd.generate_string('ABCDE')
    result4 = rnd.generate_string('1', 0)

    assert (result1 + result2 + result3 + result4) is not None

# Generated at 2022-06-23 22:01:21.352572
# Unit test for constructor of class Random
def test_Random():
    min_value = 5
    max_value = 15
    assert min_value <= random.randint(min_value, max_value) <= max_value
    assert random.random() < 1.0
    assert random.random() > 0.0
    assert 0 <= random.randrange(max_value) < max_value
    assert random.sample('abcdefghij', k=2)
    assert random.choice(['a', 'b', 'c'])
    assert random.choices(['a', 'b', 'c'], weights=[0.5, 0.5, 0.5])


# Generated at 2022-06-23 22:01:24.315861
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    r.uniform(1, ((10 ** 4) - 1) / (10 ** 4), precision=4)
    r.uniform(1, 10)
    r.uniform(0, 1)



# Generated at 2022-06-23 22:01:28.587148
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random(1)
    assert rnd.randints(10, 1, 10) == [2, 3, 3, 5, 7, 8, 8, 5, 9, 10]
    assert rnd.randints(3) == [50, 85, 74]



# Generated at 2022-06-23 22:01:32.328329
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()

    a = 99.99
    b = 99.999
    precision = 3
    expected = round(a + (b - a) * r.random(), precision)
    got = r.uniform(a, b, precision)
    assert expected == got