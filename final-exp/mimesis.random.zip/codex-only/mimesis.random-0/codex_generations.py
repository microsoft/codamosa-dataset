

# Generated at 2022-06-23 21:51:29.394254
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    assert len(rnd.generate_string('0123456789', length=5)) == 5

# Generated at 2022-06-23 21:51:30.955259
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(10), bytes)

# Generated at 2022-06-23 21:51:39.974651
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    result = random.custom_code(mask='##/@@/@@@',
                                char='@',
                                digit='#')
    assert len(result) == 8
    assert result.startswith('##/')
    assert '/' in result
    assert result[-3:].isalnum()
    assert len(result.split('/')) == 2
    # See: https://github.com/lk-geimfari/mimesis/issues/497
    assert random.custom_code('#,#,#,#', char='#', digit='#') == '#,#,#,#'
    assert random.custom_code('#,#,#,#', char='#', digit='#') != '#,#,#'

# Generated at 2022-06-23 21:51:44.515345
# Unit test for function get_random_item
def test_get_random_item():
    rnd = Random()

    class Test:
        test_item = 'test_item'

    assert get_random_item(Test, rnd) == 'test_item'
    assert get_random_item(Test) == 'test_item'

# Generated at 2022-06-23 21:51:52.280662
# Unit test for method uniform of class Random
def test_Random_uniform():
    """ Unit test for method uniform of class Random.
    """
    r = Random()
    r.seed(4)
    assert r.uniform(1.2, 3.6) == 2.8
    assert r.uniform(1.2, 3.6, 4) == 2.8
    assert r.uniform(1.2, 3.6, 3) == 2.75
    assert r.uniform(1.2, 3.6, 2) == 2.8
    assert r.uniform(1.2, 3.6, 1) == 2.8
    assert r.uniform(0.95, 1.05, 8) == 1.0

# Generated at 2022-06-23 21:51:54.668064
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import OperatingSystem
    random_os = get_random_item(OperatingSystem)
    isinstance(random_os, OperatingSystem)

# Generated at 2022-06-23 21:51:56.727682
# Unit test for method uniform of class Random
def test_Random_uniform():
    is_equal = random.uniform(1, 5, precision=5) == 1.93801
    assert is_equal, "uniform method is incorrect"

# Generated at 2022-06-23 21:52:05.626467
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random(4)
    assert r.seed(4) is None
    data = r.randints(5, 0, 9)
    assert data == [1, 1, 4, 5, 6]

    r = Random()
    assert r.seed() is None
    data = r.randints(5, 0, 9)
    assert type(data) == list

    # Exception, amount less or equal to zero
    r = Random()
    assert r.seed(7) is None
    try:
        r.randints(0, 1, 10)
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-23 21:52:09.535061
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for method uniform of class Random."""
    for _ in range(100):
        rand = random.uniform(0, 1)
        assert rand >= 0.0 and rand <= 1.0

# Generated at 2022-06-23 21:52:14.353210
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()

    # noinspection SpellCheckingInspection
    assert rnd.custom_code('@###') == 'A942'

    # noinspection SpellCheckingInspection
    assert rnd.custom_code('@###', '-', '#') == 'A942'

# Generated at 2022-06-23 21:52:18.488568
# Unit test for method uniform of class Random
def test_Random_uniform():
    _rnd = Random()
    _rnd.seed(1)
    assert _rnd.uniform(1.1, 1.2) == 1.1930725040407835

# Generated at 2022-06-23 21:52:19.837047
# Unit test for method randstr of class Random
def test_Random_randstr():
    _string = random.randstr()
    assert isinstance(_string, str)

# Generated at 2022-06-23 21:52:28.140808
# Unit test for constructor of class Random
def test_Random():
    class A:
        def __init__(self, a: int, b: int) -> None:
            self._a = a
            self._b = b

        def __call__(self, *args: Any, **kwargs: Any) -> int:
            return random_module.randint(self._a, self._b)

    a = A(2, 6)
    r1 = Random(None, a)
    assert r1.randint(2, 6) == 2

    r2 = Random(None, [1, 23, 4])
    assert r2.choice([1, 23, 4]) == 4

    assert get_random_item('string') == 's'

# Generated at 2022-06-23 21:52:35.260251
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string('Hello', 5) in ['Hello', 'Helll', 'elllo', 'oHell', 'HellH']
    assert random.generate_string('', 0) == ''
    assert random.generate_string('', 5) == ''
    assert random.generate_string('123', 5) in ['12311', '33112', '32123', '11123', '12331']
    assert random.generate_string('abc', 5) in ['aacbb', 'babac', 'ccaba', 'baacb', 'acbac']

# Generated at 2022-06-23 21:52:44.862732
# Unit test for function get_random_item
def test_get_random_item():
    import unittest
    import enum

    class TestEnum(enum.Enum):
        TEST_1 = 1
        TEST_2 = 2

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.enum = TestEnum
            self.rnd = Random()

        def test_get_random_item(self):
            random_ = get_random_item(self.enum)
            self.assertEqual(True, isinstance(random_, self.enum))

        def test_with_custom_random(self):
            random_ = get_random_item(self.enum, self.rnd)
            self.assertEqual(True, isinstance(random_, self.enum))

    unittest.main()

# Generated at 2022-06-23 21:52:49.743385
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    assert len(random.urandom(16)) == 16
    assert len(random.urandom(24)) == 24
    assert len(random.urandom(32)) == 32
    assert len(random.urandom(64)) == 64

# Generated at 2022-06-23 21:52:53.564430
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    s = Random()
    test_s = s.custom_code(mask='@###')
    assert isinstance(test_s, str)
    assert len(test_s) == 4

test_Random_custom_code()

# Generated at 2022-06-23 21:52:54.524407
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random.urandom(), bytes)

# Generated at 2022-06-23 21:53:00.385624
# Unit test for method uniform of class Random
def test_Random_uniform():
    print('test_Random_uniform ...')
    r = Random()
    a = r.uniform(13, 37, precision=1)
    print(a)
    assert 0 <= a <= 99
    assert (type(a) is float)

if __name__ == '__main__':
    test_Random_uniform()

# Generated at 2022-06-23 21:53:05.386665
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    result_code = rnd.custom_code(mask='####-@@@-##')
    assert len(result_code) == 13
    assert len(result_code.split('-')) == 3
    assert result_code[4] == '-'
    assert result_code[9] == '-'

# Generated at 2022-06-23 21:53:13.962188
# Unit test for method randints of class Random
def test_Random_randints():
    # First is default
    assert len(Random().randints()) == 3

    # Second
    assert len(Random().randints(5)) == 5

    # Third
    assert len(Random().randints(5, a=2, b=5)) == 5

    # Fourth
    r = Random()
    a, b = 0, 100
    array = r.randints(10, a, b)
    assert len(array) == 10
    assert all(x <= b and x >= a for x in array)

    # Fifth
    r = Random()
    a, b = -100, 100
    array = r.randints(30, a, b)
    assert len(array) == 30
    assert all(x <= b and x >= a for x in array)

    # Six

# Generated at 2022-06-23 21:53:18.072661
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code('@###', char='@', digit='#')
    assert len(code) == 4, \
        'Length of code should be 4, but instead got {}'.format(len(code))

# Generated at 2022-06-23 21:53:21.952188
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(random.choice,random)==random.choice
    assert get_random_item(list(range(10))) in list(range(10))
    assert get_random_item(list(range(10)),random) in list(range(10))

# Generated at 2022-06-23 21:53:28.218003
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    temp = Random()
    assert isinstance(temp.generate_string('0,1'), str)
    assert isinstance(temp.generate_string('0,1', length=3), str)
    assert isinstance(temp.generate_string(str_seq='0,1'), str)
    assert isinstance(temp.generate_string(str_seq='0,1', length=3), str)
    assert len(temp.generate_string('0,1', length=3)) == 3
    assert len(temp.generate_string('0,1', length=7)) == 7
    assert len(temp.generate_string('0,1', length=100)) == 100
    assert len(temp.generate_string('0,1', length=4)) == 4

# Generated at 2022-06-23 21:53:38.840980
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    string = random.custom_code()
    assert isinstance(string, str)
    assert len(string) == 4

    string = random.custom_code('abcd')
    assert isinstance(string, str)
    assert len(string) == 4

    string = random.custom_code('@###')
    assert isinstance(string, str)
    assert len(string) == 4

    string = random.custom_code('@@@@')
    assert isinstance(string, str)
    assert len(string) == 4

    string = random.custom_code('@@@@', '@', '#')
    assert isinstance(string, str)
    assert len(string) == 4

    string = random.custom_code('#@#@#@#@#@#@#')
    assert isinstance(string, str)
    assert len(string) == 13

   

# Generated at 2022-06-23 21:53:39.503891
# Unit test for function get_random_item
def test_get_random_item():
    get_random_item(random_module)

# Generated at 2022-06-23 21:53:41.170136
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    for i in range(20):
        x = r.uniform(-1, 1)
        assert x >= -1 and x <= 1, i

# Generated at 2022-06-23 21:53:50.427038
# Unit test for function get_random_item
def test_get_random_item():
    # Defining enum
    class MonthEnum:
        JANUARY = 1
        FEBRUARY = 2

    # Getting random item
    random_item = get_random_item(MonthEnum)
    assert isinstance(random_item, int)
    assert random_item in [1, 2]

    # Getting random item using Custom object
    rnd = Random()
    random_item = get_random_item(MonthEnum, rnd=rnd)
    assert isinstance(random_item, int)
    assert random_item in [1, 2]

# Generated at 2022-06-23 21:53:52.858582
# Unit test for method urandom of class Random
def test_Random_urandom():
    rnd = Random()
    assert isinstance(rnd.urandom(3), bytes)



# Generated at 2022-06-23 21:53:56.858400
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code('@@@###') == 'ABC123'
    assert rnd.custom_code('@###', '#') == 'A123'
    assert rnd.custom_code('@') == 'A'

# Unit tests for method randstr of class Random

# Generated at 2022-06-23 21:54:02.361768
# Unit test for function get_random_item
def test_get_random_item():
    def mock_enum(**enums):
        return type("MockEnum", (), enums)

    enum = mock_enum(a=1, b=2, c=3)
    assert 1 <= get_random_item(enum) <= 3
    assert 1 <= get_random_item(enum, random) <= 3

# Generated at 2022-06-23 21:54:04.342700
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    all_letters = string.ascii_lowercase + string.digits
    string = Random().generate_string(all_letters)
    assert len(string) == 10

# Generated at 2022-06-23 21:54:08.039925
# Unit test for method randints of class Random
def test_Random_randints():
    assert Random().randints(amount=3) == [41, 5, 41]



# Generated at 2022-06-23 21:54:17.728620
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    lst = r.randints()
    assert (isinstance(lst, list))
    assert (len(lst) == 3)
    for el in lst:
        assert (isinstance(el, int))

    lst = r.randints(amount=5)
    assert (isinstance(lst, list))
    assert (len(lst) == 5)

    lst = r.randints(amount=5, a=0)
    assert (isinstance(lst, list))
    assert (len(lst) == 5)
    for el in lst:
        assert (el >= 0)
        assert (el <= 100)

    lst = r.randints(amount=5, a=0, b=50)
    assert (isinstance(lst, list))

# Generated at 2022-06-23 21:54:24.861839
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    res = random.custom_code('#')
    assert 0 <= int(res) <= 9

    res = random.custom_code('@@')
    assert 65 <= ord(res[0]) <= 90
    assert 65 <= ord(res[1]) <= 90

    res = random.custom_code('@##')
    assert 65 <= ord(res[0]) <= 90
    assert 48 <= ord(res[1]) <= 57
    assert 48 <= ord(res[2]) <= 57

    res = random.custom_code('@###@#')
    assert 65 <= ord(res[0]) <= 90
    assert 48 <= ord(res[1]) <= 57
    assert 48 <= ord(res[2]) <= 57
    assert 48 <= ord(res[3]) <= 57
    assert 65 <= ord(res[4]) <= 90

# Generated at 2022-06-23 21:54:29.759276
# Unit test for constructor of class Random
def test_Random():
    assert random.randint(1, 9)
    assert random.randrange(1, 9)
    assert random.randints(amount=3)
    assert random.randints(amount=3, a=0, b=0)

    assert random.uniform(0, 10)
    assert random.random()

    assert random.randstr()
    assert random.randstr(unique=True)

    assert random.choice(list(random.providers))

# Generated at 2022-06-23 21:54:31.416982
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    s = Random().generate_string('abcd', 8)
    assert(any(elem in s for elem in 'abcd'))
    assert(len(s) == 8)


# Generated at 2022-06-23 21:54:43.145492
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    number = rnd.uniform(-1, 1)
    assert -1 <= number <= 1
    number = rnd.uniform(0, 0.5)
    assert 0 <= number <= 0.5
    number = rnd.uniform(1, 1)
    assert number == 1
    number = rnd.uniform(1, 1.5)
    assert 1 <= number <= 1.5
    number = rnd.uniform(1.5, 2)
    assert 1.5 <= number <= 2
    # test_Random_uniform_negative
    number = rnd.uniform(-2, 0)
    assert -2 <= number <= 0
    number = rnd.uniform(-0.5, 0)
    assert -0.5 <= number <= 0

# Generated at 2022-06-23 21:54:47.040195
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert isinstance(rnd.randints(), list)
    assert isinstance(rnd.randints(5), list)
    assert isinstance(rnd.randints(a=5, b=15), list)
    assert isinstance(rnd.randints(5, 5, 15), list)
    assert len(rnd.randints(5))==5


# Generated at 2022-06-23 21:54:53.643348
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method ``custom_code()`` of ``Random`` class.

    :return: ``True`` if test ok, ``False`` if fails.
    """
    rnd = Random()
    code = rnd.custom_code(mask='@###', char='@', digit='#')
    assert code[0].isalpha() and code[1:].isdigit()
    return True


if __name__ == '__main__':
    print(test_Random_custom_code())

# Generated at 2022-06-23 21:54:56.141270
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string(str_seq='abc', length=10) \
           == 'cabacabcac'


# Generated at 2022-06-23 21:54:57.978165
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    result = get_random_item(Gender, random)
    assert result
    assert result in Gender.__members__.values()

# Generated at 2022-06-23 21:55:03.128704
# Unit test for function get_random_item
def test_get_random_item():
    from faker.providers.internet import Provider as Internet
    enum_internet = Internet.get_internet_protocol_version
    random_item = get_random_item(enum_internet)
    for i in enum_internet:
        if i == random_item:
            break
    assert i == random_item


# Generated at 2022-06-23 21:55:09.834266
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for method uniform of class Random."""
    assert Random().uniform(a=0, b=1) == 0.5, 'Wrong result.'
    assert Random().uniform(a=0, b=0.5) == 0, 'Wrong result.'
    assert Random().uniform(a=0, b=1.5) == 0, 'Wrong result.'
    assert Random().uniform(a=0.5, b=1) == 0.5, 'Wrong result.'

# Generated at 2022-06-23 21:55:12.533576
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    r = random.uniform(0.0, 3.2)
    assert 0.0 <= r < 3.2
    assert isinstance(r, float)

# Generated at 2022-06-23 21:55:15.072330
# Unit test for constructor of class Random
def test_Random():
    # test if it works correctly
    rnd = Random()
    assert rnd.random() in [0.0, 1.0]

    assert rnd.randint(1, 100)

# Generated at 2022-06-23 21:55:17.254228
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random.urandom(), bytes)
    assert Random.urandom() == Random.urandom()


# Generated at 2022-06-23 21:55:20.370130
# Unit test for method randstr of class Random
def test_Random_randstr():
    for _ in range(10):
        val1 = random.randstr()
        val2 = random.randstr()

        assert len(val1) > 1
        assert len(val2) > 1
        assert val1 != val2

# Generated at 2022-06-23 21:55:22.878916
# Unit test for method urandom of class Random
def test_Random_urandom():
    _len = random.randint(1, 100)
    _bytes = random.urandom(_len)
    assert len(_bytes) == _len

# Generated at 2022-06-23 21:55:25.499744
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(unique=True), str)
    assert isinstance(random.randstr(unique=True, length=32), str)
    assert isinstance(random.randstr(unique=False, length=32), str)
    assert isinstance(random.randstr(), str)

# Generated at 2022-06-23 21:55:27.164419
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(random.Gender) in random.Gender

# Generated at 2022-06-23 21:55:38.040419
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    nums = [i for i in range(10)]
    print(nums)
    letters = [chr(i) for i in range(97, 123)]
    print(letters)
    print(random.choice(nums))
    print(random.choice(letters))
    res = random.generate_string("".join(letters + [str(i) for i in nums]))
    print(res)
    res = random.generate_string("".join(letters + [str(i) for i in nums]), 12)
    print(res)
    res = random.generate_string("".join(letters + [str(i) for i in nums]), 2)
    print(res)



# Generated at 2022-06-23 21:55:40.785245
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code('@###', '@') == 'AAA1'

# Generated at 2022-06-23 21:55:43.895837
# Unit test for method randstr of class Random
def test_Random_randstr():
    import time
    from collections import Counter

    start_time = time.time()
    uniques = Counter()
    for _ in range(100000):
        s = Random().randstr()
        uniques[s] += 1
    elapsed = time.time() - start_time
    print('Uniques: {}. Elapsed: {}'.format(len(uniques), elapsed))
    print(uniques)
    assert len(uniques) == 100000
    assert elapsed < 4



# Generated at 2022-06-23 21:55:48.045179
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test urandom method of class Random."""
    a = Random().urandom(100)
    try:
        a.decode()
    except Exception:
        raise ValueError('Wrong data format!')

# Generated at 2022-06-23 21:55:55.636831
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test method randstr of class Random.
    """
    rnd = Random()
    res = rnd.randstr()
    assert isinstance(res, str)
    assert len(res) <= 128
    assert len(res) >= 16
    res = rnd.randstr(unique=True)
    assert isinstance(res, str)
    assert len(res) == 32
    res = rnd.randstr(unique=False, length=64)
    assert isinstance(res, str)
    assert len(res) == 64

# Generated at 2022-06-23 21:56:04.662552
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from mimesis.enums import Gender
    g = Gender.MALE
    f = Gender.FEMALE

    for _ in range(4):
        code = Random().custom_code(mask='@###')
        assert len(code) == 4
        assert code[0].isalpha()
        assert code[1:].isdigit()

    for _ in range(4):
        code = Random().custom_code(mask='@#@#@#@#@#@#@#@#@#@#@#@#@#@#@')
        assert len(code) == 23
        assert code[0].isalpha()
        assert code[1].isdigit()
        assert code[2].isalpha()
        assert code[3].isdigit()

    code = Random().custom_code(mask='@###C#@#', char='@', digit='#')

# Generated at 2022-06-23 21:56:15.208576
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    first_string = rnd.custom_code()
    second_string = rnd.custom_code('@#')
    assert isinstance(first_string, str)
    assert isinstance(second_string, str)
    assert len(first_string) == 4
    assert len(second_string) == 3
    assert '@' not in first_string + second_string
    assert '#' not in first_string + second_string
    assert '@@' not in first_string
    assert '##' not in first_string
    assert '@@' not in second_string
    assert '##' not in second_string
    assert '@@' not in first_string
    assert '##' not in first_string


# Generated at 2022-06-23 21:56:24.424414
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('zzz@@##@@##') == 'zzzMP95MP95'
    assert Random().custom_code('zzz@@##@@##', char='Z', digit='D') == 'zzzMP95MP95'
    assert Random().custom_code('zzz@@##@@##', char='Z', digit='Z') == 'zzzMP95MP95'
    assert Random().custom_code('zzz@@##@@##', char='Z', digit='@') == 'zzzMP95MP95'
    assert Random().custom_code('zzz@@##@@##', char='Z', digit='#') == 'zzzMP95MP95'
    assert Random().custom_code('zzz@@##@@##', char='@', digit='Z') == 'zzzMP95MP95'

# Generated at 2022-06-23 21:56:32.040437
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    lst = random.randints()
    assert len(lst) == 3
    assert all([isinstance(item, int) for item in lst])

    lst = random.randints(amount=4)
    assert len(lst) == 4
    assert all([isinstance(item, int) for item in lst])

    with random_module.random() as rnd:
        lst = rnd.randints()
        assert len(lst) == 3
        assert all([isinstance(item, int) for item in lst])

        lst = rnd.randints(amount=4)
        assert len(lst) == 4
        assert all([isinstance(item, int) for item in lst])



# Generated at 2022-06-23 21:56:34.510781
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    for _ in range(100):
        result = random.generate_string('Hello')
        assert len(result) == 10
        assert isinstance(result, str)



# Generated at 2022-06-23 21:56:37.178271
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random(1)
    assert r.generate_string('abc') == 'abcabcabcabcabcabc'
    assert r.generate_string('abc', 5) == 'aaaaa'



# Generated at 2022-06-23 21:56:47.136024
# Unit test for method randints of class Random
def test_Random_randints():
    # Random
    rnd = Random(42)
    values = rnd.randints(10, 10, 12)
    res = [11, 11, 10, 11, 11, 10, 10, 11, 11, 10]
    assert values == res

    # With negative amount
    rnd = Random(42)
    values = rnd.randints(-1, 10, 12)
    res = []
    assert values == res

    # Same as above but with a greater amount
    values = rnd.randints(-10, 10, 12)
    res = []
    assert values == res

    # Without max value (1-10)
    rnd = Random(42)
    values = rnd.randints()
    res = [3, 4, 5]
    assert values == res

    # With negative amount

# Generated at 2022-06-23 21:56:51.778569
# Unit test for method urandom of class Random
def test_Random_urandom():
    _args = (
        (1, ),
        (2, ),
        (3, ),
        (4, ),
        (5, ),
        (6, ),
        (7, ),
        (8, ),
        (9, ),
        (16, ),
    )
    for _arg in _args:
        assert len(Random().urandom(*_arg)) == _arg[0]

# Generated at 2022-06-23 21:56:53.348234
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random.urandom(), bytes)


# Generated at 2022-06-23 21:56:55.832381
# Unit test for constructor of class Random
def test_Random():
    """Test init of the class Random."""
    assert isinstance(Random(), random_module.Random) is True



# Generated at 2022-06-23 21:56:59.825236
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for urandom method of class Random."""
    assert len(Random.urandom(32)) == 32
    assert len(Random.urandom(16)) == 16
    assert Random.urandom(32).__class__ == bytes
    assert Random.urandom(16).__class__ == bytes



# Generated at 2022-06-23 21:57:01.764557
# Unit test for method urandom of class Random
def test_Random_urandom():
    size = random.randint(16,128)
    rnd = Random()
    assert rnd.urandom(size) == os.urandom(size)

# Generated at 2022-06-23 21:57:10.130471
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code of class Random."""
    r = Random()
    for _ in range(1, 10):
        assert len(r.custom_code()) == 4
        assert len(r.custom_code('@@#')) == 4
        assert len(r.custom_code('@@@')) == 4
        assert len(r.custom_code('###')) == 4
        assert len(r.custom_code('@###', '#', '@')) == 4
        assert len(r.custom_code('#@@@', '#', '@')) == 4
        assert len(r.custom_code('@@@', '#', '@')) == 4


# Generated at 2022-06-23 21:57:17.321387
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    r = Random()
    r_str = r.generate_string(string.digits + string.ascii_lowercase)
    assert string.digits + string.ascii_lowercase == '0123456789abcdefghijklmnopqrstuvwxyz'
    assert r_str
    assert len(r_str) <= 10
    assert all(i in string.digits + string.ascii_lowercase for i in r_str)

# Generated at 2022-06-23 21:57:22.950428
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    r = Random()
    assert len(r.randstr()) == 36
    assert len(r.randstr(True)) == 36
    assert len(r.randstr(False)) <= 128
    assert len(r.randstr(False, 10)) == 10
    assert len(r.randstr(False, 198)) == 198

# Generated at 2022-06-23 21:57:24.176800
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@.###') == 'E.807'

# Generated at 2022-06-23 21:57:28.534297
# Unit test for method randstr of class Random
def test_Random_randstr():
    def is_any_duplicates(seq: List[Any]) -> bool:

        if set(seq) == seq:
            return False
        else:
            return True

    for _ in range(10):
        num = random.randint(1, 1000)
        values = [random.randstr(length=num) for _ in range(100)]

        result = is_any_duplicates(values)
        assert result is False, 'There are duplicates.'

# Generated at 2022-06-23 21:57:30.055551
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    n = r.uniform(0, 1, precision=10)
    assert isinstance(n, float), 'Expected float type but got {}'.format(type(n))

# Generated at 2022-06-23 21:57:32.554113
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    result = r.randints(amount=3, a=0, b=256)
    assert all([i in range(0, 256) for i in result])

# Generated at 2022-06-23 21:57:38.227448
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1.00, 3.00) >= 1.00
    assert random.uniform(1.00, 3.00) < 3.00
    assert random.uniform(10.00, 15.00) >= 10.00
    assert random.uniform(10.00, 15.00) < 15.00
    assert random.uniform(.1, .9) >= .1
    assert random.uniform(.1, .9) < .9
    assert random.uniform(-1.0, 1.0) >= -1.0
    assert random.uniform(-1.0, 1.0) < 1.0
    assert random.uniform(-3.00, -1.00) >= -3.00
    assert random.uniform(-3.00, -1.00) < -1.00


# Generated at 2022-06-23 21:57:43.281725
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for method urandom of class Random.

    Method ``urandom()`` of class ``Random`` checks for the presence
    of the ``os.urandom()`` method.

    If it is not implemented, the function ``NotImplementedError`` is raised.
    """
    with Random() as rnd:
        rnd.urandom()



# Generated at 2022-06-23 21:57:48.226027
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    r.random()
    r.randint(1, 100)
    r.randints(3, 1, 100)
    r.generate_string('123')
    r.custom_code('@###')
    r.uniform(1, 100)
    r.randstr()
    get_random_item(('one', 'two', 'three',))

# Generated at 2022-06-23 21:57:49.283964
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(10), bytes)

# Generated at 2022-06-23 21:57:55.977646
# Unit test for method uniform of class Random
def test_Random_uniform():
    a = 2.1235678
    b = 4
    precision = 2
    result = random.uniform(a, b, precision)
    assert len(str(result)) == 3

    a = -2.1235678
    b = -3
    precision = 2
    result = random.uniform(a, b, precision)
    assert len(str(result)) == 4

    a = 1
    b = 1.0000000001
    precision = 1
    result = random.uniform(a, b, precision)
    assert len(str(result)) == 5

# Generated at 2022-06-23 21:58:02.859314
# Unit test for method randints of class Random
def test_Random_randints():
    cases = [(10, 1, 100), (20, 45, 567), (3, 0, 567)]
    for case in cases:
        amount, a, b = case
        result = Random().randints(amount, a, b)
        assert amount == len(result)
        assert isinstance(result, list)
        for value in result:
            assert a <= value <= b
    print('Test for method randints in class Random is passed.')



# Generated at 2022-06-23 21:58:09.338663
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test method randstr of class Random."""
    # Test unique values
    unique_items = set()
    unique_items.add(random.randstr(unique=True))
    unique_items.add(random.randstr(unique=True))

    assert len(unique_items) == 2

    # Test length
    items = []
    items.append(random.randstr(length=10))
    items.append(random.randstr(length=10))

    assert len(items[0]) == 10
    assert items[0] != items[1]

# Generated at 2022-06-23 21:58:10.181974
# Unit test for constructor of class Random
def test_Random():
    assert Random().randstr() == random.randstr()

# Generated at 2022-06-23 21:58:15.877647
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    assert random.custom_code('@@@') == 'AAA'
    assert random.custom_code('##@') == '00A'
    assert random.custom_code('@@@', '@', '#') == 'AAA'
    assert random.custom_code('@@@', '#', '@') == '000'
    assert random.custom_code('@@@##') == 'AAA00'
    assert random.custom_code() == '111'

# Generated at 2022-06-23 21:58:17.327810
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(), bytes)



# Generated at 2022-06-23 21:58:27.048614
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()

    # test 1
    amount = 5
    a = 1
    b = 100
    result = rnd.randints(amount, a, b)
    assert isinstance(result, list)
    assert len(result) == amount
    for item in result:
        assert isinstance(item, int)
        assert a <= item < b

    # test 2
    amount = 20
    a = -100
    b = 100
    result = rnd.randints(amount, a, b)
    assert isinstance(result, list)
    assert len(result) == amount
    for item in result:
        assert isinstance(item, int)
        assert a <= item < b

    # test 3
    amount = 0
    a = -100
    b = 100

# Generated at 2022-06-23 21:58:30.152531
# Unit test for method randstr of class Random
def test_Random_randstr():
    _random = Random()
    _string = _random.randstr()

    assert isinstance(_string, str)
    assert len(_string) >= 16 and len(_string) <= 128

# Generated at 2022-06-23 21:58:38.831442
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code()
    assert r.custom_code(mask='@##@###') == 'E14L57', 'It has to be E14L57'
    assert r.custom_code(mask='@##@###', char='@', digit='#') == 'E14L57', 'It has to be E14L57'

    # Test with a mask with custom chars
    char_mask = '@(@&$'
    random_char = r.custom_code(mask=char_mask, char='@', digit='#')
    assert len(random_char) == len(char_mask)
    assert any([(char != '@' and char != '#' and char != random_char[index])
               for index, char in enumerate(char_mask)])

    # Test for

# Generated at 2022-06-23 21:58:44.405077
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert type(random.generate_string('abcd', 3)) is str
    assert len(random.generate_string('abcd', 5)) == 5
    assert len(random.generate_string('abcd')) == 10
    assert random.generate_string('abcd') in ['abcd' * 5, 'abcd' * 5]

# Generated at 2022-06-23 21:58:52.912232
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code(mask='@###', digit="#") == rnd.custom_code(mask='@###', char="@")
    assert rnd.custom_code(mask='@###', digit="@") == rnd.custom_code(mask='@###', char="#")
    assert rnd.custom_code(mask='@###', digit="*") != rnd.custom_code(mask='@###', digit="*")
    assert rnd.custom_code(mask='@###', digit="#") != rnd.custom_code(mask='@###', digit="#")

# Generated at 2022-06-23 21:58:53.932496
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(4) == os.urandom(4)

# Generated at 2022-06-23 21:58:59.916303
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import CardType, Gender, Profession
    random_card_type = get_random_item(CardType)
    random_gender = get_random_item(Gender)
    random_profession = get_random_item(Profession)
    assert random_card_type in CardType.__members__.values()
    assert random_gender in Gender.__members__.values()
    assert random_profession in Profession.__members__.values()

# Generated at 2022-06-23 21:59:02.311128
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(), str)
    assert not random.randstr(unique=True) == random.randstr()
    assert len(random.randstr(unique=False, length=200)) > 150
    assert len(random.randstr(unique=True)) == 32

# Generated at 2022-06-23 21:59:04.325862
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    res = r.custom_code()
    assert len(res) == 4, 'The length of the string is not 4'

# Generated at 2022-06-23 21:59:06.056733
# Unit test for constructor of class Random
def test_Random():
    """Test the class Random."""
    random = Random()
    assert len(random.randints()) == 3



# Generated at 2022-06-23 21:59:08.582518
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    sample = random.custom_code('@###', '@', '#')
    assert len(sample) == 4



# Generated at 2022-06-23 21:59:10.471417
# Unit test for method urandom of class Random
def test_Random_urandom():
    bytes_obj = Random.urandom(100)
    bytes_obj == os.urandom(100)

# Generated at 2022-06-23 21:59:12.392975
# Unit test for method uniform of class Random
def test_Random_uniform():
    import random
    for num in range(1000):
        assert isinstance(random.uniform(1.0, 2.0), float)


# Generated at 2022-06-23 21:59:14.102914
# Unit test for method urandom of class Random
def test_Random_urandom():
    b = Random().urandom(32)
    assert isinstance(b, bytes)
    assert len(b) == 32

# Generated at 2022-06-23 21:59:22.130220
# Unit test for method randstr of class Random
def test_Random_randstr():
    seed = 101
    random.seed(seed)
    assert random.randstr() == "a1ef5c629b0e4d8295af3d9e9de6c53b"
    assert random.randstr(length=20) == 'oRQJtuSP1OQyXewbLEcH'
    assert random.randstr(unique=True) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'
    random.seed(seed)
    assert random.randstr(unique=True) == 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3'

# Generated at 2022-06-23 21:59:23.466263
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert not Random().randstr(unique=True) == Random().randstr(unique=True)


if __name__ == '__main__':
    test_Random_randstr()

# Generated at 2022-06-23 21:59:25.485654
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.builtins.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)
    assert isinstance(get_random_item(Gender, Random()), Gender)

# Generated at 2022-06-23 21:59:27.844327
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rand_obj = Random()
    rand_obj.seed(1)
    # '0123456789ABCDEF'
    assert rand_obj.generate_string('0123456789ABCDEF', 16) == '6A8E6BE0D9A4E9F4'


# Generated at 2022-06-23 21:59:35.746989
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(random.randints(100)) == 100
    assert len(random.randints(100,3,6)) == 100
    assert len(random.randints(3,3,6)) == 3
    assert len(random.randints(10,3)) == 10
    assert len(random.randints(10,-10,0)) == 10
    assert len(random.randints(10,-10,-10)) == 10
    assert len(random.randints(10,-10,-10,20,30)) == 10
    assert len(random.randints(10,-10,-10,20)) == 10


# Generated at 2022-06-23 21:59:42.769160
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # ensure that the custom_code method
    # of class Random generates a correct code

    # check the correct operation of the method
    # in comparing the generated code with the expected
    assert random.custom_code('@###', '@', '#') == 'B146'

    # check that the wrong mask or placeholders
    # are not passed to the method
    assert random.custom_code('@##', '@', '#') == 'B46'
    assert random.custom_code('@###', 'a', '#') == 'B146'
    assert random.custom_code('@###', '@', '#') == 'B146'

# Generated at 2022-06-23 21:59:49.505260
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    rnd = Random()
    assert (rnd.uniform(0.001, 0.002) > 0.001)
    assert (rnd.uniform(0.001, 0.002) < 0.002)
    assert (rnd.uniform(0.999, 1.000) > 0.999)
    assert (rnd.uniform(0.999, 1.000) < 1.000)

# Generated at 2022-06-23 21:59:52.303929
# Unit test for function get_random_item
def test_get_random_item():
    enum = [['A', 'B', 'C'], ['a', 'b', 'c']]
    actual = get_random_item(enum)
    assert actual in enum[0] or actual in enum[1]

# Generated at 2022-06-23 21:59:54.038186
# Unit test for method randstr of class Random
def test_Random_randstr():
    random = Random()
    assert isinstance(random.randstr(), str)


# Generated at 2022-06-23 21:59:56.493626
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    res = random.generate_string("abcd1234", 200)
    assert len(res) == 200
    assert res.isalnum()


# Generated at 2022-06-23 21:59:58.041306
# Unit test for constructor of class Random
def test_Random():
    '''Test that Random instance can be
    created.
    '''
    assert Random() is not None

# Generated at 2022-06-23 21:59:59.586896
# Unit test for function get_random_item
def test_get_random_item():
    """Testing function get_random_item()."""
    assert get_random_item(random_module.random)

# Generated at 2022-06-23 22:00:01.513698
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random), Random)


if __name__ == '__main__':
    test_get_random_item()

# Generated at 2022-06-23 22:00:04.120765
# Unit test for constructor of class Random
def test_Random():
    """Test the random class constructor."""
    rnd = Random()
    assert isinstance(rnd, Random)



# Generated at 2022-06-23 22:00:06.773535
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    s = ''.join(random.choices('0123456789', k=10))
    assert isinstance(s, str)
    assert len(s) == 10


# Generated at 2022-06-23 22:00:17.670406
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _random = random_module.Random()
    _random.seed(1)
    r = Random()
    r.seed(1)
    assert r.custom_code('@###', char='@', digit='#') == 'G23Y'
    assert r.custom_code('@###', char='@', digit='#') == 'CADN'
    assert r.custom_code('@###', char='@', digit='#') == 'LWN6'
    assert r.custom_code('@###', char='@', digit='#') == '3C3I'
    assert r.custom_code('@###', char='@', digit='#') == 'CKU6'
    assert r.custom_code('@###', char='@', digit='#') == 'NJPQ'
    assert r.custom_code

# Generated at 2022-06-23 22:00:20.968321
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code()  # Without mask parameter
    assert Random().custom_code('@##')  # With mask parameter
    assert Random().custom_code('@##-@', '@', '#')  # With mask, char and digit parameter

# Generated at 2022-06-23 22:00:28.359143
# Unit test for method randints of class Random
def test_Random_randints():
    assert random.randints(1, 1, 100) == [41]
    assert random.randints(2, 1, 100) == [41, 60]
    assert random.randints(3, 1, 100) == [41, 60, 55]
    assert random.randints(4, 1, 100) == [41, 60, 55, 81]
    assert random.randints(5, 1, 100) == [41, 60, 55, 81, 43]
    assert random.randints(6, 1, 100) == [41, 60, 55, 81, 43, 8]
    assert random.randints(7, 1, 100) == [41, 60, 55, 81, 43, 8, 76]
    assert random.randints(8, 1, 100) == [41, 60, 55, 81, 43, 8, 76, 21]

# Generated at 2022-06-23 22:00:39.422048
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test custom_code method of class Random."""
    a = random.custom_code('@###')
    assert not a.isdigit()  # Check for digits.
    assert not a.isalpha()  # Check for letters.
    assert len(a) == 4  # Check length of string.

    b = random.custom_code('@@@')  # Check if custom_code works with letters only.
    assert not b.isdigit()  # Check for digits.
    assert b.isalpha()  # Check for letters.
    assert len(b) == 3  # Check length of string.

    c = random.custom_code('###')  # Check if custom_code works with digits only.
    assert c.isdigit()  # Check for digits.
    assert not c.isalpha()  # Check for letters.
   

# Generated at 2022-06-23 22:00:49.362926
# Unit test for method randints of class Random
def test_Random_randints():
    random_obj = Random()
    assert type(random_obj.randints()) == list
    assert type(random_obj.randints(a=0, b=0)) == list
    assert type(random_obj.randints(a=0, b=1000)) == list
    assert type(random_obj.randints(a=-1000, b=-1)) == list
    assert type(random_obj.randints(a=-1000, b=0)) == list
    assert type(random_obj.randints(a=-1000, b=1000)) == list
    try:
        random_obj.randints(amount=-1)
    except ValueError:
        pass
    else:
        raise Exception('test_Random_randints() failed')

# Generated at 2022-06-23 22:00:53.138744
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit-test for method randints."""
    x = Random().randints(4, a=-1, b=1)
    y = [-1, 0, 0, 1]
    assert len(x) == len(y)

    for i in range(0, len(x)):
        assert x[i] in y

# Generated at 2022-06-23 22:00:56.009818
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    global random
    assert len(random.urandom(10)) == 10

# Generated at 2022-06-23 22:00:58.866730
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test for method urandom of class Random."""
    rnd = Random()
    result = rnd.urandom(32)
    assert isinstance(result, bytes)

# Generated at 2022-06-23 22:01:03.005167
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(Random().randstr(), str)
    assert len(Random().randstr()) >= 16
    assert len(Random().randstr(length=256)) == 256
    assert isinstance(Random().randstr(unique=True), str)
    assert len(Random().randstr(unique=True)) == 32
    assert isinstance(Random.randstr(Random(), unique=True), str)



# Generated at 2022-06-23 22:01:07.744090
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert random.urandom()
    assert random.urandom(1)
    assert random.urandom(1).hex()
    assert random.urandom(1).hex().upper()
    assert random.urandom(1).hex().lower()
    assert random.urandom(1).bytes()
    assert isinstance(random.urandom(1).hex(), str)

# Generated at 2022-06-23 22:01:09.008504
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string(string.digits)) == 10

# Generated at 2022-06-23 22:01:19.814508
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code(mask='@###-@###-@###', char='@', digit='#')
    assert len(code) == 14

    code = random.custom_code(mask='###-###', char='@', digit='#')
    assert len(code) == 8

    code = random.custom_code(mask='%###', char='%', digit='#')
    assert len(code) == 5

    code = random.custom_code(mask='%##', char='%', digit='#')
    assert len(code) == 4

    code = random.custom_code(mask='###%###', char='%', digit='#')
    assert len(code) == 9

    code = random.custom_code(mask='@@@###', char='@', digit='#')

# Generated at 2022-06-23 22:01:22.910014
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(random.generate_string('1234567890987654321')) == 10
    assert len(random.generate_string('1234567890987654321', 15)) == 15


# Generated at 2022-06-23 22:01:24.230960
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1, 2) >= 1 and random.uniform(1, 2) < 2
    

# Generated at 2022-06-23 22:01:26.763245
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string('ASD123', 10) != random.generate_string('ASD123', 10)