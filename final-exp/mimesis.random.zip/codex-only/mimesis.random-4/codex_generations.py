

# Generated at 2022-06-23 21:51:30.905754
# Unit test for constructor of class Random
def test_Random():
    """Unit test to check a constructor of class Random."""
    assert(Random() is not None and isinstance(Random(), Random))

# Generated at 2022-06-23 21:51:32.240823
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert isinstance(rnd, Random)



# Generated at 2022-06-23 21:51:33.224885
# Unit test for constructor of class Random
def test_Random():
    """Test constructor of class Random."""
    Random()

# Generated at 2022-06-23 21:51:35.735986
# Unit test for constructor of class Random
def test_Random():
    """Check type of random because some other
        project can import module random.
    """
    assert isinstance(Random(), Random)


if __name__ == '__main__':
    pass

# Generated at 2022-06-23 21:51:38.081799
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for Random() class."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)

# Generated at 2022-06-23 21:51:42.325423
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    chars = 'abcdefghijklmnopqrstuvwxyz'
    digits = '1234567890'
    length = 100
    generated_string = random.generate_string(chars, length)
    assert len(generated_string) == length
    generated_string = random.generate_string(digits, length)
    assert len(generated_string) == length


# Generated at 2022-06-23 21:51:45.073014
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random.

    :return: Nothing, just raises exception if not passed.
    """
    r = Random()
    try:
        r.randints()
    except ValueError:
        pass
    else:
        raise Exception('randints does not handle correctly negative values.')



# Generated at 2022-06-23 21:51:49.895628
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Testing for possibility get bytes equal size as argument ``n``
    bytes_ = Random().urandom(16)
    assert isinstance(bytes_, bytes)
    assert len(bytes_) == 16

    # Testing for possibility get bytes with default size
    bytes_ = Random().urandom()
    assert isinstance(bytes_, bytes)
    assert len(bytes_) == 16

# Generated at 2022-06-23 21:51:50.713551
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)

# Generated at 2022-06-23 21:51:52.858356
# Unit test for constructor of class Random
def test_Random():
    rng = Random()
    assert isinstance(rng.random(), float)
    assert rng.randint(0, 10) in range(0, 10)



# Generated at 2022-06-23 21:51:54.808951
# Unit test for function get_random_item
def test_get_random_item():
    r = Random()
    assert get_random_item(r.choice(list(random.choice(list(random)))), r)

# Generated at 2022-06-23 21:52:05.092123
# Unit test for constructor of class Random
def test_Random():
    """Unit tests for class Random."""
    # Test 1: check if exists method randint
    assert hasattr(random, 'randint')

    # Test 2: check if exists method randints
    assert hasattr(random, 'randints')

    # Test 3: check if exists method generate_string
    assert hasattr(random, 'generate_string')

    # Test 4: check if exists method custom_code
    assert hasattr(random, 'custom_code')

    # Test 5: check if exists method uniform
    assert hasattr(random, 'uniform')

    # Test 6: check if exists method randstr
    assert hasattr(random, 'randstr')

    # Test 7: check if exists method urandom
    assert hasattr(random, 'urandom')



# Generated at 2022-06-23 21:52:07.496496
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(Random().randints(10, 1, 10), list)



# Generated at 2022-06-23 21:52:09.505578
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert isinstance(code, str)
    assert len(code) == 4
    assert rnd.custom_code(mask='@@###') == rnd.custom_code()



# Generated at 2022-06-23 21:52:18.582935
# Unit test for method uniform of class Random
def test_Random_uniform():
    generate_numbers = [random.uniform(3, 4, 3) for _ in range(100)]
    assert all(float(int(x)) == x for x in generate_numbers)

    assert random.uniform(1, 1) == 1
    assert random.uniform(1.0, 1.0) == 1.0

    assert random.uniform(2, 3) < 3
    assert random.uniform(1, 2) < 2

    assert random.uniform(4.5, 6.7) > 4.5
    assert random.uniform(5.5, 10.1) > 5.5

    assert random.uniform(3, 4) <= 4
    assert random.uniform(1, 2) <= 2

    assert random.uniform(4.5, 6.7) >= 4.5

# Generated at 2022-06-23 21:52:26.616782
# Unit test for function get_random_item
def test_get_random_item():
    """Unit tests of function get_random_item().

    :return: None.
    """
    from .enums import Gender
    from .enums import Orientation
    g = get_random_item(Gender)
    assert g in Gender, 'Some problem with random item of enum'

    custom_random = random.Random()
    assert get_random_item(Gender, custom_random) in Gender, (
        'Some problem with random item of enum with'
        'custom random object.')
    assert get_random_item(Orientation) in Orientation, (
        'Some problem with random item of enum.')

test_get_random_item()

# Generated at 2022-06-23 21:52:29.905338
# Unit test for constructor of class Random
def test_Random():
    """Test for `Random` class to make sure it works properly."""
    # Test for `generate_string`
    assert len(Random().generate_string('@')) == 10

    # Test for `custom_code`
    Random().custom_code('@###')

# Generated at 2022-06-23 21:52:33.007840
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    r.randints(2,100,200)
    r.urandom(3)
    r.generate_string(15)
    r.custom_code(mask = '@###',char = '@', digit = '#')
    r.uniform(1, 2)
    r.randstr()


# Generated at 2022-06-23 21:52:38.406617
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    r.seed(123)
    assert r.uniform(0, 2) == 1.764412889664973
    assert r.uniform(0, 2, precision=1) == 1.8
    assert r.uniform(0.10, 0.15, 4) == 0.1044

# Generated at 2022-06-23 21:52:43.336517
# Unit test for method randints of class Random
def test_Random_randints():
    assert len(Random.randints(amount=3)) == 3
    assert len(Random.randints(amount=3, a=1, b=3)) == 3
    assert len(Random.randints(amount=3, a=5, b=5)) == 3
    try:
        Random.randints(amount=0)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-23 21:52:51.822401
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    random = Random()
    for i in range(1000):
        assert random.uniform(0, 1) < 1
        assert random.uniform(0, 1, precision=2) < 1
        assert random.uniform(0, 1, precision=1) < 1
        assert random.uniform(0, 1, precision=0) < 1
        assert random.uniform(0.1, 1, precision=2) < 1

# Generated at 2022-06-23 21:52:53.520185
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    result = random.custom_code()
    assert len(result) == 4

# Generated at 2022-06-23 21:52:59.789514
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert '0123456789' == random.generate_string(str_seq='0123456789')
    assert '0123456789' == random.generate_string(str_seq='0123456789', length=10)
    assert '0123456789' != random.generate_string(str_seq='0123456789', length=15)

# Generated at 2022-06-23 21:53:04.761279
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    min_value = 1
    max_value = 100
    rand_str = '123456789'
    rand = Random()
    assert rand.generate_string(rand_str, 10) in rand_str
    assert rand.randint(min_value, max_value) in range(min_value, max_value)

# Generated at 2022-06-23 21:53:07.307855
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(a=1, b=1, precision=1) == 1
    assert random.uniform(a=1, b=2, precision=3) <= 2

# Generated at 2022-06-23 21:53:14.901762
# Unit test for method uniform of class Random
def test_Random_uniform():
    from math import isclose
    from assertionlib import assertion

    rnd = Random()
    for _ in range(100):
        a, b, c = rnd.randint(0, 25), rnd.randint(50, 1000), rnd.randint(100, 200)
        assertion.is_true(isclose(rnd.uniform(a, b), rnd.uniform(b, a)))
        assertion.is_false(rnd.uniform(a, b) > rnd.uniform(a, a))
        assertion.is_false(rnd.uniform(b, a) < rnd.uniform(b, b))
        assertion.is_true(isclose(rnd.uniform(b, a), b - rnd.uniform(0, a)))

# Generated at 2022-06-23 21:53:16.726583
# Unit test for method urandom of class Random
def test_Random_urandom():
    x = Random().urandom
    assert x  # NOQA

# Generated at 2022-06-23 21:53:19.046758
# Unit test for method randstr of class Random
def test_Random_randstr():
    random = Random()
    b = random.randstr()
    assert isinstance(b, str)

# Generated at 2022-06-23 21:53:21.867615
# Unit test for method randstr of class Random
def test_Random_randstr():
  random.seed(1)
  random.randstr()
  random.seed(1)
  random.randstr(unique=True)
  random.seed(1)
  random.randstr(length=16)

# Generated at 2022-06-23 21:53:24.993314
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method custom_code of class Random."""
    cts = CustomTestSuite()
    cts.test_method(Random().custom_code, '@AAA###', 1000,
                    ['@', '#'])

    cts.show_results()



# Generated at 2022-06-23 21:53:28.641675
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = '@###@@'
    char = '@'
    digit = '#'
    assert b'@', b'#' not in mask.encode()
    Random.custom_code(mask, char, digit) == Random.custom_code()

# Generated at 2022-06-23 21:53:31.552866
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = Random()
    for _ in range(10):
        l = r.randint(16, 128)
        assert len(r.randstr(length=l)) == l



# Generated at 2022-06-23 21:53:39.144407
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test function for method randstr of class Random.

    There two cases:
        - Return unique strings;
        - Return strings with fixed length.

    """
    rnd = Random()
    assert isinstance(rnd.randstr(unique=True), str)
    assert len(rnd.randstr(unique=False)) == 16
    assert len(rnd.randstr(unique=False, length=10)) == 10
    assert len(rnd.randstr(unique=False, length=50)) == 50
    assert len(rnd.randstr(unique=False, length=55)) == 55

# Generated at 2022-06-23 21:53:39.987905
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() != Random().custom_code()

# Generated at 2022-06-23 21:53:41.750843
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(Random().randstr(unique=False), str)
    assert isinstance(Random().randstr(unique=True), str)

# Generated at 2022-06-23 21:53:46.123788
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    str_seq = string.ascii_letters + string.digits
    assert isinstance(rnd.generate_string(str_seq), str)
    assert len(rnd.generate_string(str_seq)) == 10


# Generated at 2022-06-23 21:53:48.291298
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for method custom_code of class Random."""
    r = Random()
    pass



# Generated at 2022-06-23 21:53:58.673561
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code() != r.custom_code()
    assert r.custom_code(mask='@') != r.custom_code(mask='@')
    assert r.custom_code(mask='@###') != r.custom_code(mask='@###')
    assert r.custom_code(mask='@###') != r.custom_code(mask='@###')
    assert r.custom_code(mask='@@@###') != r.custom_code(mask='@@@###')
    assert r.custom_code(mask='@@@###') != r.custom_code(mask='@@@###')
    assert r.custom_code(mask='@@@@###') != r.custom_code(mask='@@@@###')

# Generated at 2022-06-23 21:54:03.290214
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method randints of class Random."""
    s = set()
    for i in range(100):
        s.add(random.randints(5))
    assert (len(s) == 100)



# Generated at 2022-06-23 21:54:06.535594
# Unit test for function get_random_item
def test_get_random_item():
    """Test get_random_item function."""
    assert get_random_item(enum='Test') == 'Test'

# Generated at 2022-06-23 21:54:09.079892
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method ``urandom()`` of class ``Random()``."""
    rand = Random()
    assert rand.urandom()

# Generated at 2022-06-23 21:54:18.263373
# Unit test for method randstr of class Random
def test_Random_randstr():
    # check length of string
    assert len(random.randstr()) == 36
    assert len(random.randstr()) == 36
    assert len(random.randstr()) == 36
    assert len(random.randstr()) == 36
    assert len(random.randstr()) == 36

    # check unique
    assert random.randstr(unique=True) != random.randstr(unique=True)
    assert random.randstr(unique=True) != random.randstr(unique=True)
    assert random.randstr(unique=True) != random.randstr(unique=True)
    assert random.randstr(unique=True) != random.randstr(unique=True)
    assert random.randstr(unique=True) != random.randstr(unique=True)

    # check length of generated string

# Generated at 2022-06-23 21:54:20.169796
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    string_numbers = random.generate_string('0123456789')
    assert len(string_numbers) == 10


# Generated at 2022-06-23 21:54:22.158869
# Unit test for method urandom of class Random
def test_Random_urandom():
    random_instance = Random()
    random_instance.urandom(10)

# Generated at 2022-06-23 21:54:25.767868
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(), str) and \
           isinstance(random.randstr(unique=True), str) and \
           len(random.randstr(length=10)) == 10
    
    

# Generated at 2022-06-23 21:54:28.706877
# Unit test for method uniform of class Random
def test_Random_uniform():
    random = Random()
    a = random.uniform(1, 9)
    b = random.uniform(1, 9)
    if a != b:
        print("Values are not equal")
        print(a,b)


# Generated at 2022-06-23 21:54:31.237137
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test method urandom of class Random"""
    print(random.urandom())
    print(random.urandom(100))
    print(random.urandom(100).hex())
    print(random.urandom(100).hex().upper())


# Generated at 2022-06-23 21:54:34.097317
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _rnd = Random()
    code = _rnd.custom_code('@###')
    assert isinstance(code, str)
    assert len(code) == 4

# Generated at 2022-06-23 21:54:40.537077
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert isinstance(rnd.randints(1), list)

    amount = 2
    a = 1
    b = 10
    result = rnd.randints(amount, a, b)
    assert isinstance(result, list)
    assert len(result) == amount
    for i in result:
        assert i >= a and i <= b



# Generated at 2022-06-23 21:54:42.233451
# Unit test for method uniform of class Random
def test_Random_uniform():
    result = random.uniform(0.00, 100.00)
    print('result = ', result)



# Generated at 2022-06-23 21:54:43.746894
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert len(Random().generate_string('abcd'))==3


# Generated at 2022-06-23 21:54:44.916452
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    assert Random().randstr()

# Generated at 2022-06-23 21:54:48.592502
# Unit test for method randstr of class Random
def test_Random_randstr():
    for length in range(0, 150, 5):
        r1 = random.randstr(length=length)
        r2 = random.randstr(unique=True, length=length)
        assert isinstance(r1, str)
        assert isinstance(r2, str)



# Generated at 2022-06-23 21:54:51.097851
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@####@##') != Random().custom_code('@####@##')
    assert Random().custom_code('@###@@#@###') != Random().custom_code('@###@@#@###')

# Generated at 2022-06-23 21:54:51.918387
# Unit test for method uniform of class Random
def test_Random_uniform():
    pass

# Generated at 2022-06-23 21:54:59.967171
# Unit test for method randints of class Random

# Generated at 2022-06-23 21:55:04.533717
# Unit test for method urandom of class Random
def test_Random_urandom():
    random1 = Random()
    random2 = Random()
    random3 = Random()
    x = random1.urandom(1)
    y = random2.urandom(1)
    z = random3.urandom(1)
    assert x != y
    assert x != z
    assert y != z


# Generated at 2022-06-23 21:55:13.994085
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    import unittest

    class TestRandomCustomCode(unittest.TestCase):
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)
            self.rnd = Random()

        def test_wrong_mask(self) -> None:
            with self.assertRaises(ValueError):
                self.rnd.custom_code('@##')

        def test_wrong_placeholder_value(self) -> None:
            with self.assertRaises(ValueError):
                self.rnd.custom_code(char='@', digit='@')

        def test_custom_code_1(self) -> None:
            code = self.rnd.custom_code('@###', char='@', digit='#')

# Generated at 2022-06-23 21:55:19.525890
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    rnd.seed(0)
    assert rnd.uniform(0, 1, precision=3) == 0.264
    assert rnd.uniform(0, 1) == 0.26434074698825103
    assert rnd.uniform(0, 1) == 0.8540157206301446
    assert rnd.uniform(0, 1) == 0.02100170098288123

# Generated at 2022-06-23 21:55:21.081542
# Unit test for constructor of class Random
def test_Random():
    """Test for Random class."""
    random = Random()
    assert isinstance(random, Random)


# Generated at 2022-06-23 21:55:23.752585
# Unit test for function get_random_item
def test_get_random_item():
    class Color(object):
        RED = 'red'
        BLUE = 'blue'
        GREEN = 'green'

    assert get_random_item(Color) in [Color.RED,
                                      Color.BLUE,
                                      Color.GREEN]

# Generated at 2022-06-23 21:55:26.287331
# Unit test for method randstr of class Random
def test_Random_randstr():
    seq = []
    for _ in range(30):
        seq.append(random.randstr(unique=False))
    assert len(set(seq)) != len(seq)



# Generated at 2022-06-23 21:55:27.115463
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    pass

# Generated at 2022-06-23 21:55:30.706264
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    result = r.uniform(1, 1.1)
    assert result >= 1 and result < 1.1

# Generated at 2022-06-23 21:55:32.190342
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    assert Random().urandom()

# Generated at 2022-06-23 21:55:36.976489
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for ``Random.randstr()`` method.

    """
    assert len(Random().randstr(length=None)) < 15
    assert len(Random().randstr(length=None)) > 10
    assert len(Random().randstr(length=None)) != 15
    assert len(Random().randstr(length=None)) != 10

# Generated at 2022-06-23 21:55:39.786641
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    code = r.custom_code()
    assert len(code) == 6, 'Code should be 6 chars.'
    assert code.isalnum(), 'Code should consist of ' \
                           'alphanumeric symbols.'

# Generated at 2022-06-23 21:55:41.764168
# Unit test for method urandom of class Random
def test_Random_urandom():
    print(random.urandom(12))



# Generated at 2022-06-23 21:55:47.817823
# Unit test for method randints of class Random
def test_Random_randints():

    # Test for empty list.
    assert (Random.randints(amount=0)) == []

    # Test for positive numbers.
    rand_int = Random.randints(amount=10)
    assert (len(rand_int)) == 10
    assert (rand_int[0] >= 1 and rand_int[0] <= 100)

    # Test for negative numbers.
    rand_int = Random.randints(amount=10, a=-20, b=-5)
    assert (len(rand_int)) == 10
    assert (rand_int[0] >= -20 and rand_int[0] <= -5)


# Generated at 2022-06-23 21:55:51.944131
# Unit test for method urandom of class Random
def test_Random_urandom():
    rng = Random()
    u_byte = rng.urandom(10)
    assert isinstance(u_byte, bytes)
    # Assert that values are equal
    assert u_byte == os.urandom(10)

# Generated at 2022-06-23 21:55:57.304159
# Unit test for function get_random_item
def test_get_random_item():
    """Test for the function ``get_random_item()`` in this module."""
    get_random_item(['one', 'two', 'three'])
    get_random_item(('one', 'two', 'three'))
    get_random_item({'one', 'two', 'three'})
    get_random_item({'one': '111', 'two': '222', 'three': '333'})

# Generated at 2022-06-23 21:56:00.203693
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    for i in range(1, 10):
        r.uniform(0.0, 100.0, i)
    r.uniform(0.0, 100.0)

# Generated at 2022-06-23 21:56:01.576725
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random().urandom(1024)) == 1024


# Generated at 2022-06-23 21:56:03.745673
# Unit test for method urandom of class Random
def test_Random_urandom():
    _random = Random()
    assert _random.urandom(10)

# Generated at 2022-06-23 21:56:05.781553
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    custom_code_Random_class = Random()
    assert custom_code_Random_class.custom_code('@###')

# Generated at 2022-06-23 21:56:07.809594
# Unit test for method urandom of class Random
def test_Random_urandom():
    random.setstate(random_module.getstate())
    random.urandom()

# Generated at 2022-06-23 21:56:09.359112
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string('ABCD') == 'CCCC'

# Generated at 2022-06-23 21:56:12.967781
# Unit test for method randints of class Random
def test_Random_randints():
    # Unit test for method randints of class Random
    rnd = Random()
    amount = 3
    arr = rnd.randints(amount=amount)
    assert len(arr) == amount



# Generated at 2022-06-23 21:56:14.979229
# Unit test for constructor of class Random
def test_Random():
    """Test the constructor of class Random.

    Test coverage: 100%

    """
    random = Random()
    assert isinstance(random, Random)



# Generated at 2022-06-23 21:56:17.677495
# Unit test for method randints of class Random
def test_Random_randints():
    _list = random.randints(amount=10)
    assert isinstance(_list, list)
    assert len(_list) == 10
    for _ in _list:
        assert isinstance(_, int)



# Generated at 2022-06-23 21:56:29.080582
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test custom_code() method."""
    rnd = Random()
    code = rnd.custom_code()
    assert any(n.isalpha() for n in code)
    assert any(n.isdigit() for n in code)
    assert len(code) == 4
    code = rnd.custom_code('@@#')
    assert code[0].isalpha()
    assert code[1].isalpha()
    assert code[2].isdigit()
    assert len(code) == 3
    code = rnd.custom_code(mask='@@##@@')
    assert len(code) == 6
    assert code[0].isalpha()
    assert code[5].isalpha()
    assert code[4].isalpha()
    assert code[2].isdigit()
    assert code[1].isdigit

# Generated at 2022-06-23 21:56:33.583680
# Unit test for method randints of class Random
def test_Random_randints():
    r1 = Random()
    assert all([
        isinstance(r, int)
        for r in r1.randints(amount=5)
    ])

    r2 = Random()
    assert r2.randints(amount=5, a=1, b=100) != r2.randints(amount=5, a=1, b=100)

# Generated at 2022-06-23 21:56:34.983234
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(string.ascii_letters), str)

# Generated at 2022-06-23 21:56:36.249472
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random.providers), Any)

# Generated at 2022-06-23 21:56:45.435036
# Unit test for method randstr of class Random
def test_Random_randstr():
    """ Test method randstr of class Random."""
    for i in range(10):
        random_string = random.randstr()
        assert random_string
        assert isinstance(random_string, str)
        assert len(random_string) >= 16
        assert len(random_string) <= 128

    # Test with length parameter
    for i in range(10):
        random_string = random.randstr(length=10)
        assert random_string
        assert isinstance(random_string, str)
        assert len(random_string) == 10

    random_string = random.randstr(unique=True)
    assert random_string
    assert isinstance(random_string, str)
    assert len(random_string) == 32

# Generated at 2022-06-23 21:56:47.779450
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    assert len(Random().generate_string('abc', 10)) == 10



# Generated at 2022-06-23 21:56:51.328444
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for method uniform of class Random.

    Test check if method uniform of class Random return a random number in the range [a, b).

    """
    result = random.uniform(0.00, 0.99)
    assert result >= 0.00
    assert result < 0.99
    result = random.uniform(1.00, 2.00)
    assert result >= 1.00
    assert result < 2.00

# Generated at 2022-06-23 21:56:53.636876
# Unit test for method uniform of class Random
def test_Random_uniform():
    for _ in range(10):
        num = random.uniform(-3,3)
        assert num >= -3 and num <= 3

# Generated at 2022-06-23 21:57:03.179837
# Unit test for function get_random_item
def test_get_random_item():
    """
    Tests ``get_random_item()`` function.
    """

    # Test with different enums
    assert random.choice(list(random.Gender)) == get_random_item(random.Gender)
    assert random.choice(list(random.Religion)) == get_random_item(random.Religion)
    assert random.choice(list(random.Language)) == get_random_item(random.Language)
    assert random.choice(list(random.Locale)) == get_random_item(random.Locale)
    assert random.choice(list(random.Category)) == get_random_item(random.Category)
    assert random.choice(list(random.Currency)) == get_random_item(random.Currency)

# Generated at 2022-06-23 21:57:06.107456
# Unit test for function get_random_item
def test_get_random_item():
    class MyEnum(str, enum.Enum):
        a = 'a'
        b = 'b'
        c = 'c'

    assert isinstance(get_random_item(MyEnum), MyEnum)

# Generated at 2022-06-23 21:57:09.414658
# Unit test for function get_random_item
def test_get_random_item():
    '''
    Check if function get_random_item returns
    random item of enum object
    '''
    import enum

    class Colors(enum.Enum):
        blue = 1
        red = 2
        green = 3

    assert isinstance(get_random_item(Colors), Colors)


# Generated at 2022-06-23 21:57:18.947459
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    ret = random.custom_code(mask='AAAAAAA', char='A')
    assert isinstance(ret, str)
    assert len(ret) == 7

    ret = random.custom_code(mask='#######', digit='#')
    assert isinstance(ret, str)
    assert len(ret) == 7

    ret = random.custom_code(mask='@###', char='@', digit='#')
    assert isinstance(ret, str)
    assert len(ret) == 4

    ret = random.custom_code(mask='A#A#A#A', char='A', digit='#')
    assert isinstance(ret, str)
    assert len(ret) == 7

# Generated at 2022-06-23 21:57:20.331575
# Unit test for method uniform of class Random
def test_Random_uniform():
    print(random.uniform(0.1, 1.1))

# Generated at 2022-06-23 21:57:25.557250
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() == 'A039'
    assert Random().custom_code() != 'A039'
    assert Random().custom_code() != 'A039'
    assert Random().custom_code() != 'A039'
    assert Random().custom_code() != 'A039'
    assert Random().custom_code() != 'A039'

# Generated at 2022-06-23 21:57:34.770846
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Testing method of the class :class:`Random()`.
    """
    number_of_tests = 10
    for _ in range(number_of_tests):
        assert len(random.custom_code('@')) == 1
        assert len(random.custom_code('@@')) == 2
        assert len(random.custom_code('@@@')) == 3
        assert len(random.custom_code('@###')) == 4
        assert len(random.custom_code('AABC')) == 4
        assert len(random.custom_code('AA@BB@@CC@@')) == 8
        assert len(random.custom_code('AA@BB@@CC@@', 'a', 'B')) == 8

# Generated at 2022-06-23 21:57:39.261652
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Check that Random.urandom() and os.urandom() return the same data
    os_urandom_result = os.urandom(32)
    random_urandom_result = Random().urandom(32)
    assert random_urandom_result == os_urandom_result

# Generated at 2022-06-23 21:57:49.083948
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() in ['A8B2', 'A2B1', 'A1B2', 'A1B1', 'A2B2']
    assert random.custom_code('@') in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    assert random.custom_code('#') in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

# Generated at 2022-06-23 21:57:51.555747
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    random = Random()
    random.randint(1, 100)

# Generated at 2022-06-23 21:57:52.865909
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random.__class__), Random)

# Generated at 2022-06-23 21:57:55.458876
# Unit test for method randints of class Random
def test_Random_randints():
    r = Random()
    r.randints(1, 10)
    r.randints(3, 1)
    try:
        r.randints(0, 10)
    except ValueError:
        pass



# Generated at 2022-06-23 21:57:58.896335
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Unit test for method urandom of class Random."""
    _random = Random()
    _bytes = _random.urandom(12)
    assert isinstance(_bytes, bytes)
    assert len(_bytes) == 12

# Generated at 2022-06-23 21:58:05.521594
# Unit test for method randints of class Random
def test_Random_randints():
    for _ in range(100):
        random_list = random.randints(amount=100, a=10, b=15)
        assert all(x in range(10, 15) for x in random_list)
        assert len(random_list) == 100

    random_list = random.randints(amount=0, a=10, b=15)
    assert all(x in range(10, 15) for x in random_list)
    assert len(random_list) == 0

# Generated at 2022-06-23 21:58:07.498180
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)

if __name__ == '__main__':
    test_Random()

# Generated at 2022-06-23 21:58:09.157700
# Unit test for method urandom of class Random
def test_Random_urandom():
    # TODO: implement unit test for method urandom of class Random
    pass


# Generated at 2022-06-23 21:58:10.338041
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    assert random.randstr() != ''

# Generated at 2022-06-23 21:58:14.703198
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = random.custom_code('@###')
    assert len(code) == 4
    assert code.isupper()
    assert code.isalnum()

    code = random.custom_code('@@@@@@@###')
    assert len(code) == 10
    assert code.isupper()
    assert code.isalnum()

    code = random.custom_code('@##.@###.@###')
    assert len(code) == 13
    assert code.isupper()
    assert code.isalnum()

# Generated at 2022-06-23 21:58:19.496447
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert isinstance(random.randstr(), str)
    assert isinstance(random.randstr(unique=True), str)
    assert isinstance(random.randstr(False, 9), str)
    assert len(random.randstr(False, 9)) == 9
    assert len(random.randstr(False, 9)) != 13



# Generated at 2022-06-23 21:58:21.131593
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)


# Unit test

# Generated at 2022-06-23 21:58:23.993296
# Unit test for method uniform of class Random
def test_Random_uniform():
    # get a random number in the range [1, b) or [1, b] depending on rounding.
    rnd = random.uniform(1, 3)
    assert rnd >= 1 and rnd <= 3

# Generated at 2022-06-23 21:58:25.535375
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    assert random is not None


# Generated at 2022-06-23 21:58:31.227259
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert rnd.uniform(1, 5) < 5
    assert rnd.uniform(0.1, 0.2) < 0.2
    assert rnd.uniform(0.1, 0.2) >= 0.1
    assert rnd.uniform(0.1, 0.2, 2) < 0.2
    assert rnd.uniform(0.1, 0.2, 3) < 0.2
    assert rnd.uniform(0.1, 0.2, 4) < 0.2
    assert rnd.uniform(0.1, 0.2, 5) < 0.2
    assert rnd.uniform(0.1, 0.2, 5) >= 0.1
    # Also need to check that the generated number has the desired precision

# Generated at 2022-06-23 21:58:32.240116
# Unit test for method urandom of class Random
def test_Random_urandom():
    Random().urandom(10)

# Generated at 2022-06-23 21:58:35.816609
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    code = r.custom_code(mask = '@###', char = '@', digit = '#')
    assert len(code) == 4
    assert code[0].isupper()
    assert code[1:].isdigit()


# Generated at 2022-06-23 21:58:41.548620
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method ``custom_code()`` of class ``Random()``."""
    # Test case 1
    mask = '@###'
    char = '@'
    digit = '#'
    expected = "E534"
    real = random.custom_code(mask, char, digit)
    assert len(real) == len(expected)

    # Test case 2
    mask = '@##@'
    char = '@'
    digit = '#'
    expected = "A534A"
    real = random.custom_code(mask, char, digit)
    assert len(real) == len(expected)

    # Test case 3
    mask = '@#####'
    char = '@'
    digit = '#'
    expected = "F82746"
    real = random.custom_

# Generated at 2022-06-23 21:58:43.983434
# Unit test for constructor of class Random
def test_Random():
    obj = Random()
    assert isinstance(obj, Random)



# Generated at 2022-06-23 21:58:45.613273
# Unit test for function get_random_item
def test_get_random_item():
    assert isinstance(get_random_item(random.Gender), str)

# Generated at 2022-06-23 21:58:49.558864
# Unit test for function get_random_item
def test_get_random_item():
    """Test get_random_item() function."""
    rnd = Random()
    # Get random item of enum object
    assert get_random_item(enum='test', rnd=rnd)
    assert get_random_item(enum=random, rnd=rnd)

# Generated at 2022-06-23 21:58:53.465868
# Unit test for constructor of class Random
def test_Random():
    a, b, c = [random.randint(1, 100) for i in range(3)]
    assert a in range(1, 100)
    assert b in range(1, 100)
    assert c in range(1, 100)



# Generated at 2022-06-23 21:58:56.864802
# Unit test for method randstr of class Random
def test_Random_randstr():
    print('Testing method randstr(unique=False).')
    result = random.randstr(unique=False)
    print(f'Result: {result}')
    print('Asking for help:\nprint(help(Random.randstr))')
    assert result is not None

# Generated at 2022-06-23 21:58:59.515131
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    result = Random().generate_string('abcdefghijklmnopqrstuvwxyz')
    assert len(result) == 10


# Generated at 2022-06-23 21:59:01.505049
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert "ITIPIT" == Random().generate_string('ITIPIT')


# Generated at 2022-06-23 21:59:02.577299
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random.urandom(), bytes)

# Generated at 2022-06-23 21:59:08.321294
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    class User:
        def __init__(self, id, username, password):
            self.id = id
            self.username = username
            self.password = password


    user = User(1, 'Владимир', 'Последний')


    # print(Random().custom_code())

    """
    for i in range(100):
        # print(Random().custom_code())
        print(Random().randints())
    """

if __name__ == '__main__':
    # print(get_random_item(Gender))
    test_Random_custom_code()

# Generated at 2022-06-23 21:59:12.586426
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test custom method uniform of class Random.

    :return: None
    """
    r = Random()
    minimum = 10
    maximum = 20
    assert r.uniform(minimum, maximum) < maximum
    assert minimum <= r.uniform(minimum, maximum)
    assert minimum <= r.uniform(minimum, maximum, precision=2) <= maximum

# Generated at 2022-06-23 21:59:16.473224
# Unit test for method urandom of class Random
def test_Random_urandom():
    """This function checks the function urandom of the class Random."""
    # Simple check
    assert isinstance(Random.urandom(), bytes)
    # Check for length
    assert len(Random.urandom(10)) == 10
    # Check with zero
    assert len(Random.urandom(0)) == 0



# Generated at 2022-06-23 21:59:18.591294
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert Random().uniform(a=0, b=1) != 0
    assert Random().uniform(a=0, b=1) != 1

# Generated at 2022-06-23 21:59:20.938299
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    assert get_random_item(random.enums.Currency) in list(random.enums.Currency)



# Generated at 2022-06-23 21:59:23.536184
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.builtins import RussiaSpecProvider
    from mimesis.enums import Gender

    class TestEnum(RussiaSpecProvider):
        def test_get_random_item(self):
            assert get_random_item(Gender)

# Generated at 2022-06-23 21:59:25.304388
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert len(rnd.randints(0)) == 0
    assert len(rnd.randints()) == 3



# Generated at 2022-06-23 21:59:26.306205
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random().urandom(10)) == 10

# Generated at 2022-06-23 21:59:34.376570
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() == 'T939', 'Incorrect length of code'
    assert len(Random().custom_code(mask='@@@@###@@@@')) == 14, \
        'Incorrect length of code'
    assert len(Random().custom_code(mask='@@@@###@@@@',
                                    char='#',
                                    digit='@')) == 14, \
        'Incorrect length of code'
    assert len(Random().custom_code(mask='@##@@@###@####')) == 18, \
        'Incorrect length of code'



# Generated at 2022-06-23 21:59:43.093788
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    import random as random_module

    class SomeEnum(enum.Enum):
        A = 1
        B = 2
        C = 3

    # random
    assert get_random_item(SomeEnum) == random_module.choice(list(SomeEnum))

    # random with seed
    seed_value = random_module.randint(1, 32)
    rnd = random_module.Random(seed_value)
    rnd.seed(seed_value)
    assert get_random_item(SomeEnum, rnd) == random_module.choice(list(SomeEnum))

    # normal use
    assert isinstance(get_random_item(SomeEnum), SomeEnum)

    # use with custom class which is subclass of Random

# Generated at 2022-06-23 21:59:45.276625
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(random.urandom(10), bytes)



# Generated at 2022-06-23 21:59:48.063881
# Unit test for method randints of class Random
def test_Random_randints():
    random_list = random.randints(3, 10, 20)
    assert len(random_list) == 3
    assert all(10 <= n <= 20 for n in random_list)



# Generated at 2022-06-23 21:59:57.289257
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    assert len(random.generate_string('@#$')) == 10
    assert random.generate_string('@#$', 20) != random.generate_string('@#$', 20)
    assert random.generate_string('abcdefg', 20) != random.generate_string('abcdefg', 20)
    assert random.generate_string('0123456789', 20) != random.generate_string('0123456789', 20)
    assert len(random.generate_string('0123456789')) == 10
    assert len(random.generate_string('0123456789', 3)) == 3



# Generated at 2022-06-23 21:59:59.427126
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for the function ``get_random_item()``.

    :return: ``None``
    """
    assert get_random_item(enum=Random, rnd=random) is not None

# Generated at 2022-06-23 22:00:01.373218
# Unit test for method randints of class Random
def test_Random_randints():
    random = Random()
    result = random.randints(a=0, b=3)
    assert result[0] in [0, 1, 2]



# Generated at 2022-06-23 22:00:08.822033
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert all([len(random.randstr()) == 32 for _ in range(10)])
    assert all([len(random.randstr(16)) == 16 for _ in range(10)])
    assert all([len(random.randstr(length=128)) == 128 for _ in range(10)])
    assert all([len(random.randstr(unique=True)) == 32 for _ in range(10)])
    assert all([len(random.randstr(128, unique=True)) == 128 for _ in range(10)])

# Generated at 2022-06-23 22:00:13.843184
# Unit test for constructor of class Random
def test_Random():
    """Test for constructor."""
    assert isinstance(Random(), Random)
    assert isinstance(Random(0), Random)
    # assert isinstance(Random(1), random_module.Random)
    # assert isinstance(Random(2), random_module.Random)
    # assert isinstance(Random(1000), random_module.Random)



# Generated at 2022-06-23 22:00:19.514866
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random.randint(1, 2), int)
    assert isinstance(random.randstr(), str)
    assert isinstance(random.custom_code(), str)
    assert isinstance(random.generate_string(string.digits), str)
    assert isinstance(random.uniform(1, 2), float)
    assert isinstance(random.randints(1), list)

# Generated at 2022-06-23 22:00:20.454742
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert isinstance(Random().urandom(16), bytes)

# Generated at 2022-06-23 22:00:25.100005
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code(mask='@###') == 'V000'
    assert random.custom_code(mask='@###') == 'E101'
    assert random.custom_code(mask='@###') == 'H527'
    assert random.custom_code(mask='@###') == 'Z655'
    assert random.custom_code(mask='@###') == 'Y343'

# Generated at 2022-06-23 22:00:28.943256
# Unit test for method uniform of class Random
def test_Random_uniform():
    _list = []
    for i in range(10000):
        number = random.uniform(3.4, 5.6)
        _list.append(number)
        if number < 3.4 or number >= 5.6:
            assert False, 'Number out of range'
    avg = sum(_list) / len(_list)
    if avg < 4.5:
        assert False, 'The average number is too small'
    if avg > 4.55:
        assert False, 'The average number is too big'

# Generated at 2022-06-23 22:00:32.492921
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    from mimesis.enums import Gender

    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 22:00:35.686037
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    random_ = Random()
    assert len(random_.randstr(unique=True)) == 32

    random_ = Random(1)
    assert len(random_.randstr(unique=True)) == 32



# Generated at 2022-06-23 22:00:37.034319
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, Random)

# Generated at 2022-06-23 22:00:41.952923
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test generate_string method of class Random."""
    for i in range(10):
        assert len(random.generate_string(str_seq='ABCDE', length=3)) == 3
    assert len(random.generate_string(str_seq='ABCDE', length=10)) == 10
    assert len(random.generate_string(str_seq='123456', length=10)) == 10



# Generated at 2022-06-23 22:00:45.744919
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    amount = 5
    a = 0
    b = 19
    lst = rnd.randints(amount, a, b)
    assert len(lst) == amount
    assert all(a <= i <= b for i in lst)

# Generated at 2022-06-23 22:00:46.726491
# Unit test for constructor of class Random
def test_Random():
    assert random.urandom(3) is not None

# Generated at 2022-06-23 22:00:51.660427
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function get_random_item."""
    import numpy as np

    class TestEnum(object):
        """Test enum class."""

        def __init__(self, value: int):
            self.value = value

    test_enum_1 = TestEnum(1)
    test_enum_2 = TestEnum(2)

    assert (get_random_item([test_enum_1, test_enum_2]) in
            np.array([test_enum_1, test_enum_2]))

# Generated at 2022-06-23 22:00:56.011966
# Unit test for method randints of class Random
def test_Random_randints():
    amount = 3
    a = 1
    b = 100
    expected = [1, 2, 3]
    Random.seed(122)
    result = Random().randints(amount, a, b)
    assert result == expected

# Generated at 2022-06-23 22:00:59.982272
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    result = random.custom_code(mask='@###', char='@', digit='#')
    assert isinstance(result, str)
    assert len(result.split('@')) == 2
    assert len(result.split('@')[0]) == 1


# Generated at 2022-06-23 22:01:01.545620
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 22:01:09.384572
# Unit test for function get_random_item
def test_get_random_item():
    # Wrong type for enum argument
    try:
        get_random_item(10)
        assert False
    except TypeError:
        pass

    # Wrong type for rnd argument
    try:
        get_random_item(10, 10)
        assert False
    except AttributeError:
        pass

    from petproject.data.enums import Gender, USState
    # Wrong type for enum argument
    try:
        get_random_item(USState.values())
        assert False
    except TypeError:
        pass

    # Random item
    assert get_random_item(Gender) in Gender

# Generated at 2022-06-23 22:01:20.388342
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code(mask='@AAA-###', digit='#', char='@') == 'RZW-011'
    assert random.custom_code(mask='@###', digit='#', char='@') == 'Z853'
    assert random.custom_code(mask='@A-A###', digit='#', char='@') == 'R-Z923'
    assert random.custom_code(mask='@###', digit='#', char='@') == 'K994'
    assert random.custom_code(mask='@####', digit='#', char='@') == 'N6026'
    assert random.custom_code(mask='@#####', digit='#', char='@') == 'L39237'
    assert random.custom_code(mask='@AAAAAA', digit='#', char='@')

# Generated at 2022-06-23 22:01:28.077439
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()

    # Amount less then zero
    with pytest.raises(ValueError):
        rnd.randints(amount=0)

    # Amount equal zero
    with pytest.raises(ValueError):
        rnd.randints(amount=-1)

    # Amount equal one
    result = rnd.randints(amount=1)
    assert len(result) == 1

    # Default values of a, b
    result = rnd.randints()
    for x in result:
        pytest.assume(x > 0)
        pytest.assume(x < 100)

    # Custom values of a, b
    result = rnd.randints(a=1, b=10)
    for x in result:
        pytest.assume(x > 0)
        pytest.assume