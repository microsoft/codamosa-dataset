

# Generated at 2022-06-23 21:51:38.180955
# Unit test for method randstr of class Random
def test_Random_randstr():
    random = Random()
    for _ in range(100):
        assert isinstance(random.randstr(), str)
        assert len(random.randstr()) >= 16
        assert len(random.randstr()) <= 128
        assert len(random.randstr(length=128)) == 128
        assert len(random.randstr(length=0)) == 0
        assert len(random.randstr(length=16)) == 16
        assert len(random.randstr(length=16)) == 16
        assert len(random.randstr(length=3)) == 3
        assert len(random.randstr(length=1)) == 1
        assert len(random.randstr(length=2, unique=True)) == 32

# Generated at 2022-06-23 21:51:39.059523
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(10) is not None

# Generated at 2022-06-23 21:51:44.977010
# Unit test for method randstr of class Random
def test_Random_randstr():
    for _ in range(20):
        assert len(random.randstr()) >= 16, 'randstr() less 16 characters'
        assert len(random.randstr(length=20)) == 20, 'randstr() not 20 characters'
        assert all([random.randstr(unique=True), len(random.randstr(unique=True)) == 32]), 'randstr(unique=True) not 32 characters'

# Generated at 2022-06-23 21:51:47.545475
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Prepare test data
    size = 16
    # Perform test action
    r = Random().urandom(size)
    # Check results
    assert len(r) == size



# Generated at 2022-06-23 21:51:56.091847
# Unit test for constructor of class Random
def test_Random():
    """Unit test for constructor of class Random."""
    rnd = Random()

    assert rnd.seed() == None

    assert rnd.random() > 0.0
    assert rnd.random() < 1.0

    assert rnd.randint(0, 100) >= 0
    assert rnd.randint(0, 100) <= 100

    assert type(rnd.uniform(0.0, 1.0)) in (float, int)

    assert rnd.randrange(0, 100, 3) % 3 == 0

    assert type(rnd.randbits(100)) in (int, float)

    assert rnd.getrandbits(100) % 100 == 0

    assert type(rnd.uniform(0.0, 4.0)) in (float, int)


# Generated at 2022-06-23 21:52:07.496438
# Unit test for method randints of class Random
def test_Random_randints():
    import pytest

    _random = Random()
    _amount = _random.randint(2, 23)
    _a = _random.randint(-200, -30)
    _b = _random.randint(20, 1000)

    _data = _random.randints(_amount, _a, _b)
    assert isinstance(_data, list)
    assert len(_data) == _amount
    for i in _data:
        assert isinstance(i, int)
        assert i >= _a and i < _b

    with pytest.raises(ValueError):
        _random.randints(0, 1, 2)
    with pytest.raises(ValueError):
        _random.randints(-1, 1, 2)

# Generated at 2022-06-23 21:52:09.636813
# Unit test for method randints of class Random
def test_Random_randints():
    _ = Random().randints(amount=3, a=1, b=100)



# Generated at 2022-06-23 21:52:18.640249
# Unit test for method randints of class Random
def test_Random_randints():
    """Test for method randint of class Random."""
    for i in range(1_000):
        result = random.randints(a=-43, b=-23)
        assert -43 <= result[0] <= -23, result[0]

        result = random.randints(a=-43, b=23)
        assert -43 <= result[0] <= 1, result[0]

        result = random.randints(a=43, b=23)
        assert 1 <= result[0] <= 23, result[0]

        result = random.randints(a=23, b=43)
        assert 23 <= result[0] <= 43, result[0]

        result = random.randints(a=23, b=43, amount=3)
        assert len(result) == 3, len(result)

# Generated at 2022-06-23 21:52:28.431246
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test for method generate_string of class Random."""
    number_randoms = 200
    str_seq_list = [string.digits, string.ascii_letters, string.punctuation,
                    string.ascii_lowercase, string.ascii_uppercase,
                    string.printable]
    length_list = [10, 42, 56, 78, 110, 100]
    for _ in range(number_randoms):
        str_seq = random_module.choice(str_seq_list)
        length = random_module.choice(length_list)
        res = random.generate_string(str_seq, length)
        if not isinstance(res, str):
            raise AssertionError('Type of result is not str.')
        if len(res) > length:
            raise Assert

# Generated at 2022-06-23 21:52:30.289057
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###', '@', '#')

# Generated at 2022-06-23 21:52:37.792152
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    rnd = Random()
    length = 10
    letters = string.ascii_lowercase + string.ascii_uppercase
    numbers = string.digits

    # generate string from letters only
    str_letters = rnd.generate_string(letters, length)
    assert (len(str_letters) == length) and \
        (str_letters.isalpha())

    # generate string from numbers only
    str_numbers = rnd.generate_string(numbers, length)
    assert (len(str_numbers) == length) and \
        (str_numbers.isdigit())

    # generate string from letters and numbers
    str_letters_numbers = rnd.generate_string(numbers + letters, length)

# Generated at 2022-06-23 21:52:42.239702
# Unit test for method randstr of class Random
def test_Random_randstr():
    # foo(100) is a test, which should be failed
    def foo(length):
        # Generate 100 random string of length 10
        for i in range(100):
            assert 10 == len(random.randstr(length=length))
        
    foo(10) # should be passed
    # foo(100) # should be failed

# Generated at 2022-06-23 21:52:45.236545
# Unit test for method uniform of class Random
def test_Random_uniform():
    random.seed(0)
    assert random.uniform(0.0, 1.0) == 0.8444218515250481



# Generated at 2022-06-23 21:52:48.650469
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method randstr of class Random."""
    _rnd_str_value = random.randstr()
    assert _rnd_str_value != ''



# Generated at 2022-06-23 21:52:53.382884
# Unit test for method randstr of class Random
def test_Random_randstr():
    _string = random.randstr(unique=False, length=None)
    assert len(_string) in list(range(16, 128)), 'Len out of range'
    _string = random.randstr(unique=False, length=32)
    assert len(_string) == 32, 'Wrong length'

# Generated at 2022-06-23 21:52:55.926178
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code = Random().custom_code(mask='@@@###')
    assert len(code) == 6


# Generated at 2022-06-23 21:52:57.531611
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(1, 2) == 1.0

# Generated at 2022-06-23 21:52:59.693658
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    print(r.randint(1, 10))


# Generated at 2022-06-23 21:53:01.152363
# Unit test for method urandom of class Random
def test_Random_urandom():
    urandom = Random.urandom(64)
    assert isinstance(urandom, bytes)

# Generated at 2022-06-23 21:53:01.884462
# Unit test for function get_random_item
def test_get_random_item():
    pass

# Generated at 2022-06-23 21:53:12.061669
# Unit test for method uniform of class Random
def test_Random_uniform():
    # test 1
    expected_result = 1.0
    result = Random().uniform(1, 1.1)
    assert result == expected_result, f'Unit test failed'
    # test 2
    expected_result = 1.1
    result = Random().uniform(1, 1.2)
    assert result == expected_result, f'Unit test failed'
    # test 3
    expected_result = 1.2
    result = Random().uniform(1, 1.3)
    assert result == expected_result, f'Unit test failed'
    # test 4
    expected_result = 1.3
    result = Random().uniform(1, 1.4)
    assert result == expected_result, f'Unit test failed'
    # test 5
    expected_result = 1.4

# Generated at 2022-06-23 21:53:16.293982
# Unit test for method randstr of class Random
def test_Random_randstr():
    string1 = random.randstr()
    string2 = random.randstr(unique=True)
    assert string1 != string2

# Generated at 2022-06-23 21:53:19.431358
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test method uniform of class Random."""
    assert random.uniform(1, 2) > 1.0 and random.uniform(1, 2) <= 2.0

# Generated at 2022-06-23 21:53:28.556860
# Unit test for constructor of class Random
def test_Random():
    # Generate list of random integers
    amount = 5
    a = 0
    b = 10
    rand_list = Random().randints(amount, a, b)
    assert isinstance(rand_list, list) and \
           len(rand_list) == amount and \
           all(i >= a and i <= b for i in rand_list)

    # Generate random string created from string sequence
    str_seq = 'ABC'
    max_value = 5
    assert Random().generate_string(str_seq, max_value)

    # Generate custom code using ascii uppercase and random integers
    code = Random().custom_code('@###')
    assert code and len(code) == 4 and code[0] in string.ascii_uppercase \
        and code[1:].isdigit()



# Generated at 2022-06-23 21:53:31.106024
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)


# Generated at 2022-06-23 21:53:38.350255
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    result = random.generate_string(char_set, 10)
    assert 10 == len(result)
    result = Random().generate_string(char_set, 20)
    assert 20 == len(result)
    result = random.generate_string(char_set, 30)
    assert 30 == len(result)
    result = random.generate_string(char_set, 40)
    assert 40 == len(result)
    result = random.generate_string(char_set, 50)
    assert 50 == len(result)
    result = r

# Generated at 2022-06-23 21:53:39.273393
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random().urandom(20)

# Generated at 2022-06-23 21:53:43.506992
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method ``generate_string()``.
    """
    n = 40
    rnd = Random()
    string_list = rnd.generate_string(string.ascii_letters, n)
    assert not len(string_list) == 0
    assert len(string_list) == n



# Generated at 2022-06-23 21:53:44.787223
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(0.25, 0.25) == 0.25

# Generated at 2022-06-23 21:53:54.579718
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Test different lengths
    print(random.randstr(unique=False, length=10))
    print(random.randstr(unique=False, length=20))
    print(random.randstr(unique=False, length=30))

    # Test unique parameter
    print(random.randstr(unique=True))
    print(random.randstr(unique=True))
    print(random.randstr(unique=True))

    # Test default length
    print(random.randstr(unique=False))
    print(random.randstr(unique=False))
    print(random.randstr(unique=False))

# Generated at 2022-06-23 21:54:03.189128
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    global random

    assert random.custom_code('@@@@@', char='@', digit='#') \
        in ['ZCXYE', 'XKQLX', 'QJGUM', 'RCCPR']
    assert random.custom_code('@@@', char='@', digit='#') in ['XKQ', 'ZCX', 'RMC']
    assert random.custom_code('@@', char='@', digit='#') in ['XK', 'ZC', 'RM']
    assert random.custom_code(mask='@##@', char='@', digit='#') \
        in ['WY22V', 'JY94B', 'ZP75W', 'TA09H']

# Generated at 2022-06-23 21:54:15.362741
# Unit test for method custom_code of class Random

# Generated at 2022-06-23 21:54:17.583819
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert len(random.randstr(unique=True, length=32)) == 32
    assert len(random.randstr(unique=False, length=32)) == 32

# Generated at 2022-06-23 21:54:19.447223
# Unit test for constructor of class Random
def test_Random():
    random = Random()
    assert random.seed == None, "Expected None, but got {}".format(random.seed)


# Generated at 2022-06-23 21:54:21.949706
# Unit test for method urandom of class Random
def test_Random_urandom():
    a = Random().urandom(100)
    b = Random().urandom(100)
    assert a != b

# Generated at 2022-06-23 21:54:28.359758
# Unit test for method randstr of class Random
def test_Random_randstr():
    count = 1000
    for _ in range(count):
        _str = random.randstr(unique=False)
        assert isinstance(_str, str)
        assert len(_str) <= 128
        assert len(_str) >= 16

        _str = random.randstr(unique=True)
        assert isinstance(_str, str)
        assert len(_str) == 32

        _str = random.randstr(length=32)
        assert isinstance(_str, str)
        assert len(_str) == 32



# Generated at 2022-06-23 21:54:29.608068
# Unit test for constructor of class Random
def test_Random():
    obj = Random()
    assert isinstance(obj, random_module.Random)


# Generated at 2022-06-23 21:54:30.588781
# Unit test for method urandom of class Random
def test_Random_urandom():
    print(Random.urandom(10))


# Generated at 2022-06-23 21:54:32.321894
# Unit test for function get_random_item
def test_get_random_item():
    """Test function ``get_random_item()``."""
    assert get_random_item(enum=random.choice([1, 2, 3])) in [1, 2, 3]

# Generated at 2022-06-23 21:54:35.708254
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import OperatingSystem

    rnd = random.randint(-10, 10)
    rnd1 = get_random_item(OperatingSystem, rnd)
    assert rnd1 == rnd


# Generated at 2022-06-23 21:54:37.098565
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code().isalnum()



# Generated at 2022-06-23 21:54:43.015667
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _rnd = Random()
    _mask = 'A###BB##'
    for _ in range(10):
        assert len(_rnd.custom_code(_mask)) == len(_mask)
        # assert len(_rnd.custom_code('..###..##')) == len(_mask)
        # assert len(_rnd.custom_code('+###++##')) == len(_mask)

# Generated at 2022-06-23 21:54:47.071382
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random.seed(3)
    rc = random.custom_code()
    assert rc == 'G0K1'
    rc = random.custom_code('@@##')
    assert rc == 'IP80'
    rc = random.custom_code('@@##')
    assert rc == 'YN47'
    rc = random.custom_code('@@##', char='$', digit='%')
    assert rc == '!W74'


# Generated at 2022-06-23 21:54:53.001082
# Unit test for function get_random_item
def test_get_random_item():
    assert type(get_random_item(enum=string.ascii_letters)) is str # nosec
    assert len(get_random_item(enum=string.ascii_letters)) == 1 # nosec
    assert type(get_random_item(enum=string.digits)) is str # nosec
    assert len(get_random_item(enum=string.digits)) == 1 # nosec

# Generated at 2022-06-23 21:54:55.869915
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rand = Random()
    rand.seed(1234)
    res = rand.custom_code()
    assert res == '@846', 'Wrong result'

# Generated at 2022-06-23 21:55:05.769493
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = Random(1)
    assert r.randstr() == "a0a5b6cca5a01c2d0f1d8f5a"
    assert len(r.randstr()) == 32
    assert r.randstr(length=10) == "a0a5b6ccaa"
    assert len(r.randstr(length=10)) == 10
    assert r.randstr(unique=True) == "d7f0009f-2d7e-4b68-b351-df1dca4482e0"
    assert len(r.randstr(unique=True)) == 36
    assert r.randstr(unique=True, length=10) == "d7f0009f-2d7e-4b68-b351-df1dca4482e0"

# Generated at 2022-06-23 21:55:12.828886
# Unit test for method uniform of class Random
def test_Random_uniform():
    r = Random()
    assert type(r.uniform(0.0, 1.0, 2)) == float, 'values should be float type'
    assert r.uniform(1, 10) >= 1, 'values should be more than 1'
    assert r.uniform(1, 10) <= 10, 'values should be less than 10'
    assert r.uniform(0, 10, 1) >= 0, 'values should be more than 0'
    assert r.uniform(0, 10, 1) <= 10, 'values should be less than 10'

# Generated at 2022-06-23 21:55:22.206051
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    letters = string.ascii_uppercase
    random_code_1 = Random().custom_code()
    random_code_2 = Random().custom_code('@###')
    random_code_3 = Random().custom_code(letters)
    random_code_4 = Random().custom_code('@###', '@', '#')
    random_code_5 = Random().custom_code('@###', '@', '#')

    assert isinstance(random_code_1, str)
    assert isinstance(random_code_2, str)
    assert isinstance(random_code_3, str)
    assert isinstance(random_code_4, str)
    assert isinstance(random_code_5, str)

    assert len(random_code_1) == 10
    assert len(random_code_2)

# Generated at 2022-06-23 21:55:25.624083
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string(string.ascii_uppercase, 40)
    assert len(Random().generate_string(string.digits, 20)) == 20
    assert Random().generate_string(string.ascii_lowercase)

# Generated at 2022-06-23 21:55:27.643552
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, random_module.Random)



# Generated at 2022-06-23 21:55:38.443041
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print(random.custom_code())
    print(random.custom_code(mask='@@@###'))
    print(random.custom_code(mask='@@@###', char='@', digit='$'))
    print(random.custom_code(mask='@@@###', char='$', digit='@'))
    random.seed(1234)
    print(random.custom_code())
    print(random.custom_code(mask='@@@###'))
    print(random.custom_code(mask='@@@###', char='@', digit='$'))
    print(random.custom_code(mask='@@@###', char='$', digit='@'))

if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-23 21:55:43.867897
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@###') == 'A123'
    assert Random().custom_code('A@@@') == 'AAMM'
    assert Random().custom_code('#@#@', char='#', digit='@') == '2Q9Q'

# Generated at 2022-06-23 21:55:50.383226
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Checking correctness of function randstr for class Random."""
    for _ in range(10):
        assert isinstance(random.randstr(), str)
        assert len(random.randstr()) in range(16, 128)
        assert random.randstr(unique=False)
        assert ''.join(random.randstr(unique=False).split('-'))

# Generated at 2022-06-23 21:55:57.111726
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for custom_code."""
    random = Random()
    from mimesis.enums import Char

    if random.custom_code() == random.custom_code():
        raise AssertionError('You cannot use equal strings for mask!')

    for i in range(100):
        if Char.UPPERCASE.value in random.custom_code(mask='##'):
            break
    else:
        raise AssertionError('Seems that the mime is utterly '
                             'unable to generate the letter "A" or "B".')

# Generated at 2022-06-23 21:55:59.293580
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(enum=random, rnd=random)
    assert get_random_item(enum=random)



# Generated at 2022-06-23 21:56:09.801777
# Unit test for method randints of class Random
def test_Random_randints():
    """Test ``Random.randints()`` method."""
    assert isinstance(random.randints(), list)
    assert len(random.randints()) == 3
    assert len(random.randints(amount=10)) == 10
    assert isinstance(random.randints(amount=1), list)
    assert len(random.randints(amount=1)) == 1
    assert random.randints(amount=5, a=5) == [5, 5, 5, 5, 5]
    assert len(random.randints(amount=5, b=5)) == 5
    assert random.randints(amount=5, a=5, b=5) == [5, 5, 5, 5, 5]



# Generated at 2022-06-23 21:56:16.128174
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert isinstance(rnd.randints(), list)
    assert isinstance(rnd.randints(10), list)
    assert isinstance(rnd.randints(a=10, b=50), list)
    assert isinstance(rnd.randints(10, 10, 50), list)
    assert isinstance(rnd.randints(amount=10, a=10, b=50), list)



# Generated at 2022-06-23 21:56:18.585474
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    for _ in range(0, 10):
        assert rnd.uniform(1, 3) >= 1.0 and rnd.uniform(1, 3) < 3.0

# Generated at 2022-06-23 21:56:21.015851
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    assert isinstance(Random().generate_string(string.ascii_letters), str)

# Generated at 2022-06-23 21:56:30.595017
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code(mask='@###', char='@', digit='#') == Random().custom_code()
    assert Random().custom_code('@###', '@', '#') == Random().custom_code()
    assert Random().custom_code('@###') == Random().custom_code(char='@', digit='#')
    assert Random().custom_code('###', '@', '#') == Random().custom_code(digit='#')
    assert Random().custom_code('@###', '@', '@') == Random().custom_code(char='@', digit='@')
    assert Random().custom_code('@###', '@', '@') == Random().custom_code('@###', '@', '@')
    assert Random().custom_code('@###', '@', '#') != Random().custom_code

# Generated at 2022-06-23 21:56:32.343384
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert len(Random.urandom(10)) == 10
    assert len(Random().urandom(10)) == 10

# Generated at 2022-06-23 21:56:37.259118
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Precondition
    rnd = Random()
    rnd.seed(0)

    str_seq = 'abcdefghijklmnopqrstuvwxyz1234567890'
    length = 10

    # Run
    result = rnd.generate_string(str_seq, length)
    # Postcondition
    assert result == 'f8g4t4p4jw'

# Generated at 2022-06-23 21:56:47.170021
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Task 1
    # With default params (mask='@###')
    # and with custom placeholder for chars and digits
    # https://github.com/lk-geimfari/mimesis/issues/8
    a = 'ABC@000@'
    b = random.custom_code('A###C###', 'A', 'C')
    c = random.custom_code('A###C###', 'C', 'A')
    d = random.custom_code()
    assert b != c
    assert len(b) == len(c) == len(a)
    assert len(d) == len(a) - 3

    # Task 2
    # With custom mask and with default placeholder
    # for chars and digits
    assert len(random.custom_code('@@@@@@@')) == 7

    # Task 3
    # With

# Generated at 2022-06-23 21:56:53.195406
# Unit test for method randints of class Random
def test_Random_randints():
    cases = [(2, 1, 3),
             (2, 0, 3),
             (2, 1, 4),
             (1, 1, 4),
             (100, 1, 4),
             (100, 1, 200),
             (100, 0, 200),
             (100, 1, 200),
             (100, -100, 200),
             (100, 1, 300)
             ]
    for case in cases:
        first_elem = next(iter(Random().randints(*case)))
        assert case[1] <= first_elem <= case[2]
        assert len(Random().randints(*case)) == case[0]

# Generated at 2022-06-23 21:56:57.528757
# Unit test for function get_random_item
def test_get_random_item():
    class EnumExample(Random):
        """Example of enum object."""
        one = 1
        two = 2
        three = 3

    item = get_random_item(EnumExample)
    assert type(get_random_item(EnumExample)) is int
    assert item == 1 or item == 2 or item == 3

# Generated at 2022-06-23 21:56:58.160164
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)



# Generated at 2022-06-23 21:56:59.430940
# Unit test for constructor of class Random
def test_Random():
    """Unit-test for constructor of class ``Random``."""
    assert isinstance(Random(), Random)



# Generated at 2022-06-23 21:57:00.400578
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(None) is None

# Generated at 2022-06-23 21:57:01.639445
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(Random().randints(), list)


# Generated at 2022-06-23 21:57:10.041505
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from random import randint
    from mimesis.enums import Gender, Currency
    from mimesis.providers.internet import Internet
    from mimesis.providers.payment import Payment

# Generated at 2022-06-23 21:57:14.161469
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert 'ABCD-5678' == random.custom_code('ABCD-####', char='@', digit='#')
    assert 'ABCD-5678' == random.custom_code('ABCD-####')



# Generated at 2022-06-23 21:57:16.141521
# Unit test for constructor of class Random
def test_Random():
    assert len(Random().randints()) == len(Random().randints(amount=4))



# Generated at 2022-06-23 21:57:18.761263
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random."""
    rnd = random_module.Random()
    output = rnd.uniform(-2, 2)
    assert -2 <= output <= 2

# Generated at 2022-06-23 21:57:28.044232
# Unit test for method randstr of class Random
def test_Random_randstr():
    # Test 1
    seed = random.getstate()
    s = random.randstr(length=10)
    random.setstate(seed)
    assert s == random.randstr(length=10)
    assert len(s) == 10

    # Test 2
    assert len(random.randstr()) > 0

    # Test 3
    s = random.randstr(unique=True)
    assert isinstance(s, str)

    # Test 4
    seed = random.getstate()
    s1 = random.randstr(unique=True)
    seed = random.getstate()
    s2 = random.randstr(unique=True)
    random.setstate(seed)
    s3 = random.randstr(unique=True)
    assert s1 != s2
    assert s2 != s3

# Generated at 2022-06-23 21:57:31.991070
# Unit test for method uniform of class Random
def test_Random_uniform():
    assert random.uniform(5, 6) >= 5
    assert random.uniform(5, 6) < 6
    assert random.uniform(5, 6) >= 5.2
    assert random.uniform(5, 6) < 5.5

# Generated at 2022-06-23 21:57:38.148143
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Generate random string created from string sequence.
    """
    rand = Random()
    # generate a random string consisting of only digits,
    # it's length is 10 characters
    rand.generate_string(string.digits, 10)

    # generate a random string consisting of only letters,
    # it's length is 10 characters
    rand.generate_string(string.ascii_uppercase, 10)
    rand.generate_string(string.ascii_lowercase, 10)

    # generate a random string consisting of both digits and letters,
    # it's length is 10 characters
    rand.generate_string(string.ascii_letters + string.digits, 10)

    # if you do not pass the second parameter, the length of the string will be 10

# Generated at 2022-06-23 21:57:44.482866
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.schema import Field, Schema

    class A:
        a = Field(enum=(1, 2, 3))

    for r in range(100):
        obj = A()
        assert get_random_item(A.a.enum) in A.a.enum
        obj.a = get_random_item(A.a.enum)
        assert Schema(obj, random=Random()).create().a in A.a.enum

# Generated at 2022-06-23 21:57:48.883765
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Test for method uniform of class Random.
    """
    rnd = Random()
    a = 0
    b = 100
    i = 0
    while i < 10:
        result = rnd.uniform(a, b)
        assert type(result) == float
        assert result >= a, result
        assert result <= b, result
        i += 1


# Generated at 2022-06-23 21:57:54.126578
# Unit test for method randints of class Random
def test_Random_randints():
    assert isinstance(random.randints(), list)
    assert isinstance(random.randints(3), list)
    assert isinstance(random.randints(amount=3), list)
    assert isinstance(random.randints(3, 1, 10), list)
    assert isinstance(random.randints(amount=3, a=1, b=10), list)



# Generated at 2022-06-23 21:58:06.020299
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _random = Random()
    print(_random.custom_code())
    print(_random.custom_code('@###'))
    print(_random.custom_code('#####'))
    print(_random.custom_code('@'))
    print(_random.custom_code('##'))
    print(_random.custom_code(None))
    print(_random.custom_code(''))
    print(_random.custom_code())
    _random.custom_code(char='#')
    _random.custom_code(digit='@')
    try:
        _random.custom_code(char='#', digit='#')
    except ValueError:
        pass


if __name__ == '__main__':
    test_Random_custom_code()

# TODO: Add tests for the other methods

# Generated at 2022-06-23 21:58:08.761486
# Unit test for method randints of class Random
def test_Random_randints():
    for i in range(1, 100):
        random_ints = Random().randints(amount=i, a=10, b=1000)
        assert len(random_ints) == i



# Generated at 2022-06-23 21:58:09.977273
# Unit test for method urandom of class Random
def test_Random_urandom():
    x = Random.urandom()
    assert x is not None


# Generated at 2022-06-23 21:58:12.599374
# Unit test for method randstr of class Random
def test_Random_randstr():
    assert Random().randstr(unique=True)
    assert Random().randstr(unique=False)
    assert Random().randstr(unique=False, length=32)
    assert Random().randstr(unique=True, length=32)

# Generated at 2022-06-23 21:58:21.572708
# Unit test for method uniform of class Random
def test_Random_uniform():

    for _ in range(100):
        assert random.uniform(0, 1) <= 1.
        assert random.uniform(0, 1) >= 0.

    for _ in range(100):
        assert random.uniform(0, 10) <= 10.
        assert random.uniform(0, 10) >= 0.

    for _ in range(100):
        assert random.uniform(1, 10) <= 10.
        assert random.uniform(1, 10) >= 1.

    for _ in range(100):
        assert random.uniform(10, 15) >= 10.
        assert random.uniform(10, 15) <= 15.

# Generated at 2022-06-23 21:58:24.338646
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Test for method generate_string of class Random."""
    r = Random()
    r.seed(10)
    assert r.generate_string('AABB12', 5) == 'BBB12'

# Generated at 2022-06-23 21:58:27.242007
# Unit test for method urandom of class Random
def test_Random_urandom():
    # Arrange
    rest = Random()

    # Act
    result = rest.urandom(4)

    # Assert
    assert len(result) == 4



# Generated at 2022-06-23 21:58:28.242811
# Unit test for method urandom of class Random
def test_Random_urandom():
    assert Random.urandom()


# Generated at 2022-06-23 21:58:30.579680
# Unit test for function get_random_item
def test_get_random_item():
    assert get_random_item(enum=list(range(10))) in list(range(10))

# Generated at 2022-06-23 21:58:31.612445
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(Random(), Random)



# Generated at 2022-06-23 21:58:34.144794
# Unit test for method uniform of class Random
def test_Random_uniform():
    rnd = Random()
    assert rnd.uniform(0,0.9)<0.9
    assert rnd.uniform(0,0.9, 15)<0.9

# Generated at 2022-06-23 21:58:38.482200
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform of class Random.

    """
    r = Random()
    min_price = 0.00
    max_price = 100.00
    precision = 2
    assert r.uniform(min_price, max_price, precision) <= max_price
    assert r.uniform(min_price, max_price, precision) >= min_price

test_Random_uniform()

# Generated at 2022-06-23 21:58:44.944864
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code('@###', char='@', digit='#')
    assert len(code) == 4
    assert code[0] in string.ascii_uppercase
    assert code[1] in string.ascii_uppercase
    assert code[2] in string.digits
    assert code[3] in string.digits

# Generated at 2022-06-23 21:58:49.279485
# Unit test for method uniform of class Random
def test_Random_uniform():
    """Unit test for method uniform."""
    test_a = 0.000000134
    test_b = 0.000000067
    test_precision = 20
    assert random.uniform(test_a, test_b, test_precision) in range(test_a, test_b)



# Generated at 2022-06-23 21:58:52.403881
# Unit test for function get_random_item
def test_get_random_item():

    class Color(enum.Enum):
        RED = 'red'
        GREEN = 'green'
        BLUE = 'blue'

    assert get_random_item(Color) in Color

# Generated at 2022-06-23 21:59:02.053315
# Unit test for function get_random_item
def test_get_random_item():
    import enum
    import random
    import string

    class FakeDataType(enum.Enum):
        NAME = 'name'
        PATRONYMIC = 'patronymic'
        SURNAME = 'surname'

    random_item = get_random_item(enum=FakeDataType, rnd=Random())
    assert random_item in FakeDataType._value2member_map_

    # Random object should not be None
    assert get_random_item(enum=FakeDataType, rnd=random.Random())[0] \
        in FakeDataType._value2member_map_.values()

    for value in FakeDataType._value2member_map_.values():
        assert get_random_item(enum=FakeDataType, rnd=Random())[0] \
            == value

    # Test with string

# Generated at 2022-06-23 21:59:06.741403
# Unit test for method randstr of class Random
def test_Random_randstr():
    # 1
    assert isinstance(random.randstr(unique=True), str)
    # 2
    assert isinstance(random.randstr(length=32), str)
    # 3
    assert len(random.randstr(length=32)) == 32
    # 4
    assert random.randstr() == random.randstr()
    # 5
    assert random.randstr(unique=True) != random.randstr(unique=True)

# Generated at 2022-06-23 21:59:08.243267
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    assert len(rnd.randints(5)) == 5

# Generated at 2022-06-23 21:59:11.852056
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    # Positive tests
    # Chars
    assert len(random.generate_string(string.ascii_letters, 10)) == 10

    # Digits
    assert len(random.generate_string(string.digits, 8)) == 8



# Generated at 2022-06-23 21:59:13.877730
# Unit test for constructor of class Random
def test_Random():
    _random = Random()
    assert _random.urandom(16) == random_module.Random().urandom(16)



# Generated at 2022-06-23 21:59:15.566673
# Unit test for function get_random_item
def test_get_random_item():
    from .enums import Gender  # noqa
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-23 21:59:17.606018
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert isinstance(rnd, random_module.Random)
    assert isinstance(rnd, Random)


# Generated at 2022-06-23 21:59:21.377190
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Test for method randstr of class Random.

    :return:
    """
    assert len(random.randstr()) == 32
    assert not random.randstr(unique=True) == random.randstr(unique=True)
    assert len(random.randstr(length=64)) == 64



# Generated at 2022-06-23 21:59:22.490642
# Unit test for method randints of class Random
def test_Random_randints():
    """Unit test for method ``randints()`` of class ``Random()``."""
    pass

# Generated at 2022-06-23 21:59:24.301602
# Unit test for constructor of class Random
def test_Random():
    rnd = Random()
    assert isinstance(rnd, Random)



# Generated at 2022-06-23 21:59:31.201533
# Unit test for method randints of class Random
def test_Random_randints():
    amount = 5
    a = 1
    b = 100
    rnd = Random()
    assert len(rnd.randints(amount=1, a=a, b=b)) == 1
    assert len(rnd.randints(amount=amount, a=a, b=b)) == amount
    assert len(rnd.randints(amount=2, a=a, b=b)) == 2


# Generated at 2022-06-23 21:59:34.704262
# Unit test for method randstr of class Random
def test_Random_randstr():
    random = Random()
    string = random.randstr()
    assert isinstance(string, str)
    assert len(string) <= 128
    string = random.randstr(length=64)
    assert isinstance(string, str)
    assert len(string) == 64

# Generated at 2022-06-23 21:59:38.511943
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    str_seq = 'abcdefghijklmnopqrstuvwxyz'
    length = 5
    string1 = random.generate_string(str_seq, length)
    assert len(string1) == length
    string2 = random.generate_string(str_seq)
    assert len(string2) > 0
    for letter in string1:
        assert letter in str_seq
    for letter in string2:
        assert letter in str_seq

# Generated at 2022-06-23 21:59:46.923485
# Unit test for function get_random_item
def test_get_random_item():
    class Item(object):
        """Class for testing."""

        def __init__(self, a: str) -> None:
            """Initialise values."""
            self.a = a

        def __str__(self) -> str:
            """String representation."""
            return self.a

        def __eq__(self, other: Any) -> bool:
            """Self-equals."""
            return self.a == other.a

    class Enum(object):
        """Enum class."""

        items = [Item('1'), Item('2'), Item('3')]

    assert get_random_item(Enum.items) in Enum.items

# Generated at 2022-06-23 21:59:54.350464
# Unit test for constructor of class Random
def test_Random():
    """Check for passing a parameter as a seed."""
    r = Random(0)
    r.randstr()
    r.custom_code()
    r.generate_string('', 1)
    r.generate_string('1')
    r.uniform(0, 1)
    r.uniform(0, 2, 3)
    r.randints(1)
    r.randints(2, 1)
    r.uniform(1, 5, 6)



# Generated at 2022-06-23 21:59:57.337085
# Unit test for method randstr of class Random
def test_Random_randstr():
    r = Random()
    assert len(r.randstr(unique=True)) == 32
    assert len(r.randstr(length=16)) == 16
    assert len(r.randstr(unique=True, length=64)) == 64

# Generated at 2022-06-23 21:59:59.492909
# Unit test for method randstr of class Random
def test_Random_randstr():
    value = random.randstr(length=10)
    assert len(value) == 10
    value = random.randstr(unique=True)
    assert len(value) == 32



# Generated at 2022-06-23 22:00:00.359738
# Unit test for constructor of class Random
def test_Random():
    assert isinstance(random, Random)

# Generated at 2022-06-23 22:00:11.642032
# Unit test for function get_random_item
def test_get_random_item():
    from datetime import date
    import enum

    class Color(enum.Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    class DateFormat(enum.Enum):
        LONG = '%d-%m-%Y'
        SHORT = '%d-%m'

    # Get random item of enum
    assert isinstance(get_random_item(Color), Color)
    assert isinstance(get_random_item(DateFormat), DateFormat)

    # Check that random item of enum is expected
    assert get_random_item(Color, random_module) == Color.RED
    assert get_random_item(DateFormat, random_module) == DateFormat.LONG

    # Custom random object is working properly
    r = Random()

# Generated at 2022-06-23 22:00:14.536791
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    """Unit test for method generate_string of class Random."""
    _str = random.generate_string('333asd')
    assert isinstance(_str, str)



# Generated at 2022-06-23 22:00:17.813794
# Unit test for method randints of class Random
def test_Random_randints():
    rnd = Random()
    lst = rnd.randints(amount=10, a=5, b=10)
    for it in lst:
        assert 5 <= it <= 10


# Generated at 2022-06-23 22:00:19.236491
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r.random(), float)



# Generated at 2022-06-23 22:00:24.453459
# Unit test for function get_random_item
def test_get_random_item():
    class Fruit:
        def __init__(self, name: str, color: str):
            self.name = name
            self.color = color

    fruits = {
        'apple': Fruit('apple', 'red'),
        'banana': Fruit('banana', 'yellow'),
        'watermelon': Fruit('watermelon', 'green'),
    }
    for _ in range(100):
        assert (get_random_item(fruits) in fruits)



# Generated at 2022-06-23 22:00:26.010617
# Unit test for constructor of class Random
def test_Random():
    # Positive
    _ = Random()


# Tests for methods of class Random

# Generated at 2022-06-23 22:00:28.007316
# Unit test for constructor of class Random
def test_Random():
    r = Random()
    assert isinstance(r, random_module.Random)

# Generated at 2022-06-23 22:00:34.025718
# Unit test for method randints of class Random
def test_Random_randints():
    _rnd = Random()
    _list = _rnd.randints(amount=10, a=-100, b=100)
    assert isinstance(_list, list)
    assert len(_list) == 10
    assert all(map(lambda x: -100 <= x <= 100, _list))
    for i in _list:
        assert isinstance(i, int)

# Generated at 2022-06-23 22:00:35.730740
# Unit test for method generate_string of class Random
def test_Random_generate_string():

    assert random.generate_string('123', 1) != random.generate_string('1234', 1)

# Generated at 2022-06-23 22:00:38.827732
# Unit test for function get_random_item
def test_get_random_item():
    class EnumTest:
        def __init__(self, value):
            self.value = value

    enum_test = EnumTest(1)

    assert get_random_item(enum_test) == enum_test

# Generated at 2022-06-23 22:00:46.268952
# Unit test for method uniform of class Random
def test_Random_uniform():
    def verify(a, b, precision, expected):
        result = random.uniform(a, b, precision)
        assert result == expected

    verify(a=0.1, b=0.1, precision=1, expected=0.1)
    verify(a=0.1, b=0.1, precision=15, expected=0.1)
    verify(a=0.1, b=0.2, precision=1, expected=0.1)
    verify(a=0.1, b=0.2, precision=15, expected=0.1)
    verify(a=0.1, b=0.9, precision=1, expected=0.1)
    verify(a=0.1, b=0.9, precision=15, expected=0.1)

# Generated at 2022-06-23 22:00:48.327774
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    x = Random().generate_string('1234567890')
    assert(len(x) == 10)


# Generated at 2022-06-23 22:00:55.755365
# Unit test for method randstr of class Random
def test_Random_randstr():
    import pytest
    from hypothesis import given, strategies as st

    r = random.randstr()

    @given(st.text(min_size=0, max_size=128))
    def test_randstr_return_length(s: str):
        # check if length > 0
        assert len(r) > 0

    test_randstr_return_length()

    @given(st.text(min_size=0, max_size=128))
    def test_str_is_str(s: str):
        # check if type is str
        assert isinstance(r, str)

    test_str_is_str()

    with pytest.raises(TypeError):
        # check if method raise TypeError with length=0
        random.randstr(length=0)


# Generated at 2022-06-23 22:01:01.277587
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    str_seq = '0123456789'
    rnd = Random()
    assert len(rnd.generate_string(str_seq)) == 10
    assert rnd.generate_string(str_seq, length=4) == '1234'
    assert ''.join([str(rnd.choice(range(10))) for _ in range(10)]
                  ) == rnd.generate_string(str_seq)



# Generated at 2022-06-23 22:01:03.249592
# Unit test for method randstr of class Random
def test_Random_randstr():
    random = Random()
    assert random.randstr(length=33).__len__() == 33

# Generated at 2022-06-23 22:01:06.100714
# Unit test for method urandom of class Random
def test_Random_urandom():
    """Test method ``urandom()`` of class ``Random()``."""
    ur = random.urandom()
    assert isinstance(ur, bytes)
    assert len(ur) == 32

# Generated at 2022-06-23 22:01:07.950484
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert random.generate_string('abc', 3) == 'abc'


# Generated at 2022-06-23 22:01:12.963145
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = random.custom_code('@###-@##-AB##')
    t = r.split('-')
    assert len(t) == 3
    assert len(t[0]) == len(t[1]) == len(t[2]) == 4
    assert t[0].isalpha()
    assert t[1].isalpha()
    assert not t[2].isdigit()

# Generated at 2022-06-23 22:01:14.919398
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    _random = Random()
    _string = _random.generate_string('ABCDEFGH')
    print(_string)


# Generated at 2022-06-23 22:01:17.595166
# Unit test for method generate_string of class Random
def test_Random_generate_string():
    assert Random().generate_string("1234567890",4) == "4175"

    # Unit test for method custom_code of class Random

# Generated at 2022-06-23 22:01:26.623769
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _len = 3
    a = random.randint(65, 91)
    b = random.randint(48, 58)
    assert len(random.custom_code(mask='@###', char='@', digit='#')) == _len
    assert len(random.custom_code(mask='@###', char='@', digit='@')) == _len
    assert len(random.custom_code(mask='@@@', char='@', digit='#')) == _len
    assert len(random.custom_code(mask='@@@', char='@', digit='@')) == _len
    assert len(random.custom_code(mask='@@@@@@', char='@', digit='#')) == _len
    assert len(random.custom_code(mask='@@@@@@', char='@', digit='@')) == _len

# Generated at 2022-06-23 22:01:32.149995
# Unit test for method randstr of class Random
def test_Random_randstr():
    """Unit test for method ``randstr()`` of class ``Random``. """
    unique_strs = {random.randstr(unique=True) for _ in range(20)}
    assert len(unique_strs) == 20

    strs = [random.randstr() for _ in range(20)]
    unique_strs = {_.lower() for _ in strs if _}
    assert len(unique_strs) == 20