

# Generated at 2022-06-12 02:51:45.784998
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    print(rnd.custom_code(mask='&@####', char='@', digit='#'))
    print(rnd.custom_code(mask='&@@@###', char='@', digit='#'))


test_Random_custom_code()

# Generated at 2022-06-12 02:51:55.457356
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = random()

    # Different placeholders
    actual = r.custom_code(mask='@@###', char='@', digit='#')
    assert actual == 'CL002', f'unexpected result -> {actual}'

    assert r.custom_code(mask='@@###', char='@', digit='$') == 'CL002'
    assert r.custom_code(mask='@@###', char='$', digit='#') == 'CL002'

    # Same placeholder
    expected = 'C@002'
    actual = r.custom_code(mask='@@###', char='@', digit='@')
    assert actual == expected, f'unexpected result -> {actual}'



# Generated at 2022-06-12 02:51:57.079328
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    assert random.custom_code() == random.custom_code()
    assert random.custom_code(mask='@@####', char='@', digit='#') is not None

# Generated at 2022-06-12 02:52:04.752017
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    assert len(Random.custom_code(mask='@##')) == 4
    assert len(Random.custom_code(mask='@@##')) == 5
    assert len(Random.custom_code(mask='@@@##')) == 6
    assert len(Random.custom_code(mask='@@@@##')) == 7
    assert len(Random.custom_code(mask='@@@@@##')) == 8
    assert len(Random.custom_code(mask='@@@@@@##')) == 9
    assert len(Random.custom_code(mask='@@@@@@@##')) == 10
    assert len(Random.custom_code(mask='@@@@@@@##@@@##')) == 16

    # Test custom placeholders

# Generated at 2022-06-12 02:52:15.408371
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random.seed(0)
    code = random.custom_code()
    assert isinstance(code, str)
    assert code == 'W821'
    random.seed(1)
    code = random.custom_code()
    assert isinstance(code, str)
    assert code == 'Y790'
    random.seed(2)
    code = random.custom_code()
    assert isinstance(code, str)
    assert code == 'O510'
    random.seed(3)
    code = random.custom_code(mask="@@@##")
    assert isinstance(code, str)
    assert code == 'ZP34'

# Generated at 2022-06-12 02:52:20.528995
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test Random custom code."""
    rnd = Random()
    result = rnd.custom_code()
    assert isinstance(result, str)
    assert len(result) == 4
    assert len(set(list(result))) == 4
    assert result.isupper()

    result = rnd.custom_code(mask='@####')
    assert isinstance(result, str)
    assert len(result) == 5
    assert len(set(list(result))) == 5
    assert result.isupper()


# Generated at 2022-06-12 02:52:23.857234
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _alpha = string.ascii_uppercase
    assert all(a in _alpha for a in Random().custom_code('@###'))



# Generated at 2022-06-12 02:52:29.615449
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code1 = random.custom_code()
    code2 = random.custom_code()
    assert code1 != code2


# Generated at 2022-06-12 02:52:34.045272
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code(mask='######-#')

    # todo: write a better test
    assert len(code) == 9

# Generated at 2022-06-12 02:52:42.796463
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Positive tests
    test_custom_code_1 = Random().custom_code('@')
    assert (len(test_custom_code_1) == 1)
    test_custom_code_2 = Random().custom_code('##@@#')
    assert (len(test_custom_code_2) == 5)
    assert (test_custom_code_2[2] >= 'A' and test_custom_code_2[2] <= 'Z')
    assert (test_custom_code_2[3] >= 'A' and test_custom_code_2[3] <= 'Z')
    assert (test_custom_code_2[4] >= '0' and test_custom_code_2[4] <= '9')
    # Negative tests