

# Generated at 2022-06-12 02:54:46.179223
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _random = Random(1234567890)
    assert _random.custom_code('@###', char='@', digit='#') == 'UED0'
    assert _random.custom_code('@@@###', char='@', digit='#') == 'XWF721'
    assert _random.custom_code('@@@ ###', char='@', digit='#') == 'NXG 950'
    assert _random.custom_code('@@@###@@@', char='@', digit='#') == 'BZU9 6AG'

# Generated at 2022-06-12 02:54:49.677784
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random(1)
    code = rnd.custom_code()
    assert code == 'V932'

# Generated at 2022-06-12 02:54:53.551122
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r1 = Random(1)
    result = r1.custom_code('@###')
    assert result == 'HK44'



# Generated at 2022-06-12 02:54:59.400066
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Testing Random().custom_code(mask='@###')"""

    mask = '@###'
    code = 'C354'
    assert Random().custom_code(mask=mask) == code, "Uncorrect custom code"

test_Random_custom_code()


# Generated at 2022-06-12 02:55:00.661297
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() not in (None, '')



# Generated at 2022-06-12 02:55:06.547265
# Unit test for method custom_code of class Random
def test_Random_custom_code():
  r = Random()
  r.seed(1)
  assert r.custom_code(mask='@AAA') == 'BWC'
  assert r.custom_code(mask='@#@#') == 'F4F4'
  assert r.custom_code(mask='@###') == 'C56'
  assert r.custom_code(mask='aa@aa@') == 'aaaaaaaa'
  assert r.custom_code(mask='@@@@@@@') == 'AAAAAAAA'
  assert r.custom_code(mask='a@@a@@a') == 'aIaIaIa'
  assert r.custom_code(mask='a@@a@@a') == 'aIaIaIa'
  assert r.custom_code(mask='a@@@a@@@') == 'aJIaJIaJI'

# Generated at 2022-06-12 02:55:13.350462
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    # custom code
    code = random.custom_code('@###')
    assert code
    assert code.isalnum()
    assert len(code) == 4

    # custom code with custom placeholder
    code = random.custom_code('@##', '@', '#')
    assert code
    assert code.isalnum()
    assert len(code) == 3

    # custom code with custom placeholder
    code = random.custom_code('@###', '@', '?')
    assert code
    assert code.isalnum()
    assert len(code) == 4

    # custom code with custom placeholder
    code = random.custom_code('@###', '@', '$')
    assert code
    assert code.isalnum()
    assert len(code) == 4

    # custom code with custom placeholder
    code

# Generated at 2022-06-12 02:55:20.117280
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    #  Success case
    assert Random().custom_code() != ''
    assert Random().custom_code(mask='###') != ''
    assert Random().custom_code(mask='#') != ''
    assert Random().custom_code(mask='##') != ''
    assert Random().custom_code(mask='##@') != ''
    assert Random().custom_code(mask='##@#') != ''
    assert Random().custom_code(mask='@@@@#') != ''
    # Failure case
    try:
        Random().custom_code(mask='@@@', char='@', digit='@')
    except ValueError:
        pass
    try:
        Random().custom_code(mask='@', char='@', digit='@')
    except ValueError:
        pass

# Generated at 2022-06-12 02:55:29.623145
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    char_mask = '@###'
    char_code = '@'
    digit_code = '#'
    code = random.custom_code(mask=char_mask,
                              char=char_code,
                              digit=digit_code)
    assert len(code) == len(char_code)
    assert code != char_mask
    assert char_code not in code
    assert digit_code not in code

# Generated at 2022-06-12 02:55:35.988373
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Testing method custom_code.

    :return: True if all tests passed.
    """
    import unittest

    class TestRandomCustomCode(unittest.TestCase):
        def test_custom_code(self):
            res = Random().custom_code()
            self.assertIsInstance(res, str)
            self.assertEqual(len(res), 4)

            res = Random().custom_code('@##')
            self.assertIsInstance(res, str)
            self.assertEqual(len(res), 3)

            res = Random().custom_code('###')
            self.assertIsInstance(res, str)
            self.assertEqual(len(res), 3)

            res = Random().custom_code(mask='@@######')
            self.assertIsInstance(res, str)