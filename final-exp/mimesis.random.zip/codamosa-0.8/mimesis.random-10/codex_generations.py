

# Generated at 2022-06-12 02:51:45.940680
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for custom_code method."""
    rnd = Random()
    _code_1 = rnd.custom_code(mask='@@##-####')
    _code_2 = rnd.custom_code(mask='@###-@###')
    _code_3 = rnd.custom_code('@###-@###', '@', '#')
    assert len(_code_1) == 10
    assert len(_code_2) == 10
    assert len(_code_3) == 10
    assert _code_1 == _code_2
    assert _code_1 == _code_3
    assert _code_2 == _code_3
    
    

# Generated at 2022-06-12 02:51:54.517483
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    s = '#'
    code = random.custom_code()
    assert any((True if c in s else False
                for c in code)) is False
    assert len(code) == 4
    code = random.custom_code(mask='@@####')
    assert len(code) == 6
    assert code[0] == '@'
    assert code[1] == '@'
    assert code[2] not in s
    assert code[3] not in s
    assert code[4] not in s
    assert code[5] not in s

# Generated at 2022-06-12 02:52:00.744656
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code1 = Random().custom_code('A@@A@@@')
    code2 = Random().custom_code('#####')
    code3 = Random().custom_code('@###@##')

    assert code1.isalnum()
    assert code2.isdigit()
    assert code3.isalnum()

# Generated at 2022-06-12 02:52:01.807413
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _code = random.custom_code()
    assert isinstance(_code, str)

# Generated at 2022-06-12 02:52:07.868455
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(100):
        assert len(random.custom_code()) == 4
        assert len(random.custom_code(mask='XXX###')) == 6
        assert len(random.custom_code(mask='XXX###', char='X')) == 6
        assert len(random.custom_code(mask='XXX###', char='*')) == 6
        assert len(random.custom_code(mask='XXX###', digit='#')) == 6
        assert len(random.custom_code(mask='XXX###', digit='%')) == 6

# Generated at 2022-06-12 02:52:15.247217
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _random = Random()
    _random.seed(42)

    _code = _random.custom_code()
    assert _code == 'H334'

    _code = _random.custom_code(mask='@###...@####')
    assert _code == 'P045...G1673'

    _code = _random.custom_code(mask='###...@###...@###')
    assert _code == '878...B730...C963'

# Generated at 2022-06-12 02:52:19.003372
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    assert Random().custom_code(mask='@###') in {'@000', 'A000', 'A123', '@123'}
    assert Random().custom_code(mask='@@@###') in {'ABC000', 'ABC123', 'ABC999'}

# Generated at 2022-06-12 02:52:28.397813
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test custom_code method of class Random."""
    from mimesis import locales
    assert 'Q123' == random.custom_code()
    assert 'Q123' == Random().custom_code()
    assert 'Q123' == Random().custom_code(length=3)
    assert 'A123' == Random().custom_code(str_seq='ABCDE0123456789')
    assert 'Q123' == Random().custom_code(mask='@###')
    assert 'A123' == Random().custom_code(mask='@###', char='A')
    assert 'Q123' == Random().custom_code(char='A')
    assert 'A123' == Random().custom_code(mask='@###', digit='1')
    assert 'Q123' == Random().custom_code(digit='1')

# Generated at 2022-06-12 02:52:38.700283
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code(mask='@#####')
    assert len(random.custom_code(mask='@#####')) == 6
    assert random.custom_code(mask='#@')
    assert len(random.custom_code(mask='#@')) == 2
    assert random.custom_code(mask='##@###')
    assert len(random.custom_code(mask='##@###')) == 6
    assert not random.custom_code(mask='@')
    assert not random.custom_code(mask='#')
    assert not random.custom_code(mask='###')
    assert not random.custom_code(mask='@@@@@@')
    assert not random.custom_code(mask='######')

# Generated at 2022-06-12 02:52:48.307477
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # 0.
    # Normal usage
    # 1.
    # Two placeholders are the same
    # 2.
    # Zero length of code
    # 3.
    # Length of code less than zero

    # TODO: Rewrite with pytest
    for i, param in enumerate([('@###@###', '@', '#'),
                               ('@###@###', '@', '@'),
                               ('@###@###', '', ''),
                               ('@###@###', '@', '#'),
                               ('@###@###', '-', '#')]):
        try:
            random.custom_code(*param)
        except ValueError as e:
            if i == 1:
                print(e)
            else:
                print('Test Error')
                break

# Generated at 2022-06-12 02:52:57.310791
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    assert rnd.custom_code() == 'J2KE', 'Wrong generated code.'
    assert rnd.custom_code(char='5', digit='7') == '5292', 'Wrong generated code.'
    assert rnd.custom_code(mask='@@@') == 'WJ7', 'Wrong generated code.'

# Generated at 2022-06-12 02:53:06.760552
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print("Test for method custom_code of class Random")
    print("")
    print("#1")
    try:
        random = Random()
        code = random.custom_code("###")
        assert 1
        print("Result: " + str(code))
    except:
        assert 0
    print("")
    print("#2")
    try:
        random = Random()
        code = random.custom_code("%###")
        assert 1
        print("Result: " + str(code))
    except:
        assert 0
    print("")
    print("#3")
    try:
        random = Random()
        code = random.custom_code("@###")
        assert 1
        print("Result: " + str(code))
    except:
        assert 0
    print("")

# Generated at 2022-06-12 02:53:12.381006
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    for _ in range(10):
        char = random.choice(string.ascii_uppercase)
        digit = random.choice(string.digits)
        mask = f'@{digit}@@@{digit}'
        code = random.custom_code(mask)
        assert code[0] == char and code[3] == char and code[4] == digit\
               and code[7] == digit

# Generated at 2022-06-12 02:53:14.210209
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random.seed(42)
    tex

# Generated at 2022-06-12 02:53:19.510949
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _custom_code = random.custom_code(mask = '@###', char = '@', digit = '#')
    assert isinstance(_custom_code, str)
    assert len(_custom_code) == 4
    assert _custom_code[0].isalpha()
    assert _custom_code[1::].isdigit()

# Generated at 2022-06-12 02:53:21.826637
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for custom_code method of class Random."""
    rnd = Random()
    rnd.seed(1)
    assert rnd.custom_code('@###') == "L609"

# Generated at 2022-06-12 02:53:26.838559
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    from mimesis.data import CONTAINERS

    for _ in range(1000):
        _code = random.custom_code()
        assert isinstance(_code, str)
        assert len(_code) == 4
        assert _code in CONTAINERS



# Generated at 2022-06-12 02:53:31.783802
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random.

    This module tests coverage of the method custom_code of Random class
    from the module ``random``.
    """
    expected = 'TEST001'
    result = Random().custom_code('T@@###', '@', '#')

    assert result == expected

# Generated at 2022-06-12 02:53:40.069139
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    rn = r.custom_code("@@@@####", char="@", digit="#")
    assert rn.count("@") == 4
    assert rn.count("#") == 4
    assert rn.islower() is True
    assert rn.isupper() is False
    assert rn[0:4].isalpha() is True
    assert rn[4:].isdigit() is True
    assert len(rn) == 8
    rn = r.custom_code(mask="####@###", digit="#", char="@")
    assert len(rn) == 8
    assert rn.count("@") == 1
    assert rn.count("#") == 7
    assert rn.islower() is False
    assert rn.isupper() is False

# Generated at 2022-06-12 02:53:44.722749
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code("@###", "@", "#") == "ABC12"
    assert random.custom_code("A@#A@#@#", "A", "#") == "A1B2C3"
    assert random.custom_code("LOL###", "@", "#") == "LOL123"