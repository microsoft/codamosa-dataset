

# Generated at 2022-06-12 02:53:57.442937
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _ = random.custom_code()

# Generated at 2022-06-12 02:54:02.623457
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random.

    :return: None.
    """
    random.seed(5)
    results = [
        'G862', 'L879', 'H875', 'B389', 'B816',
        'K715', 'H922', 'A462', 'C752', 'A559'
    ]
    for i in range(10):
        code = random.custom_code()
        assert code == results[i]

# Generated at 2022-06-12 02:54:07.295866
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    random.seed(1)
    assert random.custom_code() == '71UJ'
    assert random.custom_code(mask='@AT@###') == 'YATK861'
    assert random.custom_code(mask='@@#@@##') == 'PD5IW36'


if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-12 02:54:08.856334
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    import doctest
    doctest.run_docstring_examples(Random.custom_code, Random)

# Generated at 2022-06-12 02:54:17.680717
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print('Testing method custom_code of class Random')

    rnd = Random()
    mask = '####'
    char = '@'
    digit = '#'

    try:
        rnd.custom_code(char, char, digit)
    except ValueError:
        print('The placeholder for characters and digits cannot be the same')

    assert mask in rnd.custom_code(mask, char, digit)
    assert char not in rnd.custom_code(mask, char, digit)
    assert digit not in rnd.custom_code(mask, char, digit)


if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-12 02:54:26.634829
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    assert Random.custom_code(Random(), '@###', '@', '#')
    assert Random.custom_code(Random(), '@###', '@', '#') != Random.custom_code(Random(), '@###', '@', '#')
    assert Random.custom_code(Random(), '@###', '@', '#') != Random.custom_code(Random(), '@###', '@', '#')
    assert Random.custom_code(Random(), '@###', '@', '#') != Random.custom_code(Random(), '@###', '@', '#')
    assert len(Random.custom_code(Random(), '@###', '@', '#')) == 4

# Generated at 2022-06-12 02:54:37.115181
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random"""
    import unittest

    class RandomTestCase(unittest.TestCase):
        """Unit test for method custom_code of class Random"""
        def test_custom_code(self):
            """Method that tests custom_code
            method of class Random"""
            with self.assertRaises(ValueError) as context:
                Random().custom_code(char='a', digit='a')

            self.assertEqual("You cannot use the same "
                             "placeholder for digits and chars!",
                             str(context.exception))
            self.assertEqual(len(Random().custom_code()), 4)
            # noinspection PyTypeChecker
            self.assertEqual(len(Random().custom_code()), 4)

# Generated at 2022-06-12 02:54:39.445116
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print('#' * 40 + 'Unit test for method custom_code of class Random' + '#' * 40)
    print()
    print(random.custom_code())
    print()
    print(random.custom_code(mask='@@@@', char='@', digit='@'))
    print()


# Generated at 2022-06-12 02:54:45.965153
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    result = set()
    for i in range(100):
        result.add(r.custom_code(mask='@###'))
    for i in range(100):
        assert r.custom_code(mask='@###') in result

# Generated at 2022-06-12 02:54:48.383940
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() != ""