

# Generated at 2022-06-12 02:51:47.705434
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = '###'
    assert len(random.custom_code(mask)) == len(mask)
    assert len(random.custom_code(mask)) == len(mask)
    # same sequence
    assert random.custom_code(mask) != random.custom_code(mask)
    # same sequence with mask ###
    assert random.custom_code('###') != random.custom_code('###')
    # same sequence with mask @#@
    assert random.custom_code('@#@') != random.custom_code('@#@')
    # same sequence with mask @#####
    assert random.custom_code('@#####') != random.custom_code('@#####')
    # same sequence with mask @###
    assert random.custom_code('@###') != random.custom_code('@###')

# Generated at 2022-06-12 02:51:49.625671
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""

    assert Random().custom_code('@@@###') == 'ABC123'

# Generated at 2022-06-12 02:51:55.457978
# Unit test for function get_random_item
def test_get_random_item():
    class Numbers(object):
        one = 1
        two = 2
        three = 3

    assert get_random_item(Numbers) in [1, 2, 3]
    assert get_random_item(Numbers, rnd=random) in [1, 2, 3]

# Generated at 2022-06-12 02:51:59.555138
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    a = rnd.custom_code()
    b = rnd.custom_code()
    assert a != b

# Generated at 2022-06-12 02:52:06.516238
# Unit test for function get_random_item
def test_get_random_item():
    from mimesis.enums import Gender
    x = get_random_item(Gender)
    assert x in Gender, 'Wrong type of `x`'

# Generated at 2022-06-12 02:52:11.500620
# Unit test for function get_random_item
def test_get_random_item():
    from random import Random
    from mimesis.enums import Case, Gender
    print(Gender.FEMALE)
    print(Random().choice(list(Gender)))
    print(Case.SNAKE)
    print(Random().choice(list(Case)))

# Generated at 2022-06-12 02:52:14.345929
# Unit test for function get_random_item
def test_get_random_item():
    """Unit test for function ``get_random_item()``."""
    from mimesis.enums import Gender
    assert isinstance(get_random_item(Gender), Gender)

# Generated at 2022-06-12 02:52:21.339291
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for the custom_code method of the Random class.

    """
    # Assert that the method replace the char placeholder in the mask
    # and add the string 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.
    assert random.custom_code(mask='@AAA', char='@') in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    # Assert that the method replace the digit placeholder in the mask
    # and add the string '0123456789'.
    assert random.custom_code(mask='@###', char='@') in '0123456789'
    # Assert that the method returns string.
    assert isinstance(random.custom_code(mask='@###', char='@'), str)
    # Assert that the method replaces the mask.

# Generated at 2022-06-12 02:52:26.326959
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    result = Random().custom_code(mask='@###', char='@', digit='#')
    assert len(result) == 4
    assert result[0].isalpha()
    assert result[1].isdigit()
    assert result[2].isdigit()
    assert result[3].isdigit()

if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-12 02:52:33.687169
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert isinstance(r.custom_code(), str)

    # Check if code with length 1 can be created
    assert isinstance(r.custom_code(mask='@'), str)
    assert len(r.custom_code(mask='@')) == 1

    # Check that code with length of 0 can't be created
    assert r.custom_code(mask='') == ''

    # Check that code with length of 1 can't be created
    # and error ValueError will be rised
    try:
        r.custom_code(mask='', char='@', digit='#')
    except (ValueError):
        pass

# Generated at 2022-06-12 02:52:48.265496
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = random
    r.seed('123456')
    assert r.custom_code('AAA') == 'AAA'
    assert r.custom_code('@@@') == 'AAG'
    assert r.custom_code('###') == '821'
    assert r.custom_code('@###') == 'M821'
    assert r.custom_code('####') == '8211'
    assert r.custom_code('@@##') == 'AA73'
    assert r.custom_code('@##') == 'M73'
    assert r.custom_code('##@') == '73G'
    assert r.custom_code('@@#') == 'AA2'
    assert r.custom_code('@##@') == 'M73G'
    assert r.custom_code('@') == 'M'
   

# Generated at 2022-06-12 02:52:53.986632
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    assert rnd.custom_code('@###') == 'U619'
    assert rnd.custom_code('###') == '965'
    assert rnd.custom_code('#') == '0'
    assert rnd.custom_code('#,#') == '3,7'


# Generated at 2022-06-12 02:53:02.260780
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert len(Random().custom_code(mask='@###')) == 4
    assert type(Random().custom_code(mask='@###')) == str
    assert type(Random().custom_code(mask='@###')) == str
    assert len(Random().custom_code(mask='@@@@')) == 4
    assert len(Random().custom_code(mask='@@@@@@')) == 6
    assert len(Random().custom_code(mask='@@@@@####')) == 9
    assert len(Random().custom_code(mask='@@@@@@####@')) == 11
    assert len(Random().custom_code(mask='@@@@@####')) == 9

# Generated at 2022-06-12 02:53:04.430385
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code(mask='@### @##')
    assert isinstance(code, str)
    assert len(code) == 8

# Generated at 2022-06-12 02:53:12.398669
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() == 'AAA111'

# Generated at 2022-06-12 02:53:19.547192
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _mask = '@@##@'
    assert len(Random().custom_code(_mask)) == len(_mask)
    assert len(Random().custom_code('@####', '$')) == len('@####')
    assert len(Random().custom_code('@####', '#')) == len('@####')
    assert len(Random().custom_code('@####', '$', '#')) == len('@####')



# Generated at 2022-06-12 02:53:28.765273
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    seq = string.ascii_letters
    assert len(r.custom_code('@###', '@', '#')) == 4
    assert len(r.custom_code('@@@###', '@', '#')) == 7
    assert len(r.custom_code('@#@#@#@#', '@', '#')) == 8
    assert r.custom_code('@###', '@', '#')[0] in seq  # First letter
    assert r.custom_code('@@@###', '@', '#')[2] in seq  # Third letter
    assert r.custom_code('@#@#@#@#', '@', '#')[4] in seq  # Fifth letter
    assert r.custom_code('@###', '@', '#')[1] in seq  # Second digit

# Generated at 2022-06-12 02:53:38.104594
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _mask = '@##'
    _char = '@'
    _digit = '#'

    _randstr = random.custom_code(_mask, _char, _digit)

    # Assert that _randstr is a string
    assert isinstance(_randstr, str)

    # Assert that _randstr does not have equal number of _char and _digit symbols
    # For example, for mask @## and char @, digit # it can be A18, but not AB#
    assert not (_randstr.count(_char) == _randstr.count(_digit))

    # Assert that _randstr length is the same as length of mask
    assert len(_randstr) == len(_mask)

# Generated at 2022-06-12 02:53:41.452968
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    result = rnd.custom_code()
    assert isinstance(result, str)
    assert len(result) == 4

# Generated at 2022-06-12 02:53:48.368358
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method ``custom_code()`` of class ``Random()``."""
    _Random = Random()
    _code = _Random.custom_code('@@###', '@', '#')
    assert len(_code) == 6
    assert _code[-1].isdigit()
    assert _code[-2].isdigit()
    assert _code[-3].isdigit()
    assert _code[-4].islower()
    assert _code[-5].islower()
    assert _code[0] == '@'
    assert _code[1] == '@'