

# Generated at 2022-06-12 02:51:48.161511
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Positive tests
    _rnd = Random()
    _code = _rnd.custom_code(mask='@###', char='@', digit='#')
    assert len(_code) == 4
    assert _code[0].isupper()
    assert _code[1].isdigit()
    assert _code[2].isdigit()
    assert _code[3].isdigit()

    _code = _rnd.custom_code(mask='A@@', char='A', digit='@')
    assert len(_code) == 3
    assert _code[0].isupper()
    assert _code[1].isdigit()
    assert _code[2].isdigit()

    _code = _rnd.custom_code(mask='@@@@@@@', char='@', digit='#')

# Generated at 2022-06-12 02:51:54.445770
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code()
    assert random.custom_code(mask='@@@@', char='@')
    assert random.custom_code(mask='####', digit='#')
    assert random.custom_code(mask='@###', char='@', digit='#')

# Generated at 2022-06-12 02:52:00.179990
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random.seed(123456)
    assert random.custom_code() == 'QJWY'
    assert random.custom_code(mask="@###@###", char='@', digit='#') == 'EDCELUWY'



# Generated at 2022-06-12 02:52:06.752762
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(1000):
        code = Random().custom_code()
        assert len(code) == 4 and code[0].isupper()
        assert code[1].isupper() or code[1].isdigit()
        assert code[2].isdigit() or code[2].isupper()
        assert code[3].isdigit()

# Generated at 2022-06-12 02:52:14.104966
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print(Random().custom_code('@##'))
    print(Random().custom_code('@#'))
    print(Random().custom_code('@##', '@', '$'))
    print(Random().custom_code('@##', '$', '$'))
    print(Random().custom_code('@.##', '@', '$'))

test_Random_custom_code()

# Generated at 2022-06-12 02:52:19.711371
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    print(rnd.custom_code(mask='A#'))
    print(rnd.custom_code(mask='A#', char='A', digit='#'))
    print(rnd.custom_code(mask='A#', char='A', digit='#'))
    print(rnd.custom_code(mask='A#', char='A', digit='#'))
    print(rnd.custom_code(mask='A#', char='A', digit='#'))



# Generated at 2022-06-12 02:52:27.424655
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Given
    rnd = Random()

    # When
    result = rnd.custom_code(
        mask='@###-###-###',
        char='@',
        digit='#',
    )
    result_when_bad_digits = rnd.custom_code(
        mask='###-###',
        char='#',
        digit='#',
    )

    # Then
    assert isinstance(result, str)
    assert len(result) == 12
    assert result[1:].isdigit() is True
    assert result[0].isalpha() is True

    assert result_when_bad_digits is None

# Generated at 2022-06-12 02:52:33.038159
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    import unittest
    from mimesis.enums import Mask
    from mimesis.exceptions import MaskError

    _mask = Mask.CODE.value
    assert random.custom_code(_mask) == 'ABC1'

    try:
        random.custom_code('@@@##$@')
        assert False
    except MaskError:
        assert True

    try:
        random.custom_code(Mask.CODE.value, char='#')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-12 02:52:39.879681
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    obj = Random()
    assert isinstance(obj.custom_code(), str)
    assert isinstance(obj.custom_code('###'), str)
    assert isinstance(obj.custom_code('@#@#'), str)
    assert isinstance(obj.custom_code('@###', '*', '*'), str)
    assert isinstance(obj.custom_code('@@@@'), str)
    assert isinstance(obj.custom_code('@###', '$', '!'), str)
    assert isinstance(obj.custom_code('@###@@@', '*', '!'), str)

# Generated at 2022-06-12 02:52:41.851908
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    expected_string = 'QS7C5'
    generated_string = random.custom_code()
    assert expected_string == generated_string

