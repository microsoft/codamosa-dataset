

# Generated at 2022-06-12 02:52:38.216023
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for the method ``custom_code`` of class ``Random``"""
    rnd = Random()
    val = rnd.custom_code()

    assert isinstance(val, str)
    assert len(val) == 4



# Generated at 2022-06-12 02:52:47.761220
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from mimesis.builtins import en
    random_seed = 37
    random_module.seed(random_seed)
    locale = 'en'
    seed = 37
    mask = '@@@###'
    char = '@'
    digit = '#'
    pin = "WZ039"
    rnd = Random(seed, locale)
    random_custom_code = rnd.custom_code(mask=mask,
                                         char=char,
                                         digit=digit)
    assert random_custom_code == pin
    rnd = en.Person(seed=seed)
    random_custom_code_builtin = rnd.custom_code(mask=mask,
                                                 char=char,
                                                 digit=digit)
    assert random_custom_code == random_custom_code_builtin

# Generated at 2022-06-12 02:52:56.987134
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    checker = 0
    array = ['@###', 'A###', 'A12#', 'A123', 'A@#2', 'A#@2', 'A#2@',
             'A@2#', '@####', 'A####', 'A12##', 'A1234', 'A@#32', 'A#@32',
             'A#3@2', 'C@#32', 'D@3#2', 'E@32#']
    for x in array:
        result = Random().custom_code(x)
        if result not in array:
            print(result)
            checker = 1
    assert checker == 0

# Generated at 2022-06-12 02:53:00.545662
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = '@AAA'
    code = random.custom_code(mask, '@', '#')
    assert code[0] in string.ascii_uppercase
    assert code[1] in string.ascii_uppercase
    assert code[2] in string.ascii_uppercase

# Generated at 2022-06-12 02:53:09.546256
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    generate = random.custom_code('@###', '@', '#')
    assert isinstance(generate, str)
    assert len(generate) == 4
    assert isinstance(generate[0], str)
    assert isinstance(generate[1], str)
    assert isinstance(generate[2], str)
    assert isinstance(generate[3], str)
    assert generate[0] in string.ascii_uppercase
    assert isinstance(generate[1], str)
    assert isinstance(generate[2], str)
    assert isinstance(generate[3], str)
    assert generate[3] in string.digits


# Generated at 2022-06-12 02:53:11.267654
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    res = random.custom_code(char='#', digit='&')
    assert len(res) == 4

# Generated at 2022-06-12 02:53:16.800633
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    codes = ['@###.###', '####', '####-#@##-####', '###-##-###', '#######']
    results = []

# Generated at 2022-06-12 02:53:20.822172
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _random = Random()
    code = _random.custom_code(mask='####')
    assert any([c in code.upper() for c in 'QWERTYUIOPASDFGHJKLZXCVBNM'])
    assert any([c in code for c in '1234567890'])
    assert len(code) == 4

# Generated at 2022-06-12 02:53:22.563211
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(100):
        code = random.custom_code()
        assert isinstance(code, str)
        assert len(code) == 4

# Generated at 2022-06-12 02:53:32.658340
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code(mask='AA@@##', char='@', digit='#') in [
        (random.generate_string(str_seq=string.ascii_uppercase, length=2)
         + random.generate_string(str_seq=string.digits, length=4)),
        (random.generate_string(str_seq=string.ascii_uppercase, length=1)
         + random.generate_string(str_seq=string.digits, length=5)),
        (random.generate_string(str_seq=string.ascii_uppercase, length=3)
         + random.generate_string(str_seq=string.digits, length=3))
    ]

# Generated at 2022-06-12 03:00:41.512002
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Test for unicode encodings
    for n in range(10):
        assert Random().custom_code(mask='@###', char='@', digit='#')

    # Test for similar chars in the string
    for n in range(10):
        assert Random().custom_code(mask='@###', char='@', digit='&')

    # Test for the same chars in the string
    for n in range(10):
        assert Random().custom_code(mask='@###', char='%', digit='%')

# Generated at 2022-06-12 03:00:50.604467
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    r = Random()

    code =r.custom_code(mask='@@####', char='@')
    assert ''.join([code[0], code[1]]).isalpha()
    assert ''.join([code[2], code[3], code[4], code[5]]).isdigit()

    code = r.custom_code()
    assert len(code) == 4
    assert ''.join(code).isdigit()

    code = r.custom_code(mask='00@', char='@', digit='0')
    assert code[0] == '0'
    assert code[1] == '0'
    assert code[2].isalpha()


# Generated at 2022-06-12 03:00:59.983390
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    mask = "@#%@#@#"
    char = '@'
    digit = '#'

    r = Random()
    rnd = r.random
    r.random = lambda : 0.25
    result = r.custom_code(mask, char, digit)
    assert result == "C337C7C"

    r.random = lambda : 0.5
    result = r.custom_code(mask, char, digit)
    assert result == "F779F7F"

    r.random = lambda : 0.75
    result = r.custom_code(mask, char, digit)
    assert result == "K99K9K9"

    r.random = rnd


test_Random_custom_code()

# Generated at 2022-06-12 03:01:04.940370
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@###') == 'N030'
    assert Random().custom_code('%###') == 'T030'
    assert Random().custom_code('+###') == 'E030'
    assert Random().custom_code('+##') == 'F8C'
    assert Random().custom_code('+##') != 'H8C'
    assert Random().custom_code('') == ''
    assert Random().custom_code('(###') == 'D031'
    assert Random().custom_code('@@##') == 'ER72'
    assert Random().custom_code('@@##') != 'ER71'

# Generated at 2022-06-12 03:01:12.624362
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random.

    Result: OK.

    """
    for _ in range(1000):
        assert len(random.custom_code()) == 4
        assert len(random.custom_code('@@@@')) == 4
        assert len(random.custom_code('###')) == 3
        assert len(random.custom_code('####')) == 4
        assert len(random.custom_code('#######')) == 7
        assert len(random.custom_code('@###@###')) == 8
        assert len(random.custom_code('@##@##@##')) == 9
        assert len(random.custom_code('@##@##@##@##')) == 12
        assert len(random.custom_code('@##@##@##@##@##')) == 16
       

# Generated at 2022-06-12 03:01:16.807796
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###') == 'M123'
    assert random.custom_code('X@##', char='@', digit='#') == 'XF23'
    assert random.custom_code('X@YY', digit='#', char='@') == 'XDWW'
    assert random.custom_code('X!YY', digit='!', char='@') == 'XDWW'


# Generated at 2022-06-12 03:01:19.234688
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_instance = random
    result = random_instance.custom_code()
    assert isinstance(result, str), 'Type check failed.'
    assert len(result) == 4, 'Length of result string was not correct.'

# Generated at 2022-06-12 03:01:23.536370
# Unit test for method custom_code of class Random
def test_Random_custom_code():
  # Subclass of random.Random
  random = Random()

  # generates random code with length 5
  # each character can be a letter or a digit
  code = random.custom_code('@###@')
  assert len(code) == 5

if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-12 03:01:28.942780
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Command-line interface."""
    r = Random()
    custom_code = r.custom_code()
    assert len(custom_code) == 4
    custom_code = r.custom_code(mask='@@@@@@@')
    assert len(custom_code) == 7
    custom_code = r.custom_code(mask='@@@@@@@', char='_')
    assert len(custom_code) == 7
    custom_code = r.custom_code(mask='@@@@@@@', digit='_')
    assert len(custom_code) == 7
    custom_code = r.custom_code(mask='@@@@@@@', char='_', digit='@')
    assert len(custom_code) == 7

# Generated at 2022-06-12 03:01:32.671219
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    result = random.custom_code('@###', '@', '#')
    assert result.isupper()
    assert len(result) == 4
    assert ('A' <= result[0] <= 'Z')
    assert ('0' <= result[1] <= '9')
    assert ('0' <= result[2] <= '9')
    assert ('0' <= result[3] <= '9')

