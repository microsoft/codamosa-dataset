

# Generated at 2022-06-12 02:51:48.819712
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    results = []
    count = 20
    while len(results) < count:
        result = random.custom_code(mask='@###')
        if result not in results:
            results.append(result)
    assert count == len(results)

# Generated at 2022-06-12 02:51:59.297976
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    from mimesis.compat.builtins import str

    rnd = Random()
    mask = '####'
    code = rnd.custom_code(mask=mask)
    assert isinstance(code, str)
    assert len(code) == len(mask)

    mask = '@###'
    code = rnd.custom_code(mask=mask)
    assert isinstance(code, str)
    assert len(code) == len(mask)
    assert code[0].isalpha()

    mask = '###@'
    code = rnd.custom_code(mask=mask)
    assert isinstance(code, str)
    assert len(code) == len(mask)
    assert code[-1].isalpha()

    mask = '###@@'


# Generated at 2022-06-12 02:52:05.084682
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    print (Random().custom_code('@###'))
    assert True


# Generated at 2022-06-12 02:52:15.324658
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_code_1 = Random().custom_code(mask='@#@#@#@#@#')
    assert len(random_code_1) == 10
    assert str.isalnum(random_code_1)
    assert str.isupper(random_code_1)

    random_code_2 = Random().custom_code(mask='@#@#@#@#@#', char='%')
    assert len(random_code_2) == 10
    assert str.isupper(random_code_2)
    assert (random_code_2[0:2], random_code_2[2:10]).count('%') is 2

# Generated at 2022-06-12 02:52:19.449179
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for the method custom_code of class Random."""
    random_string = random.custom_code('??@##')
    assert isinstance(random_string, str)
    assert len(random_string) == 5
    assert all(char in string.digits + string.ascii_uppercase
               for char in random_string)



# Generated at 2022-06-12 02:52:22.828160
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _result = Random().custom_code('@###', '@', '#')
    assert isinstance(_result, str)
    assert len(_result) == 4

# Generated at 2022-06-12 02:52:26.609018
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code(mask="@###@###") == "Q123Q123"
    assert Random().custom_code(mask="@###@###", digit='x') == "Q123Q123"
    assert Random().custom_code(mask="@###@###", char='x') == "x123x123"



# Generated at 2022-06-12 02:52:27.559441
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@@##') == 'BH05'

# Generated at 2022-06-12 02:52:29.620990
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = Random()
    code = rnd.custom_code()
    assert code != ''
    assert code.isalpha() or code.isdigit()



# Generated at 2022-06-12 02:52:40.496606
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random.

    This method is called by test_random_module.py.
    """
    rand = random_module.Random()
    # Test max value of case 1
    assert rand.custom_code('@###') in ('A123',
                                        'A234',
                                        'A345',
                                        'A456',
                                        'A567')
    # Test max value of case 2
    assert rand.custom_code('123@') in ('1A23',
                                        '1A34',
                                        '1A45',
                                        '1A56',
                                        '1A67')
    # Test max value of case 3