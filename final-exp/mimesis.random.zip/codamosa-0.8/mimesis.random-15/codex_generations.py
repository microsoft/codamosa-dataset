

# Generated at 2022-06-12 02:52:28.398625
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@###') in \
           ['A111', 'B111', 'C111', 'D111', 'E111', 'F111', 'G111', 'H111',
            'I111', 'J111', 'K111', 'L111', 'M111', 'N111', 'O111', 'P111',
            'Q111', 'R111', 'S111', 'T111', 'U111', 'V111', 'W111', 'X111',
            'Y111', 'Z111']

# Generated at 2022-06-12 02:52:31.025789
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Random.custom_code() test."""

    # generate code
    _code = random.custom_code(mask='@###', char='@', digit='#')
    # assert length
    assert len(_code) == len('@###')

# Generated at 2022-06-12 02:52:40.805715
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Custom codes
    c_codes = [
        'INV-#',
        'INV-###',
        'INV-##',
        'INV-#-#',
        'INV-@###',
    ]
    for mask in c_codes:
        code = random.custom_code(mask, '@', '#')
        if not isinstance(code, str):
            raise ValueError('custom_code() does not return a string.')
        if len(code) != len(mask):
            raise ValueError('Custom code does not match the mask.')

    # All the same

# Generated at 2022-06-12 02:52:50.753945
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    r.seed(106)
    assert r.custom_code() == 'H503'
    assert r.custom_code('AA') == 'AO'
    assert r.custom_code('AA@') == 'AOR'
    assert r.custom_code('A##') == 'A39'
    assert r.custom_code('@##A') == 'R48S'
    assert r.custom_code('A)@', ')', '@') == 'A)W'
    assert r.custom_code() == 'C869'
    assert r.custom_code('@@') == 'TY'
    assert r.custom_code('@@@') == 'T91'
    assert r.custom_code('A##') == 'A93'

# Generated at 2022-06-12 02:52:53.487788
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    actual = random.custom_code(mask='@@#@@#@@#')
    expected = '4H6U4H6U4H6U'

    assert actual == expected

# Generated at 2022-06-12 02:52:55.447528
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() != Random().custom_code()

# Generated at 2022-06-12 02:53:04.600482
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # generate custom code using ascii uppercase and random integers
    def custom_code():
        rnd = Random()
        mask = '@###'
        char = '@'
        digit = '#'

        char_code = ord(char)
        digit_code = ord(digit)

        if char_code == digit_code:
            raise ValueError('You cannot use the same '
                             'placeholder for digits and chars!')

        def random_int(a, b):
            b = b - a
            return int(rnd.random() * b) + a

        mask = mask.encode()
        code = bytearray(len(mask))
        for i, p in enumerate(mask):
            if p == char_code:
                a = random_int(65, 91)  # A-Z

# Generated at 2022-06-12 02:53:13.891571
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    test_object = Random()
    test_masks = ['###', '@@#', '@##', '@@@', '@#@', '@##', '###', '#@#', '#@##@#######',
                  '#@##@########@##@#######', '#@##@##@#######################']
    test_chars = ['@', '#', 'a', '12548', '1', 'AB', 'q']
    test_digits = ['@', '#', 'a', '12548', '1', 'AB', 'q']
    for mask in test_masks:
        for char in test_chars:
            for digit in test_digits:
                try:
                    test_object.custom_code(mask, char, digit)
                except ValueError:
                    assert mask == char

# Generated at 2022-06-12 02:53:17.236377
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(100):
        code = random.custom_code()
        assert len(code) == 4
        assert set(code) <= set(string.ascii_letters + string.digits)

# Generated at 2022-06-12 02:53:19.354105
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code(mask='@@@', char='@', digit='#') == 'AAA'
