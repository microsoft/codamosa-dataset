

# Generated at 2022-06-12 02:52:28.564761
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code(mask='@###') in [
        'Z123', 'Z543', 'W111', 'Q432', 'R456', 'D789',
    ]
    assert Random().custom_code(mask='@@###') in [
        'PP123', 'SW456', 'QW789', 'DQ111', 'DD432', 'QQ543',
    ]
    assert Random().custom_code(mask='###@') in [
        '123C', '543K', '111V', '432M', '456A', '789D',
    ]
    assert Random().custom_code(mask='###@@') in [
        '123PP', '543SW', '111QW', '432DQ', '456DD', '789QQ',
    ]

# Generated at 2022-06-12 02:52:35.382875
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    rnd = random.Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code[0].isalpha()

    code = rnd.custom_code(mask='@@@###')
    assert len(code) == 6
    assert code[0].isalpha()
    assert code[3].isdigit()



# Generated at 2022-06-12 02:52:37.175379
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    one = random.custom_code()
    two = random.custom_code()

    assert one
    assert two
    assert one != two

# Generated at 2022-06-12 02:52:40.158281
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _rnd = random.Random()
    assert _rnd.custom_code() is not None
    assert len(_rnd.custom_code()) > 1


if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-12 02:52:47.685379
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    s = random.custom_code(mask='@@#@@##')
    assert len(s) == len('@@#@@##')
    assert s.isalpha() or s.isdigit()
    print(s)

    s = random.custom_code(mask='@@#@@##', digit='.')
    assert len(s) == len('@@#@@##')
    assert s.isalpha() or s.isdigit()
    assert s[4] != s[4].isdigit() or s[4] != '.'
    print(s)

if __name__ == '__main__':
    test_Random_custom_code()

# Generated at 2022-06-12 02:52:52.571389
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test for the method ``custom_code()`` of class ``Random()``."""
    code = random.custom_code(
        mask='@@@-###-###-##',
        char='@',
        digit='#'
    )

    assert isinstance(code, str)
    print("Generated code:", code)

# Generated at 2022-06-12 02:52:55.199080
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = '@@##'
    char = '@'
    digit = '#'
    code = random.custom_code(mask, char, digit)
    if code.isalnum() and len(code) == len(mask):
        chars = (char for char in code if char == '@')
        digits = (digit for digit in code if digit == '#')
        if all(char.isascii() for char in chars) and \
                all(digit.isdigit() for digit in digits):
            return True
    else:
        return False

# Generated at 2022-06-12 02:53:04.395726
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code(mask='@###', char='@', digit='#')
    assert r.custom_code(mask='@@###')
    assert r.custom_code(mask='@@###', char='@', digit='#')
    assert r.custom_code(mask='@@###', char='@', digit='#')
    assert r.custom_code(mask='@@###', char='@', digit='#')
    assert r.custom_code(mask='@@###', char='@', digit='#')
    assert r.custom_code(mask='@@###', char='@', digit='#')
    assert r.custom_code(mask='@@###', char='@', digit='#')
    assert r.custom_code(mask='@@###', char='@', digit='#')
    assert r

# Generated at 2022-06-12 02:53:13.779480
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = 'AABB'
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code() != rnd.custom_code()
    assert rnd.custom_code('@###') != rnd.custom_code('@###')
    assert rnd.custom_code('@###', 'X', '#') != rnd.custom_code('@###', 'X', '#')
    assert rnd.custom_code(code) == code
    assert rnd.custom_code(code, 'X', '#') != rnd.custom_code(code, 'X', '#')
    assert rnd.custom_code(code, 'X', '#') == \
           rnd.custom_code(code, 'X', '#')
# Unit test

# Generated at 2022-06-12 02:53:18.305988
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # Method custom_code raises error if the same character
    # passed as parameter char and digit
    rnd = Random()
    try:
        rnd.custom_code(mask='@@#', char='@', digit='@')
        assert False
    except:
        assert True