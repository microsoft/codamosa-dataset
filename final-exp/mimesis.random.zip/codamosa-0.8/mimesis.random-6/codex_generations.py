

# Generated at 2022-06-12 02:54:19.411757
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test that method custom_code return expected result."""
    chars = Random().generate_string(string.ascii_lowercase, 5)
    digits = Random().generate_string(string.digits, 3)
    assert chars.isalpha() and digits.isdigit()

    code = Random().custom_code()
    assert all(i in '1234567890' for i in code[-3:])
    assert all(i in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' for i in code[:-3])

    code = Random().custom_code('@##')
    assert all(i in '1234567890' for i in code[-2:])

# Generated at 2022-06-12 02:54:21.065592
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code(mask='@###') == 'ABCD'

# Generated at 2022-06-12 02:54:27.988683
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    assert r.custom_code().startswith('@')

    r = Random(42)
    assert r.custom_code() == 'T220'
    assert r.custom_code(mask='@###') == 'B2H1'
    assert r.custom_code(mask='@@@@@@##') == 'ILOJID02'

    r = Random(0)
    assert r.custom_code() == '@000'
    assert r.custom_code(mask='@ ###') == 'C 414'
    assert r.custom_code(mask='#######@') == '2446146J'



# Generated at 2022-06-12 02:54:37.641682
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    # 100 tests with different masks
    for i in range(1, 100):
        number = random.randrange(1, 100)
        # Create mask from string and integer
        mask = string.ascii_uppercase[:number] + str(number)
        # Generate code from mask
        code = random.custom_code(mask=mask)
        # Check that the code length is equal to the mask length
        assert len(code) == len(mask)
        # Check that the code has only letters and numbers
        assert code.isalnum()
        # Check that the code is unique
        if len(set(code)) == len(mask) and not i % 3:
            assert i
    # 100 tests with different masks
    # 100 tests with different masks

# Generated at 2022-06-12 02:54:45.976743
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###') in ['@000', '@123', '@456', '@789']
    assert random.custom_code('@###', '@', '#') in ['@000', '@123', '@456', '@789']
    assert random.custom_code('@###', '@', '#') in ['@000', '@123', '@456', '@789']
    assert random.custom_code('@###', '@', '#') in ['@000', '@123', '@456', '@789']
    assert random.custom_code('@###', '@', '#') in ['@000', '@123', '@456', '@789']

# Generated at 2022-06-12 02:54:51.274404
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _rnd = Random()
    _item = _rnd.custom_code(mask='@###', char='@', digit='#')
    assert isinstance(_item, str)
    assert len(_item) == 3
    assert _item == _item.upper()


# Generated at 2022-06-12 02:54:56.822476
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    custom_code = Random.custom_code
    pattern = '@###'
    expected_code = 'X323'

    assert custom_code(mask=pattern) == expected_code
    assert custom_code(mask=pattern) != expected_code
    assert custom_code(mask=pattern) != expected_code
    assert custom_code(mask=pattern) == expected_code
    assert custom_code(mask=pattern, digit='x') != expected_code
    assert custom_code(mask=pattern, char='x') != expected_code
    assert custom_code(mask=pattern, char=digit) == expected_code
    assert custom_code(mask=pattern, char=digit) != expected_code
    assert custom_code(mask=pattern, char=digit) != expected_code



# Generated at 2022-06-12 02:55:04.289397
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    assert code[0] in string.ascii_uppercase

    code = rnd.custom_code('@@@@@@###')
    assert len(code) == 8
    assert code[0] in string.ascii_uppercase

    code = rnd.custom_code('@@@@@@###', '@', '#')
    assert len(code) == 8
    assert code[0] in string.ascii_uppercase

    code = rnd.custom_code('@@@@#')
    assert len(code) == 5
    assert code[0] in string.ascii_uppercase

    code = rnd.custom_code('@###')
    assert len(code) == 4

# Generated at 2022-06-12 02:55:08.739598
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    m = '@###'
    s = Random().custom_code(mask=m)
    assert len(s) == len(m)
    assert s[0].isalpha()
    assert s[1:].isdigit()



# Generated at 2022-06-12 02:55:14.267656
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    test_stringcodes = [['##*#', '#'],
                        ['@@', '@'],
                        ['@@@###', '@'],
                        ['#@#*@', '#'],
                        ['QQ@@###', '@'],
                        ['ASD##*', '#']]
    # test_stringcode_true = ['H', 'R', 'M', 'C', 'D', 'E']
    test_stringcode_false = ['V', 'W', 'X', 'Y', 'Z']
    for mask in test_stringcodes:
        code = random.custom_code(mask[0], mask[1])
        result = True
        for letter in test_stringcode_false:
            if letter in code:
                result = False
                break
        assert result

# Generated at 2022-06-12 02:56:11.116001
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test special feature of method custom_code.

    The method generate custom code in which mask use placeholder
    for digits and chars.

    :return:
    """
    custom_code = Random().custom_code()
    assert len(custom_code) == 4

    custom_code = Random().custom_code('@###-@@@-###')
    assert len(custom_code) == 12

# Generated at 2022-06-12 02:56:16.678631
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for ``Random.custom_code()``.

    :return: None.
    """
    random.seed(42)
    mask = '@###'
    assert random.custom_code(mask) == 'L569'

# Generated at 2022-06-12 02:56:20.477465
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""
    code = random.custom_code(mask='@###', char='@', digit='#')
    assert isinstance(code, str)
    assert len(code) == 4
    for char in code:
        assert char.upper() in (string.ascii_uppercase + string.digits)



# Generated at 2022-06-12 02:56:26.901547
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code(mask='#@@') != random.custom_code(mask='#@@')
    assert random.custom_code(mask='#@@') != random.custom_code(mask='#@@', char='@')
    assert random.custom_code(mask='#@@') != random.custom_code(mask='#@@', digit='#')
    assert random.custom_code(mask='#@@') != random.custom_code(mask='#@@', char='#', digit='#')

# Generated at 2022-06-12 02:56:30.100774
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    s = Random().custom_code(mask='@##', char='@', digit='#')
    #print(s)
    assert isinstance(s, str) and len(s) == 4
    assert s[0].isalpha()
    assert s[1].isdigit()
    assert s[2].isdigit()

# Generated at 2022-06-12 02:56:35.438637
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code('@###') in ['Z234', 'A536', 'B134', 'C521', 'D567']

# Generated at 2022-06-12 02:56:40.305871
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test method ``custom_code`` of class ``Random()``."""
    mask = '@###'
    mask2 = '###@'

    _random = Random()
    custom_code = _random.custom_code(mask=mask)
    assert isinstance(custom_code, str)
    assert len(custom_code) == 4

    custom_code2 = _random.custom_code(mask=mask2)
    assert isinstance(custom_code2, str)
    assert len(custom_code2) == 4

    # pylint: disable=unused-variable
    with pytest.raises(ValueError):
        char = '#'
        digit = '#'
        invalid_code = _random.custom_code(mask, char, digit)  # noqa

# Generated at 2022-06-12 02:56:46.869535
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random.custom_code('@', '#', '@')

    # Amount of characters in the range (1-5)
    amount_of_characters = random.randint(1, 5)

    # Generate mask
    mask = ''.join(['@' for _ in range(amount_of_characters)])

    # Run method and check
    assert len(random.custom_code(mask=mask)) == amount_of_characters

    # Test for the same placeholders.
    with pytest.raises(ValueError):
        random.custom_code('@', '@', '@')

# Generated at 2022-06-12 02:56:49.265657
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    code = rnd.custom_code()
    assert len(code) == 4
    code = rnd.custom_code(mask='###-9@@')
    assert len(code) == 7



# Generated at 2022-06-12 02:56:54.285418
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    code = r.custom_code()
    assert isinstance(code, str)
    assert '@' not in code
    assert '#' not in code
    assert len(code) == 4