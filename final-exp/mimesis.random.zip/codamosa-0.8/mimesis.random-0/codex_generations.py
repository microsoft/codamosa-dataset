

# Generated at 2022-06-12 02:51:48.108390
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    for _ in range(10):
        code = r.custom_code(mask='@###')
        assert len(code) == 4
        assert 65 <= ord(code[0]) <= 90


if __name__ == '__main__':
    test_Random_custom_code()
    print(Random().custom_code(mask='@###'))

# Generated at 2022-06-12 02:51:58.059378
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    code_1 = random.custom_code()
    print('The code is {0}'.format(code_1))
    code_2 = random.custom_code(mask='@@####@@')
    print('The code is {0}'.format(code_2))
    code_3 = random.custom_code(mask='@@@#####')
    print('The code is {0}'.format(code_3))
    code_4 = random.custom_code(mask='######')
    print('The code is {0}'.format(code_4))


# Generated at 2022-06-12 02:52:00.657696
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    r.seed(3817)
    s = r.custom_code(mask='@###')
    assert s == 'Z388'


# Generated at 2022-06-12 02:52:10.489745
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    pass_code = rnd.custom_code()
    assert isinstance(pass_code, str)
    assert len(pass_code) == 4
    assert pass_code.isupper()
    assert not pass_code.isdigit()
    assert pass_code.isalpha()

    pass_code = rnd.custom_code('@@@')
    assert isinstance(pass_code, str)
    assert len(pass_code) == 3
    assert pass_code.isupper()
    assert not pass_code.isdigit()
    assert pass_code.isalpha()

    pass_code = rnd.custom_code('@@#')
    assert isinstance(pass_code, str)
    assert len(pass_code) == 3
    assert pass_code.isupper()
    assert pass_

# Generated at 2022-06-12 02:52:16.355920
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_module = Random()
    code = random_module.custom_code('@###')
    assert code.isupper()
    assert code.isdigit()
    assert len(code) == 4
    assert code[0].isalpha()
    assert code[1:].isdigit()
    assert code[::-1].isdigit()



# Generated at 2022-06-12 02:52:28.241916
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random(1)
    code = rnd.custom_code("@###")
    assert code == 'R539'
    rnd = Random(2)
    code = rnd.custom_code("@###")
    assert code == 'H169'
    rnd = Random(3)
    code = rnd.custom_code("@###")
    assert code == 'U632'

    # test exception when char_code and digit_code are equal
    try:
        rnd = Random(4)
        rnd.custom_code("@###", '@', '@')
    except ValueError as e:
        assert 'You cannot use the same placeholder for digits and chars!' in str(e)

    # test for generate only unique codes
    rnd = Random(5)
    codes = set()

# Generated at 2022-06-12 02:52:38.465932
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random(7)
    rnd.seed(7)

    assert rnd.custom_code('@###') == 'K28K'
    assert rnd.custom_code('@###', char='@') == 'A2KL'
    assert rnd.custom_code('@@@###') == 'DMO831'
    assert rnd.custom_code('@@@###', char='@') == 'TJU908'
    assert rnd.custom_code('@@@###', digit='#') == 'QTQ971'
    assert rnd.custom_code('@@@@@@@###') == 'QZKQSEJ70'
    assert rnd.custom_code('@@@@@@@###', char='@') == 'CAZSHYA73'

# Generated at 2022-06-12 02:52:41.264990
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(1000):
        s = random.custom_code()
        assert isinstance(s, str)
        assert len(s) == 4
        assert s.isupper()
        assert '@' not in s

# Generated at 2022-06-12 02:52:46.921137
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code('@###', char='@', digit='#')
    assert Random().custom_code('@###', char='@', digit='#') != \
        Random().custom_code('@###', char='@', digit='#')

# Generated at 2022-06-12 02:52:55.810002
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random"""
    _RND = Random()
    _MASK = '@##AA'
    _CODE = _RND.custom_code(_MASK)
    assert isinstance(_CODE, str), '_CODE is not str'
    assert len(_CODE) == len(_MASK), 'Length of _CODE is not equals length of _MASK'
    assert all(ord(c) < ord('0') or ord(c) > ord('9') for c in _CODE), \
        '_CODE contains digits'
