

# Generated at 2022-06-12 02:51:55.242539
# Unit test for method custom_code of class Random

# Generated at 2022-06-12 02:52:04.485055
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    import unittest
    import re
    from mimesis.builtins.test import TestCase

    class RandomTestCase(TestCase):
        def test_custom_code(self):
            mask = '@###'
            char = '@'
            digit = '#'

            code = self.rand.custom_code(mask=mask, char=char, digit=digit)
            self.assertGreater(len(code), 0)

            reg = re.compile(r'[A-Z][0-9]{3}')
            self.assertIsNotNone(reg.match(code))

    suite = unittest.TestLoader().loadTestsFromTestCase(RandomTestCase)
    unittest.TextTestRunner(verbosity=0).run(suite)


# Generated at 2022-06-12 02:52:14.144492
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _mask = '@###'
    _char = '@'
    _digit = '#'

    random_custom_code = Random().custom_code(_mask)
    assert isinstance(random_custom_code, str)

    random_custom_code = Random().custom_code(_mask, _char, _digit)
    assert isinstance(random_custom_code, str)

    try:
        Random().custom_code(_mask, _char, _char)
    except ValueError:
        return True
    else:
        return False

# Generated at 2022-06-12 02:52:16.368669
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for _ in range(100):
        assert len(Random().custom_code()) == 4

# Generated at 2022-06-12 02:52:28.240766
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    mask = "ABCD-###"
    str_seq = "@#$%"
    char_code = chr(ord(str_seq[0]))
    digit_code = chr(ord(str_seq[1]))

    for i in range(200):
        code = random.custom_code(mask=mask.replace(
            char_code, '@').replace(digit_code, '#'), char='@', digit='#')
        assert code.find('@') > -1
        assert code.find('#') > -1
        assert len(code.replace(char_code, '').replace(
            digit_code, '')) == len(mask) - len(mask.replace('@', ''))


# Generated at 2022-06-12 02:52:38.516383
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()

    r1 = r.custom_code(mask='@###', char='@', digit='#')
    assert len(r1) == 4
    assert r1[0].isalpha()
    assert r1[1:].isdigit()

    r2 = r.custom_code(mask='@@@@@@@###', char='@', digit='#')
    assert len(r2) == 10
    assert r2[:7].isalpha()
    assert r2[7:].isdigit()

    r3 = r.custom_code(mask='@@@@@@###', char='@', digit='#')
    assert len(r3) == 9
    assert r3[:6].isalpha()
    assert r3[6:].isdigit()


# Generated at 2022-06-12 02:52:41.020042
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random.

    :return: None.
    """
    assert isinstance(Random().custom_code(), str)



# Generated at 2022-06-12 02:52:43.074406
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    _ = Random().custom_code(mask='@###')
    _ = Random().custom_code(mask='#@##')



# Generated at 2022-06-12 02:52:53.358820
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()

    assert rnd.custom_code('######') == '924533'
    assert rnd.custom_code('######', '#', '@') == '924533'
    assert rnd.custom_code('##@@@') == '88RMB'
    assert rnd.custom_code('##@@@', '#', '@') == '88RMB'
    assert rnd.custom_code('@##@@') == 'K690KO'
    assert rnd.custom_code('@##@@', '#', '@') == 'K690KO'

    assert rnd.custom_code('##@@@') != rnd.custom_code('##@@@')

# Generated at 2022-06-12 02:52:56.400190
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    result = random.custom_code(mask=('+@-#', '+@-#'), char='@', digit='#')
    assert len(result) == 5

