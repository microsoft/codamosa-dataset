

# Generated at 2022-06-12 02:53:06.760417
# Unit test for method custom_code of class Random
def test_Random_custom_code():

    # Arrange
    rnd = Random()

    # Act
    result = rnd.custom_code(mask='@###', char='@', digit='#')

    # Assert
    assert isinstance(result, str)
    assert len(result) == 4

# Generated at 2022-06-12 02:53:09.863308
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    code = r.custom_code('ABC###')
    assert code == 'A' or code == 'B' or code == 'C'



# Generated at 2022-06-12 02:53:11.991592
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for i in range(100):
        assert len(Random.custom_code()) == 4\
            and len(Random.custom_code('@##')) == 3

# Generated at 2022-06-12 02:53:22.209794
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Test the method custom_code of class Random."""
    res = random.custom_code()
    assert isinstance(res, str)
    assert len(res) == 4
    assert '@' in res

    res = random.custom_code(mask='@###-@@@#-##@#')
    assert isinstance(res, str)
    assert len(res) == 15
    assert '@' in res
    assert '#' in res
    assert '-' in res

    res = random.custom_code(mask='A@#B@#C@#D@#E@#')
    assert isinstance(res, str)
    assert len(res) == 11
    assert 'A' in res
    assert 'B' in res
    assert 'C' in res
    assert 'D' in res
    assert 'E' in res

# Generated at 2022-06-12 02:53:25.232825
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() in ['@HPI', '@PTE', '@QXZ', '@ZQM', '@YNF', '@SEE']

# Generated at 2022-06-12 02:53:27.322213
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from mimesis.data.providers import Address
    addr = Address()
    code = addr._Address__random.custom_code(mask='@###')
    pass

# Generated at 2022-06-12 02:53:33.306723
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    rnd = Random()
    rnd.seed(3)
    assert rnd.custom_code(char='#') == 'Q2Q2Q'
    assert rnd.custom_code(digit='#', length=6) == '###890'
    assert rnd.custom_code(mask='@&#@&') == 'A4#U4'

# Generated at 2022-06-12 02:53:39.395770
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    for i in range(1000):
        code = random.custom_code(mask="@###")
        assert code[0].isalpha() and code[1:].isdecimal()
        code = random.custom_code(mask="@##Z")
        assert code[0].isalpha() and code[1:].isdecimal()
        code = random.custom_code(mask="@XYZ")
        assert code.isalpha()
        code = random.custom_code(mask="@XYZ############")
        assert code.isalnum()

# Generated at 2022-06-12 02:53:45.174944
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random_gen = Random()
    assert random_gen.custom_code().isupper() and random_gen.custom_code().isdigit()
    assert random_gen.custom_code(mask='@@@###').isupper() and random_gen.custom_code().isdigit()
    assert random_gen.custom_code(mask='@@@###', char='A', digit='1').isupper() and random_gen.custom_code().isdigit()

# Generated at 2022-06-12 02:53:48.952137
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    for _ in range(100):
        code = r.custom_code(mask='abc###')
        assert len(code) == 6
        assert code.isalpha()
        assert code[:3].islower()
        assert code[3:].isdigit()
        assert isinstance(code, str)