

# Generated at 2022-06-12 02:51:46.079291
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random."""

    random_ = Random()
    assert isinstance(random_.custom_code(), str)



# Generated at 2022-06-12 02:51:47.494458
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    random = Random()
    result = random.custom_code('@###')
    assert isinstance(result, str)

# Generated at 2022-06-12 02:51:57.676170
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    # custom_code с одинаковым значением char и digit
    assert r.custom_code('@####', char='@', digit='@') == '@3453'

    # Значение char больше значения digit
    assert r.custom_code('@####', char='?', digit='@') == '?1548'

    # Значение char меньше значения digit
    assert r.custom_code('@####', char='@', digit='?') == '@2882'

    # В качестве

# Generated at 2022-06-12 02:52:02.353469
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit tests for function custom_code of class Random."""
    rnd = Random()
    str1 = rnd.custom_code()
    str2 = rnd.custom_code()
    assert str1 != str2, 'Strings should be different'


if __name__ == '__main__':
    print(test_Random_custom_code())

# Generated at 2022-06-12 02:52:10.927089
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random"""
    string_seq = "abcdefghijklmnopqrstuvwxyz1234567890"
    custom_code = random.custom_code(string_seq)
    assert type(custom_code) == str
    assert len(custom_code) == 4
    assert all(map(lambda x: x in string_seq, custom_code))


# Generated at 2022-06-12 02:52:15.432138
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert Random().custom_code() == '@ABC'
    assert Random().custom_code(mask='@@@###') == 'ABC123'
    assert Random().custom_code(mask='@@@###', char='@', digit='#') == 'ABC123'


# Generated at 2022-06-12 02:52:19.310133
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    assert random.custom_code() in ['@###', '@@##', 'A###', 'AA##', 'AA#A',
                                    '0###', '00##', '00#0', '1###', '11##',
                                    '11#1', '2###', '22##', '22#2', ]


# Generated at 2022-06-12 02:52:23.947610
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    """Unit test for method custom_code of class Random.

    """
    result_string = random.custom_code('@###', '@', '#')
    assert len(result_string) == 4

# Generated at 2022-06-12 02:52:32.448088
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    r = Random()
    code = r.custom_code('@###')
    assert len(code) == 4
    assert not any(c.isdigit() for c in code)
    code = r.custom_code('@@@###', '@')
    assert len(code) == 7
    assert not any(c.isdigit() for c in code[:3])
    assert all(c.isdigit() for c in code[3:])

# Generated at 2022-06-12 02:52:38.320261
# Unit test for method custom_code of class Random
def test_Random_custom_code():
    from unittest import TestCase
    generator = Random()
    code = generator.custom_code()
    test = (code[0].isalpha()) & (code[1:].isdigit())
    TestCase.assertEqual(TestCase(), True, test)