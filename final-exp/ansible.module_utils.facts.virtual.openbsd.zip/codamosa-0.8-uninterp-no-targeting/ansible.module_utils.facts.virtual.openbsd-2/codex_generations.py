

# Generated at 2022-06-20 20:37:49.009578
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd = OpenBSDVirtual()
    assert openbsd.platform == 'OpenBSD'
    assert openbsd.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:37:57.448525
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:38:00.619824
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Test OpenBSDVirtual class
    """
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual._platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:12.828203
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import tempfile
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl = VirtualSysctlDetectionMixin()
    openbsd_virtual.sysctl.sysctl = {}
    openbsd_virtual.sysctl.sysctl['hw.product'] = 'VirtualBox'
    openbsd_virtual.sysctl.sysctl['hw.vendor'] = 'InnoTek GmbH'
    openbsd_virtual.sysctl.sysctl['machdep.vm_guest'] = 'QEMU'


# Generated at 2022-06-20 20:38:15.620767
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:38:19.395150
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class == OpenBSDVirtual
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:22.656514
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:38:30.235018
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class OpenBSDVirtual."""
    # Provide a mock value for hw.vendor
    #on OpenBSD:
    #hw.vendor=GenuineIntel
    #hw.product=Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz

    #on a Macbook 2018
    #hw.vendor=Apple Inc.
    #hw.product=Mac-11AB1121E1C9853C

    #on a Macbook 2012
    #hw.vendor=Apple Inc.
    #hw.product=Mac-031AEE4D24BFF0B1

    #on VMware
    #hw.vendor=GenuineIntel
    #hw.product=Intel(R) Core(TM) i7-7700HQ CPU @ 2.80GHz

    open

# Generated at 2022-06-20 20:38:32.369430
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = OpenBSDVirtual(None, None, None).collect()
    # Assert that the result is a dictionary
    assert isinstance(facts, dict)

# Generated at 2022-06-20 20:38:34.997144
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._platform == 'OpenBSD'
    assert vc._fact_class == OpenBSDVirtual
    assert vc._name == 'virtual_collector'

# Generated at 2022-06-20 20:38:43.105754
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-20 20:38:45.628722
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:38:51.161091
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.collect()
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:38:55.374044
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)

# Generated at 2022-06-20 20:38:59.584004
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:39:11.589486
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual.DMESG_BOOT = '/tmp/dmesg.boot'
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.dmidecode = {}

    # Test virtualization facts for virtual machine

# Generated at 2022-06-20 20:39:15.515176
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.collect()
    collected_facts = openbsd_virtual.get_facts()
    assert len(collected_facts['virtualization_tech_guest']) == 0
    assert len(collected_facts['virtualization_tech_host']) == 1
    assert 'vmm' in collected_facts['virtualization_tech_host']
    assert collected_facts['virtualization_type'] == 'vmm'
    assert collected_facts['virtualization_role'] == 'host'

# Generated at 2022-06-20 20:39:17.725556
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # TODO
    pass

# Generated at 2022-06-20 20:39:23.963222
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class OpenBSDVirtual'''
    virt_facts = OpenBSDVirtual().get_virtual_facts()

    assert virt_facts['virtualization_type'] == "vmm"
    assert virt_facts['virtualization_role'] == "host"
    assert virt_facts['virtualization_tech_guest'] == set()
    assert virt_facts['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-20 20:39:27.187418
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert isinstance(openbsd_virtual, OpenBSDVirtual)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:39:38.949490
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:39:43.343344
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():

    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:45.750068
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()
    assert o.platform == 'OpenBSD'
    assert o.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:39:48.355242
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:51.549961
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-20 20:39:55.046172
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    module = OpenBSDVirtual()
    virtual_facts = module.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-20 20:39:58.267269
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDVirtual
    assert isinstance(obj._fact_class(obj), Virtual)

# Generated at 2022-06-20 20:40:02.204071
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts._platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:40:03.759173
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual.platform == "OpenBSD"

# Generated at 2022-06-20 20:40:08.084396
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    info = OpenBSDVirtual.get_virtual_facts()
    assert info['virtualization_type'] == 'paravirtual'
    assert 'product_name' in info
    assert 'product_version' in info
    assert info['virtualization_role'] == 'guest'
    assert 'virtualization_type' in info


# Generated at 2022-06-20 20:40:20.062008
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.openbsd import OpenBSDVirtual

    class OurClass(OpenBSDVirtual):
        def __init__(self, kernel_version):
            self.kernel_version = kernel_version

        @property
        def kernel_release(self):
            return self.kernel_version

        def detect_virt_product(self, *args, **kwargs):
            return dict(virtualization_tech_guest=set(), virtualization_tech_host=set())

        def detect_virt_vendor(self, *args, **kwargs):
            return dict(virtualization_tech_guest=set(), virtualization_tech_host=set())


# Generated at 2022-06-20 20:40:25.138390
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert isinstance(virtual, OpenBSDVirtual)
    assert isinstance(virtual, VirtualSysctlDetectionMixin)
    assert isinstance(virtual, Virtual)

# Generated at 2022-06-20 20:40:28.754294
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsdVirtualCollector = OpenBSDVirtualCollector()
    assert openbsdVirtualCollector._fact_class == OpenBSDVirtual
    assert openbsdVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:40:39.464118
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    facts = v.get_virtual_facts()

    for key in ('virtualization_type', 'virtualization_role', 'virtualization_tech_host',
                'virtualization_tech_guest'):
        assert key in facts

    # The following tests are based on the requirements of the module_utils
    # documentation.
    # Virtualization type should be detected by hw.product
    if facts['virtualization_type'] == '':
        assert 'virtualization_type' not in facts

    if facts['virtualization_role'] == '':
        assert 'virtualization_role' not in facts

    if facts['virtualization_type'] != '':
        assert 'virtualization_type' in facts
        assert 'virtualization_role' in facts

# Generated at 2022-06-20 20:40:43.080115
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ('vmm', '', 'parallels', 'bhyve')
    assert virtual_facts['virtualization_role'] in ('guest', 'host')

# Generated at 2022-06-20 20:40:46.080863
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:40:48.212055
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._platform == OpenBSDVirtualCollector._platform
    assert vc._fact_class == OpenBSDVirtualCollector._fact_class

# Generated at 2022-06-20 20:40:53.236983
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:40:58.592820
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Arrange
    facts = OpenBSDVirtual()

    # Act
    virtual_facts = facts.get_virtual_facts()

    # Assert
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-20 20:41:09.283982
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock

    # Test for 'hw.product' and 'hw.vendor' being set to virtual and virtualbox
    # Test for virtualization_tech_guest to contain 'virtualbox'
    # Test for virtualization_tech_host to be empty
    # Test for virtualization_type to be 'virtualbox'
    # Test for virtualization_role to be 'guest'
    facts = {'hw.vendor': 'virtual', 'hw.product': 'virtualbox'}
    mock_module = MagicMock()
    mock_module.params = {}

# Generated at 2022-06-20 20:41:29.433656
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_OpenBSDVirtual = OpenBSDVirtual()
    # Empty facts
    expected = {'virtualization_type': '', 'virtualization_role': '',
                'virtualization_tech_guest': set(), 'virtualization_tech_host': set(),
                'virtualization_product_version': '', 'virtualization_product': ''}
    received = test_OpenBSDVirtual.get_virtual_facts()
    assert received == expected

    # Running on a vm (guest)
    test_OpenBSDVirtual.sysctl_output = {'hw.product': 'VMware Virtual Platform',
                                         'hw.vendor': 'Intel Corporation'}

# Generated at 2022-06-20 20:41:40.811066
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()
    print('Check the virtualization type : vmm ', file=temp_file)
    print('Check the virtualization role : host ', file=temp_file)
    print('Check the virtualization type : vmm ', file=temp_file)
    print('Check the virtualization role : host ', file=temp_file)

    temp_file.flush()
    collect = OpenBSDVirtualCollector(temp_file.name)
    assert collect
    facts = collect.collect(None, None)
    virtual = OpenBSDVirtual()
    result = virtual.get_virtual_facts()
    temp_file.close()
    assert result['virtualization_tech_host'] == {'vmm'}
    assert result['virtualization_tech_guest'] == set()

# Generated at 2022-06-20 20:41:43.013971
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    x = OpenBSDVirtualCollector()
    assert isinstance(x, OpenBSDVirtualCollector)

# Generated at 2022-06-20 20:41:44.114162
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    pass

# Generated at 2022-06-20 20:41:49.905225
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    facts = OpenBSDVirtual(None)
    virtual_facts = facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:41:50.856099
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:41:51.963495
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual

# Testing own class OpenBSDVirtual

# Generated at 2022-06-20 20:41:58.448870
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class MockOpenBSDVirtual(OpenBSDVirtual):
        @staticmethod
        def detect_virt_product(fact):
            return {'virtualization_type': 'vmm',
                    'virtualization_role': 'guest',
                    'virtualization_tech_guest': ['virtualbox'],
                    'virtualization_tech_host': ['vmm']}

        @staticmethod
        def detect_virt_vendor(fact):
            return {'virtualization_type': 'vmm',
                    'virtualization_role': 'guest',
                    'virtualization_tech_guest': ['virtualbox'],
                    'virtualization_tech_host': ['vmm']}

    testing = MockOpenBSDVirtual()
    results = testing.get_virtual_facts()
    assert results['virtualization_type'] == 'vmm'

# Generated at 2022-06-20 20:42:02.066839
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:42:13.312369
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    # Tested class exposes protected attribute
    # pylint: disable=protected-access
    openbsd_virtual.dmesg_boot = test_OpenBSDVirtual_get_virtual_facts.dmesg_boot
    openbsd_virtual.sysctl = test_OpenBSDVirtual_get_virtual_facts.sysctl
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_product_name'] == 'VMware Virtual Platform'

# Generated at 2022-06-20 20:42:48.157013
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    vendor_tech_facts = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': ''
    }
    product_tech_facts = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': ''
    }
    dmesg_content = '''
vmm0 at mainbus0: VMX/EPT
'''

    # Sample sysctl outputs for testing method get_virtual_facts

# Generated at 2022-06-20 20:42:51.550220
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_collector = OpenBSDVirtualCollector()
    openbsd_collector.collect()
    assert 'virtualization_type' in openbsd_collector.data.keys()

# Generated at 2022-06-20 20:42:55.925549
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual = OpenBSDVirtualCollector.fetch_virtual_facts()
    assert 'virtualization_type' in virtual
    assert 'virtualization_role' in virtual
    assert 'virtualization_tech_guest' in virtual
    assert 'virtualization_tech_host' in virtual

# Generated at 2022-06-20 20:43:02.291351
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    hypervisor_type = 'hypervisor_type'
    hypervisor_version = 'hypervisor_version'
    hypervisor_hostname = 'hypervisor_hostname'
    hypervisor_uuid = 'hypervisor_uuid'
    virtual_tech = 'virtual_tech'
    v_type = 'v_type'
    v_role = 'v_role'
    openbsd_virtual = OpenBSDVirtual(hypervisor_type, hypervisor_version, hypervisor_hostname, hypervisor_uuid, virtual_tech, v_type, v_role)
    assert openbsd_virtual._platform == 'OpenBSD'
    assert openbsd_virtual.hypervisor_type == hypervisor_type
    assert openbsd_virtual.hypervisor_version == hypervisor_version
    assert openbsd_virtual.hypervisor_hostname

# Generated at 2022-06-20 20:43:11.424229
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert virtual_facts['virtualization_type'] in (
        '', 'vmm', 'bhyve')
    assert virtual_facts['virtualization_role'] in (
        '', 'guest', 'host')
    assert type(virtual_facts['virtualization_tech_guest']) is set
    assert type(virtual_facts['virtualization_tech_host']) is set
    assert '' not in virtual_facts['virtualization_tech_guest']
    assert '' not in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:43:13.684406
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsdvirtual_facts = OpenBSDVirtualCollector(None, None).collect()
    assert 'virtualization_type' in openbsdvirtual_facts
    assert 'virtualization_role' in openbsdvirtual_facts

# Generated at 2022-06-20 20:43:24.696937
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import os
    import tempfile
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    # Patch VirtualSysctlDetectionMixin._read_sysctl_from_file
    from ansible.module_utils.facts.virtual.sysctl import _read_sysctl_from_file
    OpenBSDVirtual.detect_virt_product = VirtualSysctlDetectionMixin._read_sysctl_from_file
    OpenBSDVirtual.detect_virt_vendor = VirtualSysctlDetectionMixin._read_sysctl_from_file

    # Create a temporary file to pass to test cases
    (fd, path) = tempfile.mkstemp()

# Generated at 2022-06-20 20:43:27.555333
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()

    # get_virtual_facts() should return a dict
    assert isinstance(virtual_facts.get_virtual_facts(), dict)

# Generated at 2022-06-20 20:43:30.449896
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:43:34.618220
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:44:42.828979
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:44:44.938829
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._fact_class is OpenBSDVirtual
    assert vc._platform is 'OpenBSD'

# Generated at 2022-06-20 20:44:48.965861
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Create an OpenBSDVirtual instance
    test_virtual = OpenBSDVirtual()

    # Check OpenBSDVirtual facts on a real machine
    # Virtual machines
    test_vmm = test_virtual.get_virtual_facts()
    assert test_vmm['virtualization_type'] == 'vmm'
    assert 'vmm' in test_vmm['virtualization_tech_host']
    assert 'vmware' in test_vmm['virtualization_tech_guest']
    assert test_vmm['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:44:53.353597
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fact_collector = OpenBSDVirtualCollector()
    assert fact_collector._platform == 'OpenBSD'
    assert fact_collector._fact_class.__name__ == 'OpenBSDVirtual'

# Generated at 2022-06-20 20:44:54.727374
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class is OpenBSDVirtual

# Generated at 2022-06-20 20:45:00.919255
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create instance of class OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Set virtual facts to be returned by method get_virtual_facts
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'virtualbox'
    virtual_facts['virtualization_role'] = 'guest'
    virtual_facts['virtualization_tech_guest'] = {'vbox'}
    virtual_facts['virtualization_tech_host'] = {'vbox'}

    # Set return value of method get_file_content to a file
    # containing a line matching one of the regexes
    openbsd_virtual.get_file_content = lambda path: "VirtualBox\n"

    # Call method get_virtual_facts
    result_facts = openbsd_virtual.get_virtual_facts()
   

# Generated at 2022-06-20 20:45:05.394326
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'


# Generated at 2022-06-20 20:45:08.897105
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:45:11.138507
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.fact_class == OpenBSDVirtual
    assert o._platform == 'OpenBSD'

# Generated at 2022-06-20 20:45:17.762186
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    # Not virtualized
    assert v.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '',
                                     'virtualization_tech_guest': {}, 'virtualization_tech_host': {}}
    # Virtualized as guest on vmm (vmware)
    v.facts['hw.vendor'] = 'QEMU'
    v.facts['hw.product'] = 'Standard PC (i440FX + PIIX, 1996)'
    assert v.get_virtual_facts() == {'virtualization_role': 'guest', 'virtualization_type': 'vmm',
                                     'virtualization_tech_guest': {'vmm'}, 'virtualization_tech_host': {'vmm'}}


# Generated at 2022-06-20 20:47:43.241464
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    expected = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm']),
        'virtualization_type': 'vmm',
        'virtualization_role': 'host'
    }
    # Equivalent to calling the module
    virtual = OpenBSDVirtual()
    facts = virtual.get_all_facts()
    assert facts['virtualization'] == expected