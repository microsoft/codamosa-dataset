

# Generated at 2022-06-20 20:37:48.280253
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_facts = OpenBSDVirtual({})
    assert openbsd_facts
    assert openbsd_facts.platform == 'OpenBSD'
    assert openbsd_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:37:57.012771
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

    class MockOpenBSDVirtual(OpenBSDVirtual):
        def __init__(self):
            self.module = MockModule()
            self.sysctl_virtualization_tech_guest = set()
            self.sysctl_virtualization_tech_host = set()
            self.sysctl_virtualization_role = ''
            self.sysctl_virtualization_type = ''

        def detect_virt_product(self, key):
            return {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:38:08.423805
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create instance of class OpenBSDVirtual
    module = OpenBSDVirtual()

    # Get virtual facts
    virtual_facts = module.get_virtual_facts()

    # Check that virtual_facts are correct
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''
    assert virtual_facts['virtualization_product_default_name'] == ''
    assert virtual_facts['virtualization_product_default_version'] == ''
    assert virtual_facts['virtualization_product_vendor_name'] == ''
    assert virtual_facts['virtualization_product_vendor_version'] == ''
    assert len(virtual_facts['virtualization_tech_guest'])

# Generated at 2022-06-20 20:38:12.495455
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Create an object of OpenBSDVirtualCollector.
    """
    my_obj = OpenBSDVirtualCollector()
    assert my_obj._platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:14.710545
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:38:20.381445
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Unit test for constructor of class OpenBSDVirtualCollector."""
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:22.741102
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    instance = OpenBSDVirtualCollector()
    assert instance._platform == "OpenBSD"
    assert isinstance(instance._fact_class, OpenBSDVirtual)

# Generated at 2022-06-20 20:38:26.189126
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-20 20:38:29.617146
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = {}
    fact = Virtual()
    assert fact.get_virtual_facts() == virtual_facts


# Generated at 2022-06-20 20:38:40.733724
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtualCollector().collect(None, None)
    # Test if a non-empty dictionary is returned
    assert facts
    # Test if the class methods set the values
    # of virtualization_type and virtualization_role
    assert facts['virtualization_type'] in ['', 'vmm']
    assert facts['virtualization_role'] in ['', 'host']
    # Test if the class method set the value
    # of virtualization_tech_guest and virtualization_tech_host
    assert facts['virtualization_tech_guest']
    assert facts['virtualization_tech_host']
    # Test if the value of virtualization_tech_guest
    # is a subset of virtualization_tech_host
    assert facts['virtualization_tech_guest'].issubset(facts['virtualization_tech_host'])

# Generated at 2022-06-20 20:38:45.530024
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc.platform == 'OpenBSD'


# Generated at 2022-06-20 20:38:47.401446
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:38:54.663141
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd.vmm import OpenBSDVMM
    from ansible.module_utils.facts.virtual.openbsd.vbox import OpenBSDVirtualBox

    virtual = OpenBSDVirtual()
    virtual.detect_virt_product = OpenBSDVMM.detect_virt_product
    virtual.detect_virt_vendor = OpenBSDVirtualBox.detect_virt_vendor

    result = virtual.get_virtual_facts()
    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_role'] == 'host'
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-20 20:39:05.002376
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    # Fake sysctl hw.product, hw.vendor, /var/run/dmesg.boot
    openbsd_virtual.sysctl_output = {'hw.product': 'VirtualBox',
                                     'hw.vendor': 'Alibaba Cloud',
                                     'vm.guest': None,
                                     'vm.vmcount': 0}
    openbsd_virtual.dmesg_boot = 'vmm0 at mainbus0: VMX/EPT\n'
    virtual_facts = openbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:39:11.548927
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Set empty values as default
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()

    # Test constructor
    openbsd_virtual_info = OpenBSDVirtual()

    # Test virtual_facts function
    virtual_facts = openbsd_virtual_info.get_virtual_facts()

# Generated at 2022-06-20 20:39:13.933425
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vm = OpenBSDVirtualCollector().collect()[0]
    assert vm.platform == 'OpenBSD'
    assert isinstance(vm, OpenBSDVirtual)
    assert vm.virtualization_type == ''
    assert vm.virtualization_role == ''

# Generated at 2022-06-20 20:39:26.141934
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Tests for parsing dmesg.boot
    openbsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-20 20:39:31.491992
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert openbsd_virtual_facts.platform == 'OpenBSD'
    assert openbsd_virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-20 20:39:33.512022
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:37.319757
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtualCollector().collect()
    assert 'virtualization_type' in openbsd_virtual
    assert 'virtualization_role' in openbsd_virtual
    assert 'virtualization_tech_host' in openbsd_virtual
    assert 'virtualization_tech_guest' in openbsd_virtual

# Generated at 2022-06-20 20:39:46.960971
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_facts = OpenBSDVirtual()
    facts = openbsd_facts.get_all_facts()
    assert facts['virtualization_type'] != ''
    assert facts['virtualization_role'] != ''
    assert facts['virtualization_type'] == facts['virtualization_type_full']

# Generated at 2022-06-20 20:39:51.253780
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual = OpenBSDVirtualCollector()
    assert type(virtual) == OpenBSDVirtualCollector
    assert virtual.platform == 'OpenBSD'
    assert virtual._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:57.437682
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert isinstance(openbsd_virtual, OpenBSDVirtual)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual.product_facts == {}
    assert openbsd_virtual.vendor_facts == {}

# Generated at 2022-06-20 20:40:00.989080
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    example_output = {
      'virtualization_type': '',
      'product_name': '',
      'virtualization_role': '',
      'manufacturer': '',
      'product_version': '',
      'virtualization_tech_guest':
        set(['openbsd-product', 'openbsd-vendor']),
      'virtualization_tech_host':
        set(['openbsd-product', 'openbsd-vendor', 'vmm'])
    }

    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == example_output

# Generated at 2022-06-20 20:40:03.665219
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd = OpenBSDVirtualCollector()
    assert isinstance(openbsd, OpenBSDVirtualCollector)


# Generated at 2022-06-20 20:40:12.621722
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    test_spec = {'virtualization_type': 'hyperv',
                 'virtualization_role': 'guest',
                 'virtualization_tech_guest': {'hv', 'hyperv'},
                 'virtualization_tech_host': {'hv', 'hyperv'}}
    test_vm = OpenBSDVirtual(test_spec)
    assert test_vm.virtualization_type == test_spec['virtualization_type']
    assert test_vm.virtualization_role == test_spec['virtualization_role']
    assert test_vm.virtualization_tech_guest == test_spec['virtualization_tech_guest']
    assert test_vm.virtualization_tech_host == test_spec['virtualization_tech_host']

# Generated at 2022-06-20 20:40:13.473061
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:40:15.860427
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:40:17.238095
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:40:20.658733
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module = OpenBSDVirtual()
    assert module is not None
    assert module.platform == 'OpenBSD'
    assert module.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:40:43.653962
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:40:47.311946
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual('OpenBSD', {})
    assert virtual.platform == 'OpenBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest is not None
    assert virtual.virtualization_tech_host is not None

# Generated at 2022-06-20 20:40:51.017566
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    v = OpenBSDVirtualCollector()
    assert isinstance(v, OpenBSDVirtualCollector)

# Generated at 2022-06-20 20:41:00.288719
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    expected = {
        'virtual_facts': {
            'virtualization_role': 'host',
            'virtualization_type': 'vmm',
            'virtualization_tech_host': set(['vmm']),
            'virtualization_tech_guest': set()
        },
        'all_facts': {
            'virtualization_role': 'host',
            'virtualization_type': 'vmm',
            'virtualization_tech_host': set(['vmm']),
            'virtualization_tech_guest': set()
        }
    }
    with open('tests/unit/module_utils/facts/virtual/openbsd/dmesg.boot', 'r') as f:
        results = OpenBSDVirtual(dict(), f.read()).get_facts()
    assert results == expected

# Generated at 2022-06-20 20:41:04.120603
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-20 20:41:12.759584
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtualCollector().collect()['ansible_virtualization_facts']

# Generated at 2022-06-20 20:41:24.281938
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    TEST_DATA = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_product_name': '',
        'virtualization_product_version': ''
    }
    TEST_DATA['virtualization_type'] = 'vmm'
    TEST_DATA['virtualization_role'] = 'host'
    TEST_DATA['virtualization_tech_host'].add('vmm')
    TEST_DATA['virtualization_tech_host'].add('vbox')
    TEST_DATA['virtualization_product_name'] = 'VBox'

    openbsd = OpenBSDVirtual(OpenBSDVirtual.DMESG_BOOT)

# Generated at 2022-06-20 20:41:27.286130
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = {
        'kernel': 'OpenBSD',
        'virtual': 'Any'
    }
    openbsd = OpenBSDVirtualCollector(facts, None)
    assert isinstance(openbsd, OpenBSDVirtualCollector)

# Generated at 2022-06-20 20:41:31.212605
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_sysctl = OpenBSDVirtual()
    assert virtual_sysctl.platform == 'OpenBSD'
    assert virtual_sysctl.virtualization_type == ''
    assert virtual_sysctl.virtualization_role == ''

# Generated at 2022-06-20 20:41:38.494815
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object to avoid calling platform.dist() and return OpenBSD
    openbsd_virtual_facts = OpenBSDVirtual()
    assert openbsd_virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([])
    }


# Generated at 2022-06-20 20:42:03.083371
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    module = OpenBSDVirtualCollector
    assert module._platform == 'OpenBSD'
    assert module._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:42:04.975523
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert type(openbsd_virtual) is OpenBSDVirtualCollector

# Generated at 2022-06-20 20:42:08.896505
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    m = OpenBSDVirtual()
    results = m.get_virtual_facts()
    assert results.get('virtualization_type', '') == ''
    assert results.get('virtualization_role', '') == ''

# Generated at 2022-06-20 20:42:18.800504
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual(OpenBSDVirtualCollector)

    # Replace method detect_virt_product and detect_virt_vendor for a proper test
    def detect_virt_product(key):
        return {'virtualization_type': 'vmm', 'virtualization_role': 'host', 'virtualization_tech_host': ['vmm'], 'virtualization_tech_guest': ['vmm']}
    openbsd_virtual.detect_virt_product = detect_virt_product

    def detect_virt_vendor(key):
        return {'virtualization_type': 'vmm', 'virtualization_role': 'host', 'virtualization_tech_host': ['vmm'], 'virtualization_tech_guest': ['vmm']}
    openbsd_virtual.detect_virt_vendor = detect_

# Generated at 2022-06-20 20:42:23.388999
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    virtual_facts = v.get_virtual_facts()

    assert isinstance(virtual_facts, dict)
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)

# Generated at 2022-06-20 20:42:27.698444
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Unit test fot pseudo constructor, it is not an actual constructor
    # of instantiating an object
    obj_OpenBSDVirtualCollector = OpenBSDVirtualCollector()
    assert obj_OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert obj_OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:42:29.754427
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:42:39.261691
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:42:40.700510
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fact_class = OpenBSDVirtualCollector()
    assert fact_class.platform == 'OpenBSD'

# Generated at 2022-06-20 20:42:46.003333
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''

# Generated at 2022-06-20 20:43:43.498024
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual({'gather_subset': ['!all', '!min']}, {}, {})
    # Testing empty constructor
    assert o.virtual == {}
    assert o.platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:48.224767
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_facts_collector = OpenBSDVirtualCollector()
    print(virtual_facts_collector)
    assert virtual_facts_collector._fact_class == OpenBSDVirtual
    assert virtual_facts_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:51.075849
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:43:53.561343
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert isinstance(openbsd_virtual, OpenBSDVirtual)

# Generated at 2022-06-20 20:43:55.011103
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert isinstance(collector, VirtualCollector)

# Generated at 2022-06-20 20:43:55.926397
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:43:59.137217
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Constructor of class OpenBSDVirtualCollector should pass
    virtual_collector = OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:44:03.700010
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    test_facts = openbsd_virtual.get_virtual_facts()
    assert test_facts['virtualization_type'] == ''
    assert test_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:44:13.699067
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_product'] = ''
    virtual_facts['virtualization_vendor'] = ''
    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()

    virtual_facts_method = OpenBSDVirtual(module=None).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == virtual_facts_method['virtualization_type']
    assert virtual_facts['virtualization_role'] == virtual_facts_method['virtualization_role']
    assert virtual_facts['virtualization_product'] == virtual_facts_method['virtualization_product']
    assert virtual_facts['virtualization_vendor']

# Generated at 2022-06-20 20:44:23.215745
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Read the file content given by 'path' as a fact
    with open('/var/run/dmesg.boot', 'r') as f:
        content = ''.join(f.readlines())

    # Dummy class for AnsibleModule
    class DummyModule:
        def __init__(self):
            self.params = {
                'gather_subset': [],
                'gather_timeout': 10,
                'filter': ''
            }

    # Args values used when creating the objet

# Generated at 2022-06-20 20:46:41.607342
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
        obj = OpenBSDVirtualCollector()
        assert obj.platform == "OpenBSD"
        assert obj._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:46:43.228696
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:46:45.828563
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  assert OpenBSDVirtualCollector() is not None


# Generated at 2022-06-20 20:46:48.324633
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """ Check the constructor of OpenBSDVirtualCollector """
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class == OpenBSDVirtual
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:46:52.797136
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualCollector
    virtual = OpenBSDVirtualCollector()
    assert virtual.get_platform() == 'OpenBSD'
    assert virtual.get_fact_class() == 'OpenBSDVirtual'


# Generated at 2022-06-20 20:46:56.453931
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openBSDVirtual = OpenBSDVirtual()
    assert openBSDVirtual.platform == 'OpenBSD'
    assert openBSDVirtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:47:02.604138
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-20 20:47:07.779760
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual
    assert o._platform == 'OpenBSD'

# vim: set expandtab smarttab shiftwidth=4 tabstop=4 softtabstop=4

# Generated at 2022-06-20 20:47:15.974476
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert 'virtualbox' not in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' not in virtual_facts['virtualization_tech_host']
    assert 'vbox' not in virtual_facts['virtualization_tech_guest']
    assert 'vbox' not in virtual_facts['virtualization_tech_host']
    assert 'openbsd_vmm' not in virtual_facts['virtualization_tech_guest']
    assert 'openbsd_vmm' not in virtual_facts['virtualization_tech_host']
    assert 'xen' not in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:47:19.978168
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual