

# Generated at 2022-06-20 20:37:55.314376
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import json

    # Simple test with a test_dmesg.boot file and a hw.product file
    openbsd_virtual = OpenBSDVirtual({}, dmesg_boot='test_dmesg.boot',
        hw_product='test_hw.product')
    openbsd_virtual.get_file_content = lambda path: open(path).read()

    result = openbsd_virtual.get_virtual_facts()
    expected = {
        'virtualization_role': 'host',
        'virtualization_type': 'vmm',
        'virtualization_tech_host': set(['vmm'])
    }

    assert json.dumps(expected, sort_keys=True) == json.dumps(result,
        sort_keys=True)

    # Test with a hw.product file and a hw

# Generated at 2022-06-20 20:37:59.627557
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_role'] != ''

# Generated at 2022-06-20 20:38:01.566554
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtualCollector.fetch_virtual_facts()
    assert isinstance(virtual, dict)

# Generated at 2022-06-20 20:38:03.953648
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._fact_class == OpenBSDVirtual
    assert vc._platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:15.364779
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtualCollector()

    openbsd_virtual.set_virtual_facts(file_exists_map={
        '/var/run/dmesg.boot': True,
    })
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

    openbsd_virtual.set_virtual_facts(file_exists_map={
        '/var/run/dmesg.boot': False,
    })
    virtual_facts = openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:38:26.973333
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:38:30.976722
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    try:
        vc = OpenBSDVirtualCollector()
    except Exception as e:
        assert False, "Error in creating instance of OpenBSDVirtualCollector"

    assert isinstance(vc, VirtualCollector)


# Generated at 2022-06-20 20:38:34.873199
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual(None)
    ansible_facts = dict()
    ansible_facts['ansible_virtualization_type'] = ''
    ansible_facts['ansible_virtualization_role'] = ''
    virtual_facts.populate()
    assert virtual_facts.facts == ansible_facts

# Generated at 2022-06-20 20:38:38.898408
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_instance = OpenBSDVirtual()
    assert virtual_instance.platform == 'OpenBSD'
    assert virtual_instance.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:38:45.945484
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Arrange
    test_obj = OpenBSDVirtual()
    test_obj.module = MockOpenBSDFactsModule
    test_obj.collector = OpenBSDVirtualCollector()

    # Act
    result = test_obj.get_virtual_facts()

    # Assert
    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_product'] == 'VirtualBox'

# Generated at 2022-06-20 20:38:51.539172
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:39:03.070840
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    This unit test case test get_virtual_facts method of class OpenBSDVirtual.
    This test is a bit complicated, it mocks all methods used by get_virtual_facts,
    and then asserts the result of get_virtual_facts.
    """
    import mock
    import os
    import sys

    vm = OpenBSDVirtual()
    # Create a mock to call get_file_content
    mock_get_file_content = mock.Mock(return_value='')
    vm.get_file_content = mock_get_file_content
    # Create a mock to call is_sysctl_present
    mock_is_sysctl_present = mock.Mock(return_value=False)
    vm.is_sysctl_present = mock_is_sysctl_present
    # Create a mock to call detect_virt_product

# Generated at 2022-06-20 20:39:12.994656
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test data used to mock input from OpenBSD hw.vendor sysctl and
    # hw.product sysctl and dmesg.boot file.
    virtual_facts = {'virtualization_type': '',
                     'virtualization_role': ''}
    virtual_facts_hw_vendor = {'virtualization_type': '',
                               'virtualization_role': ''}
    virtual_facts_hw_product = {'virtualization_type': '',
                                'virtualization_role': ''}
    virtual_facts_dmesg_boot = {'virtualization_type': '',
                                'virtualization_role': ''}

    # Test vmm(4) hypervisor running as host.

# Generated at 2022-06-20 20:39:18.891629
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    The data needed for these unit tests are coming from the dmesg.boot file
    of a virtual OpenBSD vm running on VMWare Fusion
    """
    #Initialize some dummy data
    vm_product = 'VMWare Virtual Platform'
    vm_vendor = 'VMWare'

# Generated at 2022-06-20 20:39:23.748661
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc.platform == 'OpenBSD'
    assert vc._fact_class.platform == 'OpenBSD'
    assert vc._platform == 'OpenBSD'
    assert vc._fact_cachename == 'ansible_virtual_openbsd'
    assert vc.cacheable == True

# Generated at 2022-06-20 20:39:30.319971
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from collections import namedtuple
    from ansible.module_utils.facts.virtual.sysctl import read_sysctl

    # Mock the class open("file", "r").read() to read these lines
    lines_hw_product = 'VirtualBox'
    lines_hw_vendor = ''
    lines_dmesg_boot = 'vmm0 at mainbus0: SVM/RVI\n'

    def mock_open_read(file, *args, **kwargs):
        if file.endswith('/hw.product'):
            return lines_hw_product
        elif file.endswith('/hw.vendor'):
            return lines_hw_vendor
        elif file.endswith('/var/run/dmesg.boot'):
            return lines_dmesg_boot

# Generated at 2022-06-20 20:39:32.876028
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert type(c._fact_class) == OpenBSDVirtual

# Generated at 2022-06-20 20:39:33.427758
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual()

# Generated at 2022-06-20 20:39:36.416958
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:39:41.976881
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:39:59.381692
# Unit test for constructor of class OpenBSDVirtual

# Generated at 2022-06-20 20:40:06.693692
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Test OpenBSDVirtual.get_virtual_facts()
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])
    assert virtual_facts['virtualization_product_name'] == 'openbsd'

# Generated at 2022-06-20 20:40:09.156783
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'


# Generated at 2022-06-20 20:40:17.106246
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    module_return_values = [
        {'virtualization_type': 'vmm',
         'virtualization_role': 'host',
         'virtualization_tech_host': {'vmm'},
         'virtualization_tech_guest': set()},
        {'virtualization_type': 'vmm',
         'virtualization_role': 'guest',
         'virtualization_tech_host': {'vmm'},
         'virtualization_tech_guest': {'vmm'}},
        {'virtualization_type': 'vmm',
         'virtualization_role': 'guest',
         'virtualization_tech_host': {'vmm'},
         'virtualization_tech_guest': {'vmm'}},
    ]

    openbs

# Generated at 2022-06-20 20:40:19.423303
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt_class = OpenBSDVirtual({})
    assert virt_class.platform == 'OpenBSD'


# Generated at 2022-06-20 20:40:24.296479
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Test OpenBSDVirtual class constructor"""
    # Test without arguments
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual
    # Test with empty facts
    openbsd_virtual = OpenBSDVirtual(module_facts={})
    assert openbsd_virtual


# Generated at 2022-06-20 20:40:25.801910
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:40:29.121579
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    try:
        obj = OpenBSDVirtualCollector()
        assert True
    except Exception as e:
        assert False, 'OpenBSDVirtualCollector constructor raises an exception'

# Generated at 2022-06-20 20:40:30.734417
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'


# Generated at 2022-06-20 20:40:42.428809
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_product_serial': '',
        'virtualization_product_uuid': '',
        'virtualization_product_family': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # Test for vmm(4) host
    openbsd_virtual = OpenBSDVirtual('OpenBSD')

# Generated at 2022-06-20 20:40:53.821360
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_facts = OpenBSDVirtualCollector().collect()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert 'virtualization_tech_guest' not in virtual_facts
    assert 'virtualization_tech_host' not in virtual_facts

# Generated at 2022-06-20 20:41:01.487839
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Set up parameters of this test
    expected_virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'openvz',
        'virtualization_tech_guest': {
            'openvz',
        },
        'virtualization_tech_host': {
            'openvz',
        },
    }
    # Set up instance of OpenBSDVirtual to test
    openbsd_virtual_obj = OpenBSDVirtual(None)
    # Set up return value of method detect_virt_product and detect_virt_vendor

# Generated at 2022-06-20 20:41:07.670242
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create object to test
    openbsd_virtual = OpenBSDVirtual()
    # Set return values of methods get_file_content
    # for dmesg.boot
    openbsd_virtual.get_file_content = lambda path: ''
    # Execute method get_virtual_facts
    virtual_facts = openbsd_virtual.get_virtual_facts()
    # Get results
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:41:10.371250
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    x = OpenBSDVirtualCollector()
    assert type(x) is OpenBSDVirtualCollector
    assert x.platform == 'OpenBSD'
    assert x._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:41:13.187983
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class is not None
    assert collector._fact_class.platform == 'OpenBSD'
    assert issubclass(collector._fact_class, Virtual)


# Generated at 2022-06-20 20:41:17.247677
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:41:18.960356
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc.collect()


# Generated at 2022-06-20 20:41:21.966213
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd = OpenBSDVirtual()
    assert openbsd.platform == 'OpenBSD'
    assert openbsd.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:41:29.738957
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from . import VirtualCollectorTestCase
    from . import VirtualCollectorTestCase_OpenBSD_VMware_2020

    expected_vmware = {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmware',
        'virtualization_tech_guest': {'vmware'},
        'virtualization_tech_host': set()
    }

    expected_openbsd_host = {
        'virtualization_role': 'host',
        'virtualization_type': 'vmm',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'vmm'}
    }

    expected_openbsd_host.update(expected_vmware)


# Generated at 2022-06-20 20:41:34.348968
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:41:51.318473
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    my_openbsd_virtual = OpenBSDVirtual()
    assert my_openbsd_virtual.get_virtual_facts() == {
        'virtualization_type' : '',
        'virtualization_role' : '',
        'virtualization_tech_host' : set(),
        'virtualization_tech_guest' : set()
    }

# Generated at 2022-06-20 20:41:53.112474
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector.platform == 'OpenBSD'
    assert OpenBSDVirtualCollector.fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:42:03.082907
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    sysctl_facts = {
        'hw.vendor': 'IBM',
        'hw.product': 'IBM z13s',
    }
    openbsd_virtual_facts = OpenBSDVirtual(sysctl_facts)
    assert openbsd_virtual_facts.sysctl_facts == sysctl_facts
    assert openbsd_virtual_facts.platform == 'OpenBSD'
    # Test _virtual_tech_cache
    assert (
        openbsd_virtual_facts._virtual_tech_cache ==
        {'hw.product': 'IBM z13s', 'hw.vendor': 'IBM'}
    )



# Generated at 2022-06-20 20:42:14.313186
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual({}, {}, None, {})
    facts = {'virtual_facts': {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }}

    virtual_vendor_facts = {'virtualization_type': 'hv',
                            'virtualization_role': 'host',
                            'virtualization_tech_guest': set(),
                            'virtualization_tech_host': set(['hv'])}


# Generated at 2022-06-20 20:42:17.961761
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual({})
    assert o.platform == 'OpenBSD'
    assert OpenBSDVirtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert 'virtualization_type' in o.get_virtual_facts()


# Generated at 2022-06-20 20:42:23.791507
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_test_error1 = {
        'virtualization_type': '',
        'virtualization_role': ''
    }
    openbsd_virtual_test_error2 = {
        'hw.product': '',
        'hw.vendor': ''
    }
    openbsd_virtual_test_error3 = {
        'hw.product': 'VMware Virtual Platform',
        'hw.vendor': '',
    }
    openbsd_virtual_test_error4 = {
        'hw.product': '',
        'hw.vendor': 'OpenBSD',
    }
    openbsd_virtual_test_error5 = {
        'hw.product': 'VMware Virtual Platform',
        'hw.vendor': 'OpenBSD',
    }
    openbsd_virtual_test

# Generated at 2022-06-20 20:42:26.518321
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual(None, None)
    assert v.platform == 'OpenBSD'
    assert v.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:42:32.714943
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    virtual_facts = openbsd_virtual_collector._get_collection_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-20 20:42:36.014543
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert len(virtual_facts) == 2
    assert virtual_facts['virtualization_role'] == ''


# Generated at 2022-06-20 20:42:37.133875
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:12.291162
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # These are the facts to be returned by OpenBSDVirtual.get_virtual_facts()
    openbsd_virtual_facts = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'jail'},
        'virtualization_tech_host': set(),
        'virtualization_product_name': '',
        'virtualization_product_version': '',
    }

    # These are the values of the returned dictionary, obtained by calling
    # OpenBSDVirtual.get_virtual_facts(), that are to be validated.
    # Keys and values should be in the same order as in the dictionary
    # `openbsd_virtual_facts`

# Generated at 2022-06-20 20:43:13.451492
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    This method is not needed, since OpenBSDVirtual class is tested via
    OpenBSDVirtualCollector
    """
    pass

# Generated at 2022-06-20 20:43:20.890195
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector.platforms == { 'OpenBSD': ['OpenBSDVirtual', 'OpenBSDVirtualCollector'] }
    assert openbsd_virtual_collector._fact_class == 'OpenBSDVirtual'
    assert openbsd_virtual_collector.fact_classes == { 'OpenBSDVirtual': 'OpenBSDVirtual' }

# Generated at 2022-06-20 20:43:24.914486
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert isinstance(obj, OpenBSDVirtualCollector)
    assert obj._fact_class is OpenBSDVirtual
    assert obj._platform == 'OpenBSD'


# Generated at 2022-06-20 20:43:28.029410
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:43:35.369504
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt_collector = OpenBSDVirtualCollector()
    virtual_facts = virt_collector.get_virtual_facts()

    assert(virtual_facts['virtualization_type'] in
           ['vmm', '', 'Unknown virtualization type'])

    assert(virtual_facts['virtualization_role'] in
           ['guest', 'host', '', 'Unknown virtualization role'])

# Generated at 2022-06-20 20:43:39.990225
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    host_tech = set()
    guest_tech = set()

    # Test VMware Fusion
    # Set empty values as default
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    product = 'VMware Virtual Platform'
    vendor = 'VMware, Inc.'
    virtual_product_facts = OpenBSDVirtual().detect_virt_product(product)
    guest_tech.update(virtual_product_facts['virtualization_tech_guest'])
    host_tech.update(virtual_product_facts['virtualization_tech_host'])
    virtual_facts.update(virtual_product_facts)

    virtual_vendor_facts = OpenBSDVirtual().detect_virt_vendor(vendor)

# Generated at 2022-06-20 20:43:44.908927
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:43:48.350900
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class._platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:56.801778
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:45:05.428039
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts._platform == 'OpenBSD'
    assert not hasattr(virtual_facts, 'facts')


# Generated at 2022-06-20 20:45:07.873130
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(virtual_collector, OpenBSDVirtualCollector)

# Generated at 2022-06-20 20:45:10.518864
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:45:11.257505
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'


# Generated at 2022-06-20 20:45:12.389841
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()


# Generated at 2022-06-20 20:45:14.349190
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd = OpenBSDVirtualCollector().collect()
    assert openbsd['virtualization_type'] == ''
    assert openbsd['virtualization_role'] == ''

# Generated at 2022-06-20 20:45:17.348557
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    openbsd_virtual_collector.collect()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.facts['virtualization_type'] == ''
    assert openbsd_virtual_collector.facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:45:23.860787
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == {'hvm', 'vmm'}
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}


# Generated at 2022-06-20 20:45:26.757688
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual_obj = OpenBSDVirtual()

    # Get facts
    openbsd_virtual_facts = openbsd_virtual_obj.get_virtual_facts()

    # Assert facts
    assert openbsd_virtual_facts['virtualization_type']
    assert openbsd_virtual_facts['virtualization_role']

# Generated at 2022-06-20 20:45:31.840973
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()
    assert o.platform == 'OpenBSD'
    assert o.virtualization_type == ''
    assert o.virtualization_role == ''
    assert o.virtualization_technologies_guest == set()
    assert o.virtualization_technologies_host == set()