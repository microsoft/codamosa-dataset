

# Generated at 2022-06-20 20:37:49.437050
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == {'vmm'}
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-20 20:37:57.684993
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test a physical machine detected as hosts running OpenBSD
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

    # Test a virtual machine running in VirtualBox detected as guest running OpenBSD
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'VirtualBox'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['virtualbox'])
    assert not virtual_facts['virtualization_tech_host']

    # Test a virtual machine

# Generated at 2022-06-20 20:38:01.668999
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    platform = virtual_facts.platform

    assert platform == 'OpenBSD'
    assert hasattr(virtual_facts, '_platform')

    assert hasattr(virtual_facts, 'get_virtual_facts')

# Generated at 2022-06-20 20:38:04.046582
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert c._platform == 'OpenBSD'
    assert c._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:38:15.450772
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-20 20:38:21.289375
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Initialize OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Call method get_virtual_facts with legal argument
    result = openbsd_virtual.get_virtual_facts()

    # Check result
    assert 'virtualization_type' in result
    assert result['virtualization_type'] != ''

# Generated at 2022-06-20 20:38:25.230642
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd = OpenBSDVirtual({}, {}, {}, {})
    assert openbsd.platform == 'OpenBSD'
    assert openbsd.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd.virtual_sysctl_names == {}

# Generated at 2022-06-20 20:38:31.300606
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Given

    # When
    openbsd_virtual_facts = OpenBSDVirtual()

    # Then
    assert openbsd_virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:38:37.394567
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual({})
    v_facts = v.get_virtual_facts()
    assert 'virtualization_type' in v_facts
    assert 'virtualization_type_interface' in v_facts
    assert 'virtualization_role' in v_facts
    assert 'virtualization_role_interface' in v_facts
    assert 'virtualization_technologies' in v_facts
# end of test_OpenBSDVirtual_get_virtual_facts() method

# Generated at 2022-06-20 20:38:49.169538
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    module = MagicMock()
    set_module_args(dict())

# Generated at 2022-06-20 20:38:54.132336
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual


# Generated at 2022-06-20 20:38:55.458426
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:57.290864
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    cf = OpenBSDVirtualCollector()
    assert isinstance(cf._fact_class, OpenBSDVirtual)

# Generated at 2022-06-20 20:39:00.943748
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()

    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:39:11.829625
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import pytest

    class OpenBSDVirtual_test(OpenBSDVirtual):
        def detect_virt_vendor(self, vendor_sysctl):
            return {'virtualization_type': 'vmm', 'virtualization_role': '',
                    'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

        def detect_virt_product(self, product_sysctl):
            return {'virtualization_type': '', 'virtualization_role': '',
                    'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    vm = OpenBSDVirtual_test()
    vm_facts = vm.get_virtual_facts()
    assert vm_facts['virtualization_type'] == 'vmm'
    assert vm_facts['virtualization_role'] == ''
    assert vm

# Generated at 2022-06-20 20:39:15.667347
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # No options passed to constructor
    openbsd_virtual = OpenBSDVirtual()
    # Names of expected keys in the output dictionary
    expected_keys = ['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host', 'virtualization_product']
    assert sorted(expected_keys) == sorted(openbsd_virtual.facts.keys())

# Generated at 2022-06-20 20:39:26.909038
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Can't use unittest.mock.patch as it's not available in Python 2.7
    from ansible.module_utils.facts.virtual.openbsd import (
        VirtualSysctlDetectionMixin
    )
    mock_detect_virt_product = VirtualSysctlDetectionMixin.detect_virt_product
    mock_detect_virt_vendor = VirtualSysctlDetectionMixin.detect_virt_vendor

    # Mock the product
    virtual_product_facts = {
        'virtualization_tech_guest': {'vmware'},
        'virtualization_tech_host': set(),
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest'
    }
    mock_detect_virt_product.return_value = virtual_product_facts

   

# Generated at 2022-06-20 20:39:30.679440
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module_name = 'ansible_virtual'
    module_args = {}
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    v = OpenBSDVirtual(module)
    assert v._platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:34.415369
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    const = OpenBSDVirtual({}, {}, {})
    assert const._platform == 'OpenBSD'
    assert const._fact_class == OpenBSDVirtual
    assert type(const) == OpenBSDVirtual


# Generated at 2022-06-20 20:39:37.822673
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual({})
    assert 'virtualization_type' in v.get_virtual_facts()
    assert 'virtualization_role' in v.get_virtual_facts()
    assert 'virtualization_tech_host' in v.get_virtual_facts()
    assert 'virtualization_tech_guest' in v.get_virtual_facts()

# Generated at 2022-06-20 20:39:41.996080
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_obj = OpenBSDVirtual(None)
    assert openbsd_virtual_obj.platform == 'OpenBSD'
    assert openbsd_virtual_obj.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:39:47.117838
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    results = openbsd_virtual.get_virtual_facts()
    assert results['virtualization_role'] in ['guest', 'host', 'hv']
    assert results['virtualization_type'] in ['vmware', 'openvz', 'kvm', 'xen', 'virtualbox', 'vserver', 'jail', 'zones', 'vmm']

# Generated at 2022-06-20 20:39:59.289529
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Populate the sysctl info
    sysctl_info = dict()
    sysctl_info['hw.product'] = dict()
    sysctl_info['hw.vendor'] = dict()
    sysctl_info['hw.product']['data'] = 'ProLiant'
    sysctl_info['hw.vendor']['data'] = 'HP'
    openbsd_virtual = OpenBSDVirtual({'sysctl': sysctl_info})

    # Populate the dmesg output

# Generated at 2022-06-20 20:40:01.952377
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector is not None


# Generated at 2022-06-20 20:40:05.834500
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # construct an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == "OpenBSD"
    assert 'virtualization_type' in openbsd_virtual.get_virtual_facts()


# Generated at 2022-06-20 20:40:08.458423
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_openbsd = OpenBSDVirtual()
    assert virtual_openbsd.platform == 'OpenBSD'
    assert virtual_openbsd.is_linux() == False


# Generated at 2022-06-20 20:40:10.326504
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    assert len(openbsd_virtual.get_virtual_facts()) == 4

# Generated at 2022-06-20 20:40:13.072402
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()

    assert virtual_facts.collector._fact_class.__name__ == 'OpenBSDVirtual'
    assert virtual_facts.collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:40:15.150630
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class == OpenBSDVirtual
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:40:20.297019
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtualCollector()
    virtual_facts = virtual.get_virtual_facts()
    # Ensure that all required keys are in the result.
    assert sorted(list(virtual_facts.keys())) == sorted([
        'virtualization_role',
        'virtualization_type',
        'virtualization_tech_guest',
        'virtualization_tech_host'])

# Generated at 2022-06-20 20:40:38.123607
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    RedHatVirtual_mock = OpenBSDVirtual()
    # Case 1: Virtualization host
    setattr(RedHatVirtual_mock, '_dmesg_boot', {'content': b'vmm0 at mainbus0: SVM/RVI'})
    facts = RedHatVirtual_mock.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech_host'] == set(['vmm'])
    # Case 2: Virtualization guest
    setattr(RedHatVirtual_mock, '_dmesg_boot', {'content': b'unknown(9) at unknown(4) for vmware0'})
    facts = RedHatVirtual_mock.get_virtual_facts()
    assert facts

# Generated at 2022-06-20 20:40:43.442170
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    o = OpenBSDVirtual(module=None)
    assert o.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'vmm'},
    }

# Generated at 2022-06-20 20:40:51.092391
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:40:53.217610
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.get_virtual_facts() == {}

# Generated at 2022-06-20 20:41:00.454502
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object for testing
    openbsd_virtual = OpenBSDVirtual()

    # Test get_virtual_facts
    assert openbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': '',
        'virtualization_product': '',
        'virtualization_product_version': '',
        'virtualization_product_serial': '',
        'virtualization_product_uuid': '',
        'virtualization_product_family': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-20 20:41:02.586376
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'



# Generated at 2022-06-20 20:41:05.141882
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()
    assert o.platform == 'OpenBSD'
    assert o.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:41:08.162371
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector, "OpenBSDVirtualCollector() failed"
    assert collector._platform == 'OpenBSD', "Platform not set properly"
    assert collector._fact_class == OpenBSDVirtual, "Wrong fact class"

# Generated at 2022-06-20 20:41:11.782777
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:41:15.363811
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    from unittest import TestCase
    test = TestCase()
    obj = OpenBSDVirtualCollector()
    test.assertEqual(obj._platform, 'OpenBSD')
    test.assertIsInstance(obj._fact_class, OpenBSDVirtual)

# Generated at 2022-06-20 20:41:31.163561
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = OpenBSDVirtualCollector()
    assert isinstance(facts, VirtualCollector)
    assert isinstance(facts._fact_class, OpenBSDVirtual)
    assert facts._platform is 'OpenBSD'

# Generated at 2022-06-20 20:41:41.781779
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import os
    import sys
    import unittest
    try:
        from unittest.mock import MagicMock, patch
    except:
        from mock import MagicMock, patch

    try:
        pkg_resources = __import__('pkg_resources')
    except:
        pkg_resources = None

    # The following variables are used in asserts when checking the
    # returned facts (calls to method get_virtual_facts).
    VTYPE = 'virtualization_type'
    VROLE = 'virtualization_role'
    VHOST = 'virtualization_tech_host'
    VGUEST = 'virtualization_tech_guest'

    class FakePopen():
        def __call__(self, *args, **kwargs):
            return self

# Generated at 2022-06-20 20:41:44.728213
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert openbsd_virtual_facts.get_virtual_facts()


# Generated at 2022-06-20 20:41:55.416940
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_instance = OpenBSDVirtual()


# Generated at 2022-06-20 20:41:58.268994
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.fact_class == OpenBSDVirtual
    assert virtual_collector.platform == 'OpenBSD'

# Generated at 2022-06-20 20:42:08.524571
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual({}, False)
    assert virtual_facts.system is None
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_system == ''
    assert virtual_facts.virtualization_hypervisor == ''
    assert virtual_facts.virtual_facts.keys() == ['virtualization_role',
                                                  'virtualization_type',
                                                  'virtualization_system',
                                                  'virtualization_hypervisor',
                                                  'virtualization_tech_guest',
                                                  'virtualization_tech_host']

# Generated at 2022-06-20 20:42:11.461480
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual.__name__


# Generated at 2022-06-20 20:42:13.046933
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = dict()
    OpenBSDVirtualCollector(facts, None)
    assert 'virtual' in facts


# Generated at 2022-06-20 20:42:18.573318
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    drv = OpenBSDVirtual()
    drv.DMESG_BOOT = './test/unit/module_utils/facts/virtual/test_data/dmesg_openbsd.boot'
    openbsd_virtual_facts = drv.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_role'] == 'host'
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'

# Generated at 2022-06-20 20:42:23.389113
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_facts = OpenBSDVirtualCollector().collect()

    # test for valid keys
    assert openbsd_virtual_facts.keys() >= {
        'virtualization_role',
        'virtualization_type',
        'virtualization_tech_guest',
        'virtualization_tech_host',
    }


# Generated at 2022-06-20 20:42:46.173734
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert isinstance(openbsd_virtual_facts['virtualization_type'], str)
    assert isinstance(openbsd_virtual_facts['virtualization_role'], str)
    assert isinstance(openbsd_virtual_facts['virtualization_system'], str)
    assert isinstance(openbsd_virtual_facts['virtualization_subsystem'], str)
    assert isinstance(openbsd_virtual_facts['virtualization_hypervisor_host'], str)
    assert isinstance(openbsd_virtual_facts['virtualization_hypervisor_type'], str)
    assert isinstance(openbsd_virtual_facts['virtualization_technologies'], list)
    assert len(openbsd_virtual_facts['virtualization_technologies']) == 0

# Generated at 2022-06-20 20:42:46.878040
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector is not None

# Generated at 2022-06-20 20:42:58.258541
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Check setting product, vendor and vmm, host
    result = OpenBSDVirtual(dmesg='foo', hw_product='Product Name', hw_vendor='Vendor Name', connector='vmm').get_virtual_facts()
    if result['virtualization_type'] != 'vmm' or result['virtualization_role'] != 'host':
        raise AssertionError('Unexpected values of virtualization_type or virtualization_role, should be vmm,host: %s' % result)

    # Check setting product, vendor and vmm, guest
    result = OpenBSDVirtual(dmesg='foo', hw_product='Product Name', hw_vendor='Vendor Name', connector='vmm').get_virtual_facts()

# Generated at 2022-06-20 20:43:01.089734
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = OpenBSDVirtual()
    assert isinstance(facts, OpenBSDVirtual)


# Generated at 2022-06-20 20:43:02.641397
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:43:04.707971
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    VirtualCollector()
    assert(OpenBSDVirtualCollector != None)

# Generated at 2022-06-20 20:43:05.608543
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # No need to unit test anything
    pass

# Generated at 2022-06-20 20:43:10.314623
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_collector = OpenBSDVirtualCollector()
    virtual_facts = virtual_collector._get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'OpenBSD'
    assert not virtual_facts['virtualization_role']
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']
    assert not virtual_facts['virtualization_product']

# Generated at 2022-06-20 20:43:20.678035
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual('')
    assert v.platform == 'OpenBSD'

# This is dummy output from dmesg.boot

# Generated at 2022-06-20 20:43:23.250859
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:53.919534
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdvirtual = OpenBSDVirtual()
    assert openbsdvirtual.platform == 'OpenBSD'


# Generated at 2022-06-20 20:43:56.827771
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    collector = OpenBSDVirtualCollector()
    virtual_facts = collector._get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-20 20:44:06.997245
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import Collector

    # create fake module
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    # create collector
    collector = Collector(module=module, platform='OpenBSD')
    virtual_collector = OpenBSDVirtualCollector(module=module, platform='OpenBSD',
                                                collector=collector)
    facts = virtual_collector.collect()
    virtual_facts = facts['ansible_virtualization_facts']

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:44:08.518703
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:44:11.174575
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-20 20:44:18.895565
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.dmesg_boot_content = {
        'vmm0 at mainbus0: SVM/RVI'
    }
    openbsd_virtual.sysctl_content = {}
    openbsd_facts = openbsd_virtual.get_virtual_facts()

    # 'virtualization_type' key should be set to 'vmm'
    assert openbsd_facts['virtualization_type'] == 'vmm'

    # 'virtualization_role' key should be set to 'host'
    assert openbsd_facts['virtualization_role'] == 'host'

# Generated at 2022-06-20 20:44:20.346147
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:44:25.563937
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    openbsd_virtual = OpenBSDVirtual()
    virtual_facts = openbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])
    assert virtual_facts['virtualization_tech_guest'] == set(['vmm'])
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_product_name'] == 'openbsd'
    assert virtual_facts['virtualization_product_version']

# Generated at 2022-06-20 20:44:27.663393
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    # Construct an instance of OpenBSDVirtual class
    virtual_bsd = OpenBSDVirtual()

    assert virtual_bsd.platform == 'OpenBSD'

# Generated at 2022-06-20 20:44:30.010463
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-20 20:45:44.169995
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Creating a object of OpenBSDVirtualCollector
    obj = OpenBSDVirtualCollector()
    assert obj._platform == "OpenBSD"

# Generated at 2022-06-20 20:45:48.244173
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    result = OpenBSDVirtualCollector()
    assert result.platform == 'OpenBSD'
    assert result._fact_class == OpenBSDVirtual



# Generated at 2022-06-20 20:45:51.645944
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:46:00.697338
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import pytest, copy

    # Set up mocks for the fake facts
    tmp_openatexit = __builtins__.open
    tmp_sysctl_all = __builtins__.sysctl
    tmp_dmesg_boot = OpenBSDVirtual.DMESG_BOOT

    # The dmesg_boot file has a different path when running tests
    OpenBSDVirtual.DMESG_BOOT = 'tests/unit/module_utils/facts/virtual/test_sys_openbsd.dmesg.boot'

    # This is a fake sysctl values returned when running tests

# Generated at 2022-06-20 20:46:04.429890
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    test_dict = {'virtualization_type': '', 'virtualization_role': ''}
    assert OpenBSDVirtual(None).populate() == test_dict

# Generated at 2022-06-20 20:46:09.167115
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualCollector

    x = OpenBSDVirtualCollector()
    assert isinstance(x, OpenBSDVirtualCollector)


# Generated at 2022-06-20 20:46:11.166666
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:46:19.453996
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.collector import TestCollector
    from ansible.module_utils.facts.virtual.sysctl import FakeSysctlDetectionMixin
    class FakeOpenBSDVirtual(TestCollector, VirtualSysctlDetectionMixin):

        def detect_virt_product(self, product_name):
            self.log(product_name)

        def detect_virt_vendor(self, product_name):
            self.log(product_name)


# Generated at 2022-06-20 20:46:30.108478
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:46:39.733488
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    obj = OpenBSDVirtual({})
    assert obj.platform == 'OpenBSD'
    assert obj.VM_VENDOR_DETECTION == {
        'vmware': {
            'sysctl': 'hw.product',
            'values': [
                'VMware Virtual Platform',
                'VMware7,1'
            ],
        }
    }