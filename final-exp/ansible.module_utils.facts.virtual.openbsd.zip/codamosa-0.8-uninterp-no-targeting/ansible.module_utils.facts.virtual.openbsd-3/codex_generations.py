

# Generated at 2022-06-20 20:37:42.927638
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:37:48.471598
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:37:50.217885
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual('OpenBSD')
    assert o.platform == 'OpenBSD'



# Generated at 2022-06-20 20:37:53.290474
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:37:54.367395
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'

# Generated at 2022-06-20 20:37:59.328176
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o_OpenBSDVirtualCollector = OpenBSDVirtualCollector()
    assert o_OpenBSDVirtualCollector._fact_class is OpenBSDVirtual
    assert o_OpenBSDVirtualCollector._platform == 'OpenBSD'


# Generated at 2022-06-20 20:38:01.312379
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert not OpenBSDVirtualCollector()._platform  # In this case, platform is set in the class definition.


# Generated at 2022-06-20 20:38:03.296101
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:38:05.958226
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualCollector
    obj = OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:38:08.512488
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual({},{})
    assert o.platform == 'OpenBSD'
    assert o.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:38:23.122382
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import OpenBSDVirtual

    module = {'virtual_facts': OpenBSDVirtual.get_virtual_facts()}
    assert 'virtualization_type' in module['virtual_facts']
    assert 'virtualization_role' in module['virtual_facts']
    assert 'virtualization_tech_host' in module['virtual_facts']
    assert 'virtualization_tech_guest' in module['virtual_facts']
    assert 'openbsd' in module['virtual_facts']['virtualization_type']

# Generated at 2022-06-20 20:38:30.019918
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = dict()
    openbsd_virtual = OpenBSDVirtual("/etc/mock_file")
    openbsd_virtual.VirtualSysctlDetectionMixin.get_virtual_facts = lambda self: virtual_facts
    result = openbsd_virtual.get_virtual_facts()
    assert type(result) == dict
    assert result['virtualization_tech_guest'] == set()
    assert "virtualization_tech_host" not in result

# Generated at 2022-06-20 20:38:34.072153
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # OpenBSDVirtual instantiated with no arguments
    openbsdvirt_obj = OpenBSDVirtual()
    assert openbsdvirt_obj.platform == 'OpenBSD'
    assert openbsdvirt_obj.virtualization_type == ''
    assert openbsdvirt_obj.virtualization_role == ''


# Generated at 2022-06-20 20:38:35.337600
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector()._fact, OpenBSDVirtual)

# Generated at 2022-06-20 20:38:37.778042
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:42.242492
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class is OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:43.970359
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = OpenBSDVirtualCollector().collect()
    assert 'virtual' in facts and facts['virtual'] == "OpenBSD"

# Generated at 2022-06-20 20:38:47.465146
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = {}
    virtual = OpenBSDVirtual(facts)
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()


# Generated at 2022-06-20 20:38:51.240519
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None, None, None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:38:54.721915
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Check that the constructor of class OpenBSDVirtualCollector works as expected"""
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class

# Generated at 2022-06-20 20:39:07.768166
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.module = None
    expected_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {'vmm'}
    }
    assert openbsd_virtual.get_virtual_facts() == expected_facts

# Generated at 2022-06-20 20:39:10.174124
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:12.050822
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()

    # Test all branches of OpenBSDVirtual.get_virtual_facts
    virtual.get_virtual_facts()

# Generated at 2022-06-20 20:39:13.096350
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual

# Generated at 2022-06-20 20:39:18.946415
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import os
    from ansible.module_utils.facts import collector

    openbsd_virtual_collector = OpenBSDVirtualCollector(collector)
    openbsd_virtual_collector.module = os
    openbsd_virtual_collector.get_sysctl_facts = lambda: {
        'hw': {
            'product': '',
            'vendor': ''
        }
    }

    # Virtual by default
    dmesg_boot = '''
vmm0 at mainbus0: SVM/RVI
'''
    openbsd_virtual_collector.get_file_lines = lambda f: dmesg_boot.splitlines()
    virtual_facts = openbsd_virtual_collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
   

# Generated at 2022-06-20 20:39:20.289620
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    sv = OpenBSDVirtual()
    assert sv.platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:24.789419
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Class constructor
    openbsd_virtual = OpenBSDVirtual()
    # Check the virtualization_type
    assert openbsd_virtual.virtualization_type == ''
    # Check the virtualization_role
    assert openbsd_virtual.virtualization_role == ''

# Generated at 2022-06-20 20:39:26.115425
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual is not None


# Generated at 2022-06-20 20:39:31.492406
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtualCollector().collect()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:39:37.152041
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert 'virtualization_tech_host' in openbsd_virtual_facts
    assert 'virtualization_tech_guest' in openbsd_virtual_facts



# Generated at 2022-06-20 20:39:50.549260
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    fact_class = collector._fact_class
    assert fact_class._platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:54.298869
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = {}
    vc = OpenBSDVirtualCollector(facts, None)

    assert vc._platform == 'OpenBSD'
    assert issubclass(type(vc._fact_class), Virtual)

# Generated at 2022-06-20 20:39:55.401122
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Check OpenBSDVirtualCollector class constructor"""
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector.fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:39:58.507105
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:40:09.802639
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Create an instance
    virtual_openbsd = OpenBSDVirtual({})

    # Returned value
    retval = virtual_openbsd.get_virtual_facts()

    # Check if the returned values are correct
    assert type(retval) == dict
    for key in retval.keys():
        assert key in ['virtualization_type', 'virtualization_role',
                       'virtualization_tech_guest', 'virtualization_tech_host']
    for key in ['virtualization_type', 'virtualization_role']:
        assert type(retval[key]) == str or type(retval[key]) == unicode
    for key in ['virtualization_tech_guest', 'virtualization_tech_host']:
        assert type(retval[key]) == set

# Generated at 2022-06-20 20:40:17.492298
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, VirtualCollector
    OpenBSDVirtual._platform = 'OpenBSD'
    OpenBSDVirtual._fact_class = OpenBSDVirtual
    OpenBSDVirtualCollector.platform = 'OpenBSD'

    setattr(OpenBSDVirtual, '_collect_platform_subset', lambda x, y: dict())
    setattr(OpenBSDVirtual, '_platform', 'OpenBSD')
    setattr(OpenBSDVirtual, '_fact_class', OpenBSDVirtual)
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

   

# Generated at 2022-06-20 20:40:20.858735
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = {}
    openbsd_virtual = OpenBSDVirtual(module=None, facts=facts)
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts

# Generated at 2022-06-20 20:40:23.957583
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(virtual_collector, OpenBSDVirtualCollector)

# Generated at 2022-06-20 20:40:25.442731
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()

# Testing against sysctl hw.product



# Generated at 2022-06-20 20:40:29.131735
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:41:00.346618
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:41:04.480184
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Construct OpenBSDVirtual class

    Expected result:
        isinstance(obj_v, Virtual) is True
    """
    obj_v = OpenBSDVirtual()
    assert obj_v is not None
    assert isinstance(obj_v, Virtual)


# Generated at 2022-06-20 20:41:07.825423
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual(module=None)
    # DMESG_BOOT is a class variable
    assert(virtual.DMESG_BOOT == '/var/run/dmesg.boot')


# Generated at 2022-06-20 20:41:10.211419
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector.fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:41:13.435918
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt_facts = OpenBSDVirtual().get_virtual_facts()
    assert virt_facts['virtualization_type'] == ''
    assert virt_facts['virtualization_role'] == ''
    assert virt_facts['virtualization_tech_guest'] == set()
    assert virt_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:41:20.398634
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt_facts = OpenBSDVirtual()
    expected_fact_info = {'virtualization_type': 'vmm',
                          'virtualization_role': 'host',
                          'virtualization_tech_guest': set(),
                          'virtualization_tech_host': {'vmm'},
                          'virtualization_platform': 'vmm'}

    assert virt_facts.get_virtual_facts() == expected_fact_info

# Generated at 2022-06-20 20:41:23.989528
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:41:26.738390
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    fact_module = OpenBSDVirtual(dict())
    assert fact_module.platform == 'OpenBSD'
    assert fact_module.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:41:35.672857
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    testobj = OpenBSDVirtual()
    virtual_facts = testobj.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_product' in virtual_facts
    assert 'virtualization_vendor' in virtual_facts

# Generated at 2022-06-20 20:41:41.569128
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.virtualization_type == ''
    assert openbsd_virtual.virtualization_role == ''
    assert not openbsd_virtual.virtualization_tech_guest
    assert not openbsd_virtual.virtualization_tech_host
    assert not openbsd_virtual.virtualization

# Generated at 2022-06-20 20:42:36.504248
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a test instance of class OpenBSDVirtual
    virtual = OpenBSDVirtual()

    # The following facts should be returned when running on a real OpenBSD
    # VM: Virtualization type: vmm, Virtualization role: guest,
    # Virtualization tech guest: vmm, Virtualization tech host: vmm
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['vmm'])
    assert facts['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-20 20:42:38.625784
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_vir_col = OpenBSDVirtualCollector()
    assert openbsd_vir_col._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-20 20:42:43.682898
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts_obj = OpenBSDVirtual()

    facts_virtual_expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    assert virtual_facts_obj.platform == 'OpenBSD'
    assert virtual_facts_obj.virtual_facts == facts_virtual_expected
    assert virtual_facts_obj.extra_facts == {}

# Generated at 2022-06-20 20:42:46.651838
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_type': '',
                     'virtualization_role': '',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}
    openbsd_virtual = OpenBSDVirtual()
    result = openbsd_virtual.get_virtual_facts()
    assert result == virtual_facts

# Generated at 2022-06-20 20:42:48.448822
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    return_dict = dict(virtualization_role='guest', virtualization_type='openvz')
    class_inst = OpenBSDVirtual()
    assert class_inst.get_virtual_facts() == return_dict

# Generated at 2022-06-20 20:42:51.861287
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-20 20:42:55.316180
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:42:57.448218
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o is not None
    assert o.virtual is not None
    assert o.virtual._platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:00.961180
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    detect = OpenBSDVirtual()
    assert detect.platform == "OpenBSD"


# Generated at 2022-06-20 20:43:10.634413
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()

    #############################
    # # Fake dmesg.boot content #
    #############################
    # just virtualization_type related facts

# Generated at 2022-06-20 20:45:23.262346
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collect_obj = OpenBSDVirtualCollector({})
    assert isinstance(openbsd_virtual_collect_obj, VirtualCollector)
    assert openbsd_virtual_collect_obj.platform == 'OpenBSD'
    assert openbsd_virtual_collect_obj.fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:45:24.863136
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtualcollector = OpenBSDVirtualCollector('/path/to/file')
    openbsd_virtualcollector.get_facts()

# Generated at 2022-06-20 20:45:28.054188
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsdvirtualcollector = OpenBSDVirtualCollector()
    assert openbsdvirtualcollector._fact_class == OpenBSDVirtual
    assert openbsdvirtualcollector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:45:30.386426
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'


# Generated at 2022-06-20 20:45:33.722744
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = OpenBSDVirtual({}, {})
    assert facts.virtualization_type == ''
    assert facts.virtualization_role == ''
    assert facts.virtualization_tech_guest == set()
    assert facts.virtualization_tech_host == set()



# Generated at 2022-06-20 20:45:35.206614
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    OpenBSDVirtual()


# Generated at 2022-06-20 20:45:36.978882
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert not collector.detect()

# Generated at 2022-06-20 20:45:46.495692
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test with no virtualization facts
    virtual_facts = OpenBSDVirtual({})
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    # Test with virtual product string that does not match
    virtual_facts = OpenBSDVirtual({'ansible_product_string': ['OpenBSD', '6.0']})
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    # Test with virtual product string that matches
    virtual_

# Generated at 2022-06-20 20:45:52.425528
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual({})['virtualization_type'] == ''
    assert OpenBSDVirtual({})['virtualization_role'] == ''
    assert OpenBSDVirtual({})['virtualization_tech_guest'] == set()
    assert OpenBSDVirtual({})['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:45:54.579386
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    instance = OpenBSDVirtualCollector()
    assert instance._fact_class == OpenBSDVirtual
    assert instance._platform == 'OpenBSD'