

# Generated at 2022-06-20 20:37:47.634409
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:37:51.379305
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    bsd = OpenBSDVirtual({})
    assert bsd.is_linux() == False
    assert bsd.is_freebsd() == False
    assert bsd.is_netbsd() == False
    assert bsd.is_openbsd() == True


# Generated at 2022-06-20 20:37:55.353651
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual({'kernel': 'OpenBSD'})
    assert virtual.virtual_facts['virtualization_type'] == ''
    assert virtual.virtual_facts['virtualization_role'] == ''
    assert virtual.virtual_facts['virtualization_tech_guest'] == set()
    assert virtual.virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:37:59.626490
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert isinstance(OpenBSDVirtualCollector._fact_class(), Virtual)

# Generated at 2022-06-20 20:38:03.345495
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    import pprint as pp
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_result = openbsd_virtual.get_virtual_facts()
    pp.pprint(openbsd_virtual_result)


# Generated at 2022-06-20 20:38:06.394496
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert(openbsd_virtual_collector._platform ==
           'OpenBSD')


# Generated at 2022-06-20 20:38:10.346208
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdvirtual = OpenBSDVirtual()
    assert openbsdvirtual.platform == 'OpenBSD'
    assert openbsdvirtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:38:14.278204
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_bsd_virtual_collector = OpenBSDVirtualCollector()
    assert open_bsd_virtual_collector._fact_class == OpenBSDVirtual
    assert open_bsd_virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-20 20:38:21.286477
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Explicitly test OpenBSDVirtual()
    f = OpenBSDVirtual()
    assert f.platform == 'OpenBSD'
    assert f.DMESG_BOOT == '/var/run/dmesg.boot'

    # Test OpenBSDVirtualCollector() by checking the platform attribute
    f = OpenBSDVirtualCollector()
    assert f._platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:28.916198
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    # Test empty values
    assert openbsd_virtual.virtual == {
        'role': '', 'type': ''
    }
    # Test empty set of technologies
    assert openbsd_virtual.virtualization_tech_host == set()
    assert openbsd_virtual.virtualization_tech_guest == set()
    # Test empty set of features
    assert openbsd_virtual.virtualization_features == set()
    # Test empty string of product name
    assert openbsd_virtual.virtualization_product_name == ''
    assert openbsd_virtual.virtualization_product_version == ''
    assert openbsd_virtual.virtualization_systems == []

# Generated at 2022-06-20 20:38:33.858225
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert issubclass(collector.get_fact_class(), OpenBSDVirtual)


# Generated at 2022-06-20 20:38:36.921055
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:38:48.704984
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()

    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

    assert openbsd_virtual.detect_virt_product('hw.product') == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': '',
    }

    assert openbsd_virtual.detect_virt_vendor('hw.vendor') == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': '',
    }

    assert open

# Generated at 2022-06-20 20:38:52.502131
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    openbsd_virtual = OpenBSDVirtual(module)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:38:55.178432
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:58.183247
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual.get_virtual_facts() is not None

# Generated at 2022-06-20 20:39:07.819043
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    example_product = 'VirtualBox'
    example_vendor = 'innotek GmbH'
    fact_collection = OpenBSDVirtualCollector('openbsd')
    fact_collection._dmesg_boot_info = "/var/run/dmesg.boot"
    fact_collection._proc_cpuinfo_info = "hw.product.virtualbox=1\nhw.vendor.virtualbox=1"

    expected_dict = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': example_product, 'virtualization_role': 'guest'}
    fact_collection._populate_virtual()

    for fact in expected_dict:
        assert fact_collection._facts[fact] == expected_dict[fact]

    fact_collection._dmesg_boot_info

# Generated at 2022-06-20 20:39:15.085399
# Unit test for constructor of class OpenBSDVirtual

# Generated at 2022-06-20 20:39:23.353140
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_system': '',
        'virtualization_product_name': '',
    }

    virtual_facts['virtualization_type'] = 'vmm'
    assert OpenBSDVirtual().get_virtual_facts() == virtual_facts

# Generated at 2022-06-20 20:39:28.286504
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual._platform == 'OpenBSD'
    assert openbsd_virtual._fact_class == OpenBSDVirtual
    assert openbsd_virtual._supported_facts == set([
        'virtualization_role',
        'virtualization_type',
        'virtualization_use_type',
        'virtual',
        'virtualization_tech_guest',
        'virtualization_tech_host',
    ])

# Generated at 2022-06-20 20:39:35.219616
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual({})
    assert virt.platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:37.789552
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class is not None
    assert virtual_collector._platform is not None


# Generated at 2022-06-20 20:39:48.586122
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_cases = dict()
    test_cases['hw.product', 'hw.vendor'] = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set([]),
        virtualization_tech_host=set([]),
    )
    test_cases['VMM', 'OpenBSD'] = dict(
        virtualization_type='vmm',
        virtualization_role='host',
        virtualization_tech_guest=set([]),
        virtualization_tech_host={'vmm'},
    )

    for sysctl_data, expected_facts in test_cases.items():
        virtual_facts = OpenBSDVirtual()
        virtual_facts._sysctl_data = dict(zip(sysctl_data, ['fake-data']))
        actual_facts = virtual

# Generated at 2022-06-20 20:39:49.945696
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual({})

    assert o.platform == 'OpenBSD'

# Generated at 2022-06-20 20:40:02.009692
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Define the virtual facts to return
    virtual_facts = {
        "virtualization_role": "guest",
        "virtualization_type": "qemu",
        "virtualization_tech": {"qemu"},
        "virtualization_tech_guest": {"qemu"},
        "virtualization_tech_host": {"qemu"}
    }

    # Define content of the dmesg.boot file

# Generated at 2022-06-20 20:40:12.208468
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:40:14.660993
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'


# Generated at 2022-06-20 20:40:16.382882
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual._platform == 'OpenBSD'
    assert virtual._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:40:27.572075
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt_collector = OpenBSDVirtualCollector()
    # Test running on virtual machine
    openbsd_virtual = OpenBSDVirtual(["vmm0 at mainbus0: SVM/RVI", "qemu0 at mainbus0"])
    facts = virt_collector.get_virtual_facts(openbsd_virtual)
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_product'] == 'qemu'
    assert facts['virtualization_tech_guest'] == set(['qemu'])
    assert facts['virtualization_tech_host'] == set(['vmm', 'qemu'])
    # Test running on physical machine
    openbsd_virtual = OpenBSDVirtual([])
    facts = virt_collect

# Generated at 2022-06-20 20:40:31.072609
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Instantiate object
    virtual_facts = OpenBSDVirtual()

    # Check name of the class
    assert virtual_facts.__class__.__name__ == "OpenBSDVirtual"


# Generated at 2022-06-20 20:40:46.557459
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Constructor test of class OpenBSDVirtual
    """

    openbsd_virtual = OpenBSDVirtual(None, OpenBSDVirtual.DMESG_BOOT)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-20 20:40:51.256207
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual.DMESG_BOOT = 'tests/unittests/utils/fixtures/dmesg.boot'
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(['vmm', 'openbsd']),
        'virtualization_tech_host': set(['vmm', 'openbsd'])
    }

# Generated at 2022-06-20 20:40:52.320345
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class is OpenBSDVirtual

# Generated at 2022-06-20 20:41:00.564937
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    This test is not exhaustive, but do *not* add a pytest marker because
    it reads `/var/run/dmesg.boot`
    """
    openbsd_virtual = OpenBSDVirtual(None)

    vmm_facts_dict = openbsd_virtual.get_virtual_facts()
    assert vmm_facts_dict['virtualization_type'] == 'vmm'
    assert vmm_facts_dict['virtualization_role'] == 'host'
    assert vmm_facts_dict['virtualization_tech_guest'] == {'vmm'}
    assert vmm_facts_dict['virtualization_tech_host'] == {'vmm'}

    # Do we care to test that with a dmesg.boot with no vmm line?

# Generated at 2022-06-20 20:41:05.269470
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    virtual_facts.populate()
    assert 'virtualization_type' in virtual_facts.facts
    assert 'virtualization_role' in virtual_facts.facts
    assert 'virtualization_tech_guest' in virtual_facts.facts
    assert 'virtualization_tech_host' in virtual_facts.facts

# Generated at 2022-06-20 20:41:07.909452
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:41:10.610485
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class is OpenBSDVirtual
    assert openbsd_virtual_collector._platform is 'OpenBSD'

# Generated at 2022-06-20 20:41:12.460788
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector().platform == 'OpenBSD'


# Generated at 2022-06-20 20:41:18.217439
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj
    assert isinstance(obj, OpenBSDVirtualCollector)
    assert hasattr(obj, '_fact_class')
    assert hasattr(obj, '_platform')
    assert obj._fact_class == OpenBSDVirtual
    assert obj._platform == 'OpenBSD'


# Generated at 2022-06-20 20:41:21.965056
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    '''Unit test for constructor of class OpenBSDVirtual'''
    virtual_facts_ins = OpenBSDVirtual()
    assert virtual_facts_ins.platform == 'OpenBSD'
    assert virtual_facts_ins.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:41:48.975019
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:41:50.689012
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:41:53.885119
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """ Constructor of OpenBSDVirtual  """
    openbsd_virtual = OpenBSDVirtual()
    # Set empty values as default
    assert openbsd_virtual.virtualization_type == ''
    assert openbsd_virtual.virtualization_role == ''

# Generated at 2022-06-20 20:41:57.179141
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd = OpenBSDVirtual()
    assert openbsd.platform == 'OpenBSD'
    assert openbsd.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:42:06.939020
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj.platform == 'OpenBSD'
    assert obj.fact_class == OpenBSDVirtual
    assert obj.fact_class().platform == obj.platform
    virtual_facts = obj.collect()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_product'] == ''
    assert virtual_facts['virtualization_vendor'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:42:09.948177
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()

    facts = virt.get_virtual_facts()

    assert facts['virtualization_type'] != ''
    assert facts['virtualization_role'] != ''

# Generated at 2022-06-20 20:42:13.830884
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:42:18.496497
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.name == 'OpenBSD'
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.virtualization_type == ''
    assert openbsd_virtual.virtualization_role == ''
    assert openbsd_virtual.virtualization_typ

# Generated at 2022-06-20 20:42:19.426212
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:42:26.217317
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector.__doc__.split()[0] == 'A'
    assert OpenBSDVirtualCollector._fact_class.platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:43:26.562205
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    module_mock = {}
    fake_args = {}
    openbsd_virtual = OpenBSDVirtual(module_mock, **fake_args)
    # TODO(bofh80) proper test cases
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:43:29.273501
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert (virtual_facts['virtualization_role'] == 'guest' or
            virtual_facts['virtualization_role'] == 'host')

# Generated at 2022-06-20 20:43:32.515782
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Create instance of OpenBSDVirtual fact on OpenBSD platform"""
    fact_subclass = OpenBSDVirtual()
    assert fact_subclass.platform == 'OpenBSD'


# Generated at 2022-06-20 20:43:35.865658
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    # check type of result
    assert type(openbsd_virtual_collector) == OpenBSDVirtualCollector
    # check if _fact_class is set to OpenBSDVirtual
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    # check if _platform is set to OpenBSD
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:37.703313
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:43:39.299769
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Returns an instance of OpenBSDVirtualCollector
    """
    return OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:43:40.787386
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_fact = OpenBSDVirtual()
    assert openbsd_virtual_fact is not None


# Generated at 2022-06-20 20:43:45.963864
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()

    # Test get_virtual_facts()
    setattr(virtual, '_sysctl_root_dir', './test/unit/module_utils/facts/virtual/openbsd/fake_sysctl_root_dir')
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert 'vmware_host_guest' in virtual_facts['virtualization_tech_guest']
    assert 'vmware_host_host' in virtual_facts['virtualization_tech_host']
    assert 'vmware_guest_guest' not in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:43:48.556843
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert(OpenBSDVirtualCollector)

# Generated at 2022-06-20 20:43:54.778617
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_test_facts = OpenBSDVirtual({})
    assert openbsd_test_facts.get_virtual_facts()['virtualization_role'] == ''
    assert openbsd_test_facts.get_virtual_facts()['virtualization_type'] == ''
    assert openbsd_test_facts.get_virtual_facts()['virtualization_tech_guest'] == ''
    assert openbsd_test_facts.get_virtual_facts()['virtualization_tech_host'] == ''

# Generated at 2022-06-20 20:45:09.539323
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """ Test creation of a OpenBSDVirtualCollector object
    """
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:45:12.929392
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    # Set empty values as default
    openbsd_virtual_facts = {'virtualization_type': '',
                             'virtualization_role': ''}

    assert openbsd_virtual.get_virtual_facts() == openbsd_virtual_facts

# Generated at 2022-06-20 20:45:14.315582
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'
    assert virtual_collector._fact_class is OpenBSDVirtual

# Generated at 2022-06-20 20:45:16.648061
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual_collector._fact_class, OpenBSDVirtual)
    assert isinstance(openbsd_virtual_collector.platform, str)


# Generated at 2022-06-20 20:45:26.588780
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    fake_sysctl = dict(
                       hw_product="VM VirtualBox",
                       hw_vendor="innotek GmbH"
                       )


# Generated at 2022-06-20 20:45:31.715339
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_facts = OpenBSDVirtualCollector()
    assert hasattr(openbsd_virtual_facts, '_fact_class')
    assert hasattr(openbsd_virtual_facts, '_platform')
    assert hasattr(openbsd_virtual_facts, 'collect')


# Generated at 2022-06-20 20:45:36.280834
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual({}).get_virtual_facts()
    assert isinstance(facts, dict)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:45:40.474956
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual._platform == 'OpenBSD'
    assert hasattr(openbsd_virtual, '_fail_on_errors')


# Generated at 2022-06-20 20:45:47.512346
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {}

    # Empty test_get_file_content
    def test_get_file_content(filename):
        return ''

    module = type('AnsibleModule', (object,), {
        'get_file_content': test_get_file_content,
        })

    virtual = OpenBSDVirtual(module=module)

    # Test get_virtual_facts
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''
    assert virtual_facts['virtualization_product_vendor'] == ''
    assert virtual_facts['virtualization_product_type'] == ''


# Generated at 2022-06-20 20:45:57.674451
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtualCollector()
    assert v.get_virtual_facts()["virtualization_type"] in (
        "vmm",
        "",
    ), "OpenBSDVirtualCollector.get_virtual_facts()['virtualization_type'] \
    not in ('vmm', '')"
    assert v.get_virtual_facts()["virtualization_role"] in (
        "host",
        "guest",
        "",
    ), "OpenBSDVirtualCollector.get_virtual_facts()['virtualization_role'] \
    not in ('host', 'guest', '')"