

# Generated at 2022-06-20 20:37:47.072661
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test with OpenBSD 6.4
    openbsd = OpenBSDVirtual({'gather_subset': '!all'})
    assert openbsd.platform == 'OpenBSD'
    assert openbsd.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:37:56.331283
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, mock_open
    from ansible_collections.ansible.community.plugins.module_utils.facts import virtual

    testcases = dict()

    # Test case 1: Run on OpenBSD hosting a FreeBSD guest
    testcases[1] = dict()

# Generated at 2022-06-20 20:38:00.050597
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_instance = OpenBSDVirtual()
    assert virtual_instance.platform == 'OpenBSD'
    assert virtual_instance.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:38:04.097243
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Test the constructor of class OpenBSDVirtualCollector"""
    openbsd_virt_col = OpenBSDVirtualCollector()
    assert openbsd_virt_col.platform == 'OpenBSD'
    assert openbsd_virt_col.fact_class.platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:15.473971
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import os
    from ansible.module_utils.facts.virtual import OpenBSDVirtual
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    paths = dict()
    paths['sys_class_hypervisor'] = '/sys/class/hypervisor/hypervisor'
    paths['sys_class_dmi'] = '/sys/class/dmi/id'
    paths['sys_devices_virtual'] = '/sys/devices/virtual'
    paths['proc_cpuinfo'] = '/proc/cpuinfo'

    # Test case #1 - dmesg.boot
    dmesg_boot = '''
vmm0 at mainbus0: VMX/EPT
'''
    expected_output_facts = dict()
    expected_output_

# Generated at 2022-06-20 20:38:19.396553
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert isinstance(collector._fact_class, OpenBSDVirtual)
    assert collector._platform == 'OpenBSD'


# Generated at 2022-06-20 20:38:22.654859
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:23.941245
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:25.945646
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_obj = OpenBSDVirtual(None)
    assert 'OpenBSD' == virtual_obj.platform

# Generated at 2022-06-20 20:38:32.480975
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """Test class OpenBSDVirtual get_virtual_facts method using a mocked dmesg.boot file"""
    # This test is disabled to be run consistently as it
    # requires access to a real OpenBSD machine.

    # Due to mocking there's no real guarantee about the results
    # Thus we assume that the system is not virtual.
    # TODO: setup a real OpenBSD system and make tests on it.
    from mock import patch
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    with patch.object(OpenBSDVirtual, 'DMESG_BOOT', './tests/dmesg/dmesg.boot'):
        results = OpenBSDVirtual().get_virtual_facts()
        # These are the facts we assume to be on OpenBSD
        assert results["virtualization_type"] == "OpenBSD"
       

# Generated at 2022-06-20 20:38:40.732945
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual().get_virtual_facts()
    assert isinstance(facts, dict)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:38:44.326918
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    x = OpenBSDVirtual({})

    for prop in ['virtualization_type', 'virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host']:
        assert hasattr(x, prop)

# Generated at 2022-06-20 20:38:46.733383
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    instance = OpenBSDVirtual()
    assert instance.platform == 'OpenBSD'
    assert instance.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:38:49.808647
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:38:54.426280
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert (openbsd_virtual._fact_class == OpenBSDVirtual)
    assert (openbsd_virtual._platform == 'OpenBSD')



# Generated at 2022-06-20 20:38:57.392621
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.virtualization_role == ''

# Generated at 2022-06-20 20:39:07.596480
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    # Vmware host
    vs = OpenBSDVirtual(dict(), 'hw.vendor=GenuineIntel\nhw.product=VMware Virtual Platform\n')
    vsf = vs.get_virtual_facts()
    assert vsf['virtualization_type'] == 'vmware'
    assert vsf['virtualization_role'] == 'host'
    assert vsf['virtualization_tech_host'] == {'vmware', 'vmm'}
    assert vsf['virtualization_tech_guest'] == set()
    assert vsf['virtualization_full_info']['hw.vendor'] == 'GenuineIntel'
    assert vsf['virtualization_full_info']['hw.product'] == 'VMware Virtual Platform'

    #

# Generated at 2022-06-20 20:39:09.643402
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_OpenBSDVirtual = OpenBSDVirtual()
    result = test_OpenBSDVirtual.get_virtual_facts()
    assert 'virtualization_type' in result

# Generated at 2022-06-20 20:39:11.898953
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-20 20:39:14.108067
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector.platform == 'OpenBSD'
    vc = OpenBSDVirtualCollector()
    assert vc._fact_class is OpenBSDVirtual
    assert vc._platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:22.097270
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    module = OpenBSDVirtualCollector._create_module()
    OpenBSDVirtualCollector(module)

# Generated at 2022-06-20 20:39:23.311457
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual(None)
    assert virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:25.735852
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.virtualization_type == ''
    assert openbsd_virtual.virtualization_role == ''


# Generated at 2022-06-20 20:39:33.686237
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    # Set empty values as default
    assert openbsd_virtual.virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual.virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual.virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual.virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:39:36.038138
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class == OpenBSDVirtual
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:37.420580
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert(virt.platform == 'OpenBSD')

# Generated at 2022-06-20 20:39:40.987365
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:39:43.709539
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Test the constructor of the OpenBSDVirtual class
    """
    openbsd_virtual = OpenBSDVirtual(dict())
    assert openbsd_virtual


# Generated at 2022-06-20 20:39:51.841262
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    openbsd_virtual_facts = OpenBSDVirtual()

    # Check if return value contains virtualization_tech_guest facts
    openbsd_virtual_facts_vtg = set([
        'virtualbox', 'bhyve', 'vmm', 'xen', 'kvm'
    ])

    # Check if return value contains virtualization_tech_host facts
    openbsd_virtual_facts_vth = set([
        'vmm'
    ])

    # Check if return value contains virtualization_role facts
    openbsd_virtual_facts_vr = set([
        ''
    ])

    # Check if return value contains virtualization_type facts
    openbsd_virtual_facts_vt = set([
        ''
    ])

    # Check if return value contains virtualization_product facts
    openbsd_virtual_facts_vp

# Generated at 2022-06-20 20:39:56.355250
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual
    assert openbsd_virtual.platform is OpenBSDVirtual.platform
    assert openbsd_virtual.DMESG_BOOT is OpenBSDVirtual.DMESG_BOOT


# Generated at 2022-06-20 20:40:14.969862
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of class OpenBSDVirtual
    virtual = OpenBSDVirtual()
    # Assert that the virtualization_type is empty
    assert virtual.get_virtual_facts()['virtualization_type'] == ''
    assert virtual.get_virtual_facts()['virtualization_role'] == ''
    # Assert that the list of virtualization_tech_guest is empty
    assert len(virtual.get_virtual_facts()['virtualization_tech_guest']) == 0
    # Assert that the list of virtualization_tech_host is empty
    assert len(virtual.get_virtual_facts()['virtualization_tech_host']) == 0

# Generated at 2022-06-20 20:40:17.197096
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:40:24.508378
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    ovs = OpenBSDVirtual()
    assert ovs.get_virtual_facts() == {
            'virtualization_role': '',
            'virtualization_type': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
            'virtualization_product_vendor': {},
            'virtualization_product_version': {},
            'virtualization_product_name': {}
    }

# Generated at 2022-06-20 20:40:29.125060
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._collector_platform == 'OpenBSD'



# Generated at 2022-06-20 20:40:30.403200
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), OpenBSDVirtualCollector)

# Generated at 2022-06-20 20:40:35.881449
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert hasattr(virtual_collector, '_platform')
    assert virtual_collector._platform == 'OpenBSD'
    assert hasattr(virtual_collector, '_fact_class')
    assert virtual_collector._fact_class.__name__ == 'OpenBSDVirtual'

# Generated at 2022-06-20 20:40:37.195787
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-20 20:40:39.176360
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual({})
    assert o.platform == "OpenBSD"

# Generated at 2022-06-20 20:40:46.387056
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual._sysctl_virtual = {
        'hw.vendor': "''",
        'hw.product': "''",
    }

    OpenBSDVirtual.DMESG_BOOT = "vmm0 at mainbus0: SVM/RVI"
    test_OpenBSDVirtual = OpenBSDVirtual()
    assert test_OpenBSDVirtual.get_virtual_facts() == {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'vmm'},
    }

# Generated at 2022-06-20 20:40:48.507331
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt_facts = OpenBSDVirtual()
    assert virt_facts is not None


# Generated at 2022-06-20 20:41:12.146911
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Check if class returns correct platform and fact class."""
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:41:16.647726
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    from ansible.module_utils.facts import FactCollector

    # Test with '/proc/cpuinfo' content
    virt = OpenBSDVirtual(FactCollector())

    # Test with '/proc/cmdline' content
    virt = OpenBSDVirtual(FactCollector())

# Generated at 2022-06-20 20:41:26.619826
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """Test method OpenBSDVirtual.get_virtual_facts() with the following conditions:
        - if the result of running 'sysctl hw.vendor' equals 'Xen';
          then the virtualization_type equals 'xen' and virtualization_role equals 'guest';
        - if the result of running 'sysctl hw.vendor' equals 'innotek GmbH';
          then the virtualization_type equals 'virtualbox' and virtualization_role equals 'guest';
    """
    my_OpenBSDVirtual = OpenBSDVirtual()
    virtual_facts = {}
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_type'] = ''
    assert my_OpenBSDVirtual.get_virtual_facts('hw.vendor=Xen') == virtual_facts
    virtual_facts['virtualization_type']

# Generated at 2022-06-20 20:41:34.717450
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_collector = OpenBSDVirtualCollector()
    assert openbsd_collector._platform == 'OpenBSD'
    assert openbsd_collector._fact_class._platform == 'OpenBSD'
    assert openbsd_collector._fact_class.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:41:38.407358
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts_dict = {}
    fact_obj = OpenBSDVirtual()

    # Test virtualization_type and virtualization_role
    facts_dict = fact_obj.get_virtual_facts()
    assert not facts_dict['virtualization_type'] in ['host', 'guest']

# Generated at 2022-06-20 20:41:43.014420
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:41:54.623451
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test with "detect_virtualization, detect_virtual_fact_caches" set to False
    virtual_collector = OpenBSDVirtualCollector(detect_virtualization=False,
                                                detect_virtual_fact_caches=False)
    assert virtual_collector.platform == 'OpenBSD', \
        "virtual_collector: Invalid platform"
    assert virtual_collector.virtual == '', "virtual_collector: virtual is not empty"
    assert virtual_collector.virtual_command == '', \
        "virtual_collector: virtual_command is not empty"
    assert virtual_collector.virtual_fact_class == OpenBSDVirtual, \
        "virtual_collector: Incorrect fact class set"

# Generated at 2022-06-20 20:42:00.921405
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert hasattr(Virtual, 'platform')
    assert hasattr(Virtual, 'get_virtual_facts')

    assert hasattr(OpenBSDVirtual, 'platform')
    assert hasattr(OpenBSDVirtual, 'get_virtual_facts')

    assert 'OpenBSD' == OpenBSDVirtual.platform


# Test code to execute module as a standalone
# Returns JSON that can be loaded into a dict

# Generated at 2022-06-20 20:42:04.166452
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:42:15.033577
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    def is_guest_tech(function):
        if function == 'vmm':
            return 'guest'
        elif function == 'jail':
            return 'guest'
        else:
            return 'host'


# Generated at 2022-06-20 20:42:46.431187
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:42:57.485112
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_virtual_facts = {
        #'virtualization_type': '',
        'virtualization_role': ''
    }
    test_virtualization_tech_host_facts = set()
    test_virtualization_tech_guest_facts = set()

    test_virtualization_tech_host_facts.add('vmm')
    test_virtual_facts['virtualization_tech_host'] = test_virtualization_tech_host_facts
    test_virtual_facts['virtualization_tech_guest'] = test_virtualization_tech_guest_facts
    test_virtual_facts['virtualization_type'] = 'vmm'
    test_virtual_facts['virtualization_role'] = 'host'

    assert OpenBSDVirtual.get_virtual_facts(None) == test_virtual_facts

# Generated at 2022-06-20 20:43:09.270775
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Create an instance of class OpenBSDVirtual and check if
    - it is an instance of Virtual
    - it is an instance of OpenBSDVirtual
    - its platform is set correctly
    - it has certain methods overridden
    """
    openbsd_virtual = OpenBSDVirtual()
    assert isinstance(openbsd_virtual, Virtual)
    assert isinstance(openbsd_virtual, VirtualSysctlDetectionMixin)
    assert openbsd_virtual.platform == 'OpenBSD'

    assert openbsd_virtual._platform == 'OpenBSD'
    assert openbsd_virtual._fact_class == OpenBSDVirtual
    assert openbsd_virtual._fact_class._platform == 'OpenBSD'
    assert openbsd_virtual._collector_class == OpenBSDVirtualCollector
    assert openbsd_virtual._collector_class._

# Generated at 2022-06-20 20:43:12.607971
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt_facts = OpenBSDVirtual(None)
    assert isinstance(virt_facts, Virtual)
    assert isinstance(virt_facts, VirtualSysctlDetectionMixin)
    assert virt_facts.platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:21.531525
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # tests on OpenBSD 6.4 GENERIC#1153 amd64
    openbsd_virtual = OpenBSDVirtual({}, {})
    openbsd_virtual.facts['kernel'] = 'OpenBSD'
    openbsd_virtual.get_file_content = lambda path: get_file_content('/proc/cpuinfo')
    virtual_facts = openbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-20 20:43:27.718578
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert isinstance(obj, OpenBSDVirtualCollector)
    assert 'hw.model' in obj._sysctl_info
    assert 'hw.product' in obj._sysctl_info
    assert 'hw.vendor' in obj._sysctl_info
    assert obj._fact_class is not None
    assert obj._platform is not None

# Generated at 2022-06-20 20:43:31.206866
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Simple test case to construct class OpenBSDVirtualCollector
    """
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:43:40.596536
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_input_data_1 = {
        'hw.machine_arch': 'x86_64',
        'hw.product': '0x15ad:0x0405',
        'hw.vendor': 'QEMU'
    }

    expected_result_1 = {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['qemu']),
        'virtualization_type': 'hvm',
        'virtualization_role': ''
    }

    test_input_data_2 = {
        'hw.machine_arch': 'x86_64',
        'hw.product': '0x15ad:0x0405',
        'hw.vendor': 'QEMU'
    }


# Generated at 2022-06-20 20:43:44.171789
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    v = OpenBSDVirtualCollector()
    assert v.platform == 'OpenBSD'
    assert v.fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:43:46.961613
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:44:54.340626
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual

# Generated at 2022-06-20 20:44:56.533204
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual().get_virtual_facts()
    assert type(facts) is dict
    assert not (facts['virtualization_type'] or facts['virtualization_role'])

# Generated at 2022-06-20 20:44:58.709823
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Test case for get_virtual_facts of OpenBSDVirtual class
    :return:
    """
    test_obj = OpenBSDVirtual()
    test_obj.get_virtual_facts()



# Generated at 2022-06-20 20:45:10.042722
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_data_dir = 'tests/unit/module_utils/facts/virtual/OpenBSD/test_data'

    def get_file_content_mock(filename):
        return get_file_content('%s/%s' % (test_data_dir, filename))

    virtual = OpenBSDVirtual()
    virtual._get_file_content = get_file_content_mock
    facts = virtual.get_all_facts()
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'vmm'
    assert 'vmm' in facts['virtualization_tech_guest']

    virtual = OpenBSDVirtual()
    virtual.sysctl_sysctl_name = 'unittest_sysctl_name'

# Generated at 2022-06-20 20:45:11.175968
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Test class constructor by initiating the class and checking for idempotency"""
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:45:14.812252
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_collector = OpenBSDVirtualCollector()
    assert openbsd_collector._platform == 'OpenBSD'
    assert isinstance(openbsd_collector._fact_class, dict)
    assert 'OpenBSDVirtual' in openbsd_collector._fact_class
    assert 'Virtual' in openbsd_collector._fact_class


# Generated at 2022-06-20 20:45:16.221392
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.data['virtualization_type'] == ''
    assert virtual.data['virtualization_role'] == ''

# Generated at 2022-06-20 20:45:23.533780
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test = OpenBSDVirtual()

    virtual_facts = test.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:45:24.801515
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:45:26.766987
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'