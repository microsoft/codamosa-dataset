

# Generated at 2022-06-20 20:37:47.733046
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Test the Virtual constructor.
    """
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:37:49.106823
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:37:53.291407
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualCollector
    obj = OpenBSDVirtualCollector()
    assert obj.__class__ == OpenBSDVirtualCollector


# Generated at 2022-06-20 20:37:54.742698
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert type(obj).__name__ == 'OpenBSDVirtualCollector'

# Generated at 2022-06-20 20:37:57.678064
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert c._fact_class is not None
    assert c._platform is not None

# Generated at 2022-06-20 20:37:59.514563
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-20 20:38:03.650496
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # This test is just a sanity check
    vb = OpenBSDVirtual()
    fake_facts = vb.get_virtual_facts()
    assert(fake_facts['virtualization_type'] == '')
    assert(fake_facts['virtualization_role'] == '')

# Generated at 2022-06-20 20:38:15.144254
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import tempfile
    import pytest

    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualCollector
    from ansible.module_utils.facts.virtual.sysctl import get_sysctl_facts

    sysctl_facts = get_sysctl_facts()
    with tempfile.NamedTemporaryFile() as temp:
        temp.write(b'vmm0 at mainbus0: SVM/RVI')
        temp.seek(0)
        dmesg_boot = temp.name
        virtual = OpenBSDVirtual({}, sysctl_facts, dmesg_boot=dmesg_boot)

        virtual_facts = virtual.get_virtual_facts()

# Generated at 2022-06-20 20:38:26.874801
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    fake_platform = 'OpenBSD'
    expected_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm', 'vmware', 'vbox'])
    }

    mock_get_file_content = MagicMock()
    mock_get_file_content.return_value = (
        "vmm0 at mainbus0: SVM/RVI\n"
        "vmware0 at pci0 dev 23 function 0: VMware Virtual IDE CDROM Drive\n"
        "vboxguest0 at pci0 dev 26 function 0: VBoxGuest\n"
    )
    mock_open = mock_open(read_data="hw.product=0x0001")



# Generated at 2022-06-20 20:38:28.809523
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert(openbsd_virtual.get_virtual_facts() == {})

# Generated at 2022-06-20 20:38:32.925461
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_obj = OpenBSDVirtual()
    virtual_obj.get_virtual_facts()

# Generated at 2022-06-20 20:38:35.915395
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector_class_instance = OpenBSDVirtualCollector()
    assert virtual_collector_class_instance._fact_class == OpenBSDVirtual
    assert virtual_collector_class_instance._platform == 'OpenBSD'


# Generated at 2022-06-20 20:38:37.958273
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector('')


# Generated at 2022-06-20 20:38:40.430153
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:38:43.301892
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._fact_class is OpenBSDVirtual
    assert vc._platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:52.745367
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:38:54.475494
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector().get_virtual_facts(), dict)

# Generated at 2022-06-20 20:39:00.900644
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    collector = OpenBSDVirtual()
    test_cases = [
        ({},
         {'virtualization_type': '', 'virtualization_role': '',
          'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}),
    ]

    for args, result in test_cases:
        assert collector.get_virtual_facts(*args) == result, "%s != %s" % (collector.get_virtual_facts(args), result)

# Generated at 2022-06-20 20:39:11.796886
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_Virtual = OpenBSDVirtual()

    # Positive test case:
    # In case of a physical host
    virtual_facts_physical = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_product_name': '',
        'virtualization_product_version': '',
    }
    assert test_Virtual.get_virtual_facts() == virtual_facts_physical

    # Test cases for a virtual host running as a guest

# Generated at 2022-06-20 20:39:14.146974
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == OpenBSDVirtualCollector._platform
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtualCollector._fact_class

# Generated at 2022-06-20 20:39:23.315608
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector.platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:25.735887
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector(None, None, None, None)
    assert obj._fact_class == OpenBSDVirtual
    assert obj._platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:29.509838
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:33.162198
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual, VirtualCollector) is True
    assert isinstance(openbsd_virtual, OpenBSDVirtualCollector) is True

# Generated at 2022-06-20 20:39:35.215788
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:37.631004
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:41.241878
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.__class__.__name__ == 'OpenBSDVirtual'


# Generated at 2022-06-20 20:39:43.935560
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    v = OpenBSDVirtualCollector()
    assert isinstance(v, OpenBSDVirtualCollector)
    assert isinstance(v._fact_class, OpenBSDVirtual)

# Generated at 2022-06-20 20:39:46.838640
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_collector = OpenBSDVirtualCollector()
    assert openbsd_collector._platform == 'OpenBSD'
    assert openbsd_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:39:53.948833
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    class _Hardware:
        def __init__(self, uname_result=('OpenBSD', '', '6.0')):
            self.uname_result = uname_result

    virtual_collector = OpenBSDVirtualCollector()
    virtual_collector._hardware = _Hardware()
    assert virtual_collector._platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:40:06.041323
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class OpenBSDVirtual'''
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:40:15.397074
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:40:26.601091
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual.detect_virt_product = lambda x: {'virtualization_type': 'xen',
                                                    'virtualization_role': 'guest',
                                                    'virtualization_tech_guest': set(['xen']),
                                                    }
    OpenBSDVirtual.detect_virt_vendor = lambda x: {'virtualization_type': 'openvz',
                                                   'virtualization_role': 'host',
                                                   'virtualization_tech_host': set(['openvz']),
                                                   }

    # Virtualization type and role are empty by default
    result = OpenBSDVirtual(None, None, OpenBSDVirtual.DMESG_BOOT).get_virtual_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''
   

# Generated at 2022-06-20 20:40:37.974462
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:40:41.854984
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:40:46.274737
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Unit test of constructor of class OpenBSDVirtualCollector
    """
    # Test instantiation
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:40:48.108222
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    try:
        OpenBSDVirtualCollector()
    except Exception as e:
        assert False, "Failed to instantiate class OpenBSDVirtualCollector"

# Generated at 2022-06-20 20:40:50.844921
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """ This is a private method and is tested through the
    VirtualizationCollector """
    pass

# Generated at 2022-06-20 20:40:52.283364
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual() != None

# Generated at 2022-06-20 20:40:54.803893
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert isinstance(o, VirtualCollector)
    assert o._platform == 'OpenBSD'

# Generated at 2022-06-20 20:41:07.740804
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()

    assert collector.platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:41:10.451424
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts_obj = OpenBSDVirtual()
    assert virtual_facts_obj.platform == 'OpenBSD'
    assert virtual_facts_obj.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:41:13.284777
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''


# Generated at 2022-06-20 20:41:17.659049
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual('OpenBSD')
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-20 20:41:19.688341
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    oh = OpenBSDVirtual()
    assert oh.virtualization_type == ''
    assert oh.virtualization_role == ''


# Generated at 2022-06-20 20:41:23.256468
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    oobd = OpenBSDVirtual({})
    assert oobd.platform == 'OpenBSD'
    assert oobd.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:41:26.697061
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Constructor of class VirtualCollector is responsible for
    creating a singleton object of class OpenBSDVirtual
    """
    virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(virtual_collector._fact_class(),
                      OpenBSDVirtual)

# Generated at 2022-06-20 20:41:39.625926
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:41:41.441813
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = {}
    OpenBSDVirtualCollector(facts, None)

# Generated at 2022-06-20 20:41:46.969152
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test if OpenBSDVirtual class is type of Virtual
    assert issubclass(OpenBSDVirtual, Virtual)
    # Test create object of OpenBSDVirtual class
    bsdVirtual = OpenBSDVirtual()
    # Test if it's instance of OpenBSDVirtual
    assert isinstance(bsdVirtual, OpenBSDVirtual)

# Generated at 2022-06-20 20:42:11.412805
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'


# Generated at 2022-06-20 20:42:12.314436
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual().platform == 'OpenBSD'

# Generated at 2022-06-20 20:42:16.465296
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    '''Unit test for constructor of class OpenBSDVirtualCollector'''
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual_collector._fact_class, OpenBSDVirtual)
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:42:19.388910
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    '''Validate the constructor for class OpenBSDVirtual'''

    virtual_object = OpenBSDVirtual()
    assert virtual_object.platform == 'OpenBSD'
    assert virtual_object.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:42:23.652787
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-20 20:42:34.545943
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd = OpenBSDVirtualCollector()

    # Test vmm(4) host
    with open(OpenBSDVirtual.DMESG_BOOT, 'w+') as f:
        f.write('vmm0 at mainbus0: VMX/EPT\n')
    d = openbsd.get_virtual_facts()
    assert 'virtualization_type' in d
    assert d['virtualization_type'] == 'vmm'
    assert 'virtualization_role' in d
    assert d['virtualization_role'] == 'host'
    assert 'virtualization_tech_guest' in d
    assert 'virtualization_tech_host' in d
    assert 'vmm' in d['virtualization_tech_host']
    assert d['virtualization_tech_guest'] == set()

# Generated at 2022-06-20 20:42:42.886230
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:42:48.414984
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Set test data
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_product_serial': '',
        'virtualization_product_uuid': '',
        'virtualization_host': {},
        'virtualization_guest': {},
        'virtualization_tech_guest': '',
        'virtualization_tech_host': ''
    }

# Generated at 2022-06-20 20:42:51.860717
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:42:56.257318
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    `_fact_class` must be set to `OpenBSDVirtual` and `_platform` must be set to `OpenBSD`.
    """
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:51.264458
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'


# Generated at 2022-06-20 20:43:56.251573
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_fact = OpenBSDVirtual()
    response = openbsd_virtual_fact.get_virtual_facts()
    assert response == {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(['vmm']),
        'virtualization_tech_host': set(['vmm']),
        'is_virtual': True
    }

# Generated at 2022-06-20 20:44:01.753876
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    testobj = OpenBSDVirtual()
    assert testobj.virtualization_type == ''
    assert testobj.virtualization_role == ''
    assert 'virtualization_tech_guest' not in testobj.facts
    assert 'virtualization_tech_host' not in testobj.facts

# Generated at 2022-06-20 20:44:08.844687
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSD_virtual = OpenBSDVirtual()
    test_object = dict(virtualization_type='', virtualization_role='', virtualization_tech_guest=set(), virtualization_tech_host=set())
    expected_object = dict(virtualization_type='', virtualization_role='', virtualization_tech_guest=set(), virtualization_tech_host=set())
    result = OpenBSD_virtual.get_virtual_facts()
    assert result == expected_object

# Generated at 2022-06-20 20:44:13.367821
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Unit test for constructor of class OpenBSDVirtualCollector
    """
    # Instantiate an instance of the OpenBSDVirtualCollector class
    obj = OpenBSDVirtualCollector()

    # Assert that obj is an instance of the OpenBSDVirtualCollector class
    assert isinstance(obj, OpenBSDVirtualCollector)


# Generated at 2022-06-20 20:44:16.458667
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.get_virtual_facts()['virtualization_type'] == ''
    assert virtual_collector.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-20 20:44:24.843411
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class OpenBSDVirtual"""
    # Create a class instance
    virtual_obj = OpenBSDVirtual()
    # Get the virtual facts
    virtual_facts = virtual_obj.get_virtual_facts()
    assert virtual_facts == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    # Assert empty values are set
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:44:26.444960
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj.platform == 'OpenBSD'
    assert obj.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:44:27.617422
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:44:28.146346
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    pass



# Generated at 2022-06-20 20:46:55.686791
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.dmesg_regex is None
    assert virtual.dmesg_cmd is None
    assert virtual.dmidecode_regex is None
    assert virtual.dmidecode_cmd is None
    assert virtual.virt_what_regex is None
    assert virtual.virt_what_cmd is None
    assert virtual.sysctl_vm_guest is None
    assert virtual.sysctl_cmd is None
    assert virtual.lscpu_regex is None
    assert virtual.lscpu_cmd is None
    assert virtual.vendor_fact_name is None
    assert virtual.product_fact_name is None
    assert virtual.sys_vendor_fact_name is None
    assert virtual.sys_product_fact_name is None

# Generated at 2022-06-20 20:46:59.552597
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    virtual_facts = openbsd_virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:47:00.658047
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:47:11.717819
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Check in case of no data is passed
    result = OpenBSDVirtual({})

    # Check in case of no details are passed
    result = OpenBSDVirtual({'virtualization_type': ' '})
    assert result.get_virtual_facts() == {'virtualization_type': '',
                                          'virtualization_role': '',
                                          'virtualization_tech_guest': set(),
                                          'virtualization_tech_host': set()}

    # Check for virtualization type
    result = OpenBSDVirtual({'virtualization_type': 'vmm'})

# Generated at 2022-06-20 20:47:12.853623
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert isinstance(OpenBSDVirtual(), Virtual)


# Generated at 2022-06-20 20:47:14.602325
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:47:21.902643
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    result_expected = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm'])
    }
    assert (OpenBSDVirtual().get_virtual_facts() == result_expected)

# Generated at 2022-06-20 20:47:26.255894
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'

# Generated at 2022-06-20 20:47:37.313803
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with bare-metal
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_technologies'] == set()
    assert virtual_facts['virtualization_technologies_guest'] == set()
    assert virtual_facts['virtualization_technologies_host'] == set()

    # Test with VMM
    virtual_facts = OpenBSDVirtual(DMESG_BOOT='tests/unit/module_utils/facts/virtual/openbsd/dmesg.vmm.boot').get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-20 20:47:40.834253
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'
