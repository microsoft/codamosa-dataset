

# Generated at 2022-06-20 20:37:48.571327
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Test constructor of OpenBSDVirtual."""
    facts_obj = OpenBSDVirtual()

    vt = facts_obj.get_virtual_facts()['virtualization_type']
    assert vt == ''

# Generated at 2022-06-20 20:37:51.523263
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Case 1: Check default values of empty Virtual object
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.virtualization_type == ''
    assert openbsd_virtual.virtualization_role == ''

# Generated at 2022-06-20 20:37:58.122945
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual({})
    # Test CheckMethods
    assert not virtual_facts.is_linux()
    assert virtual_facts.is_openbsd()
    assert not virtual_facts.is_netbsd()
    assert not virtual_facts.is_freebsd()
    assert not virtual_facts.is_aix()
    assert not virtual_facts.is_hpux()
    assert not virtual_facts.is_solaris()
    assert not virtual_facts.is_vmkernel()
    assert not virtual_facts.is_xen()
    assert not virtual_facts.is_hyperv()
    assert not virtual_facts.is_kvm()
    assert not virtual_facts.is_virtualbox()

# Generated at 2022-06-20 20:38:07.526624
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_virt_facts = {'virtualization_type': '', 'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set()}

    OpenBSDVirtual.DMESG_BOOT = './tests/unittests/fixtures/virtual/openbsd_dmesg_boot'
    OpenBSDVirtual.SYSCTL_HW = './tests/unittests/fixtures/virtual/openbsd_sysctl_hw'
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts == test_virt_facts

# Generated at 2022-06-20 20:38:17.288543
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:38:27.635907
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    def mock_cmd(cmd, *args, **kwargs):
        if cmd == OpenBSDVirtual.DMESG_BOOT:
            return """
vmm0 at mainbus0: SVM/RVI
""".strip()
        elif cmd == 'sysctl hw.product':
            return """
hw.product=KVM
""".strip()
        elif cmd == 'sysctl hw.vendor':
            return """
hw.vendor=QEMU
""".strip()

    virtual_facts = OpenBSDVirtual(mock_cmd).get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert 'vmm' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:38:32.666356
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from collections import namedtuple
    OpenBSDVirtual.DictObject = namedtuple('DictObject', ['product', 'vendor'])
    openbsd_virtual = OpenBSDVirtual()
    results = openbsd_virtual.get_virtual_facts()
    assert results['virtualization_type'] == ''
    assert results['virtualization_role'] == ''

# Generated at 2022-06-20 20:38:33.573215
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:38:38.605228
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert set == type(openbsd_virtual_facts.get_virtual_facts()['virtualization_tech_guest'])
    assert set == type(openbsd_virtual_facts.get_virtual_facts()['virtualization_tech_host'])

# Generated at 2022-06-20 20:38:42.529592
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    result = virtual_collector.get_all_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''

# Generated at 2022-06-20 20:38:51.914682
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module = 'hw.vendor'
    mock_lines = (
        "GenuineIntel",
        "foobar",
        "hw.product=HVM domU",
    )
    openbsd = OpenBSDVirtualCollector()
    openbsd.populate_sysctl_facts(module, mock_lines)

    assert openbsd.facts == dict(virtualization_type='vmm',
                                 virtualization_role='guest')

# Constructor of class OpenBSDVirtual

# Generated at 2022-06-20 20:38:57.098143
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()

    # Assert some virtual_facts exist
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:39:00.392734
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    vm = OpenBSDVirtual()
    assert openbsd.platform == 'OpenBSD'
    assert openbsd.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-20 20:39:03.497438
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fc = OpenBSDVirtualCollector()
    assert fc.platform == 'OpenBSD'
    assert fc._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:39:13.265688
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bsd_virtual_obj = OpenBSDVirtual()
    ifs = set()
    ht = set()
    gt = set()
    dmesg_boot = '''
Copyright (c) 1982, 1986, 1989, 1991, 1993
	The Regents of the University of California.  All rights reserved.
Copyright (c) 1995-2018 OpenBSD. All rights reserved.  https://www.OpenBSD.org

OpenBSD 6.4 (GENERIC.MP) #1: Thu Sep 27 14:20:11 MDT 2018
        dalecki@amd64.openbsd.org:/usr/src/sys/arch/amd64/compile/GENERIC.MP
real mem = 64414976
The operating system has halted.
Please press any key to reboot.
'''
    # Host VMware:

# Generated at 2022-06-20 20:39:14.441575
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_fact = OpenBSDVirtual()
    assert virtual_fact.platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:18.445175
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Check if output of get_virtual_facts of class OpenBSDVirtual
    # is a dictionary
    OpenBSDVirtualCollector().get_virtual_facts()

# Generated at 2022-06-20 20:39:22.936931
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual(dict()).virtualization_type == ''
    assert OpenBSDVirtual(dict()).virtualization_role == ''
    assert OpenBSDVirtual(dict()).virtualization_tech_guest == set()
    assert OpenBSDVirtual(dict()).virtualization_tech_host == set()

# Generated at 2022-06-20 20:39:26.332651
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None, 'OpenBSD')
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:39:30.285057
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual(None)
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:39:39.459320
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_fact_collector = OpenBSDVirtualCollector()
    assert virtual_fact_collector._platform == 'OpenBSD'
    assert virtual_fact_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:44.206657
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = OpenBSDVirtualCollector.collect()
    assert facts['virtualization_type'] is not None
    assert facts['virtualization_role'] is not None
    assert facts['virtualization_tech_guest'] is not None
    assert facts['virtualization_tech_host'] is not None

# Generated at 2022-06-20 20:39:47.079281
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:50.646357
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector.fact_class.platform == 'OpenBSD'


# Generated at 2022-06-20 20:39:53.058152
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:40:05.137585
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Define behavior of function get_file_content

# Generated at 2022-06-20 20:40:08.460399
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual('aci1')
    assert o.name == 'aci1'
    assert o.platform == 'OpenBSD'
    assert o.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:40:14.474662
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    module = AnsibleModule(argument_spec=dict())
    module.exit_json = MagicMock(return_value=dict(ansible_facts=dict()))

    virtual = OpenBSDVirtual(module=module)
    detected_facts = virtual.detect()
    assert detected_facts['virtualization_role'] == ''
    assert detected_facts['virtualization_type'] == ''
    assert detected_facts['virtualization_tech_guest'] == set()
    assert detected_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:40:17.356701
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:40:19.647244
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtualCollector()
    assert v.platform == 'OpenBSD'


# Generated at 2022-06-20 20:40:42.559827
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    mock_module = VirtualCollector.MockModule({})
    openbsd_virtual = OpenBSDVirtual(mock_module)
    mock_module.exit_json = lambda v: None
    openbsd_virtual._get_dmesg = lambda: ('vmm0 at mainbus0: VMX/EPT\n'
                                          'vioif0 at vmm0\n')
    openbsd_virtual._get_product = lambda: 'VMware Virtual Platform'
    openbsd_virtual._get_vendor = lambda: 'VMware, Inc.'
    virtual_facts = openbsd_virtual.get_virtual_facts()

    assert 'hw' in virtual_facts['virtualization_type']
    assert 'guest' in virtual_facts['virtualization_role']

# Generated at 2022-06-20 20:40:46.280078
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Get expected results from the collect method
    collector = OpenBSDVirtualCollector()
    results = collector.collect(None, None)
    # Instantiate an object of class OpenBSDVirtual and test its method
    openbsd_virtual = OpenBSDVirtual()
    assert results == openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:40:50.601186
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    obj_virtual = OpenBSDVirtual()
    assert obj_virtual
    assert obj_virtual.platform == 'OpenBSD'
    assert obj_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:41:00.014161
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase
    from ansible_collections.ansible.community.plugins.module_utils import basic

    class TestCase(ModuleTestCase):
        # Mocked class for testing
        class MockedOpenBSDVirtual(OpenBSDVirtual):
            def detect_virt_product(self, product):
                return {}

            def detect_virt_vendor(self, vendor):
                return {}

            def get_file_content(self, path):
                return ''

        def setUp(self):
            super(TestCase, self).setUp()
            self.mocked_obj = self.MockedOpenBSDVirtual()

        def test_failure_case(self):
            self.mocked_obj._platform

# Generated at 2022-06-20 20:41:10.212040
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl = {'hw.product': 'VirtualBox', 'hw.vendor': 'QEMU', 'machdep.vm_guest': 0}
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vbox'
    assert 'vbox' in virtual_facts['virtualization_tech_guest']
    assert 'QEMU' in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type_role'] == 'guest/vbox'
    assert 'vbox' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:41:12.160762
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # environ
    assert OpenBSDVirtual().get_platform() == 'OpenBSD'

# Generated at 2022-06-20 20:41:18.207392
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    collector = OpenBSDVirtualCollector()
    virtual_facts = collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    virtual_tech_host = virtual_facts['virtualization_tech_host']
    assert 'vmm' in virtual_tech_host

# Generated at 2022-06-20 20:41:27.787432
# Unit test for constructor of class OpenBSDVirtual

# Generated at 2022-06-20 20:41:39.743451
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_data = dict()
    test_data['hw.vendor'] = 'Cisco Systems Inc'
    test_data['hw.product'] = 'UCSC-C240-M4SX, BIOS R1UC140A 02/12/2017'
    virtual_facts = dict()
    virtual_facts['virtualization_type'] = 'vmm'
    virtual_facts['virtualization_role'] = 'host'
    virtual_facts['virtualization_tech_guest'] = {'kvm'}
    virtual_facts['virtualization_tech_host'] = {'vmm'}
    test_OpenBSDVirtual = OpenBSDVirtual(test_data)
    test_OpenBSDVirtual.DMESG_BOOT = './tests/unittests/files/dmesg.boot'

# Generated at 2022-06-20 20:41:40.850999
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    cl = OpenBSDVirtualCollector()
    assert cl._platform == 'OpenBSD'

# Generated at 2022-06-20 20:42:14.732534
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_data = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    kvm_data = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set(),
    }

    bhyve_data = {
        'virtualization_type': 'bhyve',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'bhyve'},
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-20 20:42:16.787786
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virt = OpenBSDVirtualCollector()
    assert virt._fact_class._platform == 'OpenBSD'


# Generated at 2022-06-20 20:42:17.646289
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual is not None


# Generated at 2022-06-20 20:42:20.098423
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class is OpenBSDVirtual
    assert openbsd_virtual_collector._platform is 'OpenBSD'

# Generated at 2022-06-20 20:42:24.888832
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Create an instance of OpenBSDVirtualCollector and verify it's an instance of
    VirtualCollector.
    """
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual_collector, VirtualCollector)

# Generated at 2022-06-20 20:42:26.779137
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd = OpenBSDVirtual()
    assert openbsd.system == 'OpenBSD'


# Generated at 2022-06-20 20:42:34.831678
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual(None)
    openbsd_virtual.product_name = 'VirtualBox'
    openbsd_virtual.get_sysctl_data = lambda x: ''
    facts = openbsd_virtual.get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_product_name'] == 'VirtualBox'
    assert facts['virtualization_tech_guest'] == set([])
    assert facts['virtualization_tech_host'] == set([])

# Generated at 2022-06-20 20:42:38.183401
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_subtype == ''
    assert virtual.virtualization_system == ''


# Generated at 2022-06-20 20:42:43.325014
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == ''
    assert set(virtual_facts['virtualization_tech_guest']) == set(['vmm'])
    assert set(virtual_facts['virtualization_tech_host']) == set(['vmm'])
    assert virtual_facts['virtualization_product'] == ''
    assert virtual_facts['virtualization_vendor'] == ''

# Generated at 2022-06-20 20:42:45.697969
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-20 20:43:20.855803
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    test_obj = OpenBSDVirtual()

    facts = {}

    facts['virtualization_type'] = "VMware Virtual Platform"
    facts['virtualization_role'] = "guest"
    facts['virtualization_tech_guest'] = "vmware"
    facts['virtualization_tech_host'] = "vmware"

    assert facts == test_obj.get_virtual_facts()

# Generated at 2022-06-20 20:43:24.697282
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:43:27.220002
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert isinstance(openbsd_virtual, OpenBSDVirtual)


# Generated at 2022-06-20 20:43:33.028320
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    platform = 'OpenBSD'
    openbsd_virtual_collector.platform = platform
    openbsd_virtual_collector.module = {
        '_ansible_facts': {
            'platform': platform
        }
    }
    # Get virtualization facts
    facts = openbsd_virtual_collector.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert not facts['virtualization_tech_guest']
    assert 'vmm' in facts['virtualization_tech_host']

# Generated at 2022-06-20 20:43:34.014002
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)

# Test case for class OpenBSDVirtual

# Generated at 2022-06-20 20:43:35.611478
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-20 20:43:42.740290
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    if not virtual_facts:
        return

    facts = {}
    data = ['hw.model=OpenBSD', 'hw.machine=amd64']
    res = virtual_facts._get_dmesg_boot(data)
    if res:
        facts = virtual_facts.get_all_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

    data = ['foo', 'hw.product=VirtualBox', 'bar']
    res = virtual_facts._get_dmesg_boot(data)
    if res:
        facts = virtual_facts.get_all_facts()

    assert facts['virtualization_type'] == 'virtualbox'
    assert facts['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:43:44.764691
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    facts = vc.collect()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-20 20:43:51.152674
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert 'hw.product' == openbsd_virtual.SYSCTL_PRODUCT
    assert 'hw.vendor' == openbsd_virtual.SYSCTL_VENDOR
    assert 'OpenBSD' == openbsd_virtual.platform
    assert '/var/run/dmesg.boot' == openbsd_virtual.DMESG_BOOT

# Generated at 2022-06-20 20:43:54.247479
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virt_collector = OpenBSDVirtualCollector()
    assert virt_collector._fact_class == OpenBSDVirtual
    assert virt_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:45:10.327578
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = {'virtualization_role': '',
                             'virtualization_type': '',
                             'virtualization_tech_guest': set(),
                             'virtualization_tech_host': set([])}
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == openbsd_virtual_facts

# Generated at 2022-06-20 20:45:11.215695
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert OpenBSDVirtual().get_virtual_facts() == {}

# Generated at 2022-06-20 20:45:12.894994
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_facts = OpenBSDVirtualCollector().collect()
    for fact in virtual_facts.keys():
        assert virtual_facts[fact]

# Generated at 2022-06-20 20:45:17.973363
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsdvirtualcollector = OpenBSDVirtualCollector()

    # Unit test for instance created from class above
    assert isinstance(openbsdvirtualcollector, OpenBSDVirtualCollector)

    # Unit test for get_virtual_facts()
    assert 'virtualization_type' in openbsdvirtualcollector.get_virtual_facts()
    assert 'virtualization_role' in openbsdvirtualcollector.get_virtual_facts()
    assert 'virtualization_tech_guest' in openbsdvirtualcollector.get_virtual_facts()
    assert 'virtualization_tech_host' in openbsdvirtualcollector.get_virtual_facts()


# Generated at 2022-06-20 20:45:19.651351
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:45:25.498285
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class is OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Disable the Collection of test_OpenBSDVirtualCollector
# Use the following command to enable it again
# $ py.test -v -k OpenBSDVirtualCollector
del test_OpenBSDVirtualCollector


# Generated at 2022-06-20 20:45:29.093597
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector_result = OpenBSDVirtualCollector()
    assert virtual_collector_result._fact_class == OpenBSDVirtual
    assert virtual_collector_result._platform == 'OpenBSD'

# Generated at 2022-06-20 20:45:40.590649
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_vf = OpenBSDVirtual()

    # Test hypervisor

# Generated at 2022-06-20 20:45:44.357634
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-20 20:45:46.681540
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), VirtualCollector)
