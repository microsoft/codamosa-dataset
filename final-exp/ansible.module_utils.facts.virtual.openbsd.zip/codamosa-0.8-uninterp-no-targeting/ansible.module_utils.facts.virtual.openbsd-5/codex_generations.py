

# Generated at 2022-06-20 20:37:53.290767
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    openbsd_virtual_facts._get_virtual_facts()

    assert openbsd_virtual_facts.virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts.virtual_facts['virtualization_role'] == 'host'
    assert 'vmm' in openbsd_virtual_facts.virtual_facts['virtualization_tech_host']
    assert 'vmware' in openbsd_virtual_facts.virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-20 20:37:57.856638
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Create an instance of OpenBSDVirtualCollector
    obj = OpenBSDVirtualCollector()

    # Test the platform property
    assert obj._platform == 'OpenBSD', \
        "The platform property of class OpenBSDVirtualCollector is not 'OpenBSD'"
    return True

# Generated at 2022-06-20 20:38:02.779461
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    # There is no specific platform.
    assert openbsd_virtual.platform == 'OpenBSD'
    # openbsd_virtual should be instance of OpenBSDVirtual class
    assert isinstance(openbsd_virtual, OpenBSDVirtual)


# Generated at 2022-06-20 20:38:14.475339
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of class OpenBSDVirtual so we have a fresh copy
    # of all the data
    test_virtual_fact = OpenBSDVirtual()

    # Test each virtualization type so we have coverage
    virtual_fact_test_data = [
        {'key': 'hw.vendor',
         'value': 'OpenBSD',
         'expected_virtual_facts': {'virtualization_type': '', 'virtualization_role': ''}},
        {'key': 'hw.product',
         'value': 'amd64',
         'expected_virtual_facts': {'virtualization_type': '', 'virtualization_role': ''}}
    ]


# Generated at 2022-06-20 20:38:19.103435
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert c.platform == 'OpenBSD'
    assert c.fact_class._platform == 'OpenBSD'
    assert c.fact_class._fact_class is OpenBSDVirtual

# Generated at 2022-06-20 20:38:20.711036
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:25.904236
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    collector = OpenBSDVirtualCollector()
    openbsd_virt = collector.get_virtual_facts()

    assert 'virtualization_type' in openbsd_virt
    assert 'virtualization_role' in openbsd_virt
    assert 'virtualization_tech_guest' in openbsd_virt
    assert 'virtualization_tech_host' in openbsd_virt

# Generated at 2022-06-20 20:38:27.042944
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-20 20:38:37.904764
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = OpenBSDVirtualCollector().get_all_facts()
    if facts['virtualization_role'] == 'guest' and facts['virtualization_type'] != '':
        assert facts['virtualization_role'] == 'guest'
        assert facts['virtualization_type'] == 'vmm'
    elif facts['virtualization_role'] == 'host' and facts['virtualization_type'] != '':
        assert facts['virtualization_role'] == 'host'
        assert facts['virtualization_type'] == 'vmm'
    elif facts['virtualization_role'] == '' and facts['virtualization_type'] == '':
        assert facts['virtualization_role'] == ''
        assert facts['virtualization_type'] == ''
    else:
        raise Exception('Test error, please check the facts dict')

# Generated at 2022-06-20 20:38:42.719516
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()
    assert o.platform == 'OpenBSD'
    assert o._platform == 'OpenBSD'
    assert o.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:38:47.874051
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:38:50.325665
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert openbsd_virtual_facts.platform == 'OpenBSD'


# Generated at 2022-06-20 20:38:55.282857
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts

# Generated at 2022-06-20 20:39:02.666111
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Check that the method get_virtual_facts of class OpenBSDVirtual returns
    values for the facts listed in the _virtual_facts_platforms dict of class
    Virtual.
    """
    openbsd_virtual = OpenBSDVirtual()
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)
    assert set(virtual_facts.keys()) == set(Virtual._virtual_facts_platforms['OpenBSD'])



# Generated at 2022-06-20 20:39:05.201969
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(module=None)
    assert openbsd_virtual.platform == 'OpenBSD'


# Generated at 2022-06-20 20:39:07.081866
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    result = OpenBSDVirtualCollector()
    assert result._fact_class is OpenBSDVirtual

# Generated at 2022-06-20 20:39:08.737124
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:14.161749
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    with open('test/unit/module_utils/facts/virtual/openbsd_dmesg.boot', 'rb') as f:
        openbsd_dmesg_boot = f.read()
    virtual = OpenBSDVirtual({}, dmesg_boot=openbsd_dmesg_boot,
        sysctl_virtualized=True)
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:39:16.627281
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual({})


# Generated at 2022-06-20 20:39:24.349467
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    mock_ansible_module = MockAnsibleModule()
    mock_ansible_module.add_argument('filter', 'filter')
    virtual = OpenBSDVirtual(mock_ansible_module)
    virtual_facts = virtual.get_virtual_facts()
    assert len(virtual_facts) == 4
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-20 20:39:33.113557
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:35.834049
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd = OpenBSDVirtualCollector()
    assert openbsd
    assert openbsd.platform == 'OpenBSD'
    assert openbsd.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:37.089380
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector(None)

# Generated at 2022-06-20 20:39:41.976514
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:39:47.966946
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Unit test class OpenBSDVirtual.
    The method get_virtual_facts() should return a hash with the
    keys described by the class attribute VIRTUAL_KEYS.
    """
    openbsdvirtual = OpenBSDVirtual()
    assert openbsdvirtual.get_virtual_facts().has_key('virtualization_type')
    assert openbsdvirtual.get_virtual_facts().has_key('virtualization_role')
    assert openbsdvirtual.get_virtual_facts().has_key('virtualization_technology')

# Generated at 2022-06-20 20:39:50.764456
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts_collector = OpenBSDVirtualCollector()
    assert facts_collector.platform == 'OpenBSD'
    assert facts_collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:54.444881
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:40:05.845467
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_product'] = ''
    virtual_facts['virtualization_vendor'] = ''

    # Testing for vmm guest
    file_content = "vmm0 at mainbus0: VMX/EPT"
    openbsd_virtual_facts = OpenBSDVirtual({}, {'dmesg': {'content': file_content}})
    virtual_facts['virtualization_type'] = 'vmm'
    assert openbsd_virtual_facts.get_virtual_facts() == virtual_facts

    # Testing for vmm host
    file_content = "vmm0 at mainbus0: SVM/RVI"

# Generated at 2022-06-20 20:40:15.279595
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from pkg_resources import read_text
    from ansible.module_utils.facts.virtual import OpenBSDVirtual

    # Create OpenBSDVirtual object
    virt = OpenBSDVirtual()

    # Create a list of all the facts expected by method get_virtual_facts
    expected_virtual_facts = set(['virtualization_type',
                                  'virtualization_role',
                                  'virtualization_tech_guest',
                                  'virtualization_tech_host'])

    # Read the sample dmesg.boot
    dmesg_boot = read_text(__name__, 'dmesg.boot')

    with open('/tmp/dmesg.boot', 'w') as f:
        f.write(dmesg_boot)

    # Method get_virtual_facts cannot be tested on non OpenBSD system.
    # In this

# Generated at 2022-06-20 20:40:19.682873
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual(None, None, None).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-20 20:40:35.779933
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_openbsd = OpenBSDVirtual()
    # Check if class OpenBSDVirtual is subclass of Virtual
    assert(isinstance(virtual_openbsd, Virtual))
    assert(isinstance(virtual_openbsd, VirtualSysctlDetectionMixin))

# Generated at 2022-06-20 20:40:39.622561
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsdvirtualcollector = OpenBSDVirtualCollector()
    assert openbsdvirtualcollector.platform == "OpenBSD"
    assert openbsdvirtualcollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:40:44.800213
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:40:46.590771
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    platform_virtual = OpenBSDVirtualCollector()
    assert platform_virtual._platform == 'OpenBSD'
    assert platform_virtual._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:40:49.210748
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:40:52.538582
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual(None)

    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:40:55.739284
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Create a temporary instance
    instance = OpenBSDVirtualCollector()
    # Check whether the created instance is a class instance of OpenBSDVirtualCollector
    assert isinstance(instance, OpenBSDVirtualCollector)


# Generated at 2022-06-20 20:40:58.811081
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.get_virtual_facts() == dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_host=set(),
        virtualization_tech_guest=set()
    )

# Generated at 2022-06-20 20:41:03.163155
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdvirt = OpenBSDVirtual()
    assert openbsdvirt.platform == 'OpenBSD'
    assert openbsdvirt.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:41:05.649393
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual({}, {})
    assert v.platform == 'OpenBSD'
    assert v.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:41:30.336779
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()
    assert o.platform == 'OpenBSD'

# Generated at 2022-06-20 20:41:34.002493
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD', collector._platform


# Generated at 2022-06-20 20:41:36.152311
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'


# Generated at 2022-06-20 20:41:38.632654
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    obj = OpenBSDVirtual()
    assert obj.platform == 'OpenBSD'
    assert obj.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:41:48.104893
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    opbsd_virtual = OpenBSDVirtual(None)
    assert opbsd_virtual.platform == "OpenBSD"
    assert opbsd_virtual.DMESG_BOOT == "/var/run/dmesg.boot"
    assert opbsd_virtual.module is None
    assert opbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-20 20:41:50.942877
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'


# Generated at 2022-06-20 20:41:55.005458
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({},{},{},{},'OpenBSD')

    assert openbsd_virtual.get_virtual_facts() == {'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_tech_guest': set()}


# Generated at 2022-06-20 20:42:01.264619
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    facts_dict = {}
    facts_dict['virtualization_type'] = ''
    facts_dict['virtualization_role'] = ''
    facts_dict['virtualization_tech_guest'] = set()
    facts_dict['virtualization_tech_host'] = set()
    assert virtual_facts.get_virtual_facts() == facts_dict

# Generated at 2022-06-20 20:42:04.453413
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''

# Generated at 2022-06-20 20:42:11.835812
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Initialize the OpenBSDVirtual object
    test_OpenBSDVirtual = OpenBSDVirtual()

    # Test get_virtual_facts method
    # Expect the virtualization_type is 'vmm' and virtualization_role is 'host'
    virtual_facts_info = test_OpenBSDVirtual.get_virtual_facts()
    assert virtual_facts_info['virtualization_type'] == 'vmm'
    assert virtual_facts_info['virtualization_role'] == 'host'

# Generated at 2022-06-20 20:43:06.150982
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._platform == 'openbsd'

# Generated at 2022-06-20 20:43:08.106329
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:10.386530
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class is OpenBSDVirtual
    assert openbsd_virtual_collector._platform is 'OpenBSD'

# Generated at 2022-06-20 20:43:14.124092
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = dict()
    result = OpenBSDVirtual.get_virtual_facts(facts)
    assert isinstance(result, dict)
    assert 'virtual' in result
    assert isinstance(result['virtual'], bool)

if __name__ == '__main__':
    # Unit test
    module = OpenBSDVirtual()
    print(module.get_virtual_facts())

# Generated at 2022-06-20 20:43:18.367786
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    import platform

    platform_system = platform.system()
    if platform_system != "OpenBSD":
        raise Exception("This test must run on OpenBSD to ensure detection logic.")

    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:43:21.097648
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:43:25.036684
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Constructor for class OpenBSDVirtualCollector
    """
    assert OpenBSDVirtualCollector()._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector()._platform == 'OpenBSD'

# Generated at 2022-06-20 20:43:26.193391
# Unit test for constructor of class OpenBSDVirtual

# Generated at 2022-06-20 20:43:28.729445
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:43:34.615309
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector.factory()
    assert isinstance(obj, OpenBSDVirtualCollector)
    assert obj.platform == 'OpenBSD'
    assert obj.fact_class == OpenBSDVirtual

# Unit tests for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:45:51.842719
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Unit test for class OpenBSDVirtualCollector
    """

    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual is not None
    assert OpenBSDVirtual in openbsd_virtual._fact_classes
    assert openbsd_virtual._platform == 'OpenBSD'



# Generated at 2022-06-20 20:45:52.971030
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-20 20:45:58.438694
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.collect()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:46:00.085213
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_fact = OpenBSDVirtual()

    # If a OpenBSDVirtual object is created, the platform should be OpenBSD.
    assert virtual_fact.platform == 'OpenBSD'


# Generated at 2022-06-20 20:46:05.271664
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert isinstance(c, OpenBSDVirtualCollector)
    assert isinstance(c._fact_class, type)
    assert c._fact_class.platform == 'OpenBSD'


# Generated at 2022-06-20 20:46:15.866330
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Build a fake class with stubs for dependencies
    class OpenBSDVirtualWithStubs():
        get_virtual_facts_called = False

        def get_virtual_facts(self):
            self.get_virtual_facts_called = True
            return {'virtualization_type': 'jail'}

    # Create an instance of the stub class
    openbsd_virtual_instance = OpenBSDVirtualWithStubs()

    # Run the method
    result = openbsd_virtual_instance.get_virtual_facts()

    # Make sure get_virtual_facts was called
    assert openbsd_virtual_instance.get_virtual_facts_called is True

    # Make sure the expected result was returned
    assert result == {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest'
    }

# Generated at 2022-06-20 20:46:20.098329
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    dets = OpenBSDVirtual()
    # For now just make sure it's some form of a dict
    assert 'dict' in str(type(dets._data))



# Generated at 2022-06-20 20:46:25.009465
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:46:26.880741
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'


# Generated at 2022-06-20 20:46:29.711238
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._fact_class is OpenBSDVirtual
    assert collector._platform == 'OpenBSD'