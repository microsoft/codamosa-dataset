

# Generated at 2022-06-20 20:37:51.427815
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsdvirtual = OpenBSDVirtual()
    actual_facts = openbsdvirtual.get_virtual_facts()
    expected_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()}
    assert actual_facts == expected_facts

# Generated at 2022-06-20 20:37:55.983622
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = ansible_OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_system'] == ''
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts


# Generated at 2022-06-20 20:37:57.797147
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'

# Generated at 2022-06-20 20:38:00.923824
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None, None, None)
    facts = openbsd_virtual.get_facts()
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-20 20:38:03.751510
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-20 20:38:15.218302
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_cases = [
        # data, expected results
        ({'hw.vendor': 'foo', 'hw.product': 'bar'},
            {'virtualization_type': '', 'virtualization_role': '',
             'virtualization_tech_host': set(), 'virtualization_tech_guest': set(),
             'virtualization_product_name': 'bar', 'virtualization_product_version': '',
             'virtualization_product_serial': '', 'virtualization_product_uuid': '',
             'virtualization_product_vendor': 'foo'}),
    ]

    for data, expected in test_cases:

        class Mock_OpenBSDVirtual(OpenBSDVirtual):
            def _get_sysctl(self, key):
                return data[key]


# Generated at 2022-06-20 20:38:26.902242
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    openbsd_virtual = OpenBSDVirtual()


# Generated at 2022-06-20 20:38:30.975731
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts_class = OpenBSDVirtual()
    assert virtual_facts_class.platform == 'OpenBSD'
    assert virtual_facts_class.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-20 20:38:34.876595
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    '''Unit test for constructor of class OpenBSDVirtual'''
    facts = OpenBSDVirtual()
    assert facts.platform == 'OpenBSD'
    assert facts.product_name == ''
    assert facts.product_version == ''
    assert facts.virtualization_type == ''
    assert facts.virtualization_role == ''

# Generated at 2022-06-20 20:38:35.415089
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-20 20:38:40.486415
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    This is a unit test for OpenBSDVirtualCollector constructor
    """
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:38:42.578002
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Creating the class instance should not raise an exception
    OpenBSDVirtual()

# Generated at 2022-06-20 20:38:52.314871
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual(platform='OpenBSD')

    # Set the file content
    openbsd_virtual.dmesg_boot = """
vmm0 at mainbus0: SVM/RVI
vmd0 at pci6 dev 2 function 0: virtio network
vmd0: ethernet address: 52:54:00:12:34:56
vmd1 at pci6 dev 3 function 0: virtio block
vmd2 at pci6 dev 4 function 0: virtio console
vmd3 at pci6 dev 5 function 0: virtio disk
vmd4 at pci6 dev 6 function 0: virtio disk
vmd5 at pci6 dev 7 function 0: virtio disk
"""

    # Set the sysctl values.

# Generated at 2022-06-20 20:38:57.494236
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt_facts = OpenBSDVirtualCollector().collect()['ansible_facts']['virtual_facts']

    assert 'virtualization_type' in virt_facts
    assert 'virtualization_role' in virt_facts
    assert 'virtualization_tech_host' in virt_facts
    assert 'virtualization_tech_guest' in virt_facts

# Generated at 2022-06-20 20:38:59.628238
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdv = OpenBSDVirtual()
    openbsdv.get_virtual_facts()



# Generated at 2022-06-20 20:39:11.589880
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Case 1: expected host
    openbsd_virtual.sysctl = {'hw.product': 'OpenBSD', 'hw.vendor': 'OpenBSD'}

    # Case 2: expected guest
    openbsd_virtual.sysctl = {'hw.product': 'OpenBSD', 'hw.vendor': 'OpenBSD'}

    # Case 3: expected guest
    openbsd_virtual.sysctl = {'hw.product': 'OpenBSD', 'hw.vendor': 'pc98'}

    # Case 4: expected host

# Generated at 2022-06-20 20:39:16.193514
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from .test_utils import get_test_data
    from pickle import load
    from pprint import pprint

    test_data = get_test_data('OpenBSDVirtual_get_virtual_facts.json')
    for openbsd_version, expected_virtual_facts in test_data.items():
        virtual_facts = OpenBSDVirtual.get_virtual_facts(None)
        for key, value in expected_virtual_facts.items():
            assert value == virtual_facts[key]


# Generated at 2022-06-20 20:39:26.370886
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    import unittest
    import sys
    import os
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    class TestOpenBSDVirtual(unittest.TestCase):
        def setUp(self):
            sys.modules['psutil'] = None
            sys.modules['virttest'] = None
            sys.modules['libvirt'] = None

        def test_virtual_type(self):
            openbsd_inst = OpenBSDVirtual()
            self.assertEqual(openbsd_inst.virtualization_type, '')
            self.assertEqual(openbsd_inst.virtualization_role, '')

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-20 20:39:29.937130
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    test_class = OpenBSDVirtualCollector
    test_object = test_class()
    assert test_object != None
    assert test_object.platform == 'OpenBSD'


# Generated at 2022-06-20 20:39:33.937031
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:43.612577
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Test constructor of OpenBSDVirtualCollector
    """
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:39:53.267310
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_Virtual = OpenBSDVirtual()
    # Host facts for a bare-metal OpenBSD machine
    hw_vendor_product = [{"hw.vendor": "GenuineIntel", "hw.product": "Intel(R) Core(TM) i5-4590 CPU @ 3.30GHz"}]
    # Expected results for a bare-metal OpenBSD machine
    expected_results = dict(virtualization_type='', virtualization_role='', virtualization_tech_guest=set(), virtualization_tech_host=set())
    results = test_Virtual.get_virtual_facts(hw_vendor_product)
    # Compare fact results with expected results
    assert results == expected_results

    # Host facts for a OpenBSD VM guest running on a VMware ESX host
    # The output of hw.vendor is truncated to 15 characters
   

# Generated at 2022-06-20 20:39:58.629840
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.virtualization_type == ''
    assert openbsd_virtual.virtualization_role == ''
    assert openbsd_virtual.virtualization_type_facts == ['hw.product', 'hw.vendor']

# Generated at 2022-06-20 20:40:02.923398
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:40:05.313458
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual({}, {}, {}, {}, {})
    assert v.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': ''}

# Generated at 2022-06-20 20:40:12.002975
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # vmm(4) is detected as host
    dmesg_boot = "vmm0 at mainbus0: SVM/RVI"
    openbsd_virtual = OpenBSDVirtual(dmesg_boot)
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert 'OpenBSD' == virtual_facts['virtualization_type']
    assert 'host' == virtual_facts['virtualization_role']
    assert 'vmm' in virtual_facts['virtualization_tech_host']

    # vmm(4) is detected as host
    dmesg_boot = "vmm0 at mainbus0: VMX/EPT"
    openbsd_virtual = OpenBSDVirtual(dmesg_boot)
    virtual_facts = openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-20 20:40:15.363201
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_class = OpenBSDVirtual()
    assert virtual_class.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {}
    }

# Generated at 2022-06-20 20:40:17.041543
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    instanceOpenBSDVirtual = OpenBSDVirtual()
    assert type(instanceOpenBSDVirtual) is OpenBSDVirtual

# Generated at 2022-06-20 20:40:25.286284
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    facts = openbsd_virtual.get_virtual_facts()
    keys = [
        'virtualization_role',
        'virtualization_type',
        'virtualization_tech_guest',
        'virtualization_tech_host',
        'virtualization_product'
    ]

    for key in keys:
        assert key in facts
        if isinstance(facts[key], set):
            assert len(facts[key]) >= 0
        else:
            assert len(facts[key]) > 0

# Generated at 2022-06-20 20:40:28.067667
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert bool(openbsd_virtual)
    assert openbsd_virtual.platform == 'OpenBSD'


# Generated at 2022-06-20 20:40:48.508916
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    # This will set get_file_content return value
    openbsd_virtual.set_file_content(OpenBSDVirtual.DMESG_BOOT, """vmm0 at mainbus0: SVM/RVI""")

    # This will set sysctl output for sysctl hw.product
    openbsd_virtual.set_sysctl_output(mapping={'hw.product': 'VirtualBox'})

    # This will set sysctl output for sysctl hw.vendor
    openbsd_virtual.set_sysctl_output(mapping={'hw.vendor': 'Oracle Corporation'})

    # This will test if these lines are present in the dmesg output
    openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual.get_file_

# Generated at 2022-06-20 20:40:57.137075
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Facts returned by Virtual._get_virtual_facts function
    openbsd_virtual_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set()
    )

    # Create Virtual class object
    openbsd_virtual = OpenBSDVirtual()

    # Check _get_virtual_facts function
    assert openbsd_virtual_facts == openbsd_virtual._get_virtual_facts(), \
        'Failed to create instance of OpenBSDVirtual class.'


# Generated at 2022-06-20 20:41:09.151292
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-20 20:41:11.447339
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual_collector, OpenBSDVirtualCollector)


# Generated at 2022-06-20 20:41:17.097409
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual({}).get_virtual_facts()

    # Check the facts
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_type'] == ''
    assert set(facts['virtualization_tech_guest']) == set()
    assert set(facts['virtualization_tech_host']) == set()

# Generated at 2022-06-20 20:41:25.338144
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Load class for testing
    mod_OpenBSDVirtual = __import__('ansible.module_utils.facts.virtual.openbsd', fromlist=['OpenBSDVirtual'])
    OpenBSDVirtual = getattr(mod_OpenBSDVirtual, 'OpenBSDVirtual')

    # Create class object
    virtual_openbsd = OpenBSDVirtual()
    assert virtual_openbsd

    # Check 1: Platform
    assert virtual_openbsd.platform == 'OpenBSD'

    # Check 2: DMESG_BOOT
    assert virtual_openbsd.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:41:29.437440
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()

    assert c._fact_class == OpenBSDVirtual
    assert c._platform == 'OpenBSD'

# Generated at 2022-06-20 20:41:40.811294
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import sys
    import pytest

    test_data_OpenBSDVirtual = [
        (
            "OpenBSD on qemu",
            {
                'virtualization_type': 'qemu',
                'virtualization_role': 'guest',
                'virtualization_tech_guest': {'qemu'},
                'virtualization_tech_host': set()
            }
        ),
    ]

    for test_case in test_data_OpenBSDVirtual:
        OpenBSDVirtual.DMESG_BOOT = test_case[0]
        assert OpenBSDVirtual().get_virtual_facts() == test_case[1]


# Generated at 2022-06-20 20:41:47.742843
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Test OpenBSDVirtual's constructor
    """
    open_bsd_virtual = OpenBSDVirtual()

    assert open_bsd_virtual.platform == 'OpenBSD'
    assert open_bsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert open_bsd_virtual.vendor_facts == {}
    assert open_bsd_virtual.product_facts == {}

# Generated at 2022-06-20 20:41:56.817240
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # form a fact collection
    fact_collection = dict()
    virtual = OpenBSDVirtual()
    fact_collection[virtual.platform] = dict()
    fact_collection[virtual.platform]['virtual'] = dict()
    # OpenBSD do not offer any API to detect virtualization techs
    # or virtualization type and role.  So, the facts must come from the
    # virtualization facts collector.
    # Now, the hw.product and hw.vendor for VMM(4) are
    # hw.product=AMD Ryzen 5 3600 hw.vendor=AuthenticAMD
    # So, for QEMU with VMM(4), the facts should be:
    # virtualization_type=hvm
    # virtualization_role=guest
    # virtualization_tech_guest=qemu
    # virtualization_

# Generated at 2022-06-20 20:42:23.377652
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert isinstance(virtual_facts, OpenBSDVirtual)


# Generated at 2022-06-20 20:42:24.337215
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector is not None


# Generated at 2022-06-20 20:42:35.122071
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class TestOpenBSDVirtual(OpenBSDVirtual):
        def detect_virt_product(self, vendor):
            return {'virtualization_type': 'hv',
                    'virtualization_role': 'guest',
                    'virtualization_tech_guest': set([])}

        def detect_virt_vendor(self, vendor):
            return {'virtualization_type': 'hv',
                    'virtualization_role': 'host',
                    'virtualization_tech_host': set([])}

    v = TestOpenBSDVirtual()
    virtual_facts = v.get_virtual_facts()

    assert isinstance(virtual_facts, dict)
    assert virtual_facts['virtualization_type'] == 'hv'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-20 20:42:38.551789
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({}, {}, {})
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:42:46.059818
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    openbsd_vm = OpenBSDVirtual({'ansible_facts': {}})

    # Test case 1: Virtualization type is VMware
    # hw.vendor: VMware
    # hw.product: VMware Virtual Platform
    #
    # The test case checks that virtualization_type is VMWare
    result = openbsd_vm.get_virtual_facts({'ansible_facts': {'hw.vendor': 'VMware', 'hw.product': 'VMware Virtual Platform'}})
    assert result['virtualization_type'] == 'VMware'

    # Test case 2: Virtualization type is virtualbox
    # hw.vendor: OpenBSD
    # hw.product: VirtualBox
    #
    # The test case checks that virtualization_type is VirtualBox
    result = openbsd_vm.get_virtual_

# Generated at 2022-06-20 20:42:48.681532
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-20 20:42:50.374947
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'

# Generated at 2022-06-20 20:42:55.976191
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual.platform == 'OpenBSD'
    assert OpenBSDVirtual.DMESG_BOOT == '/var/run/dmesg.boot'
    obj = OpenBSDVirtual()
    assert obj.platform == 'OpenBSD'
    assert OpenBSDVirtual.get_virtual_facts.__doc__ == Virtual.get_virtual_facts.__doc__



# Generated at 2022-06-20 20:43:00.468634
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:43:01.684108
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector(None)

# Generated at 2022-06-20 20:44:00.782305
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    oBSDVirtualCol = OpenBSDVirtualCollector()
    assert oBSDVirtualCol.platform == 'OpenBSD'
    assert oBSDVirtualCol._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:44:09.837650
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    # These keys should be set by default
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    # These keys should not be set
    assert 'virtualization_product_guest' not in virtual_facts
    assert 'virtualization_product_host' not in virtual_facts
    assert 'virtualization_product' not in virtual_facts
    assert 'virtualization_product_version' not in virtual_facts

# Generated at 2022-06-20 20:44:16.689660
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual('data/dmesg.boot_OpenBSD_6.0_amd64')
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:44:17.767483
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts is not None

# Generated at 2022-06-20 20:44:20.937785
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdvirtual = OpenBSDVirtual()
    assert openbsdvirtual.platform == 'OpenBSD'
    assert openbsdvirtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:44:25.242760
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module = OpenBSDVirtualCollector(None, None, None)
    module.collect()
    assert 'virtualization_type' in module.facts
    assert 'virtualization_role' in module.facts
    assert 'virtualization_tech_guest' in module.facts
    assert 'virtualization_tech_host' in module.facts

# Generated at 2022-06-20 20:44:30.424074
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual('OpenBSD')
    assert isinstance(virtual_facts, Virtual)
    assert isinstance(virtual_facts, VirtualSysctlDetectionMixin)
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''

# Generated at 2022-06-20 20:44:38.285925
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # input data
    test_input = {
        # valid input data
        'hw.product': 'GenuineIntel',
        'hw.vendor': 'Intel Corporation',
        'hw.model': '',
        'hw.machine': '',
        'vm.vmtotal': '1 vcpu, 131168 msize\n',
        'hw.ncpu': '4\n',
        'hw.cpu_brands': '4 Intel(R) Core(TM) i7-4790 CPU @ 3.60GHz\n',
        # invalid input data
    }

    # expected output

# Generated at 2022-06-20 20:44:48.007528
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()

    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_host == set()
    assert virtual_facts.virtualization_tech_guest == set()

    # Check the virtual_facts.virtualization_type and
    # virtual_facts.virtualization_role to be set to 'vmm' and 'host'
    # respectively when the content of OpenBSDVirtual.DMESG_BOOT matches
    # the pattern '^vmm0 at mainbus0: (SVM/RVI|VMX/EPT)$'.

# Generated at 2022-06-20 20:44:51.755149
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector(None)
    assert openbsd_virtual_collector is not None

# Generated at 2022-06-20 20:47:22.250855
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Verify an instance of OpenBSDVirtualCollector can be created
    """
    open_bsd_virtual_collector = OpenBSDVirtualCollector()
    assert open_bsd_virtual_collector.platform == 'OpenBSD'
    assert open_bsd_virtual_collector._fact_class.platform == 'OpenBSD'
    assert open_bsd_virtual_collector._fact_class.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:47:24.972209
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector is not None


# Generated at 2022-06-20 20:47:28.867496
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts_output = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts_output == {'virtualization_role': '',
                                    'virtualization_type': '',
                                    'virtualization_tech_guest': set([]),
                                    'virtualization_tech_host': set([])}

# Generated at 2022-06-20 20:47:29.930261
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert isinstance(v, OpenBSDVirtual)

# Generated at 2022-06-20 20:47:31.216551
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert openbsd_virtual_facts.get_virtual_facts() == {}

# Generated at 2022-06-20 20:47:35.423251
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual({})
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert not virtual._platform_facts


# Generated at 2022-06-20 20:47:39.217647
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o_OpenBSDVirtualCollector = OpenBSDVirtualCollector()
    assert o_OpenBSDVirtualCollector.platform == 'OpenBSD'
    assert o_OpenBSDVirtualCollector.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:47:41.094041
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:47:45.938607
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj.platform == 'OpenBSD'
    assert obj.fact_class is OpenBSDVirtual