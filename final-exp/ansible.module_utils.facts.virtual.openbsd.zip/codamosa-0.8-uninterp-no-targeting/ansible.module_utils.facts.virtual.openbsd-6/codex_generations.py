

# Generated at 2022-06-20 20:37:43.910454
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:37:47.121426
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    '''Unit test constructor of class OpenBSDVirtual.'''
    module = OpenBSDVirtual(module_arg_spec={})
    assert module.platform == 'OpenBSD'

# Generated at 2022-06-20 20:37:48.232711
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test if class initialized
    OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:37:50.355503
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert c.platform == 'OpenBSD'
    assert c.fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:37:54.538915
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'openvz'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['openvz'])

# Generated at 2022-06-20 20:37:56.958400
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert VirtualCollector.get_platform() == 'OpenBSD'

# Generated at 2022-06-20 20:37:59.203579
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual
    assert virtual.platform == 'OpenBSD'


# Generated at 2022-06-20 20:38:11.596386
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    expected_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
        'virtualization_product_name': '',
        'virtualization_product_version': '',
    }
    sut = OpenBSDVirtual()
    assert sut is not None
    assert sut.platform == 'OpenBSD'
    assert sut.facts == expected_facts
    assert sut.files == {
      'virtual': '/usr/sbin/sysctl -n hw.product',
      'virtual_vendor': '/usr/sbin/sysctl -n hw.vendor'
    }

# Generated at 2022-06-20 20:38:16.096353
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert(virtual['virtualization_type'] == '')
    assert(virtual['virtualization_role'] == '')
    assert('virtualization_tech_host' not in virtual)
    assert('virtualization_tech_guest' not in virtual)
    assert('virtualization_subtype_host' not in virtual)
    assert('virtualization_subtype_guest' not in virtual)

# Generated at 2022-06-20 20:38:18.909848
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj
    assert obj._platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:38:23.080992
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt_facts = OpenBSDVirtual()
    assert virt_facts

# Generated at 2022-06-20 20:38:25.528227
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = {}
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts

# Generated at 2022-06-20 20:38:32.238738
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    data = dict(virtualization_type='vmm',
                virtualization_role='guest',
                virtualization_tech_guest=set(),
                virtualization_tech_host=set())

    # Create test object
    testobj = OpenBSDVirtual()
    # Mock method 'detect_virt_product'
    def test_detect_virt_product(key):
        return dict(virtualization_type=data['virtualization_type'],
                    virtualization_role='',
                    virtualization_tech_guest=data['virtualization_tech_guest'],
                    virtualization_tech_host=data['virtualization_tech_host'])
    testobj.detect_virt_product = test_detect_virt_product
    # Mock method 'detect_virt_vendor'

# Generated at 2022-06-20 20:38:33.135521
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:38:36.847392
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''Unit test method get_virtual_facts of OpenBSDVirtual'''
    virtual = OpenBSDVirtual()
    facts = virtual.get_all_facts()
    assert facts['virtualization_type']
    assert facts['virtualization_role']

# Generated at 2022-06-20 20:38:43.203765
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual
    assert o._results['virtualization_type'] == ''
    assert isinstance(o._results['virtualization_tech_guest'], set)
    assert isinstance(o._results['virtualization_tech_host'], set)

# Generated at 2022-06-20 20:38:45.337410
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_facts_collector = OpenBSDVirtualCollector()
    assert isinstance(virtual_facts_collector._fact_class, OpenBSDVirtual)

# Generated at 2022-06-20 20:38:47.301444
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.get_virtual_facts()["virtualization_type"] == ''



# Generated at 2022-06-20 20:38:50.764111
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == "OpenBSD"
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-20 20:39:02.825436
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_facts = OpenBSDVirtual()

    # If the get_virtual_facts method returns virtualization_type and
    # virtualization_role as empty string, then virtualization_tech_guest and
    # virtualization_tech_host must also contain empty string.
    if openbsd_facts.get_virtual_facts()['virtualization_type'] == '':
        if openbsd_facts.get_virtual_facts()['virtualization_tech_guest'] != '':
            raise Exception('Test of get_virtual_facts failed! virtualization_tech_guest is not empty!')
        if openbsd_facts.get_virtual_facts()['virtualization_tech_host'] != '':
            raise Exception('Test of get_virtual_facts failed! virtualization_tech_host is not empty!')

    # If the get_virtual

# Generated at 2022-06-20 20:39:10.393667
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    d = OpenBSDVirtual()
    assert d is not None
    assert d.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:39:14.177387
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj.platform == 'OpenBSD'
    assert obj.virtfacts.platform == 'OpenBSD'
    assert obj.virtfacts.DMESG_BOOT == '/var/run/dmesg.boot'
    assert obj.virtfacts.get_virtual_facts()


# Generated at 2022-06-20 20:39:26.409272
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of the class to be unit tested
    openbsd_virtual = OpenBSDVirtual()
    # Create the test data
    openbsd_virtual_facts = {
        'virtualization_tech_guest': set(),
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set()
    }
    # Set empty values as default
    openbsd_virtual.virtualization_type = openbsd_virtual_facts['virtualization_type']
    openbsd_virtual.virtualization_role = openbsd_virtual_facts['virtualization_role']
    openbsd_virtual.virtualization_tech_guest = openbsd_virtual_facts['virtualization_tech_guest']
    openbsd_virtual.virtualization_tech_host = openbs

# Generated at 2022-06-20 20:39:30.292531
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:39:32.876832
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert VirtualCollector.__subclasscheck__(OpenBSDVirtualCollector)


# Generated at 2022-06-20 20:39:34.585130
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual is not None

# Generated at 2022-06-20 20:39:37.579679
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    data = OpenBSDVirtual()
    # test if OpenBSD is supported
    assert data.is_platform_supported()
    # return empty dictionary if not a OpenBSD system
    assert data.get_virtual_facts() == {}

# Generated at 2022-06-20 20:39:46.755343
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # OpenBSDVirtualCollector should derive from VirtualCollector.
    OpenBSDVirtualCollector.__bases__
    assert OpenBSDVirtualCollector.__bases__ == (VirtualCollector,)

    # Create an instance of OpenBSDVirtualCollector
    virtual_collector = OpenBSDVirtualCollector()

    # Check its _fact_class is OpenBSDVirtual
    class_type = virtual_collector._fact_class
    assert class_type.__name__ == "OpenBSDVirtual"

    # Check its _platform is set to 'OpenBSD'
    assert virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-20 20:39:50.596282
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == "OpenBSD"


# Generated at 2022-06-20 20:40:03.016432
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class TestOpenBSDVirtualFacts:
        def __init__(self):
            self.vendor = ''
            self.product = ''
            self.hwvendor = ''
            self.hwproduct = ''
            self.dmesg = ''
            self.is_vmm = True

    # Check for host
    v = OpenBSDVirtual()
    v.host_sysctl = TestOpenBSDVirtualFacts()
    assert v.get_virtual_facts() == {
        'virtualization_role': 'host',
        'virtualization_type': 'vmm',
        'virtualization_tech_host': {'vmm'},
        'virtualization_tech_guest': set(),
    }

    # Check for guest for different vendor and product
    v.host_sysctl = TestOpenBSDVirtualFacts()
    v.host

# Generated at 2022-06-20 20:40:15.748767
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:40:19.204063
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual().get_virtual_facts()
    assert facts['virtualization_type'] in ['virtualbox', 'vmm', '']
    assert facts['virtualization_role'] in ['guest', 'host', '']

# Generated at 2022-06-20 20:40:24.094054
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_class = OpenBSDVirtualCollector()
    _fact_class = openbsd_virtual_class._fact_class
    _platform = openbsd_virtual_class._platform
    assert _fact_class == OpenBSDVirtual
    assert _platform == 'OpenBSD'

# Generated at 2022-06-20 20:40:25.246447
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.virtual == OpenBSDVirtual

# Generated at 2022-06-20 20:40:29.978743
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Test OpenBSDVirtualCollector object creation and methods
    """
    o = OpenBSDVirtualCollector()

    assert o.platform == 'OpenBSD'
    assert o.virt_type == 'OpenBSDVirtual'
    assert o.sysctl_detection_file == '/etc/sysctl.conf'

# Generated at 2022-06-20 20:40:31.859470
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    x = OpenBSDVirtualCollector()
    assert x.platform == 'OpenBSD'
    assert x._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:40:43.613950
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    TEST_CASES = dict()
    TEST_CASES[OpenBSDVirtual.DMESG_BOOT] = ['vmm0 at mainbus0: VMX/EPT', '']
    TEST_CASES[OpenBSDVirtual.SYSCTL_ALL] = ['hw.product=i386', '']
    TEST_CASES[OpenBSDVirtual.SYSCTL_ALL] = ['hw.vendor=QEMU', '']

    openbsd_virt = OpenBSDVirtual()

    for k, v in TEST_CASES.items():
        if k == OpenBSDVirtual.DMESG_BOOT:
            openbsd_virt.dmesg_boot = v
        if k == OpenBSDVirtual.SYSCTL_ALL:
            openbsd_virt.sysctl_all = v

    virtual

# Generated at 2022-06-20 20:40:46.591110
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(module=None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:40:50.937848
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:40:57.375228
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts._platform == 'OpenBSD'
    assert virtual_facts._fact_class == OpenBSDVirtual
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_technology_host': set(),
        'virtualization_technology_guest': set(),
    }

# Generated at 2022-06-20 20:41:20.244703
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    return OpenBSDVirtualCollector()

# Generated at 2022-06-20 20:41:22.467695
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    ''' Constructor of class OpenBSDVirtual '''
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual

# Generated at 2022-06-20 20:41:29.072795
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual.facts_dictionary = {
        'hw.product': 'VirtualBox',
        'hw.vendor': 'QEMU'
    }
    virtual.get_file_content = fake_get_file_content

    expected_virtual_facts = {
        'virtualization_type': 'vbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'vbox'},
        'virtualization_tech_host': set()
    }

    virtual_facts = virtual.get_virtual_facts()

    assert expected_virtual_facts == virtual_facts


# Generated at 2022-06-20 20:41:30.586604
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector()._platform == 'OpenBSD'

# Generated at 2022-06-20 20:41:39.782691
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test that virtualization_type and virtualization_role are the correct type
    virtual_facts = OpenBSDVirtual(bool(True)).get_virtual_facts()
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)

    # Test that virtualization_type and virtualization_role are correctly set
    virtual_facts = OpenBSDVirtual(bool(False)).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''


# Generated at 2022-06-20 20:41:42.164208
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt_facts = OpenBSDVirtual()
    assert virt_facts.platform == 'OpenBSD'
    assert isinstance(virt_facts, Virtual)
    assert isinstance(virt_facts, VirtualSysctlDetectionMixin)


# Generated at 2022-06-20 20:41:47.576410
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts_obj = OpenBSDVirtual()
    for attr in ['platform',
                 'virtualization_type',
                 'virtualization_role',
                 'virtualization_tech_guest',
                 'virtualization_tech_host']:
        assert getattr(virtual_facts_obj, attr, None) is not None

# Generated at 2022-06-20 20:41:56.722121
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.detect_virt_product = lambda product: {'virtualization_type': 'virtualbox', 'virtualization_role': ''}
    openbsd_virtual.detect_virt_vendor = lambda vendor: {'virtualization_type': '', 'virtualization_role': 'guest'}
    openbsd_virtual.DMESG_BOOT = './tests/unittests/files/dmesg.boot'
    facts = openbsd_virtual.get_virtual_facts()

    # Check virtualization_type and virtualization_role
    assert facts['virtualization_type'] == 'virtualbox'
    assert facts['virtualization_role'] == 'guest'

    # Check virtualization_tech_*

# Generated at 2022-06-20 20:42:05.104692
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    This method is used by unit tests.
    """
    facts = OpenBSDVirtual().get_virtual_facts()
    assert isinstance(facts, dict)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_product_name' in facts
    assert 'virtualization_product_version' in facts
    assert 'virtualization_product_serial' in facts

# Generated at 2022-06-20 20:42:07.189396
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert isinstance(c, OpenBSDVirtualCollector)


# Generated at 2022-06-20 20:43:02.861002
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual({})
    assert o.platform == 'OpenBSD'
    assert o.sysctl_mapping == {'hw.product': 'virtualization_type',
                                'hw.vendor': 'virtualization_type'}

# Generated at 2022-06-20 20:43:05.989258
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector.fact_class.platform == 'OpenBSD'


# Generated at 2022-06-20 20:43:09.167792
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = OpenBSDVirtualCollector().collect()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-20 20:43:11.099067
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'
    assert v.virtualization_type == ''
    assert v.virtualization_role == ''

# Generated at 2022-06-20 20:43:21.497796
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()

    # Return the virtual facts from method get_virtual_facts
    # The return values of the read_file function are changed to the
    # following to run the unit test.
    # * 'hw.product': 'QEMU Virtual CPU version 2.5+'
    # * 'hw.vendor': 'GNU/Linux'
    v.read_file = lambda f: ''
    virtual_facts = v.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'qemu'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'qemu'}
    assert virtual_facts['virtualization_tech_host'] == set()

    # Return the virtual facts from method get_virtual_facts

# Generated at 2022-06-20 20:43:27.678076
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()

    # Method get_virtual_facts returns a dictionary with keys
    # 'virtualization_type' and 'virtualization_role'
    assert isinstance(virtual.get_virtual_facts(), dict)
    assert 'virtualization_type' in virtual.get_virtual_facts()
    assert 'virtualization_role' in virtual.get_virtual_facts()

# Generated at 2022-06-20 20:43:31.548583
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = OpenBSDVirtualCollector()
    assert facts._platform == 'OpenBSD'
    assert facts._fact_class == OpenBSDVirtual


# Generated at 2022-06-20 20:43:40.819055
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    expected_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_host': {'vmm'},
        'virtualization_tech_guest': set()
    }


# Generated at 2022-06-20 20:43:42.017560
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector()


# Generated at 2022-06-20 20:43:43.950688
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual(None)
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-20 20:45:54.182490
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-20 20:45:57.103196
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-20 20:45:59.329933
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_facts_collector = OpenBSDVirtualCollector()
    assert virtual_facts_collector._fact_class == OpenBSDVirtual
    assert virtual_facts_collector._platform == 'OpenBSD'


# Generated at 2022-06-20 20:46:03.821742
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.platform == 'OpenBSD'
    assert isinstance(o.facts, OpenBSDVirtual)


# Generated at 2022-06-20 20:46:05.624522
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:46:10.379403
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_obj = OpenBSDVirtual()

    # Test the platform of OpenBSDVirtual
    assert openbsd_virtual_obj.platform == 'OpenBSD'

    # Test the correct dmesg path of OpenBSDVirtual
    assert openbsd_virtual_obj.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 20:46:13.688164
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()
    assert isinstance(openbsd_virtual, OpenBSDVirtual)

# Generated at 2022-06-20 20:46:16.280446
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert 'vmm' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-20 20:46:19.756340
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_Detected = OpenBSDVirtualCollector._fact_class()
    assert virtual_Detected.platform == 'OpenBSD'

# Generated at 2022-06-20 20:46:30.369385
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.vbox import VBoxVirtual
    from ansible.module_utils.facts.virtual.xen import XENVirtual
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBoxVirtual
    from ansible.module_utils.facts.virtual.vmware import VMWareVirtual
    from ansible.module_utils.facts.virtual.vmm import VMMVirtual

    # VBox
    vbox = VBoxVirtual()
    vbox_facts = vbox.get_virtual_facts()
    assert 'virtualbox' in vbox_facts['virtualization_type']
    assert 'virtualbox' in vbox_facts['virtualization_role']
    assert 'virtualbox' in vbox_facts['virtualization_tech_guest']
    assert 'virtualbox' in vbox_facts