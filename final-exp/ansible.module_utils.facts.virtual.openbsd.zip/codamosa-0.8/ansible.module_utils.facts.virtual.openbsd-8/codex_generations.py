

# Generated at 2022-06-11 05:57:02.165598
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Unit test for method get_virtual_facts of class OpenBSDVirtual
    class VirtualizedOpenBSDVirtual(OpenBSDVirtual):
        VIRTUALIZED_PRODUCT = 'OpenBSD/amd64'
        VIRTUALIZED_VENDOR = 'OpenBSD'

    class VmmOpenBSDVirtual(OpenBSDVirtual):
        DMESG_BOOT = 'tests/fixtures/dmesg.boot.vmm'

    class VirtioOpenBSDVirtual(OpenBSDVirtual):
        DMESG_BOOT = 'tests/fixtures/dmesg.boot.virtio'

    virtualzied_facts = VirtualizedOpenBSDVirtual().get_virtual_facts()
    assert virtualzied_facts['virtualization_type'] == 'openbsd'
    assert virtualzied_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:57:04.582578
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert isinstance(openbsd_virtual_facts.get_virtual_facts(), dict)

# Generated at 2022-06-11 05:57:07.109356
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:57:09.060518
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector({})
    assert openbsd_virtual._platform == 'OpenBSD'
    assert openbsd_virtual._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:57:18.527442
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 05:57:23.615613
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test if the OpenBSD_virtual.get_virtual_facts method return correct results
    # on OpenBSD virtual machine.
    openbsd_virtual = OpenBSDVirtual(None)
    virtual_facts = openbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-11 05:57:33.986090
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    ''' Unit test for method get_virtual_facts of class OpenBSDVirtual '''
    import pytest

    platforms = [
        ('OpenBSD', 'VirtualBox', '', ''),
        ('OpenBSD', 'Unknown', '', ''),
        ('OpenBSD', 'VirtualBox', 'vmware', 'VirtualBox'),
        ('OpenBSD', 'Unknown', 'virtualbox', 'VirtualBox'),
        ('OpenBSD', 'VirtualBox', 'virtualbox', 'VirtualBox'),
        ('OpenBSD', 'Unknown', 'unknown', 'Unknown'),
    ]

# Generated at 2022-06-11 05:57:36.117357
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Initialize a OpenBSDVirtual object
    testobj = OpenBSDVirtual()

    # Get virtualization facts
    testobj.get_virtual_facts()


# Generated at 2022-06-11 05:57:46.608973
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 05:57:48.560286
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.__class__.__name__ == 'OpenBSDVirtualCollector'

# Generated at 2022-06-11 05:57:55.361756
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class is not None, \
           "OpenBSD virtual collector was not instantiated"
    assert openbsd_virtual_collector._fact_class.platform == OpenBSDVirtual._platform, \
           "Wrong virtualization platform"

# Generated at 2022-06-11 05:58:07.455572
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    host_tech = []
    guest_tech = []

# Generated at 2022-06-11 05:58:10.121383
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtualcollector = OpenBSDVirtualCollector()
    assert openbsd_virtualcollector._fact_class == OpenBSDVirtual
    assert openbsd_virtualcollector._platform == 'OpenBSD'

# Generated at 2022-06-11 05:58:12.341465
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-11 05:58:22.281192
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert openbsd_virtual_facts.get_virtual_facts() == {'virtualization_type': '',
                                                        'virtualization_role': '',
                                                        'virtualization_tech_guest': set(),
                                                        'virtualization_tech_host': set()}

    openbsd_virtual_facts = OpenBSDVirtual()
    openbsd_virtual_facts.facts = {'hw.product': 'VMware Virtual Platform'}
    assert openbsd_virtual_facts.get_virtual_facts() == {'virtualization_type': 'vmware',
                                                        'virtualization_role': 'guest',
                                                        'virtualization_tech_guest': {'vmware'},
                                                        'virtualization_tech_host': set()}



# Generated at 2022-06-11 05:58:31.425459
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    module = VirtualCollector._get_module_mock()
    openbsd_virtual = OpenBSDVirtual(module)

    # Test case where it's a physical system

# Generated at 2022-06-11 05:58:39.020444
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of class OpenBSDVirtual
    openbsd_virtual_ins = OpenBSDVirtualCollector.factory()

    # Call get_virtual_facts method of instance openbsd_virtual_ins
    result = openbsd_virtual_ins.get_virtual_facts()
    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_role'] == 'host'
    # For OpenBSD, vmm(4) is the only host virtualization tech supported
    assert result['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-11 05:58:49.128008
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    o = OpenBSDVirtual()
    o.sysctl_data = {
        'machdep.vm_guest': 'other',
    }
    o.dmesg_boot_content = """
vmm0 at mainbus0: VMX/EPT
""".strip()
    virtual_facts = o.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'virtualbox'

    o.sysctl_data = {
        'machdep.vm_guest': 'other',
    }
    del o.dmesg_boot_content
    virtual_facts = o.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:58:59.422495
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Simulate the output of sysctl hw.vendor
    setattr(OpenBSDVirtual, '_sysctl_vendor', ' QEMU ')

    # Simulate the output of sysctl hw.product
    setattr(OpenBSDVirtual, '_sysctl_product', ' Standard PC ')

    # Simulate the output of dmesg.boot
    setattr(OpenBSDVirtual, '_dmesg_boot', 'vmm0 at mainbus0: SVM/RVI\n')

    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'hvm'
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])
   

# Generated at 2022-06-11 05:59:01.364723
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual_collector, OpenBSDVirtualCollector)

# Generated at 2022-06-11 05:59:17.548256
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class TestClass:
        def __init__(self, path, content):
            self.path = path
            self.content = content

        def read(self):
            return self.content

    lines = [
        'vmm0 at mainbus0: AMD SVM',
        'vmm: host: family: 0x16 model: 0x8, 2 CPU',
    ]
    dmesg_boot = TestClass(OpenBSDVirtual.DMESG_BOOT, '\n'.join(lines))
    openbsd_virtual = OpenBSDVirtual(dmesg_boot)

    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-11 05:59:18.333891
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-11 05:59:20.479933
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert type(virtual_facts) == dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 05:59:29.982043
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts_obj = OpenBSDVirtual()
    virtual_facts_obj.sysctl_output = [
        'hw.vendor = QEMU',
        'hw.product = Standard PC (Q35 + ICH9, 2009)'
    ]
    # Returned dict should contain the 'virtualization_type' and
    # 'virtualization_role' keys with values 'hvm' and 'guest' respectively
    assert 'virtualization_type' in virtual_facts_obj.get_virtual_facts()
    assert 'virtualization_role' in virtual_facts_obj.get_virtual_facts()
    assert virtual_facts_obj.get_virtual_facts()['virtualization_type'] == 'hvm'
    assert virtual_facts_obj.get_virtual_facts()['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:59:32.204368
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual = OpenBSDVirtualCollector(None, None, None)
    assert virtual.platform == 'OpenBSD'
    assert virtual._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:59:36.727125
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()
    result = virt.get_virtual_facts()
    assert result == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-11 05:59:44.536856
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 05:59:54.925162
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual = OpenBSDVirtual()
    OpenBSDVirtual.detect_virt_product = lambda x: {'virtualization_tech_guest': 'kvm', 'virtualization_tech_host': 'kvm'}
    OpenBSDVirtual.detect_virt_vendor = lambda x: {'virtualization_tech_guest': 'kvm', 'virtualization_tech_host': 'kvm'}
    OpenBSDVirtual.get_file_content = lambda x: 'vmm0 at mainbus0: SVM/RVI'
    facts = OpenBSDVirtual.get_virtual_facts()
    assert facts['virtualization_tech_host'] == set(['vmm', 'kvm'])
    assert facts['virtualization_tech_guest'] == set(['kvm'])

# Generated at 2022-06-11 05:59:56.165745
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc is not None

# Generated at 2022-06-11 06:00:02.453626
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual({})
    openbsd_virtual.detect_virt_product = lambda x: ({'virtualization_tech_guest': ['kvm'], 'virtualization_tech_host': [], 'virtualization_type': 'kvm', 'virtualization_role': 'guest'})
    openbsd_virtual.detect_virt_vendor = lambda x: ({'virtualization_tech_guest': [], 'virtualization_tech_host': [], 'virtualization_type': '', 'virtualization_role': ''})

    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert 'virtualization_role' in virtual_facts
    assert virtual_

# Generated at 2022-06-11 06:00:14.631189
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-11 06:00:17.770422
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_class = OpenBSDVirtualCollector()
    assert virtual_class._platform == 'OpenBSD'
    assert virtual_class._fact_class.platform == 'OpenBSD'
    assert type(virtual_class._fact_class) is OpenBSDVirtual

# Generated at 2022-06-11 06:00:27.074870
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    openbsd_virtual_instance = OpenBSDVirtual()
    openbsd_virtual_instance.DMESG_BOOT = './test/unit/module_utils/facts/virtual/test_OpenBSD_DMESG_BOOT_vbox'
    virtual_facts = openbsd_virtual_instance.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_product_name' in virtual_facts
    assert 'virtualization_product_version' in virtual_facts
    assert 'virtualization_product_serial' in virtual_facts
    assert 'virtualization_product_uuid' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'vbox'

# Generated at 2022-06-11 06:00:36.812711
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # test fake facts
    fact_class = OpenBSDVirtual(dict())

    fact_class.virtualization_type = 'vmm'
    assert fact_class.get_virtual_facts()['virtualization_type'] == 'vmm'
    assert fact_class.get_virtual_facts()['virtualization_role'] == 'guest'

    fact_class.virtualization_role = 'host'
    assert fact_class.get_virtual_facts()['virtualization_role'] == 'host'

    # test real facts
    virtual_facts = OpenBSDVirtualCollector(dict()).collect()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 06:00:39.627863
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-11 06:00:41.309237
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector


# Generated at 2022-06-11 06:00:48.157478
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    o = OpenBSDVirtual()

    # Only testing for vmware for now
    o.sysctl_all_info = {
        'hw.product': 'VMware Virtual Platform',
        'hw.vendor': 'VMware, Inc.',
    }
    facts = o.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['vmware'])
    assert 'virtualization_tech_host' not in facts



# Generated at 2022-06-11 06:00:51.215710
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual._platform = 'OpenBSD'
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    OpenBSDVirtual._platform = 'Linux'
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

# Generated at 2022-06-11 06:00:58.945695
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """Unit test

    This function is used to execute unit test on OpenBSDVirtual class.
    """

    # Set up class instance
    openbsd_virtual = OpenBSDVirtual()

    # Test result for a OpenBSD guest
    guest_facts = {'virtualization_type': 'vmm',
                   'virtualization_role': 'guest',
                   'virtualization_product_name': 'OpenBSD',
                   'virtualization_product_version': '6.0'}
    test_openbsd_guest_virt_facts = openbsd_virtual.get_virtual_facts()
    assert guest_facts == test_openbsd_guest_virt_facts

# Generated at 2022-06-11 06:01:00.095624
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), OpenBSDVirtualCollector)


# Generated at 2022-06-11 06:01:19.813844
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()
    host_facts = dict()
    host_facts['ansible_product_name'] = 'OpenBSD'
    guest_facts = dict()
    virtual_facts = openbsd_virtual.get_virtual_facts(host_facts, guest_facts)
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_system'] == 'OpenBSD'
    assert virtual_facts['virtualization_product_name'] == ''
    assert not virtual_facts['virtualization_tech_guest'].issubset(virtual_facts['virtualization_tech_host'])

    # Probe with an vmm(4) capable host

# Generated at 2022-06-11 06:01:21.552170
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._fact_class is OpenBSDVirtual
    assert collector._platform == 'OpenBSD'

# Generated at 2022-06-11 06:01:31.860476
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_detect_facts = OpenBSDVirtual({})
    virtual_facts = openbsd_virtual_detect_facts.get_virtual_facts()
    assert virtual_facts['virtualization_type'] in \
        ['', 'container', 'hyperv', 'kvm', 'openvz', 'parallel', 'qemu', 'virtualbox', 'vserver', 'vsphere', 'xen', 'vmm']
    assert virtual_facts['virtualization_role'] in \
        ['', 'guest', 'host']

# Generated at 2022-06-11 06:01:35.916274
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Method get_virtual_facts return a dict with keys
    # virtualization_type and virtualization_role
    instance = OpenBSDVirtual()
    result = instance.get_virtual_facts()
    assert isinstance(result, dict)
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result

# Generated at 2022-06-11 06:01:41.326441
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    facts_virtual = virtual_collector.collect()

    assert facts_virtual['virtualization_type'] == 'vmm'
    assert facts_virtual['virtualization_role'] == 'guest'
    assert facts_virtual['virtualization_tech_guest'] == set(['vmm'])
    assert facts_virtual['virtualization_tech_host'] == set()



# Generated at 2022-06-11 06:01:47.657550
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts_virtual_obj = OpenBSDVirtualCollector()

    # Assert whether the object created is an instance of class Virtual
    assert isinstance(facts_virtual_obj, OpenBSDVirtualCollector)

    # Assert whether the object created is an instance of class VirtualCollector
    assert isinstance(facts_virtual_obj, VirtualCollector)

    # Assert whether the object created is an instance of class OpenBSDVirtual
    assert isinstance(facts_virtual_obj, OpenBSDVirtual)

    # Assert whether base class Virtual class is VirtualOCTEON
    assert issubclass(facts_virtual_obj.__class__, Virtual)

# Generated at 2022-06-11 06:01:55.960924
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Runs the unit test for method get_virtual_facts of class OpenBSDVirtual
    """
    path_to_dmesg_boot = '/tmp/dmesg.boot-test'

    # Case 1: Virtualization tech value is not available in hw.vendor and
    # hw.product
    expected_output = {
        'virtualization_role': 'guest',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    facts = {
        'hw.product': 'OpenBSD',
        'hw.vendor': 'OpenBSD'
    }
    open(path_to_dmesg_boot, 'w').close()

# Generated at 2022-06-11 06:01:58.374314
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-11 06:02:06.720815
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual_facts = {}

    # Test normal case
    with open(OpenBSDVirtual.DMESG_BOOT, 'r') as myfile:
        dmesg_boot = myfile.read()
    virtual.hw_product_regex = (r'(?P<virtualization_type>KVM|Bochs|VMware|VirtualBox)')
    virtual.hw_vendor_regex = (r'(?P<virtualization_type>KVM|Bochs|VMware|VirtualBox)')
    virtual.disable_sysctl = False
    virtual.sysctl_product_regex = (r'(?P<virtualization_type>KVM|Bochs|VMware|VirtualBox)')

# Generated at 2022-06-11 06:02:07.737456
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'

# Generated at 2022-06-11 06:02:45.707821
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual as Fact
    from ansible.module_utils.facts.virtual.sysctl import openbsd_sysctl_virtual_facts as sysctl
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.base import BaseVirtual

    class MockSysctlVirtualSettings(VirtualCollector):
        def __init__(self, platform):
            self._fact_class = sysctl
            self._platform = platform

# Generated at 2022-06-11 06:02:52.950249
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    expected_result = {'virtualization_type': 'vmm',
                       'virtualization_role': 'host',
                       'virtualization_tech_host': set(['vmm']),
                       'virtualization_tech_guest': set(['vmm'])}

    class MockOpenBSDVirtual(OpenBSDVirtual):
        """
        Mocked class needed to avoid reading the file dmesg.boot
        """
        def _get_dmesg_boot(self):
            return "vmm0 at mainbus0: SVM/RVI"

    openbsd_test = MockOpenBSDVirtual()
    openbsd_result = openbsd_test.get_virtual_facts()
    assert openbsd_result == expected_result

# Generated at 2022-06-11 06:03:02.495956
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    module_mock = MagicMock()
    sys_map = {
        'hw.vendor': 'OpenBSD',
        'hw.product': 'VirtualBox',
    }
    virtual_collector = OpenBSDVirtualCollector(module_mock)
    virtual_collector._sysctl_all = lambda: sys_map
    with pytest.raises(NotImplementedError):
        virtual_collector.collect()
    virtual_collector.collect()
    module_mock.exit_json.assert_called_once()
    facts = module_mock.exit_json.call_args[0][0]['ansible_facts']
    assert facts['virtualization_type'] == 'VirtualBox'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:03:04.757434
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual._platform == 'OpenBSD'
    assert openbsd_virtual._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 06:03:06.448239
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'


# Generated at 2022-06-11 06:03:13.026822
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class MockModule:
        def __init__(self, params):
            self.params = params

    class MockAnsibleModule:
        def __init__(self, mock_module):
            self.params = mock_module.params

    module = MockModule({})
    ansible_module = MockAnsibleModule(module)
    openbsd_virtual = OpenBSDVirtual(ansible_module)

    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-11 06:03:21.674482
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Fixture to test class OpenBSDVirtual
    class TestOpenBSDVirtual(OpenBSDVirtual):
        virtualization_type = 'vmm'
        virtualization_role = 'guest'
        virtualization_tech_guest = set()
        virtualization_tech_host = set()
        def detect_virt_product(self, product):
            return {
                'virtualization_type': 'vmm',
                'virtualization_role': 'guest',
                'virtualization_tech_guest': set(),
                'virtualization_tech_host': set(),
            }

# Generated at 2022-06-11 06:03:23.564343
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    instance = OpenBSDVirtualCollector(None)
    assert isinstance(instance, VirtualCollector)
    assert isinstance(instance, OpenBSDVirtualCollector)

# Generated at 2022-06-11 06:03:24.465357
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector().platform == 'OpenBSD'

# Generated at 2022-06-11 06:03:26.904953
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    x = OpenBSDVirtualCollector()
    assert x.platform == 'OpenBSD'

# Generated at 2022-06-11 06:04:39.660922
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Run method get_virtual_facts of class OpenBSDVirtual
    """
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-11 06:04:46.983875
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    expected_facts = {
            # New facts
            'virtualization_type': 'vmm',
            'virtualization_role': 'host',
            'virtualization_tech_guest': set(['vmm', 'xen', 'kvm', 'lxc',
                'jail', 'zones', 'openvz']),
            'virtualization_tech_host': set(['vmm']),

            # Overwritten facts
            'virtualization_system': 'OpenBSD',
    }
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_dmesg_boot_content = \
            lambda: "vmm0 at mainbus0: SVM/RVI"
    openbsd_virtual.get_sysctl_mib_content = \
            lambda mib_name: "OpenBSD"


# Generated at 2022-06-11 06:04:51.842007
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts_obj = OpenBSDVirtual()
    virtual_facts_obj.module.exit_json = lambda a: None
    virtual_facts_obj.get_virtual_facts()
    keys = ['hw_vendor', 'virtualization_role', 'virtualization_type', 'virtualization_tech_host', 'virtualization_tech_guest', 'hw_product']
    assert set(keys).issubset(set(virtual_facts_obj.module.facts))

# Generated at 2022-06-11 06:05:01.437997
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Ensure filtering of empty virtualization_type
    # and virtualization_role keys
    openbsd = OpenBSDVirtual()
    openbsd.FACTS['virtualization_type'] = ''
    openbsd.FACTS['virtualization_role'] = ''
    facts = openbsd.get_virtual_facts()
    # If a virtualization_type or virtualization_role key
    # is empty, it should be filtered out
    assert virtualization_type_re in facts
    assert virtualization_role_re in facts
    assert facts[virtualization_type_re] == ''
    assert facts[virtualization_role_re] == ''
    # Add a non-empty virtualization_type key
    openbsd.FACTS['virtualization_type'] = 'OpenBSD'
    facts = openbsd.get_virtual_facts

# Generated at 2022-06-11 06:05:08.341100
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test an OpenBSD Baremetal system (by default no virtualization)
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_facts = {'virtualization_type': '',
                             'virtualization_role': '',
                             'virtualization_tech_host': set(),
                             'virtualization_tech_guest': set()}
    assert openbsd_virtual_facts == openbsd_virtual.get_virtual_facts()

    # Test an OpenBSD vmm guest system
    openbsd_virtual.facts['hw.vendor'] = 'OpenBSD Project'
    openbsd_virtual.facts['hw.product'] = 'vmm hypervisor'

# Generated at 2022-06-11 06:05:14.269856
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    This is a unit test for the get_virtual_facts method of class OpenBSDVirtual.
    """
    fake_hw_product_facts = {
        'virtualization_type': 'openvz',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': ['openvz'],
        'virtualization_tech_host': ['openvz']
    }

    fake_hw_vendor_facts = {
        'virtualization_type': 'openvz',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': ['openvz'],
        'virtualization_tech_host': ['openvz']
    }


# Generated at 2022-06-11 06:05:16.359261
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual({})
    openbsd_virtual.version = None
    ret = openbsd_virtual.get_virtual_facts()

    assert type(ret) is dict

# Generated at 2022-06-11 06:05:16.784202
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 06:05:23.412281
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import mock
    import sys

    sys.modules['ansible'] = mock.Mock()
    sys.modules['ansible.module_utils'] = mock.Mock()
    sys.modules['ansible.module_utils.facts'] = mock.Mock()
    sys.modules['ansible.module_utils.facts.virtual'] = mock.Mock()

    sys.modules['ansible.module_utils.facts.virtual.sysctl'] = mock.Mock()
    sys.modules['ansible.module_utils.facts.virtual.sysctl.VirtualSysctlDetectionMixin'] = mock.Mock()

# Generated at 2022-06-11 06:05:28.066325
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    result = OpenBSDVirtual().get_virtual_facts()
    assert result['virtualization_type'] in ['','OpenBSD']
    assert result['virtualization_role'] in ['','guest','host']
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()
    assert result['virtualization_product_name'] in ['','OpenBSD']
    assert result['virtualization_product_version'] in ['','OpenBSD']
    assert result['virtualization_product_serial'] in ['','']