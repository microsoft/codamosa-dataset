

# Generated at 2022-06-11 05:56:55.094107
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    test_facts = openbsd_virtual_facts.get_virtual_facts()
    assert type(test_facts) is dict
    assert test_facts.get('virtualization_type') is not None
    assert test_facts.get('virtualization_role') is not None
    assert test_facts.get('virtualization_tech_guest') is not None
    assert test_facts.get('virtualization_tech_host') is not None

# Generated at 2022-06-11 05:57:02.361104
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facter_output = {
        'hw.product': 'OpenBSD',
    }
    facts = OpenBSDVirtualCollector(facter_output, None, None)
    virtual_facts = getattr(facts, 'virtual_facts')
    assert virtual_facts.get('virtualization_type') == ''
    assert virtual_facts.get('virtualization_role') == ''
    assert virtual_facts.get('virtualization_tech_guest') == set()
    assert virtual_facts.get('virtualization_tech_host') == set()

# Unit tests for the class OpenBSDVirtual.

# Generated at 2022-06-11 05:57:03.062614
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:57:07.566974
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt_facts = OpenBSDVirtual().get_virtual_facts()
    assert virt_facts['virtualization_role'] == 'guest'
    assert virt_facts['virtualization_type'] == 'vmm'
    assert 'vmm' in virt_facts['virtualization_tech_guest']
    assert 'vmm' in virt_facts['virtualization_tech_host']


# Generated at 2022-06-11 05:57:10.864227
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class OpenBSDVirtual
    '''
    sut = OpenBSDVirtual()
    facts = sut.get_virtual_facts()
    assert isinstance(facts, dict)
    assert 'virtualization_role' in facts
    assert 'virtualization_type' in facts

# Generated at 2022-06-11 05:57:20.709360
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Setup empty dicts to hold the values computed
    virtual_facts = {}
    guest_tech = set()
    host_tech = set()
    # Define expected values
    virtual_facts_expected = dict()
    virtual_facts_expected['virtualization_type'] = 'vmm'
    virtual_facts_expected['virtualization_role'] = 'host'
    virtual_facts_expected['virtualization_product_name'] = 'unknown'
    virtual_facts_expected['virtualization_product_version'] = 'unknown'
    guest_tech_expected = set()
    host_tech_expected = set(['vmm'])
    # Create an instance of OpenBSDVirtual
    virtual_obj = OpenBSDVirtual()
    # Create an instance of VirtualSysctlDetectionMixin
    virtual_sysctl_obj = VirtualSysctlDetectionMixin

# Generated at 2022-06-11 05:57:23.569011
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:57:24.730449
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector


# Generated at 2022-06-11 05:57:28.439071
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    res = OpenBSDVirtual().get_virtual_facts()
    assert res == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-11 05:57:29.383558
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-11 05:57:34.109880
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:57:36.220160
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    d = OpenBSDVirtualCollector()
    assert OpenBSDVirtualCollector == d.__class__
    assert Virtual == d._fact_class.__base__


# Generated at 2022-06-11 05:57:37.017497
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector

# Generated at 2022-06-11 05:57:40.314237
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual().get_virtual_facts()

    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'


# Generated at 2022-06-11 05:57:50.822297
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    This is a test method for get_virtual_facts() method of class OpenBSDVirtual.
    """
    # Test1: OpenBSD virtual machine
    with open('/dev/null', 'w') as f_dmesg:
        with open('/dev/null', 'w') as f_sysctl:
            f_dmesg.write('vmm0 at mainbus0: VMX/EPT')
            f_sysctl.write('hw.vendor = QEMU')
            f_sysctl.write('hw.product = (null)')

            openbsd_virtual = OpenBSDVirtual()
            openbsd_virtual.dmesg = f_dmesg
            openbsd_virtual.sysctl = f_sysctl
            openbsd_virtual.sysctl.close()
            virtual_facts = openbs

# Generated at 2022-06-11 05:57:55.121178
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual({})

    # Unsupported virt type
    assert virtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_technologies': [''],
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-11 05:57:59.265277
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Validate that __init__ works as expected"""
    openbsd_virtual_facts = OpenBSDVirtualCollector()
    assert openbsd_virtual_facts is not None

# Generated at 2022-06-11 05:58:01.328147
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert isinstance(vc, OpenBSDVirtualCollector)

# Generated at 2022-06-11 05:58:05.349034
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Check whether facts match what VirtualBox or VMWare Fusion provides.
    facts = OpenBSDVirtualCollector().get_facts()
    assert facts['virtualization_role'] in ['host', 'guest']
    assert facts['virtualization_type'] in ['vmware', 'virtualbox', '']

# Generated at 2022-06-11 05:58:07.092205
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-11 05:58:18.692825
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = Virtual()
    virtual_facts = virtual.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_system' in virtual_facts
    assert 'virtualization_environ' in virtual_facts
    assert 'virtualization_technologies' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 05:58:19.281711
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:58:28.770349
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Mock class for sysctl detection
    class SysctlMock:
        def get(self, key):
            if key == 'hw.product':
                return ('VirtualBox', 'VirtualBox')
            if key == 'hw.vendor':
                return ('InnoTek', 'InnoTek')

    # Mock class for dmesg
    class DmesgMock:
        def get(self, key):
            return ''

    openbsd_virtual_obj = OpenBSDVirtual()
    openbsd_virtual_obj.sysctl = SysctlMock()
    openbsd_virtual_obj.dmesg = DmesgMock()

    test_virtual_facts = openbsd_virtual_obj.get_virtual_facts()
    assert test_virtual_facts['virtualization_type'] == 'vbox'


# Generated at 2022-06-11 05:58:37.349937
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual({}).get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert isinstance(virtual_facts['virtualization_type'], str)

    assert 'virtualization_role' in virtual_facts
    assert isinstance(virtual_facts['virtualization_type'], str)

    assert 'virtualization_tech_guest' in virtual_facts
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)

    assert 'virtualization_tech_host' in virtual_facts
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-11 05:58:44.207156
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_subject = OpenBSDVirtual()

# Generated at 2022-06-11 05:58:48.034032
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    result = list()
    file_content = {OpenBSDVirtual.DMESG_BOOT: 'vmm0 at mainbus0: SVM/RVI'}

    def get_file_content_mock(file_name):
        return file_content[file_name]

    OpenBSDVirtual.get_file_content = get_file_content_mock
    virtual = OpenBSDVirtual()
    result.append(virtual.get_virtual_facts())
    return result

if __name__ == '__main__':
    print(test_OpenBSDVirtual_get_virtual_facts())

# Generated at 2022-06-11 05:58:51.383443
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd = OpenBSDVirtualCollector()
    assert openbsd._fact_class == OpenBSDVirtual
    assert openbsd._platform == 'OpenBSD'

# Generated at 2022-06-11 05:58:54.418174
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Constructor of class OpenBSDVirtualCollector does nothing else
    but setting a class variable.
    """
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'

# Generated at 2022-06-11 05:58:57.107238
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o._platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual


# Unit tests for class OpenBSDVirtual

# Generated at 2022-06-11 05:59:01.364479
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    expected_virtual_facts = dict(
        virtualization_type='vmm',
        virtualization_role='host',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(['vmm']))

    openbsd_virtual = OpenBSDVirtual({}, {}, '', 'OpenBSD')

    assert expected_virtual_facts == openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:59:17.431442
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Unit test for OpenBSDVirtual.get_virtual_facts
    """
    # pylint: disable=invalid-name,unused-argument
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualCollector
    from ansible.module_utils.facts.utils import get_file_content
    # Monkey patching get_file_content to force reading a specific file
    original_get_file_content = get_file_content

# Generated at 2022-06-11 05:59:25.850653
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Create an instance of OpenBSDVirtual
    virtual = OpenBSDVirtual({})

    # Create a set of test cases

# Generated at 2022-06-11 05:59:35.835715
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    expected_facts = dict(
        virtualization_type='vmm',
        virtualization_role='host',
        virtualization_tech_host=set(['vmm'])
    )
    dmesg_boot = '''
    vmm0 at mainbus0: SVM/RVI
    em0 at vmm0 emuladdr 0x8c:2:0:0:c:0
    em1 at vmm0 emuladdr 0x8c:2:0:0:c:1
    '''
    fake_open = mock_open(read_data=dmesg_boot)
    with patch('ansible.module_utils.basic.AnsibleModule.open', fake_open, create=True):
        assert OpenBSDVirtual().get_virtual_facts() == expected_facts

# Generated at 2022-06-11 05:59:37.195921
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    module = OpenBSDVirtualCollector()
    assert module.platform == 'OpenBSD'

# Generated at 2022-06-11 05:59:39.758191
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    Collector = OpenBSDVirtualCollector()
    assert isinstance(Collector._fact_class, OpenBSDVirtual)
    assert Collector._platform == 'OpenBSD'


# Generated at 2022-06-11 05:59:41.624584
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-11 05:59:44.294385
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class == OpenBSDVirtual
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-11 05:59:54.749761
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    fake_platform_facts = {
        'kernel': 'OpenBSD',
        'system': 'OpenBSD',
        'hw.product': 'OpenBSD',
        'hw.vendor': 'AMD'
    }

    # Virtualization facts should be empty if we are running on bare-metal
    openbsd_virtual_collector = OpenBSDVirtualCollector(fake_platform_facts)
    virtual_facts = openbsd_virtual_collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''
    assert virtual_facts['virtualization_product_vendor'] == ''

# Generated at 2022-06-11 05:59:58.085076
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Unit test OpenBSDVirtual methods

# Generated at 2022-06-11 06:00:00.408314
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual

# Generated at 2022-06-11 06:00:27.405807
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # GIVEN: OpenBSDVirtual class instance
    openbsd_virtual_fact_instance = OpenBSDVirtual()

    # WHEN: get_virtual_facts is called
    virtual_facts = openbsd_virtual_fact_instance.get_virtual_facts()

    # THEN: Returned data is valid
    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_role'] != ''

# Generated at 2022-06-11 06:00:37.271520
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts, empty_facts = {}, {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_name': ''
    }

    _sysctl = MagicMock(return_value='A')
    _dmesg_boot = MagicMock(return_value='')
    with patch('importlib.import_module'):
        with patch('ansible.module_utils.facts.virtual.base.get_file_content', _dmesg_boot):
            with patch('ansible.module_utils.facts.virtual.openbsd.OpenBSDVirtual._sysctl', _sysctl):
                virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts == empty_facts

    _sysctl = MagicMock(return_value='OpenBSD')

# Generated at 2022-06-11 06:00:44.947450
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    content_vendor = [
        'hw.vendor=QEMU',
        'hw.vendor=VMWare',
        'hw.vendor=Bochs',
        'hw.vendor=Virtual Machine',
        'hw.vendor=Microsoft Corporation',
        'hw.vendor=Red Hat, Inc.',
        'hw.vendor=Amazon EC2',
        'hw.vendor=Google',
        'hw.vendor=Huawei Technologies'
    ]


# Generated at 2022-06-11 06:00:51.401380
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    virtual = OpenBSDVirtual()
    facts = virtual.get_virtual_facts()

    assert type(facts) is dict
    assert type(facts['virtualization_tech_guest']) is set
    assert type(facts['virtualization_tech_host']) is set

    assert type(facts['virtualization_role']) is str
    assert facts['virtualization_role'] in ['guest', 'host', '']

    assert type(facts['virtualization_type']) is str
    assert facts['virtualization_type'] in ['vmm', 'xen', '', 'hv']

# Generated at 2022-06-11 06:00:59.646341
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.module = MockModule()

    # dmesg.boot not set
    openbsd_virtual.get_file_content = lambda x: ''
    facts = openbsd_virtual.get_virtual_facts()
    assert facts == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(),
                     'virtualization_tech_guest': set()}

    # dmesg.boot set
    openbsd_virtual.get_file_content = lambda x: "vmm0 at mainbus0: SVM/RVI\n"
    facts = openbsd_virtual.g

# Generated at 2022-06-11 06:01:08.993847
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    # test 1

# Generated at 2022-06-11 06:01:14.634057
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    class MockOpenBSDVirtual(OpenBSDVirtual):

        def detect_virt_product(self, sysctl_value):
            return {'virtualization_type_product': 'virtualization_type_product',
                    'virtualization_type_version': 'virtualization_type_version',
                    'virtualization_role_guest': 'virtualization_role_guest',
                    'virtualization_role_host': 'virtualization_role_host',
                    'virtualization_role': 'virtualization_type',
                    'virtualization_type': 'virtualization_type',
                    'virtualization_type_hypervisor': 'virtualization_type_hypervisor',
                    'virtualization_tech_guest': 'virtualization_tech_guest',
                    'virtualization_tech_host': 'virtualization_tech_host'
                    }


# Generated at 2022-06-11 06:01:22.440389
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import os
    import sys
    here = os.path.abspath(os.path.dirname(__file__))
    sys.path.append(os.path.join(here, '../../..'))

    from ansible.module_utils.facts import virtual

    # Create a dummy /var/run/dmesg.boot
    with open('dmesg.boot', 'w') as f:
        f.write('vmm0 at mainbus0: SVM/RVI')

    detection_obj = virtual.OpenBSDVirtual()
    virtual_facts = detection_obj.get_virtual_facts()


# Generated at 2022-06-11 06:01:32.870492
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 06:01:42.373982
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {},
    }

    # Create a fake OpenBSDVirtual class using the VirtualCollector
    # as a base class, with a get_file_content method that returns
    # a fake dmesg_boot content.
    class FakeOpenBSDVirtual(OpenBSDVirtualCollector):
        def get_file_content(filename):
            if filename != OpenBSDVirtual.DMESG_BOOT:
                return ''


# Generated at 2022-06-11 06:02:45.600530
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    '''Constructor of class OpenBSDVirtualCollector'''
    # check if instance created
    facts_virtual = OpenBSDVirtualCollector()
    # check if instance of class OpenBSDVirtualCollector
    assert isinstance(facts_virtual, OpenBSDVirtualCollector)
    # check if _fact_class is set to OpenBSDVirtual
    assert facts_virtual._fact_class == OpenBSDVirtual
    # check if _platform is set to OpenBSD
    assert facts_virtual._platform == 'OpenBSD'

# Generated at 2022-06-11 06:02:53.108484
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of class OpenBSDVirtual for testing
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl = {'hw.product': 'VMWare Virtual Platform',
                              'hw.vendor': 'VMWare, Inc.'}

    # OpenBSD VM
    openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual.virtual_facts['virtualization_type'] == 'virt'
    assert openbsd_virtual.virtual_facts['virtualization_role'] == 'guest'
    assert 'virtio' in openbsd_virtual.virtual_facts['virtualization_tech_guest']
    assert 'vmware' in openbsd_virtual.virtual_facts['virtualization_tech_host']

# Generated at 2022-06-11 06:02:55.718486
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    # get_virtual_facts() should return a dict
    assert isinstance(openbsd_virtual.get_virtual_facts(), dict)

# Generated at 2022-06-11 06:03:04.871950
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Create virtual facts object
    virtual_facts = OpenBSDVirtual()
    # Create a dmesg.boot representing a vmm host

# Generated at 2022-06-11 06:03:10.552453
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 06:03:12.605475
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert isinstance(c, VirtualCollector)
    assert isinstance(c, OpenBSDVirtualCollector)

# Generated at 2022-06-11 06:03:15.183626
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    openbsd_virtual_collector.get_virtual_facts()

# Generated at 2022-06-11 06:03:17.439397
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualCollector
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'

# Generated at 2022-06-11 06:03:19.175255
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDVirtual


# Generated at 2022-06-11 06:03:24.550894
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 06:05:42.848127
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()

    assert openbsd_virtual_facts.get_virtual_facts() == {
        'virtualization_role': 'host',
        'virtualization_tech_host': {'vmm'},
        'virtualization_tech_guest': set(),
        'virtualization_type': 'vmm',
    }

# Generated at 2022-06-11 06:05:45.037299
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-11 06:05:52.123285
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible_collections.ansible.community.plugins.module_utils._text import to_text

    # Setup the test data
    module_name = 'ansible_collections.ansible.community.plugins.modules.system.setup'
    kwargs = {'ansible_facts': {'kernel': 'OpenBSD'}, 'ansible_module_name': module_name}

    # Create the 'OpenBSDVirtualCollector' object
    c = OpenBSDVirtualCollector(**kwargs)
    v = c.collect()[0]

    # Check the facts returned by method 'get_virtual_facts'
    facts = v.get_virtual_facts()

    # Check output from OpenBSD 6.4
    kwargs['ansible_facts']['product_name'] = 'VMWare Virtual Platform'

# Generated at 2022-06-11 06:05:54.220966
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virt_collector = OpenBSDVirtualCollector()
    assert virt_collector.platform == 'OpenBSD'
    assert virt_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-11 06:05:56.008716
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual, OpenBSDVirtualCollector)


# Generated at 2022-06-11 06:06:00.627774
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Inject data
    sysctl = {'hw.product': None, 'hw.vendor': None}
    virtual_facts = OpenBSDVirtual().get_virtual_facts({'sysctl': sysctl})
    # Test assert
    assert virtual_facts == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(),
                             'virtualization_type': '', 'virtualization_role': ''}


# Generated at 2022-06-11 06:06:02.001273
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._fact_class.platform == 'OpenBSD'


# Generated at 2022-06-11 06:06:03.203864
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Make sure the constructor actually calls VirtualCollector constructor
    OpenBSDVirtualCollector()

# Generated at 2022-06-11 06:06:04.631995
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual({}).get_virtual_facts()
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-11 06:06:12.645277
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Test OpenBSDVirtual.get_virtual_facts()
    """
    # pylint: disable=import-error,no-name-in-module
    from ansible.module_utils.facts.virtual.openbsd.test_data import openbsd_virtual_test_data
    from ansible.module_utils.facts.virtual.openbsd.test_data import openbsd_virtual_get_virtual_facts_test_data
    for test in openbsd_virtual_get_virtual_facts_test_data:
        # Create the test instance of the class
        test_instance = OpenBSDVirtual()

        # Define the dmesg boot file content