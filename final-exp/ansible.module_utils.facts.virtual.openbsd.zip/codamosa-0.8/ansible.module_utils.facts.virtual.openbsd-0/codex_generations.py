

# Generated at 2022-06-11 05:57:05.123704
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()

# Generated at 2022-06-11 05:57:07.182917
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual



# Generated at 2022-06-11 05:57:10.438249
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._name == 'virt_openbsd'

# Generated at 2022-06-11 05:57:14.817086
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    This function is responsible for unittest OpenBSDVirtualCollector class
    """
    openbsd_virtual_collector_obj = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector_obj.platform == 'OpenBSD'
    assert openbsd_virtual_collector_obj.fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:57:18.574118
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual_collector = OpenBSDVirtualCollector()

    # Test if the method get_virtual_facts return a dict
    assert isinstance(openbsd_virtual_collector.get_virtual_facts(), dict)

# Generated at 2022-06-11 05:57:28.487264
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.detect_virt_product = lambda x: {
        'virtualization_type': 'vmware',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set(['vmware host'])}
    openbsd_virtual.detect_virt_vendor = lambda x: {
        'virtualization_type': 'vbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vbox']),
        'virtualization_tech_host': set(['vbox host'])}

# Generated at 2022-06-11 05:57:31.831761
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-11 05:57:36.082098
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    # Common values
    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_role'] != ''
    assert virtual_facts['virtualization_tech_guest'] != set()
    assert virtual_facts['virtualization_tech_host'] != set()

# Generated at 2022-06-11 05:57:39.361929
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-11 05:57:40.569441
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-11 05:57:49.724867
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual().get_virtual_facts()
    assert facts['virtualization_type'] in ['', 'vmm', 'bhyve', 'virtualbox']
    assert facts['virtualization_role'] in ['', 'guest', 'host']

# Generated at 2022-06-11 05:57:51.921185
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDVirtual



# Generated at 2022-06-11 05:57:53.743799
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-11 05:57:54.565216
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtualCollector().collect()

# Generated at 2022-06-11 05:58:06.391738
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 05:58:11.881396
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()

    # Virtual facts to test
    openbsd_virtual_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm']),
    }

    returned_facts = virtual.get_virtual_facts()
    assert returned_facts == openbsd_virtual_facts


# Generated at 2022-06-11 05:58:14.378522
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual_collector, OpenBSDVirtualCollector)


# Generated at 2022-06-11 05:58:19.279463
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual(None)

    result = virtual_facts.get_virtual_facts()
    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_role'] == 'host'
    assert result['virtualization_tech_host'] == {'vmm'}
    assert result['virtualization_tech_guest'] == set()


# Generated at 2022-06-11 05:58:23.331803
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector.facts == {}


# Generated at 2022-06-11 05:58:26.632152
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-11 05:58:44.269789
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Test the method get_virtual_facts.
    """

    # Sample dmesg.boot output

# Generated at 2022-06-11 05:58:52.194065
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_OpenBSDVirtual = OpenBSDVirtual()
    test_OpenBSDVirtual.sysctl = {'hw.vendor': 'QEMU', 'hw.product': 'Standard PC (i440FX + PIIX, 1996)'}

    # Test 1: sysctl is not set
    test_OpenBSDVirtual.sysctl = None
    virtual_facts = test_OpenBSDVirtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == {'kvm', 'qemu'}
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test 2: hw.vendor is not set

# Generated at 2022-06-11 05:58:54.416559
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virt = OpenBSDVirtualCollector()
    assert virt.platform == 'OpenBSD'
    assert virt._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:59:00.685332
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    expected_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'hvm',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['hvm']),
        'virtualization_product': 'Amazon EC2',
    }
    # Set the hw.product for this test
    v.sysctl = {'hw.product': 'Amazon EC2'}

    # Test the get_virtual_facts method
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts == expected_facts

# Generated at 2022-06-11 05:59:02.864772
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDVirtual


# Generated at 2022-06-11 05:59:06.823604
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    linux_virtual = OpenBSDVirtual()
    facts = linux_virtual.get_virtual_facts()

    # Values returned by get_virtual_facts() should be in keys of
    # _virtual_facts dictionary, defined in Virtual class.
    assert all(key in linux_virtual._virtual_facts for key in facts)

# Generated at 2022-06-11 05:59:17.154748
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.dmesg_boot = 'test/data/dmesg.boot.test_openbsd'
    openbsd_virtual.sysctl_name = 'test/data/sysctl_virtual.test_openbsd'
    openbsd_virtual.sysctl_value = 'test/data/sysctl_vendor.test_openbsd'
    openbsd_virtual.sysctl_vm = 'test/data/sysctl_vm.test_openbsd'
    openbsd_virtual.sysctl_hw_vendor = 'test/data/sysctl_hw_vendor.test_openbsd'
    openbsd_virtual.sysctl_hw_product = 'test/data/sysctl_hw_product.test_openbsd'



# Generated at 2022-06-11 05:59:22.444429
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Test OpenBSDVirtual.get_virtual_facts()
    """
    vm = OpenBSDVirtual(module=None)

    # Test VM running on a OpenBSD host
    facts = vm.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set(['vmm'])
    assert facts['virtualization_tech_guest'] == set(['vmm'])


# Generated at 2022-06-11 05:59:23.024452
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-11 05:59:25.137812
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert(vc._fact_class == OpenBSDVirtual)
    assert(vc._platform == 'OpenBSD')

# Generated at 2022-06-11 05:59:37.434080
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual.get_virtual_facts()

# Generated at 2022-06-11 05:59:38.772471
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector(None)

# Generated at 2022-06-11 05:59:40.097875
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-11 05:59:45.077159
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    mock_module = MockModule()
    mock_module.virtual = OpenBSDVirtual(module=mock_module)
    assert mock_module.virtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-11 05:59:51.960051
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_OpenBSDVirtual = OpenBSDVirtual()
    test_OpenBSDVirtual.detect_virt_product = fake_detect_virt_product
    test_OpenBSDVirtual.detect_virt_vendor = fake_detect_virt_vendor
    test_OpenBSDVirtual.get_sysctl = fake_get_sysctl
    test_OpenBSDVirtual.get_file_content = fake_get_file_content
    test_OpenBSDVirtual.get_virtual_facts()

# Unit test helper functions

# Generated at 2022-06-11 06:00:00.427167
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl_files = ['test/files/sysctl/openbsd/*']
    openbsd_virtual.add_sysctl_info()

    dmesg_boot_content = ('vmm0 at mainbus0: SVM/RVI\n'
                          'vmm1 at mainbus0: VMX/EPT')
    openbsd_virtual.get_file_content = lambda path: dmesg_boot_content


# Generated at 2022-06-11 06:00:06.199285
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])
    assert virtual_facts['virtualization_sysctl'] == 'hw.vendor'

# Generated at 2022-06-11 06:00:09.874420
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # GIVEN a OpenBSDVirtual object
    module_executor = OpenBSDVirtual()

    # WHEN get_virtual_facts() is called, THEN it should return some fact
    assert(module_executor.get_virtual_facts() is not None)

# Generated at 2022-06-11 06:00:13.753875
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    facts = v.get_virtual_facts()

    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'vmm'

    assert 'virtualization_tech_host' not in facts
    assert 'virtualization_tech_guest' in facts
    assert 'vmm' in facts['virtualization_tech_guest']



# Generated at 2022-06-11 06:00:21.024481
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    if OpenBSDVirtualCollector._platform != 'OpenBSD':
        assert False, "OpenBSDVirtualCollector is not for OpenBSD!"
    if OpenBSDVirtualCollector._fact_class.platform != 'OpenBSD':
        assert False, "OpenBSDVirtualCollector did not set _fact_class to OpenBSDVirtual!"
    if OpenBSDVirtualCollector._fact_class.DMESG_BOOT != '/var/run/dmesg.boot':
        assert False, "OpenBSDVirtualCollector did not set DMESG_BOOT for OpenBSDVirtual!"
    return True

# Generated at 2022-06-11 06:00:48.372582
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_class = OpenBSDVirtual()
    test_class.BASIC_FACTS = {'kernel': 'OpenBSD'}
    test_class.SYSCTL_VIRT_PRODUCT = {'hw.product': 'OpenBSD OpenVM'}
    expected_facts = {'virtualization_type': 'virtualbox',
                      'virtualization_role': 'guest'}
    actual_facts = test_class.get_virtual_facts()
    assert expected_facts == actual_facts

# Generated at 2022-06-11 06:00:53.382906
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import json
    import platform

    test_platform = platform.system()
    if test_platform != OpenBSDVirtual.platform:
        raise Exception('test_OpenBSDVirtual_get_virtual_facts can only be called on OpenBSD')

    v = OpenBSDVirtualCollector()
    v.collect()
    tmp = v.get_facts()
    data = dict()
    data.update(tmp)
    with open('/tmp/ansible_facts.json', 'w') as f:
        json.dump(data, f)

# Generated at 2022-06-11 06:00:56.351739
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert isinstance(c, OpenBSDVirtualCollector)
    assert isinstance(c.get_virtual_facts(), dict)

# Generated at 2022-06-11 06:01:01.329850
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class OpenBSDVirtual
    """
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in openbsd_virtual_facts
    assert isinstance(openbsd_virtual_facts['virtualization_type'], str)
    assert 'virtualization_role' in openbsd_virtual_facts
    assert isinstance(openbsd_virtual_facts['virtualization_role'], str)

# Generated at 2022-06-11 06:01:10.785825
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    input_values = [
        {
            'hw.product': 'VirtualBox',
            'hw.vendor': 'QEMU'
        },
        {
            'hw.product': 'VirtualBox',
            'hw.vendor': 'OpenBSD'
        },
        {
            'hw.product': 'VirtualBox',
            'hw.vendor': 'OpenBSD'
        }
    ]

# Generated at 2022-06-11 06:01:19.359493
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import VirtualOpenBSDDetectionMixin

# Generated at 2022-06-11 06:01:25.384669
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 06:01:35.533938
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    module = OpenBSDVirtualCollector()

# Generated at 2022-06-11 06:01:38.748407
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # The constructor should work without arguments
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class.__name__ == 'OpenBSDVirtual'
    assert collector._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-11 06:01:42.934884
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    This function is a unit test for the constructor of class
    OpenBSDVirtualCollector.
    """
    collector = OpenBSDVirtualCollector()
    assert isinstance(collector, OpenBSDVirtualCollector)
    assert isinstance(collector._fact_class, OpenBSDVirtual)
    assert collector._platform == 'OpenBSD'

# Generated at 2022-06-11 06:02:48.239689
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Virtual facts are based on dmesg.boot, so we need to patch the
    # contents
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    original_dmesg_boot = OpenBSDVirtual.DMESG_BOOT
    OpenBSDVirtual.DMESG_BOOT = './test/unit/module_utils/facts/virtual/openbsd/dmesg.boot'

    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'vmm' in virtual_facts['virtualization_tech_host']
    assert virtual_facts['virtualization_tech_guest'] == set()

    # Restore the original

# Generated at 2022-06-11 06:02:49.953801
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.fact_class == OpenBSDVirtual
    assert o._platform == 'OpenBSD'

# Generated at 2022-06-11 06:02:59.006943
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Set some test data.
    test_data = {
        'hw.product': '',
        'hw.vendor': '',
        'hw.machine': 'amd64',
        'hw.model': '',
    }

    # Create an instance of OpenBSDVirtual
    virtual = OpenBSDVirtual(module_args=dict())

    # Set the test data
    virtual.sysctl = test_data

    # Call the get_virtual_facts method
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-11 06:03:07.315922
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """Unit test to get OpenBSD virtual facts."""
    fake_product = {
        'virtual_sysctl_values': [{'dev.vmware.0.product': 'VMWare Virtual Platform'}],
        'virtualization_role': 'guest',
        'virtualization_type': 'vmware',
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set([]),
    }

# Generated at 2022-06-11 06:03:09.020622
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Expected outcome: return 1 object of class OpenBSDVirtualCollector
    assert isinstance(OpenBSDVirtualCollector(), OpenBSDVirtualCollector)

# Generated at 2022-06-11 06:03:11.396845
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._fact_class == OpenBSDVirtual
    assert obj._platform == 'OpenBSD'


# Generated at 2022-06-11 06:03:14.849957
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Constructor of OpenBSDVirtualCollector class should return a
    OpenBSDVirtualCollector object with _platform set to OpenBSD.
    """
    result = OpenBSDVirtualCollector()
    assert result._platform == 'OpenBSD'

# Generated at 2022-06-11 06:03:16.918038
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    v = OpenBSDVirtualCollector()
    assert v._platform == 'OpenBSD'
    assert v._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 06:03:22.880353
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    class CopyOpenBSDVirtualCollector(OpenBSDVirtualCollector):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            OpenBSDVirtualCollector.__init__(self,
                                             *args,
                                             **kwargs)
    inst_OpenBSDVirtualCollector = CopyOpenBSDVirtualCollector()
    # Check that class attributes are successfully created
    assert inst_OpenBSDVirtualCollector.args == ()
    assert inst_OpenBSDVirtualCollector.kwargs == {}
    assert inst_OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert inst_OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-11 06:03:26.646558
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()
    virtual_facts = virt.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type'] == ''
    assert 'virtualization_tech_guest' not in virtual_facts
    assert 'virtualization_tech_host' not in virtual_facts

# Generated at 2022-06-11 06:05:46.046442
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # expected keys in facts
    expected_fact_keys = [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_host',
        'virtualization_tech_guest'
    ]
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector.fact_class == OpenBSDVirtual
    assert collector.fact_keys == expected_fact_keys


# Generated at 2022-06-11 06:05:53.076608
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Empty facts
    virtual_fact = {}
    virtual_fact['virtualization_type'] = ''
    virtual_fact['virtualization_role'] = ''
    virtual_fact['virtualization_system'] = ''
    virtual_fact['virtualization_product_name'] = ''
    virtual_fact['virtualization_product_version'] = ''
    virtual_fact['virtualization_technologies'] = []
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_fact == virtual_facts

    # Host/product facts
    virtual_fact = {}
    virtual_fact['virtualization_type'] = 'vmm'
    virtual_fact['virtualization_role'] = 'host'
    virtual_fact['virtualization_system'] = ''
    virtual_fact['virtualization_product_name'] = ''

# Generated at 2022-06-11 06:05:58.949103
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    # Test that the OpenBSDVirtual.get_virtual_facts() method does not return
    # 'virtualization_type' = 'physical' for OpenBSD on physical hardware
    # and does not return 'virtualization_type' = 'virtualbox' for
    # OpenBSD on physical hardware

    assert(virtual_facts['virtualization_type'] != 'virtualbox')
    assert(virtual_facts['virtualization_type'] != 'physical')
    assert(virtual_facts['virtualization_type'] != None)

# Generated at 2022-06-11 06:06:00.259368
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    v = OpenBSDVirtualCollector()
    assert isinstance(v, OpenBSDVirtualCollector)


# Generated at 2022-06-11 06:06:01.322763
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert c.platform == 'OpenBSD'

# Generated at 2022-06-11 06:06:03.439286
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-11 06:06:06.348408
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    expected = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_host=set(),
        virtualization_tech_guest=set(),
    )
    result = OpenBSDVirtual().get_virtual_facts()
    assert result == expected

# Generated at 2022-06-11 06:06:14.674275
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Test fixture to provide context
    class TestFixtureModule:
        sysctl = {}

    # Create OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Create test fixture
    test_module = TestFixtureModule()

    # Set test fixture
    openbsd_virtual.module = test_module

    # Check the get_virtual_facts return value
    test_fixture_expected = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    assert openbsd_virtual.get_virtual_facts() == test_fixture_expected

    # Test 1: CPU virtualization features
    # Set test fixture

# Generated at 2022-06-11 06:06:15.456793
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-11 06:06:24.059095
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Initialize mock module
    module = AnsibleModuleMock()
    module.return_value = {'virtualization_type': '', 'virtualization_role': ''}

    # Initialize mock file handle
    dmesg_boot_mock = FileMock('/var/run/dmesg.boot')
    dmesg_boot_mock.set_contents('hw.product=VirtualBox\nhw.vendor=Intel\nvmm0 at mainbus0: SVM/RVI')

    # Initialize mock file handle
    sysctl_mock = FileMock('/proc/sysctl')
    sysctl_mock.set_contents('hw.vendor=Intel\nhw.product=VirtualBox')

    openbsd_virtual = OpenBSDVirtual(module)
    openbsd_virtual_facts = open