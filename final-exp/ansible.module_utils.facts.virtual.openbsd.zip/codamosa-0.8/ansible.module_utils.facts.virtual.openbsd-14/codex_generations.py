

# Generated at 2022-06-11 05:57:04.214766
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()


# Generated at 2022-06-11 05:57:11.044180
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 05:57:17.847814
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

    assert set(openbsd_virtual.facts['virtualization_tech_guest']) == set(['vmm'])
    assert set(openbsd_virtual.facts['virtualization_tech_host']) == set(['vmm'])
    assert openbsd_virtual.facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual.facts['virtualization_role'] == 'host'

# Generated at 2022-06-11 05:57:19.565389
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual._platform == 'OpenBSD'

# Generated at 2022-06-11 05:57:20.497214
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-11 05:57:25.411607
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd = OpenBSDVirtual()
    virtual_facts = openbsd.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:57:35.389459
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
            }

    virtual_facts_sysctl_host = {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
            }

    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtualization_facts = lambda: virtual_facts
    openbsd_virtual.get_virtualization_facts_sysctl = lambda: virtual_facts_sysctl_host
    openbsd_virtual.get_virtual_facts()

    assert openbsd_virtual.virtualization

# Generated at 2022-06-11 05:57:36.828859
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert not (OpenBSDVirtualCollector._platform is None)
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:57:38.232350
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:57:49.041395
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            raise Exception("fail_json called")


# Generated at 2022-06-11 05:57:54.372005
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual.fact_class == OpenBSDVirtual
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-11 05:57:57.118668
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual({}, None)
    output = virt.get_virtual_facts()
    assert output == {}

# Generated at 2022-06-11 05:58:07.045962
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt_vendor_facts = {'virtualization_type': '',
                         'virtualization_role': 'guest'}
    virt_product_facts = {'virtualization_type': '',
                          'virtualization_role': 'guest'}

    class MockOpenBSDVirtual(OpenBSDVirtual):
        def detect_virt_vendor(self, uname_field):
            return virt_vendor_facts
        def detect_virt_product(self, uname_field):
            return virt_product_facts
        def detect_virt_vendor_product(self, uname_field):
            return virt_vendor_facts

    virtual_facts = MockOpenBSDVirtual()
    virtual_facts.get_virtual_facts() is not None


# Generated at 2022-06-11 05:58:16.753274
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test if method works with a dmesg.boot that does not contain
    # vmm(4) related information
    openbsd_virtual_1 = OpenBSDVirtual(content=[])
    virtual_facts_1 = openbsd_virtual_1.get_virtual_facts()
    assert virtual_facts_1['virtualization_type'] == ''
    assert virtual_facts_1['virtualization_role'] == ''

    # Test if method works with a dmesg.boot that contains vmm(4)
    # related information
    openbsd_virtual_2 = OpenBSDVirtual(content=['vmm0 at mainbus0: SVM/RVI'])
    virtual_facts_2 = openbsd_virtual_2.get_virtual_facts()
    assert virtual_facts_2['virtualization_type'] == 'vmm'
   

# Generated at 2022-06-11 05:58:20.455444
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtualCollector._fact_class
    assert openbsd_virtual_collector._platform == OpenBSDVirtualCollector._platform


# Generated at 2022-06-11 05:58:22.189415
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:58:27.967942
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    result = OpenBSDVirtual().get_virtual_facts()
    assert set(result.keys()) == { 'virtualization_type',
                                   'virtualization_role',
                                   'virtualization_technologies',
                                   'virtualization_tech_host',
                                   'virtualization_tech_guest'}
    assert isinstance(result['virtualization_tech_guest'], set)
    assert isinstance(result['virtualization_tech_host'], set)


# Generated at 2022-06-11 05:58:32.466218
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # For now, just check if it actually works and returns a dictionary
    # with the relevant keys
    facts = OpenBSDVirtual.get_virtual_facts()
    assert type(facts) is dict
    assert {'virtualization_type', 'virtualization_role',
            'virtualization_tech_host', 'virtualization_tech_guest'}.issubset(facts.keys())

# Generated at 2022-06-11 05:58:35.155023
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-11 05:58:36.838837
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    instance = OpenBSDVirtualCollector()
    assert instance.platform == 'OpenBSD'


# Generated at 2022-06-11 05:58:49.449042
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts

    if 'virtualization_tech_guest' in virtual_facts:
        assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    if 'virtualization_tech_host' in virtual_facts:
        assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-11 05:58:59.484979
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tmp = {}
    tmp['hw.product'] = 'OpenBSD'
    tmp['hw.vendor'] = 'boogie'
    tmp['hw.vendor'] = 'OpenBSD'

    virt = OpenBSDVirtual(module=None, commands=tmp)
    virtual_facts = virt.get_virtual_facts()

    assert len(virtual_facts) == 6
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']
    assert virtual_facts['virtualization_role'] == 'guest'

    tmp = {}
    tmp['hw.product'] = 'OpenBSD'
    tmp['hw.vendor'] = 'OpenBSD'


# Generated at 2022-06-11 05:59:01.458356
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
   openbsd_virtual_collector = OpenBSDVirtualCollector()
   assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:59:02.437341
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector()

# Generated at 2022-06-11 05:59:12.697854
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-11 05:59:13.991735
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert c.platform == 'OpenBSD'
    assert c._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:59:22.387541
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()

    # Test on a physical machine
    tests = [v.get_virtual_facts()]
    expected = [{'virtualization_type': '',
                 'virtualization_role': '',
                 'virtualization_products': set([]),
                 'virtualization_vendors': set([]),
                 'virtualization_tech_host': set([]),
                 'virtualization_tech_guest': set([])}]
    assert tests == expected

    # Reset the test case
    tests = []
    expected = []

    # Test on a virtual machine: VMWare
    v._hw_data_file_content['hw.product'] = 'VMware Virtual Platform'
    v._hw_data_file_content['hw.vendor'] = 'VMware, Inc.'


# Generated at 2022-06-11 05:59:27.982719
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    This function is the unit test for the constructor of class OpenBSDVirtualCollector.
    It checks if the obj is of the correct type and whether the _platform and _fact_class
    data attributes are initialized correctly.
    """
    obj = OpenBSDVirtualCollector()
    assert(isinstance(obj, OpenBSDVirtualCollector))
    assert(obj._fact_class == OpenBSDVirtual)
    assert(obj._platform == OpenBSDVirtualCollector._platform)

# Generated at 2022-06-11 05:59:35.234286
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_obj = OpenBSDVirtual()
    # We have to fake this to avoid the ImportError exception:
    # ModuleNotFoundError: No module named 'ansible_collections'
    openbsd_virtual_obj.platform = 'OpenBSD'

    openbsd_virtual_facts = openbsd_virtual_obj.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'host'


# Generated at 2022-06-11 05:59:38.151826
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert isinstance(vc, VirtualCollector)
    assert isinstance(vc._fact_class, OpenBSDVirtual)
    assert vc._platform == 'OpenBSD'

# Generated at 2022-06-11 05:59:59.098165
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    # Mock a set of facts returned by VirtualSysctlDetectionMixin.detect_virt_product
    openbsd_virtual.detect_virt_product = lambda key: {'virtualization_type': 'vmm',
                                                       'virtualization_role': 'guest',
                                                       'virtualization_tech_guest': {'vmm'},
                                                       'virtualization_tech_host': set()}

    # Mock a set of facts returned by VirtualSysctlDetectionMixin.detect_virt_vendor

# Generated at 2022-06-11 06:00:00.226384
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.platform == 'OpenBSD'

# Generated at 2022-06-11 06:00:07.973121
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OPENBSD_VIRTUAL_FACTS = {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmm',
        'virtualization_tech_guest': {'vmm'},
        'virtualization_tech_host': set()
    }

    virtual = OpenBSDVirtual()
    virtual._sysctl = {
        'hw.product': 'VirtualBox',
        'hw.vendor': 'Oracle'
    }

    facts = virtual.get_virtual_facts()
    assert facts == OPENBSD_VIRTUAL_FACTS

# Generated at 2022-06-11 06:00:08.894063
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-11 06:00:12.594416
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = OpenBSDVirtualCollector(None, None, None).collect()
    facts_list = list(facts.keys())
    assert 'virtualization_type' in facts_list
    assert 'virtualization_role' in facts_list
    assert 'virtualization_tech_host' in facts_list
    assert 'virtualization_tech_guest' in facts_list

# Generated at 2022-06-11 06:00:20.528529
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmm',
        'virtualization_tech_guest': {'vmm'}
    }
    openbsd_virtual = OpenBSDVirtual({})
    result = openbsd_virtual.get_virtual_facts()
    assert result.keys() == openbsd_virtual_facts.keys()
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_tech_guest'] == openbsd_virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-11 06:00:21.515902
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-11 06:00:30.611440
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a mock class which will return a dmesg_boot content
    # with a line showing that it is a vmware virtual host
    class MockOpenBSDVirtual:
        platform = 'OpenBSD'
        DMESG_BOOT = '/var/run/dmesg.boot'
        def get_file_content(self, file):
            return 'vmm0 at mainbus0: SVM/RVI'

    # Test vmm and vmware
    openbsd_virtual = MockOpenBSDVirtual()
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'

    # Test OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    virtual_facts = openbsd_

# Generated at 2022-06-11 06:00:33.082684
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_facts = OpenBSDVirtualCollector()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts._fact_class == OpenBSDVirtual


# Generated at 2022-06-11 06:00:37.937728
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual({'ansible_system': 'OpenBSD', 'ansible_virtual': 'kvm'})
    openbsd_virtual.get_virtual_facts() == {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-11 06:01:11.157097
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    OpenBSDVirtual._platform = 'OpenBSD'
    OpenBSDVirtual._module_path = 'ansible.module_utils.facts.virtual.openbsd'
    OpenBSDVirtual._sysctl_cmd = '/sbin/sysctl'

    v = OpenBSDVirtual()
    # pylint: disable=protected-access
    v._dmesg_virt_detection = {
        'vmm0': {'virtualization_type': 'vmm', 'virtualization_role': 'host'},
    }

# Generated at 2022-06-11 06:01:13.161587
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    ovc = OpenBSDVirtualCollector()
    assert isinstance(ovc, OpenBSDVirtualCollector)

# Unit test of class OpenBSDVirtual

# Generated at 2022-06-11 06:01:15.866358
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-11 06:01:17.021536
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # No exception should be triggered
    assert OpenBSDVirtualCollector(OpenBSDVirtual) == None

# Generated at 2022-06-11 06:01:19.528846
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_ins = OpenBSDVirtual()
    result = openbsd_virtual_ins.get_virtual_facts()

    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''
    assert result['virtualization_product_name'] == ''

# Generated at 2022-06-11 06:01:25.474026
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {}
    }
    virtual_facts_expected = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {'vmm'}
    }

    o = OpenBSDVirtual()
    o.module = type('module', (object,), dict())()
    o.module.get_bin_path = lambda x: x
    o.module.run_command = lambda x: (0, '', '')
    o.os_version = '6.2.1'
    o.os_

# Generated at 2022-06-11 06:01:35.574653
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 06:01:36.531119
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector is not None

# Generated at 2022-06-11 06:01:37.476284
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # The constructor test is not needed.
    pass

# Generated at 2022-06-11 06:01:38.523245
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-11 06:02:51.838338
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 06:02:56.517642
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    # Only the following fields are tested here as the other fields
    # are just copied from the facts collected by sysctl
    assert set(virtual_facts.keys()) == {'virtualization_role',
                                         'virtualization_type',
                                         'virtualization_tech_guest',
                                         'virtualization_tech_host'}

# Generated at 2022-06-11 06:03:00.292367
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector(
        'OpenBSD', 'OpenBSDVirtual')
    assert openbsd_virtual_collector._fact_class is OpenBSDVirtual
    assert openbsd_virtual_collector.platform == 'OpenBSD'

# Generated at 2022-06-11 06:03:08.137194
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class OpenBSDVirtual
    """

# Generated at 2022-06-11 06:03:10.090707
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 06:03:19.573273
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # The following guest_tech and host_tech are known to work on
    # amd64 testing with OpenBSD 6.6 and 6.7.
    #
    # Expected guest tech for virtualized product
    virtualized_product_guest_tech = set(['virtualbox', 'vmware', 'qemu', 'kvm'])
    # Expected host tech for virtualized product
    virtualized_product_host_tech = set()
    # Expected guest tech for virtualized vendor
    virtualized_vendor_guest_tech = set()
    # Expected host tech for virtualized vendor
    virtualized_vendor_host_tech = set()
    # Expected guest tech when VMM is enabled on the host
    vmm_guest_tech = set(['vmm'])
    # Expected host tech when VMM is enabled on

# Generated at 2022-06-11 06:03:22.417034
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-11 06:03:24.248959
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsdVirtual = OpenBSDVirtualCollector.factory()
    assert isinstance(openbsdVirtual, OpenBSDVirtualCollector)



# Generated at 2022-06-11 06:03:30.465133
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 06:03:33.886286
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual._fact_class == OpenBSDVirtual
    assert openbsd_virtual._platform == 'OpenBSD'


# Generated at 2022-06-11 06:06:04.520546
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class is OpenBSDVirtual

# Generated at 2022-06-11 06:06:05.308375
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector().collect()

# Generated at 2022-06-11 06:06:09.196804
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert type(virtual_facts['virtualization_type']) is str
    assert type(virtual_facts['virtualization_role']) is str
    assert type(virtual_facts['virtualization_tech_host']) is set
    assert type(virtual_facts['virtualization_tech_guest']) is set

# Generated at 2022-06-11 06:06:15.955157
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Run get_virtual_facts with a mock for reading dmesg.boot
    def mock_get_file_content(path):
        return 'dummy_dmesg_content'

    OpenBSDVirtual.get_file_content = mock_get_file_content
    expected_virtual_facts = {
        'virtualization_role': 'host',
        'virtualization_type': 'vmm',
        'virtualization_tech_host': set(['vmm']),
        'virtualization_tech_guest': set([])
    }
    virtual = OpenBSDVirtual()
    assert virtual.get_virtual_facts() == expected_virtual_facts

# Generated at 2022-06-11 06:06:17.430437
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 06:06:25.827135
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Setup test environment
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import tempfile
    from ansible.module_utils.facts.virtual import OpenBSDVirtual

    dirpath = tempfile.mkdtemp()
    dmesg_boot = open(os.path.join(dirpath, 'dmesg.boot'), 'w+')
    dmesg_boot.write('vmm0 at mainbus0: SVM/RVI\n')

    OpenBSDVirtual.DMESG_BOOT = dmesg_boot.name

# Generated at 2022-06-11 06:06:30.614583
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from .test_virtual import MockFile
    from .test_virtual import MockSubProcess

    facts = OpenBSDVirtual(MockFile, MockSubProcess).get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert len(facts['virtualization_tech_guest']) == 0
    assert len(facts['virtualization_tech_host']) == 0

# Generated at 2022-06-11 06:06:32.687706
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 06:06:37.395553
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()
    facts = virt.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    # Only assert on the existence of the OpenBSD-specific virtualization
    # technology facts.
    assert 'vmm' in facts['virtualization_tech_guest']

# Generated at 2022-06-11 06:06:40.685991
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()