

# Generated at 2022-06-11 05:56:56.001907
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector()._fact_class(), OpenBSDVirtual)

# Generated at 2022-06-11 05:57:01.639432
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    virtual_facts = openbsd_virtual_facts.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-11 05:57:03.528948
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 05:57:10.881157
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class Options(object):
        def __init__(self, data):
            self.data = data

    class Module(object):
        def __init__(self, variable_manager):
            self.variable_manager = variable_manager

    class VariableManager(object):
        def __init__(self):
            self.extra_vars = Options({'gather_subset': ['!all', 'virtual']})
            self.options = Options({})

        def get_vars(self, loader=None, path=None):
            return {'ansible_facts': {'virtual_guest': 'OpenBSD'}}

    virtual_facts = OpenBSDVirtual(VariableManager()).get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 05:57:12.684816
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual({}).get_virtual_facts()
    assert 'virtualization_type' in virtual_facts

# Generated at 2022-06-11 05:57:14.769674
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._fact_class == OpenBSDVirtual
    assert obj._platform == 'OpenBSD'

# Generated at 2022-06-11 05:57:19.659935
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts['virtualization_tech_guest']) == 0
    assert len(virtual_facts['virtualization_tech_host']) == 0



# Generated at 2022-06-11 05:57:25.323297
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual()
    virtual_facts_result = virtual_facts.get_virtual_facts()

    assert virtual_facts_result['virtualization_type'] == 'vmm'
    assert virtual_facts_result['virtualization_role'] == 'host'
    assert 'hvm' in virtual_facts_result['virtualization_tech_guest']
    assert 'vmm' in virtual_facts_result['virtualization_tech_host']

# Generated at 2022-06-11 05:57:35.350692
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    def get_base_facts(k):
        return {
            'hw.machine': 'amd64',
            'hw.product': 'VirtualBox',
            'hw.vendor': 'OpenBSD',
            'hw.class': 'virtual',  # This is not a base fact
            'kern.version': 'OpenBSD 6.2-current (GENERIC.MP) #1: Fri Aug 18 19:57:19 MDT 2017',  # This is not a base fact
        }.get(k)

    o = OpenBSDVirtual()
    o.get_base_facts = get_base_facts
    virtual_facts = o.get_virtual_facts()
    assert set(['vmm']) == virtual_facts['virtualization_tech_host']
    assert set() == virtual_facts['virtualization_tech_guest']
   

# Generated at 2022-06-11 05:57:40.414088
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''Unit test'''
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual, get_file_content

    # Expected results for the test if the given file 'dmesg.boot'
    # is given:
    #
    # virtualization_type: virtualbox
    # virtualization_role: host
    # virtualization_tech_guest: {}
    # virtualization_tech_host: {'virtualbox'}

    # If the file is not given, it is considered as a guest and
    # expected results are
    #
    # virtualization_type: ''
    # virtualization_role: ''
    # virtualization_tech_guest: {}
    # virtualization_tech_host: {}

    # Expected results for the test if the given file 'dmesg.boot'
   

# Generated at 2022-06-11 05:57:52.740274
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''Test the method get_virtual_facts of class OpenBSDVirtual'''
    import ast
    virtual_facts = OpenBSDVirtual()

    # Set a constant for test purpose
    virtual_facts.DMESG_BOOT = './unit_tests/dmesg.boot'

    facts = virtual_facts.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert set(ast.literal_eval(facts['virtualization_tech_guest'])) == set(['qemu'])
    assert set(ast.literal_eval(facts['virtualization_tech_host'])) == set(['vmm', 'qemu'])

# Generated at 2022-06-11 05:57:54.552661
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-11 05:57:55.959744
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-11 05:58:02.723972
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Unit test for get_virtual_facts of class OpenBSDVirtual
    test_openbsd_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert test_openbsd_virtual_facts == OpenBSDVirtual().get_virtual_facts()

# Generated at 2022-06-11 05:58:11.397746
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    host_vendor = 'GenuineIntel'
    host_product = 'Intel(R) Core(TM) i7-4770K CPU @ 3.50GHz'
    data = '''hw.vendor = {}
hw.product = {}
hw.machine = amd64
hw.model = Intel(R) Core(TM) i7-4770K CPU @ 3.50GHz
hw.ncpu = 8
hw.pagesize = 4096
'''.format(host_vendor, host_product)
    result = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_type_role': '',
        'virt_what': ['host'],
        'virtualization_tech_host': set(['vmm']),
        'virtualization_tech_guest': set()
    }


# Generated at 2022-06-11 05:58:13.494960
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual._platform == "OpenBSD"


# Generated at 2022-06-11 05:58:23.464730
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    class MockOpenBSDVirtual(OpenBSDVirtual):
        def __init__(self):
            self.facts = {}

        def detect_virt_product(self, sysctl_name):
            return {
                'virtualization_tech_host': set(['product']),
                'virtualization_tech_guest': set(['product']),
                'virtualization_type': 'product',
                'virtualization_role': 'guest'
            }

        def detect_virt_vendor(self, sysctl_name):
            return {
                'virtualization_tech_host': set(['vendor']),
                'virtualization_tech_guest': set(['vendor']),
                'virtualization_type': 'vendor',
                'virtualization_role': 'guest'
            }

    mock_obj = MockOpenBSDVirtual

# Generated at 2022-06-11 05:58:32.959030
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    module = AnsibleModuleMock()
    module.params = {}
    module.run_command = command_mock

    virtual = OpenBSDVirtual(module)

    # Case 1: The host is virtualized
    case_1_virtual_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm']),
    }
    assert virtual.get_virtual_facts() == case_1_virtual_facts

    # Case 2: The host is a physical machine

# Generated at 2022-06-11 05:58:36.968562
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    gv = OpenBSDVirtualCollector()
    assert gv.platform == 'OpenBSD'
    assert gv._fact_class.platform == 'OpenBSD'
    assert gv._platform == 'OpenBSD'


# Generated at 2022-06-11 05:58:41.379963
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_c = OpenBSDVirtualCollector()
    assert virtual_c._platform == 'OpenBSD'
    assert virtual_c._fact_class.__name__ == "OpenBSDVirtual"
    assert virtual_c._fact_class.platform == 'OpenBSD'
    assert virtual_c._fact_class.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-11 05:58:58.357627
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-11 05:59:07.434492
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """ Unit tests for get_virtual_facts of class OpenBSDVirtual """
    # init OpenBSDVirtual object
    virtual_obj = OpenBSDVirtual()

    # set expected values
    expected_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set([]),
        'virtualization_tech_host': set([]),
    }

    # create file dmesg.boot with content with virtualization capabilities
    f = open('dmesg.boot', 'w')
    f.write('vmm0 at mainbus0: SVM/RVI\n')
    f.write('vmx0 at mainbus0: VMX/EPT\n')
    f.close()

    # get virtual facts
    virtual_facts = virtual_obj.get

# Generated at 2022-06-11 05:59:15.893859
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.detect_virt_product = lambda x: {'virtualization_type': 'xen', 'virtualization_role': 'guest'}
    openbsd_virtual.detect_virt_vendor = lambda x: {'virtualization_type': 'cloud', 'virtualization_role': 'guest'}

    openbsd_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_facts['virtualization_type'] == 'xen'
    assert openbsd_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-11 05:59:21.602333
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    This unit test ensures that the OpenBSD-specific overridden method
    defined in OpenBSDVirtual class return the correct values.
    """
    openbsd_virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-11 05:59:25.569724
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test the VirtualCollector.__init__(platform=None) constructor
    obj = OpenBSDVirtualCollector()
    assert obj.platform == 'OpenBSD'
    assert isinstance(obj.facts, OpenBSDVirtual)
    assert isinstance(obj.facts.get_virtual_facts(), dict)


# Generated at 2022-06-11 05:59:31.984478
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # The title of this class is not OpenBSDVirtualCollector
    try:
        OpenBSDVirtualCollector()
        assert False
    except AssertionError:
        pass

    # The _platform of this class is not 'OpenBSD'
    try:
        class OpenBSDVirtualCollectorWithWrongPlatform(OpenBSDVirtualCollector):
            _platform = 'Linux'
        OpenBSDVirtualCollectorWithWrongPlatform()
        assert False
    except AssertionError:
        pass



# Generated at 2022-06-11 05:59:33.725619
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual()
    virtual_facts.get_virtual_facts()

# Generated at 2022-06-11 05:59:42.764197
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """Test the OpenBSDVirtual.get_virtual_facts method"""

    # This is a testcase for the above method. It sets the virtualization_facts
    # dict as expected by the method as input and calls the method. The
    # output of the method is then checked against the expected output.
    # Some tests are conditional on the existance of certain files in the
    # virtualization_facts dict, created by various conditonal facts.
    # This allows to have one testcase for all platforms.

    testcase = dict()
    testcase['virtualization_facts'] = dict()

    expected_output = dict()

    # test OpenBSD VirtualBox detection
    testcase['virtualization_facts']['virtual_vendor_facts'] = dict()

# Generated at 2022-06-11 05:59:53.236959
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.OpenBSD import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.base import Virtual
    from ansible.module_utils._text import to_bytes

    bsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-11 05:59:56.407238
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    v_collector = OpenBSDVirtualCollector()
    assert v_collector._platform == 'OpenBSD'
    assert v_collector._fact_class == OpenBSDVirtual
    assert v_collector._platform is not None


# Generated at 2022-06-11 06:00:08.701395
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    pass

# Generated at 2022-06-11 06:00:15.632018
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD 6.4 VM (VirtualBox)
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert 'OpenBSD' == virtual_facts['virtualization_type']
    assert 'guest' == virtual_facts['virtualization_role']
    assert set(['VirtualBox']) == virtual_facts['virtualization_tech']
    assert set(['VirtualBox']) == virtual_facts['virtualization_tech_guest']
    assert set() == virtual_facts['virtualization_tech_host']
    # Test for OpenBSD 6.4 VM (VirtualBox) with VMX instead of SVM
    virtual = OpenBSDVirtual()
    virtual._hw_product_regex_map = {
        'VMware Virtual Platform': 'VMware Virtual Platform',
    }

# Generated at 2022-06-11 06:00:18.042847
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Unit test: Returns OpenBSDVirtualCollector class
    """
    obj = OpenBSDVirtualCollector()
    assert obj._platform == 'OpenBSD'

# Generated at 2022-06-11 06:00:20.230404
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._platform == "OpenBSD"
    assert obj._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 06:00:24.097517
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    (is_virtual, virtual_facts) = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-11 06:00:26.878599
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    openbsd_virtual_facts.get_virtual_facts()
    assert openbsd_virtual_facts.virtual_facts == {'virtualization_type': '', 'virtualization_role': ''}

# Generated at 2022-06-11 06:00:29.436021
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = OpenBSDVirtualCollector()
    facts.populate()
    assert 'virtualization_type' in facts.data
    assert 'virtualization_role' in facts.data

# Generated at 2022-06-11 06:00:33.692280
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-11 06:00:41.540484
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():

    # Test data
    test_data = [({},
        {'ansible_virtualization_role': '',
         'ansible_virtualization_type': '',
         'ansible_virtualization_type_role': 'guest',
         'ansible_virtualization_tech_guest': set(),
         'ansible_virtualization_tech_host': set()
        }
        )]

    # Init VirtualCollector instance
    openbsd_virtual = OpenBSDVirtualCollector()

    # Test VirtualCollector constructor
    for data_item in test_data:
        openbsd_virtual.collect(data_item[0])
        assert openbsd_virtual.data == data_item[1]


# Generated at 2022-06-11 06:00:43.498366
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    module = OpenBSDVirtualCollector()
    assert module.platform == 'OpenBSD'
    assert module.fact_class == OpenBSDVirtual


# Generated at 2022-06-11 06:01:16.351071
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class OpenBSDVirtual
    """
    # pylint: disable=protected-access
    #
    # None of the hardware virtualization extensions are present.
    #
    OpenBSDVirtual._sysctl_vm_guest = {}
    OpenBSDVirtual._sysctl_hw_product = {}
    OpenBSDVirtual._sysctl_hw_vendor = {}
    OpenBSDVirtual.DMESG_BOOT = '/opt/dmesg.boot'
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts['virtualization_tech_guest']) == 0
    assert len(virtual_facts['virtualization_tech_host'])

# Generated at 2022-06-11 06:01:24.437402
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual import Virtual, OpenBSDVirtual
    from ansible.module_utils.facts.virtual._sysctl import VirtualSysctlDetectionMixin

    class TestOpenBSDVirtual(Virtual, OpenBSDVirtual, VirtualSysctlDetectionMixin):
        platform = 'OpenBSD'

    openbsd_virtual = TestOpenBSDVirtual()
    openbsd_virtual.sysctl_data = {
        'hw.vendor': 'OpenBSD',
        'hw.product': 'Generic amd64'
    }
    facts = openbsd_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'OpenBSD'
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set

# Generated at 2022-06-11 06:01:33.133038
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from unit.modules.utils import set_module_args
    from .openbsd_module import TestOpenBSDModule

    module = TestOpenBSDModule()
    set_module_args(dict(gather_subset='!all', filter='virtual'))
    module.run()
    assert module.exit_json['ansible_facts']['virtualization_role'] == 'host'
    assert 'virtualization_tech_host' in module.exit_json['ansible_facts']
    assert 'virtualization_tech_guest' in module.exit_json['ansible_facts']
    assert module.exit_json['ansible_facts']['virtualization_type'] == 'vmm'

# Generated at 2022-06-11 06:01:36.709083
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Unit test for constructor of class OpenBSDVirtualCollector
    """
    o = OpenBSDVirtualCollector(None)
    assert o.platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual
    assert o._platform == 'OpenBSD'


# Generated at 2022-06-11 06:01:41.757603
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_product_name' in facts
    assert 'virtualization_product_version' in facts
    assert 'virtualization_product_serial' in facts

# Generated at 2022-06-11 06:01:46.111830
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts.get('virtualization_type') == ''
    assert virtual_facts.get('virtualization_role') == ''
    assert virtual_facts.get('virtualization_tech_guest') == set()
    assert virtual_facts.get('virtualization_tech_host') == set()



# Generated at 2022-06-11 06:01:51.252834
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_cases = [
        {'input': 'OpenBSD', 'expected': {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set([])}},
    ]

    test_object = OpenBSDVirtual()
    for test_case in test_cases:
        test_object.facts['kernel'] = test_case['input']
        assert test_object.get_virtual_facts() == test_case['expected']

# Generated at 2022-06-11 06:01:53.390603
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert isinstance(c._fact_class, OpenBSDVirtual)
    assert c._platform == 'OpenBSD'


# Generated at 2022-06-11 06:02:02.247296
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Initialize a OpenBSDVirtualCollector object
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    # Assert that the OpenBSDVirtualCollector object
    # is an instance of class OpenBSDVirtualCollector
    assert isinstance(openbsd_virtual_collector, OpenBSDVirtualCollector)
    # Assert that the OpenBSDVirtualCollector object
    # is also an instance of parent class VirtualCollector
    assert isinstance(openbsd_virtual_collector, VirtualCollector)
    # Assert that the private variable _fact_class is
    # an OpenBSDVirtual object
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    # Assert that the private variable _platform is set to
    # 'OpenBSD'

# Generated at 2022-06-11 06:02:07.231044
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    openbsd_virtual = openbsd_virtual_collector._fact_class(platform='OpenBSD', dmesg_boot=OpenBSDVirtual.DMESG_BOOT)
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'



# Generated at 2022-06-11 06:03:14.330127
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.system.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.utils import get_file_content

    # Create instance of class OpenBSDVirtual
    openbsd_virtual_class = OpenBSDVirtual()

    # Test for method get_virtual_facts with parameter tags "virtualization_tech_guest" and "virtualization_tech_host"
    openbsd_virtual_class.get_virtual_facts(
        tags=['virtualization_tech_guest', 'virtualization_tech_host'])

    # Test for method get_virtual_facts with parameter tags "virtualization_type"

# Generated at 2022-06-11 06:03:16.879860
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    # Attributes
    assert hasattr(o, '_fact_class')
    assert hasattr(o, '_platform')

# Generated at 2022-06-11 06:03:17.964965
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector().get_virtual_facts()['virtualization_type'] == ''

# Generated at 2022-06-11 06:03:20.244283
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts.keys()
    assert 'virtualization_role' in virtual_facts.keys()

# Generated at 2022-06-11 06:03:22.472479
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 06:03:25.655340
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert issubclass(virtual_collector.fact_class, Virtual)
    assert isinstance(virtual_collector.fact_class(collect_default=True), OpenBSDVirtual)

# Generated at 2022-06-11 06:03:27.107447
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)

# Unit test to initialize fact object.

# Generated at 2022-06-11 06:03:35.472919
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_obj = OpenBSDVirtual()

    dmesg_boot_template = '''
vmm0 at mainbus0: VMX/EPT
'''
    openbsd_virtual_obj.DMESG_BOOT = '/tmp/dmesg.boot'
    openbsd_virtual_obj.sysctl_vars = {'hw.product': 'OpenBSD OpenVM',
                                       'hw.vendor': 'OpenBSD'}

    virtual_facts = openbsd_virtual_obj.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert 'vmware' in virtual_facts['virtualization_tech_guest']
    assert 'vmm' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-11 06:03:40.695841
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    # These are examples from a OpenBSD 6.2 VMM guest.
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmm'])
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-11 06:03:44.511476
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_collector = OpenBSDVirtualCollector(None, 'openbsd')
    openbsd_virtual_facts = openbsd_virtual_collector.collect()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-11 06:06:10.244542
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 06:06:18.803288
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a fake module to hold the arguments for the ansible module
    fake_module = type('', (), {
        'params': {},
        'exit_json': type('', (), {
            '__call__': lambda mock, a: mock(**a)
        })(lambda **kwargs: True)
        })()

    # Create a fake ansible module to pass to the VirtualCollector
    fake_ansible_module = type('', (), {
        'check_mode': False,
        'params': {},
        'exit_json': type('', (), {
            '__call__': lambda mock, a: mock(**a)
        })(lambda **kwargs: True)
        })()

    # Create an OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual(fake_ansible_module)

    # Get

# Generated at 2022-06-11 06:06:27.168260
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible_collections.community.general.plugins.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    # Sample outputs from the dmesg.boot file

# Generated at 2022-06-11 06:06:28.983372
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-11 06:06:37.325286
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    print('')
    print('Expect: virtualization_type=vmm, virtualization_role=host, virtualization_tech_guest=set(), virtualization_tech_host=set([vmm])')
    OpenBSDVirtual_obj = OpenBSDVirtual()
    OpenBSDVirtual_obj.DMESG_BOOT = 'test/files/dmesg.boot.2020-08-26'
    print('Actual:', OpenBSDVirtual_obj.get_virtual_facts())
    print('')

    print('Expect: virtualization_type=vmm, virtualization_role=guest, virtualization_tech_guest=set([vmm]), virtualization_tech_host=set()')
    OpenBSDVirtual_obj = OpenBSDVirtual()

# Generated at 2022-06-11 06:06:44.933605
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Setup
    openbsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-11 06:06:50.795928
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    test_os_version = 'OpenBSD 5.1'
    test_obj = OpenBSDVirtual(test_os_version)

    test_obj.facts['productname'] = 'Bochs'
    test_obj.facts['virt_productname'] = ''
    test_obj.facts['dmesg_boot'] = '/var/run/dmesg.boot'
    test_obj.facts['virtual_dmidecode'] = '/var/run/virtual_dmidecode'
    test_obj.facts['virtual_sysctl'] = '/var/run/virtual_sysctl'

    test_obj.facts['productname_content'] = 'Bochs'
    test_obj.facts['virt_productname_content'] = ''
    test_