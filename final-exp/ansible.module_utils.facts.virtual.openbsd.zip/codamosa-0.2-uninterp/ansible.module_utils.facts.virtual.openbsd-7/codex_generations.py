

# Generated at 2022-06-17 03:18:38.094200
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD VM
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl_output = {'hw.vendor': 'OpenBSD',
                                     'hw.product': 'OpenBSD Virtual Machine'}
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'openbsd'
    assert openbsd_virtual_facts['virtualization_role'] == 'guest'
    assert 'openbsd' in openbsd_virtual_facts['virtualization_tech_guest']

    # Test for OpenBSD host
    openbsd_virtual.sysctl_output = {'hw.vendor': 'OpenBSD',
                                     'hw.product': 'OpenBSD'}
    openbsd_

# Generated at 2022-06-17 03:18:41.838120
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD virtualization facts
    openbsd_virtual_facts = OpenBSDVirtual()
    openbsd_virtual_facts_result = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert openbsd_virtual_facts.get_virtual_facts() == openbsd_virtual_facts_result

# Generated at 2022-06-17 03:18:43.973508
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:18:46.383860
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'vmm' in virtual_facts['virtualization_tech_host']
    assert 'vmm' not in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-17 03:18:57.114653
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import os
    import sys
    import unittest

    class MockOpenBSDVirtual(OpenBSDVirtual):
        def __init__(self):
            self.sysctl_cmd = os.path.join(os.path.dirname(sys.argv[0]),
                                           'sysctl')

    class TestOpenBSDVirtual(unittest.TestCase):
        def setUp(self):
            self.openbsd_virtual = MockOpenBSDVirtual()

        def test_get_virtual_facts_vmm(self):
            virtual_facts = self.openbsd_virtual.get_virtual_facts()
            self.assertEqual(virtual_facts['virtualization_type'], 'vmm')
            self.assertEqual(virtual_facts['virtualization_role'], 'host')

# Generated at 2022-06-17 03:18:59.388624
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:19:02.494421
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:19:05.643947
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:19:10.782363
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-17 03:19:13.353821
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:19:18.257610
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:19:22.088781
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:19:32.063126
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a virtualized OpenBSD guest
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmm'])
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])

    # Test with a physical OpenBSD host
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-17 03:19:40.226922
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a virtualized OpenBSD guest
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'vmm' in virtual_facts['virtualization_tech_guest']
    assert 'vmm' in virtual_facts['virtualization_tech_host']
    assert 'vmware' in virtual_facts['virtualization_tech_guest']
    assert 'vmware' in virtual_facts['virtualization_tech_host']

    # Test with a bare metal OpenBSD host
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'


# Generated at 2022-06-17 03:19:45.747072
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:19:56.266429
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-17 03:20:01.656290
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:20:06.159358
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-17 03:20:09.334513
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-17 03:20:10.608389
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:20:15.644913
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:20:22.448251
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Constructor of class OpenBSDVirtualCollector should set
    _fact_class to OpenBSDVirtual and _platform to 'OpenBSD'
    """
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:20:33.882518
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-17 03:20:37.647379
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:20:46.582978
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Create a dictionary with the expected results
    expected_results = dict(
        virtualization_type='vmm',
        virtualization_role='host',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(['vmm'])
    )

    # Get the facts
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()

    # Compare the results
    assert openbsd_virtual_facts == expected_results

# Generated at 2022-06-17 03:20:48.502323
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:20:55.231466
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Create a dictionary with the expected results
    expected_result = dict(
        virtualization_type='vmm',
        virtualization_role='host',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(['vmm']),
        virtualization_product=''
    )

    # Test the method get_virtual_facts of class OpenBSDVirtual
    assert openbsd_virtual.get_virtual_facts() == expected_result

# Generated at 2022-06-17 03:21:05.861866
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a OpenBSD VM
    openbsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-17 03:21:10.626666
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:21:21.558932
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a dmesg.boot file containing a vmm(4) line
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.DMESG_BOOT = 'tests/unit/module_utils/facts/virtual/files/dmesg.boot.vmm'
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'host'
    assert openbsd_virtual_facts['virtualization_tech_host'] == {'vmm'}
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()

    # Test with a dmesg.boot file not containing a vmm(4

# Generated at 2022-06-17 03:21:29.888482
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-17 03:21:34.828675
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class OpenBSDVirtual
    """
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:21:38.596305
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-17 03:21:41.275561
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:21:43.726625
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:21:48.612412
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:21:54.932096
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD Virtualization
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual.facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual.facts['virtualization_role'] == 'host'
    assert openbsd_virtual.facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual.facts['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-17 03:21:59.011795
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:22:06.966468
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Create a dictionary that will be used to call the method
    # get_virtual_facts
    openbsd_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Call the method get_virtual_facts
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()

    # Check the result
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-17 03:22:17.711528
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a virtual machine
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'vmm' in virtual_facts['virtualization_tech_guest']
    assert 'vmm' not in virtual_facts['virtualization_tech_host']

    # Test with a physical machine
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'vmm' not in virtual_facts['virtualization_tech_guest']
    assert 'vmm' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-17 03:22:37.582542
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()
    # Get the virtual facts
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    # Check the virtual facts
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:22:45.175919
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD host
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'host'
    assert 'vmm' in openbsd_virtual_facts['virtualization_tech_host']
    assert 'vmm' not in openbsd_virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-17 03:22:49.541352
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:22:55.509503
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:22:59.383840
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:23:10.582331
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a virtual machine
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == {'vmm'}
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}

    # Test with a physical machine
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-17 03:23:16.489901
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD host
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual.facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual.facts['virtualization_role'] == 'host'
    assert openbsd_virtual.facts['virtualization_tech_host'] == {'vmm'}
    assert openbsd_virtual.facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-17 03:23:24.844658
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a virtual machine
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmm'])
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])

    # Test with a physical machine
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:23:35.732702
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with OpenBSD 6.3
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl_output = {
        'hw.product': 'OpenBSD 6.3 (GENERIC) #0: Fri Nov  3 02:04:18 UTC 2017',
        'hw.vendor': 'OpenBSD'
    }
    openbsd_virtual.dmesg_boot_content = ''
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-17 03:23:37.733954
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:24:13.261992
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD running on VMware
    openbsd_virtual = OpenBSDVirtual({'ansible_facts': {'hw': {'product': 'VMware Virtual Platform', 'vendor': 'VMware, Inc.'}}})
    assert openbsd_virtual.get_virtual_facts() == {'virtualization_type': 'vmware', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'vmware'}, 'virtualization_tech_host': {'vmware'}}

    # Test for OpenBSD running on VirtualBox
    openbsd_virtual = OpenBSDVirtual({'ansible_facts': {'hw': {'product': 'VirtualBox', 'vendor': 'innotek GmbH'}}})

# Generated at 2022-06-17 03:24:15.402250
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:24:21.980987
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:24:31.095560
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-17 03:24:39.319139
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    openbsd_virtual_facts.get_virtual_facts()
    assert openbsd_virtual_facts.virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts.virtual_facts['virtualization_role'] == 'host'
    assert openbsd_virtual_facts.virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts.virtual_facts['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-17 03:24:48.832888
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-17 03:24:59.483698
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a OpenBSD VM
    openbsd_virtual = OpenBSDVirtual({'ansible_facts': {'ansible_system': 'OpenBSD'}})
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'guest'
    assert 'vmm' in openbsd_virtual_facts['virtualization_tech_guest']
    assert 'vmm' not in openbsd_virtual_facts['virtualization_tech_host']

    # Test with a OpenBSD host
    openbsd_virtual = OpenBSDVirtual({'ansible_facts': {'ansible_system': 'OpenBSD'}})
    openbsd_virtual_

# Generated at 2022-06-17 03:25:02.895150
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.collect()
    facts = openbsd_virtual.get_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-17 03:25:16.135462
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a OpenBSD VM
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl_output = {
        'hw.vendor': 'OpenBSD',
        'hw.product': 'OpenBSD Virtual Machine'
    }
    openbsd_virtual.dmesg_boot_content = 'vmm0 at mainbus0: SVM/RVI'
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'guest'
    assert 'vmm' in openbsd_virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-17 03:25:22.609549
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Create a dictionary with the expected results
    expected_virtual_facts = dict(
        virtualization_type='vmm',
        virtualization_role='host',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(['vmm']),
    )

    # Get the virtual facts
    virtual_facts = openbsd_virtual.get_virtual_facts()

    # Assert the virtual facts are as expected
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 03:26:36.903902
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:26:47.337300
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with OpenBSD 6.3
    openbsd_virtual = OpenBSDVirtual(module=None)
    openbsd_virtual.sysctl = {'hw.product': 'OpenBSD',
                              'hw.vendor': 'OpenBSD'}
    openbsd_virtual.get_file_content = lambda x: ''
    openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual.facts['virtualization_type'] == ''
    assert openbsd_virtual.facts['virtualization_role'] == ''
    assert openbsd_virtual.facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual.facts['virtualization_tech_host'] == set()

    # Test with OpenBSD 6.3 running on VMware

# Generated at 2022-06-17 03:26:53.536569
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:26:59.708811
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual_obj = OpenBSDVirtual()

    # Create a dict with all the virtual facts
    virtual_facts = openbsd_virtual_obj.get_virtual_facts()

    # Check if the virtual_facts dict is not empty
    assert virtual_facts

# Generated at 2022-06-17 03:27:00.873280
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:27:09.295900
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-17 03:27:19.071176
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD running on vmm(4)
    openbsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-17 03:27:28.763947
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a host that is a virtual machine
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmm'])
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])

    # Test with a host that is a virtualization host
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set(['vmm'])

# Generated at 2022-06-17 03:27:38.161107
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with no virtualization
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

    # Test with vmm(4) host
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-17 03:27:46.462460
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Test get_virtual_facts()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()