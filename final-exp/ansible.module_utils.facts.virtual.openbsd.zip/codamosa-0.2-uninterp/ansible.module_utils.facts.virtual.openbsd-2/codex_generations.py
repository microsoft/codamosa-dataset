

# Generated at 2022-06-17 03:18:40.100859
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a OpenBSD VM
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'guest'
    assert 'vmm' in openbsd_virtual_facts['virtualization_tech_guest']
    assert 'vmm' in openbsd_virtual_facts['virtualization_tech_host']

# Generated at 2022-06-17 03:18:45.109667
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-17 03:18:47.436565
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:18:55.016418
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Test get_virtual_facts()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:19:00.388383
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Test the get_virtual_facts method
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:19:06.167274
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Create a dictionary with the expected results
    expected_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'vmm'}
    }

    # Get the virtual facts
    virtual_facts = openbsd_virtual.get_virtual_facts()

    # Assert the virtual facts are as expected
    assert virtual_facts == expected_facts

# Generated at 2022-06-17 03:19:09.524892
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-17 03:19:18.334896
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Set the virtualization_type and virtualization_role to empty values
    openbsd_virtual.virtualization_type = ''
    openbsd_virtual.virtualization_role = ''

    # Set the virtualization_tech_guest and virtualization_tech_host to empty sets
    openbsd_virtual.virtualization_tech_guest = set()
    openbsd_virtual.virtualization_tech_host = set()

    # Set the virtualization_product_facts to empty dict
    openbsd_virtual.virtualization_product_facts = {}

    # Set the virtualization_vendor_facts to empty dict
    openbsd_virtual.virtualization_vendor_facts = {}

    # Set the dmesg_boot to empty string
   

# Generated at 2022-06-17 03:19:29.958795
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a dmesg.boot file that contains vmm(4)
    test_OpenBSDVirtual = OpenBSDVirtual(content=get_file_content('tests/unit/module_utils/facts/virtual/test_OpenBSDVirtual_dmesg_boot_vmm'))
    virtual_facts = test_OpenBSDVirtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}

    # Test with a dmesg.boot file that does not contain vmm(4)

# Generated at 2022-06-17 03:19:38.814464
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD guest
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl_output = {'hw.product': 'OpenBSD',
                                     'hw.vendor': 'OpenBSD'}
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()

    # Test for OpenBSD host

# Generated at 2022-06-17 03:19:46.214910
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-17 03:19:50.823720
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:19:52.615196
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:19:56.737709
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Test get_virtual_facts method
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:20:00.322314
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:20:10.451279
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Create a dictionary with the expected results
    expected_results = dict(
        virtualization_type='vmm',
        virtualization_role='host',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(['vmm']),
    )

    # Create a dictionary with the results of the method get_virtual_facts
    results = openbsd_virtual.get_virtual_facts()

    # Compare the expected results with the results of the method
    # get_virtual_facts
    assert results == expected_results

# Generated at 2022-06-17 03:20:14.377347
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:20:20.434708
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with virtualization_type and virtualization_role set
    dmesg_boot = '''
vmm0 at mainbus0: SVM/RVI
vmm1 at mainbus0: VMX/EPT
'''
    dmesg_boot_file = open(OpenBSDVirtual.DMESG_BOOT, 'w')
    dmesg_boot_file.write(dmesg_boot)
    dmesg_boot_file.close()

    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])
    assert virtual_facts['virtualization_tech_guest'] == set

# Generated at 2022-06-17 03:20:22.564004
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:20:26.659094
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Test get_virtual_facts method
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'host'
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-17 03:20:33.837814
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class == OpenBSDVirtual
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:20:37.954748
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-17 03:20:48.051948
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-17 03:20:55.152278
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for virtualization_type and virtualization_role
    # when virtualization_type is not set
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # Test for virtualization_type and virtualization_role
    # when virtualization_type is set
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-17 03:21:02.780636
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a OpenBSD host
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'host'
    assert 'vmm' in openbsd_virtual_facts['virtualization_tech_host']
    assert 'vmm' not in openbsd_virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-17 03:21:13.796386
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Create a dict with the expected results
    expected_virtual_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )

    # Get the virtual facts
    virtual_facts = openbsd_virtual.get_virtual_facts()

    # Assert the virtual facts match the expected results
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 03:21:20.433693
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Test the method get_virtual_facts
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:21:21.618650
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:21:27.306713
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a OpenBSD VM
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl = {'hw.product': 'OpenBSD OpenVM',
                              'hw.vendor': 'OpenBSD'}
    openbsd_virtual.dmesg_boot = 'vmm0 at mainbus0: SVM/RVI'
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_product_name'] == 'OpenVM'
    assert virtual_facts['virtualization_product_version'] == ''
    assert virtual_facts['virtualization_product_vendor'] == 'OpenBSD'

# Generated at 2022-06-17 03:21:30.601454
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:21:50.870337
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Create a dictionary with the expected results
    expected_virtual_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm'])
    }

    # Get the virtual facts
    virtual_facts = openbsd_virtual.get_virtual_facts()

    # Assert the virtual facts are as expected
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 03:22:01.254625
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a virtual machine
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl = {'hw.product': 'VirtualBox', 'hw.vendor': 'Oracle'}
    openbsd_virtual.dmesg_boot = '''
vmm0 at mainbus0: VMX/EPT
'''
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'vmm' in virtual_facts['virtualization_tech_guest']
    assert 'vbox' in virtual_facts['virtualization_tech_guest']
    assert 'vmm' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-17 03:22:02.730192
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:22:16.270209
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD host
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual.facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual.facts['virtualization_role'] == 'host'
    assert openbsd_virtual.facts['virtualization_tech_host'] == {'vmm'}
    assert openbsd_virtual.facts['virtualization_tech_guest'] == set()

    # Test for OpenBSD guest
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.facts['product_name'] = 'VMware Virtual Platform'
    openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual.facts['virtualization_type'] == 'vmware'
   

# Generated at 2022-06-17 03:22:25.366571
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for virtualization_type and virtualization_role
    # when hw.product is 'OpenBSD Virtual Machine'
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'

    # Test for virtualization_type and virtualization_role
    # when hw.vendor is 'OpenBSD'
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-17 03:22:28.047141
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-17 03:22:31.308973
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:22:34.140720
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:22:40.576079
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-17 03:22:43.876942
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-17 03:23:19.471454
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Create a dictionary with the expected results
    expected_virtual_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm'])
    }

    # Create a dictionary with the results of the get_virtual_facts method
    virtual_facts = openbsd_virtual.get_virtual_facts()

    # Check if the results are as expected
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 03:23:21.680541
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:23:26.853152
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()
    # Create a dictionary with the expected results
    expected_virtual_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm'])
    }
    # Get the virtual facts
    virtual_facts = openbsd_virtual.get_virtual_facts()
    # Assert the virtual facts are as expected
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 03:23:29.475148
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:23:33.141161
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:23:34.916242
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:23:40.582785
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a OpenBSD host
    openbsd_virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'host'
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-17 03:23:46.215309
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:23:48.714062
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:23:50.215252
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:24:51.789584
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:24:54.994260
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-17 03:24:58.129617
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-17 03:25:01.934956
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:25:05.156975
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:25:16.636095
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for OpenBSD host
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl = {'hw.product': 'OpenBSD', 'hw.vendor': 'OpenBSD'}

# Generated at 2022-06-17 03:25:23.258382
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Create a dictionary with the expected results
    expected_virtual_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm']),
    }

    # Get the virtual facts
    virtual_facts = openbsd_virtual.get_virtual_facts()

    # Assert the virtual facts are as expected
    assert virtual_facts == expected_virtual_facts

# Generated at 2022-06-17 03:25:26.156948
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:25:32.012960
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-17 03:25:39.425618
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()
    # Create a dictionary that contains the expected results
    expected_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm'])
    }
    # Get the actual results
    actual_facts = openbsd_virtual.get_virtual_facts()
    # Assert that the actual results match the expected results
    assert actual_facts == expected_facts

# Generated at 2022-06-17 03:28:05.440077
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Test get_virtual_facts()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()

    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:28:08.747868
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual({})
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-17 03:28:14.798434
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-17 03:28:20.408801
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:28:24.756363
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a OpenBSD host
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'host'
    assert openbsd_virtual_facts['virtualization_tech_host'] == {'vmm'}
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-17 03:28:25.574222
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-17 03:28:30.643230
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual object
    openbsd_virtual = OpenBSDVirtual()

    # Create a dictionary with the expected results
    expected_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm']),
    }

    # Get the virtual facts
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()

    # Assert the virtual facts are as expected
    assert openbsd_virtual_facts == expected_facts