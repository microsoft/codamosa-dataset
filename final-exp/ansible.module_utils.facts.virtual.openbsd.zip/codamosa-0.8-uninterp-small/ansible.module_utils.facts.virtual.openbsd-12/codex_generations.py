

# Generated at 2022-06-25 01:18:21.438385
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()

    # The return value of a property may be cached
    # Thus in order to re-assign the return value
    # The cached value needs to be deleted first
    del open_b_s_d_virtual_collector._fact_class
    open_b_s_d_virtual_collector._fact_class = OpenBSDVirtual
    assert open_b_s_d_virtual_collector._fact_class == OpenBSDVirtual

    # The return value of a property may be cached
    # Thus in order to re-assign the return value
    # The cached value needs to be deleted first
    del open_b_s_d_virtual_collector._platform
    open_b_s_d_virtual_collector._platform = 'OpenBSD'

# Generated at 2022-06-25 01:18:25.812698
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    ret = open_b_s_d_virtual_0.get_virtual_facts()
    assert ret['virtualization_role'] == ''
    assert ret['virtualization_type'] == ''

# Generated at 2022-06-25 01:18:29.866877
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-25 01:18:40.345121
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.detect_virt_product = lambda a, b: 'hw.product = virtualbox'
    open_b_s_d_virtual_0.detect_virt_vendor = lambda a, b: 'hw.vendor = oracle'
    open_b_s_d_virtual_0.dmesg_boot = 'abivm0 at mainbus0: SVM/RVI\n' \
        'vmm0 at mainbus0: SVM/RVI'
    open_b_s_d_virtual_collector_0._fact_class = open_b_s_d_virtual_0


# Generated at 2022-06-25 01:18:45.548629
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:18:50.120255
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Instantiate a class OpenBSDVirtual object
    open_b_s_d_virtual_0 = OpenBSDVirtual()

    # Invoke method get_virtual_facts of class OpenBSDVirtual
    # with param open_b_s_d_virtual_0
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:54.537021
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': '', 'virtualization_type': ''}


# Generated at 2022-06-25 01:18:57.801653
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:19:03.373327
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual({}, {}, {})
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:03.976423
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    pass


# Generated at 2022-06-25 01:19:16.707724
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    list_0 = []
    list_1 = [list_0]
    open_b_s_d_virtual_1 = OpenBSDVirtual(list_1)
    # Test with bytes
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_

# Generated at 2022-06-25 01:19:22.971239
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    list_0 = []
    list_1 = [list_0]
    open_b_s_d_virtual_1 = OpenBSDVirtual(list_1)

# Generated at 2022-06-25 01:19:24.939605
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

test_case_0()
test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:19:26.077121
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:19:30.722636
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:37.684830
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:47.145483
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_2 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_2 = OpenBSDVirtual(bytes_2)
    # Call get_virtual_facts of OpenBSDVirtual.
    open_b_s_d_virtual_2.get_virtual_facts()

if __name__ == '__main__':
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:19:49.182586
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():

    # Create an instance of class OpenBSDVirtualCollector
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:19:54.478778
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:56.168004
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:12.477508
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-25 01:20:13.279579
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert True == True

# Generated at 2022-06-25 01:20:19.880880
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:23.244950
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.get_facts() == {}

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:32.722633
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'vmm'
    assert var_0['virtualization_role'] == 'host'
    bytes_1 = b'\xa6\xd0\xe0\x9dO\xdd\x97\x07\x1dn\xb2\x89\xe6\x8b\xdf'

# Generated at 2022-06-25 01:20:39.161188
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Tuple to be used as input
    var_0 = tuple([])
    var_1 = tuple([var_0])
    open_b_s_d_virtual_0 = OpenBSDVirtual(var_1)
    open_b_s_d_virtual_1 = OpenBSDVirtual(var_1)
    assert open_b_s_d_virtual_1 is not None
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:45.841509
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bytes_0)


# Generated at 2022-06-25 01:20:51.219768
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    list_0 = []
    list_1 = [list_0]
    open_b_s_d_virtual_1 = OpenBSDVirtual(list_1)
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(open_b_s_d_virtual_1)
    open_b_s_d_virtual_collector_0.collect()



# Generated at 2022-06-25 01:20:54.312606
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:57.844080
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    # Need to create a detailed test case for this
    assert open_b_s_d_virtual_collector_0 is not None


# Generated at 2022-06-25 01:21:11.364724
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:17.592344
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with string_0
    string_0 = ':'
    open_b_s_d_virtual_0 = OpenBSDVirtual(string_0)
    # Test with string_1
    string_1 = 'S'
    open_b_s_d_virtual_1 = OpenBSDVirtual(string_1)
    # Test with string_2
    string_2 = '|O'
    open_b_s_d_virtual_2 = OpenBSDVirtual(string_2)
    # Test with string_3
    string_3 = 'C'
    open_b_s_d_virtual_3 = OpenBSDVirtual(string_3)
    # Test with string_4
    string_4 = '"^\x0bT'

# Generated at 2022-06-25 01:21:18.672877
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:21:26.405076
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fact_class = OpenBSDVirtual
    platform = 'OpenBSD'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(fact_class, platform)
    # Test type of member variables
    assert isinstance(open_b_s_d_virtual_collector_0._fact_class, type)
    assert isinstance(open_b_s_d_virtual_collector_0._platform, str)

# Generated at 2022-06-25 01:21:35.522376
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    list_0 = []
    list_1 = [list_0]
    open_b_s_d_virtual_1 = OpenBSDVirtual(list_1)

# Generated at 2022-06-25 01:21:40.828523
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Case 0
    list_1 = ['VirtualBox', 'VirtualBox', 'VirtualBox']
    list_2 = ['vbox']
    virtual_facts_0 = {
        'virtualization_role': 'guest',
        'virtualization_type': 'vbox',
        'virtualization_tech_guest': set(list_1),
        'virtualization_tech_host': set(list_2)}
    open_b_s_d_virtual_0 = OpenBSDVirtual(None)
    assert open_b_s_d_virtual_0.get_virtual_facts() == virtual_facts_0


# Generated at 2022-06-25 01:21:48.437538
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_2 = OpenBSDVirtual(b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{')
    open_b_s_d_virtual_2.get_virtual_facts()
    open_b_s_d_virtual_3 = OpenBSDVirtual([])
    open_b_s_d_virtual_3.get_virtual_facts()


# Generated at 2022-06-25 01:21:51.760963
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
  assert open_b_s_d_virtual_collector_0.get_all_facts()['virtualization_role'] == ''

if __name__ == "__main__":
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:21:57.517714
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:01.629075
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0.collect()
    list_0 = []
    list_1 = [list_0]
    open_b_s_d_virtual_1 = OpenBSDVirtual(list_1)

#test_case_0()
#test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:25.037480
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:26.668127
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector is not None

# Generated at 2022-06-25 01:22:36.450392
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    list_0 = []
    list_1 = [list_0]
    open_b_s_d_virtual_1 = OpenBSDVirtual(list_1)
    assert var_0 == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}

# Generated at 2022-06-25 01:22:40.315963
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(None)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': 'host', 'virtualization_type': 'vmm', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set(['vmm'])}


# Generated at 2022-06-25 01:22:47.591291
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    dmesg_boot_0 = ''
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0, dmesg_boot_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': {'vmm'}, 'virtualization_type': 'vmm'}


# Generated at 2022-06-25 01:22:56.611696
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b"\x00"
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    open_b_s_d_virtual_0.detect_virt_product = MagicMock(return_value = {})
    open_b_s_d_virtual_0.detect_virt_vendor = MagicMock(return_value = {})
    open_b_s_d_virtual_0.get_file_content = MagicMock(return_value = "r!_")
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}


# Generated at 2022-06-25 01:23:01.977054
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:08.462433
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:09.736602
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-25 01:23:12.553259
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)


# Generated at 2022-06-25 01:24:12.790197
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test for constructor initialization
    var_0 = OpenBSDVirtualCollector()
    # Test for class attribute assignment
    var_0.platform = ''
    var_0.fact_class = ''
    # Verify definition of class attribute 'platform'
    assert hasattr(OpenBSDVirtualCollector, 'platform')
    # Verify definition of class attribute 'fact_class'
    assert hasattr(OpenBSDVirtualCollector, 'fact_class')


# Generated at 2022-06-25 01:24:23.047725
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    dict_0 = dict()
    dict_0['bytes_0'] = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    dict_0['bytes_2'] = b'\x1e\xe8\x05\x06<\xc55\x00\x87\xf3/\x97\x17\x1f\x87\x00\x9b'
    dict_0['open_b_s_d_virtual_0'] = OpenBSDVirtual(dict_0['bytes_0'])
    dict_0['open_b_s_d_virtual_1'] = OpenBSDVirtual(dict_0['bytes_2'])

# Generated at 2022-06-25 01:24:31.726146
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:39.431915
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    org.yaml.snakeyaml.tokens.TokenId
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    list_0 = []
    list_1 = [list_0]
    open_b_s_d_virtual_1 = OpenBSDVirtual(list_1)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:24:43.545848
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:46.472570
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = bytes([120, 10, 162, 234, 164, 98, 221, 154, 10, 5, 176, 157, 2, 47, 183, 1, 123])
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    # Put your code below
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:24:50.493247
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    obj = OpenBSDVirtual(0.0)
    obj.get_virtual_facts()

if __name__ == '__main__':
    test_OpenBSDVirtual_get_virtual_facts()
    test_case_0()

# Generated at 2022-06-25 01:24:55.398708
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
#     open_b_s_d_virtual_collector_0.collect()
#     open_b_s_d_virtual_collector_0.get_facts()

if __name__ == '__main__':
#     test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:25:00.201558
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    func = OpenBSDVirtual(None)
    out = func.get_virtual_facts()
    assert out != None


# Generated at 2022-06-25 01:25:04.179728
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:27:19.406733
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:27:25.804494
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_v_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    # Unit test for constructor of class OpenBSDVirtual
    test_case_0()
    # Unit test for constructor of class OpenBSDVirtualCollector
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:27:26.954446
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:27:36.801221
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_host'] == set(['xen'])
    assert var_0['virtualization_tech_guest'] == set([])
    assert var_0['virtualization_type'] == 'xen'
    assert var_0['virtualization_role'] == 'host'
    assert var_0['virtualization_product'] == 'OpenBSD'

# Generated at 2022-06-25 01:27:43.314543
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:50.444548
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # var_1 = get_file_content('/var/run/dmesg.boot')
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:27:55.400960
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_type' == var_0['virtualization_type']
    assert 'virtualization_role' == var_0['virtualization_role']
    assert 'virtualization_tech_host' == var_0['virtualization_tech_host']
    assert 'virtualization_tech_guest' == var_0['virtualization_tech_guest']

# Generated at 2022-06-25 01:27:57.217217
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test for constructor of class OpenBSDVirtualCollector
    var_1 = OpenBSDVirtualCollector()
    assert var_1.platform == 'OpenBSD'
    assert var_1._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:28:00.912069
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\n\xa2\xea\xa4b\xdd\x9a\n\x05\xb0\x9d\x02/\xb7\x01{'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    list_0 = []
    list_1 = [list_0]
    open_b_s_d_virtual_1 = OpenBSDVirtual(list_1)

# Generated at 2022-06-25 01:28:02.676714
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    x = open_b_s_d_virtual_collector_0.get_all()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()