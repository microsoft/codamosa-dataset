

# Generated at 2022-06-25 01:18:21.137966
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = open_b_s_d_virtual_collector_0.collect()
    assert open_b_s_d_virtual_0.get('virtualization_type') == 'vmm'
    assert open_b_s_d_virtual_0.get('virtualization_role') == 'host'
    assert 'vmm' in open_b_s_d_virtual_0.get('virtualization_tech_host')
    assert open_b_s_d_virtual_0.get('virtualization_tech_guest') == set()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:18:23.213011
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:18:26.019127
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual = OpenBSDVirtual()
    assert OpenBSDVirtual.get_virtual_facts() == ''

# Generated at 2022-06-25 01:18:30.364517
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0 == open_b_s_d_virtual_collector_1


# Generated at 2022-06-25 01:18:33.149012
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:41.595601
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    openbsd_virtual_0 = OpenBSDVirtual({})

# Generated at 2022-06-25 01:18:43.179727
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_OpenBSDVirtual = OpenBSDVirtual()
    test_OpenBSDVirtual._module = FakeModule()


# Generated at 2022-06-25 01:18:46.265059
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    open_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:18:49.098429
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create instance of class OpenBSDVirtual
    # This will test OpenBSDVirtual.__init__
    open_b_s_d_virtual_0 = OpenBSDVirtual()


# Generated at 2022-06-25 01:18:53.914649
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    value = open_b_s_d_virtual_0.get_virtual_facts()
    if not isinstance(value, dict):
        raise AssertionError("Returned value '%s' of get_virtual_facts is not a dict" % (value))



# Generated at 2022-06-25 01:19:04.124816
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)


# Generated at 2022-06-25 01:19:09.728862
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = -2087
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)


# Generated at 2022-06-25 01:19:15.547226
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)


# Generated at 2022-06-25 01:19:20.090915
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = -2551
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)
    open_b_s_d_virtual_collector_0.get_all_facts()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:19:24.825781
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    str_0 = open_b_s_d_virtual_0.get_virtual_facts()
    str_1 = "{'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': '', 'virtualization_type': ''}"
    assert str_0 == str_1


# Generated at 2022-06-25 01:19:29.102393
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)

# Generated at 2022-06-25 01:19:30.142052
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    test_case_0 ()

test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:19:37.927178
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = -2551
    int_1 = -2087
    virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)

if __name__ == "__main__":
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:19:42.688273
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:19:54.036792
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:20:07.643882
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = -1938
    int_1 = -2651
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)
    var_0 = open_b_s_d_virtual_collector_0.collect()
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector(int_1)

main()

# Generated at 2022-06-25 01:20:13.567316
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    os_family = 'OpenBSD'
    os_release = '6.1'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(os_release, os_family)
    var_0 = open_b_s_d_virtual_collector_0.get_virtual_facts()
    os_family = 'openbsd'
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector(os_release, os_family)
    var_1 = open_b_s_d_virtual_collector_1.get_virtual_facts()


# Generated at 2022-06-25 01:20:19.526185
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)

# Generated at 2022-06-25 01:20:28.786527
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    open_b_s_d_virtual_2 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_2.get_virtual_facts()
    open_b_s_d_virtual_3 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_3.get_virtual_

# Generated at 2022-06-25 01:20:31.719517
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:20:37.896068
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)

# Generated at 2022-06-25 01:20:40.972623
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    assert open_b_s_d_virtual_0.get_virtual_facts() == dict()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)

# Generated at 2022-06-25 01:20:49.010095
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 0
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    int_1 = -2551
    int_2 = -2087
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_2)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    open_b_s_d_virtual_2 = OpenBSDVirtual(int_1)

# Generated at 2022-06-25 01:20:57.651889
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    var_2 = 0
    var_2 = var_0
    assert var_2 == var_1


# Generated at 2022-06-25 01:21:03.093416
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 645
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:20.507189
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)


# Generated at 2022-06-25 01:21:26.996650
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector(open_b_s_d_virtual_collector_0)
    open_b_s_d_virtual_collector_2 = OpenBSDVirtualCollector(open_b_s_d_virtual_collector_0)


# Generated at 2022-06-25 01:21:28.154838
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:21:36.186580
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    # The method get_virtual_facts of class OpenBSDVirtual has errors.
    with pytest.raises(Exception):
        open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)


# Generated at 2022-06-25 01:21:38.957619
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)

# Generated at 2022-06-25 01:21:42.190893
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert True


# Generated at 2022-06-25 01:21:48.542218
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)


# Generated at 2022-06-25 01:21:51.564555
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 20
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)
    assert open_b_s_d_virtual_collector_0.get_all_facts() == {}, 'Return value was expected to be {}'


# Generated at 2022-06-25 01:21:57.518785
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)
    return var_0


# Generated at 2022-06-25 01:22:00.150274
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_2 = OpenBSDVirtual(-2551)
    var_2 = open_b_s_d_virtual_2.get_virtual_facts()


# Generated at 2022-06-25 01:22:27.855287
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:22:34.544897
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)


# Generated at 2022-06-25 01:22:39.689731
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:42.836360
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)

# Generated at 2022-06-25 01:22:50.941165
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_2 = -1
    open_b_s_d_virtual_2 = OpenBSDVirtual(int_2)
    var_1 = open_b_s_d_virtual_2.get_virtual_facts()
    print(type(var_1))
    for x in var_1.keys():
        print (x, ":", var_1[x])

if __name__ == "__main__":
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:22:55.583132
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_OpenBSDVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 01:22:56.702665
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:04.308736
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -27217
    int_1 = -7764
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    tuple_0 = open_b_s_d_virtual_0.get_virtual_facts()
    bool_0 = True
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_1)
    dict_0 = dict()
    dict_0['virtualization_type'] = ''
    dict_0['virtualization_role'] = 'host'
    dict_0['virtualization_tech_host'] = set()
    dict_0['virtualization_tech_guest'] = set()
    dict_0['virtualization_tech_host'].add('')
    dict_0['virtualization_tech_guest'].add('')


# Generated at 2022-06-25 01:23:10.405275
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -24855
    int_1 = 43
    int_2 = -30383
    int_3 = -21098
    int_4 = -24225

    # Call method get_virtual_facts of class OpenBSDVirtual
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_4)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_3)
    open_b_s_d_virtual_2 = OpenBSDVirtual(int_2)
    open_b_s_d_virtual_3 = OpenBSDVirtual(int_1)
    open_b_s_d_virtual_4 = OpenBSDVirtual(int_0)

# Generated at 2022-06-25 01:23:16.671101
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)

# Generated at 2022-06-25 01:24:28.774390
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Case 0
    test_case_0()

# Generated at 2022-06-25 01:24:30.694212
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    var_2 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:32.840358
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:24:34.596085
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -12648
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:37.553032
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:24:39.681716
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  assert VirtualCollector._platform == 'OpenBSD'
  assert _fact_class == OpenBSDVirtual

test_case_0()

# Generated at 2022-06-25 01:24:41.853269
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = -16852
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:24:45.548632
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0 != None, "Error: OpenBSDVirtualCollector()"

# Generated at 2022-06-25 01:24:50.846271
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector(int_1)


# Generated at 2022-06-25 01:24:55.660044
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    var_1 = OpenBSDVirtualCollector.get_virtual_facts()
    var_1 = OpenBSDVirtualCollector.get_virtual_facts()
    var_1 = OpenBSDVirtualCollector.get_virtual_facts()
    var_1 = OpenBSDVirtualCollector.get_virtual_facts()


if __name__ == "__main__":
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:27:31.649142
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    int_2 = -598
    open_b_s_d_virtual_0.detect_virt_product(int_2)
    int_3 = -226
    open_b_s_d_virtual_0.detect_virt_vendor(int_3)
    # FIXME: preserve_filename_case is not tested
    # FIXME: preserve_newlines is not tested
    # FIXME: follow is not tested
    # FIXME: get_file_content is not tested
    # FIXME: join is not tested
    # FIXME: get_directory_content is not tested
    # FIXME: get_directory_tree is not tested
    # FIX

# Generated at 2022-06-25 01:27:37.309521
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(-2494)
    open_b_s_d_virtual_1 = OpenBSDVirtual(-1)
    open_b_s_d_virtual_2 = OpenBSDVirtual(-2)
    open_b_s_d_virtual_3 = OpenBSDVirtual(-2)
    open_b_s_d_virtual_4 = OpenBSDVirtual(-2039)
    open_b_s_d_virtual_5 = OpenBSDVirtual(-1)
    open_b_s_d_virtual_6 = OpenBSDVirtual(-2)
    open_b_s_d_virtual_7 = OpenBSDVirtual(-1)
    open_b_s_d_virtual_8 = OpenBSDVirtual(-1)

# Generated at 2022-06-25 01:27:43.166901
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_1)


# Generated at 2022-06-25 01:27:45.125438
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -1497
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:27:50.293517
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_2 = -7659
    open_b_s_d_virtual_2 = OpenBSDVirtual(int_2)
    return_value = open_b_s_d_virtual_2.get_virtual_facts()
    assert return_value is None


# Generated at 2022-06-25 01:27:53.033623
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()

if __name__ == "__main__":
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:27:54.817372
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:27:55.757355
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:28:00.888152
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2290
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    open_b_s_d_virtual_2 = OpenBSDVirtual(int_0)
    var_2 = open_b_s_d_virtual_2.get_virtual_facts()
    open_b_s_d_virtual_3 = OpenBSDVirtual(int_0)
    var_3 = open_b_s_d_virtual_3.get_virtual_facts()
    open_b_s

# Generated at 2022-06-25 01:28:06.365214
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = -2551
    int_1 = -2087
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_1)
    open_b_s_d_virtual_0.get_file_content = lambda x: 'hw.product = "MacBook6,1"'
    open_b_s_d_virtual_0.detect_virt_product = lambda x: {'virtualization_tech_guest': {'qemu'}, 'virtualization_tech_host': {'qemu'}, 'virtualization_type': '', 'virtualization_role': ''}