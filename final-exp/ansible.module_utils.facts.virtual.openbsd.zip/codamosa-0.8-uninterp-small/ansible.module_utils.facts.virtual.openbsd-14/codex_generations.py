

# Generated at 2022-06-25 01:18:10.215449
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:15.836118
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert test_case_0() == None, 'Constructor failed.'

if __name__ == '__main__':
    test_OpenBSDVirtualCollector()
    print("Unit test for OpenBSDVirtualCollector successful")

# Generated at 2022-06-25 01:18:17.968002
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:20.907372
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual_0 = OpenBSDVirtual()
    assert OpenBSDVirtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}



# Generated at 2022-06-25 01:18:23.098917
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:26.261952
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:27.779973
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:30.134885
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:40.546240
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test setting the host type to vmm and the guest type to none
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.detect_virt_product = MagicMock(return_value={'virtualization_type': 'vmm',
                                                                       'virtualization_tech_guest': set(),
                                                                       'virtualization_tech_host': set(['vmm'])})

    open_b_s_d_virtual_0.detect_virt_vendor = MagicMock(return_value={'virtualization_type': 'vmm',
                                                                      'virtualization_tech_guest': set(),
                                                                      'virtualization_tech_host': set(['vmm'])})

    open_b_s_d_virtual_

# Generated at 2022-06-25 01:18:46.337288
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    result = open_b_s_d_virtual_0.get_virtual_facts()
    assert result['virtualization_type'] is None
    assert result['virtualization_role'] is None
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:18:57.582773
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    result = open_b_s_d_virtual_0.get_virtual_facts()
    assert result == {
        'virtualization_role': 'host',
        'virtualization_type': 'vmm',
        'virtualization_tech_host': ['vmm'],
        'virtualization_tech_guest': ['vmm'],
    }

# Generated at 2022-06-25 01:19:02.581467
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:19:04.981433
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-25 01:19:10.247701
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    data = OpenBSDVirtualCollector()
    assert data.platform == "OpenBSD", "Constructor of OpenBSDVirtualCollector failed."

# Generated at 2022-06-25 01:19:14.784334
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    p_return_value = open_b_s_d_virtual_0.get_virtual_facts()
    assert p_return_value is not None


# Generated at 2022-06-25 01:19:16.631534
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    return  # noqa


# Generated at 2022-06-25 01:19:24.968370
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.virtualization_type = ''
    open_b_s_d_virtual_0.virtualization_role = ''
    open_b_s_d_virtual_0.virtualization_product_name = None
    open_b_s_d_virtual_0.virtualization_product_version = None
    open_b_s_d_virtual_0.virtualization_product_serial = None
    open_b_s_d_virtual_0.virtualization_product_uuid = None
    open_b_s_d_virtual_0.virtualization_product_family = None
    open_b_s_

# Generated at 2022-06-25 01:19:27.042198
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:19:29.409269
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(open_b_s_d_virtual_collector_0, OpenBSDVirtualCollector)


# Generated at 2022-06-25 01:19:37.508730
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()

    open_b_s_d_virtual._module = {
        'run_command': [
            (['sysctl', '-n', 'hw.vendor'], 'QEMU\n', 0),
            (['sysctl', '-n', 'hw.product'], 'Standard PC (Q35 + ICH9, 2009)\n', 0)
        ]
    }

    facts = open_b_s_d_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'hvm'
    assert facts['virtualization_role'] == 'guest'
    assert 'qemu' in facts['virtualization_tech_guest']


# Generated at 2022-06-25 01:19:46.901440
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:49.262530
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:56.055533
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert (open_b_s_d_virtual_collector_0.fact_class is
            OpenBSDVirtual)
    assert (open_b_s_d_virtual_collector_0.platform is 'OpenBSD')
    assert (not open_b_s_d_virtual_collector_0.ignore_virtual_facts)
    assert (open_b_s_d_virtual_collector_0.collectors ==
            ['OpenBSDVirtual'])


# Generated at 2022-06-25 01:19:56.849987
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-25 01:19:57.639090
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert not OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:20:01.620300
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    open_b_s_d_virtual_get_virtual_facts = open_b_s_d_virtual.get_virtual_facts()
    assert(open_b_s_d_virtual_get_virtual_facts['virtualization_role'] == 'host')


# Generated at 2022-06-25 01:20:07.052696
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert callable(open_b_s_d_virtual_0.get_virtual_facts)

# Generated at 2022-06-25 01:20:08.754127
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts_dict = OpenBSDVirtualCollector.get_virtual_facts()
    assert type(virtual_facts_dict) is dict

# Generated at 2022-06-25 01:20:10.640087
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._platform is "OpenBSD"

# Generated at 2022-06-25 01:20:12.205334
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert(OpenBSDVirtualCollector._platform == 'OpenBSD')
    assert(OpenBSDVirtualCollector._fact_class == OpenBSDVirtual)

# Generated at 2022-06-25 01:20:19.554495
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    var_0 = OpenBSDVirtualCollector()
    assert isinstance(var_0, OpenBSDVirtualCollector)


# Generated at 2022-06-25 01:20:29.195363
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-25 01:20:35.423567
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:44.357708
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    int_1 = 499
    int_2 = 12
    int_3 = 12
    int_4 = 8
    int_5 = 10
    int_6 = 0
    tuple_0 = (int_1, int_2, int_3, int_4, int_5, int_6)
    dict_0 = {}
    dict_0['virtualization_type'] = ''
    dict_0['virtualization_role'] = ''
    dict_0['virtualization_system'] = ''
    dict_

# Generated at 2022-06-25 01:20:48.352520
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 122
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(set_0)
    var_0 = open_b_s_d_virtual_collector_0._fact_class


# Generated at 2022-06-25 01:20:52.205392
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector({})


# Generated at 2022-06-25 01:20:57.123943
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_2 = 0
    set_1 = {int_2, int_2, int_2, int_2}
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_1)
    # Test without dmesg.boot file present
    set_2 = open_b_s_d_virtual_1.get_virtual_facts()
    assert False


# Generated at 2022-06-25 01:21:07.861937
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    dmesg_boot = get_file_content(OpenBSDVirtual.DMESG_BOOT)
    # test constructor with dmesg.boot containing vmm0
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0.collect(dmesg_boot)

    # test constructor with dmesg.boot not containing vmm0
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_collector_1._dmesg_boot = get_file_content(OpenBSDVirtual.DMESG_BOOT)
    var_0 = open_b_s_d_virtual_collector_1.collect()


# Generated at 2022-06-25 01:21:14.516573
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # Call the tested method
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:20.024095
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1808
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:38.320555
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '',
 'virtualization_role': '',
 'virtualization_tech_host': set(),
 'virtualization_tech_guest': set()}


# Generated at 2022-06-25 01:21:42.438463
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:21:49.395722
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class is OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform is 'OpenBSD'

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-25 01:21:53.543354
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 784
    set_0 = {int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    open_b_s_d_virtual_0.detect_virt_vendor('hw.vendor')
    open_b_s_d_virtual_0.detect_virt_product('hw.product')
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:00.281591
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector({int_0, int_0, int_0, int_0}, open_b_s_d_virtual_0)

if __name__ is '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:04.939096
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'



# Generated at 2022-06-25 01:22:08.601820
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1852
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:12.028492
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1519
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:13.800618
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:18.075393
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert OpenBSDVirtualCollector._platform == open_b_s_d_virtual_collector_0._platform
    assert OpenBSDVirtualCollector._fact_class == open_b_s_d_virtual_collector_0._fact_class


# Generated at 2022-06-25 01:22:43.901479
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    set_0 = {1590, 1590, 1590, 1590}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_product': '', 'virtualization_tech_host': set(), 'virtualization_system': ''}, var_0


# Generated at 2022-06-25 01:22:50.780579
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    kwargs_0 = {
    }
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(**kwargs_0)
    open_b_s_d_virtual_collector_0.populate()
    var_0 = open_b_s_d_virtual_collector_0.get_facts()


# Generated at 2022-06-25 01:22:56.038122
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    dict_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:04.024967
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test case
    set_1 = {"virtualization_type", "virtualization_role", "virtualization_tech_guest", "virtualization_tech_host"}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_1)
    # Call method
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    # Assertion
    assert var_1 == {"virtualization_type": "", "virtualization_role": "", "virtualization_tech_guest": set(), "virtualization_tech_host": set()}
    # Test case
    set_2 = {"virtualization_type", "virtualization_role", "virtualization_tech_guest", "virtualization_tech_host"}

# Generated at 2022-06-25 01:23:06.922826
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_1 = 1492
    set_1 = {int_1, int_1, int_1, int_1}
    open_b_s_d_virtual_1 = OpenBSDVirtualCollector(set_1)

# Generated at 2022-06-25 01:23:14.389938
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:23:20.279859
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_role': ''}, 'Unexpected virtualization information.'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:23:26.886268
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    var_1 = {'virtualization_type': 'vmm', 'virtualization_role': 'host', 'virtualization_tech_host': {'vmm'}, 'virtualization_tech_guest': set()}

    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}

    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == var_1


# Generated at 2022-06-25 01:23:29.980617
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_1 = 1492
    set_1 = {int_1, int_1, int_1, int_1}
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_1)
    open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:23:35.103809
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_collection_0 = OpenBSDVirtualCollector(set_0)
    var_0 = open_b_s_d_virtual_collection_0._platform


# Generated at 2022-06-25 01:24:41.233897
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:45.671485
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:50.918136
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:51.641548
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    pass


# Generated at 2022-06-25 01:24:56.465238
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_collector_0._get_virtual_facts()
    var_0 = open_b_s_d_virtual_collector_0.collect()
    var_1 = open_b_s_d_virtual_collector_0._get_virtual_facts()

# Generated at 2022-06-25 01:25:01.544391
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'vmm'


# Generated at 2022-06-25 01:25:05.573327
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    var_0 = OpenBSDVirtualCollector()
    #var_0 = OpenBSDVirtualCollector(int_0)
    #var_0 = OpenBSDVirtualCollector(int_0, int_1)
    #var_0 = OpenBSDVirtualCollector(int_0, int_1, int_2)
    #var_0 = OpenBSDVirtualCollector(dict_0, dict_1)
    #var_0 = OpenBSDVirtualCollector(dict_0, dict_1, dict_2)


# Generated at 2022-06-25 01:25:10.621088
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:25:14.695445
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    with open(OpenBSDVirtual.DMESG_BOOT, 'w') as fd:
        fd.write("vmm0 at mainbus0: SVM/RVI")
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'vmm'


# Generated at 2022-06-25 01:25:19.519991
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

    var_1 = var_0['virtualization_role']
    var_2 = var_0['virtualization_type']
    var_3 = var_0['virtualization_tech_host']
    var_4 = var_0['virtualization_tech_guest']

# Generated at 2022-06-25 01:27:38.776366
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(set())

# Generated at 2022-06-25 01:27:48.418985
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = set()
    var_1.add(2)
    var_1.add(8)
    var_2 = set()
    var_2.add(8)
    open_b_s_d_virtual_1 = OpenBSDVirtual(var_1, var_2)
    var_3 = open_b_s_d_virtual_1.get_virtual_facts()
    var_4 = set()
    var_5 = set()
    var_5.add(3)


# Generated at 2022-06-25 01:27:51.073693
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_1 = 1492
    set_1 = {int_1, int_1, int_1, int_1}
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_1)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:27:56.975032
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0 == OpenBSDVirtualCollector(), ""


# Generated at 2022-06-25 01:27:59.192798
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 23
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:28:03.934075
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:28:07.353460
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1492
    set_0 = {int_0, int_0, int_0, int_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()

    try:
        assert var_0 == var_1
    except AssertionError as e:
        print('Test case 0 failed: {}'.format(e))