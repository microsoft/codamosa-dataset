

# Generated at 2022-06-25 01:18:21.533754
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    host_tech = set()
    guest_tech = set()
    virtual_facts = {}

    # Set empty values as default
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''

    # dict : virtual_product_facts = open_b_s_d_virtual_0.detect_virt_product(str : 'hw.product')
    virtual_product_facts = {'virtualization_type': 'vmm', 'virtualization_role': 'guest'}
    guest_tech.add('vmm')
    host_tech.add('vmm')
    virtual_facts['virtualization_type'] = 'vmm'
    virtual_facts['virtualization_role'] = 'guest'

    # dict

# Generated at 2022-06-25 01:18:32.955276
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Case 0: Test empty facts
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

    # Case 1: Test expected get_virtual_facts
    open_b_s_d_virtual_1 = OpenBSDVirtual()
    open_b_s_d_virtual_1.set_facts({'hw.vendor': 'GenuineIntel', 'hw.product': 'QEMU Virtual CPU version (cpu64-rhel6)', 'hw.machine': 'amd64', 'sysctl': {'hw.vendor': 'GenuineIntel', 'hw.product': 'QEMU Virtual CPU version (cpu64-rhel6)', 'hw.machine': 'amd64'}})
    virtual_facts_returned_1 = open_b_

# Generated at 2022-06-25 01:18:36.542221
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert isinstance(open_b_s_d_virtual_collector_0, OpenBSDVirtualCollector)


# Generated at 2022-06-25 01:18:39.436528
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    ansible_facts = {}
    open_b_s_d_virtual_0 = OpenBSDVirtual(ansible_facts)
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:42.387306
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'


# Generated at 2022-06-25 01:18:45.655939
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:47.958134
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:49.446220
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:58.762466
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    if hasattr(open_b_s_d_virtual_collector_0, '_platform'):
        if open_b_s_d_virtual_collector_0._platform != 'OpenBSD':
            raise Exception('AssertionError')
    else:
        raise Exception('AssertionError')
    if hasattr(open_b_s_d_virtual_collector_0, '_fact_class'):
        if not isinstance(open_b_s_d_virtual_collector_0._fact_class, OpenBSDVirtual):
            raise Exception('AssertionError')
    else:
        raise Exception('AssertionError')

# Generated at 2022-06-25 01:19:06.874119
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    open_b_s_d_virtual_0 = OpenBSDVirtual(None)
    open_b_s_d_virtual_0.collect()

    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set(['openbsd'])
    assert virtual_facts['virtualization_tech_host'] == set(['vmm', 'openbsd'])

# Generated at 2022-06-25 01:19:20.194731
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -4851
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    open_b_s_d_virtual_2 = open_b_s_d_virtual_1.get_virtual_facts()
    int_1 = open_b_s_d_virtual_2.get('virtualization_type')
    int_2 = open_b_s_d_virtual_2.get('virtualization_role')
    str_0 = Test0.get('virtualization_tech_guest')
    str_

# Generated at 2022-06-25 01:19:21.513696
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:19:24.738503
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:29.033610
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Initializing object
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert isinstance(open_b_s_d_virtual_0, OpenBSDVirtual)

    # Call the get_virtual_facts() method.
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:34.127166
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    # Verify that the file 'hw.vendor' exists, otherwise
    # skip the test.
    if (not os.path.isfile('hw.vendor')):
        skip("Cannot find file 'hw.vendor'")
    # Verify that the file 'hw.product' exists, otherwise
    # skip the test.
    if (not os.path.isfile('hw.product')):
        skip("Cannot find file 'hw.product'")
    # Input parameters:
    #   *with_facts*: determines if the returned fact
    #                 structure will include nested facts
    # Expected result: the method returns a collection of
    #                  facts about the virtualization
    #                  configuration of the host.
    # Actual result:

# Generated at 2022-06-25 01:19:39.214616
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = 858
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:19:49.184693
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:19:55.076869
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:19:57.977827
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual(open_b_s_d_virtual_collector_0)
    test_case_0()

# Generated at 2022-06-25 01:20:00.700455
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'


# Generated at 2022-06-25 01:20:08.609058
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-25 01:20:17.212505
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    int_0 = -2861
    string_0 = 'hw.product'
    open_b_s_d_virtual_0 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, int_0, string_0)
    bool_0 = True
    string_1 = 'hw.vendor'
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_0, string_1)
    string_2 = '/var/run/dmesg.boot'
    open_b_s_d_virtual_0.DMESG_BOOT = string_2
    string_3 = '/var/run/dmesg.boot'
    open_b_s_d_virtual_1

# Generated at 2022-06-25 01:20:21.885618
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:20:26.664440
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.platform = 'OpenBSD'
    open_b_s_d_virtual_0.kernel = 'OpenBSD'
    open_b_s_d_virtual_0.mount_device = 'OpenBSD'
    open_b_s_d_virtual_0.dmidecode_facts = 'OpenBSD'
    open_b_s_d_virtual_0.architecture = 'OpenBSD'
    open_b_s_d_virtual_0.path_exists = 'OpenBSD'
    open_b_s_d_virtual_0.platform_version = 'OpenBSD'
    open_b_s_d_virtual_0.get_mount_device = 'OpenBSD'
    open_b

# Generated at 2022-06-25 01:20:31.991591
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    my_obj = OpenBSDVirtual()
    dict_0 = my_obj.get_virtual_facts()
#   print(dict_0)

if __name__ == '__main__':
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:20:41.712437
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

    assert open_b_s_d_virtual_1.virtualization_tech_host == {'vmm'}
    assert open_b_s_d_virtual_1.virtualization_tech_guest == set()
    assert open_b_s_d_virtual_1.virtualization_role == 'host'
    assert open_

# Generated at 2022-06-25 01:20:45.914516
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:47.860248
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    return var_0


# Generated at 2022-06-25 01:20:58.938043
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
    bool_1 = True
    open_b_s_d_virtual_2 = OpenBSDVirtual(bool_1)
    int_1 = -2861
    open_b_s_d_virtual_3 = OpenBSDVirtual(open_b_s_d_virtual_2, int_1)
    var_0 = open_b_

# Generated at 2022-06-25 01:21:01.981799
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:21:21.899089
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = 1
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    assert 'virtualization_type' in open_b_s_d_virtual_1.get_virtual_facts()
    assert 'virtualization_role' in open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:21:27.611246
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = open_b_s_d_virtual_collector_0._get_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_2 = open_b_s_d_virtual_1._get_facts()


# Generated at 2022-06-25 01:21:32.454995
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)




# Generated at 2022-06-25 01:21:37.790213
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:21:42.504921
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:21:50.920030
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = 1808
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:21:59.121193
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var = open_b_s_d_virtual_1.get_virtual_facts()
    assert var is None


# Generated at 2022-06-25 01:22:10.068379
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    # Check for value of virtualization_type is vmm
    try:
        assert open_b_s_d_virtual_0.get_virtual_facts()['virtualization_type'] == 'vmm'
    except AssertionError as error:
        raise error
    # Check for value of virtualization_role is host
    try:
        assert open_b_s_d_virtual_0.get_virtual_facts()['virtualization_role'] == 'host'
    except AssertionError as error:
        raise error
    # Check for value of virtualization_tech_guest is 'kvm'

# Generated at 2022-06-25 01:22:16.895324
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:22:19.983894
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Default Constructor
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:22:51.623359
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_role': 'guest', 'virtualization_type': 'vmm',
                     'virtualization_technologies_host': ['vmm'], 'virtualization_technologies_guest': ['vmm']}
    assert virtual_facts == OpenBSDVirtual(True).get_virtual_facts()
    assert virtual_facts == OpenBSDVirtual(OpenBSDVirtualCollector(), -2861).get_virtual_facts()


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:22:52.219983
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    unit_test_test_case_0()


# Generated at 2022-06-25 01:23:01.011475
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    # Call method get_virtual_facts
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:23:08.968056
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = 18788
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:23:11.594750
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    print(var_0)


# Generated at 2022-06-25 01:23:19.612297
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()

    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:23:23.669905
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool())
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:23:27.917006
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector(open_b_s_d_virtual_collector_0)


# Generated at 2022-06-25 01:23:28.945946
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 01:23:35.253738
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.fact_cache
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:40.103737
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    test_case_0()


# Generated at 2022-06-25 01:24:44.905704
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD', '_platform is not set to "OpenBSD"!'
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual, '_fact_class is not set to OpenBSDVirtual!'


# Generated at 2022-06-25 01:24:47.456311
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:24:56.731588
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_1 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_1)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    var_1 = False
    assert(var_0['virtualization_role'] == var_1)


# Generated at 2022-06-25 01:25:02.724712
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:25:04.233534
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:07.848622
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:25:12.978995
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -2861
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:25:18.276662
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert type(open_b_s_d_virtual_collector_0) == OpenBSDVirtualCollector
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'
    assert type(open_b_s_d_virtual_collector_0._fact_class) == type(OpenBSDVirtual)


# Generated at 2022-06-25 01:25:21.702571
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    open_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:27:51.634090
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(['a', 'A'], 65, [])
    open_b_s_d_virtual_0 = OpenBSDVirtualCollector.get_virtual_class()
    str_0 = OpenBSDVirtualCollector.get_platform()
    var_0 = OpenBSDVirtualCollector.is_supported(str_0)
    open_b_s_d_virtual_1 = OpenBSDVirtualCollector.get_virtual_class(str_0)
    var_1 = OpenBSDVirtualCollector.is_supported(str_0, open_b_s_d_virtual_1)
    open_b_s_d_virtual_2 = OpenBSDVirtualCollector.get_virtual_class(str_0, open_b_s_d_virtual_1)

# Generated at 2022-06-25 01:27:56.339324
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:27:57.616043
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:28:02.634876
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Default test case
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:28:11.884082
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    int_0 = -1431
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, int_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    str_0 = 'product'
    var_1 = open_b_s_d_virtual_collector_0.detect_virt_product(str_0)
    int_1 = 2
    str_1 = 'vendor'
    var_2 = open_b_s_d_virtual_collector_0.detect