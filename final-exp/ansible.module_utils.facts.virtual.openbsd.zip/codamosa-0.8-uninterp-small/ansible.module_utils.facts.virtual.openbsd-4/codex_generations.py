

# Generated at 2022-06-25 01:18:09.079860
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:18:11.707833
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': 'vmm', 'virtualization_role': 'host', 'virtualization_tech_host': {'vmm'}, 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:18:16.507349
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(open_b_s_d_virtual_collector, OpenBSDVirtualCollector)



# Generated at 2022-06-25 01:18:23.017630
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import os
    import pytest
    import json

    os.environ['ANSIBLE_GET_VIRTUAL_FACTS_CMD'] = 'cat tests/unit/module_utils/facts/virtual/fixtures/openbsd_virtual_info.out'
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    virtual_facts = open_b_s_d_virtual_collector.collect()
    with open('tests/unit/module_utils/facts/virtual/expected_openbsd_virtual_facts.json') as f:
        expected_facts = json.load(f)

    assert virtual_facts == expected_facts
    assert open_b_s_d_virtual_collector._platform == 'OpenBSD'


# Familiar pattern, but we don't want to call the
# Open

# Generated at 2022-06-25 01:18:25.810458
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:30.176123
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    result = OpenBSDVirtual().get_virtual_facts()
    assert type(result) is dict
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_system' in result
    assert 'virtualization_product' in result
    assert 'virtualization_uuid' in result


# Generated at 2022-06-25 01:18:36.350475
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    virtual_facts = open_b_s_d_virtual_collector_0.get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-25 01:18:38.624088
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_instance_0 = OpenBSDVirtual()
    open_b_s_d_virtual_instance_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:45.097606
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_1 = OpenBSDVirtual()
    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:49.322338
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == \
        {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}



# Generated at 2022-06-25 01:18:56.060769
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 01:19:01.026351
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-25 01:19:03.215011
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.facts != empty_facts


# Generated at 2022-06-25 01:19:10.370522
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0._fact_class == 'OpenBSDVirtual'
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'

# Generated at 2022-06-25 01:19:18.546942
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.populate_sysctl_facts = lambda: {'hw.vendor': 'Parallels', 'hw.product': ''}
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': 'parallels', 'virtualization_role': 'guest', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}


# Generated at 2022-06-25 01:19:24.490647
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # This is a constructor test; no assertions needed
    try:
        open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    except Exception:
        assert False


# Generated at 2022-06-25 01:19:28.813262
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:29.727030
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()



# Generated at 2022-06-25 01:19:33.462595
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': ''}



# Generated at 2022-06-25 01:19:40.059245
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

    # Test with no arguments
    assert open_b_s_d_virtual_0.get_virtual_facts()['virtualization_type'] == ''
    assert open_b_s_d_virtual_0.get_virtual_facts()['virtualization_role'] == ''
    assert open_b_s_d_virtual_0.get_virtual_facts()['virtualization_tech_guest'] == set([])
    assert open_b_s_d_virtual_0.get_virtual_facts()['virtualization_tech_host'] == set([])

# Generated at 2022-06-25 01:19:48.747530
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0 is not None


# Generated at 2022-06-25 01:19:49.950882
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # TODO: implement
    pass


# Generated at 2022-06-25 01:19:52.348272
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:54.932278
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # TODO: Add proper unit tests
    if False:
        open_b_s_d_virtual = OpenBSDVirtual()
        open_b_s_d_virtual.get_virtual_facts()


# Generated at 2022-06-25 01:19:57.526494
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual({'ansible_facts': {'ansible_system': 'OpenBSD'}})
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:59.964488
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-25 01:20:04.679869
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtualCollector()
    expected = dict(virtualization_role='host', virtualization_type='virtualbox', virtualization_tech_host={'vboxsf', 'openbsd', 'vboxvideo', 'vboxguest', 'usb', 'virtio', 'vboxnetadp', 'vboxnetflt', 'vboxdrv'}, virtualization_tech_guest={'openbsd'})
    returned = open_b_s_d_virtual.get_virtual_facts()
    assert returned == expected


# Generated at 2022-06-25 01:20:07.341996
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:20:11.276346
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.facts == {}
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0.fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:20:17.110050
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Test case to cover execution of get_virtual_facts() method.
    This test is used only for coverage purposes.
    """
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:26.396502
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-25 01:20:31.776500
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0 is not None


# Generated at 2022-06-25 01:20:38.788126
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Referece https://github.com/ansible/ansible/issues/6623
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    print(var_0)

# Generated at 2022-06-25 01:20:49.486814
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert set({'openbsd', 'xen'}).issubset(var_0['virtualization_tech_guest'])
    assert set({'openbsd', 'xen'}).issubset(var_0['virtualization_tech_host'])
    assert set({'xen'}).issubset(var_0['virtualization_tech_guest'])
    assert set({'xen'}).issubset(var_0['virtualization_tech_host'])
    assert var

# Generated at 2022-06-25 01:20:56.057613
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector.__class__ == OpenBSDVirtualCollector
    assert open_b_s_d_virtual_collector._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-25 01:20:58.386156
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:21:05.850783
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_type' in var_0

# Generated at 2022-06-25 01:21:09.903752
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_guest'] == set([])
    assert var_0['virtualization_tech_host'] == set([])


# Generated at 2022-06-25 01:21:12.384332
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert True == True


# Generated at 2022-06-25 01:21:14.629936
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:31.664986
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    return var_0


# Generated at 2022-06-25 01:21:33.284689
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:21:38.180093
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert(isinstance(OpenBSDVirtual().get_virtual_facts(), dict))

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:21:45.247034
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    # TODO: fix this
    # var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # assert var_0 == 'some value'

# Generated at 2022-06-25 01:21:54.036203
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-25 01:21:59.366907
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(False)
    open_b_s_d_virtual_1 = OpenBSDVirtual(False)
    open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:22:05.453203
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    bool_0 = False
    virtual_facts_0 = open_b_s_d_virtual_0.get_virtual_facts(bool_0)
    dmesg_boot_0 = open_b_s_d_virtual_0.dmesg_boot()



# Generated at 2022-06-25 01:22:07.736210
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    print("Virtual_facts = " + str(open_b_s_d_virtual.get_virtual_facts()))


# Generated at 2022-06-25 01:22:10.740795
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-25 01:22:15.046071
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(False)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert True

# Generated at 2022-06-25 01:22:41.892548
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_1 = OpenBSDVirtual()
    bool_0 = False
    dict_0 = open_b_s_d_virtual_1.get_virtual_facts(bool_0)

# Generated at 2022-06-25 01:22:50.019045
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert type(var_0) is dict and var_0


# Generated at 2022-06-25 01:22:52.093031
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_3 = OpenBSDVirtual(False)
    var_3 = open_b_s_d_virtual_3.get_virtual_facts()
    assert var_3 == {}


# Generated at 2022-06-25 01:22:56.119572
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool())
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:01.404633
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:23:09.325534
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    if var_0 != {'virtualization_type': '',
                 'virtualization_role': '',
                 'virtualization_tech_host': set(),
                 'virtualization_tech_guest': set()}:
        raise AssertionError()


# Generated at 2022-06-25 01:23:10.521024
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector() != None


# Generated at 2022-06-25 01:23:17.783065
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = None
    var_0 = var_0.get('virtualization_type')
    assert var_0 == var_1

# Generated at 2022-06-25 01:23:21.669011
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'


# Generated at 2022-06-25 01:23:26.933174
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:35.964377
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
    bool_1 = False
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_1)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()

    for item in var_1:
        print(item + ' : ' + var_1[item])

# Generated at 2022-06-25 01:24:42.895881
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:24:52.158539
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # dict
    assert isinstance(var_0, dict)
    #
    for key in var_0.keys():
        # str
        assert isinstance(key, str)
        # str
        assert isinstance(var_0[key], str)
    # int
    assert isinstance(var_0['virtualization_role'], int)

# Generated at 2022-06-25 01:24:53.091367
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:24:54.432992
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_2 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:24:59.746411
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    if test_OpenBSDVirtualCollector.func_name == 'test_case_0':
        open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
        assert True
        # No exception was raised
    if test_OpenBSDVirtualCollector.func_name == 'test_case_1':
        open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
        assert True
        # No exception was raised


# Generated at 2022-06-25 01:25:01.304988
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:25:02.985430
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:25:11.938013
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Test module.
    """
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.__class__.__name__ == 'OpenBSDVirtualCollector'
    open_b_s_d_virtual_0 = OpenBSDVirtual(True)
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

if __name__ == "__main__":
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:25:18.941426
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    var_6 = len(var_0)
    var_7 = len(var_1)
    assert var_6 == var_7
    assert var_0 == var_1

# Generated at 2022-06-25 01:27:49.513380
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:53.496736
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''
    assert len(var_0['virtualization_tech_host']) == 0
    assert len(var_0['virtualization_tech_guest']) == 0

# Generated at 2022-06-25 01:27:56.972216
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.hw_product = ''
    open_b_s_d_virtual_0.hw_vendor = ''
    assert open_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-25 01:27:58.079498
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:28:02.897674
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(False)
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:28:12.139575
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()