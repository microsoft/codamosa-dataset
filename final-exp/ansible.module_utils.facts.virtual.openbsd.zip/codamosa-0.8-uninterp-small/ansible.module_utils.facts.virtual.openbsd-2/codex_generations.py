

# Generated at 2022-06-25 01:18:09.759993
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_1


# Generated at 2022-06-25 01:18:11.726471
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  obj = OpenBSDVirtualCollector()
  assert obj._fact_class == OpenBSDVirtual
  assert obj._platform == 'OpenBSD'


# Generated at 2022-06-25 01:18:20.114304
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    open_b_s_d_virtual = open_b_s_d_virtual_collector.collect()
    assert open_b_s_d_virtual['virtualization_type'] == ''
    assert open_b_s_d_virtual['virtualization_role'] == ''
    assert open_b_s_d_virtual['virtualization_tech_guest']  == set()
    assert open_b_s_d_virtual['virtualization_tech_host']  == set()


# Generated at 2022-06-25 01:18:22.364882
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual



# Generated at 2022-06-25 01:18:25.415173
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual_0 = OpenBSDVirtual(OpenBSDVirtualCollector)
    OpenBSDVirtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:27.665213
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_obj = OpenBSDVirtualCollector()
    test_case_0()


# Generated at 2022-06-25 01:18:32.596916
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.platform = 'OpenBSD'
    open_b_s_d_virtual_0.get_virtual_facts()

test_case_0()
test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:18:35.856513
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:39.606453
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  assert open_b_s_d_virtual_collector_0.get_all() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_product_name': '', 'virtualization_product_version': ''}


# Generated at 2022-06-25 01:18:43.059298
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:55.444531
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

    assert var_0 == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_product_serial': '',
        'virtualization_product_uuid': '',
        'virtualization_product_vendor': '',
        'virtualization_tech_guest': {},
        'virtualization_tech_host': {'vmm'},
    }


# Generated at 2022-06-25 01:19:01.269330
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_1 = open_b_s_d_virtual_collector_0.fetch_virtual_facts()
    assert open_b_s_d_virtual_collector_0._fact_class.__name__ == 'OpenBSDVirtual'
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'
    assert isinstance(var_1, dict)


# Generated at 2022-06-25 01:19:04.615261
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    # call method get_virtual_facts of class OpenBSDVirtual
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

test_case_0()

# Generated at 2022-06-25 01:19:06.738545
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    if (open_b_s_d_virtual_0.get_virtual_facts() != None):
        raise Exception('Test failed')



# Generated at 2022-06-25 01:19:08.879999
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_0)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:19:19.367174
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_1 = 3651
    open_b_s_d_virtual_1 = OpenBSDVirtual(int_1)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    var_2 = open_b_s_d_virtual_1.get_virtual_facts()
    var_3 = open_b_s_d_virtual_1.get_virtual_facts()
    var_4 = open_b_s_d_virtual_1.get_virtual_facts()
    var_5 = open_b_s_d_virtual_1.get_virtual_facts()
    var_6 = open_b_s_d_virtual_1.get_virtual_facts()
   

# Generated at 2022-06-25 01:19:22.052307
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = type(open_b_s_d_virtual_collector_0) is OpenBSDVirtualCollector


# Generated at 2022-06-25 01:19:26.480085
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    dict_0 = {'virtualization_tech_host': set([]), 'virtualization_tech_guest': set([])}
    assert open_b_s_d_virtual_0.get_virtual_facts() == dict_0

# Generated at 2022-06-25 01:19:30.839533
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 3651
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)
    var_0 = open_b_s_d_virtual_collector_0.populate()


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:19:37.147480
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 0
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    print(var_0)

# Run all unit tests
test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:19:48.666619
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 0
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# vim: se fileencoding=utf-8 :

# Generated at 2022-06-25 01:19:54.267817
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    var_2 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:02.063498
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    open_b_s_d_virtual_0.platform = 'EFI'
    open_b_s_d_virtual_0.detect_virt_vendor = OpenBSDVirtual.detect_virt_vendor
    open_b_s_d_virtual_0.detect_virt_product = OpenBSDVirtual.detect_virt_product
    open_b_s_d_virtual_0.detect_virt_sysctl = OpenBSDVirtual.detect_virt_sysctl
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    print(var_0)


# Generated at 2022-06-25 01:20:08.274538
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 14
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)
    var_0 = open_b_s_d_virtual_collector_0.platform
    assert var_0 == 'OpenBSD'


# Generated at 2022-06-25 01:20:14.482916
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_1 == dict(virtualization_role='', virtualization_type='', virtualization_tech_guest=set(), virtualization_tech_host=set())


# Generated at 2022-06-25 01:20:20.205612
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    #
    # create a "fixture" by invoking the constructor
    #
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

    #
    # Do some operations with the object
    #


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:22.430659
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_1 = 3651
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_1)


# Generated at 2022-06-25 01:20:25.440247
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert isinstance(open_b_s_d_virtual_collector_0._fact_class, OpenBSDVirtual) == True
    assert isinstance(open_b_s_d_virtual_collector_0._platform, str) == True


# Generated at 2022-06-25 01:20:27.981840
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:29.204183
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:49.209698
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0._fact_class
    var_1 = open_b_s_d_virtual_collector_0._platform
    assert isinstance(var_0, OpenBSDVirtual)
    assert isinstance(var_1, str)
    var_0 = open_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:20:52.400703
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:20:54.952363
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 3651
    int_4 = 4705
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_4, int_0)


# Generated at 2022-06-25 01:21:00.131949
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    int_0 = open_b_s_d_virtual_collector_0._fact_class._vendor_re_1

    int_1 = open_b_s_d_virtual_collector_0._fact_class._virt_vendor_count
    open_b_s_d_virtual_collector_0._get_virtual_facts()
    open_b_s_d_virtual_collector_0._sanitize_facts()


# Generated at 2022-06-25 01:21:03.782749
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 3651
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)
    var_0 = open_b_s_d_virtual_collector_0.get_all_facts()

# Generated at 2022-06-25 01:21:05.871708
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0._platform


# Generated at 2022-06-25 01:21:08.374725
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

    assert 'virtualization_role' in var_0

# Generated at 2022-06-25 01:21:12.771190
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    try:
        open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    except:
        raise
    else:
        pass
    finally:
        pass


# Generated at 2022-06-25 01:21:14.745033
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 10356
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)
    assert open_b_s_d_virtual_collector_0 is not None

# Generated at 2022-06-25 01:21:18.414496
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 4782
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # assert var_0.keys() == frozenset({'virtualization_tech_host', 'virtualization_tech_guest', 'virtualization_role', 'virtualization_type'})



# Generated at 2022-06-25 01:21:48.097604
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:21:54.253621
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-25 01:21:59.570815
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 3651
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)
    var_0 = open_b_s_d_virtual_collector_0._fact_class
    var_1 = open_b_s_d_virtual_collector_0._platform

test_case_0()
#test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:01.095441
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert 0 == 0

# Generated at 2022-06-25 01:22:05.043147
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:22:11.742563
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == 'host', "assertion error"
    assert var_0['virtualization_tech_host'] == set(['vmm']), "assertion error"
    assert var_0['virtualization_type'] == 'vmm', "assertion error"
    assert var_0['virtualization_tech_guest'] == set([]), "assertion error"



# Generated at 2022-06-25 01:22:18.367658
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0._platform
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
    var_1 = open_b_s_d_virtual_collector_1._fact_class
    var_2 = open_b_s_d_virtual_collector_1._fact_class()

# Generated at 2022-06-25 01:22:25.252646
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 3651
    openbsd_virtualcollector_0 = OpenBSDVirtualCollector(int_0)
    print(openbsd_virtualcollector_0)

if __name__ == "__main__":
    test_case_0()
    # Test Case of class constructor
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:29.577086
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(path='/proc')
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:22:31.488049
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:27.288631
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    print("\n")

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:28.876331
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Instance method get_virtual_facts
    test_case_0()


# Generated at 2022-06-25 01:23:34.204327
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
  var_0 = open_b_s_d_virtual_collector_0.get_all_facts()

# Generated at 2022-06-25 01:23:38.160713
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test for constructor
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:41.464509
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 01:23:43.291268
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 3651
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)


# Generated at 2022-06-25 01:23:44.997754
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_0 = 3651
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_0)


# Generated at 2022-06-25 01:23:48.002793
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:49.865237
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3661
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:51.430068
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    int_1 = 3651
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(int_1)


# Generated at 2022-06-25 01:26:13.624661
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 1767
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:26:21.782981
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 != None
    assert isinstance(var_0, dict)
    assert len(var_0) == 6
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_product' in var_0
    assert 'virtualization_vendor' in var_0

# Generated at 2022-06-25 01:26:28.918020
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o_p_e_n_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert o_p_e_n_b_s_d_virtual_collector_0._fact_class.DMESG_BOOT == '/var/run/dmesg.boot'
    assert o_p_e_n_b_s_d_virtual_collector_0._fact_class.platform == 'OpenBSD'
    assert o_p_e_n_b_s_d_virtual_collector_0._platform == 'OpenBSD'

# Generated at 2022-06-25 01:26:34.376629
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    print('Method get_virtual_facts in class OpenBSDVirtual')
    int_0 = 3651
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    assert re.match('^en[0-9]$', var_1['virtualization_tech'], re.M | re.I)
    assert re.match('^en[0-9]$', var_1['virtualization_tech_guest'], re.M | re.I)
    assert re.match('^en[0-9]$', var_1['virtualization_tech_host'], re.M | re.I)

test_case_0()
test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:26:35.912189
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0._fact_class
    assert var_0 == OpenBSDVirtual


# Generated at 2022-06-25 01:26:37.068854
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    return

# Generated at 2022-06-25 01:26:37.826497
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:26:45.370401
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 2512
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # assert that the method produces the expected output
    assert var_0 == {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmm',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {
            'vmm',
        },
    }

# Generated at 2022-06-25 01:26:52.876223
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    sys_platform_0 = 'OpenBSD'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(sys_platform_0)
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD' # protected member _platform of class OpenBSDVirtualCollector
    int_0 = 1
    open_b_s_d_virtual_0 = open_b_s_d_virtual_collector_0._get_fact_class(int_0)
    assert open_b_s_d_virtual_0._platform == 'OpenBSD' # protected member _platform of class OpenBSDVirtual


# Generated at 2022-06-25 01:26:55.129563
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    int_0 = 6244
    open_b_s_d_virtual_0 = OpenBSDVirtual(int_0)
    assert open_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }