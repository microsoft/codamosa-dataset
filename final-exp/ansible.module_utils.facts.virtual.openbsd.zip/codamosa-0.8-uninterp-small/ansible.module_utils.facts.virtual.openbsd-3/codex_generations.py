

# Generated at 2022-06-25 01:18:13.146297
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()

    facts = open_b_s_d_virtual.get_virtual_facts()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_product' in facts
    assert 'virtualization_vendor' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-25 01:18:14.886096
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    result = open_b_s_d_virtual.get_virtual_facts()
    assert result['virtualization_role'] != ''
    assert result['virtualization_type'] != ''


# Generated at 2022-06-25 01:18:17.310688
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:18.469194
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert callable(OpenBSDVirtual.get_virtual_facts)


# Generated at 2022-06-25 01:18:21.648464
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:33.069855
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test without parameter 'host_sysctl_mapping'
    open_bsd_virtual = OpenBSDVirtual()
    if hasattr(open_bsd_virtual, 'get_virtual_facts'):
        open_bsd_virtual_facts = open_bsd_virtual.get_virtual_facts()
        assert 'virtualization_type' in open_bsd_virtual_facts
        assert 'virtualization_role' in open_bsd_virtual_facts
        assert 'virtualization_tech_guest' in open_bsd_virtual_facts
        assert 'virtualization_tech_host' in open_bsd_virtual_facts

    # Test with parameter 'host_sysctl_mapping'
    open_bsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-25 01:18:41.555228
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Set up test case data
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    # Set up test case data
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    # Assertion message for failure to set up test case.
    assert(open_b_s_d_virtual_0 is not None)

    # Call method get_virtual_facts of class OpenBSDVirtual
    open_b_s_d_virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()

    # Test if method get_virtual_facts of class OpenBSDVirtual is working correctly.
    assert(open_b_s_d_virtual_facts is not None)

# Generated at 2022-06-25 01:18:44.944437
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:48.733948
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Check if sysctl hw.vendor is available and in the right format (non-empty string)
    if not open_b_s_d_virtual_collector_0._sysctl_available('hw.vendor'):
        raise AssertionError()
    if not isinstance(open_b_s_d_virtual_collector_0._sysctl('hw.vendor'), str):
        raise AssertionError()

    # Check if sysctl hw.product is available and in the right format (non-empty string)
    if not open_b_s_d_virtual_collector_0._sysctl_available('hw.product'):
        raise AssertionError()
    if not isinstance(open_b_s_d_virtual_collector_0._sysctl('hw.product'), str):
        raise Assert

# Generated at 2022-06-25 01:18:51.993412
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # This is a generic test in order to have hypervisor, cpu and os facts
    open_b_s_d_virtual_0_obj = OpenBSDVirtual()
    open_b_s_d_virtual_0_obj.get_virtual_facts()

# Generated at 2022-06-25 01:18:58.457652
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual = OpenBSDVirtual()
    assert open_b_s_d_virtual.get_virtual_facts() == {}

# Generated at 2022-06-25 01:19:03.644334
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual({})
    print("# Test get_virtual_facts with arguments:")
    # open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:10.825036
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_technology_guest' in virtual_facts
    assert 'virtualization_technology_host' in virtual_facts

# Generated at 2022-06-25 01:19:14.149077
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:19:18.842409
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()

    assert open_b_s_d_virtual_0.get_virtual_facts() == {u'virtualization_type': u'', u'virtualization_role': u'', u'virtualization_tech_host': set([]), u'virtualization_tech_guest': set([])}

# Generated at 2022-06-25 01:19:28.284424
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()

    # Although get_virtual_facts is declared on Virtual, it will call
    # get_virtual_facts on the derived class anyway
    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-25 01:19:32.741798
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual.get_virtual_facts()
    # Check the facts are as expected
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-25 01:19:35.299462
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector()._fact_class is OpenBSDVirtual
    assert OpenBSDVirtualCollector()._platform == 'OpenBSD'


# Generated at 2022-06-25 01:19:37.755404
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test OpenBSD Virtualization Collector
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()

    open_b_s_d_virtual_collector.get_virtual_facts()

# Generated at 2022-06-25 01:19:41.057758
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:19:49.894930
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # get_virtual_facts is expected to return a dict
    # which is then used to set module.exit_json(ansible_facts=dict(virt=virtual_facts))

    test_0 = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_host': {'vmm'},
        'virtualization_tech_guest': set()
    }

    test_case = OpenBSDVirtual()
    virtual_facts = test_case.get_virtual_facts()
    for key in virtual_facts.keys():
        assert virtual_facts[key] == test_0[key], "get_virtual_facts() returned wrong data for %s : %s" % (key, virtual_facts[key])

# Generated at 2022-06-25 01:19:54.746667
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    open_b_s_d_virtual_facts = open_b_s_d_virtual.get_virtual_facts()
    assert len(open_b_s_d_virtual_facts['virtualization_tech_guest']) > 0
    assert len(open_b_s_d_virtual_facts['virtualization_tech_host']) > 0

# Generated at 2022-06-25 01:19:59.510148
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert isinstance(open_b_s_d_virtual_0, OpenBSDVirtual)
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_role': ''}


# Generated at 2022-06-25 01:20:00.963876
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:20:03.725324
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    method = OpenBSDVirtual.get_virtual_facts
    f_0 = OpenBSDVirtual()
    assert method(f_0) == {'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_role': ''}


# Generated at 2022-06-25 01:20:07.228915
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:08.311935
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # ToDo: Unit test OpenBSDVirtual.get_virtual_facts
    return

# Generated at 2022-06-25 01:20:09.432886
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_1._platform == 'OpenBSD'


# Generated at 2022-06-25 01:20:13.392531
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual({}).get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-25 01:20:23.696239
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-25 01:20:37.789245
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_role': 'host', 'virtualization_type': 'vmm', 'virtualization_tech_host': {'vmm'}, 'virtualization_tech_guest': set()}



# Generated at 2022-06-25 01:20:40.495002
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    bytes_0 = b'\xe8\xe7\xb3\xee\x1c\xb8\x9f'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0, bytes_0)

# Generated at 2022-06-25 01:20:49.701752
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'\xc1\xaa\xad\xbd\xf7\x22\x84\xe28'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    assert open_b_s_d_virtual_0.virtualization_role == ''
    assert open_b_s_d_virtual_0.virtualization_type == ''
    assert open_b_s_d_virtual_0.virtualization_tech_guest

# Generated at 2022-06-25 01:20:57.423474
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = False
    bytes_0 = b'Jb\xa3\xb7\xd3\x19\xdczL'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:21:04.694964
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'\x18\x8f\xd5\xa9\x1e^\x82\xbcn'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:08.090042
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'Jb\xa3\xb7\xd3\x19\xdczL'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:11.648390
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'Jb\xa3\xb7\xd3\x19\xdczL'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()

test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:21:15.565974
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # test_variable_0 is assigned a value
    bool_0 = False
    bytes_0 = b'\xd5\x1a\x9e\x87'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:17.590840
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    bytes_0 = b'\x05\x84q\x9dA\xf1\xfb'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0, bytes_0)

# Generated at 2022-06-25 01:21:26.719774
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'f\x0f'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_0, bytes_0)
    open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1.get_virtual_facts()
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:21:42.664213
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    try:
        OpenBSDVirtualCollector()
    except Exception as e:
        assert False


# Generated at 2022-06-25 01:21:49.954142
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
  try:
    bool_0 = False
    bytes_0 = b'\xa8\xc8\xfd\xf0\xfd\xa1'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
  except:
    var_0 = None
  assert var_0 == None


# Generated at 2022-06-25 01:21:56.792184
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'\x0f\xe4\x93s\xbd\xdc\x96\x1f\xd3'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_type_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:22:02.304122
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    bytes_0 = b'\x16\x1f\xe8\x01\x0c\x9c\xda\x8d\xf7'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0, bytes_0)
    open_b_s_d_virtual_collector_0.collect()
    open_b_s_d_virtual_collector_0.collect()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:04.939796
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_2 = open_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 01:22:11.181398
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    var_0 = False
    var_1 = b'u\x84\x13\n\xc4\xfc\x9e'
    open_b_s_d_virtual_0 = OpenBSDVirtual(var_0, var_1)
    var_2 = open_b_s_d_virtual_0.get_virtual_facts()

    assert var_2 == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-25 01:22:20.040724
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'Jb\xa3\xb7\xd3\x19\xdczL'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_type' in var_0
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_role' in var_0
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 01:22:28.116046
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b':\xaa\x1f\xcc\x82\xe9\xa8\xb0'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:36.218263
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    bytes_0 = b'Jb\xa3\xb7\xd3\x19\xdczL'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0._fact_class
    var_1 = open_b_s_d_virtual_collector_0._fact_class
    var_2 = open_b_s_d_virtual_collector_0._fact_class


# Generated at 2022-06-25 01:22:38.556162
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'8\x1b\xfa'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:05.583698
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 01:23:10.550198
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    bytes_0 = b'k\x05\x0f\x83\x17\xd2\x80\xaa'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0, bytes_0)

# Generated at 2022-06-25 01:23:19.851209
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'\x8f\xe3\xda\x1b\xef\x93\x0b\x86'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == '', 'virtualization_role should be empty string instead of: ' + var_0['virtualization_role']
    assert var_0['virtualization_tech_host'] == set(), 'virtualization_tech_host should be set() instead of: ' + str(var_0['virtualization_tech_host'])

# Generated at 2022-06-25 01:23:23.905536
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'g\xd8\xaa\xda\xb3\xb5\x8f'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:28.765615
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'a\x87\x0c\x0e\xa6\xfc\xe8\xa1'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:35.967818
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'Jb\xa3\xb7\xd3\x19\xdczL'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    get_virtual_facts_0 = var_0['virtualization_role']
    assert get_virtual_facts_0 == ''


# Generated at 2022-06-25 01:23:42.061848
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    bytes_0 = b'\xd0\xbd\x04\x8b\x89\x9a\xb2\x03>\xfc\xcc\xb5\x04\xe5\x82\xfbp\x04\x1a'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0, bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:44.951056
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    bytes_0 = b'P\xaf\x99\xfd\xa0\x1d\x1c\x0f'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0, bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:49.434314
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'\x13`\x9c\xcd\xef\x89\xbe\xde'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 01:23:52.947605
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'Jb\xa3\xb7\xd3\x19\xdczL'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:25:01.284006
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    bool_1 = False
    bytes_0 = b'\xd4\xed\xda\xe8\x05\x9f\tG\xe4'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    assert isinstance(open_b_s_d_virtual_0.get_virtual_facts(), dict) == True


# Generated at 2022-06-25 01:25:02.955046
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:25:10.058363
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'Jb\xa3\xb7\xd3\x19\xdczL'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 01:25:11.727334
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert (OpenBSDVirtualCollector._fact_class == OpenBSDVirtual)
    assert (OpenBSDVirtualCollector._platform == 'OpenBSD')

# vim: set et sts=4 ts=4 sw=4 cc=80: #

# Generated at 2022-06-25 01:25:15.495326
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    try:
        test_case_0()
    except Exception as err:
        print(err)



# Generated at 2022-06-25 01:25:22.658621
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    bytes_0 = b'\x9c\x19\xaf\xc6'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:24.685865
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    msg = "Incorrect type returned"
    assert isinstance(test_case_0(), dict), msg


# Generated at 2022-06-25 01:25:34.198736
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_1 = True
    bytes_1 = b'\xd7\x81\xec\x90m\xc2\xaa\x9b\xaf\x8bz\xcd'
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_1, bytes_1)
    var_2 = open_b_s_d_virtual_1.get_virtual_facts()
    bool_2 = True
    bytes_2 = b'\x1645\xc8\x8b\x9d\x88\xda\x0c\xba\x88\x1b'
    open_b_s_d_virtual_2 = OpenBSDVirtual(bool_2, bytes_2)
    var_3 = open_b_s_d_virtual_2.get_virtual_facts

# Generated at 2022-06-25 01:25:42.938250
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    set_0 = set()
    set_0.add('bochs')
    set_0.add('vbox')
    set_0.add('vmware')
    bool_0 = False
    bytes_0 = b'Jb\xa3\xb7\xd3\x19\xdczL'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0, bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    var_2 = open_b_s_d_virtual_0.get_virtual_facts()
    var_3 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:49.341238
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    bytes_0 = b'+\xe5\x91\x8f\x9e\xf4\xca\x96\x0f'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0, bytes_0)
