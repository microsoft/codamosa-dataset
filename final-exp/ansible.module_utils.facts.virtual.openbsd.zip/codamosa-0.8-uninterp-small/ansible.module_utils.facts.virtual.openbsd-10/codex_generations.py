

# Generated at 2022-06-25 01:18:19.975714
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_facts = test_openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:18:22.832780
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()
    print(virtual_facts)

# Generated at 2022-06-25 01:18:25.593895
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:28.889298
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert(open_b_s_d_virtual_0.get_virtual_facts()['virtualization_tech_guest'] == ['openbsd'])

# Generated at 2022-06-25 01:18:36.835326
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    setattr(OpenBSDVirtual, 'detect_virt_product', lambda _:
            {'virtualization_tech_guest': set(),
             'virtualization_tech_host': set(),
             'virtualization_type': 'vmm',
             'virtualization_role': 'guest'})
    setattr(OpenBSDVirtual, 'detect_virt_vendor', lambda _:
            {'virtualization_tech_guest': set(),
             'virtualization_tech_host': set(),
             'virtualization_type': '',
             'virtualization_role': ''})
    expected_result = {'virtualization_type': 'vmm',
                       'virtualization_role': 'guest',
                       'virtualization_tech_host': set(),
                       'virtualization_tech_guest': set()}
    # Call OpenBSDVirtual

# Generated at 2022-06-25 01:18:39.638927
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  assert(open_b_s_d_virtual_collector_0._platform)=='OpenBSD'
  assert(open_b_s_d_virtual_collector_0._fact_class)==OpenBSDVirtual


# Generated at 2022-06-25 01:18:45.474138
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_1._fact_class is not None
    assert open_b_s_d_virtual_collector_1._platform is not None


# Generated at 2022-06-25 01:18:48.404558
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    output = open_b_s_d_virtual_0.get_virtual_facts()
    assert output is not None


# Generated at 2022-06-25 01:18:51.198429
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:18:57.535699
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_get_virtual_facts_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_get_virtual_facts_0 = open_b_s_d_virtual_get_virtual_facts_0.get_virtual_facts()

if __name__ == '__main__':
    print (test_OpenBSDVirtual_get_virtual_facts())

# Generated at 2022-06-25 01:19:04.710023
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': '', 'virtualization_product': ''}

# Generated at 2022-06-25 01:19:09.496070
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:19:19.956389
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.virtualization_type = ''
    dict_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_1.virtualization_type = 'vmm'
    dict_1 = open_b_s_d_virtual_1.get_virtual_facts()
    open_b_s_d_virtual_0.virtualization_type = 'vmm'
    dict_2 = open_b_s_d

# Generated at 2022-06-25 01:19:22.614313
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:24.391220
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)


# Generated at 2022-06-25 01:19:28.992661
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:31.005035
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():

    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual

# Generated at 2022-06-25 01:19:35.777187
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    assert type(open_b_s_d_virtual_0) is OpenBSDVirtual


# Generated at 2022-06-25 01:19:42.992538
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_1 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_1)
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual

# Generated at 2022-06-25 01:19:48.294283
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 is not None


# Generated at 2022-06-25 01:20:00.033530
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Unit test setup
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)

    # Unit test execution
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

    # Unit test verification
    # assert: virtualization_type is 'vmm'
    assert var_0['virtualization_type'] == 'vmm'

    # assert: virtualization_role is 'host'
    assert var_0['virtualization_role'] == 'host'

# Generated at 2022-06-25 01:20:00.850888
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert True == False


# Generated at 2022-06-25 01:20:02.432665
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)



# Generated at 2022-06-25 01:20:08.311991
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert (open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual)
    assert (open_b_s_d_virtual_collector_0._platform == 'OpenBSD')


# Generated at 2022-06-25 01:20:12.444243
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
  bool_0 = True
  bool_1 = False
  open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
  open_b_s_d_virtual_1 = OpenBSDVirtual(bool_1)
  var_0 = open_b_s_d_virtual_0.get_virtual_facts()
  var_1 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:20:16.810660
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:23.334916
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_1 = False
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_1)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    try:
        assert var_1 == {'virtualization_tech_host': {'vmm'}, 'virtualization_tech_guest': {'openbsd_virtual'}, 'virtualization_type': 'vmm', 'virtualization_role': 'host'}
    except AssertionError as e:
        var_2 = format(e)
        print(var_2)


# Generated at 2022-06-25 01:20:31.186412
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_host'] == {'vmm'}
    assert var_0['virtualization_type'] == 'vmm'
    assert var_0['virtualization_role'] == 'host'
    assert var_0['virtualization_tech_guest'] == set()



# Generated at 2022-06-25 01:20:37.969472
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtualCollector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    virtualCollector_0._fact_class = open_b_s_d_virtual_0
    bool_1 = False
    assert virtualCollector_0.get_all_facts(bool_1) == None


# Generated at 2022-06-25 01:20:39.880946
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_1 = open_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 01:20:58.093789
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Declaring the current facts dictionary
    # Declaring the expected facts dictionary
    # Create an instance of the OpenBSDVirtual class
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    # Call method get_virtual_facts of the OpenBSDVirtual class
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # Assert the expected versus the actual facts
    # assertEqual(var_0, var_1)



# Generated at 2022-06-25 01:21:01.572737
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Make sure the method is able to run without error.
    test_case_0()

# Generated at 2022-06-25 01:21:06.507173
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:12.961460
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)

    # Call method (with example args) for testing
    # Return value should be of type dict
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 01:21:14.424209
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtualCollector(bool_0)


# Generated at 2022-06-25 01:21:19.779994
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    bool_0 = OpenBSDVirtual.is_virtual_sysctl_loaded()
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:21:22.406770
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:21:32.512408
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Testing different variations of dmesg
    dmesg_boot_0 = list()
    dmesg_boot_0.append('vmm0 at mainbus0: VMX/EPT')
    vmm_result_0 = dict()
    vmm_result_0['virtualization_type'] = 'vmm'
    vmm_result_0['virtualization_role'] = 'host'
    vmm_result_0['virtualization_product'] = ''
    vmm_result_0['virtualization_platform'] = ''
    vmm_result_0['virtualization_tech_guest'] = set([])
    vmm_result_0['virtualization_tech_host'] = set([])
    assert OpenBSDVirtual.get_virtual_facts(dmesg_boot_0) == vmm_result_0

    d

# Generated at 2022-06-25 01:21:33.289700
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert True


# Generated at 2022-06-25 01:21:37.981524
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openb_sd_virtual_collector_0 = OpenBSDVirtualCollector()
    openb_sd_virtual_collector_0.collect()


# Generated at 2022-06-25 01:22:05.958190
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'



# Generated at 2022-06-25 01:22:06.436226
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert True

# Generated at 2022-06-25 01:22:07.539152
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:14.209469
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    method_ret_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert type(method_ret_0) == dict
    assert 'virtualization_type' in method_ret_0.keys()
    assert 'virtualization_tech_guest' in method_ret_0.keys()
    assert 'virtualization_tech_host' in method_ret_0.keys()
    assert 'virtualization_role' in method_ret_0.keys()
    assert 'virtualization_role' in method_ret_0.keys()
    assert 'virtualization_role' in method_ret_0.keys()


# Generated at 2022-06-25 01:22:14.679260
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert True

# Generated at 2022-06-25 01:22:18.137857
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:19.168357
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert True


# Generated at 2022-06-25 01:22:25.141510
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:27.231944
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    assert open_b_s_d_virtual_0.get_virtual_facts() == \
        {"virtualization_role": "", "virtualization_tech_host": set(), "virtualization_tech_guest": set(), "virtualization_type": ""}

# Generated at 2022-06-25 01:22:33.461526
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:28.838145
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # var_0, open_b_s_d_virtual_0
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    print ("test_OpenBSDVirtual_get_virtual_facts :: var_0 = %s" % var_0)

# Generated at 2022-06-25 01:23:33.973370
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

test_OpenBSDVirtualCollector()
test_case_0()

# Generated at 2022-06-25 01:23:43.112917
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.dmesg = '/var/run/dmesg.boot'
    open_b_s_d_virtual_0.dmidecode = 'dmesg'
    open_b_s_d_virtual_0.sysctl = 'dmesg'
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_tech_host': {'vmm'}, 'virtualization_tech_guest': set(), 'virtualization_type': 'vmm'}


if __name__ == "__main__":
    test_case_0()


# Generated at 2022-06-25 01:23:50.269244
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    # get_virtual_facts() return a dict object
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)
    # The dict object contains a value "virtualization_type" of string type
    assert isinstance(var_0["virtualization_type"], str)
    # The dict object contains a value "virtualization_role" of string type
    assert isinstance(var_0["virtualization_role"], str)
    # The dict object contains a value "virtualization_tech_guest" of set type
    assert isinstance(var_0["virtualization_tech_guest"], set)
    # The dict object contains a value "virtual

# Generated at 2022-06-25 01:23:52.779685
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:55.710435
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Input params list for unit test
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)

    # Perform the unit operation
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:23:59.285659
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    var_1 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:24:02.647333
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert not open_b_s_d_virtual_collector_0.virtual

# Generated at 2022-06-25 01:24:09.133337
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    # Test assertions
    # Test if virtual_facts['virtualization_role'] is equal to ''
    assert virtual_facts['virtualization_role'] == ''
    # Test if virtual_facts['virtualization_type'] is equal to ''
    assert virtual_facts['virtualization_type'] == ''
    # Test if virtual_facts['virtualization_tech_host'] is equal to set
    assert virtual_facts['virtualization_tech_host'] == set
    # Test if virtual_facts['virtualization_tech_guest'] is equal to set
    assert virtual_facts['virtualization_tech_guest'] == set

# Generated at 2022-06-25 01:24:10.414190
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)


# Generated at 2022-06-25 01:26:31.494927
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    if var_0 is None:
        print("1")
        assert False
    var_2 = open_b_s_d_virtual_0.get_virtual_facts()
    if var_2['virtualization_type'] is not None:
        print("2")
        assert False
    var_3 = open_b_s_d_virtual_0.get_virtual_facts()
    if var_3['virtualization_role'] is not None:
        print("3")
        assert False

# Generated at 2022-06-25 01:26:39.591337
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': 'vmm', 'virtualization_tech_host': {'vmm'}, 'virtualization_tech_guest': {'vmm'}}


import pytest


# Generated at 2022-06-25 01:26:43.276782
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    open_b_s_d_virtual_0 = OpenBSDVirtual(None)

    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

    assert (var_0 == {})

# Generated at 2022-06-25 01:26:44.831865
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    test_case_0()

# Generated at 2022-06-25 01:26:48.986582
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_type'] == 'vmm'
    assert var_0['virtualization_role'] == 'host'



# Generated at 2022-06-25 01:26:49.371516
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:26:52.736464
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0


# Generated at 2022-06-25 01:26:56.740359
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


if __name__ == '__main__':
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:27:00.694440
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:27:02.822453
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    assert (var_1['virtualization_role'] == 'guest')
    assert (var_1['virtualization_type'] == 'vbox')