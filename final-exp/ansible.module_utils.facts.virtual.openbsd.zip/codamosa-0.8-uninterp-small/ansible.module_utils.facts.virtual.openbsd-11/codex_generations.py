

# Generated at 2022-06-25 01:18:16.048002
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'

# Generated at 2022-06-25 01:18:18.164730
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:29.977351
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()  # Test idempotent function
    open_b_s_d_virtual_0 = OpenBSDVirtual()  # Test idempotent function
    open_b_s_d_virtual_0 = OpenBSDVirtual()  # Test idempotent function
    open_b_s_d_virtual_0 = OpenBSDVirtual()  # Test idempotent function
    open_b_s_d_virtual_0 = OpenBSDVirtual()  # Test idempotent function
    open_b_s_d_virtual_0 = OpenBSDVirtual()  # Test idempotent function
    open_b_s_d_virtual_0 = OpenBSDVirtual()  # Test idempotent function
    open_b_s_d_virtual_0 = OpenBSDVirtual()

# Generated at 2022-06-25 01:18:34.693737
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector.platform == 'OpenBSD'



# Generated at 2022-06-25 01:18:37.275257
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert isinstance(open_b_s_d_virtual_collector_0, OpenBSDVirtualCollector)


# Generated at 2022-06-25 01:18:45.039827
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts_data_0 = {
        'virtualization_role': 'host',
        'virtualization_type': 'vmm',
        'virtualization_tech_guest': '',
        'virtualization_tech_host': 'vmm',
    }

    virtual_facts_data_1 = {
        'virtualization_role': 'guest',
        'virtualization_type': 'virtio',
        'virtualization_tech_guest': 'virtio',
        'virtualization_tech_host': '',
    }

    virtual_facts_data_2 = {
        'virtualization_role': 'guest',
        'virtualization_type': 'qemu',
        'virtualization_tech_guest': 'hvm',
        'virtualization_tech_host': '',
    }


# Generated at 2022-06-25 01:18:47.231359
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:53.181323
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = Virtual(distribution='OpenBSD').get_virtual_facts()

    assert virtual_facts['virtualization_type'] in ['', 'vmm', 'OpenBSD', 'xen']
    assert virtual_facts['virtualization_role'] in ['', 'host', 'guest']
    assert virtual_facts['virtualization_system'] in ['', 'xen']
    assert virtual_facts['virtualization_product'] in ['', 'OpenBSD', 'xen']

# Generated at 2022-06-25 01:18:55.701220
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:58.418239
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:10.988750
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual_0 = OpenBSDVirtual()
    virtual_facts = OpenBSDVirtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:19:12.048833
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), OpenBSDVirtualCollector)


# Generated at 2022-06-25 01:19:17.755314
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:21.356504
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = open_b_s_d_virtual_collector_0.get_virtual_facts()

    assert open_b_s_d_virtual_0['virtualization_type'] == ''

# Generated at 2022-06-25 01:19:24.701239
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:28.438313
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:19:33.698908
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    expected_ans = dict(
        virtualization_type='vmm',
        virtualization_role='guest',
        virtualization_tech_guest=set(['vmm']),
        virtualization_tech_host=set(['vmm'])
    )
    test_ans = open_b_s_d_virtual.get_virtual_facts()
    for key in expected_ans:
        assert expected_ans[key] == test_ans[key]

# Generated at 2022-06-25 01:19:36.164957
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:38.099099
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:43.995109
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual({},{},{},{},{})
    
    assert open_b_s_d_virtual_0.get_virtual_facts() == ({'virtualization_type': '', 'virtualization_role': ''}, {'virtualization_tech_guest': (), 'virtualization_tech_host': ()})

# Generated at 2022-06-25 01:19:57.865595
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert getattr(OpenBSDVirtualCollector, '_platform') == 'OpenBSD'


# Generated at 2022-06-25 01:20:04.949814
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # No virtualization technology detected
    virtual_facts_no_vmm = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_technologies_guest': set(),
        'virtualization_technologies_host': set()
    }

    # Virtualization host
    virtual_facts_host_with_vmm = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_technologies_guest': set(),
        'virtualization_technologies_host': {'vmm'}
    }

    open_bsd_virtual = OpenBSDVirtual()
    open_bsd_virtual.facts['product'] = 'OpenBSD'
    open_bsd_virtual.facts['vendor'] = 'OpenBSD'

    #

# Generated at 2022-06-25 01:20:06.325977
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:20:08.928947
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class.platform == 'OpenBSD'


# Generated at 2022-06-25 01:20:12.510498
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == ({'virtualization_role': '', 'virtualization_type': '', 'virtualization_system': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}, None)

# Generated at 2022-06-25 01:20:14.366005
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts_dict_0 = OpenBSDVirtual.get_virtual_facts()
    assert virtual_facts_dict_0['virtualization_type'] == ''

# Generated at 2022-06-25 01:20:17.808879
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:20:18.349143
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:20:19.841959
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:20:21.811531
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:39.161035
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    str_0 = '8`d;\'\x125\t\n\r'
    open_b_s_d_virtual_0 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:20:48.848439
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    dmesg_boot = get_file_content(OpenBSDVirtual.DMESG_BOOT)
    for line in dmesg_boot.splitlines():
        match = re.match('^vmm0 at mainbus0: (SVM/RVI|VMX/EPT)$', line)
        if match:
            bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
            open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
            result = open_b_s_d_virtual_0.get_virtual_facts()
            assert isinstance(result, dict)

# Generated at 2022-06-25 01:20:59.176290
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    dict_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    bool_0 = False
    open_b_s_d_virtual_2 = OpenBSDVirtual(bytes_0, bool_0)
    dict_1 = open_b_s

# Generated at 2022-06-25 01:21:08.247118
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_collector_1.add_default_facts(str_0)

    open_b_s_d_virtual_0 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, open_b_s_d_virtual_collector_1.default_facts)
    # TODO: The values of actual and expected are too different
    # assert actual == expected

# Generated at 2022-06-25 01:21:12.786574
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'[\xb7\xdb\x0e\x00\x99\xf8\xea\x1a'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:14.040334
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:21:18.947665
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_2 = OpenBSDVirtual()
    assert open_b_s_d_virtual_2.get_virtual_facts() != None


# Generated at 2022-06-25 01:21:30.112639
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    str_0 = '`el\rQjwgdnJPM8R'
    bool_0 = False
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0, bool_0)
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    pass_ = True

# Generated at 2022-06-25 01:21:35.999272
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, "")
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:36.742146
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    pass


# Generated at 2022-06-25 01:22:04.612127
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert True


# Generated at 2022-06-25 01:22:10.912925
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    str_0 = '`el\rQjwgdnJPM8R'
    bool_0 = True
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, str_0, bool_0)
    open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:22:20.040378
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x12\x19\xad\x92\x94'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    str_0 = '\t'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    bool_0 = True
    open_b_s_d_virtual_2 = OpenBSDVirtual(bytes_0, bool_0)
    var_0 = open_b_s_d_virtual_2.get_virtual_facts()

# Generated at 2022-06-25 01:22:26.841873
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:29.168381
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  # Instantiate the class.
  openBSDVirtualCollector = OpenBSDVirtualCollector()
  # Return the name of the class or an empty string if undefined.
  test = openBSDVirtualCollector.getClassName()
  assert test == 'OpenBSDVirtualCollector'


# Generated at 2022-06-25 01:22:32.232487
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert len(var_0) == 5


# Generated at 2022-06-25 01:22:34.970730
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bytes_0 = open_b_s_d_virtual_collector_0.get_host_uuid()
    assert bytes_0 is not None

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:43.754506
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    bool_0 = False
    open_b_s_d_virtual_2 = OpenBSDVirtual(bytes_0, bool_0)
    int_0 = 0
    open_

# Generated at 2022-06-25 01:22:51.006982
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_2 = OpenBSDVirtual()
    expected = {
        'virtualization_role': 'host',
        'virtualization_type': 'vmm',
        'virtualization_tech_host': {'vmm'},
        'virtualization_tech_guest': set()
    }
    assert open_b_s_d_virtual_2.get_virtual_facts() == expected

# Generated at 2022-06-25 01:23:00.114072
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    bool_0 = False
    open_b_s_d_virtual_2 = OpenBSDVirtual(bytes_0, bool_0)


# Generated at 2022-06-25 01:24:09.245386
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert not None


# Generated at 2022-06-25 01:24:10.758764
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
  assert open_b_s_d_virtual_collector_0 != None


# Generated at 2022-06-25 01:24:14.550764
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0, True)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}

# Generated at 2022-06-25 01:24:19.083853
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd1\xcd\x0f\xed\xe4\x0b\x00'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:22.785535
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x94\x07\xb1\xd9\x7fP\xf0\xc7'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:24.765063
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:24:31.006440
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_0, str_0)
    bool_0 = False
    open_b_s_d_virtual_2 = OpenBSDVirtual(bytes_0, bool_0)

# Generated at 2022-06-25 01:24:40.607081
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    print('Testing OpenBSDVirtual.get_virtual_facts')
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': 'OpenBSD', 'virtualization_role': 'guest'}
    bytes_1 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_1 = OpenBSDVirtual(bytes_1)

# Generated at 2022-06-25 01:24:45.905007
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # ...
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(str_0)
    # ...


# Generated at 2022-06-25 01:24:53.777300
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    bool_0 = False
    open_b_s_d_virtual_2 = OpenBSDVirtual(bytes_0, bool_0)


# Generated at 2022-06-25 01:27:36.783094
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    bool_0 = False
    open_b_s_d_virtual_2 = OpenBSDVirtual(bytes_0, bool_0)


# Generated at 2022-06-25 01:27:46.438533
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    open_b_s_d_virtual_2 = OpenBSDVirtual(bytes_0, None)
    var_1 = open_b_s_d_virtual_2.get_

# Generated at 2022-06-25 01:27:52.965754
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    open_b_s_d_virtual_1 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    bool_0 = False
    open_b_s_d_virtual_2 = OpenBSDVirtual(bytes_0, bool_0)
    open_b_s_d_virtual_2.get_virtual_facts()

# Generated at 2022-06-25 01:27:55.112881
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:28:00.298126
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    open_b_s_d_virtual_collector_3 = OpenBSDVirtualCollector()
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_4 = OpenBSDVirtual(bytes_0)
    var_1 = open_b_s_d_virtual_4.get_virtual_facts()
    open_b_s_d_virtual_5 = OpenBSDVirtual(open_b_s_d_virtual_collector_3, str_0)
    bool_0 = False
    open_b_s_d_virtual_6 = OpenBSDVirtual(bytes_0, bool_0)


# Generated at 2022-06-25 01:28:05.087664
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'T\xe1\x04\x91\xfc\x94\xfd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0, bool())
    # Test if the values match
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in var_0
    # Test if the values match
    assert set() == set(var_0.get('virtualization_type'))


# Generated at 2022-06-25 01:28:12.340975
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xd7\x05"0\xd4\xfc\xe7\xf2'
    str_0 = '`el\rQjwgdnJPM8R'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual(open_b_s_d_virtual_collector_0, str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1 = OpenBSDVirtual(bytes_0)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
