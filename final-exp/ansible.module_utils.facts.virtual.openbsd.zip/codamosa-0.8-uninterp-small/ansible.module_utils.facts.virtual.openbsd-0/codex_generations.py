

# Generated at 2022-06-25 01:18:15.778935
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    virtual = open_b_s_d_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:17.927465
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    str_0 = 'AtY6/8kr'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:18:24.665698
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'AtY6/8kr'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    dict_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # Verify method get_virtual_facts of class OpenBSDVirtual is called with parameters
    # and return correctly.
    assert dict_0 == {}

# Generated at 2022-06-25 01:18:32.915100
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    input0 = get_fake_input()
    assert isinstance(input0, dict)

    open_b_s_d_virtual_0 = OpenBSDVirtual()
    result_0 = open_b_s_d_virtual_0.get_virtual_facts()

    assert isinstance(result_0, dict)
    assert 'virtualization_type' in result_0
    assert 'virtualization_role' in result_0
    assert 'virtualization_tech_guest' in result_0
    assert 'virtualization_tech_host' in result_0


# Generated at 2022-06-25 01:18:41.461518
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = '\n'
    str_1 = 'qnTNC1'
    str_2 = '\n'
    str_3 = '\n'
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.set_dmesg_boot(str_0)
    open_b_s_d_virtual_0.set_sysctl('hw.vendor', str_1)
    open_b_s_d_virtual_0.set_sysctl('hw.product', str_2)
    open_b_s_d_virtual_0.set_sysctl('machdep.hypervisor_vendor', str_3)
    open_b_s_d_virtual_0.get_virtual_facts()

# Unit test

# Generated at 2022-06-25 01:18:48.189033
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Assigning parameters
    str_0 = 'AtY6/8kr'
    # Return value
    dict_0 = {}
    # Executing method
    result = OpenBSDVirtual.get_virtual_facts(str_0)
    # Checking result is not empty
    assert len(result) != 0
    # Checking result
    assert result == dict_0
    # Check that function may return a dictionary.
    assert isinstance(result, dict)


# Generated at 2022-06-25 01:18:50.693507
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:57.836664
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    ret = open_b_s_d_virtual.get_virtual_facts()
    assert ret['virtualization_type'] == ''
    assert ret['virtualization_role'] == ''
    assert ret['virtualization_tech_host'] == set(['vmm'])
    assert ret['virtualization_tech_guest'] == set(['openbsd'])
    assert ret['virtualization_product'] == 'OpenBSD'

# Generated at 2022-06-25 01:19:03.403470
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = dict()
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:05.048358
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    str_0 = 'AtY6/8kr'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:19:10.377944
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._platform == "OpenBSD"



# Generated at 2022-06-25 01:19:13.346497
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), OpenBSDVirtualCollector)

# Generated at 2022-06-25 01:19:16.709324
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual({u'kernel': u'OpenBSD', u'virtualization_type': u'vmm', u'virtualization_role': u'guest'})
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:24.996433
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    # Case 0: Method exists
    assert open_b_s_d_virtual_0 is not None
    # Case 1: None type
    open_b_s_d_virtual_0.ansible_facts = None
    open_b_s_d_virtual_0.get_virtual_facts()
    # Case 2: Non type
    open_b_s_d_virtual_0.ansible_facts = 'BOGUS'
    open_b_s_d_virtual_0.get_virtual_facts()
    # Case 3: Empty dictionary type
    open_b_s_d_virtual_0.ansible_facts = {}
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:28.861130
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:30.178237
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual({})


# Generated at 2022-06-25 01:19:35.036732
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(open_b_s_d_virtual_collector_0, OpenBSDVirtualCollector)


# Generated at 2022-06-25 01:19:38.754955
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtualCollector().get_virtual_facts()
    assert open_b_s_d_virtual_0['virtualization_type'] == ''

# Generated at 2022-06-25 01:19:41.497907
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:48.207928
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:19:58.090298
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.populate_facts()
    result = open_b_s_d_virtual_0.get_virtual_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''

# Generated at 2022-06-25 01:20:00.192154
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    assert {} == open_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:20:07.275948
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-25 01:20:09.537344
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert not open_b_s_d_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:13.417686
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}


# Generated at 2022-06-25 01:20:19.635675
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    assert open_b_s_d_virtual.get_virtual_facts() == {'virtualization_type': '',
                                                      'virtualization_role': '',
                                                      'virtualization_tech_guest': set(),
                                                      'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:20:22.216036
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:26.241071
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:20:32.136027
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
  assert open_b_s_d_virtual_collector._fact_class == OpenBSDVirtual
  assert open_b_s_d_virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-25 01:20:37.335995
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector._fact_class is not None
    assert open_b_s_d_virtual_collector._platform is not None



# Generated at 2022-06-25 01:20:59.250068
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual(module=None)
    virtual_facts = open_b_s_d_virtual.get_virtual_facts()
    if not virtual_facts['virtualization_role']:
        assert 'virtualization_role' not in virtual_facts
    else:
        assert virtual_facts['virtualization_role'] in ('guest', 'host')
    if not virtual_facts['virtualization_type']:
        assert 'virtualization_type' not in virtual_facts

# Generated at 2022-06-25 01:21:08.035069
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual_obj = OpenBSDVirtual()
    virtual_facts = OpenBSDVirtual_obj.get_virtual_facts()
    assert type(virtual_facts) == dict
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'virtualization_tech_guest' in virtual_facts
    assert type(virtual_facts['virtualization_tech_guest']) == set
    assert 'virtualization_tech_host' in virtual_facts
    assert type(virtual_facts['virtualization_tech_host']) == set
    assert 'vmm' in virtual_facts['virtualization_tech_guest']
    assert 'vmm' in virtual_

# Generated at 2022-06-25 01:21:12.215850
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fixture = OpenBSDVirtualCollector()
    assert fixture._fact_class == OpenBSDVirtual
    assert fixture._platform == 'OpenBSD'


# Generated at 2022-06-25 01:21:13.471210
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:21:22.780093
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Setup
    open_b_s_d_virtual_0 = OpenBSDVirtual()

    open_b_s_d_virtual_0._populate_from_facts()
    open_b_s_d_virtual_0._populate_from_sysctl()
    open_b_s_d_virtual_0._populate_dmesg_boot()
    expected = {
        "virtualization_type": "",
        "virtualization_role": "",
        "virtualization_tech_guest": set(),
        "virtualization_tech_host": set(),
        "virtualization_product_guest": set(),
        "virtualization_product_host": set()
    }

    # Test
    actual = open_b_s_d_virtual_0.get_virtual_facts()

    # Assert

# Generated at 2022-06-25 01:21:28.086584
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_obj = OpenBSDVirtual()
    virtual_facts = open_b_s_d_virtual_obj.get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == '')
    assert(virtual_facts['virtualization_role'] == '')
    assert('virtualization_tech_guest' in virtual_facts)
    assert('virtualization_tech_host' in virtual_facts)



# Generated at 2022-06-25 01:21:35.560548
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(module=None)
    result = open_b_s_d_virtual_0.get_virtual_facts()
    assert result == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-25 01:21:36.637633
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:21:37.376906
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert True



# Generated at 2022-06-25 01:21:41.900093
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

    assert open_b_s_d_virtual_collector_0.platform == "OpenBSD"
    assert open_b_s_d_virtual_collector_0.fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0.fact_subclasses == set([])
    assert open_b_s_d_virtual_collector_0.additional_subclasses == set([])


# Generated at 2022-06-25 01:21:57.768283
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'lX)D'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:00.554677
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    str_0 = 'AtY6/kr'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(str_0)
    return open_b_s_d_virtual_collector_0

# Generated at 2022-06-25 01:22:08.144685
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'P&gt;Imv'
    str_1 = 'AtY6/kr'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_1)
    str_2 = 'R&amp;vT)'
    str_3 = 'hw.vendor'
    var_0 = open_b_s_d_virtual_0.detect_virt_vendor(str_3)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    assert str_2 in var_1
    assert str_0 not in var_1


# Generated at 2022-06-25 01:22:11.115522
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:22:14.231286
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:22:17.722007
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'AtY6/kr'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:26.008267
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'AtY6/kr'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    open_b_s_d_virtual_0.virtualization_type = 'AtY6/kr'
    open_b_s_d_virtual_0.hw = {}
    assert open_b_s_d_virtual_0.get_virtual_facts() is not False


# Generated at 2022-06-25 01:22:29.034653
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    print("Testing constructor of OpenBSDVirtualCollector.")
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector.fact_class == OpenBSDVirtual

# Generated at 2022-06-25 01:22:32.804159
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'i39H/AB'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    res_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert res_0 == {'virtualization_tech_host': set(['vmm']), 'virtualization_role': 'host', 'virtualization_tech_guest': set(), 'virtualization_type': 'vmm'}



# Generated at 2022-06-25 01:22:33.525427
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:00.466510
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # these tests are not implemented
    pass

# Generated at 2022-06-25 01:23:09.427266
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    _fact_class_var = OpenBSDVirtual
    _platform_var = 'OpenBSD'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(_fact_class_var, _platform_var)
    # check if the value of variable _fact_class is the same as variable _fact_class
    assert(open_b_s_d_virtual_collector_0._fact_class == _fact_class_var)
    # check if the value of variable _platform is the same as variable _platform_var
    assert(open_b_s_d_virtual_collector_0._platform == _platform_var)

test_case_0()

# Generated at 2022-06-25 01:23:12.144205
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'AtY6/kr'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:23:19.066297
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_1 = 'iZDlNr'
    open_b_s_d_virtual_1 = OpenBSDVirtual(str_1)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    assert var_1 == {}
    assert open_b_s_d_virtual_1.virtualization_type == ''
    assert open_b_s_d_virtual_1.virtualization_role == ''


# Generated at 2022-06-25 01:23:21.154070
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert True

# Generated at 2022-06-25 01:23:22.769327
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:26.173493
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    var_0 = OpenBSDVirtualCollector()

# Unit tests for functions in class OpenBSDVirtualCollector

# Generated at 2022-06-25 01:23:26.968315
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    pass



################################################################################


# Generated at 2022-06-25 01:23:30.523196
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_1 = '/etc/hostname'
    open_b_s_d_virtual_1 = OpenBSDVirtual(str_1)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    assert var_1['virtualization_type'] == ''
    assert var_1['virtualization_role'] == ''



# Generated at 2022-06-25 01:23:34.121376
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    str_0 = 'AtY6/kr'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(str_0)

# Generated at 2022-06-25 01:24:52.514757
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'AtY6/kr'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert 'hw.product' in var_0
    assert 'hw.vendor' in var_0
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_system' in var_0
    assert 'virtualization_uuid' in var_0


# Generated at 2022-06-25 01:24:55.568938
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'AtY6/kr'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


test_case_0()

# Generated at 2022-06-25 01:24:59.313452
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'AtY6/kr'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 01:25:02.410879
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'AtY6/kr'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:25:07.158718
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:25:10.276020
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    str_0 = 'AtY6/kr'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(str_0)

# Generated at 2022-06-25 01:25:11.769271
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    str_0 = 'uxU|p6'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(str_0)

# Generated at 2022-06-25 01:25:22.249027
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    _0 = '/var/run/dmesg.boot'
    _1 = ['OpenBSD']
    _2 = []
    _3 = ['OpenBSD']
    _4 = []
    _5 = []
    _6 = []
    _7 = {'virtualization_tech_host': _5, 'virtualization_tech_guest': _6, 'virtualization_type': '', 'virtualization_role': ''}
    _8 = ('hw.product', 'OpenBSD', 'OpenBSD', None, None)
    _9 = {'virtualization_tech_guest': _2, 'virtualization_tech_host': _3}
    _10 = {'virtualization_tech_guest': _4, 'virtualization_tech_host': _1}

# Generated at 2022-06-25 01:25:27.596679
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'P5y'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:29.846275
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    str_0 = 'TZ0m0'
    open_b_s_d_virtual_0 = OpenBSDVirtual(str_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
