

# Generated at 2022-06-25 01:18:16.048291
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    with pytest.raises(OrderDict):
        assert OpenBSDVirtual.get_virtual_facts() == {'virtualization_type': 'openbsd', 'virtualization_role': 'guest'}

# Generated at 2022-06-25 01:18:20.183974
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    openbsd_virtual_connection_0 = OpenBSDVirtual()
    openbsd_virtual_virtual_facts_0 = openbsd_virtual_connection_0.get_virtual_facts()

    assert openbsd_virtual_virtual_facts_0['virtualization_type'] != ''
    assert openbsd_virtual_virtual_facts_0['virtualization_role'] != ''



# Generated at 2022-06-25 01:18:28.419976
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_bsd = OpenBSDVirtual()
    open_bsd._sysctl_virtualization_facts = {
        'hw.vendor': 'QEMU',
        'hw.product': 'Standard PC (i440FX + PIIX, 1996)',
    }
    virtual_facts = open_bsd.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'xen'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'qemu' in virtual_facts['virtualization_tech_guest']



# Generated at 2022-06-25 01:18:30.052299
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:37.157791
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:18:42.776499
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set()}



# Generated at 2022-06-25 01:18:45.691199
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:51.992601
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    fixture_OpenBSDVirtual_get_virtual_facts_0 = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_host': set(['vmm']),
        'virtualization_tech_guest': set(['vmm']),
    }

    virtual_0 = OpenBSDVirtual({})
    assert virtual_0.get_virtual_facts() == fixture_OpenBSDVirtual_get_virtual_facts_0



# Generated at 2022-06-25 01:18:54.634877
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual('OpenBSD')
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:59.766529
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    o_b_v_0 = OpenBSDVirtual()
    # Test get_virtual_facts
    assert o_b_v_0.get_virtual_facts() == {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {
            'vmm'
        }
    }

# Generated at 2022-06-25 01:19:07.772837
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:19:08.686576
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:19:14.075454
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    # Check attribute _fact_class of class OpenBSDVirtualCollector
    assert open_b_s_d_virtual_collector_0._fact_class is OpenBSDVirtual


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 01:19:22.655937
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert isinstance(virtual_facts['virtualization_role'], str)
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)
    assert isinstance(virtual_facts['virtualization_guest_os_type'], str)
    assert isinstance(virtual_facts['virtualization_product_name'], str)
    assert isinstance(virtual_facts['virtualization_product_version'], str)
    assert isinstance(virtual_facts['virtualization_product_serial'], str)

# Generated at 2022-06-25 01:19:24.172275
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:19:28.243864
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(open_b_s_d_virtual_collector._fact_class, OpenBSDVirtual)
    assert open_b_s_d_virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-25 01:19:38.477687
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
  c = OpenBSDVirtual()
  c.is_xen = False
  c.is_kvm = False
  c.is_vserver = False
  c.is_openvz = False
  c.is_vz = False
  c.is_hyperv = False
  c.is_zlinux = False
  c.is_lxc = False
  c.is_uml = False
  c.is_ovirt = False
  c.is_vmware = False
  c.is_docker = False
  c.is_parallels = False
  c.is_jail = False
  c.is_gce = False
  c.is_azure = False
  c.is_kubevirt = False
  c.is_openstack = False
  c.is_ovm = False

# Generated at 2022-06-25 01:19:46.605446
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == {
        "virtualization_role": "",
        "virtualization_type": "",
        "virtualization_tech_guest": set([]),
        "virtualization_tech_host": set([])
    }, "Return value of get_virtual_facts() should be a dict of the expected values"


# Generated at 2022-06-25 01:19:52.005836
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    try:
        assert open_b_s_d_virtual_collector_0
    except NameError:
        open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    else:
        raise Exception('Failed to create an instance of ' +
                        'OpenBSDVirtualCollector')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:19:53.341648
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:00.797524
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:03.156098
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    open_b_s_d_virtual.collect()

    # No need to test the rest of this function, as it is already covered by
    # the tests for the other mixins/classes.

# Generated at 2022-06-25 01:20:08.681300
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Make it possible to import modules
    import pathlib
    sys.path.append(str(pathlib.Path('/usr/local/lib/')))
    # Set up test class OpenBSDVirtual
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:11.722523
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    if not OpenBSDVirtualCollector._platform == 'OpenBSD':
        raise AssertionError("Class constructor of class OpenBSDVirtualCollector wrong")
    if not OpenBSDVirtualCollector._fact_class == OpenBSDVirtual:
        raise AssertionError("Class constructor of class OpenBSDVirtualCollector wrong")


# Generated at 2022-06-25 01:20:12.477303
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-25 01:20:14.364763
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:19.803284
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual(open_b_s_d_virtual_collector_0)
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:22.359748
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts(['virtualization_type'])


# Generated at 2022-06-25 01:20:32.209645
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.detect_virt_product = lambda x: {'virtualization_type': 'VirtualBox'}
    openbsd_virtual.detect_virt_vendor = lambda x: {'virtualization_type': 'VMware'}

# Generated at 2022-06-25 01:20:36.103006
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:45.135819
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:45.531381
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass


# Generated at 2022-06-25 01:20:48.199210
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0._fact_class()
    var_0 = open_b_s_d_virtual_collector_0._platform()


# Generated at 2022-06-25 01:20:54.902752
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:20:57.488565
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)


# Generated at 2022-06-25 01:21:04.154854
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:21:05.428606
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:21:10.603804
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector(bool_0)
    assert open_b_s_d_virtual_collector._platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector.collect() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_facts': {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}}


# Generated at 2022-06-25 01:21:13.071162
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_1 = False
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_1)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:21:18.743262
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:30.769663
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_OpenBSDVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 01:21:34.529634
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:36.483108
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:21:37.954096
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    try:
        test_case_0()
    except Exception:
        pass
    else:
        raise Exception

# Generated at 2022-06-25 01:21:43.240774
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 01:21:44.427141
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:21:49.540521
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    # Check whether constructor function returns an instance of class OpenBSDVirtualCollector
    assert isinstance(OpenBSDVirtualCollector(bool_0), OpenBSDVirtualCollector) == True


# Generated at 2022-06-25 01:21:52.195616
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)
    var_0 = open_b_s_d_virtual_collector_0.get_all_facts()


# Generated at 2022-06-25 01:21:54.071538
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    var_1 = OpenBSDVirtualCollector()
    assert isinstance(var_1, OpenBSDVirtualCollector)

# Generated at 2022-06-25 01:21:55.849541
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    _platform = 'OpenBSD'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(_platform)


# Generated at 2022-06-25 01:22:29.519426
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    class_name = 'OpenBSDVirtualCollector'
    var_1 = {}
    def func_0():
        '''
        hm = self._fact_class(self._gather_subset)
        return hm.get_virtual_facts()
        '''
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(func_0, class_name, var_1)
    var_2 = var_0['virtualization_tech_guest']
    expected = set()
    expected.add('vmm')
    expected.add('virtio')
    assert var

# Generated at 2022-06-25 01:22:31.896853
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = str(open_b_s_d_virtual_collector_0)
    assert var_0 == 'OpenBSDVirtualCollector'


# Generated at 2022-06-25 01:22:33.752281
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    test_case_0()

# Generated at 2022-06-25 01:22:39.885933
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance (var_0, dict)


# Generated at 2022-06-25 01:22:42.959082
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    # test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:22:50.973368
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # pytestmark = pytest.mark.xfail(reason='TODO')
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': ''}, "Result was %s" % var_0


# Generated at 2022-06-25 01:23:00.081612
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # mock the sysctl output
    sysctl_swap_mock = dict(
        hw_product='',
        hw_vendor='VMware, Inc.',
        )

    sysctl_virtual_mock = dict(
        hw_vendor='Bochs',
        hw_product='Bochs',
        )

    check_sysctl_mock = dict(
        hw_vendor='Bochs',
        hw_product='Bochs',
        )

    with patch('ansible.module_utils.facts.virtual.openbsd.OpenBSDVirtual.collect_sysctl_facts') as mock_collect:
        mock_collect.return_value = sysctl_swap_mock
        openbsd_virtual = OpenBSDVirtual(False)
        assert openbsd_virtual.get

# Generated at 2022-06-25 01:23:06.503536
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# End of unit test for method get_virtual_facts of class OpenBSDVirtual


# Generated at 2022-06-25 01:23:09.702856
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Define a boolean value for arg option_enable_fact_cache
    bool_0 = False
    # Initialize object of class OpenBSDVirtual
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    # Call method
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)



# Generated at 2022-06-25 01:23:11.759145
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:14.650493
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Arrange
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)

    # Act
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

    # Assert
    assert var_0.get('virtualization_tech_guest') == set()
    assert var_0.get('virtualization_tech_host') == set()

# Generated at 2022-06-25 01:24:18.029630
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:21.946687
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:24:25.946965
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    #assert var_0 == 'hw.product'

# Generated at 2022-06-25 01:24:34.882493
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with valid values
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # Test with invalid values
    bool_1 = True
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_1)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()

# run unit test for class OpenBSDVirtual
# test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:24:41.111534
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = type({})
    assert type(var_0) == var_1

# Generated at 2022-06-25 01:24:44.056185
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)


# Generated at 2022-06-25 01:24:45.298259
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:24:50.262783
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    try:
        open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    except NameError:
        pass


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:24:53.717004
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Run get_virtual_facts of OpenBSDVirtual
    test_case_0()


# Run unit tests
if __name__ == '__main__':
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:27:19.193303
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert len(var_0) == 5
    assert var_0['virtualization_tech_guest'] == set(['vmm'])
    assert var_0['virtualization_tech_host'] == set(['vmm'])
    assert var_0['virtualization_role'] == 'guest'
    assert var_0['virtualization_type'] == 'vmm'
    assert var_0['virtualization_product'] == 'vmm'


# Generated at 2022-06-25 01:27:27.822153
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)
    assert open_b_s_d_virtual_collector_0._collect_only_virt_facts == False
    assert open_b_s_d_virtual_collector_0._fact_class is OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0.collect()['virtualization_type'] == 'vmm'
    assert open_b_s_d_virtual_collector_0.collect()['virtualization_role'] == 'host'

# Unit test

# Generated at 2022-06-25 01:27:28.424547
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:27:33.784054
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Set up mock
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)

    return open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:27:43.533566
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    bool_1 = False
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_1)
    open_b_s_d_virtual_2 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_3 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.get_virtual_facts()
    open_b_s_d_virtual_1.get_virtual_facts()
    open_b_s_d_virtual_2.get_virtual_facts()
    open_b_s_d_virtual_3.get_virtual_facts()



# Generated at 2022-06-25 01:27:44.840473
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)



# Generated at 2022-06-25 01:27:48.679114
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = False
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:27:50.570586
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:53.297694
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    if isinstance(open_b_s_d_virtual_0, OpenBSDVirtual):
        var_0 = open_b_s_d_virtual_0.get_virtual_facts()
        assert var_0 == {}


# Generated at 2022-06-25 01:27:57.640239
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # assert the return value of get_virtual_facts is string, if return value is not string, the test case fails
    try:
        test_case_0()
    except Exception as e:
        raise e
    else:
        assert True
