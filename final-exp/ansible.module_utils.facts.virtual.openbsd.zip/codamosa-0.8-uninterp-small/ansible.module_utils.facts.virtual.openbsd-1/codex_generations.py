

# Generated at 2022-06-25 01:18:09.968061
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_collector_0.populate()
    open_b_s_d_virtual_collector_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:15.084682
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:20.118373
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_1.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_1.fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_1.fact_class().platform == 'OpenBSD'



# Generated at 2022-06-25 01:18:22.572074
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set([]),
       'virtualization_tech_host': set([u'vmm'])
    }

    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert virtual_facts == open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:28.036430
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = open_b_s_d_virtual_collector_0.get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-25 01:18:38.984403
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openb_sdvirtual = OpenBSDVirtual()
    # Test with empty file contents
    openb_sdvirtual.DMESG_BOOT = ''
    expected_facts = {
        'virtualization_type': 'vmm',
        'virtualization_type_full': '',
        'virtualization_role': 'host',
        'virtualization_tech_guest': {'vmm'},
        'virtualization_tech_host': {'vmm'},
        'virtualization_virtual_guest': ['OpenBSD'],
        'virtualization_virtual_guest_full': ['OpenBSD'],
        'virtualization_product_name': 'OpenBSD'
    }
    facts = openb_sdvirtual.get_virtual_facts()
    assert facts == expected_facts

    # Test with non-empty file contents
    openb

# Generated at 2022-06-25 01:18:42.978836
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform is 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class is OpenBSDVirtual

test_OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:48.652704
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }


# Generated at 2022-06-25 01:18:49.533372
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector_0 = OpenBSDVirtualCollector()
    virtual_collector_1 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:51.749673
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:00.505034
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:19:04.860471
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()



# Generated at 2022-06-25 01:19:12.404085
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:19:20.735880
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:19:27.149210
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    set_0 = {'m5'}
    tuple_0 = (None,)
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0, tuple_0)
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': ''}


# Generated at 2022-06-25 01:19:32.059902
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    assert True


# Generated at 2022-06-25 01:19:38.592450
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:19:41.460313
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    class_0 = OpenBSDVirtualCollector()
    assert class_0._fact_class == OpenBSDVirtual
    assert class_0._platform == 'OpenBSD'

# Generated at 2022-06-25 01:19:51.067439
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_product_name': '', 'virtualization_product_version': '', 'virtualization_product_version_major': '', 'virtualization_product_version_minor': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_hypervisor': {'is_guest': False, 'is_host': False}}

# Generated at 2022-06-25 01:19:52.197273
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
        open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:05.184886
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    open_b_s_d_virtual_1.platform = None
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    open_b_s_d_virtual_1.platform = 'virtualization_type'
    var_2 = open_b_s_d_virtual_1.get_virtual

# Generated at 2022-06-25 01:20:11.171710
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

if __name__ == "__main__":
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:20:14.284480
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:20:21.848454
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:20:29.292782
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(set_0, tuple_0)


# Generated at 2022-06-25 01:20:36.182096
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtualCollector(set_0, tuple_0)


# Generated at 2022-06-25 01:20:41.723341
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_2 = None
    dict_0 = {}
    dict_1 = {u'virtualization_role': u'', u'virtualization_type': u''}
    tuple_1 = (dict_0, dict_1)
    open_b_s_d_virtual_1 = OpenBSDVirtual(dict_0, tuple_1)
    dict_2 = open_b_s_d_virtual_1.get_virtual_facts()
    dict_3 = {u'virtualization_role': u'', u'virtualization_type': u''}
    assert dict_2 == dict_3

# Generated at 2022-06-25 01:20:45.915116
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-25 01:20:49.752167
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0, (None,))
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector.from_platform(set_0, open_b_s_d_virtual_0)


if __name__ == "__main__":
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:58.157896
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    # Test for constructor of class OpenBSDVirtual
    open_b_s_d_virtual_1 = OpenBSDVirtualCollector(set_0, tuple_0)
    # Verify there's no exception raised
    pass

if __name__ == "__main__":
    # Unit test for class OpenBSDVirtual
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:21:12.047031
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_1 = (None,)
    set_1 = {None, None, None, None}
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(set_1, tuple_1)



# Generated at 2022-06-25 01:21:14.801882
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'

# Generated at 2022-06-25 01:21:19.812808
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    set_0 = set()
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:21:28.382727
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(open_b_s_d_virtual_1)
    var_0 = open_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:21:38.741102
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    dict_0 = dict()
    dict_1 = dict()
    dict_0.update(var_0)
    dict_1.update(var_0)
    open_b_s_d_virtual_2 = OpenBSDVirtual(set_0, tuple_0)

# Generated at 2022-06-25 01:21:45.465284
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    set_0 = set()
    tuple_0 = (open_b_s_d_virtual_collector_0,)
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:51.894777
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = OpenBSDVirtual(set_0)
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = None
    var_0 = OpenBSDVirtualCollector(set_0, tuple_0)


# Generated at 2022-06-25 01:21:55.305083
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(dict())
    if not open_b_s_d_virtual_0.get_virtual_facts():
        assert False
    else:
        assert True


# Generated at 2022-06-25 01:22:03.394237
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-25 01:22:11.487418
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    print(var_0)



# Generated at 2022-06-25 01:22:41.428596
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():

    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._collector == None



# Generated at 2022-06-25 01:22:44.690543
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test without arguments
    try:
        test_case_0()
    except NameError:
        OpenBSDVirtual.get_virtual_facts()


test_case_0()

# Generated at 2022-06-25 01:22:52.194942
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()



# Generated at 2022-06-25 01:23:02.837444
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''

    open_bsd_virtual_collector_0 = OpenBSDVirtualCollector()
    tuple_0 = ('hw.vendor',)

# Generated at 2022-06-25 01:23:06.190478
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Input params
    # Output params
    # Output result
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:12.192762
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
  open_b_s_d_virtual_collector_0._platform = 'OpenBSD'
  # We were calling a private member function of a class, will try to re-design
  #var_0 = open_b_s_d_virtual_collector_0._collect_platform_facts()
  return

# Generated at 2022-06-25 01:23:20.668194
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_3 = OpenBSDVirtual(set_0, None)
    tuple_0 = (open_b_s_d_virtual_3,)
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(0, 0, set_0, tuple_0)
    assert open_b_s_d_virtual_collector_0._supported_facts == set_0
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-25 01:23:24.144852
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    set_0 = set()
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    assert var_0 == {}


# Generated at 2022-06-25 01:23:29.555431
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:23:37.330159
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Init the class
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    # Call the method
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    # Assert the results
    assert isinstance(var_0, dict)
    assert  'virtualization_role' in var_0
    assert  'virtualization_type' in var_0
    assert 'virtualization_type' in var_0
    assert 'virtualization_type' in var_

# Generated at 2022-06-25 01:24:53.965844
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # This is the file path that is being tested.
    # ($ANSIBLE_TEST_DATA/utils/facts)
    dmesg_boot_path = ('/home/alan/ansible_test_data/utils/facts/'
                       'dmesg.boot.openbsd')
    var_0 = OpenBSDVirtual.get_file_content(dmesg_boot_path)

    # Run the method with the file path
    test_case_0()

    # Set expected results
    expected_0 = {}
    expected_0['virtualization_type'] = ''
    expected_0['virtualization_role'] = ''
    expected_0['virtualization_product'] = 'N/A'
    expected_0['virtualization_vendor'] = 'N/A'
    expected_0['virtualization_tech_guest']

# Generated at 2022-06-25 01:25:00.931932
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(open_b_s_d_virtual_1)

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:25:02.696632
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    t_0 = OpenBSDVirtual()
    print(t_0.get_virtual_facts())


# Generated at 2022-06-25 01:25:03.359802
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_case_0()

# Generated at 2022-06-25 01:25:10.901282
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    var_1 = {0.5}
    open_b_s_d_virtual_2 = None
    tuple_1 = (open_b_s_d_virtual_2,)
    open_b_s_d_virtual_3 = OpenBSDVirtual(var_1, tuple_1)
    var_2 = open_b_s_d_virtual_3.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:25:14.752040
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(open_b_s_d_virtual_1)


# Generated at 2022-06-25 01:25:19.146032
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:25:24.057925
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 01:25:30.026309
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:25:34.289934
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    float_0 = 0.5
    set_0 = {float_0, float_0, float_0, float_0}
    open_b_s_d_virtual_0 = None
    tuple_0 = (open_b_s_d_virtual_0,)
    open_b_s_d_virtual_1 = OpenBSDVirtual(set_0, tuple_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()
    assert var_0 is not None
