

# Generated at 2022-06-25 01:18:19.167550
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert 'name' in virtual_facts
    assert 'release' in virtual_facts
    assert 'kernel' in virtual_facts
    assert 'version' in virtual_facts
    assert 'architecture' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-25 01:18:21.627483
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:23.096897
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:18:32.282083
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector.fact_class._platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector.fact_class.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector.fact_class.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-25 01:18:36.845596
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    assert open_b_s_d_virtual.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-25 01:18:40.623118
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-25 01:18:44.941749
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:47.098183
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_obj = OpenBSDVirtual()
    open_b_s_d_virtual_obj.get_virtual_facts()

# Generated at 2022-06-25 01:18:48.689240
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:51.456291
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-25 01:19:01.275857
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:19:06.196687
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    facts = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(facts, dict)
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_product_name' in facts
    assert 'virtualization_product_version' in facts
    assert 'virtualization_product_serial' in facts

# Generated at 2022-06-25 01:19:10.668499
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-25 01:19:19.127813
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    virtual_facts = open_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_product'] == 'OpenBSD'
    assert virtual_facts['virtualization_vendor'] == 'OpenBSD'

# Generated at 2022-06-25 01:19:26.655168
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:19:33.360927
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    this_open_b_s_d_virtual = OpenBSDVirtualCollector()

    this_open_b_s_d_virtual.detect_virt_product = (lambda: {'virtualization_tech_host': {'sun4u'}, 'virtualization_type': ''})
    this_open_b_s_d_virtual.detect_virt_vendor = (lambda: {'virtualization_tech_host': {'sun4u'}, 'virtualization_type': ''})
    this_open_b_s_d_virtual.get_file_content = (lambda: 'vmm0 at mainbus0: SVM/RVI')
    ret = this_open_b_s_d_virtual.get_virtual_facts()
    assert ret['virtualization_tech_guest'] == {'sun4u'}
   

# Generated at 2022-06-25 01:19:36.200880
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert hasattr(OpenBSDVirtualCollector, '_fact_class') == True
    assert isinstance(open_b_s_d_virtual_collector_0, OpenBSDVirtualCollector) == True


# Generated at 2022-06-25 01:19:42.132662
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:19:45.508403
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    assert open_b_s_d_virtual.get_virtual_facts()

# Generated at 2022-06-25 01:19:48.207832
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:19:58.063156
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == var_1


# Generated at 2022-06-25 01:20:00.192179
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_0 = ()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(tuple_0)

# Generated at 2022-06-25 01:20:02.917315
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_0 = ()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(tuple_0)
    var_0 = open_b_s_d_virtual_collector_0.get_all_facts()


# Generated at 2022-06-25 01:20:09.497762
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_0 = ()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(tuple_0)
    var_0 = open_b_s_d_virtual_collector_0._fact_class
    var_1 = open_b_s_d_virtual_collector_0._platform
    var_2 = open_b_s_d_virtual_collector_0._virtuals

# Generated at 2022-06-25 01:20:11.129624
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_0 = ()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(tuple_0)

# Generated at 2022-06-25 01:20:12.710565
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_1 = ()
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector(tuple_1)

# Generated at 2022-06-25 01:20:13.783365
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:17.296037
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_0 = ()
    var_0 = OpenBSDVirtualCollector(tuple_0)

# Generated at 2022-06-25 01:20:19.224829
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_0 = ()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(tuple_0)

# Generated at 2022-06-25 01:20:22.980089
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    dmesg_boot_0 = OpenBSDVirtual.DMESG_BOOT
    open_b_s_d_virtual_1 = OpenBSDVirtual(dmesg_boot_0)


# Generated at 2022-06-25 01:20:42.686745
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'vmm', 'expected value was not returned'
    assert var_0['virtualization_role'] == 'host', 'expected value was not returned'
    assert var_0['virtualization_tech_guest'] == set(), 'expected value was not returned'
    assert var_0['virtualization_tech_host'] == {'vmm'}, 'expected value was not returned'
    return 0

test_case_0()

# Generated at 2022-06-25 01:20:45.729508
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:50.336667
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_3 = OpenBSDVirtual()
    open_b_s_d_virtual_3._platform = 'OpenBSD'
    tuple_3 = ()
    open_b_s_d_virtual_3._sysctl_all = tuple_3
    open_b_s_d_virtual_3.DMESG_BOOT = '/var/run/dmesg.boot'
    # Call method
    result = open_b_s_d_virtual_3.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result


# Generated at 2022-06-25 01:20:59.099052
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_tech_host' in var_0
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:21:03.478256
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:21:09.538189
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

    assert var_0.keys() == ['virtualization_role', 'virtualization_type', 'virtualization_tech_host', 'virtualization_tech_guest']
    assert var_0['virtualization_role'] == 'host'
    assert var_0['virtualization_type'] == 'virtualbox'
    assert var_0['virtualization_tech_host'] == set(['vmm'])
    assert var_0['virtualization_tech_guest'] == set(['vbox'])


# Generated at 2022-06-25 01:21:13.922652
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'
    assert isinstance(open_b_s_d_virtual_collector_0._fact_class(), OpenBSDVirtual)


# Generated at 2022-06-25 01:21:16.180225
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_0.get('virtualization_type')


# Generated at 2022-06-25 01:21:20.964909
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_0 = ()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(tuple_0)
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'

# Test the method 'get_virtual_facts' of class 'VirtualCollector'.

# Generated at 2022-06-25 01:21:25.286297
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    assert open_b_s_d_virtual_0.get_virtual_facts() is None


# Generated at 2022-06-25 01:21:51.827114
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'

# Generated at 2022-06-25 01:21:56.473197
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_0 = ()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(tuple_0, platform="OpenBSD")
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == "OpenBSD"


# Generated at 2022-06-25 01:22:07.344096
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    # Test for equality
    #assert(open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': 'vmm', 'virtualization_role': 'host', 'virtualization_tech_guest': set(['bhyve', 'vmm']), 'virtual_product': 'VMM (Virtual Machine Monitor)', 'virtualization_tech_host': set(['vmm'])})
    #assert(open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': 'vmm', 'virtualization_role': 'host', 'virtualization_tech_guest': set(['bhyve', 'vmm']), 'virtual_product

# Generated at 2022-06-25 01:22:12.359393
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # AssertionError for each boolean value in dictionary: {'virtualization_role': '', 'virtualization_type': ''}
    assert var_0 == {'virtualization_role': '', 'virtualization_type': ''}

# Generated at 2022-06-25 01:22:18.816707
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    var_2 = open_b_s_d_virtual_0.get_virtual_facts()
    var_2 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:22:26.793896
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_0 = ()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(tuple_0)
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD', "Unexpected attribute value for '_platform'"
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual, "Unexpected attribute value for '_fact_class'"


# Generated at 2022-06-25 01:22:33.428341
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:43.185862
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    open_b_s_d_virtual_0._set_sysctl_values({'hw.vendor': 'GenuineIntel', 'machdep.cpu_vendor': 'GenuineIntel', 'machdep.cpu_brand': 'Intel(R) Core(TM) i5-7200U CPU @ 2.50GHz', 'hw.product': 'HVM domU', 'hw.machine': 'amd64'})
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == 'guest'


# Generated at 2022-06-25 01:22:46.019101
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert True


# Generated at 2022-06-25 01:22:51.857415
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-25 01:23:52.786911
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_1 = ()
    open_b_s_d_virtual_1 = OpenBSDVirtual(tuple_1)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    assert var_1 == {'bhyve': set(), 'virtualization_role': '', 'xen': set(), 'virtualization_type': '', 'vmware': set(), 'kvm': set(), 'virtualbox': set(), 'paravirtualization': set(), 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'hyperv': set(), 'openvz': set(), 'vz': set(), 'qemu': set()}

# Generated at 2022-06-25 01:23:56.228581
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_1 = ()
    open_b_s_d_virtual_1 = OpenBSDVirtual(tuple_1)
    assert open_b_s_d_virtual_1.get_virtual_facts() == {'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': ''}



# Generated at 2022-06-25 01:23:58.828287
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:24:06.684570
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_1 = ()
    open_b_s_d_virtual_1 = OpenBSDVirtual(tuple_1)
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector(open_b_s_d_virtual_1)
    tuple_2 = ()
    open_b_s_d_virtual_2 = OpenBSDVirtual(tuple_2)
    open_b_s_d_virtual_collector_2 = OpenBSDVirtualCollector(open_b_s_d_virtual_2)
    var_1 = str(open_b_s_d_virtual_collector_1)
    var_2 = str(open_b_s_d_virtual_collector_2)


# Generated at 2022-06-25 01:24:10.305323
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_cases = [0]
    for test_case in test_cases:
        if test_case == 0:
            test_case_0()
if __name__ == '__main__':
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:24:13.120367
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:24:18.485206
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}


test_case_0()

# Generated at 2022-06-25 01:24:23.048183
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)
    assert var_0 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:24:29.778311
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    assert (open_b_s_d_virtual_0.get_virtual_facts() == {
            'virtualization_role': 'host',
            'virtualization_type': 'vmm',
            'virtualization_technologies': {
                'host': {
                    'vmm'
                },
                'guest': set()
            }
        })



# Generated at 2022-06-25 01:24:33.339110
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Invoke method get_virtual_facts, then get the virtualization_type.
    """
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = var_0.get("virtualization_type")


# Generated at 2022-06-25 01:26:58.578118
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:03.865369
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 01:27:12.500947
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_0 = ()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(tuple_0)

# The following is the piece of code used to generate the file
# open_b_s_d_virtual.txt containing the facts returned by
# the collect_facts() method of class OpenBSDVirtualCollector
# Of course, real values are returned by the collect_facts()
# method, and not the ones given in this file.
#
#if __name__ == '__main__':
#    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
#    result_file_0 = open('open_b_s_d_virtual.txt', 'w')
#    result_file_0.write(str(open_b_s_d_virtual_collector

# Generated at 2022-06-25 01:27:19.048318
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    tuple_1 = ()
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(tuple_1)
    var_1 = open_b_s_d_virtual_collector_0.platform
    var_2 = open_b_s_d_virtual_collector_0.get_virtual_facts()


# Generated at 2022-06-25 01:27:21.266143
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts_0 = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': 'host', 'virtualization_type': 'vmm'}
    assert OpenBSDVirtual({}).get_virtual_facts() == facts_0


# Generated at 2022-06-25 01:27:23.030825
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:25.278673
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Setup test environment
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    # Assertions
    assert open_b_s_d_virtual_0.get_virtual_facts() is not None


# Generated at 2022-06-25 01:27:27.180809
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:35.129594
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    if not pytest.config.getoption('--openbsd-facts'):
        pytest.skip('OpenBSD facts not requested')
    assert get_virtual_facts(variables=['ansible_facts']) == {
        'ansible_virtual_facts': {
            'virtualization_role': None,
            'virtualization_type': None,
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set()
        }
    }

# Generated at 2022-06-25 01:27:39.333216
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tuple_0 = ()
    open_b_s_d_virtual_0 = OpenBSDVirtual(tuple_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
