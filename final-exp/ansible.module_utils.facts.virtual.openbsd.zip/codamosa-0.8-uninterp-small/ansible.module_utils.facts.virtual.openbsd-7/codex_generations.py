

# Generated at 2022-06-25 01:18:16.590864
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'

    del open_b_s_d_virtual_collector_0



# Generated at 2022-06-25 01:18:22.598783
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()
    assert open_b_s_d_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_sysctl_support': '',
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_product_serial': '',
        'virtualization_product_uuid': '',
        'virtualization_product_family': '',
        'virtualization_vendor': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-25 01:18:26.397316
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector._fact_class is OpenBSDVirtual


# Generated at 2022-06-25 01:18:27.224719
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-25 01:18:29.663337
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:38.550487
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert not hasattr(open_b_s_d_virtual_0, '_platform')
    assert open_b_s_d_virtual_0.platform == 'OpenBSD'
    assert open_b_s_d_virtual_0.DMESG_BOOT == '/var/run/dmesg.boot'
    open_b_s_d_virtual_0.get_virtual_facts()
    assert True



# Generated at 2022-06-25 01:18:42.263497
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test constructor
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:18:45.556663
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == {}

# Generated at 2022-06-25 01:18:49.482910
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bsd_virtual_collector = OpenBSDVirtualCollector()
    assert bsd_virtual_collector.platform == 'OpenBSD'
    assert bsd_virtual_collector._fact_class == OpenBSDVirtual
    assert bsd_virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-25 01:18:59.502643
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()

    # Evaluate code path where virtualization_type is empty
    open_b_s_d_virtual.detect_virt_product = lambda x: {'virtualization_type': '',
                                                        'virtualization_tech_guest': set(),
                                                        'virtualization_tech_host': set()}
    open_b_s_d_virtual.get_virtual_facts()

    # Evaluate code path where virtualization_type is not empty
    open_b_s_d_virtual.detect_virt_product = lambda x: {'virtualization_type': 'vmm',
                                                        'virtualization_tech_guest': set(['vmm']),
                                                        'virtualization_tech_host': set()}
    open_b_s_

# Generated at 2022-06-25 01:19:04.615005
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0.get_all_facts()

# Generated at 2022-06-25 01:19:09.849220
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:19:15.675192
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_1 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_1.get_virtual_facts()

# Generated at 2022-06-25 01:19:21.266799
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    list_0 = []
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bytes_0, list_0,
                                                              list_0)
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:19:26.734430
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {}

# Generated at 2022-06-25 01:19:29.134535
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-25 01:19:34.055209
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    assert open_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'kvm'},
    }, 'Argument 0 to OpenBSDVirtual.get_virtual_facts is invalid'


# Generated at 2022-06-25 01:19:37.894256
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    var_0 = OpenBSDVirtualCollector()
    assert var_0.get_virtual_facts() == dict({'virtualization_type': '',
                                              'virtualization_role': '',
                                              'virtualization_tech_guest': [],
                                              'virtualization_tech_host': []})


# Generated at 2022-06-25 01:19:43.588606
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:50.847713
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bytes_0)
    # test constructor without arguments
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:01.506483
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    open_b_s_d_virtual_collector_0.collect()
    open_b_s_d_virtual_collector_0.populate()
    open_b_s_d_virtual_collector_0.get_facts()
    open_b_s_d_virtual_collector_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:12.613267
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    host_tech = set()
    guest_tech = set()
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    if (var_0):
        if isinstance(var_0, set):
            host_tech.update(var_0)
        else:
            guest_tech.add(var_0)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    if (var_1):
        if isinstance(var_1, set):
            host_

# Generated at 2022-06-25 01:20:18.138816
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bytes_0)

test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:20:24.207838
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-25 01:20:27.454596
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    try:
        open_b_s_d_virtual_0 = OpenBSDVirtual(b'')
        var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    except:
        assert True
        return
    assert False


# Generated at 2022-06-25 01:20:36.996352
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:20:41.640117
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


if __name__ == '__main__':
    test_OpenBSDVirtual_get_virtual_facts()
    test_case_0()

# Generated at 2022-06-25 01:20:49.502332
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_tech_host': {'vmm'}, 'virtualization_tech_guest': set(), 'virtualization_role': 'host', 'virtualization_type': 'vmm'}

# Generated at 2022-06-25 01:20:59.250682
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_tech_host'] == set()
    bytes_1 = bytes([15, 156, 208, 220, 147, 153, 254, 177, 163, 170, 198, 141])
    open_b_s_d_virtual_1 = OpenBSDVirtual

# Generated at 2022-06-25 01:21:08.035036
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    with open('./test/testdata/openbsd/dmesg.boot', 'r') as dmesg_boot:

        def read_file(*_):
            return dmesg_boot.read()
        with patch('ansible.module_utils.facts.virtual.openbsd.OpenBSDVirtual.get_file_content', read_file):
            var_0 = open_b_s_d_virtual_0.get_virtual_facts()
            assert var_0['virtualization_type'] == 'vmm'

# Generated at 2022-06-25 01:21:27.864295
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_1 == {'virtualization_role': '',
                     'virtualization_type': '',
                     'virtualization_tech_guest': set(),
                     'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:21:37.556666
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert type(var_0) is dict
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''

# Generated at 2022-06-25 01:21:41.065913
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 01:21:48.936432
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(b'\x16\xbb\x8a\x9b\x06')
    open_b_s_d_virtual_1 = OpenBSDVirtual(b'\xa6\x1e\xcd\xe5M\xef\x12\x03')
    open_b_s_d_virtual_2 = OpenBSDVirtual(b'\x94\x10\x07\xa2{\x07\xda\x10\x9e\xd3\x94\x93\xbfm\xc4\x03')
    open_b_s_d_virtual_3 = OpenBSDVirtual(b'\xeb\x8f\x04\x0e\xdb\x19\xfd\xaa\x1b\xd2')

# Generated at 2022-06-25 01:21:54.254451
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes = '\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual = OpenBSDVirtual(bytes)
    expected_var_0 = {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': '', 'virtualization_type': ''}
    var_0 = open_b_s_d_virtual.get_virtual_facts()
    assert var_0 == expected_var_0

if __name__ == "__main__":
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:22:01.421723
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_type'] == 'vmm'
    assert var_0['virtualization_role'] == 'host'
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_tech_host'] == {'vmm'}


# Generated at 2022-06-25 01:22:06.854098
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\x8b\xff\x03\x08\x9c\x8b$\xcc\xb5\x83\xff\x0f/\xcf\xff'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:22:10.776326
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    var = OpenBSDVirtual()
    expected = {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    actual = var.get_virtual_facts()
    assert expected == actual


# Generated at 2022-06-25 01:22:19.598589
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''
    assert var_0['virtualization_tech_guest'] == set()
    assert var_0['virtualization_tech_host'] == set()
    assert var_0['virtualization_system'] == ''


# Generated at 2022-06-25 01:22:27.150345
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert isinstance(open_b_s_d_virtual_collector_0, OpenBSDVirtualCollector)
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'
    assert isinstance(open_b_s_d_virtual_collector_0._fact_class, OpenBSDVirtual)

# Generated at 2022-06-25 01:22:52.878888
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)

    # Call method get_virtual_facts of class OpenBSDVirtual with arguments
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:02.853243
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    # setUp method execution
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    # Method execution
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    # Assertion message
    msg_0 = 'dict'
    # Assertion condition
    assert_0 = isinstance(var_0, dict)
    assert_1 = var_0
    # Assertion message
    msg_1 = 'dict'
    # Assertion condition
    assert_2 = isinstance

# Generated at 2022-06-25 01:23:10.678108
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == ''
    assert var_0['virtualization_type'] == ''



# Generated at 2022-06-25 01:23:17.052242
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._fact_class is OpenBSDVirtual
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-25 01:23:22.117718
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()



# Generated at 2022-06-25 01:23:26.092964
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Create an instance of class OpenBSDVirtualCollector
    obj = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:23:27.138324
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:23:27.625164
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert False

# Generated at 2022-06-25 01:23:32.835866
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = var_0['virtualization_type']
    var_2 = var_0['virtualization_role']
    var_3 = var_0['virtualization_tech_guest']
    var_4 = var_0['virtualization_tech_host']



# Generated at 2022-06-25 01:23:33.820690
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:24:43.932004
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(b'')
    var_1 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_1 == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_technologies_guest': set(), 'virtualization_technologies_host': set()}

if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:24:46.804943
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    print(var_0)


# Generated at 2022-06-25 01:24:51.373764
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:24:53.819039
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:25:02.579236
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Call function get_virtual_facts with arguments:
    ret_0 = OpenBSDVirtual.get_virtual_facts()

    # Check if the return value is equal to:

# Generated at 2022-06-25 01:25:07.723704
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert callable(OpenBSDVirtual.get_virtual_facts)
    test_case_0()

# Generated at 2022-06-25 01:25:08.680465
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:25:11.850962
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = test_case_0()
    assert open_b_s_d_virtual_0 == None


# Generated at 2022-06-25 01:25:17.421512
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:25:19.628132
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:27:43.488725
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    var_0 = OpenBSDVirtual(bytes_0)
    var_1 = var_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:51.542905
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0['virtualization_role'] == 'guest', 'Failed to get virtualization_role'
    assert var_0['virtualization_type'] == 'vmm', 'Failed to get virtualization_type'
    assert var_0['virtualization_tech_guest'] == set(['vmm']), 'Failed to get virtualization_tech_guest'


# Generated at 2022-06-25 01:28:00.693935
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xce\x8f\x94\x95\x01\x14\x15\x15\x01\xcd\x1a\x8b\xac\x82E\x95\x0b\xa5O\x1bq\x15\x83\x11]\x88'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    assert open_b_s_d_virtual_0.get_virtual_facts('e4\xc4\xc4\xfe') == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-25 01:28:06.354097
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bytes_0 = b'\xb8x\x03\x08\xa7Lh\xc3|X0\xfd\x9f\t/Qd'
    open_b_s_d_virtual_0 = OpenBSDVirtual(bytes_0)
    open_b_s_d_virtual_0.detect_virt_product = lambda *args, **kwargs: {'virtualization_type': '', 'virtualization_tech_host': {'some-host-tech'}, 'virtualization_role': '', 'virtualization_tech_guest': {'some-guest-tech'}}