

# Generated at 2022-06-25 01:18:09.836108
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)


# Generated at 2022-06-25 01:18:14.068684
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    set_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert 'virtualization_type' in set_0
    assert 'virtualization_role' in set_0
    assert 'virtualization_tech_host' in set_0
    assert 'virtualization_tech_guest' in set_0
    assert 'virtualization_subtype' in set_0


# Generated at 2022-06-25 01:18:15.581431
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    str0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:18:20.350498
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': {'vmm'},
        'virtualization_tech_host': {'vmm'}
    }



# Generated at 2022-06-25 01:18:30.680690
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.facts = {}
    open_b_s_d_virtual_0.facts['system'] = dict()
    open_b_s_d_virtual_0.facts['system']['manufacturer'] = 'OpenBSD'
    ret_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert ret_0['virtualization_type'] == ''
    assert ret_0['virtualization_role'] == ''
    assert ret_0['virtualization_tech_guest'] == set()
    assert ret_0['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:18:38.624430
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = False
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    try:
        open_b_s_d_virtual_0.get_virtual_facts()
    except:
        bool_0 = False
        open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
        open_b_s_d_virtual_0.get_virtual_facts()

test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:18:42.938899
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual(True)
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:18:46.040946
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)


# Generated at 2022-06-25 01:18:55.488603
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-25 01:18:58.796363
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:19:05.384124
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualCollector
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert isinstance(open_b_s_d_virtual_collector_0, VirtualCollector)


# Generated at 2022-06-25 01:19:11.098221
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()

    get_virtual_facts_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert get_virtual_facts_0['virtualization_type'] == ''


# Generated at 2022-06-25 01:19:13.110698
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector._fact_class == OpenBSDVirtual
    assert open_b_s_d_virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-25 01:19:19.889034
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0.fact_class._platform == 'OpenBSD'


# Generated at 2022-06-25 01:19:30.632818
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()

    # Set up test data
    open_b_s_d_virtual_0.facts = dict()
    open_b_s_d_virtual_0.sysctl_cmd = 'sysctl'
    open_b_s_d_virtual_0.sysctl = dict()
    open_b_s_d_virtual_0.sysctl['hw.vendor'] = 'None'
    open_b_s_d_virtual_0.sysctl['hw.product'] = 'None'
    open_b_s_d_virtual_0.sysctl['hw.machine'] = 'None'

    # Call method
    result = open_b_s_d_virtual_0.get_virtual_facts()

    # Check results

# Generated at 2022-06-25 01:19:34.003345
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    test_case_0()

# Generated at 2022-06-25 01:19:40.936488
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-25 01:19:42.687857
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert hasattr(OpenBSDVirtualCollector, '_fact_class')
    assert hasattr(OpenBSDVirtualCollector, '_platform')


# Generated at 2022-06-25 01:19:50.670451
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    # Tests if the module returns the expected virtual_facts
    virtual_facts = open_b_s_d_virtual_collector_0.get_virtual_facts()
    assert virtual_facts == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_host': set([]), 'virtualization_tech_guest': set([])}

# Generated at 2022-06-25 01:19:52.157141
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:19:59.872721
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    result = OpenBSDVirtual().get_virtual_facts()
    assert result is not None


# Generated at 2022-06-25 01:20:01.289067
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:20:04.819078
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    pass  # Nothing to test


# Generated at 2022-06-25 01:20:07.341827
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_1 = OpenBSDVirtual()
    print(open_b_s_d_virtual_1.get_virtual_facts())


# Generated at 2022-06-25 01:20:16.869945
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual = OpenBSDVirtual()

    # Test when hw.product is 'QEMU Virtual CPU version (cpu64-rhel6)'
    open_b_s_d_virtual.sysctl = {
        'hw.product': 'QEMU Virtual CPU version (cpu64-rhel6)',
    }
    assert open_b_s_d_virtual.get_virtual_facts() == {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['virtualbox']),
        'virtualization_tech_host': set(['qemu']),
    }

    # Test when hw.vendor is 'Parallels Software International Inc.'
    open_b_s_d_virtual.sysctl

# Generated at 2022-06-25 01:20:22.741675
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0._platform == 'OpenBSD'
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual
    assert isinstance(open_b_s_d_virtual_collector_0._fact_class, Virtual)
    assert open_b_s_d_virtual_collector_0._fact_class.platform == 'OpenBSD'


# Generated at 2022-06-25 01:20:29.153193
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_get_virtual_facts = OpenBSDVirtual()
    ansible_var = openbsd_virtual_get_virtual_facts.get_virtual_facts()
    assert ansible_var['ansible_virtualization_type'] == ''
    assert ansible_var['ansible_virtualization_role'] == ''
    assert ansible_var['ansible_virtualization_tech_guest'] == set()
    assert ansible_var['ansible_virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-25 01:20:30.750840
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:20:34.938773
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:37.108213
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert {} == open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:45.082215
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    var_1 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:20:48.482411
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # No fact-checking needed, but we need to execute the method to get
    # the test coverage.
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:20:53.582545
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:20:56.140892
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)

# Generated at 2022-06-25 01:21:04.611041
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-25 01:21:08.372283
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)
    assert isinstance(open_b_s_d_virtual_collector_0._fact_class, OpenBSDVirtual) and open_b_s_d_virtual_collector_0._fact_class._platform == 'OpenBSD' and open_b_s_d_virtual_collector_0._platform == 'OpenBSD'


# Generated at 2022-06-25 01:21:09.037938
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    var_1 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:21:12.546485
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    var = OpenBSDVirtual()
    var.get_virtual_facts()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 01:21:15.589368
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_type': '',
                                                        'virtualization_role': '',
                                                        'virtualization_tech_guest': set(),
                                                        'virtualization_tech_host': set()}



# Generated at 2022-06-25 01:21:16.744874
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:21:34.454078
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Assign argument
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    # Run method
    var_0 = open_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:21:35.488634
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:21:37.555206
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert isinstance(open_b_s_d_virtual_collector_0, OpenBSDVirtualCollector)


# Generated at 2022-06-25 01:21:40.103759
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)
    assert isinstance(open_b_s_d_virtual_collector_0, OpenBSDVirtualCollector) == True

# Generated at 2022-06-25 01:21:45.554609
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 == {'virtualization_type': '', 'virtualization_role': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}


# Generated at 2022-06-25 01:21:49.071320
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)

# Generated at 2022-06-25 01:21:52.079812
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_0 = OpenBSDVirtual()
    assert open_b_s_d_virtual_0.get_virtual_facts() == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_role': '', 'virtualization_type': ''}

# Generated at 2022-06-25 01:21:54.981192
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:00.212992
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_1 = False
    open_b_s_d_virtual_1 = OpenBSDVirtual(bool_1)
    var_1 = open_b_s_d_virtual_1.get_virtual_facts()
    if var_1 is not None:
        print("get_virtual_facts with value " + str(var_1))
    assert var_1 is not None


# Generated at 2022-06-25 01:22:02.529326
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert isinstance(obj, OpenBSDVirtualCollector)


# Generated at 2022-06-25 01:22:33.665975
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Testing constructor
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()


if __name__ == '__main__':
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:22:42.181357
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    # Assigning variable 'OpenBSDVirtual' to attribute '_fact_class'
    open_b_s_d_virtual_collector_0._fact_class = OpenBSDVirtual
    # Assigning variable 'OpenBSD' to attribute '_platform'
    open_b_s_d_virtual_collector_0._platform = 'OpenBSD'
    open_b_s_d_virtual_collector_1 = OpenBSDVirtualCollector()


# Generated at 2022-06-25 01:22:45.885894
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 01:22:51.568716
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'
    open_b_s_d_virtual_collector_0.collect()


# Generated at 2022-06-25 01:22:53.137166
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    print(var_0)

# Generated at 2022-06-25 01:22:55.877823
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)

# Generated at 2022-06-25 01:23:03.933002
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    # <InteractiveInput object>
    #

# Generated at 2022-06-25 01:23:08.946310
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.DMESG_BOOT = 'hw.product'
    open_b_s_d_virtual_0.get_file_content = open_b_s_d_virtual_0.get_file_content
    open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:23:11.860071
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)
    assert open_b_s_d_virtual_collector_0.platform == 'OpenBSD'


# Generated at 2022-06-25 01:23:17.991102
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)
    assert isinstance(open_b_s_d_virtual_collector_0, OpenBSDVirtualCollector)
    assert open_b_s_d_virtual_collector_0._fact_class == OpenBSDVirtual

# Generated at 2022-06-25 01:24:28.426352
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)

# Generated at 2022-06-25 01:24:30.073368
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert (OpenBSDVirtual.get_virtual_facts.__doc__ is not None)

if __name__ == "__main__":
    test_case_0()
    test_OpenBSDVirtual_get_virtual_facts()

# Generated at 2022-06-25 01:24:34.729160
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_data = {}
    open_b_s_d_virtual_0 = OpenBSDVirtual(**test_data)
    ret_val_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert ret_val_0.__contains__('virtualization_type') is True
    assert ret_val_0.__contains__('virtualization_role') is True
    assert ret_val_0.__contains__('virtualization_tech_guest') is True
    assert ret_val_0.__contains__('virtualization_tech_host') is True



# Generated at 2022-06-25 01:24:35.605759
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert get_file_content(OpenBSDVirtual.DMESG_BOOT) != ''

# Generated at 2022-06-25 01:24:41.552086
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)

if __name__ == "__main__":
    test_case_0()
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:24:44.785641
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    open_b_s_d_virtual_1 = OpenBSDVirtual(False)
    open_b_s_d_virtual_1.get_virtual_facts()


# Generated at 2022-06-25 01:24:45.388645
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    pass

# Generated at 2022-06-25 01:24:50.584212
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    var_1 = isinstance(var_0, dict)
    assert var_1

# Generated at 2022-06-25 01:24:51.999432
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    test_case_0()

if __name__ == '__main__':
    test_OpenBSDVirtualCollector()

# Generated at 2022-06-25 01:24:55.534421
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert type(var_0) == dict


# Generated at 2022-06-25 01:27:25.263574
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:27.778015
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()
    assert var_0 is not None
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 01:27:35.544984
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Setting up test variables
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)

    # Invoking method
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

    # Checking conditions
    assert var_0 == {'virtualization_role': '', 'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([]), 'virtualization_type': ''}, 'Return does not match expected value'


# Generated at 2022-06-25 01:27:42.144102
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)

    assert open_b_s_d_virtual_0.get_virtual_facts() == {
                'virtualization_role': 'guest',
                'virtualization_type': '',
                'virtualization_tech_host': set(),
                'virtualization_tech_guest': set(['vmm'])}

# Generated at 2022-06-25 01:27:44.939116
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    var_0 = open_b_s_d_virtual_0.get_virtual_facts()

# Generated at 2022-06-25 01:27:46.719366
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bool_0 = True
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector(bool_0)



# Generated at 2022-06-25 01:27:52.828557
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    open_b_s_d_virtual_0.detect_virt_product = get_file_content
    open_b_s_d_virtual_0.detect_virt_vendor = get_file_content
    # for testing purpose only
    open_b_s_d_virtual_0.read_sysctl = lambda x: "vmm0 at mainbus0: SVM/RVI"
    method_ret_val_0 = open_b_s_d_virtual_0.get_virtual_facts()

    assert (method_ret_val_0['virtualization_type'] == 'vmm')

# Generated at 2022-06-25 01:27:59.566700
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bool_0 = True
    open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
    # Calling get_virtual_facts()
    # get_virtual_facts() calls detect_virt_product('hw.product')
    # detect_virt_product() calls detect_virt_vendor('hw.vendor')
    # detect_virt_vendor() calls dict.get()
    # dict.get() calls object.__getattribute__(__dict__)
    return open_b_s_d_virtual_0.get_virtual_facts()


# Generated at 2022-06-25 01:28:02.998921
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    open_b_s_d_virtual_collector_0 = OpenBSDVirtualCollector()
    var_0 = open_b_s_d_virtual_collector_0.collect()

# Generated at 2022-06-25 01:28:09.305426
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
  # Initialization
  bool_0 = True
  open_b_s_d_virtual_0 = OpenBSDVirtual(bool_0)
  # Execution
  var_0 = open_b_s_d_virtual_0.get_virtual_facts()
  # Verification
  assert var_0 != None
