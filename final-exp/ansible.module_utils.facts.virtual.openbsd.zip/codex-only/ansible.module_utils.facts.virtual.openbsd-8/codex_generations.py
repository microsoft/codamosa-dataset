

# Generated at 2022-06-23 02:24:17.415298
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_fact = OpenBSDVirtualCollector()
    assert openbsd_virtual_fact.platform == 'OpenBSD'
    assert openbsd_virtual_fact.virt_what_command == '/sbin/sysctl -n hw.product'
    assert openbsd_virtual_fact.sysctl_command == '/sbin/sysctl -a'
    assert openbsd_virtual_fact.vendor_files == ['/var/run/dmesg.boot']

# Generated at 2022-06-23 02:24:19.707847
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtualplatform = OpenBSDVirtualCollector()
    assert virtualplatform._fact_class is OpenBSDVirtual
    assert virtualplatform._platform == 'OpenBSD'

# Generated at 2022-06-23 02:24:22.754491
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:24:33.356969
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Default OpenBSDVirtual if no virtualization product/vendor detected
    openbsd_virtual = OpenBSDVirtual(None)
    result = openbsd_virtual.get_virtual_facts()
    assert result == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_type_role': '',
        'virtualization_full': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # OpenBSD with bhyve
    # Virtualization facts from sysctl 'hw.product'
    openbsd_virtual = OpenBSDVirtual({'hw.product': 'i386'})

# Generated at 2022-06-23 02:24:43.620043
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    # Test OpenBSD/VMM based install
    facts = dict()
    virtual_facts = dict(
        virtualization_type='vmm',
        virtualization_role='host',
        virtualization_tech_host=set(['vmm'])
    )
    openbsd_virtual.DMESG_BOOT = 'tests/unittests/files/dmesg_vmm.boot'

    openbsd_virtual.get_virtual_facts_from_sysctl = MagicMock(return_value=virtual_facts)
    returned_facts = openbsd_virtual.get_virtual_facts(facts)

# Generated at 2022-06-23 02:24:44.641300
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:24:47.496746
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_vd = OpenBSDVirtualCollector.fetch_virtual_facts()
    assert isinstance(openbsd_vd, dict)

# Generated at 2022-06-23 02:24:50.861196
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.virtual.freebsd_vmm import OpenBSDVirtualCollector
    assert issubclass(OpenBSDVirtualCollector, Collector)

# Generated at 2022-06-23 02:25:00.841145
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd = OpenBSDVirtual({})

    # Test the virt_host product detection
    #
    # VirtualBox guest
    product = 'VirtualBox'
    expected_facts = {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'vbox', 'virtualbox'},
        'virtualization_tech_host': set()
    }
    assert openbsd._get_virtual_facts_for_virt_product(product) == expected_facts

    # Test the virt_vendor product detection
    #
    # VirtualBox guest
    vendor = 'Oracle Corporation'

# Generated at 2022-06-23 02:25:05.340563
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_obj = OpenBSDVirtual()
    assert openbsd_virtual_obj.platform == 'OpenBSD'
    assert openbsd_virtual_obj.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:25:16.890855
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a empty OpenBSDVirtual object
    o = OpenBSDVirtual()

    # Create the expected results of method get_virtual_facts
    virtual_facts = {
        'virtualization_type': 'jail',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'jail'},
        'virtualization_tech_host': set(),
    }

    # Set empty values as default
    o.facts['virtualization_type'] = ''
    o.facts['virtualization_role'] = ''

    # override the detect_virt_product method, which will normally
    # return the "jail" virtualization type

# Generated at 2022-06-23 02:25:23.045132
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    vp_dict = {
        'virtualization': '',
        'product_name': '',
        'product_version': '',
        'product_serial': '',
        'product_uuid': '',
        'product_vendor': '',
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': '',
        'virtualization_technologies': []
    }
    test_vp = OpenBSDVirtual()
    assert test_vp.virtual_facts == vp_dict

# Generated at 2022-06-23 02:25:23.950169
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector is not None

# Generated at 2022-06-23 02:25:28.027535
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # empty constructor will work with OpenBSDPlatform class
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    # both of private properties should be work
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:33.856031
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test creation of a collector
    c = OpenBSDVirtualCollector()
    assert isinstance(c, OpenBSDVirtualCollector)

    # Test platform property
    assert c.platform == 'OpenBSD'
    assert c._platform == 'OpenBSD'
    assert c.fact_class == OpenBSDVirtual
    assert c._fact_class is OpenBSDVirtual


# Generated at 2022-06-23 02:25:38.304581
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual(None).get_virtual_facts()
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert virtual_facts['virtualization_type'] == 'virtualbox'

# Generated at 2022-06-23 02:25:48.246415
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    v = OpenBSDVirtual()

    # pkgpath == 'none'
    v._virt_product_facts['hw.product'] = 'none'
    v._virt_vendor_facts['hw.vendor'] = 'none'
    v.dmesg_boot = """
vgapci0 at pci0 dev 2 function 0: vendor 0x8086 product 0x1912 (rev. 0x07)
vmm0 at mainbus0: (SVM/RVI)
    """
    expected = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'vmm'},
        'virtualization_role': 'host',
        'virtualization_type': 'vmm',
    }
    result = v.get_virtual_facts()
    assert result == expected
    v.dmes

# Generated at 2022-06-23 02:25:52.893749
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    results = {}
    results['virtualization_type'] = ''
    results['virtualization_role'] = ''
    results['virtualization_tech_host'] = set([])
    results['virtualization_tech_guest'] = set([])
    assert virtual_facts.data == results

# Generated at 2022-06-23 02:25:55.882973
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector.fact_class is not None
    assert collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:26:06.534212
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import os
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    # Initialize an object of type OpenBSDVirtual
    # with mocked values for some methods

# Generated at 2022-06-23 02:26:08.588960
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert isinstance(obj, OpenBSDVirtualCollector)
    assert obj.platform == 'OpenBSD'

# Generated at 2022-06-23 02:26:10.692223
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    redhat = OpenBSDVirtual()
    assert redhat.platform == 'OpenBSD'


# Generated at 2022-06-23 02:26:15.381525
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual({})
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_product_vendor': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-23 02:26:18.626738
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts._platform == 'OpenBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''


# Generated at 2022-06-23 02:26:22.049849
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == OpenBSDVirtual.platform
    assert openbsd_virtual.DMESG_BOOT == OpenBSDVirtual.DMESG_BOOT

# Generated at 2022-06-23 02:26:28.195783
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    virtual_facts = openbsd_virtual_facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] in ['', 'vmm']
    assert virtual_facts['virtualization_role'] in ['', 'host']
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert 'vmm' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:26:31.112322
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert 'virtualization_type' in virtual.facts
    assert 'virtualization_role' in virtual.facts

# Generated at 2022-06-23 02:26:32.597414
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:26:34.749472
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # As OpenBSDVirtualCollector is just declaring a class
    # and does not do any operation, there is no test
    assert True

# Generated at 2022-06-23 02:26:45.154946
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = {'virtualization_type': 'vmm',
                     'virtualization_role': 'host',
                     'virtualization_tech_guest': set(['vmm']),
                     'virtualization_tech_host': set(['vmm'])}

    facts = { 'kernel': 'OpenBSD',
              'kernel_version': '6.6',
              'virtual': 'OpenBSD'}
    openbsd_virtual = OpenBSDVirtual(facts)
    openbsd_virtual.detect_virt_product = lambda x: {'virtualization_type': '',
                                                     'virtualization_role': '',
                                                     'virtualization_tech_guest': set(),
                                                     'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:26:55.370121
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual()

    # Define a dict of facts and create a new dict of expected virtual facts
    # to easily validate the results.
    # - virtualization_type: Define the virtualization role of the system
    # - virtualization_role: Define the virtualization type of the system
    # - virtualization_tech_guest: Define the virtualization technologies
    #   supported by the system as a guest
    # - virtualization_tech_host: Define the virtualization technologies
    #   supported by the system as a host
    #
    # List of virtualization_type values
    # - 'host': System is capable of hypervisor functionality
    # - 'guest': System is controlled by a hypervisor
    # - '': System is not virtualized
    #
    # List of virtualization_role values
    # - 'host

# Generated at 2022-06-23 02:26:57.955441
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual
    assert openbsd_virtual._fact_class
    assert openbsd_virtual._platform


# Generated at 2022-06-23 02:26:59.486304
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    hypervisor = OpenBSDVirtual()
    assert hypervisor.platform == 'OpenBSD'

# Generated at 2022-06-23 02:27:07.859557
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Test virtual_facts with Virtualization vendor and product
    dmesg_boot_content = '''
vmm0 at mainbus0: SVM/RVI
OpenBSD 6.4-current (GENERIC.MP) #78: Thu Mar 26 01:25:34 MDT 2020     xxx@xxx.xxx:/usr/src/sys/arch/amd64/compile/GENERIC.MP
real mem = 8589934592 (8192MB)
avail mem = 8190427136 (7842MB)
'''

    # Set the dmesg.boot file content
    dmesg_boot = set_file_content(OpenBSDVirtual.DMESG_BOOT, dmesg_boot_content)

    # Test get_virtual_facts with Virtualization vendor and product
    openbsd_virtual = OpenBSDVirtual()


# Generated at 2022-06-23 02:27:11.609915
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:27:19.176752
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_facts = OpenBSDVirtual({}).get_virtual_facts()

    # Test that all keys are present
    assert all(key in test_facts for key in [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host',
    ])
    # Test that all values are not an empty string
    assert all(test_facts[key] != '' for key in [
        'virtualization_type',
        'virtualization_role',
        'virtualization_tech_guest',
        'virtualization_tech_host',
    ])

# Generated at 2022-06-23 02:27:24.203857
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_product' in virtual_facts
    assert 'virtualization_vendor' in virtual_facts

# Generated at 2022-06-23 02:27:27.683257
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_data = OpenBSDVirtual()
    assert virtual_data.platform == 'OpenBSD'
    assert virtual_data.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-23 02:27:35.620560
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class OpenBSDVirtual

    Here we set virtualization_type and virtualization_role from hwdetect
    """
    openbsd = OpenBSDVirtual()
    openbsd.collect_platform_subset_facts = lambda: {'hwdetect': {'virtualization': 'virtualbox',
                                                                  'role': 'guest'}}
    assert openbsd.get_virtual_facts() == {'virtualization_type': 'virtualbox',
                                           'virtualization_role': 'guest',
                                           'virtualization_tech_guest': set(),
                                           'virtualization_tech_host': set(),
                                           'virtualization_product_name': ''}



# Generated at 2022-06-23 02:27:46.079029
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    ven = VirtualSysctlDetectionMixin()
    ven._sysctl = {'hw.product': 'VirtualBox', 'hw.vendor': 'QEMU'}
    ven._supported_virt_vendors = ['QEMU', 'VirtualBox']
    ven._supported_virt_products = ['VirtualBox']
    ov = OpenBSDVirtual()
    ov._detect_virt_vendor = ven.detect_virt_vendor
    ov._detect_virt_product = ven.detect_virt_product
    ov.DMESG_BOOT = 'tests/unittests/dmesg.boot'
    ov._get_file_content = get_file_content
    virtual_facts = ov.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'VirtualBox'
    assert virtual_facts

# Generated at 2022-06-23 02:27:54.518118
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Helper method to test get_virtual_facts of OpenBSDVirtual class
    """
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert len(virtual_facts['virtualization_tech_guest']) == 0
    assert len(virtual_facts['virtualization_tech_host']) == 0

    virtual_facts = OpenBSDVirtual(sysctl_values={'hw.vendor': 'VirtualBox',
                                                  'hw.product': ''}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert len(virtual_facts['virtualization_tech_host']) == 0

    virtual_facts = OpenBSDVirtual

# Generated at 2022-06-23 02:27:56.351000
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert isinstance(obj, OpenBSDVirtualCollector)


# Generated at 2022-06-23 02:28:09.677439
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Set facts
    openbsd_facts = {}
    openbsd_facts['kernel'] = 'OpenBSD'
    openbsd_facts['virtualization_product_name'] = 'VMware Virtual Platform'
    openbsd_facts['virtualization_type'] = ''
    openbsd_facts['virtualization_role'] = ''
    openbsd_facts['virtualization_product_version'] = ''
    openbsd_facts['virtualization_product_serial'] = ''
    openbsd_facts['virtualization_product_uuid'] = ''
    openbsd_facts['virtualization_product_vendor'] = ''
    openbsd_facts['virtualization_product_vendor_uc'] = ''

    # Set input
    openbsd_input = {}
    openbsd_input['sysctl_hw_product']

# Generated at 2022-06-23 02:28:17.345381
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()
    assert virt.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_product_vendor': '',
        'virtualization_product_host': '',
        'virtualization_product_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:28:19.985150
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:28:25.115813
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''

# Generated at 2022-06-23 02:28:28.457664
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    # Test for the default empty values
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''

# Generated at 2022-06-23 02:28:38.961654
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:28:50.345735
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Set up a fake hypervisor, and verify that get_virtual_facts finds it.
    """
    fake_system = 'OpenBSD'
    fake_product = 'VMware Virtual Platform'
    fake_vendor = 'VMware, Inc.'

    # Set up a fake hypervisor, and verify that get_virtual_facts finds it.
    class FakeOpenBSDVirtual(OpenBSDVirtual):
        def get_sysctl(self, sysctl_key):
            fake_hypervisor = {'hw.vendor': fake_vendor, 'hw.product': fake_product}
            return fake_hypervisor[sysctl_key]


# Generated at 2022-06-23 02:28:52.729950
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert isinstance(virt.facts, dict)
    assert virt.platform == 'OpenBSD'
    assert virt.system == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:28:54.766541
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj is not None


# Generated at 2022-06-23 02:28:57.786854
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    tech = OpenBSDVirtual().get_virtual_facts()
    assert len(tech['virtualization_tech_guest']) == 0 and len(tech['virtualization_tech_host']) == 0

# Generated at 2022-06-23 02:28:59.915307
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:29:00.364348
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    VirtualCollector()

# Generated at 2022-06-23 02:29:04.193140
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Unit test for constructor of class OpenBSDVirtualCollector."""

    # Check constructor without parameters
    obj = OpenBSDVirtualCollector()
    assert obj._platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDVirtual
    assert obj._fact_class._platform == 'OpenBSD'

# Generated at 2022-06-23 02:29:09.115136
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    virtual_facts = openbsd_virtual.get_virtual_facts()

    assert len(virtual_facts) > 0
    assert virtual_facts['virtualization_type'] in ['', 'vmm', 'docker']
    assert virtual_facts['virtualization_role'] in ['', 'host', 'guest']

# Generated at 2022-06-23 02:29:13.194289
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    data = {'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
            'virtualization_type': '',
            'virtualization_role': ''}

    vclass = OpenBSDVirtual()
    facts = vclass.get_virtual_facts()

    assert facts == data

# Generated at 2022-06-23 02:29:22.937668
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    def mock_detect_virt_vendor(k):
        return {'virtualization_type': 'vendor',
                'virtualization_role': 'guest',
                'virtualization_tech_guest': set(['vendor']),
                'virtualization_tech_host': set(['vendor'])}

    def mock_detect_virt_product(k):
        return {'virtualization_type': 'product',
                'virtualization_role': 'host',
                'virtualization_tech_guest': set(['product']),
                'virtualization_tech_host': set(['product'])}

    with open('tests/unit/module_utils/facts/virtual/test_openbsd') as f:
        dmesg_boot = f.read()


# Generated at 2022-06-23 02:29:33.546528
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    virtual_facts = openbsd_virtual.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type'] in ['', 'vmm']
    assert 'vmware' not in virtual_facts['virtualization_tech_guest']
    assert 'aws' not in virtual_facts['virtualization_tech_guest']
    assert 'vbox' not in virtual_facts['virtualization_tech_guest']
    assert 'parallels' not in virtual_facts['virtualization_tech_guest']
    assert 'xen' not in virtual_facts['virtualization_tech_guest']
    assert 'kvm' not in virtual_facts['virtualization_tech_guest']
    assert 'vmm' not in virtual_facts

# Generated at 2022-06-23 02:29:37.457393
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_collector = OpenBSDVirtualCollector()
    assert openbsd_collector._platform == "OpenBSD"
    assert openbsd_collector._fact_class._platform == "OpenBSD"

# Generated at 2022-06-23 02:29:40.858092
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._platform == 'OpenBSD'


# Generated at 2022-06-23 02:29:42.866565
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc.platform == 'OpenBSD'
    assert vc._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:29:50.740551
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test with OpenBSD 11
    openbsd_11_output = '''
product     (unknown)
hw.product  VirtualBox
hw.machine  amd64
hw.ncpu     1
hw.pagesize 4096
hw.vendor   innotek GmbH
hw.model    VirtualBox
hw.uuid     432a086f-48a8-42d6-9f7a-a9a8a62d50f0
hw.ncpufound 1
'''
    openbsd_11_virtual = OpenBSDVirtual(openbsd_11_output, 'amd64')

# Generated at 2022-06-23 02:29:54.244441
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd = OpenBSDVirtual()

    assert openbsd.get_virtual_facts() == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': ''
    }

# Generated at 2022-06-23 02:30:05.273522
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = {}
    virtual = OpenBSDVirtual(facts)
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    with open('/proc/cpuinfo', 'rb') as cpuinfo:
        virtual_facts_host = virtual_facts.copy()
        virtual_facts_host.update({
            'virtualization_type': '',
            'virtualization_role': 'host',
            'virtualization_tech_host': {'vmm'},
        })
        assert virtual.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:30:10.826198
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = OpenBSDVirtual({})
    assert ('virtualization_type' in facts.facts)
    assert ('virtualization_role' in facts.facts)
    assert ('virtualization_tech_guest' in facts.facts)
    assert ('virtualization_tech_host' in facts.facts)
    assert ('virtualization_facts_hw_product' in facts.facts)
    assert ('virtualization_facts_hw_vendor' in facts.facts)

# Generated at 2022-06-23 02:30:13.905768
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    if OpenBSDVirtualCollector.detect_virtual_fact_class():
        facter = OpenBSDVirtualCollector()
        fact = facter.collect()
        assert 'virtualization_role' in fact
        assert 'virtualization_tech_host' in fact

# Generated at 2022-06-23 02:30:24.436849
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Here are some examples of dmesg boot lines containing information
    # on virtualization type and role of the machine.
    dmesg_boot_lines = [
        'vmm0 at mainbus0: VMX/EPT',
        'vmm0 at mainbus0: VMX/RVI',
        'vmm0 at mainbus0: SVM/RVI',
        'vmm0 at mainbus0: SVM/EPT',
    ]
    # Create Virtual objects to test get_virtual_facts
    OpenBSDVirtual.DMESG_BOOT = '/dev/null'
    virtual_object = OpenBSDVirtual()
    virtual_facts = virtual_object.get_virtual_facts()

    # Default values
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:30:27.761163
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    We test that the constructor of the OpenBSDVirtual class works
    """
    obj = OpenBSDVirtual()
    assert obj is not None


# Generated at 2022-06-23 02:30:30.041514
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = VirtualCollector.create_virtual_instance()
    assert v.__class__.__name__ == 'OpenBSDVirtual'

# Generated at 2022-06-23 02:30:34.981385
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OPENBSD_HOST_VM = OpenBSDVirtual({})
    assert(OPENBSD_HOST_VM.get_virtual_facts() ==
        dict(virtualization_type='vmm',
            virtualization_role='host',
            virtualization_technologies=set(['vmm']),
            virtualization_tech_guest=set([]),
            virtualization_tech_host=set(['vmm'])))

# Generated at 2022-06-23 02:30:41.447204
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test 1: returns a dictionary containing the facts
    openbsd_virtual_info = OpenBSDVirtual()
    openbsd_virtual_info.collect()
    assert isinstance(openbsd_virtual_info.data, dict)

    # Test 2: the data returned by the facts is non-empty
    assert openbsd_virtual_info.data

# Generated at 2022-06-23 02:30:43.915854
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:45.965662
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._fact_class is OpenBSDVirtual
    assert vc._platform is 'OpenBSD'



# Generated at 2022-06-23 02:30:50.906893
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:52.794604
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert type(virtual_facts) is OpenBSDVirtual



# Generated at 2022-06-23 02:31:02.182958
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    def mock__fact_class_init(self, *args, **kwargs):
        # Test the value of the dmesg.boot file
        if args[0] == '/var/run/dmesg.boot':
            return 'vmm0 at mainbus0: VMX/EPT'
        else:
            return None

    def mock_detect_virt_vendor(self, *args, **kwargs):
        return {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
        }


# Generated at 2022-06-23 02:31:07.165150
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector(collect_only_if_present=True)
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._collect_only_if_present == True

# Generated at 2022-06-23 02:31:15.650582
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Test method get_virtual_facts of OpenBSDVirtual class.
    """
    vbsd = OpenBSDVirtual()
    virtual_facts = {'virtualization_type': 'vmm', 'virtualization_role': 'host',
                     'virtualization_tech_guest': {'vmm'}, 'virtualization_tech_host': {'vmm'},
                     'virtualization_product_name': '', 'virtualization_product_version': ''}
    assert virtual_facts == vbsd.get_virtual_facts()

# Generated at 2022-06-23 02:31:17.709922
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    fact_class = OpenBSDVirtual()
    if fact_class.platform != 'OpenBSD':
        raise AssertionError('Platform should be OpenBSD')

# Generated at 2022-06-23 02:31:20.114234
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector.fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:31:21.014746
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:31:33.346462
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:31:36.169435
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == OpenBSDVirtual.platform
    assert virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:31:44.002547
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import json
    from ansible.module_utils.facts.virtual import OpenBSDVirtual

    # Given a OpenBSD system
    # When I get the virtual facts of OpenBSDVirtual
    facts = OpenBSDVirtual().get_virtual_facts()

    # Then I see the virtual_facts is not empty
    assert facts
    json.dumps(facts)

# Generated at 2022-06-23 02:31:56.760236
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_obj = OpenBSDVirtual(module=None)

    # Test for VM Product
    # Test for VM Product where ldom comes in priority
    mock_virtual_product_facts_1 = {
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set(
            ['domu', 'xen', 'xen-domu', 'xen-domU', 'xen-dom0', 'dom0']),
        'virtualization_type': 'xen',
        'virtualization_role': 'guest'}

# Generated at 2022-06-23 02:31:58.248207
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd = OpenBSDVirtualCollector()
    assert openbsd

# Generated at 2022-06-23 02:32:00.923669
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual('collector')
    assert o.platform == 'OpenBSD'

    o = OpenBSDVirtual(['collector'])
    assert o.platform == 'OpenBSD'

# Generated at 2022-06-23 02:32:09.724148
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl = _get_sysctl_stub

    # Test case no virtualization
    facts = openbsd_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

    # Test case host
    openbsd_virtual.sysctl = _get_sysctl_stub_host
    facts = openbsd_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech_guest'] == set()
   

# Generated at 2022-06-23 02:32:11.444737
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()

    assert o._platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:32:13.027911
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._fact_class == OpenBSDVirtual
    assert vc._platform == 'OpenBSD'

# Generated at 2022-06-23 02:32:14.513219
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:32:18.773910
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    expected_fact_class = OpenBSDVirtual
    expected_platform = 'OpenBSD'
    vc_obj = OpenBSDVirtualCollector()
    assert vc_obj._fact_class == expected_fact_class
    assert vc_obj._platform == expected_platform

# Generated at 2022-06-23 02:32:23.515589
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert isinstance(collector, OpenBSDVirtualCollector)
    assert isinstance(collector._fact_class, OpenBSDVirtual)
    assert collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:32:27.645132
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # GIVEN a class
    openbsd = OpenBSDVirtual()
    # WHEN calling method get_virtual_facts
    facts = openbsd.get_virtual_facts()

    # THEN the facts returned should be the string that corresponds with
    # the parameters
    assert facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:32:37.556404
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # test_OpenBSDVirtual_obj initialization
    test_OpenBSDVirtual_obj = OpenBSDVirtual()

    # mock file content

# Generated at 2022-06-23 02:32:40.706862
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = Virtual({'module_setup': {'filter': '*'}})
    assert OpenBSDVirtual.platform == 'OpenBSD'
    assert virtual_facts.platform == 'OpenBSD'


# Generated at 2022-06-23 02:32:43.801884
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(module=None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:32:53.018560
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    # Prepare mocks for get_file_content and detect_virt_product

# Generated at 2022-06-23 02:32:56.790882
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc.platform == 'OpenBSD'
    assert vc.fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:33:00.722615
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.get_virtual_facts() == {'virtualization_role': '',
                                     'virtualization_type': '',
                                     'virtualization_tech_host': set(),
                                     'virtualization_tech_guest': set()}

# Generated at 2022-06-23 02:33:03.114171
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:05.784923
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual({})
    assert virtual.platform == "OpenBSD"


# Generated at 2022-06-23 02:33:08.839107
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:33:14.386145
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Verifies that the constructor of class OpenBSDVirtual
    """
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:33:16.530427
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    config = [1, 2]
    collector = OpenBSDVirtualCollector(config)
    assert isinstance(collector, OpenBSDVirtualCollector)
    assert collector._config == config

# Generated at 2022-06-23 02:33:27.291815
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    # OpenBSD, VMX/EPT
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_tech_guest': set(['vmware']),
        'virtualization_tech_host': set(['vmm']),
        'virtualization_type': 'vmm',
        'virtualization_role': 'host'
    }

    # OpenBSD, SVM/RVI
    virtual_facts = OpenBSDVirtual({'hw.vendor':'AuthenticAMD', 'hw.product':'AMD Opteron(TM) Processor 6272'})

# Generated at 2022-06-23 02:33:34.681591
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual({})
    virtual_facts = openbsd_virtual.get_virtual_facts()

    assert(virtual_facts['virtualization_type'] == '')
    assert(virtual_facts['virtualization_role'] == '')
    assert(virtual_facts['virtualization_tech_guest'] == set())
    assert(virtual_facts['virtualization_tech_host'] == set())


# Generated at 2022-06-23 02:33:41.830056
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt_facts = OpenBSDVirtual()
    assert virt_facts.platform == 'OpenBSD'
    assert virt_facts.DMESG_BOOT == '/var/run/dmesg.boot'
    assert virt_facts.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': {'hv'},
        'virtualization_tech_host': {'hv'}
    }


# Generated at 2022-06-23 02:33:43.451509
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual(None)
    assert virtual.platform.lower() == 'openbsd'

# Generated at 2022-06-23 02:33:52.542386
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()

    # Check that the code is still working if the files are empty or missing.
    virtual._get_file_content = lambda x: ''
    virtual_facts = virtual.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()



# Generated at 2022-06-23 02:34:03.347764
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:34:04.848588
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual(None).platform == 'OpenBSD'


# Generated at 2022-06-23 02:34:08.104915
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    ovs = OpenBSDVirtual()
    assert ovs.platform == 'OpenBSD'

# Generated at 2022-06-23 02:34:10.963277
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    # Return virtual_facts dictionary
    assert isinstance(openbsd_virtual_collector.get_virtual_facts(), dict)

# Generated at 2022-06-23 02:34:12.526143
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    result = OpenBSDVirtualCollector()
    assert result.platform == 'OpenBSD'