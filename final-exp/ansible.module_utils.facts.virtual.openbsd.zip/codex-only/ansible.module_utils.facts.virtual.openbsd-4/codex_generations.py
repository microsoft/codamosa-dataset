

# Generated at 2022-06-23 02:24:12.302565
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'


# Generated at 2022-06-23 02:24:15.406672
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'



# Generated at 2022-06-23 02:24:17.607365
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtualCollector().get_virtual_facts()
    assert virtual_facts['virtualization_type'] != ''

# Generated at 2022-06-23 02:24:27.277341
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # OpenBSDVirtual is instantiated with platform as OpenBSD
    openbsd_virtual = OpenBSDVirtual('OpenBSD')

    openbsd_virtual.sysctl_available = True
    openbsd_virtual.sysctl_output = {'hw.product': 'OpenBSD', 'hw.vendor': 'OpenBSD'}

    assert openbsd_virtual.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '',
                                                   'virtualization_tech_host': {'vmm'},
                                                   'virtualization_tech_guest': set()}

    openbsd_virtual.sysctl_output = {'hw.product': 'OpenBSD', 'hw.vendor': 'QEMU'}


# Generated at 2022-06-23 02:24:31.729000
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class.platform == 'OpenBSD'


# Generated at 2022-06-23 02:24:36.074132
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual({}, {})
    assert v.platform == 'OpenBSD'
    assert v.virttype == ''
    assert v.product == ''
    assert v.vendor == ''
    assert v.role == ''

    assert OpenBSDVirtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:24:37.973373
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Make sure, that no error is thrown, if all needed variables are set,
    with constructor
    """
    virtual_facts = OpenBSDVirtual()

# Generated at 2022-06-23 02:24:43.722853
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    vclass = OpenBSDVirtual()
    res = vclass.get_virtual_facts()
    assert "virtualization_role" in res
    assert "virtualization_type" in res
    assert "virtualization_tech_guest" in res
    assert "virtualization_tech_host" in res
    assert res["virtualization_type"] == ""
    assert res["virtualization_role"] == ""

# Generated at 2022-06-23 02:24:45.170380
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:24:47.602999
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual


# Generated at 2022-06-23 02:24:58.443956
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    hw_product_output = {
        'sysctl hw.product': 'VirtualBox\n'
    }
    hw_vendor_output = {
        'sysctl hw.vendor': 'innotek GmbH\n'
    }
    dmesg_boot_content = 'vmm0 at mainbus0: SVM/RVI'


# Generated at 2022-06-23 02:25:03.472521
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector_obj = OpenBSDVirtualCollector()
    assert virtual_collector_obj

# Generated at 2022-06-23 02:25:05.384652
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._platform == 'OpenBSD'


# Generated at 2022-06-23 02:25:10.371122
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual, OpenBSDVirtualCollector)
    assert openbsd_virtual._fact_class == OpenBSDVirtual
    assert openbsd_virtual._platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:13.127728
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    object = OpenBSDVirtualCollector()
    assert object.platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:14.646959
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    result = OpenBSDVirtualCollector()._platform
    assert result == 'OpenBSD'

# Generated at 2022-06-23 02:25:23.963342
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    class MockOpenBSDVirtual(OpenBSDVirtual):
        def __init__(self, module):
            pass

    os = MockOpenBSDVirtual(None)

    # Test empty data
    os.DETECT_VIRT_PRODUCT_CMD = ''
    os.DETECT_VIRT_VENDOR_CMD = ''
    facts = os.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert 'virtualization_tech_guest' not in facts
    assert 'virtualization_tech_host' not in facts

    # Test with output from product detection
    os.DETECT_VIRT_PRODUCT_CMD = 'virt_product: vmm'
    facts = os.get_virtual_facts()

# Generated at 2022-06-23 02:25:24.712028
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector() is not None

# Generated at 2022-06-23 02:25:33.691767
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    This test is to check the method get_virtual_facts of the class OpenBSDVirtual.
    """

    # gen_dmesg_boot file creation

# Generated at 2022-06-23 02:25:38.109518
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:25:39.624234
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o

# Generated at 2022-06-23 02:25:41.451118
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert isinstance(virtual, OpenBSDVirtual)
    assert isinstance(virtual, Virtual)

# Generated at 2022-06-23 02:25:53.620432
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a OpenBSDVirtual instance
    openbsdvirtual = OpenBSDVirtual({})

# Generated at 2022-06-23 02:25:58.187889
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:26:00.426773
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector(None, {})
    assert o.platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:26:05.531736
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    This test verifies if the constructor
    of the class OpenBSDVirtualCollector
    works.
    """

    # Create an object of class OpenBSDVirtualCollector
    opbsd_virtual_collector = OpenBSDVirtualCollector()
    assert opbsd_virtual_collector is not None
    assert opbsd_virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-23 02:26:07.951051
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:26:10.866648
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()

    assert collector._fact_class == OpenBSDVirtual
    assert collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:26:15.653520
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert isinstance(openbsd_virtual._platform, str)
    assert isinstance(openbsd_virtual._fact_class, str)
    assert len(openbsd_virtual._supported_facts) > 0

# Generated at 2022-06-23 02:26:19.180504
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:26:21.553204
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert c._fact_class is OpenBSDVirtual
    assert c._platform == 'OpenBSD'

# Generated at 2022-06-23 02:26:32.393105
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    module = 'OpenBSDVirtual'
    OpenBSDVirtual.DMESG_BOOT = '/tmp/dmesg.boot'

# Generated at 2022-06-23 02:26:33.789333
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:26:35.189551
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    # No return value because of subclass
    assert v is None

# Generated at 2022-06-23 02:26:35.735139
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    OpenBSDVirtual()

# Generated at 2022-06-23 02:26:40.567015
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-23 02:26:50.136771
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:26:59.542197
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    # Empty dictionary to store the results
    results = {}
    # Get the results of the function get_virtual_facts
    results = openbsd_virtual_facts.get_virtual_facts()

    # Assert facts that should be present in results.
    assert "virtualization_type" in results
    assert "virtualization_role" in results
    assert "virtualization_tech_guest" in results
    assert "virtualization_tech_host" in results

    # Assert values of virtualization_type
    assert results["virtualization_type"] in (
        '', 'hvm', 'openvz', 'para_virtualization', 'lxc', 'vserver',
        'zone', 'jail', 'xen', 'vmm')

    # Assert values of virtualization_

# Generated at 2022-06-23 02:27:00.291224
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:27:03.082414
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'


# Generated at 2022-06-23 02:27:05.940899
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    host_facts = OpenBSDVirtual().get_virtual_facts()
    assert host_facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:27:09.395323
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.is_openbsd()
    assert collector.get_virtual_facts() is not None


# Generated at 2022-06-23 02:27:12.463884
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:27:19.425457
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # This will be called by unittest through sysctl
    sysctl_mock = {
        'hw.product': 'IBM,32R1820',
        'hw.vendor': 'IBM Corporation'
    }

    virt = OpenBSDVirtual(sysctl_mock)

    assert virt.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

# Generated at 2022-06-23 02:27:29.011833
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # test vmware technology
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl_output['hw.vendor'] = 'VMware, Inc.'
    openbsd_virtual.sysctl_output['hw.product'] = 'VMware Virtual Platform'

    assert openbsd_virtual.get_virtual_facts()['virtualization_type'] == 'vmware'
    assert openbsd_virtual.get_virtual_facts()['virtualization_role'] == 'guest'

    # test hyper-v technology
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl_output['hw.vendor'] = 'Microsoft Corporation'
    openbsd_virtual.sysctl_output['hw.product'] = 'Virtual Machine'

    assert openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:27:38.012786
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-23 02:27:40.470111
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class == OpenBSDVirtual
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:27:43.628103
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == "OpenBSD"
    assert virtual_facts.DMESG_BOOT == "/var/run/dmesg.boot"

# Generated at 2022-06-23 02:27:46.427743
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Create an instance of OpenBSDVirtual class
    """
    openbsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-23 02:27:54.011300
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual({})
    virt._module.exit_json = lambda x: None
    virt._module.run_command = lambda a: (0, '', '')

    # check empty values as default
    expected_dict = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_product_guest': '',
        'virtualization_product_host': ''
    }

    # Set empty values as default
    virt.get_virtual_facts()
    assert virt.virtual_facts == expected_dict

# Generated at 2022-06-23 02:27:56.305908
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virt_fact = OpenBSDVirtualCollector()
    assert virt_fact._platform == 'OpenBSD'
    assert virt_fact._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:27:59.729412
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:28:02.032307
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    detect = OpenBSDVirtualCollector()
    assert detect.platform == 'OpenBSD'
    assert detect.fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:28:02.929419
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:28:09.626960
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''
    Testing method get_virtual_facts of class OpenBSDVirtual
    '''
    virtual_facts = OpenBSDVirtual()
    json_output = {
        "virtualization_type": "vmm",
        "virtualization_role": "host",
        "virtualization_tech_host": set(['vmm']),
        "virtualization_tech_guest": set(['kvm'])
    }
    assert virtual_facts.get_virtual_facts() == json_output

# Generated at 2022-06-23 02:28:12.438996
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector.platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:28:21.586134
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual('OpenBSD')
    openbsd_virtual.DMESG_BOOT = 'tests/unit/module_utils/facts/virtual/openbsd_dmesg_boot'
    openbsd_virtual.sysctl = {}
    openbsd_virtual.sysctl['hw.model'] = 'amd64'
    openbsd_virtual.sysctl['hw.product'] = 'VMware_VMware_VMware_VMware'
    openbsd_virtual.sysctl['hw.vendor'] = 'VMware_VMware_VMware_VMware'
    openbsd_virtual.sysctl['machdep.cpu_brand'] = 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'

# Generated at 2022-06-23 02:28:24.747850
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:28:27.903413
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:28:38.474186
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    expected_virtual_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmm',
        'virtualization_tech_guest': set(['vmm']),
        'virtualization_tech_host': set(['vmm'])}

    virtual_product_facts = {
        'virtualization_role': 'guest',
        'virtualization_type': 'vmm',
        'virtualization_tech_guest': set(['vmm']),
        'virtualization_tech_host': set(['vmm'])}


# Generated at 2022-06-23 02:28:46.495376
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    fake_sysctl_output = {
        "hw.vendor": "VMWare, Inc.",
        "hw.model": "VMware Virtual Platform",
        "hw.ncpu": "4",
        "hw.machine": "amd64"
    }

    fact_collector = OpenBSDVirtualCollector()
    fact_collector.get_sysctl_all_output = lambda: fake_sysctl_output
    virtual_facts = fact_collector.collect()

    assert virtual_facts['virtualization_type'] == 'vmware'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'vmware' in virtual_facts['virtualization_tech_guest']
    assert 'vmware' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:28:49.669640
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:28:53.995978
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Test class constructor"""

    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-23 02:28:55.777721
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vm = OpenBSDVirtualCollector()
    assert vm.platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:58.319683
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    f = OpenBSDVirtualCollector()
    assert isinstance(f, OpenBSDVirtualCollector)

# Generated at 2022-06-23 02:29:01.378757
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
  openbsd_virtual_test_obj = OpenBSDVirtual()
  result = openbsd_virtual_test_obj.get_virtual_facts()
  assert result['virtualization_type'] == ''

# Generated at 2022-06-23 02:29:02.789672
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()

    assert o
    assert o.platform == 'OpenBSD'

# Generated at 2022-06-23 02:29:05.811933
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module_created = OpenBSDVirtual({})
    assert module_created.platform == 'OpenBSD'
    assert module_created.DEFAULT_DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:29:15.604789
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import (
        OpenBSDVirtualCollector as Collector,
    )

    # Create the test case class
    class MyOpenBSDVirtual(Collector._fact_class):
        DMESG_BOOT = 'tests/unittests/fixtures/dmseg.boot'

    # Create the test case instance
    obj = MyOpenBSDVirtual()

    # Run the "get_virtual_facts" method
    results = obj.get_virtual_facts()

    # Assert the results match our expectations

# Generated at 2022-06-23 02:29:19.090881
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts_gen = OpenBSDVirtual.get_virtual_facts()
    virtual_facts_func = dict(OpenBSDVirtual().get_virtual_facts())
    assert sorted(virtual_facts_gen) == sorted(virtual_facts_func)

# Generated at 2022-06-23 02:29:20.065535
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:29:26.539628
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt_facts = OpenBSDVirtual()

    # Test the virtualization facts
    assert 'virtualization_type' in virt_facts.facts
    assert 'virtualization_role' in virt_facts.facts

    # Test for the expected virtualization_types
    assert virt_facts.facts['virtualization_type'] in ['', 'vmm']

    # Test for the expected virtualization_roles
    assert virt_facts.facts['virtualization_role'] in ['', 'guest', 'host']

# Generated at 2022-06-23 02:29:29.760270
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Given: Unmodified new instance of OpenBSDVirtual()
    openbsd_virtual = OpenBSDVirtual()

    # When: I get virtualization facts
    facts = openbsd_virtual.get_virtual_facts()

    # Then: I expect the returned dict to be not empty
    assert isinstance(facts, dict)
    assert facts != {}

# Generated at 2022-06-23 02:29:32.619074
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.platform == 'OpenBSD'
    assert o.fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:29:42.867275
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''
    Unit test for method get_virtual_facts of class OpenBSDVirtual
    '''
    # Dummy hw.product sysctl content
    hw_product_content = """
    Qemu Virtual CPU version 2.5+
    """

    # Dummy hw.vendor sysctl content
    hw_vendor_content = """
    QEMU
    """

    # Dummy dmesg.boot file content
    dmesg_boot_content = """
    vmm0 at mainbus0: SVM/RVI
    """

    openbsd_virtual = OpenBSDVirtual()
    # Set up the dummy sysctl content

# Generated at 2022-06-23 02:29:45.608390
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    expected_platform = 'OpenBSD'
    expected_virtual_fact = OpenBSDVirtual
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == expected_platform
    assert openbsd_virtual_collector._fact_class == expected_virtual_fact


# Generated at 2022-06-23 02:29:51.091252
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    sv = OpenBSDVirtual()
    assert sv.DMESG_BOOT == '/var/run/dmesg.boot'
    assert sv.platform is None
    assert sv.product_name is None
    assert sv.product_version is None
    assert sv.product_serial is None
    assert sv.product_uuid == ''
    assert sv.vendor_name == 'OpenBSD'


# Generated at 2022-06-23 02:30:02.617088
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    sysctl_results = {
        'hw.product': 'VirtualBox',
        'hw.vendor': 'Oracle Corporation'
    }


# Generated at 2022-06-23 02:30:12.701888
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual = OpenBSDVirtual()

    # Test case with empty values as default
    openbsd_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert(openbsd_facts == OpenBSDVirtual.get_virtual_facts())

    # Test case for VMM host/guest
    OpenBSDVirtual.DMESG_BOOT = '../test/test_data/OpenBSD/dmesg.boot'

# Generated at 2022-06-23 02:30:24.380372
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    v.vendors = { 'VMware, Inc.': { 'virtualization_types': ['vmware'],
                                    'virtualization_tech_guest': ['vmware'],
                                    'virtualization_tech_host': ['vmware']}}

    v.products = { 'VMware Virtual Platform': { 'virtualization_types': ['vmware'],
                                                'virtualization_tech_guest': ['vmware'],
                                                'virtualization_tech_host': ['vmware']}}

    # Test an OpenBSD virtual product.
    v.sysctl = { 'hw.product': 'VMware Virtual Platform' }

# Generated at 2022-06-23 02:30:25.706876
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:30:28.741106
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()

    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:30:29.756952
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector

# Generated at 2022-06-23 02:30:37.759342
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.utils import get_file_content

    # When OpenBSDVirtual.DMESG_BOOT contains 'vmm0 at mainbus0: SVM/RVI'
    OpenBSDVirtual.DMESG_BOOT = lambda: get_file_content("tests/unit/module_utils/facts/virtual/test_OpenBSDVirtual_get_virtual_facts_host")
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'vmm' in virtual_facts['virtualization_tech_host']

    # When OpenBSDVirtual.DMESG_BOOT contains 'vmm0 at mainbus0: VMX/EPT'

# Generated at 2022-06-23 02:30:39.536868
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), OpenBSDVirtualCollector)


# Generated at 2022-06-23 02:30:47.856642
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Prepare test values
    sample_vendor = 'OpenBSD'
    sample_product = 'VirtualBox'
    sample_sysctl_values = {'machdep.vmm.guest': '0',
                            'machdep.vmm.guest_device_model': '0'}
    # Create test object
    oVirtual = OpenBSDVirtual()
    oVirtual._sysctl_values = sample_sysctl_values
    oVirtual._test_vendor = sample_vendor
    oVirtual._test_product = sample_product
    # Run get_virtual_facts()
    virtual_facts = oVirtual.get_virtual_facts()
    # Check results

# Generated at 2022-06-23 02:30:49.609840
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), VirtualCollector), 'Failed to create instance of OpenBSDVirtualCollector'

# Generated at 2022-06-23 02:30:51.099868
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._platform == 'OpenBSD'

# Generated at 2022-06-23 02:30:53.338541
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:30:55.156119
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()

    assert(virtual_facts.platform == 'OpenBSD')



# Generated at 2022-06-23 02:30:58.170735
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual({},{},{})
    assert v.platform == 'OpenBSD'
    assert v.virtualization_type == ''
    assert v.virtualization_role == ''


# Generated at 2022-06-23 02:31:06.442403
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    # OpenBSDVirtual.detect_virt_product will return an empty dictionary
    # if hw.product is an empty string
    virtual.facts['hw.product'] = ''
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])
    assert virtual_facts['virtualization_tech_guest'] == set()



# Generated at 2022-06-23 02:31:14.572338
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # The constructor should set virtualization_type to '',
    # virtualization_role to '', and none of
    # virtualization_tech_guest, virtualization_tech_host to be set.
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-23 02:31:18.439189
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    test_virtual = OpenBSDVirtual()
    assert test_virtual.platform == 'OpenBSD'
    assert test_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert test_virtual.virtualization_type == ''
    assert test_virtual.virtualization_role == ''

# Generated at 2022-06-23 02:31:20.969522
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts_dict = {}
    collector = OpenBSDVirtualCollector(facts_dict, None)
    assert collector.platform == 'OpenBSD'


# Generated at 2022-06-23 02:31:23.195146
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual({})
    assert virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:31:34.795965
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Testcase is to check the output of
    get_virtual_facts() method of class OpenBSDVirtual.
    """
    obj = OpenBSDVirtual()
    # Generate dmesg.boot file used by the OpenBSDVirtual class
    # to detect virtualization
    dmesg_boot_file = open(OpenBSDVirtual.DMESG_BOOT, 'w')
    dmesg_boot_file.write('vmm0 at mainbus0: SVM/RVI\n')
    dmesg_boot_file.close()
    output = obj.get_virtual_facts()
    assert 'virtualization_type' in output
    assert output['virtualization_type'] == 'vmm'
    assert 'virtualization_role' in output
    assert output['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:31:43.047980
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    virtual_facts = {'virtualization_type': 'vmm',
                     'virtualization_role': 'host',
                     'virtualization_tech_host': {'vmm'},
                     'virtualization_tech_guest': set()}
    assert openbsd_virtual.get_virtual_facts() == virtual_facts

# Generated at 2022-06-23 02:31:45.775664
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    test_object = OpenBSDVirtual()
    assert test_object
    assert test_object.platform == 'OpenBSD'
    assert test_object.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:31:56.692548
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:31:58.610746
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:32:01.257923
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'


# Generated at 2022-06-23 02:32:06.251341
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_subtype == ''


# Generated at 2022-06-23 02:32:08.881072
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual._platform == "OpenBSD"
    assert virtual.platform == "OpenBSD"
    assert hasattr(virtual, 'get_virtual_facts')


# Generated at 2022-06-23 02:32:19.234318
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_platform = 'OpenBSD'
    test_host_tech = set()
    test_guest_tech = set()
    test_facts = { 'virtualization_type': '' }
    test_return = { 'virtualization_type': '', 'virtualization_role': '' }

    test_mock = {
        'hw.product': 'OpenBSD',
        'hw.vendor': 'OpenBSD',
        'cmdline.vm': 'false',
        'sysctl.xen': 'Xen/Xen/Xen',
        'sysctl.vm': 'VirtualBox'
    }

    test_obj = OpenBSDVirtual()
    test_obj.set_sysctl_info(test_mock)

    for key in test_mock.keys():
        test_obj.get_sysctl_info(key)

# Generated at 2022-06-23 02:32:21.251486
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:32:30.164356
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    # Set the DMESG_BOOT to the vmm test fixture.
    openbsd_virtual.DMESG_BOOT = 'unittests/fixtures/virtual/dmesg.boot.vmm'
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtual_facts['virtualization_role'] == 'host'
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == {'vmm'}


# Generated at 2022-06-23 02:32:36.693811
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class is OpenBSDVirtual
    assert openbsd_virtual_collector._platform is 'OpenBSD'

# Generated at 2022-06-23 02:32:39.884856
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:32:43.121509
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    detect = OpenBSDVirtual(None)
    # Test empty constructor
    assert detect.platform == 'OpenBSD'
    assert detect.virtualization_type == ''
    assert detect.virtualization_role == ''
    assert detect.virtualization_tech_guest is None

# Generated at 2022-06-23 02:32:45.526380
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = {}
    openbsd_virtual = OpenBSDVirtual(facts)
    assert openbsd_virtual.platform == 'OpenBSD'


# Generated at 2022-06-23 02:32:49.184605
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()
    facts = virt.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-23 02:32:56.156698
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:32:58.682671
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test if OpenBSDVirtualCollector returns a OpenBSDVirtual object
    obj = OpenBSDVirtualCollector()
    assert '_platform' in obj.__dict__

# Generated at 2022-06-23 02:33:06.494548
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:33:11.449688
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v_facts = OpenBSDVirtual().get_virtual_facts()

    assert v_facts['virtualization_type'] != ''
    assert v_facts['virtualization_role'] != ''
    assert len(v_facts['virtualization_tech_guest']) > 0

# Generated at 2022-06-23 02:33:22.117445
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual({})

    # Check for product vmm, which indicates we are a guest
    facts = {}
    openbsd_virtual._detect_virt_product = lambda *args: \
        {'virtualization_type': 'vmm',
        'virtualization_role': 'guest'}

    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts == {'virtualization_type': 'vmm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'vmm'},
        'virtualization_tech_host': set(),
        'virtualization_product_fact': None}

    # Check for vmm in dmesg.boot, which indicates we are a host
    openbsd_virtual._detect_virt

# Generated at 2022-06-23 02:33:26.002312
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual({}, {}, False)
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:33:32.204634
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """ Unit test for constructor of class OpenBSDVirtualCollector"""
    # check if OpenBSDVirtualCollector can be created
    openbsd_virtual_collector = OpenBSDVirtualCollector()

    assert openbsd_virtual_collector
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:33:35.654479
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    # Constructor of OpenBSDVirtual should set platform to OpenBSD
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:40.989697
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual.virtualization is None
    assert openbsd_virtual.virtual is None
    assert openbsd_virtual.detect() is None

# Generated at 2022-06-23 02:33:49.501953
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual._read_virtual_guest_info = lambda: {'Virtual': 'KVM'}
    assert openbsd_virtual.get_virtual_facts() == {
        'virtualization_type': 'KVM',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'KVM'},
        'virtualization_tech_host': set()
    }

    openbsd_virtual._read_virtual_guest_info = lambda: {'Virtual': ''}
    openbsd_virtual._read_virtual_host_info = lambda: {'ESX': 'VMware'}

# Generated at 2022-06-23 02:33:55.032187
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:34:05.117284
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Create the object
    obj = OpenBSDVirtual()

    # Check the default values for attributes
    assert obj.platform == 'OpenBSD'
    assert obj.virtualization_type == ''
    assert obj.virtualization_role == ''
    assert obj.virtualization_subtype == ''
    assert obj.virtualization_system == ''
    assert obj.virtualization_uuid == ''

    # Check the values assigned by the base class constructor
    assert obj.file_exists is not None
    assert obj.get_file_content is not None
    assert obj.grep is not None
    assert obj.search_file_content is not None
    assert obj.lsmod is not None
    assert obj.read_file is not None
    assert obj.sysctl is not None
    assert obj.cmdline is not None
    assert obj.sestatus

# Generated at 2022-06-23 02:34:10.276798
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdVirtual = OpenBSDVirtual(None)
    assert openbsdVirtual is not None
    assert openbsdVirtual.platform == 'OpenBSD'
    assert openbsdVirtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:34:13.896425
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Constructing a instance of class OpenBSDVirtualCollector
    """
    virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(virtual_collector, VirtualCollector)
    assert virtual_collector._platform == "OpenBSD"
