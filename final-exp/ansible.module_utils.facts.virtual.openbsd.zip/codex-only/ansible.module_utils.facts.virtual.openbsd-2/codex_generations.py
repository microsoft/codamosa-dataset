

# Generated at 2022-06-23 02:24:12.538132
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    instance = OpenBSDVirtualCollector()
    assert instance._platform == "OpenBSD"
    assert instance._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:24:19.285430
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # NOTE: These tests are incomplete and assume the hardware is virtualized.
    # Future improvements could include checking hardware using OpenBSD's
    # hw.product and hw.vendor sysctl variables.
    openbsd_virtual_facts = OpenBSDVirtual()
    virtual_facts = openbsd_virtual_facts.get_virtual_facts()

    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_role'] != ''

# Generated at 2022-06-23 02:24:22.371979
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    import sys
    import json
    sys.modules['_struct'] = None

    o = OpenBSDVirtual()
    facts = o.get_virtual_facts()

    json.dumps(facts)

# Generated at 2022-06-23 02:24:33.084805
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import json
    import os
    import sys
    import pytest

    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    import test_utils

    # Facts
    this_dir = os.path.dirname(__file__)
    facts_file = f'{this_dir}/../fixtures/OpenBSDVirtual_get_virtual_facts.json'
    facts_file = test_utils.get_abs_path(facts_file)  # do not depend on the current working directory
    with open(facts_file, encoding='utf-8') as f:
        facts = json.load(f)

    # Mocked methods
    VirtualSysctlDetectionMixin.detect_virt_product_

# Generated at 2022-06-23 02:24:36.247483
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts._platform == 'OpenBSD'
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''

# Generated at 2022-06-23 02:24:39.998912
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    tests the constructor of class OpenBSDVirtualCollector
    """
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector.fact_class is OpenBSDVirtual


# Generated at 2022-06-23 02:24:47.445426
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    if not isinstance(virtual_collector, VirtualCollector):
        raise AssertionError("OpenBSDVirtualCollector object has incorrect type")
    if virtual_collector.platform != 'OpenBSD':
        raise AssertionError("OpenBSDVirtualCollector has incorrect platform")
    if virtual_collector._fact_class != OpenBSDVirtual:
        raise AssertionError("OpenBSDVirtualCollector has incorrect fact_class")

# Generated at 2022-06-23 02:24:53.384930
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual(dict()).get_virtual_facts()

    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)
    assert isinstance(virtual_facts['virtualization_tech_guest'], set)
    assert isinstance(virtual_facts['virtualization_tech_host'], set)

# Generated at 2022-06-23 02:24:54.633319
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:24:56.252135
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:03.863320
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test data
    # Based on output of command "sysctl -a | grep '^hw.product\|^hw.vendor'"

    # Expected output for virtualization_type and virtualization_role
    expected_virtualization_type = 'hvm'
    expected_virtualization_role = 'guest'

    # Expected output for virtualization_tech_guest and virtualization_tech_host
    expected_virtualization_tech_guest = {'xen', 'vmm'}
    expected_virtualization_tech_host = set()

    # Expected output for virt_product_name and virt_vendor_name
    expected_virt_product_name = 'Xen PV'
    expected_virt_vendor_name = ''

    # Expected output for virt_product_version and virt_vendor_name
    expected_

# Generated at 2022-06-23 02:25:09.973117
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual({}, {}, {})
    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_product_name'] == ''
    assert facts['virtualization_product_version'] == ''
    assert facts['virtualization_product_vendor'] == ''
    assert facts['virtualization_product_host'] == ''
    assert facts['virtualization_product_guest'] == ''
    assert facts['virtualization_product_uuid'] == ''
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:25:15.008186
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    expected = 'OpenBSD'
    assert virtual_facts.platform == expected
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:25:20.269792
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual.DMESG_BOOT = './tests/dmesg_boot'
    v = OpenBSDVirtual()
    result = v.get_virtual_facts()
    assert result == {
        'virtualization_type': 'vmm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['vmm']),
        'virtualization_tech_host': set(['vmm'])
    }

# Generated at 2022-06-23 02:25:23.927715
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:25:26.911985
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsdVirtualCollector = OpenBSDVirtualCollector()
    assert openbsdVirtualCollector._fact_class == OpenBSDVirtual
    assert openbsdVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:29.533193
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:25:31.487083
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # There are no unit tests for this platform at the moment
    pass

# Generated at 2022-06-23 02:25:34.869213
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual = OpenBSDVirtualCollector()
    assert isinstance(virtual, VirtualCollector)
    assert isinstance(virtual._fact_class, OpenBSDVirtual)
    assert virtual._platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:39.508865
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:25:48.305129
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an OpenBSDVirtual object
    openbsd_virt = OpenBSDVirtual()

    # Add the virtualization_type key to the OpenBSDVirtual object
    openbsd_virt.virtual_facts['virtualization_type'] = 'bhyve'

    # Add the virtualization_role key to the OpenBSDVirtual object
    openbsd_virt.virtual_facts['virtualization_role'] = 'guest'

    # Add the virtualization_tech_guest key to the OpenBSDVirtual object
    openbsd_virt.virtual_facts['virtualization_tech_guest'] = 'bhyve'

    # Add the virtualization_tech_host key to the OpenBSDVirtual object
    openbsd_virt.virtual_facts['virtualization_tech_host'] = 'bhyve'

    # Get the virtual facts
    virtual_facts = open

# Generated at 2022-06-23 02:25:52.932361
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsdvirtualcollector = OpenBSDVirtualCollector()
    assert openbsdvirtualcollector._platform == 'OpenBSD'
    assert openbsdvirtualcollector._fact_class == OpenBSDVirtual
    assert isinstance(openbsdvirtualcollector._fact_class(), OpenBSDVirtual)


# Generated at 2022-06-23 02:25:53.975615
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:56.836636
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:26:01.684118
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    fake_sysctl_output = (b'hw.vendor=PCI\nhw.product=440BX Desktop Reference Platform', '')
    v = OpenBSDVirtual(fake_sysctl_output)

    assert v.platform == "OpenBSD"
    assert v.virtualization_type == "product"
    assert v.virtualization_role == "guest"

# Generated at 2022-06-23 02:26:04.453557
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual



# Generated at 2022-06-23 02:26:09.986978
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual._platform == 'OpenBSD'
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual._fact_class == OpenBSDVirtual
    assert openbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

# Generated at 2022-06-23 02:26:11.662893
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Make sure OpenBSDVirtualCollector can be instantiated.
    """
    assert OpenBSDVirtualCollector

# Generated at 2022-06-23 02:26:14.232077
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Return the OpenBSDVirtual instance.
    """
    return OpenBSDVirtual(None, None)

# Generated at 2022-06-23 02:26:18.270457
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_fact = OpenBSDVirtual()
    assert openbsd_virtual_fact.platform == 'OpenBSD'
    assert openbsd_virtual_fact.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:26:22.812508
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'vmm' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:26:33.496540
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetection
    from ansible.module_utils.facts.virtual.dmesg import OpenBSDDmesgDetectionMixin
    from ansible.module_utils.facts.virtual.dmesg import OpenBSDDmesgDetection

    openbsd_virtual = OpenBSDVirtual()

    # dmidecode not found
    openbsd_virtual.dmidecode_exists = False
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # d

# Generated at 2022-06-23 02:26:35.188478
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_obj = OpenBSDVirtual(None)
    virtual_obj.get_virtual_facts()

# Generated at 2022-06-23 02:26:38.989836
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:26:40.523184
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector is not None


# Generated at 2022-06-23 02:26:42.614247
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector.fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:26:43.693644
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual(None, {})

# Generated at 2022-06-23 02:26:48.038814
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()

    assert openbsd_virtual._platform == 'OpenBSD'
    assert openbsd_virtual._fact_class == OpenBSDVirtual
    assert isinstance(openbsd_virtual._virtual_facts, dict)
    assert openbsd_virtual._virtual_facts == dict()


# Generated at 2022-06-23 02:26:50.338899
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o._platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:26:52.695122
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    os = OpenBSDVirtualCollector()
    assert os._platform == 'OpenBSD'
    assert os._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:26:56.376036
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    x = OpenBSDVirtualCollector()
    y = x.get_virtual_facts()
    assert (y['virtualization_type'] == 'vmm' or
            y['virtualization_role'] == 'guest' or
            y['virtualization_role'] == 'host')

# Generated at 2022-06-23 02:26:58.351440
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdvirtual = OpenBSDVirtual()
    assert openbsdvirtual.platform == 'OpenBSD'


# Generated at 2022-06-23 02:27:05.694826
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """Test get_virtual_facts of OpenBSDVirtual class."""
    module = 'ansible.module_utils.facts.virtual.openbsd_virtual.OpenBSDVirtual'
    OpenBSDVirtual.init_cache(method_name='detect_virt_vendor',
                              method_class='ansible.module_utils.facts.virtual.openbsd_virtual.OpenBSDVirtual')
    OpenBSDVirtual.init_cache(method_name='detect_virt_product',
                              method_class='ansible.module_utils.facts.virtual.openbsd_virtual.OpenBSDVirtual')
    OpenBSDVirtual.init_cache(method_name='get_file_content',
                              method_class='ansible.module_utils.facts.virtual.base.Virtual')
    virtual = OpenBSDVirtual(module)
    virtual.init_cache

# Generated at 2022-06-23 02:27:16.352961
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual('/sbin')
    openbsd_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:27:25.740407
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:27:28.873112
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'
    assert virtual_collector.platforms == set(['OpenBSD'])

# Generated at 2022-06-23 02:27:31.441590
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-23 02:27:35.567444
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:27:41.583994
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test dictionary to be used as arguments in get_virtual_facts
    test_facts = {
            'virtualization_type': 'paravirtual',
            'virtualization_role': 'host'
    }
    # Expected result
    result = {
            'virtualization_type': 'paravirtual',
            'virtualization_role': 'host'
    }
    assert OpenBSDVirtual(test_facts).get_virtual_facts() == result

# Generated at 2022-06-23 02:27:51.329753
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test 1:
    # empty name should raise a ValueError exception
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualCollector
    try:
        OpenBSDVirtualCollector('')
    except ValueError as err:
        assert err.args[0] == "The value of 'name' must be a non-empty string"
    else:
        raise Exception('ValueError exception was not raised')

    # Test 2:
    # name with length of 1 should raise a ValueError exception
    try:
        OpenBSDVirtualCollector('o')
    except ValueError as err:
        assert err.args[0] == "The value of 'name' must be a non-empty string"
    else:
        raise Exception('ValueError exception was not raised')

    # Test 3:
    # name should be a string

# Generated at 2022-06-23 02:27:55.652234
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector
    o = OpenBSDVirtualCollector()
    assert o
    assert o._fact_class == OpenBSDVirtual
    assert o._platform == 'OpenBSD'


# Generated at 2022-06-23 02:27:57.133630
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert isinstance(obj._fact_class(obj), OpenBSDVirtual)

# Generated at 2022-06-23 02:27:58.434868
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual



# Generated at 2022-06-23 02:27:59.720420
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector.__name__ == 'OpenBSDVirtualCollector'

# Generated at 2022-06-23 02:28:01.306506
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    x = OpenBSDVirtualCollector()
    assert x.platform == 'OpenBSD'



# Generated at 2022-06-23 02:28:03.268324
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdvirt = OpenBSDVirtual({})
    assert openbsdvirt != None


# Generated at 2022-06-23 02:28:06.225956
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc.platform == 'OpenBSD'
    assert vc._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:28:08.092282
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()
    assert o.platform == 'OpenBSD'


# Generated at 2022-06-23 02:28:10.049927
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:14.599022
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_instance = OpenBSDVirtual(module=None)

    assert openbsd_virtual_instance.platform == 'OpenBSD'
    assert openbsd_virtual_instance.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:28:19.389150
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    host = OpenBSDVirtual()
    # Set empty values as default
    assert host.get_virtual_facts() == {'virtualization_type': '',
                                        'virtualization_role': '',
                                        'virtualization_tech_guest': set(),
                                        'virtualization_tech_host': set()}


# Unit tests for constructor of class OpenBSDVirtualCollector

# Generated at 2022-06-23 02:28:21.613496
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:28.916983
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual().get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech'] == set(['vmm'])
    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set(['vmm'])
    assert facts['virtualization_product_name'] == ''
    assert facts['virtualization_product_version'] == ''
    assert facts['virtualization_product_serial'] == ''
    assert facts['virtualization_product_uuid'] == ''
    assert facts['virtualization_vendor'] == ''

# Generated at 2022-06-23 02:28:31.286195
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    result = OpenBSDVirtualCollector()
    assert(result.platform == 'OpenBSD')
    assert(result._fact_class is OpenBSDVirtual)

# Generated at 2022-06-23 02:28:38.086681
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    module_mock = Mock()
    virtual = OpenBSDVirtual(module_mock)
    virtual._get_sysctl_virtualization_facts = Mock(return_value={})
    virtual._get_sysctl_vendor = Mock(return_value={})
    virtual._get_sysctl_product = Mock(return_value={})
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:28:40.728099
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts_collector = OpenBSDVirtualCollector('OpenBSD')
    assert(facts_collector.platform == 'OpenBSD')
    assert(facts_collector._fact_class == OpenBSDVirtual)


# Generated at 2022-06-23 02:28:43.002410
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Test OpenBSDVirtualCollector class"""
    facts = OpenBSDVirtualCollector()
    assert isinstance(facts, OpenBSDVirtualCollector)
    assert isinstance(facts._fact_class, OpenBSDVirtual)

# Generated at 2022-06-23 02:28:54.913285
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsdvirtual = OpenBSDVirtual()
    facts = openbsdvirtual.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_product_name'] == ''
    assert facts['virtualization_product_version'] == ''
    assert facts['virtualization_product_serial'] == ''
    assert facts['virtualization_product_uuid'] == ''
    assert facts['virtualization_host_product_name'] == ''
    assert facts['virtualization_host_product_version'] == ''
    assert facts['virtualization_host_product_serial'] == ''
    assert facts['virtualization_host_product_uuid'] == ''
    assert facts['virtualization_host_vendor'] == ''
    assert facts['virtualization_host_distro']

# Generated at 2022-06-23 02:28:56.834940
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    openbsd_virtual = OpenBSDVirtual('ssh')
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:29:00.123949
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:29:07.339188
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    '''
    Unit test for constructor of class OpenBSDVirtual
    '''
    virtual_facts = {}
    virtual_facts['virtualization_type'] = ''
    virtual_facts['virtualization_role'] = ''
    virtual_facts['virtualization_systems'] = set()

    virtual_facts['virtualization_tech_guest'] = set()
    virtual_facts['virtualization_tech_host'] = set()

    openbsd_virtual_test_obj = OpenBSDVirtual()
    assert (openbsd_virtual_test_obj.virtual_facts == virtual_facts)

# Generated at 2022-06-23 02:29:12.650827
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    facts = {}
    virtual.populate(facts)
    virtual = virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual
    assert 'virtualization_role' in virtual
    assert 'virtualization_tech' not in virtual
    assert 'virtualization_tech_guest' in virtual
    assert 'virtualization_tech_host' in virtual


# Generated at 2022-06-23 02:29:14.443042
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd = OpenBSDVirtualCollector()
    assert openbsd._platform == 'OpenBSD'

# Generated at 2022-06-23 02:29:17.465672
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = Virtual()
    OpenBSDVirtual(v)
    assert isinstance(v, OpenBSDVirtual)

# Generated at 2022-06-23 02:29:19.176754
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    "Create an instance of OpenBSDVirtualCollector"
    platform = 'OpenBSD'
    OpenBSDVirtualCollector(platform)

# Generated at 2022-06-23 02:29:21.838010
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:29:24.042683
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'



# Generated at 2022-06-23 02:29:25.721789
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facter = OpenBSDVirtualCollector(None, None)
    assert facter.platform == 'OpenBSD'

# Generated at 2022-06-23 02:29:28.358295
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    result = openbsd_virtual_facts.get_virtual_facts()
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result

# Generated at 2022-06-23 02:29:32.450525
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd = OpenBSDVirtual()
    output = {}
    output['virtualization_type'] = ''
    output['virtualization_role'] = ''
    output['virtualization_tech_guest'] = set()
    output['virtualization_tech_host'] = set()
    assert output == openbsd.get_virtual_facts()

# Generated at 2022-06-23 02:29:38.586632
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts_collection = OpenBSDVirtualCollector({}, {}).collect(None, None)
    virtual_facts = virtual_facts_collection['ansible_facts']['ansible_virtualization_facts']
    # Test required fields
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert len(virtual_facts['virtualization_tech_guest']) == 0
    assert len(virtual_facts['virtualization_tech_host']) == 0

# Generated at 2022-06-23 02:29:44.265141
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual._virtual_facts == {}


# Generated at 2022-06-23 02:29:48.115433
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert openbsd_virtual_facts.platform == 'OpenBSD'
    assert openbsd_virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:29:53.110750
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = {'hw.machine_arch': 'amd64'}
    f = OpenBSDVirtual(facts)
    result = f.get_virtual_facts()
    assert (result['virtualization_tech_guest']) == set()
    assert (result['virtualization_tech_host']) == set()
    assert (result['virtualization_type']) == ''
    assert (result['virtualization_role']) == ''


# Generated at 2022-06-23 02:29:55.977431
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    l = OpenBSDVirtualCollector()
    assert l.platform == 'OpenBSD'
    assert l._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:29:59.075291
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert isinstance(v, OpenBSDVirtual)
    assert isinstance(v, Virtual)
    assert isinstance(v, VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:30:03.424700
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual('hardware')
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-23 02:30:06.308549
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual(module=None)
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:30:15.493353
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    v.sysctl_outputs = {'hw.vendor': 'GenuineIntel', 'hw.product': 'QEMU Virtual CPU version 2.0'}
    assert v.get_virtual_facts() == {
        'virtualization_type': 'hvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['hvm']),
        'virtualization_tech_host': set(),
    }

    v = OpenBSDVirtual()
    v.sysctl_outputs = {'hw.vendor': 'OpenBSD Foundation', 'hw.product': 'amd64'}

# Generated at 2022-06-23 02:30:18.516577
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_openbsd = OpenBSDVirtual()
    assert virtual_openbsd
    assert virtual_openbsd.running_on_openbsd()


# Generated at 2022-06-23 02:30:22.423747
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert isinstance(obj, OpenBSDVirtualCollector)
    assert isinstance(obj._fact_class, OpenBSDVirtual)
    assert obj._platform == 'OpenBSD'



# Generated at 2022-06-23 02:30:32.564894
# Unit test for constructor of class OpenBSDVirtual

# Generated at 2022-06-23 02:30:44.760908
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test for detecting VM host
    openbsd_virtual_host = OpenBSDVirtual(None)
    facts = openbsd_virtual_host.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert 'vmm' in facts['virtualization_tech_host']

    # Test for detecting KVM VM
    openbsd_virtual_kvm = OpenBSDVirtual(None)
    openbsd_virtual_kvm.sysctl = {'hw.product': 'KVM'}
    facts = openbsd_virtual_kvm.get_virtual_facts()
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:30:47.206138
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    try:
        module = get_module_args()
        virtual = OpenBSDVirtual(module)
    except:
        assert False
    assert True


# Generated at 2022-06-23 02:30:59.042648
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    # If there is no virtualization technology, values should be empty.
    openbsd_virtual.get_file_lines = lambda _: []
    openbsd_virtual.sysctl_all = lambda: {}
    openbsd_virtual.lsdev = lambda _: {}
    assert openbsd_virtual.get_virtual_facts()['virtualization_type'] == ''
    assert openbsd_virtual.get_virtual_facts()['virtualization_role'] == ''

    # If dmesg says the host is capable of virtualization, detect host vmm.
    openbsd_virtual.get_file_lines = lambda _: ['vmm0 at mainbus0: SVM/RVI']

# Generated at 2022-06-23 02:31:05.819188
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()
    virtual_facts = virt.get_virtual_facts()

    # Check virtualization role and type
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

    if virtual_facts['virtualization_role'] == 'guest' or virtual_facts['virtualization_role'] == 'host':
        assert virtual_facts['virtualization_type'] == 'vmm'
    else:
        assert virtual_facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:31:13.809834
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Return the virtual facts of a OpenBSD system
    """

    class MockModule(object):
        def __init__(self):
            self.params = dict()

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception('fail_json')

    mock_module = MockModule()

    if not hasattr(mock_module, 'exit_args'):
        open_bsd_virtual_facts = OpenBSDVirtual(module=mock_module)
        open_bsd_virtual_facts.get_virtual_facts()

        assert mock_module.exit_args[0]['failed'] == False

# Generated at 2022-06-23 02:31:16.621650
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Test class constructor"""
    virtual_facts = OpenBSDVirtual()

    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:31:18.243217
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert isinstance(o._fact_class, OpenBSDVirtual)

# Generated at 2022-06-23 02:31:21.578889
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class is OpenBSDVirtual

# Generated at 2022-06-23 02:31:25.859850
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:31:36.670726
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = {}
    v = OpenBSDVirtualCollector(facts, None)

# Generated at 2022-06-23 02:31:49.129268
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.sysctl_machine_hw_model = 'OpenBSD'
    assert openbsd_virtual.get_virtual_facts() == {}

    openbsd_virtual.sysctl_machine_hw_vendor = 'OpenBSD'
    openbsd_virtual.sysctl_machine_hw_model = 'Virtual Machine'
    openbsd_virtual.sysctl_machine_hw_product = 'OpenBSD'

# Generated at 2022-06-23 02:32:00.336727
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_vm = OpenBSDVirtual({})

    # Test OpenBSD VM running on vmm
    openbsd_vm.facts = {
        'hw.vendor': 'OpenBSD',
        'hw.product': 'OpenBSD Virtual Machine',
        'hw.machine': 'amd64',
        'kern.vm_guest': 'openbsd',
    }
    facts = openbsd_vm.get_virtual_facts()
    assert 'openbsd' in facts['virtualization_type']
    assert 'guest' in facts['virtualization_role']
    assert 'openbsd' in facts['virtualization_tech_guest']
    assert 'vmm' in facts['virtualization_tech_host']

    # Test FreeBSD VM running on vmm

# Generated at 2022-06-23 02:32:09.329573
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsdvirtual = OpenBSDVirtual()

    # Initialize virtual facts content
    virtual_facts = {
        'virtualization_type' : '',
        'virtualization_role' : '',
        'virtualization_product' : '',
        'virtualization_vendor' : '',
        'virtualization_tech_guest' : set(),
        'virtualization_tech_host' : set(),
    }

    # Initialize DMESG_BOOT content

# Generated at 2022-06-23 02:32:11.041430
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:32:14.099443
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_openbsd = OpenBSDVirtualCollector()
    assert virtual_openbsd._platform == 'OpenBSD'
    assert virtual_openbsd._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:32:24.388417
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test ``virtualization_type`` and ``virtualization_role``
    # for OpenBSD host
    openbsd_host_virtual_facts = dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(['sysctl_hw_product', 'sysctl_hw_vendor']),
        virtualization_tech_host=set(['sysctl_hw_vendor'])
    )

    OpenBSDVirtual.detect_virt_vendor = lambda self, x: dict(virtualization_type='vmm',
                                                             virtualization_tech_host=set(['sysctl_hw_vendor', 'vmm']))


# Generated at 2022-06-23 02:32:28.977453
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """ Test constructor of class OpenBSDVirtualCollector """
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-23 02:32:30.619802
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert isinstance(v, OpenBSDVirtual)
    assert isinstance(v, Virtual)


# Generated at 2022-06-23 02:32:39.978591
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual(None)
    assert virtual.get_virtual_facts()['virtualization_type'] == 'vmm'
    assert virtual.get_virtual_facts()['virtualization_role'] == 'host'
    assert virtual.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert virtual.get_virtual_facts()['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-23 02:32:41.758004
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:32:51.781901
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:32:54.036734
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Unit test for constructor of class OpenBSDVirtualCollector"""
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:32:57.675627
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts._platform == 'OpenBSD'
    virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:33:00.386595
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:33:02.482796
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    x = OpenBSDVirtualCollector()
    assert x.platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:06.775409
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual._platform == 'OpenBSD'
    assert openbsd_virtual.virtualization_type == ''
    assert openbsd_virtual.virtualization_role == ''



# Generated at 2022-06-23 02:33:19.294243
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_mock = OpenBSDVirtual({})

# Generated at 2022-06-23 02:33:23.663315
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:33:29.178257
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_obj = OpenBSDVirtual()
    expected_virtual_facts = {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    assert openbsd_virtual_obj.get_virtual_facts() == expected_virtual_facts

# Generated at 2022-06-23 02:33:32.241612
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:33:40.800376
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert openbsd_virtual_facts.get_virtual_facts() == {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'vmm'},
        'virtualization_product_guest': '',
        'virtualization_product_host': '',
        'virtualization_product_version_guest': '',
        'virtualization_product_version_host': '',
    }

# Generated at 2022-06-23 02:33:43.933457
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._fact_class is OpenBSDVirtual
    assert vc._platform is 'OpenBSD'
    assert vc.include_200_platforms is True

# Generated at 2022-06-23 02:33:46.776334
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual({}).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:33:49.006558
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    class_obj = OpenBSDVirtualCollector()
    assert class_obj._platform == 'OpenBSD'
    assert class_obj._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:33:52.638148
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsdvirtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsdvirtual_collector._fact_class, OpenBSDVirtual)

# Generated at 2022-06-23 02:34:03.343775
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual.virtualization_type_facts == ['virt_type',  'virt_type_full']
    assert openbsd_virtual.virtualization_role_facts == ['role']
    assert openbsd_virtual.virtualization_sysctl_facts == ['hw.product', 'hw.vendor']
    assert openbsd_virtual.virtualization_additional_facts == ['virtualization_tech_guest', 'virtualization_tech_host']
    assert openbsd_virtual.virtualization_features_facts == ['features']

# Generated at 2022-06-23 02:34:04.345260
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert not virtual.virtual

# Generated at 2022-06-23 02:34:11.200198
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Arrange
    expected_conditional_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'vmm'}
    }

    # Act
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    actual_conditional_facts = openbsd_virtual_collector.collect()

    # Assert
    assert actual_conditional_facts == expected_conditional_facts