

# Generated at 2022-06-23 02:24:12.314593
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    d = OpenBSDVirtualCollector()
    assert d._platform == OpenBSDVirtualCollector._platform

# Generated at 2022-06-23 02:24:15.406457
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:24:21.734900
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = {}
    openbsd_virtual = OpenBSDVirtual(facts, [])
    assert openbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_product': '',
        'virtualization_system': '',
        'virtualization_uuid': '',
    }

# Generated at 2022-06-23 02:24:27.829588
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()

    # Check call to Virtual.__init__()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.virtinfo == {}
    assert openbsd_virtual.sysctl_mapping == {}


# Generated at 2022-06-23 02:24:35.414624
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    # Create a instance of class OpenBSDVirtual
    openbsd_virtual_object = OpenBSDVirtual()

    # Validate that the object is a instance of class OpenBSDVirtual
    assert isinstance(openbsd_virtual_object, OpenBSDVirtual)

    # Validate the attribute dmesg_boot_collector
    assert openbsd_virtual_object.DMESG_BOOT == '/var/run/dmesg.boot'

    # Validate the attribute platform
    assert openbsd_virtual_object.platform == 'OpenBSD'

# Generated at 2022-06-23 02:24:41.594676
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ""
    assert virtual_facts['virtualization_role'] == ""
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()
    return

# Generated at 2022-06-23 02:24:43.672879
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual({}).platform == 'OpenBSD'
    assert OpenBSDVirtual({}).virtualization_role == ''

# Generated at 2022-06-23 02:24:51.028110
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    openbsd_virtual = openbsd_virtual_collector.collect()

    assert openbsd_virtual['virtualization_type'] == 'vmm'
    assert openbsd_virtual['virtualization_role'] == 'host'
    assert 'virtualization_tech_guest' not in openbsd_virtual
    assert openbsd_virtual['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-23 02:24:58.677682
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    virtual_facts = openbsd_virtual_collector.get_virtual_facts()
    print(virtual_facts)

# Returns a dictionary containing some OS information if run as a script
if __name__ == '__main__':
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    virtual_facts = openbsd_virtual_collector.get_virtual_facts()
    for key in virtual_facts:
        print("{0}: {1}".format(key, virtual_facts[key]))

# Generated at 2022-06-23 02:25:04.775780
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual(module=None)
    virtual_facts_dict = openbsd_virtual.get_virtual_facts()
    assert virtual_facts_dict['virtualization_type'] == 'virtualbox'

# Generated at 2022-06-23 02:25:10.886982
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:25:15.577239
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    obj = OpenBSDVirtual()
    assert obj.DMESG_BOOT == '/var/run/dmesg.boot'
    assert obj.platform == 'OpenBSD'


# Generated at 2022-06-23 02:25:24.384619
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import os
    import unittest

    class TestModule(unittest.TestCase):
        def test_get_virtual_facts_OpenBSD_kvm_guest(self):
            mock_module = type('AnsibleModule', (object,), {'params': None, 'fail_json': type('compat_fail_json', (object,), {'__call__': lambda *a, **kw: a[0](*a[1:], **kw)})})
            virtual = OpenBSDVirtual(mock_module, {'sysctl': {'hw.product': "OpenBSD VirtualCPU", 'hw.vendor': 'GenuineIntel'}})
            virtual_facts = virtual.get_virtual_facts()
            assert virtual_facts['virtualization_type'] == 'kvm'
            assert virtual_facts['virtualization_role']

# Generated at 2022-06-23 02:25:26.482243
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_openbsd = OpenBSDVirtual()
    assert virtual_openbsd._platform == "OpenBSD"

# Generated at 2022-06-23 02:25:29.413019
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    # Test the get_virtual_facts() return value
    assert isinstance(openbsd_virtual.get_virtual_facts(), dict), 'get_virtual_facts() should return a dictionary'


# Generated at 2022-06-23 02:25:37.085652
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_name': None,
        'virtualization_product_version': None,
        'virtualization_product_serial': None,
        'virtualization_product_uuid': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:25:40.422487
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fact_class = OpenBSDVirtual
    platform = 'OpenBSD'
    obj = OpenBSDVirtualCollector(fact_class, platform)
    assert obj._fact_class == fact_class
    assert obj._platform == platform

# Generated at 2022-06-23 02:25:44.158559
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({}, None)
    assert openbsd_virtual
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:25:47.118337
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Unit test for constructor of class OpenBSDVirtual"""
    virt_facts_obj = OpenBSDVirtual()
    assert isinstance(virt_facts_obj._dmesg_boot, str)
    assert virt_facts_obj._platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:50.477979
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts = OpenBSDVirtualCollector({}, {}).collect()

    assert(facts['virtualization_type'] == 'vmm')
    assert(facts['virtualization_role'] == 'host')

# Generated at 2022-06-23 02:26:00.309420
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual(None)

    # Mock the Virtual.detect_virtual_product method
    product_attribute = 'hw.product'
    product_value = 'HVM domU'
    product_virtual_facts = {
        'virtualization_type': 'xen hvm',
        'virtualization_type_role': 'guest'
    }
    product_real_facts = openbsd_virtual.detect_virt_product(product_attribute)
    openbsd_virtual.detect_virt_product = MagicMock(return_value=product_virtual_facts)

    # Mock the Virtual.detect_virtual_vendor method
    vendor_attribute = 'hw.vendor'
    vendor_value = 'HVM domU'

# Generated at 2022-06-23 02:26:03.246008
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_test = OpenBSDVirtualCollector()
    assert openbsd_virtual_test._platform == 'OpenBSD'
    assert openbsd_virtual_test._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:26:07.011081
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # pylint: disable=protected-access
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._file_name == 'OpenBSDVirtualCollector'


# Generated at 2022-06-23 02:26:08.316855
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector()._fact_class is OpenBSDVirtual

# Generated at 2022-06-23 02:26:10.153808
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = OpenBSDVirtual()
    assert facts.virtualization_type is ''

# Generated at 2022-06-23 02:26:14.961428
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    inp_dict = {
        'hw.product': 'OpenBSD siemem-smp',
        'hw.vendor': 'OpenBSD'
    }
    vm = Virtual()
    facts = vm.get_facts(inp_dict)
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_product'] == 'OpenBSD'
    assert facts['virtualization_vendor'] == ''

# Generated at 2022-06-23 02:26:17.445967
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class is OpenBSDVirtual


# Generated at 2022-06-23 02:26:25.026206
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()

    # test for method get_collector_name
    assert (openbsd_virtual_collector.get_collector_name() ==
            "OpenBSDVirtualCollector")
    # test for method get_fact_class
    assert (openbsd_virtual_collector.get_fact_class() ==
            OpenBSDVirtual)
    # test for method get_platform
    assert openbsd_virtual_collector.get_platform() == "OpenBSD"

# Generated at 2022-06-23 02:26:35.114964
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test without any argument
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()
    # Test with arguments
    virtual_dict = dict(platform='Linux',
                        virtualization_type='vmm',
                        virtualization_role='host',
                        virtualization_tech_guest=set('vmm'),
                        virtualization_tech_host=set('vmm')
                       )
    virtual = OpenBSDVirtual(**virtual_dict)
    for key in virtual_dict:
        assert getattr(virtual, key) == virtual_dict[key]

# Generated at 2022-06-23 02:26:45.157121
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class BSDVirtual(Virtual):
        def get_file_content(self, filename):
            return get_file_content('unit/ansible/module_utils/facts/virtual/%s' % filename)

    openbsd_virtual = BSDVirtual(OpenBSDVirtual.platform)
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert sorted(virtual_facts['virtualization_role'].split(',')) == ['guest', 'host']
    assert sorted(virtual_facts['virtualization_type'].split(',')) == ['vmm']
    assert sorted(virtual_facts['virtualization_tech_guest']) == ['vmm', 'vxsim']
    assert sorted(virtual_facts['virtualization_tech_host']) == ['vmm']

# Generated at 2022-06-23 02:26:48.038189
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert isinstance(collector, VirtualCollector)
    assert hasattr(collector, '_fact_class')
    assert hasattr(collector, '_platform')

# Generated at 2022-06-23 02:26:58.231581
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:26:59.744232
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:27:08.202848
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    ''' Unit test for method get_virtual_facts of class OpenBSDVirtual '''

    def get_file_content_mock(filename):
        ''' Mock method for get_file_content '''

# Generated at 2022-06-23 02:27:10.521526
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:27:13.145104
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'
    assert v.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:27:16.096904
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector(None, None, None)
    assert isinstance(openbsd_virtual._fact_class, OpenBSDVirtual)
    assert openbsd_virtual._platform == 'OpenBSD'

# Generated at 2022-06-23 02:27:19.592982
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'
    assert v.DMESG_BOOT == '/var/run/dmesg.boot'

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 02:27:26.377314
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(module=None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual.VIRT_SYSCTL_KEY == 'machdep.vm_guest'
    assert openbsd_virtual.VIRT_DETECTION_ORDER == 'hw.product hw.vendor'
    assert openbsd_virtual.VIRT_PRODUCT_MAPPING == {'OpenBSD': 'OpenBSD'}

# Generated at 2022-06-23 02:27:29.893303
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_facts = OpenBSDVirtualCollector(None, None, None, None)
    assert openbsd_facts._fact_class is OpenBSDVirtual
    assert openbsd_facts._platform is 'OpenBSD'


# Generated at 2022-06-23 02:27:31.046698
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    f_class = OpenBSDVirtual()
    f_class.get_virtual_facts()

# Generated at 2022-06-23 02:27:43.453290
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:27:52.618666
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    def test_virt(lines, host_virtualization_type, host_virtualization_role, virtualization_tech_guest, virtualization_tech_host):
        collector = OpenBSDVirtualCollector()
        collector.DMESG_BOOT = lines
        facts = collector._get_virtual_facts()

        assert facts['virtualization_type'] == host_virtualization_type
        assert facts['virtualization_role'] == host_virtualization_role
        assert facts['virtualization_tech_guest'] == set(virtualization_tech_guest)
        assert facts['virtualization_tech_host'] == set(virtualization_tech_host)


# Generated at 2022-06-23 02:27:55.400147
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'


# Generated at 2022-06-23 02:27:58.666928
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    This function enables unit test for the class
    OpenBSDVirtualCollector
    """
    openbsd_virtual = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual, VirtualCollector)
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:00.303127
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:28:04.416576
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Tests the constructor of class OpenBSDVirtualCollector"""
    assert hasattr(OpenBSDVirtualCollector, '_fact_class')
    assert hasattr(OpenBSDVirtualCollector, '_platform')
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:06.597272
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'


# Generated at 2022-06-23 02:28:07.562745
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:28:10.241528
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts()['virtualization_type'] == ''



# Generated at 2022-06-23 02:28:19.437365
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts_test = OpenBSDVirtual(None)
    assert 'OpenBSD' == virtual_facts_test.platform
    assert 'hw.product' == virtual_facts_test.SYSTEM_PRODUCT
    assert 'hw.vendor' == virtual_facts_test.SYSTEM_VENDOR
    assert '/var/run/dmesg.boot' == virtual_facts_test.DMESG_BOOT
    assert 'OpenBSD virtualization detection via sysctl' == virtual_facts_test.detect_virt_product.__doc__
    assert 'OpenBSD virtualization detection via sysctl' == virtual_facts_test.detect_virt_vendor.__doc__
    assert 'Run all subclass virtualization detection methods' == virtual_facts_test.get_virtual_facts.__doc__

# Generated at 2022-06-23 02:28:30.697184
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdvirtual = OpenBSDVirtual()
    # Asserts the correct platform is detected
    assert openbsdvirtual.platform == 'OpenBSD'

    # Assert virtualization facts are empty by default
    assert openbsdvirtual.get_virtual_facts() == {'virtualization_role': '',
                                                  'virtualization_type': '',
                                                  'virtualization_tech_host': set(),
                                                  'virtualization_tech_guest': set()}

    # Assert virtual product can be detected
    openbsdvirtual = OpenBSDVirtual(facts={'hw.product': 'OpenBSD OpenVM'})

# Generated at 2022-06-23 02:28:33.983625
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Initialize object
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector != None, "Object OpenBSDVirtualCollector was not initialized"


# Generated at 2022-06-23 02:28:36.578958
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class == OpenBSDVirtual
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:44.824549
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:28:47.683665
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:28:57.435892
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with kvm and host role
    kvm = VirtualCollector("OpenBSD")

# Generated at 2022-06-23 02:29:07.740725
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test case where the 'hw.product' sysctl is set
    ov = OpenBSDVirtual()
    ov.sysctl_values = {'hw.product': 'OpenBSD Virtual Machine'}
    facts = ov.get_virtual_facts()
    assert facts['virtualization_type'] == 'openbsd'
    assert facts['virtualization_role'] == 'guest'
    assert 'openbsd' in facts['virtualization_tech_guest']

    # Test case where the 'hw.product' sysctl is not set
    ov = OpenBSDVirtual()
    ov.sysctl_values = {}
    facts = ov.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert 'openbsd' not in facts['virtualization_tech_guest']



# Generated at 2022-06-23 02:29:09.741173
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts_module = OpenBSDVirtualCollector(None, None)

# Generated at 2022-06-23 02:29:19.376987
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:29:22.487290
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert VirtualCollector._get_platform_subclass(OpenBSDVirtualCollector.platform)().__class__ == OpenBSDVirtualCollector

# Generated at 2022-06-23 02:29:30.277351
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    ######################################################################
    # Sample data

    # Data from hw.product
    hw_product = frozenset(["VirtualBox", "VirtualBox", "VirtualBox", "Acer Incorporated [ALI]|HG-181", "OpenBSD BOOTB", "Virtual Machine"])

    # Data from hw.vendor
    hw_vendor = frozenset(["", "", "", "Acer Incorporated [ALI]|HG-181", "OpenBSD BOOTB", "Virtual Machine"])

    # Data from dmesg.boot

# Generated at 2022-06-23 02:29:41.216960
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    sysctl = VirtualSysctlDetectionMixin()
    openbsd_virtual = OpenBSDVirtual('', '')

    # Set various sysctl 'facts'
    sysctl.facts = {'hw.vendor': 'QEMU',
                    'hw.product': 'Standard PC (i440FX + PIIX, 1996)',
                    'hw.machine': 'amd64'}

    # Save the original sysctl 'facts'
    orig_sysctl_facts = sysctl.facts

    # Try to get the facts
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()

    # Check if the facts are what is expected
    assert openbsd_virtual_facts['virtualization_type'] == 'hvm'

# Generated at 2022-06-23 02:29:44.884273
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtualcollector = OpenBSDVirtualCollector()
    assert openbsd_virtualcollector._platform == 'OpenBSD'
    assert openbsd_virtualcollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:29:45.988965
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:29:48.826372
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    obj = OpenBSDVirtual(None)

    assert obj.platform == 'OpenBSD'
    assert obj.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:29:50.883161
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert collector.platform == 'OpenBSD'

# Generated at 2022-06-23 02:29:54.077054
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual({})
    virtual.collect()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert isinstance(virtual_facts['virtualization_type'], str)
    assert isinstance(virtual_facts['virtualization_role'], str)

# Generated at 2022-06-23 02:29:57.481382
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert (obj is not None), "Unable to instantiate OpenBSDVirtualCollector"
    assert isinstance(obj._fact_class, OpenBSDVirtual), \
        "Invalid type for OpenBSDVirtualCollector._fact_class"
    assert obj._platform == 'OpenBSD', \
        "Invalid value for OpenBSDVirtualCollector._platform"


# Generated at 2022-06-23 02:30:00.723115
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()

    assert virtual_collector._platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:06.667044
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class.platform == 'OpenBSD'
    assert collector._fact_class.DMESG_BOOT == '/var/run/dmesg.boot'
    assert type(collector._fact_class.get_virtual_facts()) == dict


# Generated at 2022-06-23 02:30:09.541290
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Unit test for constructor of class OpenBSDVirtualCollector"""
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'


# Generated at 2022-06-23 02:30:11.962096
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual({})
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:30:16.579382
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.virtualization_type == ''
    assert virt.virtualization_role == ''

# Generated at 2022-06-23 02:30:25.283365
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    test_virtual_facts = OpenBSDVirtual()
    assert test_virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }

    # Mock detect_virt_product

# Generated at 2022-06-23 02:30:29.883845
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Verify we can create an instance of OpenBSDVirtualCollector
    """
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual_collector, OpenBSDVirtualCollector)

# Generated at 2022-06-23 02:30:37.845150
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    supported_facts_class = OpenBSDVirtual
    supported_facts_platform = 'OpenBSD'


# Generated at 2022-06-23 02:30:43.798858
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual({})
    virtual.dmesg_boot_data = [
        'vmm0 at mainbus0: SVM/RVI',
        'vmm1 at mainbus0: VMX/EPT',
        'vmm2 at mainbus0: unknown capability'
    ]
    expected_result = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_host': set(['vmm']),
        'virtualization_tech_guest': set()
    }
    result = virtual.get_virtual_facts()
    assert result == expected_result, result

# Generated at 2022-06-23 02:30:55.250692
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual

# Generated at 2022-06-23 02:31:04.741487
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.product = 'OpenBSD Virtual Machine'
    openbsd_virtual.vendor = 'OpenBSD'
    test_cases = [
        (
            openbsd_virtual.get_virtual_facts(),
            {
                'virtualization_tech_guest': set(['openbsd']),
                'virtualization_tech_host': set(['vmm']),
                'virtualization_type': 'vmm',
                'virtualization_role': 'guest'
            }
        )
    ]
    for (test_input, expected_output) in test_cases:
        assert test_input == expected_output, 'Expected: %s, got: %s' % (expected_output, test_input)


# Generated at 2022-06-23 02:31:07.065463
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector(None)
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:31:11.084888
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj
    assert obj._fact_class == OpenBSDVirtual
    assert obj._platform == 'OpenBSD'

# Generated at 2022-06-23 02:31:20.402134
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual({})
    v.detect_virt_vendor = lambda x: {
        'virtualization_type': 'vmm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    v.detect_virt_product = lambda x: {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-23 02:31:23.304690
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-23 02:31:27.627926
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    result = OpenBSDVirtualCollector()
    assert isinstance(result, OpenBSDVirtualCollector)
    assert isinstance(result._fact_class, OpenBSDVirtual)
    assert result._platform == 'OpenBSD'

# Generated at 2022-06-23 02:31:37.046182
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts_dict = {
        'virtualization_func': 'guest',
        'virtualization_role': 'guest',
        'virtualization_type': 'vmm',
        'virtualization_tech_guest': {'vmm'},
        'virtualization_tech_host': set(),
        'virtualization_product': 'OpenBSD VM',
        'virtualization_vendor': 'OpenBSD'
    }
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts = MagicMock(return_value=openbsd_virtual_facts_dict)
    assert openbsd_virtual.get_virtual_facts() == openbsd_virtual_facts_dict

# Generated at 2022-06-23 02:31:46.707784
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual(None, None).get_virtual_facts()

    # Check the virtualization_tech keys are populated and
    # that the values are sets.
    assert 'virtualization_tech_guest' in facts
    assert isinstance(facts['virtualization_tech_guest'], set)
    assert 'virtualization_tech_host' in facts
    assert isinstance(facts['virtualization_tech_host'], set)

    # Check the virtualization_type is set and that it is one of the
    # expected values.
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] in ['', 'vmm']

    # Check the virtualization_role is set and that it is one of the
    # expected values.
    assert 'virtualization_role' in facts

# Generated at 2022-06-23 02:31:48.241092
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._fact_class

# Generated at 2022-06-23 02:31:49.706026
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o is not None

# Generated at 2022-06-23 02:31:55.022021
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    fact = OpenBSDVirtual()
    facts = fact.get_virtual_facts()
    assert('virtualization_type' in facts)
    assert('virtualization_role' in facts)
    assert('virtualization_technologies_guest' in facts)
    assert('virtualization_technologies_host' in facts)

# Generated at 2022-06-23 02:31:59.921772
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] in ['', 'virtualbox', 'vmm']
    assert virtual_facts['virtualization_role'] in ['', 'guest', 'host']
    assert virtual_facts['virtualization_role'] != 'guest' or virtual_facts['virtualization_type'] != 'vmm'

# Generated at 2022-06-23 02:32:08.525057
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    result = openbsd_virtual.get_virtual_facts()

    assert (result['virtualization_type'] == 'vmm' or result['virtualization_type'] == '')

    if result['virtualization_type'] == 'vmm':
        assert result['virtualization_role'] == 'host'
        assert result['virtualization_tech_host'] == set('vmm')
    else:
        assert result['virtualization_role'] == ''
        assert result['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:32:19.063838
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual and run method get_virtual_facts.
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()

    # Unit test for virtualization_type.
    openbsd_virtualization_type = openbsd_virtual_facts['virtualization_type']
    if openbsd_virtualization_type == '':
        assert openbsd_virtualization_type == ''
    elif openbsd_virtualization_type == 'vmm':
        assert openbsd_virtualization_type == 'vmm'

    # Unit test for virtualization_role.
    openbsd_virtualization_role = openbsd_virtual_facts['virtualization_role']

# Generated at 2022-06-23 02:32:24.404351
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual.virt_what == {}


# Generated at 2022-06-23 02:32:27.237192
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()

    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:32:30.546044
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:32:41.428862
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # TODO: Fix the tests to work with Python 3 (python-future)
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.collect()
    openbsd_virtual_facts = openbsd_virtual.get_facts()
    assert 'virtualization_role' in openbsd_virtual_facts
    assert 'virtualization_type' in openbsd_virtual_facts
    assert 'virtualization_role' in openbsd_virtual_facts
    assert 'virtualization_type' in openbsd_virtual_facts

# Generated at 2022-06-23 02:32:51.529465
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with a OpenBSD VirtualBox virtual machine
    vm_virtual_facts = dict(virtualization_type='',
                            virtualization_role='guest')
    openbsd_virt = OpenBSDVirtual({'ansible_facts': dict(dmesg_boot='vmm0 at mainbus0: VirtualBox\n')})
    virtual_facts = dict(openbsd_virt.get_virtual_facts())
    assert vm_virtual_facts == virtual_facts

    # Test with a OpenBSD VirtualBox host
    host_virtual_facts = dict(virtualization_type='vmm',
                              virtualization_role='host')
    openbsd_host = OpenBSDVirtual({'ansible_facts': dict(dmesg_boot='vmm0 at mainbus0: SVM/RVI\n')})
    virtual_facts = dict

# Generated at 2022-06-23 02:32:53.484698
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:32:56.250039
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    require_only_one_instance_of_class(OpenBSDVirtualCollector)

# Generated at 2022-06-23 02:32:59.559221
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    v = OpenBSDVirtual(None)
    # Default result is False
    assert(v.is_openbsd_virtual() is False)
    assert(v.is_openbsd_virtual('boolean') is True)

# Generated at 2022-06-23 02:33:11.414714
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Initialize target class
    virtual_facts = OpenBSDVirtual()

    # OpenBSD VirtualizationType fact
    # sysctl 'hw.product' output:
    # hw.product=VirtualBox
    virtual_facts.sysctl_output = {'hw.product': 'VirtualBox'}
    assert virtual_facts.get_virtual_facts() == {'virtualization_type': 'virtualbox', 'virtualization_role': ''}

    virtual_facts.sysctl_output = {'hw.product': 'innotek GmbH VirtualBox'}
    assert virtual_facts.get_virtual_facts() == {'virtualization_type': 'virtualbox', 'virtualization_role': ''}

    virtual_facts.sysctl_output = {'hw.product': 'KVM'}

# Generated at 2022-06-23 02:33:13.153862
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)

# Generated at 2022-06-23 02:33:14.697790
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:33:25.007206
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Test case 1:
    # Test case with no virtualization_type, no virtualization_role,
    # and no virtualization_tech_guest and no virtualization_tech_host
    dmesg_boot_content = '''
vmm0 at mainbus0: VMX/EPT
'''
    sysctl_hw_product_content = '''
hw.product=VMWare Virtual Platform
'''
    sysctl_hw_vendor_content = '''
hw.vendor=VMware, Inc.
'''
    openbsd_virtual = OpenBSDVirtual('bsd', collect_fallback=False)

# Generated at 2022-06-23 02:33:29.127020
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class.platform == OpenBSDVirtual.platform
    assert openbsd_virtual_collector._platform == OpenBSDVirtualCollector._platform

# Generated at 2022-06-23 02:33:35.517823
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test for default values for empty OpenBSDVirtual object
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-23 02:33:37.576088
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:42.946251
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    '''OpenBSDVirtual.__init__()'''
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:33:44.819897
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual._fact_class is OpenBSDVirtual


# Generated at 2022-06-23 02:33:50.887165
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(['virtualbox']),
        'virtualization_tech_host': set(['virtualbox'])
    }

# Generated at 2022-06-23 02:33:53.209882
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector
    assert virtual_collector.platform == 'OpenBSD'
    assert virtual_collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:33:57.950705
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual_collector, VirtualCollector)
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:34:00.032897
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual(None)
    assert virtual
    assert virtual._collector_platform == 'OpenBSD'
    assert virtual._platform == 'OpenBSD'


# Generated at 2022-06-23 02:34:09.687042
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """Unit test for method get_virtual_facts of class OpenBSDVirtual"""
    virt = OpenBSDVirtual(module=None)
    # fake the sysctl product detection
    virt.get_file_content = lambda _: 'OpenBSD.amd64'
    # fake the sysctl vendor detection
    virt.get_cmd_output = lambda _: 'GenuineIntel'
    # fake the dmesg detection
    virt.get_file_lines = lambda _: ['vmm0 at mainbus0: SVM/RVI']
    result = virt.get_virtual_facts()
    assert result['virtualization_type'] == 'vmm'


# Generated at 2022-06-23 02:34:11.267745
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual