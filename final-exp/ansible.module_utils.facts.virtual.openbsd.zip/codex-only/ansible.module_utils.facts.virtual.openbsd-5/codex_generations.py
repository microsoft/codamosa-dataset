

# Generated at 2022-06-23 02:24:11.384090
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
  vc = OpenBSDVirtualCollector()
  assert vc._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:24:21.988741
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

# Generated at 2022-06-23 02:24:24.424303
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'

# Generated at 2022-06-23 02:24:27.302742
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector != None
    assert isinstance(collector, OpenBSDVirtualCollector)


# Generated at 2022-06-23 02:24:34.807138
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Remove all facts under 'virtualization'
    virtual = OpenBSDVirtual()
    facts = virtual.get_virtual_facts()
    assert (facts['virtualization_tech_guest']) == set()
    assert (facts['virtualization_tech_host']) == set()
    assert (facts['virtualization_type']) == ''
    assert (facts['virtualization_role']) == ''
    assert (facts['virtualization_system']) == ''
    assert (facts['virtualization_product_name']) == ''

# Generated at 2022-06-23 02:24:37.613515
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtualFactCollector()
    virtual_facts.collect()
    assert_equals(virtual_facts.virtual.platform, 'OpenBSD')
    assert_equals(virtual_facts.virtual.virtualization_type, 'vmm')

# Generated at 2022-06-23 02:24:39.357594
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Unit test for constructor of class OpenBSDVirtual"""
    vm = OpenBSDVirtual()
    assert vm.platform == 'OpenBSD'


# Generated at 2022-06-23 02:24:41.652894
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual('OpenBSD')
    assert o.get_virtual_facts() == {}

# Generated at 2022-06-23 02:24:44.250980
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts
    assert isinstance(virtual_facts, Virtual)
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:24:49.882767
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """Test that we properly set the virtual facts for OpenBSD hosts."""
    o = OpenBSDVirtual({})
    assert o.get_virtual_facts() == {'virtualization_role': '',
                                     'virtualization_type': '',
                                     'virtualization_tech_guest': set(),
                                     'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:24:59.649873
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    dmesg_boot = '''vscsi0 at root
scsibus0 at vscsi0: 256 targets
softraid0 at root
sd0 at scsibus0 targ 0 lun 0: <QEMU, QEMU HARDDISK, 2.5+> SCSI0 0/direct fixed
sd0: 3961MB, 512 bytes/sector, 8044544 sectors
boot device: <unknown>
root on sd0a (b792f7cbc0671e43.a) swap on sd0b dump on sd0b
vmm0 at mainbus0: SVM/RVI
'''

    with open('/tmp/dmesg.boot', 'w') as dmesg_file:
        dmesg_file.write(dmesg_boot)

    virtual = OpenBSDVirtual()
    virtual.get_virtual

# Generated at 2022-06-23 02:25:06.827198
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    openbsd_virtual = OpenBSDVirtual(module=None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.paths == dict(sysctl='/sbin/sysctl',
                                         lscpu=None,
                                         dmidecode=None,
                                         dmesg=None,
                                         lsmod=None)


# Generated at 2022-06-23 02:25:10.125489
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc.platform == 'OpenBSD'
    assert vc._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:25:16.135608
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Always returns empty dict.
    assert OpenBSDVirtual(None, None, None).get_virtual_facts() == {}

if __name__ == '__main__':
    from unittest import TestLoader, TextTestRunner
    tests = TestLoader().loadTestsFromName(__name__)
    TextTestRunner(verbosity=2).run(tests)

# Generated at 2022-06-23 02:25:18.380182
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual({})
    assert virtual._platform == 'OpenBSD'
    assert virtual.platform == 'OpenBSD'
    assert virtual.virtual == 'None'


# Generated at 2022-06-23 02:25:21.826283
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector.__name__ == 'OpenBSDVirtualCollector'
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Unit tests for constructor and all method of class OpenBSDVirtual

# Generated at 2022-06-23 02:25:26.921137
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Using OpenBSD 6.0 as a sample
    facts = {
        'kernel': 'OpenBSD',
        'kernelrelease': '6.0',
    }
    assert OpenBSDVirtual(facts).platform == 'OpenBSD'
    assert OpenBSDVirtual(facts).get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-23 02:25:29.211828
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module = OpenBSDVirtual()
    assert module.platform == 'OpenBSD'
    assert module.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:25:40.262898
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with empty dmesg.boot
    collector = OpenBSDVirtualCollector(None, "OpenBSD", "", None)
    result = collector._get_virtual_facts()

    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()

    # Test with a vmm(4) hint in dmesg.boot
    collector = OpenBSDVirtualCollector(None, "OpenBSD", "vmm0 at mainbus0: SVM/RVI\n", None)
    result = collector._get_virtual_facts()

    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:25:43.218726
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Constructor of OpenBSDVirtualCollector
    """
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:25:47.838929
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.set_sysctl(get_file_content)
    facts = openbsd_virtual.get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_product_name'] == ''
    assert facts['virtualization_product_version'] == ''

# Generated at 2022-06-23 02:25:49.018886
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector.platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:55.053943
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_obj = OpenBSDVirtual()
    assert isinstance(openbsd_virtual_obj.platform, str)
    assert isinstance(openbsd_virtual_obj.DMESG_BOOT, str)
    assert openbsd_virtual_obj.platform == 'OpenBSD'
    assert openbsd_virtual_obj.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:25:59.935423
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector({'_ansible_version': 2.7})
    assert vc.platform == 'OpenBSD'
    assert vc.collect()['virtualization_type'] == ''
    assert vc.collect()['virtualization_role'] == ''

# Generated at 2022-06-23 02:26:04.321178
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = {'kernel': 'OpenBSD'}
    openbsd_virtual = OpenBSDVirtual(facts, None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Unit tests for methods of class OpenBSDVirtual

# Generated at 2022-06-23 02:26:10.734345
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    '''
    Unit test for testing constructor
    '''
    OpenBsdVirtual = OpenBSDVirtual(None)
    assert OpenBsdVirtual.platform == 'OpenBSD'
    assert OpenBsdVirtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert OpenBsdVirtual._virtual_facts == {}
    return True


# Generated at 2022-06-23 02:26:12.820803
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:26:17.939738
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.collect() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-23 02:26:22.203309
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.platform == "OpenBSD"
    assert openbsd_virtual.DMESG_BOOT == "/var/run/dmesg.boot"

# Generated at 2022-06-23 02:26:23.283682
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:26:29.403935
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    from ansible.module_utils.facts.collector import VirtualCollector
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.base import Virtual
    import pytest

    isinstance(OpenBSDVirtualCollector(), VirtualCollector)
    isinstance(OpenBSDVirtualCollector(), VirtualSysctlDetectionMixin)
    isinstance(OpenBSDVirtualCollector(), Virtual)

# Generated at 2022-06-23 02:26:31.721133
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    v = OpenBSDVirtualCollector()
    assert v._fact_class == OpenBSDVirtual
    assert v._platform == 'OpenBSD'

# Generated at 2022-06-23 02:26:37.239743
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:26:39.553971
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual({})
    assert virtual
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:26:40.659287
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector.platform == 'OpenBSD'

# Generated at 2022-06-23 02:26:42.384275
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == OpenBSDVirtual.platform


# Generated at 2022-06-23 02:26:45.158852
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    test_OpenBSDVirtual_obj = OpenBSDVirtualCollector._get_fact_class()(None)
    assert test_OpenBSDVirtual_obj.platform == 'OpenBSD'


# Generated at 2022-06-23 02:26:48.038493
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:26:51.103379
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:26:58.474502
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd = OpenBSDVirtualCollector(None)
    assert openbsd.get_virtual_facts() == {}


# Generated at 2022-06-23 02:26:59.707256
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual._platform == OpenBSDVirtual.platform

# Generated at 2022-06-23 02:27:01.392440
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module = OpenBSDVirtualCollector(None, None, None)
    module = OpenBSDVirtual()

# Generated at 2022-06-23 02:27:09.354939
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:27:19.373257
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    def is_virtual_facts_none(virtual_facts):
        return virtual_facts['virtualization_type'] is None \
               and virtual_facts['virtualization_role'] is None \
               and virtual_facts['virtualization_technology'] is None \
               and virtual_facts['virtualization_system'] is None \
               and virtual_facts['virtualization_product_name'] is None \
               and virtual_facts['virtualization_product_version'] is None


# Generated at 2022-06-23 02:27:28.930555
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    sysctl_facts = {'hw.vendor': 'Intel',
                    'hw.product': 'Core Processor (Nehalem, IBRS, no TSX)',
                    'hw.machine': 'amd64'}
    dmesg_boot_content = 'cpu0 at mainbus0: (uniprocessor)\nvmm0 at mainbus0: SVM/RVI'
    test_OpenBSDVirtual = OpenBSDVirtual()
    virtual_facts_result = {'virtualization_type': 'vmm',
                            'virtualization_role': 'host',
                            'virtualization_tech_guest': set(),
                            'virtualization_tech_host': set(['vmm'])}
    assert test_OpenBSDVirtual.get_virtual_facts(sysctl_facts, None, dmesg_boot_content) == virtual_

# Generated at 2022-06-23 02:27:37.980145
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class args:
        pass
    args.custom_virtual_facts = []
    args.filter = ['all']
    args.gather_subset = ['!all']

    virtual_facts = OpenBSDVirtual(args)

    cls_name = type(virtual_facts).__name__
    assert cls_name == 'OpenBSDVirtual'

    assert virtual_facts.dmidecode is None

    virtual_facts.get_virtual_facts()

    virtualization_type = virtual_facts.virtualization_type
    assert virtualization_type == 'vmm' or virtualization_type == ''

    virtualization_role = virtual_facts.virtualization_role
    assert virtualization_role == 'host' or virtualization_role == ''

    virtualization_product = virtual_facts.virtualization_product

# Generated at 2022-06-23 02:27:45.166789
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    expected_virtual_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm'])
    }

    v.DMESG_BOOT = 'tests/unit/module_utils/facts/virtual/files/dmesg.boot'
    virtual_facts = v.get_virtual_facts()

    assert(virtual_facts == expected_virtual_facts)

# Generated at 2022-06-23 02:27:54.319032
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd = OpenBSDVirtual(collector=None, shared_obj=dict())
    assert openbsd.platform == 'OpenBSD'
    assert openbsd.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd.VIRTUAL_DMIDE_CODE_DICT == {}
    assert openbsd.VIRTUAL_DMIDE_TYPE_DICT == {}
    assert openbsd.VIRTUAL_PRODUCT_DICT == {
        '0x83848503': 'vmware',
        '0x7A878603': 'xen',
        '0x53654420': 'vpc',
        '0x57694D41': 'vmi'
    }

# Generated at 2022-06-23 02:28:02.081385
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Both product and vendor returns virtualization_type='vmm'
    product_content = 'hypervisor'
    vendor_content = 'OpenBSD'
    dmesg_content = "vmm0 at mainbus0: SVM/RVI\n"
    facts_result = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
    testobj = OpenBSDVirtual()

# Generated at 2022-06-23 02:28:13.576982
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_obj = OpenBSDVirtual()

    # Test vmm(4) virtualization
    openbsd_virtual_obj.sysctl_virtualization_type_data = {'hw.vendor': 'GenuineIntel',
                                                           'hw.product': 'Xeon E5-2697 v4',
                                                           'hw.machine': 'amd64',
                                                           'hw.model': 'Xeon',
                                                           'hw.ncpu': '1'}
    openbsd_virtual_obj.sysctl_virtual_data = {}
    setattr(openbsd_virtual_obj, 'DMESG_BOOT', '/__PLAYBOOK_DIR__/tests/unittests/files/OpenBSD/dmesg.boot')
    virtual_facts = openbsd_virtual_obj.get

# Generated at 2022-06-23 02:28:16.209622
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc.platform == 'OpenBSD'
    assert vc.fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:28:25.190696
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual(
        module=None,
        systctl_path='tests/unit/module_utils/facts/virtual/test_OpenBSD_dmesg.boot')
    # Regex to extract the virtualization type and role
    pattern = re.compile(r"^.*(?P<virtualization_type>\w+)\((?P<virtualization_role>\w+)\).*$")
    openbsd_virtual_facts_str = str(openbsd_virtual_facts.get_virtual_facts())
    assert openbsd_virtual_facts_str is not None
    match = pattern.match(openbsd_virtual_facts_str)
    assert match.group('virtualization_type') == 'vmm'

# Generated at 2022-06-23 02:28:27.260548
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    x = OpenBSDVirtualCollector()
    assert x.platform == "OpenBSD"

# Generated at 2022-06-23 02:28:30.001862
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    '''Unit test to check construction of class OpenBSDVirtualCollector'''
    obj = OpenBSDVirtualCollector()
    assert obj is not None


# Generated at 2022-06-23 02:28:40.178599
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    openbsd_virtual.sysctl_hw_virtual_info = None
    openbsd_virtual.sysctl_hw_virtual_vendor = None
    openbsd_virtual.dmesg_boot = None

    openbsd_virtual.sysctl_hw_virtual_info = {'hw.product': 'VMware Virtual Platform'}
    openbsd_virtual.sysctl_hw_virtual_vendor = {'hw.vendor': 'VMware, Inc.'}
    openbsd_virtual.dmesg_boot = 'vmm0 at mainbus0: VMX/EPT'


# Generated at 2022-06-23 02:28:43.612768
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class == OpenBSDVirtual
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:50.974324
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class OpenBSDVirtual'''

    # Setup
    f = OpenBSDVirtual()

    # Test with no virtualization support
    virtual_facts = f.get_virtual_facts()
    assert(virtual_facts['virtualization_type'] == '')
    assert(virtual_facts['virtualization_role'] == '')

    # Test with VMM guest
    f.set_file_content(OpenBSDVirtual.SYSTEM_PRODUCT_NAME, 'VirtualBox\n')
    f.set_file_content(OpenBSDVirtual.DMESG_BOOT,
                       'vmm0 at mainbus0: VMX/EPT\n'
                       'acpi0 at mainbus0: VirtualBox\n')
    virtual_facts = f.get_virtual_facts()

# Generated at 2022-06-23 02:28:53.009399
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert 'OpenBSD' == virtual_facts.platform

# Generated at 2022-06-23 02:28:57.424357
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    dmesg_boot = '/var/run/dmesg.boot'
    openbsd_virtual = OpenBSDVirtual(dmesg_boot)
    assert openbsd_virtual.DMESG_BOOT == dmesg_boot

# Generated at 2022-06-23 02:29:01.626766
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Test to make sure OpenBSDVirtualCollector class initializes
    properly
    """

    try:
        OpenBSDVirtualCollector()
    except NameError:
        assert False, "OpenBSDVirtualCollector class initializer failed"
    else:
        assert True

# Generated at 2022-06-23 02:29:06.247007
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    facts_obj = OpenBSDVirtualCollector()
    assert facts_obj.platform == 'OpenBSD'
    assert facts_obj.fact_class == OpenBSDVirtual
    assert repr(facts_obj) == '<ansible.module_utils.facts.virtual.openbsd.OpenBSDVirtualCollector [OpenBSD,OpenBSDVirtual]>'

# Generated at 2022-06-23 02:29:15.963942
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # This is a constructor test.
    #
    # It is intended to set up and tear down a OpenBSDVirtual instance
    # for use by the other tests.

    observed_facts = {}

    # Initialize empty instance
    oBSD_virtual = OpenBSDVirtual()

    # Make sure the expected keys are in the instance
    keys = oBSD_virtual.__dict__.keys()
    assert '_platform' in keys
    assert '_fact_class' in keys
    assert '_fact_bases' in keys
    assert 'virtualization_type' in keys
    assert 'virtualization_role' in keys

    # Make sure the base classes were initialized
    assert oBSD_virtual._fact_bases == (Virtual,)  # pylint: disable=protected-access
    assert oBSD_virtual._fact_class is OpenBSDVirtual  # p

# Generated at 2022-06-23 02:29:18.517473
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual1 = OpenBSDVirtualCollector({'ansible_facts': {}})
    assert isinstance(virtual1, VirtualCollector)


# Generated at 2022-06-23 02:29:22.406354
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert hasattr(OpenBSDVirtualCollector, '_fact_class')
    assert isinstance(OpenBSDVirtualCollector._fact_class, object)
    assert hasattr(OpenBSDVirtualCollector, '_platform')
    assert isinstance(OpenBSDVirtualCollector._platform, str)


# Generated at 2022-06-23 02:29:26.324162
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    virtual = OpenBSDVirtual(ansible_facts)
    assert virtual.facts['virtualization_type'] == ''
    assert virtual.facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:29:29.009813
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_ins = OpenBSDVirtual()
    assert openbsd_virtual_ins.platform == 'OpenBSD'
    assert openbsd_virtual_ins.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:29:32.913220
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert OpenBSDVirtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:29:43.070150
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = OpenBSDVirtual()
    if openbsd_virtual_facts.get_virtual_facts()['virtualization_type'] == 'virtualbox':
        assert openbsd_virtual_facts.get_virtual_facts()['virtualization_role'] == 'guest'
        assert 'vbox_version' in openbsd_virtual_facts.get_virtual_facts()
    elif openbsd_virtual_facts.get_virtual_facts()['virtualization_type'] == 'qemu':
        assert openbsd_virtual_facts.get_virtual_facts()['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:29:45.547861
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    qemu_facts = OpenBSDVirtual(dict())
    assert qemu_facts.virtualization_type == ''
    assert qemu_facts.virtualization_role == ''


# Generated at 2022-06-23 02:29:49.965168
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)

    assert isinstance(openbsd_virtual, OpenBSDVirtual)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:29:51.883423
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc.platform == 'OpenBSD'
    assert vc._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:29:55.454898
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual_collector._fact_class, OpenBSDVirtual)

# Generated at 2022-06-23 02:30:01.511791
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """ This will test the constructor of the class OpenBSDVirtual """
    virtual = OpenBSDVirtual()
    assert virtual.name == 'OpenBSD'
    assert virtual.platform == 'OpenBSD'
    assert virtual.virtualization_type == ''
    assert virtual.virtualization_role == ''
    assert virtual.virtualization_tech_guest == set()
    assert virtual.virtualization_tech_host == set()
    assert not virtual.is_virtual

# Generated at 2022-06-23 02:30:12.088649
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # We create an instance in order to be able to access protected members and methods
    o = OpenBSDVirtual()
    # Create with empty dmesg
    o._dmesg_boot = ''
    expected_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    actual_facts = o.get_virtual_facts()
    assert actual_facts == expected_facts
    # Create with dmesg containing vmm(4)
    o._dmesg_boot = '''
vmm0 at mainbus0: SVM/RVI
'''

# Generated at 2022-06-23 02:30:17.566727
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fact_collector = OpenBSDVirtualCollector()
    assert fact_collector._platform == 'OpenBSD'
    assert fact_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:20.833105
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsdvirtual_collector = OpenBSDVirtualCollector()
    assert openbsdvirtual_collector._platform == 'OpenBSD'
    assert openbsdvirtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:22.918283
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:30:24.978377
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), VirtualCollector)

# Generated at 2022-06-23 02:30:26.680257
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector

# Generated at 2022-06-23 02:30:29.880653
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd = OpenBSDVirtualCollector()
    assert openbsd._platform == 'OpenBSD'

# Unit tests for class OpenBSDVirtual

# Generated at 2022-06-23 02:30:39.151131
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts_data = dict(ansible_facts={})
    obj = OpenBSDVirtual()


# Generated at 2022-06-23 02:30:42.683589
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:44.273941
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:45.362835
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert(OpenBSDVirtual().platform == 'OpenBSD')


# Generated at 2022-06-23 02:30:50.951688
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Test the constructor of class OpenBSDVirtual
    """
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:30:52.875517
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert type(openbsd_virtual) == OpenBSDVirtual


# Generated at 2022-06-23 02:30:54.686470
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:31:00.142375
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.module = MockModule()


# Generated at 2022-06-23 02:31:01.869377
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_fa = OpenBSDVirtual()
    assert virtual_fa._platform == 'OpenBSD'


# Generated at 2022-06-23 02:31:06.440686
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Unit test for constructor of class OpenBSDVirtual
    This is a OpenBSD-specific subclass of Virtual.  It defines the following facts:
    - virtualization_type
    - virtualization_role
    """
    obj = OpenBSDVirtual()
    assert obj.platform == "OpenBSD"


# Generated at 2022-06-23 02:31:08.656436
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd = OpenBSDVirtualCollector()
    assert openbsd.platform == 'OpenBSD'
    assert openbsd._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:31:12.643399
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual('')
    assert v.platform == 'OpenBSD'
    assert v.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-23 02:31:21.352412
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import sys

    if sys.version_info.major >= 3:
        from unittest.mock import patch
    else:
        from mock import patch

    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    def return_values(invocation):
        virtual_facts = {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set(),
        }

# Generated at 2022-06-23 02:31:23.330412
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector()._fact_class._platform == 'OpenBSD'

# Generated at 2022-06-23 02:31:26.543798
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:31:28.800931
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:31:38.528498
# Unit test for constructor of class OpenBSDVirtual

# Generated at 2022-06-23 02:31:41.757939
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fact_class = OpenBSDVirtualCollector()
    facts = fact_class.collect()
    assert facts['virtualization_type'] == 'OpenBSD'

# Generated at 2022-06-23 02:31:45.450502
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Successfully get virtual facts from OpenBSD
    openbsd = OpenBSDVirtual()
    facts = openbsd.get_virtual_facts()
    assert facts == {'virtualization_role': 'host', 'virtualization_type': 'vmm', 'virtualization_tech_host': {'vmm'}, 'virtualization_tech_guest': set()}

# Generated at 2022-06-23 02:31:48.430520
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-23 02:31:55.347897
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_collector = OpenBSDVirtualCollector()
    assert openbsd_collector._platform == 'OpenBSD'
    assert openbsd_collector.__class__._platform == 'OpenBSD'
    assert openbsd_collector._fact_class == OpenBSDVirtual
    assert openbsd_collector.__class__._fact_class == OpenBSDVirtual
    fact = openbsd_collector.collect()


# Generated at 2022-06-23 02:31:57.736390
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    os_virtual = OpenBSDVirtualCollector()
    assert os_virtual._platform == 'OpenBSD'
    assert issubclass(os_virtual._fact_class, Virtual)

# Generated at 2022-06-23 02:32:02.901096
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual(None)
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts

# Generated at 2022-06-23 02:32:08.767630
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()

    assert virtual_facts.get_virtual_facts()['virtualization_type'] == ''
    assert virtual_facts.get_virtual_facts()['virtualization_role'] == ''
    assert virtual_facts.get_virtual_facts()['virtualization_tech_host'] == set()
    assert virtual_facts.get_virtual_facts()['virtualization_tech_guest'] == set()
    assert virtual_facts.get_virtual_facts()['virtualization_product'] == ''
    assert virtual_facts.get_virtual_facts()['virtualization_vendor'] == ''


# Generated at 2022-06-23 02:32:10.892854
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:32:15.005917
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:32:16.926766
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert isinstance(OpenBSDVirtualCollector(), VirtualCollector)


# Generated at 2022-06-23 02:32:19.453655
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == openbsd_virtual.virtual_facts



# Generated at 2022-06-23 02:32:24.862074
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.platform == 'OpenBSD'
    assert virt.virtualization_type == ''
    assert virt.virtualization_role == ''
    assert virt.virtualization_tech_guest == set()
    assert virt.virtualization_tech_host == set()

# vim: set expandtab ts=4 sw=4

# Generated at 2022-06-23 02:32:26.999751
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert(OpenBSDVirtualCollector._platform == "OpenBSD")
    assert(OpenBSDVirtualCollector._fact_class == OpenBSDVirtual)

# Generated at 2022-06-23 02:32:28.964147
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsdvirtual_collector = OpenBSDVirtualCollector()
    assert openbsdvirtual_collector.platform == 'OpenBSD'
    assert openbsdvirtual_collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:32:30.015500
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.get_virtual_facts() is not None

# Generated at 2022-06-23 02:32:38.520392
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    virtual_facts = v.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-23 02:32:41.434716
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == OpenBSDVirtual.platform

# Generated at 2022-06-23 02:32:44.335572
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:32:48.053205
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_facts = {'virtualization_type': 'vmm',
                             'virtualization_role': 'host'}
    virtual_collector = OpenBSDVirtualCollector(None, OpenBSDVirtual, 'OpenBSD')
    assert openbsd_virtual_facts == virtual_collector.get_virtual_facts()

# Generated at 2022-06-23 02:32:56.392234
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:33:00.455687
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_fact_collector = OpenBSDVirtualCollector()
    virtual_facts = openbsd_virtual_fact_collector.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_tech_host'] == set(['vmm'])
    assert virtual_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:33:11.975117
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # test_OpenBSDVirtual_get_virtual_facts_rvi is a dict with
    # (fake) output of the hw.vendor and hw.product sysctl.
    # test_OpenBSDVirtual_get_virtual_facts_vmm is a dict with (fake)
    # dmesg.boot contents, indicating the VM runs OpenBSD 6.6 and the
    # hardware supports virtualization.
    from ansible.module_utils._text import to_bytes
    import sys
    import io
    import os
    import subprocess

    result = io.BytesIO()
    for line in to_bytes(subprocess.check_output(['sysctl', 'hw.vendor', 'hw.product'])).splitlines():
        result.write(line + b'\n')

# Generated at 2022-06-23 02:33:13.550625
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:16.854472
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class is OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:19.856307
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual_collector, OpenBSDVirtualCollector)

# Generated at 2022-06-23 02:33:21.774504
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdvirtual = OpenBSDVirtual({})
    assert openbsdvirtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:33.690527
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    # Gather facts from a physical host
    openbsd_virtual = OpenBSDVirtual()
    facts = openbsd_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set()

    # Gather facts from a VirtualBox guest
    openbsd_virtual = OpenBSDVirtual()
    facts = openbsd_virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'virtualbox'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:33:35.914838
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    myVirtual = OpenBSDVirtual()
    assert myVirtual.platform == 'OpenBSD'


# Generated at 2022-06-23 02:33:45.931623
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_inst = OpenBSDVirtual()

    platform = 'OpenBSD'
    virtualization_tech_guest = set()
    virtualization_tech_host = set()
    virtualization_type = ''
    virtualization_role = ''

    assert len(virtual_inst.virtual) == 0
    virtual_inst.populate_virtual_facts()
    assert len(virtual_inst.virtual) == 4
    assert virtual_inst.virtual['platform'] == platform
    assert virtual_inst.virtual['virtualization_tech_guest'] \
           == virtualization_tech_guest
    assert virtual_inst.virtual['virtualization_tech_host'] \
           == virtualization_tech_host
    assert virtual_inst.virtual['virtualization_type'] == virtualization_type
    assert virtual_inst.virtual['virtualization_role'] == virtualization_

# Generated at 2022-06-23 02:33:52.691820
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """ Unit test for constructor of class OpenBSDVirtual """
    virtual_obj = OpenBSDVirtual()
    # The VM is not running on a OpenBSD platform
    result = virtual_obj.get_virtual_facts()
    if 'virtualization_type' in result.keys():
        print(result['virtualization_type'], end='')

if __name__ == '__main__':
    test_OpenBSDVirtual()

# Generated at 2022-06-23 02:33:56.655946
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert issubclass(OpenBSDVirtual, Virtual)
    assert isinstance(OpenBSDVirtual(), Virtual)
    assert hasattr(OpenBSDVirtual, 'get_virtual_facts')
    assert callable(OpenBSDVirtual.get_virtual_facts)


# Generated at 2022-06-23 02:34:02.488043
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual._name == 'OpenBSD'
    assert openbsd_virtual._virt_sysctl_names == [
        'hw.vendor',
        'hw.product',
    ]

# Generated at 2022-06-23 02:34:05.705788
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:34:07.104193
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'

# Generated at 2022-06-23 02:34:08.936739
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Test when it is a OpenBSD platform
    OpenBSDVirtualCollector()