

# Generated at 2022-06-23 02:24:19.270493
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    This is a unit test for OpenBSDVirtual.get_virtual_facts method.
    This tests the virtual_facts return value on multiple OpenBSD
    releases.
    """
    import os
    import json
    with open(os.path.join(os.path.dirname(__file__), 'testdata', 'test_get_virtual_facts_OpenBSD.json'), 'rb') as fp:
        test_data = json.load(fp)

    for test_data in test_data:
        virtual_facts = test_data['input']

        # Create a Virtual object.
        openbsd_virtual = OpenBSDVirtualCollector()

        # Now call the get_virtual_facts() method of class OpenBSDVirtual
        output = openbsd_virtual.get_virtual_facts(virtual_facts=virtual_facts)


# Generated at 2022-06-23 02:24:22.373875
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:24:25.053403
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    for key in v.platform:
        assert v.platform[key] == 'OpenBSD'

# Generated at 2022-06-23 02:24:27.779745
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # call the constructor without arguments
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector is not None

# Generated at 2022-06-23 02:24:30.771603
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module = FakeAnsibleModule()
    virtual = OpenBSDVirtual(module)
    assert isinstance(virtual, OpenBSDVirtual)



# Generated at 2022-06-23 02:24:32.171168
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test constructor
    openbsd_virtual = OpenBSDVirtual()
    pass

# Generated at 2022-06-23 02:24:34.332652
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    instance = OpenBSDVirtualCollector()
    assert isinstance(instance, OpenBSDVirtual)
    assert isinstance(instance, VirtualCollector)

# Generated at 2022-06-23 02:24:37.034215
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()

    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:24:39.055822
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)
    openbsd_facts = OpenBSDVirtualCollector()
    assert issubclass(openbsd_facts.fact_class, OpenBSDVirtual)

# Generated at 2022-06-23 02:24:43.202502
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt_fact_class = OpenBSDVirtual()
    assert virt_fact_class.platform == 'OpenBSD'
    assert virt_fact_class.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:24:44.640594
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    module = OpenBSDVirtualCollector()
    assert module is not None

# Generated at 2022-06-23 02:24:45.279602
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    pass

# Generated at 2022-06-23 02:24:49.619067
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(module=None)

    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:24:52.868091
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Get the facts
    o = OpenBSDVirtual()
    openbsd_facts = o.get_virtual_facts()

    # We should have a virtual type
    assert 'virtualization_type' in openbsd_facts

# Generated at 2022-06-23 02:24:55.979982
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual = OpenBSDVirtualCollector()
    assert virtual._platform == 'OpenBSD'
    assert virtual._fact_class.__name__ == 'OpenBSDVirtual'
    assert virtual._fact_class.platform == 'OpenBSD'

# Generated at 2022-06-23 02:24:59.905477
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-23 02:25:09.756153
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.is_linux is False
    assert virtual_facts.is_freebsd is False
    assert virtual_facts.is_openbsd is True
    assert virtual_facts.is_netbsd is False
    assert virtual_facts.is_solaris is False
    assert virtual_facts.is_windows is False
    assert virtual_facts.is_kvm is False
    assert virtual_facts.is_hyperv is False
    assert virtual_facts.is_virtualbox is False
    assert virtual_facts.is_vmware is False
    assert virtual_facts.is_openvz is False
    assert virtual_facts.is_lxc is False
    assert virtual_facts.is_jail is False
    assert virtual_

# Generated at 2022-06-23 02:25:13.266461
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj.platform == 'OpenBSD'


# Generated at 2022-06-23 02:25:21.997048
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test all hypervisor except vmm
    hypervisor = ['qemu', 'virtualbox', 'parallels', 'kvm', 'hyperv', 'vserver', 'ibm_powerkvm', 'xen_domu', 'xen_dom0']
    for h in hypervisor:
        virtual_facts = OpenBSDVirtual().get_virtual_facts(h)
        assert virtual_facts['virtualization_type'] == h
        assert virtual_facts['virtualization_role'] == 'guest'

    # Test hypervisor vmm
    virtual_facts = OpenBSDVirtual().get_virtual_facts('vmm')
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:25:28.988842
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    testobj = OpenBSDVirtual()
    testobj.detect_virt_product = mock_detect_virt_product
    testobj.detect_virt_vendor = mock_detect_virt_vendor
    testobj.get_file_content = mock_get_file_content


# Generated at 2022-06-23 02:25:40.021865
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:25:41.400929
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:50.423904
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt_sysctl = VirtualSysctlDetectionMixin()
    virt_sysctl.DETECT_VIRT_PRODUCT_FACTS_SUFFIX = '_product'
    virt_sysctl.DETECT_VIRT_VENDOR_FACTS_SUFFIX = '_vendor'
    OpenBSDVirtual.DETECT_VIRT_PRODUCT_FACTS_SUFFIX = '_product'
    OpenBSDVirtual.DETECT_VIRT_VENDOR_FACTS_SUFFIX = '_vendor'

    virt = OpenBSDVirtual()
    # Check virtual_facts = {} returned
    virtual_facts = virt.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == '', \
        'Wrong virtual_facts in OpenBSDVirtual'
    assert virtual_facts

# Generated at 2022-06-23 02:26:00.267983
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual(module)

    # Test with OpenBSD guest on vmm
    setattr(openbsd_virtual, '_platform', 'OpenBSD')
    setattr(openbsd_virtual, '_proc_sysctl', {
        'hw.product': 'OpenBSD',
        'hw.vendor': 'OpenBSD',
        'hw.machine': 'amd64',
    })
    setattr(openbsd_virtual, '_dmesg_boot', [
        'virtio0 at mainbus0: virtio pci emulation',
        'vmm0 at mainbus0: SVM/RVI',
    ])
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:26:02.820170
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'
    assert v.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:26:05.491015
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual._platform == 'OpenBSD'
    assert openbsd_virtual._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:26:08.629998
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Execute constructor
    openbsd_vm = OpenBSDVirtualCollector()

    # Test attributes
    assert openbsd_vm._fact_class == OpenBSDVirtual
    assert openbsd_vm._platform == 'OpenBSD'

# Generated at 2022-06-23 02:26:11.078855
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual(None).get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''



# Generated at 2022-06-23 02:26:18.843364
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Unit test for method get_virtual_facts of class OpenBSDVirtual
    """
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_product' in virtual_facts
    assert 'virtualization_vendor' in virtual_facts

# Generated at 2022-06-23 02:26:20.884687
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector.collect() == OpenBSDVirtual.all_virtual_facts


# Generated at 2022-06-23 02:26:24.866655
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()

    assert virtual.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-23 02:26:29.300856
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test if first instance is created
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    # Test if second instance is created
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'



# Generated at 2022-06-23 02:26:36.983951
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt_detect = OpenBSDVirtual()
    virtual_facts = virt_detect.get_virtual_facts()

    # Initial test to see if the facts have been successfully
    # populated by the method.
    assert virtual_facts is not None
    assert virtual_facts['virtualization_type'] is not None

    # Check if virtualization_type is set correctly.
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:26:43.062203
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():  # pylint: disable=too-few-public-methods
    module = OpenBSDVirtualCollector._create_module_mock()
    openbsd_virtual_fact = OpenBSDVirtual(module)
    assert openbsd_virtual_fact.platform == 'OpenBSD'
    assert openbsd_virtual_fact.name == 'virtual'
    assert openbsd_virtual_fact.fact_subsets == {}

# Generated at 2022-06-23 02:26:47.798307
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_product_name' in virtual_facts

# Generated at 2022-06-23 02:26:50.047193
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual
    assert virtual._platform == 'OpenBSD'
    assert virtual.get_virtual_facts() == {}

# Generated at 2022-06-23 02:26:56.664457
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # set up some fake data to analyze
    sysctl_hw_vendor = 'Xen'

# Generated at 2022-06-23 02:26:59.146001
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual.platform == 'OpenBSD'
    assert OpenBSDVirtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:27:07.098323
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import sys
    import json
    from ansible.module_utils.facts.virtual import OpenBSDVirtual

    if sys.version_info.major >= 3:
        from unittest.mock import patch

        # use mock_open for both open() and file() since these two built-ins
        # have different interfaces. For open, we need to mock both read() and
        # close(), while for file, we only need to mock read()
        mock_open = patch('ansible.module_utils.facts.virtual.open')
    else:
        from mock import patch

        mock_open = patch('ansible.module_utils.facts.virtual.__builtin__.open')

    mod_args = {}

# Generated at 2022-06-23 02:27:11.147491
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    ob_vc = OpenBSDVirtualCollector()
    assert isinstance(ob_vc, OpenBSDVirtualCollector)
    assert isinstance(ob_vc._fact_class, OpenBSDVirtual)
    assert ob_vc._platform == 'OpenBSD'
    assert not ob_vc.data


# Generated at 2022-06-23 02:27:21.305734
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Testing get_virtual_facts of class OpenBSDVirtual with no vendor in hw.vendor
    """
    class MockOpenBSDVirtual(OpenBSDVirtual):
        def detect_virt_product(self, product_attribute):
            return {"virtualization_tech_guest": set(), "virtualization_tech_host": set(),
                    "virtualization_type": "", "virtualization_role": ""}

        def detect_virt_vendor(self, vendor_attribute):
            return {"virtualization_tech_guest": set(), "virtualization_tech_host": set(),
                    "virtualization_type": "", "virtualization_role": ""}

    openbsd_virtual = MockOpenBSDVirtual()
    result = openbsd_virtual.get_virtual_facts()
    assert(len(result) == 4)

# Generated at 2022-06-23 02:27:23.393902
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    bsd_virtual = OpenBSDVirtualCollector()
    assert bsd_virtual is not None

# Class for mocking up OpenBSD virtual environment

# Generated at 2022-06-23 02:27:26.966895
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    expected_value = 'OpenBSD'
    assert openbsd_virtual.platform == expected_value, "Value %s not as expected: %s" % (expected_value, openbsd_virtual.platform)


# Generated at 2022-06-23 02:27:28.511748
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual.get_virtual_facts()


# Generated at 2022-06-23 02:27:31.401973
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:27:34.349086
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    x = OpenBSDVirtual()
    assert x.platform == 'OpenBSD'


# Generated at 2022-06-23 02:27:45.312614
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from . import OpenBSDVirtual
    from .. import get_file_content, VirtualProductFacts, VirtualVendorFacts
    from mock import patch, Mock

    # Return empty string
    with patch.object(get_file_content, 'open', create=True):
        with patch.object(get_file_content, 'read'):
            facts = OpenBSDVirtual().get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

    # Return valid values

# Generated at 2022-06-23 02:27:53.934169
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = {}
    facts['kernel'] = 'OpenBSD'

    memory = {}
    memory['bank_label'] = 'Physical Memory'
    memory['bank_locator'] = 'System Board Or Motherboard'
    memory['capacity'] = '16 GB'
    memory['clock'] = 'Unknown'
    memory['configured_clockspeed'] = 'Unknown'
    memory['configured_memoryclockspeed'] = 'Unknown'
    memory['devicetype'] = 'Unknown'
    memory['formfactor'] = 'Unknown'
    memory['manufacturer'] = 'HP'
    memory['max_capacity'] = '16 GB'
    memory['memory_type'] = 'Unknown'
    memory['model'] = 'Unknown'
    memory['nof_banks'] = '1'
    memory['part_number'] = 'Unknown'
   

# Generated at 2022-06-23 02:27:55.900349
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:02.351008
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()
    assert o.platform == 'OpenBSD'
    assert o.DMESG_BOOT == '/var/run/dmesg.boot'
    assert o.hv_facts == {}



# Generated at 2022-06-23 02:28:13.783100
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for hw.vendor OpenBSD
    v = OpenBSDVirtualCollector({'kernel': 'OpenBSD'})
    host_tech = set()
    guest_tech = set()
    result = v.get_virtual_facts()
    assert result['virtualization_type'] == ''
    assert result['virtualization_role'] == ''
    assert guest_tech == result['virtualization_tech_guest']
    assert host_tech == result['virtualization_tech_host']

    # Test for hw.product vmm
    v = OpenBSDVirtualCollector({'kernel': 'OpenBSD'})
    v.facts['hw_product'] = 'QEMU Virtual CPU'
    host_tech = set()
    guest_tech = set()
    guest_tech.add('kvm')

# Generated at 2022-06-23 02:28:17.040220
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collecter = OpenBSDVirtualCollector()
    assert 'ansible.module_utils.facts.virtual.openbsd.OpenBSDVirtual' == str(collecter._fact_class)
    assert 'OpenBSD' == collecter._platform

# Generated at 2022-06-23 02:28:21.284284
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual({}, {}, {})

    facts = virtual.get_virtual_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'

    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-23 02:28:24.027747
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual(None)
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:28:25.472964
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector


# Generated at 2022-06-23 02:28:31.337566
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fn = VirtualCollector.factory
    assert issubclass(fn(_platform='OpenBSD'), OpenBSDVirtualCollector)
    assert fn(_platform='OpenBSD') is not fn(_platform='OpenBSD')
    assert fn(_platform='OpenBSD')() is not fn(_platform='OpenBSD')()
    assert isinstance(fn(_platform='OpenBSD')(), OpenBSDVirtualCollector)

# Generated at 2022-06-23 02:28:33.778371
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test an empty instance
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'
    assert not v.is_virtual

# Generated at 2022-06-23 02:28:37.299578
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Unit test for constructor of class OpenBSDVirtualCollector
    """

    vc = OpenBSDVirtualCollector()
    assert vc._platform == 'OpenBSD'
    assert vc._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:28:38.594947
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert isinstance(OpenBSDVirtual(), Virtual)

# Generated at 2022-06-23 02:28:42.399626
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = OpenBSDVirtual()
    assert facts.collect() == facts.get_virtual_facts()

# Generated at 2022-06-23 02:28:53.253062
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class OpenBSDVirtual_test(OpenBSDVirtual):
        def __init__(self):
            self.platform = 'OpenBSD'
            self.DMESG_BOOT = 'tests/unit/module_utils/facts/virtual/openbsd_dmesg.boot'

    test_OpenBSDVirtual = OpenBSDVirtual_test()
    results = {}

    results.update(test_OpenBSDVirtual.get_virtual_facts())
    assert results['virtualization_type'] == 'vmm'
    assert results['virtualization_role'] == 'host'
    assert results['virtualization_tech_guest'] == set([])
    assert results['virtualization_tech_host'] == set(['vmm'])

# Generated at 2022-06-23 02:29:04.823705
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    ''' Test get_virtual_facts() for multiple OpenBSD system types. '''

# Generated at 2022-06-23 02:29:16.558227
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test with no virtualization
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_product'] == ''
    assert virtual_facts['virtualization_vendor'] == ''
    assert virtual_facts['virtualization_tech_guest'].isdisjoint(['vmm'])
    assert virtual_facts['virtualization_tech_host'].isdisjoint(['vmm'])

    # Test with vmm
    setattr(OpenBSDVirtual, 'DMESG_BOOT', './test/vmm/dmesg.boot')
    virtual_facts = OpenBSDVirtual().get_virtual_facts()

# Generated at 2022-06-23 02:29:24.625965
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    o = OpenBSDVirtual()

    # Test the case when the host is virtualized
    o.facts['hw.vendor'] = 'OpenBSD'
    o.facts['hw.product'] = 'vmm'
    o.detect_virt_vendor = lambda x: {'virtualization_type': 'vmm',
                                      'virtualization_role': 'guest',
                                      'virtualization_tech_guest': {'vmm'},
                                      'virtualization_tech_host': set()}
    o.detect_virt_product = lambda x: {'virtualization_type': 'vmm',
                                       'virtualization_role': 'guest',
                                       'virtualization_tech_guest': {'vmm'},
                                       'virtualization_tech_host': set()}
    o.get_file_

# Generated at 2022-06-23 02:29:33.015298
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()

    # Test get_virtual_facts method on OpenBSD VM
    # Virtual product should be 'OpenBSD'
    # Virtual vendor should be 'OpenBSD'
    # Virtual role should be 'guest'
    # Virtual technology should be 'bhyve'
    with open('/proc/cpuinfo') as cpuinfo_file:
        open_virt_facts = v.get_virtual_facts(content=cpuinfo_file.read())
        assert open_virt_facts['virtualization_type'] == 'bhyve'
        assert open_virt_facts['virtualization_role'] == 'guest'
        assert open_virt_facts['virtualization_product'] == 'OpenBSD'
        assert open_virt_facts['virtualization_vendor'] == 'OpenBSD'
        assert 'bhyve' in open_virt_

# Generated at 2022-06-23 02:29:35.507936
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    r = OpenBSDVirtual({})
    assert r.platform == 'OpenBSD'
    assert len(r.get_virtual_facts()) == 4

# Generated at 2022-06-23 02:29:38.117498
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fact_collector = OpenBSDVirtualCollector()
    assert fact_collector._platform == 'OpenBSD'
    assert fact_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:29:44.582928
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert hasattr(openbsd_virtual_collector, 'platform')
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert hasattr(openbsd_virtual_collector, '_fact_class')
    assert openbsd_virtual_collector._fact_class == 'OpenBSDVirtual'

# Generated at 2022-06-23 02:29:47.984270
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    my_test = OpenBSDVirtual({})
    assert my_test.platform == 'OpenBSD'
    assert my_test.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-23 02:29:53.070375
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd = OpenBSDVirtualCollector()
    assert openbsd.platform == 'OpenBSD'
    assert openbsd._fact_class is OpenBSDVirtual


# Generated at 2022-06-23 02:30:01.714547
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """ constructor """
    expected_virtual_facts = {
        'virtualization_role': 'host',
        'virtualization_type': 'vmm',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm'])
    }
    # mock module args
    module_args = {}
    # mock ansible facts
    ansible_facts = {
        'kernel': 'OpenBSD'
    }
    openbsd_virtual =  OpenBSDVirtual(module_args, ansible_facts)
    assert openbsd_virtual.collect() == expected_virtual_facts

# Generated at 2022-06-23 02:30:05.760253
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Testing OpenBSDVirtual constructor
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:30:09.455124
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual(None).get_virtual_facts()
    assert isinstance(facts, dict)
    assert set(facts.keys()) == set(['virtualization_type', 'virtualization_role'])
    for value in facts.values():
        assert isinstance(value, str)

# Generated at 2022-06-23 02:30:11.509245
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.collect()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:30:14.187862
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual
    assert OpenBSDVirtualCollector._fact_class.platform == 'OpenBSD'


# Generated at 2022-06-23 02:30:16.438055
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:30:18.097197
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Just instantiate the Class
    output = OpenBSDVirtual()


# Generated at 2022-06-23 02:30:19.151594
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:30:21.655136
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd = OpenBSDVirtual()
    assert openbsd
    assert openbsd.platform == 'OpenBSD'


# Generated at 2022-06-23 02:30:26.600090
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Construct the object
    test_OpenBSDVirtual = OpenBSDVirtual()
    # Check the platform variable
    assert test_OpenBSDVirtual.platform == 'OpenBSD'
    # Check the DMESG_BOOT variable
    assert test_OpenBSDVirtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:30:31.670618
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()
    facts = virt.get_virtual_facts()

    # Check if it has the expected type
    assert isinstance(facts, dict)

    # Check if it populated the virtual facts
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts

# Generated at 2022-06-23 02:30:35.045259
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:46.161879
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:30:51.152706
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o_platform = OpenBSDVirtual._platform
    o_fact_class = OpenBSDVirtual._fact_class
    assert o_platform == 'OpenBSD'
    assert o_fact_class == OpenBSDVirtualCollector

# Generated at 2022-06-23 02:30:53.002468
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'
    assert OpenBSDVirtualCollector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:54.827572
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:30:58.220670
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdvirtual = OpenBSDVirtual(None, None)
    assert openbsdvirtual.get_virtual_facts()['virtualization_type'] == ''
    assert openbsdvirtual.get_virtual_facts()['virtualization_role'] == ''

# Generated at 2022-06-23 02:31:09.312186
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:31:10.044549
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    OpenBSDVirtual()

# Generated at 2022-06-23 02:31:12.564026
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._fact_class == OpenBSDVirtual
    assert collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:31:15.999781
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(module=None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:31:23.869744
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.openshift import OpenShiftVirtual
    from ansible.module_utils.facts.virtual.xen import XenVirtual
    from ansible.module_utils.facts.virtual.kvm import KVMVirtual
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBoxVirtual
    from ansible.module_utils.facts.virtual.parallels import ParallelsVirtual
    from ansible.module_utils.facts.virtual.vmware import VMWareVirtual
    from ansible.module_utils.facts.virtual.hyperv import HyperVVirtual

    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.get_virtual_facts()

# Generated at 2022-06-23 02:31:28.249107
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    virtual = OpenBSDVirtual({})
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert virtual.sysctl_default == '/usr/sbin/sysctl'

# Generated at 2022-06-23 02:31:30.714483
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    oobvd = OpenBSDVirtualCollector()
    assert oobvd
    assert oobvd.platform == 'OpenBSD'

# Generated at 2022-06-23 02:31:36.300341
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Constructor test
    openbsd_virtual_facts = OpenBSDVirtual()
    assert openbsd_virtual_facts.platform == 'OpenBSD'
    assert openbsd_virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:31:48.846078
# Unit test for constructor of class OpenBSDVirtual

# Generated at 2022-06-23 02:31:52.610827
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:31:55.110324
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector()._platform == 'OpenBSD'
    assert issubclass(OpenBSDVirtualCollector()._fact_class, OpenBSDVirtual)


# Generated at 2022-06-23 02:32:00.871102
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._fact_class._platform == 'OpenBSD'
    assert collector._fact_class.__name__ == 'OpenBSDVirtual'
    assert collector.platform == 'OpenBSD'
    assert collector.collect()['virtualization_type'] == ''
    assert collector.collect()['virtualization_role'] == ''

# Generated at 2022-06-23 02:32:05.563092
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    openbsd = OpenBSDVirtual()
    assert openbsd.platform == 'OpenBSD'
    assert openbsd.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-23 02:32:07.909046
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():

    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:32:11.618505
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    test_obj = OpenBSDVirtual(module=None)
    assert test_obj
    assert test_obj.platform == 'OpenBSD'
    assert test_obj.virttype == ''
    assert test_obj.virtrole == ''

# Generated at 2022-06-23 02:32:20.762597
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Test module for get_virtual_facts method
    """
    # Test data: virtual_facts
    virtual_facts = {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_product_name': '',
        'virtualization_product_version': '',
        'virtualization_product_default_variant': ''
    }
    # Test data: guest_tech
    guest_tech = set()
    # Test data: host_tech
    host_tech = set()
    # Test data: virtual_product_facts

# Generated at 2022-06-23 02:32:23.743093
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Unit test for constructor of class OpenBSDVirtual"""
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'


# Generated at 2022-06-23 02:32:26.404132
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDVirtual
    assert not obj._loaded

# Generated at 2022-06-23 02:32:29.614795
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    assert OpenBSDVirtual().get_virtual_facts() == dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_product='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )

# Generated at 2022-06-23 02:32:40.101466
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()

    # Unit test for Virtualization facts for OpenBSD host
    openbsd_virtualization_facts = virt.get_virtual_facts()
    assert openbsd_virtualization_facts['virtualization_type'] == 'vmm'
    assert openbsd_virtualization_facts['virtualization_role'] == 'host'
    assert openbsd_virtualization_facts['virtualization_tech_host'] == {'vmm'}
    assert openbsd_virtualization_facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:32:41.092020
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:32:44.238546
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:32:46.975811
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:32:49.495872
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:32:52.747488
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test environment not available on all platforms, so this test
    # also tests that get_virtual_facts() returns a dict.
    osvirtual = OpenBSDVirtual()
    virtual_facts = osvirtual.get_virtual_facts()
    assert isinstance(virtual_facts, dict)

# Generated at 2022-06-23 02:32:55.319950
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual({})
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:33:02.632927
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # pylint: disable=unused-argument

    def mock_get_file_content(filename, default=None, strip=False):
        # pylint: disable=unused-argument
        """
        Returns dmesg.boot.
        """

# Generated at 2022-06-23 02:33:13.112065
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
  openbsd_virtual = OpenBSDVirtual()

  dmesg_boot = ""
  # vmm(4) attached as host
  dmesg_boot += "vmm0 at mainbus0: VMX/EPT\n"

  dmesg_boot += "sdmmc0 at umass? scbus? target ? lun ?\n"

  dmesg_boot += "acpi0 at mainbus0: (PNP0A03, PNP0A08)\n"
  dmesg_boot += "acpiac0 at acpi0: AC adapter\n"
  dmesg_boot += "acpibat0 at acpi0: BAT1 model \"4C\" serial \"LGP4C0X9\" type LION\n"

  # TODO: Actually check the below lines, but this requires acquiring one of the

# Generated at 2022-06-23 02:33:17.648150
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:33:18.705397
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual({})
    assert virtual_facts._platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:22.388416
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

# Generated at 2022-06-23 02:33:26.935056
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    from ansible.module_utils.facts import _get_platform_subclass

    openbsd_virtual = _get_platform_subclass(OpenBSDVirtual)
    assert issubclass(openbsd_virtual, OpenBSDVirtual)

# Generated at 2022-06-23 02:33:30.545981
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    os_facts = { 'kernel': 'OpenBSD' }
    virtual = OpenBSDVirtual(os_facts)


# Generated at 2022-06-23 02:33:33.123781
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert issubclass(OpenBSDVirtualCollector, VirtualCollector)
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'


# Generated at 2022-06-23 02:33:35.322431
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:37.838785
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._fact_class.__name__ == "OpenBSDVirtual"
    assert OpenBSDVirtualCollector._platform == "OpenBSD"

# Generated at 2022-06-23 02:33:45.009747
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual({})
    # By default all virtual facts will be empty
    facts = v.get_virtual_facts()
    assert all([v in facts for v in ('virtualization_type',
                                     'virtualization_role',
                                     'virtualization_tech_guest',
                                     'virtualization_tech_host')])
    assert all([facts[v] == '' for v in ('virtualization_type',
                                         'virtualization_role',
                                         'virtualization_tech_guest',
                                         'virtualization_tech_host')])


# Generated at 2022-06-23 02:33:47.691789
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_openbsd = OpenBSDVirtual(None)
    # If the constructor is working then the platform is set.
    assert virtual_openbsd.platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:56.732369
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtualCollector({}, None).collect()['ansible_facts']['ansible_virtualization_facts']
    assert virtual['virtualization_type'] == ''
    assert virtual['virtualization_role'] == ''
    assert virtual['virtualization_tech_host'] == set()
    assert virtual['virtualization_tech_guest'] == set()
    assert virtual['virtualization_product_name'] == ''
    assert virtual['virtualization_product_version'] == ''
    assert virtual['virtualization_product_serial'] == ''
    assert virtual['virtualization_product_uuid'] == ''
    assert virtual['virtualization_product_family'] == ''

# Generated at 2022-06-23 02:34:00.252752
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:34:04.488406
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Check if the class doesn't fail with empty input
    OpenBSDVirtual({})
    # Check if the class doesn't fail
    OpenBSDVirtual({'ansible_virtualization_type': 'OpenBSDVM'})

# Generated at 2022-06-23 02:34:13.738850
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Define an empty OpenBSDVirtualCollector object
    test_OpenBSDVirtualCollector_obj = OpenBSDVirtualCollector()

    # Define an empty OpenBSDVirtual object
    test_OpenBSDVirtual_obj = test_OpenBSDVirtualCollector_obj._fact_class()

    # Run the method and test the output
    result_get_virtual_facts = test_OpenBSDVirtual_obj.get_virtual_facts()
    assert(result_get_virtual_facts['virtualization_type'] == '')
    assert(result_get_virtual_facts['virtualization_role'] == '')
    assert(result_get_virtual_facts['virtualization_product_name'] == '')
    assert(result_get_virtual_facts['virtualization_product_version'] == '')