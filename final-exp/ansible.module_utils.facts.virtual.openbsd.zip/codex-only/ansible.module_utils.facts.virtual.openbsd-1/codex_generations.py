

# Generated at 2022-06-23 02:24:12.810318
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:24:17.854964
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = {'kernel': 'OpenBSD'}
    openbsd_virtual = OpenBSDVirtual(facts, None)
    assert 'virtualization_type' in openbsd_virtual.get_virtual_facts()
    assert 'virtualization_role' in openbsd_virtual.get_virtual_facts()


# Generated at 2022-06-23 02:24:21.091849
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    my_collector = OpenBSDVirtualCollector()
    print(my_collector)
    assert my_collector._fact_class.platform == 'OpenBSD'
    assert my_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:24:27.834775
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Given
    openbsd_virtual = OpenBSDVirtual({'ANSIBLE_SYSTEM_HAS_NO_VIRTUALIZATION_PRODUCT': 1,
                                      'ANSIBLE_SYSTEM_HAS_NO_VIRTUALIZATION_VENDOR': 1})

    # When
    facts = openbsd_virtual.get_virtual_facts()

    # Then
    assert facts['virtualization_role'] == ''
    assert facts['virtualization_type'] == ''
    assert {'vmm'} == facts['virtualization_tech_host']
    assert set() == facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:24:36.083011
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    host_virtual_facts = {'virtualization_type': 'vmm',
                          'virtualization_role': 'host',
                          'virtualization_tech_host': ['vmm'],
                          'virtualization_tech_guest': set()}

    guest_virtual_facts = {'virtualization_type': 'vmm',
                           'virtualization_role': 'guest',
                           'virtualization_tech_guest': ['vmm'],
                           'virtualization_tech_host': set()}

    openbsd_virtual_facts = OpenBSDVirtual({'ansible_system': 'OpenBSD', 'ansible_virtualization_type': 'vmm'})
    assert openbsd_virtual_facts.get_virtual_facts() == host_virtual_facts


# Generated at 2022-06-23 02:24:41.649247
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    vc = OpenBSDVirtualCollector()
    facts = vc.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'virtualization_product' in facts
    assert 'virtualization_vendor' in facts

# Generated at 2022-06-23 02:24:43.723319
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:24:49.291454
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = OpenBSDVirtual().get_all()

    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

    assert 'product_name' in facts
    assert 'product_version' in facts

# Generated at 2022-06-23 02:24:58.585311
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Invoke the get_virtual_facts() method of class OpenBSDVirtual
    # to get the virtual facts of a OpenBSD VM
    openbsd_virtual = OpenBSDVirtual({})
    virtual_facts = openbsd_virtual.get_virtual_facts()

    # Assert that the openbsd_virtual class uses the DVU class
    # to get the virtual facts.
    assert(virtual_facts['virtualization_type'] == 'vmm')
    assert(virtual_facts['virtualization_role'] == 'guest')
    assert(virtual_facts['virtualization_tech_guest'] == set(['vmm']))
    assert(virtual_facts['virtualization_tech_host'] == set(['vmm']))

# Generated at 2022-06-23 02:25:07.321202
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtualCollector()
    openbsd_virtual_facts = openbsd_virtual.get_virtual_facts()
    assert openbsd_virtual_facts['virtualization_type'] == ''
    assert openbsd_virtual_facts['virtualization_role'] == ''
    assert openbsd_virtual_facts['virtualization_tech_guest'] == set()
    assert openbsd_virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:25:11.393428
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()
    assert o.platform == 'OpenBSD'
    assert o.product_name == 'hw.product'
    assert o.vendor_name == 'hw.vendor'
    assert o.sysctl_platform_values == {}

# Generated at 2022-06-23 02:25:19.198588
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # The values returned by OpenBSDVirtual.get_virtual_facts() should be the
    # same as those returned by the function _get_virtual_facts() defined
    # in OpenBSD's ansible/module_utils/facts/virtual/openbsd.py
    from ansible.module_utils.facts.virtual import openbsd
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual as OpenBSDVirtual_ansible
    virtual_facts = OpenBSDVirtual_ansible().get_virtual_facts()
    _virtual_facts = openbsd._get_virtual_facts()
    assert virtual_facts == _virtual_facts


# Generated at 2022-06-23 02:25:23.089052
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    for key in openbsd_virtual.get_virtual_facts():
        assert isinstance(openbsd_virtual.get_virtual_facts()[key], set)

# Generated at 2022-06-23 02:25:24.637973
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    try:
        OpenBSDVirtualCollector()
    except Exception as e:
        assert type(e) == Exception


# Generated at 2022-06-23 02:25:27.389653
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = {'kernel': 'OpenBSD'}
    testobj = OpenBSDVirtual(facts, [])
    assert testobj.platform == 'OpenBSD'
    assert testobj.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:25:31.486922
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:25:34.377895
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    fact_class = OpenBSDVirtual
    fact_collector_class = OpenBSDVirtualCollector

    assert fact_collector_class._fact_class == fact_class

# Generated at 2022-06-23 02:25:39.163469
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()
    assert o.platform == 'OpenBSD'
    assert 'virtualization_type' in o.facts
    assert 'virtualization_role' in o.facts
    assert 'virtualization_technology_guest' in o.facts
    assert 'virtualization_technology_host' in o.facts



# Generated at 2022-06-23 02:25:41.527838
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # This is a class, not a method, so we can't test it directly.
    # It is tested indirectly through the LinuxVirtualCollector.
    pass



# Generated at 2022-06-23 02:25:42.524113
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector(None)

# Generated at 2022-06-23 02:25:47.999043
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_obj = OpenBSDVirtual()
    openbsd_virtual_facts = openbsd_virtual_obj.get_virtual_facts()
    assert openbsd_virtual_facts == dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
        virtualization_product='',
        virtualization_vendor=''
    )

# Generated at 2022-06-23 02:25:51.439773
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual('OpenBSD')
    assert virt.platform == 'OpenBSD'
    assert virt.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:26:01.180951
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create an instance of OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()

    # Mock virt_product_facts
    virt_product_facts = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': ''
    }
    openbsd_virtual.detect_virt_product = lambda x: virt_product_facts

    # Mock virt_vendor_facts
    virt_vendor_facts = {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_system': ''
    }
    open

# Generated at 2022-06-23 02:26:06.803452
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    # Test if the correct platform is set
    assert virtual.platform == 'OpenBSD'
    # Test if the correct facts are set
    assert virtual.get_virtual_facts() == {'virtualization_type': '',
                                           'virtualization_role': '',
                                           'virtualization_tech_guest': set(),
                                           'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:26:14.080660
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    fact_collector = OpenBSDVirtualCollector()
    virtual_facts_dic = fact_collector.collect(None, None)

    assert 'virtualization_type' in virtual_facts_dic
    assert 'virtualization_role' in virtual_facts_dic
    assert 'virtualization_tech_guest' in virtual_facts_dic
    assert 'virtualization_tech_host' in virtual_facts_dic
    assert 'virtualization_product_name' in virtual_facts_dic

# Generated at 2022-06-23 02:26:24.080135
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    sysctl_virtual_facts = '''sysctl_hw_vendor: VMware, Inc.
sysctl_hw_product: VMware Virtual Platform'''
    virtual_collector = OpenBSDVirtualCollector()
    virtual_collector._cache[OpenBSDVirtual.DMESG_BOOT] = sysctl_virtual_facts
    virtual_collector._cache['product_name'] = 'VMware Virtual Platform'
    virtual_collector._cache['manufacturer'] = 'VMware Inc.'
    virtual_facts = virtual_collector.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert 'vmware' in virtual_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:26:26.835915
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:26:27.886175
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:26:37.865158
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import unittest
    import tempfile
    import shutil
    import os
    import sys

    # Create temp workdir and symlink to facter's modules and lib dir
    # Should be at least Python 2.6 compatible
    tempdir = tempfile.mkdtemp()
    src_dir = os.path.dirname(os.path.dirname(__file__))
    os.symlink(os.path.join(src_dir, "lib"),
               os.path.join(tempdir, "lib"))
    os.symlink(os.path.join(src_dir, "module_utils"),
               os.path.join(tempdir, "module_utils"))

    # Use the temporary dir as first entry in PYTHONPATH
    pypath = tempdir + os.pathsep + os.pathse

# Generated at 2022-06-23 02:26:48.253567
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test OpenBSD system run on OpenBSD host
    test_facts = OpenBSDVirtual({})
    host_facts = {'ansible_system': 'OpenBSD', 'ansible_product_name': 'OpenBSD',
                  'ansible_kernel': 'OpenBSD'}

    output = {'virtualization_role': 'guest',
              'virtualization_type': 'OpenBSD',
              'virtualization_tech_guest': set(['OpenBSD']),
              'virtualization_tech_host': set([])}
    assert test_facts.get_virtual_facts(host_facts) == output

    # Test OpenBSD system run on Linux host
    host_facts['ansible_system'] = 'Linux'
    host_facts['ansible_product_name'] = 'Linux'

# Generated at 2022-06-23 02:26:51.295769
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector is not None
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:26:56.375575
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_product='',
        virtualization_vendor='',
        virtualization_tech_guest=set(),
        virtualization_tech_host=set(),
    )

# Generated at 2022-06-23 02:26:58.088736
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts is not None

# Generated at 2022-06-23 02:27:00.367660
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class
    assert openbsd_virtual_collector._platform

# Generated at 2022-06-23 02:27:08.827014
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test cases:
    # vmm0 at mainbus0: SVM/RVI
    test_cases = list()
    test_cases.append(
        dict(
            dmesg_boot='''
vmm0 at mainbus0: SVM/RVI
''',
            expected_virtual_facts=dict(
                virtualization_tech_host=set(['vmm']),
                virtualization_tech_guest=set(),
                virtualization_type='vmm',
                virtualization_role='host'
            )
        )
    )
    # vmm0 at mainbus0: VMX/EPT

# Generated at 2022-06-23 02:27:19.041919
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = {}
    v = OpenBSDVirtual(facts, None)

    # Set virtualization_type=vmm and virtualization_role=guest
    facts['kernel'] = 'OpenBSD'
    facts['architecture'] = 'amd64'
    facts['devices'] = {'vmm': {'product': 'OpenBSD Virtual Machine'}, 'acpi': {'vendor': 'OpenBSD'}}

    try:
        v.get_virtual_facts()
    except Exception:
        pass

    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'guest'
    assert 'vmm' in facts['virtualization_tech_guest']
    assert not facts['virtualization_tech_host']

    # Set virtualization_type=vmm and virtualization_role=host
   

# Generated at 2022-06-23 02:27:28.671321
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:27:31.562236
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual(None)
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:27:40.470639
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    invalid_values = [
        '',
        'None',
        'none',
        'NONE'
    ]
    class_instance = OpenBSDVirtual()
    # Check if the values are non-empty strings
    for k, v in class_instance.get_virtual_facts().items():
        assert isinstance(v, str) and v != ''
    # Check if get_virtual_facts returns all the required keys
    assert sorted(class_instance.get_virtual_facts().keys()) == sorted(class_instance.REQUIRED_KEYS)
    # Check if the values returned by get_virtual_facts are not in the invalid_values list
    for k, v in class_instance.get_virtual_facts().items():
        assert v not in invalid_values

# Generated at 2022-06-23 02:27:43.197877
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._fact_class == OpenBSDVirtual
    assert virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:27:44.680869
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector.get_instance() is not None

# Generated at 2022-06-23 02:27:50.650309
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    platform = 'OpenBSD'
    fact_class = OpenBSDVirtualCollector._fact_class(platform)

    get_virtual_facts = fact_class.get_virtual_facts()
    assert isinstance(get_virtual_facts, dict)
    assert get_virtual_facts['virtualization_type'] == 'vmm'
    assert get_virtual_facts['virtualization_role'] == 'host'
    assert get_virtual_facts['virtualization_tech_host'] == {'vmm'}

# Generated at 2022-06-23 02:27:55.654281
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'



# Generated at 2022-06-23 02:27:57.923028
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj.platform == 'OpenBSD'
    assert isinstance(obj.get_all(), dict)


# Generated at 2022-06-23 02:27:59.317756
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector().platform == 'OpenBSD'


# Generated at 2022-06-23 02:28:02.730098
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:28:03.812281
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:28:15.195526
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Test case 1: when is_vmm_host returns True and is_vmm_guest returns False
    test_data_1 = dict(
        hw_product = 'OpenBSD',
        hw_vendor = 'OpenBSD',
        vmm_guest_re = 'unknown',
        vmm_host_re = '',
        dmesg_boot = 'vmm0 at mainbus0: SVM/RVI'
    )
    expected_1 = dict(
        virtualization_type = 'vmm',
        virtualization_role = 'host',
        virtualization_tech_host = { 'vmm' },
        virtualization_tech_guest = set()
    )
    actual_1 = OpenBSDVirtual.get_virtual_facts(test_data_1)
    assert actual_1 == expected_1

# Generated at 2022-06-23 02:28:18.689172
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    x = OpenBSDVirtual()
    assert x.platform == 'OpenBSD'
    assert x.DMESG_BOOT == '/var/run/dmesg.boot'
    assert x.VIRT_WHAT == '/usr/sbin/virt-what'



# Generated at 2022-06-23 02:28:21.510867
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-23 02:28:31.241012
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    facts = {'hw_product': 'VirtualBox', 'hw_vendor': 'innotek GmbH'}
    virtual_facts = v.get_virtual_facts(facts)

    assert virtual_facts['virtualization_type'] == 'virtualbox'
    assert 'virtualbox' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']

    # Test a system that is capable of virtualization but is not virtual
    facts = {'hw_product': 'OpenBSD', 'hw_vendor': 'OpenBSD'}
    virtual_facts = v.get_virtual_facts(facts)

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
   

# Generated at 2022-06-23 02:28:34.573228
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class is OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:43.357837
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    def mocked_detect_virt_product(self, product):
        return {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set()
        }

    def mocked_detect_virt_vendor(self, vendor):
        return {
            'virtualization_type': '',
            'virtualization_role': '',
            'virtualization_tech_guest': set(),
            'virtualization_tech_host': set()
        }

    # create patch for method detect_virt_product
    openBSDVirtual_patch__detect_virt_product = 'ansible.module_utils.facts.virtual.openbsd.OpenBSDVirtual.detect_virt_product'

# Generated at 2022-06-23 02:28:47.944701
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'
    assert openbsd_virtual_collector.fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:28:57.592671
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    facts = {}
    # Test "baremetal" system
    virtual = OpenBSDVirtual(module=None, facts=facts)
    vf = virtual.get_virtual_facts()
    assert vf['virtualization_type'] == ''
    assert vf['virtualization_role'] == ''
    assert vf['virtualization_tech_host'] == set()
    assert vf['virtualization_tech_guest'] == set()

    # Test "vmm guest" system
    facts['product_name'] = 'SVM'
    virtual = OpenBSDVirtual(module=None, facts=facts)
    vf = virtual.get_virtual_facts()
    assert vf['virtualization_type'] == 'vmm'
    assert vf['virtualization_role'] == 'guest'
    assert vf['virtualization_tech_guest']

# Generated at 2022-06-23 02:29:00.180580
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:29:06.016700
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    from ansible.module_utils.facts import ansible_facts
    if ansible_facts['ansible_virtualization_type'] == 'virtualbox':
        assert 'OpenBSD' in ansible_facts['virtual']['guest_os_name']
        assert 'OpenBSD' in ansible_facts['virtual']['hypervisor_os_name']
        assert 'OpenBSD' in ansible_facts['virtual']['system_type']

# Generated at 2022-06-23 02:29:15.112470
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Need to mock the get_file_content to return vmm0 at mainbus0 line
    # in the dmesg.boot.
    with mock.patch.object(OpenBSDVirtual, 'get_file_content') as get_file_content_mock:
        get_file_content_mock.return_value = 'vmm0 at mainbus0: SVM/RVI'
        virtual_facts = OpenBSDVirtual().get_virtual_facts()

        assert virtual_facts['virtualization_tech_host'] == {'vmm'}
        assert virtual_facts['virtualization_tech_guest'] == set()
        assert virtual_facts['virtualization_type'] == 'vmm'
        assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:29:18.141524
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual._fact_class.platform == 'OpenBSD'



# Generated at 2022-06-23 02:29:27.054507
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # initialize a test instance of OpenBSDVirtual class
    v = OpenBSDVirtual()

    # test result when dmidecode reports product name: iLO 3
    sysctl_values = {'hw.product': 'iLO 3'}
    virtual_facts = v.get_virtual_facts(sysctl=sysctl_values)
    # check virtualization_type is 'hvm'
    assert virtual_facts['virtualization_type'] == 'hvm'
    # check virtualization_role is 'host'
    assert virtual_facts['virtualization_role'] == 'host'
    # check virtualization_product_name is 'HP ProLiant DL'
    assert virtual_facts['virtualization_product_name'] == 'HP ProLiant DL'
    # check virtualization_product_version is 'Gen9'

# Generated at 2022-06-23 02:29:31.922371
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'
    assert v.DMESG_BOOT == '/var/run/dmesg.boot'
    assert v.VIRTUAL_PRODUCT_FILE == '/proc/cpuinfo'
    assert v.VIRTUAL_VENDOR_FILE == '/proc/cpuinfo'


# Generated at 2022-06-23 02:29:34.715803
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Always return empty value
    virt_facts = OpenBSDVirtual({}).get_virtual_facts()
    assert virt_facts['virtualization_type'] == ''

# Generated at 2022-06-23 02:29:44.287429
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    test_openbsd_virtual = OpenBSDVirtual()
    test_openbsd_virtual._platform = 'OpenBSD'
    test_openbsd_virtual.vendors = {'0x8086': 'intel', '0x106b': 'apple', '0x1022': 'amd'}
    test_openbsd_virtual.products = {'0x3a29': 'AppleVMX', '0x0b00': 'OpenBSD Virtual', '0x0b0c': 'NetBSD Virtual'}
    test_openbsd_virtual.hwvendors = {'i386': {'0x8086': 'intel'}, 'amd64': {'0x106b': 'apple', '0x1022': 'amd'}}

# Generated at 2022-06-23 02:29:48.161924
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:29:55.800186
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # GIVEN a class instance
    openbsd_virtual = OpenBSDVirtual()

    # WHEN calling get_virtual_facts method
    facts = openbsd_virtual.get_virtual_facts()

    # THEN the virtualization facts related keys should be in facts
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_system' in facts
    assert 'virtualization_hypervisor' in facts

# Generated at 2022-06-23 02:30:03.014488
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    # Load the virtual facts from a JSON file.
    with open('unit/ansible_collections/ansible/community/tests/unit/module_utils/facts/facts_d/virtual/openbsd_virtual.json') as virtual_facts_file:
        virtual_facts_from_file = json.load(virtual_facts_file)
        virtual_facts_from_system = openbsd_virtual.get_virtual_facts()
        assert virtual_facts_from_file == virtual_facts_from_system

# Generated at 2022-06-23 02:30:05.525921
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    f = OpenBSDVirtualCollector()
    assert f.platform == 'OpenBSD'
    assert f._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:14.548523
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    sysctl_info_for_test = {'hw.vendor': "",
                            'hw.product': "",
                            'hw.machine': "",
                            'hw.model': "",
                            'hw.machine_arch': ""}
    virtual_facts_for_test = OpenBSDVirtual(sysctl_info_for_test).get_virtual_facts()
    assert isinstance(virtual_facts_for_test['virtual'], dict)
    assert isinstance(virtual_facts_for_test['virtualization_role'], str)
    assert virtual_facts_for_test['virtualization_role'] == ''
    assert isinstance(virtual_facts_for_test['virtualization_type'], str)
    assert virtual_facts_for_test['virtualization_type'] == ''

# Generated at 2022-06-23 02:30:18.278674
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:30:24.730772
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    virtual_facts = v.get_virtual_facts()

    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_type'] == 'vmm'

    guest_tech = virtual_facts['virtualization_tech_guest']
    assert len(guest_tech) == 0
    assert 'vmm' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:30:28.087242
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:30:31.099794
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    klass = OpenBSDVirtual()
    assert klass
    assert klass.platform == 'OpenBSD'
    assert klass.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:30:37.199390
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual_values = {
        'virtualization_type': '',  # Virtualization type
        'virtualization_role': '',  # Virtualization type
        'virtualization_product_name': '',
    }
    assert openbsd_virtual.data == openbsd_virtual_values
    assert openbsd_virtual.platform == "OpenBSD"
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:30:39.843522
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj._platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:30:42.937282
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert(virtual_collector._platform == 'OpenBSD')
    assert(virtual_collector._fact_class == OpenBSDVirtual)

# Generated at 2022-06-23 02:30:44.196482
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert OpenBSDVirtualCollector._platform == 'OpenBSD'


# Generated at 2022-06-23 02:30:45.965606
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    o = OpenBSDVirtualCollector()
    assert o.platform == 'OpenBSD'
    assert o._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:30:50.910503
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:30:53.978603
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:30:57.319834
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual(None)
    assert virtual.get_virtual_facts() == {'virtualization_role': '', 'virtualization_type': '', 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:31:00.188557
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual({}, {}, {}, {})
    assert o.get_virtual_facts.__doc__ == 'Get virtualization facts for OpenBSD'
    assert o.platform == 'OpenBSD'


# Generated at 2022-06-23 02:31:05.284156
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Test constructor of class OpenBSDVirtual"""
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual
    assert openbsd_virtual.dmesg_boot == '/var/run/dmesg.boot'
    assert openbsd_virtual.platform == 'OpenBSD'



# Generated at 2022-06-23 02:31:09.816301
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual()
    assert o.virtualization_type == ''
    assert o.virtualization_role == ''

# Generated at 2022-06-23 02:31:13.467121
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """Unit test for constructor of class OpenBSDVirtualCollector"""
    result = OpenBSDVirtualCollector()

    assert isinstance(result, OpenBSDVirtualCollector)
    assert isinstance(result.collect(), dict)



# Generated at 2022-06-23 02:31:15.983533
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual(None)
    assert v.platform == 'OpenBSD'
    assert v.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:31:21.601189
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    data_virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': ''
    }

    virtual = OpenBSDVirtual(data_virtual_facts)
    virtual_facts = virtual.get_virtual_facts()

    assert isinstance(virtual_facts, dict)
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert 'virtualization_tech_host' in virtual_facts
    assert 'virtualization_tech_guest' in virtual_facts

# Generated at 2022-06-23 02:31:29.662924
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    v = OpenBSDVirtualCollector()
    assert v.platform == 'OpenBSD'
    assert v._fact_class.__name__ == 'OpenBSDVirtual'
    assert v._fact_class.platform == 'OpenBSD'
    assert not v._supported_dists


# Unit test the detection of OpenBSDVirtual (hw.vendor = 'GenuineIntel' and hw.product = 'Intel(R) Xeon(R) CPU E3-1220 V2 @ 3.10GHz')

# Generated at 2022-06-23 02:31:30.822600
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:31:36.797374
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    '''Unit test for constructor of class OpenBSDVirtual'''
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == "OpenBSD"
    assert openbsd_virtual.virtualization_type == ''
    assert openbsd_virtual.virtualization_role == ''

# Generated at 2022-06-23 02:31:49.238422
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # OpenBSD with no virtualization:
    virtual = OpenBSDVirtual()
    dmesg_boot = '''
OpenBSD 6.3-current (GENERIC) #59: Fri Jun 22 11:31:17 MDT 2018
    deraadt@i386.openbsd.org:/usr/src/sys/arch/i386/compile/GENERIC
real mem = 1257783296 (1193MB)
avail mem = 1210779648 (1154MB)
mainbus0 at root
'''
    with open(virtual.DMESG_BOOT, 'w') as f:
        f.write(dmesg_boot)
    virtual_facts = virtual.get_virtual_facts()
    # Virtual facts should be empty

# Generated at 2022-06-23 02:31:58.671762
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''
    Test get_virtual_facts of class OpenBSDVirtual
    '''
    # Facts parsed before testing
    virtual_facts_before_testing = {
        "virtualization_type": "",
        "virtualization_role": "",
        "virtualization_product_name": "",
        "virtualization_product_version": "",
        "virtualization_product_vendor": "",
        "virtualization_product_uuid": "",
        "virtualization_technology_guest": "",
        "virtualization_technology_host": "",
    }

    virtual_collector_before_testing = OpenBSDVirtualCollector(virtual_facts_before_testing)
    virtual_facts_after_testing = {}
    # Mock dmesg.boot file to simulate vmm(4) is attached

# Generated at 2022-06-23 02:31:59.693661
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    assert(OpenBSDVirtualCollector)



# Generated at 2022-06-23 02:32:04.108290
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_collector = OpenBSDVirtualCollector()
    openbsd_collector.collect()
    facts = openbsd_collector.get_facts()
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'


# Generated at 2022-06-23 02:32:05.981722
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module_args = dict()
    vm = OpenBSDVirtual(module_args, {})
    assert vm.platform == "OpenBSD"


# Generated at 2022-06-23 02:32:08.009753
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert openbsd_virtual._fact_class == OpenBSDVirtual
    assert openbsd_virtual._platform == 'OpenBSD'

# Generated at 2022-06-23 02:32:15.677699
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual({'ansible_facts': {}})
    assert o.platform == 'OpenBSD'
    assert o.DMESG_BOOT == '/var/run/dmesg.boot'
    assert o.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }



# Generated at 2022-06-23 02:32:19.177307
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    collect = OpenBSDVirtualCollector()
    assert collect.platform == 'OpenBSD'
    assert collect.fact_class._platform == 'OpenBSD'
    assert collect.fact_class.DMESG_BOOT == '/var/run/dmesg.boot'
    assert collect.fact_class.platform == 'OpenBSD'

# Generated at 2022-06-23 02:32:19.900648
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    hypervisor = OpenBSDVirtual()
    hypervisor.get_virtual_facts()

# Generated at 2022-06-23 02:32:20.997313
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:32:29.734417
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    # These values are hardcoded in the tested implementation, use them in the
    # test.
    OpenBSDVirtual.DMESG_BOOT = 'tests/module_utils/facts/virtual/OpenBSDVirtual/dmesg.boot'
    sut = OpenBSDVirtual(module=None)
    virtual_facts = sut.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'vmm' in virtual_facts['virtualization_tech_guest']
    assert 'vmm' in virtual_facts['virtualization_tech_host']

# Generated at 2022-06-23 02:32:34.238348
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_obj = OpenBSDVirtual()
    openbsd_virtual_obj.get_virtual_facts()



# Generated at 2022-06-23 02:32:45.479928
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test empty dmesg.boot.
    virtual_facts = OpenBSDVirtual().get_virtual_facts({'DMESG_BOOT': ''})

    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_host']
    assert not virtual_facts['virtualization_tech_guest']

    # Test dmesg.boot with SVM/RVI
    virtual_facts = OpenBSDVirtual().get_virtual_facts(
        {'DMESG_BOOT': 'vmm0 at pci0 dev 17 function 0 "AMD AMD-Vi" rev 0x01'})

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:32:54.081485
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    content = """
vmm0 at mainbus0: SVM/RVI
"""
    # Save the content of the dmesg.boot file in order to restore it later
    backup_dmesg = get_file_content(OpenBSDVirtual.DMESG_BOOT)

# Generated at 2022-06-23 02:32:57.176580
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:33:00.090055
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    info = {'ansible_facts':{'virtualization_type':'', 'virtualization_role':''}}
    info = OpenBSDVirtualCollector(info)
    assert info


# Generated at 2022-06-23 02:33:09.020290
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Test with OpenBSD as host
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type_role'] == ''

    # Test with OpenBSD as guest
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type_role'] == ''

# Generated at 2022-06-23 02:33:15.050371
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:33:18.826279
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_facts = virtual_facts_object()
    assert virtual_facts._platform == 'OpenBSD'
    assert virtual_facts._fact_class == OpenBSDVirtual
    assert isinstance(virtual_facts._fact_class, object)


# Generated at 2022-06-23 02:33:20.908913
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:33.171861
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    # Create a instance of class OpenBSDVirtual
    results = OpenBSDVirtual({})

    # Create a dictionary,  which will be returned by _get_dmesg_boot_content
    dmesg_boot_content = {
        'lines': ['svm: SVM disabled by the BIOS',
                  'vmm0 at mainbus0: SVM/RVI',
                  'vmd0 at vmm0',
                  'vmd0: vmport 0x0, host interface (null)']
    }

    # Create a dict with keys, which would be returned by facts, when
    # executing on an OpenBSD with VMware ESXi 5.5
    expected = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host'
    }

    # Extend our OpenBSDVirtual, so the method _get_dmes

# Generated at 2022-06-23 02:33:37.628799
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Create a class instance
    openbsd_virtual = OpenBSDVirtual()

    # Create a class instance and call set_virtual_facts()
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    openbsd_virtual_collector.set_virtual_facts()

    # Compare the two dicts
    assert openbsd_virtual.virtual_facts == openbsd_virtual_collector.virtual_facts

# Generated at 2022-06-23 02:33:42.224009
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:33:51.411418
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()

    # Test with a single hypervisors product
    virtual.sysctl['hw.vendor'] = 'OpenBSD'
    virtual.sysctl['hw.product'] = 'OpenBSD'
    facts = virtual.get_virtual_facts()
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert facts['virtualization_product'] == 'OpenBSD'
    assert facts['virtualization_product_brand'] == 'OpenBSD'
    assert facts['virtualization_product_version'] == 'OpenBSD'
    assert facts['virtualization_product_version_major'] == 'OpenBSD'

    virtual.sysctl['hw.product'] = 'Firefox'
    facts = virtual.get_virtual_facts()
    assert 'virtualization_type' not in facts

# Generated at 2022-06-23 02:33:53.102147
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual, OpenBSDVirtualCollector)


# Generated at 2022-06-23 02:34:03.635405
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:34:13.144732
# Unit test for method get_virtual_facts of class OpenBSDVirtual