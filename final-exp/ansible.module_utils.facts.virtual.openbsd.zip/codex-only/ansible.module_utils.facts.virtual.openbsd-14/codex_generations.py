

# Generated at 2022-06-23 02:24:18.013284
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    # Class attribute accesses should be done through api
    # _platform: This variable is never used in the code
    # pylint: disable=no-member
    OpenBSDVirtual._platform = 'OpenBSD'
    OpenBSDVirtual._fact_class = OpenBSDVirtual
    OpenBSDVirtual.DMESG_BOOT = './tests/unittests/test_files/dmesg_boot_openbsd'
    facts = {}
    vplatform = OpenBSDVirtual()
    vplatform.populate()
    virtual_facts = vplatform.get_virtual_facts()

    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert 'hw' in virtual_facts['virtualization_tech_guest']


# Generated at 2022-06-23 02:24:20.392915
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform == 'OpenBSD'

# Generated at 2022-06-23 02:24:23.977905
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()
    facts = virt.get_virtual_facts()
    assert 'virtualization_type' in facts
    assert 'virtualization_role' in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts

# Generated at 2022-06-23 02:24:28.511287
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual = OpenBSDVirtualCollector()
    assert isinstance(openbsd_virtual, OpenBSDVirtualCollector)
    assert openbsd_virtual._fact_class == OpenBSDVirtual
    assert openbsd_virtual.platform == 'OpenBSD'


# Generated at 2022-06-23 02:24:36.946430
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    collector = OpenBSDVirtualCollector()
    virtual_facts = collector.get_virtual_facts()

    assert 'virtualization_type' not in virtual_facts

    # Virtualization facts which exist on all systems
    assert virtual_facts['virtualization_role'] == ''
    assert virtual_facts['virtualization_technologies'] == set()

    # Virtualization facts which exist on any system, but not all
    assert virtual_facts['virtualization_tech_host'] == set()
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_product_name'] == ''
    assert virtual_facts['virtualization_product_version'] == ''

# Generated at 2022-06-23 02:24:39.957510
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts_object = OpenBSDVirtual()
    assert virtual_facts_object
    assert virtual_facts_object.platform == 'OpenBSD'
    assert virtual_facts_object.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:24:42.736214
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    oob = OpenBSDVirtualCollector()
    assert oob.platform == 'OpenBSD'
    assert oob.fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:24:46.754525
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:24:48.967628
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    try:
        OpenBSDVirtualCollector()
    except Exception:
        assert False, "Error while creating virtualization collector"

# Generated at 2022-06-23 02:24:54.285830
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    platform_pat = re.compile("OpenBSD")
    platform = platform_pat.match("OpenBSD")
    
    virtualCol = OpenBSDVirtualCollector("name",platform,"version",None)
    assert isinstance(virtualCol,OpenBSDVirtualCollector)
    assert virtualCol.fact_class == OpenBSDVirtual

# Unit test to check if a virtual guest is detected

# Generated at 2022-06-23 02:24:58.092190
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Constructor test for class OpenBSDVirtualCollector
    openbsd_collector = OpenBSDVirtualCollector()
    assert openbsd_collector._fact_class == OpenBSDVirtual
    assert openbsd_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:02.612427
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    result = OpenBSDVirtualCollector()
    assert result.platform == 'OpenBSD', 'platform fact is not set correctly'
    assert str(result.__class__) == "<class 'ansible.module_utils.facts.virtual.openbsd.OpenBSDVirtualCollector'>", 'class is not as expected'
    assert result._fact_class == OpenBSDVirtual
    assert result._platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:05.472474
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual = OpenBSDVirtualCollector()
    assert virtual.platform == 'OpenBSD'
    assert virtual._fact_class == OpenBSDVirtual
    assert virtual._platform == 'OpenBSD'

# Generated at 2022-06-23 02:25:09.989322
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualCollector
    assert OpenBSDVirtualCollector.collector_class() is OpenBSDVirtualCollector


# Generated at 2022-06-23 02:25:14.265446
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual_obj = OpenBSDVirtual()
    openbsd_virtual_obj.collect()
    openbsd_virtual_obj.get_virtual_facts()

# Generated at 2022-06-23 02:25:23.640840
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    OpenBSDVirtual_get_virtual_facts = OpenBSDVirtual()
    # Missing hw.product and hw.vendor
    assert OpenBSDVirtual_get_virtual_facts.get_virtual_facts() == {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Provide hw.product and hw.vendor
    OpenBSDVirtual_get_virtual_facts._detect_virt_product = lambda x: {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }
    OpenBSDVirtual_get_virtual_facts._detect_virt

# Generated at 2022-06-23 02:25:26.555981
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Test the constructor of class OpenBSDVirtual.

    This function tests that the constructor of class OpenBSDVirtual can be called without
    any error.
    """

    # Just call the constructor.
    OpenBSDVirtual()

# Generated at 2022-06-23 02:25:34.667360
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # OpenBSD of a host is always a host
    test_machinedesc = 'some_machinedesc'
    test_hwvendor = 'some_hwvendor'
    test_hwproduct = 'some_hwproduct'
    test_result = 'host'
    test_expected = {
        'virtualization_role': test_result,
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # Prepare
    class TestOpenBSDVirtual(OpenBSDVirtual):
        pass

    class TestParams():
        hw_machinedesc = test_machinedesc
        hw_vendor = test_hwvendor
        hw_product = test_hwproduct


# Generated at 2022-06-23 02:25:43.588949
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    facts_collector = FactCollector()
    openbsd_virtual = OpenBSDVirtual(facts_collector)
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual.platform == 'OpenBSD'
    assert openbsd_virtual.get_virtual_facts() == \
        {'virtualization_role': '',
         'virtualization_type': '',
         'virtualization_tech_host': set(['vmm']),
         'virtualization_tech_guest': set([])}

# Generated at 2022-06-23 02:25:52.894502
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    hypervisor_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'host',
        'virtualization_tech_guest': {'vmm'},
        'virtualization_tech_host': {'vmm'},
        'virtualization_product_name': 'OpenBSD',
        'virtualization_product_version': '6.0'
    }
    assert OpenBSDVirtual().get_virtual_facts() == hypervisor_facts
    assert OpenBSDVirtualCollector().get_virtual_facts() == hypervisor_facts

# Generated at 2022-06-23 02:26:00.134520
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_instance = OpenBSDVirtual({})
    assert openbsd_virtual_instance.__doc__ == "This is a OpenBSD-specific subclass of Virtual.  It defines\n- virtualization_type\n- virtualization_role"
    assert openbsd_virtual_instance.platform == 'OpenBSD'
    assert openbsd_virtual_instance.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:26:09.395733
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    # Set the 'hw.vendor' sysctl value so we can test the 'hw.product' sysctl path
    virtual.sysctl = {'hw.vendor': 'QEMU'}
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert 'vmm' in virtual_facts['virtualization_tech_guest']
    assert 'virtualbox' in virtual_facts['virtualization_tech_host']
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_product_name'] == 'QEMU'
    assert virtual_facts['virtualization_product_version'] == '1.0.0'

# Generated at 2022-06-23 02:26:17.278451
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Test for when dmesg_boot contains vmm0 and no virtualization_type is set
    test_OpenBSDVirtual = OpenBSDVirtual(None)
    test_OpenBSDVirtual.DMESG_BOOT = 'dmesg_boot.vmm0'
    actual_virtual_facts = test_OpenBSDVirtual.get_virtual_facts()
    assert actual_virtual_facts['virtualization_type'] == 'vmm'
    assert actual_virtual_facts['virtualization_role'] == 'host'
    assert actual_virtual_facts['virtualization_tech_guest'] == set(['vmm'])
    assert actual_virtual_facts['virtualization_tech_host'] == set(['vmm'])

    # Test for when dmesg_boot contains vmm0 and virtualization_type is set
    test_OpenBSDVirtual = Open

# Generated at 2022-06-23 02:26:20.174380
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert 'virtualization_type' in virtual_facts.get_virtual_facts()

# Generated at 2022-06-23 02:26:30.994140
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''
    Test get_virtual_facts of OpenBSDVirtual
    '''
    # Test virtualization_type and virtualization_role
    virtual_product_facts = dict(virtualization_type='',
                                 virtualization_role='',
                                 virtualization_tech_guest=set(),
                                 virtualization_tech_host=set())
    virtual_product_facts['virtualization_tech_guest'].update(['hyperv', 'vmware'])
    virtual_product_facts['virtualization_tech_host'].update(['hyperv', 'vmware'])
    virtual_product_facts['virtualization_type'] = 'hyperv'
    virtual_product_facts['virtualization_role'] = 'guest'


# Generated at 2022-06-23 02:26:33.643932
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    test_collector = OpenBSDVirtualCollector()
    assert test_collector._fact_class == OpenBSDVirtual
    assert test_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:26:35.349984
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual({})
    assert openbsd_virtual is not None

# Generated at 2022-06-23 02:26:41.290846
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()

    assert virtual_facts.platform == 'OpenBSD'
    assert virtual_facts.get_virtual_facts() == {
        'virtualization_role': '', 'virtualization_type': '',
        'virtualization_technologies_guest': set(),
        'virtualization_technologies_host': set()
    }


# Generated at 2022-06-23 02:26:50.623196
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual_facts = OpenBSDVirtual().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''

    # A mocked dmesg.boot file, just to get vmm(4) detected as host
    class OpenBSDVirtualWithVmm:
        DMESG_BOOT = './tests/unit/module_utils/facts/virtual/dmesg_boot.txt'

    virtual_facts = OpenBSDVirtualWithVmm().get_virtual_facts()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'

# Generated at 2022-06-23 02:26:54.934349
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    bsd_virtual = OpenBSDVirtual({})
    response = bsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in response
    assert 'virtualization_role' in response
    assert 'virtualization_tech_guest' in response
    assert 'virtualization_tech_host' in response

# Generated at 2022-06-23 02:26:55.896688
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:27:04.331086
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    # Write product output to simulate a hardware vendor
    mock_product_return_values = (
        ('OpenBSD \n', 'openbsd'),
        ('OpenBSD', 'openbsd'),
        ('OpenBSD', None),
        ('', None),
    )

    # Write vendor output to simulate a hardware vendor
    mock_vendor_return_values = (
        ('OpenBSD \n', 'openbsd'),
        ('OpenBSD', 'openbsd'),
        ('OpenBSD', None),
        ('', None),
    )

    # Structure for set of return values for sysctl call

# Generated at 2022-06-23 02:27:08.779116
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual._virtual.platform == 'OpenBSD'
    assert openbsd_virtual._virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:27:18.992659
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:27:28.624851
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # arrange
    from sysctl import sysctl

    # act
    ov = OpenBSDVirtual()

    # assert
    assert ov.get_virtual_facts()['virtualization_type'] == ''
    assert ov.get_virtual_facts()['virtualization_role'] == ''
    sysctl.set_property("hw.vendor", "QEMU")
    assert ov.get_virtual_facts()['virtualization_type'] == 'virtualbox'
    assert ov.get_virtual_facts()['virtualization_role'] == 'guest'
    sysctl.set_property("hw.product", "bhyve")
    assert ov.get_virtual_facts()['virtualization_type'] == 'bhyve'
    assert ov.get_virtual_facts()['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:27:37.366214
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    """
    Return a fact dict for the given platform
    Supported platforms are Linux, FreeBSD and OpenBSD.
    The dict is then used as:
        - Multiple choice inventory variables
        - Multiple choice Conditional statements
        - Templates
    """
    import json
    import pkg_resources

    # Load the test data
    tests_json = pkg_resources.resource_filename(__name__, 'tests/unit_tests/virtual/OpenBSD_virtual_facts.json')
    with open(tests_json) as data_file:
        tests_json = json.load(data_file)

    for test in tests_json.get('virtual_facts'):
        # Set up the test
        virtual_collector = OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:27:39.150759
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual({})
    assert not virtual_facts.gather_facts()

# Generated at 2022-06-23 02:27:49.458306
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    import os
    import tempfile

    kern_bootfile = 'boot file: /bsd'
    vmm_output = 'vmm0 at mainbus0: SVM/RVI'

    # Write a temporary dmesg.boot file.
    openbsd_dmesg_boot_content = kern_bootfile + '\n' + vmm_output + '\n'

    dmesg_fd, dmesg_path = tempfile.mkstemp()
    with os.fdopen(dmesg_fd, 'w') as dmesg_file:
        dmesg_file.write(openbsd_dmesg_boot_content)

    qemu_output = """hw.product=OpenBSD
hw.vendor=QEMU"""

    # Write a temporary sysctl file.
    tmp_

# Generated at 2022-06-23 02:28:00.367531
# Unit test for constructor of class OpenBSDVirtual

# Generated at 2022-06-23 02:28:04.032201
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None, None)

    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'
    assert openbsd_virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:06.535483
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert isinstance(obj._fact_class, OpenBSDVirtual)
    assert obj.platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:10.740458
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual({'ansible_facts': {}})
    virt_facts = virt.get_virtual_facts()
    assert virt_facts['virtualization_role'] == ''
    assert virt_facts['virtualization_type'] == ''
    assert 'virtualization_tech' in virt_facts



# Generated at 2022-06-23 02:28:11.743300
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    OpenBSDVirtualCollector()

# Generated at 2022-06-23 02:28:13.508784
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt.platform == 'OpenBSD'


# Generated at 2022-06-23 02:28:16.390842
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt_facts = Virtual(None)
    assert virt_facts.platform == "OpenBSD"
    assert virt_facts._virtualization_type == ''
    assert virt_facts._virtualization_role == ''

# Generated at 2022-06-23 02:28:24.490760
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    virtual_facts = openbsd_virtual.get_virtual_facts()
    assert 'virtualization_type' in virtual_facts
    assert 'virtualization_role' in virtual_facts
    assert virtual_facts['virtualization_type'] in ('virtualbox',
                                                    'vmware', 'kvm', 'xen', '')
    assert virtual_facts['virtualization_role'] in ('guest', 'host', '')

# Generated at 2022-06-23 02:28:27.674628
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual_facts = OpenBSDVirtual()
    assert openbsd_virtual_facts is not None
    assert openbsd_virtual_facts.platform == 'OpenBSD'


# Generated at 2022-06-23 02:28:29.932515
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert isinstance(collector._fact_class, OpenBSDVirtual)
    assert collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:28:36.819098
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.__class__.__name__ == 'OpenBSDVirtual'

    # Check that get_virtual_facts return
    # a list of hash (dictionary)
    openbsd_virtual.get_virtual_facts() and type(openbsd_virtual.get_virtual_facts() == list)
    for virtual_facts in openbsd_virtual.get_virtual_facts():
        assert type(virtual_facts) is dict

# Generated at 2022-06-23 02:28:43.867171
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Create an instance of OpenBSDVirtual
    open_bsd_virtual = OpenBSDVirtual()

    # Check 'virtualization_type' variable
    assert open_bsd_virtual.data['virtualization_type'] == ''

    # Check 'virtualization_role' variable
    assert open_bsd_virtual.data['virtualization_role'] == ''

    # Check 'virtualization_tech_guest' variable, empty set
    assert open_bsd_virtual.data['virtualization_tech_guest'] == set()

    # Check 'virtualization_tech_host' variable, empty set
    assert open_bsd_virtual.data['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:28:45.513454
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt = OpenBSDVirtual()
    virt.get_virtual_facts()


# Generated at 2022-06-23 02:28:47.891052
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facter_virtual = OpenBSDVirtual()
    assert facter_virtual.virtual == {}


# Generated at 2022-06-23 02:28:57.570541
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    v = OpenBSDVirtual()
    facts = v.get_virtual_facts()
    # Tests for VMware ESX guest
    assert facts['virtualization_type'] == 'VMware'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['vmware'])
    assert facts['virtualization_tech_host'] == set(['vmware'])
    # Tests for VMware ESXi host
    v.facts['hw.product'] = 'VMware Virtual Platform'
    facts = v.get_virtual_facts()
    assert facts['virtualization_type'] == 'VMware'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech_guest'] == set([])

# Generated at 2022-06-23 02:29:00.987179
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()

    # Method get_virtual_facts must return a dictionary
    assert isinstance(openbsd_virtual.get_virtual_facts(), dict)


# Generated at 2022-06-23 02:29:05.042261
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert c._platform == 'OpenBSD'

    # Class OpenBSDVirtualCollector should be a subclass of class VirtualCollector
    assert isinstance(c, VirtualCollector)
    # Class OpenBSDVirtualCollector should be a superclass of class OpenBSDVirtual
    assert issubclass(OpenBSDVirtual, c._fact_class)

# Generated at 2022-06-23 02:29:14.945246
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    from sys import platform
    from collections import namedtuple
    from ansible.module_utils.facts.virtual.atoz import VirtualCollector

    Virtual = namedtuple('Virtual', ['name', 'value'])
    Hardware = namedtuple('Hardware', ['name', 'value'])

# Generated at 2022-06-23 02:29:19.253700
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # get a OpenBSDVirtual object
    virtual = OpenBSDVirtual()
    # Test the constructor of OpenBSDVirtual,
    # only the result of virtual.platform is checked here,
    # the testing for other funtions of OpenBSDVirtual
    # are in the test_OpenBSDVirtualCollector
    assert virtual.platform == 'OpenBSD'



# Generated at 2022-06-23 02:29:22.736825
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()

    assert virtual_collector._platform == 'OpenBSD'
    assert virtual_collector._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:29:29.424671
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    '''Unit test for method get_virtual_facts of class OpenBSDVirtual'''
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.get_virtual_facts() == dict(
        virtualization_type='',
        virtualization_role='',
        virtualization_tech_host=set(),
        virtualization_tech_guest=set(),
    )

# Generated at 2022-06-23 02:29:37.200727
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    module = OpenBSDVirtual()

    # machine is bare-metal
    module.sysctl_get = lambda k: None
    assert module.get_virtual_facts() == {
        'virtualization_role': '',
        'virtualization_type': '',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    # machine is a host
    module.sysctl_get = lambda k: '''OpenBSD'''
    assert module.get_virtual_facts() == {
        'virtualization_role': 'host',
        'virtualization_type': 'vmm',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(['vmm'])
    }

    # machine is a guest

# Generated at 2022-06-23 02:29:44.135767
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_collector = OpenBSDVirtualCollector()

    # Set data for vmm detection

# Generated at 2022-06-23 02:29:47.535847
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = OpenBSDVirtual()
    assert 'OpenBSD' == facts.platform
    assert 'virtualization_type' in facts.get_virtual_facts()
    assert 'virtualization_role' in facts.get_virtual_facts()

# Generated at 2022-06-23 02:29:49.339502
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = OpenBSDVirtual(module=None)
    assert facts.platform == 'OpenBSD'


# Generated at 2022-06-23 02:29:50.968012
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Unit test for constructor of class OpenBSDVirtual"""
    # OpenBSDVirtual(module)
    assert OpenBSDVirtual

# Generated at 2022-06-23 02:29:53.937418
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    """
    Verify that OpenBSDVirtualCollector class can be instantiated.
    """
    collector = OpenBSDVirtualCollector()
    assert collector

# Generated at 2022-06-23 02:30:05.065491
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():

    def mock_detect_virt_product(self, sysctl):
        return {'virtualization_tech_guest': set(),
                'virtualization_tech_host': set(),
                'virtualization_type': 'qemu',
                'virtualization_role': 'host'}

    def mock_detect_virt_vendor(self, sysctl):
        return {'virtualization_tech_guest': set(),
                'virtualization_tech_host': set(),
                'virtualization_type': '',
                'virtualization_role': ''}

    virtual = OpenBSDVirtual()
    virtual._detect_virt_product = mock_detect_virt_product.__get__(virtual)
    virtual._detect_virt_vendor = mock_detect_virt_vendor.__get__(virtual)


# Generated at 2022-06-23 02:30:06.881271
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = OpenBSDVirtual()
    assert isinstance(facts, OpenBSDVirtual)


# Generated at 2022-06-23 02:30:15.962209
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()

    # No virtualization_type in /var/run/dmesg.boot and no dmesg output
    # from get_file_content, this will indicate the machine is not
    # virtualized
    virtual.get_file_content = lambda x: ''
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] == ''
    assert virtual_facts['virtualization_role'] == ''
    assert not virtual_facts['virtualization_tech_guest']
    assert not virtual_facts['virtualization_tech_host']

    # No virtualization_type in /var/run/dmesg.boot but dmesg output
    # from get_file_content contains 'vmm0 at mainbus0: SVM/RVI' or
    # 'vmm0 at

# Generated at 2022-06-23 02:30:19.354365
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector._fact_class == OpenBSDVirtual
    assert openbsd_virtual_collector._platform == 'OpenBSD'

# Generated at 2022-06-23 02:30:23.241890
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd = OpenBSDVirtual('OpenBSD')
    assert openbsd.platform == 'OpenBSD'
    assert openbsd.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:30:25.570266
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector.platform == 'OpenBSD'
    assert collector._fact_class == OpenBSDVirtual

# Generated at 2022-06-23 02:30:30.169667
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()

    # All key/values should be empty, since this is not a virtualized platform
    for key in virtual_facts:
        assert(virtual_facts[key] == '')

# Generated at 2022-06-23 02:30:33.153051
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    collector = OpenBSDVirtualCollector()
    assert collector._platform == 'OpenBSD'
    assert collector.__class__.__name__ == 'OpenBSDVirtualCollector'
    assert collector.collect()['virtualization_type'] == ''

# Generated at 2022-06-23 02:30:36.459360
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts = OpenBSDVirtual()
    assert virtual_facts.virtualization_type == ''
    assert virtual_facts.virtualization_role == ''
    assert virtual_facts.virtualization_tech_guest == set()
    assert virtual_facts.virtualization_tech_host == set()

# Generated at 2022-06-23 02:30:41.963751
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    facts = OpenBSDVirtual({})
    assert facts.virtualization_type == ''
    assert facts.virtualization_role == ''
    assert len(facts.virtualization_tech_guest) == 0
    assert len(facts.virtualization_tech_host) == 0

# Generated at 2022-06-23 02:30:52.069895
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # pylint: disable=protected-access
    # This class shares code with FreeBSD.
    #
    # The testing methods are implemented in the class
    # ansible.module_utils.facts.virtual.sysctl.SysctlVirtualizationDetectionMixin.
    #
    # The class SysctlVirtualizationDetectionMixin is tested in the
    # test_FreeBSDVirtual_get_virtual_facts function.
    #
    # Therefore, this function only tests additional code paths.
    #
    # pylint: enable=protected-access
    _tested_facts = OpenBSDVirtual()

    # Test empty dmesg.boot
    dmesg_boot = ''
    _tested_facts.DMESG_BOOT = '/some/non/existing/file'

# Generated at 2022-06-23 02:31:01.517857
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    class Options(object):
        def __init__(self, facts):
            self.gather_subset = ['!all', 'virtual']
            self.filter = facts

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

    _openbsd = OpenBSDVirtual()

    # Prepare test data
    _cpu_system = 100
    _cpu_product = 'VMWare Virtual Platform'
    _cpu_vendor = 'GenuineIntel'
    _cpu_svm = {'hw.svm': 0}
    _cpu_vmx = {'hw.vmx': 1}
    _cpu_zero = {'hw.vmx': 0}
    _product_prod = {'hw.product': 'VirtualBox'}

# Generated at 2022-06-23 02:31:03.204544
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'

# Generated at 2022-06-23 02:31:07.706889
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    # Test that class OpenBSDVirtual can be successfully instantiated
    ovm = OpenBSDVirtual()

    # Test that class OpenBSDVirtual has correct class variables
    assert ovm.platform == 'OpenBSD'
    assert ovm.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:31:11.991225
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'
    assert isinstance(virtual_collector._fact_class, OpenBSDVirtual)

# Generated at 2022-06-23 02:31:14.227635
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    vc = OpenBSDVirtualCollector()
    assert vc._fact_class == OpenBSDVirtual
    assert vc._platform == 'OpenBSD'

# Generated at 2022-06-23 02:31:18.365089
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    virtual_facts = virtual.get_virtual_facts()
    assert virtual_facts['virtualization_type'] != ''
    assert virtual_facts['virtualization_role'] != ''
    assert virtual_facts['virtualization_tech_guest'] != set()
    assert virtual_facts['virtualization_tech_host'] != set()

# Generated at 2022-06-23 02:31:21.967328
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsdvirtual = OpenBSDVirtual(None)
    assert openbsdvirtual.platform == 'OpenBSD'
    assert openbsdvirtual.DMESG_BOOT == '/var/run/dmesg.boot'


# Generated at 2022-06-23 02:31:26.113376
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_facts = OpenBSDVirtualCollector(None, None, None, None, None)
    assert isinstance(openbsd_virtual_facts._fact_class, OpenBSDVirtual)

# Generated at 2022-06-23 02:31:29.662519
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    o = OpenBSDVirtual(None, None, None)
    assert o._facts['virtualization_type'] == ''
    assert o._facts['virtualization_role'] == ''
    assert 'OpenBSD' in o._platforms

# Generated at 2022-06-23 02:31:33.762729
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virtual = OpenBSDVirtual()
    facts = virtual.get_virtual_facts()

    assert facts['virtualization_type'] == ''
    assert facts['virtualization_role'] == ''

    assert facts['virtualization_tech_guest'] == set()
    assert facts['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:31:37.214206
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_facts_ins = OpenBSDVirtual()
    assert openbsd_facts_ins.platform == 'OpenBSD'
    assert openbsd_facts_ins.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:31:42.939161
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual({})
    facts = openbsd_virtual.get_virtual_facts()

    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'host'
    assert facts['virtualization_tech_host'] == {'vmm'}
    assert facts['virtualization_tech_guest'] == set()

# Generated at 2022-06-23 02:31:45.368215
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual(None)
    assert openbsd_virtual.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-23 02:31:56.768378
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    collected_facts = {}

    # create a OpenBSDVirtual object
    testobj = OpenBSDVirtual(collected_facts, None)

    # make the test object think this host is virtual
    testobj.facts['virtualization_type'] = 'test'

    # create a dictionary with expected results when the host is virtual
    expected_facts = {
        'virtualization_type': 'test',
        'virtualization_role': 'host',
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': {'test'}
    }

    # run the get_virtual_facts method
    results = testobj.get_virtual_facts()

    # check if the results are the same as expected facts
    assert results == expected_facts

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 02:31:57.824398
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virt = OpenBSDVirtual()
    assert virt

# Generated at 2022-06-23 02:32:02.952283
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    expected = {'virtualization_type': '', 'virtualization_role': '', 'virtualization_product': '', 'virtualization_technology': '', 'virtualization_technologies': {}}

    assert(openbsd_virtual.platform == 'OpenBSD')
    assert(openbsd_virtual.virtual_facts == expected)

# Generated at 2022-06-23 02:32:05.452980
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector.fact_class == OpenBSDVirtual
    assert virtual_collector.platform == 'OpenBSD'

# Generated at 2022-06-23 02:32:09.036791
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    virt_collector = OpenBSDVirtualCollector()
    virt_facts = virt_collector.get_virtual_facts()
    assert virt_facts == {"virtualization_type": "",
                          "virtualization_role": "",
                          "virtualization_technologies_guest": set(),
                          "virtualization_technologies_host": set()}

# Generated at 2022-06-23 02:32:19.319090
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    from ansible.module_utils._text import to_bytes

    # Something to put in module.params['gather_subset'] so that we call get_virtual_facts
    set_gather_subset = ['!all', 'virtual']

    # Create a instance of the OpenBSDVirtual class.
    oBSDVirtual = OpenBSDVirtual()

    # Create a set of virtual facts for different virtualization type
    virtual_facts = dict()

    # VirtualBox
    with open("test/unit/ansible_facts/virtual/dmesg-vbox.txt", "rb") as f:
        virtual_facts['dmesg_boot'] = to_bytes(f.read())
    with open("test/unit/ansible_facts/virtual/sysctl-vm.txt", "rb") as f:
        virtual_facts['sysctl_vm']

# Generated at 2022-06-23 02:32:21.001621
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()

    assert openbsd_virtual._platform == 'OpenBSD'

# Generated at 2022-06-23 02:32:25.935891
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    v = OpenBSDVirtual()
    assert v.platform == 'OpenBSD'
    assert v.DMESG_BOOT == '/var/run/dmesg.boot'
    assert hasattr(v, 'get_virtual_facts')
    assert v.virtualization_type == ''
    assert v.virtualization_role == ''

# Unit tests for OpenBSDVirtual.get_virtual_facts()

# Generated at 2022-06-23 02:32:33.005498
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector(): # pylint: disable=too-many-locals
    """
    Create an instance of OpenBSDVirtualCollector
    """
    # Create instance of class OpenBSDVirtualCollector
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    # Get sysctl facts
    openbsd_sysctl_facts = openbsd_virtual_collector.get_sysctl_facts()
    # Get virtual facts
    openbsd_virtual_facts = openbsd_virtual_collector.collect(openbsd_sysctl_facts, [])
    # Get facts keys
    openbsd_virtual_facts_keys = openbsd_virtual_facts.keys()
    # Get facts keys reference

# Generated at 2022-06-23 02:32:41.360652
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    openbsd_virtual = OpenBSDVirtual()
    dmesg_boot = get_file_content('tests/fixtures/dmesg.boot')

    # Test empty dmesg.boot
    assert openbsd_virtual.get_virtual_facts() == {'virtualization_type': '',
                                                   'virtualization_role': '',
                                                   'virtualization_tech_host': set(),
                                                   'virtualization_tech_guest': set()}

    # Test with vmm(4) attached in dmesg.boot
    openbsd_virtual.DMESG_BOOT = 'tests/fixtures/dmesg.boot'

# Generated at 2022-06-23 02:32:51.126342
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_facts_collector = OpenBSDVirtualCollector()
    dmesg_boot = get_file_content(OpenBSDVirtual.DMESG_BOOT)
    virtual_facts_collector._cache['dmesg_boot'] = dmesg_boot

    virtual_facts = virtual_facts_collector.collect()
    assert virtual_facts['virtualization_type'] == 'vmm'
    assert virtual_facts['virtualization_role'] == 'host'
    assert virtual_facts['virtualization_product'] == 'OpenBSD'
    assert virtual_facts['virtualization_vendor'] == 'OpenBSD'
    assert virtual_facts['virtualization_tech_guest'] == set()
    assert virtual_facts['virtualization_tech_host'] == {'vmm'}


# Generated at 2022-06-23 02:32:52.894487
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector=OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.platform=='OpenBSD'

# Generated at 2022-06-23 02:32:53.553570
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    assert OpenBSDVirtual()

# Generated at 2022-06-23 02:33:04.374569
# Unit test for method get_virtual_facts of class OpenBSDVirtual

# Generated at 2022-06-23 02:33:07.777125
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """Test constructor of class OpenBSDVirtual"""
    virtual = OpenBSDVirtual()
    assert virtual.platform == 'OpenBSD'
    assert virtual.virt_type == ''
    assert virtual.virt_role == ''


# Generated at 2022-06-23 02:33:10.089817
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    # Check correct initialization of a class
    assert OpenBSDVirtualCollector().fact_class._platform == 'OpenBSD'

# Generated at 2022-06-23 02:33:12.763485
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    obj = OpenBSDVirtualCollector()
    assert obj.platform == 'OpenBSD'
    assert obj._fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:33:18.681354
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    """
    Test if constructor of class OpenBSDVirtual works as expected
    """
    virtual = OpenBSDVirtual()

    # Test if 'virtual' is of type Virtual
    assert isinstance(virtual, Virtual)
    assert virtual.platform == 'OpenBSD'
    assert virtual.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-23 02:33:21.194602
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    virtual_collector = OpenBSDVirtualCollector()
    assert virtual_collector._platform == 'OpenBSD'



# Generated at 2022-06-23 02:33:32.285577
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # Generate test input and output
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    test_input = {
        'sysctl': {
        }
    }

    test_output = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
    }

    # Generate test Virtual object
    test_OpenBSDVirtual = OpenBSDVirtual()

    # Get virtual facts from Virtual object
    test_virtual_facts = test_OpenBSDVirtual.get_virtual_facts(test_input)

    # Check virtual facts
    assert test_virtual_facts == test_output

# Generated at 2022-06-23 02:33:43.544821
# Unit test for method get_virtual_facts of class OpenBSDVirtual
def test_OpenBSDVirtual_get_virtual_facts():
    # pylint: disable=unused-argument
    def mock_get_file_content(file_name):
        if file_name == '/var/run/dmesg.boot':
            mock_dmesg_boot = '''
[...]
vmm0 at mainbus0: VMX/EPT
[...]
vmm1 at mainbus0: SVM/RVI
[...]
'''
            return mock_dmesg_boot
        elif file_name == '/proc/cpuinfo':
            mock_cpuinfo = '''
[...]
vendor_id       : GenuineIntel
model name      : Intel(R) Xeon(R) CPU           L5520  @ 2.27GHz
model name      : Intel(R) Xeon(R) CPU           L5520  @ 2.27GHz
'''
            return mock_

# Generated at 2022-06-23 02:33:52.568313
# Unit test for constructor of class OpenBSDVirtual

# Generated at 2022-06-23 02:33:55.245299
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    c = OpenBSDVirtualCollector()
    assert c.platform == 'OpenBSD'
    assert c.fact_class == OpenBSDVirtual


# Generated at 2022-06-23 02:33:58.819287
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    obj = openbsd_virtual_collector._fact_class(openbsd_virtual_collector)
    assert type(obj) == OpenBSDVirtual


# Generated at 2022-06-23 02:34:01.046001
# Unit test for constructor of class OpenBSDVirtualCollector
def test_OpenBSDVirtualCollector():
    openbsd_virtual_collector = OpenBSDVirtualCollector()
    assert openbsd_virtual_collector.collect()['virtualization_role'] == ''

# Generated at 2022-06-23 02:34:03.053233
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    module = OpenBSDVirtual({})
    assert module.platform == 'OpenBSD'

# Generated at 2022-06-23 02:34:05.087775
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    openbsd_virtual = OpenBSDVirtual()
    assert openbsd_virtual.platform == "OpenBSD"

# Generated at 2022-06-23 02:34:08.477251
# Unit test for constructor of class OpenBSDVirtual
def test_OpenBSDVirtual():
    virtual_openbsd = OpenBSDVirtual()
    assert virtual_openbsd.platform == 'OpenBSD'
    assert virtual_openbsd.DMESG_BOOT == '/var/run/dmesg.boot'
