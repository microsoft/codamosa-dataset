

# Generated at 2022-06-17 16:17:20.331929
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:30.308199
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:38.643545
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:48.972714
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:17:53.516066
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:18:04.175799
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:15.940205
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test for public names
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'tasks' in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names(include_private=False)
    assert 'name' in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names(include_private=False)
    assert 'block' in get_reserved_names(include_private=False)
    assert 'when'

# Generated at 2022-06-17 16:18:26.351640
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vars_files_prompt' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names

# Generated at 2022-06-17 16:18:35.901620
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:48.378366
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test reserved names
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()


# Generated at 2022-06-17 16:19:17.827609
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test for public names
    public_names = get_reserved_names(include_private=False)
    assert 'hosts' in public_names
    assert 'roles' in public_names
    assert 'action' in public_names
    assert 'local_action' in public_names
    assert 'with_' in public_names
    assert 'loop' not in public_names
    assert 'private' not in public_names

    # Test for private names
    private_names = get_reserved_names(include_private=True)
    assert 'hosts' in private_names
    assert 'roles' in private_names
    assert 'action' in private_names
    assert 'local_action' in private_names
    assert 'with_' in private_names
    assert 'loop' in private_names
    assert 'private'

# Generated at 2022-06-17 16:19:25.471635
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:35.736291
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()

# Generated at 2022-06-17 16:19:49.389708
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:55.185857
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:04.200263
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()
    assert 'become_method' in get_reserved_names()
    assert 'become_flags' in get_reserved_names()
    assert 'become_exe' in get_reserved_names()
    assert 'become_user' in get_reserved_names

# Generated at 2022-06-17 16:20:15.085688
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['action', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'changed_when', 'connection', 'delegate_to', 'environment', 'failed_when', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'name', 'notify', 'notified_by', 'notify_level', 'notify_no_data', 'notify_when', 'register', 'remote_user', 'roles', 'serial', 'tags', 'tasks', 'until', 'vars', 'when', 'with_'])

# Generated at 2022-06-17 16:20:24.548221
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:35.803696
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:49.664267
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:33.463905
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:40.467817
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'async' in get_reserved_names()
    assert 'poll' in get_reserved_names()
    assert 'register' in get_res

# Generated at 2022-06-17 16:21:51.505208
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'vars_files' in get_reserved_names()
    assert 'vars_files' in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names()
    assert 'vars' in get_reserved_names(include_private=False)
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names()
    assert 'local_action' in get_reserved_names(include_private=False)
    assert 'with_' in get

# Generated at 2022-06-17 16:21:57.838689
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'roles' in get_reserved_names(include_private=True)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'private' in get_reserved_names(include_private=True)

# Generated at 2022-06-17 16:22:05.831074
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:22:14.626522
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_role' in get_reserved_names()

# Generated at 2022-06-17 16:22:19.835244
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()
    assert 'become_method' in get_reserved_names()

# Generated at 2022-06-17 16:22:30.236221
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:40.007833
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()

# Generated at 2022-06-17 16:22:51.706197
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:05.339599
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:24:14.718288
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:26.106875
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:33.149053
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                assert attribute in _RESERVED_NAMES
            else:
                assert attribute in _RESERVED_NAMES

# Generated at 2022-06-17 16:24:46.628775
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:58.223417
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function.
    '''

    # Test for public names
    public_names = get_reserved_names(include_private=False)
    assert 'name' in public_names
    assert 'hosts' in public_names
    assert 'gather_facts' in public_names
    assert 'tasks' in public_names
    assert 'roles' in public_names
    assert 'vars' in public_names
    assert 'vars_files' in public_names
    assert 'include' in public_names
    assert 'include_vars' in public_names
    assert 'pre_tasks' in public_names
    assert 'post_tasks' in public_names
    assert 'handlers' in public_names
    assert 'tags' in public_names
   

# Generated at 2022-06-17 16:25:09.984892
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names

# Generated at 2022-06-17 16:25:21.557300
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:25:33.068590
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:44.709550
# Unit test for function get_reserved_names