

# Generated at 2022-06-17 16:17:20.332751
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'import_playbook' in reserved_names
    assert 'import_tasks' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'vars' in reserved_names

# Generated at 2022-06-17 16:17:27.494301
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' not in get_reserved_names(include_private=False)

# Generated at 2022-06-17 16:17:34.480209
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:17:40.062386
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' not in get_reserved_names(include_private=False)

# Generated at 2022-06-17 16:17:49.858534
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:18:01.700976
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:07.599936
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'loop' in reserved
    assert 'vars' in reserved
    assert 'block' in reserved
    assert 'include' in reserved
    assert 'include_role' in reserved
    assert 'include_tasks' in reserved
    assert 'pre_tasks' in reserved
    assert 'post_tasks' in reserved
    assert 'tasks' in reserved
    assert 'handlers' in reserved
    assert 'when' in reserved
    assert 'name' in reserved
    assert 'become' in reserved
    assert 'become_user' in reserved
    assert 'become_method' in reserved

# Generated at 2022-06-17 16:18:18.145319
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:27.899350
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()

# Generated at 2022-06-17 16:18:36.927319
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:07.865402
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role'

# Generated at 2022-06-17 16:19:15.968440
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)


# Generated at 2022-06-17 16:19:24.369547
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:34.658341
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:42.961635
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                assert attribute in _RESERVED_NAMES
            else:
                assert attribute in _RESERVED_NAMES

    assert 'local_action' in _RESERVED_NAMES
    assert 'with_' in _RESERVED_NAMES

# Generated at 2022-06-17 16:19:45.049080
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:19:51.548239
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests that the list of reserved names is accurate '''

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if attribute in _RESERVED_NAMES:
                continue
            else:
                raise AssertionError('%s not in reserved names' % attribute)

# Generated at 2022-06-17 16:20:01.834375
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:20:13.975658
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:24.276481
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:47.085658
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' in get_reserved_names(include_private=False)


# Generated at 2022-06-17 16:20:58.003759
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:05.869050
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:21:13.851080
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'rescue' in get_reserved_names()

# Generated at 2022-06-17 16:21:25.982986
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'any_errors_fatal', 'async', 'become', 'become_user', 'block', 'changed_when', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'failed_when', 'first_available_file', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'name', 'notify', 'notified_by', 'no_log', 'poll', 'register', 'remote_user', 'role', 'run_once', 'serial', 'sudo', 'sudo_user', 'tags', 'task', 'until', 'vars', 'when', 'with_'])
    assert get_reserved_names(include_private=True) == frozenset

# Generated at 2022-06-17 16:21:34.418699
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:40.977838
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:52.010183
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:01.700907
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:13.242652
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function.
    '''

# Generated at 2022-06-17 16:22:34.036440
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:22:41.604134
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include' in get_reserved_names()

# Generated at 2022-06-17 16:22:51.267209
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:58.453223
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:23:05.303542
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'become' in get_reserved_names()

# Generated at 2022-06-17 16:23:15.513399
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['hosts', 'name', 'gather_facts', 'vars', 'vars_files', 'tags', 'register', 'any_errors_fatal', 'max_fail_percentage', 'local_action', 'with_'])

# Generated at 2022-06-17 16:23:27.063792
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'block_errors', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'gather_facts', 'hosts', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'name', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'register', 'roles', 'run_once', 'serial', 'tags', 'tasks', 'vars', 'vars_files', 'vars_prompt', 'when'])

# Generated at 2022-06-17 16:23:35.720426
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test for public names
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()
    assert 'import_role' in get_reserved_names()

# Generated at 2022-06-17 16:23:49.896340
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:02.031400
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:24:47.320096
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:24:58.640224
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'when' in reserved_names
    assert 'block' in reserved_names
    assert 'rescue' in reserved_names
    assert 'always' in reserved

# Generated at 2022-06-17 16:25:10.236366
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:11.627532
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:25:22.488736
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'roles' in get_reserved_names(include_private=True)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'include_role' in get_reserved_names()
    assert 'include_role' in get_reserved_names(include_private=True)
    assert 'include_role' not in get_reserved_names(include_private=False)
    assert 'include_tasks' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names(include_private=True)
    assert 'include_tasks' not in get_reserved_names(include_private=False)
    assert 'include_vars' in get_reserved_names()


# Generated at 2022-06-17 16:25:33.395310
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:44.800067
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:56.260802
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()
    assert 'import_role' in get_reserved_names()

# Generated at 2022-06-17 16:26:03.473720
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:13.880363
# Unit test for function get_reserved_names