

# Generated at 2022-06-17 16:17:13.056235
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:23.095423
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:27.143803
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()) - frozenset(get_reserved_names(include_private=True))

# Generated at 2022-06-17 16:17:34.247105
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()

# Generated at 2022-06-17 16:17:37.239596
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()) - frozenset(get_reserved_names(include_private=True))

# Generated at 2022-06-17 16:17:43.633160
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()

# Generated at 2022-06-17 16:17:51.902217
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:03.469063
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)
    assert len(get_reserved_names()) > len(get_reserved_names(include_private=False))
    assert 'hosts' in get_reserved_names()
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names()
    assert 'local_action' not in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names()
    assert 'with_' not in get_

# Generated at 2022-06-17 16:18:15.699204
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:18:25.997177
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test public names
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'tasks' in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names(include_private=False)
    assert 'vars_files' in get_reserved_names(include_private=False)
    assert 'vars_prompt' in get_reserved_names(include_private=False)
    assert 'vault_password_files' in get_reserved_names(include_private=False)
    assert 'tags' in get_reserved_names(include_private=False)

# Generated at 2022-06-17 16:18:48.376682
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)
    assert 'name' in public
    assert 'name' in private
    assert 'private' in private
    assert 'private' not in public
    assert 'action' in public
    assert 'local_action' in private
    assert 'local_action' in public
    assert 'loop' in private
    assert 'with_' in public

# Generated at 2022-06-17 16:18:57.016363
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'import_playbook' in reserved_names
    assert 'import_tasks' in reserved_names
    assert 'import_role' in reserved_names
    assert 'pre_tasks' in reserved_names

# Generated at 2022-06-17 16:19:07.747071
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:17.825633
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:19.656671
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:19:26.504192
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:36.629735
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:41.878599
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['loop', 'action', 'local_action']))

# Generated at 2022-06-17 16:19:44.208288
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:19:52.850476
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:27.493305
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:20:37.725475
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test for public names
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()

    # Test for private names
    assert '_role_name' in get_reserved_names(include_private=True)
    assert '_role_path' in get_reserved_names(include_private=True)

# Generated at 2022-06-17 16:20:50.258647
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:59.646275
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:07.363308
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:21:14.781384
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:26.058909
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:34.447522
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()

# Generated at 2022-06-17 16:21:48.291885
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test public names
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()

    # Test private names
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()

    # Test private names are not returned when include_private=False
    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved

# Generated at 2022-06-17 16:21:57.678492
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:01.962997
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:23:12.589381
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:18.285917
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:27.902847
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:23:36.515295
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:23:50.362595
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:58.866019
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'roles' in get_reserved_names(include_private=True)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)

# Generated at 2022-06-17 16:24:05.490603
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:24:14.748716
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:24:26.137041
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:22.910389
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'when' in reserved_names
    assert 'async' in reserved_names
    assert 'poll' in reserved_names
    assert 'become' in reserved_names
    assert 'become_user' in reserved_names
    assert 'become_method' in reserved_names
    assert 'become_flags' in reserved_

# Generated at 2022-06-17 16:26:28.665268
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()) - frozenset(get_reserved_names(include_private=True))

# Generated at 2022-06-17 16:26:37.950502
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['connection', 'delegate_to', 'gather_facts', 'hosts', 'name', 'roles', 'serial', 'tasks', 'vars', 'vars_files', 'vars_prompt', 'vault_password_files', 'when', 'with_', 'local_action'])
    assert get_reserved_names(include_private=False) == frozenset(['connection', 'delegate_to', 'gather_facts', 'hosts', 'name', 'roles', 'serial', 'tasks', 'vars', 'vars_files', 'vars_prompt', 'vault_password_files', 'when', 'with_', 'local_action'])

# Generated at 2022-06-17 16:26:49.442778
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:58.508085
# Unit test for function get_reserved_names