

# Generated at 2022-06-17 16:17:20.289603
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:30.254771
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:38.600544
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:17:48.972173
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:17:53.107977
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                assert attribute in _RESERVED_NAMES
            else:
                assert attribute in _RESERVED_NAMES

    # local_action is implicit with action
    assert 'local_action' in _RESERVED_NAMES

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in _RESERVED_NAMES

# Generated at 2022-06-17 16:18:03.811469
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:06.967536
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)
    assert len(get_reserved_names()) > 0
    assert len(get_reserved_names(include_private=False)) > 0
    assert len(get_reserved_names()) > len(get_reserved_names(include_private=False))


# Generated at 2022-06-17 16:18:18.021092
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:27.873085
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:36.927193
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function
    '''

    # Test the public names
    public = get_reserved_names(include_private=False)
    assert 'hosts' in public
    assert 'roles' in public
    assert 'tasks' in public
    assert 'vars' in public
    assert 'name' in public
    assert 'action' in public
    assert 'local_action' in public
    assert 'with_' in public
    assert 'loop' not in public
    assert 'include' not in public
    assert 'include_role' not in public
    assert 'include_tasks' not in public
    assert 'pre_tasks' not in public
    assert 'post_tasks' not in public
    assert 'when' not in public
    assert 'block' not in public


# Generated at 2022-06-17 16:19:06.640612
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'when' in reserved_names
    assert 'register' in reserved_

# Generated at 2022-06-17 16:19:14.977246
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:19:23.640315
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()

# Generated at 2022-06-17 16:19:34.216384
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks'

# Generated at 2022-06-17 16:19:44.632603
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:48.051392
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'notify' in get_reserved_names()
    assert 'register' in get_reserved_names()

# Generated at 2022-06-17 16:19:54.428824
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'vars' in reserved
    assert 'block' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'loop' in reserved
    assert 'register' in reserved
    assert 'delegate_to' in reserved
    assert 'delegate_facts' in reserved
    assert 'include' in reserved
    assert 'include_role' in reserved
    assert 'include_tasks' in reserved
    assert 'import_playbook' in reserved
    assert 'import_tasks' in reserved
    assert 'import_role' in reserved
    assert 'tags' in reserved

# Generated at 2022-06-17 16:20:03.772168
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:15.048600
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:24.511077
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names '''

    # test for public names
    public = get_reserved_names(include_private=False)
    assert 'name' in public
    assert 'hosts' in public
    assert 'roles' in public
    assert 'tasks' in public
    assert 'vars' in public
    assert 'vars_files' in public
    assert 'block' in public
    assert 'action' in public
    assert 'local_action' in public
    assert 'with_' in public

    # test for private names
    private = get_reserved_names(include_private=True)
    assert 'name' in private
    assert 'hosts' in private
    assert 'roles' in private
    assert 'tasks' in private
    assert 'vars' in private

# Generated at 2022-06-17 16:21:07.539293
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:17.148050
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:27.324322
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'connection', 'delegate_to', 'environment', 'first_available_file', 'ignore_errors', 'local_action', 'loop', 'name', 'notify', 'register', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'transport', 'vars_files', 'with_'])

# Generated at 2022-06-17 16:21:34.796268
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:41.236896
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:50.752103
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:57.965782
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:59.251268
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:22:07.742599
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()

# Generated at 2022-06-17 16:22:17.159710
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:23:27.197295
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()
    assert 'become_method' in get_reserved_names()

# Generated at 2022-06-17 16:23:28.273887
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:23:36.806599
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:50.501097
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:02.440307
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:13.192114
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:18.555430
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:22.760668
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['private']))

# Generated at 2022-06-17 16:24:26.677151
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]
    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            assert attribute in _RESERVED_NAMES

# Generated at 2022-06-17 16:24:38.134150
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'block' in get_res

# Generated at 2022-06-17 16:26:50.146220
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:26:59.013476
# Unit test for function get_reserved_names