

# Generated at 2022-06-17 16:17:23.742142
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test public names
    public_names = get_reserved_names(include_private=False)
    assert 'name' in public_names
    assert 'hosts' in public_names
    assert 'roles' in public_names
    assert 'tasks' in public_names
    assert 'pre_tasks' in public_names
    assert 'post_tasks' in public_names
    assert 'vars' in public_names
    assert 'vars_files' in public_names
    assert 'vars_prompt' in public_names
    assert 'handlers' in public_names
    assert 'block' in public_names
    assert 'action' in public_names
    assert 'local_action' in public_names
    assert 'with_' in public_names
    assert 'include' in public_names

# Generated at 2022-06-17 16:17:32.498094
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    This function tests the warn_if_reserved function.
    '''
    # Test for reserved names
    myvars = ['vars', 'action', 'local_action', 'loop', 'with_']
    warn_if_reserved(myvars)

    # Test for non-reserved names
    myvars = ['vars', 'action', 'local_action', 'loop', 'with_', 'myvar']
    warn_if_reserved(myvars)

    # Test for non-reserved names with additional reserved names
    myvars = ['vars', 'action', 'local_action', 'loop', 'with_', 'myvar']
    additional = ['myvar2']
    warn_if_reserved(myvars, additional)

    # Test for reserved names with additional reserved names
    my

# Generated at 2022-06-17 16:17:39.887463
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'action', 'local_action', 'loop', 'with_'])
    warn_if_reserved(['vars', 'action', 'local_action', 'loop', 'with_'], ['foo'])
    warn_if_reserved(['vars', 'action', 'local_action', 'loop', 'with_', 'foo'])
    warn_if_reserved(['vars', 'action', 'local_action', 'loop', 'with_', 'foo'], ['foo'])
    warn_if_reserved(['vars', 'action', 'local_action', 'loop', 'with_', 'foo'], ['foo', 'bar'])

# Generated at 2022-06-17 16:17:49.748183
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'meta' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'when' in get_reserved_names()

# Generated at 2022-06-17 16:18:01.529812
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'block_errors', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'gather_facts', 'gather_subset', 'gather_timeout', 'hosts', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'name', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'register', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'vars_prompt', 'when'])

# Generated at 2022-06-17 16:18:07.769702
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                assert attribute in _RESERVED_NAMES
            else:
                assert attribute in _RESERVED_NAMES

    # local_action is implicit with action
    assert 'local_action' in _RESERVED_NAMES

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in _

# Generated at 2022-06-17 16:18:18.190748
# Unit test for function warn_if_reserved

# Generated at 2022-06-17 16:18:22.846909
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    warn_if_reserved(['foo', 'vars', 'action', 'local_action', 'loop', 'with_'])
    warn_if_reserved(['foo', 'vars', 'action', 'local_action', 'loop', 'with_'], ['foo'])
    warn_if_reserved(['foo', 'vars', 'action', 'local_action', 'loop', 'with_'], ['foo', 'action'])
    warn_if_reserved(['foo', 'vars', 'action', 'local_action', 'loop', 'with_'], ['foo', 'action', 'local_action'])

# Generated at 2022-06-17 16:18:29.622067
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # FIXME: this is a unit test, but it's not being run as one.
    #        It should be moved to test/unit/playbook/test_reserved.py
    #        and run as part of the unit test suite.
    #        See https://github.com/ansible/ansible/issues/25891
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestWarnIfReserved(unittest.TestCase):

        def setUp(self):
            self.mock_display = patch('ansible.playbook.reserved.display')
            self.mock_display.start()

        def tearDown(self):
            self.mock_display.stop()


# Generated at 2022-06-17 16:18:33.751324
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:18:48.740855
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    # test that all attributes are in the reserved list
    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            assert attribute in get_reserved_names()

    # test that all reserved names are in the attributes list
    for aclass in class_list:
        aobj = aclass()
        for reserved in get_reserved_names():
            assert reserved in aobj.__dict__['_attributes']

# Generated at 2022-06-17 16:18:57.388042
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:19:08.026506
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:19:18.138904
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function.
    '''

    # Test the default case
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'pre_tasks' in reserved_names

# Generated at 2022-06-17 16:19:25.660100
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:35.892091
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()


# Generated at 2022-06-17 16:19:49.426871
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()
    assert 'become_method' in get_reserved_names()

# Generated at 2022-06-17 16:19:51.612802
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['private']))

# Generated at 2022-06-17 16:19:55.699735
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()).difference(frozenset(get_reserved_names(include_private=True)))

# Generated at 2022-06-17 16:20:04.482979
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'import_playbook' in reserved_names
    assert 'import_tasks' in reserved_names
    assert 'import_role' in reserved_names

# Generated at 2022-06-17 16:20:24.156012
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:29.909787
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:31.634427
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:20:33.134681
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:20:39.655086
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()
    assert 'import_role' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_

# Generated at 2022-06-17 16:20:47.410396
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:58.424298
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test for public names
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_

# Generated at 2022-06-17 16:21:05.921153
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:13.879296
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()
    assert 'become_method' in get_reserved_names()
    assert 'become_flags' in get_reserved_names()
    assert 'connection' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names()
    assert 'environment' in get_reserved_names()
    assert 'gather_facts' in get

# Generated at 2022-06-17 16:21:25.988431
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)

    # test for presence of some known names
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()

    # test for absence of some known names
    assert 'foobar' not in get_reserved_names()
    assert 'foobar' not in get

# Generated at 2022-06-17 16:21:50.172108
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks'

# Generated at 2022-06-17 16:21:57.630345
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:05.633958
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                assert attribute in get_reserved_names(include_private=True)
            else:
                assert attribute in get_reserved_names(include_private=False)

    # local_action is implicit with action
    assert 'local_action' in get_reserved_names(include_private=False)

    # loop implies with_
    # FIXME: remove after with_

# Generated at 2022-06-17 16:22:14.794772
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:25.930620
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:36.649029
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function
    '''
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'name' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'block' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'pre_tasks' in reserved_names


# Generated at 2022-06-17 16:22:50.201840
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_res

# Generated at 2022-06-17 16:22:57.601097
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:23:04.788185
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)


# Generated at 2022-06-17 16:23:11.526582
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' not in get_reserved_names(include_private=False)


# Generated at 2022-06-17 16:23:50.802454
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'name' in get_reserved_names()


# Generated at 2022-06-17 16:24:02.686045
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:13.550979
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:25.869527
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include' in get_reserved_names()

# Generated at 2022-06-17 16:24:37.665669
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:45.370198
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:51.757699
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:59.952864
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'when' in get_reserved_names()


# Generated at 2022-06-17 16:25:11.073196
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:18.619047
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)
    assert len(get_reserved_names()) > 0
    assert len(get_reserved_names(include_private=False)) > 0
    assert len(get_reserved_names()) > len(get_reserved_names(include_private=False))


# Generated at 2022-06-17 16:26:20.285644
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:21.466858
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:26:28.083207
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:38.285439
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:47.464066
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:53.121534
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:54.218591
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:27:01.176846
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test public names
    assert 'name' in get_reserved_names(False)
    assert 'hosts' in get_reserved_names(False)
    assert 'roles' in get_reserved_names(False)
    assert 'tasks' in get_reserved_names(False)
    assert 'vars' in get_reserved_names(False)
    assert 'vars_files' in get_reserved_names(False)
    assert 'vars_prompt' in get_reserved_names(False)
    assert 'action' in get_reserved_names(False)
    assert 'local_action' in get_reserved_names(False)
    assert 'with_' in get_reserved_names(False)
    assert 'include' in get_reserved_names(False)