

# Generated at 2022-06-17 16:17:31.116749
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()

# Generated at 2022-06-17 16:17:39.205093
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names
    assert 'vars' in reserved_names
    assert 'private' in reserved_names
    assert 'any_errors_fatal' in reserved_names
    assert 'always_run' in reserved_names
    assert 'connection' in reserved_names
    assert 'delegate_to' in reserved_names
    assert 'delegate_facts' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'ignore_errors' in reserved_names
    assert 'no_log' in reserved_names
    assert 'notify' in reserved_names


# Generated at 2022-06-17 16:17:47.633025
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)


# Generated at 2022-06-17 16:17:50.040165
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names(include_private=False))

# Generated at 2022-06-17 16:18:01.810692
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:07.624797
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'block' in get_reserved_names(include_private=False)
    assert 'include' in get_reserved_names()
    assert 'include' in get_reserved_names(include_private=False)
    assert 'include_vars' in get_reserved_names()
    assert 'include_vars' in get_reserved_names(include_private=False)
    assert 'include_role' in get_reserved_names()
   

# Generated at 2022-06-17 16:18:18.146128
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:22.856578
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:33.919455
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()

# Generated at 2022-06-17 16:18:43.417707
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'when'

# Generated at 2022-06-17 16:19:22.428591
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:30.377973
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)


# Generated at 2022-06-17 16:19:40.955208
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()


# Generated at 2022-06-17 16:19:48.777831
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:19:59.306983
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'include_role' in get_reserved_names()

# Generated at 2022-06-17 16:20:06.298736
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()

# Generated at 2022-06-17 16:20:15.854903
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:25.190053
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:20:36.170140
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:38.533667
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:21:40.223017
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test reserved names '''

    # test public names
    public = get_reserved_names(include_private=False)
    assert 'name' in public
    assert 'hosts' in public
    assert 'roles' in public
    assert 'tasks' in public
    assert 'vars' in public
    assert 'vars_files' in public
    assert 'vars_prompt' in public
    assert 'include' in public
    assert 'include_vars' in public
    assert 'gather_facts' in public
    assert 'pre_tasks' in public
    assert 'post_tasks' in public
    assert 'handlers' in public
    assert 'tags' in public
    assert 'any_errors_fatal' in public
    assert 'serial' in public
    assert 'max_fail_percentage'

# Generated at 2022-06-17 16:21:50.458549
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:57.817464
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:05.831720
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:14.625494
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:25.746240
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['action', 'any_errors_fatal', 'become', 'become_user', 'block', 'changed_when', 'connection', 'delegate_to', 'environment', 'failed_when', 'gather_facts', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'name', 'notify', 'notified_by', 'no_log', 'post_tasks', 'pre_tasks', 'register', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'when', 'with_'])

# Generated at 2022-06-17 16:22:36.465181
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                assert attribute in get_reserved_names(include_private=True)
            else:
                assert attribute in get_reserved_names(include_private=False)

    # local_action is implicit with action
    assert 'local_action' in get_reserved_names(include_private=False)

    # loop implies with_
    # FIXME: remove after with_

# Generated at 2022-06-17 16:22:49.948959
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:01.657864
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:23:12.524484
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:10.337015
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'when' in reserved_names
    assert 'block' in reserved_names
    assert 'rescue' in reserved_names
    assert 'always' in reserved

# Generated at 2022-06-17 16:25:21.771687
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:33.061485
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:44.707818
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:56.180292
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:26:01.188494
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:11.550957
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)

    # test that the function returns the same set of reserved names
    # regardless of whether private names are included
    assert get_reserved_names() == get_reserved_names(include_private=False).union(get_reserved_names(include_private=True))

    # test that the function returns a set of reserved names that is
    # a subset of the set of all reserved names
    assert get_reserved_names() <= _RESERVED_NAMES
    assert get_reserved_names(include_private=False) <= _RESERVED_NAMES

    # test that the function returns a set of reserved names that is
    # a superset of the set of public reserved names
   

# Generated at 2022-06-17 16:26:21.516715
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()
    assert 'import_role' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()
    assert 'import_role' in get_reserved_names()
    assert 'include_tasks' in get_res

# Generated at 2022-06-17 16:26:26.944268
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]
    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            assert attribute in _RESERVED_NAMES

# Generated at 2022-06-17 16:26:37.369437
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get