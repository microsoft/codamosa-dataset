

# Generated at 2022-06-17 16:17:15.330457
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()

# Generated at 2022-06-17 16:17:23.465857
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' not in get_reserved_names(include_private=False)


# Generated at 2022-06-17 16:17:32.308674
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:17:44.180440
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:52.293334
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:55.373160
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)

# Generated at 2022-06-17 16:18:05.145797
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'block' in get_reserved_names(include_private=False)
    assert 'include' in get_reserved_names()
    assert 'include' in get_reserved_names(include_private=False)
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:18:06.328647
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:18:17.773999
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == {'action', 'connection', 'delegate_to', 'gather_facts', 'hosts', 'name', 'notify', 'register', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'with_'}
    assert get_reserved_names(include_private=True) == {'action', 'connection', 'delegate_to', 'gather_facts', 'hosts', 'name', 'notify', 'register', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'with_', 'loop'}

# Generated at 2022-06-17 16:18:27.699191
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:18:53.743563
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'any_errors_fatal', 'connection', 'delegate_to', 'gather_facts', 'gather_subset', 'gather_timeout', 'handlers', 'hosts', 'ignore_errors', 'local_action', 'name', 'notify', 'post_tasks', 'pre_tasks', 'roles', 'serial', 'tags', 'tasks', 'vars', 'vars_files', 'with_'])

# Generated at 2022-06-17 16:19:00.609118
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['connection', 'delegate_to', 'environment', 'gather_facts', 'hosts', 'name', 'no_log', 'notify', 'register', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'vars', 'vars_files', 'when', 'with_', 'local_action'])
    assert get_reserved_names(include_private=False) == frozenset(['connection', 'delegate_to', 'environment', 'gather_facts', 'hosts', 'name', 'no_log', 'notify', 'register', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'vars', 'vars_files', 'when', 'with_', 'local_action'])

# Generated at 2022-06-17 16:19:03.948762
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)


# Generated at 2022-06-17 16:19:13.581970
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'action' in get_reserved_names

# Generated at 2022-06-17 16:19:22.799246
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:33.901061
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function
    '''
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'when' in reserved

# Generated at 2022-06-17 16:19:35.251019
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES - frozenset(['loop', 'when'])

# Generated at 2022-06-17 16:19:41.198810
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()) - frozenset(get_reserved_names(include_private=True))

# Generated at 2022-06-17 16:19:51.839186
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:20:02.146787
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:44.512316
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_vars'

# Generated at 2022-06-17 16:20:52.289421
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'when' in reserved_names
    assert 'async' in reserved

# Generated at 2022-06-17 16:21:01.900559
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:07.947361
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)

# Generated at 2022-06-17 16:21:17.577401
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:27.743138
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test for public names
    public = get_reserved_names(include_private=False)
    assert 'hosts' in public
    assert 'roles' in public
    assert 'action' in public
    assert 'local_action' in public
    assert 'with_' in public
    assert 'include_role' in public
    assert 'include_tasks' in public
    assert 'include' in public
    assert 'import_playbook' in public
    assert 'import_tasks' in public
    assert 'import_role' in public
    assert 'import_tasks' in public
    assert 'import_role' in public
    assert 'vars' in public
    assert 'vars_files' in public
    assert 'vars_prompt' in public

# Generated at 2022-06-17 16:21:30.650096
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()) - frozenset(get_reserved_names(include_private=True))

# Generated at 2022-06-17 16:21:39.551777
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:43.081481
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()) - frozenset(get_reserved_names(include_private=True))


# Generated at 2022-06-17 16:21:51.142759
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:58.741354
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
   

# Generated at 2022-06-17 16:23:05.367761
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:10.645234
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:16.426568
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:27.119185
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:35.755587
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()

# Generated at 2022-06-17 16:23:37.862273
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:23:50.961167
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:02.719323
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:13.560512
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:27.713986
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()
    assert 'become_method' in get_reserved_names()
    assert 'connection' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names()

# Generated at 2022-06-17 16:26:37.950562
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test for public names
    public_names = get_reserved_names(include_private=False)
    assert 'name' in public_names
    assert 'hosts' in public_names
    assert 'roles' in public_names
    assert 'action' in public_names
    assert 'local_action' in public_names
    assert 'with_' in public_names
    assert 'loop' not in public_names
    assert 'vars' not in public_names

    # test for private names
    private_names = get_reserved_names(include_private=True)
    assert 'name' in private_names
    assert 'hosts' in private_names
    assert 'roles' in private_names
    assert 'action' in private_names


# Generated at 2022-06-17 16:26:47.226830
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:52.945845
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()