

# Generated at 2022-06-17 16:17:14.953110
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:15.956309
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)

# Generated at 2022-06-17 16:17:26.505593
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:17:36.128362
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:48.506010
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:54.956172
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:04.951010
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'ignore_errors' in get_reserved_names()
    assert 'delegate_to'

# Generated at 2022-06-17 16:18:16.617655
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:26.932656
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:18:36.316884
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()


# Generated at 2022-06-17 16:19:06.686881
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'local_action', 'with_'])

# Generated at 2022-06-17 16:19:12.752571
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)



# Generated at 2022-06-17 16:19:22.279061
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'vars_files' in get_reserved_names()
    assert 'vars_files' in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names()
    assert 'vars' in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names()
    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names()
    assert 'local_action' not in get_reserved_names(include_private=False)
    assert 'loop' in get_reserved_names()


# Generated at 2022-06-17 16:19:27.945048
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:37.577591
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'ignore_errors' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names()
    assert 'run_once' in get_reserved_names()

# Generated at 2022-06-17 16:19:50.296791
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:00.615772
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()

# Generated at 2022-06-17 16:20:12.305876
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:18.961209
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:27.182420
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:10.465341
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:21:18.596517
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'when'

# Generated at 2022-06-17 16:21:28.710548
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:35.611779
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:21:49.221197
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:56.952857
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test for public names
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:22:05.119035
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:22:14.085564
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test for private names
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)

    # Test for implicit names
    assert 'local_action' in get_reserved_names(include_private=True)
    assert 'with_' in get_reserved_names(include_private=True)

    # Test for public names
    assert 'name' in get_reserved_names(include_private=True)
    assert 'name' in get_reserved_names(include_private=False)

    # Test for private names
    assert 'action' in get_reserved_names(include_private=True)
    assert 'action' in get_reserved_names(include_private=False)

    # Test for private names


# Generated at 2022-06-17 16:22:25.169304
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:35.981666
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:51.674341
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:02.793280
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This is a list of reserved names that we expect to find
    expected_reserved_names = set(['any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'block_errors', 'changed_when', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'failed_when', 'gather_facts', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'name', 'notify', 'notify_handler', 'no_log', 'register', 'remote_user', 'roles', 'run_once', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'until', 'vars', 'vars_files', 'vars_prompt', 'when', 'with_'])

# Generated at 2022-06-17 16:24:13.549978
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:25.870103
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:30.997444
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES - frozenset(['loop', 'with_'])

# Generated at 2022-06-17 16:24:40.244497
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'ignore_errors' in get_reserved_names()
    assert 'delegate_to'

# Generated at 2022-06-17 16:24:48.793491
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'name' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'block' in reserved_names
    assert 'blockinfile' in reserved_names
    assert 'blockreplace' in reserved_names
    assert 'blockreplace' in reserved_names
    assert 'block' in reserved_names


# Generated at 2022-06-17 16:24:59.440762
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # check for expected number of reserved names
    assert len(get_reserved_names()) == len(get_reserved_names(include_private=False)) + len(get_reserved_names(include_private=True))

    # check for expected number of reserved names
    assert len(get_reserved_names()) == len(get_reserved_names(include_private=False)) + len(get_reserved_names(include_private=True))

    # check for expected number of reserved names
    assert len(get_reserved_names()) == len(get_reserved_names(include_private=False)) + len(get_reserved_names(include_private=True))

    # check for expected number of reserved names

# Generated at 2022-06-17 16:25:10.759488
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:22.021811
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test public names
    public_names = get_reserved_names(include_private=False)
    assert 'hosts' in public_names
    assert 'roles' in public_names
    assert 'action' in public_names
    assert 'local_action' in public_names
    assert 'with_' in public_names
    assert 'loop' not in public_names
    assert 'private' not in public_names

    # test private names
    private_names = get_reserved_names(include_private=True)
    assert 'hosts' in private_names
    assert 'roles' in private_names
    assert 'action' in private_names
    assert 'local_action' in private_names
    assert 'with_' in private_names
