

# Generated at 2022-06-17 16:17:19.841699
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:29.874495
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'when' in reserved_names
    assert 'async' in reserved_names
    assert 'poll' in reserved_names
    assert 'ignore_errors' in reserved_names
    assert 'register' in reserved_names
    assert 'delegate_to' in reserved_names
    assert 'delegate_facts' in reserved_names


# Generated at 2022-06-17 16:17:35.901321
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function
    '''

# Generated at 2022-06-17 16:17:48.420197
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:59.144289
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:04.860655
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names

# Generated at 2022-06-17 16:18:16.581628
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:26.898710
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:34.140824
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)

# Generated at 2022-06-17 16:18:43.635515
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:19:00.018154
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:19:09.329662
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test that we get the same result for public and public+private
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)
    assert public.union(private) == private

    # test that we get the same result for public and public+private
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)
    assert public.union(private) == private

    # test that we get the same result for public and public+private
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)
    assert public.union(private) == private

# Generated at 2022-06-17 16:19:19.544542
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names
    assert 'include' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_vars' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'when' in reserved_names
    assert 'name' in reserved_names
    assert 'block'

# Generated at 2022-06-17 16:19:31.668284
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:19:41.575578
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:19:52.001571
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:02.297819
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:20:14.552438
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:21.331679
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'vars' in reserved
    assert 'block' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'loop' in reserved
    assert 'with_' in reserved
    assert 'when' in reserved
    assert 'include' in reserved
    assert 'include_role' in reserved
    assert 'include_tasks' in reserved
    assert 'pre_tasks' in reserved
    assert 'post_tasks' in reserved
    assert 'handlers' in reserved
    assert 'register' in reserved
    assert 'ignore_errors' in reserved
    assert 'always_run' in reserved

# Generated at 2022-06-17 16:20:28.613870
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function
    '''

# Generated at 2022-06-17 16:20:49.280949
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)


# Generated at 2022-06-17 16:20:58.925210
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()
    assert 'become_method' in get_reserved_names()

# Generated at 2022-06-17 16:21:07.578341
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:17.180712
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()


# Generated at 2022-06-17 16:21:27.395368
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:34.854422
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:41.261379
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks'

# Generated at 2022-06-17 16:21:50.755497
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:57.943047
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:22:05.937774
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:50.589864
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:57.935688
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:02.662105
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test the public names
    public_names = get_reserved_names(include_private=False)
    assert 'name' in public_names
    assert 'hosts' in public_names
    assert 'roles' in public_names
    assert 'tasks' in public_names
    assert 'vars' in public_names
    assert 'vars_files' in public_names
    assert 'vars_prompt' in public_names
    assert 'gather_facts' in public_names
    assert 'serial' in public_names
    assert 'any_errors_fatal' in public_names
    assert 'max_fail_percentage' in public_names
    assert 'local_action' in public_names
    assert 'with_' in public_names

# Generated at 2022-06-17 16:23:13.237341
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:20.049166
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:23:30.944757
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:23:39.291394
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:51.481367
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:02.794575
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()


# Generated at 2022-06-17 16:24:13.550787
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:25:21.772621
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'block' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'loop' in reserved
    assert 'with_' in reserved
    assert 'vars' in reserved
    assert 'include' in reserved
    assert 'include_role' in reserved
    assert 'include_tasks' in reserved
    assert 'pre_tasks' in reserved
    assert 'post_tasks' in reserved
    assert 'when' in reserved
    assert 'name' in reserved
    assert 'register' in reserved
    assert 'ignore_errors' in reserved
    assert 'delegate_to' in reserved
    assert 'delegate_facts' in reserved
    assert 'notify' in reserved

# Generated at 2022-06-17 16:25:33.061168
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'async' in get_reserved_names()

# Generated at 2022-06-17 16:25:44.707459
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:56.182080
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:01.174393
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:06.791326
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vault_password_file' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'connection' in get_reserved_names()


# Generated at 2022-06-17 16:26:17.220092
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:25.479787
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:28.897252
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['private']))

# Generated at 2022-06-17 16:26:34.149475
# Unit test for function get_reserved_names