

# Generated at 2022-06-17 16:17:13.381103
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:23.465537
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:32.306841
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:39.771596
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    # test that we get the same number of reserved names as the number of attributes in the classes
    # FIXME: remove after with_ is not only deprecated but removed
    assert len(get_reserved_names()) == sum(len(a.__dict__['_attributes']) for a in class_list) - 1

    # test that we get the same number of reserved names as the number of attributes in the classes
    # FIXME: remove after with_ is not only deprecated but removed

# Generated at 2022-06-17 16:17:49.672032
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:01.402374
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test public names
    public = get_reserved_names(include_private=False)
    assert 'hosts' in public
    assert 'roles' in public
    assert 'tasks' in public
    assert 'vars' in public
    assert 'action' in public
    assert 'local_action' in public
    assert 'with_' in public
    assert 'loop' not in public

    # test private names
    private = get_reserved_names(include_private=True)
    assert 'hosts' in private
    assert 'roles' in private
    assert 'tasks' in private
    assert 'vars' in private
    assert 'action' in private
    assert 'local_action' in private
    assert 'with_' in private
   

# Generated at 2022-06-17 16:18:07.722930
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:18.166163
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vars_files_prompt' in get_reserved_names()
    assert 'vars_prompt_once' in get_reserved_names()
    assert 'vars_files_prompt_once' in get_reserved_names()
    assert 'vars_prompt_rerun' in get_reserved_names()

# Generated at 2022-06-17 16:18:27.900973
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vault_password_files' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'include' in get_reserved_

# Generated at 2022-06-17 16:18:36.927301
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'connection', 'delegate_to', 'environment', 'gather_facts', 'gather_subset', 'gather_timeout', 'handlers', 'hosts', 'ignore_errors', 'include', 'include_tasks', 'local_action', 'loop', 'name', 'notify', 'no_log', 'post_tasks', 'pre_tasks', 'roles', 'run_once', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'vars_prompt', 'when'])

# Generated at 2022-06-17 16:19:06.493159
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'when'

# Generated at 2022-06-17 16:19:14.814202
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'rescue' in get_reserved_names()

# Generated at 2022-06-17 16:19:23.538289
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:34.135840
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:37.396963
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) > 0
    assert len(get_reserved_names(include_private=False)) > 0
    assert len(get_reserved_names()) > len(get_reserved_names(include_private=False))

# Generated at 2022-06-17 16:19:50.182663
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'rescue' in get_reserved_names()

# Generated at 2022-06-17 16:20:00.615285
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:12.310097
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'vars' in get_reserved_names()

# Generated at 2022-06-17 16:20:18.958210
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'gather_facts', 'gather_subset', 'handlers', 'hosts', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'max_fail_percentage', 'meta', 'name', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'roles', 'serial', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'vars_prompt', 'when'])
    assert get_reserved_names

# Generated at 2022-06-17 16:20:26.362154
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['gather_facts', 'hosts', 'name', 'roles', 'tasks', 'vars', 'vars_files', 'vars_prompt', 'vault_password_files', 'connection', 'sudo', 'sudo_user', 'transport', 'remote_user', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'check', 'delegate_to', 'environment', 'ignore_errors', 'no_log', 'notify', 'poll', 'register', 'retries', 'run_once', 'tags', 'when', 'local_action', 'with_', 'action', 'loop'])

# Generated at 2022-06-17 16:21:07.448183
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_

# Generated at 2022-06-17 16:21:14.830288
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:26.058963
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:34.446387
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'block' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'loop' in reserved
    assert 'with_' in reserved
    assert 'include' in reserved
    assert 'include_role' in reserved
    assert 'include_tasks' in reserved
    assert 'import_playbook' in reserved
    assert 'import_tasks' in reserved
    assert 'vars' in reserved
    assert 'vars_files' in reserved
    assert 'vars_prompt' in reserved
    assert 'vars_prompt' in reserved
    assert 'tags' in reserved
    assert 'pre_tasks' in reserved

# Generated at 2022-06-17 16:21:48.286905
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:56.249072
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'when' in reserved_names
    assert 'name' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'import_playbook' in reserved_names
    assert 'import_tasks' in reserved_names
    assert 'meta' in reserved_

# Generated at 2022-06-17 16:22:02.949738
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)


# Generated at 2022-06-17 16:22:13.786804
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'gather_facts', 'gather_subset', 'handlers', 'hosts', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'local_action', 'name', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'vars_prompt', 'when'])

# Generated at 2022-06-17 16:22:24.641392
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name'

# Generated at 2022-06-17 16:22:35.627460
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:51.425842
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:02.752581
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:13.556654
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()
    assert 'become_method' in get_reserved_names()
    assert 'become_flags' in get_reserved_names()
    assert 'become_exe' in get_reserved_names()


# Generated at 2022-06-17 16:24:25.872099
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'vars' in reserved
    assert 'block' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'loop' in reserved
    assert 'include' in reserved
    assert 'include_role' in reserved
    assert 'include_tasks' in reserved
    assert 'pre_tasks' in reserved
    assert 'post_tasks' in reserved
    assert 'when' in reserved
    assert 'async' in reserved
    assert 'poll' in reserved
    assert 'become' in reserved
    assert 'become_user' in reserved

# Generated at 2022-06-17 16:24:37.664738
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:48.093629
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'import_playbook' in reserved_names
    assert 'import_tasks' in reserved_names
    assert 'import_role' in reserved_names
    assert 'pre_tasks' in reserved_names

# Generated at 2022-06-17 16:24:59.062733
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:10.529786
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()


# Generated at 2022-06-17 16:25:21.872414
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:33.070736
# Unit test for function get_reserved_names