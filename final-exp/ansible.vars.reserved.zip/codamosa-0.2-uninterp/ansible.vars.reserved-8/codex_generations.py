

# Generated at 2022-06-17 16:17:20.452544
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:30.423454
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:38.700226
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names
    assert 'name' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'block' in reserved_names
    assert 'rescue' in reserved_names
    assert 'always' in reserved_names
    assert 'meta' in reserved_names
    assert 'pre_tasks' in reserved_names


# Generated at 2022-06-17 16:17:48.974121
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:00.147730
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:07.097723
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names function '''

    # test for public names
    public_names = get_reserved_names(include_private=False)
    assert 'name' in public_names
    assert 'hosts' in public_names
    assert 'roles' in public_names
    assert 'tasks' in public_names
    assert 'vars' in public_names
    assert 'vars_files' in public_names
    assert 'vars_prompt' in public_names
    assert 'gather_facts' in public_names
    assert 'tags' in public_names
    assert 'any_errors_fatal' in public_names
    assert 'serial' in public_names
    assert 'max_fail_percentage' in public_names
    assert 'local_action' in public_names

# Generated at 2022-06-17 16:18:18.050548
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:27.872676
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()
    assert 'become_method' in get_reserved_names()
    assert 'become_flags' in get_reserved_names()
    assert 'connection' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names()
    assert 'environment' in get_reserved

# Generated at 2022-06-17 16:18:36.939394
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:48.931432
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:19:15.469927
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                assert attribute in _RESERVED_NAMES
            else:
                assert attribute in _RESERVED_NAMES

    # local_action is implicit with action
    assert 'local_action' in _RESERVED_NAMES

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in _RESERVED_NAMES

# Generated at 2022-06-17 16:19:24.003389
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()
   

# Generated at 2022-06-17 16:19:34.389366
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['become_user', 'block', 'block_rescue', 'block_always', 'block_errors', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'gather_facts', 'gather_subset', 'gather_timeout', 'handler', 'hosts', 'ignore_errors', 'import_playbook', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'name', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'roles', 'serial', 'strategy', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'vars_prompt', 'when', 'with_'])
    assert get

# Generated at 2022-06-17 16:19:44.919137
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:46.022081
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:19:47.533158
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:19:54.128840
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'register' in get_reserved_names()

# Generated at 2022-06-17 16:20:03.535886
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:14.979128
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:21.615281
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)
    assert len(get_reserved_names()) > len(get_reserved_names(include_private=False))
    assert 'action' in get_reserved_names()
    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' not in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names()
    assert 'with_' not in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names()
    assert 'loop' not in get_reserved_names(include_private=False)

# Generated at 2022-06-17 16:21:02.424059
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:11.040280
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:18.867290
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:28.918260
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:38.709202
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test public names
    public_names = get_reserved_names(include_private=False)
    assert 'name' in public_names
    assert 'hosts' in public_names
    assert 'action' in public_names
    assert 'local_action' in public_names
    assert 'with_' in public_names
    assert 'loop' not in public_names
    assert 'vars' in public_names
    assert 'roles' in public_names
    assert 'tasks' in public_names
    assert 'block' in public_names
    assert 'include' in public_names
    assert 'include_role' in public_names
    assert 'include_tasks' in public_names
    assert 'pre_tasks' in public_names
   

# Generated at 2022-06-17 16:21:48.740131
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'vars_files' in get_reserved_names()
    assert 'vars_files' in get_reserved_names(include_private=False)
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'local_action' in get_reserved_names()
    assert 'local_action' in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names()
    assert 'with_' in get_reserved_names(include_private=False)



# Generated at 2022-06-17 16:21:56.614691
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vault_password_files' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_

# Generated at 2022-06-17 16:22:04.719327
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()

# Generated at 2022-06-17 16:22:14.130988
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()


# Generated at 2022-06-17 16:22:25.208890
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['become', 'become_user', 'connection', 'delegate_to', 'environment', 'gather_facts', 'hosts', 'ignore_errors', 'name', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'vars', 'vars_files', 'when', 'with_', 'local_action'])

# Generated at 2022-06-17 16:23:37.265285
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks'

# Generated at 2022-06-17 16:23:43.744527
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['loop', 'action', 'local_action', 'with_']))

# Generated at 2022-06-17 16:23:52.742014
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'loop' in reserved
    assert 'vars' in reserved
    assert 'private' in reserved
    assert 'block' in reserved
    assert 'include' in reserved
    assert 'include_role' in reserved
    assert 'include_tasks' in reserved
    assert 'pre_tasks' in reserved
    assert 'post_tasks' in reserved
    assert 'when' in reserved
    assert 'async' in reserved
    assert 'poll' in reserved
    assert 'become' in reserved
    assert 'become_user'

# Generated at 2022-06-17 16:24:03.147131
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:13.585509
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:25.907313
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:24:37.669765
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:45.335814
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:51.760362
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'action' in get_reserved_names()

# Generated at 2022-06-17 16:24:59.953857
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test public only
    assert get_reserved_names(include_private=False) == set(['hosts', 'name', 'gather_facts', 'vars', 'vars_files', 'tags', 'roles', 'tasks', 'handlers', 'pre_tasks', 'post_tasks', 'any_errors_fatal', 'serial', 'max_fail_percentage', 'local_action', 'with_'])

    # test public and private