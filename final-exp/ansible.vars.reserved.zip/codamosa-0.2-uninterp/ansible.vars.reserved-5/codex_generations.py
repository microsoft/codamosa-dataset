

# Generated at 2022-06-17 16:17:15.354235
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()

# Generated at 2022-06-17 16:17:25.894265
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:17:30.144819
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'local_action', 'with_'])
    assert get_reserved_names(include_private=True) == frozenset(['action', 'local_action', 'with_', 'loop'])

# Generated at 2022-06-17 16:17:38.468253
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['action', 'any_errors_fatal', 'block', 'block_errors', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'first_available_file', 'ignore_errors', 'local_action', 'loop', 'loop_control', 'notify', 'notified_by', 'post_tasks', 'pre_tasks', 'register', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'when', 'with_'])

# Generated at 2022-06-17 16:17:49.458959
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:54.015200
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test reserved names '''

    # test public
    assert 'name' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'tasks' in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names(include_private=False)

    # test private
    assert '_role_name' in get_reserved_names(include_private=True)
    assert '_role_path' in get_reserved_names(include_private=True)

# Generated at 2022-06-17 16:18:04.532792
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:16.249655
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:26.611547
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:36.062762
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:58.737690
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:08.342369
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'tags'

# Generated at 2022-06-17 16:19:18.461940
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:25.820408
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:36.015352
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test the public names
    assert 'name' in get_reserved_names(include_private=False)
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'tasks' in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names(include_private=False)
    assert 'vars_files' in get_reserved_names(include_private=False)
    assert 'handlers' in get_reserved_names(include_private=False)
    assert 'tags' in get_reserved_names(include_private=False)
    assert 'gather_facts' in get_reserved_names(include_private=False)
   

# Generated at 2022-06-17 16:19:48.556164
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)


# Generated at 2022-06-17 16:19:49.688183
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:19:55.345453
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:04.314828
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:20:09.949093
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()) - frozenset(get_reserved_names(include_private=True))

# Generated at 2022-06-17 16:20:50.174143
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:59.568845
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:05.966924
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:08.346205
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['loop', 'action', 'local_action', 'with_']))

# Generated at 2022-06-17 16:21:17.892454
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:19.545084
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:21:29.430060
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:39.047736
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:50.101811
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:57.575374
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(['name', 'hosts', 'gather_facts', 'tasks', 'handlers', 'vars', 'vars_files', 'roles', 'pre_tasks', 'post_tasks', 'any_errors_fatal', 'max_fail_percentage', 'serial', 'sudo', 'sudo_user', 'become', 'become_user', 'tags', 'skip_tags', 'transport', 'remote_user', 'connection', 'timeout', 'local_action', 'with_'])

# Generated at 2022-06-17 16:22:54.681518
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:03.216469
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'rescue' in get_reserved_names()

# Generated at 2022-06-17 16:23:14.418961
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['action', 'any_errors_fatal', 'async', 'become', 'become_user', 'block', 'block_errors', 'changed_when', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'failed_when', 'first_available_file', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'loop_control', 'name', 'notify', 'notify_handler', 'notify_host', 'notify_task', 'no_log', 'poll', 'register', 'retries', 'roles', 'serial', 'tags', 'task', 'tasks', 'until', 'vars', 'vars_files', 'when'])

# Generated at 2022-06-17 16:23:19.706391
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test public names
    public_names = get_reserved_names(include_private=False)
    assert 'hosts' in public_names
    assert 'name' in public_names
    assert 'roles' in public_names
    assert 'tasks' in public_names
    assert 'vars' in public_names
    assert 'block' in public_names
    assert 'action' in public_names
    assert 'local_action' in public_names
    assert 'with_' in public_names
    assert 'include' in public_names
    assert 'include_role' in public_names
    assert 'include_tasks' in public_names
    assert 'import_playbook' in public_names
    assert 'import_tasks' in public_names

# Generated at 2022-06-17 16:23:28.046162
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names
    assert 'include' in reserved_names
    assert 'include_role' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'import_playbook' in reserved_names
    assert 'import_tasks' in reserved_names
    assert 'import_role' in reserved_names

# Generated at 2022-06-17 16:23:36.637019
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:50.432024
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'vars' in get_reserved_names()

# Generated at 2022-06-17 16:24:02.403904
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:13.354307
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_role' in get_reserved_names()


# Generated at 2022-06-17 16:24:18.618375
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:02.665793
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['private']))

# Generated at 2022-06-17 16:26:12.905610
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:22.837233
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:26:34.421297
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:44.255919
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test public names
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:26:54.105614
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:27:01.102591
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test the get_reserved_names function '''

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    # test public names
    public = get_reserved_names(include_private=False)
    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            if 'private' not in attribute:
                assert attribute in public

    # test private names
    private = get_reserved_names(include_private=True)
    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                assert attribute in private

