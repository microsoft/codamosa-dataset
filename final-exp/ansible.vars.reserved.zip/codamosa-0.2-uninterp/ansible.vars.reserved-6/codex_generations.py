

# Generated at 2022-06-17 16:17:10.819456
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    import StringIO

    # Capture stdout
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO.StringIO()

    # Test warn_if_reserved
    warn_if_reserved(['vars', 'action', 'local_action', 'loop', 'with_', 'private'])
    assert mystdout.getvalue() == 'Found variable using reserved name: action\nFound variable using reserved name: loop\nFound variable using reserved name: private\n'

    # Restore stdout
    sys.stdout = old_stdout

# Generated at 2022-06-17 16:17:21.321439
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test with no additional reserved names
    warn_if_reserved(['vars', 'hosts'])
    warn_if_reserved(['vars', 'hosts', 'roles'])
    warn_if_reserved(['vars', 'hosts', 'roles', 'tasks'])
    warn_if_reserved(['vars', 'hosts', 'roles', 'tasks', 'name'])
    warn_if_reserved(['vars', 'hosts', 'roles', 'tasks', 'name', 'action'])
    warn_if_reserved(['vars', 'hosts', 'roles', 'tasks', 'name', 'action', 'local_action'])

# Generated at 2022-06-17 16:17:24.489378
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['private']))

# Generated at 2022-06-17 16:17:32.862094
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:45.921589
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:17:47.101341
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['foo', 'action', 'vars'])

# Generated at 2022-06-17 16:17:54.164553
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()

# Generated at 2022-06-17 16:18:04.566406
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()
    assert 'become_method' in get_reserved_names()
    assert 'connection' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'serial' in get_reserved

# Generated at 2022-06-17 16:18:16.285776
# Unit test for function warn_if_reserved

# Generated at 2022-06-17 16:18:26.648333
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:42.972217
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test public names
    assert 'name' in get_reserved_names(include_private=False)
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'tasks' in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names(include_private=False)
    assert 'vars_files' in get_reserved_names(include_private=False)
    assert 'vars_prompt' in get_reserved_names(include_private=False)
    assert 'gather_facts' in get_reserved_names(include_private=False)
    assert 'tags' in get_reserved_names(include_private=False)

# Generated at 2022-06-17 16:18:48.172533
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:18:56.807307
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'connection' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()
    assert 'serial' in get_reserved_names()

# Generated at 2022-06-17 16:19:07.544835
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:17.544713
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:19:25.299778
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:29.034062
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()) - frozenset(get_reserved_names(include_private=True))

# Generated at 2022-06-17 16:19:39.966975
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function
    '''
    assert isinstance(get_reserved_names(), set)
    assert len(get_reserved_names()) > 0
    assert 'hosts' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()

# Generated at 2022-06-17 16:19:43.925173
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test public names
    public = get_reserved_names(include_private=False)
    assert 'name' in public
    assert 'hosts' in public
    assert 'roles' in public
    assert 'tasks' in public
    assert 'vars' in public
    assert 'block' in public
    assert 'action' in public
    assert 'local_action' in public
    assert 'with_' in public
    assert 'loop' not in public

    # Test private names
    private = get_reserved_names(include_private=True)
    assert 'name' in private
    assert 'hosts' in private
    assert 'roles' in private
    assert 'tasks' in private
    assert 'vars' in private
    assert 'block' in private
    assert 'action' in private

# Generated at 2022-06-17 16:19:52.773651
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vault_password_file' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names()
    assert 'run_once' in get_reserved

# Generated at 2022-06-17 16:20:14.497701
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:21.315514
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:28.613750
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function
    '''
    # Test that the function returns a set
    assert isinstance(get_reserved_names(), set)

    # Test that the function returns the correct number of reserved names
    assert len(get_reserved_names()) == len(get_reserved_names(include_private=False)) + len(get_reserved_names(include_private=True))

    # Test that the function returns the correct number of reserved names
    assert len(get_reserved_names()) == len(get_reserved_names(include_private=False)) + len(get_reserved_names(include_private=True))

    # Test that the function returns the correct number of reserved names

# Generated at 2022-06-17 16:20:38.331016
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:20:50.480840
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test public names
    public_names = get_reserved_names(include_private=False)
    assert 'name' in public_names
    assert 'hosts' in public_names
    assert 'gather_facts' in public_names
    assert 'roles' in public_names
    assert 'tasks' in public_names
    assert 'action' in public_names
    assert 'local_action' in public_names
    assert 'with_' in public_names
    assert 'loop' not in public_names
    assert 'delegate_to' in public_names
    assert 'register' in public_names
    assert 'ignore_errors' in public_names
    assert 'any_errors_fatal' in public_names
    assert 'changed_when'

# Generated at 2022-06-17 16:20:57.025115
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'when' in reserved_names
    assert 'become' in reserved_names
    assert 'become_user' in reserved_names
    assert 'become_method' in reserved_names
    assert 'become_flags' in reserved_names
    assert 'connection' in reserved_names

# Generated at 2022-06-17 16:21:05.745869
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vault_password_file' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'connection' in get_reserved_names()


# Generated at 2022-06-17 16:21:13.758265
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:25.902935
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:34.419061
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:55.687185
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:03.935609
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:22:13.896657
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()

# Generated at 2022-06-17 16:22:24.965933
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'block'

# Generated at 2022-06-17 16:22:28.286960
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()) - frozenset(get_reserved_names(include_private=True))

# Generated at 2022-06-17 16:22:39.186518
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:22:51.455254
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:58.628091
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()

# Generated at 2022-06-17 16:23:05.367031
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['become', 'become_user', 'block', 'block_rescue', 'block_always', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'gather_facts', 'gather_subset', 'gather_timeout', 'hosts', 'ignore_errors', 'import_playbook', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'max_fail_percentage', 'meta', 'name', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'register', 'remote_user', 'roles', 'serial', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'vars_prompt', 'when', 'with_'])

# Generated at 2022-06-17 16:23:06.554632
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)


# Generated at 2022-06-17 16:23:41.474067
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()
    assert 'max_fail_percentage' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names()
    assert 'delegate_facts' in get_reserved_names()

# Generated at 2022-06-17 16:23:52.112291
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'rescue' in get_reserved_names()

# Generated at 2022-06-17 16:24:02.844587
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'always' in get_reserved_names()

# Generated at 2022-06-17 16:24:13.549649
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:25.873856
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()

# Generated at 2022-06-17 16:24:28.163445
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:24:38.657872
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:46.188163
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:47.958516
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:24:52.387416
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:38.759257
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:25:50.137816
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:25:56.260997
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert len(get_reserved_names()) > 0
    assert isinstance(get_reserved_names(include_private=False), set)
    assert len(get_reserved_names(include_private=False)) > 0
    assert len(get_reserved_names(include_private=False)) < len(get_reserved_names())


# Generated at 2022-06-17 16:26:02.877864
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_vars' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:26:06.890390
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()) - frozenset(get_reserved_names(include_private=True))


# Generated at 2022-06-17 16:26:17.302690
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vault_password_file' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'connection' in get_reserved_names()


# Generated at 2022-06-17 16:26:20.930325
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'local_action', 'with_'])
    assert get_reserved_names(include_private=True) == frozenset(['action', 'local_action', 'with_', 'loop'])

# Generated at 2022-06-17 16:26:27.770190
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vault_password_files' in get_reserved_names()
    assert 'connection' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'serial' in get_reserved_names()
    assert 'sudo' in get_reserved_names()
    assert 'sudo_user' in get_reserved_names()
    assert 'transport' in get_res

# Generated at 2022-06-17 16:26:36.193058
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)


# Generated at 2022-06-17 16:26:48.893467
# Unit test for function get_reserved_names