

# Generated at 2022-06-17 16:17:15.564684
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:17:26.084531
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:17:35.753353
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # test public
    assert 'name' in get_reserved_names(include_private=False)
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'tasks' in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names(include_private=False)
    assert 'vars_files' in get_reserved_names(include_private=False)
    assert 'handlers' in get_reserved_names(include_private=False)
    assert 'pre_tasks' in get_reserved_names(include_private=False)

# Generated at 2022-06-17 16:17:48.315609
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_files_0' in get_reserved_names()
    assert 'vars_files_1' in get_reserved_names()
    assert 'vars_files_2' in get_reserved_names

# Generated at 2022-06-17 16:17:52.589767
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test for public names
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()

    # Test for private names
    assert '_role_name' in get_reserved_names()
    assert '_role_path' in get_reserved_names()
    assert '_role_params' in get_reserved_names()
   

# Generated at 2022-06-17 16:18:03.699812
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:15.822978
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:24.891355
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)

# Generated at 2022-06-17 16:18:35.335710
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:18:48.109494
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:05.963854
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:19:15.829515
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_

# Generated at 2022-06-17 16:19:24.273553
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:19:34.579425
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:19:45.105527
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'become_user' in get_reserved_names()

# Generated at 2022-06-17 16:19:50.617345
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'async' in get_reserved_names()
    assert 'poll' in get_reserved_names()

# Generated at 2022-06-17 16:19:51.792031
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:20:02.070359
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()

# Generated at 2022-06-17 16:20:14.303969
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:20:17.717357
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['loop', 'action', 'local_action']))

# Generated at 2022-06-17 16:20:50.378433
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()
    assert 'import_role' in get_reserved_names()
    assert 'vars' in get_reserved_names

# Generated at 2022-06-17 16:20:59.761637
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:01.059247
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-17 16:21:09.740334
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:16.154776
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'block_errors', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'error_on_undefined_vars', 'gather_facts', 'gather_subset', 'gather_timeout', 'handlers', 'hosts', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'local_action', 'loop', 'name', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'roles', 'serial', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'vars_prompt', 'when', 'with_'])

# Generated at 2022-06-17 16:21:26.852411
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:34.529578
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:21:48.381939
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'connection', 'delegate_to', 'environment', 'first_available_file', 'ignore_errors', 'local_action', 'loop', 'name', 'notify', 'register', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars_files', 'with_'])

# Generated at 2022-06-17 16:21:56.315372
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:22:04.396534
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test for public names
    assert 'name' in get_reserved_names(include_private=False)
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'tasks' in get_reserved_names(include_private=False)
    assert 'block' in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names(include_private=False)
    assert 'include'

# Generated at 2022-06-17 16:23:03.728092
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'local_action', 'with_'])

# Generated at 2022-06-17 16:23:14.658690
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'connection' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()
    assert 'serial' in get_reserved_names()
    assert 'max_fail_percentage' in get_

# Generated at 2022-06-17 16:23:19.837410
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:30.778187
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    # test public names
    public_names = get_reserved_names(include_private=False)
    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            if 'private' not in attribute:
                assert attribute in public_names

    # test private names
    private_names = get_reserved_names(include_private=True)
    for aclass in class_list:
        aobj = aclass()

# Generated at 2022-06-17 16:23:37.802767
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:23:50.964655
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:02.731520
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:24:13.555251
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:24:25.869884
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name'

# Generated at 2022-06-17 16:24:37.664916
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:26:27.790526
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:26:37.995946
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()

# Generated at 2022-06-17 16:26:47.257376
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()

# Generated at 2022-06-17 16:26:52.970405
# Unit test for function get_reserved_names

# Generated at 2022-06-17 16:27:00.290840
# Unit test for function get_reserved_names