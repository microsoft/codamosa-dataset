

# Generated at 2022-06-21 09:48:31.019590
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test function to ensure we detect reserved vars correctly '''

    myvars = [u'hosts', u'gather_facts', u'post_tasks', u'tasks', u'pre_tasks', u'vars']
    warn_if_reserved(myvars)

    myvars = [u'hosts', u'not_reserved', u'gather_facts', u'post_tasks', u'tasks', u'pre_tasks', u'vars']
    warn_if_reserved(myvars)

    # test with a role deps var
    myvars = [u'hosts', u'not_reserved', u'gather_facts', u'post_tasks', u'roles', u'tasks', u'pre_tasks', u'vars']
    warn

# Generated at 2022-06-21 09:48:35.250702
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('vars')
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('loop')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:48:44.312849
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert isinstance(result, set)
    # This is a specific known set of names

# Generated at 2022-06-21 09:48:45.775674
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts', 'name'])


# Generated at 2022-06-21 09:48:53.446690
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # assert that all reserved names are indeed reserved in the function is_reserved_name
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)

    # assert some common names are not reserved
    assert not is_reserved_name('when')
    assert not is_reserved_name('delegate_to')
    assert not is_reserved_name('hosts')
    assert not is_reserved_name('roles')


# Unit Test for function get_reserved_names

# Generated at 2022-06-21 09:48:57.607870
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # the set can change so we can't be too strict but
    # we should have at least the ones from the examples
    assert 'name' in get_reserved_names(include_private=True)
    assert 'with_items' in get_reserved_names(include_private=False)



# Generated at 2022-06-21 09:49:04.691460
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:49:07.776250
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 1
    warn_if_reserved(['vars', 'hosts', 'name', 'tasks'])



# Generated at 2022-06-21 09:49:16.555726
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')      is True
    assert is_reserved_name('hosts')       is True
    assert is_reserved_name('connection')  is True
    assert is_reserved_name('port')        is True
    assert is_reserved_name('private_key') is True
    assert is_reserved_name('private_key_file') is True
    assert is_reserved_name('user')        is True
    assert is_reserved_name('when')        is True
    assert is_reserved_name('become')      is True
    assert is_reserved_name('delegate_to') is True
    assert is_reserved_name('tags')        is True
    assert is_reserved_name('run_once')    is True

# Generated at 2022-06-21 09:49:17.638875
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:49:47.314137
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # all these names should be reserved
    assert is_reserved_name('action')
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('become')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('tags')
    assert is_reserved_name('local_action')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('block')
    assert is_reserved_name('notify')
    assert is_reserved_name('meta')
    assert is_reserved_name('include_role')
    assert is_reserved_name('include_tasks')
    assert is_res

# Generated at 2022-06-21 09:49:51.584778
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES == {'become', 'become_user', 'block', 'block&meta', 'hosts', 'hosts&meta', 'name', 'name&meta', 'roles', 'roles&meta', 'tags', 'tags&meta', 'tasks', 'tasks&meta', 'vars', 'vars&meta', 'with_'}

# Generated at 2022-06-21 09:50:02.951613
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    play = Play()
    play._attributes = ('vars',)
    pbc = PlayContext(play=play)
    pbc.vars = dict()
    assert not pbc.vars
    # warn_if_reserved raises a warning, so assert that there is no warning
    # for the valid variable name
    display.verbosity = 4  # Ensure that warnings are not output
    with pbc.cleanup_on_failure():
        pbc.vars['some_var'] = dict()
        warn_if_reserved(pbc.vars)
    pbc.vars.pop('some_var')

# Generated at 2022-06-21 09:50:05.357609
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_vars = ['test_var', 'name', 'vars', 'test_vars']
    warn_if_reserved(test_vars)

# Generated at 2022-06-21 09:50:11.052974
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(_RESERVED_NAMES) > 50, 'The reserved names should have about 50 members'
    for name in ('hosts', 'any_errors_fatal', 'roles', 'gather_facts', 'tasks'):
        assert name in _RESERVED_NAMES, '{} should be reserved'.format(name)


# Generated at 2022-06-21 09:50:22.227515
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == get_reserved_names(include_private=False)
    assert set(get_reserved_names()) == set(get_reserved_names(include_private=False))

    assert 'gather_facts' in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names()

    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' not in get_reserved_names()

    assert 'notify' in get_reserved_names()
    assert 'vars' in get_reserved_names()
   

# Generated at 2022-06-21 09:50:31.950775
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'any_errors_fatal' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES
    assert 'loop' in _RESERVED_NAMES
    assert 'with_' in _RESERVED_NAMES
    assert 'tags' in _RESERVED_NAMES
    assert 'ignore_errors' in _RESERVED_NAMES
    assert 'with_items' in _RESERVED_NAMES
    assert 'loop_control' in _RESERVED_NAMES

# Generated at 2022-06-21 09:50:41.544696
# Unit test for function get_reserved_names
def test_get_reserved_names():
    class_list = ['action', 'any_errors_fatal', 'block', 'become', 'become_user', 'become_method', 'delegate_to', 'environment', 'ignore_errors', 'local_action', 'name', 'notify', 'role_name', 'serial', 'tags', 'tasks', 'vars', 'when', 'with_', 'with_file', 'with_fileglob', 'with_first_found', 'with_indexed_items', 'with_items', 'with_dict', 'with_lines', 'with_nested', 'with_sequence', 'with_subelements']
    assert class_list == list(get_reserved_names(include_private=True))

# Generated at 2022-06-21 09:50:48.821081
# Unit test for function is_reserved_name

# Generated at 2022-06-21 09:50:52.817329
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(include_private=False)
    private_names = get_reserved_names(include_private=True)
    assert public_names
    assert private_names
    assert public_names.issubset(private_names)

# Generated at 2022-06-21 09:51:10.742297
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')

    # Test for lowercase version for names that have only been
    # reserved in yaml_loader
    assert is_reserved_name('vars')
    assert is_reserved_name('rolesfile')
    assert is_reserved_name('handlersfile')

    # Test for the name 'block' which is a special case
    # since it is not registered as an attribute in a block object,
    # and is not listed in _RESERVED_NAMES
    assert is_reserved_name('block')

# Generated at 2022-06-21 09:51:14.221362
# Unit test for function is_reserved_name
def test_is_reserved_name():
    d = get_reserved_names()
    for name in d:
        assert is_reserved_name(name)
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:51:19.218156
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = frozenset(['name', 'hosts', 'any_errors_fatal', 'remote_user', 'sudo_user'])
    varnames = set(['name', 'hosts'])
    warn_if_reserved(varnames, additional=reserved)
    assert varnames == set(['name', 'hosts'])
    assert frozenset(['name', 'hosts']) == frozenset(['hosts', 'name'])

# Generated at 2022-06-21 09:51:21.348797
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert 'name' in _RESERVED_NAMES
    assert 'not_reserved' not in _RESERVED_NAMES

# Generated at 2022-06-21 09:51:23.746645
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for res in _RESERVED_NAMES:
        assert is_reserved_name(res)

    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:51:32.765182
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import os
    import sys

    class FakeDisplay(object):
        def __init__(self):
            self.warnings = []

        def warning(self, msg):
            self.warnings.append(msg)

    # create fake warning and output
    saved_display = display
    try:
        display = FakeDisplay()
        warn_if_reserved(['when'])
        assert len(display.warnings) == 1
        if sys.version_info[0] > 2:
            assert 'Found variable using reserved name: when' in display.warnings
        else:
            assert 'Found variable using reserved name: when' == display.warnings[0]
    except AssertionError:
        raise AssertionError
    finally:
        display = saved_display



# Generated at 2022-06-21 09:51:34.265287
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('connection')
    assert not is_reserved_name('foo_bar')


# Generated at 2022-06-21 09:51:36.852967
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test = get_reserved_names()
    assert len(test) > 0, "Should return names"
    assert 'pre_tasks' in test, "Should return pre_tasks as a reserved name"

# Generated at 2022-06-21 09:51:40.244031
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=True), set)
    assert isinstance(get_reserved_names(include_private=False), set)

# Generated at 2022-06-21 09:51:45.468917
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('connection')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('delegate_facts')
    assert is_reserved_name('include')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('when')   # is reserved, but not in RESERVED_NAMES

# Generated at 2022-06-21 09:52:22.494924
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    vars = ['vars', 'ansible_ssh_user']
    try:
        warn_if_reserved(vars)
    except AssertionError:
        pass
    else:
        assert False, "vars: [vars, ansible_ssh_user] should have raised AssertionError"

    vars = ['foo', 'vars', 'ansible_ssh_user']
    try:
        warn_if_reserved(vars)
    except AssertionError:
        pass
    else:
        assert False, "vars: [foo, vars, ansible_ssh_user] should have raised AssertionError"

# Generated at 2022-06-21 09:52:29.505753
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = StringIO()
            return self
        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio    # free up some memory
            sys.stdout = self._stdout


# Generated at 2022-06-21 09:52:34.622800
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['a'])
    except:
        assert False, 'warn_if_reserved() should not raise an exception for non reserved names'
    try:
        warn_if_reserved(['connection'])
        assert False, 'warn_if_reserved() should raise an exception for reserved names'
    except Exception:
        pass


# Generated at 2022-06-21 09:52:36.054146
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' just ensure that the reserved name set is non-empty '''
    assert len(get_reserved_names()) > 1

# Generated at 2022-06-21 09:52:45.874453
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['vars', 'action']) is None
    assert warn_if_reserved(['vars', 'action', 'roles']) is None
    assert warn_if_reserved(['vars', 'action', 'roles', 'delegate_to']) is None
    assert warn_if_reserved(['vars', 'action', 'roles', 'delegate_to', 'invalid_name']) is None
    assert warn_if_reserved(['vars', 'action', 'roles', 'delegate_to', 'invalid_name']) is None
    assert warn_if_reserved(['vars', 'action', 'roles', 'delegate_to', 'invalid_name', 'invalid_name2']) is None

# Generated at 2022-06-21 09:52:49.918455
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('host')
    assert is_reserved_name('tags')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('become_user')
    assert is_reserved_name('roles')



# Generated at 2022-06-21 09:53:01.744394
# Unit test for function get_reserved_names
def test_get_reserved_names():

    class_list = [
        'Play',
        'Role',
        'Block',
        'Task',
    ]

    for aclass in class_list:
        aobj = globals()[aclass]()
        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                assert get_reserved_names(include_private=True).__contains__(attribute)
            else:
                assert get_reserved_names(include_private=False).__contains__(attribute)

    # local_action is implicit with action
    assert get_reserved_names(include_private=False).__contains__('local_action')

    # loop implies with_

# Generated at 2022-06-21 09:53:10.099546
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:53:11.412883
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('with_')
    assert is_reserved_name('local_action')
    assert is_reserved_name('vars')



# Generated at 2022-06-21 09:53:17.792756
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = get_reserved_names(False)
    for res_name in reserved_names:
        assert is_reserved_name(res_name)

    faile_res_names = ['not_reserved_test1', 'not_reserved_test2', 'not_reserved_test3']
    for faile_res_name in faile_res_names:
        assert not is_reserved_name(faile_res_name)

# Generated at 2022-06-21 09:54:02.190912
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'action': 'test'}) is None

# Generated at 2022-06-21 09:54:07.084466
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]
    for aclass in class_list:
        reserved = set()

        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                reserved.add(attribute)
            else:
                reserved.add(attribute)

    print(reserved)
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'connection' in reserved
    assert 'sudo' in reserved
    assert 'sudo_user' in reserved
    assert 'environment' in reserved

# Generated at 2022-06-21 09:54:08.176702
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')


# Generated at 2022-06-21 09:54:11.328765
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # check that the reserved list is all strings
    for word in _RESERVED_NAMES:
        assert(isinstance(word, str))

    # test inclusion of private and removal
    assert(len(get_reserved_names(False)) < len(_RESERVED_NAMES))

# Generated at 2022-06-21 09:54:20.533557
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Create a sample of variables with reserved names
    reserved_vars = get_reserved_names()
    # Create a sample of additonal reserved names
    additional_reserved_names = frozenset(('reserved_name_one',
                                           'reserved_name_two'))
    # Create a dictionary of variables with reserved names
    reserved_vars_dict = {}
    for name in reserved_vars:
        reserved_vars_dict[name] = name
    additional_reserved_vars_dict = {}
    for name in additional_reserved_names:
        additional_reserved_vars_dict[name] = name
    # Test warn_if_reserved with a dictionary of variables that uses reserved names
    warn_if_reserved(reserved_vars_dict)
    # Test warn_if_

# Generated at 2022-06-21 09:54:22.313639
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(["hosts"])
    warn_if_reserved(["hosts", "vars"])

# Generated at 2022-06-21 09:54:30.286367
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = [
        'action',
        'any_errors_fatal',
        'async',
        'become',
        'become_user',
        'become_method',
        'changed_when',
        'connection',
        'delegate_to',
        'delay',
        'delegate_facts',
        'environment',
        'failed_when',
        'first_available_file',
        'ignore_errors',
        'local_action',
        'loop',
        'name',
        'notify',
        'no_log',
        'poll',
        'register',
        'role_name',
        'run_once',
        'serial',
        'when',
        'until',
        'retries',
        'tags',
    ]


# Generated at 2022-06-21 09:54:37.448932
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('ignore_errors')

    assert not is_reserved_name('somename')
    assert not is_reserved_name('roles')
    assert not is_reserved_name('pre_tasks')
    assert not is_reserved_name('post_tasks')
    assert not is_reserved_name('any_errors_fatal')

# Generated at 2022-06-21 09:54:45.895562
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.errors import AnsibleError

    # Test conflicting with private reserved
    try:
        warn_if_reserved(['include_tasks'])
    except AnsibleError:
        pass
    else:
        # did not get expected error
        assert False

    # Test conflicting with public reserved
    try:
        warn_if_reserved(['action'])
    except AnsibleError:
        pass
    else:
        # did not get expected error
        assert False

    # Test not conflicting with reserved
    try:
        warn_if_reserved(['name'])
    except AnsibleError:
        # got unexpected error
        assert False

    # Test not conflicting with custom reserved

# Generated at 2022-06-21 09:54:52.704636
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_reserved = get_reserved_names(include_private=False)

# Generated at 2022-06-21 09:56:43.728344
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')


# Generated at 2022-06-21 09:56:53.130846
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert_equal(set(['name', 'hosts', 'vars', 'roles', 'tasks', 'handlers', 'pre_tasks', 'post_tasks', 'any_errors_fatal', 'become', 'become_user', 'become_method', 'environment', 'become_flags', 'verbosity', 'gather_facts', 'tags', 'register', 'ignore_errors', 'force_handlers', 'serial']), get_reserved_names(include_private=False))

# Generated at 2022-06-21 09:57:01.134689
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names() ==
           {'async', 'become', 'become_user', 'become_method', 'block', 'connection', 'delegate_to', 'register',
            'retries', 'until', 'when', 'notify', 'failed_when', 'local_action', 'name', 'port', 'remote_user',
            'roles', 'serial', 'tasks', 'vars', 'tags', 'with_'})


# Generated at 2022-06-21 09:57:04.399968
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['private']))

# Generated at 2022-06-21 09:57:06.264871
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert 'private' in _RESERVED_NAMES

# Generated at 2022-06-21 09:57:07.697010
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become_user')

# Generated at 2022-06-21 09:57:15.930736
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    try:
        # set display to None to disable warnings
        display_test = Display()
        display.display = None

        # warn_if_reserved get 'hosts' and 'vars' internally
        # those names are reserved
        reserved = get_reserved_names()
        reserved.remove('hosts')
        reserved.remove('vars')
        expected_warnings = len(reserved)

        warn_if_reserved(reserved)

        # we should have got as many warnings as we have names
        assert display_test.deprecations == expected_warnings
    finally:
        # set display back to normal
        display.display = display_test.display


# Generated at 2022-06-21 09:57:23.421839
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_result = frozenset(['block', 'name', 'role_name', 'hosts', 'meta', 'pre_tasks', 'tasks', 'post_tasks', 'become', 'become_user', 'delegate_to', 'become_method', 'vars', 'host_vars', 'group_vars', 'roles', 'local_action', 'with_', 'register', 'ignore_errors', 'any_errors_fatal', 'connection', 'port', 'remote_user', 'loop', 'when'])
    assert set(_RESERVED_NAMES) == expected_result

# Generated at 2022-06-21 09:57:31.068399
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test public reserved names only
    reserved_names = get_reserved_names(False)
    # all names are unique
    assert len(reserved_names) == len(set(reserved_names))
    # no private names
    assert all(not name.startswith('_') for name in reserved_names)

    # test public and private reserved names
    reserved_names = get_reserved_names(True)
    # all names are unique
    assert len(reserved_names) == len(set(reserved_names))
    # no private names
    assert all(not name.startswith('_') for name in reserved_names)



# Generated at 2022-06-21 09:57:32.816382
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('name')
    assert not is_reserved_name('foobar')

