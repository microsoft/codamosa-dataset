

# Generated at 2022-06-21 09:48:34.177570
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('with_items') is True
    assert is_reserved_name('not_a_reserved_name') is False

# Generated at 2022-06-21 09:48:39.472166
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test the reserved name checking functionality '''

    # define a test set of reserved words
    public = set()
    private = set()
    public.add('foo')
    private.add('localhost')
    private.add('play_hosts')
    private.add('play_hosts_all')
    private.add('groups')

    # add an additional word we don't want to check
    private.add('bar')

    # run the checker with all types of options, which should not produce any errors
    warn_if_reserved(['foo'], additional=private)
    warn_if_reserved(['localhost'], additional=public)
    warn_if_reserved(['play_hosts'], additional=private)
    warn_if_reserved(['play_hosts'], additional=public)
    warn_

# Generated at 2022-06-21 09:48:43.213657
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('roles:') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('random_non_reserved_name') is False

# Generated at 2022-06-21 09:48:54.344205
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    display = Display()

    #  Build a mock class
    class MockDisplay(object):
        """ mock object for testing.. """
        def __init__(self):
            self.displayed = []

        def warning(self, msg):
            self.displayed.append(msg)

    def reset_displayed():
        display.deprecated = MockDisplay()
        display.displayed = []

    # Reset the caches.
    reset_displayed()

    # Create a fake variable list
    fake_var_list = [ 'foo', 'my_action', 'my_task', 'my_loop', 'my_block' ]

    # Call the function
    warn_if_reserved(fake_var_list)

    assert 'Found variable using reserved name: my_action' in display.displayed

# Generated at 2022-06-21 09:48:59.807789
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)
    assert 'name' in public

    assert 'any_errors_fatal' in private
    assert 'any_errors_fatal' not in public

    # make sure local_action is still a reserved name, even though it's not explicitly defined
    assert 'local_action' in private
    assert 'local_action' in public

# Generated at 2022-06-21 09:49:06.476311
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('localhost')
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert is_reserved_name('roles')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('tasks')
    assert not is_reserved_name('playbook')
    assert not is_reserved_name('play')
    assert not is_reserved_name('include')
    assert not is_reserved_name('include_tasks')
    assert not is_reserved_name('include_role')

# Generated at 2022-06-21 09:49:08.176380
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'name' in names

# Generated at 2022-06-21 09:49:12.633953
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles'), "roles is reserved name"
    assert is_reserved_name('vars'), "vars is reserved name"
    assert is_reserved_name('hosts'), "hosts is reserved name"
    assert not is_reserved_name('valid_name'), "valid_name is a valid name"

# Generated at 2022-06-21 09:49:14.114381
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")
    assert is_reserved_name("vars")
    assert not is_reserved_name("host")
    assert not is_reserved_name("var")

# Generated at 2022-06-21 09:49:16.544139
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('block')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('xyz')



# Generated at 2022-06-21 09:49:49.175613
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('hosts'))
    assert(not is_reserved_name('host'))
    assert(is_reserved_name('connection'))
    assert(is_reserved_name('action'))


# The test below checks the list of reserved names against the real units.
# It should not be run with other unit tests as it is not really a test.

# Generated at 2022-06-21 09:50:01.834732
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test if all object's attributes are returned
    private = get_reserved_names(include_private=True)
    public = get_reserved_names(include_private=False)
    assert private.difference(public) == {'action', 'loop', 'local_action', 'with_'}

    # test if local_action is inside public names
    assert 'local_action' in public

    # test if all object's attributes are returned
    private = get_reserved_names(include_private=True)
    all_object_attributes = set()
    for aclass in [Play, Role, Block, Task]:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            all_object_attributes.add(attribute)

    assert private.union(public) == all_object

# Generated at 2022-06-21 09:50:13.350718
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names(include_private=True)
    assert 'loop' in get_reserved_names(include_private=True)
    assert 'gather_facts' in get_reserved_names(include_private=True)
    assert 'meta' in get_reserved_names(include_private=True)
    assert 'with_' in get_reserved_names(include_private=True)
    assert 'local_action' in get_reserved_names(include_private=True)

    assert 'name' in get_reserved_names(include_private=False)
    assert 'loop' in get_reserved_names(include_private=False)
    assert 'gather_facts' in get_reserved_names(include_private=False)
    assert 'meta' in get_reserved

# Generated at 2022-06-21 09:50:17.590512
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('whatever')
    assert is_reserved_name('with_')


# Generated at 2022-06-21 09:50:26.601362
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved({'vars': {'test': {}}}, additional=set())
    except KeyError:
        raise AssertionError("warn_if_reserved() raised KeyError unexpectedly!")
    try:
        warn_if_reserved({'vars': {'role': {}}}, additional=set())
    except KeyError:
        raise AssertionError("warn_if_reserved() raised KeyError unexpectedly!")
    try:
        warn_if_reserved({'vars': {'play': {}}}, additional=set())
    except KeyError:
        raise AssertionError("warn_if_reserved() raised KeyError unexpectedly!")

# Generated at 2022-06-21 09:50:34.458816
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    import ansible.utils.module_docs as module_docs

    display = Display()
    display.verbosity = 3

    # Test with one reserved name
    task = dict(action=dict(module='setup', args=dict(filter='ansible_all_ipv4_addresses')))

    reserved = set(('delegate_to', 'delegate_facts'))
    reserved_names = get_reserved_names(include_private=True)
    varnames = set([k for k in task['action']])
    varnames = varnames.intersection(reserved_names).intersection(reserved)

    for varname in varnames:
        display.deprecated('Found variable using reserved name: %s' % varname, version='2.8')

    # Test with multiple reserved

# Generated at 2022-06-21 09:50:45.023915
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('vars')
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('with_')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('private')
    assert is_reserved_name('when')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('include_role')
    assert is_reserved_name('include_playbook')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('register')
    assert is_reserved_name('local_action')

# Generated at 2022-06-21 09:50:55.974350
# Unit test for function is_reserved_name

# Generated at 2022-06-21 09:51:00.927658
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        old_display_warning = display.warning
        assert False, "We should never get here."
    except AssertionError:
        pass
    except Exception as e:
        assert e.__class__.__name__ == 'UndefinedError'
        assert 'ERROR!' in str(e)
    finally:
        display.warning = old_display_warning

# Generated at 2022-06-21 09:51:03.416705
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for reserved_name in _RESERVED_NAMES:
        assert is_reserved_name(reserved_name)
    assert not is_reserved_name('whatever')

# Generated at 2022-06-21 09:51:43.985319
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(_RESERVED_NAMES) == 33
    assert 'action' in _RESERVED_NAMES
    assert 'pre_tasks' in _RESERVED_NAMES
    assert 'post_tasks' in _RESERVED_NAMES

# Generated at 2022-06-21 09:51:48.425734
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ex_dict = {'name': u'nfs_server',
               'serial': 1,
               'hosts': u'nfs_server',
               'roles': u'nfs_server',
               'tasks': [{'name': u'make sure nfs is installed', 'apt': u'name=nfs-kernel-server'}],
               'handlers': [{'name': u'start rpcbind', 'service': u'name=rpcbind state=started'}]}

    warn_if_reserved(ex_dict)

# Generated at 2022-06-21 09:51:52.332213
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('with_items')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('vars_prompt')
    assert not is_reserved_name('foobar')
    assert not is_reserved_name('role')
    assert not is_reserved_name('hosts')


# Generated at 2022-06-21 09:52:02.416199
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['foo', 'when', 'role_name', 'name', 'action']) == None
    assert warn_if_reserved(['foo', 'when', 'role_name', 'name', 'action'], ['newreserved']) == None
    assert warn_if_reserved(['foo', 'when', 'role_name', 'name', 'action'], ['newreserved', 'with_']) == None
    assert warn_if_reserved(['foo', 'when', 'role_name', 'name', 'action', 'newreserved']) == None
    assert warn_if_reserved(['foo', 'when', 'role_name', 'name', 'action', 'newreserved'], ['newreserved']) == None

# Generated at 2022-06-21 09:52:04.122331
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('main')


# Generated at 2022-06-21 09:52:05.718735
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['hosts', 'roles'])
        assert False, 'should have failed'
    except:
        pass

# Generated at 2022-06-21 09:52:11.792286
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from cStringIO import StringIO

    # Create a string buffer to capture output
    buf = StringIO()
    # Capture warnings to the buffer
    display.wrap_warnings(buf)

    # Create a list of variables with some reserved names
    vars = ['vars', 'name', 'become', 'block', 'action']
    # Run the test
    warn_if_reserved(vars)
    # Get the contents of the buffer
    results = buf.getvalue()

    # The expected variable names are in the buffer
    assert vars[1] in results
    assert vars[2] in results
    assert vars[3] in results
    assert vars[4] in results
    # vars

# Generated at 2022-06-21 09:52:21.187831
# Unit test for function get_reserved_names
def test_get_reserved_names():
    def assert_result(result):
        assert 'hosts' in result
        assert 'tasks' in result
        assert 'roles' in result
        assert 'vars_files' in result
        assert 'vars' in result
        assert 'remote_user' in result
        assert 'name' in result
        assert 'become' in result
        assert 'gather_facts' in result
        assert 'any_errors_fatal' in result
        assert 'tags' in result
        assert 'with_' in result
        assert 'local_action' in result

    assert_result(get_reserved_names())
    assert_result(get_reserved_names(include_private=False))

# Generated at 2022-06-21 09:52:22.828032
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts': 'somehosts', 'vars': 'somevars'})

# Generated at 2022-06-21 09:52:23.916598
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'vars' in _RESERVED_NAMES

# Generated at 2022-06-21 09:53:11.223584
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['notify', 'tags'])
    warn_if_reserved(['notify', 'task'])
    warn_if_reserved(['notify', 'role'])
    warn_if_reserved(['notify', 'block'])

# Generated at 2022-06-21 09:53:13.761187
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'roles', 'with_', 'include_role', 'role', 'task', 'loop', 'include_vars'}) is None



# Generated at 2022-06-21 09:53:24.069165
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the internal function get_reserved_names '''

    # create the results
    # since this function should be updated when play features are updated,
    # we have to hardcode the results
    # FIXME: find a way to automate this test

# Generated at 2022-06-21 09:53:33.282990
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test individual name
    assert 'hosts' in get_reserved_names()
    assert 'environment' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'port' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()

    # Test name count
    assert len(get_reserved_names()) >= 40

    # Test with_
    assert 'with_' in get_reserved_names()
    assert 'loop' not in get_reserved_names()

    # Test local_action
    assert 'local_action' in get_reserved_names()
    assert 'action' not in get_reserved_names()

    # Test including private names
    assert 'transport'

# Generated at 2022-06-21 09:53:35.646082
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('gather_facts') is True
    assert is_reserved_name('foobar') is False
    assert is_reserved_name('frozenset') is False

# Generated at 2022-06-21 09:53:45.537341
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.vars import combine_vars

    class Dummy:
        _attributes = frozenset()

    orig_reserved = _RESERVED_NAMES

    _RESERVED_NAMES = frozenset(['foo'])
    for name in ['foo', 'bar']:
        var = {'vars': {name: 'bar-value'}}

        # Test without include_private or additional
        warn_if_reserved(combine_vars(var, var))

        # Test with additional
        warn_if_reserved(combine_vars(var, var), ['baz'])

        # Test with additional AND private_attributes
        warn_if_reserved(combine_vars(var, var), additional=['baz'], include_private=True)

        #

# Generated at 2022-06-21 09:53:53.135165
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'pre_tasks' in get_reserved_names()
    assert 'add_host' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'no_log' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'environment' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert '_raw_params' in get_reserved_names()
    assert '_role_name' in get_reserved_names()
    assert '_role_path' in get_reserved_names()
    assert '_flush_cache' in get_reserved_names(include_private=True)

# Generated at 2022-06-21 09:54:01.979509
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.included_file import IncludedFile
    from ansible.vars.hostvars import HostVars
    fake_vars = dict(all_hosts=dict(), magic_hosts=dict())
    fake_host = HostVars(name="fakehost", vars=fake_vars)
    fake_inc_file = IncludedFile(path='/path/to/file', args=dict(), private=dict())
    fake_play = Play().load({'name': 'fakeplay',
                             'hosts': '127.0.0.1',
                             'tasks': [dict(action=dict(module='shell', args='echo hello'))]})

# Generated at 2022-06-21 09:54:09.269667
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert isinstance(get_reserved_names(True), set)
    assert isinstance(get_reserved_names(False), set)
    assert _RESERVED_NAMES == get_reserved_names(True)
    assert 'tasks' in _RESERVED_NAMES
    assert 'tasks' in get_reserved_names(True)
    assert 'tasks' in get_reserved_names(False)
    assert not is_reserved_name('bogus_name')
    assert is_reserved_name('tasks')


# Generated at 2022-06-21 09:54:15.190834
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name("hosts")
    assert is_reserved_name("hosts")

    assert not is_reserved_name("play_hosts")
    assert not is_reserved_name("play_hosts")

    assert is_reserved_name("remote_user")
    assert is_reserved_name("remote_user")

    assert not is_reserved_name("play_remote_user")
    assert not is_reserved_name("play_remote_user")

# Generated at 2022-06-21 09:56:18.104390
# Unit test for function is_reserved_name
def test_is_reserved_name():
    '''
    Ensures is_reserved_names() functions as expected
    '''
    assert is_reserved_name('hosts')
    assert is_reserved_name('block')
    assert is_reserved_name('role_name')
    assert is_reserved_name('max_fail_percentage')
    assert is_reserved_name('vars')  # we add this one internally, so safe to ignore
    assert not is_reserved_name('foobar')
    assert not is_reserved_name('name')
    assert not is_reserved_name('command')
    assert not is_reserved_name('local_action')

# Generated at 2022-06-21 09:56:21.048471
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    loop implies with_
    FIXME: remove after with_ is not only deprecated but removed
    '''

    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()



# Generated at 2022-06-21 09:56:31.151379
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this function is a test of warn_if_reserved'''

    vars = {'action': {'echo': 'hello world'}}
    warn_if_reserved(vars)
    assert 'action' in _RESERVED_NAMES

    vars = {'action': {'shell': 'echo hello'}}
    warn_if_reserved(vars)
    assert 'action' in _RESERVED_NAMES

    vars = {'local_action': {'shell': 'echo hello'}}
    warn_if_reserved(vars)
    assert 'local_action' in _RESERVED_NAMES

    vars = {'become': 'yes'}
    warn_if_reserved(vars)
    assert 'become' in _RESERVED_NAMES



# Generated at 2022-06-21 09:56:39.154482
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_values = (
        # test_set, should_warn?
        ([''], False),
        (['name'], False),
        (['loops'], True),
        (['roles'], True),
        (['action'], True),
        (['action', 'local_action'], False),
        (['roles', 'tasks'], True),
        (['vars'], False),
        (['roles', 'vars'], True),
        (['roles', 'foo_bar'], False)
    )
    import sys
    from io import StringIO

    for test_set, should_warn in test_values:
        out = StringIO()
        display.verbosity = 0
        display.stdout = out
        warn_if_reserved(test_set)
        out.seek

# Generated at 2022-06-21 09:56:46.876258
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import tempfile
    import os

    (handle, fpath) = tempfile.mkstemp()
    f = os.fdopen(handle, 'w')
    f.write("""
        # hosts must be a list even if it contains only one host
        hosts:
            - somerole
        vars:
            - test_var: somevalue""")
    f.flush()
    f.close()

    f = open(fpath, 'r')
    yaml_data = yaml.safe_loa

# Generated at 2022-06-21 09:56:56.078671
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    unit test for function get_reserved_name
    '''

    result = get_reserved_names(include_private=False)
    expected = set()

    # build list of expected names
    class_list = [Play, Role, Block, Task]
    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' not in attribute:
                expected.add(attribute)

    # check for any unexpected names
    if not result.issubset(expected):
        raise AssertionError("Unexpected names returned from function get_reserved_name")

    # check for any missing names
    if not expected.issubset(result):
        raise AssertionError

# Generated at 2022-06-21 09:56:58.248687
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('roles')
    assert not is_reserved_name('something_else')

# Generated at 2022-06-21 09:57:04.441999
# Unit test for function get_reserved_names
def test_get_reserved_names():
    rn = get_reserved_names()
    assert 'become' in rn
    assert 'connection' in rn
    assert 'gather_facts' in rn
    assert 'role_path' in rn
    assert 'roles' in rn
    assert 'tasks' in rn
    assert 'ignore_errors' in rn
    assert 'include' in rn
    assert 'private' not in rn
    assert 'private' in get_reserved_names(include_private=True)

# Generated at 2022-06-21 09:57:14.346829
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:57:16.349143
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('task')
    assert not is_reserved_name('play')
    assert not is_reserved_name('hosts')