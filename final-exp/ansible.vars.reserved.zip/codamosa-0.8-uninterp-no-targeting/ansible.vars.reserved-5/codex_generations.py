

# Generated at 2022-06-21 09:48:33.168297
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys

    import ansible.plugins.loader as plugins

    # create a dummy object to have a display.warning() method
    class foo(object):
        def warning(self, string):
            #print string
            pass

    global display
    display = foo()

    # create a dummy dict so we can test for it
    class bar(dict):
        def __getattr__(self, key):
            value = self[key]
            if isinstance(value, dict):
                return bar(value)
            return value

    # create a dummy plugins loader
    class baz(plugins.PluginLoader):
        module_utils = ['foo']

    # create a dummy module_utils module to test loader
    class foo_module_utils(object):
        @staticmethod
        def bar(myvars):
            return myvars

    sys

# Generated at 2022-06-21 09:48:35.426089
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for rn in _RESERVED_NAMES:
        assert(is_reserved_name(rn))
    assert(not is_reserved_name('whatever'))

# Generated at 2022-06-21 09:48:44.452650
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    from ansible.module_utils.six import StringIO

    # setup display to save output
    d = Display()
    buf = StringIO()
    d.verbosity = 4
    d.display(buf)

    # check reserved names
    warn_if_reserved(['vars', 'name', 'roles', 'tasks'], ['test'])
    assert buf.getvalue() == 'warning: Found variable using reserved name: name\nwarning: Found variable using reserved name: roles\nwarning: Found variable using reserved name: tasks\n', buf.getvalue()

    # check warning not shown
    buf.truncate(0)
    warn_if_reserved(['vars', 'not_rname', 'not_rname2'])

# Generated at 2022-06-21 09:48:48.586688
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('any_keyword')
    assert is_reserved_name('roles')
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('bananas')

# Generated at 2022-06-21 09:48:53.274057
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['local_action', 'delegate_to', 'action', 'loop', 'with_', 'vars'])
    warn_if_reserved(['with_'])
    warn_if_reserved(['ignore_errors'])
    warn_if_reserved(['name'])

# Generated at 2022-06-21 09:48:54.543245
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')



# Generated at 2022-06-21 09:48:57.646476
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('loop')
    assert is_reserved_name('role_names')



# Generated at 2022-06-21 09:49:00.297579
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('actions')

__all__ = ['_RESERVED_NAMES', 'get_reserved_names', 'warn_if_reserved', 'is_reserved_name']

# Generated at 2022-06-21 09:49:01.881631
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(False)
    assert 'hosts' in reserved


# Generated at 2022-06-21 09:49:07.869265
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest

    try:
        warn_if_reserved({'vars': 'test'})
    except:
        pytest.fail("warn_if_reserved({'vars': 'test'}) raised an exception unexpectedly!")

    try:
        warn_if_reserved({'debug': 'test'})
    except:
        pytest.fail("warn_if_reserved({'debug': 'test'}) raised an exception unexpectedly!")

    with pytest.raises(Exception) as excinfo:
        warn_if_reserved({'vars': 'test', 'action': 'test2'})
    assert 'Found variable using reserved name: action' in excinfo.value.args[0]


# Generated at 2022-06-21 09:49:45.769870
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:49:47.676093
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    for name in ['name', 'hosts', 'user', 'connection', 'gather_facts']:
        assert name in reserved
    assert 'no_log' not in reserved

# Generated at 2022-06-21 09:49:53.497806
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display

    display = Display()
    warn_if_reserved(['action', 'delegate_to'])
    assert display.display.__contains__("Found variable using reserved name: action")

# Generated at 2022-06-21 09:49:59.564830
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get_reserved_names function test
    # return list of reserved names
    reserved_names = get_reserved_names(True)

    # assert reserved names
    assert 'tags' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'delegate_to' in reserved_names
    assert 'with_items' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'become' in reserved_names
    assert 'become_user' in reserved_names
    assert 'name' in reserved_names
    assert 'sudo' in reserved_names
    assert 'sudo_user' in reserved_names

    # test without private names
    reserved_names = get_reserved_names(False)

    # assert reserved names
    assert 'tags'

# Generated at 2022-06-21 09:50:02.887065
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # With test name that is a reserved name
    assert is_reserved_name("hosts")

    # With test name thatis not a reserved name
    assert not is_reserved_name("some_random_name")

# Generated at 2022-06-21 09:50:14.677880
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from .unit.mock.loader import DictDataLoader
    from .unit.mock.path import mock_unfrackpath_noop

# Generated at 2022-06-21 09:50:17.726349
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('foo') is False



# Generated at 2022-06-21 09:50:22.126255
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(dict(action='ping'))
    except Exception as e:
        raise AssertionError("unexpected exception: %s" % e)


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-21 09:50:24.472980
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['connection', 'vars', 'sudo_user', 'not_reserved']) is None

# Generated at 2022-06-21 09:50:30.776044
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('tasks')
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('with_dict')
    assert is_reserved_name('with_dict')
    assert is_reserved_name('with_dict')
    assert not is_reserved_name('inta')
    assert not is_reserved_name('intd')

# Generated at 2022-06-21 09:50:51.644162
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('roles')
    assert not is_reserved_name('my_role')
    assert not is_reserved_name('hosts')

# Generated at 2022-06-21 09:50:55.791941
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('action')
    assert is_reserved_name('vars')
    assert is_reserved_name('tags')
    assert is_reserved_name('hosts')
    assert is_reserved_name('block')
    assert is_reserved_name('block_tasks')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('delegate_facts')
    assert is_reserved_name('register')

    assert not is_reserved_name('foo')
    assert not is_reserved_name('bar')
    assert not is_reserved_name('baz')
    assert not is_reserved_name('qux')

# Generated at 2022-06-21 09:51:05.707054
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test public and private names
    assert get_reserved_names() == get_reserved_names(True)
    assert get_reserved_names(False) < get_reserved_names()

    # test specific names

# Generated at 2022-06-21 09:51:10.507375
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=True)
    assert 'action' in result
    assert 'local_action' in result
    assert 'loop' in result
    assert 'with_' in result

    result = get_reserved_names(include_private=False)
    assert 'action' in result
    assert 'loop' in result
    assert 'with_' in result
    assert 'local_action' not in result


# Generated at 2022-06-21 09:51:14.844688
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('roles_path')
    assert is_reserved_name('import_playbook')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:51:22.368332
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:51:24.556060
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test get_reserved_names function to verify reserved names returned'''

    assert 'name' in get_reserved_names()


# Generated at 2022-06-21 09:51:33.016846
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    _RESERVED_NAMES = set(get_reserved_names())
    assert 'hosts' in _RESERVED_NAMES
    assert 'hosts' in warn_if_reserved({'hosts': '127.0.0.1'})
    assert 'hosts' in warn_if_reserved({'hosts': '127.0.0.1'}, ['bogus'])
    assert 'hosts' in warn_if_reserved({'bogus': '127.0.0.1', 'hosts': '127.0.0.1'}, ['bogus'])
    assert 'include_vars' in warn_if_reserved({'include_vars': '127.0.0.1'})

# Generated at 2022-06-21 09:51:36.639628
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=True)
    assert result
    assert isinstance(result, set)
    assert 'vars' in result

    result = get_reserved_names(include_private=False)
    assert result
    assert isinstance(result, set)
    assert 'vars' in result


# Generated at 2022-06-21 09:51:42.546970
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert len(_RESERVED_NAMES) > 40
    assert 'hosts' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'meta' in _RESERVED_NAMES
    assert 'depends_on' in _RESERVED_NAMES
    assert 'any_errors_fatal' not in _RESERVED_NAMES



# Generated at 2022-06-21 09:52:45.687017
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('vars')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert is_reserved_name('tags')
    assert is_reserved_name('tasks')
    assert not is_reserved_name('foo')


# Generated at 2022-06-21 09:52:54.678788
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.plugins.loader import find_plugin_filters

    # reserved = ['environment', 'with_items', 'when', 'facts', 'vars', 'tags', 'any_errors_fatal', 'block', 'async', 'notify', 'register']
    assert warn_if_reserved([
        'environment', 'with_items', 'when', 'facts', 'tags', 'any_errors_fatal', 'block', 'async', 'notify', 'register'
    ]) is None, 'reseved name not detected'
    assert warn_if_reserved(['fake_name']) is None, 'variable name that does not collide with reserved not detected'
    assert warn_if_reserved(['fake_name', 'fake_name2']) is None, 'variable name that does not collide with reserved not detected'

# Generated at 2022-06-21 09:53:05.633238
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the function get_reserved_names() '''
    public_set = set([u'delegate_to', u'when', u'block', u'local_action', u'tags', u'roles', u'vars', u'include', u'hosts', u'name', u'tasks', u'any_errors_fatal', u'gather_facts', u'gather_subset', u'vars_files', u'handlers', u'include_tasks', u'no_log', u'register', u'post_tasks', u'pre_tasks', u'with_'])

# Generated at 2022-06-21 09:53:08.404283
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('test')
    assert not is_reserved_name('Test')

# Generated at 2022-06-21 09:53:17.876359
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = {}
    warn_if_reserved(myvars)
    warn_if_reserved(myvars, ['custom_var'])
    myvars = {'vars': 'myvars'}
    warn_if_reserved(myvars)
    myvars = {'action': 'myvars'}
    warn_if_reserved(myvars)
    myvars = {'local_action': 'myvars'}
    warn_if_reserved(myvars)
    myvars = {'loop': 'myvars'}
    warn_if_reserved(myvars)
    myvars = {'with_': 'myvars'}
    warn_if_reserved(myvars)

# Generated at 2022-06-21 09:53:26.434267
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # NOTE: this is here for testing purposes, not for linting
    # pylint: disable=too-few-public-methods

    class MyClass(object):
        class_attr = None

    obj = MyClass()

    # Test case for non-string type
    try:
        get_reserved_names(obj)
    except AssertionError:
        pass
    else:
        assert False, "Expected AssertionError"

    # Test case for empty list
    assert get_reserved_names([]) == set()

    # Test case for basic class
    assert get_reserved_names([obj]) == set(['class_attr'])

    # Test case for configured class
    obj.__dict__['_attributes'] = ['first_attr', (({'private': True},)), 'second_attr']


# Generated at 2022-06-21 09:53:30.435664
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in ('hosts', 'roles', 'tasks', 'pre_tasks', 'post_tasks', 'vars', 'action', 'name', 'delegate_to', 'notify', 'tags', 'register', 'ignore_errors', 'run_once'):
        assert is_reserved_name(name) is True

# Generated at 2022-06-21 09:53:38.274599
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")
    assert is_reserved_name("vars")
    assert is_reserved_name("roles")
    assert is_reserved_name("become")
    assert is_reserved_name("gather_facts")
    assert is_reserved_name("connection")
    assert is_reserved_name("register")
    assert is_reserved_name("when")
    assert is_reserved_name("any_errors_fatal")
    assert is_reserved_name("serial")
    assert is_reserved_name("block")
    assert is_reserved_name("tags")
    assert is_reserved_name("hosts")
    assert is_reserved_name("name")
    assert is_reserved_name("action")
    assert is_reserved

# Generated at 2022-06-21 09:53:48.798344
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.task import Task

    # Test a list of reserved names
    names = _RESERVED_NAMES
    for name in names:
        assert name in Task._attributes
    value = Task(task_include=dict(var1=1))
    assert value.task_include == dict(var1=1)
    assert value.private == []

    # Test a reserved name
    value = Task(delegate_to='127.0.0.1')
    assert value.delegate_to == '127.0.0.1'
    assert value.private == ['delegate_to']
    value = Task(action=dict(module='raw', delegate_to='127.0.0.1'))
    assert value.action == dict(module='raw', delegate_to='127.0.0.1')

# Generated at 2022-06-21 09:53:55.849728
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        assert _RESERVED_NAMES == frozenset(get_reserved_names())
    except AssertionError:
        # Print the sets and manually compare them to determine what's different
        import pprint
        pp = pprint.PrettyPrinter()
        pp.pprint('Expected: ' + str(frozenset(get_reserved_names())))
        pp.pprint('Actual: ' + str(_RESERVED_NAMES))
        raise

# Generated at 2022-06-21 09:55:52.037192
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = ['hosts', 'roles']
    non_reserved_names = ['foo', 'bar']

    for name in reserved_names:
        assert is_reserved_name(name) is True

    for name in non_reserved_names:
        assert is_reserved_name(name) is False

# Generated at 2022-06-21 09:55:54.587271
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles') == True
    assert is_reserved_name('action') == True
    assert is_reserved_name('not_reserved') == False

# Generated at 2022-06-21 09:55:57.439125
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert not warn_if_reserved(['foo'])
    assert not warn_if_reserved(['foo', 'bar', 'name'])
    assert warn_if_reserved(['foo', 'name'])

# Generated at 2022-06-21 09:55:58.596628
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:56:02.836853
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class TestAnsibleModule(object):
        def __getattr__(self, name):
            if name in get_reserved_names():
                return 'pong'

    class MockDisplay(object):
        def __init__(self):
            self.message = None

        def warning(self, msg):
            self.message = msg

    display = MockDisplay()
    warn_if_reserved(vars(TestAnsibleModule()), display)
    assert display.message == "Found variable using reserved name: action"

# Generated at 2022-06-21 09:56:11.908855
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:56:20.440097
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('with_items')
    assert is_reserved_name('with_dict')
    assert is_reserved_name('with_sequence')
    assert is_reserved_name('with_fileglob')
    assert is_reserved_name('with_first_found')
    assert is_reserved_name('with_flattened')
    assert is_reserved_name('tags')
    assert is_reserved_name('loop')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('vars')
    assert not is_reserved_name('my_vars')
    assert not is_reserved_name('block')
    assert not is_reserved_name('connection')

# Generated at 2022-06-21 09:56:27.101088
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # function warn_if_reserved needs to be called with a dictionary
    vars = dict()

    # validate that it works with an empty dict
    warn_if_reserved(vars)

    # validate that it works when a var name matches
    vars['hosts'] = 'localhost'
    warn_if_reserved(vars)

    # validate that it works when no var names match
    vars = dict()
    vars['foo'] = 'bar'
    warn_if_reserved(vars, additional=['baz'])

# Generated at 2022-06-21 09:56:34.572265
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('become') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('tasks') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('action') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('with') is True
    assert is_reserved_name('include') is True


# Generated at 2022-06-21 09:56:38.327367
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars','become','delegate_to','register','ignore_errors','always_run','run_once','first_available_file','any_errors_fatal','connection','become_user','remote_user','sudo','sudo_user','sudo_pass','su','su_user','su_pass','no_log','notify','async','poll'])