

# Generated at 2022-06-21 09:48:28.711876
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=False)
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'role_names' not in reserved_names
    assert 'vars' in reserved_names
    assert 'vars_files' in reserved_names
    assert 'handlers' in reserved_names
    assert 'environment' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'loop' not in reserved_names



# Generated at 2022-06-21 09:48:30.632552
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('frodo')
    assert is_reserved_name('name')

# Generated at 2022-06-21 09:48:31.804626
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')


# Generated at 2022-06-21 09:48:36.292427
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test that all reserved variables are in the return set
    assert isinstance(get_reserved_names(), frozenset)
    assert len(get_reserved_names()) >= len(_RESERVED_NAMES)

    # Test that the intersect of _RESERVED_NAMES and
    # that of get_reserved_names(include_private=False)
    # should be empty
    assert not len(get_reserved_names(include_private=False).intersection(_RESERVED_NAMES))

# Generated at 2022-06-21 09:48:44.959657
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Verify that the function get_reserved_names returns a set of names that is
    a superset of the set of names found in reserved_names-test.yml.
    '''
    import ansible.parsing.yaml.objects

    test_filename = 'lib/ansible/playbook/reserved_names-test.yml'

    with open(test_filename) as test_file:
        test_data = ansible.parsing.yaml.objects.AnsibleBaseYAMLObject.load(test_file)

    assert test_data is not None
    assert 'reserved_names' in test_data

    # Convert the list of reserved names in the test file to a set.
    test_names_set = set(test_data['reserved_names'])

    # Get the set of

# Generated at 2022-06-21 09:48:49.765926
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get_reserved_names returns a set of strings
    assert isinstance(get_reserved_names(), set)
    # the set of strings should not be empty
    assert len(get_reserved_names()) > 0
    # get_reserved_names should include 'hosts'
    assert 'hosts' in get_reserved_names()

# Generated at 2022-06-21 09:48:52.859258
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('name'))
    assert(is_reserved_name('tags'))
    assert(is_reserved_name('when'))

# Generated at 2022-06-21 09:49:02.152607
# Unit test for function warn_if_reserved

# Generated at 2022-06-21 09:49:12.313174
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, Mock

    class TestWarnIfReserved(unittest.TestCase):
        def setUp(self):
            self.warn_display = patch('ansible.playbook.role.warn_if_reserved.display')
            self.warn_display_mock = self.warn_display.start()

        def tearDown(self):
            self.warn_display.stop()

        def test_no_warnings(self):
            warn_if_reserved(['not', 'warn'])
            self.assertFalse(self.warn_display_mock.warning.called)

        def test_one_warning(self):
            warn_if_reserved(['handler'])
            self.warn_display_

# Generated at 2022-06-21 09:49:18.273616
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    from io import StringIO

    # Capture warning output
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out

        myvars = {'hosts': 'foo', 'gather_facts': 'bar', 'foobar': 'foo'}
        warn_if_reserved(myvars)

        output = out.getvalue().strip()
        assert output.startswith('[WARNING]: Found variable using reserved name: hosts')
        assert output.endswith('[WARNING]: Found variable using reserved name: gather_facts')
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-21 09:50:01.696465
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:50:10.376673
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # test if list of str is accepted
    assert warn_if_reserved(["become_user", "ansible_ssh_user"]) is None
    # test if set of str is accepted
    assert warn_if_reserved(set(["become_user", "ansible_ssh_user"])) is None
    # test if dict is accepted
    assert warn_if_reserved({"ansible_ssh_user": "testing"}) is None
    # test if frozenset is accepted
    assert warn_if_reserved(frozenset(["become_user", "ansible_ssh_user"])) is None

# Generated at 2022-06-21 09:50:12.755180
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('foobar')


# Generated at 2022-06-21 09:50:23.932350
# Unit test for function is_reserved_name
def test_is_reserved_name():
    def assert_is_reserved_name(name):
        assert is_reserved_name(name), "Name '%s' is not reserved." % name

    assert_is_reserved_name('playbook')
    assert_is_reserved_name('hosts')
    assert_is_reserved_name('remote_user')
    assert_is_reserved_name('delegate_to')
    assert_is_reserved_name('become')
    assert_is_reserved_name('become_user')
    assert_is_reserved_name('tags')

    assert not is_reserved_name('vars'), "Name 'vars' is reserved."
    assert not is_reserved_name('foobar'), "Name 'foobar' is reserved."

# Generated at 2022-06-21 09:50:32.745858
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this test ensures that get_reserved_names returns correct values '''

    display.display('\nTESTING get_reserved_names')
    private_reserved = get_reserved_names(include_private=True)
    public_reserved = get_reserved_names(include_private=False)

    assert 'action' in private_reserved
    assert 'action' in public_reserved
    assert 'hosts' in private_reserved
    assert 'hosts' in public_reserved
    assert 'become' in private_reserved
    assert 'become' in public_reserved
    assert 'serial' in private_reserved
    assert 'serial' in public_reserved
    assert 'become_user' in private_reserved
    assert 'become_user' in public_reserved

# Generated at 2022-06-21 09:50:33.995815
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('roles'))
    assert(not is_reserved_name('xyz'))

# Generated at 2022-06-21 09:50:35.671741
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test for validation of reserved names'''
    warn_if_reserved(set(['connection', 'vars']))

# Generated at 2022-06-21 09:50:38.781886
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host_list')

# Generated at 2022-06-21 09:50:40.344251
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(["foo", "action", "role_name"])

# Generated at 2022-06-21 09:50:42.738339
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:51:30.114235
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    for w in ('vars', 'name', 'hosts', 'remote_user', 'sudo_user', 'action', 'local_action', 'become_user', 'tags', 'when', 'gather_facts',
              'register', 'delegate_to', 'run_once', 'connection', 'port', 'environment', 'max_fail_percentage', 'accelerate', 'no_log',
              'deprecation_warnings'):
        assert(is_reserved_name(w))
    assert(not is_reserved_name('blarg'))

# Generated at 2022-06-21 09:51:32.071536
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars_ = {'hosts': 'localhost', 'remote_user': 'root', 'gather_facts': False}
    warn_if_reserved(vars_)

# Generated at 2022-06-21 09:51:40.481493
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # When not specifying parameters, it should return private and public attributes
    reserved_names = get_reserved_names()

    # Test result should be not empty
    assert reserved_names

    # Check that there is no empty string in result
    assert '' not in reserved_names

    # Check that there is at least one private attribute and at least one public attribute
    private_attributes = set()
    public_attributes = set()

    for attribute in reserved_names:
        if attribute.startswith('_'):
            private_attributes.add(attribute)
        else:
            public_attributes.add(attribute)

    assert private_attributes
    assert public_attributes

    # When specifying that we don't want private attributes in result, it should be empty
    reserved_names = get_reserved_names(include_private=False)


# Generated at 2022-06-21 09:51:47.585296
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = dict()

    # new role with no reserved names
    for name in ('myvar', 'my_var', 'my_role'):
        vars.clear()
        vars[name] = 'whatever'
        warn_if_reserved(vars)

    # play with a reserved name
    vars.clear()
    vars['hosts'] = 'whatever'  # the host list is often a variable, so check is disabled by default
    warn_if_reserved(vars)
    vars['hosts'] = 'whatever'  # test again with check enabled
    warn_if_reserved(vars, additional=set(('hosts',)))

    # role with reserved name
    vars.clear()
    vars['tasks'] = 'whatever'
    warn_if_reserved(vars)



# Generated at 2022-06-21 09:51:49.401966
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == get_reserved_names(include_private=False)



# Generated at 2022-06-21 09:51:50.528173
# Unit test for function is_reserved_name
def test_is_reserved_name():
    names = ['hosts', 'roles']

    for name in names:
        assert is_reserved_name(name)

# Generated at 2022-06-21 09:51:59.998472
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test function in vars_plugins/__init__.py '''

    print("Testing vars_plugins/__init__.py get_reserved_names()")
    myvars = dict()

    myvars = get_reserved_names()
    assert isinstance(myvars, set)
    assert 'hosts' in myvars
    assert 'play_hosts' in myvars
    assert 'action' in myvars

    myvars = get_reserved_names(include_private=False)
    assert isinstance(myvars, set)
    assert 'hosts' in myvars
    assert 'play_hosts' in myvars
    assert 'action' in myvars
    assert 'new_play_ds' not in myvars
    assert 'play' not in myvars

# Generated at 2022-06-21 09:52:04.692659
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names(include_private=False)
    assert(len(reserved) > 0)
    myvars = ['action', 'remote_user', 'hosts', 'vars', 'some_other_name']
    warn_if_reserved(myvars)
    assert(is_reserved_name('action'))

# Generated at 2022-06-21 09:52:05.685364
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')



# Generated at 2022-06-21 09:52:11.766773
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import os
    import tempfile

    tmp = tempfile.NamedTemporaryFile(delete=False)
    tmp.write("""
name: a variable named 'delegate_to'
hosts: localhost
connection: local
vars:
  delegate_to: 127.0.0.1
tasks:
  - ping:
""")
    tmp.close()

    # first, do a dry run of the playbook to test for warnings

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    playbook_path = tmp.name
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost'])
    variable_manager = Variable

# Generated at 2022-06-21 09:54:00.130917
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'hosts': 'all', 'action': 'setup'}) == None
    assert warn_if_reserved({'hosts': 'all', 'action': 'setup', 'roles': ['web'], 'tasks': [dict(action='flask')]}) == None
    assert warn_if_reserved({'hosts': 'all', 'pre_tasks': [dict(action='flask')]}) == None
    assert warn_if_reserved({'hosts': 'all', 'post_tasks': [dict(action='flask')]}) == None
    assert warn_if_reserved({'hosts': 'all', 'tasks': [dict(action='nested', with_items=['a', 'b'])]}) == None

# Generated at 2022-06-21 09:54:02.221060
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('delegate_to') is True)
    assert(is_reserved_name('_incl') is True)
    assert(is_reserved_name('dep') is False)

# Generated at 2022-06-21 09:54:04.498470
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('action')
    assert is_reserved_name('private')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:54:13.611942
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this function unit test the warn_if_reserved function'''

    # create a dict with reserved names and others
    reserved = _RESERVED_NAMES.copy()
    other_names = set(['foo', 'bar', 'baz'])

    input = reserved.union(other_names)

    # clear the warning to silence the first run
    display.clear_warning()

    # run the function and make sure all reserved names are warned
    warn_if_reserved(input)

    # make sure all the reserved names were warned
    if not all(display._warnings[0].endswith(name) for name in reserved):
        raise AssertionError('reserved names were not all warned')

    # make sure the non-reserved names were not warned

# Generated at 2022-06-21 09:54:22.665226
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.action import Action
    from yaml.nodes import Node
    from collections import namedtuple

    class FakeTask(Action):
        pass

    # class_list = [Play, Role, Block, Task, Handler, Action, Node]
    class_list = [Play, Role, Block, Task, Handler, FakeTask, Node]

    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                continue
            assert is_reserved_

# Generated at 2022-06-21 09:54:24.325297
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles') is False
    assert is_reserved_name('tasks') is True

# Generated at 2022-06-21 09:54:27.211022
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # No Warning Message
    myvars = {'test': 'value'}
    warn_if_reserved(myvars)

    # Warning Message
    myvars = {'name': 'value'}
    warn_if_reserved(myvars)

# Generated at 2022-06-21 09:54:29.261546
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become')
    assert is_reserved_name('become_user')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-21 09:54:35.155376
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = set([
        'connection',
        'gather_facts',
        'hosts',
        'max_fail_percentage',
        'name',
        'no_log',
        'notify',
        'port',
        'pre_tasks',
        'post_tasks',
        'roles',
        'serial',
        'tags',
        'tasks',
        'vars_files',
        'vars_prompt',
        'vault_id',
        'vault_password_file',
        'when'
    ])


# Generated at 2022-06-21 09:54:37.363544
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['name', 'foo'])
    warn_if_reserved(['name', 'foo'], additional=['bar'])