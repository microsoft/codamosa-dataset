

# Generated at 2022-06-21 09:48:21.617048
# Unit test for function get_reserved_names
def test_get_reserved_names():
    _test_reserved = _RESERVED_NAMES
    assert isinstance(_test_reserved, set)
    assert len(_test_reserved) > 0

    for reserved in _test_reserved:
        assert isinstance(reserved, str)
        assert reserved[0] != '_'



# Generated at 2022-06-21 09:48:28.667246
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # A name that is not reserved should not raise a warning
    import ansible.playbook.play_context as pc
    pc.warn_if_reserved(['foo'])

    # A name that is reserved should raise a warning
    import warnings
    with warnings.catch_warnings(record=True) as w:
        pc.warn_if_reserved(['name'])
        assert len(w) == 1
        assert issubclass(w[-1].category, UserWarning)

# Generated at 2022-06-21 09:48:33.954486
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pub = get_reserved_names(False)
    priv = get_reserved_names(True)
    assert 'hosts' in pub
    assert 'hosts' in pub
    assert 'name' in pub
    assert 'name' in priv
    assert 'roles' in pub
    assert 'serial' in pub
    assert 'remote_user' not in pub
    assert 'remote_user' in priv
    assert 'vars' in pub
    assert 'vars' not in priv

# Generated at 2022-06-21 09:48:35.390532
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('foo')



# Generated at 2022-06-21 09:48:38.963968
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # expect True because 'name' is reserved name
    assert is_reserved_name('name')
    # expect False because 'test' is not reserved name
    assert not is_reserved_name('test')

# Generated at 2022-06-21 09:48:40.787505
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert not warn_if_reserved({'test_varname': 'foo', 'test_another': 'bar'})

# Generated at 2022-06-21 09:48:41.733780
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('tags')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:48:43.610011
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles') or is_reserved_name('tasks')

# Generated at 2022-06-21 09:48:54.584340
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    display = Display()

# Generated at 2022-06-21 09:49:00.697390
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import mock

    m_warn = mock.MagicMock()
    m_warn.warning = display.warning

    warn_if_reserved({}, additional=set(['test_var']))
    m_warn.assert_not_called()

    warn_if_reserved({'test_var': 'test_value'}, additional=set(['test_var']))
    m_warn.assert_called_once_with('Found variable using reserved name: test_var')

# Generated at 2022-06-21 09:49:20.206074
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import AnsibleExitJson, AnsibleFailJson, patch
    from ansible.utils.vars import warn_if_reserved

    args = {'vars': {'test_var': '1'}}
    args2 = {'vars': {'test_var': '1', 'hosts': '1'}}

    with patch.object(Display, 'warning') as display_mock:
        with patch.object(Display, 'deprecate') as deprecate_mock:
            warn_if_reserved(args['vars'])
            assert not display_mock.called
            assert not deprecate_mock.called

            warn_if_reserved(args2['vars'])
            assert display_mock.called
            assert display_mock.call_args

# Generated at 2022-06-21 09:49:28.374084
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'action' in reserved
    assert 'tasks' in reserved
    assert 'become' in reserved
    assert 'become_user' in reserved
    assert 'become_method' in reserved
    assert 'async' in reserved
    assert 'poll' in reserved
    assert 'when' in reserved
    assert 'environment' in reserved
    assert 'sudo_flags' in reserved
    assert 'tags' in reserved
    assert 'hosts' in reserved
    assert 'vars' in reserved
    assert 'connection' in reserved
    assert 'gather_facts' in reserved
    assert 'name' in reserved
    assert 'include' in reserved
    assert 'roles' in reserved
    assert 'block' in reserved
    assert 'block:tasks' in reserved
    assert 'block:rescue'

# Generated at 2022-06-21 09:49:30.227621
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('become')
    assert is_reserved_name('loop')
    assert not is_reserved_name('not_a_real_name')
    assert not is_reserved_name(None)



# Generated at 2022-06-21 09:49:31.881065
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names()

    assert 'actions' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved

    assert 'vars' not in reserved
    assert 'loop' in reserved
    assert 'with_' not in reserved

# Generated at 2022-06-21 09:49:36.375709
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(_RESERVED_NAMES.intersection(set(get_reserved_names(include_private=True))))

# Generated at 2022-06-21 09:49:42.706644
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES == set(
        ['block', 'pre_tasks', 'post_tasks', 'roles', 'tags', 'tasks', 'vars', 'gather_facts', 'register', 'become', 'become_user',
         'hosts', 'name', 'include_tasks', 'handler_tasks', 'vars_files']
    )



# Generated at 2022-06-21 09:49:47.900847
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('include')
    assert is_reserved_name('roles')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('roles_in_hosts_variable')
    assert not is_reserved_name('another_hosts')


# Generated at 2022-06-21 09:49:56.044590
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('register')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('local_action')
    assert is_reserved_name('when')
    assert is_reserved_name('async')
    assert is_reserved_name('poll')
    assert is_reserved_name('become')
    assert is_reserved_name('become_user')

# Generated at 2022-06-21 09:50:04.772828
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert_msg = 'reserved name is missing'
    reserved_names = get_reserved_names()
    assert 'become' in reserved_names, assert_msg
    assert 'become_user' in reserved_names, assert_msg
    assert 'become_method' in reserved_names, assert_msg

    reserved_names_private = get_reserved_names(include_private=False)
    assert 'become' in reserved_names_private, assert_msg
    assert 'become_user' in reserved_names_private, assert_msg
    assert 'become_method' in reserved_names_private, assert_msg

# Generated at 2022-06-21 09:50:09.995361
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('changed_when')
    assert is_reserved_name('register')
    assert is_reserved_name('become')
    assert is_reserved_name('private_key_file')
    assert is_reserved_name('group_by')
    assert is_reserved_name('group_vars')

# Generated at 2022-06-21 09:50:37.411893
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Ensure reserved words are matched
    assert is_reserved_name('vars') is True
    assert is_reserved_name('name') is True

    # Ensure no false positives for non-reserved words
    assert is_reserved_name('myrole') is False
    assert is_reserved_name('my_definite_role') is False
    assert is_reserved_name('my_definite_role_name') is False

    # Ensure no false positives for reserved words with underscores
    assert is_reserved_name('_meta') is False

# Generated at 2022-06-21 09:50:46.916923
# Unit test for function warn_if_reserved

# Generated at 2022-06-21 09:50:48.386917
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) is frozenset



# Generated at 2022-06-21 09:50:59.033606
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:51:04.406864
# Unit test for function is_reserved_name
def test_is_reserved_name():
    import pytest
    from .common import get_data_files

    test_file = get_data_files('test_validate_is_reserved_name.yaml')[0]
    tasks = list(get_tasks_from_file(test_file))

    # Test a non reserved name
    assert not is_reserved_name("ok")

    # Test a reserved  name
    assert is_reserved_name("serial")


# Generated at 2022-06-21 09:51:12.387714
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    import pytest
    display.verbosity = 3

    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('tags')
    assert not is_reserved_name('not_a_reserved_name')

    # Make sure everything still works when the cached frozenset is empty
    global _RESERVED_NAMES
    _RESERVED_NAMES = frozenset()

    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('tags')
    assert not is_reserved_name('not_a_reserved_name')

    # Test the warn_if_reserved function


# Generated at 2022-06-21 09:51:13.525290
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('playbook')
    assert is_reserved_name('foo') is False

# Generated at 2022-06-21 09:51:16.379542
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Since 'when' is a reserved name, is_reserved_name should return 'True'
    assert is_reserved_name('when')
    # Since 'ansible' is not a reserved name, is_reserved_name should return 'False'
    assert not is_reserved_name('ansible')



# Generated at 2022-06-21 09:51:24.327507
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('playbook')
    assert is_reserved_name('play')
    assert is_reserved_name('role')
    assert is_reserved_name('block')
    assert is_reserved_name('task')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('when')
    assert is_reserved_name('become_method')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:51:30.995930
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(['hosts', 'roles', 'name', 'become', 'become_user', 'become_method', 'delegate_to', 'gather_facts'])
    private = set(['_parent', 'include_tasks', 'include_roles', 'task_blocks', 'role_blocks','post_tasks', 'pre_tasks', 'handlers', '_role_tasks', '_role_handlers'])
    assert sorted(get_reserved_names()) == sorted(public.union(private))


# Generated at 2022-06-21 09:52:28.687707
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    assert 'vars' in reserved_names
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'include' in reserved_names

    # action is reserved because we implicitly add local_action
    assert 'action' in reserved_names

    # assert 'loop' in reserved_names  # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in reserved_names

# Generated at 2022-06-21 09:52:38.001247
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private_names = get_reserved_names(include_private=True)
    public_names = get_reserved_names(include_private=False)

    private_names.discard('roles')
    private_names.discard('role_names')
    private_names.discard('force_handlers')
    private_names.discard('playbook')
    private_names.discard('block')
    private_names.discard('dependency')

    public_names.discard('force_handlers')
    public_names.discard('role_names')
    public_names.discard('roles')
    public_names.discard('playbook')
    public_names.discard('block')
    public_names.discard('dependency')


# Generated at 2022-06-21 09:52:41.885060
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert not is_reserved_name('unreserved_name')

# Generated at 2022-06-21 09:52:45.874332
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('role')
    assert is_reserved_name('block')
    assert is_reserved_name('with_')
    assert is_reserved_name('local_action')
    assert is_reserved_name('compile_role_vars')
    assert not is_reserved_name('unrelated_var')

# Generated at 2022-06-21 09:52:47.410057
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("any_task_name")
    assert not is_reserved_name("any_variable_name")


# Generated at 2022-06-21 09:52:56.240671
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Set a few reserved names, but they aren't in the list of reserved names
    # Check warn_if_reserved doesn't complain
    varnames = set(['private', 'action', 'roles'])
    assert len(varnames.intersection(_RESERVED_NAMES)) == 0
    warn_if_reserved(varnames)  # shouldn't crash and shouldn't print anything

    # Add a reserved name to the set and see what happens
    varnames.add('name')
    # Check warn_if_reserved complains
    warn_if_reserved(varnames)  # shouldn't crash, but should print
    assert len(varnames.intersection(_RESERVED_NAMES)) == 1

# Generated at 2022-06-21 09:52:59.297886
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")
    assert not is_reserved_name("not_a_reserved_name")

# Generated at 2022-06-21 09:53:08.441792
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('when')
    assert is_reserved_name('block')
    assert is_reserved_name('block_rescue')
    assert is_reserved_name('block_always')
    assert is_reserved_name('become_user')
    assert is_reserved_name('become')
    assert is_reserved_name('become_method')
    assert is_reserved_name('tags')
    assert is_reserved_name('run_once')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert not is_reserved_name

# Generated at 2022-06-21 09:53:09.948870
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['foo', 'bar']
    warn_if_reserved(myvars)

# Generated at 2022-06-21 09:53:13.056116
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('hosts') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('with_') is True
    assert is_reserved_name('foobar') is False

# Generated at 2022-06-21 09:55:02.685767
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit tests for get_reserved_names '''

    expected_public = frozenset(['tasks', 'name', 'pre_tasks',
                  'post_tasks', 'become', 'become_user', 'become_method',
                  'delegate_to', 'connection', 'any_errors_fatal',
                  'serial', 'max_fail_percentage', 'local_action', 'with_'])

    expected_private = frozenset(['action', 'handlers', 'block',
                       'block_errors', 'block_start', 'block_end',
                       'block_task', 'block_var', 'role', 'loop', 'vars'])

    expected_private_not_included = frozenset(['local_action', 'with_'])


# Generated at 2022-06-21 09:55:06.219031
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # warn_if_reserved returns nothing, so we have to check display warned with the right text
    display.display = None
    warn_if_reserved(['private'])
    assert display.display == 'Found variable using reserved name: private'

# Generated at 2022-06-21 09:55:08.160921
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")
    assert not is_reserved_name("host")
    assert not is_reserved_name("host_list")

# Generated at 2022-06-21 09:55:11.490208
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert 'hosts' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES
    assert 'source' not in _RESERVED_NAMES


# Generated at 2022-06-21 09:55:21.537204
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This test is just ensuring that we didn't miss any reserved play variables,
    # not that all of them are the ones we want.

    reserved = get_reserved_names(include_private=False)
    public = get_reserved_names()

    assert len(reserved) == 39
    assert len(public) == 57

# Generated at 2022-06-21 09:55:33.022487
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = set()
    public_names.add('name')
    public_names.add('connection')
    public_names.add('remote_user')
    public_names.add('local_action')
    public_names.add('with_')
    public_names.add('when')

    private_names = set()
    private_names.add('name')
    private_names.add('connection')
    private_names.add('remote_user')
    private_names.add('local_action')
    private_names.add('with_')
    private_names.add('when')
    private_names.add('tags')
    private_names.add('register')
    private_names.add('run_once')
    private_names.add('delegate_to')

# Generated at 2022-06-21 09:55:34.840239
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('gather_facts') is True
    assert is_reserved_name('fake_key') is False



# Generated at 2022-06-21 09:55:41.281454
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.conditional import Conditional

    # deprecated
    from ansible.playbook.task import TaskInclude

    use_private = False

    class_list = [Play, Block, Task, Handler, Role, RoleInclude, Conditional, TaskInclude]

    for aclass in class_list:
        aobj = aclass()
        # make sure we don't use private names

# Generated at 2022-06-21 09:55:43.344794
# Unit test for function is_reserved_name
def test_is_reserved_name():
    print("RESERVED_LIST", get_reserved_names())
    assert(is_reserved_name('roles'))
    assert(not is_reserved_name('roles2'))

# Generated at 2022-06-21 09:55:45.132239
# Unit test for function is_reserved_name
def test_is_reserved_name():
    '''
    Validate that is_reserved_name returns expected results
    '''
    assert is_reserved_name('any_errors_fatal')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:57:49.863447
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:57:50.994535
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['name'])


# Generated at 2022-06-21 09:57:58.960327
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function unit tests the get_reserved_names function '''

    # FIXME: remove after with_ is not only deprecated but removed
    with_names = {
        'with_first_found', 'with_dict', 'with_sequence',
        'with_fileglob', 'with_nested',
        'with_together', 'with_subelements', 'with_items',
        'with_random_choice', 'with_flattened', 'with_fileglob',
        'with_file', 'with_lines', 'with_subelements',
        'with_first_found'
    }

    # test all names returned by the function
    result = get_reserved_names()


# Generated at 2022-06-21 09:58:06.549511
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('serial') == True
    assert is_reserved_name('become') == True
    assert is_reserved_name('become_user') == True
    assert is_reserved_name('become_method') == True
    assert is_reserved_name('any_errors_fatal') == True
    assert is_reserved_name('ignore_errors') == True
    assert is_reserved_name('register') == True
    assert is_reserved_name('remote_user') == True
    assert is_reserved_name('sudo') == True
    assert is_reserved_name('sudo_user') == True
    assert is_reserved_name('su') == True
    assert is_reserved_name('su_user') == True