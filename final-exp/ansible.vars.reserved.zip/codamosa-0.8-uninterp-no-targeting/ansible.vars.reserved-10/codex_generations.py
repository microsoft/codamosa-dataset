

# Generated at 2022-06-21 09:48:29.888616
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names(include_private=False)
    reserved.update(['playbook'])

    warn_if_reserved({'name': 'foo'})
    warn_if_reserved({'playbook': 'foo'})
    warn_if_reserved(['name', 'playbook'])
    warn_if_reserved({'playbook': 'foo', 'name': 'bar'})
    warn_if_reserved(['playbook', 'name'], additional=['foo'])
    warn_if_reserved(['playbook', 'name'], additional=reserved)

# Generated at 2022-06-21 09:48:37.098524
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:48:42.398946
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test reserved names
    for n in list(_RESERVED_NAMES):
        assert is_reserved_name(n)

    # Test non-reserved names
    assert not is_reserved_name('variable_name')
    assert not is_reserved_name('something_else')


if __name__ == '__main__':
    import pytest
    pytest.main(args=[__file__])

# Generated at 2022-06-21 09:48:53.657029
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import os
    import tempfile

    class TempLogger(object):
        ''' This class mocks display.warning and allows us to determine if it was called '''
        def __init__(self):
            self.warning = False

        def warning(self, msg):
            self.warning = True

    class Context(object):
        ''' This class encapsulates the common actions for the following tests and provides the
        context for them. '''
        def __init__(self, test_data):
            self.temp_dir = tempfile.gettempdir()
            self.test_data = test_data
            self.called_warning = TempLogger()
            self.old_display = display
            self.old_cwd = os.getcwd()
            os.chdir(self.temp_dir)


# Generated at 2022-06-21 09:48:58.158680
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('forced_handlers')
    assert not is_reserved_name('name')
    assert not is_reserved_name('action')
    assert not is_reserved_name('with_')
    assert not is_reserved_name('loop')
    assert not is_reserved_name('not_an_attribute')

# Generated at 2022-06-21 09:49:01.441728
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'hosts'])
    warn_if_reserved(['action', 'hosts', 'foobar'])
    warn_if_reserved(['action', 'hosts', 'foobar', 'tasks'])


# Generated at 2022-06-21 09:49:04.842466
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('tags')
    assert is_reserved_name('vars')
    assert is_reserved_name('when')
    assert not is_reserved_name('bogus')



# Generated at 2022-06-21 09:49:14.462251
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Returns True on success and False on failure
    '''

    reserved_names = get_reserved_names()

    # check if all names have length < 22
    # (22 is the max length of the longest ansible keyword)
    for name in reserved_names:
        if len(name) > 22:
            print('{} is too large...'.format(name))
            return False

    # check if all names are lowercase
    # (this is used later on to convert variables names as lowercase)
    for name in reserved_names:
        if name != name.lower():
            print('{} is not lowercase...'.format(name))
            return False

    # check if all names are not empty

# Generated at 2022-06-21 09:49:17.932910
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    play_vars = {'include_vars': {'foo': 'bar'}, 'roles': [], 'hosts': 'all'}
    test_vars = {'roles': [], 'hosts': 'all'}
    assert warn_if_reserved(play_vars) == None
    assert warn_if_reserved(test_vars) == None

# Generated at 2022-06-21 09:49:26.102102
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Reserved names are present in object names
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('block')
    assert is_reserved_name('action')
    assert is_reserved_name('with_')
    assert is_reserved_name('with_fileglob')
    assert is_reserved_name('when')

    # Known reserved names are present
    assert is_reserved_name('accelerate')
    assert is_reserved_name('accelerate_port')
    assert is_reserved_name('always_run')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('async')
    assert is_

# Generated at 2022-06-21 09:49:49.219754
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('magic_key')

    assert not is_reserved_name('vars')

    assert not is_reserved_name('a_normal_var')

    assert is_reserved_name('become')

    assert is_reserved_name('become_user')

    assert is_reserved_name('tasks')

    assert not is_reserved_name('blah')

    assert not is_reserved_name(None)

# Generated at 2022-06-21 09:49:53.398908
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    expected_vars = ['hosts', 'roles', 'roles_path', 'action', 'local_action', 'block']
    warn_if_reserved(expected_vars)

# Generated at 2022-06-21 09:49:54.893833
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'vars' in get_reserved_names()


# Generated at 2022-06-21 09:49:57.098244
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'name', 'foo', 'action', 'local_action', 'loop'])



# Generated at 2022-06-21 09:50:08.905374
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles') is True
    assert is_reserved_name('include_role') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('task') is True
    assert is_reserved_name('vars_files') is True
    assert is_reserved_name('vars') is True
    assert is_reserved_name('local_action') is True

    assert is_reserved_name('nonexistent_role') is False
    assert is_reserved_name('tasks') is False
    assert is_reserved_name('dummy_block') is False
    assert is_reserved_name('dummy_task') is False
    assert is_reserved_name('my_var') is False

# Generated at 2022-06-21 09:50:11.608261
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)

    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:50:14.024784
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('register')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:50:16.513493
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for i in _RESERVED_NAMES:
        assert is_reserved_name(i)

# Generated at 2022-06-21 09:50:22.363371
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_dict = {}
    test_dict['hosts'] = 'localhost'
    test_dict['vars'] = {}
    test_dict['vars']['action'] = 'test'
    test_dict['vars']['loop'] = 'test'
    test_dict['vars']['tags'] = 'test'
    test_dict['vars']['name'] = 'test'
    warn_if_reserved(test_dict)

# Generated at 2022-06-21 09:50:27.898660
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=False)
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'with_items' not in reserved
    assert 'with_nested' not in reserved
    assert 'when' in reserved
    assert 'listen' not in reserved



# Generated at 2022-06-21 09:50:58.644243
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest

    # example testcase
    class Testcase(object):
        def test_scenarios(self):
            '''this is a test'''
            return {
                'foo': {'vars': {'role_path': 'foobar'}}
            }

    # get testcases
    testcase_obj = Testcase()
    scenarios = testcase_obj.test_scenarios()

    # run pytest
    pytest.main(['-q', __file__])

# Generated at 2022-06-21 09:51:08.274014
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    d = Display()

    for function in [is_reserved_name, warn_if_reserved]:
        assert function(AnsibleUnicode('vars'))
        assert not function(AnsibleUnicode('vars_test'))

    assert warn_if_reserved(['test', 'action', 'name', 'vars']) is None

    assert warn_if_reserved(['test', 'action', 'name', 'vars', 'any_errors_fatal'], ['any_errors_fatal']) is None

    # FIXME: these tests force the mocked function to return what we expect
    # and don't check the result is

# Generated at 2022-06-21 09:51:17.257750
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'vars' in reserved_names, '"vars" not in reserved_names'
    assert 'private' not in reserved_names, '"private" in reserved_names'

    reserved_names = get_reserved_names(include_private=False)
    assert 'vars' in reserved_names, '"vars" not in reserved_names'
    assert 'private' not in get_reserved_names(include_private=False), '"private" in reserved_names'

# Generated at 2022-06-21 09:51:19.062588
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # TODO: write unit tests for warn_if_reserved()
    pass

# Generated at 2022-06-21 09:51:21.175707
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert len(_RESERVED_NAMES) > 1



# Generated at 2022-06-21 09:51:30.876627
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=True) == _RESERVED_NAMES

# Generated at 2022-06-21 09:51:37.328074
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test function
    reserved_names_1 = get_reserved_names()
    reserved_names_2 = get_reserved_names(include_private=False)

    # asserts for private and public attributes
    assert 'tags' in reserved_names_1
    assert 'any_errors_fatal' in reserved_names_1
    assert 'post_tasks' in reserved_names_1
    assert 'role_path' in reserved_names_1
    assert 'private' in reserved_names_1
    assert 'private' in reserved_names_2
    assert 'private' not in reserved_names_2

    # asserts for presence of private and public attributes
    assert 'any_errors_fatal' in reserved_names_1
    assert 'role_path' in reserved_names_1
    assert 'private' in reserved_names_1


# Generated at 2022-06-21 09:51:38.373055
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(dict(name='action', other='var'))

# Generated at 2022-06-21 09:51:46.326684
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(include_private=False)
    private_names = get_reserved_names(include_private=True)
    reserved_names = frozenset(get_reserved_names())

    assert set(get_reserved_names(include_private=False)).union(set(get_reserved_names(include_private=True))) == reserved_names

    assert 'hosts' in reserved_names
    assert 'hosts' in public_names
    assert 'hosts' in private_names

    assert 'roles' in reserved_names
    assert 'roles' in public_names
    assert 'roles' in private_names

    # with_ is deprecated, so should be marked private
    assert 'with_' in reserved_names
    assert 'with_' in public_names

# Generated at 2022-06-21 09:51:52.156156
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names(include_private=False)
    assert 'hosts' in reserved
    assert 'name' in reserved
    assert 'action' in reserved
    assert 'with_' in reserved
    assert 'with_items' in reserved
    if 'local_action' in reserved:
        assert 'action' in reserved
    assert 'connections' in reserved

    reserved = get_reserved_names(include_private=True)
    assert 'hosts' in reserved
    assert 'name' in reserved
    assert 'action' in reserved
    assert 'with_' in reserved
    assert 'with_items' in reserved
    if 'local_action'in reserved:
        assert 'action' in reserved
    assert 'connections' in reserved

# Generated at 2022-06-21 09:53:00.722399
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['foo', 'action', 'my_action', 'with_', 'vars']
    warn_if_reserved(myvars)


__all__ = ['get_reserved_names', 'warn_if_reserved']

# Generated at 2022-06-21 09:53:04.732439
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in ['name', 'register', 'when', 'local_action', 'with', 'include_tasks']:
        assert is_reserved_name(name)
    for name in ['name1', 'register_']:
        assert not is_reserved_name(name)

# Generated at 2022-06-21 09:53:10.228256
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import sys

    result = get_reserved_names(include_private=True)
    assert result == _RESERVED_NAMES

    result = get_reserved_names(include_private=False)
    if sys.version_info[0] >= 3:
        assert result == _RESERVED_NAMES.difference(set(['become']))
    else:
        assert result == _RESERVED_NAMES.difference(set(['remote_user', 'become']))

# Generated at 2022-06-21 09:53:12.675881
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert_msg = "Failed while testing get_reserved_names() on ansible.playbook.play"
    test_reserved_names = get_reserved_names(True)
    assert len(test_reserved_names) > 0, "%s, 'test_reserved_names' is empty" % assert_msg

    test_reserved_names = get_reserved_names(False)
    assert len(test_reserved_names) > 0, "%s, 'test_reserved_names' is empty" % assert_msg



# Generated at 2022-06-21 09:53:23.112935
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # checking the reserved names without private names
    assert '__ansible_module__' not in get_reserved_names(include_private=False)
    assert 'serial' not in get_reserved_names(include_private=False)
    assert 'serial' in get_reserved_names(include_private=True)
    assert 'tags' in get_reserved_names(include_private=True)
    assert 'when' in get_reserved_names(include_private=True)
    assert 'role_name' in get_reserved_names(include_private=True)
    assert 'action' in get_reserved_names(include_private=True)
    assert 'local_action' in get_reserved_names(include_private=True)

# Generated at 2022-06-21 09:53:25.638093
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = {'hosts': 'localhost', 'gather_facts': 'no', 'tasks': [], 'roles': []}
    warn_if_reserved(vars)
    assert True

# Generated at 2022-06-21 09:53:29.678516
# Unit test for function is_reserved_name
def test_is_reserved_name():
    '''
    Ensure all public and private attributes of a Task are reserved.
    '''
    task = Task()
    for aname in task._attributes:
        if 'vars.' not in aname:
            assert is_reserved_name(aname)
    assert is_reserved_name('vars.')



# Generated at 2022-06-21 09:53:36.013161
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # common expected return
    assert _RESERVED_NAMES
    assert len(_RESERVED_NAMES) > 10

    # test filter with private and public
    test_reserved_names_with_private = get_reserved_names()
    assert _RESERVED_NAMES == test_reserved_names_with_private

    # test filter only public
    test_reserved_names_without_private = get_reserved_names(include_private=False)
    assert len(_RESERVED_NAMES) > len(test_reserved_names_without_private)

# Generated at 2022-06-21 09:53:39.643418
# Unit test for function is_reserved_name
def test_is_reserved_name():
    test_cases = [
        ('hosts', True),
        ('any_value', False),
        ('gather_facts', True),
        ('inventories', True),
        ('vars', False)
    ]
    for (name, result) in test_cases:
        assert is_reserved_name(name) == result

# Generated at 2022-06-21 09:53:49.841505
# Unit test for function get_reserved_names
def test_get_reserved_names():

    public  = {'gather_facts', 'vars_files', 'include', 'include_vars',
              'role_paths', 'roles', 'tasks', 'name', 'delegate_to', 'handlers',
              'pre_tasks', 'post_tasks', 'tags', 'any_errors_fatal', 'max_fail_percentage',
              'serial', 'vars_prompt', 'action', 'local_action', 'with_'}

    private = {'include_role', 'include_tasks', 'include_vars', 'role_names', 'block',
               'task', 'handler', 'loop', 'register'}

    all_names = public.union(private)

    assert _RESERVED_NAMES == all_names

# Generated at 2022-06-21 09:56:06.379088
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name("hosts"))


# Generated at 2022-06-21 09:56:10.255411
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['reserved_name']) == None
    assert warn_if_reserved(['not_reserved']) == None
    assert warn_if_reserved(['not_reserved'], additional=['new_reserved']) == None

# Generated at 2022-06-21 09:56:12.623623
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles') == True
    assert is_reserved_name('this_is_not_reserved_name') == False


# Generated at 2022-06-21 09:56:20.943470
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('with_fileglob')
    assert is_reserved_name('with_seq')
    assert is_reserved_name('include')
    assert is_reserved_name('include_role')
    assert is_reserved_name('register')
    assert is_reserved_name('ignore_errors')
    assert is_reserved_name('vars')

    assert not is_reserved_name('my_play')

# Generated at 2022-06-21 09:56:24.960999
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)

    reserved = get_reserved_names(include_private=False)
    assert isinstance(reserved, set)

    assert len(get_reserved_names()) == len(get_reserved_names(include_private=False))

# Generated at 2022-06-21 09:56:29.228330
# Unit test for function is_reserved_name
def test_is_reserved_name():

    result = _RESERVED_NAMES
    assert isinstance(result, frozenset)

    assert is_reserved_name('foo') is False
    assert is_reserved_name('roles') is True
    assert is_reserved_name('variable_start') is True



# Generated at 2022-06-21 09:56:31.858251
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars_dict = {"hosts": "myhosts", "gather_facts": "yes"}
    warn_if_reserved(vars_dict)



# Generated at 2022-06-21 09:56:33.915891
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts', 'vars'})
    warn_if_reserved({'tasks'})

# Generated at 2022-06-21 09:56:40.585080
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    p = Play()
    r = Role()
    b = Block()
    t = Task()
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)
    assert public == set(p._attributes).union(r._attributes).union(b._attributes).union(t._attributes).difference(set(p._private_attributes))
    assert private == set(p._attributes).union(r._attributes).union(b._attributes).union(t._attributes)

# Generated at 2022-06-21 09:56:49.553840
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from six import iteritems
    from ansible.playbook import Playbook
    from ansible.utils import plugin_docs

    test_doc = plugin_docs.get_docstring('plays', Playbook)
    assert test_doc is not None
    assert isinstance(test_doc, dict)

    assert 'short_description' in test_doc
    assert 'description' in test_doc

    assert 'options' in test_doc
    assert test_doc['options'] is not None
    assert isinstance(test_doc['options'], dict)

    # check the option names in the documentation against the set of reserved names
    for name, value in iteritems(test_doc['options']):
        assert is_reserved_name(name) is False