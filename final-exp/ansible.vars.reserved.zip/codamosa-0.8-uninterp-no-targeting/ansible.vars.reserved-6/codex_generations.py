

# Generated at 2022-06-21 09:48:21.946816
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'ansible_user': 'myuser'})
    warn_if_reserved({'vars': 'something'})
    warn_if_reserved({'vars': {'ansible_user': 'myuser'}})

# Generated at 2022-06-21 09:48:32.516824
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    from ansible.playbook.base import Base

    class TestClass(Base):
        def __init__(self):
            super(TestClass, self).__init__()
            self._attributes['foobar'] = None
            self._attributes['name'] = None
            self._attributes['action'] = None
            self._attributes['loop'] = None

    testclass = TestClass()
    testvars = {'foobar': 'foo', 'name': 'bar', 'action': 'baz', 'loop': 'qux'}

    # fake display
    class FakeDisplay(Display):
        def __init__(self):
            super(FakeDisplay, self).__init__()
            self._warnings = []


# Generated at 2022-06-21 09:48:34.366528
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['hosts', 'action', 'vars']) == None

# Generated at 2022-06-21 09:48:38.530763
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # when get_reserved_names called it should return a list of variables
    # that are reserved by play and task objects
    result = get_reserved_names(True)
    assert len(result) > 0
    assert isinstance(result, set)

    # when called with include_private set to False it should return a list
    # of variables that are reserved by play and task objects that do not have
    # the attributes private set to True
    result = get_reserved_names(False)
    assert len(result) > 0
    assert isinstance(result, set)



# Generated at 2022-06-21 09:48:45.602770
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:48:47.731320
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('boom')

# Generated at 2022-06-21 09:48:58.119275
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''this function tests the list of reserved variable names associated with play objects'''


# Generated at 2022-06-21 09:49:05.882571
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts") is True
    assert is_reserved_name("vars") is True
    assert is_reserved_name("vars_prompt") is True
    assert is_reserved_name("vars_files") is True
    assert is_reserved_name("tasks") is True
    assert is_reserved_name("tags") is True
    assert is_reserved_name("pre_tasks") is True
    assert is_reserved_name("post_tasks") is True
    assert is_reserved_name("any_errors_fatal") is True
    assert is_reserved_name("max_fail_percentage") is True
    assert is_reserved_name("serial") is True
    assert is_reserved_name("remote_user") is True

# Generated at 2022-06-21 09:49:08.043355
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Do this to make sure we have at least one test.
    assert get_reserved_names()

# Generated at 2022-06-21 09:49:16.753807
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:49:42.130652
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=False)
    assert 'remote_user' in reserved
    assert 'name' in reserved
    assert 'any_errors_fatal' in reserved
    assert 'hosts' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved

    reserved = get_reserved_names(include_private=True)
    assert 'register' in reserved
    assert 'async' in reserved
    assert 'run_once' in reserved
    assert 'loop_control' in reserved
    assert 'loop' in reserved


    # test equivalence of deprecated 'with_' and 'loop'
    assert 'with_' in reserved
    assert 'loop' in reserved



# Generated at 2022-06-21 09:49:51.988205
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:49:56.074658
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Ensure there is a conflict. We could check them one by one, but explicit
    # is better than implicit
    assert is_reserved_name('action') == True
    # Ensure there is no conflict
    assert is_reserved_name('some_name') == False

# Generated at 2022-06-21 09:50:07.743184
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    result = warn_if_reserved(['vars', 'action', 'delegate_to'])
    assert result is None
    result = warn_if_reserved(['vars', 'action', 'delegate_to', 'notification'])
    assert result is None
    result = warn_if_reserved(['vars', 'action', 'delegate_to', 'notification',
                               'any_errors_fatal'])
    assert result is None
    result = warn_if_reserved(['vars', 'action', 'delegate_to', 'notification',
                               'any_errors_fatal', 'with_'])
    assert result is None

# Generated at 2022-06-21 09:50:10.831534
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    vars_list = ['name', 'action', 'become_user', 'register', 'roles', 'tasks', 'vars', 'with_items']
    warn_if_reserved(vars_list)

# Generated at 2022-06-21 09:50:14.626014
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, set)
    assert ('playbook' in _RESERVED_NAMES)
    assert ('vars' in _RESERVED_NAMES)

# Generated at 2022-06-21 09:50:17.324017
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'action': 'somedata', 'foobar': 'somedata'}) is None


# Generated at 2022-06-21 09:50:19.290413
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars') == False
    assert is_reserved_name('delegate_to') == True


# Generated at 2022-06-21 09:50:20.862112
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert not is_reserved_name('other')

# Generated at 2022-06-21 09:50:30.967641
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Test Reserved names
    result_reserved = get_reserved_names()
    assert 'any_errors_fatal' in result_reserved, "any_errors_fatal should be in reserved, got: %s" % result_reserved
    assert 'block' in result_reserved, "block should be in reserved, got: %s" % result_reserved
    assert 'connection' in result_reserved, "connection should be in reserved, got: %s" % result_reserved
    assert 'delegate_to' in result_reserved, "delegate_to should be in reserved, got: %s" % result_reserved
    assert 'environment' in result_reserved, "environment should be in reserved, got: %s" % result_reserved

# Generated at 2022-06-21 09:50:54.897976
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' warns if any variable passed conflicts with internally reserved names '''
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'inventory_hostname' in reserved

    myvars = {'name': 'myhostname', 'action': 'ping', 'local_action': 'ping', 'inventory_hostname': 'myhostname'}
    warn_if_reserved(myvars)

# Generated at 2022-06-21 09:51:03.769261
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['post_tasks', 'tags', 'with_', 'pre_tasks', 'when', 'hosts', 'vars', 'become', 'local_action', 'become_user', 'serial', 'connection', 'transport', 'user', 'action', 'name', 'include_tasks'])
    assert get_reserved_names(include_private=False) == frozenset(['tags', 'with_', 'when', 'hosts', 'vars', 'become', 'local_action', 'become_user', 'serial', 'connection', 'transport', 'user', 'action', 'name', 'include_tasks'])

# Generated at 2022-06-21 09:51:11.880123
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('hosts')
    assert is_reserved_name('include')
    assert is_reserved_name('connection')
    assert is_reserved_name('sudo')
    assert is_reserved_name('sudo_user')
    assert is_reserved_name('environment')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('serial')
    assert is_reserved_name('async')
    assert is_reserved_name('poll')
    assert is_res

# Generated at 2022-06-21 09:51:20.660271
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' make sure we are getting an appropriate list of reserved names for objects '''

    names = get_reserved_names()
    assert 'name' in names
    assert 'action' in names
    assert 'local_action' in names
    assert 'serial' in names
    assert 'become' in names
    assert 'become_user' in names
    assert 'async' in names
    assert 'tags' in names
    assert 'run_once' in names
    assert 'failed_when' in names
    assert 'when' in names
    assert 'notify' in names
    assert 'register' in names
    assert 'delegate_to' in names
    assert '__undefined__' not in names  # this one is not a real attr

    names = get_reserved_names(False)

# Generated at 2022-06-21 09:51:30.398672
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    import io
    import pytest
    saved_stdout = sys.stdout

    try:
        myvars = dict(tags=['a', 'b'], roles=[])
        out = io.StringIO()
        sys.stdout = out
        warn_if_reserved(myvars, additional=set(['tags', 'roles']))
        output = out.getvalue().strip()
        assert "Found variable using reserved name: tags" in output
        assert "Found variable using reserved name: roles" in output
        out.close()
    finally:
        sys.stdout = saved_stdout


# Generated at 2022-06-21 09:51:38.301071
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:51:46.269157
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:51:48.593727
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible import constants as C

    warn_if_reserved(myvars=dict(deprecated_key="value"))
    assert "deprecated_key" in C.DEPRECATED_PLAYBOOK_KEYS

    display.deprecated = dict()
    display.deprecated_war

# Generated at 2022-06-21 09:51:51.566449
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('foobar')
    assert not is_reserved_name('failed_when')
    assert not is_reserved_name('become')



# Generated at 2022-06-21 09:52:01.086574
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.base import Base
    received = Base.warn_if_reserved(['action', 'strategy'], ['action', 'strategy', 'other'])
    expected = None
    assert received == expected

    received = Base.warn_if_reserved(['action', 'strategy'])
    expected = None
    assert received == expected

    received = Base.warn_if_reserved(['action', 'strategy', 'other'])
    expected = None
    assert received == expected

    received = Base.warn_if_reserved(['action', 'strategy', 'other'], ['other'])
    expected = None
    assert received == expected

    received = Base.warn_if_reserved(['action', 'strategy', 'other'], ['other', 'some'])
    expected = None

# Generated at 2022-06-21 09:53:04.693677
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private = get_reserved_names(include_private=True)
    public = get_reserved_names(include_private=False)

    assert 'name' in private
    assert 'name' in public
    assert 'hosts' in private
    assert 'hosts' in public
    assert 'roles' in private
    assert 'roles' in public
    assert 'tasks' in private
    assert 'tasks' in public
    assert 'include_role' not in private
    assert 'include_role' in public

    # FIXME: remove after with_ is not only deprecated but removed
    assert 'loop' in private
    assert 'loop' in public
    assert 'with_' in private
    assert 'with_' in public

    # local_action is implicit with action
    assert 'action' in private

# Generated at 2022-06-21 09:53:09.550532
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' get_reserved_names returns the list of reserved names '''
    reserved_names = get_reserved_names()
    assert ('hosts' in reserved_names)
    assert ('hosts' not in get_reserved_names(include_private=False))
    assert ('roles' in reserved_names)
    assert ('roles' not in get_reserved_names(include_private=False))



# Generated at 2022-06-21 09:53:11.003280
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts', 'skipped', 'hello', 'vault_password'])

# Generated at 2022-06-21 09:53:12.394415
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')

# Unit tests for function warn_if_reserved

# Generated at 2022-06-21 09:53:15.640317
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('with_items')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:53:16.663616
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')

# Generated at 2022-06-21 09:53:19.112804
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = _RESERVED_NAMES
    assert 'port' not in reserved
    assert 'name' in reserved
    assert 'local_action' in reserved

# Generated at 2022-06-21 09:53:27.230099
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()

    # FIXME: find a way to 'not hardcode'
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    if 'loop' in private or 'loop' in public:
        public.add('with_')

    # remove v

# Generated at 2022-06-21 09:53:31.148549
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    # test the defaults
    assert (len(reserved) > 0)
    assert ('vars' in reserved)

    # test reserved names
    assert (is_reserved_name('vars'))
    assert (not is_reserved_name('var'))

# Generated at 2022-06-21 09:53:35.422565
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names function '''

    # Test both cases: include private and exclude private
    for param in [True, False]:
        result = get_reserved_names(param)
        assert type(result) is set, "get_reserved_names should return a set"
        assert len(result) > 0, "get_reserved_names should return non empty set"

# Generated at 2022-06-21 09:54:31.388803
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    _display = Display()

    # Mock out display.warning
    _display.warning = lambda x: x


# Generated at 2022-06-21 09:54:38.043971
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('vars')
    assert not is_reserved_name('boom')
    assert not is_reserved_name('when')
    assert not is_reserved_name('tags')
    assert not is_reserved_name('name')
    assert not is_reserved_name('action')
    assert not is_reserved_name('local_action')

# Generated at 2022-06-21 09:54:40.041072
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)

# Generated at 2022-06-21 09:54:47.324941
# Unit test for function get_reserved_names
def test_get_reserved_names():
    play_vars = get_reserved_names(False)
    assert 'vars' in play_vars
    assert 'prompt' not in play_vars
    assert 'private' not in play_vars
    assert 'tasks' in play_vars
    assert 'hosts' in play_vars
    assert 'name' in play_vars
    assert 'connection' in play_vars

    play_vars = get_reserved_names(True)
    assert 'private' in play_vars
    assert 'vars' in play_vars
    assert 'prompt' in play_vars
    assert 'tasks' in play_vars
    assert 'hosts' in play_vars
    assert 'name' in play_vars
    assert 'connection' in play_vars


# Unit

# Generated at 2022-06-21 09:54:51.237589
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'hosts' in names
    assert 'roles' in names
    assert 'block' in names
    assert 'action' in names
    assert 'register' in names
    assert 'name' in names
    assert 'connection' in names
    assert 'delegate_to' in names
    assert 'local_action' in names
    assert 'with_' in names
    assert 'loop' in names

# Generated at 2022-06-21 09:54:55.310526
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Some of the reserved names are private names that are not returned
    # by default.  These are checked separately (in test_get_private).
    public = set(get_reserved_names())
    assert public.issuperset('name host hosts connection gather_facts delegate_to become become_method become_user become_flags' .split())



# Generated at 2022-06-21 09:55:02.339114
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class Test_warn_if_reserved:
        def __init__(self, namespace):
            self.namespace = namespace
            self.failed = False

        def assertEqual(self, s1, s2):

            if s1 == s2:
                return

            display.error("expected %s, got %s" % (s1, s2))
            self.failed = True

        def assertTrue(self, val):

            if val:
                return

            display.error("expected value is True, got False")
            self.failed = True

    # Create a test object, and add it to the module namespace
    namespace = {}
    test_object = Test_warn_if_reserved(namespace)
    namespace['test_object'] = test_object

    # test if warn_if_reserved gives a warning for reserved names

# Generated at 2022-06-21 09:55:06.459165
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert_true(is_reserved_name('action'))
    assert_true(is_reserved_name('private'))
    assert_false(is_reserved_name('python vars'))
    assert_false(is_reserved_name('asdf'))


# Generated at 2022-06-21 09:55:09.936241
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('serial')
    assert is_reserved_name('localhost')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('notify')

# Generated at 2022-06-21 09:55:16.861650
# Unit test for function is_reserved_name
def test_is_reserved_name():
    '''
    this tests the is_reserved_name function
    '''

    assert is_reserved_name('action')
    assert is_reserved_name('name')
    assert is_reserved_name('pause')
    assert is_reserved_name('with_')

    assert not is_reserved_name('foo')
    assert not is_reserved_name('var')
    assert not is_reserved_name('namevar')


# Generated at 2022-06-21 09:56:24.014198
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved = set([
        'playbook_dir',
        'play_hosts',
        'play_name',
        'task_vars',
        'role_name',
        'include',
        'tags',
        'action',
        'register',
        'ignore_errors',
        'become',
        'become_method',
        'become_user',
        'block_name',
        'when',
        'local_action',
        'with_'
    ])
    for name in reserved:
        assert is_reserved_name(name) is True
    for name in ('vars', 'roles'):
        assert is_reserved_name(name) is False



# Generated at 2022-06-21 09:56:27.704788
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Check warn_if_reserved() with empty variable name, undefined variable,
    # and reserved variable name.
    assert not warn_if_reserved(['name'])


if __name__ == '__main__':
    test_warn_if_reserved()

# Generated at 2022-06-21 09:56:34.743732
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'name': 'hack1'})
    warn_if_reserved({'connection': 'hack'})
    warn_if_reserved({'hosts': 'hack'})
    warn_if_reserved({'post_tasks': 'hack'})
    warn_if_reserved({'pre_tasks': 'hack'})
    warn_if_reserved({'role_path': 'hack'})
    warn_if_reserved({'vars': 'hack'})
    warn_if_reserved({'vars_files': 'hack'})

# Generated at 2022-06-21 09:56:41.112179
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # No warnings should be shown for any of the three lists
    no_warn = [
        ['hosts', 'name', 'action', 'shell', 'args'],
        ['hosts', 'name', 'action', 'apt', 'name'],
        ['hosts', 'name', 'action', 'apt', 'state'],
    ]
    for list in no_warn:
        with Display().redirected(out=True, err=True, quiet=True) as disp:
            warn_if_reserved(list, additional={"hosts", "name", "action"})
            assert disp.out.strip() == ''

    # Warnings should be shown for all of the three lists

# Generated at 2022-06-21 09:56:41.920510
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # FIXME: add tests here
    pass

# Generated at 2022-06-21 09:56:49.302138
# Unit test for function is_reserved_name
def test_is_reserved_name():
    res = get_reserved_names(include_private=False)
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('any_errors_fatal')
    assert not is_reserved_name('with_')
    assert not is_reserved_name('loop')
    assert not is_reserved_name('action')
    assert not is_reserved_name('no_log')
    assert not is_reserved_name('private')
    assert not is_reserved_name('local_action')

# Generated at 2022-06-21 09:56:51.185058
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-21 09:56:59.808023
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import pytest
    assert get_reserved_names() == _RESERVED_NAMES

    # no private reserved names
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(set(['_role_name', '_role_path']))

    # _role_name, _role_path are private for Role object
    assert '_role_name' in _RESERVED_NAMES and '_role_path' in _RESERVED_NAMES
    assert '_role_name' in get_reserved_names() and '_role_path' in get_reserved_names()

# Generated at 2022-06-21 09:57:01.211720
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pass
    # FIXME

# Generated at 2022-06-21 09:57:07.736811
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # simple default test
    assert is_reserved_name("action") is True
    assert is_reserved_name("local_action") is False
    assert is_reserved_name("with_items") is True
    assert is_reserved_name("with_facts") is True
    assert is_reserved_name("become") is True
    assert is_reserved_name("become_user") is False
    assert is_reserved_name("become_method") is False