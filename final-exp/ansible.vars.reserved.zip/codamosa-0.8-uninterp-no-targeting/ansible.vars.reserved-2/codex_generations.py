

# Generated at 2022-06-21 09:48:29.804520
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import ast
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.action import ActionBase

    add_var = {'_raw_params': 'not used by this plugin'}
    playcontext = PlayContext()
    action = ActionBase()

    # unit test setup
    playcontext.vars = set()
    action._task.vars = set()
    action._task.action = 'not used by this plugin'

    # positive test case
    varnames = ['vars', 'action', 'loop']

    playcontext.vars = playcontext.vars.union(varnames)
    action._task.vars = action._task.vars.union(varnames)
    action._task.action = '{{ action }}'

    ast.parse(action._task.action)
    ast

# Generated at 2022-06-21 09:48:32.665583
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('async') is True
    assert is_reserved_name('with_items') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('foo_bar') is False

# Generated at 2022-06-21 09:48:35.763333
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('action'))
    assert(is_reserved_name('local_action'))
    assert(is_reserved_name('with_'))
    assert(is_reserved_name('loop'))
    assert(not is_reserved_name('does_not_exist'))



# Generated at 2022-06-21 09:48:40.618934
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 2

    fail = True
    try:
        warn_if_reserved({'action': 'foo'})
    except AssertionError:
        fail = False

    assert fail == False


# Generated at 2022-06-21 09:48:42.994497
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' test if reserved names are detected correctly '''
    assert is_reserved_name('action')
    assert is_reserved_name('with_items')
    assert not is_reserved_name('local_action')
    assert not is_reserved_name('with_')

# Generated at 2022-06-21 09:48:54.343586
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this function tests the warn_if_reserved function '''

    assert display._deprecation == 0

    # confirm that warning is emitted for all reserved names
    for reserved_name in _RESERVED_NAMES:
        warn_if_reserved(dict(myvar="var1", another="var2", var3="myvar", var=dict(var1=1, var2=2, var3=3),
                              play_hosts="all", var4="task", var5="var4"))
        assert display._deprecation == 1

    # confirm that warning is not emitted for non-reserved names

# Generated at 2022-06-21 09:48:58.761622
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('with_items')
    assert is_reserved_name('pre_tasks')
    assert not is_reserved_name('foobar')
    assert not is_reserved_name('include')
    assert not is_reserved_name('include_vars')

# Generated at 2022-06-21 09:49:01.760803
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for get_reserved_names '''

    assert 'hosts' in get_reserved_names()
    assert not 'hosts' in get_reserved_names(include_private=False)



# Generated at 2022-06-21 09:49:07.815792
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test that we warn on reserved names '''

    from ansible.module_utils.six import StringIO

    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common._collections_compat import Sequence

    m = basic.AnsibleModule
    m.basic._ANSIBLE_ARGS = {'argument_spec': {'reserved_name': dict(required=True)}}

    module = None
    setattr(m, '_load_params', lambda: None)
    setattr(m, 'run_command', lambda x, environ_update, check_rc=True: (0, '', ''))
    setattr(m, 'add_cleanup_file', lambda x: None)

# Generated at 2022-06-21 09:49:12.956198
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=True)
    public = get_reserved_names(include_private=False)

    assert type(reserved) is frozenset
    assert type(public) is frozenset

    assert 'any_errors_fatal' in reserved
    assert 'any_errors_fatal' in public

    assert 'private' in reserved
    assert 'private' not in public

# Generated at 2022-06-21 09:49:44.129132
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'name', 'remote_user'])

# Generated at 2022-06-21 09:49:53.417912
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test that warnning is not emitted for non-reserved names
    import StringIO
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.display import Display
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    display.verbosity = 1
    myvars = dict(action='foo', register='blarg', when='saturday')
    backup = sys.stdout
    sys.stdout = StringIO.StringIO()
    try:
        warn_if_reserved(myvars)
    except AnsibleParserError:
        raise
    finally:
        sys.stdout = backup

    assert sys.stdout.getvalue() == ''

    # Test that warning is emitted for reserved names
    my

# Generated at 2022-06-21 09:49:55.485059
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    additional = ['foo']
    warn_if_reserved(['foo', 'vars'], additional)

# Generated at 2022-06-21 09:50:06.866476
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:50:08.468886
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['fail'])


# Generated at 2022-06-21 09:50:18.652661
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names() == get_reserved_names(include_private=True))
    assert(len(get_reserved_names()) == 15)
    assert('vars' in get_reserved_names())
    assert('when' in get_reserved_names())
    assert('delegate_to' in get_reserved_names())
    assert('with_' in get_reserved_names())
    assert('private' not in get_reserved_names())
    assert(len(get_reserved_names(False)) == 11)
    assert('private' not in get_reserved_names(False))
    assert('private' in get_reserved_names(True))


# Generated at 2022-06-21 09:50:22.055999
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names()

    mean = (len(reserved) + 3) // 2
    list_of_vars = list(reserved)
    list_of_vars.extend(['foo', 'bar', 'baz'])

    # Check that warning is produced if any of the reserved names are used
    for i in range(len(reserved)):
        myvars = set(list_of_vars[:i])
        try:
            warn_if_reserved(myvars)
        except:
            display.warning('warn_if_reserved failed when it should have passed')

    # Check that warning is produced if the given names include any of the reserved names

# Generated at 2022-06-21 09:50:29.937766
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class FakeDisplay(object):
        def __init__(self):
            self.warning = None

        def display(self, msg='', log_only=None, color=None, stderr=False, screen_only=False, runner_warnings=False,
                    fatal=False, redirect_stderr=True):
            self.warning = msg
    from ansible.playbook.play import warn_if_reserved
    fake_display = FakeDisplay()
    Display.display = fake_display.display
    warn_if_reserved(["name"])
    assert fake_display.warning is not None

# Generated at 2022-06-21 09:50:33.057750
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert not is_reserved_name("not_a_reserved_name")
    assert is_reserved_name("tags")

# Generated at 2022-06-21 09:50:39.028655
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import json

    # verify function returns list
    assert isinstance(get_reserved_names(), set)

    # we print our list as JSON and compare to a known value

# Generated at 2022-06-21 09:51:29.622061
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES
    assert 'task' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'vars' in _RESERVED_NAMES
    assert 'when' in _RESERVED_NAMES
    assert 'register' in _RESERVED_NAMES
    assert 'notify' in _RESERVED_NAMES
    assert 'always_run' in _RESERVED_NAMES
    assert 'with_' in _RESERVED

# Generated at 2022-06-21 09:51:36.993766
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import mock
    import io

    captured_output = io.StringIO()

    # Mock out stdout
    with mock.patch('ansible.utils.display.Display.display') as mock_display:
        mock_display.return_value = captured_output
        warn_if_reserved(['test'])
    assert captured_output.getvalue() == ""

    captured_output = io.StringIO()

    # Mock out stdout
    with mock.patch('ansible.utils.display.Display.display') as mock_display:
        mock_display.return_value = captured_output
        warn_if_reserved(['tasks'])
    assert captured_output.getvalue().startswith("Found variable using reserved name: tasks")

    from ansible.constants import DEFAULT_HANDLER_TASK_NAME
   

# Generated at 2022-06-21 09:51:38.953093
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['hosts', 'roles', 'action']
    warn_if_reserved(myvars)

# Generated at 2022-06-21 09:51:43.952234
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    display.verbosity = 2
    display.deprecated = 0
    display.failed = False
    display.warned = False

    warn_if_reserved(['privilege', 'name'])
    assert display.warned

    display.verbosity = 0
    display.deprecated = 0
    display.failed = False
    display.warned = False

    warn_if_reserved(['privilege', 'name'])
    assert not display.warned

# Generated at 2022-06-21 09:51:45.536385
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('not_a_reserved_name')

# Generated at 2022-06-21 09:51:51.869973
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # We don't care if warnings were already or already not caught.
    import warnings
    if hasattr(warnings, 'catch_warnings'):
        if not hasattr(warnings, 'onceregistry'):
            # Python 3.3
            warnings._onceregistry.clear()
        else:
            warnings.resetwarnings()

    # And also don't care about what display.warning() does.
    from ansible.utils.display import Display
    Display.display = Display.warning = Display.deprecated = lambda self, msg: None

    warn_if_reserved(["action"])
    warn_if_reserved(["local_action"])
    warn_if_reserved(["loop"])
    warn_if_reserved(["with_"])
    warn_if_reserved(["not_reserved"])

# Generated at 2022-06-21 09:51:53.888108
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(["any_key", "action", "hosts", "with_items"])



# Generated at 2022-06-21 09:52:03.949960
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:52:10.090404
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'ignore_errors' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()


# Generated at 2022-06-21 09:52:20.379012
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test Reserved names
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('roles') == True
    assert is_reserved_name('tasks') == True
    assert is_reserved_name('name') == True

    # Test Non-Reserved names
    assert is_reserved_name('my_name') == False
    assert is_reserved_name('myplay') == False
    assert is_reserved_name('myrole') == False
    assert is_reserved_name('myblock') == False
    assert is_reserved_name('mytask') == False

    # Test Private Reserved names
    assert is_reserved_name('action') == True
    assert is_reserved_name('include_role') == True

# Generated at 2022-06-21 09:53:15.112313
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warnings = [
        'Found variable using reserved name: name',
        'Found variable using reserved name: delegate_to',
    ]

    # Since we don't have the real display object, this will raise an exception if warn_if_reserved tries to use it
    display.warning = None

    try:
        warn_if_reserved({
            'name': 'should yield a warning',
            'delegate_to': 'should yield a warning',
            'nope': 'should not yield a warning',
        })
    except Exception as ex:
        if str(ex) in warnings:
            warnings.remove(str(ex))
        else:
            assert False, 'Unexpected warning: %s' % ex

    assert len(warnings) == 0

# Generated at 2022-06-21 09:53:18.374021
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names()
    assert len(reserved) > 10, reserved
    assert 'action' in reserved, reserved
    assert 'loop' in reserved, reserved



# Generated at 2022-06-21 09:53:26.785608
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('some action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('become')
    assert is_reserved_name('become_user')
    assert is_reserved_name('become_method')
    assert is_reserved_name('become_flags')
    assert is_reserved_name('connection')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('environment')
    assert is_reserved_name('ignore_errors')
    assert is_reserved_name('name')
    assert is_reserved_name('register')
    assert is_reserved_

# Generated at 2022-06-21 09:53:35.721527
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' unit tests to cover the function warn_if_reserved '''
    try:
        # this will raise a deprecation warning because 'with_' is deprecated
        warn_if_reserved({'with_': 'someone'}, ['with_'])
    except DeprecationWarning:
        pass

    assert(warn_if_reserved({'action': 'someone'}) == None)
    assert(warn_if_reserved({'tasks': 'someone'}) == None)
    assert(warn_if_reserved({'roles': 'someone'}) == None)
    assert(warn_if_reserved({'pre_tasks': 'someone'}) == None)
    assert(warn_if_reserved({'post_tasks': 'someone'}) == None)

# Generated at 2022-06-21 09:53:45.615801
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # pylint: disable=redefined-outer-name
    # pylint: disable=import-error,no-name-in-module
    # pylint: disable=missing-docstring
    from ansible.plugins import game_console
    from ansible.plugins.loader import load_callback_plugins

    load_callback_plugins()
    display.verbosity = 5
    display.deprecated = True
    display.deprecate_commit = False

    class FakeVarsModule(object):
        def __init__(self, name, age, p1):
            self.name = name
            self.age = age
            self.p1 = p1

    vars_module = FakeVarsModule('alice', 25, 'play1')
    vars_module.myvar = 'myvar'
    warn_if_res

# Generated at 2022-06-21 09:53:53.192629
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:53:59.515157
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import ansible.playbook.deprecated
    warnings = []
    myvars = ['inventory', 'action', 'local_action', 'with_', 'loop', 'tasks', 'vars']

    old_display = Display()
    Display.warning = lambda *args, **kwargs: warnings.append(args[0])
    ansible.playbook.deprecated.warn_if_reserved(myvars)
    Display.warning = old_display.warning

    assert len(warnings) == 7

# Generated at 2022-06-21 09:54:04.199574
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_vars = {
        'hosts': 'foo',
        'gather_facts': False,
        'vars': [],
    }

    # Make sure no warnings are thrown when hosts is passed in.
    warn_if_reserved(test_vars)

    # Make sure a warning is thrown when the gather_facts key is used.
    try:
        warn_if_reserved(test_vars, { 'gather_facts' })
        assert False, 'Warning should have been thrown when gather_facts is used.'
    except SystemExit:
        pass

# Generated at 2022-06-21 09:54:13.340220
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    class TestPlaybookReservedNames(unittest.TestCase):

        def test_warn_if_reserved(self):
            reserved_names = get_reserved_names()
            reserved_names.add('this_is_custom_name')

            # set to warn on reserved names
            display.verbosity = 2

            # create a list of reserved names
            test_reserved_vars = ['foo', 'random_name', 'this_is_custom_name']
            play_obj = Play()
            block_

# Generated at 2022-06-21 09:54:22.393910
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()


# Generated at 2022-06-21 09:56:25.656333
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars1 = {"vars": "test", "name": "test", "foo": "bar", "action": "test" }
    vars2 = {"vars": "test", "name": "test", "foo": "bar", "action": "test", "other": "test" }
    warn_if_reserved(vars1, additional=["other"])
    warn_if_reserved(vars2)

# Generated at 2022-06-21 09:56:30.518194
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = _RESERVED_NAMES
    non_reserved_names = ('foo', 'foo_bar', 'bar', 'bar_foo')

    for name in reserved_names:
        assert is_reserved_name(name)

    for name in non_reserved_names:
        assert not is_reserved_name(name)

# Generated at 2022-06-21 09:56:33.994795
# Unit test for function is_reserved_name
def test_is_reserved_name():
    '''Unit test for function is_reserved_name'''
    assert is_reserved_name('action')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('not_a_reserved_name')


# Generated at 2022-06-21 09:56:37.525796
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_items')
    assert is_reserved_name('become')
    assert not is_reserved_name('shell')
    assert not is_reserved_name('myvar')

# Generated at 2022-06-21 09:56:43.354807
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('connection')

    # Make sure loop is considered reserved (even though it is deprecated) because
    # of its historical use.
    assert is_reserved_name('loop')

    # Make sure the implicit alternate for loop is considered reserved for the same reason
    assert is_reserved_name('with_')

    # Make sure the implicit alternate for action is considered reserved for the same reason
    assert is_reserved_name('local_action')

# Generated at 2022-06-21 09:56:52.843465
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:56:56.035564
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('private')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-21 09:57:02.365502
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'hosts' in get_reserved_names()
    assert 'hosts' in get_reserved_names(include_private=False)

    assert 'any_errors_fatal' in get_reserved_names(include_private=False)
    assert 'any_errors_fatal' in get_reserved_names()

    assert 'name' in get_reserved_names()
    assert 'name' in get_reserved_names(include_private=False)

    assert 'gather_facts' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names(include_private=False)

    assert 'roles' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names()

    assert 'tags' in get_res

# Generated at 2022-06-21 09:57:11.590546
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('private')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('register')
    assert is_reserved_name('name')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('connection')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('environment')
    assert is_reserved_name('with_items')
    assert is_reserved_name('tags')
    assert not is_reserved_name('ansible_ssh_host')
    assert not is_reserved_name('ansible_ssh_port')

# Generated at 2022-06-21 09:57:14.173976
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test_warn_if_reserved '''

    # FIXME: find a way to unit test this.  This module actually has less test coverage than we'd like
    pass