

# Generated at 2022-06-21 09:48:26.479739
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('connection')
    assert is_reserved_name('roles')
    assert is_reserved_name('name')
    assert not is_reserved_name('not_reserved')

#
# REMOVED:  `include` is not special anymore, see PR #17789
#
# # This is a special magic role name which is used as an include.  You cannot have
# # a role with this name.  The parser uses this to decide to treat this as an include rather
# # than a role call.
#
# if not C.DEFAULT_PRIVATE_ROLE_VARS:
#     _RESERVED_NAMES = _RESERVED_NAMES.union({'include'})
#

# Generated at 2022-06-21 09:48:35.040614
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Shouldn't break
    warn_if_reserved({u'vars': {u'foo': 1}})
    warn_if_reserved({u'vars': {u'foo': 1}}, additional={u'foo'})
    warn_if_reserved({u'vars': {u'foo': 1}, u'vars_prompt': {u'foo': 1}})
    warn_if_reserved({u'foo': 1})
    warn_if_reserved({u'foo': 1, u'bar': 1})
    warn_if_reserved({u'foo': 1, u'bar': 1}, additional={u'foo'})

    # Should warn once for all

# Generated at 2022-06-21 09:48:35.844700
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert is_reserved_name('vars')

# Generated at 2022-06-21 09:48:43.080926
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test will fail if this function has issues '''
    assert 'action' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES
    assert 'tags' in _RESERVED_NAMES
    assert 'register' in _RESERVED_NAMES
    assert 'with_' in _RESERVED_NAMES
    assert 'when' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES

    assert 'loop' not in _RESERVED_NAMES

# Generated at 2022-06-21 09:48:52.859186
# Unit test for function get_reserved_names
def test_get_reserved_names():

    test_public = _RESERVED_NAMES.intersection(set(['pre_tasks', 'roles', 'vars_files']))

    assert test_public == set(['pre_tasks', 'roles', 'vars_files']), 'Failed to return the correct values for public reserved names.'

    test_private = _RESERVED_NAMES.intersection(set(['gather_facts', 'register', 'remote_user', 'vars_prompt']))

    assert test_private == set(['gather_facts', 'register', 'remote_user', 'vars_prompt']), 'Failed to return the correct values for private reserved names.'

# Generated at 2022-06-21 09:49:02.151934
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:49:12.317239
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # internal use only
    private_reserved = get_reserved_names()
    public_reserved = get_reserved_names(include_private=False)

    # ensure we are keeping track of the right names
    public_only = public_reserved.difference(private_reserved)
    assert public_only == set(['action', 'local_action', 'with_'])

    # loop implies with_, remove after with_ is not only deprecated but removed
    assert 'with_' in private_reserved
    assert 'loop' in private_reserved

    # ensure reserved names do not change
    assert len(private_reserved) == len(_RESERVED_NAMES)
    assert len(public_reserved) == len(_RESERVED_NAMES) - 3



# Generated at 2022-06-21 09:49:16.084264
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.plugins.action import ActionModule
    warn_if_reserved(['action', 'name', 'failed'])
    warn_if_reserved(['action', 'name', 'failed'], additional=['failed'])
    warn_if_reserved(['action', 'name', 'failed'], additional=set(['failed']))
    warn_if_reserved(['action', 'name', 'failed'], additional=frozenset(['failed']))
    warn_if_reserved(['action', 'name', 'failed'], additional=ActionModule.RESERVED_WORDS)

# Generated at 2022-06-21 09:49:17.880917
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)



# Generated at 2022-06-21 09:49:19.514463
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''Unit test for function get_reserved_names'''
    assert 'name' in get_reserved_names(include_private=True)

# Generated at 2022-06-21 09:49:32.073444
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:49:43.806306
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Test cases for get_reserved_names
    '''

    public = ['name', 'gather_facts', 'hosts', 'remote_user', 'become', 'become_method', 'connection', 'vars', 'tasks']
    private = ['any_errors_fatal', 'max_fail_percentage', 'serial', 'sudo', 'sudo_user', 'transport', 'ignore_errors', 'tags',
               'skip_tags', 'roles', 'import_playbook', 'include', 'deprecate_import']
    # we can't assert the full resultset because its contents may have changed over time
    # instead, we check to see if the superset is the same
    # we do not check for local_action and with_ because we automatically add those
    # FIXME: remove with_ once it is removed from

# Generated at 2022-06-21 09:49:46.176182
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)

# Generated at 2022-06-21 09:49:47.900691
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from collections import Iterable
    assert isinstance(get_reserved_names(), Iterable)



# Generated at 2022-06-21 09:49:51.395488
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' use the reserved names as variables and ensure that it does not warn or throw an error '''
    myvars = ['var_%s' % x for x in _RESERVED_NAMES]
    myvars.append('vars')
    warn_if_reserved(myvars)

# Generated at 2022-06-21 09:49:56.862566
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = set(get_reserved_names())

    # There should be no private names in the public list
    assert not (result.intersection(set(get_reserved_names(include_private=True))) - result)

    # There should be no private names outside of the public list
    assert not (result - set(get_reserved_names(include_private=True)))

# Generated at 2022-06-21 09:50:01.406475
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    myvars = loader.load_from_file('lib/ansible/playbook/tests/test_vars.yml')
    warn_if_reserved(myvars)

# Generated at 2022-06-21 09:50:12.483857
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:50:19.247491
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('name'))
    assert(not is_reserved_name('does_not_exist'))
    assert(is_reserved_name('role_path'))
    assert(is_reserved_name('action'))
    assert(is_reserved_name('local_action'))
    assert(is_reserved_name('loop'))
    assert(is_reserved_name('with_'))

# Generated at 2022-06-21 09:50:29.616656
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import ansible.playbook.task
    with_item = ansible.playbook.task.Task.with_item
    loop_item = ansible.playbook.task.Task.loop_item
    loop = ansible.playbook.task.Task.loop
    assert get_reserved_names(include_private=False) == {'any_errors_fatal', 'become', 'become_method', 'become_user', 'connection', 'delegate_to', 'loop', 'name', 'register', 'remote_user'}
    assert get_reserved_names() == {'any_errors_fatal', 'become', 'become_method', 'become_user', 'connection', 'delegate_to', 'loop', 'loop_item', 'name', 'register', 'remote_user', 'with_item'}


# Generated at 2022-06-21 09:50:39.557691
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = {'hosts': 'localhost'}
    warn_if_reserved(myvars)


# Generated at 2022-06-21 09:50:45.136445
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('any_playbook_attribute')
    assert is_reserved_name('any_block_attribute')
    assert is_reserved_name('any_role_attribute')
    assert is_reserved_name('any_task_attribute')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('this_is_not_a_reserved_name')

# Generated at 2022-06-21 09:50:47.767598
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    varnames = [u'roles', u'with_', u'action', 'loop']
    warn_if_reserved(varnames)

# Generated at 2022-06-21 09:50:58.134717
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    warn_if_reserved(['gather_facts', 'hosts', 'name', 'vars_files', 'vars', 'register', 'roles', 'tasks'])
    warn_if_reserved(['vars_prompt', 'action', 'when', 'local_action', 'block', 'meta', 'include',
                      'include_tasks', 'import_playbook'])
    warn_if_reserved(['play_hosts', 'playbook', 'post_tasks', 'pre_tasks', 'role_name', 'serial', 'strategy'])
    warn_if_reserved(['tags', 'notify', 'handlers', 'tasks_from'])
    # FIXME: remove after with_ is not only deprecated but removed

# Generated at 2022-06-21 09:51:07.982973
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ansible_tests = dict(
        meta=True,
        name=True,
        hosts=True,
        gather_facts=True,
        tasks=True,
        pre_tasks=True,
        roles=True,
        handlers=True,
        post_tasks=True,
        vars=True,
        vars_files=True,
        any_errors_fatal=True,
        no_log=True,
        delegate_to=True,
        delegate_facts=True,
        force_handlers=True,
        serial=True,
        tags=True,
        skip_tags=True,
        until=True,
        dependencies=True,
        when=True,
        notify=True,
    )


# Generated at 2022-06-21 09:51:09.244085
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(myvars=['name', 'foobar'])
    warn_if_reserved(myvars=['name', 'foobar'], additional=['foobar'])



# Generated at 2022-06-21 09:51:12.015136
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['a', 'b', 'hosts'])

# Generated at 2022-06-21 09:51:19.673629
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = dict(name='value',
                not_reserved_var='value',
                vars='value',
                when='value',
                hosts='value',
                connection='value',
                play='value',
                gather_facts='value',
                remote_user='value',
                no_log='value',
                roles='value',
                become='value',
                become_user='value',
                become_method='value',
                sudo='value',
                sudo_user='value',
                environment='value',
                any_errors_fatal='value',
                serial='value',
                action='value'
                )

    warn_if_reserved(vars)

# Generated at 2022-06-21 09:51:26.636751
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # not reservable function names
    test_names = ['test', 'test1', 'test_1']
    for t in test_names:
        assert is_reserved_name(t) is False

    # reservable function names
    test_names = ['name', 'hosts', 'pre_tasks', 'tasks', 'post_tasks', 'roles']
    for t in test_names:
        assert is_reserved_name(t)


if __name__ == '__main__':
    test_is_reserved_name()

# Generated at 2022-06-21 09:51:30.121308
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: add tests to make sure that no new reserved names are being added
    #        without being added to this test
    assert 'become' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'vars' in get_reserved_names()



# Generated at 2022-06-21 09:51:47.083757
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = _RESERVED_NAMES
    for name in reserved_names:
        assert(is_reserved_name(name))

# Generated at 2022-06-21 09:51:54.466745
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:51:57.527030
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    warn_vars = ["notify", "tags", "async"]
    warn_if_reserved(warn_vars)

# Generated at 2022-06-21 09:51:59.349868
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['vars'])
        assert True
    except AssertionError:
        assert False

    try:
        warn_if_reserved(['invalid_value'])
        assert False
    except AssertionError:
        assert True



# Generated at 2022-06-21 09:52:00.519161
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests if get_reserved_names() return a list '''

    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, frozenset)



# Generated at 2022-06-21 09:52:05.422941
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # Test for two variables that do not collide
    myvars = {'myvar1': 'first', 'myvar2': 'second'}
    assert not warn_if_reserved(myvars)

    # Test for two variables that do collide
    myvars = {'gather_facts': 'first', 'myvar2': 'second'}
    assert warn_if_reserved(myvars)

# Generated at 2022-06-21 09:52:06.654685
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars') == False
    assert is_reserved_name('include_role') == True

# Generated at 2022-06-21 09:52:12.721319
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test the public API
    assert isinstance(get_reserved_names(), set)
    assert len(get_reserved_names()) > 0

    # Test all public API's private API variants
    assert isinstance(get_reserved_names(False), set)
    assert len(get_reserved_names(False)) > 0

    assert isinstance(get_reserved_names(True), set)
    assert len(get_reserved_names(True)) > 0

    # Test an invalid value for the public API
    try:
        get_reserved_names('invalid')
    except TypeError:
        pass
    else:
        raise AssertionError('get_reserved_names should fail with a bad value.')



# Generated at 2022-06-21 09:52:14.854633
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    bad_names = ['action', 'hosts', 'host']
    warn_if_reserved(bad_names)

# Generated at 2022-06-21 09:52:19.651765
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('with_')
    assert is_reserved_name('tags')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('host')
    assert not is_reserved_name('tags_')

# Generated at 2022-06-21 09:53:06.189477
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # if this function does not find anything, it will raise an AssertionError
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(False), set)

    # there is no guarantee that a given version of Ansible will have a certain
    # reserved name, but this version should have at least these:
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'name' in get_reserved_names()

    # the private names are, by definition, not part of the public API and
    # could change at any time, so we will not test them, only make sure
    # that the correct number of private names are found
    public = get_reserved_names(False)
    private = get_reserved_names

# Generated at 2022-06-21 09:53:08.636965
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = get_reserved_names(include_private=False)
    for name in reserved_names:
        assert is_reserved_name(name) == True

# Generated at 2022-06-21 09:53:13.055674
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # no warnings
    warn_if_reserved(['foo', 'bar'])
    warn_if_reserved(['foo', 'bar', 'vars'])

    # with warnings
    warn_if_reserved(['foo', 'bar', 'name'])
    warn_if_reserved(['foo', 'bar', 'vars', 'name'])

# Generated at 2022-06-21 09:53:23.388032
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import unittest
    from ansible.utils.display import Display
    from ansible import errors

    class TestDisplay(Display):
        ''' A display class that does not actually display anything, but allows us to test '''
        def display(self, msg, *args, **kwargs):
            self.msg = msg

        def warning(self, msg, *args, **kwargs):
            self.msg = msg

        def display_deprecation_warning(self, msg, *args, **kwargs):
            self.msg = msg

    class TestCase(unittest.TestCase):

        def setUp(self):
            self.testdisplay = TestDisplay()
            self.testdisplay.verbosity = 3

            # This is needed because otherwise the Display class tries to cache it
            # and for tests caching

# Generated at 2022-06-21 09:53:28.474725
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('block')
    assert is_reserved_name('roles')
    assert is_reserved_name('first_available_file')
    assert is_reserved_name('register')
    assert is_reserved_name('with_')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('xyz_reservedname')

# Generated at 2022-06-21 09:53:34.360327
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pub, priv = get_reserved_names(include_private=False), get_reserved_names(include_private=True)
    assert isinstance(pub, set)
    assert isinstance(priv, set)
    assert pub != priv
    assert 'hosts' in pub
    assert 'hosts' in priv
    assert 'private' not in pub     # private is a private attribute and thus not in the public namespace
    assert 'private' in priv
    assert 'name' in pub
    assert 'name' in priv

# Generated at 2022-06-21 09:53:35.469199
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become')
    assert not is_reserved_name('not_in_reserved_names')

# Generated at 2022-06-21 09:53:38.712555
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert not warn_if_reserved({'vars'})
    assert warn_if_reserved({'vars', 'action'})
    assert warn_if_reserved({'vars', 'loop'})
    assert warn_if_reserved({'vars', 'async'})



# Generated at 2022-06-21 09:53:44.401321
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # No vars, no warning
    warn_if_reserved({})
    # Action is a reserved name, but it's also in our vars, so no warning
    warn_if_reserved({'action': 'banana'})
    # Using a reserved name, we will trigger a warning
    warn_if_reserved({'action': 'banana', 'vars': 'apple'})

# Generated at 2022-06-21 09:53:52.505848
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('hosts')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('max_fail_percentage')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('always_run')
    assert is_reserved_name('register')
    assert not is_reserved_name('urgent')
    assert not is_reserved_name('username')


# Generated at 2022-06-21 09:54:30.006154
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-21 09:54:30.733650
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')

# Generated at 2022-06-21 09:54:33.828280
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('block')
    assert not is_reserved_name('bloxx')


# Generated at 2022-06-21 09:54:43.132107
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('pre_tags') is True
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('tasks') is True
    assert is_reserved_name('handlers') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('action') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('with_') is True
    assert is_reserved_name('with_block') is True
    assert is_reserved_name('with_dict') is True
    assert is_reserved_name('with_file') is True
    assert is_reserved_name('with_items') is True


# Generated at 2022-06-21 09:54:43.957086
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')

# Generated at 2022-06-21 09:54:46.009603
# Unit test for function is_reserved_name
def test_is_reserved_name():
    play = Play()
    play.vars = {}
    play.post_validate()

    for attr in play.__dict__.keys():
        assert(is_reserved_name(attr))

# Generated at 2022-06-21 09:54:53.249766
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Testing public attributes
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'import_role' in get_reserved_names()
    assert 'import_tasks' in get_reserved_names()

# Generated at 2022-06-21 09:54:55.901952
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')


# Generated at 2022-06-21 09:55:02.797250
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # create list to hold results and test against
    function_result = get_reserved_names()

    # standard names

# Generated at 2022-06-21 09:55:11.833991
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import contextlib
    import six
    import sys

    # Test empty list
    with captured_output() as (out, err):
        warn_if_reserved(None)
    output = out.getvalue().strip()
    assert output == ''

    # Test var that conflicts with a reserved name
    with captured_output() as (out, err):
        warn_if_reserved(['action'])
    output = out.getvalue().strip()
    assert output == 'Found variable using reserved name: action'

    # Test vars that conflict with a reserved name
    with captured_output() as (out, err):
        warn_if_reserved(['action', 'local_action'])
    output = out.getvalue().strip()

# Generated at 2022-06-21 09:56:37.876386
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('tags') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('action') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('parent') is True

    # FIXME: remove after with_ is not only deprecated but removed
    assert is_reserved_name('with_') is True

    assert is_reserved_name('vars') is False
    assert is_reserved_name('foobar') is False
    assert is_reserved_name('foo_bar') is False
    assert is_reserved_name('foo-bar') is False

# Generated at 2022-06-21 09:56:41.060263
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in get_reserved_names():
        assert is_reserved_name(name)
    for name in ['foobar', 'play', 'roles', 'tasks', 'handlers']:
        assert not is_reserved_name(name)
    # Add user-defined reserved names
    for name in ['foobar', 'bazbaz']:
        assert is_reserved_name(name, additional=set(name))

# Generated at 2022-06-21 09:56:42.475740
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'name': 'foobar', 'hosts': ['localhost']}, additional=['other'])

# Generated at 2022-06-21 09:56:47.207829
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = {'roles': None,
              'tasks': None,
              'vars': None,
              'var': None,
              'somethingelse': None,
              'somethingelse_name': None,
              }

    warn_if_reserved(myvars)



# Generated at 2022-06-21 09:56:49.447917
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    assert len(reserved) > 0, 'Expected to get some reserved names'

    assert 'connection' in reserved, 'connection is a reserved name'

# Generated at 2022-06-21 09:56:52.941748
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('task') is True

    assert is_reserved_name('name') is False

# Generated at 2022-06-21 09:56:58.674128
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({})
    warn_if_reserved({'action': None})
    warn_if_reserved({'vars': None, 'action': None})
    warn_if_reserved({'vars': None, 'action': None, 'tasks': None, 'with_items': None})
    warn_if_reserved({'vars': None, 'action': None, 'tasks': None, 'my_new_block': None})

# Generated at 2022-06-21 09:57:00.053028
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-21 09:57:10.301420
# Unit test for function get_reserved_names
def test_get_reserved_names():
    output = get_reserved_names()

# Generated at 2022-06-21 09:57:19.233943
# Unit test for function is_reserved_name