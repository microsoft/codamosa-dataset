

# Generated at 2022-06-21 09:48:22.363116
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:48:32.921579
# Unit test for function get_reserved_names
def test_get_reserved_names():
    known_reserved_names = {
        'action',
        'any_errors_fatal',
        'become',
        'become_flags',
        'become_method',
        'become_user',
        'connection',
        'delegate_facts',
        'gather_facts',
        'hosts',
        'ignore_errors',
        'loop',
        'name',
        'no_log',
        'notify',
        'poll',
        'register',
        'roles',
        'serial',
        'sudo',
        'sudo_flags',
        'sudo_user',
        'tags',
        'tasks',
        'when',
        'vars_prompt',
    }
    assert get_reserved_names(False) == known_reserved_names


# Generated at 2022-06-21 09:48:42.675798
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('async')
    assert is_reserved_name('become')
    assert is_reserved_name('become_user')
    assert is_reserved_name('become_method')
    assert is_reserved_name('become_flags')
    assert is_reserved_name('block')
    assert is_reserved_name('block_errors_fatal')
    assert is_reserved_name('connection')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('delegate_facts')
    assert is_reserved_name('environment')
    assert is_reserved_name('force_handlers')
   

# Generated at 2022-06-21 09:48:45.404688
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('not_name')



# Generated at 2022-06-21 09:48:51.709796
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') is True
    assert is_reserved_name('playbook') is True
    assert is_reserved_name('become') is True
    assert is_reserved_name('tags') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('with_') is True

    assert is_reserved_name('foobar') is False

# Generated at 2022-06-21 09:48:55.396747
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved_names = get_reserved_names()
    for name in reserved_names:
        class FakeClass(object):
            def __init__(self):
                setattr(self, name, "foo")

        warn_if_reserved(vars(FakeClass()))

# Generated at 2022-06-21 09:49:04.179159
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    class MockDisplay(object):
        def __init__(self):
            self.mock_warnings = []

        def warning(self, msg):
            self.mock_warnings.append(msg)

    myvars = dict(
        vars=dict(),
        name='foo',
    )

    # verify the display got called
    mydisplay = MockDisplay()
    warn_if_reserved(myvars.keys(), additional=['name'], display=mydisplay)
    assert len(mydisplay.mock_warnings) == 1

    # verify it did not get called when we add to vars
    mydisplay = MockDisplay()
    warn_if_reserved(myvars['vars'].keys(), display=mydisplay)
    assert len(mydisplay.mock_warnings) == 0

    # make

# Generated at 2022-06-21 09:49:13.815028
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class fake_display(object):
        def __init__(self):
            self.warn_list = []

        def warning(self, msg):
            self.warn_list.append(msg)

    vars1 = {'action': 'shell', 'hosts': 'all'}
    vars2 = {'action': 'shell', 'hosts': 'all', 'vars': {'reserved': 'value'}}
    vars3 = {'action': 'shell', 'hosts': 'all', 'vars': {'third_party': 'value'}}

    # Setup the fake display class
    global display
    old_display = display
    display = fake_display()

    # Test warnings when there are no vars
    warn_if_reserved({})

# Generated at 2022-06-21 09:49:18.820379
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # This test requires pytest 2.7.0 and pytest-mock 1.3.0 or newer.
    # When running the unit tests the display plugin isn't loaded, so the
    # warning doesn't actually show on the console. Instead, a mock is used to
    # verify that the warning was called with the correct arguments.
    reserved_names = get_reserved_names()

    for name in 'included_files', 'vars', 'roles':
        if name in reserved_names:
            reserved_names.remove(name)

    # Verify that no warning is pritned for variables that are not reserved.
    with display.mocked():
        warn_if_reserved(['included_files', 'vars', 'roles'])

    # Verify that a warning is pritned for each reserved variable.

# Generated at 2022-06-21 09:49:26.686129
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.module_utils.six import PY3
    if PY3:
        import io
        import sys
        myout = sys.stdout = io.StringIO()
    else:
        import StringIO
        myout = sys.stdout = StringIO.StringIO()
    myvars = ['action', 'hosts', 'a', 'b', 'c', 'd']
    display = Display()
    warn_if_reserved(myvars)
    if myout.getvalue() == 'Found variable using reserved name: action\n':
        pass
    else:
        print('Unit test for function warn_if_reserved in ansible.playbook.play_context ERROR.')

# Generated at 2022-06-21 09:49:55.867026
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Get a list of all play reserved names, public and private
    '''
    assert 'vars' in get_reserved_names()
    assert 'private' not in get_reserved_names()

    # this is a private attribute
    assert 'include_tasks' in get_reserved_names(include_private=True)

# Generated at 2022-06-21 09:50:06.314481
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(include_private=False)
    private_names = get_reserved_names(include_private=True)

    # Check for private names are in the public ones
    assert private_names.issubset(public_names)

    # Make sure nothing was removed from the private ones
    assert len(private_names) > len(public_names)

    # Make sure the total size is expected
    assert len(private_names) >= 30

    # Check that some specific names are in the list
    assert 'hosts' in public_names
    assert 'private' in private_names
    assert 'when' in public_names
    assert 'delegate_to' in private_names
    assert 'become' in public_names

# Generated at 2022-06-21 09:50:18.170669
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = _RESERVED_NAMES
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('local_action')
    assert is_reserved_name('action')
    assert is_reserved_name('with_')
    assert is_reserved_name('when')
    assert is_reserved_name('name')
    assert is_reserved_name('tasks')
    assert is_reserved_name('task_args')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('block')
    assert is_reserved_name('block_errors_fatal')
    assert is_reserved_name('no_log')

# Generated at 2022-06-21 09:50:24.742975
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    We expect a set of names to be reserved
    '''
    expected = ['orig', 'vars', 'action', 'block', 'block:', 'delegate_to',
                'delegate_facts', 'environment', 'include', 'local_action',
                'name', 'no_log', 'notify', 'register', 'roles', 'tags',
                'tasks', 'when']
    assert set(expected).issubset(_RESERVED_NAMES)

# Generated at 2022-06-21 09:50:30.094296
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Check public names
    public = get_reserved_names(False)
    assert 'action' in public
    assert 'local_action' in public
    assert 'with_' in public
    assert 'loop' not in public

    # Check all names
    assert 'loop' in get_reserved_names()

    # Check if the list is up to date by examining a random attribute
    assert 'user' in get_reserved_names()


# Generated at 2022-06-21 09:50:32.051719
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved('async', 'sudo_user')

# Generated at 2022-06-21 09:50:34.013544
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'hosts': 'localhost', 'action': 'ping'}) is None

# Generated at 2022-06-21 09:50:36.439845
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['gather_facts', 'action', 'local_action', 'when', 'register', 'vars', 'not_a_reserved'])

# Generated at 2022-06-21 09:50:41.785209
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # Test reserved names returned by get_reserved_names()
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name) is True

    # Test non-reserved names
    assert is_reserved_name('task') is False
    assert is_reserved_name('foo_bar') is False

# Generated at 2022-06-21 09:50:48.917648
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_expected = set(['hosts', 'name', 'user', 'roles', 'vars', 'tags', 'register', 'delegate_to', 'local_action', 'become',
                           'become_user', 'become_method', 'connection', 'gather_facts', 'no_log', 'environment', 'any_errors_fatal',
                           'ignore_errors', 'force_handlers', 'transport', 'remote_user', 'serial', 'su', 'su_user', 'sudo', 'sudo_user',
                           'async', 'poll', 'when', 'block', 'notify', 'handler', 'listen', 'pre_tasks', 'post_tasks', 'tasks', 'pre_tags',
                           'post_tags'])


# Generated at 2022-06-21 09:51:25.121634
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('some_random_name')

# Generated at 2022-06-21 09:51:29.020125
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert not warn_if_reserved({'hash': 'value'})

    try:
        warn_if_reserved({'hosts': 'value'})
    except Exception as e:
        assert False, 'Should not throw exception'
    assert True



# Generated at 2022-06-21 09:51:36.173382
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # create class with top level keys
    class TestClass(object):

        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    test_names = {
        'test_vars': ['name', 'tasks', 'vars', 'with_items', 'when'],
        'test_vars2': ['name', 'tasks', 'vars', 'action', 'local_action'],
        'test_vars3': ['name', 'tasks', 'vars', 'action',
                       'local_action', 'with_items', 'when'],
        'test_vars4': ['name', 'tasks', 'vars', 'action', 'local_action', 'when'],
    }

    # Check warnings

# Generated at 2022-06-21 09:51:37.551485
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')


# Generated at 2022-06-21 09:51:40.355454
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=True)
    assert 'roles' in result
    assert 'private_roles' in result
    assert 'name' in result



# Generated at 2022-06-21 09:51:45.264843
# Unit test for function is_reserved_name
def test_is_reserved_name():

    for name in get_reserved_names(include_private=True):
        assert is_reserved_name(name)
        assert is_reserved_name(name+'_')  # check that trailing underscore is OK
        assert not is_reserved_name(name+'_other')
        assert not is_reserved_name('_'+name)  # check that leading underscore is not OK


# This is differnt from test_is_reserved_name because it tests the function get_reserved_names

# Generated at 2022-06-21 09:51:46.211268
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({"connection": "local"})


# Generated at 2022-06-21 09:51:47.614317
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('not_a_reserved_name')

# Generated at 2022-06-21 09:51:51.209316
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert not is_reserved_name('vars_files')
    assert not is_reserved_name('vars_prompt')


# Generated at 2022-06-21 09:51:55.186527
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['action', 'perform_task']) == None
    assert warn_if_reserved(['action', 'perform_task'], additional=['ansible_ssh_host']) == None
    assert warn_if_reserved(['action', 'perform_task'], additional=['whatever']) == None


# Generated at 2022-06-21 09:53:22.594341
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    # Just a few checks
    assert isinstance(names, list)
    assert isinstance(names, set)
    assert 'action' in names
    assert 'register' in names

# Generated at 2022-06-21 09:53:31.267936
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # These are a randomly selected set of reserved names
    # as they exist on 2017-04-12.  If you change this test
    # or the function get_reserved_names, be sure to update
    # this list to contain a few reserved names from each
    # class.

    assert 'any_errors_fatal' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_

# Generated at 2022-06-21 09:53:38.742580
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert(len(reserved_names)) > 100


# Generated at 2022-06-21 09:53:43.797076
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class Test:
        def __init__(self):
            self.warn = False

        def warning(self, msg):
            self.warn = True

    t = Test()
    display.warning = t.warning

    warn_if_reserved({'hosts': 'all'})
    assert t.warn is True

# Generated at 2022-06-21 09:53:50.868960
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import mock

    from ansible.utils import plugin_docs

    mock_display = mock.patch.object(plugin_docs.display, 'warning')

    with mock_display as mock_display_warn:
        plugin_docs.warn_if_reserved({'action': 'foobar'})
    assert mock_display_warn.call_args == mock.call('Found variable using reserved name: action')

    mock_display.reset_mock()
    plugin_docs.warn_if_reserved({'hosts': 'foobar'})
    assert mock_display_warn.call_args == mock.call('Found variable using reserved name: hosts')

# Generated at 2022-06-21 09:53:54.841722
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'vars' in reserved
    assert 'tasks' in reserved
    assert 'roles' in reserved
    assert 'ignore_errors' in reserved
    assert 'action' in reserved
    assert 'include_vars' not in reserved


# Generated at 2022-06-21 09:54:03.257165
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:54:07.254849
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_var = ['vars', 'fail_on_error', 'name', 'register']
    warn_if_reserved(test_var)
    # Test with additional reserved names
    additional = ['x']
    warn_if_reserved(test_var, additional)

# Generated at 2022-06-21 09:54:08.033744
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')

# Generated at 2022-06-21 09:54:09.965039
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert( is_reserved_name('roles') == True)
    assert( is_reserved_name('roles1') == False)

# Generated at 2022-06-21 09:57:29.381168
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)



# Generated at 2022-06-21 09:57:36.676570
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    from ansible.utils.py3compat import StringIO

    display = Display()
    display.verbosity = 3
    display._output = StringIO()

    warn_if_reserved(['name', 'action', 'notify'], additional=['tags'])

    assert 'Found variable using reserved name: name' in display._output.getvalue()
    assert 'Found variable using reserved name: action' in display._output.getvalue()
    assert 'Found variable using reserved name: notify' in display._output.getvalue()
    assert 'Found variable using reserved name: tags' in display._output.getvalue()

    display._output.truncate(0)

    warn_if_reserved(['hosts', 'tasks'])

    assert 'Found variable using reserved name: hosts' in display._

# Generated at 2022-06-21 09:57:38.431356
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # reserved_name
    values = dict(name='debug', bar='foo')
    warn_if_reserved(values)

    # not reserved
    values = dict(name='debug', foo='bar')
    warn_if_reserved(values)

# Generated at 2022-06-21 09:57:40.982530
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('playbook')
    assert is_reserved_name('role')
    assert is_reserved_name('action')
    assert is_reserved_name('vars')
    assert not is_reserved_name('foo')


# Generated at 2022-06-21 09:57:44.850653
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    dummy_myvars = dict()
    dummy_myvars['hosts'] = 'all'
    dummy_myvars['action'] = 'ping'
    dummy_myvars['tasks'] = 'all'
    dummy_myvars['otherstuff'] = 'all'
    warn_if_reserved(dummy_myvars)

# Generated at 2022-06-21 09:57:45.919076
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')



# Generated at 2022-06-21 09:57:54.144802
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:57:56.426557
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # FIXME: this test is a total sham....
    myvars = {'name': 'test'}
    warn_if_reserved(myvars)