

# Generated at 2022-06-21 09:48:28.620727
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)
    assert isinstance(get_reserved_names(include_private=False), frozenset)

# Generated at 2022-06-21 09:48:38.029107
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        import __builtin__
        builtin_name = '__builtin__'
    except ImportError:
        import builtins
        builtin_name = 'builtins'
    test_vars = [
        'hosts',
        'roles',
        'action',
        'local_action',
        'with_',
        'name',
        'name2',
        'include',
        'import_playbook',
        'include_tasks',
        'import_tasks',
    ]
    mock_display = Mock()
    with patch.dict(sys.modules, {builtin_name: mock_display}):
        warn_if_reserved(test_vars)

# Generated at 2022-06-21 09:48:45.098402
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class TestResult(object):
        def __init__(self):
            self.results = []

        def add(self, item):
            self.results.append(item)

        def __contains__(self, item):
            return item in self.results

    import sys
    import os
    import io
    tmpstdout = sys.stdout
    sys.stdout = io.StringIO()
    try:
        display.verbosity = 1
        test = TestResult()
        reserved = _RESERVED_NAMES
        reserved.add('NOT_RESERVED')
        warn_if_reserved(reserved)
        assert "Found variable using reserved name: action" in test
    finally:
        sys.stdout = tmpstdout

# Generated at 2022-06-21 09:48:56.053855
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.helpers import load_list_of_blocks

    display.verbosity = 3
    warn_if_reserved({})
    warn_if_reserved({'include_tasks': 'test.yml'})
    warn_if_reserved({'include_role': 'test'})
    warn_if_reserved({'pre_tasks': load_list_of_blocks([])})
    warn_if_reserved({'post_tasks': load_list_of_blocks([])})
    warn_if_reserved({'roles': load_list_of_blocks([])})
    warn_if_reserved({'tasks': load_list_of_blocks([])})
    warn_if_reserved({'any_errors_fatal': True})
    warn_if_reserved

# Generated at 2022-06-21 09:48:58.720663
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # This should display the appropriate warning
    warn_if_reserved(['vars', 'action'])


if __name__ == "__main__":
    test_warn_if_reserved()

# Generated at 2022-06-21 09:49:00.617241
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(dict(hosts="foo", gather_facts="no", roles=[{"role": "foobar"}]))

# Generated at 2022-06-21 09:49:03.144017
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars') is False
    assert is_reserved_name('name') is True
    assert is_reserved_name('__foo') is False
    assert is_reserved_name('bar__') is False
    assert is_reserved_name('meta') is True

# Generated at 2022-06-21 09:49:13.312508
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:49:17.839183
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    p = Play().load(dict(
        name="test play",
        hosts='somehosts',
        roles='someroles',
        become='true',
        become_method='somebecomemethod',
        become_user='somebecomeuser',
        connection='someconnection',
        delegate_to='somedelegateto',
        gather_facts='somegatherfacts',
        max_fail_percentage='somemaxfailpercentage',
        tags='sometags',
        serial='someserial',
        any_errors_fatal='someanyerrorsfatal',
        tasks=[{'name': 'task1',
                'somevarname': 'somevarvalue'}]
    ))

# Generated at 2022-06-21 09:49:19.448700
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:49:42.232685
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('name')
    assert is_reserved_name('import_role')
    assert not is_reserved_name('not a reserved name')
    assert not is_reserved_name('not_a_reserved_name')
    assert not is_reserved_name('another__reserved_name')

# Generated at 2022-06-21 09:49:46.296154
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import mock
    from ansible.utils.display import Display
    from ansible.utils.vars import warn_if_reserved
    from ansible.utils.vars import is_reserved_name

    names = ['roles', 'roles_path', 'action', 'block']

    Display.warning = mock.Mock()

    warn_if_reserved(names)
    for n in names:
        assert Display.warning.call_count == 1
        assert Display.warning.call_args[0][0] == 'Found variable using reserved name: %s' % n
        Display.warning.reset_mock()

    warn_if_reserved(['arole'])
    assert Display.warning.call_count == 0

    assert is_reserved_name('roles')

# Generated at 2022-06-21 09:49:56.812428
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['vars', 'name', 'register', 'become'])
    except Exception as e:
        assert False, e
    try:
        warn_if_reserved(['vars', 'rescue'])
        assert False, 'rescue is a reserved name'
    except Exception as e:
        assert 'rescue is a reserved name' in str(e)
    try:
        warn_if_reserved(['vars', 'pre_tasks'])
        assert False, 'pre_tasks is a reserved name'
    except Exception as e:
        assert 'pre_tasks is a reserved name' in str(e)

# Generated at 2022-06-21 09:50:08.514530
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:50:19.725327
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names '''

# Generated at 2022-06-21 09:50:21.652289
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'strategy': 'free', 'remote_user': 'wkumari'})

# Generated at 2022-06-21 09:50:27.943334
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' Test warning output for reserved names '''
    # Make sure we don't get false positives with
    # non-reserved variables.
    nonreserved_list = ['foo', 'bar', 'baz', 'boo']
    warn_if_reserved(nonreserved_list)

    # This should generate a warning
    reserved_list = ['action', 'local_action']
    warn_if_reserved(reserved_list)

# Generated at 2022-06-21 09:50:35.326203
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    import os
    import sys
    import unittest
    import tempfile

    def run_warn_if_reserved(vars, additional, expected_results_one=None, expected_results_two=None):

        (fd, filename) = tempfile.mkstemp(prefix="warn_if_reserved")
        os.close(fd)

        display.PLUGIN_WARNINGS = True
        display.PLUGIN_WARNINGS_FILENAME = filename

        warn_if_reserved(vars, additional=additional)

        display.PLUGIN_WARNINGS = False

        with open(filename, 'r') as f:
            results = f.readlines()

        os.remove(filename)

        if expected_results_one is None and expected_results_two is None:
            return

        # Order is undefined


# Generated at 2022-06-21 09:50:45.639957
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == set(['tasks', 'hosts', 'meta', 'vars', 'pre_tasks', 'post_tasks', 'notify', 'handlers', 'tags', 'any_errors_fatal', 'always_run', 'become', 'become_user', 'become_method', 'block', 'block:rescue', 'block:always', 'ignore_errors', 'vars_files', 'include_vars', 'roles', 'vars_prompt', 'connection', 'when', 'gather_facts', 'delegate_to', 'run_once', 'local_action', 'with_', 'environment', 'no_log', 'register', 'ignore_errors', 'sudo_user', 'sudo', 'listen'])

# Generated at 2022-06-21 09:50:51.048788
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

    assert "action" in public
    assert "name" in private
    assert "include" not in private
    assert "include_tasks" in private
    assert "local_action" in public
    assert "delegate_to" in private
    assert "delegate_facts" in private

# Generated at 2022-06-21 09:51:03.109652
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['name', 'action', 'private_test'])



# Generated at 2022-06-21 09:51:08.274119
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # FIXME: what's the way to unit test this?
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    vars = dict(
        when=AnsibleUnsafeText('today'),
        version=AnsibleUnsafeText('1.2.3.4'),
        noop=AnsibleUnsafeText('yes'),
    )
    warn_if_reserved(vars)

# Generated at 2022-06-21 09:51:13.581653
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'action': 1, 'vars': 1})
    warn_if_reserved({'hosts': 1, 'name': 1}, additional=frozenset(['block']))

# Generated at 2022-06-21 09:51:16.574409
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'block' in reserved
    assert 'private_key_file' in reserved
    assert 'private_key_file' in reserved
    assert 'name' in reserved

# Generated at 2022-06-21 09:51:23.203601
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # the expected number of reserved names
    expected_public_name_count = 17
    expected_private_name_count = 13

    # Check the number of reserved names
    public_names = get_reserved_names(include_private=False)
    assert len(public_names) == expected_public_name_count

    private_names = get_reserved_names(include_private=True)
    assert len(private_names) == expected_private_name_count

    # Check for expected reserved names
    assert 'name' in public_names
    assert 'hosts' in public_names
    assert 'roles' in public_names
    assert 'tasks' in public_names
    assert 'vars' in public_names
    assert 'block' in public_names
    assert 'action' in public_names

# Generated at 2022-06-21 09:51:27.562871
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = dict(reserved_name='var')
    assert warn_if_reserved(myvars.keys()) == 'Found variable using reserved name: reserved_name'
    assert warn_if_reserved(myvars.keys(), additional=set(['toto'])) == 'Found variable using reserved name: toto'

# Generated at 2022-06-21 09:51:34.839128
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('private_action')
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts_all')
    assert is_reserved_name('hosts_hosts')
    assert is_reserved_name('hosts_set')
    assert is_reserved_name('hosts_vars')
    assert is_reserved_name('hosts_vars_all')
    assert is_reserved_name('hosts_vars_hosts')
    assert is_reserved_name('hostvars')
    assert is_reserved_name('vars')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:51:39.381060
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # these should warn
    warn_if_reserved(['action'])
    warn_if_reserved(['action', 'local_action'])
    warn_if_reserved(['action', 'loop'])

    # these should not warn
    warn_if_reserved(['foo'])
    warn_if_reserved(['action', 'foo'])

# Generated at 2022-06-21 09:51:40.629830
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action'])

# Generated at 2022-06-21 09:51:42.754489
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('delegate_to')
    assert not is_reserved_name('made_up_name')

# Generated at 2022-06-21 09:52:16.318451
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['name', 'tags'])
    # no output is expected here
    assert True

# Generated at 2022-06-21 09:52:22.606773
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # this should print out a warning message
    warn_if_reserved({'loop':'value'})

    # variables with any of these names should not print out a warning
    # message
    safe_names = set(['vars', 'ignore_errors', 'when', 'become', 'become_method', 'become_user', 'delegate_to'])
    for safe_name in safe_names:
        warn_if_reserved({safe_name: 'value'})

# Generated at 2022-06-21 09:52:23.704350
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')


# Generated at 2022-06-21 09:52:30.562930
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test the function get_reserved_names returns what we expect '''

    public = set(['become', 'become_method', 'become_user', 'connection', 'environment', 'gather_facts', 'hosts', 'max_fail_percentage', 'name', 'no_log', 'post_tasks', 'pre_tasks', 'roles', 'serial', 'tags', 'tasks', 'vars_files', 'vars_prompt', 'with_items', 'with_path', 'with_sequence', 'with_subelements'])

# Generated at 2022-06-21 09:52:35.684765
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:52:38.470365
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('hosts')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('tasks')
    assert is_reserved_name('name')
    assert not is_reserved_name('some_other_name')



# Generated at 2022-06-21 09:52:46.649017
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = set(get_reserved_names())
    assert 'hosts' in reserved
    assert 'vars' in reserved
    assert 'action' in reserved
    assert 'loop' in reserved
    assert '_run_as' in reserved
    assert 'local_action' not in reserved
    assert 'with_' not in reserved

    reserved = set(get_reserved_names(include_private=False))
    assert 'hosts' in reserved
    assert 'vars' in reserved
    assert 'action' in reserved
    assert 'loop' in reserved
    assert 'local_action' not in reserved
    assert 'with_' not in reserved
    assert '_run_as' not in reserved

# Generated at 2022-06-21 09:52:56.630353
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == _RESERVED_NAMES
    assert set(get_reserved_names(include_private=False)) <= _RESERVED_NAMES

# Generated at 2022-06-21 09:53:06.804686
# Unit test for function get_reserved_names
def test_get_reserved_names():
    def test_is_equal(expected, received):
        if len(received) != len(expected):
            raise AssertionError("%s (received) is not equal to %s (expected)" % (received, expected))

        for i in received:
            if i not in expected:
                raise AssertionError("%s (received) is not equal to %s (expected)" % (received, expected))


# Generated at 2022-06-21 09:53:16.542102
# Unit test for function get_reserved_names
def test_get_reserved_names():
    all_items = set()
    for item in get_reserved_names():
        all_items.add(item)


# Generated at 2022-06-21 09:54:03.988710
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME
    assert len(get_reserved_names()) > 0

# Generated at 2022-06-21 09:54:13.179263
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # check that name conflict warning works correctly
    ok_vars = ['vars', '_vars', '_raw_params']
    err_vars = ['tasks', 'roles']

    out = ''
    for var in ok_vars:
        warn_if_reserved([var])
        display.display = out.write
        try:
            display.warning('Found variable using reserved name: %s' % var)
        except AssertionError:
            # we are happy if it didn't display the warning
            continue
        else:
            raise AssertionError('Should not have displayed warning, var={0}'.format(var))

    for var in err_vars:
        warn_if_reserved([var])
        display.display = out.write

# Generated at 2022-06-21 09:54:22.235105
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('error_tasks')
    assert is_reserved_name('when')
    assert is_reserved_name('name')
    assert is_reserved_name('tags')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_items')
    assert is_reserved_name('include')
    assert not is_reserved_name('playbook')
    assert not is_reserved_name('role')


# Generated at 2022-06-21 09:54:23.915734
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:54:25.618199
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    varnames = ['foo', 'hosts', 'action', 'local_action', 'vars']
    warn_if_reserved(varnames)

# Generated at 2022-06-21 09:54:31.095717
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # Even though 'local_action' is not an actual reserved name, because
    # 'action' is reserved, 'local_action' is also reserved.
    assert is_reserved_name('action') is True
    assert is_reserved_name('local_action') is True

    # 'with_' is not a reserved name
    assert is_reserved_name('with_') is False

    # These names are reserved
    assert is_reserved_name('when') is True
    assert is_reserved_name('tags') is True
    assert is_reserved_name('become') is True

# Generated at 2022-06-21 09:54:34.239411
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('myvar')

# Generated at 2022-06-21 09:54:43.506311
# Unit test for function get_reserved_names
def test_get_reserved_names():
    play_names = ['connection', 'delegate_to', 'gather_facts',
                  'name', 'hosts', 'remote_user', 'tasks',
                  'roles', 'any_errors_fatal', 'max_fail_percentage',
                  'sudo_user', 'sudo', 'sudo_pass', 'transport', 'tags',
                  'should_end_session', 'continue_on_error', 'block']
    role_names = ['dependencies', 'tasks', 'name', 'handlers', 'meta', 'pre_tasks', 'roles', 'post_tasks', 'vars', 'defaults', 'block']
    task_names = ['action', 'async', 'changed_when', 'notify', 'poll', 'register', 'retries', 'tags', 'until', 'when', 'local_action']


# Generated at 2022-06-21 09:54:44.935466
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('strategy')
    assert not is_reserved_name('unused')

# Generated at 2022-06-21 09:54:48.155849
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'local_action', 'with_'])
    warn_if_reserved(['tags'])
    warn_if_reserved(['hosts'])
    warn_if_reserved(['register'])
    warn_if_reserved(['include', 'include_tasks'])
    warn_if_reserved(['import_tasks'])

# Generated at 2022-06-21 09:57:00.586570
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import pytest
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()


# Generated at 2022-06-21 09:57:10.898465
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:57:13.821782
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('tasks')
    assert not is_reserved_name('playbooks')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:57:19.564900
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    Based on basic unit test concept in ansible
    '''
    # FIXME: need a proper cleanup of the display object
    # FIXME: test specific warning message
    d = Display()
    d.display = lambda msg, color=None: None
    d.verbosity = 0
    # silence
    old_display = display
    display = d
    try:
        warn_if_reserved({'vars': 'vars'})
        assert True
    except AssertionError:
        assert False
    finally:
        display = old_display

# Generated at 2022-06-21 09:57:29.222170
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Some reserved names that can safely be used by users.
    VALID_RESERVED_NAMES = frozenset(['name', 'type', 'delegate_to', 'local_action', 'with_'])

    # Test all reserved names with the function
    for name in _RESERVED_NAMES:
        if name in VALID_RESERVED_NAMES:
            assert is_reserved_name(name) == False, "Reserved name %s shouldn't be reserved." % name
        else:
            assert is_reserved_name(name), "Reserved name %s is not recognised as reserved." % name

    # Test that it does not detect random strings as reserved names
    for name in ['foo', 'bar', 'baz', 'föo', 'öar', 'öar']:
        assert is_res

# Generated at 2022-06-21 09:57:35.825977
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # This should work
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('privilege')
    assert is_reserved_name('tasks')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    # This should work
    assert not is_reserved_name('host')
    assert not is_reserved_name('namp')
    assert not is_reserved_name('priv')
    assert not is_reserved_name('task')
    assert not is_reserved_name('local_actionn')

# Generated at 2022-06-21 09:57:40.022317
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # setup

    class TestPlay1(Play):
        def __init__(self, name=None):
            super(TestPlay1, self).__init__()
            self._name = name

    # test

    play = TestPlay1()
    assert(is_reserved_name('name') == True)
    assert(is_reserved_name('foo') == False)

    # teardown

# Generated at 2022-06-21 09:57:48.137273
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # We need to temporarily set the display component to catch the warning
    old_display = display

# Generated at 2022-06-21 09:57:52.776157
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this function tests the ability of the warnings to properly identify reserved names '''

    # test trivial pass case
    myvars = [ 'foo', 'bar', 'baz' ]
    warn_if_reserved(myvars)

    # test trivial fail case
    myvars = [ 'action', 'foo', 'bar', 'baz' ]
    warn_if_reserved(myvars)



# Generated at 2022-06-21 09:57:53.483188
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('task')

