

# Generated at 2022-06-21 09:48:18.616503
# Unit test for function is_reserved_name

# Generated at 2022-06-21 09:48:25.874121
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # We don't want to include private attributes in the default
    reserved = get_reserved_names(include_private=False)
    assert 'name' in reserved
    assert 'roles' in reserved
    assert 'loop' not in reserved

    # If we specify, we do want to include private
    reserved = get_reserved_names(include_private=True)
    assert 'name' in reserved
    assert 'roles' in reserved
    assert 'loop' in reserved

# Generated at 2022-06-21 09:48:27.525427
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('when')
    assert not is_reserved_name('foo')



# Generated at 2022-06-21 09:48:31.571486
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)
    assert len(public.intersection(private)) > 0
    assert len(public) + len(private) > len(public.intersection(private))


# Generated at 2022-06-21 09:48:38.070043
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' is_reserved_name() unit tests'''

    def run_test(name, expected):
        ''' Run a test given a name and its expected value '''
        result = is_reserved_name(name)
        if expected:
            if not result:
                assert False, "Expected %s to be reserved, but was not" % name
        else:
            if result:
                assert False, "Expected %s not to be reserved, but was" % name

    run_test('name', False)
    run_test('name', False)
    run_test('name', False)
    run_test('tags', True)
    run_test('with_', True)
    run_test('loop', True)
    run_test('local_action', True)

_RESERVED_NAMES = fro

# Generated at 2022-06-21 09:48:45.430529
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for function get_reserved_names '''


# Generated at 2022-06-21 09:48:50.342286
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    # 'loop' is deprecated, but for now we allow it
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:48:56.198259
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert 'hosts' in result
    assert 'action' in result
    assert 'name' in result
    assert 'become' in result

    result = get_reserved_names(include_private=False)
    assert 'hosts' in result
    assert 'action' in result
    assert 'name' in result
    assert 'become' in result

# Generated at 2022-06-21 09:49:04.553735
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:49:14.196459
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("action")
    assert is_reserved_name("become")
    assert is_reserved_name("become_user")
    assert is_reserved_name("become_method")
    assert is_reserved_name("gather_facts")
    assert is_reserved_name("hosts")
    assert is_reserved_name("name")
    assert is_reserved_name("serial")
    assert is_reserved_name("tags")
    assert is_reserved_name("tasks")
    assert is_reserved_name("task_name")
    assert is_reserved_name("until")
    assert is_reserved_name("when")
    assert is_reserved_name("with_")
    assert is_reserved_name("loop")
    assert is_

# Generated at 2022-06-21 09:49:29.164480
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('with_items')
    assert is_reserved_name('vars_prompt')
    assert is_reserved_name('vars_files')
    assert is_reserved_name('vars_files_contents')
    assert not is_reserved_name('hosts')
    assert not is_reserved_name('user')

# Generated at 2022-06-21 09:49:30.305357
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('not_a_reserved_name') == False

# Generated at 2022-06-21 09:49:34.457468
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'register' in reserved
    assert 'sudo' in reserved
    assert 'login_password' not in reserved

    assert get_reserved_names(include_private=False)
    reserved = get_reserved_names(include_private=False)
    assert 'register' in reserved
    assert 'login_password' not in reserved
    assert 'ignore_errors' in reserved

    reserved = get_reserved_names(include_private=True)
    assert 'login_password' in reserved
    assert 'ignore_errors' in reserved


# Generated at 2022-06-21 09:49:36.219410
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:49:47.632041
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    This test will run a smoke test for the warn_if_reserved function.
    '''

    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.module_utils.basic import AnsibleModule

    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 1
            self.become = None
            self.become_method

# Generated at 2022-06-21 09:49:52.543138
# Unit test for function get_reserved_names
def test_get_reserved_names():
    output = get_reserved_names()

    assert all(isinstance(v, str) for v in output)
    assert len(output) > 20



# Generated at 2022-06-21 09:49:54.165261
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    result = warn_if_reserved(['test_key'])
    assert result == None

# Generated at 2022-06-21 09:50:04.999349
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_cases = {
        'play_hosts': True,
        'play': True,
        'hosts': True,
        'name': True,
        'gather_facts': True,
        'roles': True,
        'handlers': True,
        'user': False,
        'action': True,
        'local_action': True,
        'task': False,
        'block': False
    }

    for key, value in test_cases.items():
        assert key in get_reserved_names() == value
        assert key in _RESERVED_NAMES == value

    # check the function with include_private option
    assert len(get_reserved_names(include_private=False)) == len(get_reserved_names()) - 10

# Generated at 2022-06-21 09:50:17.143422
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    This test verifies the warnings which occur when reserved variables are used
    '''
    import tests.data as data

    verbose = False
    inventory = data.parse_inventory(None)
    loader = data.DataLoader()
    variable_manager = data.VariableManager(loader=loader)
    variable_manager.set_inventory(inventory)

    # run_once is a reserved variable, but it should still pass since we're
    #  not using it yet on any play
    yaml_data = {
        'hosts': 'localhost',
        'tasks': [
            {'name': 'debug', 'debug': 'var=run_once'}
        ]
    }

    pb = data.create_pb(yaml_data)
    for play in pb.get_plays():
        variable_manager.extra

# Generated at 2022-06-21 09:50:19.805142
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become')
    assert is_reserved_name('environment')
    assert is_reserved_name('ignore_errors')
    assert not is_reserved_name('something_else')

# Generated at 2022-06-21 09:50:33.868811
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:50:44.446212
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:50:55.791548
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager

    h = Host('host')
    g = Group('group')
    i = InventoryManager(None)

    new_names = set()
    for attr in h.__dict__['_attributes']:
        new_names.add(attr['name'])
    for attr in g.__dict__['_attributes']:
        new_names.add(attr['name'])
    for attr in i.__dict__['_attributes']:
        new_names.add(attr['name'])

    assert new_names.issubset(_RESERVED_NAMES)
    assert is_reserved_name('hosts') is True
    assert is_reserved_name

# Generated at 2022-06-21 09:51:00.404831
# Unit test for function is_reserved_name
def test_is_reserved_name():
    import os
    import ansible.module_utils.basic

    for name in get_reserved_names():
        assert ansible.module_utils.basic.is_reserved_name(name)

    for name in os.listdir('.'):
        assert not ansible.module_utils.basic.is_reserved_name(name)

# Generated at 2022-06-21 09:51:09.766531
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from unittest import TestCase

    class MockDisplay(object):
        def __init__(self):
            self.called = False

        def warning(self, msg):
            self.called = True

    class TestWarnIfReserved(TestCase):

        def setUp(self):
            self.additional = set(['vars', 'include', 'roles'])
            self.reserved = _RESERVED_NAMES.union(self.additional)
            self.mock_display = MockDisplay()

        def test_warning_reserved_name(self):
            warn_if_reserved(['vars'], self.additional)
            self.assertTrue(self.mock_display.called)

        def test_no_warning_not_reserved_name(self):
            warn_if_res

# Generated at 2022-06-21 09:51:19.933626
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    import StringIO

    my_stdout = StringIO.StringIO()
    sys.stdout = my_stdout

    test_vars = ['action', 'become_user', 'hosts', 'name', 'roles', 'roles_path', 'tasks', 'vars']
    warn_if_reserved(test_vars)
    assert "Found variable using reserved name: action" in my_stdout.getvalue()
    my_stdout.close()

    my_stdout = StringIO.StringIO()
    sys.stdout = my_stdout

    test_vars = ['ansible_version']
    warn_if_reserved(test_vars)
    assert "Found variable using reserved name: ansible_version" not in my_stdout.getvalue()
    my_stdout

# Generated at 2022-06-21 09:51:29.829832
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:51:37.583953
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = {
        'action',
        'connection',
        'delegate_to',
        'local_action',
        'tags',
        'run_once',
        'any_errors_fatal',
        'serial',
        'become',
        'become_user',
        'become_method',
        'vars',
        'when',
        'with_',
        'register',
        'ignore_errors',
        'notify',
        'first_available_file',
        # These are in private, but not in public.  These should not be in
        # either though since they are deprecated at the play level.
        'sudo',
        'sudo_user',
    }

# Generated at 2022-06-21 09:51:38.372085
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('role_path')

# Generated at 2022-06-21 09:51:41.943043
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    warn_if_reserved(['playbook_dir', 'play_hosts', 'playbook', 'play_context'])
    warn_if_reserved(PlayContext.__dict__.keys())

# Generated at 2022-06-21 09:52:06.525413
# Unit test for function get_reserved_names
def test_get_reserved_names():

    def _compare(a, b):
        """ compare 2 sets returning the set of elements in A but not in B, and in B but not in A """
        return a.difference(b), b.difference(a)

    result = get_reserved_names()
    display.debug('Public names:')
    for i in result:
        display.debug(str(i))

    # compare against hardcoded list of reserved names
    # known issues:
    #  - 'vars' is not in this list as it is added by ansible internally
    #  - pre_defined_vars is in this list, but only because of the test for is_reserved_name()
    #    in ansible.module_utils.basic.AnsibleModule.

# Generated at 2022-06-21 09:52:13.296878
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # This is a simple test to make sure certain names are reserved
    # and they are only reserved once.
    reserved_names = get_reserved_names()

    reserved_names_dict = {}

    for reserved_name in ('name','action','become','become_user','connection','environment','group','gather_facts','hosts','ignore_errors','no_log','port','roles','sudo_user','sudo','su','user','vars'):
        if reserved_name in reserved_names:
            reserved_names_dict[reserved_name] = reserved_names_dict.get(reserved_name, 0) + 1

            assert reserved_names_dict[reserved_name] == 1, 'Reserved name %s is listed more than once' % reserved_name


# Generated at 2022-06-21 09:52:23.566856
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == get_reserved_names(True)

# Generated at 2022-06-21 09:52:30.450750
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Make sure we have a list of all the Play attributes
    reserved_names = get_reserved_names()
    expected_names = frozenset([
        'any_errors_fatal',
        'become',
        'delegate_to',
        'environment',
        'gather_facts',
        'gather_subset',
        'handlers',
        'hosts',
        'max_fail_percentage',
        'name',
        'no_log',
        'post_tasks',
        'pre_tasks',
        'roles',
        'serial',
        'tasks',
        'tags',
        'transport',
    ])

    if reserved_names != expected_names:
        # We also need to check for 'new' reserved names
        unexpected = reserved_names - expected_names

# Generated at 2022-06-21 09:52:31.318019
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert_reserved_names('name', loop)


# Generated at 2022-06-21 09:52:41.332716
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:52:42.037402
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('localhost')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:52:50.009170
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''Run through the list of reserved names, adding them to a play and testing that
    they are properly recognized as being reserved.'''

    play = Play()
    play.vars.vars = {}

    # Create a fake inventory containing localhost
    display.debug("Creating fake inventory")
    play.set_loader(None)
    play.set_variable_manager(None)
    play._set_inventory(None)

    # Create a fake play context
    display.debug("Creating fake PlayContext")
    play_context = play.set_play_context(play)

    # Create a fake task
    display.debug("Creating fake Task")
    task = Task()

    display.debug("Generating list of reserved names")
    reserved_names = get_reserved_names()

    for reserved_name in reserved_names:
        display.debug

# Generated at 2022-06-21 09:52:55.151299
# Unit test for function get_reserved_names
def test_get_reserved_names():
    class_list = [Play, Role, Block, Task]
    reserved_names = set()
    for aclass in class_list:
        aobj = aclass()
        reserved_names = reserved_names.union(set(aobj.__dict__['_attributes'].keys()))
    assert get_reserved_names(True) == reserved_names

# Generated at 2022-06-21 09:53:03.818058
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # setup - define vars to test on
    myvars = dict(
        state='present',
        user='joe',
        state_lock='yes',
        connection='network_cli',
        gather_facts='yes',
        deprecate_facts=['user', 'hostname'],
        flush_cache='yes',
        remote_user='john',
        password='123',
        name='joe_test',
        count=5,
        tasks=3,
        debug=False
    )

    # test function
    warn_if_reserved(myvars)

# Generated at 2022-06-21 09:53:25.796313
# Unit test for function get_reserved_names
def test_get_reserved_names():

    result = get_reserved_names()
    assert 'name' in result
    assert 'hosts' in result
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'loop' in result
    assert 'with_' in result
    assert 'remote_user' in result
    assert 'when' in result
    assert 'tags' in result
    assert 'become' in result
    assert 'become_user' in result
    assert 'connection' in result

    result = get_reserved_names(include_private=False)
    assert 'name' in result
    assert 'hosts' in result
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'loop' not in result
    assert 'with_' in result
    assert 'remote_user' in result

# Generated at 2022-06-21 09:53:34.862618
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:53:44.117573
# Unit test for function is_reserved_name
def test_is_reserved_name():
    fail = False
    msg = ''
    name = 'action'
    if not is_reserved_name(name):
        msg = '"%s" not detected as reserved' % name
        fail = True
    name = 'action1'
    if is_reserved_name(name):
        msg = '"%s" detected as reserved' % name
        fail = True
    name = '_action1'
    if is_reserved_name(name):
        msg = '"%s" detected as reserved' % name
        fail = True
    name = 'with_items'
    if not is_reserved_name(name):
        msg = '"%s" not detected as reserved' % name
        fail = True
    name = '_with_items'

# Generated at 2022-06-21 09:53:46.141852
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:53:47.682681
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")
    assert not is_reserved_name("foo")



# Generated at 2022-06-21 09:53:59.089241
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultLib
    from ansible.utils.encrypt import do_encrypt, do_decrypt
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultEditor

    # load some data
    vault_password = 'test_pass'
    unencrypted_data = 'test_secret in plain text'
    vault = VaultLib([])
    unencrypted_data = vault.encrypt(unencrypted_data, vault_password)
    unencrypted_data2 = vault.encrypt(unencrypted_data, vault_password)

    # store to file
    # FIXME: put into a proper tempdir

# Generated at 2022-06-21 09:54:03.257118
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # _RESERVED_NAMES should actually not raise a warning
    warn_if_reserved(_RESERVED_NAMES)

    from ansible.modules import test as t  # noqa

    # should raise a warning
    warn_if_reserved(['test'])

    # should not raise a warning
    warn_if_reserved(['test', 'another'])

    # should not raise a warning
    warn_if_reserved(['not_test'])

# Generated at 2022-06-21 09:54:12.260325
# Unit test for function get_reserved_names
def test_get_reserved_names():

    class Dummy(object):
        _attributes = frozenset(['attribute_not_reserved', 'attribute_reserved', '_attribute_reserved'])


# Generated at 2022-06-21 09:54:15.626191
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    var_passed_dict = {'hosts': 'test_hosts', 'name': 'test_name', 'other_vars': 'test_other_vars'}
    warn_if_reserved(var_passed_dict)

# Generated at 2022-06-21 09:54:18.321397
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved({'action': 'hello'}, set(['action']))
    except Exception as e:
        raise AssertionError('warn_if_reserved raised %r' % e)



# Generated at 2022-06-21 09:54:37.739034
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("vars")
    assert is_reserved_name("tags")
    assert not is_reserved_name("foo")

# Generated at 2022-06-21 09:54:42.383980
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = {'name': 'foo', 'action': 'bar', 'roles': 'baz'}
    warn_if_reserved(vars, set(['name']))

    vars = {'roles': 'foo', 'any_errors_fatal': 'bar', 'name': 'baz'}
    warn_if_reserved(vars, set(['name']))

# Generated at 2022-06-21 09:54:45.003576
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert isinstance(_RESERVED_NAMES, frozenset), "get_reserved_names should return frozenset"
    assert len(_RESERVED_NAMES) > 10, "frozenset should get size of more then 10"

# Generated at 2022-06-21 09:54:47.484907
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_vars = {'hosts': 'all', 'sudo': 'yes'}
    warn_if_reserved(test_vars.keys())



# Generated at 2022-06-21 09:54:49.003251
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['non_reserved']) is None

# Generated at 2022-06-21 09:54:49.978018
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'role_name'])

# Generated at 2022-06-21 09:54:58.114850
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(include_private=False)
    private_names = get_reserved_names(include_private=True)
    assert 'hosts' in public_names
    assert 'hosts' in private_names

    assert 'vars' in public_names
    assert 'vars' in private_names

    assert 'action' in public_names
    assert 'action' in private_names

    assert 'local_action' not in public_names
    assert 'local_action' in private_names

    assert 'loop' not in public_names
    assert 'loop' in private_names

    assert 'with_' not in public_names
    assert 'with_' in private_names

    assert 'name' not in public_names
    assert 'name' in private_names


# Generated at 2022-06-21 09:55:07.856153
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names_with_private = {'any_errors_fatal', 'first_available_file', 'hosts', 'file',
                          'hosts', 'name', 'post_tasks', 'environment', 'roles', 'become',
                          'become_method', 'become_user', 'delegate_to', 'gather_facts',
                          'roles', '_load_name', '_role_params'
                         }


# Generated at 2022-06-21 09:55:18.012336
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Make sure result is a set, and doesn't contain duplicates
    reserved_set = set(get_reserved_names(include_private=True))
    assert isinstance(reserved_set, set)
    assert len(reserved_set) == len(list(reserved_set))

    # Include private
    reserved = sorted(get_reserved_names(include_private=True))

# Generated at 2022-06-21 09:55:23.240409
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # create a dictionary with a few incorrect names
    # test_a is a valid name, test_b is not
    dict = dict(test_a=1, test_b=2, test_c=3)

    # The warn_if_reserved function should return an array with one warning
    warns = warn_if_reserved(dict)
    assert len(warns) == 1

    # The warn_if_reserved function should return an array with one warning
    warns = warn_if_reserved(dict.copy(), ['ping'])
    assert len(warns) == 2

# Generated at 2022-06-21 09:55:49.442519
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest
    assert isinstance(_RESERVED_NAMES, frozenset)

    a_play_vars_dict = {'roles': 'foo'}
    warn_if_reserved(a_play_vars_dict)
    a_play_vars_dict['vars'] = {}
    warn_if_reserved(a_play_vars_dict)

    a_play_vars_dict['vars']['roles'] = 'foo'
    with pytest.raises(SystemExit):
        warn_if_reserved(a_play_vars_dict)
    a_play_vars_dict['vars']['roles'] = ['foo', 'bar']

# Generated at 2022-06-21 09:55:58.278396
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:56:04.861083
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function makes sure that we have all names reserved
    '''


# Generated at 2022-06-21 09:56:15.025769
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys

    display.verbosity = 4
    testvars = ['vars', 'include', 'loop', 'playbook_dir', 'playbook_file', 'name', 'hosts', 'roles', 'action', 'block', 'role', 'roles_path',
                'version', 'tags', 'tasks', 'handler', 'handlers', 'connection', 'gather_facts']
    # sanity check that we have something to test
    assert(len(testvars) > 1)
    saved_display = display.display
    saved_stderr = sys.stderr

# Generated at 2022-06-21 09:56:21.560292
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import unittest

    class TestWarnIfReserved(unittest.TestCase):

        def test_empty(self):
            warn_if_reserved({})

        def test_normal_name(self):
            warn_if_reserved({'foo': 'a'})

        def test_reserved_name(self):
            warn_if_reserved({'name': 'a'})
            warn_if_reserved({'block': 'a'})

        def test_normal_and_reserved_name(self):
            warn_if_reserved({'foo': 'a', 'name': 'a'})
            warn_if_reserved({'foo': 'a', 'block': 'a'})

    unittest.main()

# Generated at 2022-06-21 09:56:31.730302
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['hosts', 'username', 'vars']

    # check basic functionality
    import ansible.playbook.play_context
    ansible.playbook.play_context.warn_if_reserved(myvars)

    # check with additional reserved names
    myvars.append('roles')
    ansible.playbook.play_context.warn_if_reserved(myvars, additional=set(['roles']))
    myvars.append('tasks')
    try:
        ansible.playbook.play_context.warn_if_reserved(myvars)
    except SystemExit:
        pass
    except Exception as e:
        raise AssertionError("Unexpected exception raised: %s" % e)
    else:
        raise AssertionError("Exception not raised as expected")

# Generated at 2022-06-21 09:56:38.291426
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    dummy_vars = ['vars', 'inventory', 'playbook', 'connection',
                  'include', 'include_role', 'roles', 'run_once',
                  'tasks', 'gather_facts', 'pre_tasks', 'post_tasks',
                  'vars_files', 'handlers', 'name']

    warn_if_reserved(dummy_vars)

    # Make sure that warn_if_reserved does not throw an error
    # if there are no reserved names
    dummy_vars.extend(["something", "something_else"])
    warn_if_reserved(dummy_vars)

# Generated at 2022-06-21 09:56:43.649393
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)

    # since we create a reserved_names list, the length should
    # not change with changes to code, so this test is a bit brittle
    # if the code changes and the length changes, should consider
    # updating this test to reflect the new length, or if the list
    # is longer, consider changing the code to stop returning
    # non-reserved names
    assert len(get_reserved_names()) == 308



# Generated at 2022-06-21 09:56:51.449362
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('description')
    assert is_reserved_name('connection')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('when')
    assert is_reserved_name('local_action')
    assert is_reserved_name('tags')
    assert is_reserved_name('failed_when')
    assert is_reserved_name('ignore_errors')

    assert not is_reserved_name('blah')

# Generated at 2022-06-21 09:56:54.336089
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('role') == True, 'role should be a reserved name'
    assert is_reserved_name('foobar') == False, 'foobar should not be a reserved name'

# Generated at 2022-06-21 09:57:19.998564
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    warn_if_reserved({'hosts': 'default'})  # default variable
    warn_if_reserved({'host': 'default'})  # default variable
    warn_if_reserved({'hosts': 'default', 'task1': 'task1'})  # default variable
    warn_if_reserved({'host': 'default', 'task1': 'task1'})  # default variable
    warn_if_reserved({'tasks': 'tasks1'})  # reserved by play
    warn_if_reserved({'roles': 'roles1'})  # reserved by play
    warn_if_reserved({'name': 'name1'})  # reserved by play

# Generated at 2022-06-21 09:57:21.639275
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserveds = _RESERVED_NAMES
    assert reserveds and 'hosts' in reserveds



# Generated at 2022-06-21 09:57:25.587458
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES == frozenset(['any_errors_fatal', 'any_errors_fatal', 'become', 'become_user', 'delegate_to', 'notify', 'roles', 'roles', 'tags', 'tags', 'when'])


# Generated at 2022-06-21 09:57:30.357825
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = dict(
        action='test',
        first_var='foo',
        second_var='bar',
        vars=dict(
            test='test'
        )
    )
    warn_if_reserved(myvars)
    warn_if_reserved(myvars, additional=['additional', 'second_var'])



# Generated at 2022-06-21 09:57:37.204274
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'vars': {'yes': 'please'}}) == None
    assert warn_if_reserved({'vars': {'pre_tasks': {'name': 'please'}}}) == None
    assert warn_if_reserved({'vars': {'with_': {'name': 'please'}}}) == None
    assert warn_if_reserved({'vars': {'playbook_dir': {'name': 'please'}}}) == None
    assert warn_if_reserved({'vars': {'post_tasks': {'name': 'please'}}}) == None
    assert warn_if_reserved({'vars': {'post_vars': {'name': 'please'}}}) == None

# Generated at 2022-06-21 09:57:39.215541
# Unit test for function get_reserved_names
def test_get_reserved_names():

    for item in _RESERVED_NAMES:
        if item in get_reserved_names():
            assert True
        else:
            assert False



# Generated at 2022-06-21 09:57:44.012195
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('hosts')
    assert is_reserved_name('ignore_errors')
    assert is_reserved_name('register')
    assert is_reserved_name('tags')
    assert is_reserved_name('tasks')
    assert is_reserved_name('vars')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_') is True
    assert is_reserved_name('become_user') is True
    assert is_reserved_name('become') is True
    assert is_reserved_name('become_method') is True
    assert is_reserved_name('z_custom_attribute') is False

# Generated at 2022-06-21 09:57:47.798647
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = frozenset(['action', 'arguments', 'delegate_to', 'failed_when',
                          'ignore_errors', 'name', 'notify', 'register', 'retries',
                          'run_once', 'tags', 'until', 'when', 'when_file_exists'])
    assert warn_if_reserved(['action', 'name'], reserved) is None

# Generated at 2022-06-21 09:57:50.958481
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    vars = {'playbook_dir': None, 'inventory_dir': None}
    additional = set(['loop', 'with_', 'local_action', 'action'])

    warn_if_reserved(vars, additional)

# Generated at 2022-06-21 09:57:58.912909
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    myvars = ['vars', 'delegate_to', 'register', 'tags']
    warn_if_reserved(myvars)

    myvars = ['action', 'tags']
    warn_if_reserved(myvars)

    myvars = ['local_action']
    warn_if_reserved(myvars)

    myvars = ['notify']
    warn_if_reserved(myvars)

    myvars = ['loop']
    warn_if_reserved(myvars)

    myvars = ['with_']
    warn_if_reserved(myvars)

    myvars = ['the_name_of_a_host', 'hosts']
    warn_if_reserved(myvars)

    myvars = ['host']
    warn_if