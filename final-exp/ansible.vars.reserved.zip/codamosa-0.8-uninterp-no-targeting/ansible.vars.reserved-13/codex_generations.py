

# Generated at 2022-06-21 09:48:30.048485
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # find out if warning occurs on two reserved names and two that are not
    try:
        warn_if_reserved(['hosts','roles','foo','bar'])
        assert False, "Should have failed, 'hosts' and 'roles' are reserved names"
    except AssertionError as e:
        raise
    except:
        assert True

    # find out if warning occurs on one reserved name and three that are not
    try:
        warn_if_reserved(['foo','bar','baz','roles'])
        assert False, "Should have failed, 'roles' is a reserved name"
    except AssertionError as e:
        raise
    except:
        assert True

    # find out if warning occurs on one reserved name and three that are not

# Generated at 2022-06-21 09:48:37.127249
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Check if return value is the same as the list of reserved names from the code
    assert _RESERVED_NAMES == frozenset(['become', 'become_user', 'delegate_to', 'environment', 'gather_facts', 'hosts', 'ignore_errors', 'name', 'roles', 'sudo', 'sudo_user', 'tags', 'tasks', 'vars', 'vars_prompt', 'vars_files', 'include', 'include_tasks', 'include_role', 'include_vars', 'action', 'local_action', 'with_', 'meta', 'pre_tasks', 'post_tasks', 'any_errors_fatal', 'serial', 'connection', 'block', 'when', 'notify']), "The list of reserved names does not match"

# Generated at 2022-06-21 09:48:41.244192
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This test is a simple smoke test that ensures get_reserved_names
    # returns a list of strings. It does not test for any specific value.

    reserved = get_reserved_names()
    assert isinstance(reserved, set)
    for name in reserved:
        assert isinstance(name, str)

# Generated at 2022-06-21 09:48:42.957296
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'name', 'when', 'with_items'})

# Unit tests for function get_reserved_names

# Generated at 2022-06-21 09:48:54.301819
# Unit test for function is_reserved_name
def test_is_reserved_name():
    fail_list = ['add_host', 'async', 'become', 'become_user', 'become_method', 'connection', 'delegate_to', 'environment', 'failed_when', 'ignore_errors', 'name', 'no_log', 'notify', 'poll', 'register', 'remote_user', 'retries', 'run_once', 'sudo', 'sudo_user', 'when', 'with_items', 'with_dict', 'with_first_found', 'with_lines', 'with_subelements', 'with_together', 'with_sequence', 'with_fileglob', 'with_nested', 'with_random_choice', 'with_loop']
    for name in fail_list:
        assert is_reserved_name(name), '%s not recognized as a reserved name' % name

# Generated at 2022-06-21 09:48:57.397447
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'action', 'sudo', 'sudo_password', 'register', 'delegate_to', 'run_once', 'any_errors_fatal'], additional=set())

# Generated at 2022-06-21 09:49:01.681575
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['oops'])
    warn_if_reserved(['remote_user'])
    warn_if_reserved(['hosts'])
    warn_if_reserved(['hosts', 'oops'])

    try:
        warn_if_reserved(['hosts'], [])
    except Exception as e:
        assert False


# Generated at 2022-06-21 09:49:07.775431
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Ensure that each of the reserved names are returned
    list_reserved_names = get_reserved_names()
    for reserved_name in _RESERVED_NAMES:
        assert reserved_name in list_reserved_names

    # Ensure that no other names are returned for the default case
    assert len(_RESERVED_NAMES) == len(list_reserved_names)

    # Ensure that the 'internal' attributes are returned with the private flag
    private_reserved_names = get_reserved_names(include_private=True)
    assert len(_RESERVED_NAMES) < len(private_reserved_names)

    # Ensure that the 'public' attributes are returned without the private flag
    public_reserved_names = get_reserved_names(include_private=False)

# Generated at 2022-06-21 09:49:16.555220
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test base case
    assert _RESERVED_NAMES == {'async', 'connection', 'delegate_to', 'environment', 'ignore_errors',
                              'local_action', 'loop', 'notify', 'register', 'remote_user', 'run_once',
                              'sudo', 'sudo_user', 'tags', 'until', 'with_plugins', 'with_items', 'when'}

    # test flag for including private
    assert get_reserved_names(include_private=False) == {'async', 'connection', 'delegate_to', 'environment', 'ignore_errors',
                                                         'local_action', 'notify', 'register', 'remote_user', 'run_once',
                                                         'sudo', 'sudo_user', 'tags', 'until', 'with_items', 'when'}



# Generated at 2022-06-21 09:49:17.308190
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'tags' in reserved

# Generated at 2022-06-21 09:49:36.219922
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('not_a_reserved_name')

# Generated at 2022-06-21 09:49:38.041466
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert (set(['gather_facts', 'name', 'hosts']) == get_reserved_names(False))

# Generated at 2022-06-21 09:49:49.257146
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # First check public only
    public = get_reserved_names(include_private=False)
    assert(public)
    assert('gather_facts' in public)
    assert('action' in public)
    assert('local_action' in public)
    assert('register' in public)
    assert('hosts' in public)
    assert('no_log' in public)
    assert('sudo' in public)
    assert('sudo_user' in public)

    # Now check private only
    private = get_reserved_names(include_private=True) - public
    assert(private)
    assert('vars_files' in private)
    assert('vars_prompt' in private)
    assert('any_errors_fatal' in private)
    assert('serial' in private)

# Generated at 2022-06-21 09:49:56.332090
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name("include"))
    assert(is_reserved_name("when"))
    assert(is_reserved_name("with_items"))
    assert(is_reserved_name("become"))
    assert(is_reserved_name("become_user"))
    assert(is_reserved_name("name"))
    assert(is_reserved_name("any_errors_fatal"))

# Generated at 2022-06-21 09:50:00.483405
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    varlist = ['roles', 'roles_path', 'gather_facts', 'hosts', 'action', 'local_action', 'delegate_to', 'with_', 'loop', 'environment']
    warn_if_reserved(varlist)

# Generated at 2022-06-21 09:50:11.511383
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils.six import PY3
    variable_dicts = [{'role_name': 'test', 'name': 'test'}, {'role_name': 'test', 'name': 'test', 'vars': 'test'},
                      {'roles': 'test'}]

    for variable in variable_dicts:
        if PY3:
            try:
                warn_if_reserved(variable)
            except SystemExit:
                pass
            else:
                assert False, 'warn_if_reserved did not raise SystemExit'

        else:
            try:
                warn_if_reserved(variable)
            except SystemExit:
                pass
            else:
                assert False, 'warn_if_reserved did not raise SystemExit'


# Generated at 2022-06-21 09:50:18.433615
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name(u'vars') is False
    assert is_reserved_name(u'action') is True
    assert is_reserved_name(u'local_action') is True
    assert is_reserved_name(u'any_errors_fatal') is True
    assert is_reserved_name(u'private') is False
    assert is_reserved_name(u'private_action') is True

# Generated at 2022-06-21 09:50:19.333712
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')

# Generated at 2022-06-21 09:50:22.310892
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert is_reserved_name('loop')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert not is_reserved_name('name')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-21 09:50:28.882906
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleUnicode
    play_ds = AnsibleBaseYAMLObject()
    play_ds.vars = {'vars': AnsibleUnicode('test'), 'action': AnsibleUnicode('test'), 'private': AnsibleUnicode('test')}
    warn_if_reserved(play_ds.vars)

# Generated at 2022-06-21 09:50:56.822582
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function only tests get_reserved_names(), not warn_if_reserved(). '''

    # In this function we get the list of reserved names, and then check for the existence of the
    # most common names for each object type.  These are not 100% guaranteed to be correct.
    # They are a representation of the common names that were found in Ansible, and can be added to
    # over time.  The purpose is to catch any new names that are defined in Ansible and do not
    # conflict with existing reserved names.

    reserved = get_reserved_names()

    play_names = frozenset(['name', 'hosts', 'vars', 'roles', 'tasks'])
    assert(play_names.intersection(reserved))

    role_names = frozenset(['name', 'tasks'])
   

# Generated at 2022-06-21 09:51:05.663160
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This test assumes the default config settings
    assert _RESERVED_NAMES == frozenset(['connection',
                                         'delegate_to',
                                         'gather_facts',
                                         'ignore_errors',
                                         'local_action',
                                         'no_log',
                                         'notify',
                                         'poll',
                                         'priority',
                                         'remote_user',
                                         'register',
                                         'retries',
                                         'run_once',
                                         'serial',
                                         'sudo',
                                         'sudo_user',
                                         'tags',
                                         'transport',
                                         'until',
                                         'when',
                                         'with_'])

# Generated at 2022-06-21 09:51:08.841349
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert not is_reserved_name('loop')

# Utility function for use in tests

# Generated at 2022-06-21 09:51:12.877598
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext

    pc = PlayContext()
    warn_if_reserved(pc._attributes)

# Generated at 2022-06-21 09:51:16.658192
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = ['vars', 'any_other_var']
    warn_if_reserved(vars)
    vars.append('vars_files')
    warn_if_reserved(vars)
    vars.append('name')
    warn_if_reserved(vars)

# Generated at 2022-06-21 09:51:24.778768
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(False)
    private = get_reserved_names(True)

    assert 'name' in public
    assert 'name' in private

    assert 'include' in public
    assert 'include' in private

    assert 'action' in public
    assert 'action' in private

    assert 'local_action' in private
    assert 'local_action' not in public

    assert 'vars' in private
    assert 'vars' not in public

    assert 'with_' in private
    assert 'with_' not in public

    assert 'loop' in private
    a

# Generated at 2022-06-21 09:51:33.723894
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print(get_reserved_names())
    assert get_reserved_names(include_private=False) == frozenset(('vars', 'roles', 'tasks', 'post_tasks', 'pre_tasks', 'handlers', 'block', 'block_rescue', 'block_always', 'name', 'any_errors_fatal', 'fail_when', 'delegate_to', 'local_action', 'run_once', 'action', 'syslog', 'with_'))

# Generated at 2022-06-21 09:51:34.986046
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['roles', 'action', 'loop', 'new_var'])

# Generated at 2022-06-21 09:51:36.781035
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') == True
    assert is_reserved_name('xyz_name') == False

# Generated at 2022-06-21 09:51:45.194189
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(True) == set(['vars', 'name', 'register', 'ignore_errors', 'when', 'delegate_to', 'connection', 'any_errors_fatal', 'gather_facts', 'tags', 'roles', 'tasks', 'block', 'handlers', 'pre_tasks', 'post_tasks', 'include', 'private', 'meta', 'notify', 'always_run', 'local_action', 'fatal', 'with_', 'delegated_vars', 'run_once', 'hosts', 'run_once'])

# Generated at 2022-06-21 09:52:40.907287
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts', 'name'])

# Generated at 2022-06-21 09:52:47.212696
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.vars import warn_if_reserved

    # Assert that reserved names are caught
    myvars = {'name': 'localhost',
              'tasks': []}
    warn_if_reserved(myvars)

    # Assert that additional names are caught
    myvars = {'name': 'localhost',
              'tasks': [],
              'original_name': 'localhost',
              'some_other_name': 'localhost'}
    warn_if_reserved(myvars, additional=['original_name', 'some_other_name'])

# Generated at 2022-06-21 09:52:48.499541
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')



# Generated at 2022-06-21 09:52:50.796345
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)

    assert not is_reserved_name('foo')
    assert not is_reserved_name('__foo__')

# Generated at 2022-06-21 09:52:53.425395
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['when', 'roles', 'block', 'loop'])


# unit test for function get_reserved_names

# Generated at 2022-06-21 09:52:58.678121
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # get current reserved names list
    reserved = _RESERVED_NAMES

    # add new names
    Play.add_ni_attribute('new_name')
    Play.add_ni_attribute('second_new_name')

    # add private names
    Play.add_ni_attribute('new_private', private=True)
    Play.add_ni_attribute('second_private', private=True)

    new_names_set = frozenset(('new_name', 'second_new_name'))
    new_private_set = frozenset(('new_private', 'second_private'))

    # Test that the new public names are added
    assert new_names_set.issubset(set(get_reserved_names()))

# Generated at 2022-06-21 09:53:03.694539
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('become_user') == True
    assert is_reserved_name('when') == True
    assert is_reserved_name('gather_facts') == False
    assert is_reserved_name('anything') == False



# Generated at 2022-06-21 09:53:11.447488
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_public_only = set(['name', 'hosts', 'gather_facts', 'connection', 'sudo', 'sudo_user',
                                'remote_user', 'transport', 'any_errors_fatal', 'serial', 'max_fail_percentage',
                                'any_errors_fatal', 'notify', 'vars', 'vars_files', 'handlers', 'pre_tasks', 'post_tasks',
                                'include', 'include_vars', 'include_role', 'local_action', 'with_', 'block'])


# Generated at 2022-06-21 09:53:20.459218
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Unit test for function get_reserved_names '''

    assert get_reserved_names(include_private=False) == frozenset(['action', 'post_tasks', 'pre_tasks', 'name', 'serial', 'hosts', 'tags', 'gather_facts', 'vars', 'any_errors_fatal', 'local_action', 'with_'])
    assert 'name' in get_reserved_names(include_private=False)
    assert 'when' not in get_reserved_names(include_private=False)
    assert 'when' in get_reserved_names(include_private=True)

# Generated at 2022-06-21 09:53:22.197988
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = [ 'foo', 'bar', 'vars' ]
    warn_if_reserved(myvars)


# Generated at 2022-06-21 09:55:00.144861
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('become')
    assert is_reserved_name('delegate_to')
    assert not is_reserved_name('xyz')
    assert not is_reserved_name('task_name')
    assert not is_reserved_name('task')

# Generated at 2022-06-21 09:55:09.820564
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.unit_test import TestCase as unitTest

    write_handle = unitTest()


# Generated at 2022-06-21 09:55:11.147523
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['action', 'inventory', 'become']) != None

# Generated at 2022-06-21 09:55:13.625219
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('vars')
    assert is_reserved_name('action')



# Generated at 2022-06-21 09:55:17.424236
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert "tags" in get_reserved_names()
    assert "private" in get_reserved_names()
    assert "private" not in get_reserved_names(include_private=False)

# Generated at 2022-06-21 09:55:22.220153
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert isinstance(names, set)
    assert all(isinstance(n, str) for n in names)
    assert 'any_errors_fatal' in names
    assert 'become' in names
    assert 'become_user' in names
    assert 'delegate_to' in names
    assert not is_reserved_name('foo')
    assert not is_reserved_name('action')


# Generated at 2022-06-21 09:55:31.359805
# Unit test for function is_reserved_name
def test_is_reserved_name():

    reserved_names = get_reserved_names()

    # Test basic names
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')

    # Test private names
    assert is_reserved_name('remote_user')
    assert is_reserved_name('loop')

    # Test non reserved names
    assert not is_reserved_name('non_reserved_name')
    assert not is_reserved_name('random_variable')

# Generated at 2022-06-21 09:55:33.430455
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)
    assert get_reserved_names() == _RESERVED_NAMES


# Generated at 2022-06-21 09:55:36.323566
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(["vars"])
    warn_if_reserved(["vars", "action"])
    warn_if_reserved(["vars", "action", "name"])
    warn_if_reserved(["vars", "action", "name", "private"])


# Generated at 2022-06-21 09:55:37.869281
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('section')