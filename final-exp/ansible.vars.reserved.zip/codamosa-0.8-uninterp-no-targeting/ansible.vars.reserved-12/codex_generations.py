

# Generated at 2022-06-21 09:48:30.862293
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test for a regular reserved name
    assert is_reserved_name('name') == True

    # Test for a name that can't be a reserved name
    assert is_reserved_name('my_var_name') == False

    # Test for a name that is only a reserved name because it's the name of a
    # task action
    assert is_reserved_name('local_action') == True

# Generated at 2022-06-21 09:48:33.479385
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("action")
    assert is_reserved_name("private")
    assert not is_reserved_name("zippity")
    assert not is_reserved_name("name")



# Generated at 2022-06-21 09:48:41.974233
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test for reserved names '''

    class FooPlay:
        _attributes = frozenset(['fake_play1', 'fake_play2', 'fake_play3'])

    expected_public = set()
    expected_private = set(['fake_play2'])
    expected_all = set(['fake_play1', 'fake_play2', 'fake_play3'])

    actual_public = get_reserved_names(include_private=False)
    actual_private = get_reserved_names(include_private=True)

    assert expected_public == actual_public
    assert expected_private == actual_private
    assert expected_all == actual_private

# Generated at 2022-06-21 09:48:44.734231
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)
        assert is_reserved_name('foo' + name + 'bar')

# Generated at 2022-06-21 09:48:52.198087
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # First test reserved words
    warn_if_reserved(["hosts", "tasks", "vars", "name"])
    # No error (as display.warning is a no-op)

    # Test additional words
    warn_if_reserved(["hosts", "name"], ["myvar"])
    # No error (as display.warning is a no-op)

    # Test no warnings
    warn_if_reserved(["name"])
    # No error (as display.warning is a no-op)

# Generated at 2022-06-21 09:48:53.573386
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')



# Generated at 2022-06-21 09:48:56.280216
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert len(get_reserved_names()) > 0
    assert len(get_reserved_names(include_private=False)) > 0
    assert is_reserved_name('hosts')

# Generated at 2022-06-21 09:49:04.618412
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('any_children') is True
    assert is_reserved_name('any_errors') is True
    assert is_reserved_name('any_failed') is True
    assert is_reserved_name('any_unreachable') is True
    assert is_reserved_name('any_ok') is True
    assert is_reserved_name('all_ok') is True
    assert is_reserved_name('all_hosts') is True
    assert is_reserved_name('no_hosts') is True

    assert is_reserved_name('hosts') is True
    assert is_reserved_name('hosts_all') is True
    assert is_reserved_name('hosts_as') is True
    assert is_reserved_name('hosts_and_children') is True

# Generated at 2022-06-21 09:49:12.714676
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    myvars = {'action': 1, 'other': 2, 'vars': 2, 'yup': 'something'}

    # this should not display any warnings
    warn_if_reserved(myvars)

    myvars = {'roles': 3, 'vars': 2, 'my_role': 4}

    # this should display a warning
    warn_if_reserved(myvars)

    myvars = {'roles': 3, 'vars': 2, 'my_role': 4}

    # this should not display a warning
    warn_if_reserved(myvars, additional=set(['roles']))

# Generated at 2022-06-21 09:49:13.598931
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:49:31.521106
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('foobar')



# Generated at 2022-06-21 09:49:42.536475
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import yaml

    # This test method will read the reserved names from the Ansible code
    # (this method) and the test data, and compare the two and if there
    # is any discrepancy then show the error message

    # The reserved names are maintained in this file. If a variable
    # is introduced that conflicts with the reserved names, then add
    # the variable name to this test file so that the variable name
    # gets added to the reserved names list in the code

    # The test data format is a yaml list of strings. Each string
    # is a reserved variable name.

    # The test data file is in the test/units/utils/test_reserved_names.yaml
    # and it is generated from the test data files in
    # lib/ansible/core/test/units/reserved_names_*/ with the script
    # bin/

# Generated at 2022-06-21 09:49:44.642265
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['arguments', 'hosts', 'remote_user'], ['vars'])

# Generated at 2022-06-21 09:49:53.746007
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    import io

    if sys.version_info < (2, 6):
        return

    warn_if_reserved(['vars'])

    # Test that warning is printed when reserved word is used as a variable
    try:
        stdout = sys.stdout
        sys.stdout = io.StringIO()

        warn_if_reserved(['hosts'])
        output = sys.stdout.getvalue()
        assert 'Found variable using reserved name: hosts' in output
    finally:
        sys.stdout = stdout

    # Test that no warning is printed when reserved word is not used as a variable

# Generated at 2022-06-21 09:50:04.908195
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    from mock import patch


# Generated at 2022-06-21 09:50:10.051900
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for varname in _RESERVED_NAMES:
        assert is_reserved_name(varname)
    assert not is_reserved_name('foo_bar')
    assert not is_reserved_name('foo bar')
    #assert not is_reserved_name('foo.bar')  # FIXME: this should be passed

# Generated at 2022-06-21 09:50:16.823437
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = _RESERVED_NAMES
    # Given
    not_reserved_name = 'not_reserved_name'

    # Should not raise exception
    try:
        # When
        is_reserved_name(not_reserved_name)
    except:
        assert False, "Should not raise exception because '{}' is not reserved".format(not_reserved_name)


# Generated at 2022-06-21 09:50:27.279674
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_reserved = get_reserved_names(False)
    assert 'include' in public_reserved, "include should be in list of reserved names without private"
    assert 'roles' in public_reserved, "roles should be in list of reserved names without private"
    assert 'block' in public_reserved, "block should be in list of reserved names without private"
    assert 'vars_files' in public_reserved, "vars_files should be in list of reserved names without private"
    assert 'register' in public_reserved, "register should be in list of reserved names without private"

    private_reserved = get_reserved_names(True)
    assert 'java_home' in private_reserved, "java_home should be in list of reserved names including private"
    assert 'java_opts' in private_

# Generated at 2022-06-21 09:50:28.880642
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)



# Generated at 2022-06-21 09:50:31.695051
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('not_reserved')



# Generated at 2022-06-21 09:50:48.538857
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test default
    result = get_reserved_names()

# Generated at 2022-06-21 09:50:59.164839
# Unit test for function get_reserved_names
def test_get_reserved_names():
    r = get_reserved_names()
    assert 'name' in r, 'name missing from reserved names'
    assert 'action' in r, 'action missing from reserved names'
    assert 'serial' in r, 'serial missing from reserved names'
    assert 'roles' in r, 'roles missing from reserved names'
    assert 'delegate_to' in r, 'delegate_to missing from reserved names'
    assert 'connection' in r, 'connection missing from reserved names'
    assert 'become' in r, 'become missing from reserved names'
    assert 'become_user' in r, 'become_user missing from reserved names'
    assert 'become_method' in r, 'become_method missing from reserved names'
    assert 'hosts' in r, 'hosts missing from reserved names'

# Generated at 2022-06-21 09:51:08.760371
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_reserved = get_reserved_names(include_private=False)

    assert 'action' in public_reserved
    assert 'local_action' in public_reserved
    assert 'with_' in public_reserved

    assert 'any_errors_fatal' in public_reserved
    assert 'become' in public_reserved
    assert 'become_user' in public_reserved
    assert 'block' in public_reserved
    assert 'changed_when' in public_reserved
    assert 'check_mode' in public_reserved
    assert 'connection' in public_reserved
    assert 'failed_when' in public_reserved
    assert 'gather_facts' in public_reserved
    assert 'hosts' in public_reserved
    assert 'name' in public_reserved

# Generated at 2022-06-21 09:51:16.113663
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for get_reserved_names '''

    result = get_reserved_names()
    assert 'hosts' in result
    assert 'roles' not in result
    assert 'private_roles' in result

    result = get_reserved_names(include_private=False)
    assert 'hosts' in result
    assert 'roles' not in result
    assert 'private_roles' not in result



# Generated at 2022-06-21 09:51:22.321114
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True).difference(public)

    assert public == frozenset({'hosts', 'roles', 'tasks', 'vars', 'name', 'action', 'meta', 'local_action'})
    assert private == frozenset({'connection', 'serial', 'delegate_to', 'gather_facts', 'become',
                                 'become_method', 'become_user', 'environment', 'sudo', 'sudo_user',
                                 'tags', 'remote_user', 'tasks_from', 'ignore_errors', 'loop', 'when'})

# Generated at 2022-06-21 09:51:25.760996
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_name = 'name'
    assert is_reserved_name(reserved_name)
    none_reserved_name = 'test'
    assert not is_reserved_name(none_reserved_name)



# Generated at 2022-06-21 09:51:27.260020
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-21 09:51:28.015490
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert isinstance(_RESERVED_NAMES, frozenset)



# Generated at 2022-06-21 09:51:35.573394
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    class MockDisplay:
        def __init__(self):
            self.warnings = []

        def warning(self, msg):
            self.warnings.append(msg)

    myvars = ['hosts', 'roles', 'tasks', 'vars', 'name', 'action', 'local_action', 'loop', 'with_', 'meta']
    myvars = ['hosts', 'roles', 'tasks', 'vars', 'name', 'action', 'local_action', 'loop', 'with_', 'meta', 'block']
    md = MockDisplay()
    # change the global display object for testing
    global display
    display = md

    warn_if_reserved(myvars)

    assert len(md.warnings) == 9, "expected to see warning on 9 variables"
    # make sure all of

# Generated at 2022-06-21 09:51:42.017251
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check that the list does not contain duplicates
    assert len(get_reserved_names()) == len(set(get_reserved_names()))

    # Check that the list contains all expected names
    assert get_reserved_names().issuperset(['roles', 'connection', 'sudo_flags', 'gather_facts', 'tags'])

    # Check that we get the same list when not including private
    assert get_reserved_names() == get_reserved_names(include_private=True)



# Generated at 2022-06-21 09:52:21.486529
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # should return a list
    assert isinstance(get_reserved_names(), set)

    # should have a length of at least 20
    assert len(get_reserved_names()) >= 20
    assert len(get_reserved_names(include_private=False)) >= 15

    # should contain name, debug
    assert 'name' in get_reserved_names()
    assert 'debug' in get_reserved_names()

    # should contain a bunch of others
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()

# Generated at 2022-06-21 09:52:29.373695
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' Unit test for function is_reserved_name '''
    from nose.tools import assert_true, assert_false

    assert_true(is_reserved_name('hosts'))
    assert_true(is_reserved_name('name'))
    assert_true(is_reserved_name('any_errors_fatal'))
    assert_true(is_reserved_name('local_action'))
    assert_true(is_reserved_name('with_'))
    assert_true(is_reserved_name('with_fileglob'))
    assert_true(is_reserved_name('include'))

    assert_false(is_reserved_name('foo'))
    assert_false(is_reserved_name('vars'))

# Generated at 2022-06-21 09:52:30.785613
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:52:31.639910
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('gather_facts')

# Generated at 2022-06-21 09:52:40.128807
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' make sure get_reserved_names function returns expected reserved names'''
    expected_names = frozenset(['name', 'register', 'delegate_to', 'local_action', 'connection', 'when',
                                'any_errors_fatal', 'become', 'become_user', 'become_method', 'become_flags',
                                'become_exe', 'become_info', 'check_mode', 'serial', 'tags', 'until', 'failed_when',
                                'ignore_errors'])
    assert(get_reserved_names() > expected_names)
    assert(get_reserved_names(include_private=False) == expected_names)

# Generated at 2022-06-21 09:52:41.587764
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts': 'foo'}, additional=set())

# Generated at 2022-06-21 09:52:49.665479
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('loop')
    assert is_reserved_name('include_role')
    assert is_reserved_name('include')
    assert is_reserved_name('import_role')
    assert is_reserved_name('import_tasks')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('when')

# Generated at 2022-06-21 09:53:01.446633
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'import_playbook' not in get_reserved_names()
    assert 'private' not in get_reserved_names()

    assert 'hosts' in get_reserved_names(include_private=True)
    assert 'action' in get_reserved_names(include_private=True)
    assert 'local_action' in get_reserved_names(include_private=True)
    assert 'loop' in get_reserved_names(include_private=True)
    assert 'private' in get_reserved_names(include_private=True)


# Unit test

# Generated at 2022-06-21 09:53:08.036385
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test public names only
    expected_names = ['become', 'become_user', 'connection', 'delegate_to', 'environment', 'gather_facts', 'hosts', 'ignore_errors', 'import_role', 'no_log', 'post_tasks', 'pre_tasks', 'roles', 'run_once', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'vars', 'with_items', 'with_subelements', 'when']
    reserved_names = get_reserved_names(include_private=False)
    assert set(expected_names).issubset(reserved_names)
    assert 'register' in reserved_names  # private attribute

    # Test public and private names

# Generated at 2022-06-21 09:53:13.054624
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('role_path') is True)
    assert(is_reserved_name('name') is True)
    assert(is_reserved_name('action') is True)
    assert(is_reserved_name('local_action') is True)
    assert(is_reserved_name('with_') is True)
    assert(is_reserved_name('become_user') is False)



# Generated at 2022-06-21 09:54:01.301947
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('include_role')
    assert is_reserved_name('import_playbook')
    assert is_reserved_name('when')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('vars')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:54:09.722817
# Unit test for function get_reserved_names
def test_get_reserved_names():
    display.vvv('RESERVED NAMES: %s' % get_reserved_names())

    # make sure the list contains no duplicates
    reserved_list = list(get_reserved_names())
    if len(reserved_list) != len(set(reserved_list)):
        display.warning('list contains duplicates')
        return False

    # make sure the list does not contain any new items
    if len(reserved_list) != len(get_reserved_names(include_private=False)):
        display.warning('list contains items that are not public names')
        return False

    # make sure there are no extra public items
    if len(reserved_list) != len(get_reserved_names()):
        display.warning('list contains items that are not reserved names')
        return False

    return

# Generated at 2022-06-21 09:54:13.218915
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') == True
    assert is_reserved_name('local_action') == True
    assert is_reserved_name('with_') == True
    assert is_reserved_name('with_first_found') == True
    assert is_reserved_name('loop') == True

# Generated at 2022-06-21 09:54:16.397549
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: needs to compare results to actual class attributes
    try:
        names = get_reserved_names()
        display.debug(names)
    except Exception as e:
        display.error(e)

    assert names is not None

# Generated at 2022-06-21 09:54:25.150410
# Unit test for function is_reserved_name

# Generated at 2022-06-21 09:54:28.402359
# Unit test for function is_reserved_name
def test_is_reserved_name():
    '''
    Test if the function is_reserved_name is returning the expected output.
    '''
    for name in _RESERVED_NAMES:
        assert(is_reserved_name(name))

    assert(not is_reserved_name("not_a_reserved_name"))

# Generated at 2022-06-21 09:54:34.626415
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('host') is True
    assert is_reserved_name('vars') is True
    assert is_reserved_name('vars_files') is True
    assert is_reserved_name('tags') is True
    assert is_reserved_name('gather_facts') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('action') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('become') is True
    assert is_reserved_name('become_user') is True
    assert is_reserved_name('become_method') is True
    assert is_reserved_name('import_role')

# Generated at 2022-06-21 09:54:38.675261
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('include')
    assert is_reserved_name('register')
    assert is_reserved_name('vars')
    assert not is_reserved_name('name')
    assert not is_reserved_name('_test')

# Generated at 2022-06-21 09:54:44.969653
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function returns the set of reserved names.
    '''

    result = {"hosts", "name", "tags", "gather_facts", "vars", "delegate_to", "connection", "any_errors_fatal", "serial", "remote_user", "become", "become_user", "become_method", "no_log", "notify", "check_mode", "diff", "register", "ignore_errors", "environment", "local_action", "with_"}

    assert result == get_reserved_names()



# Generated at 2022-06-21 09:54:46.827238
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names(False)
    assert 'hosts' not in get_reserved_names(True)

# Generated at 2022-06-21 09:56:42.587465
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('delegate_to') == True
    assert is_reserved_name('some_other_name') == False



# Generated at 2022-06-21 09:56:49.410445
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        import pytest
    except ImportError:
        pytest = None
    if pytest:
        def check_get_reserved_names():
            assert set(get_reserved_names()) == _RESERVED_NAMES
            assert set(get_reserved_names(False)) != _RESERVED_NAMES
            assert not set(get_reserved_names(False)).difference(_RESERVED_NAMES)
        check_get_reserved_names()



# Generated at 2022-06-21 09:56:58.504524
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this function is set to be a unit test for warn_if_reserved()'''

    # Needs to be imported here to prevent import errors
    import pytest

    # Check simple cases
    with pytest.raises(NameError):
        warn_if_reserved({'vars': 'vars'})
    with pytest.raises(NameError):
        warn_if_reserved({'hosts': 'hosts'})
    with pytest.raises(NameError):
        warn_if_reserved({'name': 'name'})

    # Check with additional variable
    with pytest.raises(NameError):
        warn_if_reserved({'vars': 'vars'}, additional='name')

# Generated at 2022-06-21 09:57:00.798006
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)


# Generated at 2022-06-21 09:57:11.053568
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # The following names should be reserved
    reserved_names = ['hosts', 'roles', 'vars', 'become', 'become_method', 'become_user', 'name', 'action', 'local_action', 'with_', 'loop', 'delegate_to', 'register', 'ignore_errors', 'run_once', 'when', 'async_status_poll', 'async', 'pause', 'poll', 'connection', 'su', 'sudo', 'su_user', 'sudo_user', 'remote_user', 'shell', 'system', 'environment', 'no_log', 'always_run', 'failed_when', 'changed_when', 'ignore_errors', 'retries', 'delay', 'first_available_file', 'until', 'when']

# Generated at 2022-06-21 09:57:16.570889
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('notify')
    assert is_reserved_name('tags')
    assert is_reserved_name('with_')
    assert not is_reserved_name('foobar')
    assert not is_reserved_name('include_vars')

# Generated at 2022-06-21 09:57:25.459654
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved_public = frozenset(get_reserved_names(include_private=False))
    reserved_private = frozenset(get_reserved_names(include_private=True))

    # Test private and public reserved names
    assert len(reserved_private) < len(reserved_public)
    assert len(reserved_private.intersection(reserved_public)) > 0

    # Test for specific private and public reserved names
    assert 'become' in reserved_public
    assert 'become_user' in reserved_private
    assert 'run_once' in reserved_private
    assert 'loop' in reserved_private
    assert 'action' in reserved_public
    assert 'local_action' in reserved_public
    assert 'with_' in reserved_public

# Generated at 2022-06-21 09:57:34.189782
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=False)
    assert reserved_names == frozenset(['hosts', 'delegate_to', 'post_tasks', 'pre_tasks', 'vars', 'tags', 'gather_facts',
                                        'role', 'block', 'include', 'import_role', 'import_tasks', 'environment',
                                        'any_errors_fatal', 'failed_when', 'become', 'become_user', 'become_method',
                                        'check_mode', 'always_run', 'local_action', 'notify', 'when', 'async',
                                        'poll', 'changed_when', 'failed_when', 'no_log', 'register', 'ignore_errors',
                                        'until'])
    reserved_names_with_private = get_

# Generated at 2022-06-21 09:57:39.154297
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(dict(hosts='foobar', action='baz'))
    warn_if_reserved(dict(hosts='foo', local_action='baz'))
    warn_if_reserved(dict(hosts='foo', action='baz'))
    warn_if_reserved(dict(hosts='foo', with_='baz'))



# Generated at 2022-06-21 09:57:44.119868
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == set(['name', 'include', 'hosts', 'tasks', 'tasks', 'tasks', 'tasks', 'tasks', 'tasks', 'tasks'])