

# Generated at 2022-06-21 09:48:15.312345
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')


# FIXME: remove after with_ is not only deprecated but removed
_RESERVED_NAMES.discard('with_')


# Generated at 2022-06-21 09:48:19.581348
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['hosts']) == None
    assert warn_if_reserved(['hosts'], ['hosts']) == None
    assert warn_if_reserved(['hosts', 'hosts']) == None
    assert warn_if_reserved(['hosts', 'hosts'], ['hosts']) == None
    assert warn_if_reserved(['hosts', 'hosts', 'hosts']) == None
    assert warn_if_reserved(['hosts', 'hosts', 'hosts'], ['hosts']) == None
    assert warn_if_reserved(['hosts', 'hosts', 'hosts'], ['hosts', 'hosts']) == None

# Generated at 2022-06-21 09:48:21.371755
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for key in _RESERVED_NAMES:
        assert is_reserved_name(key)


# Generated at 2022-06-21 09:48:25.277426
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    print(warn_if_reserved({'hosts', 'name', 'roles', 'tasks'}))

if __name__ == '__main__':
    test_warn_if_reserved()

# Generated at 2022-06-21 09:48:33.617797
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("Unit test for function get_reserved_names")

    print("Testing for reserved names")
    reserved = get_reserved_names()
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'vars' in reserved

    print("Testing for private names")
    reserved = get_reserved_names(include_private=False)
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'vars' in reserved
    assert 'register' in reserved
    assert 'delegate_to' in reserved

    print("Testing for deprecated loop")
    reserved = get_reserved_names()
    assert 'with_' in reserved

# Generated at 2022-06-21 09:48:37.671504
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test for warning when an internal reserved name is used
    test_var = { 'strategy': 'unknown' }
    warn_if_reserved(test_var)

    # Test for warning when a reserved name is used
    test_var = {}
    warn_if_reserved(test_var, {'async', 'with_' })

    # Test for no warning when no reserved name is used
    warn_if_reserved(test_var)
    warn_if_reserved(test_var, set())

# Generated at 2022-06-21 09:48:42.537404
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # list of names
    names = get_reserved_names(include_private=False)

    assert isinstance(names, frozenset)
    assert len(names) > 15

    # final test, make sure all the names are valid
    for name in names:
        assert isinstance(name, str)
        assert isinstance(is_reserved_name(name), bool)


# Generated at 2022-06-21 09:48:49.357814
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for n in _RESERVED_NAMES:
        assert is_reserved_name(n)

    assert not is_reserved_name('foo')

if __name__ == '__main__':
    # Run local unit tests
    import sys
    import nose
    import logging

    # Set logging level
    log_level = logging.WARNING
    logging.basicConfig(stream=sys.stdout, level=log_level)

    # Run tests
    nose.runmodule()

# Generated at 2022-06-21 09:48:59.657574
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:49:06.748928
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'connection',
                                    'delegate_to', 'delegate_facts', 'environment', 'force_handlers', 'gather_facts',
                                    'hosts', 'ignore_errors', 'import_playbook', 'include', 'include_role',
                                    'include_tasks', 'local_action', 'meta', 'name', 'no_log', 'post_tasks',
                                    'pre_tasks', 'remote_user', 'role_paths', 'roles', 'serial', 'some_errors_fatal',
                                    'tasks', 'tags', 'when', 'with_', 'vars'}

# Generated at 2022-06-21 09:49:26.649021
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert frozenset(get_reserved_names()) == frozenset(('environment', 'roles', 'vars', 'tags', 'name', 'gather_facts', 'vars_prompt', 'vars_files', 'pre_tasks', 'post_tasks', 'handlers', 'tasks', 'action', 'local_action', 'with_'))
    assert frozenset(get_reserved_names(include_private=False)) == frozenset(('environment', 'roles', 'vars', 'tags', 'name', 'gather_facts', 'vars_prompt', 'vars_files', 'pre_tasks', 'post_tasks', 'handlers', 'tasks', 'action', 'local_action', 'with_'))


# Generated at 2022-06-21 09:49:29.060465
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # not enabled by default
    class TestInit:
        def __init__(self):
            self._attributes = {'name': {}}
    t = TestInit()
    assert not "name" in get_reserved_names(include_private=False)

# Generated at 2022-06-21 09:49:34.856805
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:49:39.474406
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:49:49.868993
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    import logging

    # Setup logging
    logging.basicConfig()
    log = logging.getLogger(__name__)
    # Add a null display handler
    log.addHandler(logging.NullHandler())

    test_vars = {'debug': 'somevalue', 'tags': 'tag value', 'vars': {'somekey': 'somevalue'}}
    display = Display()

    # Execute function
    warn_if_reserved(test_vars)

    # Assert we have 2 warnings
    assert len(display.warnings) == 2

    # Assert warning messages
    assert 'Found variable using reserved name: debug' in display.warnings
    assert 'Found variable using reserved name: tags' in display.warnings

# Generated at 2022-06-21 09:49:54.936731
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action'])
    warn_if_reserved(['become'])
    warn_if_reserved(['become_user'])
    warn_if_reserved(['become_method'])


# Generated at 2022-06-21 09:50:06.095818
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' Test function is_reserved_name '''
    assert is_reserved_name('roles')
    assert is_reserved_name('roles_path')
    assert not is_reserved_name('roles_paths')
    assert not is_reserved_name('role')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('action')
    assert is_reserved_name('with_')
    assert not is_reserved_name('delegated_vars')
    assert not is_reserved_name('not_a_reserved_name')
    assert is_reserved_name('tags')
    assert is_reserved_name('local_action')
    assert is_reserved_name('register')

# Generated at 2022-06-21 09:50:08.361331
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)

# Generated at 2022-06-21 09:50:10.629611
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    for name in _RESERVED_NAMES:
        yield _warn_if_reserved_unit, {name: None}



# Generated at 2022-06-21 09:50:15.997365
# Unit test for function get_reserved_names
def test_get_reserved_names():

    results = get_reserved_names()
    assert 'roles' in results
    assert 'hosts' in results

    results = get_reserved_names(include_private=False)
    assert 'roles' in results
    assert 'hosts' in results

    assert 'vars' not in results

# Generated at 2022-06-21 09:50:31.351486
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = dict(
        connection=dict(
            type=dict(
                default=dict(woo=dict(hoo=dict(hoo='hoo'))),
                other=dict(more=dict(nested=dict(stuff='hoo')))
            ),
        ),
        gather_facts=dict(default='no'),
        become_user=dict(default='root'),
        become=dict(default='root'),
        become_method=dict(default='sudo')
    )
    warn_if_reserved(myvars)

# Generated at 2022-06-21 09:50:42.330873
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_result = get_reserved_names()

    # list of strings

# Generated at 2022-06-21 09:50:45.774151
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('import_playbook')
    assert is_reserved_name('include')
    assert is_reserved_name('roles')



# Generated at 2022-06-21 09:50:48.810417
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name) == True
    assert is_reserved_name('obviously_not_a_reserved_name') == False

# Generated at 2022-06-21 09:50:51.004172
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('name')
    assert not is_reserved_name('foo')

# Generated at 2022-06-21 09:51:01.665602
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:51:09.240391
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts'), 'hosts should be a reserved name'
    assert is_reserved_name('local_action'), 'local_action should be a reserved name'
    assert is_reserved_name('_private_name'), '_private_name should be a reserved name'
    # 'vars' is not a name - it's a keyword that gets added to a task.  See base.py:245
    assert not is_reserved_name('vars'), 'vars should not be a reserved name'
    assert not is_reserved_name('test'), 'test should not be a reserved name'



# Generated at 2022-06-21 09:51:19.521364
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('plays')
    assert is_reserved_name('roles')
    assert not is_reserved_name('subordinate')
    assert is_reserved_name('private')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('delegate_to')
    assert not is_reserved_name('tasks')
    assert not is_reserved_name('blocks')
    assert not is_reserved_name('hosts')
    assert not is_reserved_name('action')
    assert not is_reserved_name('pre_tasks')
    assert not is_reserved_name('post_tasks')


# Generated at 2022-06-21 09:51:29.537726
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' returns ok if no difference between the actual list of reserved variables and the hardcoded list '''
    actual_reserved_names = get_reserved_names()

# Generated at 2022-06-21 09:51:33.175404
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('include_role')
    assert is_reserved_name('roles')
    assert is_reserved_name('vars')
    assert is_reserved_name('tags')
    assert (not is_reserved_name('foobar'))
    assert (not is_reserved_name(['action', 'foobar']))

# Generated at 2022-06-21 09:51:58.940525
# Unit test for function is_reserved_name
def test_is_reserved_name():

    reserved = _RESERVED_NAMES

    for name in reserved:
        assert is_reserved_name(name)

# Unit tests for function get_reserved_names

# Generated at 2022-06-21 09:52:03.102224
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # tests reserved names
    assert warn_if_reserved(['action'])

    # tests reserved names with additional values
    assert warn_if_reserved(['foo'], set(['foo']))

    # tests non-reserved names
    assert not warn_if_reserved(['foo'])

# Generated at 2022-06-21 09:52:04.457020
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('test_name')
    assert is_reserved_name('name') # name property of play/role/task/block objects

# Generated at 2022-06-21 09:52:10.537040
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """
    test_get_reserved_names is a unit test for get_reserved_names
    checks that it returns the correct set of names to be reserved
    """
    public_names = set(['name', 'hosts', 'remote_user', 'any_errors_fatal', 'gather_facts', 'vars'])
    private_names = set(['action', 'delegate_to', 'serial', 'notify', 'first_available_file',
                         'until', 'async', 'poll', 'become', 'become_method', 'become_user',
                         'tags', 'run_once', 'ignore_errors', 'register', 'ignore_unreachable'])

    assert get_reserved_names(False) == public_names

# Generated at 2022-06-21 09:52:12.031800
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(not is_reserved_name("foo"))
    assert(is_reserved_name("tasks"))

# Generated at 2022-06-21 09:52:18.234683
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

    assert 'local_action' in public
    assert 'local_action' in private
    assert 'with_' in public
    assert 'with_' in private
    assert 'hosts' in public
    assert 'hosts' in private
    assert 'roles' not in public
    assert 'roles' in private

# Generated at 2022-06-21 09:52:23.912735
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('vars')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('_test')
    assert not is_reserved_name('task')
    assert not is_reserved_name('role')
    assert not is_reserved_name('var')
    assert not is_reserved_name('host')

# Generated at 2022-06-21 09:52:29.779991
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import io
    import sys

    buffer = io.BytesIO()
    saved_stdout = sys.stdout
    try:
        sys.stdout = buffer
        warn_if_reserved(['vars', 'tasks', 'name', 'hosts', 'roles'])
        output = buffer.getvalue()
        assert "Found variable using reserved name: name" in output
        assert "Found variable using reserved name: hosts" in output
        assert "Found variable using reserved name: tasks" in output
        assert "Found variable using reserved name: vars" not in output
        assert "Found variable using reserved name: roles" in output
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-21 09:52:40.030086
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('tasks') is True
    assert is_reserved_name('vars') is True
    assert is_reserved_name('role_name') is True
    assert is_reserved_name('become') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('name_template') is True
    assert is_reserved_name('name_facts') is True
    assert is_reserved_name('include_tasks') is True
    assert is_reserved_name('previoustask') is True
    assert is_reserved_name('notify') is True
    assert is_reserved_name('local_action')

# Generated at 2022-06-21 09:52:41.927457
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names()
    print(reserved)
    assert reserved is _RESERVED_NAMES

# Generated at 2022-06-21 09:53:26.336943
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars') is False
    assert is_reserved_name('whatever') is False

    assert is_reserved_name('action') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('when') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('task') is True

    assert is_reserved_name('loop') is False
    assert is_reserved_name('with_') is False

    assert is_reserved_name('_raw_params') is True
    assert is_reserved_name('_role') is True
    assert is_reserved_name('_parent') is True

# Generated at 2022-06-21 09:53:32.760790
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names(False)
    assert isinstance(reserved, set)
    assert len(reserved) == 22

    # names in the set
    assert 'action' in reserved
    assert 'included_file' in reserved
    assert 'j2_template' in reserved
    assert 'name' in reserved
    assert 'tags' in reserved
    assert 'vars' in reserved

    # names not in the set
    assert 'private' not in reserved
    assert 'any_errors_fatal' not in reserved



# Generated at 2022-06-21 09:53:39.352799
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['action', 'any_errors_fatal', 'vars', 'foo']) == None
    assert warn_if_reserved(['foo_bar']) == None
    assert warn_if_reserved(['action', 'any_errors_fatal']) != None
    assert warn_if_reserved(['foo_action', 'foo_any_errors_fatal']) != None
    try:
        warn_if_reserved(['action', 'any_errors_fatal'])
    except AnsibleError:
        assert False

    # This can't actually break the test, but we want to make sure it doesn't
    # raise any sort of exception

# Generated at 2022-06-21 09:53:43.357801
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function unit tests function get_reserved_names() '''

    # FIXME: what else to assert here?
    assert isinstance(_RESERVED_NAMES, frozenset)



# Generated at 2022-06-21 09:53:47.049227
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) > 0
    assert len(get_reserved_names(include_private=False)) > 0
    assert len(get_reserved_names()) > len(get_reserved_names(include_private=False))


# Generated at 2022-06-21 09:53:53.770336
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test for simple names
    assert is_reserved_name('name')
    assert not is_reserved_name('myname')

    # Test for names with underscores
    assert is_reserved_name('with_items')
    assert not is_reserved_name('my_items')

    # Test for names where we cannot use the CamelCase conversion
    assert is_reserved_name('with_dict')
    assert not is_reserved_name('withdict')

    # Test for names with special chars
    assert is_reserved_name('delegate_to')
    assert not is_reserved_name('mydelegate_to')

    # Test for names where we can use the CamelCase conversion
    assert is_reserved_name('block')
    assert not is_reserved_name('myblock')



# Generated at 2022-06-21 09:54:02.451227
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' Unit test for validating the is_reserved_name function '''
    import os
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    valid_name = 'xyz'
    invalid_name = 'hosts'
    # Create a playbook file in that directory

    fh, fpath = tempfile.mkstemp(suffix='.yml', dir=tmpdir)
    tempfile = os.fdopen(fh, 'w')
    data = '- name: %s\n  hosts: all' % valid_name
    tempfile.write(data)
    tempfile.close()

    # Create a playbook file with an invalid name in that directory

    fh, fpath = tempfile.mkstemp(suffix='.yml', dir=tmpdir)
   

# Generated at 2022-06-21 09:54:09.498495
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('private') is True
    assert is_reserved_name('action') is True
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('args') is False
    assert is_reserved_name('my_custom_action') is False
    assert is_reserved_name('my_custom_hosts') is False
    assert is_reserved_name('my_custom_name') is False
    assert is_reserved_name('my_custom_args') is False

# Generated at 2022-06-21 09:54:18.214582
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.executor import task_queue_manager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.config.manager import ConfigManager

    test_data = 'action: this is the action I want to take'
    extra_vars = load_extra_vars(loader=DataLoader(), variables=test_data)

    _config = ConfigManager()
    _inventory = None
    _variable_manager = VariableManager(loader=DataLoader(), inventory=_inventory)
    _variable_manager.extra_vars = extra_vars  # put passed in vars into vars

    # this should be removed when deprecated with_ is removed
    _variable_manager.options_vars = dict

# Generated at 2022-06-21 09:54:25.113624
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'gather_facts' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names(include_private=False)
    assert 'loop' in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names(include_private=False)
    assert '_private' in get_reserved_names(include_private=True)

# Generated at 2022-06-21 09:56:20.969924
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    yamlvarlist = ['item', 'role_name', 'task_name', 'role_path', 'block', 'block_name', 'vars_files',
                   'vars', 'action', 'local_action', 'loop']
    strvar = 'role_name'
    additional = set(['block', 'block_name', 'vars'])
    reserved_names = get_reserved_names()
    reserved_names_with_additional = get_reserved_names().union(additional)

    assert(reserved_names.issubset(get_reserved_names()))
    assert(reserved_names_with_additional.issubset(get_reserved_names()))
    assert(set(yamlvarlist).issubset(reserved_names))

# Generated at 2022-06-21 09:56:26.898021
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Run with a variable using a reserved name
    warn_if_reserved(['action'])
    # Run without a variable using a reserved name
    warn_if_reserved(['my_action'])
    # Run with a variable using an additional reserved name
    warn_if_reserved(['become'], ['become'])
    # Run without a variable using an additional reserved name
    warn_if_reserved(['my_become'], ['become'])

# Generated at 2022-06-21 09:56:30.518108
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == get_reserved_names().difference(get_reserved_names(include_private=True))

# Generated at 2022-06-21 09:56:38.721594
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    class FakeOpts(object):
        def __init__(self):
            self.step = False
            self.start_at_task = None
            self.verbosity = 0

    # set up some fake variables
    fake_vars = dict()
    fake_options = FakeOpts()
    fake_loader = 'fake_loader'
    fake_inventory = 'fake_inventory'
    # create a fake play

# Generated at 2022-06-21 09:56:47.833764
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' unit test for function is_reserved_name '''

    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('copy')
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert is_reserved_name('local_action')

    assert not is_reserved_name('new_role')
    assert not is_reserved_name('new_task')
    assert not is_reserved_name('non_reserved')
    assert not is_reserved_name('my_action')
    assert not is_reserved_name('my_loop')
    assert not is_reserved_name('non_reserved')

# Generated at 2022-06-21 09:56:49.897314
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('not_a_reserved_name') == False


# Generated at 2022-06-21 09:56:51.487263
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('my_hosts')

# Generated at 2022-06-21 09:56:54.336527
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    # make sure returned variable is a set
    assert isinstance(reserved, set)

    # make sure vars is reserved
    assert 'vars' in reserved

# Generated at 2022-06-21 09:56:57.564422
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('myvar')
    assert is_reserved_name('vars')
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')



# Generated at 2022-06-21 09:57:01.569911
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")
    assert is_reserved_name("roles")
    assert is_reserved_name("tasks")
    assert not is_reserved_name("name")
    assert is_reserved_name("delegate_to")
    assert is_reserved_name("loop")
    assert is_reserved_name("with_")
    assert is_reserved_name("with_item")