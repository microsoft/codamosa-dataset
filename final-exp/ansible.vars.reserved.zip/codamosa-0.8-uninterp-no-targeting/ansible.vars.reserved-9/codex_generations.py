

# Generated at 2022-06-21 09:48:26.985638
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('any_context_block')
    assert not is_reserved_name('not_a_reserved_name')

# Generated at 2022-06-21 09:48:35.347550
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    Returns True if test succeeds
    '''

    import os
    import sys
    import StringIO
    import contextlib
    import tempfile

    # Create temp directory to save tempfile. NamedTemporaryFile() does not create the file
    temp_dir = tempfile.mkdtemp()

    from collections import namedtuple

    # Function under test
    def warn_if_reserved(myvars, additional=None):
        pass

    # Print saved in memory buffer
    @contextlib.contextmanager
    def nostdout():
        save_stdout = sys.stdout
        sys.stdout = mystdout = StringIO.StringIO()
        yield
        sys.stdout = save_stdout

    # Create temporary file and add reserved word to file

# Generated at 2022-06-21 09:48:44.397773
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_private_names = frozenset([u'action', u'become', u'become_user', u'block', u'connection',
                                        u'debugger', u'environment', u'failed_when', u'ignore_errors',
                                        u'local_action', u'loop', u'name', u'notify', u'notify_content',
                                        u'notify_level', u'register', u'run_once', u'run_once_enabled',
                                        u'static', u'tags', u'task_tags', u'until', u'when', u'when_content'])
    expected_public_names = frozenset([u'vars', u'roles', u'pre_tasks', u'post_tasks', u'tasks', u'handlers'])
   

# Generated at 2022-06-21 09:48:55.088507
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import os
    import tempfile

    # Save original environment
    saved_env = os.environ.copy()

    # Set up new temp directory as a temp workspace
    tmp_dir = tempfile.mkdtemp()
    os.environ['HOME'] = tmp_dir

    # Create a fake display class
    class FakeDisplay():
        def __init__(self):
            self.displayed = []

        def warning(self, msg):
            self.displayed.append(msg)

    # Create a fake display object
    fake_display = FakeDisplay()

    # Assign the fake display object to the global display object
    globals()['display'] = fake_display

    # Test warn_if_reserved with a vars containing reserved name
    vars = {'foo': 'bar', 'hosts': 'all'}
    warn

# Generated at 2022-06-21 09:48:59.849375
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('tasks')
    assert is_reserved_name('tags')
    assert is_reserved_name('ignore_errors')
    assert not is_reserved_name('sport')
    assert not is_reserved_name('hosts')
    assert not is_reserved_name('play')

# Generated at 2022-06-21 09:49:02.075977
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('include_tasks')
    assert not is_reserved_name('non_reserved_name')

# Generated at 2022-06-21 09:49:04.413846
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('when') == True
    assert is_reserved_name('no-such-name') == False


# Generated at 2022-06-21 09:49:09.762012
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('None')
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert not is_reserved_name('name')
    assert not is_reserved_name('my_fav_var')

# Generated at 2022-06-21 09:49:17.913127
# Unit test for function get_reserved_names

# Generated at 2022-06-21 09:49:22.654147
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = get_reserved_names(include_private=True)
    if not isinstance(reserved_names, set):
        reserved_names = set(reserved_names)
    assert not reserved_names.intersection(get_reserved_names(include_private=False))
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-21 09:49:47.543228
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this is a test function for warn_if_reserved '''

    # Test that a variable not in reserved is a warning
    assert warn_if_reserved(['test_list']) is False
    # Test that a variable in reserved is a warning
    assert warn_if_reserved(['vars']) is True
    # Test that a variable in additional is a warning
    assert warn_if_reserved(['foo'], ['foo']) is True

# Generated at 2022-06-21 09:49:48.464330
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action'])

# Generated at 2022-06-21 09:49:54.576994
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Loop over each name returned and ensure it's in the list
    # of available attributes
    for name in get_reserved_names():
        obj = Play()
        attrs = [ attr for attr in obj._attributes if name in attr ]
        assert len(attrs) > 0

# Generated at 2022-06-21 09:49:58.752710
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['name', 'foo', 'vars', 'myvar']
    reserved = frozenset(['vars', 'with_', 'name'])
    warn_if_reserved(myvars)
    warn_if_reserved(myvars, additional=reserved)

# Generated at 2022-06-21 09:50:01.321931
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names()
    warn_if_reserved(reserved, additional='xyz')
    assert True


# Generated at 2022-06-21 09:50:08.310084
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # No warning should be emitted for non-conflicting names
    current_display = display.verbosity
    display.verbosity = 0
    warn_if_reserved(['foo', 'bar', 'tasks'])
    display.verbosity = current_display

    # Warning should be emitted for conflicting names
    current_display = display.verbosity
    display.verbosity = 2
    warn_if_reserved(['tasks'])
    display.verbosity = current_display

# Generated at 2022-06-21 09:50:17.866487
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    yaml_data = """
---
- hosts: localhost
  tasks:
    - debug:
        msg: "friday the 7th"
"""

    loader, inventory, variable_manager = _setup_loader(yaml_data)

    # make sure the namespace is not polluted
    assert 'vars' not in _RESERVED_NAMES

    # make sure a reserved namespace is warned
    assert not warn_if_reserved(['playbook'])
    assert warn_if_reserved(['playbook', 'vars'])
    assert warn_if_reserved(['playbook', 'vars', 'other'])



# Generated at 2022-06-21 09:50:19.121581
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == _RESERVED_NAMES

# Generated at 2022-06-21 09:50:29.495342
# Unit test for function get_reserved_names
def test_get_reserved_names():

    public_only = get_reserved_names(include_private=False)

    assert 'action' in public_only
    assert 'local_action' in public_only
    assert 'rescue' in public_only
    assert 'always' in public_only
    assert 'delegate_to' in public_only

    assert 'run_once' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'vars' in get_reserved_names()

    # FIXME: remove after with_ is not only deprecated but removed
    assert 'loop' not in get_reserved_names()
    assert 'with_' in get_reserved_names()

    # FIXME: remove after with_ is not only deprecated but removed

# Generated at 2022-06-21 09:50:40.964193
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert (get_reserved_names(False) == {'action', 'vars', 'name', 'gather_facts', 'tags', 'vars_files', 'delegate_to',
                                          'delegate_facts', 'local_action', 'with_', 'serial', 'transport', 'remote_user',
                                          'remote_port', 'environment', 'hosts', 'become', 'become_user', 'run_once',
                                          'no_log', 'until', 'retries', 'delay', 'register', 'ignore_errors', 'listen'})

# Generated at 2022-06-21 09:51:09.080690
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'roles' in reserved_names
    assert 'name' in reserved_names
    assert 'tasks' in reserved_names
    assert 'action' in reserved_names
    assert 'notify' in reserved_names



# Generated at 2022-06-21 09:51:19.783784
# Unit test for function get_reserved_names
def test_get_reserved_names():
    play = Play()
    play.vars = {'action': 'test'}
    play.post_validate(play.vars, None)
    assert 'action' in play.vars

    # A local action should be allowed since this is a new attribute that comes
    # from the action prefix
    play = Play()
    play.vars = {'local_action': 'test'}
    play.post_validate(play.vars, None)
    assert 'local_action' in play.vars

    # with_ is deprecated in favor of loop, but we should still allowed it
    play = Play()
    play.vars = {'with_': 'test'}
    play.post_validate(play.vars, None)
    assert 'with_' in play.vars

    # Deprecated roles should not

# Generated at 2022-06-21 09:51:29.706284
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import tempfile

# Generated at 2022-06-21 09:51:37.129946
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'tasks' in reserved
    assert 'roles' in reserved
    assert 'gather_facts' in reserved
    assert 'serial' in reserved
    assert 'delegate_to' in reserved
    assert 'register' in reserved
    assert 'any_errors_fatal' in reserved
    assert 'become' in reserved
    assert 'become_user' in reserved
    assert 'tags' in reserved
    assert 'ignore_errors' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'connection' in reserved
    assert 'transport' in reserved
    assert 'remote_user' in reserved
    assert 'environment' in reserved
    assert 'no_log' in reserved
    assert 'when' in reserved
    assert 'async' in reserved
   

# Generated at 2022-06-21 09:51:39.381568
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') is True, _RESERVED_NAMES
    assert is_reserved_name('blahblahblah') is False

# Generated at 2022-06-21 09:51:45.862727
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('tasks') == True
    assert is_reserved_name('tags') == True
    assert is_reserved_name('ignore_errors') == True
    assert is_reserved_name('environment') == True
    assert is_reserved_name('connection') == True
    assert is_reserved_name('sudo_user') == True
    assert is_reserved_name('post_tasks') == True

    assert is_reserved_name('not_reserved') == False
    assert is_reserved_name('sudouser') == False
    assert is_reserved_name('when') == False

# Generated at 2022-06-21 09:51:48.425168
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'hosts', 'name', 'action'])

    try:
        warn_if_reserved(['vars', 'hosts', 'name', 'action', 'debug'])
    except Exception as e:
        assert not e, "Exception should not be raised."

# Generated at 2022-06-21 09:51:49.612257
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'vars': 'hello'}) is None

# Generated at 2022-06-21 09:51:51.679885
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import ansible.utils.unsafe_proxy
    args = ansible.utils.unsafe_proxy.AnsibleUnsafeText('foo')
    warn_if_reserved(['hosts', 'foo'], ['hosts'])

# Generated at 2022-06-21 09:52:01.196185
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        from ansible.tests import unittest
        from ansible.playbook.play_context import PlayContext
        from ansible.module_utils.six import PY3
    except ImportError:
        raise SkipTest('Test requires unittest>=1.2.2')
    class Test(unittest.TestCase):
        def test_warn_if_reserved(self):
            # verify no warning when there are no reserved variable names
            warn_if_reserved(dict(a=1, b=2, c=3))

            # verify warning when there are reserved variable names
            with self.assertRaises(UserWarning):
                warn_if_reserved(dict(a=1, action=2, c=3, _private=4))
            # The behavior of assertRaises is different for PY3.


# Generated at 2022-06-21 09:52:46.572001
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become_user')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('handlers')
    assert is_reserved_name('include')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('vars')
    assert is_reserved_name('block')
    assert is_reserved_name('rescue')
    assert is_reserved_name('always')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('serial')
    assert not is_reserved_name('become')
    assert not is_reserved_name('tags')



# Generated at 2022-06-21 09:52:56.629776
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == len(['post_tasks', 'tasks', 'pre_tasks', 'handlers', 'roles', 'notify', 'dependencies', 'name', 'vars_files', 'include', 'include_role', 'vars', 'gather_facts', 'connection', 'port', 'action', 'tags', 'when', 'async', 'poll', 'local_action', 'register', 'failed_when', 'ignore_errors', 'delegate_to', 'run_once', 'environment', 'no_log', 'become', 'become_user', 'become_method', 'become_flags', 'become_exe', 'src', 'dest', 'with_'])

# Generated at 2022-06-21 09:53:03.039256
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils.six import PY3

    warn_if_reserved(['hosts', 'roles', 'vars', 'connection', 'port', 'any_errors_fatal', 'serial'])
    # FIXME: remove after with_ is not only deprecated but removed
    if not PY3:
        warn_if_reserved(['loop', 'with_'])

# Generated at 2022-06-21 09:53:05.153607
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # All of the variables here should trigger warnings
    warn_if_reserved(['hosts', 'roles', 'tasks', 'vars', 'action'])

# Generated at 2022-06-21 09:53:13.919205
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    all = get_reserved_names(include_private=True)
    public = get_reserved_names(include_private=False)
    private = all - public

    # Test basic collision detection
    warn_if_reserved(all)
    warn_if_reserved(public)
    warn_if_reserved(private)

    # Test collision detection with extra reserved names
    warn_if_reserved(all, set(['fa_ke']))
    warn_if_reserved(all.union(set(['fa_ke'])), set(['fa_ke']))

    # Test collision detection with non-colliding names
    warn_if_reserved(set(['no_collision']))
    warn_if_reserved(set(['no_collision']), set(['fa_ke']))

# Generated at 2022-06-21 09:53:20.719967
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names(True)
    assert 'name' in names
    assert 'hosts' in names
    assert 'private' not in names
    assert isinstance(names, frozenset)

    names = get_reserved_names(False)
    assert 'name' in names
    assert 'hosts' in names
    assert 'private' not in names
    assert isinstance(names, frozenset)

# Generated at 2022-06-21 09:53:27.616594
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts': 'localhost', 'action': {'module': 'ping'}, 'roles': []})
    warn_if_reserved({'hosts': 'localhost', 'action': {'module': 'ping'}, 'roles': [], 'include': 'foo'})
    warn_if_reserved({'hosts': 'localhost', 'action': {'module': 'ping'}, 'roles': [], 'include': 'foo', 'vars': {'foo': 'bar'}})
    warn_if_reserved({'hosts': 'localhost', 'action': {'module': 'ping'}, 'roles': [], 'include': 'foo', 'vars': {'foo': 'bar', 'when': None}})

# Generated at 2022-06-21 09:53:34.084395
# Unit test for function get_reserved_names
def test_get_reserved_names():
    class_list = [Play, Role, Block, Task]
    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            name = attribute
            if 'private' in attribute:
                reserved = get_reserved_names(include_private=True)
                assert name in reserved
            else:
                reserved = get_reserved_names(include_private=False)
                assert name in reserved



# Generated at 2022-06-21 09:53:38.257664
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('action')

    assert is_reserved_name('local_action')

    assert is_reserved_name('name')

    assert is_reserved_name('loop')

    assert is_reserved_name('with_')

    # FIXME: remove after with_ is not only deprecated but removed
    assert is_reserved_name('tags') is False

    assert is_reserved_name('vars') is False

    assert is_reserved_name('with_items') is False

# Generated at 2022-06-21 09:53:48.797566
# Unit test for function is_reserved_name
def test_is_reserved_name():
    public_reserveds = set()
    private_reserveds = set()
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private_reserveds.add(attribute)
            else:
                public_reserveds.add(attribute)

    # test private var
    assert is_reserved_name('vars_files')
    assert not is_reserved_name('vars_files_test')

    # test public var
    assert is_reserved_name('hosts')
    assert not is_reserved_name('hosts_test')

    # test invalid var

# Generated at 2022-06-21 09:55:00.076884
# Unit test for function get_reserved_names
def test_get_reserved_names():

    result = get_reserved_names()

    assert set(result) == set(['action', 'block', 'connection', 'delegate_to', 'delegate_facts', 'gather_facts', 'handler', 'hosts', 'include', 'include_role',
                               'local_action', 'meta', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'previous_tasks', 'serial', 'sudo', 'sudo_user',
                               'tags', 'tasks', 'when', 'with_', 'block_errors', 'become', 'become_user'])



# Generated at 2022-06-21 09:55:03.310069
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(False)
    private = get_reserved_names(True)
    assert (private.difference(public) == set(['loop', 'private']))



# Generated at 2022-06-21 09:55:09.425711
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    testvars = {'action': 'setup',
                'local_action': 'debug',
                'with_items': [1,2,3],
                'name': 'system',
                'loop': '{{ mylist }}',
                'include': 'roles/foo.yml',
                'tags': ['tag1', 'tag2'],
                'pre_tasks': ['setup'],
                'hosts': 'all',
                'user': 'root'}

    warn_if_reserved(testvars)

# Generated at 2022-06-21 09:55:19.912111
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' check to see if we can find all reserved names '''

    public = ["connection", "delegate_to", "remote_user", "any_errors_fatal", "first_available_file", "serial",
              "become", "become_method", "become_user", "sudo", "sudo_user", "check_mode", "gather_facts",
              "name", "register", "tags", "environment", "action", "local_action", "with_", "ignore_errors",
              "user", "hosts", "roles", "task_vars", "play_hosts", "force_handlers"]


# Generated at 2022-06-21 09:55:31.013222
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    ansible.playbook.common.get_reserved_names
    This is a Unit Test for ansible.playbook.common.get_reserved_names() function.
    '''
    test_reserved_names = get_reserved_names(include_private=True)

    assert isinstance(test_reserved_names, set)
    assert 'name' in test_reserved_names
    assert 'roles' in test_reserved_names
    assert 'action' in test_reserved_names
    assert 'local_action' in test_reserved_names
    assert 'with_' in test_reserved_names
    assert 'include' in test_reserved_names
    assert 'vars' in test_reserved_names
    assert 'connection' in test_reserved_names

# Generated at 2022-06-21 09:55:35.304152
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # FIXME: use official unittest module, rather than assert
    myvars = dict()
    myvars['roles'] = 'foo'
    assert('roles' in myvars)
    assert('roles' in _RESERVED_NAMES)

    # TODO: this unit test requires the user to visually verify the warning message
    warn_if_reserved(myvars)

# Generated at 2022-06-21 09:55:41.943306
# Unit test for function get_reserved_names
def test_get_reserved_names():
    display.verbosity = 6
    # function get_reserved_names returns a set
    # so we are comparing sets
    assert set(get_reserved_names(False)) == {'name', 'tasks', 'vars', 'pre_tasks', 'post_tasks', 'notify', 'become', 'become_user', 'async', 'poll', 'tags', 'hosts', 'roles', 'roles_path', 'strategy', 'action', 'local_action', 'with_', 'connection', 'gather_facts', 'vars_files', 'forks', 'sudo', 'sudo_user', 'transport', 'remote_user', 'any_errors_fatal', 'ignore_errors', 'run_once', 'serial', 'delegate_to', 'bundle', 'wipe', 'delegate_facts'}

# Generated at 2022-06-21 09:55:48.131903
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_warning = []

    class TestDisplay(object):
        def __init__(self):
            self.warning = test_warning

    test_display = TestDisplay()

    try:
        real_display = Display
        Display = test_display
        warn_if_reserved(['foo', 'become_user', 'something', 'hosts'])
    finally:
        Display = real_display

    assert(len(test_warning) == 2)


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-21 09:55:51.409747
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # test if we get a warning
    display.verbosity = 3

    # create a fake structure to pass via vars.
    test_vars = {'reserved': 'test', 'notreserved': 'test'}

    # Warning should be returned
    warn_if_reserved(test_vars)

# Generated at 2022-06-21 09:55:59.773279
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import io
    import sys

    out = io.StringIO()
    saved_stdout = sys.stdout
    sys.stdout = out

    # Assert no warning
    warn_if_reserved(['foo'])
    output = out.getvalue().strip()
    assert not output

    # Assert one warning
    warn_if_reserved(['foo', 'su'])
    output = out.getvalue().strip()
    assert output == 'WARNING: Found variable using reserved name: su'

    # Assert two warnings
    warn_if_reserved(['foo', 'su', 'become'])
    output = out.getvalue().strip()
    lines = output.split('\n')
    assert len(lines) == 3
    assert lines[1] == 'WARNING: Found variable using reserved name: su'
