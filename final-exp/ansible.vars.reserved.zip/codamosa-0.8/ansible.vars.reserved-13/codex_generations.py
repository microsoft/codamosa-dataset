

# Generated at 2022-06-11 19:13:51.634263
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:13:55.787190
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Don't expose private attributes
    assert 'task_include' not in get_reserved_names(include_private=False)

    # Expose private attributes
    assert 'task_include' in get_reserved_names(include_private=True)



# Generated at 2022-06-11 19:14:01.080795
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # use reserved name list from list above

    # should include reserved names
    assert get_reserved_names(include_private=True) == _RESERVED_NAMES

    # should include only public reserved names
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names(include_private=True) - set('_pre_tasks _post_tasks'))


# Generated at 2022-06-11 19:14:06.031932
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names() == _RESERVED_NAMES)
    assert(len(get_reserved_names(include_private=False)) < len(get_reserved_names()))

    # Unit test for function warn_if_reserved

# Generated at 2022-06-11 19:14:10.502192
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Ensure all reserved names are in the fixtures
    for name in get_reserved_names():
        if name not in _RESERVED_NAMES:
            raise AssertionError("Function get_reserved_names() returned name '%s' not in fixture _RESERVED_NAMES" % name)



# Generated at 2022-06-11 19:14:21.969007
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Define some reserved variables
    reserved_variables = get_reserved_names()

    # Check the length of reserved variables
    assert len(reserved_variables) > 20, 'There should be more reserved variables than 20.'

    # Check the reserved variables contain some specific variables
    assert reserved_variables.__contains__('local_action'), 'The reserved_variables should contain local_action.'
    assert reserved_variables.__contains__('with_'), 'The reserved_variables should contain with_.'
    assert reserved_variables.__contains__('until'), 'The reserved_variables should contain until.'
    assert reserved_variables.__contains__('become'), 'The reserved_variables should contain become.'

# Generated at 2022-06-11 19:14:33.126825
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:44.036832
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # This test will fail if the structure of the module changes,
    # new attributes are added, or old attributes are removed.
    # TODO: remove test if this ever becomes a problem.
    assert 'roles' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'pre_tasks' in _RESERVED_NAMES
    assert 'post_tasks' in _RESERVED_NAMES
    assert 'handlers' in _RESERVED_NAMES
    assert 'vars' in _RESERVED_NAMES
    assert 'default_vars' in _RESERVED_NAMES
    assert 'meta' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES
    assert 'register' in _

# Generated at 2022-06-11 19:14:55.235958
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in _RESERVED_NAMES
    assert 'register' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'tags' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'vars' in _RESERVED_NAMES
    assert 'gather_facts' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'ignore_errors' in _RESERVED_NAMES
    assert 'async' in _RESERVED_NAMES
    assert 'free_form' in _RESERVED_NAMES
    assert 'any_errors_fatal' in _RESERVED_NAMES

# Generated at 2022-06-11 19:15:04.028292
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = ['name', 'hosts', 'user', 'sudo', 'connection', 'remote_user', 'become_user', 'become_method', 'become', 'become_flags',
              'environment', 'gather_facts', 'vars_files', 'vars_prompt', 'vars', 'vault_password_file', 'handlers', 'pre_tasks',
              'post_tasks', 'tasks', 'any_errors_fatal', 'max_fail_percentage', 'serial', 'tags', 'skip_tags', 'transport', 'register',
              'ignore_errors', 'roles', 'include', 'include_vars', 'include_tasks']


# Generated at 2022-06-11 19:15:18.750301
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print(get_reserved_names(include_private=False))
    print(get_reserved_names(include_private=True))



# Generated at 2022-06-11 19:15:27.475276
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function unit tests when modules are loaded, to ensure that there are no play-related
        variables which clash with internally reserved names. If any of the below assertions fail,
        please check the definition of `get_reserved_names` to ensure it is properly including/excluding
        the names you think it is. This also ensures that the above unit test is correctly defined. '''

    # Make sure that no variable defined in the play conflicts with internal variables
    variable_names = [
        variable for variable in dir(Play()) if not variable.startswith('_')
    ]
    assert not set(variable_names).intersection(_RESERVED_NAMES)

    # Make sure that no variable defined in a role conflicts with internal variables
    variable_names = [
        variable for variable in dir(Role()) if not variable.startswith('_')
    ]


# Generated at 2022-06-11 19:15:37.774431
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES == {'name', 'hosts', 'gather_facts', 'remote_user', 'roles', 'tasks', 'become', 'become_method', 'become_user',
                               'delegate_to', 'no_log', 'remote_tmp', 'any_errors_fatal', 'ignore_errors', 'force_handlers', 'register', 'serial',
                               'vars', 'vars_files', 'action', 'handlers', 'local_action', 'with_', 'connection', 'delegate_facts', 'post_tasks', 'pre_tasks',
                               'tags', 'when', 'ignore_dependencies', 'only_tasks', 'forks'}

# Generated at 2022-06-11 19:15:47.149787
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:48.808096
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES


# Generated at 2022-06-11 19:15:57.806316
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = set(['name',
                    'hosts',
                    'gather_facts',
                    'remote_user',
                    'roles',
                    'tasks',
                    'vars',
                    'tasks',
                    'become',
                    'become_user',
                    'tags',
                    'run_once',
                    'block',
                    'any_errors_fatal',
                    'delegate_to',
                    'environment',
                    'no_log',
                    'register'])
    assert set(get_reserved_names()) == reserved

# Generated at 2022-06-11 19:15:59.160433
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'vars' in get_reserved_names()

# Generated at 2022-06-11 19:16:05.706224
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function will fail if the reserved names list ever drops below a set value '''

    should_be_atleast = 84
    result = len(get_reserved_names())
    assert result >= should_be_atleast, 'We should have at least %d reserved names but found %d' % (should_be_atleast, result)



# Generated at 2022-06-11 19:16:11.751846
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:16:15.830923
# Unit test for function get_reserved_names
def test_get_reserved_names():
    new_names = ['hosts', 'roles', 'vars', 'action']
    reserved_names = get_reserved_names(include_private=False)

    for name in new_names:
        if name in reserved_names:
            assert False, '%s is reserved name' % (name)



# Generated at 2022-06-11 19:16:35.702781
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert names
    assert isinstance(names, set)
    assert 'hosts' in names
    assert 'action' in names
    assert 'name' in names

# Generated at 2022-06-11 19:16:46.798186
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private_names = set(['.*?__.*?'])
    private_names.add('any_errors_fatal')
    public_names = set(['any_errors_fatal'])

# Generated at 2022-06-11 19:16:47.659465
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) is set



# Generated at 2022-06-11 19:16:48.777120
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert isinstance(result, set)



# Generated at 2022-06-11 19:16:57.931427
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check that list of reserved names does not change without notice
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert all(isinstance(item, str) for item in _RESERVED_NAMES)
    assert 'action' in _RESERVED_NAMES
    assert 'async' in _RESERVED_NAMES
    assert 'become' in _RESERVED_NAMES
    assert 'delegate_to' in _RESERVED_NAMES
    assert 'environment' in _RESERVED_NAMES
    assert 'include' in _RESERVED_NAMES
    assert 'import_playbook' not in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES
    assert 'loop' in _RESERVED_

# Generated at 2022-06-11 19:17:08.899515
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ansible_reserved = ['gather_facts', 'hosts', 'name', 'roles', 'tasks', 'vars']
    role_reserved = ['become', 'become_user', 'hosts', 'name', 'tags', 'tasks']

    res = get_reserved_names()
    assert isinstance(res, frozenset)
    assert isinstance(res, set)

    res_ansible = get_reserved_names(include_private=False)
    assert isinstance(res_ansible, frozenset)
    assert isinstance(res_ansible, set)

    # check that result is not empty
    assert res
    assert res_ansible

    # check that a known ansible reserved name exists in the result
    assert 'gather_facts' in res
    assert 'gather_facts'

# Generated at 2022-06-11 19:17:20.439374
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:29.104870
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this method tests the get_reserved_names method '''

    public_reserved = get_reserved_names(False)
    assert len(public_reserved) > 0
    assert 'roles' in public_reserved
    assert 'roles' in _RESERVED_NAMES
    assert 'with_' in public_reserved
    assert 'with_' in _RESERVED_NAMES

    private_reserved = get_reserved_names(True)
    assert 'when' in _RESERVED_NAMES
    assert 'when' in private_reserved



# Generated at 2022-06-11 19:17:35.827567
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:40.432858
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private_names = set(['strategy', 'gather_facts', 'delegate_to'])
    assert get_reserved_names(include_private=True) == _RESERVED_NAMES
    assert private_names < _RESERVED_NAMES

# Generated at 2022-06-11 19:18:22.692507
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This unit test checks get_reserved_names and warn_if_reserved return the
    proper reserved names and warnings when calling either function
    '''


# Generated at 2022-06-11 19:18:26.231370
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=True)
    assert 'action' in result
    assert 'with_' in result
    assert 'loop' in result
    assert 'tags' in result
    assert 'tasks' in result
    assert 'vars' in result

# Generated at 2022-06-11 19:18:35.483966
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' return the list of reserved names associated with play objects, including private ones '''


# Generated at 2022-06-11 19:18:43.022862
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:18:44.475280
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'gather_facts' in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:18:53.308614
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_path = 'lib/ansible/playbook/play_context.py'
    with open(test_path) as f:
        for line in f:
            if line.startswith('_RESERVED_NAMES'):
                text = line.split('=')[1].strip().lstrip('frozenset(').rstrip(')')

    # Verify we get back the same names as hardcoded in the unit test file
    assert sorted(get_reserved_names(include_private=False)) == sorted(eval(text))
    assert sorted(get_reserved_names(include_private=True)) == sorted(eval(text))

    # Verify we get back the same names as hardcoded in the unit test file with private names included
    test_names = get_reserved_names()
    text_plus_private_names

# Generated at 2022-06-11 19:18:54.234349
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(_RESERVED_NAMES) > 1

# Generated at 2022-06-11 19:19:03.051191
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check that names are returned as list
    assert isinstance(get_reserved_names(), set)

    # Make sure nothing is duplicated
    names = get_reserved_names()
    assert len(names) == len(set(names))

    # Make sure no reserved names are missing
    assert _RESERVED_NAMES == get_reserved_names()

    # Make sure no names are returned when private is false
    assert not get_reserved_names(include_private=False)

    # Make sure local_action is returned when action is reserved
    Play.action = 'foo'
    assert 'local_action' in get_reserved_names()
    del Play.action

    # Make sure with_ is returned when loop is reserved
    Play.loop = 'foo'
    assert 'with_' in get_reserved_names()

# Generated at 2022-06-11 19:19:13.766974
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test if reserved names are returned correctly,
    including a subset with only the public ones '''

    reserved_names_set = get_reserved_names()
    reserved_names_public = get_reserved_names(include_private=False)

    # check for assertion errors
    assert(isinstance(reserved_names_set, set))
    assert(isinstance(reserved_names_public, set))
    assert(isinstance(reserved_names_set, set))

    # check if we get the difference we want
    assert(reserved_names_set.difference(reserved_names_public))

    # check if the union is the same as the first set
    assert(reserved_names_set.union(reserved_names_public) == reserved_names_set)

    # check if reserved names are in the set


# Generated at 2022-06-11 19:19:16.590573
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert isinstance(result, set) == True
    assert 'name' in result

# Generated at 2022-06-11 19:20:29.191282
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test function get_reserved_names '''

    public_names = set(get_reserved_names(include_private=False))

    # These are just a few test cases. This apparently needs to be updated
    # for any changes to the _meta_vars structure.
    assert Play.name in public_names
    assert Play.gather_facts in public_names
    assert Role.name in public_names
    assert Block.name in public_names
    assert Task.action in public_names

    private_names = set(get_reserved_names()).difference(public_names)

    # These are just a few test cases. This apparently needs to be updated
    # for any changes to the _meta_vars structure.
    assert 'gather_facts' in private_names
    assert 'connection' in private_names
   

# Generated at 2022-06-11 19:20:38.805389
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_names = set()

    test_names.add('name')
    test_names.add('hosts')
    test_names.add('gather_facts')
    test_names.add('remote_user')
    test_names.add('any_errors_fatal')
    test_names.add('serial')
    test_names.add('sudo')
    test_names.add('sudo_user')
    test_names.add('transport')
    test_names.add('connection')
    test_names.add('environment')
    test_names.add('become')
    test_names.add('become_user')
    test_names.add('become_method')
    test_names.add('tasks')
    test_names.add('roles')

# Generated at 2022-06-11 19:20:45.958288
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print('Running unit test for get_reserved_names ...')
    reserved_public = get_reserved_names(include_private=False)
    reserved_private = get_reserved_names(include_private=True)
    assert len(reserved_private) > len(reserved_public)
    assert 'roles' in reserved_private
    assert 'roles' in reserved_public
    assert 'role_path' in reserved_private
    assert 'role_path' in reserved_public
    assert 'role_names' in reserved_private
    assert 'role_names' not in reserved_public
    print('Passed unit test for get_reserved_names.')

# Generated at 2022-06-11 19:20:56.159125
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = frozenset(get_reserved_names())
    assert isinstance(names, frozenset)
    print(names)
    # This is a generated list of the current reserved names
    # TODO: update this whenever the reserved names change

# Generated at 2022-06-11 19:20:57.501866
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-11 19:21:06.213411
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'vars' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'user' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'blocks' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'includes' in get_reserved_names()

# Generated at 2022-06-11 19:21:15.627565
# Unit test for function get_reserved_names
def test_get_reserved_names():
    passed = True


# Generated at 2022-06-11 19:21:23.831296
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(False)
    assert 'name' in reserved_names
    assert 'roles' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'block' in reserved_names
    assert 'when' in reserved_names
    assert 'local_action' not in reserved_names
    assert 'with_' not in reserved_names
    assert 'loop' not in reserved_names
    assert 'role_name' not in reserved_names
    assert 'tasks' not in reserved_names
    assert 'condition' not in reserved_names



# Generated at 2022-06-11 19:21:34.704071
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Required for unit tests as we cannot directly unset env variable
    # inside function
    import ansible.constants as C
    C.DEFAULT_ACTION_PROMPT = False

    assert 'name' in get_reserved_names(include_private=False)

    assert 'roles' in get_reserved_names(include_private=False)

    assert 'no_log' in get_reserved_names(include_private=True)
    assert 'no_log' not in get_reserved_names(include_private=False)

    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' not in get_reserved_names(include_private=False)

    assert 'loop' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:21:37.961397
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)

