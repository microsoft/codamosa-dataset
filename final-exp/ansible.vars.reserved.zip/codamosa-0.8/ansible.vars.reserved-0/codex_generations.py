

# Generated at 2022-06-11 19:14:02.023793
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names() '''


# Generated at 2022-06-11 19:14:07.998877
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert frozenset(['gather_facts', 'remote_user', 'roles', 'tags']) == \
        get_reserved_names(include_private=False)

    assert frozenset(['gather_facts', 'remote_user', 'roles', 'tags', 'name', 'any_errors_fatal']) == \
        get_reserved_names()

# Generated at 2022-06-11 19:14:13.104903
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)
    assert get_reserved_names(False).issubset(get_reserved_names())

# Generated at 2022-06-11 19:14:22.534820
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert type(get_reserved_names()) == set
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'task' in get_reserved_names()
    assert 'meta' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()

    assert type(get_reserved_names(include_private=False)) == set
    assert 'hosts' in get_reserved_names()

# Generated at 2022-06-11 19:14:33.676808
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    private_reserved = get_reserved_names(include_private=True)

    assert len(private_reserved) >= len(reserved)

    for attr in reserved:
        assert attr not in private_reserved or private_reserved[attr].get('private')

    reserved_vars = get_reserved_names()
    assert 'private' not in reserved_vars, 'private should not be a reserved keyword'
    assert 'private' not in reserved_vars, 'private should not be a reserved keyword'
    assert 'private' not in reserved_vars, 'private should not be a reserved keyword'
    assert 'private' in reserved_vars, 'private should be a reserved keyword'
    assert 'private' in reserved_vars, 'private should be a reserved keyword'
   

# Generated at 2022-06-11 19:14:35.008420
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-11 19:14:43.003285
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test function get_reserved_names '''

    public = set(['hosts', 'name', 'delegate_to', 'roles', 'tasks', 'vars', 'block', 'action', 'local_action'])
    private = set(['loop', 'tags'])
    actual = get_reserved_names()

    # include private names in the test
    assert actual == public.union(private)

    # exclude private names from the test
    actual = get_reserved_names(include_private=False)
    assert actual == public

# Generated at 2022-06-11 19:14:51.884766
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get_reserved_names replaces some values in public and private sets,
    # 'local_action' is replaced with 'action', and 'with_' is replaced
    # with 'loop'
    # As such we need to check for the original reserved names (with action,
    # and without with_)
    result = get_reserved_names()
    assert 'action' in result
    assert 'local_action' not in result
    assert 'loop' in result
    assert 'with_' not in result

    result = get_reserved_names(False)
    assert 'action' in result
    assert 'local_action' not in result
    assert 'loop' not in result
    assert 'with_' not in result

# Generated at 2022-06-11 19:15:01.587134
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # We will assert that certain names are reserved and others are not
    reserved_names = ['name', 'hosts', 'roles', 'tasks', 'vars', 'action', 'local_action', 'with_', 'register', 'ignore_errors', 'changed_when', 'failed_when', 'when', 'notify', 'block']
    not_reserved_names = ['user', 'password']
    # Get the list of reserved names
    reserved_list = get_reserved_names()
    not_reserved_list = get_reserved_names(include_private=False)
    # Make sure the lists have the right values
    for rn in reserved_names:
        assert rn in reserved_list
    for nrn in not_reserved_names:
        assert nrn not in reserved_list


# Generated at 2022-06-11 19:15:04.791308
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    assert len(public) == 9, "Lenght of public is incorrect"

    all_names = get_reserved_names(include_private=True)
    assert len(all_names) == 11, "Lenght of all (public and private) is incorrect"



# Generated at 2022-06-11 19:15:36.446245
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Split into public and private, make sure the split is the same
    public, private = get_reserved_names(include_private=False), get_reserved_names(include_private=True)

    assert len(public.union(private)) == len(public) + len(private)
    assert len(public.intersection(private)) == len(public)

    assert 'debug' in public

    # Check that some known reserved names are present in public
    assert 'gather_facts' in public
    assert 'any_errors_fatal' in public

    # Check that some known reserved names are present in private
    assert 'become' in private
    assert 'delegate_to' in private

    # Check that some variables that are non reserved are not returned
    assert 'foobar' not in private
    assert 'foobarbaz' not in public

# Generated at 2022-06-11 19:15:42.356371
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # unit test metadata
    version = 1
    tags = ['utils', 'get_reserved_names']

    reserved_names = get_reserved_names()
    assert len(reserved_names) > 10

    reserved_names = get_reserved_names(include_private=False)
    assert len(reserved_names) > 10

    reserved_names = get_reserved_names(include_private=True)
    assert len(reserved_names) > 10

# Generated at 2022-06-11 19:15:48.953865
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)
    assert "name" in reserved_names
    assert "hosts" in reserved_names
    assert "gather_facts" in reserved_names
    assert "vars_prompt" in reserved_names
    assert "vars_files" in reserved_names
    assert "vars" in reserved_names
    assert "pre_tasks" in reserved_names
    assert "roles" in reserved_names
    assert "post_tasks" in reserved_names


# Generated at 2022-06-11 19:16:00.124593
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names(include_private=False)) == len(get_reserved_names()) - 12
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'block' in get_reserved_names(include_private=False)
    assert 'rescue' in get_reserved_names()
    assert 'rescue' in get_reserved_names(include_private=False)
    assert 'always' in get_reserved_names()
    assert 'always' in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:16:03.527318
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert 'hosts' in result
    assert 'tasks' in result


# Generated at 2022-06-11 19:16:07.922829
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # display.display(get_reserved_names(False))
    assert set(get_reserved_names(False)) == set(['vars', 'name', 'action', 'local_action', 'block', 'roles', 'with_'])



# Generated at 2022-06-11 19:16:18.361609
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=False)
    assert 'delegate_to' in reserved_names
    assert 'become' in reserved_names
    assert 'connection' in reserved_names
    assert 'remote_user' in reserved_names
    assert 'action' not in reserved_names
    assert 'local_action' not in reserved_names
    assert 'loop' not in reserved_names
    assert 'with_' not in reserved_names

    reserved_names = get_reserved_names(include_private=True)
    assert 'delegate_to' in reserved_names
    assert 'become' in reserved_names
    assert 'connection' in reserved_names
    assert 'remote_user' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names


# Generated at 2022-06-11 19:16:27.459331
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:16:36.429676
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''Unit test for function get_reserved_names'''

    # check output type
    assert(isinstance(get_reserved_names(False), set))

    # check no private items
    private = set(get_reserved_names(True)).difference(
        set(get_reserved_names(False)))
    assert(len(private) != 0)

    # check no public items
    public = set(get_reserved_names(False)).difference(
        set(get_reserved_names(True)))
    assert(len(public) == 0)

    return


# Generated at 2022-06-11 19:16:39.536526
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    assert isinstance(reserved_names, set)
    assert len(reserved_names) > 1
    assert 'hosts' in reserved_names

# Generated at 2022-06-11 19:17:26.237569
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test default value
    result = get_reserved_names()
    assert len(result) > 0
    assert 'action' in result
    assert 'any_errors_fatal' in result
    assert 'become' in result
    assert 'become_user' in result
    assert 'delegate_to' in result
    assert 'name' in result
    assert 'roles' in result
    assert 'tasks' in result
    assert 'when' in result

    # test value of include_private=False
    result = get_reserved_names(include_private=False)
    assert 'action' in result
    assert 'any_errors_fatal' in result
    assert 'become' in result
    assert 'become_user' in result
    assert 'delegate_to' in result
    assert 'name' in result

# Generated at 2022-06-11 19:17:30.215270
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test that reserved names are detected '''

    # This method is a reserved name, so we use it to test
    assert 'test_get_reserved_names' in get_reserved_names()



# Generated at 2022-06-11 19:17:31.365855
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert(len(result) > 0)

# Generated at 2022-06-11 19:17:41.869819
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test public and private names
    assert 'name' in get_reserved_names(include_private=True)
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)
    # test implicit names
    assert 'local_action' in get_reserved_names(include_private=True)
    assert 'with_' in get_reserved_names(include_private=True)
    # test non-implicit names
    assert 'gather_facts' in get_reserved_names(include_private=True)
    assert 'no_log' in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:17:52.333350
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function returns the list of reserved names associated with play objects'''


# Generated at 2022-06-11 19:17:56.545187
# Unit test for function get_reserved_names
def test_get_reserved_names():
    all_reserved = get_reserved_names(include_private=True)
    assert 'name' in all_reserved

    all_reserved = get_reserved_names(include_private=False)
    assert 'name' in all_reserved

# Generated at 2022-06-11 19:18:05.124548
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names function '''

    # pylint: disable=no-name-in-module,import-error
    # AnsibleAction is imported by get_reserved_names in __main__
    from ansible.plugins.action import ActionModule

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [ActionModule, Play, Role, Block, Task]

    reserved = set()
    for aclass in class_list:
        aobj = aclass()

        # no_log is injected in aobj.__dict__['_attributes'], remove from test
        if 'no_log' in aobj.__dict__['_attributes']:
            aobj.__dict__['_attributes'].remove('no_log')


# Generated at 2022-06-11 19:18:11.379217
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public, private = get_reserved_names()

    assert isinstance(public, set)
    assert isinstance(private, set)

    assert len(public) > 6
    assert len(private) > 0

    assert 'hosts' in public
    assert 'vars' in public
    assert 'post_tasks' in public

    assert 'name' in private
    assert 'hosts' not in private
    assert 'vars' not in private


# Generated at 2022-06-11 19:18:17.679977
# Unit test for function get_reserved_names
def test_get_reserved_names():
    mypublic = frozenset([
        'name', 'hosts', 'roles', 'vars', 'gather_facts', 'register', 'any_errors_fatal',
        'force_handlers', 'serial', 'max_fail_percentage', 'remote_user', 'connection',
        'sudo', 'sudo_user', 'environment', 'tags', 'when', 'run_once', 'block', 'post_tasks',
        'always_run', 'notify', 'handlers', 'pre_tasks',
        'action', 'local_action', 'with_'
    ])
    myprivate = frozenset(['tags_handler'])

    assert get_reserved_names(include_private=False) == mypublic
    assert get_reserved_names(include_private=True) == mypublic.union(myprivate)

# Generated at 2022-06-11 19:18:28.098802
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'hosts' in get_reserved_names(), "hosts is a reserved word."
    assert 'name' in get_reserved_names(), "name is a reserved word."
    assert 'become' in get_reserved_names(), "become is a reserved word."
    assert 'gather_facts' in get_reserved_names(), "gather_facts is a reserved word."

    assert 'action' in get_reserved_names(), "action is a reserved word."
    assert 'local_action' in get_reserved_names(), "local_action is a reserved word."
    assert 'register' in get_reserved_names(), "register is a reserved word."
    assert 'with_' in get_reserved_names(), "with_ is a reserved word."

# Generated at 2022-06-11 19:19:14.969659
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]
    # FIXME: this loop needs to be fixed.
    # The _attributes list is initialized in the _load_vars method
    # That method populates the dict with the vars and the available methods. So
    # the order that the methods are defined in will change the order of the list.
    # This is fixing the problem by sorting the lists we are comparing
    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                assert attribute in _RESERVED_NAMES
            else:
                assert attribute in _RESERVED_NAMES

# Generated at 2022-06-11 19:19:24.665981
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # define list of public and private reserved names
    public = set([u'become', u'become_method', u'become_user', u'connection', u'delegate_to', u'environment', u'ignore_errors', u'name', u'notify', u'poll', u'run_once', u'run_once_with_watch', u'register', u'remote_user', u'serial', u'start_at_task', u'sync', u'tags', u'vars', u'when', u'with_'])

# Generated at 2022-06-11 19:19:26.323695
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 32


# Generated at 2022-06-11 19:19:37.235394
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 40
    assert len(get_reserved_names(include_private=False)) == 34
    assert get_reserved_names() == frozenset(['pre_tasks', 'roles', 'environment', 'priority', 'vars_files', 'gather_facts', 'hosts', 'register', 'include_tasks', 'roles_path', 'connection', 'vars', 'post_tasks', 'handlers', 'name', 'action', 'become', 'become_user', 'become_method', 'force_handlers', 'tags', 'remote_user', 'no_log', 'local_action', 'with_', 'transport', 'other_actions', 'serial', 'strategy', 'delegate_to', 'delegate_facts', 'notify'])
    assert get

# Generated at 2022-06-11 19:19:45.680703
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:19:54.060229
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names(include_private=True)).issuperset(set(['name', 'hosts', 'connection', 'gather_facts', 'tasks']))
    assert set(get_reserved_names(include_private=False)).issuperset(set(['name', 'hosts', 'connection', 'gather_facts', 'tasks']))
    assert isinstance(get_reserved_names(include_private=False), frozenset)
    assert isinstance(get_reserved_names(include_private=True), frozenset)



# Generated at 2022-06-11 19:20:03.189083
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:20:04.614378
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES



# Generated at 2022-06-11 19:20:05.671855
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert 'hosts' in result

# Generated at 2022-06-11 19:20:10.630162
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test reserved names getting '''

    assert('action' in get_reserved_names())
    assert('local_action' in get_reserved_names())
    assert('loop' in get_reserved_names())
    assert('with_' in get_reserved_names())
    assert('private' in get_reserved_names(include_private=True))
    assert('private' not in get_reserved_names(include_private=False))

# Generated at 2022-06-11 19:21:38.196638
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'use_proxy' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()


# Generated at 2022-06-11 19:21:47.951491
# Unit test for function get_reserved_names
def test_get_reserved_names():
    p = Play()
    r = Role()
    t = Task()
    b = Block()

    # Add ansible 1.9 names to 1.8 test case

# Generated at 2022-06-11 19:21:58.304237
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' confirm expected reserved names (public only) '''
    reserved = get_reserved_names(include_private=False)

    assert 'name' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'delegate_to' in reserved
    assert 'register' in reserved
    assert 'connection' in reserved
    assert 'ignore_errors' in reserved
    assert 'run_once' in reserved
    assert 'sudo' in reserved
    assert 'sudo_user' in reserved
    assert 'remote_user' in reserved
    assert 'any_errors_fatal' in reserved
    assert 'vars' in reserved
    assert 'with_' in reserved
    assert 'when' in reserved
    assert 'changed_when' in reserved
    assert 'failed_when' in reserved


# Generated at 2022-06-11 19:22:01.713257
# Unit test for function get_reserved_names
def test_get_reserved_names():
    class_list = [Play, Role, Block, Task]
    for aclass in class_list:
        aobj = aclass()
        for attr in aobj.__dict__['_attributes']:
            assert attr in get_reserved_names()

# Generated at 2022-06-11 19:22:09.229306
# Unit test for function get_reserved_names
def test_get_reserved_names():

    class TestMe:
        _attributes = dict()
        _attributes['test1'] = dict()
        _attributes['test2'] = dict()
        _attributes['test3'] = dict(private=True)

    test = TestMe()
    assert test._attributes.keys() == ['test1', 'test2', 'test3']

    assert get_reserved_names() == get_reserved_names()
    assert len(get_reserved_names()) == len(get_reserved_names(include_private=False))

# Generated at 2022-06-11 19:22:20.419750
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'play' in reserved_names
    assert 'block' in reserved_names
    assert 'task' in reserved_names
    assert 'vars_files' in reserved_names

    # local_action is part of action
    assert 'local_action' in reserved_names

    # with_ is implied with loop
    assert 'with_' in reserved_names

    # block tags are special
    assert 'when' in reserved_names

    assert 'action' in reserved_names
    assert 'any_errors_fatal' in reserved_names
    assert 'block' in reserved_names
    assert 'changed_when' in reserved_names
    assert 'connection' in reserved_names
    assert 'delay'

# Generated at 2022-06-11 19:22:32.109894
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # nothing public should be in the private list
    assert _RESERVED_NAMES.isdisjoint(get_reserved_names(include_private=False))

    # list should contain the common action attribute
    assert 'action' in _RESERVED_NAMES

    # action should imply local_action
    assert 'local_action' in _RESERVED_NAMES

    # 'try' is deprecated but still a reserved word
    assert 'try' in _RESERVED_NAMES
    display.deprecated("'try:' is deprecated and will be removed in version 2.5. Use 'block:' instead.")

    # 'with_' is deprecated but still a reserved word
    assert 'with_' in _RESERVED_NAMES

# Generated at 2022-06-11 19:22:34.869773
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names(include_private=False)) == 29
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-11 19:22:44.948191
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_reserved = get_reserved_names()
    private_reserved = get_reserved_names(include_private=True)

    assert 'hosts' in public_reserved
    assert 'action' in public_reserved
    assert 'local_action' in public_reserved
    assert 'with_' in public_reserved

    assert 'roles' in public_reserved
    assert 'role_path' in public_reserved
    assert 'name' in public_reserved
    assert 'include' in public_reserved
    assert 'block' in public_reserved
    assert 'block_vars' in public_reserved
    assert 'task' in public_reserved
    assert 'pre_tasks' in public_reserved
    assert 'post_tasks' in public_reserved

# Generated at 2022-06-11 19:22:55.243327
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """Verify that the set of reserved names matches what we believe they are."""
    expected_public = set(['any_errors_fatal', 'become', 'connection', 'delegate_to', 'environment', 'first_available_file', 'ignore_errors', 'local_action', 'name', 'no_log', 'notify', 'poll', 'register', 'remote_user', 'tags', 'transport', 'until', 'vars_prompt', 'vars_files', 'with_', 'when'])
    expected_private = set(['changed_when', 'failed_when', 'ignore_errors', 'loop', 'loop_control', 'notify', 'register'])
    assert set(get_reserved_names(include_private=True)) == expected_public.union(expected_private)