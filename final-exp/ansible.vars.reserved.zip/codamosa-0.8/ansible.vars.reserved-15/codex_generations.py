

# Generated at 2022-06-11 19:13:51.359992
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:01.740751
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:12.451906
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Test to make sure the reserved names are getting properly discovered
    '''

    # Have a set of variables to test against
    test_set = set([
        'any_errors_fatal', 'become', 'become_method',
        'become_user', 'connection', 'delegate_to', 'gather_facts',
        'no_log', 'notify', 'remote_user', 'roles', 'serial',
        'sudo', 'sudo_user', 'tags', 'until', 'when'
    ])

    # Get the list of reserved names
    result = get_reserved_names()

    # The length should be 38 because we have 38 reserved names
    assert len(result) == 38, \
           "The length of the reserved names is not 38: [%d]" % len(result)

    # Make sure

# Generated at 2022-06-11 19:14:22.335316
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert_equal(get_reserved_names(include_private=False), frozenset(['action', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'connection', 'delegate_to', 'environment', 'gather_facts', 'hosts', 'ignore_errors', 'include', 'loop', 'notify', 'pre_tasks', 'post_tasks', 'remote_user', 'roles', 'serial', 'strategy', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'with_', 'local_action']))

# Generated at 2022-06-11 19:14:28.572184
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.utils import plugin_docs

    module = plugin_docs._get_docstring('action')[1]

    # _get_docstring returns a yaml docstring, so check the first line of the yaml docstring
    if module[0:9] != '---\nname: ':
        raise AssertionError('get_reserved_names function returns incorrect value')

# Generated at 2022-06-11 19:14:36.763218
# Unit test for function get_reserved_names
def test_get_reserved_names():

    public = set()
    private = set()
    result = set()

    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    if 'loop' in private or 'loop' in public:
        public.add('with_')

    # Check if reserved names are returned as expected
    result = public.union(private)
    assert(_RESERVED_NAMES == result)

   

# Generated at 2022-06-11 19:14:38.746630
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) < len(get_reserved_names(True))

# Generated at 2022-06-11 19:14:46.853444
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = ['roles', 'tasks', 'handlers', 'block', 'block>', 'block', 'include', 'action', 'defaults', 'vars', 'pre_tasks', 'post_tasks', 'fail_when', 'any_errors_fatal', 'ignore_errors', 'connection', 'delegate_to', 'local_action', 'when', 'notify', 'register', 'first_available_file', 'hosts', 'name', 'include_role', 'pre_tasks', 'tasks', 'post_tasks', 'vars', 'defaults', 'meta', 'block', 'block>', 'block']

    assert sorted(list(get_reserved_names())) == sorted(reserved)

# Generated at 2022-06-11 19:14:58.156726
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # we should handle cases in which the input list is not sorted
    class_list = [Play, Block, Task, Role]

    # test with private names included
    reserved_names = get_reserved_names(include_private=True)
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            assert attribute in reserved_names

    # test without private names included
    reserved_names = get_reserved_names()
    assert 'action' in reserved_names
    assert 'local_action' not in reserved_names
    for aclass in class_list:
        aobj = aclass()

# Generated at 2022-06-11 19:15:03.869401
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not _RESERVED_NAMES.isdisjoint(['name', 'action', 'any_errors_fatal', 'local_action'])
    assert 'tags' not in _RESERVED_NAMES
    assert 'hosts' not in _RESERVED_NAMES
    assert 'roles' not in _RESERVED_NAMES


# Generated at 2022-06-11 19:15:19.487896
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:21.671754
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 54
    assert len(get_reserved_names(include_private=False)) == 32

# Generated at 2022-06-11 19:15:28.752649
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:34.301813
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'name' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()

    assert 'post_validate' in get_reserved_names(include_private=True)
    assert 'post_validate' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:15:37.694650
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(False)
    aclass = Play()
    for attribute in aclass.__dict__['_attributes']:
        if 'private' not in attribute:
            assert attribute in reserved_names

# Generated at 2022-06-11 19:15:41.437724
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names(False)
    assert 'name' in get_reserved_names(False)
    assert 'action' in get_reserved_names(False)
    assert 'tags' in get_reserved_names(False)
    assert 'register' in get_reserved_names(False)


# Generated at 2022-06-11 19:15:49.806378
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

# Generated at 2022-06-11 19:15:54.320738
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(False) == frozenset(get_reserved_names(False))

# Generated at 2022-06-11 19:16:01.891285
# Unit test for function get_reserved_names
def test_get_reserved_names():

    my_names = get_reserved_names()
    assert isinstance(my_names, frozenset)
    assert len(my_names) > 0
    assert 'name' in my_names
    assert 'action' in my_names
    assert 'local_action' in my_names

    my_names = get_reserved_names(include_private=False)
    assert isinstance(my_names, frozenset)
    assert len(my_names) > 0
    assert 'name' in my_names
    assert 'action' in my_names
    assert 'local_action' not in my_names
    assert 'when' in my_names
    assert 'ignore_errors' in my_names
    assert 'delegate_to' in my_names


# Generated at 2022-06-11 19:16:09.367303
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'action' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'include' in reserved_names
    assert 'roles' in reserved_names
    assert 'tags' in reserved_names
    assert 'hosts' in reserved_names
    assert 'vars' in reserved_names
    assert 'tasks' in reserved_names
    assert 'game_console' in reserved_names

# Generated at 2022-06-11 19:16:29.674085
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == {'action', 'connection', 'delegate_to', 'gather_facts', 'ignore_errors', 'loop', 'name', 'notify', 'register', 'remote_user', 'roles', 'sudo', 'sudo_user', 'tags', 'tasks', 'vars', 'with_'}

    if 'local_action' in get_reserved_names(include_private=False):
        raise Exception('test for get_reserved_names() failed')


# Generated at 2022-06-11 19:16:37.105889
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:16:47.992852
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names(include_private=False)
    assert 'hosts' in names
    assert 'vars' in names
    assert 'action' in names
    assert 'local_action' in names
    assert 'any_errors_fatal' in names

    names = get_reserved_names(include_private=True)
    assert 'hosts' in names
    assert 'vars' in names
    assert 'action' in names
    assert 'local_action' in names
    assert 'any_errors_fatal' in names
    assert 'loops' in names
    assert 'loop' in names
    assert 'with_' in names
    assert 'with_fileglob' in names
    assert 'with_fileglob' in names
    assert 'with_first_found' in names

# Generated at 2022-06-11 19:16:52.747958
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'connection' in get_reserved_names()

    assert 'serial' in get_reserved_names()
    assert 'serial' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:17:03.866910
# Unit test for function get_reserved_names
def test_get_reserved_names():
    RESERVED_NAMES_COUNT = 31
    # NOTE: list below is sorted alphabetically

# Generated at 2022-06-11 19:17:11.432648
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' return value test for function get_reserved_names'''

    assert 'action' in get_reserved_names(include_private=True)
    assert 'local_action' in get_reserved_names(include_private=True)
    assert '_private' in get_reserved_names(include_private=True)
    assert '_private' not in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names(include_private=True)
    assert 'loop' in get_reserved_names(include_private=True)
    assert 'with_' in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:17:22.322239
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:24.096204
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES

# Generated at 2022-06-11 19:17:29.756510
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert_msg = "Failure in test_get_reserved_names for %s"
    expected = frozenset(['tags', 'connection', 'environment', 'failed_when', 'ignore_errors', 'always_run', 'any_errors_fatal',
                          'block', 'block:', 'meta', 'notify', 'register', 'run_once', 'remote_user', 'sudo', 'sudo_user',
                          'until', 'async', 'poll', 'name', 'local_action', 'with_', 'with_items'])
    assert _RESERVED_NAMES == expected, assert_msg % '- Public attributes'


# Generated at 2022-06-11 19:17:37.888629
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(include_private=False)
    assert(set(public_names) == set(['hosts', 'gather_facts', 'tasks', 'name', 'roles', 'vars_files', 'tags', 'register', 'ignore_errors', 'action', 'local_action', 'with_']))

    private_names = get_reserved_names(include_private=True)
    assert(set(private_names) == set(['hosts', 'gather_facts', 'tasks', 'name', 'roles', 'vars_files', 'tags', 'register', 'ignore_errors', 'serial', 'action', 'local_action', 'with_', 'loop']))

# Generated at 2022-06-11 19:17:57.519634
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Assert that there is a class for each reserved word in the role directory
    play_path = Play()._load_attr_module().__path__[0]  # get path to Play
    class_list = [Play, Role, Block, Task]
    role_reserved_names = [role.__name__ for role in class_list]
    assert set(role_reserved_names).issubset(set(get_reserved_names()))

    # Assert that the set of reserved names is a subset of the public and private
    assert set(role_reserved_names) < set(get_reserved_names())

    # Assert that special reserved names are picked up
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_

# Generated at 2022-06-11 19:18:05.502586
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(True), set)
    assert isinstance(get_reserved_names(False), set)
    assert 'hosts' in get_reserved_names()
    assert 'hosts' in get_reserved_names(True)
    assert 'hosts' in get_reserved_names(False)
    assert 'task_tags' in get_reserved_names()
    assert 'task_tags' in get_reserved_names(True)
    assert 'task_tags' not in get_reserved_names(False)
    assert 'loop' in get_reserved_names()
    assert 'loop' in get_reserved_names(True)
    assert 'loop' not in get_reserved_names(False)
   

# Generated at 2022-06-11 19:18:10.952836
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_only = get_reserved_names(include_private=False)
    public_and_private = get_reserved_names(include_private=True)

    # We check that private names are also in public names
    # as private names are not reserved for use by users.
    assert set(public_and_private.difference(public_only)) < set(public_and_private)

# Generated at 2022-06-11 19:18:17.452930
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import sys
    import os
    import warnings
    import unittest

    try:
        import unittest2 as unittest
    except ImportError:
        pass

    class TestGetReservedNames(unittest.TestCase):

        def setUp(self):
            self._reserved = get_reserved_names()
            self._original_warnings = warnings.showwarning

        def tearDown(self):
            warnings.showwarning = self._original_warnings

        def test_is_frozenset(self):
            self.assertTrue(isinstance(self._reserved, frozenset))

        def test_is_not_empty(self):
            self.assertTrue(self._reserved)

        def test_contains_name(self):
            self.assertTrue('roles' in self._reserved)

# Generated at 2022-06-11 19:18:27.905789
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:18:37.362456
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert Play.vars.name in reserved
    assert Play.vars_prompt.name in reserved
    assert Role.defaults.name in reserved
    assert Role.handlers.name in reserved
    assert Role.tasks.name in reserved
    assert Task.action.name in reserved
    assert Task.local_action.name in reserved
    assert Task.delegate_to.name in reserved
    assert Task.register.name in reserved
    assert Task.ignore_errors.name in reserved
    assert Task.sudo.name in reserved
    assert Task.sudo_user.name in reserved
    assert Task.when.name in reserved
    assert Task.with_.name in reserved
    assert Task.tags.name in reserved
    assert False == (Task.with_items.name in reserved)

    private = get_

# Generated at 2022-06-11 19:18:44.095046
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function exercises the get_reserved_names function '''
    good_set = set(['name', 'hosts', 'roles', 'vars', 'vars_files', 'tasks'])

    # test with all possible options
    result = get_reserved_names(include_private=True)
    assert result == good_set, \
        'incorrect results with include_private=True, got %s, expected %s' % \
        (result, good_set)

    result = get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:18:50.737417
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_names = get_reserved_names()
    # Test the returned set of names to see if it is of the correct
    # type and if the expected names are present.

    assert isinstance(test_names, set)
    assert 'roles' in test_names
    assert 'post_tasks' in test_names
    assert 'pre_tasks' in test_names
    assert 'gather_facts' in test_names
    assert 'vars' in test_names



# Generated at 2022-06-11 19:18:53.604739
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names(include_private=False)) == 13
    assert len(get_reserved_names(include_private=True)) == 43

# Generated at 2022-06-11 19:19:01.950403
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(['name', 'hosts', 'roles', 'tasks', 'action']) == get_reserved_names(include_private=False)
    assert set(['name', 'hosts', 'roles', 'tasks', 'action', 'private', 'dep_chain',
                'task_include', 'strategy', 'when', 'changed_when', 'failed_when',
                'include', 'import_role', 'include_role', 'include_tasks', 'loop',
                'register', 'remote_user', 'sudo', 'sudo_user', 'vars_prompt',
                'vars_files', 'vault_password_file', 'no_log', 'run_once']) == get_reserved_names(include_private=True)



# Generated at 2022-06-11 19:19:36.412575
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' return the list of reserved words associated with play objects'''

# Generated at 2022-06-11 19:19:39.047772
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'vars' in reserved_names
    assert 'roles' in reserved_names



# Generated at 2022-06-11 19:19:44.386900
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ret1 = get_reserved_names(include_private=False)
    assert isinstance(ret1, set), 'function did not return expected type set'
    assert len(ret1) == 11, 'function did not return expected number of names'

    ret2 = get_reserved_names(include_private=True)
    assert isinstance(ret2, set), 'function did not return expected type set'
    assert len(ret2) == 19, 'function did not return expected number of names'

# Generated at 2022-06-11 19:19:55.111391
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:19:58.113466
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # This is a reserved word
    assert 'port' in get_reserved_names()

    # This is not a reserved word.
    assert 'bogus' not in get_reserved_names()

# Generated at 2022-06-11 19:20:06.393077
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:20:07.516800
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()



# Generated at 2022-06-11 19:20:11.327953
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == _RESERVED_NAMES
    assert set(get_reserved_names(include_private=False)) == _RESERVED_NAMES.difference(set(['private']))
    assert 'private' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:20:19.617720
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:20:28.753390
# Unit test for function get_reserved_names
def test_get_reserved_names():

    class _TestObj:

        def __init__(self):
            self._attributes = {'attr1': None}
            self._private_attributes = {'p_attr1': None}
            self._get_attr1 = None
            self._p_get_p_attr1 = None
            self._set_attr1 = None
            self._p_set_p_attr1 = None

    # test getting all public and private reserved names
    to = _TestObj()
    to.attr1 = 'attr1'
    to.p_attr1 = 'p_attr1'
    attrs = get_reserved_names()
    assert('attr1' in attrs)
    assert('p_attr1' in attrs)

    # test getting only public reserved names
    to = _TestObj()
    to.attr1

# Generated at 2022-06-11 19:20:57.003988
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(_RESERVED_NAMES) > 0
    assert isinstance(_RESERVED_NAMES, frozenset)

# Generated at 2022-06-11 19:20:58.164355
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert 'gather_facts' in result

# Generated at 2022-06-11 19:21:06.707046
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:21:15.960130
# Unit test for function get_reserved_names
def test_get_reserved_names():

    private = get_reserved_names(include_private=False)
    private_and_public = get_reserved_names(include_private=True)

    # a few sanity checks
    assert 'hosts' in private_and_public
    assert 'name' in private_and_public
    assert 'pre_tasks' in private_and_public

    assert 'private' in private_and_public
    assert 'private' not in private

    assert 'local_action' in private_and_public
    assert 'with_' in private_and_public

    assert 'private' in [i for i in private_and_public if i.startswith('private')]
    assert 'with_' in [i for i in private_and_public if i.startswith('with')]

    # now some validates

# Generated at 2022-06-11 19:21:18.747240
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert frozenset(get_reserved_names(include_private=False)).difference(frozenset(['action', 'local_action', 'with_'])) == frozenset([])

# Generated at 2022-06-11 19:21:26.793375
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This does not test private attributes, as that is considered an implementation detail,
    but it does make sure some public attributes from various play objects are returned
    '''

    # Build list of reserved attributes outside of function scope
    reserved_names_without_private = set()


# Generated at 2022-06-11 19:21:29.901831
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert "any_errors_fatal" in _RESERVED_NAMES
    assert "_private_any_errors_fatal" in _RESERVED_NAMES

# Generated at 2022-06-11 19:21:37.782888
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # currently the public reserved names are
    # {'action', 'roles', 'hosts', 'gather_facts', 'vars', 'tasks', 'block', 'become', 'become_user', 'become_method', 'name', 'include', 'include_role', 'tags', 'when', 'notify', 'vars_prompt', 'vars_files', 'pre_tasks', 'post_tasks', 'handlers', 'any_errors_fatal', 'max_fail_percentage', 'remote_user'}
    # {'loop', 'register'}

    # verify the length of the list is correct
    assert len(get_reserved_names(False)) == 33

    # verify some of the values in the list are correct
    assert 'action' in get_reserved_names(False)

# Generated at 2022-06-11 19:21:47.696123
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import ast
    import inspect
    from ansible.playbook import Play, Task

    test_dict = ast.literal_eval(get_reserved_names(include_private=False))
    test_list = list(test_dict)

    def test_func():
        pass

    assert isinstance(test_dict, set), "get_reserved_names should return set"

    # get_reserved_names() return names(keys) of Play.__dict__
    play_inspect = inspect.getmembers(Play)
    play_vars = [x[0] for x in play_inspect if not x[0].startswith('_')]
    play_vars.remove('vars')  # we add this one internally, so safe to ignore

    # check length

# Generated at 2022-06-11 19:21:58.117968
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:32.984471
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:43.141395
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:49.539452
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=True)

    # The reserved words should be returned as a set.
    assert isinstance(reserved, set)

    # Check that the reserved words include public ones.
    assert 'name' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved

    # Check that the reserved words include private ones.
    assert '_role' in reserved
    assert '_raw_params' in reserved
    assert 'become' in reserved
    assert 'become_method' in reserved

    reserved = get_reserved_names(include_private=False)

    # Check that the nonprivate reserved words include public ones.
    assert 'name' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved

# Generated at 2022-06-11 19:22:52.742266
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)


# Generated at 2022-06-11 19:22:54.090001
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 73



# Generated at 2022-06-11 19:22:57.123095
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'local_action' in reserved_names


# Generated at 2022-06-11 19:23:04.042869
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import ansible.playbook.deprecated
    import ansible.playbook.role_include
    import ansible.plugins.loader
    import ansible.plugins.task

    # Check if function returns a list
    assert isinstance(get_reserved_names(), set)

    # Check if any reserved name is in the list
    assert is_reserved_name('atask')
    assert is_reserved_name('roles')
    assert is_reserved_name('blocks')

    # Check if not existing reserved names from different modules are not in the list
    assert not is_reserved_name('strname')
    assert not is_reserved_name('None')

# Generated at 2022-06-11 19:23:12.454596
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    # set to ensure no duplicates
    assert len(get_reserved_names()) == len(_RESERVED_NAMES)
    # set to ensure no duplicates
    assert len(get_reserved_names(include_private=False)) == len(set(_RESERVED_NAMES) - set(get_reserved_names(include_private=False)))



# Generated at 2022-06-11 19:23:17.642723
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check that all reserved names are in the set of public + private names
    assert set(_RESERVED_NAMES).issubset(set(get_reserved_names(True)))
    assert set(_RESERVED_NAMES).issubset(set(get_reserved_names(False)))

# Generated at 2022-06-11 19:23:23.102046
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get_reserved_names returns a set of strings
    assert isinstance(get_reserved_names(), frozenset)

    # get_reserved_names contains names of variables with and without private
    assert 'action' in get_reserved_names()
    assert 'private_action' in get_reserved_names(include_private=True)
    assert 'private_action' not in get_reserved_names(include_private=False)