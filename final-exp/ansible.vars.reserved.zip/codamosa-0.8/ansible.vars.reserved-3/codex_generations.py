

# Generated at 2022-06-11 19:13:53.115396
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names(include_private=False) == set(['name', 'hosts', 'roles', 'gather_facts', 'tasks', 'vars', 'any_errors_fatal',
                                              'become', 'tags', 'until', 'delegate_to', 'environment', 'remote_user', 'gather_subset',
                                              'gather_timeout', 'when', 'always_run', 'ignore_errors', 'notify', 'handlers', 'local_action']))

# Generated at 2022-06-11 19:13:59.448312
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # function should return a set/frozenset of strings
    assert isinstance(get_reserved_names(), (set, frozenset))
    assert isinstance(get_reserved_names(include_private=False), (set, frozenset))
    # function should return at least one item
    assert len(get_reserved_names()) > 0
    assert len(get_reserved_names(include_private=False)) > 0



# Generated at 2022-06-11 19:14:10.072734
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Verify we have a full set of reserved names
    names = get_reserved_names()
    for attr in Play()._attributes:
        # Skip private names
        if 'private' in attr:
            continue
        if attr not in names:
            raise AssertionError("missing attribute %s" % attr)

    # Verify private names are included when requested
    private_names = [attr for attr in Play()._attributes if 'private' in attr]
    names = get_reserved_names(include_private=True)
    for attr in private_names:
        if attr not in names:
            raise AssertionError("missing private attribute %s" % attr)

# Generated at 2022-06-11 19:14:12.639526
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # just see that we get back sane values
    assert type(_RESERVED_NAMES) is frozenset
    assert len(_RESERVED_NAMES) > 0



# Generated at 2022-06-11 19:14:22.397183
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'import_playbook' in get_reserved_names()
    assert 'import_role' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'connection' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'environment' in get_reserved_names()
    assert 'no_log' in get_reserved_names()
    assert 'include' in get_reserved_names

# Generated at 2022-06-11 19:14:33.525688
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the functionality of get_reserved_names '''

    # verify function returns a set
    assert isinstance(get_reserved_names(), set)

    # verify that the names are in upper case
    result = get_reserved_names()
    assert 'ACTION' in result

    # verify that no missing names
    result = get_reserved_names()
    assert 'ANY_ERRORS_FATAL' in result
    assert 'ANY_ERRORS_FATAL' in result
    assert 'CONNECTION' in result
    assert 'CONTINUATION' in result
    assert 'DELEGATED_VARS' in result
    assert 'DIFF' in result
    assert 'ENVIRONMENT' in result
    assert 'ERROR_ON_UNDEFINED_VARS' in result

# Generated at 2022-06-11 19:14:44.342567
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Sort the returned list to make test output match stub
    assert sorted(get_reserved_names()) == sorted([
        'action', 'any_errors_fatal', 'become',
        'become_user', 'block', 'changed_when',
        'connection', 'delegate_to', 'delegate_facts',
        'environment', 'failed_when', 'ignore_errors',
        'include', 'include_tasks', 'local_action',
        'loop', 'name', 'notify', 'notify_only', 'register',
        'retries', 'role', 'run_once', 'serial', 'sudo',
        'sudo_user', 'tags', 'tier', 'tasks', 'vars',
        'until', 'when', 'with_'
    ])

# Generated at 2022-06-11 19:14:55.524372
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed

# Generated at 2022-06-11 19:15:04.321284
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_attributes = set(['action', 'block', 'delegate_to', 'delegate_facts', 'deprecate_hosts', 'deprecate_groups', 'connection', 'ignore_errors', 'loop',
                           'name', 'no_log', 'notify', 'notify_content', 'register', 'tags', 'until', 'vars', 'when', 'any_errors_fatal', 'always_run',
                           'remote_user', 'sudo', 'sudo_user', 'su', 'su_user', 'transport', 'environment', 'role_name', 'ignore_errors'])

    attributes = get_reserved_names()

    assert attributes == test_attributes, "get_reserved_names has changed, please update test_get_reserved_names if this is expected"


# Generated at 2022-06-11 19:15:13.242626
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES == frozenset(['hosts', 'pre_tasks', 'roles', 'tasks', 'vars_files', 'action', 'post_tasks',
                                         'handlers', 'include', 'vars', 'name', 'register', 'any_errors_fatal',
                                         'connection', 'gather_facts', 'become', 'become_user', 'includes', 'when',
                                         'async', 'delegate_to', 'delegate_facts', 'notify', 'loop', 'until', 'run_once',
                                         'block', 'rescue', 'always', 'meta', 'import_role', 'include_role', 'tags',
                                         'when', 'local_action', 'with_'])

# Generated at 2022-06-11 19:15:30.659076
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)

# Generated at 2022-06-11 19:15:40.613834
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tags' in reserved
    assert 'connection' in reserved
    assert 'gather_facts' in reserved
    assert 'vars_prompt' in reserved
    assert 'register' in reserved
    assert 'ignore_errors' in reserved
    assert 'any_errors_fatal' in reserved
    assert 'no_log' in reserved
    assert 'post_tasks' in reserved
    assert 'pre_tasks' in reserved
    assert 'when' in reserved
    assert 'become_user' in reserved
    assert 'become' in reserved
    assert 'become_method' in reserved
    assert 'remote_user' in reserved
    assert 'delegate_to' in reserved

# Generated at 2022-06-11 19:15:49.271320
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:54.719001
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=False)
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'role_path' not in reserved
    assert 'roles_path' not in reserved

# Generated at 2022-06-11 19:15:58.056921
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert len(reserved_names) > 0
    assert 'vars' in reserved_names
    assert 'action' in reserved_names
    assert 'with_' in reserved_names



# Generated at 2022-06-11 19:16:09.779274
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the output of get_reserved_names '''

    # test public names
    public_names = get_reserved_names(include_private=False)
    assert 'name' in public_names
    assert 'roles' in public_names
    assert 'hosts' in public_names
    assert 'action' in public_names
    assert 'local_action' in public_names
    assert 'block' in public_names
    assert 'tags' in public_names
    assert 'vars' in public_names
    assert 'gather_facts' in public_names
    assert 'serial' in public_names
    assert 'when' in public_names
    assert 'connection' in public_names
    assert 'with_' in public_names
    assert 'delegate_to' in public_names

# Generated at 2022-06-11 19:16:11.229461
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Ensure that base blueprints have not changed
    assert get_reserved_names() == frozenset()

# Generated at 2022-06-11 19:16:20.393659
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names()
    reserved_private = get_reserved_names(include_private=True)

    # test that loop implies with_, and that local_action implies action
    assert 'loop' in reserved_private
    assert 'with_' in reserved_private
    assert 'action' in reserved_private
    assert 'local_action' in reserved_private

    assert 'action' in reserved
    assert 'local_action' not in reserved
    assert 'loop' not in reserved  # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' not in reserved  # FIXME: remove after with_ is not only deprecated but removed

    assert 'tags' in reserved
    assert 'always_run' in reserved
    assert 'any_errors_fatal' in reserved
    assert 'become' in reserved
   

# Generated at 2022-06-11 19:16:26.386339
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' verify that the reserved names cannot be accessed like a normal
    variable '''
    reserved = get_reserved_names()

    assert 'connection' in reserved
    assert 'vars' in reserved
    assert 'any_errors_fatal' in reserved

    # verify that the reserved names are private attributes
    player = Play()
    for name in reserved:
        try:
            player.name
        except AttributeError:
            continue
        except:
            raise
        else:
            raise AssertionError('Attribute %s is not private!' % name)

# Generated at 2022-06-11 19:16:37.343587
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests get_reserved_names function'''
    # testing public
    assert 'hosts' in get_reserved_names()
    assert 'connection' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()

    # testing private (default)
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()

    # testing not private
    assert 'name' not in get_reserved_names(include_private=False)
    assert 'roles' not in get_reserved_names(include_private=False)
    assert 'vars_files' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:17:12.826623
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:16.565664
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'delegate_to' in get_reserved_names()
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'notify' in get_reserved_names()



# Generated at 2022-06-11 19:17:22.226911
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this test ensures that get_reserved_names produces valid reserved names '''

    result = get_reserved_names()
    assert isinstance(result, set)

    # assert that keywords for task module are part of result
    # FIXME: get these from the modules instead
    assert 'command' in result
    assert 'local_action' in result
    assert 'with_' in result


# Generated at 2022-06-11 19:17:32.247419
# Unit test for function get_reserved_names
def test_get_reserved_names():

    public = set(['gather_facts', 'hosts', 'name', 'remote_user', 'serial', 'tasks', 'vars', 'vars_prompt', 'vars_files'])

# Generated at 2022-06-11 19:17:35.450031
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test for function get_reserved_names()'''
    x = get_reserved_names()
    # test for minimum number of names in reserved list
    assert len(x) > 175

# Generated at 2022-06-11 19:17:42.763792
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names function '''

    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

    # if 'name' is found with include_private=False, something is wrong
    assert('name' not in public)
    assert('name' in private)
    # local_action should be in both
    assert('local_action' in public)
    assert('local_action' in private)



# Generated at 2022-06-11 19:17:45.792021
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names(include_private=False)) > len(get_reserved_names(include_private=True))
    assert 'name' in get_reserved_names()
    assert len(_RESERVED_NAMES) > 1

# Generated at 2022-06-11 19:17:53.938981
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['action', 'become', 'become_user', 'block', 'connection', 'delegate_to', 'delegate_facts', 'ignore_errors', 'local_action', 'loop', 'notify', 'remote_user', 'until', 'wait_for', 'with_', 'with_dict', 'with_file', 'with_first_found', 'with_items', 'with_lines', 'with_nested', 'with_sequence', 'with_subelements', 'with_together', 'with_together', 'with_two_loops', 'when'])

# Generated at 2022-06-11 19:18:00.392966
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert reserved, "Reserved names are: %s" % reserved
    assert 'action' in reserved, "'action' not in reserved"
    assert 'cacheable' in reserved, "'cacheable' not in reserved"
    assert 'serial' in reserved, "'serial' not in reserved"
    assert 'any_errors_fatal' in reserved, "'any_errors_fatal' not in reserved"
    assert 'gather_facts' in reserved, "'gather_facts' not in reserved"
    assert 'connection' in reserved, "'connection' not in reserved"
    assert 'sudo' in reserved, "'sudo' not in reserved"
    assert 'sudo_user' in reserved, "'sudo_user' not in reserved"
    assert 'sudo_pass' not in reserved, "'sudo_pass' not in reserved"
   

# Generated at 2022-06-11 19:18:11.404644
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    # these names are implicit with action
    assert 'local_action' in reserved
    assert 'with_' in reserved

    # make sure we have action and loop before removing them
    assert 'action' in reserved
    assert 'loop' in reserved

    # get rid of implicit names
    reserved.remove('local_action')
    reserved.remove('with_')
    if 'action' in reserved:
        reserved.remove('action')

    if 'loop' in reserved:
        reserved.remove('loop')

    # make sure the ones we expect are in the list
    assert 'delegate_to' in reserved
    assert 'post_tasks' in reserved
    assert 'pre_tasks' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'vars'

# Generated at 2022-06-11 19:19:11.267160
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests get_reserved_names function'''
    results = get_reserved_names()
    assert isinstance(results, set)
    assert len(results) > 0

    results = get_reserved_names(False)
    assert isinstance(results, set)
    assert len(results) > 0

    results = get_reserved_names(False)
    assert isinstance(results, set)
    assert len(results) > 0

# Generated at 2022-06-11 19:19:16.831244
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Create an empty set, add one value.
    public = set()
    public.add('hosts')

    # This is a set already
    private = set(['tags', 'gather_facts'])

    result = public.union(private)
    assert result == _RESERVED_NAMES

# Generated at 2022-06-11 19:19:19.676749
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=True)
    assert 'name' in reserved_names
    assert 'roles' in reserved_names
    assert 'import_playbook' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'handlers' in reserved_names


# Unit tests for function warn_if_reserved

# Generated at 2022-06-11 19:19:27.089314
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function runs all the tests associated with get_reserved_names '''


# Generated at 2022-06-11 19:19:29.698961
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert len(_RESERVED_NAMES) > 10

# Generated at 2022-06-11 19:19:34.381438
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == _RESERVED_NAMES
    assert set(get_reserved_names(include_private=False)) == (set(get_reserved_names()) - set(get_reserved_names(include_private=True)))


# Generated at 2022-06-11 19:19:43.909330
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset({
        'become', 'become_user', 'connection', 'delegate_to', 'environment', 'ignore_errors', 'name', 'role', 'roles', 'strategy', 'tags', 'vars', 'with_', 'hosts', 'any_errors_fatal', 'block',
        'always_run'
    })
    assert get_reserved_names() == frozenset({
        'become', 'become_user', 'connection', 'delegate_to', 'environment', 'ignore_errors', 'name', 'any_errors_fatal', 'block', 'private', 'always_run', 'private',
        'role', 'roles', 'strategy', 'tags', 'vars', 'with_', 'hosts'
    })

# Generated at 2022-06-11 19:19:54.902035
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES.issuperset(['name', 'become', 'remote_user', 'connection', 'gather_facts', 'vars', 'register'])
    assert 'tags' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'pre_tasks' in _RESERVED_NAMES
    assert 'post_tasks' in _RESERVED_NAMES
    assert 'notify' in _RESERVED_NAMES
    assert 'pre_tasks' in _RESERVED_NAMES
    assert 'post_tasks' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES

# Generated at 2022-06-11 19:19:57.112695
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert len(get_reserved_names()) > 0



# Generated at 2022-06-11 19:20:01.439334
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names()

    assert 'hosts' in reserved
    assert 'vars' in reserved
    assert 'tasks' in reserved
    assert 'notify' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved


### Function warn_if_reserved()
### Unit test for function warn_if_reserved()


# Generated at 2022-06-11 19:21:58.117029
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function ensures the function get_reserved_names() returns the correct names'''


# Generated at 2022-06-11 19:22:08.265685
# Unit test for function get_reserved_names
def test_get_reserved_names():

    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed

# Generated at 2022-06-11 19:22:16.526607
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the function get_reserved_names '''

    test = get_reserved_names()

    assert 'hosts' in test, 'hosts missing from reserved names list'
    assert 'roles' in test, 'roles missing from reserved names list'
    assert 'tasks' in test, 'tasks missing from reserved names list'
    assert 'vars' in test, 'vars missing from reserved names list'
    assert 'hosts_all' not in test, 'hosts_all should not be in public reserved names list'



# Generated at 2022-06-11 19:22:23.884008
# Unit test for function get_reserved_names
def test_get_reserved_names():

    test = 'test'

    # verify the test is not currently a reserved name
    assert test not in _RESERVED_NAMES

    # add the test to the list of reserved names
    _TEST_RESERVED_NAMES = list(_RESERVED_NAMES)
    _TEST_RESERVED_NAMES.append(test)

    # get a fresh list of reserved names (including private)
    _TEST_RESERVED_NAMES = get_reserved_names(include_private=True)
    assert test in _TEST_RESERVED_NAMES

    # get a fresh list of reserved names (excluding private)
    _TEST_RESERVED_NAMES = get_reserved_names(include_private=False)
    assert test not in _TEST_RESERVED_

# Generated at 2022-06-11 19:22:30.109744
# Unit test for function get_reserved_names
def test_get_reserved_names():
    x = Play()
    x.vars = dict()
    x.post_validate()
    result = get_reserved_names(include_private=False)
    assert 'vars' in result
    assert 'loop' not in result
    assert 'with_' in result
    assert 'local_action' in result
    result = get_reserved_names(include_private=True)
    assert 'loop' in result
    assert 'tags' in result

# Generated at 2022-06-11 19:22:36.843750
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:39.712597
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # make sure we get a set back
    assert(isinstance(get_reserved_names(), set))

# Generated at 2022-06-11 19:22:43.847241
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' This function unit tests the get_reserved_names function '''

    reserved_names = get_reserved_names()

# Generated at 2022-06-11 19:22:49.413499
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test when not passing additional names
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'become_user' in reserved_names
    assert 'action' in reserved_names
    assert 'name' in reserved_names
    assert 'vars' in reserved_names
    assert 'tags' in reserved_names
    assert 'local_action' not in reserved_names

    # Test when passing additional names
    additional_names = set(['foo', 'bar'])
    reserved_names = get_reserved_names(additional=additional_names)
    assert 'foo' in reserved_names
    assert 'bar' in reserved_names



# Generated at 2022-06-11 19:22:59.749862
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Tests the get_reserved_names() function.
    '''

    # test public names
    public_names = get_reserved_names(include_private=False)
    assert 'gather_facts' in public_names, "verify the name 'gather_facts' is in reserved word list"
    assert 'name' in public_names, "verify the name 'name' is in reserved word list"
    assert 'tags' in public_names, "verify the name 'tags' is in reserved word list"
    assert 'environment' in public_names, "verify the name 'environment' is in reserved word list"
    assert 'loop' in public_names, "verify the name 'loop' is in reserved word list"