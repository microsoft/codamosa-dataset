

# Generated at 2022-06-11 19:13:51.896793
# Unit test for function warn_if_reserved

# Generated at 2022-06-11 19:14:01.988883
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test = {'action': 'test', 'when': True}
    warn_if_reserved(test)

    test = {'action': 'test', 'when': True, 'loop': [1,2,3]}
    warn_if_reserved(test)

    test = {'action': 'test', 'when': True, 'loop': [1,2,3], 'vars': {'not_a_reserved_name': 'true'}}
    warn_if_reserved(test['vars'], additional=('loop', 'not_a_reserved_name'))

    test = {'action': 'test', 'when': True, 'not_a_reserved_name': True}
    warn_if_reserved(test, additional=('not_a_reserved_name',))


# Generated at 2022-06-11 19:14:07.600151
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved({'hosts': '127.0.0.1', 'action': 'test_action'})
        warn_if_reserved({'action': 'test_action'})
    except Exception as e:
        assert False, 'Function warn_if_reserved failed with exception %s' % e

# Generated at 2022-06-11 19:14:15.284590
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for get_reserved_names '''
    actual_public = _RESERVED_NAMES


# Generated at 2022-06-11 19:14:22.535963
# Unit test for function get_reserved_names
def test_get_reserved_names():
    exp_names = frozenset(['hosts', 'roles', 'block', 'any_errors_fatal', 'become',
                           'become_user', 'gather_facts', 'name', 'name', 'name', 'name',
                           'serial', 'vars', 'vars_prompt', 'vars_files', 'action',
                           'local_action', 'with_', 'loop', 'task', 'block', 'include',
                           'delegate_to', 'register', 'ignore_errors', 'when', 'changed_when',
                           'failed_when'])
    assert _RESERVED_NAMES == exp_names



# Generated at 2022-06-11 19:14:29.243959
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    RESERVED_NAMES = get_reserved_names()
    assert type(RESERVED_NAMES) == set
    assert len(RESERVED_NAMES) > 0
    for reserved in RESERVED_NAMES:
        assert type(reserved) == AnsibleUnsafeText
        assert isinstance(reserved, str)

# Generated at 2022-06-11 19:14:32.871717
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['hosts', 'action', 'other']
    warn_if_reserved(myvars)
    assert is_reserved_name('hosts')
    assert is_reserved_name('action')
    assert is_reserved_name('other')

# Generated at 2022-06-11 19:14:43.876964
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import io
    import sys
    import tempfile
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    vars = {'new_var': 'new_var_value', 'action': 'action_value', 'hosts': 'hosts_value', 'private_var': 'private_var_value'}
    reserved_names = get_reserved_names()
    add_

# Generated at 2022-06-11 19:14:44.768756
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts'])

# Generated at 2022-06-11 19:14:55.664240
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' check that reserved names are identified and warned about '''
    warn_if_reserved(['become', 'tags', 'environment', 'any_errors_fatal', 'connection', 'environment', 'include', 'local_action', 'loop', 'name', 'no_log', 'post_tasks', 'pre_tasks', 'run_once', 'sudo_password', 'sudo_user', 'sudo', 'user', 'vars', 'with_'])
    warn_if_reserved(['name', 'any_errors_fatal', 'tags'], ['name', 'any_errors_fatal', 'tags'])
    warn_if_reserved(['name', 'any_errors_fatal', 'tags'], ['name', 'any_errors_fatal', 'tags', 'private'])

# Generated at 2022-06-11 19:15:06.895882
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: I have to hardcode the reserved names for now, we need a better way to get list
    result = get_reserved_names()


# Generated at 2022-06-11 19:15:15.373960
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get the list of publicly reserved names
    public = get_reserved_names(False)
    public_list = ['hosts', 'remote_user', 'vars', 'vars_files', 'roles', 'tasks', 'pre_tasks', 'post_tasks',
                   'any_errors_fatal', 'delegate_to', 'register', 'ignore_errors', 'environment', 'no_log',
                   'sudo', 'sudo_user', 'tags', 'when', 'run_once', 'always_run', 'delegated_vars', 'run_once',
                   'notify', 'handlers', 'meta', 'become', 'become_user', 'become_method', 'become_flags', 'setup',
                   'teardown', 'action']

    assert public == set(public_list)
   

# Generated at 2022-06-11 19:15:26.138076
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests get_reserved_names function to cover all the return paths '''


# Generated at 2022-06-11 19:15:37.853985
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this tests that get_reserved_names returns the correct values '''

    reserved_names = get_reserved_names(include_private=False)

    # we should have get_reserved_names + with_ (implied from loop) in the public non-private reserve list
    assert len(reserved_names) == len(get_reserved_names()) + 1

    # test that everything in the private list is not in the public list
    private_names = get_reserved_names(include_private=True).difference(reserved_names)
    assert not private_names.intersection(reserved_names)

    # test that we have local_action in the public list and not the private list
    assert 'local_action' in reserved_names
    assert 'local_action' not in private_names

    # test that we have with

# Generated at 2022-06-11 19:15:41.241822
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = set(['connection', 'delegate_to', 'name'])
    assert _RESERVED_NAMES.issuperset(names)



# Generated at 2022-06-11 19:15:48.152617
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=False)
    assert isinstance(result, set)
    assert 'action' in result
    assert 'local_action' not in result
    assert 'delegate_to' in result
    assert 'loop_control' not in result

    result = get_reserved_names(include_private=True)
    assert isinstance(result, set)
    assert 'action' in result
    assert 'local_action' in result
    assert 'delegate_to' in result
    assert 'loop_control' in result


# Generated at 2022-06-11 19:15:59.491528
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=True)
    assert reserved_names == frozenset(['gather_facts', 'hosts', 'roles', 'pre_tasks', 'post_tasks', 'tags', 'name', 'vars_files', 'vars_prompt', 'tasks', 'include', 'handlers', 'author', 'connection', 'sudo', 'sudo_user', 'remote_user', 'any_errors_fatal', 'max_fail_percentage', 'serial', 'environment', 'sudo_flags', 'transport', 'ignore_errors', 'implicit_local_action', 'force_handlers', 'tags', 'delegate_to', 'local_action', 'with_', 'block', 'loop'])



# Generated at 2022-06-11 19:16:03.166297
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Should get a list of reserved names
    assert get_reserved_names()
    # Should get a list of reserved names
    assert get_reserved_names(False)

# Generated at 2022-06-11 19:16:05.492253
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: need to compare output with expected output
    for name in get_reserved_names():
        print(name)

# Generated at 2022-06-11 19:16:11.490708
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test that there are expected reserved names
    assert 'roles' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES

    # make sure this function is tested in case it's been updated
    # list should be roughly 2/3 of the public set
    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes

# Generated at 2022-06-11 19:16:23.726396
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Make sure the list is what we expect it to be
    assert get_reserved_names() == frozenset(['hosts', 'vars', 'name', 'gather_facts', 'tasks', 'roles', 'include', 'any_errors_fatal', 'always_run', 'serial', 'action', 'local_action', 'with_', 'loop', 'tags', 'run_once', 'connection', 'delegate_to', 'delegate_facts'])
    # Make sure the list is frozen
    try:
        get_reserved_names().add('test')
    except AttributeError as e:
        assert "attribute 'add' of 'frozenset' object" in str(e)


# Generated at 2022-06-11 19:16:32.577965
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'hosts' in get_reserved_names(include_private=True)
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'hosts' in _RESERVED_NAMES

    assert 'action' in get_reserved_names()
    assert 'action' in get_reserved_names(include_private=True)
    assert 'action' in get_reserved_names(include_private=False)
    assert 'action' in _RESERVED_NAMES

    assert 'local_action' in get_reserved_names(include_private=True)
    assert 'local_action' not in get_reserved_names(include_private=False)
    assert 'local_action' not in _RESER

# Generated at 2022-06-11 19:16:35.855381
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # check that all reserved names are unique
    assert len(get_reserved_names()) == len(set(get_reserved_names()))

# Generated at 2022-06-11 19:16:39.760106
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'include' in reserved
    assert 'role' in reserved
    assert 'roles' in reserved
    assert 'block' in reserved

# Generated at 2022-06-11 19:16:50.670449
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_data = [
        {
            'include_private': True,
            'expected': set(['loop', 'action', 'remote_user', 'with_', 'connection', 'private', 'tags', 'notify', 'when', 'until', 'any_errors_fatal', 'register', 'ignore_errors', 'delegate_to', 'local_action']),
        },
        {
            'include_private': False,
            'expected': set(['action', 'remote_user', 'with_', 'connection', 'tags', 'notify', 'when', 'until', 'any_errors_fatal', 'register', 'ignore_errors', 'delegate_to', 'local_action']),
        },
    ]

    for test in test_data:
        yield check_reserved_names, test



# Generated at 2022-06-11 19:16:55.350556
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'roles' in reserved
    assert 'with_' in reserved
    assert 'when' in reserved

    reserved = get_reserved_names(include_private=False)
    assert 'roles' in reserved
    assert 'when' in reserved
    assert 'delegate_to' not in reserved



# Generated at 2022-06-11 19:17:06.473898
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()

# Generated at 2022-06-11 19:17:14.369806
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests that reserved names are correctly discoved '''

    import sys
    # these imported names will be excluded as we filter out anything starting with '_'
    myvars = sys._getframe().f_code.co_varnames

    # test private names are included by default
    result = get_reserved_names()
    assert 'tags' in result, 'tags not found in reserved names'

    # test private names are included by default
    result = get_reserved_names(include_private=False)
    assert 'tags' in result, 'tags not found in reserved names'

    # test that imported names are not marked as reserved
    assert not any(True for x in result if x in myvars), 'imported names should not be marked as reserved'

# Generated at 2022-06-11 19:17:20.817093
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test: get_reserved_names '''
    reserved_names = get_reserved_names()

    if len(reserved_names) == 0:
        raise AssertionError('No reserved names found')

    if 'hosts' not in reserved_names:
        raise AssertionError('hosts missing from reserved names')

    if 'roles' not in reserved_names:
        raise AssertionError('roles missing from reserved names')


# Generated at 2022-06-11 19:17:30.377609
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # initialize
    public = set()
    private = set()

    # build public and private lists
    reserved_names = get_reserved_names()
    for name in reserved_names:
        if name.startswith('_'):
            private.add(name)
        else:
            public.add(name)

    # local_action is implicit with action
    if 'action' in public:
        assert 'local_action' in public

    # loop implies with_
    if 'loop' in private or 'loop' in public:
        assert 'with_' in public

    # ensure all private names are also in public list
    assert public.union(private) == reserved_names



# Generated at 2022-06-11 19:17:47.229510
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:52.252197
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert len(names) == 22
    assert 'hosts' in names
    assert 'name' in names
    assert 'sudo' in names
    assert 'sudo_user' in names
    assert 'tasks' in names
    assert 'task' in names

# Generated at 2022-06-11 19:18:02.992387
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # public
    reserved_names = get_reserved_names()
    assert 'version' in reserved_names
    assert 'name' in reserved_names
    assert 'hosts' in reserved_names
    assert 'tasks' in reserved_names
    assert 'roles' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'tags' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'connection' in reserved_names
    assert 'any_errors_fatal' in reserved_names
    assert 'serial' in reserved_names
    assert 'sudo' in reserved_names
    assert 'sudo_user' in reserved_names
    assert 'transport' in reserved_names
    assert 'remote_user' in reserved_names


# Generated at 2022-06-11 19:18:12.271311
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # some of the reserved names are hardcoded (not dynamic), so make sure they're recognized
    hardcoded_names = [
        'roles',
        'hosts',
        'tasks',
        'vars',
        'pre_tasks',
        'post_tasks',
        'block',
        'rescue',
        'always',
        'connection',
        'remote_user',
        'any_errors_fatal',
        'ignore_errors',
        'max_fail_percentage',
        'max_fail_percentage',
        'gather_facts',
        'serial',
        'sudo_user',
        'sudo',
        'sudo_flags',
        'tags',
        'transport',
        'when',
        'delegate_to',
    ]

# Generated at 2022-06-11 19:18:15.700740
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # verify that reserved names are found
    for attr in get_reserved_names():
        assert is_reserved_name(attr)

    # verify that non reserved names are not found
    for attr in ['bad_name', 'delegate_to', 'remote_user', 'serial', 'also_bad_name']:
        assert not is_reserved_name(attr)

# Generated at 2022-06-11 19:18:26.350452
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:18:30.825715
# Unit test for function get_reserved_names
def test_get_reserved_names():

    public = set(['become_user', 'gather_facts', 'name', 'post_tasks', 'pre_tasks', 'roles', 'tasks'])
    private = set(['_role_params', '_role_params_file'])
    assert public.union(private) == get_reserved_names()
    assert public == get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:18:39.356396
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' returns the set of reserved play names '''

    reserved_names = get_reserved_names()
    assert len(reserved_names) > 50

    # tests for private play attrs
    assert 'hosts' in reserved_names
    assert 'vars' in reserved_names
    assert 'roles' in reserved_names

    # tests for public play attrs
    assert 'name' in reserved_names
    assert 'connection' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'hosts' in reserved_names
    assert 'max_fail_percentage' in reserved_names
    assert 'no_log' in reserved_names
    assert 'sudo' in reserved_names
    assert 'sudo_user' in reserved_names

# Generated at 2022-06-11 19:18:50.022993
# Unit test for function get_reserved_names
def test_get_reserved_names():
    output = get_reserved_names()

    assert('hosts' in output)
    assert('roles' in output)
    assert('tasks' in output)
    assert('name' in output)
    assert('include' in output)
    assert('gather_facts' in output)
    assert('pre_tasks' in output)
    assert('post_tasks' in output)
    assert('vars_files' in output)
    assert('action' in output)
    assert('when' in output)
    assert('local_action' in output)
    assert('handler' in output)
    assert('register' in output)
    assert('notify' in output)
    assert('delegate_to' in output)

    assert('ignore_errors' in output)
    assert('always_run' in output)
   

# Generated at 2022-06-11 19:19:00.055364
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import sys

    # No longer need to do this, but keeping this in for reference
    #sys.modules['ansible.playbook.role'] = None


# Generated at 2022-06-11 19:19:08.636886
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(["with_", "vars", "include", "name", "gather_facts", "action", "local_action"])

# Generated at 2022-06-11 19:19:16.056854
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.playbook.role.definition import RoleDefinition

    # test with public function
    public_reserved = get_reserved_names(False)
    public_reserved.discard('private')
    public_reserved.discard('private_role')
    public_reserved.discard('private_data')
    public_reserved.discard('squid_needs_restart')
    assert 'private' not in public_reserved
    assert 'private_role' not in public_reserved
    assert 'private_data' not in public_reserved
    assert 'squid_needs_restart' not in public_reserved

    # test with private function
    private_reserved = get_reserved_names()
    assert 'private' in private_reserved
    assert 'private_role' in private_reserved


# Generated at 2022-06-11 19:19:19.372465
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'name' in names
    assert 'connection' in names
    assert 'gather_facts' in names
    assert 'post_tasks' in names

# Generated at 2022-06-11 19:19:26.881452
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:19:36.942287
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert len(get_reserved_names()) == 33

    # ensure it is up to date with the Playbook class
    play_obj = Play()
    assert len(get_reserved_names()) == len(set(play_obj.__dict__['_attributes']))

    public = get_reserved_names(include_private=False)
    assert len(public) == 29
    assert 'environment' in public
    assert 'include_role' not in public
    assert 'include_vars' not in public
    assert 'include' not in public
    assert 'local_action' in public

    assert isinstance(_RESERVED_NAMES, frozenset)



# Generated at 2022-06-11 19:19:39.714126
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test for names in public and private
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'name' in get_reserved_names()



# Generated at 2022-06-11 19:19:46.896468
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Positive
    reserved_public = get_reserved_names(include_private=False)
    assert 'name' in reserved_public
    assert 'roles' in reserved_public
    assert 'tasks' in reserved_public
    assert 'action' in reserved_public

    reserved_private = get_reserved_names(include_private=True)
    assert 'name' in reserved_private
    assert 'roles' in reserved_private
    assert 'tasks' in reserved_private
    assert 'action' in reserved_private
    assert 'delegate_to' in reserved_private
    assert 'local_action' in reserved_private
    assert 'loop' in reserved_private

    # Negative
    assert 'foo' not in reserved_public
    assert 'bar' not in reserved_private

# Generated at 2022-06-11 19:19:47.871621
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) > 10

# Generated at 2022-06-11 19:19:58.245092
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(('hosts', 'name', 'remote_user', 'vars', 'vars_prompt', 'vars_files', 'any_errors_fatal', 'gather_facts', 'roles', 'tasks', 'post_tasks', 'pre_tasks'))

# Generated at 2022-06-11 19:20:02.092259
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=False)
    assert 'vars' in reserved_names
    assert 'action' in reserved_names
    assert 'with_sequence' in reserved_names
    assert 'local_action' not in reserved_names
    assert 'private_key_file' not in reserved_names

# Generated at 2022-06-11 19:20:20.213441
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test for all reserved names
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'vars' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'when' in reserved_names
    assert 'register' in reserved_names
    assert 'delegate_to' in reserved_names
    assert 'delegate_facts' in reserved_names
    assert 'ignore_errors' in reserved_names

# Generated at 2022-06-11 19:20:29.234412
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not _RESERVED_NAMES.issubset(set(['name', 'hosts', 'action', 'local_action', 'include', 'include_role', 'roles', 'include_tasks', 'tasks', 'with_items', 'with_dict', 'with_fileglob', 'with_first_found', 'with_nested', 'with_subelements', 'with_sequence', 'loop', 'vars', 'vars_prompt', 'vars_files', 'vars_prompt', 'pre_tasks', 'post_tasks', 'notify', 'handlers', 'block', 'rescue', 'always', 'no_log']))

# Generated at 2022-06-11 19:20:38.806049
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_vars = [
        ('strategy', 'strategy', False),
        ('action', 'action', True),
        ('local_action', 'local_action', True),
        ('delegate_to', 'delegate_to', False),
        ('become', 'become', False),
        ('become_method', 'become_method', False),
        ('become_user', 'become_user', False),
        ('loop', 'loop', False),
        ('with_', 'with_', True),
        ('tags', 'tags', False),
        ('register', 'register', False),
        ('when', 'when', False),
        ('only_if', 'only_if', False),
        ('notify', 'notify', False)
    ]

# Generated at 2022-06-11 19:20:46.706028
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:20:56.334903
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'block' in reserved
    assert 'include' in reserved
    assert 'meta' in reserved
    assert 'vars' in reserved

    not_reserved = get_reserved_names(include_private=False)
    assert 'roles' in not_reserved
    assert 'tasks' in not_reserved
    assert 'include' in not_reserved
    assert 'meta' in not_reserved
    assert 'vars' in not_reserved
    assert 'block' not in not_reserved

    assert 'VARS' not in reserved
    assert 'vars_files' not in reserved



# Generated at 2022-06-11 19:21:04.516059
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert frozenset(['hosts', 'roles', 'gather_facts', 'user', 'tags',
                      'vars', 'vars_prompt', 'vars_files',
                      'connection', 'sudo', 'sudo_user', 'become', 'become_method', 'remote_user',
                      'environment', 'any_errors_fatal', 'serial', 'max_fail_percentage',
                      'block', 'rescue', 'always',
                      'register', 'ignore_errors',
                      'delegate_to', 'run_once', 'check_mode', 'no_log',
                      'when', 'async', 'poll', 'free_form']) == _RESERVED_NAMES



# Generated at 2022-06-11 19:21:11.700337
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'remote_user' in get_reserved_names()
    assert 'become' in get_reserved_names(include_private=False)
    assert 'handlers' in get_reserved_names(include_private=False)
    assert 'tasks' in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names(include_private=False)



# Generated at 2022-06-11 19:21:18.975143
# Unit test for function get_reserved_names
def test_get_reserved_names():  # pylint: disable=too-complex,too-many-locals,too-many-statements
    ''' unit test for get_reserved_names '''

    reserved = get_reserved_names(include_private=False)

    # check all simple play attributes
    assert 'connection' in reserved
    assert 'remote_user' in reserved
    assert 'become' in reserved
    assert 'become_user' in reserved
    assert 'vars' in reserved
    assert 'hosts' in reserved
    assert 'name' in reserved
    assert 'gather_facts' in reserved
    assert 'tags' in reserved
    assert 'register' in reserved

    # check action/local_action
    assert 'action' in reserved
    assert 'local_action' in reserved

    # check with_/loop
    assert 'with_' in reserved

# Generated at 2022-06-11 19:21:26.904475
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private_set = set(['name', 'roles', 'vars_prompt', 'task_vars', 'default_vars', 'vars_files', 'hosts', 'host_vars', 'role_vars', 'group_vars', 'play_hosts', 'play_vars', 'play_basedirs', 'is_import_role', 'default_vars_files', 'handlers', 'tasks', 'post_tasks', 'pre_tasks', 'private_role_vars', 'private_group_vars', 'private_host_vars', 'vars_files_from_task', 'block', 'retry_files_from_task', 'dep_chain', 'serial'])

# Generated at 2022-06-11 19:21:36.718399
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = _RESERVED_NAMES
    assert 'gather_facts' in reserved
    assert 'no_log' in reserved
    assert 'name' in reserved
    assert 'pre_tasks' in reserved
    assert 'post_tasks' in reserved
    assert 'deprecate' in reserved
    assert 'include_role' in reserved
    assert 'with_items' in reserved
    assert 'with_' in reserved
    assert 'when' in reserved
    assert 'async' in reserved
    assert 'listen' in reserved
    assert 'hosts' in reserved
    assert 'register' in reserved
    assert 'roles' in reserved
    assert 'block' in reserved
    assert 'local_action' in reserved
    assert 'include' in reserved
    assert 'any_errors_fatal' not in reserved

# Generated at 2022-06-11 19:22:08.204764
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated

# Generated at 2022-06-11 19:22:19.765946
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Basic Unit test for get_reserved_names function
    '''
    from ansible.playbook.play_context import PlayContext

    public = set()
    private = set()
    result = set()
    class_list = [Play, PlayContext, Role, Block, Task]

    # build ordered list to loop over and dict with attributes
    for aclass in class_list:
        aobj = aclass()

        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_

# Generated at 2022-06-11 19:22:26.875616
# Unit test for function get_reserved_names
def test_get_reserved_names():
    check_names = ['ansible_connection', 'ansible_user', 'ansible_ssh_pass', 'ansible_become', 'ansible_become_user', 'delegate_to']
    for check_name in check_names:
        assert check_name in _RESERVED_NAMES, "%s was not found in reserved vars list" % check_name

# Generated at 2022-06-11 19:22:32.640036
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # not strictly true, but we're checking for whether
    # the number of reserved names is as expected
    assert len(get_reserved_names()) == len(set(get_reserved_names(include_private=True)))
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=True), set)
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:22:43.102041
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:43.915946
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES

# Generated at 2022-06-11 19:22:46.365640
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' This function performs a simple unit test on the get_reserved_names() function '''

    reserved = get_reserved_names()

    # validate that our private names are excluded as expected
    if 'sudo_user' in reserved:
        print("failed: reserved names contains 'sudo_user'")
        return False

    return True



# Generated at 2022-06-11 19:22:52.309449
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # get_reserved_names returns a set
    assert isinstance(list(get_reserved_names()), list)

    # now compare the list with hardcoded list
    assert set(get_reserved_names()) >= set(['include_vars', 'register', 'roles', 'roles_path', 'vars_files'])

# Generated at 2022-06-11 19:23:01.724150
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This module is for internal use, so the tests are only
    meant for use by other test modules.
    '''
    expected_public = frozenset(['name', 'action', 'remote_user', 'connection', 'sudo', 'sudo_user', 'environment', 'any_errors_fatal', 'serial', 'poll',
                                 'register', 'ignore_errors', 'delegate_to', 'tags', 'run_once', 'with_', 'local_action', 'transport'])


# Generated at 2022-06-11 19:23:13.607680
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    # this function modifies the display object, so we want to ensure it returns to the original state afterwards
    display_orig = display.verbosity

    # tests of public names with and without private
    assert '__tasks__' in reserved_names
    assert 'collect_facts' in reserved_names
    assert 'any_errors_fatal' in reserved_names
    assert 'notify' not in reserved_names
    assert 'delegate_to' in reserved_names
    assert 'run_once' in reserved_names
    assert 'hosts' in reserved_names

    # test that a private name is skipped when it is not included
    assert 'dependencies' not in reserved_names
    assert 'post_tasks' not in reserved_names

    # test that it does not have a public name (as