

# Generated at 2022-06-11 19:13:51.515546
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:13:57.092795
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_set = get_reserved_names(include_private=False)
    assert 'name' in reserved_set
    assert 'async' in reserved_set
    assert 'sudo' in reserved_set
    assert 'role' in reserved_set
    assert 'tasks' in reserved_set
    assert 'block' in reserved_set

# Generated at 2022-06-11 19:13:59.779048
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Simple check for reserved names
    assert 'name' in _RESERVED_NAMES
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in _RESERVED_NAMES

# Generated at 2022-06-11 19:14:11.338784
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test public
    public = get_reserved_names(include_private=False)
    assert 'hosts' in public
    assert 'vars' in public
    assert 'vars_files' in public
    assert 'vars_prompt' in public
    assert 'vault_password_files' in public
    assert 'handlers' in public
    assert 'roles' in public
    assert 'tasks' in public
    assert 'meta' in public
    assert 'pre_tasks' in public
    assert 'post_tasks' in public
    assert 'no_log' in public
    assert 'run_once' in public
    assert 'connection' in public
    assert 'gather_facts' in public
    assert 'any_errors_fatal' in public
    assert 'serial' in public

# Generated at 2022-06-11 19:14:22.035304
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()
    result = set()

    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    if 'loop' in private or 'loop' in public:
        public.add('with_')

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # build the result

# Generated at 2022-06-11 19:14:32.524836
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for function get_reserved_names '''

    # list of reserved names from function
    result = get_reserved_names()

    # manually add names for testing (all must be lower-case)
    manual = set(['name', 'hosts', 'roles', 'tasks', 'vars_files', 'vars', 'action', 'local_action', 'block', 'blockinfile', 'blockoutfile', 'lineinfile', 'replace', 'fail', 'register', 'ignore_errors', 'delegate_to'])
    manual.add('with_')  # FIXME: remove after with_ is not only deprecated but removed

    # test and make sure the result is what we expect
    assert set(result) == manual



# Generated at 2022-06-11 19:14:37.810535
# Unit test for function get_reserved_names
def test_get_reserved_names():
    if 'connection' not in _RESERVED_NAMES:
        raise AssertionError('expected connection in reserved names')
    if 'action' not in _RESERVED_NAMES:
        raise AssertionError('expected action in reserved names')
    if 'private' not in _RESERVED_NAMES:
        raise AssertionError('expected private in reserved names')

# Generated at 2022-06-11 19:14:47.066847
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_public = set(['name', 'hosts', 'remote_user', 'connection',
                       'sudo', 'sudo_user', 'become', 'become_method',
                       'become_user', 'become_flags', 'check', 'gather_facts',
                       'vars_files', 'tags', 'ignore_errors', 'port',
                       'any_errors_fatal', 'serial', 'transport', 'remote_tmp',
                       'accelerate', 'no_log', 'run_once', 'register', 'environment',
                       'no_target_syslog', 'delegate_to', 'async'])


# Generated at 2022-06-11 19:14:57.344931
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(['name', 'roles', 'tasks', 'block', 'blockrescue', 'blockalways', 'pre_tasks', 'post_tasks', 'become', 'become_user', 'delegate_to', 'local_action', 'action', 'with_', 'tags', 'vars', 'handlers'])
    private = set(['serial', '_role', 'when', 'loop', '_play', '_block', '_blockrescue', '_blockalways', '_task', '_hostnames'])
    assert get_reserved_names() == public.union(private)
    assert get_reserved_names(include_private=False) == public

test_get_reserved_names()

# Generated at 2022-06-11 19:15:04.759430
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import pytest
    r = get_reserved_names()
    assert r == get_reserved_names()
    rp = get_reserved_names(include_private=False)
    assert rp != r
    assert rp.issubset(r)
    with pytest.raises(TypeError) as excinfo:
        get_reserved_names(include_private='bad')
    assert "argument 'include_private' (position 1) must be bool, not str" in str(excinfo.value)

# Generated at 2022-06-11 19:15:19.124983
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'register' in reserved
    assert 'first_available_file' in reserved
    assert 'become' in reserved
    assert 'become_method' in reserved
    assert 'tags' in reserved
    assert 'become_user' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'vars_prompt' in reserved
    assert 'vars_files' in reserved
    assert 'gather_facts' in reserved
    assert 'remote_user' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'vars_prompt' in reserved
    assert 'vars_files' in reserved
    assert 'delegate_to' in reserved

# Generated at 2022-06-11 19:15:26.279501
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected = frozenset(['action', 'block', 'block_rescue', 'block_always', 'connection', 'delegate_facts', 'delegate_to', 'environment', 'env', 'fail_on_missing_handler', 'flush_handlers', 'include_role', 'include', 'local_action', 'name', 'notify', 'register', 'remote_user', 'roles', 'run_once', 'serial', 'su', 'su_user', 'sudo', 'sudo_user', 'tasks', 'ignore_errors', 'vars', 'vars_prompt', 'when'])
    assert get_reserved_names() == expected

# Generated at 2022-06-11 19:15:37.339085
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)
    assert 'handlers' in public
    assert 'pre_tasks' in public
    assert 'tasks' in public
    assert 'post_tasks' in public
    assert 'vars' in public
    assert 'any_errors_fatal' in public
    assert 'block' in public
    assert 'block' in private
    assert 'always_run' in public
    assert 'changed_when' in public
    assert 'when' in public
    assert 'loop' in private
    assert 'local_action' in private
    assert 'action' in public
    assert 'with_' in private



# Generated at 2022-06-11 19:15:42.020545
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'loop' in reserved
    assert 'with_' in reserved
    # FIXME: the following should pass, but they don't
    # assert 'connection' in reserved
    # assert 'port' in reserved
    # assert 'tags' in reserved
    # assert 'when' in reserved
    # assert 'vars' in reserved

# Generated at 2022-06-11 19:15:50.173435
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = frozenset([u'action', u'any_errors_fatal', u'delegate_to', u'handlers', u'hosts', u'include_tasks',
                        u'include_vars', u'name', u'notify', u'notify_handlers', u'post_tasks', u'pre_tasks',
                        u'roles', u'run_once', u'tags', u'tasks', u'tags', u'vars', u'vars_files', u'block'])


# Generated at 2022-06-11 19:15:53.133292
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)



# Generated at 2022-06-11 19:15:59.974110
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import json
    reference_file = open('lib/ansible/playbook/reserved/reserved.json')
    reference_data = json.load(reference_file)
    reference_file.close()
    for reserved_attribute in reference_data['reserved_attributes']:
        if not reserved_attribute in get_reserved_names(include_private=False):
            assert False
    for reserved_attribute in reference_data['reserved_attributes_private']:
        if not reserved_attribute in get_reserved_names(include_private=True):
            assert False
    assert True

# Generated at 2022-06-11 19:16:11.212336
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Initialize and test the is_reserved_name() function.
    assert is_reserved_name('with_first_found')
    assert not is_reserved_name('my_special_thingy_name')

    # Initialize and test the get_reserved_names() function.
    # Test the public interface.
    reserved_names_public = get_reserved_names(include_private=False)
    assert isinstance(reserved_names_public, set)
    assert 'task' in reserved_names_public
    assert 'with_first_found' in reserved_names_public
    assert 'roles' in reserved_names_public
    assert 'connection' in reserved_names_public
    assert 'async' in reserved_names_public
    assert 'run_once' in reserved_names_public

# Generated at 2022-06-11 19:16:20.395162
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = set(['name', 'hosts', 'roles', 'tasks', 'meta', 'block', 'block', 'rescue', 'always', 'any_errors_fatal', 'delegate_to', 'become', 'become_user', 'become_method', 'environment', 'when', 'register', 'local_action', 'ignore_errors', 'loop', 'with_items', 'include', 'include_role', 'include_tasks', 'vars', 'vars_files', 'vars_prompt', 'vault_password_file', 'tags', 'no_log'])
    assert reserved_names == get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:16:25.142462
# Unit test for function get_reserved_names
def test_get_reserved_names():
    known_reserved_names = set(['imports', 'notify', 'async', 'retries', 'gather_facts', 'any_errors_fatal', 'continue_on_errors', 'name', 'connection', 'vars_files', 'roles', 'roles_path', 'handler_tasks', 'pre_tasks', 'post_tasks', 'tags', 'tasks', 'tags', 'when', 'become', 'become_method', 'become_user', 'block'])
    reserved_names = set(get_reserved_names())
    assert len(reserved_names) >= len(known_reserved_names)
    assert known_reserved_names.issubset(reserved_names)

# Generated at 2022-06-11 19:16:40.473856
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # reserved is a set because order does not matter for this test
    reserved = set(['become', 'delegate_to', 'register', 'run_once', 'remote_user', 'when',
                    'environment', 'connection', 'any_errors_fatal', 'serial', 'failed_when', 'max_fail_percentage'])
    assert reserved == _RESERVED_NAMES

# Generated at 2022-06-11 19:16:51.313394
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = frozenset(['action', 'delegate_to', 'local_action', 'async', 'poll', 'become', 'become_user', 'become_method', 'tags', 'block', 'block:', 'ignore_errors', 'always_run', 'register', 'name', 'environment', 'no_log', 'role', 'with_', 'include', 'include_role', 'vars_files', 'vars', 'hosts', 'when', 'any_errors_fatal', 'serial', 'transport', 'remote_user', 'sudo', 'sudo_user', 'connection', 'gather_facts', 'add_host', 'magic_variables', 'pre_tasks', 'tasks', 'post_tasks', 'handlers'])

    assert frozenset(get_reserved_names(True)) == reserved

# Generated at 2022-06-11 19:16:56.201433
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private_reserved = get_reserved_names(include_private=True)
    public_reserved = get_reserved_names(include_private=False)

    assert isinstance(private_reserved, set)
    assert isinstance(public_reserved, set)
    assert public_reserved.issubset(private_reserved)



# Generated at 2022-06-11 19:17:07.297889
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {
        'action',
        'become',
        'connection',
        'delegate_to',
        'environment',
        'gather_facts',
        'hosts',
        'local_action',
        'name',
        'notify',
        'no_log',
        'poll',
        'run_once',
        'sudo',
        'sudo_user',
        'tags',
        'task',
        'tasks',
        'transport',
        'vars',
        'with_',
        'when',
        'when_file_exists',
        'when_file_missing',
    }

    assert not get_reserved_names(include_private=False) == _RESERVED_NAMES

    assert not is_reserved_

# Generated at 2022-06-11 19:17:10.103034
# Unit test for function get_reserved_names
def test_get_reserved_names():
    results = get_reserved_names()
    assert isinstance(results, set)
    assert 'roles' in results
    assert 'tasks' in results


# Generated at 2022-06-11 19:17:15.421571
# Unit test for function get_reserved_names
def test_get_reserved_names():
    for var in ['include_tasks', 'roles', 'tasks', 'vars', 'action', 'local_action', 'with_', 'include_role', 'register', 'environment', 'include_vars', 'include_plays']:
        assert var in get_reserved_names(), '%s missing from reserved names set' % var

# Generated at 2022-06-11 19:17:21.907549
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' not in reserved_names
    assert 'register' in reserved_names
    assert 'vars' in reserved_names
    assert 'roles' in reserved_names
    assert 'include_role' in reserved_names



# Generated at 2022-06-11 19:17:30.820500
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Add a new task attribute and make sure that it gets picked up by the
    # function

    # attributes which are private are not exposed
    # FIXME: find a better way to test
    aobj = Task()
    aobj.attributes['foo'] = 'bar'
    aobj.attributes['foo']['private'] = True

    # add a new public attribute
    aobj.attributes['baz'] = 'bar'

    # check that foo is not private, because it's not in the list
    # and baz is in the list
    assert 'foo' not in get_reserved_names()
    assert 'baz' in get_reserved_names()



# Generated at 2022-06-11 19:17:32.766800
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: this is a temp unit test to demonstrate how to unit test a function
    # in a utils module

    # FIXME: define some expected output
    assert True

# Generated at 2022-06-11 19:17:37.461585
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Verify if both private and public reserved names are returned
    # for include_private=True
    assert _RESERVED_NAMES == get_reserved_names()

    # Verify if only public reserved names are returned
    # for include_private=False
    assert _RESERVED_NAMES.difference(get_reserved_names(include_private=False)) == set()

# Generated at 2022-06-11 19:18:00.877720
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # TODO: add more tests
    assert 'action' in get_reserved_names()
    assert 'local_action' not in get_reserved_names()


# Generated at 2022-06-11 19:18:05.366679
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert len(_RESERVED_NAMES) > 0


# Generated at 2022-06-11 19:18:06.072267
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert ('name' in get_reserved_names())

# Generated at 2022-06-11 19:18:07.494701
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set() == set().union(_RESERVED_NAMES)

# Generated at 2022-06-11 19:18:14.198748
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:18:16.219540
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # check reserved name
    result = frozenset(get_reserved_names(include_private=False))
    assert 'any_errors_fatal' in result


# Generated at 2022-06-11 19:18:26.875279
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'hosts' in get_reserved_names(False)
    assert 'name' in get_reserved_names()
    assert 'name' in get_reserved_names(False)
    assert 'gather_facts' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names(False)
    assert 'roles' in get_reserved_names()
    assert 'roles' in get_reserved_names(False)
    assert 'tasks' in get_reserved_names()
    assert 'tasks' in get_reserved_names(False)
    assert 'tags' in get_reserved_names()
    assert 'tags' in get_reserved_names(False)
    assert 'block' in get

# Generated at 2022-06-11 19:18:36.241527
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test that function returns the correct number
    assert len(get_reserved_names()) == 53
    assert len(get_reserved_names(include_private=False)) == 43
    # Test that the reserved names have been correctly generated
    assert 'hosts' in get_reserved_names()
    assert 'ignore_err' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names(include_private=False)
    assert '_private_key_data' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'delegate_to' in get_res

# Generated at 2022-06-11 19:18:37.442238
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == _RESERVED_NAMES

# Generated at 2022-06-11 19:18:40.334037
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'private_key_file' in get_reserved_names(include_private=True)
    assert 'private_key_file' not in get_reserved_names(include_private=False)



# Generated at 2022-06-11 19:19:29.985674
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:19:35.043851
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = set(get_reserved_names(include_private=True))
    reserved_names_no_private = set(get_reserved_names(include_private=False))
    assert reserved_names != reserved_names_no_private
    for name in get_reserved_names(include_private=False):
        assert name in reserved_names

# Generated at 2022-06-11 19:19:41.692540
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Note: This is not meant to be a complete test, just a basic sanity check
    assert 'hosts' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names(include_private=False)
    assert 'gather_subset' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'task' in get_reserved_names()
    assert 'user' in get_reserved_names()

# Generated at 2022-06-11 19:19:43.415817
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert isinstance(result, frozenset)
    assert len(result) == 399

# Generated at 2022-06-11 19:19:47.737201
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert isinstance(get_reserved_names(), frozenset)
    assert len(_RESERVED_NAMES) == len(get_reserved_names())

# Generated at 2022-06-11 19:19:52.765824
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'action' in reserved
    assert 'private_key_file' in reserved
    assert 'private_key_file' in reserved
    assert not ('foo' in reserved or 'bar' in reserved)



# Generated at 2022-06-11 19:20:01.935317
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private = get_reserved_names(include_private=False)
    public = get_reserved_names(include_private=True)

    assert 'hosts' in private
    assert 'hosts' in public

    assert 'vars' in private
    assert 'vars' in public

    assert 'name' in private
    assert 'name' in public

    assert 'roles' in private
    assert 'roles' in public

    assert 'action' in private
    assert 'action' in public

    assert 'local_action' in private
    assert 'local_action' in public

    assert 'delegate_to' in private
    assert 'delegate_to' in public

    assert 'deprecate' in public
    assert 'deprecate' not in private

    assert 'notify' in public

# Generated at 2022-06-11 19:20:05.742891
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    reserved = get_reserved_names()
    assert 'hosts' in reserved
    assert 'roles' in reserved

    reserved = get_reserved_names(include_private=False)
    assert 'hosts' in reserved
    assert 'roles' in reserved

# Generated at 2022-06-11 19:20:15.155076
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this test uses the same names as the function so it will fail if the function is updated without updating the test '''
    assert Play()._attributes == frozenset(['vars', 'hosts', 'name', 'gather_facts', 'connection', 'remote_user', 'sudo', 'sudo_user', 'sudo_pass', 'tags', 'environment', 'any_errors_fatal', 'serial', 'transport', 'poison_pill', 'rollback', 'rollback_enabled', 'no_log', 'run_once', 'become', 'become_user', 'become_method'])

# Generated at 2022-06-11 19:20:21.714312
# Unit test for function get_reserved_names
def test_get_reserved_names():

    def list_to_set(mylist):
        return set(mylist)

    # this is testing the list of 'public' reserved names, which should exclude
    # all private attributes prefixed with '_'

# Generated at 2022-06-11 19:21:47.544700
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' basic test to ensure unit test is working, returns expected structure and makes sure it includes 'hosts' '''
    public, private = get_reserved_names()
    assert(isinstance(public, set))
    assert(isinstance(private, set))
    assert('hosts' in public)

# Generated at 2022-06-11 19:21:56.098738
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['action', 'become', 'connection', 'delegate_to', 'gather_facts', 'include', 'include_tasks', 'local_action', 'name', 'no_log', 'notify', 'notified_by', 'serial', 'tags', 'until', 'vars', 'when', 'with_', 'with_dict', 'with_file', 'with_first_found', 'with_items', 'with_subelements', 'with_sequence', 'with_together', 'register'])



# Generated at 2022-06-11 19:22:02.108801
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert 'action' in result
    assert 'action' in result
    assert 'hosts' in result

    result = get_reserved_names(include_private=False)
    assert 'hosts' in result
    assert 'role_name' not in result
    assert 'private' not in result
    assert 'event' not in result
    assert 'register' not in result



# Generated at 2022-06-11 19:22:05.301189
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # there is no test here yet, but in the future we can make sure that if new calls are added to
    assert isinstance(get_reserved_names(), set)

# Generated at 2022-06-11 19:22:12.945662
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == get_reserved_names(True)

    # when include_private is False, private attribute names should not be included in result
    names = get_reserved_names()
    privates = get_reserved_names(False).difference(names)
    for private in privates:
        assert private not in get_reserved_names(False)

    # Check for expected attributes
    assert 'action' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'tags'

# Generated at 2022-06-11 19:22:22.454810
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:25.903701
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert isinstance(result, set)
    assert 'hosts' in result
    assert 'action' in result

# Generated at 2022-06-11 19:22:34.618783
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test public names
    public = set(['name', 'hosts', 'roles', 'vars', 'action', 'local_action', 'connection', 'delegate_to', 'gather_facts',
                  'vars_files', 'include', 'include_role', 'tags', 'block', 'any_errors_fatal', 'max_fail_percentage',
                  'serial', 'sudo', 'sudo_user', 'remote_user', 'with_items', 'with_dict', 'with_fileglob', 'with_lines',
                  'with_sequence', 'with_fileinput'])
    assert public == get_reserved_names(include_private=False)

    # Test private names

# Generated at 2022-06-11 19:22:44.734802
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:51.671876
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)

    # Be sure that warnings get issued when they should
    # when they shouldn't, then no warning issues
    assert warn_if_reserved(['action']) is None
    assert warn_if_reserved({'remote_user'}) is None
    assert warn_if_reserved({'hosts'}) is None
    assert warn_if_reserved({'loop'}) is None