

# Generated at 2022-06-11 19:13:49.648115
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_result = get_reserved_names(include_private=False)
    private_result = get_reserved_names(include_private=True)

    # check that the private set is a superset of the public
    assert(all(element in private_result for element in public_result))

    # check that the public set is a subset of the private
    assert(all(element in public_result for element in private_result))

# Generated at 2022-06-11 19:13:54.829926
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for get_reserved_names '''

    # This is a very weak test - better this than none at all.
    # Will be replaced by AnsibleModuleTestCase once that is functional
    result = get_reserved_names()
    assert isinstance(result, set)
    assert len(result) > 1
    assert len(result) < 100

# Generated at 2022-06-11 19:14:03.439721
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:06.767380
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' return value should always be a set() '''
    names = get_reserved_names()
    assert isinstance(names, set)



# Generated at 2022-06-11 19:14:08.590338
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test if the reserved attribute is valid '''
    assert isinstance(_RESERVED_NAMES, frozenset)

# Generated at 2022-06-11 19:14:21.203423
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:29.642862
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function ensures that reserved names are correctly recognized '''

    reserved = set(['name', 'hosts', 'roles', 'tasks', 'vars', 'pre_tasks', 'post_tasks', 'handlers'])

    assert get_reserved_names(False) == reserved, "public reserved names do not match"

    reserved.add('become')
    reserved.add('become_user')
    reserved.add('register')
    reserved.add('action')

    assert get_reserved_names(True) == reserved, "reserved names do not match"

# Generated at 2022-06-11 19:14:37.346366
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True).difference(public)

# Generated at 2022-06-11 19:14:41.388495
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)
    assert len(public) != len(private)
    assert _RESERVED_NAMES == private

# Generated at 2022-06-11 19:14:46.456301
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert Block._attributes.keys() | Play._attributes.keys() | Role._attributes.keys() | Task._attributes.keys() == get_reserved_names()

    # removed private
    assert Block._attributes.keys() | Play._attributes.keys() | Role._attributes.keys() | Task._attributes.keys() - set(x for x in set(get_reserved_names(False)) if x.get('private', None)) == get_reserved_names(False)

# Generated at 2022-06-11 19:15:01.599737
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'action', 'block', 'gather_facts', 'hosts', 'loop', 'name', 'post_tasks', 'pre_tasks', 'role', 'roles', 'serial', 'task', 'tasks', 'vars', 'with_'}
    assert get_reserved_names(include_private=False) == {'action', 'block', 'gather_facts', 'hosts', 'name', 'post_tasks', 'pre_tasks', 'role', 'roles', 'serial', 'task', 'tasks', 'vars', 'with_'}

# Generated at 2022-06-11 19:15:07.967966
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Unit test for function get_reserved_names
    '''
    import copy
    import sys

    # define play, role, block and task objects to test

# Generated at 2022-06-11 19:15:10.264130
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'roles' in names
    assert 'pre_tasks' in names
    assert 'post_tasks' in names



# Generated at 2022-06-11 19:15:19.123940
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES == frozenset(get_reserved_names())
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names(include_private=False))

# Generated at 2022-06-11 19:15:23.156168
# Unit test for function get_reserved_names
def test_get_reserved_names():

    exclude_private = get_reserved_names(include_private=False)
    include_private = get_reserved_names(include_private=True)

    assert 'connection' in include_private
    assert 'connection' in exclude_private

    assert 'serial' in include_private
    assert 'serial' not in exclude_private

# Generated at 2022-06-11 19:15:24.859724
# Unit test for function get_reserved_names
def test_get_reserved_names():
    res_names = get_reserved_names()
    assert isinstance(res_names, set)

# Generated at 2022-06-11 19:15:29.822007
# Unit test for function get_reserved_names
def test_get_reserved_names():
    p = Play()
    p._load_name_uniquified(dict(name='test', hosts='test1', gather_facts=False), play=p, variable_manager=None)

    assert p.name == 'test'
    assert p.hosts == 'test1'
    assert p.gather_facts is False

# Generated at 2022-06-11 19:15:32.992411
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names(True) == get_reserved_names(False))
    assert(isinstance(get_reserved_names(True), set))

# Generated at 2022-06-11 19:15:36.696167
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'local_action' in get_reserved_names()

# Generated at 2022-06-11 19:15:39.081262
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'tags' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'loop' in reserved

# Generated at 2022-06-11 19:15:57.675229
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print('\nTest get_reserved_names')
    print(get_reserved_names())


# Generated at 2022-06-11 19:16:09.493557
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

# Generated at 2022-06-11 19:16:10.849458
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'include_role' in get_reserved_names(True)


# Generated at 2022-06-11 19:16:20.189880
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:16:22.513728
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'become_user' in get_reserved_names(include_private=True)
    assert 'delegate_to' in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:16:32.745071
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:16:40.655868
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test_get_reserved_names:  test the get_reserved_names function '''

    public = set()
    private = set()
    result = set()

    for aclass in [Play, Role, Block, Task]:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    if 'action' in public:
        public.add('local_action')

    if 'loop' in private or 'loop' in public:
        public.add('with_')

    result = public.union(private)

    assert result == _RESERVED_NAMES


# Generated at 2022-06-11 19:16:51.497863
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:02.700758
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(_RESERVED_NAMES) is frozenset
    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    # FIXME: remove after with_ is not only deprecated but removed
    assert len(_RESERVED_NAMES) == 71
    assert 'name' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'connection' in _RESERVED_NAMES
    assert 'gather_facts' in _RESERVED_NAMES
    assert 'vars' in _RESERVED_NAMES
    assert 'vars_files' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES

# Generated at 2022-06-11 19:17:11.854075
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_reserved_names = get_reserved_names(include_private=False)
    assert(Play.name in public_reserved_names)
    assert(Play.hosts in public_reserved_names)
    assert('sudo' in public_reserved_names)
    assert('sudo_user' in public_reserved_names)
    assert('tags' in public_reserved_names)
    assert('when' in public_reserved_names)
    assert('gather_facts' in public_reserved_names)
    assert('vars' in public_reserved_names)
    assert('include' in public_reserved_names)
    assert('listen' not in public_reserved_names)

    private_and_public_reserved_names = get_reserved_names(include_private=True)


# Generated at 2022-06-11 19:17:54.041809
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = frozenset(get_reserved_names(include_private=False))
    private = frozenset(get_reserved_names(include_private=True))

# Generated at 2022-06-11 19:17:57.859071
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    if reserved != {'action', 'connection', 'delegate_to', 'environment', 'ignore_errors', 'loop', 'notify', 'register', 'remote_user', 'roles', 'serial', 'tags', 'tasks', 'transport', 'when'}:
        raise Exception('Test failed: get_reserved_names returned wrong set!')

# Generated at 2022-06-11 19:18:05.070433
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()

    # this should catch if any new attributes are added
    assert 'become' in result
    assert 'become_user' in result
    assert 'connection' in result
    assert 'delegate_to' in result
    assert 'gather_facts' in result
    assert 'hosts' in result

    assert 'private_key_file' in result
    assert 'port' in result
    assert 'sudo' in result
    assert 'sudo_user' in result
    assert 'transport' in result
    assert 'user' in result
    assert 'vars' in result
    assert 'vars_prompt' in result
    assert 'vars_prompt_again' in result

# Generated at 2022-06-11 19:18:14.368284
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Reserved names
    reserved = get_reserved_names()
    assert "hosts" in reserved
    assert "roles" in reserved
    assert "gather_facts" in reserved
    assert "action" in reserved
    assert "pre_tasks" in reserved

    # Private Reserved names
    reserved = get_reserved_names(include_private=True)
    assert "__ansible_module__" in reserved
    assert "__ansible_module_name__" in reserved
    assert "__ansible_module_args__" in reserved
    assert "__ansible_version__" in reserved
    assert "connection" in reserved
    assert "sudo" in reserved
    assert "sudo_user" in reserved
    assert "environment" in reserved
    assert "no_log" in reserved
    assert "run_once" in reserved

    #

# Generated at 2022-06-11 19:18:20.754501
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test_get_reserved_names is a unit test for function get_reserved_names '''

    reserved_names = get_reserved_names()

    assert isinstance(reserved_names, set)
    assert isinstance(_RESERVED_NAMES, set)

    assert len(reserved_names) > 0
    assert len(_RESERVED_NAMES) > 0

    assert reserved_names == _RESERVED_NAMES



# Generated at 2022-06-11 19:18:28.541890
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # ensure we get the reserved names
    names = get_reserved_names()
    assert 'roles' in names

    # ensure there are no unexpected names we didn't expect
    unexpected = set([
        'host_file_parser',
        'set_vars',
    ])
    assert unexpected.isdisjoint(names)

    # ensure that if we do not allow private names we do not get them
    names = get_reserved_names(include_private=False)
    assert 'roles' in names

    # ensure there are no unexpected names we didn't expect
    unexpected = set([
        'host_file_parser',
        'set_vars',
    ])
    assert unexpected.isdisjoint(names)

# Generated at 2022-06-11 19:18:35.904047
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function unit tests the function get_reserved_names '''

    # FIXME: This just seems wrong at this level of abstraction
    # right now there are 182 reserved names
    # if we change play object, the number can change
    # the solution is to "cache" the result of get_reserved_names
    # and if that changes, regenerate the cached value
    # and then add a "regenerate" button when users open up the
    # playbook editor
    assert len(get_reserved_names()) == 182
    assert len(get_reserved_names(include_private=False)) == 123

# Generated at 2022-06-11 19:18:42.047717
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # verify default
    rn_default = get_reserved_names()
    assert isinstance(rn_default, set)
    assert len(rn_default) > 0

    # verify public
    rn_public = get_reserved_names(False)
    assert isinstance(rn_public, set)
    assert len(rn_public) > 0
    assert rn_public.issubset(rn_default)

    # verify private
    rn_private = get_reserved_names(True)
    assert isinstance(rn_private, set)
    assert len(rn_private) > 0
    assert rn_default == rn_private

# Generated at 2022-06-11 19:18:51.745026
# Unit test for function get_reserved_names
def test_get_reserved_names():
    functions_under_test = [get_reserved_names, warn_if_reserved, is_reserved_name]
    for function in functions_under_test:
        # when
        result = function()

        # then
        assert 'roles' in result
        assert 'tasks' in result
        assert 'block' in result
        assert 'name' in result
        assert 'include_role' in result
        assert 'include_tasks' in result
        assert 'include' in result
        assert 'tags' in result
        assert 'action' in result  # do not use when running block
        assert 'local_action' in result  # do not use when running block
        # local_action is implicit with action
        # FIXME: remove after with_ is not only deprecated but removed
        assert 'with_' in result

# Make sure

# Generated at 2022-06-11 19:18:55.734710
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test the get_reserved_names function '''

    reserved = get_reserved_names()

    assert 'hosts' in reserved
    assert 'vars' in reserved
    assert 'roles' in reserved
    assert 'name' in reserved
    assert 'local_action' in reserved

# Generated at 2022-06-11 19:20:03.251398
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(include_private=False)
    assert public_names
    assert 'action' in public_names
    assert 'local_action' in public_names
    assert 'with_' in public_names
    assert 'loop' not in public_names
    assert 'vars' not in public_names

    private_names = get_reserved_names(include_private=True)
    assert private_names
    assert 'action' in private_names
    assert 'local_action' in private_names
    assert 'with_' in private_names
    assert 'loop' in private_names
    assert 'vars' not in private_names



# Generated at 2022-06-11 19:20:09.770878
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:20:18.669419
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:20:19.462988
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert isinstance(get_reserved_names(), set)

# Generated at 2022-06-11 19:20:23.853682
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'user' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:20:31.119194
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'post_tasks' in _RESERVED_NAMES, 'verify post_tasks is in reserved_names list'
    assert 'pre_tasks' in _RESERVED_NAMES, 'verify pre_tasks is in reserved_names list'
    assert 'any_errors_fatal' in _RESERVED_NAMES, 'verify any_errors_fatal is in reserved_names list'
    assert 'roles' in _RESERVED_NAMES, 'verify role is in reserved_names list'
    assert 'vars' in _RESERVED_NAMES, 'verify vars is in reserved_names list'
    assert 'vars_files' in _RESERVED_NAMES, 'verify vars_files is in reserved_names list'
    assert 'tasks'

# Generated at 2022-06-11 19:20:36.366654
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(['name', 'hosts', 'gather_facts', 'roles', 'tasks'])
    private = set(['remote_user', 'any_errors_fatal', 'serial', 'sudo_user', 'sudo', 'sudo_pass', 'connection', 'become', 'become_user', 'become_method'])
    assert public.union(private) == _RESERVED_NAMES


# Generated at 2022-06-11 19:20:40.908522
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names()
    assert 'tags' in reserved
    assert 'pre_tasks' in reserved

    reserved = get_reserved_names(include_private=False)
    assert 'tags' in reserved
    assert 'pre_tasks' not in reserved

# Generated at 2022-06-11 19:20:48.743824
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed

# Generated at 2022-06-11 19:20:59.275789
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == set(['name', 'vars', 'vars_prompt', 'vars_files', 'tags',
                                             'hosts', 'gather_facts', 'roles', 'pre_tasks', 'post_tasks',
                                             'handlers', 'tasks', 'block', 'any_errors_fatal', 'serial',
                                             'when', 'failed_when', 'changed_when', 'notify', 'async',
                                             'poll', 'sudo', 'sudo_user', 'connection', 'become', 'become_user',
                                             'flush_cache', 'ignore_errors', 'environment', 'delegate_to',
                                             'local_action', 'transport', 'action', 'with_', 'meta'])


# Generated at 2022-06-11 19:22:04.228383
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names()

# Generated at 2022-06-11 19:22:12.397196
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:21.308317
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = _RESERVED_NAMES
    assert 'action' in reserved
    assert 'delegate_to' in reserved
    assert 'vars' in reserved
    assert 'role_name' in reserved
    assert 'include_variables' not in reserved
    assert 'private' not in reserved

    # FIXME: remove after with_ is not only deprecated but removed
    assert 'loop' in reserved
    assert 'with_' in reserved
    assert 'local_action' in reserved

    # FIXME: remove after with_ is not only deprecated but removed
    assert get_reserved_names(True)
    assert get_reserved_names()
    assert get_reserved_names(False)

# Generated at 2022-06-11 19:22:27.933042
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names(include_private=True)
    assert names == _RESERVED_NAMES
    names = get_reserved_names(include_private=False)
    assert names.difference(_RESERVED_NAMES) == set(['action', 'loop', 'local_action', 'with_'])



# Generated at 2022-06-11 19:22:34.207574
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # build list of methods for all classes
    pla = Play()
    rol = Role()
    blk = Block()
    tas = Task()
    class_list = [Play, Role, Block, Task]

    result = get_reserved_names()

    # test if result set is super set of pla, rol, blk, tas
    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            if attribute in result:
                assert True
            else:
                assert False



# Generated at 2022-06-11 19:22:40.231581
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This must be called from an explicit test_<thing>() function, since
    get_reserved_names() is used to build the set _RESERVED_NAMES, and
    thus this would fail.
    '''

    pubic_names = get_reserved_names()
    private_names = get_reserved_names(include_private=True)

    assert(len(pubic_names) < len(private_names))

# Generated at 2022-06-11 19:22:43.457076
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ret = get_reserved_names()
    assert(ret)
    assert('name' in ret)
    assert('remote_user' in ret)
    assert('tasks' in ret)
    assert('roles' in ret)

# Generated at 2022-06-11 19:22:47.383240
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'tags' in reserved
    assert 'vars' in reserved
    assert 'action' in reserved
    assert 'register' in reserved
    assert 'block' in reserved
    assert 'when' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'private' not in reserved



# Generated at 2022-06-11 19:22:57.681209
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    assert 'action' in get_reserved_names(include_private=True)
    assert 'action' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'any_errors_fatal' not in get_reserved_names(include_private=False)

    assert 'tags' in get_reserved_names()

# Generated at 2022-06-11 19:23:05.242006
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''Validate that the reserved names are properly determined.'''

    # test without private names included.
    assert frozenset([u'name', u'debug', u'vars', u'roles', u'block', u'hosts', u'gather_facts', u'tasks', u'include', u'import_playbook', u'local_action', u'with_']) == get_reserved_names(False)

    # test with private names included