

# Generated at 2022-06-11 19:14:03.740649
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:13.463335
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:18.808631
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names()
    assert 'local_action' not in get_reserved_names(include_private=False)
    assert 'name' in get_reserved_names()
    assert 'name' in get_reserved_names(include_private=False)
    assert 'loop' in get_reserved_names()
    assert 'loop' in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names()
    assert 'with_' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:14:30.676774
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert ('name' in reserved)
    assert ('hosts' in reserved)
    assert ('roles' in reserved)
    assert ('tasks' in reserved)
    assert ('vars' in reserved)

    assert ('action' in reserved)
    assert ('local_action' in reserved)
    assert ('become' in reserved)
    assert ('become_user' in reserved)
    assert ('become_method' in reserved)
    assert ('connection' in reserved)
    assert ('environment' in reserved)

    assert ('block' in reserved)
    assert ('rescue' in reserved)
    assert ('always' in reserved)
    assert ('notify' in reserved)
    assert ('handlers' in reserved)

    assert ('include' in reserved)

# Generated at 2022-06-11 19:14:37.859110
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:41.131296
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests that all reserved names are returned by get_reserved_names '''
    assert len(_RESERVED_NAMES) > 0, "Expected to have some reserved names."

# Generated at 2022-06-11 19:14:48.322222
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:14:53.458640
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert len(get_reserved_names()) > 0
    assert isinstance(get_reserved_names(include_private=False), set)
    assert len(get_reserved_names(include_private=False)) > 0



# Generated at 2022-06-11 19:15:02.811400
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_public_names = frozenset(['any_errors_fatal',
                                       'become',
                                       'become_user',
                                       'connection',
                                       'delegate_facts',
                                       'environment',
                                       'gather_facts',
                                       'hosts',
                                       'max_fail_percentage',
                                       'serial',
                                       'sudo',
                                       'sudo_user',
                                       'tasks',
                                       'transport',
                                       'vars',
                                       'vars_prompt',
                                       'vars_files',
                                       'action',
                                       'local_action'])

# Generated at 2022-06-11 19:15:07.834269
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert isinstance(result, set)

    # this is a subset of the full list, b/c things like local_action, with_, and loop
    # are implicit and hence not direct attributes
    assert 'strategy' in result
    assert 'hosts' in result
    assert 'roles' in result
    assert 'tasks' in result

# Generated at 2022-06-11 19:15:24.199002
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == get_reserved_names(include_private=False)
    assert get_reserved_names(include_private=True) != get_reserved_names(include_private=False)
    assert isinstance(get_reserved_names(), frozenset)

# Generated at 2022-06-11 19:15:36.446634
# Unit test for function get_reserved_names
def test_get_reserved_names():

    play_object_names = set()
    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        play_object_names = play_object_names.union(aobj.__dict__['_attributes'])

        # local_action is implicit with action
        play_object_names.add('local_action')

        # loop implies with_
        # FIXME: remove after with_ is not only deprecated but removed
        play_object_names.add('with_')

    play_object_names = frozenset(play_object_names)

    # test for equality
    assert play_object_names == _

# Generated at 2022-06-11 19:15:46.039335
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import pytest


# Generated at 2022-06-11 19:15:54.931120
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from unittest import TestCase

    class TestGetReservedNames(TestCase):
        def test_get_reserved_names(self):
            result = get_reserved_names()
            self.assertIsInstance(result, set)
            self.assertIn('name', result)
            self.assertIn('action', result)
            self.assertIn('local_action', result)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGetReservedNames)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-11 19:15:59.469547
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'hosts' in reserved
    assert 'vars' in reserved
    assert 'roles' in reserved
    assert 'tags' in reserved
    assert 'gather_facts' in reserved

    # private keywords
    assert 'block' in reserved
    assert 'ignore_errors' in reserved
    assert 'loop' in reserved



# Generated at 2022-06-11 19:16:10.757009
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pub_reserved = set(['name', 'hosts', 'gather_facts', 'vars_prompt',
                        'vars_files', 'tasks', 'handlers', 'pre_tasks',
                        'post_tasks', 'roles', 'tags', 'when', 'any_errors_fatal',
                        'serial', 'transport', 'delegate_to', 'run_once', 'action'])

# Generated at 2022-06-11 19:16:17.833438
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get public names
    public = get_reserved_names(include_private=False)
    # get all names
    private = get_reserved_names(include_private=True)
    # public and private names should match
    assert(set(public).union(set(private)) == set(private))
    # check that we have the expected number of public names
    assert(len(public) == len(set(public)))
    # check that we have the expected number of all names
    assert(len(private) == len(set(private)))

# Generated at 2022-06-11 19:16:22.084675
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=True)
    assert isinstance(reserved_names, set)
    assert 'roles' in reserved_names
    assert 'tags' in reserved_names
    assert 'block' in reserved_names
    assert 'with_' in reserved_names


# Generated at 2022-06-11 19:16:30.560108
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # setup
    my_terms = {
        'when',
        'with_',
        'hosts',
        'roles',
        'action',
        'any_errors_fatal',
        'delegate_to',
        'notify',
        'handlers',
        'local_action',
        'run_once',
        'serial',
        'tasks',
        'vars',
    }

    # test same terms
    my_terms_set = get_reserved_names()

    assert my_terms_set == my_terms

    # test without private names
    my_terms_set = get_reserved_names(include_private=False)

    assert my_terms_set == my_terms - {'delegate_facts', 'group_by', 'loop'}

# Generated at 2022-06-11 19:16:37.393604
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:16:56.176596
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # get a list of reserved keywords for objects.
    # here we explicitly use set() instead set literal (e.g. {}) to ensure that
    # we are comparing with a set
    reserved = set(get_reserved_names())
    # reserved names relevant to play objects are:
    #   vars, when, pre_tasks, post_tasks, handlers, include_tasks, tasks
    #   connection, gather_facts, user, become, become_method, become_user
    #   serial, max_fail_percentage, ERROR, OKAY, SKIPPED, UNREACHABLE

# Generated at 2022-06-11 19:17:07.297034
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(False)
    assert 'hosts' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'roles' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' not in reserved_names
    assert 'tasks' in reserved_names
    assert 'local_action' in reserved_names

    names = get_reserved_names()

    assert 'hosts' in names
    assert 'pre_tasks' in names
    assert 'roles' in names
    assert 'block' in names
    assert 'action' in names
    assert 'loop' in names
    assert 'tasks' in names
    assert 'local_action' in names
   

# Generated at 2022-06-11 19:17:09.637884
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test_get_reserved_names
    '''
    assert 'roles' in get_reserved_names(include_private=False)


# Generated at 2022-06-11 19:17:20.720755
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:31.252470
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:42.557101
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test base and default case
    reserved = get_reserved_names(True)
    assert len(reserved) > 18 and len(reserved) < 27
    assert 'vars' in reserved and 'roles' in reserved
    assert 'loop' in reserved and 'with_' in reserved

    # test with private=False
    public_only = get_reserved_names(False)
    assert len(public_only) > 18 and len(public_only) < 26

    # ensure 'private' attributes are not present
    reserved_private_attributes = frozenset(['vars', 'roles', 'include_tasks', 'include_vars', 'role_path', 'loop'])
    assert reserved_private_attributes.isdisjoint(public_only)

# Generated at 2022-06-11 19:17:52.951803
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test that get_reserved_names returns proper set of reserved names '''

# Generated at 2022-06-11 19:17:55.409820
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(_RESERVED_NAMES) == len(get_reserved_names())



# Generated at 2022-06-11 19:18:04.536635
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:18:07.958508
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """
    run_once, vars_files, roles, become, gather_facts
    are all reserved names and should be part of the set.
    """

    reserved = get_reserved_names()

    assert 'run_once' in reserved
    assert 'vars_files' in reserved
    assert 'roles' in reserved
    assert 'become' in reserved
    assert 'gather_facts' in reserved

# Generated at 2022-06-11 19:18:35.773291
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = set(get_reserved_names())
    private_names = set(get_reserved_names(include_private=True))
    assert len(public_names) < len(private_names)

    assert 'name' in public_names
    assert 'action' in public_names
    assert 'local_action' in public_names
    assert 'with_' in public_names

# Generated at 2022-06-11 19:18:43.216713
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(['name', 'hosts', 'gather_facts', 'vars_files', 'vars_prompt', 'vars', 'tasks', 'pre_tasks', 'post_tasks', 'handlers', 'environment', 'no_log', 'become', 'become_user', 'become_method', 'become_flags', 'serial', 'any_errors_fatal', 'max_fail_percentage', 'force_handlers', 'tags', 'skip_tags', 'run_once', 'local_action'])


# Generated at 2022-06-11 19:18:50.192372
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'any_errors_fatal' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES
    assert 'vars' in _RESERVED_NAMES
    assert 'when' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES


# Generated at 2022-06-11 19:19:00.098027
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.compat.tests import unittest

    class TestReservedNames(unittest.TestCase):
        def setUp(self):
            # Gather all the expected reserved names

            self.reserved = set()

            # FIXME: find a way to 'not hardcode', possibly need role deps/includes
            class_list = [Play, Role, Block, Task]

            for aclass in class_list:
                aobj = aclass()

                # Build ordered list to loop over and dict with attributes
                for attribute in aobj.__dict__['_attributes']:
                    if 'private' not in attribute:
                        self.reserved.add(attribute)

            # local_action is implicit with action
            self.reserved.add('local_action')

            # loop implies with_
            # FIXME: remove after

# Generated at 2022-06-11 19:19:03.223736
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'debug' in get_reserved_names()

    assert is_reserved_name('name')
    assert is_reserved_name('delegate_to')
    assert not is_reserved_name('a')

# Generated at 2022-06-11 19:19:13.852614
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Assert function doesn't return duplicate names
    my_list = get_reserved_names()
    assert len(my_list) == len(set(my_list))

    # Assert function returns the correct value, including the private attributes
    assert set(get_reserved_names()) == set(['any_errors_fatal', 'changed_when', 'connection', 'delegate_to', 'failed_when', 'ignore_errors', 'loop', 'local_action', 'notify', 'poll', 'register', 'roles', 'sudo', 'sudo_user', 'transport', 'vars', 'with_', 'when', 'with'])

    # Assert function returns the correct value, only the public attributes

# Generated at 2022-06-11 19:19:24.094612
# Unit test for function get_reserved_names
def test_get_reserved_names():
    #def test_get_reserved_names(self):
    # test public names only
    list1 = get_reserved_names(include_private=False)
    list1.discard('vars')
    assert 'hosts' in list1
    assert 'playbook' not in list1
    assert 'become' in list1
    assert 'become_method' not in list1
    assert 'environment' in list1
    assert 'async' in list1
    assert 'register' in list1
    assert 'delegate_to' in list1
    assert 'environment' in list1
    assert 'action' in list1
    assert 'with_' in list1
    assert 'local_action' in list1
    assert 'tags' in list1

    # test private names
    list2 = get_reserved_names

# Generated at 2022-06-11 19:19:35.207730
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for get_reserved_names '''

    assert len(_RESERVED_NAMES) > 0
    assert 'action' in _RESERVED_NAMES
    assert 'any_errors_fatal' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'notified_by' in _RESERVED_NAMES
    #assert 'fireball_action' not in _RESERVED_NAMES

    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in _RESERVED_NAMES
    assert 'loop' in _RESERVED_NAMES



# Generated at 2022-06-11 19:19:44.261024
# Unit test for function get_reserved_names
def test_get_reserved_names():
    fn = get_reserved_names

    assert fn() == fn(True)
    assert 'name' in fn()
    assert 'connection' in fn()
    assert 'sudo' in fn()
    assert 'sudo_user' in fn()
    assert 'async' in fn()
    assert 'poll' in fn()
    assert 'become' in fn()
    assert 'become_user' in fn()
    assert 'environment' in fn()
    assert 'no_log' in fn()
    assert 'action' in fn()
    assert 'local_action' in fn()
    assert 'register' in fn()
    assert 'ignore_errors' in fn()
    assert 'when' in fn()
    assert 'args' in fn()
    assert 'delegate_to' in fn()
    assert 'transport' in fn()


# Generated at 2022-06-11 19:19:53.580131
# Unit test for function get_reserved_names
def test_get_reserved_names():

    from collections import Iterable

    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

    # Test public and private reserved name existence (length)
    # length should be different since private == public + private
    assert len(public) < len(private)

    # Test public/private reserved names == intial names
    assert public == get_reserved_names(include_private=False)
    assert private == get_reserved_names(include_private=True)

    # Test public/private reserved names are iterables (aka, sets)
    assert isinstance(public, Iterable)
    assert isinstance(private, Iterable)

# Generated at 2022-06-11 19:20:46.431152
# Unit test for function get_reserved_names
def test_get_reserved_names():
    res = get_reserved_names()
    assert 'hosts' in res
    assert 'roles' in res
    assert 'tasks' in res
    assert 'block' in res
    assert 'action' in res
    assert 'local_action' in res
    assert 'loop' in res
    assert 'with_' in res

    res = get_reserved_names(include_private=False)
    assert 'hosts' in res
    assert 'roles' in res
    assert 'tasks' in res
    assert 'block' in res
    assert 'action' in res
    assert 'local_action' in res
    assert 'loop' not in res
    assert 'with_' not in res



# Generated at 2022-06-11 19:20:47.261390
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)

# Generated at 2022-06-11 19:20:54.451049
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset({'name', 'action', 'local_action', 'with_', 'with_items', 'async', 'any_errors_fatal', 'delegate_to', 'poll', 'register', 'ignore_errors', 'block'})
    assert get_reserved_names(include_private=False) == frozenset({'name', 'action', 'with_items', 'async', 'any_errors_fatal', 'delegate_to', 'poll', 'register', 'ignore_errors', 'block'})



# Generated at 2022-06-11 19:20:57.581626
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names(include_private=False)
    assert len(names) > 0, 'Must get at least one reserved name'



# Generated at 2022-06-11 19:21:06.274396
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import pytest

    # Function get_reserved_names() should not return an empty list
    # Test for all public names
    public_object_names = get_reserved_names(include_private=False)
    assert len(public_object_names) > 0
    assert 'hosts' in public_object_names
    assert 'gather_facts' in public_object_names
    assert 'register' in public_object_names
    assert 'action' in public_object_names
    assert 'local_action' in public_object_names
    # Make sure something is removed
    assert 'ignore_errors' not in public_object_names
    assert 'delegate_to' not in public_object_names
    assert 'connection' not in public_object_names

    # Test for all public and private names

# Generated at 2022-06-11 19:21:12.107126
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert set(['vars', 'pre_tasks', 'block', 'block:rescue', 'block:always', 'roles']) <= reserved_names
    reserved_names = get_reserved_names(include_private=False)
    assert set(['vars', 'pre_tasks', 'roles']) <= reserved_names


# Generated at 2022-06-11 19:21:13.714834
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'private' not in get_reserved_names(False)

# Generated at 2022-06-11 19:21:24.261761
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = _RESERVED_NAMES

    assert 'vars' in reserved

    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'pre_tasks' in reserved
    assert 'post_tasks' in reserved
    assert 'handler_tasks' in reserved
    assert 'dependencies' in reserved

    assert 'action' in reserved
    assert 'local_action' in reserved

    assert 'block' in reserved

    assert 'name' in reserved
    assert 'tags' in reserved
    assert 'register' in reserved
    assert 'ignore_errors' in reserved

    assert 'notify' in reserved
    assert 'listen' in reserved

    assert 'when' in reserved
    assert 'loop' in reserved



# Generated at 2022-06-11 19:21:33.890116
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'privately_owned' in get_reserved_names()



# Generated at 2022-06-11 19:21:42.477025
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names()
    assert 'loop' not in get_reserved_names()
    assert 'loop' in get_reserved_names(include_private=True)
    assert 'with_' in get_reserved_names(include_private=True)
    assert 'with_' not in get_reserved_names()



# Generated at 2022-06-11 19:23:28.161660
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test no private
    result = get_reserved_names(include_private=False)
    assert 'action' in result
    assert 'local_action' in result
    assert 'loop' in result
    assert 'with_' in result
    assert 'block' not in result
    assert 'delegate_to' not in result

    # test private
    result = get_reserved_names(include_private=True)
    assert 'action' in result
    assert 'local_action' in result
    assert 'loop' in result
    assert 'with_' in result
    assert 'block' in result
    assert 'delegate_to' in result

