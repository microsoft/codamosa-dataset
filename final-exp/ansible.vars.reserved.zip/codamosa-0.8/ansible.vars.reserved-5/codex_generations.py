

# Generated at 2022-06-11 19:13:45.580824
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == get_reserved_names(include_private=True) - get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:13:52.966160
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:02.586118
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_list = list(get_reserved_names(include_private=True))

    assert 'name' in reserved_list
    assert 'hosts' in reserved_list
    assert 'hosts_regex' in reserved_list
    assert 'hosts_all' in reserved_list
    assert 'hosts_exclude_ansible' in reserved_list
    assert 'hosts_exclude' in reserved_list
    assert 'hosts_pattern' in reserved_list
    assert 'remote_user' in reserved_list
    assert 'remote_port' in reserved_list
    assert 'transport' in reserved_list
    assert 'connection' in reserved_list
    assert 'gather_facts' in reserved_list
    assert 'gather_timeout' in reserved_list
    assert 'any_errors_fatal' in reserved_list


# Generated at 2022-06-11 19:14:12.902847
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(["action", "hosts", "name", "tasks", "roles", "include_vars", "vars_files", "block", "pre_tasks", "async", "environment", "tags", "connection", "remote_user", "post_tasks", "any_errors_fatal", "delegate_to", "notify", "first_available_file", "local_action", "transport", "become", "become_user", "run_once", "no_log", "register", "ignore_errors", "check_mode", "with_items", "with_fileglob", "with_filetree", "with_sequence", "with_subelements", "with_nested", "with_random_choice", "with_first_found"])
    assert get

# Generated at 2022-06-11 19:14:22.481869
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)

    reserved_names_no_private = get_reserved_names(False)
    assert isinstance(reserved_names_no_private, set)

    assert len(reserved_names) == len(reserved_names_no_private) + 2

    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'ignore_errors' in reserved_names
    assert 'name' in reserved_names
    assert 'register' in reserved_names

    assert 'action' in reserved_names_no_private
    assert 'local_action'

# Generated at 2022-06-11 19:14:24.433297
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print(get_reserved_names())


# Generated at 2022-06-11 19:14:28.952651
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(True) == _RESERVED_NAMES
    assert get_reserved_names(False) == _RESERVED_NAMES.difference('private', 'connection')

# Generated at 2022-06-11 19:14:36.954278
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # variables that are reserved names
    reserved_names = set(get_reserved_names())
    assert 'roles' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names

    # spot check exclusions
    assert 'vars' not in reserved_names
    assert 'tasks' not in reserved_names

    # spot check private attributes
    assert 'private' not in reserved_names
    reserved_names_with_privates = set(get_reserved_names(include_private=True))
    assert 'private' in reserved_names_with_privates

    # test with additional names
    test_names = ['foo', 'bar', 'baz']

# Generated at 2022-06-11 19:14:46.603063
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:57.881709
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert ('hosts' in get_reserved_names(include_private=True))
    assert ('hosts' in get_reserved_names(include_private=False))

    assert ('random_attribute' not in get_reserved_names(include_private=True))
    assert ('random_attribute' not in get_reserved_names(include_private=False))

    assert ('become' in get_reserved_names(include_private=True))
    assert ('become' in get_reserved_names(include_private=False))

    assert ('serial' in get_reserved_names(include_private=True))
    assert ('serial' in get_reserved_names(include_private=False))

    assert ('run_once' in get_reserved_names(include_private=True))

# Generated at 2022-06-11 19:15:17.986252
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:25.110968
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'vars' in reserved
    assert 'block' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'loop' in reserved
    assert 'include_role' in reserved

    assert 'block' in get_reserved_names(include_private=True)
    assert 'block' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:15:30.326674
# Unit test for function get_reserved_names
def test_get_reserved_names():
    results = get_reserved_names(include_private=True)
    assert 'name' in results
    assert 'register' in results
    results = get_reserved_names(include_private=False)
    assert 'name' in results
    assert 'register' in results
    assert 'connection' not in results

# Generated at 2022-06-11 19:15:39.313298
# Unit test for function get_reserved_names
def test_get_reserved_names():
    set_reserved_names = set(get_reserved_names())
    set_reserved_names_without_private = set(get_reserved_names(include_private=False))
    set_reserved_names_with_private = set(get_reserved_names(include_private=True))

    assert 'name' in set_reserved_names
    assert 'name' in set_reserved_names_without_private
    assert 'name' in set_reserved_names_with_private

    assert 'private' in set_reserved_names
    assert 'private' not in set_reserved_names_without_private
    assert 'private' in set_reserved_names_with_private


# Generated at 2022-06-11 19:15:46.023065
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not _RESERVED_NAMES.intersection(set(['invalid_reserved_name', 'another_invalid_reserved_name']))
    assert 'gather_facts' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'connection' in _RESERVED_NAMES
    assert 'run_once' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES

# Generated at 2022-06-11 19:15:50.810357
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = ['name', 'hosts', 'roles', 'block']
    private = ['version', 'vars', 'default_vars', 'handlers', 'tasks', 'meta', 'action']

    assert get_reserved_names() == set(public + private)
    assert get_reserved_names(include_private=False) == set(public)

# Generated at 2022-06-11 19:15:57.889661
# Unit test for function get_reserved_names
def test_get_reserved_names():

    names = get_reserved_names(include_private=False)
    assert 'roles' in names

    names = get_reserved_names(include_private=True)
    assert 'action' in names

    names = get_reserved_names(include_private=True)
    assert 'with_' in names

    names = get_reserved_names(include_private=True)
    assert 'inventory' in names


# Generated at 2022-06-11 19:16:09.697521
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # get and sort list of reserved names
    reserved = get_reserved_names(include_private=False)
    reserved_items = list(reserved)
    reserved_items.sort()

    # define and sort the expected list

# Generated at 2022-06-11 19:16:16.499790
# Unit test for function get_reserved_names
def test_get_reserved_names():
    all_reserved = get_reserved_names(True)
    public_reserved = get_reserved_names(False)
    private_reserved = set(all_reserved).difference(frozenset(public_reserved))

    # Test to make sure the private reserved names are returned
    assert bool(private_reserved)

    # Test to make sure the private and public reserved names are in the all list
    assert bool(private_reserved.intersection(frozenset(public_reserved)))


# Generated at 2022-06-11 19:16:21.374788
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'debug' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'sudo_user' in get_reserved_names(False)
    assert 'become_user' in get_reserved_names(False)



# Generated at 2022-06-11 19:16:52.781486
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = ['hosts', 'name', 'roles', 'tasks', 'vars', 'vars_files']
    private = ['action', 'any_errors_fatal', 'block', 'block_errors', 'cache', 'check_mode', 'connection', 'delegate_to',
               'delegate_facts', 'deprecate_as', 'enabled', 'first_available_file', 'inventory', 'local_action',
               'loop', 'notify', 'poll', 'remote_user', 'register', 'retries', 'run_once', 'serial', 'sudo', 'sudo_user',
               'transport', 'until', 'when', 'with_']
    private.extend(public)

    assert isinstance(get_reserved_names(), set)

# Generated at 2022-06-11 19:17:03.918099
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == set([
        'action', 'hosts', 'name', 'ignore_errors', 'remote_user', 'gather_facts', 'sudo',
        'sudo_user', 'tags', 'tasks', 'vars_files', 'vars_prompt', 'vars',
        'connection', 'any_errors_fatal', 'serial', 'local_action', 'with_'
    ])

# Generated at 2022-06-11 19:17:10.879579
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import os
    from six import StringIO
    from ansible.utils.display import Display
    display = Display()
    old_stdout = display.display

    results = StringIO()
    display.display = results.write
    results.truncate(0)
    results.seek(0)
    get_reserved_names(include_private=True)
    assert 'private' in results.getvalue()

    results.truncate(0)
    results.seek(0)
    get_reserved_names(include_private=False)
    assert 'private' not in results.getvalue()

# Generated at 2022-06-11 19:17:22.048694
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'delegate_to', 'connection', 'local_action', 'vars', 'with_', 'any_errors_fatal', 'become', 'become_user', 'become_method', 'task_args', 'environment', 'register', 'retries', 'until', 'ignore_errors', 'register', 'tags', 'run_once', 'notify', 'always_run', 'delegate_facts', '_raw_params', 'first_available_file', 'with_first_available_file', 'any_errors_fatal', 'name'])

# Generated at 2022-06-11 19:17:25.205212
# Unit test for function get_reserved_names
def test_get_reserved_names():
    actual = get_reserved_names(False)
    assert len(actual) == 52
    assert 'roles' in actual
    assert 'meta' in actual
    assert 'fact_path' in actual
    assert 'vars_prompt' not in actual

# Generated at 2022-06-11 19:17:30.174483
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:36.428600
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = set(get_reserved_names(include_private=False))
    assert 'connection' in public_names
    assert 'roles' in public_names
    assert 'name' in public_names
    assert 'any_errors_fatal' in public_names
    assert 'vars_files' in public_names
    assert 'tasks' in public_names
    assert 'loop' not in public_names

    private_names = set(get_reserved_names(include_private=True))
    assert 'connection' in private_names
    assert 'roles' in private_names
    assert 'name' in private_names
    assert 'any_errors_fatal' in private_names
    assert 'vars_files' in private_names
    assert 'tasks' in private_names

# Generated at 2022-06-11 19:17:39.309687
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'hosts' in reserved
    assert not is_reserved_name('foo')
    assert is_reserved_name('hosts')

# Generated at 2022-06-11 19:17:43.828134
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'become' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:17:54.108471
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:18:41.815555
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=False)
    assert len(result) == 16
    assert 'hosts' in result
    assert 'connection' in result
    assert 'vars' in result
    assert 'roles' in result
    assert 'gather_facts' in result

    result = get_reserved_names(include_private=True)
    assert len(result) == 19
    assert 'hosts' in result
    assert 'connection' in result
    assert 'vars' in result
    assert 'roles' in result
    assert 'gather_facts' in result
    assert 'serial' in result

# Generated at 2022-06-11 19:18:45.136963
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Try without private names
    assert not get_reserved_names(False).issuperset(['private'])

    # Try with private names
    assert get_reserved_names().issuperset(['private'])


# Generated at 2022-06-11 19:18:53.087146
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Regular test
    reserved_names = get_reserved_names(include_private=True)

    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names

    # Test without private names
    reserved_names = get_reserved_names(include_private=False)

    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars_files' in reserved_names
    assert 'roles' in reserved_names

    # Test for specific names
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()



# Generated at 2022-06-11 19:19:01.818668
# Unit test for function get_reserved_names
def test_get_reserved_names():
    external_vars = get_reserved_names()

# Generated at 2022-06-11 19:19:08.087932
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(include_private=False)
    private_names = get_reserved_names(include_private=True)
    assert private_names.union(public_names) == _RESERVED_NAMES, "Error in get_reserved_names"
    assert private_names.intersection(public_names) == public_names, "Error in get_reserved_names"

# Generated at 2022-06-11 19:19:15.841317
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    unit test to validate that get_reserved_names is working as expected.
    '''

    assert get_reserved_names(False) == get_reserved_names()
    assert set(get_reserved_names()) == set(['roles', 'name', 'tasks', 'vars', 'block', 'connection', 'any_errors_fatal', 'delegate_to', 'when', 'handler', 'first_available_file', 'notify', 'local_action', 'include', 'include_tasks', 'gather_facts', 'register', 'with_', 'sudo', 'sudo_user', 'environment', 'serial', 'user'])

    assert set(get_reserved_names(True)).issuperset(set(['tags', 'environment', 'serial', 'user']))



# Generated at 2022-06-11 19:19:24.165097
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected = frozenset(['block', 'block_tasks', 'default_vars', 'delegate_to', 'dst', 'environment', 'gather_facts',
                         'gather_subset', 'hosts', 'ignore_errors', 'include', 'include_role', 'include_tasks',
                         'local_action', 'loop', 'no_log', 'notify', 'notified_by', 'others', 'post_tasks', 'pre_tasks',
                         'register', 'remote_user', 'roles', 'serial', 'src', 'tags', 'task_name', 'tasks', 'when',
                         'with_'])

    returned = get_reserved_names()

    assert returned == expected

# Generated at 2022-06-11 19:19:36.187826
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    tests the output of get_reserved_names()

    this is to make sure the function works as intended (not simply as a way to list the names)
    '''
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    # test if function includes builtin names
    reserved_names_for_builtins = [item for item in builtins.__dict__ if item in _RESERVED_NAMES]
    if reserved_names_for_builtins:
        raise Exception('found reserved names used for builtins: %s' % reserved_names_for_builtins)

    # test if function includes builtin types
    reserved_types_for_builtins = [item for item in builtins.__dict__ if item in _RESERVED_NAMES]

# Generated at 2022-06-11 19:19:37.591169
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pass
    #assert 'hosts' in get_reserved_names()

# Generated at 2022-06-11 19:19:39.342059
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == len(get_reserved_names(include_private=False))

# Generated at 2022-06-11 19:20:30.693930
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pub_reserved = ['name', 'hosts', 'remote_user', 'connection',
                    'sudo', 'sudo_user', 'environment', 'become',
                    'become_user', 'become_method', 'when', 'gather_facts', 'tags']


# Generated at 2022-06-11 19:20:37.638951
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_items' in reserved_names
    assert 'block' in reserved_names
    assert 'rescue' in reserved_names
    assert 'always' in reserved_names
    assert 'connection' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'any_errors_fatal' in reserved_names

# Generated at 2022-06-11 19:20:40.392785
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # this will fail if above list is not empty
    assert get_reserved_names() is not None



# Generated at 2022-06-11 19:20:46.890904
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test function get_reserved_names() '''

    # Test if function get_reserved_names() returns a list
    list_of_reserved_names = get_reserved_names(include_private=True)
    assert isinstance(list_of_reserved_names, set)

    # Test if function get_reserved_names() returns a list of reserved names
    # Test if list contains all the reserved attribute names

# Generated at 2022-06-11 19:20:52.076405
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import pytest
    from ansible.playbook.play import Play

    reserved1 = frozenset(get_reserved_names())
    for name in reserved1:
        assert isinstance(name, str)
        assert hasattr(Play, name)

    assert not reserved1.isdisjoint(set(getattr(Play(), name) for name in reserved1))

# Generated at 2022-06-11 19:21:02.349826
# Unit test for function get_reserved_names
def test_get_reserved_names():
    actual = get_reserved_names()

    expected = set()
    # FIXME: find a way to 'not hardcode'
    expected.add('roles')
    expected.add('name')
    expected.add('hosts')
    expected.add('tasks')
    expected.add('block')
    expected.add('action')
    expected.add('local_action')
    expected.add('with_')
    expected.add('include_tasks')
    expected.add('include_role')
    expected.add('loop')

    # This is reserved by the yaml parser
    if 'vars' in actual:
        actual.remove('vars')

    # FIXME: find a way to 'not hardcode'
    # Until we can find a way to detect options in plugins dynamically,
    # this is a throwaway

# Generated at 2022-06-11 19:21:08.701802
# Unit test for function get_reserved_names
def test_get_reserved_names():

    class_list = [Play, Role, Block, Task]
    for aclass in class_list:
        assert aclass.__name__ in get_reserved_names()

    assert 'local_action' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'include' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'role' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()

# Generated at 2022-06-11 19:21:11.903470
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)
    assert 'ansible_ssh_pass' in reserved_names


# Generated at 2022-06-11 19:21:19.096212
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Tests for names reserved for Ansible play objects. '''

    # Names with private or complex attributes take precedent.
    assert 'connection' not in get_reserved_names()
    assert 'gather_facts' not in get_reserved_names()
    assert 'hosts' not in get_reserved_names()
    assert 'no_log' not in get_reserved_names()
    assert 'serial' not in get_reserved_names()
    assert 'sudo' not in get_reserved_names()
    assert 'sudo_user' not in get_reserved_names()
    assert 'sudo_pass' not in get_reserved_names()
    assert 'sudo_exe' not in get_reserved_names()
    assert 'tags' not in get_reserved_names()
    assert 'transport' not in get

# Generated at 2022-06-11 19:21:26.947445
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:23:04.563096
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset([u'environment', u'vars', u'pre_tasks',
                                              u'post_tasks', u'roles', u'become', u'become_user',
                                              u'import_playbook', u'register', u'tags', u'gather_facts',
                                              u'local_action', u'with_', u'connection', u'no_log', u'when',
                                              u'async', u'poll', u'until', u'failed_when'])

# Generated at 2022-06-11 19:23:14.173442
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names(include_private=False)
    assert 'when' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:23:22.712958
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # local_action is implicit with action
    assert 'action' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES

    # with_ implies loop
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'loop' in _RESERVED_NAMES
    assert 'with_' in _RESERVED_NAMES

    # name and tags are deprecated
    assert 'name' in _RESERVED_NAMES
    assert 'tags' in _RESERVED_NAMES



# Generated at 2022-06-11 19:23:25.024319
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private_names = get_reserved_names(include_private=False)
    public_names = get_reserved_names(include_private=True)
    assert private_names != public_names

# Generated at 2022-06-11 19:23:27.681495
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) > 0



# Generated at 2022-06-11 19:23:36.391171
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'action', 'async', 'become', 'become_method', 'become_user', 'block', 'changed_when', 'connection', 'sudo', 'sudo_user', 'delegate_facts', 'environment', 'failed_when', 'gather_facts', 'ignore_errors', 'include', 'include_vars', 'name', 'no_log', 'notify', 'register', 'remote_user', 'roles', 'run_once', 'tags', 'tasks', 'until', 'vars', 'with_', 'vars_files', 'vars_prompt', 'vault_password_files', 'when'}