

# Generated at 2022-06-11 19:13:56.054455
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:03.905497
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_common_reserved_names = {'name', 'any_errors_fatal', 'connection', 'gather_facts', 'delegate_to', 'no_log', 'remote_user', 'sudo', 'sudo_user', 'when', 'async', 'poll', 'register', 'first_available_file', 'local_action', 'transport', 'ignore_errors', 'retries', 'until', 'delay', 'environment', 'failed_when', 'failed_results', 'ignore_unreachable', 'port', 'su', 'su_user', 'tags', 'with_'}
    public_play_reserved_names = public_common_reserved_names.union({'roles', 'pre_tasks', 'post_tasks', 'tasks'})
    public_role_reserved_names = public_common_reserved_

# Generated at 2022-06-11 19:14:05.938899
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-11 19:14:10.420246
# Unit test for function get_reserved_names
def test_get_reserved_names():

    pub = get_reserved_names(include_private=False)
    priv = get_reserved_names(include_private=True)

    # the private list should be bigger than the public list
    assert(len(priv) > len(pub))

    # the private list should contain all public names
    assert(pub.issubset(priv))

# Generated at 2022-06-11 19:14:21.894362
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(['tags', 'connection', 'gather_facts'])
    private = set(['private', 'delegate_to'])
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attr in aobj.__dict__['_attributes']:
            if 'private' in attr:
                private.add(attr)
            else:
                public.add(attr)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_

# Generated at 2022-06-11 19:14:33.042173
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''Tests to make sure get_reserved_names does not return unexpected names'''

    import os
    import sys
    import inspect

    # Get all public attributes for Play, Block, Role, and Task objects.
    # Private attributes are filtered out by their leading underscore.
    # However, the Task object contains _load_attributes which is not a
    # private attribute even though it contains a leading underscore. To
    # filter out this attribute, we have to filter it out explicitly.

# Generated at 2022-06-11 19:14:38.679018
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # We will know that the test failed if we have any of these in the
    # non-private reserved names.
    non_public = ('private', 'vars_prompt')

    reserved = get_reserved_names()

    for name in non_public:
        assert name not in reserved

    for name in non_public:
        assert name in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:14:47.433520
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)
    assert 'name' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()
    assert isinstance(get_reserved_names(include_private=True), set)
    assert 'name' in get_reserved_names(include_private=True)
    assert 'any_errors_fatal' in get_reserved_names(include_private=True)
    assert 'group_by' in get_reserved_names(include_private=True)
    assert 'loop' in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:14:55.076024
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'tags' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()


# Generated at 2022-06-11 19:14:56.035261
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)

# Generated at 2022-06-11 19:15:14.205399
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names(False) == {'roles', 'gather_facts', 'become', 'user', 'sudo_user', 'connection', 'name', 'hosts', 'vars', 'any_errors_fatal', 'serial',
                                        'sudo', 'delegate_to', 'become_method', 'become_user', 'environment', 'tags', 'run_once', 'ignore_errors', 'create_dirs',
                                        'check_mode', 'action', 'local_action', 'with_'})

# Generated at 2022-06-11 19:15:19.547253
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=True) == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(['action', 'local_action', 'with_'])


# Generated at 2022-06-11 19:15:27.736754
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(['roles', 'hosts', 'name', 'vars', 'tasks', 'gather_facts', 'vars_files', 'pre_tasks',
                  'post_tasks', 'handlers', 'max_fail_percentage', 'any_errors_fatal', 'serial', 'block',
                  'become', 'become_user', 'become_method', 'local_action'])
    private = set(['action', 'with_', 'include', 'include_tasks', 'include_vars', 'loop', 'when', 'tags',
                   'register', 'freeze_includes', 'max_fail_percentage', 'any_errors_fatal', 'block'])

    assert public.union(private) == get_reserved_names()
    assert public == get_reserved_names(False)

# Generated at 2022-06-11 19:15:33.225885
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ret = get_reserved_names()
    assert 'roles' in ret
    assert 'tasks' in ret

    ret = get_reserved_names(include_private=False)
    assert 'roles' in ret
    assert 'tasks' in ret
    assert 'any_errors_fatal' not in ret

# Generated at 2022-06-11 19:15:42.366600
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Function get_reserved_names returns the list of reserved names associated with play objects
    including private ones if include_private is True
    '''

    # this test is only relevant to ansible 2.4+, ansible 2.3 does not have
    # 'private' names
    if LooseVersion(__version__) < LooseVersion('2.4'):
        return

    reserved_names = get_reserved_names(include_private=True)

    # The list of reserved names also includes the reserved names of parent class

# Generated at 2022-06-11 19:15:50.339912
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:16:00.622391
# Unit test for function get_reserved_names
def test_get_reserved_names():

    class PlayAnsible(Play):
        _valid_attrs = frozenset(('playbook', 'play_hosts', 'play_basedir', 'play_name', 'play_uuid', 'play_suuid', 'play_roles', 'handler_list', 'clear_host_errors'))

    class RoleAnsible(Role):
        _valid_attrs = frozenset(('role_name',))

    class BlockAnsible(Block):
        _valid_attrs = frozenset(('block_name',))

    class TaskAnsible(Task):
        _valid_attrs = frozenset(('name',))

    class_list = [PlayAnsible, RoleAnsible, BlockAnsible, TaskAnsible]

    for aclass in class_list:
        public = set()


# Generated at 2022-06-11 19:16:11.460572
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests get_reserved_names() function.
    '''
    _public_reserved_names = frozenset(['task_start', 'block', 'task', 'tasks', 'name', 'include', 'include_tasks', 'roles', 'role_names', 'role_params', 'include_role', 'hosts', 'delegate_to', 'vars', 'tags', 'environment', 'environment_append', 'environment_replace', 'no_log', 'deprecations', 'when', 'register', 'local_action', 'connection', 'with_'])

# Generated at 2022-06-11 19:16:20.395935
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'include_vars' in reserved_names
    assert 'role' in reserved_names
    assert 'roles' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop' in reserved_names

    # private attributes are not part of the public API
    reserved_names = get_reserved_names(include_private=False)

    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'include_vars'

# Generated at 2022-06-11 19:16:24.512806
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    # there are currently two ways in which a reserved word may be in the list
    # 'action' should be present for 'local_action'
    # 'loop' should be present for 'with_'
    # since the list is a set and all items are unique, we check the length
    assert 'action' in reserved
    assert 'loop' in reserved
    assert len(reserved) - 2 == len(get_reserved_names(include_private=False))
    assert len(reserved) == len(get_reserved_names(include_private=True))

# Generated at 2022-06-11 19:16:47.912388
# Unit test for function get_reserved_names
def test_get_reserved_names():
    results = get_reserved_names()

    assert 'become_user' in results
    assert 'become' in results
    assert 'action' in results
    assert 'local_action' in results
    assert 'with_' in results
    assert 'with_' in results
    assert 'register' in results
    assert 'ignore_errors' in results
    assert 'always_run' in results

    results = get_reserved_names(include_private=False)

    assert 'become_user' in results
    assert 'become' in results
    assert 'action' in results
    assert 'local_action' in results
    assert 'with_' in results
    assert 'register' not in results
    assert 'ignore_errors' not in results
    assert 'always_run' not in results

# Generated at 2022-06-11 19:16:55.385806
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:05.379472
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(len(get_reserved_names()) > 20)
    assert(len(get_reserved_names(include_private=False)) < 30)
    assert(len(get_reserved_names(include_private=False)) > 20)
    assert(len('with_') > 1)
    assert('with_' in get_reserved_names())
    assert(len('action') > 1)
    assert('action' in get_reserved_names())
    assert(len('local_action') > 1)
    assert('local_action' in get_reserved_names())
    assert(len('loop') > 1)
    assert('loop' in get_reserved_names())


# Generated at 2022-06-11 19:17:11.178232
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' check for differences when getting reserved names '''

    reserved = get_reserved_names()
    assert len(reserved) > 0

    reserved_private = get_reserved_names(True)
    assert len(reserved_private) > 0
    assert len(reserved_private) > len(reserved)

    reserved_public = get_reserved_names(False)
    assert len(reserved_public) > 0
    assert len(reserved_public) < len(reserved)



# Generated at 2022-06-11 19:17:22.133131
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Basic test, do names match?
    assert len(get_reserved_names().intersection(['name', 'hosts', 'gather_facts', 'roles'])) == 4

    # Do we get the same results with include private on/off?
    assert len(get_reserved_names(include_private=True)) == len(get_reserved_names(include_private=False)) + 2

    # Do we get the same results with include private on (default) / off
    assert len(get_reserved_names(include_private=True)) == len(get_reserved_names()) + 2

    # Do we get the same results with include private on/off in same run
    assert len(get_reserved_names(include_private=False)) == len(get_reserved_names(include_private=False))

    #

# Generated at 2022-06-11 19:17:25.635588
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=True) == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES - frozenset(['loop', 'tags', 'register', 'until', 'environment'])

# Generated at 2022-06-11 19:17:33.202703
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['roles', 'include', 'include_role', 'when', 'vars_files', 'tags', 'pre_tasks', 'tasks', 'post_tasks', 'handlers', 'delegate_to', 'run_once', 'connection', 'sudo_user', 'sudo', 'become', 'become_user', 'become_method', 'environment', 'block', 'ignore_errors', 'register', 'name', 'local_action', 'with_', 'transport', 'remote_user', 'sudo_pass', 'no_log', 'any_errors_fatal'])

# Generated at 2022-06-11 19:17:43.747546
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for function get_reserved_names '''

    # the size of the names list should always be the same
    assert(len(get_reserved_names()) == len(get_reserved_names(include_private=False)))

    # the private names should always be a subset of the public plus private names
    assert(get_reserved_names(include_private=False).issubset(get_reserved_names()))

    # check to see if role names are also in the list
    assert(len(get_reserved_names().intersection(set(['name', 'pretasks', 'posttasks']))) == 3)

    # check to see if role names are also in the list

# Generated at 2022-06-11 19:17:53.430089
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    reserved_names_private = get_reserved_names(include_private=True)
    reserved_names_public = get_reserved_names(include_private=False)

    assert 'private' in reserved_names_private
    assert 'private' not in reserved_names_public
    assert 'private' not in reserved_names

    assert 'with_first_found' not in reserved_names_private
    assert 'with_first_found' not in reserved_names_public
    assert 'with_first_found' not in reserved_names

    assert 'with_items' in reserved_names_private
    assert 'with_items' not in reserved_names_public
    assert 'with_items' not in reserved_names

# Generated at 2022-06-11 19:17:59.561681
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = set(['connection', 'gather_facts', 'hosts', 'remote_user', 'serial', 'sudo', 'sudo_user', 'tags'])
    private_names = set(['_handler', '_role', '_task'])
    total_names = public_names.union(private_names)

    # Public names
    assert public_names == get_reserved_names(include_private=False)

    # Private names
    assert private_names == get_reserved_names(include_private=True) - get_reserved_names(include_private=False)

    # Total names
    assert total_names == get_reserved_names()



# Generated at 2022-06-11 19:18:27.470196
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(len(get_reserved_names(False)) > 1)
    assert(len(get_reserved_names(True)) > 1)

    # check for empty set!
    assert(len(get_reserved_names(False)) > len(get_reserved_names(True)))

# Generated at 2022-06-11 19:18:36.825578
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = ('name', 'hosts', 'vars', 'roles', 'tasks', 'block', 'handlers', 'meta', 'any_errors_fatal',
                    'changed_when', 'force_handlers', 'gather_facts', 'ignore_errors', 'include', 'include_role',
                    'import_playbook', 'no_log', 'post_tasks', 'pre_tasks', 'register', 'remote_user',
                    'serial', 'strategy', 'tags', 'tasks', 'vars')


# Generated at 2022-06-11 19:18:43.822009
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:18:52.861998
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:18:58.588909
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: this should be in a proper unit test module,
    #        however, this will work for now until we split
    #        this out into a separate module.
    class FakeClass(object):
        _attributes = frozenset(8)

    my_obj = FakeClass()
    assert isinstance(my_obj._attributes, frozenset)
    assert get_reserved_names(include_private=True) == frozenset(8)

# Generated at 2022-06-11 19:19:08.561280
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test get_reserved_names function '''

    # Remove the 'private' key
    class_list = [Play, Role, Block, Task]
    attribute_set = set()

    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            if not 'private' in attribute:
                attribute_set.add(attribute)

    # local_action is implicit with action
    attribute_set.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    attribute_set.add('loop')
    attribute_set.add('with_')

    assert attribute_set == _RESERVED_NAMES


# Generated at 2022-06-11 19:19:11.397101
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert get_reserved_names() == get_reserved_names(include_private=False)

    assert 'include' in get_reserved_names()

# Generated at 2022-06-11 19:19:22.598106
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:19:29.458078
# Unit test for function get_reserved_names
def test_get_reserved_names():
    class Test(object):
        _attributes = dict(
            foo=('bar', 'baz'),
            with_=('bar', 'baz'),
            blah=('bar', 'baz'),
            action=('bar', 'baz'),
            local_action=('bar', 'baz'),
            loop=('bar', 'baz'),
            _private=('bar', 'baz'),
        )
    public = set(['foo', 'with_', 'blah', 'action', 'loop'])
    private = set(['foo', 'with_', 'blah', 'action', 'local_action', 'loop', '_private', 'loop'])
    assert(get_reserved_names(False) == public)
    assert(get_reserved_names(True) == private)

# Generated at 2022-06-11 19:19:38.370225
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test public only and contains private
    assert isinstance(get_reserved_names(), set)
    assert 'playbook' in get_reserved_names()
    assert 'inventory' in get_reserved_names()
    assert 'remote_user' in get_reserved_names()
    assert 'remote_pass' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'gather_facts' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'remote_user' in get_reserved_names(include_private=True)
    assert 'remote_user' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:20:30.068411
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # we have all the default attributes
    assert len(get_reserved_names()) == len(Play().__dict__) - len(Play().__dict__['_attributes'])

    # we have all the default attributes plus the private ones
    assert len(get_reserved_names(True)) == len(Play().__dict__)



# Generated at 2022-06-11 19:20:33.273349
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test public names
    test_names = set(get_reserved_names(include_private=False))

# Generated at 2022-06-11 19:20:36.791810
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # checking length is more reliable than copying the list in this test
    assert len(_RESERVED_NAMES) == 89
    assert len(get_reserved_names()) == 89
    assert len(get_reserved_names(include_private=False)) == 46

# Generated at 2022-06-11 19:20:42.090124
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test in function
    output = get_reserved_names()
    assert type(output) == set
    assert len(output)
    assert 'hosts' in output

    # Test against _RESERVED_NAMES
    output2 = get_reserved_names()
    assert output == _RESERVED_NAMES



# Generated at 2022-06-11 19:20:49.132040
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset([
        'any_errors_fatal',
        'connection',
        'delegate_to',
        'gather_facts',
        'hosts',
        'notify',
        'remote_user',
        'roles',
        'serial',
        'strategy',
        'sudo',
        'sudo_user',
        'tags',
        'tasks',
        'transport',
        'until',
        'vars',
        'vault_id',
        'vault_password_files',
        'with_'
    ])



# Generated at 2022-06-11 19:20:52.822791
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:20:55.781958
# Unit test for function get_reserved_names
def test_get_reserved_names():
    for aclass in [Play(), Role(), Block(), Task()]:
        for attribute in aclass.__dict__['_attributes']:
            assert attribute in _RESERVED_NAMES

# Generated at 2022-06-11 19:21:04.965508
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this unit test checks if the reserved name list yields all names '''

    # public names
    public_names = frozenset(get_reserved_names(include_private=False))
    assert 'name' in public_names
    assert 'hosts' in public_names
    assert 'vars' in public_names
    assert 'tasks' in public_names
    assert 'when' in public_names

    # private names
    private_names = frozenset(get_reserved_names(include_private=True))
    assert 'delegate_facts' in private_names
    assert 'run_once' in private_names
    assert 'connection' in private_names
    assert 'gather_facts' in private_names

    # full list
    names = frozenset(get_reserved_names())

# Generated at 2022-06-11 19:21:15.199902
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:21:25.436470
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_result = get_reserved_names(include_private=False)
    assert type(test_result) is set
    assert len(test_result) > 0
    assert 'playbook' in test_result
    assert 'become_user' not in test_result
    assert 'hosts' in test_result


# Generated at 2022-06-11 19:22:17.349058
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = _RESERVED_NAMES
    assert 'hosts' in names
    assert 'roles' in names
    assert 'gather_facts' in names
    assert 'vars_files' in names
    assert 'pre_tasks' in names
    assert 'tasks' in names
    assert 'post_tasks' in names
    assert 'pre_role_tasks' in names
    assert 'post_role_tasks' in names

# Generated at 2022-06-11 19:22:24.174027
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_reserved = ['name', 'action', 'connection', 'delegate_to', 'delegate_facts', 'ignore_errors',
                       'no_log', 'notify', 'register', 'remote_user', 'sudo', 'sudo_user', 'tags', 'when', 'local_action']
    private_reserved = ['loop', 'loop_control']
    all_reserved = public_reserved + private_reserved

    # Test public reserved
    public_reserved_set = set(public_reserved)
    public_reserved_check = get_reserved_names(False)
    if public_reserved_set.issubset(public_reserved_check):
        assert True
    else:
        assert False

    private_reserved_set = set(private_reserved)

# Generated at 2022-06-11 19:22:33.640812
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:43.614439
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:48.366950
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'register' in _RESERVED_NAMES
    assert 'become_user' in _RESERVED_NAMES
    assert 'when' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'with_loop' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES

# Generated at 2022-06-11 19:22:58.408226
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    def mytest(name, set_of_reserved_names):
        assert isinstance(name, str)
        assert isinstance(set_of_reserved_names, set)
        assert name in set_of_reserved_names


    # make sure all yaml elements in _attributes are in reserved list
    for aclass in class_list:
        # build ordered list to loop over and dict with attributes
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                mytest(attribute, get_reserved_names(include_private=True))

# Generated at 2022-06-11 19:23:03.912300
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import pytest
    assert 'hosts' in get_reserved_names()
    assert 'roles' not in get_reserved_names()
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'tags' in get_reserved_names()
    assert 'tasks' not in get_reserved_names()
    assert 'tasks' in get_reserved_names(include_private=False)


# Unit tests for function warn_if_reserved

# Generated at 2022-06-11 19:23:14.632267
# Unit test for function get_reserved_names
def test_get_reserved_names():
    tst_public = set(['hosts', 'name', 'roles', 'gather_facts', 'remote_user',
                      'sudo', 'tasks', 'tasks_from', 'vars', 'vars_from',
                      'vars_prompt', 'action', 'local_action', 'with_'])
    tst_private = set(['_attributes', '_included_files', '_role_names', '_role_params',
                       '_role_vars', '_post_validation_assertion_callbacks', '_dep_chain',
                       '_dep_map', '_task_deps', '_task_blocks', '_loop'])
    tst_full = tst_public.union(tst_private)
    # by default we return public + private
    assert tst_

# Generated at 2022-06-11 19:23:24.905994
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:23:35.631818
# Unit test for function get_reserved_names