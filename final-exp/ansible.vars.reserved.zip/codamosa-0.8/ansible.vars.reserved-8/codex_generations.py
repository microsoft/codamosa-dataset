

# Generated at 2022-06-11 19:13:56.340163
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_set = frozenset(['name', 'hosts', 'vars', 'tasks', 'roles', 'pre_tasks', 'post_tasks', 'tags', 'errors',
                            'any_errors_fatal', 'max_fail_percentage', 'serial', 'gather_facts', 'ignore_errors',
                            'action', 'local_action', 'delegate_to', 'become', 'become_user', 'become_method',
                            'with_', 'become_flags', 'forks', 'remote_user', 'connection', 'inventory', 'playbook',
                            'play', 'play_hosts', 'playbook_basedir', 'remote_addr', 'remote_port', 'use_handlers',
                            'ignore_conditional_check'])
    private_set = frozens

# Generated at 2022-06-11 19:13:58.780667
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() >= get_reserved_names(False)
    assert get_reserved_names(True) != get_reserved_names(False)

# Generated at 2022-06-11 19:14:04.831541
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not set(get_reserved_names().union(['pre_tasks', 'post_tasks'])).difference(get_reserved_names(include_private=True))
    assert not set(get_reserved_names(include_private=False)).difference(get_reserved_names(include_private=True))



# Generated at 2022-06-11 19:14:14.168540
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:16.585785
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names(include_private=False)) == len(get_reserved_names()) - 6



# Generated at 2022-06-11 19:14:21.313032
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = ['block', 'any_errors_fatal', 'delegate_to', 'pre_tasks', 'roles', 'with_items', 'vars',
                      'become', 'become_user', 'delegate_facts', 'gather_facts', 'hosts', 'serial', 'tags']

    assert sorted(get_reserved_names()) == sorted(reserved_names)

# Generated at 2022-06-11 19:14:25.412084
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'tags' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'async' not in get_reserved_names()



# Generated at 2022-06-11 19:14:32.339770
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names(include_private=True)
    assert 'connection' in names
    assert 'sudo' in names
    assert 'sudo_user' in names
    assert 'remote_user' in names

    names = get_reserved_names(include_private=False)
    assert 'connection' in names
    assert 'sudo' not in names
    assert 'sudo_user' not in names
    assert 'remote_user' not in names



# Generated at 2022-06-11 19:14:43.477346
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:53.909982
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # we do not use assertIn/assertNotIn because that prevents us from
    # printing out what the test is checking

    # check that any attribute found in the set of reserved names is either
    # an attribute of the object, or is the implied local action
    reserved = get_reserved_names(include_private=True)
    for reserved_name in reserved:
        assert(reserved_name in _RESERVED_NAMES)

    # check that loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    assert('with_' in reserved)

    # check that action implies local_action
    assert('local_action' in reserved)

    # check that we find attributes in the public or private section of the play object
    reserved = get_reserved_names(include_private=False)
    # we cannot assert

# Generated at 2022-06-11 19:15:11.896271
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

# Generated at 2022-06-11 19:15:21.113649
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Create dict of names and test that they are correct.
    # These are the names we expect to be returned by get_reserved_names()
    expected_public = {
        "action", "delegate_to", "delegate_facts", "ignore_errors", "loop", "name", "remote_user", "until",
        "run_once", "tags", "register", "errors", "with_", "notify", "local_action", "transport", "become",
        "become_method", "become_user", "become_flags", "when", "async", "poll", "su", "sudo", "sudo_user",
        "sudo_flags", "connection", "environment", "no_log", "meta", "any_errors_fatal", "always_run",
    }

# Generated at 2022-06-11 19:15:28.499910
# Unit test for function get_reserved_names
def test_get_reserved_names():
    r = get_reserved_names()

    # this is the set of reserved names.

# Generated at 2022-06-11 19:15:39.352263
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:48.507101
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:51.260375
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'gather_facts' in get_reserved_names()

test_get_reserved_names()

# Generated at 2022-06-11 19:15:55.023164
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert reserved_names
    assert 'gather_facts' in reserved_names
    assert 'privatekey_file' in reserved_names

# Generated at 2022-06-11 19:16:02.181230
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests if the function get_reserved_names is returning
    the right set of reserved names based on the consituent plays'''

    reserved = _RESERVED_NAMES
    reserved_list = list(reserved)
    assert 'name' in reserved_list, 'playbook name not in reserved list'
    assert 'hosts' in reserved_list, 'playbook hosts not in reserved list'
    assert 'gather_facts' in reserved_list, 'playbook gather_facts not in reserved list'
    assert 'tasks' in reserved_list, 'playbook tasks not in reserved list'
    assert 'no_log' in reserved_list, 'playbook no_log not in reserved list'
    assert 'vars' in reserved_list, 'playbook vars not in reserved list'
    assert 'action' in reserved_

# Generated at 2022-06-11 19:16:07.922406
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests reserved names '''

    reserved = get_reserved_names()
    required_reserved = set(['tasks', 'handlers', 'vars', 'pre_tasks', 'post_tasks', 'roles'])
    assert(reserved.intersection(required_reserved) == required_reserved)

# Generated at 2022-06-11 19:16:18.361998
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names(include_private=False)

    # Test that we have the right number of reserved names (does web_port count?)
    assert len(reserved) == 42, "Reserved names count is incorrect "
    assert 'delegate_to' in reserved, "delegate_to is missing from reserved list"
    assert 'tags' in reserved, "tags is missing from reserved list"
    assert 'run_once' in reserved, "run_once is missing from reserved list"

    reserved = get_reserved_names(include_private=True)

    # Test that we have the right number of reserved names (does web_port count?)
    assert len(reserved) == 45, "Reserved names count is incorrect "
    assert 'delegate_to' in reserved, "delegate_to is missing from reserved list"

# Generated at 2022-06-11 19:16:39.065706
# Unit test for function get_reserved_names
def test_get_reserved_names():
    _RESERVED_NAMES = tuple(get_reserved_names())

    assert not is_reserved_name('myvar')
    assert is_reserved_name('roles')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('environment')
    assert is_reserved_name('connection')
    assert is_reserved_name('any_errors_fatal')

# Generated at 2022-06-11 19:16:50.038831
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test cases for function get_reserved_names '''

    assert 'register' in get_reserved_names(include_private=True)
    assert 'register' in get_reserved_names(include_private=False)
    assert 'become' in get_reserved_names(include_private=False)
    assert not 'become' in get_reserved_names(include_private=True)
    assert 'become_user' in get_reserved_names(include_private=True)
    assert not 'become_user' in get_reserved_names(include_private=False)
    assert 'when' in get_reserved_names(include_private=False)
    assert 'when' in get_reserved_names(include_private=True)
    assert not 'post_tasks' in get_res

# Generated at 2022-06-11 19:16:51.236949
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()



# Generated at 2022-06-11 19:17:02.387958
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    all_ = get_reserved_names()

    assert(all_ > public)

    assert('roles' in public)
    assert('roles' in all_)

    assert('gather_facts' in public)
    assert('gather_facts' in all_)

    assert('connection' in public)
    assert('connection' in all_)

    assert('tags' in public)
    assert('tags' in all_)

    assert('run_once' in public)
    assert('run_once' in all_)

    assert('name' in all_)
    assert('when' in all_)

    # local_action is implicit with action
    assert('action' in public)
    assert('action' in all_)

# Generated at 2022-06-11 19:17:07.156896
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    # General test to see if list is empty
    assert reserved_names

    # Test to see if specific reserved names are included
    assert 'vars' in reserved_names
    assert 'roles' in reserved_names
    assert 'become' in reserved_names
    assert 'delegate_to' in reserved_names

# Generated at 2022-06-11 19:17:15.360695
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = [
        'become', 'become_method', 'become_user', 'block', 'block:', 'connection', 'delegate_to', 'environment', 'fail_key',
        'gather_facts', 'handlers', 'name', 'no_log', 'notify', 'notify:', 'register', 'roles', 'roles:', 'run_once',
        'serial', 'tags', 'tasks', 'tasks:', 'vars', 'vars:', 'when'
    ]


# Generated at 2022-06-11 19:17:18.849457
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names returns a list of reserved names '''
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names



# Generated at 2022-06-11 19:17:25.325926
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Make sure function returns sets of names
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(False), set)

    # Make sure the number of reserved names increases when specifically asking for private names
    assert len(get_reserved_names()) < len(get_reserved_names(True))

    # Make sure there is no overlap between public and private names
    assert not set(get_reserved_names()) & set(get_reserved_names(True))



# Generated at 2022-06-11 19:17:31.815083
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test inclusion of private attributes
    private_reserved = get_reserved_names()
    public_reserved = get_reserved_names(include_private=False)

    # private names are a subset of all names
    assert private_reserved.difference(public_reserved)

    # test that the private names start with _
    for name in private_reserved.difference(public_reserved):
        assert name[0] == '_'



# Generated at 2022-06-11 19:17:38.607085
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the function get_reserved_names()
    '''
    assert isinstance(get_reserved_names(), set)
    assert len(get_reserved_names()) > 100
    assert 'tasks' in get_reserved_names()
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert len(_RESERVED_NAMES) > 100
    assert 'tasks' in _RESERVED_NAMES



# Generated at 2022-06-11 19:18:12.494169
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'tasks' in _RESERVED_NAMES
    assert 'environment' in _RESERVED_NAMES
    assert 'pre_tasks' in _RESERVED_NAMES

# Generated at 2022-06-11 19:18:14.532748
# Unit test for function get_reserved_names
def test_get_reserved_names():
   reserved = get_reserved_names()
   assert 'hosts' in reserved
   assert 'vars' in reserved
   assert 'become' in reserved
   assert 'become_method' in reserved

# Generated at 2022-06-11 19:18:25.208092
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    # Since reserved_names is a set, we cannot do an exact match here
    assert 'play' in reserved_names
    assert 'role' in reserved_names
    assert 'block' in reserved_names
    assert 'task' in reserved_names
    assert 'any_errors_fatal' in reserved_names
    assert 'connection' in reserved_names
    assert 'delegate_to' in reserved_names
    assert 'hosts' in reserved_names
    assert 'name' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'no_log' in reserved_names
    assert 'serial' in reserved_names
    assert 'su' in reserved_names
    assert 'sudo' in reserved_names
    assert 'sudo_user' in reserved_names

# Generated at 2022-06-11 19:18:35.014631
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ## Test result for public attribute names
    result_public = get_reserved_names(include_private=False)

    ## Test result for all attribute names
    result_all = get_reserved_names(include_private=True)

    # Test result for public attribute names
    assert 'action' in result_public
    assert 'flow_style' in result_public
    assert 'name' in result_public
    assert 'register' in result_public
    assert 'delegate_to' in result_public
    assert 'when' in result_public
    assert 'connection' in result_public
    assert 'local_action' in result_public
    assert 'with_' in result_public
    assert 'loop' not in result_public

    # Test result for all attribute names
    assert 'action' in result_all

# Generated at 2022-06-11 19:18:42.686491
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for reserved names '''

    public = set()
    private = set()
    result = set()
    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    private.discard('include_role')  # This is not a reserved attribute
    private.discard('include_tasks')  # This is not a reserved attribute
    public.discard('include_role')  # This is not a reserved

# Generated at 2022-06-11 19:18:50.390812
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names(include_private=False)
    assert 'name' in reserved
    assert 'tags' in reserved
    assert 'when' in reserved

    assert 'vars' not in reserved
    assert 'private' not in reserved
    assert 'any_errors_fatal' not in reserved

    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'tags' in reserved
    assert 'when' in reserved

    assert 'vars' not in reserved
    assert 'private' in reserved
    assert 'any_errors_fatal' in reserved

# Generated at 2022-06-11 19:18:57.592562
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # any reserved name ending in '_ignore_errors' should also be in the list
    # of reserved names without the suffix.
    #
    # This test ensures that we don't accidentally add new reserved names
    # that follow this naming convention.
    ignore_errors = frozenset(n for n in get_reserved_names() if n.endswith('_ignore_errors'))
    for name in ignore_errors:
        assert name[:-len('_ignore_errors')] in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:19:05.323002
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:19:14.622218
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # There should be a list of names
    assert type(get_reserved_names()) == frozenset

    # Check some known reserved names
    assert 'remote_user' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'hosts' in get_reserved_names()

    # Some names are private so should not be in list
    assert 'delegate_to' not in get_reserved_names()

    # Some names are private so should be in list
    assert 'delegate_to' in get_reserved_names(include_private=True)


# Generated at 2022-06-11 19:19:17.556675
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check that there is no overlap with deprecated loop var
    assert not (_RESERVED_NAMES.intersection(set(['loop'])))

# Generated at 2022-06-11 19:19:59.255502
# Unit test for function get_reserved_names
def test_get_reserved_names():
    old_stdout = display.verbosity
    display.verbosity = 3

    print('reserved names w/o private: %s' % get_reserved_names(False))
    print('reserved names w/ private: %s' % get_reserved_names(True))
    assert set(get_reserved_names(False)) == set([u'any_errors_fatal', u'block', u'connection', u'container', u'environment', u'ignore_errors', u'local_action', u'loop', u'name', u'post_tasks', u'pre_tasks', u'rescue', u'rescue_enabled', u'tags', u'tasks', u'terminate_on_error', u'when'])

# Generated at 2022-06-11 19:20:05.867574
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' This function returns the list of reserved names associated with play objects'''


# Generated at 2022-06-11 19:20:10.512776
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=False)
    assert 'tags' in reserved
    assert 'when' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    reserved = get_reserved_names(include_private=True)
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved


# Generated at 2022-06-11 19:20:16.671450
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' This unit test verifies items returned by get_reserved_names '''

    reserved_list = get_reserved_names(True)
    display.display('Found %d reserved names' % len(reserved_list))

    # Verify basic names
    assert 'hosts' in reserved_list
    assert 'name' in reserved_list
    assert 'roles' in reserved_list

    # Check implicit names
    assert 'local_action' in reserved_list
    assert 'with_' in reserved_list


# Generated at 2022-06-11 19:20:20.350108
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved_names = get_reserved_names(include_private=True)

    assert('action' in reserved_names)
    assert('local_action' in reserved_names)
    assert('with_' in reserved_names)
    assert('loop' in reserved_names)

# Generated at 2022-06-11 19:20:29.322671
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()
    public.add('action')
    public.add('become')
    public.add('become_method')
    public.add('connection')
    public.add('delegate_to')
    public.add('environment')
    public.add('ignore_errors')
    public.add('name')
    public.add('register')
    public.add('retries')
    public.add('run_once')
    public.add('sudo')
    public.add('sudo_user')
    public.add('tags')
    public.add('transport')
    public.add('until')
    public.add('vars')
    public.add('local_action')
    public.add('with_')
    public.add('ignore_unreachable')
    public.add

# Generated at 2022-06-11 19:20:33.726808
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test function reserved_names'''

    # This test will fail if new attributes are added to the play
    test_classes = [Play, Role, Task, Block]
    for aclass in test_classes:
        for attr in aclass().__dict__['_attributes']:
            assert attr in _RESERVED_NAMES

# Generated at 2022-06-11 19:20:43.745919
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:20:53.438730
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Test to make sure internal reserved names function is working correctly
    '''


# Generated at 2022-06-11 19:20:57.586040
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(False) == get_reserved_names()
    assert isinstance(get_reserved_names(), frozenset)
    assert isinstance(get_reserved_names(), set)  # Backwards compatibility with 2.4.1.0

# Generated at 2022-06-11 19:22:07.794092
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test reserved name '''

    reserved = ('gather_facts', 'action', 'name', 'hosts',
                'vars', 'local_action', 'with_items',
                'async', 'poll', 'ignore_errors', 'when',
                'changed_when', 'failed_when', 'include',
                'include_role', 'tags', 'register', 'notify',
                'handlers', 'block', 'rescue', 'always', 'delegate_to')

    for reserved_name in reserved:
        assert reserved_name in _RESERVED_NAMES

# Generated at 2022-06-11 19:22:19.692019
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function exercises the get_reserved_names function '''

    # we expect a set of strings, but may come back as sorted or not, so convert to a set
    reserved = set(get_reserved_names())

    with_ansible_connection = "with_ansible_connection"
    if with_ansible_connection in reserved:
        reserved.remove(with_ansible_connection)

    with_items = "with_items"
    if with_items in reserved:
        reserved.remove(with_items)

    with_sequence = "with_sequence"
    if with_sequence in reserved:
        reserved.remove(with_sequence)


# Generated at 2022-06-11 19:22:31.492967
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset((u'name', u'hosts', u'gather_facts', u'delegate_to', u'vars_files', u'vars', u'roles', u'blocks', u'block', u'tasks', u'task', u'action', u'tags', u'local_action', u'with_', u'include_role', u'pre_tasks', u'post_tasks'))

# Generated at 2022-06-11 19:22:40.536846
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test with private attributes
    reserved_names = get_reserved_names(include_private=True)
    assert isinstance(reserved_names, set)
    assert 'roles' in reserved_names
    assert 'private' in reserved_names
    assert len(reserved_names) >= 14

    # test without private attributes
    reserved_names = get_reserved_names(include_private=False)
    assert isinstance(reserved_names, set)
    assert 'roles' in reserved_names
    assert 'private' not in reserved_names
    assert len(reserved_names) >= 13

# Generated at 2022-06-11 19:22:48.341435
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:58.405938
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:23:05.460837
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This testcase is not exhaustive, just checks for some expected
    # keys in the returned dict
    assert 'hosts' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'port' in get_reserved_names()
    assert 'no_log' in get_reserved_names()
    assert 'role_path' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'loop' in get_reserved_names(include_private=False)
    assert 'loop' in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:23:14.956671
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:23:24.937286
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get_reserved_names returns a set, so we convert it to a list
    list_reserved_names = list(get_reserved_names())
    list_reserved_names.sort()


# Generated at 2022-06-11 19:23:28.542877
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(True) == _RESERVED_NAMES
    assert get_reserved_names(False) != _RESERVED_NAMES