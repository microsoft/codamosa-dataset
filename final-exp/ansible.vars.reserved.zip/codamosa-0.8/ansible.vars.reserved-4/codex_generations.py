

# Generated at 2022-06-11 19:13:54.370650
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert sorted(get_reserved_names(include_private=False)) == sorted([
        "action", "any_errors_fatal", "become", "become_method", "become_user", "connection",
        "delegate_to", "environment", "ignore_errors", "local_action", "name", "no_log",
        "notify", "poll", "register", "remote_user", "retries", "run_once", "sudo",
        "sudo_user", "tags", "transport", "with_", "when"])

# Generated at 2022-06-11 19:14:03.254941
# Unit test for function get_reserved_names
def test_get_reserved_names():

    expected_reserved_names = frozenset(['action', 'async', 'become', 'become_user', 'connection', 'environment', 'delegate_to',
                                         'ignore_errors', 'local_action', 'poll', 'register', 'retries', 'serial', 'sudo', 'sudo_user',
                                         'tags', 'until', 'with_', 'when', 'always_run', 'any_errors_fatal', 'block', 'block_errors',
                                         'delegate_facts', 'ignore_errors', 'max_fail_percentage', 'notify', 'post_tasks', 'pre_tasks', 'roles',
                                         'role_names', 'tags', 'tasks', 'when'])


# Generated at 2022-06-11 19:14:13.223851
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:22.558691
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:33.675833
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:39.041780
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # first time this is run, it will have 'vars' in the set. Subsequent runs should leave it out,
    # as we should detect the bug and have prevented it from re-adding itself
    assert get_reserved_names() == get_reserved_names(include_private=False)
    assert 'vars' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:14:46.516583
# Unit test for function get_reserved_names
def test_get_reserved_names():

    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

    assert len(public.intersection(private)) == len(public)
    assert 'roles' in public
    assert 'become_user' in public
    assert 'any_errors_fatal' in public
    assert 'connection' in public

    assert 'roles' in private
    assert 'become_user' in private
    assert 'any_errors_fatal' in private
    assert 'connection' in private
    assert 'private' in private
    assert 'private' not in public



# Generated at 2022-06-11 19:14:54.612647
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'ignore_errors' in get_reserved_names()



# Generated at 2022-06-11 19:15:03.763936
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names(include_private=False)

    assert 'include' in reserved
    assert 'roles' in reserved
    assert 'hosts' in reserved
    assert 'name' in reserved

    assert 'gather_facts' in reserved
    assert 'connection' in reserved

    assert 'vars' in reserved
    assert 'vars_files' in reserved
    assert 'vars_prompt' in reserved
    assert 'vault_password_files' in reserved
    assert 'vault_password' in reserved
    assert 'tags' in reserved
    assert 'skip_tags' in reserved

    assert 'action' in reserved
    assert 'local_actions' in reserved

    assert 'when' in reserved
    assert 'notify' in reserved
    assert 'handlers' in reserved

    assert 'run_once' in reserved
   

# Generated at 2022-06-11 19:15:13.036640
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test if the function get_reserved_names returns reserved names correctly '''

    reserved_names = get_reserved_names(include_private=False)

    assert Play.REQUIRED_FIELDS == set(['hosts', 'roles']), \
           "The Play.REQUIRED_FIELDS might have changed, please update the unit test accordingly"

    assert Play._play_hosts_variables == set(['playbook_hosts', 'play_hosts', 'hosts']), \
           "The Play._play_hosts_variables might have changed, please update the unit test accordingly"

    assert reserved_names.issuperset(set()), \
           'The function get_reserved_names does not include the correct names'


# Generated at 2022-06-11 19:15:28.449375
# Unit test for function get_reserved_names
def test_get_reserved_names():

    public = get_reserved_names(False)
    private = get_reserved_names(True)

    assert 'name' in public
    assert 'name' in private

    assert 'hosts' in public
    assert 'hosts' in private

    assert 'localhost' in public
    assert 'localhost' in private

    assert 'post_tasks' in public
    assert 'post_tasks' in private

    assert 'pre_tasks' in public
    assert 'pre_tasks' in private

    assert 'tags' in public
    assert 'tags' in private

    assert 'vars' in public
    assert 'vars' in private

    assert 'vars_files' in public
    assert 'vars_files' in private

    assert 'roles' not in public

    assert 'roles' in private


# Generated at 2022-06-11 19:15:34.244056
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'roles' in names
    assert 'post_tasks' in names
    assert 'roles' in names
    assert 'vars_files' in names
    assert 'hosts' in names
    assert 'pre_tasks' in names
    assert 'vars' in names

# Generated at 2022-06-11 19:15:39.843934
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test to check correct names are reserved'''
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' not in get_reserved_names(include_private=False)



# Generated at 2022-06-11 19:15:46.138795
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """
    This is an AnsibleModule unit test for get_reserved_names()
    """
    # test that only public names are returned when private is not set
    names = frozenset(get_reserved_names(include_private=False))
    assert names == _RESERVED_NAMES

    # test that private names are returned now
    names = frozenset(get_reserved_names(include_private=True))
    assert names == _RESERVED_NAMES

# Generated at 2022-06-11 19:15:57.847756
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    # this list is built from the definitions in the Play and Task classes,
    # so it is possible it will grow over time

# Generated at 2022-06-11 19:16:06.449002
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(False)
    # we don't want to depend on a specific attribute order for this test to pass
    assert len(result) == 50
    assert 'any_errors_fatal' in result
    assert 'private' not in result
    assert 'serial' in result

    result = get_reserved_names(True)
    assert len(result) == 57
    assert 'any_errors_fatal' in result
    assert 'private' in result
    assert 'serial' in result

# Generated at 2022-06-11 19:16:11.885060
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert frozenset(['accelerate', 'connection', 'delegate_to', 'hosts', 'ignore_errors',
                      'name', 'remote_user', 'serial', 'sudo', 'sudo_user', 'tags',
                      'transport', 'vars_prompt']) == get_reserved_names(include_private=False)
    assert frozenset(['action', 'args', 'become', 'become_method', 'become_user', 'block',
                      'ignore_errors', 'local_action', 'loop', 'name', 'notify', 'tags',
                      'tasks', 'with_', 'vars_files', 'vars_prompt', 'when', 'with_']) == get_reserved_names()

# Generated at 2022-06-11 19:16:15.600963
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test case 1: private attributes = False
    assert 'foo' not in get_reserved_names(include_private=False)

    # test case 2: private attributes = False
    assert 'foo' in get_reserved_names(include_private=True)



# Generated at 2022-06-11 19:16:18.687329
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'include_tasks' in get_reserved_names()


# Generated at 2022-06-11 19:16:25.800616
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'block' in reserved_names
    assert 'tasks' in reserved_names
    assert 'hosts' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'when' in reserved_names
    assert 'async' in reserved_names
    assert 'async_poll_interval' in reserved_names
    assert 'async_status_timeout' in reserved_names

# Generated at 2022-06-11 19:16:49.317755
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Following would throw an error if test fails
    assert isinstance(get_reserved_names(), frozenset)
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == \
           _RESERVED_NAMES.difference(get_reserved_names(include_private=True))

# Generated at 2022-06-11 19:16:51.928629
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function unit tests get_reserved_names '''

    assert len(get_reserved_names(include_private=False)) == 240
    assert len(get_reserved_names(include_private=True)) == 260

# Generated at 2022-06-11 19:17:01.017140
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ret = get_reserved_names()
    assert isinstance(ret, set)

    public = set()
    private = set()

    for name in ret:
        if name.startswith('_'):
            private.add(name)
        else:
            public.add(name)

    assert 'private' in private
    assert 'private' not in public
    assert 'action' in public
    assert 'with_' in public
    assert 'loop' in public

    ret = get_reserved_names(include_private=False)
    assert isinstance(ret, set)
    assert 'private' not in ret



# Generated at 2022-06-11 19:17:10.504834
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private = set()
    public = set()
    result = set()
    class_list = [Play, Role, Block, Task]

    # test that names are not None
    # result = get_reserved_names(include_private=True)
    # assert result is not None

    # test that names are not empty
    # result = get_reserved_names(include_private=True)
    # assert result is not None

    # test that names are present in the public and private namespace
    # result = get_reserved_names(include_private=True)
    # assert result is not None

    # test that reserved names are not identified when the include_private param is set to false
    result = get_reserved_names(include_private=False)
    assert result is not None

    # test that private names are not identified when the include

# Generated at 2022-06-11 19:17:20.438701
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(False)
    assert isinstance(reserved_names, set)
    assert len(reserved_names) > 1
    assert 'name' in reserved_names
    assert 'action' in reserved_names
    assert 'become' not in reserved_names
    assert 'register' not in reserved_names
    assert 'become_user' in reserved_names

    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)
    assert len(reserved_names) > 1
    assert 'become' in reserved_names
    assert 'register' in reserved_names
    assert 'name' in reserved_names



# Generated at 2022-06-11 19:17:22.751632
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert get_reserved_names(include_private=False)
    assert get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:17:29.928820
# Unit test for function get_reserved_names
def test_get_reserved_names():
    myset = frozenset( ['name', 'roles', 'gather_facts', 'connection', 'delegate_to',
                       'become', 'become_user', 'become_method', 'sudo', 'sudo_user',
                       'remote_user', 'check'])
    # Because the reserved names change as we add to the class attributes in the modules
    # we cannot do a direct compare to a static set, but we can make sure it is a subset
    assert myset.issubset(_RESERVED_NAMES)

# Generated at 2022-06-11 19:17:40.716655
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # check to see if we get the same list of reserved names without including private names
    public = set()
    private = set()

    class_list = [Play, Role, Block, Task]

    result = get_reserved_names(include_private=False)
    result2 = get_reserved_names(include_private=True)

    assert(len(result2.difference(result)) > 0)

    public = set()
    private = set()

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action

# Generated at 2022-06-11 19:17:42.470916
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'role_path' in get_reserved_names(), 'get_reserved_names must include role_path'

# Generated at 2022-06-11 19:17:52.876641
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:18:34.826656
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:18:38.652610
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert 'hosts' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'gather_facts' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES

# Generated at 2022-06-11 19:18:49.352126
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == {'action', 'vars_files', 'tags', 'handlers', 'vars', 'name', 'include_tasks', 'roles', 'gather_facts', 'pre_tasks', 'post_tasks', 'vars_prompt', 'become_user', 'become', 'delegate_to', 'delegate_facts', 'include', 'hosts', 'when', 'transport', 'connection', 'serial', 'remote_user', 'any_errors_fatal', 'retries', 'local_action'}

# Generated at 2022-06-11 19:18:59.972625
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # we are making _RESERVED_NAMES a list so we can easily test it
    assert isinstance(get_reserved_names(), frozenset)


# Generated at 2022-06-11 19:19:01.094818
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-11 19:19:12.511167
# Unit test for function get_reserved_names
def test_get_reserved_names():

    result = get_reserved_names(include_private=False)
    assert 'hosts' in result
    assert 'roles' in result
    assert 'block' in result
    assert 'action' in result
    assert 'local_action' in result
    assert 'tasks' in result
    assert 'register' in result
    assert 'name' in result
    assert 'tags' in result

    # private attributes not returned by default
    assert 'connection' not in result
    assert 'delegate_to' not in result
    assert 'gather_facts' not in result
    assert 'serial' not in result

    # this is the case with internal loop
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in result

    # private attributes returned with include_private=True
    result = get_reserved

# Generated at 2022-06-11 19:19:20.757205
# Unit test for function get_reserved_names
def test_get_reserved_names():
    def assertEquals(a, b):
        if a == b:
            return
        raise Exception('Assertion failed: %s != %s' % (a, b))
    # This test doesn't test all the attributes as that would be too much work
    # to update. Instead it just verifies that a subset of them are present
    assertEquals(is_reserved_name('action'), True)
    assertEquals(is_reserved_name('run_once'), True)
    assertEquals(is_reserved_name('vars'), False)

# Generated at 2022-06-11 19:19:27.264551
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES == frozenset([
        'block', 'any_errors_fatal', 'async_poll_interval_seconds', 'async_timeout',
        'become', 'become_method', 'become_user', 'connection', 'fact_caching', 'gather_facts',
        'hosts', 'ignore_errors', 'include', 'meta', 'no_log', 'notify', 'post_tasks',
        'pre_tasks', 'remote_user', 'roles', 'serial', 'stats', 'strategy', 'sudo', 'sudo_user',
        'tags', 'tasks', 'transport', 'any_errors_fatal', 'loop', 'with_', 'local_action', 'action'])

# Generated at 2022-06-11 19:19:37.585985
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this test ensures that the reserved names list is always up to date '''

    import os
    import ast
    import json

    this_file = os.path.dirname(os.path.realpath(__file__))
    data_file = os.path.join(this_file, 'reserved_names.json')

    # if we're generating a new file, write it out
    if "ANSIBLE_GENERATE_HASH_DATA" in os.environ:
        data = sorted(list(get_reserved_names()))
        with open(data_file, 'w') as f:
            json.dump(data, f, indent=4)

    # otherwise, read the file in, and ensure nothing has changed
    with open(data_file, 'r') as f:
        data = ast.literal_eval

# Generated at 2022-06-11 19:19:41.361547
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'name' in get_reserved_names(include_private=False)
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:20:59.546918
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # This will eventually be deprecated, so we don't test it in the deprecation warning case
    assert 'with_' not in get_reserved_names(include_private=False)

    # This is the default, so we don't test it in the default case
    assert 'loop' not in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:21:07.514808
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:21:15.427602
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_reserved_names = get_reserved_names(include_private=False)
    private_reserved_names = get_reserved_names(include_private=True)

    assert isinstance(public_reserved_names, set)
    assert isinstance(private_reserved_names, set)

    assert private_reserved_names.issuperset(public_reserved_names)

    assert 'name' in public_reserved_names
    assert 'name' in private_reserved_names

    assert 'private' in private_reserved_names
    assert 'private' not in public_reserved_names


# Generated at 2022-06-11 19:21:25.451400
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(False), set)
    assert get_reserved_names(True).issuperset(get_reserved_names(False))
    assert get_reserved_names(True).isdisjoint(['foo'])
    assert get_reserved_names(False).isdisjoint(['foo'])
    assert 'hosts' in get_reserved_names(False)
    assert 'hosts' in get_reserved_names(True)
    assert 'tasks' in get_reserved_names(False)
    assert 'tasks' in get_reserved_names(True)

# Generated at 2022-06-11 19:21:30.214364
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'roles' in reserved
    assert 'handlers' in reserved
    assert 'include' in reserved
    assert 'pre_tasks' in reserved
    assert 'post_tasks' in reserved
    assert 'tasks' in reserved

# Generated at 2022-06-11 19:21:37.885994
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=True)
    assert 'role_name' in reserved, 'Expected role_name to be in reserved names'
    assert 'action' in reserved, 'Expected action to be in reserved names'
    assert 'local_action' in reserved, 'Expected local_action to be in reserved names'
    assert 'with_' in reserved, 'Expected with_ to be in reserved names'
    assert 'loop' in reserved, 'Expected loop to be in reserved names'
    assert 'become' in reserved, 'Expected become to be in reserved names'
    assert 'become_user' in reserved, 'Expected become_user to be in reserved names'
    assert 'vars' in reserved, 'Expected vars to be in reserved names'

# Generated at 2022-06-11 19:21:40.435579
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()

    assert(len(result) > 2)
    assert('hosts' in result)
    assert('role_name' in result)

# Generated at 2022-06-11 19:21:41.882549
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print(get_reserved_names())
    print(get_reserved_names(include_private=False))



# Generated at 2022-06-11 19:21:47.152504
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'register' in get_reserved_names()

    assert 'roles' in get_reserved_names(False)
    assert 'register' in get_reserved_names(False)

    assert 'roles' not in get_reserved_names(True)
    assert 'register' not in get_reserved_names(True)



# Generated at 2022-06-11 19:21:57.710156
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test for get_reserved_names function
    - check that it generally works
    - check that the set matches the ones in the code
    '''

    # get public reserved names
    res_names = get_reserved_names(include_private=False)

    # check valid results