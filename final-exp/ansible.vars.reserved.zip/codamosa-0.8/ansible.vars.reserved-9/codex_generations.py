

# Generated at 2022-06-11 19:14:01.669649
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=True)
    assert isinstance(reserved, set)
    assert reserved >= _RESERVED_NAMES
    assert 'roles' in reserved
    assert 'delegate_to' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'loop' in reserved
    assert 'with_' in reserved
    assert 'block' not in reserved
    assert 'name' not in reserved

    reserved = get_reserved_names(include_private=False)
    assert isinstance(reserved, set)
    assert reserved >= _RESERVED_NAMES
    assert 'roles' in reserved
    assert 'delegate_to' in reserved
    assert 'action' in reserved
    # implicit attrs aren't included
    assert 'local_action'

# Generated at 2022-06-11 19:14:12.415040
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''test to make sure get_reserved_names works as expected'''

    # FIXME: should wrap the whole function with a try/catch and return None,
    #        but there might be side affects from adding an imported class
    #        that can't be imported/found.
    try:
        from ansible.playbook.role_include import IncludedRole
        IncludedRole
    except ImportError:
        return None

    # first, test the implicit 'action' and 'local_action'
    reserved_names = ["action", "local_action", "loop", "with_"]
    # then test the default reserved names

# Generated at 2022-06-11 19:14:17.342451
# Unit test for function get_reserved_names
def test_get_reserved_names():

    result_private = get_reserved_names(include_private=True)
    result_public = get_reserved_names(include_private=False)

    assert(result_private.issuperset(result_public))
    assert(len(result_private) > len(result_public))

# Generated at 2022-06-11 19:14:21.050550
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(True) is not None
    assert get_reserved_names(False) is not None
    assert len(get_reserved_names(True)) >= len(get_reserved_names(False))
    assert 'action' in get_reserved_names(True)

# Generated at 2022-06-11 19:14:24.337482
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert is_reserved_name('private')
    assert not is_reserved_name('something_not_reserved')

# Generated at 2022-06-11 19:14:28.854063
# Unit test for function get_reserved_names
def test_get_reserved_names():
    function_names = get_reserved_names()
    print("Number of function names: %d" % len(function_names))
    print("Function names: %s" % function_names)

if __name__ == '__main__':
    test_get_reserved_names()

# Generated at 2022-06-11 19:14:32.198627
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    #assert len(reserved_names) == 15
    reserved_names = get_reserved_names(include_private=False)
    #assert len(reserved_names) == 14

# Generated at 2022-06-11 19:14:38.550116
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test with private
    result = get_reserved_names(True)
    assert result == frozenset(['connection', 'delegate_to', 'environment', 'gather_facts', 'name', 'no_log', 'notify', 'pause_before', 'poll', 'register', 'remote_user', 'retries', 'run_once', 'sudo', 'sudo_user', 'when', 'with_items', 'with_nested', 'with_subelements', 'with_together', 'with_dict', 'with_fileglob', 'with_first_found', 'with_sequence', 'with_lines', 'with_together', 'wait_for_connection', 'local_action'])

    # test without private
    result = get_reserved_names(False)

# Generated at 2022-06-11 19:14:43.004293
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert len(_RESERVED_NAMES) == 318
    assert 'serial' in _RESERVED_NAMES
    assert 'become' in _RESERVED_NAMES

# Generated at 2022-06-11 19:14:47.775518
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests get_reserved_names function '''
    public = frozenset(['hosts', 'delegate_to', 'gather_facts', 'tasks'])
    private = frozenset(['name', 'action', 'local_action', 'loop'])
    assert get_reserved_names(include_private=False) == public
    assert get_reserved_names(include_private=True) == public.union(private)

# Generated at 2022-06-11 19:15:12.091798
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: not sure how to properly test this, as there are implicit values
    # as well as per-module/per-plugin etc.
    assert len(get_reserved_names()) > 0



# Generated at 2022-06-11 19:15:17.733635
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'vars' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'loop' in get_reserved_names()
    assert 'with' not in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'become' in get_reserved_names()



# Generated at 2022-06-11 19:15:26.914578
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:32.894331
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'post_tasks' in get_reserved_names()
    assert 'notify' in get_reserved_names(include_private=False)
    assert 'become' in get_reserved_names()
    assert 'vars' not in get_reserved_names(include_private=False)



# Generated at 2022-06-11 19:15:42.022512
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:50.174046
# Unit test for function get_reserved_names
def test_get_reserved_names():
    #Pylint would fail this test as the isinstance check is more generic than it would like.
    #pylint: disable=no-member,unidiomatic-typecheck

    class foo(Task):
        pass

    class bar(Role):
        pass

    item = Play()
    item2 = foo()

    assert(isinstance(item, Play))
    assert(isinstance(item2, Task))


# Generated at 2022-06-11 19:16:00.540193
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private_names = sorted(get_reserved_names(include_private=True))
    public_names = sorted(get_reserved_names(include_private=False))
    assert private_names != public_names

# Generated at 2022-06-11 19:16:11.461096
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:16:17.572627
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()

    assert 'name' in result
    assert 'hosts' in result
    assert 'connection' in result
    assert 'port' in result
    assert 'remote_user' in result
    assert 'no_log' in result
    assert 'sudo' in result
    assert 'sudo_user' in result
    assert 'become' in result
    assert 'become_method' in result
    assert 'become_user' in result



# Generated at 2022-06-11 19:16:23.964391
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:13.314835
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' not in get_reserved_names()
    assert 'local_action' in get_reserved_names(include_private=True)
    assert 'local_action' not in get_reserved_names(include_private=False)
    assert 'loop' in get_reserved_names(include_private=True)
    assert 'loop' not in get_reserved_names(include_private=False)
    assert 'with_' in get

# Generated at 2022-06-11 19:17:20.242248
# Unit test for function get_reserved_names
def test_get_reserved_names():
    allnames = get_reserved_names(include_private=True)
    pubnames = get_reserved_names(include_private=False)
    assert type(allnames) == set
    assert type(pubnames) == set
    assert 'hosts' in allnames
    assert 'hosts' in pubnames
    assert 'remote_user' in allnames
    assert 'remote_user' in pubnames
    assert 'sudo_user' in allnames
    assert 'sudo_user' not in pubnames

# Generated at 2022-06-11 19:17:25.126088
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(False) != _RESERVED_NAMES
    assert 'roles' in get_reserved_names(False)
    assert not 'roles' in get_reserved_names()
    assert not 'name' in get_reserved_names()

# Generated at 2022-06-11 19:17:26.247288
# Unit test for function get_reserved_names
def test_get_reserved_names():
    x = get_reserved_names()
    assert x
    assert isinstance(x, set)

# Generated at 2022-06-11 19:17:34.943358
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # unit test for function get_reserved_names
    ret_names = get_reserved_names()
    assert 'name' in ret_names, 'Expected name in reserved names'
    assert 'roles' in ret_names, 'Expected roles in reserved names'
    ret_names = get_reserved_names(include_private=False)
    assert 'action' in ret_names, 'Expected action in reserved names'
    assert 'block' in ret_names, 'Expected block in reserved names'
    assert 'hosts' in ret_names, 'Expected hosts in reserved names'
    assert 'gather_facts' in ret_names, 'Expected gather_facts in reserved names'
    assert 'vars' in ret_names, 'Expected vars in reserved names'

# Generated at 2022-06-11 19:17:43.257665
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'loop' not in get_reserved_names()
    assert 'with_' not in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'block' in get_reserved_names(include_private=False)


# Generated at 2022-06-11 19:17:47.655328
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test all reserved names
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)

    # Test non reserved names
    assert not is_reserved_name('example')
    assert not is_reserved_name('example_iterator')
    assert not is_reserved_name('with_*)')

# Generated at 2022-06-11 19:17:52.759776
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in get_reserved_names()
    # local_action is implicit with action
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()



# Generated at 2022-06-11 19:18:00.400271
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'name' in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names(include_private=False)
    assert 'vars_prompt' not in get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:18:07.584239
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'hosts' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'environment' in get_reserved_names(include_private=True)
    assert 'environment' not in get_reserved_names(include_private=False)



# Generated at 2022-06-11 19:19:33.435596
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = frozenset(['gather_facts', 'become', 'any_errors_fatal', 'sudo', 'sudo_user', 'remote_user', 'register', 'tags', 'delegate_to', 'notify', 'roles', 'pre_tasks', 'post_tasks', 'vars', 'when', 'connection', 'transport', 'check_mode', 'no_log', 'first_available_file', 'ignore_errors', 'when', 'local_action', 'with_'])

# Generated at 2022-06-11 19:19:39.921617
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(['hosts', 'name', 'gather_facts', 'roles', 'remote_user', 'become', 'become_user',
                  'serial', 'check_mode', 'no_log', 'any_errors_fatal', 'handlers', 'vars', 'vars_files', 'tags',
                  'notify', 'pre_tasks', 'post_tasks', 'tasks', 'registered', 'failed_when', 'ignore_errors', 'always_run',
                  'local_action', 'connection', 'gather_subset', 'timeout', 'when', 'with_'])
    private = ['environment', 'loop', 'action', 'until']
    reserved = get_reserved_names(include_private=True)
    assert reserved == public.union(private)

# Generated at 2022-06-11 19:19:47.004150
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected = ['action', 'block', 'block_strategy', 'block_errors', 'changed_when', 'check_mode', 'connection', 'debug', 'delegate_to', 'delegate_facts', 'environment', 'failed_when', 'gather_facts', 'gather_subset', 'handlers', 'hosts', 'ignore_errors', 'include_tasks', 'local_action', 'loop', 'loop_control', 'name', 'notify', 'no_log', 'post_tasks', 'pre_tasks', 'register', 'role_name', 'roles', 'serial', 'tasks', 'tags', 'task_tags', 'when']
    assert sorted(get_reserved_names(include_private=True)) == sorted(expected)



# Generated at 2022-06-11 19:19:56.178285
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''this function provides unit tests for the get_reserved_names function'''
    import os
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # test for public attributes
    public_attributes = set()
    for attribute in get_reserved_names(include_private=False):
        public_attributes.add(attribute)
    if not public_attributes:
        module.fail_json(msg='unable to find any public attributes')

    # test for private attributes
    private_attributes = set()
    for attribute in get_reserved_names(include_private=True):
        privat

# Generated at 2022-06-11 19:20:00.588386
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Simple test case used also in docstring of get_reserved_names
    assert get_reserved_names() == frozenset(['action', 'gather_facts', 'post_tasks',
                                              'pre_tasks', 'roles', 'tasks', 'vars_files',
                                              'vars_prompt', 'vars'])



# Generated at 2022-06-11 19:20:08.170770
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:20:14.792295
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test base case
    privates = set()
    public = set()
    res = get_reserved_names()
    assert res == _RESERVED_NAMES

    # test no_private case
    res = get_reserved_names(include_private=False)
    for each in _RESERVED_NAMES:
        if not each.startswith('_'):
            public.add(each)
        else:
            privates.add(each)

    assert res == public

# Generated at 2022-06-11 19:20:19.676008
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import pytest

    assert get_reserved_names() == _RESERVED_NAMES

    assert get_reserved_names(include_private=False) == _RESERVED_NAMES.difference(
        {'private', 'any_errors_fatal', 'serial', 'sudo_user', 'connection', 'remote_user', 'environment', 'no_log',
         'async', 'poll', 'until', 'retries', 'first_available_file', 'vars_prompt', 'ignore_errors'})


# Generated at 2022-06-11 19:20:28.841763
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This function does not return private names
    names = get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:20:36.791537
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert len(reserved_names) > 0
    assert 'any_errors_fatal' in reserved_names
    assert 'connection' in reserved_names
    assert is_reserved_name('connection')
    assert 'tags' in reserved_names
    assert is_reserved_name('tags')
    assert 'vars' not in reserved_names
    assert not is_reserved_name('vars')
    assert 'local_action' in reserved_names
    assert 'action' not in reserved_names
    assert 'local_port' not in reserved_names
    assert 'ports' in reserved_names

# Generated at 2022-06-11 19:23:27.681836
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''test get_reserved_names for a known subset of names defined in objects'''

    # A dictionary containing known names and if they are a public, private or implicit name

# Generated at 2022-06-11 19:23:30.656017
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test that private names are not included
    assert 'notify' in get_reserved_names(False)
    assert 'notify' not in get_reserved_names(True)
