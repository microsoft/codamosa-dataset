

# Generated at 2022-06-11 19:13:50.312515
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES == frozenset(['name', 'hosts', 'action', 'local_action', 'any_errors_fatal', 'max_fail_percentage', 'deprecate_tags',
                                         'include_tasks', 'gather_facts', 'include_vars', 'serial', 'connection', 'vars', 'vars_files', 'roles',
                                         'vars_prompt', 'tags', 'always_run', 'block', 'handler', 'async', 'poll', 'ignore_errors', 'register',
                                         'delegate_to', 'with_', 'sudo_user', 'sudo', 'su_user', 'su', 'transport', 'notify', 'when', 'first_available_file',
                                         'local_action'])

# Generated at 2022-06-11 19:14:01.006372
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:12.005976
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:22.169719
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # TODO: we should add a test for Role and other objects here
    import operator
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    play_obj = Play()
    task_obj = Task()
    block_obj = Block()
    role_obj = Role()

    play_private_names = set(reduce(operator.add, [x for x in play_obj.__dict__ if 'private' in x]))
    play_public_names = set(reduce(operator.add, [x for x in play_obj.__dict__ if 'private' not in x]))


# Generated at 2022-06-11 19:14:26.886082
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=True) == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) != _RESERVED_NAMES


# Generated at 2022-06-11 19:14:29.830134
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    unit test for function get_reserved_names
    '''

    assert 'include' in get_reserved_names()



# Generated at 2022-06-11 19:14:37.939111
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not (set(['hosts', 'name', 'connection']) - get_reserved_names(False))
    assert not (set(['hosts', 'name', 'connection']) - get_reserved_names(True))
    assert not (set(['hosts', 'name', 'connection', 'sudo', 'sudo_user', 'remote_user', 'environment', 'no_log', 'vars_prompt', 'vars_files', 'vars_prompt', 'vars_files', 'notify', 'handlers', 'tags', 'no_log', 'with_', 'local_action']) - get_reserved_names(True))

# Generated at 2022-06-11 19:14:41.595232
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'tasks' in reserved_names
    assert 'connection' in reserved_names
    assert 'action' in reserved_names

# Generated at 2022-06-11 19:14:48.506019
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:14:59.362183
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:21.243738
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # just test with public names
    public_names = get_reserved_names(False)
    assert len(public_names) > 0
    assert 'action' in public_names
    assert 'roles' in public_names
    assert 'tasks' in public_names
    assert 'private' not in public_names
    assert 'when' in public_names

    # test with private names too
    public_names = get_reserved_names(True)
    assert len(public_names) > 0
    assert 'action' in public_names
    assert 'roles' in public_names
    assert 'tasks' in public_names
    assert 'private' in public_names
    assert 'when' in public_names



# Generated at 2022-06-11 19:15:26.942992
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from collections import Counter
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, frozenset)
    assert reserved_names & {'become', 'become_user', 'connection', 'delegate_to',
                             'environment', 'name', 'tags', 'vars'}, reserved_names
    assert (Counter(get_reserved_names()) == Counter(get_reserved_names(include_private=False))), \
        'Reserved names must be updated to not have public/private duplicates'



# Generated at 2022-06-11 19:15:38.378867
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'name' in reserved_names
    assert 'tasks' in reserved_names
    assert 'connection' in reserved_names
    assert 'login_user' in reserved_names
    assert 'sudo' in reserved_names
    assert 'sudo_user' in reserved_names

    public_reserved = get_reserved_names(include_private=False)
    assert 'hosts' in public_reserved
    assert 'name' in public_reserved
    assert 'tasks' in public_reserved
    assert 'connection' in public_reserved
    assert 'login_user' in public_reserved
    assert 'sudo' in public_reserved
    assert 'sudo_user' in public_reserved

    # the private flag is because

# Generated at 2022-06-11 19:15:47.331621
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'pre_tasks' in get_reserved_names(include_private=False)
    assert 'post_tasks' in get_reserved_names(include_private=False)
    assert 'pre_tags' in get_reserved_names(include_private=False)
    assert 'post_tags' in get_reserved_names(include_private=False)
    assert 'remote_user' in get_reserved_names(include_private=False)

    assert 'private_key_file' in get_reserved_names(include_private=True)
    assert 'private_key_file' not in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)


# Generated at 2022-06-11 19:15:56.079444
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This test verifies the reserved names list is correct for both cases
    '''
    reserved_names = set(get_reserved_names())
    assert 'with_' in reserved_names
    assert 'with__' not in reserved_names
    assert 'private' not in reserved_names

    reserved_names = set(get_reserved_names(include_private=False))
    assert 'with_' in reserved_names
    assert 'with__' not in reserved_names
    assert 'private' not in reserved_names

# Generated at 2022-06-11 19:16:02.557541
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'roles' in reserved
    assert 'private_roles' in reserved
    assert 'post_tasks' in reserved
    assert 'roles_path' in reserved
    assert 'block' in reserved
    assert 'handlers' in reserved
    assert 'hosts' in reserved
    assert 'gather_facts' in reserved
    assert 'vars_files' in reserved
    assert 'when' in reserved
    assert 'vars' in reserved
    assert 'delegate_to' in reserved
    assert 'delegate_facts' in reserved
    assert 'register' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'ignore_errors' in reserved
    assert 'tags' in reserved
    assert 'run_once' in reserved

# Generated at 2022-06-11 19:16:12.261713
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names() function'''

    reserved_names_public = frozenset(['become', 'connection', 'gather_facts', 'gather_subset', 'gather_timeout', 'hosts', 'name', 'roles', 'serial', 'sudo', 'sudo_user', 'when', 'no_log', 'notify', 'vars_files', 'vars_prompt', 'vars', 'tags', 'delegate_facts', 'register', 'remote_user', 'no_log'])


# Generated at 2022-06-11 19:16:15.945084
# Unit test for function get_reserved_names
def test_get_reserved_names():
    rnames = get_reserved_names()
    assert 'name' in rnames
    assert 'roles' in rnames
    assert 'hosts' in rnames
    assert 'vars' in rnames
    assert 'block' in rnames
    assert 'local_action' in rnames


# Generated at 2022-06-11 19:16:22.981134
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_list = get_reserved_names(False)
    private_list = get_reserved_names(True)

    assert 'roles' in public_list
    assert 'roles' in private_list

    assert 'include_tasks' in public_list
    assert 'include_tasks' not in private_list

    assert 'register' in public_list
    assert 'register' not in private_list

    assert 'local_action' in public_list
    assert 'local_action' in private_list

# Generated at 2022-06-11 19:16:33.104529
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    this function tests get_reserved_names()
    '''

    reserved_names = get_reserved_names()
    private_names = get_reserved_names(include_private=False)
    assert 'name' in reserved_names
    assert 'name' not in private_names
    assert 'vars' not in reserved_names
    assert 'vars' not in private_names
    assert 'private' not in reserved_names
    assert 'private' not in private_names
    assert 'delegate_to' in reserved_names
    assert 'delegate_to' not in private_names
    assert 'with_' not in reserved_names
    assert 'with_' in private_names
    assert 'when' in reserved_names
    assert 'when' not in private_names

# Generated at 2022-06-11 19:17:06.473808
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert frozenset(['gather_facts', 'name', 'hosts', 'roles', 'tasks', 'vars', 'tags', 'become', 'delegate_to', 'become_user']) == get_reserved_names(include_private=False)
    assert frozenset(['gather_facts', 'name', 'hosts', 'roles', 'tasks', 'vars', 'tags', 'become', 'delegate_to', 'become_user', 'local_action', 'with_', 'environment', 'connection']) == _RESERVED_NAMES



# Generated at 2022-06-11 19:17:16.797471
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()
    public_string = """
    role_name
    remote_user
    delegate_to
    ignore_errors
    environment
    no_log
    """


# Generated at 2022-06-11 19:17:23.213680
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private = get_reserved_names(False)
    public = get_reserved_names(True)

    assert 'action' in public
    assert 'local_action' in public
    assert 'loop' in public
    assert 'with_' in public

    assert 'action' in private
    assert 'local_action' not in private
    assert 'loop' in private
    assert 'with_' in private

    assert len(private) == len(public) + 3



# Generated at 2022-06-11 19:17:24.874121
# Unit test for function get_reserved_names
def test_get_reserved_names():
    module = get_reserved_names()
    assert 'name' in module



# Generated at 2022-06-11 19:17:29.447768
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)
    assert 'hosts' in reserved
    assert 'sudo' in reserved
    assert 'roles' in reserved
    assert 'environment' in reserved

    assert len(reserved) > 20  # this is simply to ensure that the list of reserved words is not empty

    reserved = get_reserved_names(include_private=False)
    assert isinstance(reserved, set)
    assert 'hosts' in reserved
    assert 'sudo' in reserved
    assert 'roles' in reserved
    assert 'environment' in reserved

    assert len(reserved) > 10  # this is simply to ensure that the list of reserved words is not empty



# Generated at 2022-06-11 19:17:35.175405
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'tasks' in reserved
    assert 'roles' in reserved
    assert 'vars' in reserved

    private = get_reserved_names(include_private=False)
    assert 'name' in private
    assert 'hosts' in private
    assert 'tasks' in private
    assert 'vars' in private
    assert 'roles' not in private


# Generated at 2022-06-11 19:17:45.672459
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:46.483284
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'meta' in get_reserved_names()

# Generated at 2022-06-11 19:17:56.361423
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the get_reserved_names function '''

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        for attribute in aobj.__dict__['_attributes']:
            if attribute not in _RESERVED_NAMES:
                raise AssertionError('%s not in reserved list' % attribute)

    # a few more tests for some special cases
    if 'local_action' not in _RESERVED_NAMES:
        raise AssertionError('local_action not in reserved list')

# Generated at 2022-06-11 19:17:58.347554
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: this is way too weak
    assert len(get_reserved_names()) != 0

# Generated at 2022-06-11 19:18:53.775549
# Unit test for function get_reserved_names
def test_get_reserved_names():
    meta_dict = {'name': {'required': False, 'private': True},
                 'other_name': {'required': True},
                 'some_other_name': {'required': False, 'private': True}}

    class dummyclass:
        _attributes = meta_dict

    task_meta_dict = {'name': {'required': False},
                 'other_name': {'required': True},
                 'some_other_name': {'required': False, 'private': True},
                 'action': {'required': False}}

    class dummytask(dummyclass):
        _attributes = task_meta_dict


# Generated at 2022-06-11 19:18:57.836636
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'provider' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'handler' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)



# Generated at 2022-06-11 19:19:08.483588
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == set(['vars', 'keyed_groups', 'groups', 'hosts', 'remote_user', 'sudo_user', 'sudo', 'connection', 'gather_facts', 'delegate_facts', 'any_errors_fatal', 'serial', 'force_handlers', 'name', 'roles', 'tasks', 'block', 'meta', 'pre_tasks', 'post_tasks', 'become_user', 'tags', 'register', 'ignore_errors', 'delegate_to', 'hosts', 'action', 'local_action', 'with_', 'notify', 'listen', 'async', 'poll', 'ignore_errors', 'delegate_to', 'when', 'tags', 'register', 'environment', 'args', 'run_once'])

# Generated at 2022-06-11 19:19:10.779199
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'vars' in reserved
    assert 'role_path' in reserved

# Generated at 2022-06-11 19:19:21.911467
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:19:29.187363
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert sorted(get_reserved_names()) == sorted(['name', 'gather_facts', 'delegate_to', 'no_log', 'when', 'async', 'poll', 'sudo', 'sudo_user', 'become', 'become_user', 'parent', 'connection', 'any_errors_fatal', 'serial', 'ignore_errors', 'tags', 'register', 'transport', 'notify', 'block', 'local_action', 'remote_user', 'with_'])

# Generated at 2022-06-11 19:19:37.780499
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = _RESERVED_NAMES

    assert {'action', 'local_action', 'with_'}.issubset(reserved)
    assert {'become', 'become_user', 'connection', 'delegate_to', 'environment', 'gather_facts', 'hosts', 'priority', 'roles', 'serial', 'tags', 'task_action', 'vars_files', 'vars_prompt', 'vars_source'}.issubset(reserved)
    assert 'notify' in reserved
    assert 'listen' not in reserved
    assert 'become_method' not in reserved
    assert 'name' not in reserved
    assert 'version' not in reserved



# Generated at 2022-06-11 19:19:45.982559
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(('name', 'hosts', 'vars', 'roles', 'tasks', 'handlers', 'vars_files', 'pre_tasks',
                  'post_tasks', 'tasks_from', 'role_paths', 'action_plugins', 'tags', 'post_validate'))

    private = set(('become', 'become_user', 'become_method', 'delegate_to', 'gather_facts',
                   'environment', 'when', 'async_val', 'poll', 'ignore_errors', 'no_log',
                   'always_run', 'register', 'when', 'local_action', 'until', 'retries',
                   'delay', 'first_available_file', 'loop', 'notify', 'ignore_errors'))


# Generated at 2022-06-11 19:19:55.788274
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pub = get_reserved_names(include_private=False)
    pri = get_reserved_names(include_private=True)

    assert 'name' in pub and 'name' in pri
    assert 'action' in pub and 'action' not in pri
    assert 'local_action' not in pub and 'local_action' in pri
    assert 'loop' not in pub and 'loop' in pri
    assert 'with_' not in pub and 'with_' in pri
    assert 'include' in pub and 'include' in pri
    assert 'include_role' not in pub and 'include_role' in pri
    assert 'include_tasks' not in pub and 'include_tasks' in pri

# Generated at 2022-06-11 19:20:04.615202
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests that get_reserved_names returns the reserved names '''

    result = get_reserved_names()

    assert 'gather_facts' in result
    assert 'roles' in result
    assert 'action' in result
    assert 'connection' in result
    assert 'hosts' in result
    assert 'include_role' in result
    assert 'include' in result
    assert 'import_playbook' in result
    assert 'post_tasks' in result
    assert 'pre_tasks' in result
    assert 'tasks' in result
    assert 'vars' in result
    assert 'async_timeout' in result
    assert 'async' in result
    assert 'auto_failback' in result
    assert 'environment' in result
    assert 'delegate_to' in result

# Generated at 2022-06-11 19:21:57.349770
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:22:02.379463
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test get_reserved_names() '''

    reserved = set(get_reserved_names())

    assert reserved
    # test private attributes as well
    assert reserved != set(get_reserved_names(include_private=False))

    assert set(get_reserved_names(include_private=False)).issubset(reserved)



# Generated at 2022-06-11 19:22:10.318991
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This should fail any time a new attribute is added to Play or PlayContext
    assert _RESERVED_NAMES == frozenset([
        'environment', 'force_handlers', 'gather_facts', 'handler_list', 'hosts', 'max_fail_pct', 'name',
        'pre_tasks', 'roles', 'serial', 'start_at_task', 'strategy', 'su', 'su_user', 'sudo', 'sudo_user',
        'tags', 'tasks', 'vars_files', 'vars_prompt', 'when'
    ])



# Generated at 2022-06-11 19:22:13.478758
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print('UnitTest: test_get_reserved_names')

    reserved = get_reserved_names()
    assert(type(reserved) == set)

    print(reserved)

# Generated at 2022-06-11 19:22:22.758575
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # There are many reserved names, too many to list here as test cases.
    # Instead we test
    # 1) That we have a large enough list to be useful
    # 2) That we do not include names that are not in _attributes
    # 3) That we do not include old deprecated names
    # Note: we cannot easily test that the appropriate names are returned
    # because Play() etc are abstract and cannot be instantiated without
    # specifying the objects they represent.
    assert len(_RESERVED_NAMES) > 20

    p = Play()
    for name in _RESERVED_NAMES:
        assert name in p._attributes, '%s not in reserved names' % name

    assert 'with_list' not in _RESERVED_NAMES
    assert 'without_list' not in _RESERVED_NAMES

# Generated at 2022-06-11 19:22:29.945574
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'delegate_to' in _RESERVED_NAMES
    assert 'register' in _RESERVED_NAMES
    assert 'ignore_errors' in _RESERVED_NAMES
    assert 'listen' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES

# Generated at 2022-06-11 19:22:36.543407
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_names = {
        'any_errors_fatal',
        'become',
        'become_user',
        'become_method',
        'changed_when',
        'check_mode',
        'connection',
        'delegate_to',
        'failed_when',
        'ignore_errors',
        'include',
        'local_action',
        'name',
        'notify',
        'notify_slack',
        'run_once',
        'sudo',
        'sudo_user',
        'task_name',
        'tags',
        'when',
        'with_',
    }
    reserved_names = get_reserved_names(include_private=False)
    assert expected_names == reserved_names

# Generated at 2022-06-11 19:22:46.507329
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()

    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)

    assert 'include' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'import_playbook' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' not in get_reserved_names()
    assert 'loop' not in get_reserved_names()
    assert 'with_' not in get_res

# Generated at 2022-06-11 19:22:52.263340
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Simply ensures that get_reserved_names function returns data
    '''

    # we simply check that we got a set with content
    assert len(get_reserved_names()) > 10
    assert len(get_reserved_names(include_private=False)) > 10



# Generated at 2022-06-11 19:23:01.723196
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test function for function get_reserved_names'''
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'pre_tasks' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'post_tasks' in get_reserved_names()
    assert 'handlers' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
