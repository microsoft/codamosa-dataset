

# Generated at 2022-06-11 19:13:42.922388
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) >= 51
    assert len(get_reserved_names(False)) >= 51

# Generated at 2022-06-11 19:13:50.881338
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names(include_private=False)
    assert 'name' in get_reserved_names(include_private=True)
    assert 'async' in get_reserved_names(include_private=False)
    assert 'async' not in get_reserved_names(include_private=True)
    assert 'loop' in get_reserved_names(include_private=False)
    assert 'loop' in get_reserved_names(include_private=True)
    assert 'with_' not in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:13:57.391507
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'private' in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)
    assert 'roles' in _RESERVED_NAMES

# Generated at 2022-06-11 19:14:04.364767
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get the reserved names
    reserved_names = get_reserved_names()

    # Some names that should be and should not be in reserved names

# Generated at 2022-06-11 19:14:09.871790
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(True) == _RESERVED_NAMES
    assert get_reserved_names(False) == frozenset([
        'gather_facts', 'hosts', 'name', 'roles', 'tags', 'tasks', 'vars', 'vars_files', 'action', 'local_action',
        'with_'
    ])

# Generated at 2022-06-11 19:14:12.801511
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 29
    assert "action" in get_reserved_names()
    assert "include_role" in get_reserved_names()
    assert "_private_action" in get_reserved_names()

# Generated at 2022-06-11 19:14:16.476338
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not get_reserved_names(False).intersection(get_reserved_names(True))
    assert not get_reserved_names(True).intersection(get_reserved_names(False))


# Generated at 2022-06-11 19:14:22.334664
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert not get_reserved_names().difference(get_reserved_names(False))
    assert 'hosts' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'local_action' in get_reserved_names()


# Generated at 2022-06-11 19:14:33.491404
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = set(get_reserved_names())
    assert 'hosts' in reserved_names
    assert is_reserved_name('hosts')
    assert 'roles' in reserved_names
    assert is_reserved_name('roles')
    assert 'serial' in reserved_names
    assert is_reserved_name('serial')
    assert 'gather_facts' in reserved_names
    assert is_reserved_name('gather_facts')
    assert 'remote_user' in reserved_names
    assert is_reserved_name('remote_user')
    assert 'vars' in reserved_names
    assert is_reserved_name('vars')
    assert 'sudo' in reserved_names
    assert is_reserved_name('sudo')
    assert 'sudo_user' in reserved_names

# Generated at 2022-06-11 19:14:44.305388
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:06.896461
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Test that we get known set of reserved names both with and without private
    '''

    public = set(["block", "connection", "delegate_to", "gather_facts", "gather_subset", "handlers", "hosts",
                  "ignore_errors", "local_action", "notify", "roles", "serial", "when", "any_errors_fatal", "any_unreachable_fatal",
                  "become", "become_method", "fail_on_missing_handler", "force_handlers", "max_fail_percentage", "name",
                  "post_tasks", "pre_tasks", "remote_user", "sudo", "sudo_user", "tags", "transport", "vars", "version"])

    private = set(["loop"])


# Generated at 2022-06-11 19:15:09.031675
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names())
    assert(len(set(get_reserved_names())) > 0)



# Generated at 2022-06-11 19:15:17.629973
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert(len(reserved) > 50)
    assert('hosts' in reserved)
    assert('roles' in reserved)
    assert('pre_tasks' in reserved)
    assert('post_tasks' in reserved)
    assert('loop' not in reserved)
    assert('local_action' in reserved)
    assert('with_' in reserved)
    assert('should_continue' in reserved)
    assert('block' in reserved)
    assert('rescue' in reserved)
    assert('always' in reserved)

    reserved = get_reserved_names(include_private=False)
    assert(len(reserved) > 40)
    assert('hosts' in reserved)
    assert('roles' in reserved)
    assert('pre_tasks' in reserved)
   

# Generated at 2022-06-11 19:15:24.876010
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == get_reserved_names(include_private=True)
    assert 'debug' in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'loop' in get_reserved_names(include_private=True)
    assert 'loop' not in get_reserved_names()
    assert 'with_' in get_reserved_names()



# Generated at 2022-06-11 19:15:34.112996
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_public = get_reserved_names(include_private=False)
    reserved_private = get_reserved_names(include_private=True)

    assert 'when' in reserved_public
    assert 'action' in reserved_public
    assert 'local_action' in reserved_public
    assert 'args' not in reserved_public
    assert 'private' not in reserved_public
    assert 'any_errors_fatal' in reserved_private
    assert 'serial' in reserved_private
    assert 'private' not in reserved_private
    assert len(reserved_public) < len(reserved_private)



# Generated at 2022-06-11 19:15:44.374107
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:15:47.573835
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'local_action' not in get_reserved_names()
    assert 'local_action' in get_reserved_names(True)  # include private


# Generated at 2022-06-11 19:15:59.354635
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # use non-private reserved variables
    assert 'name' in get_reserved_names(False)
    assert 'hosts' in get_reserved_names(False)
    assert 'connection' in get_reserved_names(False)
    assert 'any_errors_fatal' in get_reserved_names(False)

    # use private reserved variables
    assert 'include' in get_reserved_names(True)
    assert 'include_hosts' in get_reserved_names(True)
    assert 'include_tasks' in get_reserved_names(True)
    assert 'include_vars' in get_reserved_names(True)
    assert 'vars' in get_reserved_names(True)
    assert 'deprecated' in get_reserved_names(True)

# Generated at 2022-06-11 19:16:10.641008
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(include_private=False)
    private_names = get_reserved_names(include_private=True)

    assert 'inventory' in private_names
    assert 'inventory_dir' in private_names
    assert 'playbook_dir' in private_names
    assert 'play_hosts' in private_names
    assert 'play_name' in private_names
    assert 'play_basedir' in private_names
    assert 'play_vars' in private_names
    assert 'vars' in private_names
    assert 'vars_files' in private_names
    assert 'vars_prompt' in private_names
    assert 'vars_prompt_once' in private_names

    # make sure names starting with '_' are not public

# Generated at 2022-06-11 19:16:20.039739
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set([
        'any_errors_fatal', 'block', 'block_errors', 'connection', 'delegate_facts', 'environment',
        'environment_vars', 'error_on_undefined_vars', 'force_handlers', 'with_', 'hosts', 'ignore_errors',
        'import_playbook', 'include', 'include_role', 'include_tasks', 'included_file', 'vars',
        'loops', 'loop_control', 'no_log', 'name', 'post_tasks', 'pre_tasks', 'precedence', 'roles',
        'tasks', 'tags', 'vars_files'
    ]) == get_reserved_names(include_private=False)


# Generated at 2022-06-11 19:16:55.649451
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    # this function should return only strings, not unicode
    assert(not all(isinstance(x, unicode) for x in reserved_names))

    # this is the current list of reserved names
    # (subject to change without notice)

# Generated at 2022-06-11 19:17:00.969415
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=True)
    assert 'action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names
    assert 'loop_control' in reserved_names
    assert 'vars' in reserved_names

# Generated at 2022-06-11 19:17:10.504699
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:21.819188
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for function get_reserved_names '''

    # Are the get_reserved_names the same as the _RESERVED_NAMES?
    assert get_reserved_names(True) == _RESERVED_NAMES

    # Check expected public vs. private reserved names

# Generated at 2022-06-11 19:17:31.961565
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed

# Generated at 2022-06-11 19:17:34.828468
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == get_reserved_names(True)
    assert get_reserved_names(False) == _RESERVED_NAMES



# Generated at 2022-06-11 19:17:45.348121
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:17:47.534636
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """This is a simple unit test for function get_reserved_names()
    """
    assert 'name' in get_reserved_names()

# Generated at 2022-06-11 19:17:56.985165
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # contrived example:
    #   two public, two private variables
    #   two of each start with 'with_', one of each starts with 'loop'
    class ExampleA(object):
        _attributes = dict(private_loop='private', public_with='public',
                           private_with='private', public_loop='public')
    class ExampleB(object):
        _attributes = dict(private_with='private', public_with='public',
                           private_loop='private', public_loop='public')
    class ExampleC(object):
        _attributes = dict(private_loop='private', private_with='private')

    # Names should not be duplicated in each of the following sets
    # pylint: disable=redefined-outer-name

# Generated at 2022-06-11 19:18:05.316549
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' This function unit tests the get_reserved_names() functionality '''
    # test private
    assert 'become' in get_reserved_names(include_private=True)
    assert not get_reserved_names(include_private=False)
    # test public
    assert 'gather_facts' in get_reserved_names(include_private=True)
    assert get_reserved_names(include_private=True).difference(_RESERVED_NAMES) == set()
    # test local_action
    assert 'local_action' in get_reserved_names(include_private=True)
    assert 'local_action' not in get_reserved_names(include_private=False)
    # test with_
    assert 'with_' in get_reserved_names(include_private=True)


# Generated at 2022-06-11 19:18:57.320383
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: need to write this test
    pass

# Generated at 2022-06-11 19:19:00.055502
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(True)

# Generated at 2022-06-11 19:19:07.043897
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' check that function get_reserved_names returns expected output '''

    public = set(['handlers', 'vars', 'roles', 'name', 'gather_facts', 'action', 'local_action', 'with_', 'tags'])
    private = set(['post_validate', '_role_vars', '_task_blocks', '_update_vars', '_handlers', '_next',
                   '_block', '_parent', 'dump_me', '_included_file', '_role', '_load_fragment', '_role_params',
                   '_play', '_included_file_insertion_index', '_is_role', '_role_context', '_play_context', '_role_name'])
    result = public.union(private)
    assert get_

# Generated at 2022-06-11 19:19:12.998291
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test that get_reserved_names returns identical sets for private and public '''

    private = get_reserved_names(include_private=True)
    public = get_reserved_names(include_private=False)

    assert private > public

    # fix for loop implies with_
    assert '.loop' in private
    assert '.with_' in public

    # fix for implicit local_action
    assert 'action' in public
    assert 'local_action' in public



# Generated at 2022-06-11 19:19:19.497687
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # pylint: disable=protected-access
    public = set(get_reserved_names(False))
    private = set(get_reserved_names(True))
    assert public.issubset(private)
    assert len(public) > 0
    assert len(private) > len(public)
    # pylint: enable=protected-access


# Generated at 2022-06-11 19:19:26.961563
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert 'name' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'gather_facts' in _RESERVED_NAMES
    assert 'any_errors_fatal' in _RESERVED_NAMES
    assert 'fail_mode' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES
    assert 'rescue' in _RESERVED_NAMES
    assert 'always' in _RESERVED_NAMES
   

# Generated at 2022-06-11 19:19:36.109910
# Unit test for function get_reserved_names
def test_get_reserved_names():
    tests = [
        {'description': 'check length of public reserved names',
         'expected': 62,
         'include_private': False},
        {'description': 'check length of all reserved names',
         'expected': 76,
         'include_private': True},
    ]

    for test in tests:
        result = len(get_reserved_names(test['include_private']))
        if test['expected'] != result:
            raise AssertionError('get_reserved_names() incorrect for test: %s. Expected: %s Actual: %s' %
                                 (test['description'], test['expected'], result))

# Generated at 2022-06-11 19:19:45.027701
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved_names = get_reserved_names()

    assert all('_' not in _rname for _rname in reserved_names), \
        'reserved names list should not contain underscores ' \
        '(prevent potential conflicts when expanding dictionaries)'

    assert 'hosts' in reserved_names, \
        'hosts should be a reserved name'

    assert 'action' in reserved_names, \
        'action should be a reserved name'

    assert 'local_action' in reserved_names, \
        'local_action should be a reserved name'

    assert 'with_' in reserved_names, \
        'with_ should be a reserved name'

    assert 'loop' in reserved_names, \
        'loop should be a reserved name'


# Generated at 2022-06-11 19:19:55.904576
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:19:58.735784
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public, private = get_reserved_names(include_private=False), get_reserved_names(include_private=True)
    assert public.issubset(private)



# Generated at 2022-06-11 19:21:02.273340
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' reserved names are not allowed to have variables created with them '''
    # FIXME: this should really be some kind of test module using a framework
    # like py.test, but for now just call it as a stand-alone executable.
    #
    # I'm just verifying the public list here, as the private list is being
    # deprecated and we'd have to make the test more complex to deal with the
    # private list.
    public_names = get_reserved_names(include_private=False)

# Generated at 2022-06-11 19:21:04.258227
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set), 'one set of names required'
    assert get_reserved_names() != [], 'empty set of reserved names not allowed'

# Generated at 2022-06-11 19:21:14.715177
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(('action', 'block', 'connection', 'delegate_to', 'ignore_errors', 'local_action', 'name', 'no_log', 'notify', 'poll', 'register', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'until', 'when', 'with_'))
    assert get_reserved_names(include_private=False) == frozenset(('action', 'block', 'connection', 'delegate_to', 'ignore_errors', 'name', 'no_log', 'notify', 'poll', 'register', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'until', 'when', 'with_'))

# Generated at 2022-06-11 19:21:25.396365
# Unit test for function get_reserved_names

# Generated at 2022-06-11 19:21:36.086699
# Unit test for function get_reserved_names
def test_get_reserved_names():
    actual = get_reserved_names()

# Generated at 2022-06-11 19:21:46.522526
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """ Test for function get_reserved_names() """
    # Test pubic names
    assert 'hosts' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'loop' not in get_reserved_names()
    assert 'vars' not in get_reserved_names()
    assert 'any_errors_fatal' not in get_reserved_names()
    assert 'connection' not in get_reserved_names()

    # Test private names
    assert 'loop' in get_reserved_names(True)
    assert 'vars' in get_reserved_names(True)

# Generated at 2022-06-11 19:21:57.412230
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_public = set([])
    expected_private = set([])
    expected_all = set([])

    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()
        expected_public.update(set(aobj._public_attributes))
        expected_private.update(set(aobj._private_attributes))
        expected_all.update(set(aobj._attributes))

    # local_action is implicit with action
    if 'action' in expected_public:
        expected_public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    if 'loop' in expected_private:
        expected_private.add('with_')

    # FIXME: check if it's

# Generated at 2022-06-11 19:22:05.794872
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names()

    # there may be more reserved in the future,
    # but as long as this list is representative, they are probably all there
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved

    # these should not be in the reserved list:
    assert 'not_a_real_attr' not in reserved
    assert 'tags' not in reserved
    assert 'defaults' not in reserved
    assert 'vars' not in reserved
    assert 'meta' not in reserved


# Generated at 2022-06-11 19:22:08.851775
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'connection' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)

# Generated at 2022-06-11 19:22:16.367688
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this is a test for the function get_reserved_names '''

    my_reserved = get_reserved_names()
    for attribute in Play.__dict__['_attributes']:
        if 'private' not in attribute:
            assert attribute in my_reserved

    my_reserved = get_reserved_names(include_private=False)
    for attribute in Play.__dict__['_attributes']:
        if 'private' in attribute:
            assert attribute not in my_reserved