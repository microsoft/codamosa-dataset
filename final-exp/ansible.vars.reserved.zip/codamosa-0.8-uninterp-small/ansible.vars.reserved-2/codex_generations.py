

# Generated at 2022-06-25 14:26:28.226977
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:35.639814
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: This should be a doctest
    var_0 = sorted(get_reserved_names())

# Generated at 2022-06-25 14:26:41.524411
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:43.413342
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 158
    assert len(get_reserved_names(include_private=False)) == 134



# Generated at 2022-06-25 14:26:51.094385
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_cases = dict()


# Generated at 2022-06-25 14:26:51.851820
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()

# Generated at 2022-06-25 14:26:55.772821
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Set up test variables
    hostvars = dict()
    play_ds = dict()
    play_hosts = []
    loader = None
    variable_manager = None

    # Ensure function does not return empty set
    assert len(get_reserved_names()) > 0


# Generated at 2022-06-25 14:26:57.999261
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print('Test')
    var_0 = get_reserved_names()
    assert 'delegate_to' in var_0

test_get_reserved_names()

# Generated at 2022-06-25 14:26:58.930536
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()



# Generated at 2022-06-25 14:27:01.044169
# Unit test for function get_reserved_names
def test_get_reserved_names():
    myvars = ['first', 'second', 'action', 'connector', 'loop']
    test_case_0()
    warn_if_reserved(myvars)

# Generated at 2022-06-25 14:27:24.754041
# Unit test for function get_reserved_names
def test_get_reserved_names():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        test_case_0()
    assert pytest_wrapped_e.type == SystemExit

# Generated at 2022-06-25 14:27:32.246734
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:36.575381
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Test module for function get_reserved_names
    '''
    assert len(get_reserved_names()) == 51, "Failed to get list of reserved names"


# This is a simple test to check if the reserved names
# have changed without updating the unittest.
# If this test fails, then you should update the unittest above.

# Generated at 2022-06-25 14:27:43.770147
# Unit test for function get_reserved_names
def test_get_reserved_names():
    hostvars_0 = {"hostvars.hostvars_0": {"ansible_default_ipv4": {"address": "172.17.0.2"}}}
    role = Role()
    role.post_validate("playbook.yml", hostvars_0)
    hostvars_1 = {"hostvars.hostvars_0": {"ansible_default_ipv4": {"address": "172.17.0.2"}}}
    block = Block()
    block.post_validate("playbook.yml", hostvars_1)
    name_0 = "example.yml"
    hosts_0 = "all"
    play_0 = Play()

# Generated at 2022-06-25 14:27:47.224129
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) is set
    assert len(get_reserved_names()) > 0
    assert 'vars' in get_reserved_names()
    assert 'local_action' in get_reserved_names()


# Generated at 2022-06-25 14:27:48.423869
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == _RESERVED_NAMES

# Generated at 2022-06-25 14:27:49.292514
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()



# Generated at 2022-06-25 14:27:54.050012
# Unit test for function get_reserved_names
def test_get_reserved_names():
    arg0 = True
    arg1 = False
    arg2 = True
    arg3 = False
    var_0 = get_reserved_names(arg0)
    var_1 = get_reserved_names(arg1)
    var_2 = get_reserved_names(arg2)
    var_3 = get_reserved_names(arg3)
    assert var_1 == var_3
    assert var_2 == var_3
    pass


# Generated at 2022-06-25 14:28:01.683933
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:02.898617
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) == set


# Generated at 2022-06-25 14:28:49.662742
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:53.836923
# Unit test for function get_reserved_names
def test_get_reserved_names():
    type_0 = type(get_reserved_names())
    assert (type_0 is frozenset), "get_reserved_names() returns %s instead of 'set'" % type_0
    assert (len(get_reserved_names()) > 0), "get_reserved_names() returns length 0"



# Generated at 2022-06-25 14:28:55.403752
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Just make sure it doesn't blow up
    get_reserved_names()



# Generated at 2022-06-25 14:28:57.001380
# Unit test for function get_reserved_names
def test_get_reserved_names():
    isinstance(get_reserved_names(), set)
    assert get_reserved_names() == _RESERVED_NAMES



# Generated at 2022-06-25 14:29:04.633206
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(False) == {'any_errors_fatal', 'async', 'backup', 'become', 'become_user', 'connection', 'delegate_to', 'elements', 'environment', 'first_available_file', 'forks', 'hosts', 'ignore_errors', 'inventory', 'key_file', 'limit', 'local_action', 'loop', 'no_log', 'notify', 'password', 'poll', 'post_tasks', 'pre_tasks', 'roles', 'serial', 'sudo', 'sudo_user', 'su', 'su_user', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'with_', 'user'}


# Generated at 2022-06-25 14:29:07.710931
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function
    '''
    var_0 = get_reserved_names()
    assert type(var_0) is set, "Return value from frozenset(get_reserved_names()) must be set type"


# Generated at 2022-06-25 14:29:09.016471
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() is not None, 'Failed test_case_0'



# Generated at 2022-06-25 14:29:15.420748
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:16.216252
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() is None

# Generated at 2022-06-25 14:29:25.470715
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:01.687814
# Unit test for function get_reserved_names
def test_get_reserved_names():

    expected_result = frozenset([u'hosts', u'roles', u'name', u'vars', u'action', u'block', u'include_vars', u'include_role', u'serial', u'gather_facts', u'pre_tasks', u'post_tasks', u'tags', u'tasks', u'when', u'notify', u'handlers', u'local_action', u'with_', u'loop', u'become', u'become_user', u'become_method', u'connection', u'delegate_to', u'run_once', u'environment', u'no_log', u'any_errors_fatal', u'status', u'async'])

    result = get_reserved_names()

    assert result == expected_result

#

# Generated at 2022-06-25 14:31:08.276629
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:13.952839
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:15.331479
# Unit test for function get_reserved_names
def test_get_reserved_names():
    cases = [0]
    for case in cases:
        print("Running test case: %s" % case)
        test_case_0()


# Generated at 2022-06-25 14:31:18.565605
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        assert len(get_reserved_names()) > 0
    except AssertionError as ae:
        raise AssertionError(ae.args)


# Generated at 2022-06-25 14:31:20.554688
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert isinstance(var_0, set)


# Generated at 2022-06-25 14:31:23.584563
# Unit test for function get_reserved_names
def test_get_reserved_names():

    var_1 = get_reserved_names()
    var_2 = get_reserved_names()

    assert var_1 == var_2
    assert var_1 is not var_2


# Generated at 2022-06-25 14:31:25.833195
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("Begin test: {}".format(test_get_reserved_names.__name__))
    print("\t{}".format(test_case_0.__doc__))
    test_case_0()

# Generated at 2022-06-25 14:31:30.665316
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset({'action', 'block', 'blockrescue', 'blockalways', 'hosts', 'notify', 'tasks', 'vars', 'handler', 'roles', 'include', 'register', 'tags', 'when', 'local_action', 'loop', 'with_'})
    assert get_reserved_names(include_private=False) == frozenset({'action', 'block', 'hosts', 'register', 'tags', 'when', 'local_action', 'with_'})

# Generated at 2022-06-25 14:31:34.685865
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Check that the returned list of reserved names is correct
    var_1 = get_reserved_names()
    assert var_1 == frozenset(['become', 'become_method', 'become_user', 'connection', 'delegate_to', 'environment', 'fail_key', 'gather_facts', 'ignore_errors', 'local_action', 'loop', 'name', 'notify', 'register', 'serial', 'tags', 'task_name', 'until', 'when', 'with_'])

# Generated at 2022-06-25 14:34:55.352455
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:35:04.280090
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:35:04.948896
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(test_case_0())!=0

# Generated at 2022-06-25 14:35:11.662368
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()

# Generated at 2022-06-25 14:35:20.001401
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test_case_0
    var_0 = get_reserved_names()


# Generated at 2022-06-25 14:35:26.546162
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:35:32.435963
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:35:33.495632
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()

# Generated at 2022-06-25 14:35:37.738007
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # check if we get an error on illegal input
    try:
        get_reserved_names(include_private=1)
    except TypeError:
        pass
    else:
        raise AssertionError("It should raise an error")

    # check if we get the same output with original function
    var_0 = get_reserved_names()
    var_1 = test_case_0()
    if var_0 != var_1:
        raise AssertionError("It should return the same output")



# Generated at 2022-06-25 14:35:38.675025
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: use pytest instead
    assert get_reserved_names()