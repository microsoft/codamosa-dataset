

# Generated at 2022-06-25 14:26:29.951688
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:30.751069
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert var_0 is not None



# Generated at 2022-06-25 14:26:33.355297
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Case provided by docs
    PlayObj = Play()
    Vars = PlayObj.__dict__['_attributes']

    assert set(Vars) == get_reserved_names()

# FIXME: perhaps just check elsewhere for this?

# Generated at 2022-06-25 14:26:41.484985
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:44.220006
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_cases = (
        (dict(include_private=True), test_case_0()),
    )

    for test_case, expected in test_cases:
        test = get_reserved_names(**test_case)
        assert test == expected

# Generated at 2022-06-25 14:26:49.028207
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == ['gather_facts', 'hosts', 'name', 'roles', 'tasks', 'vars_files', 'vars', 'tags', 'post_tasks', 'pre_tasks', 'handlers', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'delegate_to', 'environment', 'remote_user', 'register', 'ignore_errors', 'local_action']



# Generated at 2022-06-25 14:26:57.636765
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:05.682513
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # setup
    testcase = get_reserved_names(include_private=True)

# Generated at 2022-06-25 14:27:15.347192
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_0 = get_reserved_names()
    reserved_1 = get_reserved_names(include_private=False)
    
    reserved_0 = set(reserved_0)
    reserved_1 = set(reserved_1)

    assert len(reserved_1) + len(reserved_0.difference(reserved_1)) == len(reserved_0)

# Generated at 2022-06-25 14:27:19.312215
# Unit test for function get_reserved_names
def test_get_reserved_names():

    var_0 = len(get_reserved_names(True))
    assert var_0 == 39, 'Expected 39, got %s' % var_0
    var_1 = len(get_reserved_names(False))
    assert var_1 == 36, 'Expected 36, got %s' % var_1


# Generated at 2022-06-25 14:27:32.383967
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert reserved_names is not None



# Generated at 2022-06-25 14:27:36.432915
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\xe1T\xc2\x0f\xcf\xaa'
    bytes_1 = b'\x0f\x1e\x1d\xd2\xc8j\xbb'
    assert get_reserved_names(bytes_0) == bytes_1


# Generated at 2022-06-25 14:27:42.039814
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Simple tests
    assert 'include' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'name' in get_reserved_names()

    reserved = get_reserved_names()
    assert isinstance(reserved, set)
    assert not isinstance(reserved, list)
    assert not isinstance(reserved, tuple)
    assert not isinstance(reserved, str)
    assert not isinstance(reserved, bytes)

    assert not 'doesnt_exist' in get_reserved_names()


# Generated at 2022-06-25 14:27:50.877203
# Unit test for function get_reserved_names
def test_get_reserved_names():
    #Test with params include_private
    a = get_reserved_names(True)
    b = set(['handler', 'remote_user', 'roles', 'strategy', 'hosts', 'block', 'name', 'vars', 'post_tasks', 'any_errors_fatal', 'transport', 'tags', 'become_user', 'vars_files', 'task', 'gather_facts', 'delegate_to', 'roles_path', 'pre_tasks', 'vars_prompt', 'async', 'post_validate', 'become', 'environment', 'always_run', 'notify'])
    assert a == b
    #Test without params
    a = get_reserved_names()

# Generated at 2022-06-25 14:27:52.920799
# Unit test for function get_reserved_names
def test_get_reserved_names():
    _result = get_reserved_names()
    assert isinstance(_result, set)
    assert {'register', 'loop', 'env'} <= _result


# Generated at 2022-06-25 14:27:58.659118
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(False) == {'name', 'register', 'run_once', 'notify', 'vars', 'handlers', 'roles', 'gather_facts', 'strategy', 'any_errors_fatal', 'max_fail_percentage', 'tags', 'when'}
    assert get_reserved_names(True) == {'serial', 'post_tasks', 'block', 'become_user', 'name', 'register', 'run_once', 'notify', 'vars', 'handlers', 'roles', 'gather_facts', 'strategy', 'any_errors_fatal', 'max_fail_percentage', 'tags', 'when'}


# Generated at 2022-06-25 14:28:06.805763
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()


# Generated at 2022-06-25 14:28:12.505305
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_list = frozenset(['any_errors_fatal', 'connection', 'delegate_facts', 'gather_facts', 'hosts', 'ignore_errors', 'name', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tasks', 'tags', 'transport', 'vars', 'vars_files', 'become', 'local_action', 'with_'])
    
    assert get_reserved_names() == expected_list


# Generated at 2022-06-25 14:28:20.364807
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:24.024515
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'connection', 'gather_facts', 'hosts', 'name', 'no_log', 'notify', 'roles', 'serial', 'tags', 'until', 'vars_prompt', 'vars_files', 'vault_password_files', 'when'])



# Generated at 2022-06-25 14:28:47.362644
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\x00\x00\x00\x00'
    var_0 = get_reserved_names(bytes_0)


# Generated at 2022-06-25 14:28:50.418142
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        test_case_0()
    except Exception as err:
        display.error(err)
        display.error('Failed test case: 0')

    display.display('Test module is working correctly')


if __name__ == '__main__':
    test_get_reserved_names()

# Generated at 2022-06-25 14:28:51.181734
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert isinstance(get_reserved_names(), list)

# Generated at 2022-06-25 14:28:58.186299
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['name', 'action', 'loop', 'local_action', 'delegate', 'delegate_facts', 'delegate_to', 'changed_when', 'failed_when', 'register', 'notify', 'tags', 'until', 'async', 'poll', 'ignore_errors', 'when', 'run_once', 'post_tasks', 'pre_tasks', 'always_run', 'any_errors_fatal', 'connection', 'with_items', 'no_log', 'run_once', 'sudo', 'sudo_user', 'shell', 'when', 'notify'])


# Generated at 2022-06-25 14:29:04.109103
# Unit test for function get_reserved_names
def test_get_reserved_names():
    my_test_list = ['tags', 'vars', 'name', 'action', 'handler', 'any_errors_fatal', 'create', 'delegate_to', 'delegate_facts', 'failed_when', 'ignore_errors', 'loop', 'local_action', 'register', 'retries', 'run_once', 'until', 'when']
    my_set = frozenset(my_test_list)
    my_obj = get_reserved_names()
    assert(my_set == my_obj)


# Generated at 2022-06-25 14:29:11.741721
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_data_0 = {
        u'include_private': False,
    }
    expected_0 = {
        u'any_errors_fatal',
        u'action',
        u'become',
        u'become_user',
        u'block',
        u'delegate_to',
        u'delegate_facts',
        u'environment',
        u'gather_facts',
        u'handlers',
        u'ignore_errors',
        u'name',
        u'notify',
        u'register',
        u'remote_user',
        u'roles',
        u'run_once',
        u'vars',
        u'when',
        u'with_',
    }

# Generated at 2022-06-25 14:29:13.318638
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        result = get_reserved_names(include_private=True)
        assert True
    except AssertionError:
        assert False


# Generated at 2022-06-25 14:29:21.962537
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()

# Generated at 2022-06-25 14:29:29.907084
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:35.372604
# Unit test for function get_reserved_names
def test_get_reserved_names():
    display = Display()
    assert get_reserved_names() == set(('environment', 'connection', 'any_errors_fatal', 'delegate_facts', 'gather_facts', 'ignore_errors', 'rolename', 'notify', 'serial', 'tags', 'transport', 'become', 'become_user', 'bogus', 'bogus_with_underscores', 'deprecated', 'deprecated_with_underscores', 'name', 'vars', 'register', 'when', 'remote_user', 'sudo', 'sudo_user', 'async', 'poll', 'local_action', 'with_'))


# Generated at 2022-06-25 14:30:22.948182
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset({'async', 'gather_facts', 'connection', 'other', 'action', 'post_tasks', 'register', 'tags', 'roles', 'vars', 'transport', 'no_log', 'environment', 'vars_files', 'ignore_errors', 'when', 'pre_tasks', 'notify'})


# Generated at 2022-06-25 14:30:25.089042
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: Implement
    ret = get_reserved_names()
    assert ret is not None


# Generated at 2022-06-25 14:30:26.121372
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names() is not None)


# Generated at 2022-06-25 14:30:27.608486
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False)
    assert get_reserved_names(include_private=True)


# Generated at 2022-06-25 14:30:28.542114
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert result is not None


# Generated at 2022-06-25 14:30:33.830292
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Ensure that we are using the correct set of reserved names in Ansible.
    Further, ensure that private and public types of reserved names are not being mixed.

    FIXME: needs a better means of testing that the reserved names are current
    '''

    # Create a list of reserved and public names
    reserved_names = get_reserved_names()
    reserved_public = get_reserved_names(include_private=False)

    # Test that there is no overlap between public and private
    assert reserved_names != reserved_public



# Generated at 2022-06-25 14:30:36.229274
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\xea\x00\xd5\xc84\xa1'
    var_0 = get_reserved_names(bytes_0)
    assert var_0 is not None


# Generated at 2022-06-25 14:30:38.131285
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test failure of function get_reserved_names, with positional argument 'include_private'
    assert get_reserved_names() is not None


# Generated at 2022-06-25 14:30:45.331071
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset({'action', 'pre_tasks', 'hosts', 'vars', 'gather_facts', 'post_tasks', 'tasks', 'roles', 'async', 'notify', 'remote_user', 'delegate_to', 'serial', 'notified_by', 'delegated_to', 'run_once', 'environment', 'connection', 'tags', 'register', 'until', 'ignore_errors', 'loop', 'when', 'local_action', 'with_'})

# Generated at 2022-06-25 14:30:45.997702
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:32:25.797299
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\xea\x00\xda\x17\xa9|'
    str_0 = string_to_bytes(bytes_0)
    var_0 = get_reserved_names(str_0)


# Generated at 2022-06-25 14:32:33.885858
# Unit test for function get_reserved_names
def test_get_reserved_names():
    my_var = get_reserved_names()

# Generated at 2022-06-25 14:32:35.393561
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), (set, frozenset))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 14:32:36.422926
# Unit test for function get_reserved_names
def test_get_reserved_names():
    actual = get_reserved_names()
    expected = 'tasks'
    assert actual == expected


# Generated at 2022-06-25 14:32:41.270913
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: this is incomplete, see #44801
    assert get_reserved_names() == set(['connection', 'ignore_errors', 'loop', 'name', 'notify', 'register', 'until', 'delegate_to', 'depends_on', 'become', 'become_user', 'tags', 'transport', 'environment', 'run_once', 'no_log', 'su', 'su_user', 'sudo', 'sudo_user', 'when'])


# Generated at 2022-06-25 14:32:49.969930
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()

# Generated at 2022-06-25 14:32:51.774900
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names()


# Generated at 2022-06-25 14:32:57.875022
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\xea\x00\xfa\x0c\x7f\x80\x00\x00'
    bytes_1 = b'#\x89\x85\xbec'
    bytes_2 = b'\x83\x9c\x9a\xaa\x93'
    bytes_3 = b'S\xb9\x9b'
    bytes_4 = b'\x0c\xe3\x01\x89\x84'
    bytes_5 = b'\x80\xd7\xde\xdc\xfc'
    bytes_6 = b'\x9b'
    bytes_7 = b'\xdf\xad\xce\xdf'

# Generated at 2022-06-25 14:33:02.630682
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert frozenset(get_reserved_names()) == frozenset(['become', 'become_method', 'become_user', 'connection', 'delegate_to', 'gather_facts', 'gather_subset', 'ignore_errors', 'name', 'no_log', 'notify', 'poll', 'register', 'remote_user', 'roles', 'run_once', 'sudo', 'sudo_user', 'tags', 'tasks', 'until', 'when', 'with_items', 'with_subelements', 'with_together', 'when'])


# Generated at 2022-06-25 14:33:05.322655
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """verify that get_reserved_names returns a list of reserved names """
    expected_result = {'gather_facts', 'name'}
    assert set(get_reserved_names(include_private=False)) == expected_result