

# Generated at 2022-06-25 14:26:32.368234
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()



# Generated at 2022-06-25 14:26:34.795586
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'connection', 'gather_facts', 'hosts', 'name', 'remote_user', 'serial', 'sudo_user', 'sudo', 'tasks', 'vars', 'vars_files'}

# Generated at 2022-06-25 14:26:39.785216
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert var_0 == frozenset({'block', 'environment', 'include_tasks', 'pre_tasks', 'include_role', 'post_tasks', 'hosts', 'role_name', 'name', 'local_action', 'tags', 'tasks', 'vars', 'any_errors_fatal', 'connection', 'action', 'delegate_to', 'gather_facts', 'vars_prompt', 'register', 'notify', 'environment_file', 'handler', 'ignore_errors', 'force_handlers', 'roles', 'become', 'async_pool'})


# Generated at 2022-06-25 14:26:41.292791
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check that we can get reserved names now
    var_1 = get_reserved_names()


# Generated at 2022-06-25 14:26:49.295015
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:57.866172
# Unit test for function get_reserved_names
def test_get_reserved_names():
    case_0 = frozenset(('become', 'remote_user', 'action', 'gather_facts', 'local_action', 'with_', 'vars', 'tags', 'register', 'until', 'notify', 'delegate_to', 'any_errors_fatal', 'failed_when', 'ignore_errors', 'block', 'block_rescue', 'block_always', 'name', 'run_once', 'when', 'include', 'meta', 'import_role', 'include_role', 'pre_tasks', 'post_tasks', 'vars_prompt', 'vars_files', 'default_vars', 'extra_vars', 'roles', 'tasks', 'handlers', 'always_run', 'become_user', 'become_method', 'conditional', 'dependencies'))

# Generated at 2022-06-25 14:26:59.639307
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test with incorrect parameter types
    var_0 = get_reserved_names('string')
    assert var_0 is None



# Generated at 2022-06-25 14:27:06.327790
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'any_errors_fatal', 'async', 'attempts', 'become', 'become_flags', 'become_method', 'become_user', 'block', 'changed_when', 'check_mode', 'connection', 'delay', 'delegate_to', 'environment', 'failed_when', 'ignore_errors', 'local_action', 'notify', 'poll', 'register', 'retries', 'role_name', 'run_once', 'sudo', 'sudo_flags', 'sudo_user', 'tags', 'transport', 'until', 'warn', 'with_', 'when', 'async_status'}



# Generated at 2022-06-25 14:27:15.827167
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:20.645624
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Assert that get_reserved_names() returns a frozenset of strings, including 'roles', 'hosts', and 'name'
    var_0 = get_reserved_names()
    assert isinstance(var_0, frozenset)
    assert isinstance(next(iter(var_0)), str)
    assert True in [i in var_0 for i in ('roles', 'hosts', 'name')]


# Generated at 2022-06-25 14:28:02.727517
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:03.580150
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() is not None

# Generated at 2022-06-25 14:28:05.477952
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ret = get_reserved_names()
    assert isinstance(ret, set)


# Generated at 2022-06-25 14:28:06.625482
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()


# Generated at 2022-06-25 14:28:07.697965
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() != [], "No reserved names found"



# Generated at 2022-06-25 14:28:09.303728
# Unit test for function get_reserved_names
def test_get_reserved_names():
    for reserved_name in _RESERVED_NAMES:
        assert(reserved_name in get_reserved_names())


# Generated at 2022-06-25 14:28:10.603062
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert isinstance(var_0, set)


# Generated at 2022-06-25 14:28:18.994580
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset({'action', 'become', 'become_user', 'become_method',
                                                                   'environment', 'gather_facts', 'ignore_errors',
                                                                   'name', 'no_log', 'pre_tasks', 'post_tasks',
                                                                   'role_path', 'roles', 'serial', 'tags', 'tasks',
                                                                   'when', 'register', 'notify', 'delegate_to', 'with_'})

# Generated at 2022-06-25 14:28:23.441291
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    cls_list = [Play, Role, Block, Task, TaskInclude, Handler]
    for cls in cls_list:
        obj =cls()
        for attr in obj._attributes:
            if not attr.get('name'):
                continue
            assert attr['name'] in get_reserved_names()




# Generated at 2022-06-25 14:28:24.786698
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert var_0 == _RESERVED_NAMES

# Generated at 2022-06-25 14:29:44.025193
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names(include_private=True)

# Generated at 2022-06-25 14:29:45.188733
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()
    return get_reserved_names()

# Generated at 2022-06-25 14:29:46.048734
# Unit test for function get_reserved_names
def test_get_reserved_names():
  assert type(test_case_0()) == frozenset

# Generated at 2022-06-25 14:29:47.183886
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == True


# Generated at 2022-06-25 14:29:54.808697
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:55.879333
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'remote_user' in get_reserved_names()

# Generated at 2022-06-25 14:30:02.261793
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:03.200058
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:30:08.813729
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print('Testing get_reserved_names()')

    # Get the list of reserved names
    var_0 = get_reserved_names()

    # Save the output
    with open('test_get_reserved_names.out', 'w') as f:
        print(var_0)
        f.write(repr(var_0))

    # Read in the expected list of reserved names
    with open('test_get_reserved_names.exp', 'r') as f:
        var_1 = eval(f.read())

    return var_0 == var_1

# Generated at 2022-06-25 14:30:16.406210
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:06.606561
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:16.015459
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:18.224085
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check that return type is a set
    assert isinstance(test_case_0(), set)



# Generated at 2022-06-25 14:33:26.206871
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # No point in testing this unless it has been defined
    if 'get_reserved_names' in globals():
        # Get list of all class members
        cls_members = set(dir(get_reserved_names))
        # Get the list of method names (the ones that do not start with '_')
        func_names = [x for x in cls_members if not x.startswith('_')]
        for name in func_names:
            # Assert that other methods exist to test with
            assert name + '_test_with_xxxx' in globals(), name + ' not covered'
        del cls_members, func_names, name
    else:
        # Callable not defined, nothing to test
        assert True is not False


# Generated at 2022-06-25 14:33:32.990654
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:39.147540
# Unit test for function get_reserved_names
def test_get_reserved_names():
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        a = aclass()
        reserved_names = get_reserved_names()
        # Test that all reserved_names are in the attribute list
        for b in a.__dict__['_attributes']:
            if b in reserved_names:
                assert b in reserved_names
        # Test that all attribute list attribute are in reserved names
        for c in reserved_names:
            assert c in a.__dict__['_attributes']


# Generated at 2022-06-25 14:33:46.461725
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:48.288235
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # ensure private names are included in results
    set1 = set(get_reserved_names(include_private=False))
    set2 = set(get_reserved_names(include_private=True))
    for a_name in set2.difference(set1):
        assert 'private' in str(a_name)


# Generated at 2022-06-25 14:33:54.641842
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()

# Generated at 2022-06-25 14:33:59.607208
# Unit test for function get_reserved_names