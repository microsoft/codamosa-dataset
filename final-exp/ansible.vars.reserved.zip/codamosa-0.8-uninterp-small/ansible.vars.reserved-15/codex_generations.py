

# Generated at 2022-06-25 14:26:24.149074
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:32.946532
# Unit test for function get_reserved_names
def test_get_reserved_names():

    file_path = os.path.join('lib', 'ansible', 'playbook', 'play_ds.py')

    lines, line_no = inspect.getsourcelines(get_reserved_names)

    # First line of function should be a doc string
    assert re.match(r'^(?!\s*$)', lines[0]) is not None, \
        'get_reserved_names() has no docstring in %s:%d' % (file_path, line_no)

    # Last line should be return statement
    paren_count = 0
    for l in reversed(lines):
        line_no -= 1
        if l.startswith('return'):
            paren_count += l.count('(') - l.count(')')
            if paren_count == 0:
                return
           

# Generated at 2022-06-25 14:26:34.949466
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert (len(var_0) == 77)


# Generated at 2022-06-25 14:26:43.802647
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Create a list of arguments
    arguments = []
    arguments.append({'include_private': True, 'result': frozenset({'with_first_found', 'with_subelements', 'local_action', 'loop', 'action', 'notify', 'post_tasks', 'always_run', 'vars', 'register', 'roles', 'any_errors_fatal', 'block', 'tasks', 'retries', 'pre_tasks', 'delegate_to', 'condition', 'listen', 'when', 'with_', 'when_loop'})})

# Generated at 2022-06-25 14:26:45.902009
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Case 0:
    #   Test the function get_reserved_names
    var_0 = get_reserved_names()
    # We expect no errors here.
    assert var_0 is not None


# Generated at 2022-06-25 14:26:54.311843
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert var_0 is not None, "Function get_reserved_names did not return a value"

# Generated at 2022-06-25 14:27:02.618176
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_var_0 = set()
    test_var_0.add('any_errors_fatal')
    test_var_0.add('with_items')
    test_var_0.add('port')
    test_var_0.add('delegate_facts')
    test_var_0.add('action')
    test_var_0.add('local_action')
    test_var_0.add('hosts')
    test_var_0.add('hosts')
    test_var_0.add('roles')
    test_var_0.add('vars_files')
    test_var_0.add('vars')
    test_var_0.add('gather_facts')
    test_var_0.add('when')
    test_var_0.add('name')

# Generated at 2022-06-25 14:27:07.018684
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    var_0.add('new_var')
    var_1 = get_reserved_names()
    var_2 = get_reserved_names()
    var_2.add('new_var')
    assert var_0 == var_2
    assert var_0 != var_1


# Generated at 2022-06-25 14:27:11.148523
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_cases = [
        {
            "name": "0",
            "input": test_case_0,
            "want": frozenset
        }
    ]
    for t in test_cases:
        yield t["input"], t["want"], t["name"]

# Generated at 2022-06-25 14:27:12.442269
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES


# Generated at 2022-06-25 14:27:39.959521
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert 'hosts' in var_0
    assert 'become_user' in var_0
    assert 'register' in var_0
    assert 'ignore_errors' in var_0
    assert 'delegate_to' in var_0
    assert 'block' in var_0
    assert 'meta' not in var_0



# Generated at 2022-06-25 14:27:41.068333
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() is not None


# Generated at 2022-06-25 14:27:50.134209
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:51.876852
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert var_0 is not None  # noqa: E402


# Generated at 2022-06-25 14:27:58.062234
# Unit test for function get_reserved_names
def test_get_reserved_names():
    play_list = [
        Play.load(dict(
            name='test play',
            hosts='all',
            gather_facts='no',
            tasks=[
                dict(action=dict(module='command', args='foo')),
                dict(action=dict(module='command', args='bar')),
            ],
        )),
    ]


# Generated at 2022-06-25 14:28:00.743521
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(len(get_reserved_names()) > 70)
    assert(len(get_reserved_names(include_private=False)) > 50)
    assert(len(get_reserved_names(include_private=True)) > 70)


# Generated at 2022-06-25 14:28:01.659486
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = list(get_reserved_names())
    assert type(var_0) == list


# Generated at 2022-06-25 14:28:07.379209
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Basic test
    expected_result = set(['gather_facts', 'name', 'connection', 'delegate_to', 'remote_user', 'sudo', 'sudo_user', 'any_errors_fatal', 'serial', 'su', 'su_user', 'run_once', 'become', 'become_method', 'become_user', 'vars_files', 'no_log'])
    actual_result = get_reserved_names()
    assert actual_result == expected_result


# Generated at 2022-06-25 14:28:08.158667
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0()


# Generated at 2022-06-25 14:28:10.297251
# Unit test for function get_reserved_names
def test_get_reserved_names():
    #from ansible.utils.vars import get_reserved_names
    reserved_list = get_reserved_names()
    assert isinstance(reserved_list, set)


# Generated at 2022-06-25 14:29:01.820299
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # mock_names_0
    #
    # we set the expected set of reserved names here.  It is important to
    # keep this up to date.
    #
    # the set of names reserved for private use should be mocked for testing
    # public function calls.
    expected = get_reserved_names(include_private=False)
    mock_names_0 = get_reserved_names(include_private=False)
    actual = get_reserved_names(include_private=False)
    assert expected == actual == mock_names_0

    # mock_names_1
    #
    # we set the expected set of reserved names here.  It is important to
    # keep this up to date.
    #
    # the set of names reserved for private use should not be mocked for testing
    # public function calls.

# Generated at 2022-06-25 14:29:09.632991
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names(include_private=True)
    assert 'connection' in var_0
    assert 'gather_facts' in var_0
    assert 'serial' in var_0
    assert 'tags' in var_0
    assert 'block' in var_0
    assert 'pre_tasks' in var_0
    assert 'roles' in var_0
    assert 'post_tasks' in var_0
    assert 'tasks' in var_0
    assert 'name' in var_0
    assert 'include_role' in var_0
    assert 'register' in var_0
    assert 'roles_path' in var_0
    assert 'when' in var_0
    assert 'loop' in var_0
    assert 'import_role' in var_0

# Generated at 2022-06-25 14:29:15.853469
# Unit test for function get_reserved_names
def test_get_reserved_names():
    dict_0 = dict()
    dict_0['include_private'] = False
    result = get_reserved_names(**dict_0)

# Generated at 2022-06-25 14:29:16.963498
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not get_reserved_names()


# Generated at 2022-06-25 14:29:18.374150
# Unit test for function get_reserved_names
def test_get_reserved_names():

    test_case_0()

# Generated at 2022-06-25 14:29:25.824166
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_var_0 = get_reserved_names(include_private=True)
    assert type(test_var_0) == set
    assert test_var_0 == set(['action', 'local_action', 'with_', 'become', 'become_user', 'become_method', 'challenge', 'check_mode', 'connection', 'delegate_to', 'environment', 'gather_facts', 'group_by', 'inventory_hostname', 'name', 'no_log', 'notify', 'poll', 'retries', 'run_once', 'serial', 'sudo', 'sudo_user', 'sudo_pass', 'tags', 'transport', 'until', 'when'])

# Generated at 2022-06-25 14:29:28.257245
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("test_get_reserved_names for function get_reserved_names")
    var_0 = get_reserved_names()
    print("var_0 = %s" % var_0)
    assert isinstance(var_0, frozenset)

if __name__ == '__main__':
    test_case_0()
    test_get_reserved_names()

# Generated at 2022-06-25 14:29:29.315277
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() is None, "test_case_0 failed"


# Generated at 2022-06-25 14:29:30.635300
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Just to make sure we can call function
    get_reserved_names()


# Generated at 2022-06-25 14:29:32.531255
# Unit test for function get_reserved_names
def test_get_reserved_names():
    name = 'test'
    assert get_reserved_names(name) is not None
    name = 'test'
    assert get_reserved_names(name) is not None


# Generated at 2022-06-25 14:30:27.881168
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:29.230414
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == _RESERVED_NAMES


# Generated at 2022-06-25 14:30:31.817248
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Check list contains expected values
    assert var_0 == {'any_errors_fatal', 'connection', 'hosts', 'name', 'post_tasks', 'roles', 'tasks', 'when', 'with_items'}



# Generated at 2022-06-25 14:30:32.784102
# Unit test for function get_reserved_names
def test_get_reserved_names():
    raise NotImplementedError('test')


# Generated at 2022-06-25 14:30:40.237900
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_cases = [
        (
            0,
        ),
    ]
    for test_case in test_cases:
        var_0 = get_reserved_names()

# Generated at 2022-06-25 14:30:45.799708
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    :return:
    '''
    assert set(get_reserved_names()) == set(['when', 'action', 'local_action', 'with_', 'connection', 'delegate_to', 'sudo', 'sudo_user',
                                             'remote_user', 'register', 'name', 'environment', 'first_available_file', 'include',
                                             'block', 'pre_tasks', 'post_tasks', 'role', 'hosts', 'tasks', 'vars', 'defaults',
                                             'vars_files', 'tasks_from', 'meta'])

# Generated at 2022-06-25 14:30:49.343351
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == frozenset(['any_errors_fatal', 'block', 'connection', 'delegate_facts', 'gather_facts', 'handlers', 'hosts', 'included_file', 'name', 'notify', 'post_tasks', 'pre_tasks', 'remote_user', 'roles', 'serial', 'tasks', 'vars_files', 'vars_prompt', 'when'])

# Generated at 2022-06-25 14:30:56.251980
# Unit test for function get_reserved_names
def test_get_reserved_names():
    actual = get_reserved_names()

# Generated at 2022-06-25 14:30:57.456609
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == '0'


# Generated at 2022-06-25 14:30:58.205663
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'when' in get_reserved_names()

# Generated at 2022-06-25 14:31:55.847754
# Unit test for function get_reserved_names
def test_get_reserved_names():

    fixture_0 = [
        'become',
        'become_method',
        'become_user',
        'connection',
        'delegate_to',
        'environment',
        'ignore_errors',
        'no_log',
        'register',
        'remote_user',
        'run_once',
        'name'
    ]

    fixture_1 = True

    get_reserved_names(fixture_1)

    fixture_2 = [
        'name',
        'hosts',
        'remote_user',
        'roles',
        'tasks',
        'gather_facts',
        'errors',
        'changed_when'
    ]

    get_reserved_names(fixture_1)

    fixture_3 = True


# Generated at 2022-06-25 14:32:03.227168
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: this code is breaking in weird ways, it's related to how
    # FIXME: get_reserved_names interacts with the various types of
    # FIXME: roles, but I don't know why
    ## play = Play()
    ## block = Block()
    ## role = Role()
    ## task = Task()

    ## reserved_names = get_reserved_names()

    ## assert isinstance(reserved_names, set)

    ## assert isinstance(reserved_names, set)
    ## reserved_names = get_reserved_names(True)
    ## assert isinstance(reserved_names, set)
    pass


# Generated at 2022-06-25 14:32:10.008703
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = 'd'
    str_1 = '-'
    str_2 = 'w'
    str_3 = 'j'
    str_4 = 'V'
    str_5 = '7'
    str_6 = 'q'
    str_7 = 'z'
    str_8 = '9'
    str_9 = 'g'
    str_10 = 'J'
    str_11 = 'P'

    var_0 = get_reserved_names(False)
    var_1 = get_reserved_names(True)
    var_2 = get_reserved_names(False)
    var_3 = get_reserved_names(False)
    var_4 = get_reserved_names(False)
    var_5 = get_reserved_names(False)
    var

# Generated at 2022-06-25 14:32:12.606055
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = 'gather_facts'
    var_0 = get_reserved_names(1)
    var_0.discard(str_0)
    var_1 = len(var_0)
    if var_1 is not 1:
        raise Exception("Get reserved names failed.")


# Generated at 2022-06-25 14:32:14.890645
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("")
    print("Running test_get_reserved_names")
    str_0 = get_reserved_names()
    print(str_0)
    print(type(str_0))



# Generated at 2022-06-25 14:32:21.818121
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = 'action'
    str_1 = 'additional_parameters'
    str_2 = 'become'
    str_3 = 'connection'
    str_4 = 'environment'
    str_5 = 'local_action'
    str_6 = 'loop'
    str_7 = 'name'
    str_8 = 'register'
    str_9 = 'retries'
    str_10 = 'sudo'
    str_11 = 'sudo_user'
    str_12 = 'tags'
    str_13 = 'transport'

# Generated at 2022-06-25 14:32:29.676469
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = ['action', 'local_action', 'loop', 'tags', 'gather_facts', 'any_errors_fatal', 'delegate_to']
    var_0 = get_reserved_names()
    var_1 = str_0
    assert sorted(var_0) == sorted(var_1)
    str_0 = ['action', 'local_action', 'loop', 'tags', 'gather_facts', 'any_errors_fatal', 'delegate_to']
    var_0 = get_reserved_names(True)
    var_1 = str_0
    assert sorted(var_0) == sorted(var_1)
    str_0 = ['action', 'local_action', 'loop', 'tags', 'gather_facts', 'any_errors_fatal', 'delegate_to']
   

# Generated at 2022-06-25 14:32:34.069072
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(True) == frozenset({'become_method', 'connection', 'delegate_to', 'environment', 'gather_facts', 'ignore_errors', 'imaginary_test_var', 'loop', 'module_defaults', 'register', 'remote_user', 'roles', 'serial', 'tags', 'tasks', 'transport', 'vars', 'vars_files', 'defaults'}) == _RESERVED_NAMES

# Generated at 2022-06-25 14:32:41.081046
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:46.297269
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: This test only continues to work because get_reserved_names()
    #        is not validated against the contents of _attributes,
    #        it is just hard coded.
    #        We need to fix this.
    #        Then we will get a failing test and make sure we fix
    #        get_reserved_names() to return the right attributes.
    assert 'role_name' in _RESERVED_NAMES

# Generated at 2022-06-25 14:34:29.816742
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES


# Generated at 2022-06-25 14:34:37.122885
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:34:46.252314
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(
        ['hosts', 'name', 'vars', 'contains', 'when', 'meta', 'tasks', 'with_items', 'register',
         'connection', 'delegate_to', 'include', 'any_errors_fatal', 'serial', 'environment',
         'no_log', 'become_user', 'ignore_errors', 'local_action', 'tags', 'vars_prompt', 'pre_tasks',
         'post_tasks', 'notify', 'handlers', 'gather_facts', 'roles', 'any_errors_fatal',
         'vars_files', 'tasks', 'tasks_from', 'vars_files_from', 'hosts', 'ignore_errors'])


# Generated at 2022-06-25 14:34:48.282001
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = 'action'
    var_0 = get_reserved_names(str_0)
    str_1 = 'variable'
    var_1 = get_reserved_names(str_1)

# Generated at 2022-06-25 14:34:50.316777
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == get_reserved_names(True)


# Generated at 2022-06-25 14:34:56.099199
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test case #0
    str_0 = ' eH'
    var_0 = get_reserved_names(str_0)

    try:
        assert 'get_reserved_names' in globals()
    except AssertionError:
        display.error('Function not found: {}'.format('get_reserved_names'))
        raise

# Generated at 2022-06-25 14:34:56.986997
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(False) is not None


# Generated at 2022-06-25 14:35:05.974551
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:35:12.288470
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_2 = 'kUH'
    var_2 = get_reserved_names(str_2)

# Generated at 2022-06-25 14:35:20.425455
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed