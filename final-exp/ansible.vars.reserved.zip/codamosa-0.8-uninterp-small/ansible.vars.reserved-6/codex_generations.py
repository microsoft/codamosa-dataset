

# Generated at 2022-06-25 14:26:22.726745
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check that get_reserved_names returns a list.
    assert isinstance(get_reserved_names(), frozenset)


# Generated at 2022-06-25 14:26:31.569228
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:38.331498
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # perform unit test utilizing pytest

    var_0 = get_reserved_names()
    var_1 = get_reserved_names(True)

    # assert if var_0 is not a set
    try:
        assert(isinstance(var_0, set))
    except AssertionError as e:
        print("Expected a set object, Recieved object of type: " + type(var_0).name)

    # assert if var_0 is not a set
    try:
        assert(isinstance(var_1, set))
    except AssertionError as e:
        print("Expected a set object, Recieved object of type: " + type(var_0).name)

    # check the length of the set to ensure that the correct number of values were returned

# Generated at 2022-06-25 14:26:46.623518
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:47.491913
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()



# Generated at 2022-06-25 14:26:56.558031
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:04.278432
# Unit test for function get_reserved_names
def test_get_reserved_names():
    name = (('var1', 'var2', 'var3', 'var4'))

    # set variable var1
    var1 = ({'var1': 'var1'})
    # set variable var2
    var2 = ({'var2': 'var2'})
    # set variable var3
    var3 = ({'var3': 'var3'})
    # set variable var4
    var4 = ({'var4': 'var4'})

    # call get_reserved_names() with required argument and optional argument
    # (not defined)
    var_0 = get_reserved_names(False)

    # call get_reserved_names() with required argument and optional argument
    # (defined)
    var_1 = get_reserved_names(True)

    # check that the function works correctly

# Generated at 2022-06-25 14:27:05.565581
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()
__name__ = '__main__'

# Generated at 2022-06-25 14:27:06.969951
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: test not implemented
    pass


# Generated at 2022-06-25 14:27:12.779956
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['first_available_file', 'first_available_filepath', 'groups', 'inventory_hostname', 'inventory_hostname_short', 'inventory_hostname_short', 'is_localhost', 'item', 'omit', 'playbook_dir', 'play_hosts', 'play_hosts_all', 'play_role_names', 'play_path', 'play_name', 'tags'])

# Generated at 2022-06-25 14:27:28.786975
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['gather_facts', 'connection', 'name', 'remote_user', 'no_log', 'sudo', 'sudo_user', 'tags', 'become', 'become_method', 'become_user', 'check_mode', 'hosts', 'any_errors_fatal', 'serial', 'max_fail_percentage'])


# Generated at 2022-06-25 14:27:30.100176
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names('include_private'), set)


# Generated at 2022-06-25 14:27:33.345204
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bool_0 = False
    bool_1 = True
    var_0 = get_reserved_names(bool_0)
    bool_0 = False
    var_1 = get_reserved_names(bool_0)
    bool_0 = True
    var_2 = get_reserved_names(bool_0)


# Generated at 2022-06-25 14:27:41.710736
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:50.652121
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:54.780888
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:59.920151
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(('include', 'connection', 'post_tasks', 'gather_facts', 'pre_tasks', 'roles', 'vars', 'tags', 'any_errors_fatal', 'hosts', 'tasks', 'register', 'ignore_errors', 'notify', 'become', 'environment', 'no_log', 'name', 'local_action', 'when', 'become_user'))


# Generated at 2022-06-25 14:28:00.672094
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) != 0

# Generated at 2022-06-25 14:28:05.131805
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_2 = get_reserved_names()

# Generated at 2022-06-25 14:28:07.022764
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert isinstance(names, set)
    assert len(names) > 0


# Generated at 2022-06-25 14:28:32.223052
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bool_0 = False

    var_0 = get_reserved_names(bool_0)
    var_1 = get_reserved_names(bool_0)



# Generated at 2022-06-25 14:28:32.898555
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not get_reserved_names()

# Generated at 2022-06-25 14:28:38.383373
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:46.329071
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:54.665508
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:02.837700
# Unit test for function get_reserved_names
def test_get_reserved_names():
    myvars = dict(name="bar", with_items=["s1", "s2"], action="foo",
                  local_action="foo", debug="msg", register="shell_out",
                  changed_when="True")

# Generated at 2022-06-25 14:29:03.639956
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: this needs tests
    pass

# Generated at 2022-06-25 14:29:04.741105
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() is not None


# Generated at 2022-06-25 14:29:12.224405
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'debug' in get_reserved_names()
    assert 'async' in get_reserved_names()
    assert 'connection' in get_reserved_names()
    assert 'sudo' in get_reserved_names()
    assert 'sudo_user' in get_reserved_names()
    assert 'environment' in get_reserved_names()
    assert 'poll' in get_reserved_names()
    assert 'tags' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()
    assert 'always_run' in get_reserved_names()
    assert 'serial' in get_reserved_names()

# Generated at 2022-06-25 14:29:13.595269
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()
    assert get_reserved_names(include_private=False)



# Generated at 2022-06-25 14:30:04.719453
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not get_reserved_names(False).intersection(['with_', 'when', 'tags', 'post_tasks', 'vars', 'roles'])



# Generated at 2022-06-25 14:30:05.767501
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print(get_reserved_names())



# Generated at 2022-06-25 14:30:13.678455
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:14.955488
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(None) == get_reserved_names(True)


# Generated at 2022-06-25 14:30:16.094347
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: not sure how to test this...
    pass


# Generated at 2022-06-25 14:30:19.640261
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print('Testing get_reserved_names')
    if get_reserved_names() == get_reserved_names(False):
        print('get_reserved_names() returns correctly')
    else:
        print('get_reserved_names() does not return correctly')


# Generated at 2022-06-25 14:30:20.807182
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)

# Generated at 2022-06-25 14:30:28.852821
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Check for unittest_playbook.playbook_examples.play_0
    expected = ['block', 'connection', 'file', 'gather_facts', 'hosts', 'name', 'roles', 'serial', 'strategy', 'tasks', 'vars', 'any_errors_fatal', 'delegate_to', 'delegate_facts', 'import_role', 'include', 'include_role', 'include_tasks', 'meta', 'pre_tasks', 'post_tasks', 'tags', 'become', 'become_user', 'become_method', 'environment', 'register', 'ignore_errors', 'sudo', 'sudo_user', 'sudo_pass', 'transport', 'remote_user', 'remote_pass', 'remote_port', 'private', 'local_action', 'vars_files']

# Generated at 2022-06-25 14:30:36.491566
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:38.691038
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names().__contains__('local_action')
    assert get_reserved_names().__contains__('delegate_facts')


# Generated at 2022-06-25 14:32:27.806524
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:34.447265
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Function should return the union of public and private attributes
    # without include_private parameter
    reserved_names = get_reserved_names(include_private=False)

# Generated at 2022-06-25 14:32:41.486428
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:50.222986
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:51.335840
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'name' in names


# Generated at 2022-06-25 14:32:52.188558
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test case 1
    # FIXME
    pass



# Generated at 2022-06-25 14:32:58.867722
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = set()
    var_0.add('local_action')
    var_0.add('block')
    var_0.add('tasks')
    var_0.add('vars')
    var_0.add('gather_facts')
    var_0.add('with_')
    var_0.add('loop')
    var_0.add('when')
    var_0.add('action')
    var_0.add('any_errors_fatal')
    var_0.add('max_fail_percentage')
    var_0.add('serial')
    var_0.add('post_tasks')
    var_0.add('handlers')
    var_0.add('tasks')
    var_0.add('name')

# Generated at 2022-06-25 14:33:00.006927
# Unit test for function get_reserved_names
def test_get_reserved_names():
    warning_0 = get_reserved_names()
    print("warning_0 = ", warning_0)

# Generated at 2022-06-25 14:33:04.232693
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)
    assert len(reserved) > 2
    assert 'action' in reserved
    assert 'when' in reserved
    assert 'loop' not in reserved
    assert 'become' in reserved

    reserved = get_reserved_names(include_private=False)
    assert isinstance(reserved, set)
    assert len(reserved) > 2
    assert 'action' in reserved
    assert 'when' in reserved
    assert 'loop' not in reserved
    assert 'become' in reserved

# Generated at 2022-06-25 14:33:13.061911
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    if 'loop' in private or 'loop' in public:
        public.add('with_')

    # result