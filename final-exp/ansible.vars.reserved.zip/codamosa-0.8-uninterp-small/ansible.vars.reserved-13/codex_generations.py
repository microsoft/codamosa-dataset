

# Generated at 2022-06-25 14:26:17.133942
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Run unit test for function get_reserved_names
    results = get_reserved_names()
    assert 'any_errors_fatal' in results
    assert 'connection' in results
    assert 'remote_user' in results
    assert 'name' in results


# Generated at 2022-06-25 14:26:26.006463
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == set(['connection', 'gather_facts', 'hosts', 'ignore_errors', 'name', 'port', 'remote_user', 'remote_pass', 'roles', 'serial', 'sudo', 'sudo_user', 'sudo_pass', 'user', 'vars', 'vars_prompt', 'vars_files', 'vars_file', 'local_action', 'with_', 'any_errors_fatal', 'max_fail_percentage', 'action', 'loop', 'serial', 'until', 'retries', 'delay', 'first_available_file'])

# Generated at 2022-06-25 14:26:34.397097
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:36.458534
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert 'hosts' in get_reserved_names()


# Generated at 2022-06-25 14:26:42.248803
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Setup
    expected_dict_0 = dict(include_private=True)
    expected_dict_1 = dict(include_private=False)

    # Test calls
    result_0 = get_reserved_names()
    result_1 = get_reserved_names(**expected_dict_0)
    result_2 = get_reserved_names(**expected_dict_1)

    # Verify
    assert(result_0)
    assert(result_1)
    assert(result_2)


# Generated at 2022-06-25 14:26:50.139835
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:53.610055
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert 'include_role' in var_0
    assert 'nocompile' in var_0
    assert 'vars' in var_0
    assert 'with_' in var_0
    # FIXME
    # assert 'execution_strategy' in var_0


# Generated at 2022-06-25 14:26:56.970876
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Run a test for all cases
    result1 = get_reserved_names()
    result2 = get_reserved_names(True)

    assert result1 == result2



# Generated at 2022-06-25 14:27:04.682948
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:06.931765
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Method 1
    # Simple test for size
    assert(len(get_reserved_names()) > 0)


# Generated at 2022-06-25 14:27:18.707333
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_cases = [0]
    for test_case in test_cases:
        print("Test case " + str(test_case) + ":")
        if test_case == 0:
            test_case_0()

# Generated at 2022-06-25 14:27:24.994354
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:26.519810
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: make testing for reserved names more robust.
    var_1 = get_reserved_names()
    assert 'block' in var_1

# Generated at 2022-06-25 14:27:28.855405
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This test will fail with no test cases. To get the test working add one or more test cases to the test case list
    test_case_0()


# Run all unit tests

# Generated at 2022-06-25 14:27:36.793566
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:43.922505
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()

# Generated at 2022-06-25 14:27:52.493142
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert isinstance(var_0, set)
    assert 'any_errors_fatal' in var_0
    assert 'remote_user' in var_0
    assert 'roles' not in var_0
    assert 'name' not in var_0
    assert 'when' not in var_0
    var_1 = get_reserved_names(include_private=False)
    assert isinstance(var_1, set)
    assert 'any_errors_fatal' in var_1
    assert 'remote_user' in var_1
    assert 'roles' not in var_1
    assert 'name' not in var_1
    assert 'when' not in var_1
    assert 'vars' in var_1
    assert 'hosts' in var_1

# Generated at 2022-06-25 14:27:54.659590
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert isinstance(var_0, set)
    assert len(var_0)>0
    var_1 = get_reserved_names(include_private=False)
    assert isinstance(var_1, set)
    assert len(var_1)>0


# Generated at 2022-06-25 14:27:58.430429
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset({'environment', 'name', 'localhost', 'gather_facts', 'tasks', 'handlers', 'connection', 'vars', 'pre_tasks', 'roles', 'post_tasks', 'tags', 'hosts'})


# Generated at 2022-06-25 14:28:06.564213
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:23.969117
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == None


# Generated at 2022-06-25 14:28:24.962864
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()



# Generated at 2022-06-25 14:28:31.545815
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:37.050730
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:39.155764
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'roles' in reserved_names
    assert 'vars' in reserved_names



# Generated at 2022-06-25 14:28:42.246496
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check 'include_private' argument not present
    try:
        test_case_0()
        test_failed = False
    except TypeError:
        test_failed = True
    assert not test_failed, 'Argument \'include_private\' not found'


# Generated at 2022-06-25 14:28:49.595595
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:57.976380
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:06.488934
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:07.815802
# Unit test for function get_reserved_names
def test_get_reserved_names():
    name = get_reserved_names()
    assert isinstance(name, set)


# Generated at 2022-06-25 14:29:49.255592
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Code from Ansible @ 775957e9c92f1f8d8d7edc78b57a7c1276cfd8bb
    assert len(get_reserved_names()) > 0


# Generated at 2022-06-25 14:29:56.440864
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:58.270069
# Unit test for function get_reserved_names
def test_get_reserved_names():
    with open('ansible/playbook/__tests__/data/get_reserved_names_output.txt', 'r') as f:
        test_data = f.read()
    assert test_data == str(get_reserved_names())

# Generated at 2022-06-25 14:29:59.760099
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(type(get_reserved_names()) == set)
    assert(get_reserved_names() == _RESERVED_NAMES)


# Generated at 2022-06-25 14:30:07.666537
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Testing get_reserved_names with given test cases
    result = get_reserved_names()

# Generated at 2022-06-25 14:30:08.812911
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) is set


# Generated at 2022-06-25 14:30:10.763782
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    # This is a type test, not a value test
    assert isinstance(var_0, set)



# Generated at 2022-06-25 14:30:17.650895
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get_reserved_names should return a set
    var_1 = get_reserved_names()
    assert isinstance(var_1, frozenset)
    # get_reserved_names should return a set containing 'delegate_to'
    var_2 = get_reserved_names()
    assert 'delegate_to' in var_2
    # get_reserved_names should return a set containing 'with_'
    var_3 = get_reserved_names()
    assert 'with_' in var_3
    # get_reserved_names should return a set containing 'vars'
    var_4 = get_reserved_names()
    assert 'vars' in var_4


# Generated at 2022-06-25 14:30:20.812063
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names(False)
    assert 'hosts' in var_0
    assert 'name' in var_0
    assert 'vars' in var_0
    assert 'private' not in var_0


# Generated at 2022-06-25 14:30:22.123731
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: how to test?
    pass


# Generated at 2022-06-25 14:31:05.564630
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test case for get_reserved_names '''

    reserved_names = get_reserved_names()
    assert 'remote_user' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'with_' in reserved_names
    assert 'hosts' in reserved_names
    assert 'local_action' in reserved_names
    assert 'any_errors_fatal' in reserved_names
    assert 'notify' in reserved_names
    assert 'roles' in reserved_names
    assert 'block' in reserved_names
    assert 'sudo_user' in reserved_names
    assert 'connection' in reserved_names
    assert 'include' in reserved_names
    assert 'vars_prompt' in reserved_names
    assert 'when' in reserved_names

# Generated at 2022-06-25 14:31:11.375340
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'any_errors_fatal', 'block', 'changed_when', 'connection', 'delegate_to',
                                    'delegate_facts', 'environment', 'error_on_undefined_vars', 'failed_when',
                                    'first_available_file', 'groups', 'hosts', 'ignore_errors', 'include',
                                    'include_tasks', 'include_vars', 'local_action', 'loop', 'loop_control', 'name',
                                    'no_log', 'notify', 'pre_tasks', 'register', 'remote_user', 'roles', 'serial',
                                    'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'when'}



# Generated at 2022-06-25 14:31:19.182926
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:27.664138
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: replace the test with pytest.test
    print("Testing get_reserved_names...")
    assert type(frozenset()) == type(get_reserved_names())
    assert type(frozenset()) == type(get_reserved_names(include_private=False))
    assert type(type('')) == type(get_reserved_names().pop())
    assert type(type('')) == type(get_reserved_names(include_private=False).pop())
    # TODO: add a more rigorous test
    #assert frozenset(['action', 'async', 'become', 'become_user', 'become_method', 'block', 'connection', 'delegate_to', 'environment', 'failed_when', 'gather_facts', 'handlers', 'ignore_errors', 'include

# Generated at 2022-06-25 14:31:34.165120
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:36.633805
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = ':'
    str_1 = frozenset(str_0)
    res_0 = get_reserved_names(str_1)
    assert res_0 != None


# Generated at 2022-06-25 14:31:43.893633
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:46.033958
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    print("Reserved names: {}".format(reserved_names))
    assert(len(reserved_names) > 0)


# Generated at 2022-06-25 14:31:51.915986
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # specify keys and values to test
    data_0 = ':'
    data_1 = ':5'
    data_2 = ':5.5'
    data_3 = ':true'
    data_4 = ':[]'
    data_5 = ':{}'


    # call function with arguments
    result_0 = get_reserved_names(data_0)
    result_1 = get_reserved_names(data_1)
    result_2 = get_reserved_names(data_2)
    result_3 = get_reserved_names(data_3)
    result_4 = get_reserved_names(data_4)
    result_5 = get_reserved_names(data_5)

    # assert return values

# Generated at 2022-06-25 14:31:54.216631
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """
    Test the get_reserved_names function
    """
    str_0 = ':'
    var_0 = get_reserved_names(str_0)
    assert var_0 == True


# Generated at 2022-06-25 14:33:12.142264
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert result is not None

# Generated at 2022-06-25 14:33:13.941508
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_0 = get_reserved_names(include_private=True)
    assert True

# Generated at 2022-06-25 14:33:15.374114
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test with the following string
    var_0 = get_reserved_names()


# Generated at 2022-06-25 14:33:16.301459
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names())


# Generated at 2022-06-25 14:33:17.436227
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()

# Generated at 2022-06-25 14:33:19.180041
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=True)


# Generated at 2022-06-25 14:33:23.812068
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test with keyword 'include_private set to False
    result = get_reserved_names(include_private=False)

    assert 'private' not in result
    assert 'non_private' in result

    # test with keyword 'include_private set to True
    result = get_reserved_names(include_private=True)
    assert 'private' in result
    assert 'non_private' in result


# Generated at 2022-06-25 14:33:25.100124
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = ':'
    var_0 = get_reserved_names(str_0)


# Generated at 2022-06-25 14:33:29.271406
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'attributes', 'connection', 'delegate_to', 'ignore_errors', 'local_action', 'loop', 'name', 'notify', 'register', 'retries', 'run_once', 'sudo', 'sudo_user', 'tags', 'task_action', 'with_', 'when'}


# Generated at 2022-06-25 14:33:30.634401
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not(get_reserved_names().intersection(['var1', 'var2','var3']))


# Generated at 2022-06-25 14:36:08.118420
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = True
    var_0 = get_reserved_names(var_1)
    assert 'inventory' in var_0
    assert 'name' in var_0
    assert 'host_vars' in var_0
    assert 'hosts' in var_0
    assert 'playbook' in var_0
    assert 'vars' in var_0
    assert 'gather_facts' in var_0
    assert 'include' in var_0
    assert 'include_vars' in var_0
    assert 'include_tasks' in var_0
    assert 'include_role' in var_0
    assert 'import_playbook' in var_0
    assert 'import_role' in var_0
    assert 'roles' in var_0
    assert 'tasks' in var_0
   