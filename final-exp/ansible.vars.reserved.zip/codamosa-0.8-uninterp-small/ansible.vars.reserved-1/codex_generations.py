

# Generated at 2022-06-25 14:26:23.457022
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test case 1
    test_case_1 = get_reserved_names(False)
    # Test case 2
    test_case_2 = get_reserved_names()



# Generated at 2022-06-25 14:26:32.303451
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1_actual = get_reserved_names()

# Generated at 2022-06-25 14:26:35.765215
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test_playbook_reserved_names.py:test_get_reserved_names()'''

    # Test if 'hosts' is in reserved_names
    assert 'hosts' in get_reserved_names()
    assert not get_reserved_names(include_private=False) >= frozenset(['hosts'])


# Generated at 2022-06-25 14:26:37.186160
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_var = get_reserved_names()
    assert type(test_var) is frozenset



# Generated at 2022-06-25 14:26:38.017247
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == var_0

# Generated at 2022-06-25 14:26:46.324711
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:54.865233
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['action', 'block', 'block_children', 'block_parents', 'cluster_host', 'delegate_facts', 'delegate_to', 'delegated_vars', 'first_available_file', 'first_found', 'hosts', 'ignore_errors', 'ignore_unreachable', 'include', 'include_vars', 'inventory_hostname', 'inventory_hostname_short', 'item', 'loop', 'loop_control', 'name', 'notify', 'register', 'roles', 'stat', 'subset', 'tags', 'tasks', 'when', 'with_', 'with_*', 'with_*items', 'with_*lookup', 'with_*only_if', 'with_*when'])

# Generated at 2022-06-25 14:27:03.034490
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:12.779531
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:15.307732
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)
    assert len(reserved_names) > 0
    assert "when" in reserved_names


# Generated at 2022-06-25 14:27:36.837977
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)


# Generated at 2022-06-25 14:27:37.743503
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()

# Generated at 2022-06-25 14:27:44.503233
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:53.000247
# Unit test for function get_reserved_names
def test_get_reserved_names():

    var_0 = get_reserved_names()
    assert isinstance(var_0, frozenset), "get_reserved_names() returned incorrect variable type. Should be frozenset, returned %s" % type(var_0)
    assert len(var_0) == 22, "get_reserved_names() returned incorrect variable length. Should be 22, returned %d" % len(var_0)
    assert 'accelerate' in var_0, "get_reserved_names() returned incorrect variable data. Fails to return 'accelerate' in output"
    assert 'tags' in var_0, "get_reserved_names() returned incorrect variable data. Fails to return 'tags' in output"

# Generated at 2022-06-25 14:27:54.126071
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("Testing the function get_reserved_names with input:")
    var_0 = get_reserved_names()


# Generated at 2022-06-25 14:27:57.337119
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'include' in reserved_names
    assert 'private' not in reserved_names
    assert 'vars' in reserved_names
    assert 'private' in get_reserved_names(include_private=True)

# Generated at 2022-06-25 14:28:05.156559
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:06.443557
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) == frozenset

# Generated at 2022-06-25 14:28:09.213535
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()
    var_2 = get_reserved_names()
    for var_3 in var_2:
        if var_3 in var_1:
            pass
        else:
            assert False


# Generated at 2022-06-25 14:28:11.585236
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Test case for the function get_reserved_names()
    # function generates the reserved names for a play object or role object

    result_0 = get_reserved_names()
    print(result_0)



# Generated at 2022-06-25 14:28:46.203165
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Case 0
    test_case_0()

# Generated at 2022-06-25 14:28:52.048571
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        assert test_case_0() == frozenset(('nocows', 'async_poll_interval', 'async_status_timeout', 'private', 'block', 'hosts', 'serial', 'role_names', 'with_items', 'roles', 'name', 'tasks', 'action', 'post_tasks', 'loop_control', 'block_list', 'vars', 'tasks_list', 'tags', 'playbook', 'vars_prompt', 'role_path'))
    except:
        display.error('test_get_reserved_names failed')



# Generated at 2022-06-25 14:28:56.241885
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert var_0 != [], "Failed to return a list of reserved names"
    assert isinstance(var_0, list) is True, "Failed to return a list of reserved names"
    assert len(var_0) > 0, "Failed to return a list of reserved names"


# Generated at 2022-06-25 14:29:04.109773
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names(include_private=True)
    var_1 = get_reserved_names(include_private=False)
    var_2 = get_reserved_names(include_private=False)

    assert var_1 == var_2
    assert isinstance(var_0, set)
    assert isinstance(var_1, set)
    assert isinstance(var_2, set)
    assert var_0.issubset(_RESERVED_NAMES)
    assert not var_0.isdisjoint(_RESERVED_NAMES)
    assert var_1.issubset(_RESERVED_NAMES)
    assert not var_1.isdisjoint(_RESERVED_NAMES)


# Generated at 2022-06-25 14:29:06.042247
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'tags' in get_reserved_names()
    assert 'var_0' in get_reserved_names()


# Generated at 2022-06-25 14:29:08.512086
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Setup
    test_dict = {'some_var': 'foo'}
    test_dict['vars'] = get_reserved_names()

    # Tests
    warn_if_reserved(test_dict)


# Generated at 2022-06-25 14:29:12.077617
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_cases = [
        [0],
        ]

    for test_case in test_cases:
        local_vars = locals()
        exec('test_case_%d()' % test_case[0], globals(), local_vars)
        assert(local_vars['var_%d' % test_case[0]])


# Generated at 2022-06-25 14:29:20.505712
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:28.784824
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """
    Test that the function returns the same hard coded list
    """

# Generated at 2022-06-25 14:29:35.314778
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = list(get_reserved_names())
    var_1 = list(get_reserved_names(False))

# Generated at 2022-06-25 14:30:15.625277
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: get something real
    expected = None
    actual = get_reserved_names()
    assert actual == expected


# Generated at 2022-06-25 14:30:24.705765
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'action', 'become', 'become_flags', 'become_method', 'become_user', 'block', 'block:', 'changed_when', 'connection', 'delegate_facts', 'delegate_to', 'deprecate', 'deprecated', 'deprecated_args', 'environment', 'environment_variables', 'failed_when', 'gather_facts', 'group_by', 'ignore_errors', 'loop', 'loop_control', 'meta', 'notify', 'omit', 'post_validate', 'pre_tasks', 'pre_validate', 'private', 'provider', 'register', 'remote_user', 'roles', 'run_once', 'serial', 'tags', 'tasks', 'when', 'with_'}

# Generated at 2022-06-25 14:30:25.741060
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # load case input data
    case_0 = test_case_0()


# Generated at 2022-06-25 14:30:33.084233
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:37.140865
# Unit test for function get_reserved_names
def test_get_reserved_names():
    for attr in ['action', 'local_action', 'loop']:
        assert attr in _RESERVED_NAMES

    for attr in ['name', 'vars', 'roles']:
        assert attr in _RESERVED_NAMES

    for attr in ['transport', 'delegate_to']:
        assert attr in _RESERVED_NAMES



# Generated at 2022-06-25 14:30:38.629997
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()
    assert len(var_1) > 0


# Generated at 2022-06-25 14:30:45.683337
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:47.240074
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Variables used in testing this function
    var_0 = get_reserved_names()

    # Test results
    assert var_0 is not None


# Generated at 2022-06-25 14:30:48.319985
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) is frozenset



# Generated at 2022-06-25 14:30:49.841047
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) == set
    assert type(get_reserved_names(include_private=False)) == set


# Generated at 2022-06-25 14:31:33.059032
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bool_0 = get_reserved_names(include_private=True)
    bool_1 = get_reserved_names(include_private=True)
    assert bool_0 == bool_1


# Generated at 2022-06-25 14:31:37.604583
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:42.176722
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Always include private names
    names = get_reserved_names(True)
    assert isinstance(names, frozenset)
    assert 'local_action' in names
    assert 'with_' in names

    # Do not include private names (deprecated)
    names = get_reserved_names(False)
    assert isinstance(names, frozenset)
    assert 'local_action' in names
    assert 'with_' in names


# Generated at 2022-06-25 14:31:46.757619
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset({'connection', 'environment', 'gather_facts', 'hosts', 'name', 'no_log', 'register', 'roles', 'serial', 'tags', 'vars'})
    assert get_reserved_names(include_private=True) == frozenset({'connection', 'environment', 'gather_facts', 'hosts', 'name', 'no_log', 'register', 'roles', 'serial', 'tags', 'vars', 'private'})


# Generated at 2022-06-25 14:31:53.751296
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:54.972557
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names(False)) == 12
    assert len(get_reserved_names(True)) == 26



# Generated at 2022-06-25 14:31:57.232115
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bool_0 = None
    var_0 = get_reserved_names(bool_0)
    var_1 = get_reserved_names(bool_0, bool_0)
    var_2 = get_reserved_names(bool_0, bool_0, bool_0)


# Generated at 2022-06-25 14:32:05.781948
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:07.256624
# Unit test for function get_reserved_names
def test_get_reserved_names():
    vars_reserved_names = get_reserved_names()
    assert 'action' in vars_reserved_names
    assert 'ignore_unreachable' in vars_reserved_names
    assert 'sudo_user' in vars_reserved_names



# Generated at 2022-06-25 14:32:13.117142
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bool_0 = None
    var_0 = get_reserved_names(bool_0)
    bool_1 = None
    var_1 = get_reserved_names(bool_1)
    bool_2 = None
    var_2 = get_reserved_names(bool_2)
    bool_3 = None
    var_3 = get_reserved_names(bool_3)
    bool_4 = None
    var_4 = get_reserved_names(bool_4)
    bool_5 = None
    var_5 = get_reserved_names(bool_5)
    bool_6 = None
    var_6 = get_reserved_names(bool_6)
    bool_7 = None
    var_7 = get_reserved_names(bool_7)
    bool_8 = None


# Generated at 2022-06-25 14:33:40.711070
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:42.051109
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This function returns an ordered list.
    assert len(get_reserved_names()) > 0


# Generated at 2022-06-25 14:33:43.568544
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bool_0 = get_reserved_names()
    var_0 = set()
    assert bool_0 == var_0


# Generated at 2022-06-25 14:33:50.523525
# Unit test for function get_reserved_names
def test_get_reserved_names():
    class_0 = get_reserved_names()
    class_1 = get_reserved_names(include_private=False)
    var_0 = is_reserved_name("environment")
    var_1 = is_reserved_name("action")
    var_2 = is_reserved_name("private")
    var_3 = is_reserved_name("any_errors_fatal")
    var_4 = is_reserved_name("notify")
    var_5 = is_reserved_name("handlers")
    var_6 = is_reserved_name("delegate_to")
    var_7 = is_reserved_name("post_validate")
    var_8 = is_reserved_name("action")
    var_9 = is_reserved_name("tasks")
    var_

# Generated at 2022-06-25 14:33:51.684279
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bool_0 = None
    var_0 = get_reserved_names()



# Generated at 2022-06-25 14:33:57.375302
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = ['connection', 'hosts', 'ignore_unreachable', 'max_fails', 'name', 'remote_user', 'roles', 'serial', 'sudo_user', 'tasks', 'vars', 'vars_files', 'when']
    private = ['delegate_to', 'gather_facts', 'gather_subset', 'other_vars', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'block', 'delegate_facts', 'first_available_file', 'force_handlers', 'no_log', 'poll', 'sudo', 'sudo_pass', 'tags', 'transport', 'vault_password_file']


# Generated at 2022-06-25 14:34:01.026030
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_cases = [
        dict(),
        dict(include_private=True),
        dict(include_private=False),

    ]
    for test_case in test_cases:
        get_reserved_names(**test_case)



# Generated at 2022-06-25 14:34:08.089898
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Arguments:
    #    include_private: [bool] Include or exclude private reserved names
    # Returns:
    #   set: All reserved names
    set_0 = frozenset(['delegate_to', 'remote_user', 'sudo_user', 'no_log', 'connection', 'sudo', 'environment', 'action', 'vars', 'name', 'su', 'local_action', 'with_', 'block', 'any_errors_fatal', 'always_run', 'register', 'ignore_errors', 'delegate_facts', 'changed_when'])
    set_1 = frozenset(['hosts', 'become', 'gather_facts'])

    var_0 = get_reserved_names(set_0) == set_1

# Generated at 2022-06-25 14:34:17.578407
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:34:19.051064
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bool_0 = None
    var_0 = get_reserved_names(bool_0)
    var_1 = get_reserved_names(True)

