

# Generated at 2022-06-25 14:26:17.352035
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = 'Fz4|gcGwosB\nP'
    var_0 = get_reserved_names(str_0)
    assert var_0 == 'dockers'


# Generated at 2022-06-25 14:26:20.041822
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: this test is not really useful, it calls 'get_reserved_names' once and then does nothing

    test_case_0()


# Generated at 2022-06-25 14:26:22.001286
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # TODO: Update tests to work with module path
    # print(get_reserved_names())
    assert True == True


# Generated at 2022-06-25 14:26:23.406252
# Unit test for function get_reserved_names
def test_get_reserved_names():
    myvar = get_reserved_names(True)
    assert myvar is not None


# Generated at 2022-06-25 14:26:30.099505
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == set(['tags', 'hosts', 'vars', 'tasks', 'name', 'local_action', 'action', 'roles','with_','loop','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block','block'])

test_case_0()
test_get_reserved_names()

# Generated at 2022-06-25 14:26:37.185110
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = 'Fz4|gcGwosB\nP'
    var_0 = get_reserved_names(str_0)

# Generated at 2022-06-25 14:26:41.446298
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = 'Bf_6Y#C6T'
    str_1 = 'a.or^3,Li'
    var_0 = get_reserved_names(str_0)
    var_1 = get_reserved_names(str_1)
    assert var_0 == var_1


# Generated at 2022-06-25 14:26:45.264560
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names_default = get_reserved_names()
    assert 'vars' in reserved_names_default

    reserved_names_all = get_reserved_names(include_private=True)
    assert 'vars' in reserved_names_all

    assert len(reserved_names_all) > len(reserved_names_default)



# Generated at 2022-06-25 14:26:49.366515
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Run tests against the following inputs.
    # The expected result is the last element in the tuple.
    inputs = [
        (True, ),
        (False, ),
    ]

    # Run the function as expected.
    for inp in inputs:
        assert get_reserved_names(*inp) == inp[-1], "Expected result does not match."


# Generated at 2022-06-25 14:26:52.322206
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check for reserved names
    var_string = 'Fz4|gcGwosBP'
    var_check = get_reserved_names(var_string)
    print (var_check)

if __name__ == "__main__":
    test_get_reserved_names()

# Generated at 2022-06-25 14:27:08.910790
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:11.379410
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == get_reserved_names(True)


# Generated at 2022-06-25 14:27:19.010318
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == set(['any_errors_fatal', 'block', 'block_encryption', 'check_mode', 'connection', 'environment', 'force_handlers', 'gather_facts',
                                        'handler', 'ignore_errors', 'name', 'no_log', 'post_tasks', 'pre_tasks', 'precedence', 'remote_user', 'roles', 'serial',
                                        'strategy', 'su', 'su_user', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars', 'when', 'when_changed', 'with_items',
      'with_subelements', 'with_unquoted'])



# Generated at 2022-06-25 14:27:20.669907
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert names is not None
    assert len(names) > 0


# Generated at 2022-06-25 14:27:21.427232
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:27:22.236519
# Unit test for function get_reserved_names
def test_get_reserved_names():
    return get_reserved_names()


# Generated at 2022-06-25 14:27:23.518903
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print(get_reserved_names())


# Generated at 2022-06-25 14:27:31.000738
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:35.617241
# Unit test for function get_reserved_names
def test_get_reserved_names():

    #
    # test case 1
    #
    bytes_1 = b'\xba\xee\x9dL\xd4\xdb!\x04ap\xc2'
    expected_1 = b'\xba\xee\x9dL\xd4\xdb!\x04ap\xc2'
    var_1 = get_reserved_names(bytes_1)
    assert var_1 == expected_1


# Generated at 2022-06-25 14:27:43.140293
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_variable = get_reserved_names(True)

# Generated at 2022-06-25 14:28:01.758861
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)

# Generated at 2022-06-25 14:28:03.016467
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False)



# Generated at 2022-06-25 14:28:05.962952
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\xba\xee\x9dL\xd4\xdb!\x04ap\xc2'
    var_0 = get_reserved_names(bytes_0)


# Generated at 2022-06-25 14:28:08.720870
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\xba\xee\x9dL\xd4\xdb!\x04ap\xc2'
    var_0 = get_reserved_names(bytes_0)
    assert type(var_0) is set



# Generated at 2022-06-25 14:28:09.745171
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)


# Generated at 2022-06-25 14:28:16.903381
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.playbook import Task, Role, TaskInclude, Block, Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    obj_0 = get_reserved_names()
    assert obj_0 is not None
    assert obj_0 is not False
    assert obj_0 != False
    assert obj_0 != None
    assert obj_0 is True
    assert obj_0 != True
    assert obj_0 != 0


# Generated at 2022-06-25 14:28:20.531976
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test for a bool value
    bool_0 = True
    assert get_reserved_names(bool_0)
    # test for a string
    bytes_0 = b'\xba\xee\x9dL\xd4\xdb!\x04ap\xc2'
    var_0 = warn_if_reserved(bytes_0)


# Generated at 2022-06-25 14:28:22.849031
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names(include_private=False)) is frozenset
    assert type(get_reserved_names(include_private=True)) is frozenset


# Generated at 2022-06-25 14:28:27.632809
# Unit test for function get_reserved_names
def test_get_reserved_names():

    results = get_reserved_names(include_private=True)
    assert isinstance(results, set)
    assert 'hosts' in results
    assert 'pre_tasks' in results
    assert 'roles' in results
    assert 'private' in results

    results = get_reserved_names(include_private=False)
    assert isinstance(results, set)
    assert 'hosts' in results
    assert 'pre_tasks' in results
    assert 'roles' in results
    assert 'private' not in results



# Generated at 2022-06-25 14:28:31.754929
# Unit test for function get_reserved_names
def test_get_reserved_names():
    my_play = Play()
    my_play.vars = dict(key_1 = 'val_1', key_2 = 'val_2')
    my_reserved_names = get_reserved_names(include_private=True)

    # Check if internal names are reserved
    assert 'vars' in my_reserved_names
    # Check if passed names are reserved
    assert not 'key_1' in my_reserved_names
    assert not 'key_2' in my_reserved_names



# Generated at 2022-06-25 14:29:07.465055
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\x94\x90\xec\xce7\xf8\x98\x15\xe9'
    var_0 = get_reserved_names(True)
    var_1 = get_reserved_names(False)


# Generated at 2022-06-25 14:29:08.501449
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()


# Generated at 2022-06-25 14:29:15.032468
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Test with expected values
    assert get_reserved_names(True) == frozenset(['tasks', 'vars', 'notify', 'tags', 'roles', 'block', 'pre_tasks', 'include', 'name', 'post_tasks', 'dynamic', 'connection', 'private', 'when', 'vars_prompt', 'local_action', 'handlers', 'vars_files', 'hosts', 'register', 'with_', 'meta', 'action', 'become_user', 'hosts_prompt', 'become', 'connection_prompt', 'no_log', 'run_once'])

    # Test with edge case parameters

# Generated at 2022-06-25 14:29:20.410518
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_args = ([], [True])
    for args in test_args:
        if args:
            test_params = args[0]
        else:
            test_params = args
        try:
            result = apply(get_reserved_names, test_params)
        except Exception as e:
            display.error('Error with function get_reserved_names.' + 
                          ' Exception: ' + str(e))



# Generated at 2022-06-25 14:29:28.715264
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test for empty argument
    assert get_reserved_names() == {
        'block',
        'connection',
        'delegate_to',
        'notify',
        'with_',
        'action',
        'local_action',
        'any_errors_fatal',
        'always_run',
        'ignore_errors',
        'first_available_file',
        'become',
        'become_method',
        'become_user',
        'diff',
        'environment',
        'no_log',
        'poll',
        'tags',
        'run_once',
        'when'
    }


# Generated at 2022-06-25 14:29:35.225442
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(False) == {'become_method', 'become_user', 'connection', 'delegate_to', 'environment', 'ignore_errors', 'name', 'notify', 'register', 'remote_user', 'tags', 'transport', 'when'}

# Generated at 2022-06-25 14:29:36.580951
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES


# Generated at 2022-06-25 14:29:40.705419
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['role', 'any_errors_fatal', 'block',
                                              'vars', 'action', 'local_action',
                                              'delegate_to', 'become_user',
                                              'hosts', 'become_method', 'loop',
                                              'when', 'roles', 'with_',
                                              'ignore_errors', 'tasks', 'delegate_facts',
                                              'playbook'])


# Generated at 2022-06-25 14:29:45.937098
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:49.173356
# Unit test for function get_reserved_names
def test_get_reserved_names():
    for _ in range(4):
        bytes_0 = b'\xba\xee\x9dL\xd4\xdb!\x04ap\xc2'
        var_0 = get_reserved_names(bytes_0)


# Generated at 2022-06-25 14:31:15.724588
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:17.871462
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()


# Generated at 2022-06-25 14:31:21.599085
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(len(get_reserved_names(include_private=True)) == 42)
    assert(len(get_reserved_names(include_private=False)) == 36)


# Generated at 2022-06-25 14:31:24.521361
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\xba\xee\x9dL\xd4\xdb!\x04ap\xc2'
    var_0 = get_reserved_names()

    assert set(var_0) == set(_RESERVED_NAMES)



# Generated at 2022-06-25 14:31:26.734816
# Unit test for function get_reserved_names
def test_get_reserved_names():
    r = get_reserved_names()

    # assert isinstance(r, set)
    assert type(r) is set
    assert 'role' in r
    assert 'set_fact' in r



# Generated at 2022-06-25 14:31:33.400497
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # case 1
    bytes_0 = b'\xba\xee\x9dL\xd4\xdb!\x04ap\xc2'
    var_1 = get_reserved_names(bytes_0)
    # should be set(['name', 'serial', 'connection', 'remote_user', 'gather_facts', 'sudo', 'sudo_user', 'tags', 'hosts', 'tasks', 'vars', 'vars_files', 'block', 'when', 'roles', 'include', 'include_role', 'environment', 'post_tasks', 'pre_tasks', 'tags', 'any_errors_fatal', 'minimize_serialization', 'no_log', 'notify', 'register', 'remote_user', 'sudo', 'sudo_user', 'run_once', 'changed_when', 'failed_

# Generated at 2022-06-25 14:31:34.790428
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES


# Generated at 2022-06-25 14:31:35.957889
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() is not None


# Generated at 2022-06-25 14:31:43.312067
# Unit test for function get_reserved_names
def test_get_reserved_names():
    vars_0 = {u'ansible_playbook_python': u'/usr/bin/python',
              u'hostvars': {u'localhost': {u'ansible_playbook_python': u'/usr/bin/python',
                                           u'omit': u'X'}},
              u'my_hostname': u'localhost'}
    play_0 = Play()
    play_0._load_vars(vars_0)
    bytes_0 = b'\xba\xee\x9dL\xd4\xdb!\x04ap\xc2'
    result = get_reserved_names(bytes_0)

    # Test case verifies that given no arguments, the names 'async', 'delegate_to',
    # 'register', 'when', 'run_once' are reserved and

# Generated at 2022-06-25 14:31:45.441172
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_dict = dict()
    test_dict['include_private'] = True
    result = get_reserved_names(**test_dict)
    assert result is not None


# Generated at 2022-06-25 14:34:37.731261
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()
    assert get_reserved_names(include_private=True)


# Generated at 2022-06-25 14:34:43.574543
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['roles', 'loop', 'tags', 'block', 'tasks', 'action', 'with_', 'gather_facts', 'any_errors_fatal', 'register', 'delegate_to', 'hosts', 'notify', 'pre_tasks', 'async', 'notify_handler', 'local_action', 'post_tasks'])


# Generated at 2022-06-25 14:34:45.659191
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()

    assert isinstance(names, frozenset)
    assert 'tasks' in names


# Generated at 2022-06-25 14:34:47.736947
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert type(result) is set, "Return type is not set."
    assert len(result) != 0, "Set is empty."


# Generated at 2022-06-25 14:34:48.651073
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(isinstance(get_reserved_names(), frozenset))


# Generated at 2022-06-25 14:34:53.305850
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Call function with wrong argument type and/or length
    try:
        get_reserved_names(include_private='str')
    except Exception as e:
        # Verify that exception message contains correct error
        assert e.args[0] == 'include_private (str) is an invalid value for include_private. Allowed values are: True, False'
    else:
        raise AssertionError("Expected Exception to be raised")


# Generated at 2022-06-25 14:34:56.746582
# Unit test for function get_reserved_names
def test_get_reserved_names():
    #
    # Adding a new reserved name should cause the tests to fail
    #
    # Make sure you add a test case to test_case_0 that exercises
    # the newly added reserved name.
    #
    assert len(get_reserved_names()) == len(_RESERVED_NAMES)
    obj = Play()
    # FIXME: I can't test the result of var_0 in the case of non-serializable strings
    # such as those returned by 'obj.freaky_strings()'
    test_case_0()



# Generated at 2022-06-25 14:34:57.422755
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()

# Generated at 2022-06-25 14:35:03.059193
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(('action', 'any_errors_fatal', 'become', 'delegate_to', 'gather_facts', 'ignore_errors', 'ignore_unreachable', 'local_action', 'loop', 'max_fail_percentage', 'name', 'notify', 'register', 'run_once', 'tags', 'until', 'with_', 'when'))


# Generated at 2022-06-25 14:35:10.752613
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=True)
