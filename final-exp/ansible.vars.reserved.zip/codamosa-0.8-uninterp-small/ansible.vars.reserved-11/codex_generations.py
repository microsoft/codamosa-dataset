

# Generated at 2022-06-25 14:26:22.230005
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        from ansible.playbook import Play
        from ansible.playbook.block import Block
        from ansible.playbook.role import Role
        from ansible.playbook.task import Task
    except ImportError:
        print("No Ansible installed")

    obj1 = Play()
    obj2 = Role()
    obj3 = Block()
    obj4 = Task()

    for obj in [obj1, obj2, obj3, obj4]:
        for attribute in obj.__dict__['_attributes']:
            name = attribute['name']
            assert name in get_reserved_names()

    var_0 = get_reserved_names()
    return var_0



# Generated at 2022-06-25 14:26:23.664345
# Unit test for function get_reserved_names
def test_get_reserved_names():

    result = get_reserved_names()
    assert type(result) == set
    assert len(result) > 0

# Generated at 2022-06-25 14:26:32.512471
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:37.038418
# Unit test for function get_reserved_names
def test_get_reserved_names():
    with open('test_doc_fragments/test_facts.json', 'r') as test_vars_file:
        test_vars = json.load(test_vars_file)
    testobj = my_object()
    assert test_get_reserved_names(testobj, test_vars) == '<return_value>'


# Generated at 2022-06-25 14:26:38.851813
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 60
    assert len(get_reserved_names(include_private=False)) == 47



# Generated at 2022-06-25 14:26:47.034073
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Set up test data
    var_0 = get_reserved_names()

    assert var_0 == frozenset({'become_user','become','su','build_tags','continue_on_error','include','import_playbook','tags','post_tasks','tasks','max_fail_percentage','name','become_flags','connection','any_errors_fatal','role_path','become_pass','tags_regex','handlers','vars_files','special_args','check_mode','default_vars','hosts','roles','pre_tasks','allow_duplicates','ignore_errors','gather_facts','roles_path','vars','host_vars','register','groups','become_method','transport','remote_user','delegate_to'})


# Generated at 2022-06-25 14:26:55.613372
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:57.181693
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 96


# Generated at 2022-06-25 14:27:04.887807
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("\n")
    print("Testing get_reserved_names")
    print("-------------------------")
    print("\n")

    # Test for type of the value returned by get_reserved_names
    assert isinstance(get_reserved_names(), set)

    # Test for function get_reserved_names with include_private == True

# Generated at 2022-06-25 14:27:06.851663
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # second and additional args are always empty
    assert type(get_reserved_names()) is set



# Generated at 2022-06-25 14:27:32.724151
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This test is for function get_reserved_names.
    If a play has a task named "include", this test
    will fail.
    '''
    var_0 = get_reserved_names()


# Generated at 2022-06-25 14:27:41.062273
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:44.289607
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Print the results of the function
    print('\nTest get_reserved_names')
    print('-----------------------')
    print('The returned values are: ')
    print(get_reserved_names())


# Generated at 2022-06-25 14:27:52.808255
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    # test with a play

# Generated at 2022-06-25 14:27:59.820803
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()

# Generated at 2022-06-25 14:28:01.115682
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES, "Unable to return a set of reserved names."


# Generated at 2022-06-25 14:28:05.567145
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names(False)
    assert var_0 == {'action', 'any_errors_fatal', 'async', 'connection', 'delegate_facts', 'delegate_to', 'environment', 'failed_when', 'gather_facts', 'ignore_errors', 'name', 'notify', 'poll', 'register', 'remote_user', 'serial', 'tags', 'transport', 'until', 'vars', 'when', 'with_'}
    var_1 = get_reserved_names()

# Generated at 2022-06-25 14:28:07.247604
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert var_0 is not None
    assert len(var_0) == 63


# Generated at 2022-06-25 14:28:08.870983
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Test case for get_reserved_names function
    '''
    test_case_0()


# Generated at 2022-06-25 14:28:10.431926
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # TODO: change this to only include certain names
    assert_equals(type(get_reserved_names()), frozenset)


# Generated at 2022-06-25 14:28:32.921899
# Unit test for function get_reserved_names
def test_get_reserved_names():
    my_obj = get_reserved_names(include_private=False)
    assert isinstance(my_obj,set)


# Generated at 2022-06-25 14:28:38.383744
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:39.938531
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Add testcases here
    test_case_0()


# Generated at 2022-06-25 14:28:47.431816
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\x11\xb2\x9aG\xcb\xdbs\x06'
    var_1 = get_reserved_names(False)

# Generated at 2022-06-25 14:28:48.177318
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pass


# Generated at 2022-06-25 14:28:55.514091
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['gather_facts', 'vars', 'hosts', 'roles', 'pre_tasks', 'tasks', 'post_tasks', 'handlers', 'vars_files', 'include', 'any_errors_fatal', 'max_fail_percentage', 'delegate_to', 'transport', 'notify', 'delegate_facts', 'tags', 'ignore_errors', 'register', 'until', 'retries', 'delay', 'become', 'become_user', 'become_method', 'become_flags', 'serial', 'environment', 'action', 'local_action', 'with_'])



# Generated at 2022-06-25 14:28:56.864530
# Unit test for function get_reserved_names
def test_get_reserved_names():
    rc, out, err = get_reserved_names()
    assert not rc



# Generated at 2022-06-25 14:29:00.754237
# Unit test for function get_reserved_names
def test_get_reserved_names():
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    dict_1 = dict()
    dict_1['foo'] = 'bar'
    var_0 = get_reserved_names(include_private=False)
    var_1 = get_reserved_names(include_private=True)


# Generated at 2022-06-25 14:29:06.117120
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == ['block', 'become', 'become_user', 'connection', 'delegate_to', 'delegate_facts', 'environment', 'flush_cache', 'force_handlers', 'hosts', 'ignore_errors', 'include', 'include_tasks', 'local_action', 'name', 'no_log', 'notify', 'register', 'remote_user', 'roles', 'serial', 'strategy', 'tags', 'tasks', 'transport', 'vars']


# Generated at 2022-06-25 14:29:13.151814
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:07.739252
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # function get_reserved_names
    bytes_0 = b'\x11\xb2\x9aG\xcb\xdbs\x06'
    var_0 = is_reserved_name(bytes_0)
    var_1 = get_reserved_names()
    # FIXME: remove after with_ is not only deprecated but removed
    var_2 = get_reserved_names(include_private=False)
    assert(var_0 == False)

# Generated at 2022-06-25 14:30:14.522186
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names() == frozenset(['hosts', 'post_tasks', 'failed_when', 'vars_prompt', 'roles', 'let', 'tags', 'hosts_all', 'meta', 'with_', 'include', 'remote_user', 'block', 'delegate_to', 'when', 'ignore_errors', 'pre_tasks', 'name', 'vars', 'run_once', 'register', 'raw', 'notify', 'become_user', 'tags_all', 'tasks', 'async', 'delegate_facts', 'block', 'connection', 'transport', 'failed_when', 'until', 'loop_control', 'environment']))


# Generated at 2022-06-25 14:30:23.010473
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:26.210435
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)

    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'host' in reserved

    assert 'pla' not in reserved


# Generated at 2022-06-25 14:30:26.946019
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(test_case_0())

# Generated at 2022-06-25 14:30:34.230719
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:37.254899
# Unit test for function get_reserved_names
def test_get_reserved_names():
    my_vars = dict(
        test_first='first',
        test_second='second',
        test_third='third',
        test_fourth='fourth',
    )
    warn_if_reserved(my_vars.keys())


# Generated at 2022-06-25 14:30:44.619977
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['action', 'block', 'connection', 'delegate_to', 'when', 'become', 'sudo', 'su', 'become_user', 'remote_user', 'local_action', 'tags', 'any_errors_fatal', 'ignore_errors', 'become_method', 'gather_facts', 'hosts', 'name', 'roles', 'serial', 'handler', 'vars', 'environment', 'include', 'tasks', 'register', 'with_'])
    assert is_reserved_name(b'\x11\xb2\x9aG\xcb\xdbs\x06') == False

if __name__ == "__main__":
    # Unit test for function get_reserved_names
    test_get_reserved_names()

# Generated at 2022-06-25 14:30:50.918104
# Unit test for function get_reserved_names
def test_get_reserved_names():
    passed = 0
    failed = 0
    msg = ''


# Generated at 2022-06-25 14:30:58.242139
# Unit test for function get_reserved_names
def test_get_reserved_names():
    mock = [{'json': {'when': '{{ a }}'}}]
    host = "10.10.10.10"
    user = "user"
    port = 2222
    passwd = "passwd"
    result_0 = get_reserved_names()
    result_1 = get_reserved_names(include_private=True)
    test_dict = {
        'host': host,
        'user': user,
        'port': port,
        'passwd': passwd,
    }
    result_2 = get_reserved_names(include_private=True)
    result_3 = get_reserved_names(include_private=True)
    result_4 = get_reserved_names(include_private=False)

# Generated at 2022-06-25 14:32:45.445429
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("Testing function get_reserved_names:")
    var_0 = get_reserved_names()
    print("\nvalue returned: %s" % var_0)

# Generated at 2022-06-25 14:32:46.597033
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: implement test for get_reserved_names()
    pass

# Generated at 2022-06-25 14:32:52.862676
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bytes_0 = b'\x11\xb2\x9aG\xcb\xdbs\x06'
    bytes_1 = b'\x1c\xd7\xf5\x86\x91\x14\xa5\x9f'
    bytes_2 = b'\x7f\x06\xb5\x0c?\xd5\x9c\x17\xe1'
    var_0 = get_reserved_names(include_private=False)
    var_1 = get_reserved_names(include_private=True)

    # Check values
    assert isinstance(var_0, set)
    assert isinstance(var_1, set)


# Generated at 2022-06-25 14:32:59.318308
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()


# Generated at 2022-06-25 14:33:05.057677
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:14.441564
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:16.014787
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert 'name' in get_reserved_names()



# Generated at 2022-06-25 14:33:18.924082
# Unit test for function get_reserved_names
def test_get_reserved_names():
    actual = get_reserved_names()
    print(len(actual))
    print(actual)
    assert type(actual) is set


# Generated at 2022-06-25 14:33:26.583961
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'become_user', 'block', 'roles', 'hosts', 'gather_facts', 'name', 'task', 'remote_user', 'action', 'local_action', 'tasks', 'connection', 'loop', 'with_', 'any_errors_fatal', 'always_run', 'ignore_errors', 'serial', 'vars_files', 'include_role', 'import_playbook', 'register', 'run_once', 'become', 'roles_path', 'become_method', 'delegate_to', 'namespace', 'tags', 'delegate_facts', 'no_log', 'environment', 'ignore_unreachable', 'async', 'poll', 'first_available_file'}


# Generated at 2022-06-25 14:33:28.915095
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    return var_0
