

# Generated at 2022-06-25 14:26:22.908067
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(
        ['action', 'block', 'connection', 'delegate_to', 'delegate_facts', 'deprecate', 'delegate_through', 'environment',
         'ignore_errors', 'included_vars', 'keyed_groups', 'name', 'notify', 'notify_handler', 'no_log', 'poll',
         'post_validate', 'raw', 'register', 'retries', 'roles', 'run_once', 'serial', 'tags', 'task_files', 'tasks',
         'until', 'updated', 'vars', 'vars_files', 'with_', 'local_action'])

# Generated at 2022-06-25 14:26:24.889333
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = False
    var_0 = get_reserved_names(str_0)
    print(var_0)


# Generated at 2022-06-25 14:26:33.397808
# Unit test for function get_reserved_names
def test_get_reserved_names():
    actual = get_reserved_names()
    actual_1 = get_reserved_names(True)
    actual_2 = get_reserved_names(False)

# Generated at 2022-06-25 14:26:35.378958
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)


# Generated at 2022-06-25 14:26:37.590871
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = 'bar'
    var_0 = get_reserved_names(str_0)
    assert len(var_0) == 36


# Generated at 2022-06-25 14:26:40.281401
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() != None, 'function returned None'
    assert isinstance(get_reserved_names(), set), 'function did not return a set'


# Generated at 2022-06-25 14:26:42.372645
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() is not None, "Failed"
    assert get_reserved_names(include_private=False) is not None, "Failed"


# Generated at 2022-06-25 14:26:45.768906
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    check_reserved_names = names.issuperset(['host_list', 'hostvars', 'groups', 'group_names', 'omit', 'vars_files', 'roles', 'block', 'tasks', 'meta', 'include'])
    assert check_reserved_names == True

# Generated at 2022-06-25 14:26:46.523357
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()

# Generated at 2022-06-25 14:26:48.658791
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert result != None
    assert isinstance(result, set)


# Generated at 2022-06-25 14:27:02.295615
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    if isinstance(var_0, set):
        pass
    else:
        raise AssertionError

    var_1 = get_reserved_names(False)
    if isinstance(var_1, set):
        pass
    else:
        raise AssertionError


# Generated at 2022-06-25 14:27:03.563694
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert var_0 is not None


# Generated at 2022-06-25 14:27:05.965066
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 =  get_reserved_names()
    var_2 =  get_reserved_names(False)
    assert var_1
    assert var_2


# Generated at 2022-06-25 14:27:11.276525
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Setup:
    include_private = True

    # Exercise:
    var_0 = get_reserved_names(include_private)

    # Verify:
    assert str(type(var_0)) == "<type 'set'>"
    assert len(var_0) > 0
    assert str(type(var_0.pop())) == "<type 'str'>"


# Generated at 2022-06-25 14:27:19.838143
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:21.689564
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # No assertion needed
    get_reserved_names()

    # No assertion needed
    get_reserved_names(include_private=False)


# Generated at 2022-06-25 14:27:23.519444
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert isinstance(var_0, frozenset)


# Generated at 2022-06-25 14:27:25.629578
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Case 0
    test_case_0()
    # Case 1
    var_1 = get_reserved_names(False)
    assert var_1.issubset(_RESERVED_NAMES)

# Generated at 2022-06-25 14:27:33.172613
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # this will call the function we want to test
    result = get_reserved_names()

    # this is used to count how many assertions we test
    assertion_count = 0

    # this is used to check how many assertion passed
    assertions_passed = 0

    # check if result type is set
    try:
        assert(type(result) is set)
        assertions_passed += 1
    except AssertionError:
        print("AssertionError: Result of get_reserved_names is not of type set")
    assertion_count += 1
    # check if result contains reserved variables
    try:
        assert(len(result) is not 0)
        assertions_passed += 1
    except AssertionError:
        print("AssertionError: Result of get_reserved_names is empty")

# Generated at 2022-06-25 14:27:41.425804
# Unit test for function get_reserved_names
def test_get_reserved_names():

    var_0 = get_reserved_names()

    # FIXME: do we want to sort this?
    assert isinstance(var_0, set)

    assert 'private' in var_0
    assert 'hosts' in var_0

    assert 'vars' not in var_0
    assert 'forks' not in var_0
    assert 'hosts' not in var_0

    var_1 = get_reserved_names(include_private=False)

    assert 'private' not in var_1
    assert 'hosts' in var_1

    # make sure its the same when we call it again
    assert var_0 == get_reserved_names()
    assert var_1 == get_reserved_names(include_private=False)



# Generated at 2022-06-25 14:28:00.948859
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    var_1 = get_reserved_names(False)
    var_2 = get_reserved_names(True)


# Generated at 2022-06-25 14:28:01.708804
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test case 0:
    assert test_case_0() == res_0

# Generated at 2022-06-25 14:28:05.601619
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert not 'action' in get_reserved_names()
    assert 'action' in get_reserved_names(include_private=True)
    assert 'loop' in get_reserved_names(include_private=True)
    assert not 'loop' in get_reserved_names()



# Generated at 2022-06-25 14:28:13.445108
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_0 = get_reserved_names()
    assert isinstance(test_0, set)

# Generated at 2022-06-25 14:28:21.125246
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:28.279383
# Unit test for function get_reserved_names
def test_get_reserved_names():
    actual = get_reserved_names()
    assert isinstance(actual, set)

# Generated at 2022-06-25 14:28:30.687048
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()
    var_2 = get_reserved_names(include_private=False)

    assert isinstance(var_1, frozenset)
    assert isinstance(var_2, frozenset)


# Generated at 2022-06-25 14:28:36.220636
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test case 0
    var_0 = set(['max_tries', 'action', 'handler', 'with_', 'tags', 'any_errors_fatal', 'connection', 'include', 'transport', 'async', 'post_tasks', 'roles', 'notify', 'bundles', 'pre_tasks', 'ignore_errors', 'meta', 'environment', 'vars', 'always_run', 'delegate_to', 'local_action', 'gather_facts', 'when', 'name', 'no_log', 'register', 'roles_path', 'vars_files', 'name', 'tasks', 'become', 'become_user', 'hosts', 'become_method', 'environment', 'serial', 'block', 'ignore_errors', 'listen'])
    var_1 = get_reserved_

# Generated at 2022-06-25 14:28:40.047847
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:42.377808
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:18.619595
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names(include_private=True)) == len(_RESERVED_NAMES)



# Generated at 2022-06-25 14:29:27.315720
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    var_1 = get_reserved_names(include_private=False)

# Generated at 2022-06-25 14:29:29.804609
# Unit test for function get_reserved_names
def test_get_reserved_names():
    global _RESERVED_NAMES
    _RESERVED_NAMES_TEST = get_reserved_names(include_private=False)
    assert _RESERVED_NAMES == _RESERVED_NAMES_TEST

# Generated at 2022-06-25 14:29:36.219193
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)

# Generated at 2022-06-25 14:29:42.533202
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    # 0:
    #[u'name', u'connection', u'vars_files', u'hosts', u'remote_user', u'roles', u'gather_facts', u'vars_prompt', u'any_errors_fatal', u'roles_path', u'become', u'serial', u'become_user', u'become_method', u'become_ask_pass', u'port', u'modules_path', u'forks', u'async', u'poll_interval', u'post_tasks', u'pre_tasks', u'vars', u

# Generated at 2022-06-25 14:29:50.050906
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:57.236115
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # it's a reserved name if it's in the obj's attribute list
        for attribute in aobj.__dict__['_attributes']:

            # the namespace cannot be used without specifying private or not
            if attribute not in reserved_names:
                assert False

    # these are not present in the object attributes
    assert 'local_action' in reserved_names

    # these are deprecated, but still need to be reserved
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in reserved_names

    # this is a special one, it returns public and private names

# Generated at 2022-06-25 14:29:58.649056
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Verify we are getting the right set back
    assert _RESERVED_NAMES == get_reserved_names(), "Actions were not loaded correctly"



# Generated at 2022-06-25 14:30:06.069262
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:12.016625
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert isinstance(var_0, set)
    assert len(var_0) == 9
    assert 'action' in var_0
    assert 'any_errors_fatal' in var_0
    assert 'connection' in var_0
    assert 'delegate_to' in var_0
    assert 'notify' in var_0
    assert 'when' in var_0
    assert 'gather_facts' in var_0
    assert 'roles' in var_0
    assert 'tags' in var_0


# Generated at 2022-06-25 14:30:58.049115
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:59.749253
# Unit test for function get_reserved_names
def test_get_reserved_names():
    with pytest.raises(AnsibleError):
      ansible.module_utils.common.get_reserved_names(None)


# Generated at 2022-06-25 14:31:05.067131
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(True) == frozenset(['name', 'roles', 'run_once', 'hosts', 'gather_facts', 'vars', 'tags', 'serial', 'transport', 'become', 'become_user', 'become_method', 'check_mode', 'delegate_to', 'register', 'ignore_errors', 'action', 'local_action', 'connection', 'no_log', 'run_once', 'no_log', 'when', 'async', 'poll', 'changed_when', 'failed_when', 'succeeded_when'])

# Generated at 2022-06-25 14:31:06.901092
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Setup Inventory, Play, etc and call get_reserved_names
    # check if the result is not none
    x = get_reserved_names()
    assert x is not None


# Generated at 2022-06-25 14:31:12.796124
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:15.759892
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = '-U'
    var_1 = get_reserved_names(include_private=True)
    var_2 = get_reserved_names(include_private=False)
    assert ('-U' in var_1) == False
    assert ('-U' in var_2) == False


# Generated at 2022-06-25 14:31:23.959726
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'loop', 'remote_user', 'when', 'register', 'sudo', 'sudo_user', 'gather_facts', 'name', 'serial', 'roles', 'serial', 'tags', 'delegate_to', 'run_once', 'tasks', 'handlers', 'notify', 'vars', 'environment', 'post_tasks', 'any_errors_fatal', 'local_action', 'transport', 'ignore_errors', 'connection', 'with_'}

# Unit test function warn_if_reserved

# Generated at 2022-06-25 14:31:25.942128
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test case for function get_reserved_names
    # Get reserved_names for internal ansible use
    results_0 = get_reserved_names()



# Generated at 2022-06-25 14:31:28.873794
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert len(reserved_names) > 0, "No reserved names returned"
    assert 'serial' in reserved_names, "\"serial\" is not a reserved name"
    assert 'connection' in reserved_names, "\"connection\" is not a reserved name"


# Generated at 2022-06-25 14:31:33.493557
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:02.146154
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = 'tags'
    var_0 = get_reserved_names(str_0)
    assert var_0 == False


# Generated at 2022-06-25 14:33:07.337004
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = 'become'
    list_0 = ['become', 'action', 'connection', 'loop', 'meta', 'name', 'serial', 'tags', 'vars']
    list_1 = ['become', 'action', 'connection', 'loop', 'meta', 'name', 'serial', 'tags', 'vars', 'delegate_to', 'local_action']
    list_2 = ['become', 'action', 'connection', 'loop', 'meta', 'name', 'serial', 'tags', 'vars', 'delegate_to', 'local_action', 'register', 'when']

# Generated at 2022-06-25 14:33:11.348568
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names1 = get_reserved_names()
    names2 = get_reserved_names(True)
    names3 = get_reserved_names(False)
    assert names1 == names2
    assert names1 != names3



# Generated at 2022-06-25 14:33:18.403914
# Unit test for function get_reserved_names
def test_get_reserved_names():
    parameter_dict = {'include_private': True}

# Generated at 2022-06-25 14:33:20.538500
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = '-U'
    var_0 = get_reserved_names(str_0)

# Generated at 2022-06-25 14:33:21.459342
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES


# Generated at 2022-06-25 14:33:23.155343
# Unit test for function get_reserved_names
def test_get_reserved_names():
    data = get_reserved_names()
    assert type(data) == list


# Generated at 2022-06-25 14:33:23.840956
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:33:25.579344
# Unit test for function get_reserved_names
def test_get_reserved_names():
    str_0 = '-U'
    var_0 = get_reserved_names(str_0)
    assert var_0 is not None


# Generated at 2022-06-25 14:33:28.220182
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pb_attributes = get_reserved_names()
    assert len(pb_attributes) == 150
