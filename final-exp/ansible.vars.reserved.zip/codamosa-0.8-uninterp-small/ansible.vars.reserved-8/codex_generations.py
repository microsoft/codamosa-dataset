

# Generated at 2022-06-25 14:26:24.182287
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        test_case_0()
    except:
        assert(False)



# Generated at 2022-06-25 14:26:32.935543
# Unit test for function get_reserved_names
def test_get_reserved_names():
   var_1 = get_reserved_names()

# Generated at 2022-06-25 14:26:36.959674
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Validate get_reserved_names'''

    var_0 = get_reserved_names()
    assert(isinstance(var_0, set))

    var_1 = get_reserved_names(include_private=False)
    assert(isinstance(var_1, set))


# Generated at 2022-06-25 14:26:37.824479
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() is None

# Generated at 2022-06-25 14:26:46.170476
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test with default parameters
    var_0 = get_reserved_names()

# Generated at 2022-06-25 14:26:54.653804
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Test get_reserved_names with defaults
    '''
    var_0 = get_reserved_names()

    assert len(var_0) == 27
    assert "local_action" in var_0
    assert "sudo_user" in var_0
    assert "become" in var_0
    assert "name" in var_0
    assert "loops" in var_0
    assert "vars" in var_0
    assert "private" in var_0
    assert "loop" in var_0
    assert "roles" in var_0
    assert "action" in var_0
    assert "become_user" in var_0
    assert "include_role" in var_0
    assert "any_errors_fatal" in var_0
    assert "post_tasks"

# Generated at 2022-06-25 14:27:02.871227
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Verify that the output of get_reserved_names() is a frozenset
    assert isinstance(get_reserved_names(), frozenset)

    # Verify that the output of get_reserved_names() is 25 elements
    # This number is the number of reserved names returned in the sample output
    assert (len(get_reserved_names()) == 25)

    # Verify that the output of get_reserved_names(include_private=False) is 23 elements
    # This number is the number of reserved public names returned in the sample output
    assert (len(get_reserved_names(False)) == 23)

    # Verify that the output of get_reserved_names(include_private=False) is 25 elements
    # This number is the number of reserved private names returned in the sample output
    # This will fail until the private name union is added

# Generated at 2022-06-25 14:27:12.571069
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:20.870365
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert var_0 is not None
    assert len(var_0) == 38
    assert 'become' in var_0
    assert 'serial' in var_0
    assert 'max_fails' in var_0
    assert 'roles' in var_0
    assert 'environment' in var_0
    assert 'environment_file' in var_0
    assert 'remote_tmp' in var_0
    assert 'hosts' in var_0
    assert 'run_once' in var_0
    assert 'host_vars' in var_0
    assert 'test' in var_0
    assert 'block' in var_0
    assert 'ignore_errors' in var_0
    assert 'no_log' in var_0
    assert 'always_run'

# Generated at 2022-06-25 14:27:21.848101
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()


# Generated at 2022-06-25 14:27:48.138152
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check return value of get_reserved_names()
    reserved_names = get_reserved_names()
    assert len(reserved_names) == len(_RESERVED_NAMES)
    for name in reserved_names:
        assert name in _RESERVED_NAMES


# Generated at 2022-06-25 14:27:55.773660
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Test case 0
    # Test with defaults
    test_case_0()

    # Test case 1
    # Test with explicit include_private=True
    var_1 = get_reserved_names(include_private=True)

# Generated at 2022-06-25 14:28:03.853524
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:06.698909
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() is not None, "Expected None"
    assert isinstance(get_reserved_names(), frozenset), "Expected frozenset"
    test_case_0()



# Generated at 2022-06-25 14:28:07.769519
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(True)


# Generated at 2022-06-25 14:28:16.022799
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # all private variables
    result = get_reserved_names(include_private=True)

# Generated at 2022-06-25 14:28:22.847623
# Unit test for function get_reserved_names
def test_get_reserved_names():
    #temp set of expected answers from test data
    expected = frozenset([
        'handler',
        'hosts',
        'name',
        'roles',
        'vars',
        'with_',
        'local_action',
        'action',
        'block',
        'meta',
        'notify',
        'notified_by',
        'pause',
        'tags',
        'task',
        'vars_files',
        'delegate_to',
        'when',
        'register',
        'validate_certs'
    ])

    # Call the function to test
    returned = get_reserved_names()

    # Assert the expected results match
    assert expected == returned

# Generated at 2022-06-25 14:28:24.707023
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test first use of function
    assert test_case_0()

if __name__ == '__main__':
    test_get_reserved_names()

# Generated at 2022-06-25 14:28:28.873105
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert "hosts" in get_reserved_names(include_private=True)
    assert "hosts" in get_reserved_names()
    assert "hosts" not in get_reserved_names(include_private=False)
    assert "action" in get_reserved_names(include_private=True)
    assert "loop" in get_reserved_names()
    assert "loop" not in get_reserved_names(include_private=False)



# Generated at 2022-06-25 14:28:33.984596
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == {
        'action',
        'block',
        'block_end',
        'block_start',
        'connection',
        'gather_facts',
        'handlers',
        'hosts',
        'include',
        'include_vars',
        'name',
        'post_tasks',
        'pre_tasks',
        'precedence',
        'pre_tasks',
        'register',
        'roles',
        'tags',
        'tasks',
        'vars',
        'when',
        'with_items',
        'with_together',
        'with_dict'
    }

# Generated at 2022-06-25 14:29:23.637061
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:31.320676
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_cases = dict()
    test_cases[0] = dict(expected_return_value=('action', 'become', 'become_user', 'block', 'block:', 'delegate_to',
                                                'delegate_facts', 'environment', 'gather_facts', 'ignore_errors',
                                                'import_playbook', 'include', 'include_role', 'include_tasks',
                                                'local_action', 'loop', 'name', 'post_tasks', 'pre_tasks', 'remote_user',
                                                'roles', 'run_once', 'serial', 'tasks', 'vars', 'with_items', 'with_subelements',
                                                'with_together'),
                         expected_except=None)
    # test private names
    test_cases[1] = dict

# Generated at 2022-06-25 14:29:34.097732
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Test function for function get_reserved_names()
    '''
    print("Test function: get_reserved_names")
    var_0 = get_reserved_names()
    assert len(var_0) != 0
    assert isinstance(var_0, set)


# Generated at 2022-06-25 14:29:40.670615
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:44.692420
# Unit test for function get_reserved_names
def test_get_reserved_names():
    play = Play()
    play.tasks.append(Task())
    play.tasks.append(Task())
    reserved = get_reserved_names()
    assert 'tasks' in reserved
    assert 'gather_facts' in reserved
    assert 'name' in reserved
    assert 'sudo' in reserved
    assert 'sudo_user' in reserved
    assert 'tags' in reserved
    assert 'vars' in reserved
    assert 'vars_files' in reserved
    assert 'vars_prompt' in reserved
    assert 'vault_password_file' in reserved


# Generated at 2022-06-25 14:29:52.622640
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:58.501377
# Unit test for function get_reserved_names
def test_get_reserved_names():
    output = set(['author', 'post_tasks', 'roles', 'vars_files', 'hosts', 'pre_tasks', 'gather_facts', 'tags', 'when', 'import_playbook', 'register', 'delegate_to', 'become_user', 'connection', 'become', 'notify', 'transport', 'check_mode', 'handlers', 'name', 'meta', 'ignore_errors', 'no_log', 'roles_path', 'remote_user', 'always_run', 'include', 'tasks', 'ignore_unreachable', 'when', 'tags'])
    assert output == get_reserved_names()


# Generated at 2022-06-25 14:30:01.294474
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # given
    var_1 = None

    # when
    var_0 = get_reserved_names(include_private=True)
    var_0 = get_reserved_names(include_private=False)

    # then
    assert var_0 != var_1


# Generated at 2022-06-25 14:30:09.157101
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = frozenset(['action', 'any_errors_fatal', 'block',
                          'connection', 'delegate_to', 'delay', 'environment',
                          'error_on_undefined_vars', 'handler_only',
                          'ignore_errors', 'include', 'loop', 'local_action',
                          'name', 'notify', 'no_log', 'post_handlers',
                          'pre_tasks', 'pre_tags', 'roles', 'run_once',
                          'serial', 'tags', 'task', 'tasks', 'task_files',
                          'task_includes', 'vars'])
    assert get_reserved_names() == reserved
    assert get_reserved_names(include_private=False) == reserved - frozenset(['loop', 'with_'])



# Generated at 2022-06-25 14:30:11.388713
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        assert test_case_0
    except AssertionError as e:
        print('Unit test failed: get_reserved_names')
        print(str(e))



# Generated at 2022-06-25 14:31:00.697697
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print('test_play.py::test_get_reserved_names')
    assert test_case_0()

# Generated at 2022-06-25 14:31:03.662600
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert result == {'tags', 'name', 'environment', 'gather_facts', 'delegate_to', 'block', 'vars', 'roles', 'tasks', 'when'}


# Generated at 2022-06-25 14:31:04.340120
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 0



# Generated at 2022-06-25 14:31:05.474936
# Unit test for function get_reserved_names
def test_get_reserved_names():
  reserved_1 = get_reserved_names()
  assert len(reserved_1) > 0


# Generated at 2022-06-25 14:31:06.374751
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) == frozenset


# Generated at 2022-06-25 14:31:12.331337
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:14.836108
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: This test is incomplete, but should be sufficient for
    # coverage of the function. Feel free to improve.

    # FIXME: test should be more extensive

    mydict = {'name': 'blah'}
    result = get_reserved_names(mydict)
    assert isinstance(result, frozenset)
    assert b'name' in result



# Generated at 2022-06-25 14:31:17.706623
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names(True)) > 0
    assert len(get_reserved_names(False)) > 0



# Generated at 2022-06-25 14:31:24.486772
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This test is for issue https://github.com/ansible/ansible/issues/29262
    # reserve names are not available at play_context, but are available at task_vars
    # so with_ loops need to be consulted before the task_vars in order to be able to
    # choose a loop variable correctly
    assert set(['action', 'local_action', 'with_']) == get_reserved_names(True)
    assert set(['action', 'local_action', 'with_']) == get_reserved_names(False)

# Generated at 2022-06-25 14:31:25.870340
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This function is not supposed to be tested, it is supposed to be used.
    assert (True)

# Generated at 2022-06-25 14:33:18.202038
# Unit test for function get_reserved_names
def test_get_reserved_names():
    dict_0 = {}
    dict_1 = {}
    dict_1['include_private'] = True
    dict_2 = {}
    dict_2['include_private'] = False
    try:
        result_0 = get_reserved_names(dict_0)
    except Exception as e:
        display.display('Exception: %s' % e, color='red')
        assert False
    try:
        result_1 = get_reserved_names(dict_2)
    except Exception as e:
        display.display('Exception: %s' % e, color='red')
        assert False

    assert result_0 == _RESERVED_NAMES
    assert result_1 == _RESERVED_NAMES.difference(set(['port']))



# Generated at 2022-06-25 14:33:23.983371
# Unit test for function get_reserved_names
def test_get_reserved_names():
    function_name = "get_reserved_names"
    function_class = "module_utils.common.collections.play_collection"
    dict_1 = {}
    dict_1["include_private"] = True
    var_1 = get_reserved_names(dict_1)

    # test for valid output
    assert len(var_1) > 0, (
        '{0}.{1}: Test for valid output FAILED!'.format(function_class,
                                                        function_name))



# Generated at 2022-06-25 14:33:25.280646
# Unit test for function get_reserved_names
def test_get_reserved_names():
    function_name = 'play_has_tasks'
    assert test_case_0

# Generated at 2022-06-25 14:33:29.244545
# Unit test for function get_reserved_names
def test_get_reserved_names():
    warning = False
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        test_case_0()
        if len(w) > 0:
            warning = True
            print(w[0])
    assert(not warning)


# Generated at 2022-06-25 14:33:33.138141
# Unit test for function get_reserved_names
def test_get_reserved_names():
    dict_0 = {}
    dict_0['include_private'] = True
    var_0 = get_reserved_names(**dict_0)
    var_1 = get_reserved_names(**{'include_private': True})
    assert var_0 == var_1

    dict_1 = {}
    dict_1['include_private'] = False
    var_2 = get_reserved_names(**dict_1)
    var_3 = get_reserved_names(**{'include_private': False})
    assert var_2 == var_3



# Generated at 2022-06-25 14:33:41.788719
# Unit test for function get_reserved_names
def test_get_reserved_names():
    dict_0 = {}
    display.warning("Testing function get_reserved_names")

# Generated at 2022-06-25 14:33:48.742711
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:49.517728
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == None, "test_case_0"


# Generated at 2022-06-25 14:33:52.204275
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(
        get_reserved_names(True), set
    ), "Incorrect return type for get_reserved_names()"



# Generated at 2022-06-25 14:33:57.173048
# Unit test for function get_reserved_names