

# Generated at 2022-06-25 14:26:35.764842
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    assert type(reserved_names) is set
    assert set([u'hosts', u'name', u'action', u'local_action', u'tasks']) == reserved_names


# Generated at 2022-06-25 14:26:44.422640
# Unit test for function get_reserved_names
def test_get_reserved_names():
    play1 = Play()
    play1.hosts = 'hosts'
    play1.name = 'name'
    play1.connection = 'connection'
    play1.gather_facts = 'gather_facts'
    play1.serial = 'serial'
    play1.any_errors_fatal = 'any_errors_fatal'
    play1.become = 'become'
    play1.become_user = 'become_user'
    play1.become_method = 'become_method'
    play1.verbosity = 'verbosity'
    play1.environment = 'environment'
    play1.tags = 'tags'
    play1.skip_tags = 'skip_tags'
    play1.max_fail_percentage = 'max_fail_percentage'

# Generated at 2022-06-25 14:26:52.081707
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_result = set(['fetch', 'changed_when', 'handlers', 'roles', 'notify', 'connection',
                           'hosts', 'pre_tasks', 'notify_handlers', 'vars', 'roles_path',
                           'local_action', 'name', 'include_tasks', 'pre_tasks', 'block',
                           'post_tasks', 'tags', 'ignore_errors', 'include', 'when', 'any_errors_fatal',
                           'failed_when', 'post_tasks', 'delegate_to', 'tasks', 'tasks'])

    actual_result = get_reserved_names()
    assert actual_result == expected_result, "Failed: '%s' != '%s'" % (actual_result, expected_result)


# Unit test

# Generated at 2022-06-25 14:26:58.397189
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == set([u'environment', u'vars_prompt', u'connection', u'action', u'vars_files', u'name', u'include_vars', u'post_tasks', u'register', u'local_action', u'roles', u'with_', u'pre_tasks', u'tasks', u'include', u'include_role', u'vars', u'hosts', u'block'])


# Generated at 2022-06-25 14:27:01.053378
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test with no arguments
    assert get_reserved_names() is not None
    # Test with arguments
    assert get_reserved_names(True) is not None
    assert get_reserved_names(False) is not None


# Generated at 2022-06-25 14:27:02.079897
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print(get_reserved_names())


# Generated at 2022-06-25 14:27:11.635767
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """Test function to get reserved names"""

    # Test with no arguments
    assert 'host' in get_reserved_names()

    # Test with private argument
    assert 'host' in get_reserved_names(include_private=True)
    assert 'ssh_args' in get_reserved_names(include_private=True)
    assert 'ansible_ssh_user' in get_reserved_names(include_private=True)
    assert 'ansible_become' in get_reserved_names(include_private=True)
    assert 'delegate_to' in get_reserved_names(include_private=True)
    assert 'register' in get_reserved_names(include_private=True)

    # Test without private argument
    assert 'host' in get_reserved_names(include_private=False)


# Generated at 2022-06-25 14:27:14.513433
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check if get_reserved_names is a defined function
    assert callable(get_reserved_names)
    # Check if get_reserved_names returns a set
    assert isinstance(get_reserved_names(), set)



# Generated at 2022-06-25 14:27:16.002676
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert len(reserved) == 144



# Generated at 2022-06-25 14:27:19.943584
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # TODO: check for empty set and bad type
    set_1 = set(get_reserved_names())
    var_1 = isinstance(set_1, set)
    set_2 = set(get_reserved_names(include_private=False))
    var_2 = isinstance(set_2, set)


# Generated at 2022-06-25 14:27:45.428630
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset({
        'become', 'become_user', 'become_method', 'connection', 'gather_facts',
        'gather_subset', 'gather_timeout', 'hosts', 'name', 'remote_user', 'sudo',
        'sudo_user', 'tasks', 'when', 'serial', 'accelerate', 'vars_files', 'vars',
        'action', 'local_action', 'with_'})



# Generated at 2022-06-25 14:27:46.478944
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES

# Generated at 2022-06-25 14:27:49.334234
# Unit test for function get_reserved_names
def test_get_reserved_names():
    play = Play()
    reserved = get_reserved_names()
    assert len(reserved) > 0
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'foo' not in reserved


# Generated at 2022-06-25 14:27:56.699329
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:04.339770
# Unit test for function get_reserved_names
def test_get_reserved_names():
    play_0 = module_0.Play()
    play_1 = module_0.Play()

    for attr in play_0.__dict__['_attributes']:
        if attr.init_type is not None:
            play_0.__dict__[attr.name] = None

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]


# Generated at 2022-06-25 14:28:07.734152
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['pre_tasks', 'notify', 'post_tasks', 'handler', 'action', 'tasks', 'include', 'register', 'vars', 'name', 'local_action', 'with_'])


# Generated at 2022-06-25 14:28:09.610167
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(),set)
    assert isinstance(get_reserved_names(include_private=True),set)


# Generated at 2022-06-25 14:28:10.903376
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'name' in names


# Generated at 2022-06-25 14:28:16.416771
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['become', 'become_user', 'check_mode', 'connection', 'environment', 'gather_facts', 'hosts', 'ignore_errors', 'max_fail_percentage', 'no_log', 'pre_tasks', 'post_tasks', 'port', 'roles', 'serial', 'sudo', 'sudo_user', 'tasks', 'transport', 'vars', 'vars_files'])


# Generated at 2022-06-25 14:28:16.890012
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pass

# Generated at 2022-06-25 14:28:36.553546
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == _RESERVED_NAMES


# Generated at 2022-06-25 14:28:39.824884
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'hosts' in names
    assert 'roles' in names
    assert 'block' in names
    assert 'include_tasks' in names
    assert 'include_vars' in names
    assert 'environment' in names
    assert 'deprecations' not in names


# Generated at 2022-06-25 14:28:47.295104
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:48.956598
# Unit test for function get_reserved_names
def test_get_reserved_names():
    display.warning(get_reserved_names())

if __name__ == '__main__':
    test_get_reserved_names()

# Generated at 2022-06-25 14:28:54.394779
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test defaults
    assert 'name' in get_reserved_names()
    assert get_reserved_names(include_private=False) != get_reserved_names()

    # test that argument handling does not blow up, negative testing
    try:
        get_reserved_names(include_private=None)
    except:
        pass

    with pytest.raises(TypeError):
        get_reserved_names(include_private='None')


# Generated at 2022-06-25 14:29:00.118556
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected = {'sudo', 'remote_user', 'pipelining', 'environment', 'become', 'serial', 'roles', 'gather_facts', 'tasks', 'name', 'post_tasks', 'hosts', 'tags', 'any_errors_fatal', 'force_handlers', 'forks', 'pre_tasks', 'vars', 'handlers', 'block'}
    get_all = get_reserved_names()
    assert get_all == expected, "Expected " + str(expected) + ", Got " + str(get_all)



# Generated at 2022-06-25 14:29:02.358006
# Unit test for function get_reserved_names
def test_get_reserved_names():
    set_1 = frozenset({'name', 'hosts'})
    var_1 = get_reserved_names()

    assert var_1 == set_1



# Generated at 2022-06-25 14:29:04.292856
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Verify function returns a set
    set_0 = get_reserved_names()
    assert isinstance(set_0, set)
    return



# Generated at 2022-06-25 14:29:11.895860
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:14.622821
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_set = ['meta', 'vars', 'block', 'name', 'roles', 'tasks',
                'gather_facts', 'connection']
    reserved = get_reserved_names()
    assert test_set.sort() == reserved.sort()


# Generated at 2022-06-25 14:29:55.598665
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert type(get_reserved_names()) == set


# Generated at 2022-06-25 14:29:56.866944
# Unit test for function get_reserved_names
def test_get_reserved_names():
    set_0 = get_reserved_names()
    assert 'role_name' in set_0


# Generated at 2022-06-25 14:29:58.523303
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names(include_private=True)) == frozenset
    assert type(get_reserved_names(include_private=False)) == frozenset



# Generated at 2022-06-25 14:30:05.902277
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import os
    import sys
    import subprocess
    import time
    import signal

    counter = 0
    devnull = open(os.devnull, 'w')
    kwargs = {}
    kwargs['stdout'] = devnull
    kwargs['stderr'] = devnull

    def _get_reserved_names_test_helper(cmd):
        proc = subprocess.Popen(cmd, **kwargs)
        try:
            proc.wait(timeout=1.0)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGTERM)
            return None
        if proc.returncode:
            raise subprocess.CalledProcessError(proc.returncode, cmd)
        return proc.returncode


# Generated at 2022-06-25 14:30:08.062115
# Unit test for function get_reserved_names
def test_get_reserved_names():
    my_vars = get_reserved_names()
    assert isinstance(my_vars, set)
    assert len(my_vars) > 1



# Generated at 2022-06-25 14:30:09.429316
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert(reserved_names)


# Generated at 2022-06-25 14:30:17.236706
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=True)
    # assert that var_0 came from fixture_0
    assert 'hosts' in result
    assert 'vars' in result
    assert 'roles' in result
    assert 'tasks' in result
    assert 'block' in result
    assert 'post_tasks' in result
    assert 'pre_tasks' in result
    assert 'become' in result
    assert 'gather_facts' in result
    assert 'any_errors_fatal' in result
    assert 'no_log' in result
    assert 'remote_user' in result
    assert 'sudo' in result
    assert 'sudo_user' in result
    assert 'su' in result
    assert 'su_user' in result
    assert 'when' in result

# Generated at 2022-06-25 14:30:19.432974
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() is not None
    assert get_reserved_names(include_private=False) is not None



# Generated at 2022-06-25 14:30:27.731595
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Unit test for function for public and private attributes
    #
    #
    assert "tags" in _RESERVED_NAMES
    assert "name" in _RESERVED_NAMES
    assert "roles" in _RESERVED_NAMES
    assert "hosts" in _RESERVED_NAMES
    assert "public" in _RESERVED_NAMES
    assert "private" in _RESERVED_NAMES
    assert "block" in _RESERVED_NAMES

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    #
    # Unit tests for the different class objects
    #

# Generated at 2022-06-25 14:30:35.000765
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:11.369457
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:12.450913
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 10, 'reserved names should exist'



# Generated at 2022-06-25 14:32:13.324054
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    print(result)



# Generated at 2022-06-25 14:32:15.130123
# Unit test for function get_reserved_names
def test_get_reserved_names():
    set_0 = get_reserved_names(include_private=True)
    var_0 = is_reserved_name(set_0)

# Generated at 2022-06-25 14:32:22.531205
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:24.547629
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Set that contains all the reserved names.
    reserved = get_reserved_names()
    assert reserved
    assert len(reserved) > 0
    assert reserved == _RESERVED_NAMES



# Generated at 2022-06-25 14:32:32.628189
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:38.800748
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert type(reserved_names) == set

# Generated at 2022-06-25 14:32:41.537394
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected = set(['myvar', 'myvar2', 'my_var3'])
    actual = get_reserved_names(['myvar', 'myvar2', 'my_var3'])
    assert expected == actual


# Generated at 2022-06-25 14:32:50.286814
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:35:36.587088
# Unit test for function get_reserved_names
def test_get_reserved_names():

    list_0 = get_reserved_names(True)
    list_1 = get_reserved_names(False)
    assert "name" in list_0
    assert "name" in list_1
    assert "block" not in list_0
    assert "block" in list_1



# Generated at 2022-06-25 14:35:39.705437
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # $ANSIBLE_ROLES_PATH/test_role is searched for the role
    # If the role is not found, the test is skipped.
    a_reserved_name_list = get_reserved_names()
    for a_name in a_reserved_name_list:
        assert is_reserved_name(a_name)


# Generated at 2022-06-25 14:35:44.541596
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test play
    play_0 = Play()
    play_0.name = dict()
    play_0.hosts = set()
    play_0.gather_facts = False
    play_0.vars = dict()
    play_0.vars_files = list()
    play_0.roles = list()
    play_0.tasks = list()
    play_0.post_tasks = list()
    play_0.handlers = list()
    play_0.default_vars = dict()
    play_0.pre_tasks = list()
    play_0.tags = set()



# Generated at 2022-06-25 14:35:45.218782
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()

# Generated at 2022-06-25 14:35:47.171439
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set) or isinstance(get_reserved_names(), frozenset)


# Generated at 2022-06-25 14:35:48.452568
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert isinstance(result, set)


# Generated at 2022-06-25 14:35:55.181987
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result_0 = get_reserved_names()
    assert 'group_by' in result_0
    assert 'serial' in result_0
    assert 'action' in result_0
    assert 'ignore_errors' in result_0
    assert 'notify' in result_0
    assert 'role_defaults' in result_0
    assert 'block' in result_0
    assert 'roles' in result_0
    assert 'become_user' in result_0
    assert 'gather_facts' in result_0
    assert 'block_rescue' in result_0
    assert 'become' in result_0
    assert 'sudo_flags' in result_0
    assert 'vars_files' in result_0
    assert 'post_tasks' in result_0
    assert 'block_end' in result

# Generated at 2022-06-25 14:36:02.140807
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected = set()
    expected.add('block')
    expected.add('meta')
    expected.add('ignore_errors')
    expected.add('notify')
    expected.add('run_once')
    expected.add('pre_tasks')
    expected.add('roles')
    expected.add('tasks')
    expected.add('become')
    expected.add('vars')
    expected.add('rescue')
    expected.add('environment')
    expected.add('post_tasks')
    expected.add('always_run')
    expected.add('local_action')
    expected.add('register')
    expected.add('with_')
    expected.add('hosts')
    expected.add('when')
    expected.add('delegate_to')
    expected.add('include')


# Generated at 2022-06-25 14:36:03.954691
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
