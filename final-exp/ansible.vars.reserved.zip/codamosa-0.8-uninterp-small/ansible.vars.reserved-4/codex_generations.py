

# Generated at 2022-06-25 14:26:49.436780
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()
    assert(isinstance(var_1,set))

# Generated at 2022-06-25 14:26:50.766306
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)



# Generated at 2022-06-25 14:26:52.367467
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert (test_case_0())

if __name__ == '__main__':
    test_get_reserved_names()

# Generated at 2022-06-25 14:27:00.257290
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names(include_private=False)
    assert "action" in var_1
    assert "become" in var_1
    assert "become_user" in var_1
    assert "block" in var_1
    assert "local_action" in var_1
    assert "name" in var_1
    assert "no_log" in var_1
    assert "register" in var_1
    assert "roles" in var_1
    assert "tags" in var_1
    assert "tasks" in var_1
    assert "vars" in var_1
    assert "with_" in var_1

# Generated at 2022-06-25 14:27:03.760900
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ans_0 = {'block_tags', 'condition', 'any_errors_fatal', 'any_errors_fatal' ,'register', 'delegate_to', 'ignore_errors', 'tags', 'connection', 'when', 'action', 'loop', 'local_action', 'notify', 'post_validate'}
    assert ans_0 == test_case_0()

# Generated at 2022-06-25 14:27:07.084666
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Arrange
    additional = set()
    # Act
    test_get_reserved_names = get_reserved_names(additional)
    # Assert
    assert len(test_get_reserved_names) == 60


# Generated at 2022-06-25 14:27:16.431322
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert len(var_0) == 27
    assert 'b' in var_0
    assert 'e' in var_0
    assert 'pre_tasks' in var_0
    assert 's' in var_0
    assert 'tags' in var_0
    assert '_gather_facts' in var_0
    assert 'a' in var_0
    assert 'd' in var_0
    assert 'post_tasks' in var_0
    assert 'r' in var_0
    assert 'tasks' in var_0
    assert '_block' in var_0
    assert 'c' in var_0
    assert 'f' in var_0
    assert 'handlers' in var_0
    assert 'q' in var_0

# Generated at 2022-06-25 14:27:21.194820
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert len(reserved_names) > 30
    assert 'any_errors_fatal' in reserved_names
    assert 'meta' not in reserved_names
    assert isinstance(reserved_names, set)

    assert 'meta' in get_reserved_names(include_private=True)
    assert 'meta' not in get_reserved_names(include_private=False)



# Generated at 2022-06-25 14:27:22.632024
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert all(item in get_reserved_names() for item in ['action', 'hosts', 'name'])


# Generated at 2022-06-25 14:27:29.988656
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Case 0: Simple test case
    var_0 = get_reserved_names()

# Generated at 2022-06-25 14:28:03.737635
# Unit test for function get_reserved_names
def test_get_reserved_names():
    current = get_reserved_names()
    assert current == _RESERVED_NAMES

# Generated at 2022-06-25 14:28:04.529482
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == None

# Generated at 2022-06-25 14:28:12.859599
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:20.644373
# Unit test for function get_reserved_names
def test_get_reserved_names():
    class_list = [Play, Role, Block, Task]
    all_keys = []
    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            all_keys.append(attribute)

    # local_action is implicit with action
    if 'action' in all_keys:
        all_keys.append('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    if 'loop' in all_keys:
        all_keys.append('with_')

    # test we get all the keys back
    var_0 = get_reserved_names()
    assert var_0 == set(all_keys)


# Generated at 2022-06-25 14:28:27.822220
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names(include_private=False)
    var_1 = set(['delegate_to', 'roles', 'tasks', 'name', 'any_errors_fatal', 'hosts', 'sudo', 'serial', 'block', 'hosts', 'register', 'remote_user', 'sudo_user', 'vars_files', 'when', 'async', 'connection', 'vars', 'gather_facts', 'become', 'become_user', 'failed_when', 'until', 'flush_handlers', 'tags', 'with_items', 'with_fileglob', 'with_first_found', 'with_sequence', 'with_subelements', 'notify', 'meta', 'no_log'])
    assert var_1 == _RESERVED_NAMES


# Generated at 2022-06-25 14:28:30.235460
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'exclude_hosts' in get_reserved_names(include_private=False)
    assert 'exclude_hosts' in get_reserved_names(include_private=True)


# Generated at 2022-06-25 14:28:35.930325
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:38.111025
# Unit test for function get_reserved_names
def test_get_reserved_names():

    names = get_reserved_names(include_private=False)
    assert isinstance(names, set)
    assert 'name' in names

    names = get_reserved_names()
    assert isinstance(names, set)
    assert 'name' in names



# Generated at 2022-06-25 14:28:39.466714
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-25 14:28:42.996655
# Unit test for function get_reserved_names
def test_get_reserved_names():

    var_0 = get_reserved_names()
    assert isinstance(var_0, set)
    assert len(var_0) == 58

    var_1 = get_reserved_names(include_private=False)
    assert isinstance(var_1, set)
    assert len(var_1) == 41



# Generated at 2022-06-25 14:30:00.411629
# Unit test for function get_reserved_names
def test_get_reserved_names():
    """ Test with no options """
    assert get_reserved_names(True)


# Generated at 2022-06-25 14:30:02.014462
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_vars = get_reserved_names()
    assert isinstance(reserved_vars, set)

# Generated at 2022-06-25 14:30:03.857795
# Unit test for function get_reserved_names
def test_get_reserved_names():

    try:
        assert test_case_0()
    except AssertionError as e:
        print(e)



# Generated at 2022-06-25 14:30:08.274957
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved_names = get_reserved_names()
    assert 'auth_password' in reserved_names
    assert 'any_errors_fatal' in reserved_names
    assert 'name' in reserved_names
    assert 'role_name' in reserved_names
    assert 'roles' in reserved_names

    # This should not happen but included for completeness
    assert not 'foobar_invalid_name' in reserved_names


# Generated at 2022-06-25 14:30:15.892590
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import tempfile

    var_1 = tempfile.tempdir
    class_list_0 = [Play, Role, Block, Task]
    public_1 = set()
    private_0 = set()
    result_0 = set()

    for aclass_0 in class_list_0:
        aobj_0 = aclass_0()

        for attribute_0 in aobj_0.__dict__['_attributes']:
            if 'private' in attribute_0:
                private_0.add(attribute_0)
            else:
                public_1.add(attribute_0)

    if 'action' in public_1:
        public_1.add('local_action')

    if 'loop' in private_0 or 'loop' in public_1:
        public_1.add('with_')

    result_

# Generated at 2022-06-25 14:30:25.162211
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:27.486066
# Unit test for function get_reserved_names
def test_get_reserved_names():
  myvars = get_reserved_names()
  assert isinstance(myvars, set)
  assert 'action' in myvars
  assert 'private' in myvars
  assert 'var' in myvars


# Generated at 2022-06-25 14:30:29.062323
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test with no arguments
    try:
        get_reserved_names()
    except TypeError:
        pass



# Generated at 2022-06-25 14:30:29.533587
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pass

# Generated at 2022-06-25 14:30:31.025934
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES



# Generated at 2022-06-25 14:31:57.019471
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert names is not None


# Generated at 2022-06-25 14:32:05.590992
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()

# Generated at 2022-06-25 14:32:09.961534
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:16.545618
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:24.040782
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:29.452734
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("Running tests on function get_reserved_names")
    # Test when input is not a string and not a list, should return a scalar
    var_0 = get_reserved_names(False)
    print(type(var_0))
    assert isinstance(var_0, set)

    # Test when input is not a string and not a list, should return a scalar
    var_0 = get_reserved_names(True)
    print(type(var_0))
    assert isinstance(var_0, set)



# Generated at 2022-06-25 14:32:30.699848
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(True)
    assert get_reserved_names()


# Generated at 2022-06-25 14:32:32.506588
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()  # TODO: choose an appropriate value for assert


# Generated at 2022-06-25 14:32:38.610185
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:32:39.922293
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: Mock/Test cases needed
    pass



# Generated at 2022-06-25 14:35:22.276956
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()


# Generated at 2022-06-25 14:35:22.970196
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()

# Generated at 2022-06-25 14:35:23.633630
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:35:29.482256
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Call function with arg: include_private = true
    results = get_reserved_names(True)
    assert (results == {'become', 'become_user', 'delegate_to', 'gather_facts', 'hosts', 'include', 'include_tasks', 'loop', 'name', 'no_log', 'notify', 'private', 'remote_user', 'roles', 'serial', 'strategy', 'sudo', 'sudo_user', 'tags', 'tasks', 'transport', 'vars'})

    # Call function with arg: include_private = false
    results = get_reserved_names(False)

# Generated at 2022-06-25 14:35:31.244608
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in _RESERVED_NAMES
    assert 'include_role' in _RESERVED_NAMES
    assert 'no_log' in _RESERVED_NAMES

# Generated at 2022-06-25 14:35:34.158400
# Unit test for function get_reserved_names
def test_get_reserved_names():
    with pytest.raises(TypeError) as excinfo:
        get_reserved_names(tuple_0)
    the_exception = excinfo.value
    assert 'list indices must be integers, not str' in str(the_exception)



# Generated at 2022-06-25 14:35:36.125638
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        get_reserved_names()
    except AnsibleError as e:
        msg = 'Exception raised (%s): %s' % (type(e), e)
        assert False, msg


# Generated at 2022-06-25 14:35:42.272388
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = {'action', 'hosts', 'name', 'tasks', 'vars', 'vars_files', 'with_', 'local_action'}

# Generated at 2022-06-25 14:35:44.705029
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test the get_reserved_names function '''
    with open('tests/unit/utils/get_reserved_names') as f:
        expected_result = f.read()
    print(expected_result)
    assert get_reserved_names() == expected_result


# Generated at 2022-06-25 14:35:47.300597
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # These tests are for the private functions
    from ansible.playbook import get_reserved_names
    assert get_reserved_names(include_private=True)
    assert get_reserved_names(include_private=False)

