

# Generated at 2022-06-25 14:26:20.067539
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()
    var_1.add('name')
    var_2 = get_reserved_names(include_private=True)
    var_1.union(var_2)
    assert var_1 == var_2

    # Set up test
    test_1 = {u'name': u'Sauce'}
    var_1 = get_reserved_names(include_private=False)
    var_2 = get_reserved_names(include_private=True)

    # Run unit test with set up and tear down
    #with pytest.raises(AttributeError):
    #    warn_if_reserved(test_1)
    assert var_2
    assert var_1



# Generated at 2022-06-25 14:26:29.103708
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test case 1
    assert ((get_reserved_names() == frozenset('post_tasks handler tasks vars serial ignore_errors delegate_to pre_tasks conditions name as_bool remote_user gather_facts environment any_errors always_run become_user changed_when check_mode connection delay when local_action action with_')) or (get_reserved_names() == frozenset('post_tasks handler tasks vars serial ignore_errors delegate_to pre_tasks conditions name as_bool remote_user gather_facts environment any_errors always_run become_user changed_when check_mode connection delay when local_action action with_')))

    # test case 2

# Generated at 2022-06-25 14:26:30.214677
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), type(set()))


# Generated at 2022-06-25 14:26:35.024339
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test function get_reserved_names'''
    public = set()
    private = set()
    expected = set()
    result = set()


    # build ordered list to loop over and dict with attributes
    for attribute in _PLAY_ATTRIBUTES:
        if 'private' in attribute:
            private.add(attribute)
        else:
            public.add(attribute)

    expected = public.union(private)

    result = get_reserved_names()

    assert result == expected



# Generated at 2022-06-25 14:26:36.064987
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:26:44.658063
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:52.320887
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    var_1 = get_reserved_names(False)

# Generated at 2022-06-25 14:27:01.349584
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:02.360148
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) is set



# Generated at 2022-06-25 14:27:08.539237
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This is a simple test without any parameters.
    print("Test no parameters")
    var_0 = get_reserved_names()
    print("var_0 = %s" % var_0)
    print("Test with private = true")
    var_1 = get_reserved_names(True)
    print("var_1 = %s" % var_1)
    print("Test with private = false")
    var_2 = get_reserved_names(False)
    print("var_2 = %s" % var_2)

# Generated at 2022-06-25 14:27:25.961839
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) == set


# Generated at 2022-06-25 14:27:33.549859
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:39.336041
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 49
    assert 'block' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'remote_user' in get_reserved_names()
    assert 'become' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'roles' in get_reserved_names()


# Generated at 2022-06-25 14:27:45.358665
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:47.770181
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: add better test cases
    var_0 = get_reserved_names()
    assert isinstance(var_0, set)


# Generated at 2022-06-25 14:27:49.293027
# Unit test for function get_reserved_names
def test_get_reserved_names():
    passwd = get_reserved_names()
    assert isinstance(passwd, str)



# Generated at 2022-06-25 14:27:49.873030
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) > 0


# Generated at 2022-06-25 14:27:50.730369
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()

# Generated at 2022-06-25 14:27:57.739335
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test function with default params (from pytest_ansible.py)
    var_1 = get_reserved_names()
    assert var_1.pop() == "with_lines"
    assert var_1.pop() == "with_items"
    assert var_1.pop() == "with_dict"
    assert var_1.pop() == "with_fileglob"
    assert var_1.pop() == "with_file"
    assert var_1.pop() == "with_first_found"
    assert var_1.pop() == "with_subelements"
    assert var_1.pop() == "when"
    assert var_1.pop() == "vars"
    assert var_1.pop() == "sudo_args"
    assert var_1.pop() == "sudo_flags"


# Generated at 2022-06-25 14:28:00.982676
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # No error when the include_private is True
    result = get_reserved_names(True)
    assert result != None
    assert isinstance(result, set)
    # No error when the include_private is False
    result = get_reserved_names(False)
    assert result != None
    assert isinstance(result, set)



# Generated at 2022-06-25 14:28:30.852940
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_cases = [0]
    for case_number in test_cases:
        print("Testing '%s'" % get_reserved_names.__name__)
        globals()['test_case_%s' % case_number]()



# Generated at 2022-06-25 14:28:32.460595
# Unit test for function get_reserved_names
def test_get_reserved_names():
    results = get_reserved_names()
    assert type(results) == set
    assert 'roles' in results


# Generated at 2022-06-25 14:28:37.976038
# Unit test for function get_reserved_names
def test_get_reserved_names():
    case_0 = test_case_0()


# Generated at 2022-06-25 14:28:42.931250
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) == set
    assert len(get_reserved_names()) == 32
    assert type(get_reserved_names(include_private=False)) == set
    assert len(get_reserved_names(include_private=False)) == 28
    assert type(get_reserved_names(include_private=True)) == set
    assert len(get_reserved_names(include_private=True)) == 32


# Generated at 2022-06-25 14:28:50.284403
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:58.799774
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.executor.playbook_executor import PlaybookExecutor
    

# Generated at 2022-06-25 14:29:07.114410
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:08.432122
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()

    assert len(var_1) > 0


# Generated at 2022-06-25 14:29:09.185311
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == None



# Generated at 2022-06-25 14:29:10.485808
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()
    assert isinstance(var_1, set)


# Generated at 2022-06-25 14:29:47.448688
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    var_1 = 'tags'
    var_0.add(var_1)
    assert var_0 == var_0


# Generated at 2022-06-25 14:29:49.348349
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var = get_reserved_names(include_private=True)
    assert isinstance(var, set)


# Generated at 2022-06-25 14:29:51.808885
# Unit test for function get_reserved_names
def test_get_reserved_names():
    play = Play()
    expected = frozenset(play._attributes)
    actual = frozenset(get_reserved_names())
    assert actual == expected

if __name__ == "__main__":
    test_get_reserved_names()

# Generated at 2022-06-25 14:29:55.115034
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert len(reserved_names) == 154
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'tags' in reserved_names
    assert 'any_errors_fatal' in reserved_names

# Generated at 2022-06-25 14:30:01.294662
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("TESTING get_reserved_names")

    play = Play()
    role = Role()
    task = Task()
    block = Block()

    play_names = []
    play_names.append(play.__dict__['_attributes'])
    play_names.append(play.__dict__['_role_attributes'])

    role_names = []
    role_names.append(role.__dict__['_attributes'])
    role_names.append(role.__dict__['_role_attributes'])

    task_names = []
    task_names.append(task.__dict__['_attributes'])
    task_names.append(task.__dict__['_role_attributes'])

    block_names = []

# Generated at 2022-06-25 14:30:02.164144
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:30:03.095288
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pass



# Generated at 2022-06-25 14:30:07.810532
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert len(names) > 0 and len(names) == len(set(names)), 'Got: %s' % (names,)
    assert 'tags' in names, 'Got: %s' % (names,)
    assert 'with_' in names, 'Got: %s' % (names,)
    assert 'loop' in names, 'Got: %s' % (names,)

# Unit tests for function is_reserved_name

# Generated at 2022-06-25 14:30:08.951074
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=True)


# Generated at 2022-06-25 14:30:09.981731
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)


# Generated at 2022-06-25 14:31:17.540577
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Tests for get_reserved_names()
    # We use sets to ensure values are unique, then test for equality
    assert get_reserved_names() == _RESERVED_NAMES


# Generated at 2022-06-25 14:31:18.401401
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:31:19.742077
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:31:21.992778
# Unit test for function get_reserved_names
def test_get_reserved_names():
    arguments = get_reserved_names()
    assert arguments == _RESERVED_NAMES, arguments


# Generated at 2022-06-25 14:31:29.304135
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:36.071315
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:37.763294
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: test is incomplete
    var_1 = get_reserved_names()
    assert var_1 is not None


# Generated at 2022-06-25 14:31:45.020661
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:31:45.604640
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()

# Generated at 2022-06-25 14:31:51.506147
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_1 = {'private', 'action', 'private', 'listen', 'block', 'gather_facts', 'local_action', 'sudo_user', 'roles', 'tasks', 'post_tasks', 'notify', 'sudo_pass', 'local_action', 'notify', 'when', 'include', 'block', 'user', 'local_action', 'sudo', 'hosts', 'become_method', 'connection', 'gather_facts', 'pre_tasks', 'playbook', 'environment', 'dependencies', 'include_vars', 'block', 'always_run', 'name', 'with_'}

# Generated at 2022-06-25 14:34:19.363234
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:34:21.055409
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # vars: function_return
    function_return = get_reserved_names()
    assert not False, 'Failed to get names.'


# Generated at 2022-06-25 14:34:29.027871
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:34:36.424005
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == {
        'action', 'any_errors_fatal', 'async', 'become_user', 'block', 'changed_when', 'check_mode', 'connection', 'delegate_facts', 'delegate_to', 'debug', 'delay', 'deprecate',
        'description', 'environment', 'failed_when', 'first_available_file', 'ignore_errors', 'local_action', 'name', 'notify', 'pause', 'pause_before', 'poll', 'register', 'remote_user',
        'role', 'run_once', 'run_once_with_handler', 'serial', 'sudo', 'sudo_user', 'tags', 'task', 'until', 'update_cache', 'vars', 'when', 'with_',
    }

# Generated at 2022-06-25 14:34:45.670820
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:34:46.444652
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_case_0()


# Generated at 2022-06-25 14:34:53.853267
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:34:55.757409
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:35:00.558940
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        assert(get_reserved_names() != None)
    except AssertionError as e:
        print(e)
    try:
        assert(get_reserved_names(False) != None)
    except AssertionError as e:
        print(e)
    try:
        assert(get_reserved_names(True) != None)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 14:35:01.258248
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() is not None