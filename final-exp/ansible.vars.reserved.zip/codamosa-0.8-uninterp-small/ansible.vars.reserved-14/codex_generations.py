

# Generated at 2022-06-25 14:26:29.106677
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == None


# Generated at 2022-06-25 14:26:36.390548
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # set parameter as defined
    include_private = True
    # execute function
    result = get_reserved_names(include_private)
    # check result is what was expected

# Generated at 2022-06-25 14:26:44.691442
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names(True)) == {'become_user', 'hosts', 'hosts_all', 'hostvars', 'inventory_hostname', 'inventory_hostname_short', 'magic_variables', 'playbook_dir', 'play_hosts', 'task_name', 'task_path', 'vars', 'vars_files'}
    assert set(get_reserved_names(False)) == {'become_user', 'hosts', 'hosts_all', 'hostvars', 'inventory_hostname', 'inventory_hostname_short', 'magic_variables', 'playbook_dir', 'play_hosts', 'task_name', 'task_path', 'vars', 'vars_files'}


# Generated at 2022-06-25 14:26:46.022565
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # run test case 0
    display.banner('Test case 0')
    test_case_0()



# Generated at 2022-06-25 14:26:49.339820
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ansible_options = {}
    ansible_options['private'] = True
    ansible_options['public'] = True
    var_0 = get_reserved_names()
    var_1 = get_reserved_names(ansible_options)


# Generated at 2022-06-25 14:26:51.195075
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        assert test_case_0() == None
    except AssertionError as e:
        print('AssertionError: %s' % e)


# Generated at 2022-06-25 14:26:54.311577
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        assert len(test_case_0()) > 0
    except AssertionError as e:
        print("test_case_0() failed: " + str(e))
        return False
    else:
        return True



# Generated at 2022-06-25 14:26:55.541943
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() is not None



# Generated at 2022-06-25 14:27:03.563796
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()

# Generated at 2022-06-25 14:27:13.441298
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Get the reserved names
    var_0 = get_reserved_names()

    # Check if the returned type is correct
    assert isinstance(var_0, set)

    # Make sure that the list of reserved names has at least one element
    assert len(var_0) > 0

    # Check that the first element of the set is a string and not empty
    var_0_first = ''
    for x in var_0:
        var_0_first = x
        break
    assert isinstance(var_0_first, basestring)
    assert var_0_first != ''

    # Check that a public name is in the set
    assert 'name' in var_0
    
    # Check that a private name is in the set
    assert 'remote_user' in var_0

    # Get a set containing only the public

# Generated at 2022-06-25 14:27:38.753420
# Unit test for function get_reserved_names
def test_get_reserved_names():
    res = get_reserved_names(include_private=True)
    assert 'gather_facts' in res
    assert 'roles' in res
    assert 'sudo_user' in res
    assert 'environment' in res
    assert 'vars_prompt' in res
    assert 'any_errors_fatal' in res
    assert 'max_fail_percentage' in res
    assert 'ignore_errors' in res
    assert 'become_user' in res
    assert 'become' in res
    assert 'connection' in res
    assert 'no_log' in res
    assert 'sudo' in res
    assert 'sudo_user' in res
    assert 'when' in res
    assert 'block' in res
    assert 'include_role' in res
    assert 'include_tasks' in res

# Generated at 2022-06-25 14:27:39.850231
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) is set


# Generated at 2022-06-25 14:27:45.636912
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:50.141124
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:27:51.240880
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 400         # Ansible >= 2.7.0
    assert len(get_reserved_names()) == 382         # Ansible >= 2.5.0


# Generated at 2022-06-25 14:27:51.837991
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) is set


# Generated at 2022-06-25 14:27:53.541143
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 137
    assert len(get_reserved_names(include_private=False)) == 44


# Generated at 2022-06-25 14:27:54.286534
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:28:00.351527
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert(var_0 == {'action', 'connection', 'hosts', 'local_action', 'loop', 'name', 'tags',
                    'tasks', 'vars_files', 'with_items', 'with_fileglob', 'with_nested',
                    'with_subelements', 'with_together', 'with_file', 'with_first_found',
                    'with_flattened', 'with_subelements', 'with_sequence', 'with_hashed',
                    'with_dict', 'with_lines', 'with_glob', 'private_key_file', 'become',
                    'become_user', 'delegate_to', 'gather_facts', 'condition', 'notify', 'when'})


# Generated at 2022-06-25 14:28:01.346017
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: this doesn't really assert much
    assert test_case_0() is None

# Generated at 2022-06-25 14:28:35.648273
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names(include_private=False)
    assert len(var_1) == 144
    var_2 = get_reserved_names()
    assert len(var_2) == 156



# Generated at 2022-06-25 14:28:38.486345
# Unit test for function get_reserved_names
def test_get_reserved_names():
  # Some of these may fail if we add names, but then again
  # we might want to know if we do.
    assert 'vars' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'serial' in get_reserved_names()
    assert 'become' in get_reserved_names()



# Generated at 2022-06-25 14:28:41.915349
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) == frozenset, "get_reserved_names() should return frozenset"
    assert type(get_reserved_names(False)) == frozenset, "get_reserved_names() should return frozenset"


# Generated at 2022-06-25 14:28:42.930580
# Unit test for function get_reserved_names
def test_get_reserved_names():
    obj = get_reserved_names()
    assert obj is not None


# Generated at 2022-06-25 14:28:50.284477
# Unit test for function get_reserved_names
def test_get_reserved_names():
    results = get_reserved_names()

# Generated at 2022-06-25 14:28:58.754095
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = ['name', 'port', 'transport', 'remote_user', 'remote_port',
                      'connection', 'gather_facts', 'become', 'become_user', 'forks',
                      'serial', 'any_errors_fatal', 'hosts', 'roles', 'vars_files',
                      'vars_prompt', 'vault_files', 'tags', 'skip_tags', 'start_at_task',
                      'action', 'environment', 'no_log', 'run_once', 'sudo_user',
                      'sudo', 'async', 'poll', 'until', 'ignore_errors',
                      'listen', 'delegate_to', 'run_once', 'local_action', 'gather_facts',
                      'with_items', 'with_together']
    actual = get_reserved_

# Generated at 2022-06-25 14:29:00.485102
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert var_0 is not None



# Generated at 2022-06-25 14:29:01.269970
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()



# Generated at 2022-06-25 14:29:04.923177
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 38

##################################################################
#
# Test Case:
#
#    Test warning_if_reserved
#
# Test Conditions:
#
#    - None
#
# Input:
#
#    - None
#
# Output:
#
#    - None
#
##################################################################


# Generated at 2022-06-25 14:29:06.524736
# Unit test for function get_reserved_names
def test_get_reserved_names():
    results = get_reserved_names()
    assert isinstance(results, set)



# Generated at 2022-06-25 14:30:25.845324
# Unit test for function get_reserved_names
def test_get_reserved_names():
    class Test(object):
        # FIXME: handle properly
        _attributes = frozenset
        # FIXME: handle properly
        __dict__ = frozenset
    class Test2(object):
        # FIXME: handle properly
        _attributes = frozenset
        # FIXME: handle properly
        __dict__ = frozenset
    class Test3(object):
        # FIXME: handle properly
        _attributes = frozenset
        # FIXME: handle properly
        __dict__ = frozenset
    class Test4(object):
        # FIXME: handle properly
        _attributes = frozenset
        # FIXME: handle properly
        __dict__ = frozenset
    class Test5(object):
        # FIXME: handle properly
        _attributes = frozenset
        # FIXME: handle properly

# Generated at 2022-06-25 14:30:33.181159
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'post_tasks' in get_reserved_names(), \
        'Post-tasks not in get_reserved_names'
    assert 'pre_tasks' in get_reserved_names(), \
        'Pre-tasks not in get_reserved_names'
    assert 'roles' in get_reserved_names(), \
        'Roles not in get_reserved_names'
    assert 'vars' in get_reserved_names(), \
        'Vars not in get_reserved_names'
    assert 'name' in get_reserved_names(), \
        'Name not in get_reserved_names'
    assert 'connection' in get_reserved_names(), \
        'Connection not in get_reserved_names'

# Generated at 2022-06-25 14:30:34.169110
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(set(get_reserved_names())) >= 24


# Generated at 2022-06-25 14:30:35.425318
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert type(var_0) == set



# Generated at 2022-06-25 14:30:36.751868
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'strategy' in get_reserved_names()


# Generated at 2022-06-25 14:30:38.858961
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, frozenset)
    assert len(reserved_names) > 10


# Generated at 2022-06-25 14:30:45.888099
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:30:46.540635
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() is not None

# Generated at 2022-06-25 14:30:47.396604
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == set()


# Generated at 2022-06-25 14:30:53.179082
# Unit test for function get_reserved_names
def test_get_reserved_names():
    _RESERVED_NAMES = frozenset(get_reserved_names())
    
    block = Block()
    role = Role()
    play = Play()
    task = Task()
    assert isinstance(block, Block)
    assert isinstance(role, Role)
    assert isinstance(play, Play)
    assert isinstance(task, Task)
    assert _RESERVED_NAMES
    assert isinstance(_RESERVED_NAMES, set)
    assert 'rescue' in _RESERVED_NAMES
    assert 'debugger' in _RESERVED_NAMES
    assert 'other' not in _RESERVED_NAMES
    assert 'tags' in _RESERVED_NAMES


# Generated at 2022-06-25 14:33:35.826176
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()
    var_2 = get_reserved_names(include_private=False)

    assert(var_1 == var_2)

    assert(len(var_2) == 29)
    assert('roles' in var_2)
    assert('hosts' in var_2)


# Generated at 2022-06-25 14:33:44.006589
# Unit test for function get_reserved_names
def test_get_reserved_names():
    data_0 = [
        {'include_private': True, 'result': frozenset({'become', 'become_user', 'block', 'block_errors', 'connection', 'delegate_to', 'environment', 'ignore_errors', 'local_action', 'loop', 'no_log', 'notify', 'poll', 'register', 'remote_user', 'role_name', 'run_once', 'serial', 'sudo', 'sudo_user', 'tasks', 'when', 'with'})},
        {'include_private': False, 'result': frozenset({'become', 'connection', 'delegate_to', 'environment', 'local_action', 'loop', 'no_log', 'notify', 'poll', 'register', 'run_once', 'serial', 'sudo', 'when', 'with'})}
    ]
   

# Generated at 2022-06-25 14:33:46.430505
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Arrange
    var_0 = set()

    # Act
    var_1 = get_reserved_names()

    # Assert
    assert type(var_1) == type(var_0)


# Generated at 2022-06-25 14:33:53.061685
# Unit test for function get_reserved_names
def test_get_reserved_names():

    class_list = [Play, Role, Block, Task]

# Generated at 2022-06-25 14:33:57.407575
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Test for function get_reserved_names.
    '''
    assert(get_reserved_names() == ['hosts', 'name', 'become', 'become_method', 'become_user', 'block', 'block_var', 'connection', 'delegate_to', 'gather_facts', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'meta', 'no_log', 'notify', 'post_tasks', 'pre_tasks', 'roles', 'serial', 'tags', 'task', 'tasks', 'vars', 'when', 'local_action', 'with_'])


# Generated at 2022-06-25 14:34:05.856192
# Unit test for function get_reserved_names
def test_get_reserved_names():
    function_name = 'get_reserved_names'
    test_cases = [
        {
            "args": [],
            "assert":
            {
                "assert": "isinstance",
                "value": "frozenset",
            }
        },
        {
            "args": [True],
            "assert":
            {
                "assert": "isinstance",
                "value": "frozenset",
            }
        }
    ]
    for test_case in test_cases:
        args = test_case["args"]
        result = get_reserved_names(*args)
        test_assert = test_case["assert"]
        assert_type = test_assert["assert"]
        assert_value = test_assert["value"]
        assert_return = False


# Generated at 2022-06-25 14:34:14.938202
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:34:18.067179
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert type(var_0) == set
    if not var_0:
        print('No variables found')
    else:
        for v in var_0:
            print('', v)


# Generated at 2022-06-25 14:34:22.661858
# Unit test for function get_reserved_names
def test_get_reserved_names():

    this_data = {
        'roles': ['role_a', 'role_b'],
        'tasks': ['task_a', 'task_b'],
        'blocks': ['block_a', 'block_b'],
        'hosts': ['host_a', 'host_b']
    }

    for key in this_data.keys():
        assert key in get_reserved_names(False), \
            "Failed to find '%s' in the reserved names" % key

    assert 'local_action' not in get_reserved_names(False), "local_action should not be in the reserved names"


# Generated at 2022-06-25 14:34:24.757852
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
