

# Generated at 2022-06-25 14:26:31.823813
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # FIXME: use actual assert, also with support for pytest
    try:
        assert(test_case_0())
    except AssertionError:
        raise AssertionError()

# Generated at 2022-06-25 14:26:33.215711
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset), 'Did not return frozenset'


# Generated at 2022-06-25 14:26:39.590636
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:26:47.377660
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private = ['private', 'vars', 'register']

# Generated at 2022-06-25 14:26:51.126997
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print('Unit test for function get_reserved_names')
    var_0 = get_reserved_names()

    if type(var_0) is set:
        print('get_reserved_names() returned the correct type')
    else:
        raise AssertionError('Type returned by get_reserved_names() was not correct')


# Generated at 2022-06-25 14:26:52.950789
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # get_reserved_names() should find the list of reserved names

    # This is a test
    assert type(test_case_0) is frozenset


# Generated at 2022-06-25 14:26:58.997258
# Unit test for function get_reserved_names
def test_get_reserved_names():
   reserved_names = get_reserved_names()
   reserved_names.add('vars')
   reserved_names.add('gather_facts')
   reserved_names.add('priority')
   reserved_names.add('ignore_errors')
   assert len(reserved_names) > 0

   assert 'gather_facts' in reserved_names
   assert 'priority' in reserved_names
   assert 'ignore_errors' in reserved_names
   assert 'vars' in reserved_names

# Generated at 2022-06-25 14:27:00.267530
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()


# Generated at 2022-06-25 14:27:01.314730
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert test_case_0() == None


# Generated at 2022-06-25 14:27:09.693390
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # need to move those to unit tests
    #reserved_names = get_reserved_names()
    #print len(reserved_names)
    #for name in reserved_names:
    #    print "name=%s" % name
    #print reserved_names

    reserved_names = get_reserved_names()
    assert len(reserved_names) == 72
    assert 'remote_user' in reserved_names
    assert 'any_errors_fatal' in reserved_names
    assert 'ignore_errors' in reserved_names
    assert 'local_action' in reserved_names
    assert 'vars' in reserved_names
    assert 'with_items' in reserved_names
    assert 'connection' in reserved_names
    assert 'hosts' in reserved_names
    assert 'gather_facts' in reserved_names


# Generated at 2022-06-25 14:27:54.729154
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:02.808190
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:09.167613
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Check basic functionality
    var_0 = get_reserved_names()
    assert type(var_0) == set
    assert 'action' in var_0

    # Check that includes private attributes
    var_0 = get_reserved_names(include_private=False)
    assert type(var_0) == set
    assert 'accelerate' in var_0

    # Check that normal use excludes private attributes
    var_0 = get_reserved_names(include_private=True)
    assert type(var_0) == set
    assert 'accelerate' not in var_0


# Generated at 2022-06-25 14:28:17.415069
# Unit test for function get_reserved_names
def test_get_reserved_names():
    aobj_1 = [
        Play(),
        Role(),
        Block(),
        Task()]

# Generated at 2022-06-25 14:28:24.729585
# Unit test for function get_reserved_names
def test_get_reserved_names():
    vars_0 = set(['tags', 'name', 'included_files', 'roles', 'roles_path', 'handlers',
                  'hosts', 'gather_facts', 'user', 'vars', 'vault_password_file', 'pre_tasks',
                  'remote_user', 'block', 'post_tasks', 'meta', 'private', 'tags', 'hosts',
                  'become', 'become_user', 'register', 'action', 'notify',
                  'local_action', 'ignore_errors', 'vars', 'include', 'include_tasks',
                  'include_role', 'import_tasks', 'delegate_to', 'when', 'async', 'poll'])

# Generated at 2022-06-25 14:28:27.379744
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check if function returns the correct result
    assert get_reserved_names() == _RESERVED_NAMES

    # Check if function returns names when private set to True
    assert get_reserved_names(False) != _RESERVED_NAMES



# Generated at 2022-06-25 14:28:28.872913
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names()
    var_2 = get_reserved_names(False)



# Generated at 2022-06-25 14:28:29.804044
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() is not None


# Generated at 2022-06-25 14:28:35.622627
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:28:42.760340
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_1 = get_reserved_names(False)
    var_2 = get_reserved_names(True)
    assert var_1 == var_2.difference('private', 'vars')
    #assert var_2 == ['name', 'hosts', 'roles', 'gather_facts', 'tasks', 'handlers', 'vars', 'vars_files', 'connection', 'sudo', 'sudo_user', 'transport', 'remote_user', 'remote_port', 'module_defaults', 'any_errors_fatal', 'max_fail_percentage', 'serial', 'accelerate', 'accelerate_ipv6', 'accelerate_port', 'vault_password', 'become', 'become_method', 'become_user', 'environment', 'no_log', 'tags', 'skip_

# Generated at 2022-06-25 14:29:47.229560
# Unit test for function get_reserved_names
def test_get_reserved_names():
    p = Play()
    p.post_validate()
    assert len(p.RESERVED_WORDS) == 151



# Generated at 2022-06-25 14:29:54.875972
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:29:56.713281
# Unit test for function get_reserved_names
def test_get_reserved_names():
    var_0 = get_reserved_names()
    assert len(var_0) == 127
    assert "allow_duplicates" in var_0


# Generated at 2022-06-25 14:29:59.939722
# Unit test for function get_reserved_names
def test_get_reserved_names():
    passed = True

    reserved_list = get_reserved_names()
    if reserved_list is None:
        passed = False
    elif len(reserved_list) == 0:
        passed = False

    if not passed:
        display.error('Test get_reserved_names(): FAILED')
        display.display(reserved_list)

    return passed


# Generated at 2022-06-25 14:30:07.919746
# Unit test for function get_reserved_names
def test_get_reserved_names():

    var_0 = get_reserved_names()


# Generated at 2022-06-25 14:30:09.053806
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 52


# Generated at 2022-06-25 14:30:11.835199
# Unit test for function get_reserved_names
def test_get_reserved_names():
    for aclass in [Play, Role, Block, Task]:
        aobj = aclass()
        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            assert attribute.name in _RESERVED_NAMES

# Generated at 2022-06-25 14:30:17.616154
# Unit test for function get_reserved_names
def test_get_reserved_names():

    var_0 = get_reserved_names()

    assert 'block' in var_0
    assert 'name' in var_0
    assert 'vars' not in var_0
    assert 'roles' not in var_0
    assert 'playbooks' not in var_0
    assert 'host_list' not in var_0
    assert 'vault_password' not in var_0
    assert 'forks' not in var_0
    assert 'include_role' not in var_0
    assert 'action' in var_0
    assert 'local_action' in var_0

# Generated at 2022-06-25 14:30:19.814373
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: this test is pretty lame
    var_0 = get_reserved_names(include_private=False)



# Generated at 2022-06-25 14:30:22.055663
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test_get_reserved_names can be used to check that the list of reserved names is
        not corrupted.
    '''
    test_case_0()



# Generated at 2022-06-25 14:33:01.804868
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'action' in names
    assert 'playbook' in names
    assert '_role' in names
    assert 'name' in names
    assert 'hosts' in names
    assert 'gather_facts' in names
    assert 'vars' in names
    assert 'block' in names
    assert 'when' in names
    assert 'changed_when' in names
    assert 'failed_when' in names
    assert 'notify' in names
    assert 'register' in names


# Generated at 2022-06-25 14:33:03.378049
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("\nBEGIN function 'get_reserved_names' testing")
    # Test case 0
    print("\nTest case 0")
    var_0 = get_reserved_names()
    assert isinstance(var_0, set)
    print("\nPass")



# Generated at 2022-06-25 14:33:12.763597
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)

# Generated at 2022-06-25 14:33:19.074565
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:20.572607
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names()


# Generated at 2022-06-25 14:33:24.422724
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == set(['name', 'action', 'async', 'delegate_to', 'environment', 'local_action', 'with_', 'meta', 'notify', 'poll', 'register',
                                             'remote_user', 'serial', 'su', 'sudo', 'sudo_user', 'tags', 'transport', 'vars'])



# Generated at 2022-06-25 14:33:31.867519
# Unit test for function get_reserved_names

# Generated at 2022-06-25 14:33:34.545492
# Unit test for function get_reserved_names
def test_get_reserved_names():
    for var_test in (0,1,2):
        yield test_case_0, var_test

if __name__ == '__main__':
    get_reserved_names()

# Generated at 2022-06-25 14:33:42.446547
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset({'async', 'block', 'block_rescue', 'block_always', 'block_errors', 'block_start', 'block_end', 'cache', 'changed_when', 'connection', 'delegate_facts', 'delegate_to', 'environment', 'failed_when', 'gather_facts', 'handlers', 'ignore_errors', 'include', 'include_role', 'include_tasks', 'includes', 'inject', 'listen', 'local_action', 'loop', 'name', 'notify', 'no_log', 'post_tasks', 'pre_tasks', 'precedence', 'register', 'retries', 'roles', 'serial', 'strategy', 'tags', 'tasks', 'when'})


# Generated at 2022-06-25 14:33:43.438090
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert "post_tasks" in get_reserved_names()