

# Generated at 2022-06-23 15:19:47.197883
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('hosts_path')
    assert is_reserved_name('included_roles')
    assert not is_reserved_name('vars')
    assert is_reserved_name('name')
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('not_reserved')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('when')
    assert is_reserved_name('max_fail_percentage')

# Generated at 2022-06-23 15:19:56.617367
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test some arbitrary names
    assert not is_reserved_name("not_reserved")
    assert is_reserved_name("name")
    assert is_reserved_name("action")
    assert is_reserved_name("include_role")

    # Test name with _
    assert is_reserved_name("name_")
    assert is_reserved_name("_name")
    assert is_reserved_name("a_name")
    assert is_reserved_name("name_b")
    assert is_reserved_name("_name_")
    assert not is_reserved_name("__name")
    assert not is_reserved_name("name__")

# Generated at 2022-06-23 15:20:00.828607
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    warning should be raised when reserved variable name is present
    '''
    # test_variable_name_is_not_reserved
    assert warn_if_reserved(['not_reserved']) == None

    # test_variable_name_is_reserved
    assert warn_if_reserved(['action'])

# Generated at 2022-06-23 15:20:02.688606
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts': 'localhost', 'name': 'test', 'invalid': 'crap'})

# Generated at 2022-06-23 15:20:04.769369
# Unit test for function is_reserved_name
def test_is_reserved_name():
    try:
        is_reserved_name('task')
    except:
        print("%s: Failed to detect reserved name 'task'" % __name__)

# Generated at 2022-06-23 15:20:15.605572
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test warn_if_reserved function '''
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task_include import TaskIncludeArgs
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    # We need this to be sure we have all reserved words
    _RESERVED_NAMES = frozenset(get_reserved_names())

    # We create a dict with all reserved words
    myvars = {}
    for reserved_name in _RESERVED_NAMES:
        myvars[reserved_name] = ""

    # It must raise a warning at least once
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:20:17.343846
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('not_a_reserved_name')


# Generated at 2022-06-23 15:20:18.673654
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')

# Generated at 2022-06-23 15:20:27.394794
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('hosts'))
    assert(is_reserved_name('hosts') == is_reserved_name('Hosts'))
    assert(is_reserved_name('role_name') is False)
    assert(is_reserved_name('action') == is_reserved_name('local_action'))
    assert(is_reserved_name('action') == is_reserved_name('ACTiOn'))
    assert(is_reserved_name('when'))
    assert(is_reserved_name('debug') is False)
    assert(is_reserved_name('name'))
    assert(is_reserved_name('loop'))
    assert(is_reserved_name('loop') == is_reserved_name('with_'))

# Generated at 2022-06-23 15:20:29.054770
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['test', 'action', 'connection', 'local_action'], additional=['test2', 'test3'])

# Generated at 2022-06-23 15:20:35.186851
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = dict()
    myvars['vars'] = dict()

    myvars['vars']['garbage'] = 'foo'
    myvars['vars']['private_private_private'] = 'foo'
    myvars['vars']['loop'] = 'foo'
    myvars['vars']['with_'] = 'foo'

    warn_if_reserved(myvars)


if __name__ == '__main__':
    test_warn_if_reserved()

# Generated at 2022-06-23 15:20:46.380666
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = get_reserved_names()
    reserved_names = set(reserved_names)
    assert len(reserved_names) > 0
    assert 'block' in reserved_names
    assert 'tasks' in reserved_names
    assert 'no_log' in reserved_names
    assert 'become' in reserved_names

    assert is_reserved_name('block')
    assert is_reserved_name('tasks')
    assert is_reserved_name('no_log')
    assert is_reserved_name('become')

    assert not is_reserved_name('host')
    assert not is_reserved_name('name')
    assert not is_reserved_name('user')
    assert not is_reserved_name('debug')

# Generated at 2022-06-23 15:20:56.058782
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests if get_reserved_names() returns the expected content '''

    print(get_reserved_names(include_private=False))

    # test for regression in reserved names
    # TODO: update this list when deps/includes are solved in order to find a better way to get the reserved names

# Generated at 2022-06-23 15:21:01.352493
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('include')
    assert is_reserved_name('name')
    assert is_reserved_name('block')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert not is_reserved_name('vars')


# unit test for get_reserved_names

# Generated at 2022-06-23 15:21:05.161916
# Unit test for function get_reserved_names
def test_get_reserved_names():
    playobj = Play()
    assert 'hosts' in get_reserved_names()
    assert all(x in get_reserved_names() for x in playobj.__dict__['_attributes'])

# Generated at 2022-06-23 15:21:13.018451
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(
        [u'action',
         u'become',
         u'become_flags',
         u'become_method',
         u'become_user',
         u'connection',
         u'environment',
         u'gather_facts',
         u'handlers',
         u'hosts',
         u'local_action',
         u'tasks',
         u'when',
         ])

# Generated at 2022-06-23 15:21:14.956234
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts', 'connection'])

# Generated at 2022-06-23 15:21:22.129105
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.vault import VaultLib

    reserved = get_reserved_names()
    v = VaultLib("abcd")
    myvars = dict()
    for i in reserved:
        myvars[i] = v.encrypt("test")
    warn_if_reserved(myvars)

    myvars = dict()
    myvars['tasks'] = v.encrypt("test")
    warn_if_reserved(myvars)
    for i in reserved:
        myvars[i] = v.encrypt("test")
    warn_if_reserved(myvars)
    myvars = dict()
    myvars[v.encrypt("test")] = v.encrypt("test")
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:21:26.800651
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''test the warn_if_reserved function'''

    host_vars = {'hostvars': 'foo'}
    vars = {'vars': 'foo'}
    play = {'play': 'bar'}
    tasks = {'tasks': 'baz'}
    include = {'include': 'another'}
    block = {'block': 'another'}

    for test in [host_vars, vars, play, tasks, include, block]:
        warn_if_reserved(test)

# Generated at 2022-06-23 15:21:33.573862
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('block')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('hosts')
    assert is_reserved_name('with_items')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('ignore_errors')

# Generated at 2022-06-23 15:21:42.689344
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = [
        'include',
        'roles',
        'hosts',
        'tasks',
        'vars',
        'name',
        'action',
        'pre_tasks',
        'post_tasks',
        'handlers',
        'tags',
        'when',
        'environment',
        'register',
        'ignore_errors',
    ]

    warn_if_reserved(vars)

    additional_reserved = [
        'listen',
        'vars',
        'delegate_to',
        'delegate_facts',
        'notify',
        'tags',
        'meta',
        'gather_facts',
    ]

    warn_if_reserved(vars, additional_reserved)

    # This is needed to avoid the test failing

# Generated at 2022-06-23 15:21:43.185559
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')

# Generated at 2022-06-23 15:21:50.564454
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # makes sure tests are run on a clean (reserved names) set
    reboot_reserved_names = frozenset(get_reserved_names())

    def warn_if_reserved(*args, **kwargs):
        assert args[0] == {'action', 'loop', 'become'}
        assert args[1] == frozenset({'gather_facts', 'vars'})

    # for some reason, the new_callable= keyword had to be added in py2.7
    from mock import patch, MagicMock
    p = patch('ansible.playbook.helpers.warn_if_reserved', autospec=True, new_callable=MagicMock)
    res = p.start()
    res.side_effect = warn_if_reserved


# Generated at 2022-06-23 15:21:56.420913
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import os
    import tempfile
    import datetime
    from collections import namedtuple

    tmpdir = tempfile.mkdtemp()
    fd, path = tempfile.mkstemp(suffix='.yml', dir=tmpdir)
    with open(path, mode='wt') as f:
        f.write("""
variable_in_yaml: 'value of the variable'
play:
  action:
    module: this_module
    local_action: another_module
    loop: item
    with_:
      - list_value
""")

    # Provide namedtuple instead of file
    FakeVars = namedtuple('FakeVars', ['items', 'get', '_get_name'])

# Generated at 2022-06-23 15:21:57.309829
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')

# Generated at 2022-06-23 15:22:07.520468
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests get_reserved_names()'''

# Generated at 2022-06-23 15:22:17.755911
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert warn_if_reserved([]) == None
    assert warn_if_reserved(['vars']) == None
    assert warn_if_reserved(['vars', 'foo']) == None
    assert warn_if_reserved(['foo', 'name']) == None
    assert warn_if_reserved(['foo', 'name', 'bar', 'tags']) == None

    assert is_reserved_name('foo') == False
    assert is_reserved_name('name') == True
    assert is_reserved_name('bar') == False
    assert is_reserved_name('tags') == True

# Generated at 2022-06-23 15:22:23.335162
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars') == True
    assert is_reserved_name('vars_files') == True
    assert is_reserved_name('vars_prompt') == True
    assert is_reserved_name('vars_prompt_format') == True
    assert is_reserved_name('playbook') == True
    assert is_reserved_name('gather_facts') == True
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('name') == True
    assert is_reserved_name('pre_tasks') == True
    assert is_reserved_name('post_tasks') == True
    assert is_reserved_name('roles') == True
    assert is_reserved_name('tasks') == True
    assert is_

# Generated at 2022-06-23 15:22:25.289025
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts', 'vars', 'roles'])


# Generated at 2022-06-23 15:22:31.182880
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = {'tags': 'all', 'any_errors_fatal': True, 'delegate_to': 'localhost', 'action': 'setup'}
    warn_if_reserved(myvars)

    # there are no warning
    try:
        import sys
        print('\n'.join(str(x) for x in sys.stderr.getvalue().split('\n') if x.startswith('Warning:')))
        assert(False)
    except AssertionError:
        pass

# Generated at 2022-06-23 15:22:32.987400
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('foo')



# Generated at 2022-06-23 15:22:42.581546
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    display.verbosity = 5
    # Test 1: varnames exactly matches reserved names
    varnames = {'role_name', 'roles_path', 'name', 'included_roles'}
    ans = warn_if_reserved(varnames)
    assert ans is None, 'warn_if_reserved should return None'

    # Test 2: varnames does not match reserved names
    varnames = {'role_name2', 'name2', 'roles_path2', 'included_roles2'}
    ans = warn_if_reserved(varnames)
    assert ans is None, 'warn_if_reserved should return None'

    # Test 3: varnames partially matches reserved names

# Generated at 2022-06-23 15:22:43.457535
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')



# Generated at 2022-06-23 15:22:47.110614
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert not warn_if_reserved(['name'])
    assert warn_if_reserved(['name', 'delegate_to'])



# Generated at 2022-06-23 15:22:52.001618
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class MockDisplay(object):
        def __init__(self):
            self.warnings = []

        def warning(self, msg):
            self.warnings.append(msg)

    class MockVars(object):
        class __metaclass__(type):
            def __iter__(self):
                return iter(['action', 'vars', 'foo'])

    display = MockDisplay()
    warn_if_reserved(MockVars(), additional={'vars'})
    assert display.warnings == ['Found variable using reserved name: vars']

# Generated at 2022-06-23 15:22:57.836226
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # FIXME: how to test things that trigger warning output?
    # warn_if_reserved(['become'])

    passing = ['bob', 'tru', 'soc']
    failing = ['become', 'become_user', 'any_errors_fatal', 'action', 'loop', 'with_']

    for name in passing:
        assert not is_reserved_name(name)

    for name in failing:
        assert is_reserved_name(name)

# Generated at 2022-06-23 15:22:59.092575
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts'])



# Generated at 2022-06-23 15:23:03.292560
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function and its unit test are a good way to ensure we did not introduce any new reserved names '''

    # for example, appending 'playbook_dir' to this list, and running
    # nosetests [playbook/...]/test_play_context.py:test_get_reserved_names
    # will give an exhaustive list of reserved names

# Generated at 2022-06-23 15:23:08.123408
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest
    warn_if_reserved(['foobar'])
    warn_if_reserved(['action'])
    with pytest.raises(AssertionError) as excinfo:
        warn_if_reserved(['foobar'])
        assert 'Found variable using reserved name' in str(excinfo.value)

# Generated at 2022-06-23 15:23:12.217796
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test non-deprecated reserved names
    warn_if_reserved(['hosts', 'name', 'roles', 'tasks'])

    # Test deprecated reserved names
    warn_if_reserved(['task', 'role', 'play', 'block'])

    # Test additional reserved names
    warn_if_reserved(['playbook'], additional=['playbook'])

# Generated at 2022-06-23 15:23:19.259302
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved_names = get_reserved_names()

    # check we have all the required names
    assert reserved_names.issuperset(['action', 'gather_facts', 'delegate_to', 'become', 'become_user', 'become_method', 'local_action'])

    # check that no private names are included
    assert 'loop' not in reserved_names
    assert 'with_items' not in reserved_names

    # check we have all the required names including the private names
    assert get_reserved_names(include_private=True).issuperset(['loop', 'with_items'])

# Generated at 2022-06-23 15:23:27.739633
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('vars')

    # the following two are not 'reserved' per se, but are added as synonyms based on 'action' and 'loop'
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')

    assert not is_reserved_name('play')
    assert not is_reserved_name('block')
    assert not is_reserved_name('roles')
    assert not is_reserved_name('tasks')

# Generated at 2022-06-23 15:23:33.663920
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    display.verbosity = 3
    display.columns = 80

    # no warning generated, because 'vars' is in the list of reserved names, but we do not warn on it
    warn_if_reserved({'vars': 'something'})
    # this should generate warnings
    warn_if_reserved({'tasks': 'something'})
    warn_if_reserved({'roles': 'something'})
    warn_if_reserved({
        'tasks': 'something',
        'roles': 'something'})

# Generated at 2022-06-23 15:23:36.108894
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('hostsssss') == False

# Generated at 2022-06-23 15:23:45.826001
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:23:49.636525
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("name")
    assert is_reserved_name("action")
    assert is_reserved_name("delegate_to")
    assert is_reserved_name("register")
    assert is_reserved_name("environment")
    assert not is_reserved_name("foobar")

# Generated at 2022-06-23 15:23:59.905977
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['vars', 'action', 'roles'])
    except AssertionError:
        assert False, "Failed to handle valid reserved word."

    try:
        warn_if_reserved(['vars', 'action', 'roles', 'secret'])
    except AssertionError:
        assert False, "Failed to handle valid reserved word private."

    try:
        warn_if_reserved(['vars', 'action', 'roles', 'secret', 'vault_password_file'])
    except AssertionError:
        assert False, "Failed to handle valid reserved word private when including private."


# Generated at 2022-06-23 15:24:08.469703
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'listen' not in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'tags' in _RESERVED_NAMES
    assert 'any_errors_fatal' in _RESERVED_NAMES
    assert 'ignore_errors' in _RESERVED_NAMES
    assert 'deprecated' in _RESERVED_NAMES
    assert 'role_path' in _RESERVED_NAMES
    assert 'vars_files' in _RESERVED_NAMES
    assert 'gather_facts' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'roles_path' in _RESERVED_NAMES
    assert 'become_user' in _RESER

# Generated at 2022-06-23 15:24:12.365105
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = get_reserved_names(False)
    for reserved_name in reserved_names:
        assert is_reserved_name(reserved_name) == True

    assert is_reserved_name('foo') == False
    assert is_reserved_name('host') == True

# Generated at 2022-06-23 15:24:14.361799
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('name')

# Generated at 2022-06-23 15:24:24.553271
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: test will break when we get new attributes for a class, need
    #        to build a better test matix.

    # names from Play class
    play_public = [
        'author',
        'connection',
        'delegate_facts',
        'gather_facts',
        'hosts',
        'max_fail_percentage',
        'name',
        'no_log',
        'post_tasks',
        'pre_tasks',
        'roles',
        'serial',
        'strategy',
        'sudo',
        'sudo_user',
        'tasks',
        'tags',
        'transport',
        'vars',
        'vars_files',
        'vars_prompt',
        'local_action',
    ]


# Generated at 2022-06-23 15:24:27.743568
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert 'action' in get_reserved_names()
    assert 'action' in _RESERVED_NAMES

    warn_if_reserved({'action': 123})



# Generated at 2022-06-23 15:24:39.088672
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved_public = get_reserved_names(include_private=False)

    assert 'action' in reserved_public                 # action is public, ensure it's in reserved
    assert 'local_action' in reserved_public           # local_action is implicit with action
    assert 'with_' in reserved_public                  # with_ is implicit with loop
    assert 'tags' in reserved_public                   # tags is public
    assert 'loop' in reserved_public                   # loop is public

    # ensure implicit reserved names exist, but only when the 'regular' reserved exists
    if 'action' in reserved_public:
        assert 'local_action' in reserved_public
    if 'loop' in reserved_public:
        assert 'with_' in reserved_public

    reserved_private = get_reserved_names(include_private=True)

    assert 'action' in reserved

# Generated at 2022-06-23 15:24:43.152314
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Fake these variables, they are not defined in the actual environment
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    Base._attributes = {}
    Task._attributes = {}
    Handler._attributes = {}

    warn_if_reserved({'playbook_dir':'test'})


# Generated at 2022-06-23 15:24:47.461195
# Unit test for function is_reserved_name
def test_is_reserved_name():
    names_from_get_reserved_names = get_reserved_names()

    # Check that each name returned by get_reserved_names is
    # correctly identified by is_reserved_name
    for name in names_from_get_reserved_names:
        assert(is_reserved_name(name))


# Generated at 2022-06-23 15:24:54.418923
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    display.COLOR = False
    import sys
    import warnings

    def run(given_vars, expected_exit_code=0, expected_warnings=[]):
        warnings.resetwarnings()
        orig_stderr = sys.stderr
        sys.stderr = sys.stdout

        # Tests that do not raise an exception
        try:
            warn_if_reserved(given_vars)
        except SystemExit as e:
            if e.code != expected_exit_code:
                raise
        else:
            if expected_exit_code != 0:
                raise Exception("Expected SystemExit %d, didn't get it." % expected_exit_code)

        # Tests that raise an exception
        caught_warnings = []

# Generated at 2022-06-23 15:24:59.958154
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()

    assert 'tags' in names
    assert 'any_errors_fatal' in names
    assert 'max_fail_percentage' in names

    assert 'serial' in names
    assert 'any_errors_fatal' in names

    assert 'vars_prompt' in names

    assert 'roles' in names
    assert 'handlers' in names
    assert 'tasks' in names
    assert 'block' in names
    assert 'pre_tasks' in names
    assert 'post_tasks' in names

    assert 'imports' in names

    assert 'action' in names
    assert 'local_action' in names
    assert 'with_' in names
    assert 'loop' in names



# Generated at 2022-06-23 15:25:11.405256
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:15.412681
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('roles'))
    assert(not is_reserved_name('play'))
    assert(not is_reserved_name('hosts'))
    assert(not is_reserved_name('no_such_reserved_name'))



# Generated at 2022-06-23 15:25:24.833393
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' verify that get_reserved_names returns expected list '''

    # First, test that the list is up-to-date by adding new
    # internals to a list of known tests

    # Test that the list is non-empty
    assert get_reserved_names() != set()

    # Test that private is optional
    assert len(get_reserved_names(False)) < len(get_reserved_names())
    assert len(get_reserved_names(True)) > len(get_reserved_names())

    # Test that the list doesn't include deprecated
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' not in get_reserved_names()

    # Test that the list doesn't include legacy
    assert 'local_action' not in get_reserved_names()

# Generated at 2022-06-23 15:25:26.633215
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in get_reserved_names():
        assert is_reserved_name(name)

# Generated at 2022-06-23 15:25:29.514703
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class myvars:
        a = 'a'
        b = 'b'
        c = 'c'
    warn_if_reserved(myvars())

# Generated at 2022-06-23 15:25:34.092347
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('private')
    assert is_reserved_name('private')
    assert is_reserved_name('action')
    assert not is_reserved_name('foo')


# Generated at 2022-06-23 15:25:36.361052
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    warn_if_reserved(['vars', 'hosts', 'name'])
    warn_if_reserved(['foo', 'bar'])

# Generated at 2022-06-23 15:25:43.447000
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.playbook.play_context import PlayContext

    reserved_names = get_reserved_names()
    assert type(reserved_names) is set

    context = PlayContext()
    for name in context.__dict__:
        if name != 'vars':
            assert name in reserved_names

    assert str(context) in reserved_names
    assert 'name' in reserved_names
    assert 'vars' in reserved_names
    assert 'roles' in reserved_names
    assert 'role_names' in reserved_names
    assert 'become' in reserved_names
    assert 'become_method' in reserved_names
    assert 'become_user' in reserved_names

# Generated at 2022-06-23 15:25:50.367586
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('hosts')
    assert is_reserved_name('include')
    assert is_reserved_name('include_vars')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('register')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert not is_reserved_name('name')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-23 15:25:52.728467
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    dummy_vars = dict(action='ping', hosts='somewhere')
    warn_if_reserved(dummy_vars)

# Generated at 2022-06-23 15:26:04.066914
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:15.011178
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # these should always be reserved, no matter what
    always_reserved = frozenset(['vars', 'roles', 'tasks', 'handlers', 'block', 'blockinfile', 'blockreplace'])

    reserved = get_reserved_names()
    assert reserved == _RESERVED_NAMES

    more = frozenset(['action', 'inventory', 'setup', 'teardown', 'tags', 'ignore_errors', 'any_errors_fatal'])
    reserved = get_reserved_names()
    assert reserved.union(more) == _RESERVED_NAMES.union(more)

    reserved = get_reserved_names(include_private=False)
    assert reserved.union(always_reserved) == _RESERVED_NAMES.union(always_reserved)

    reserved = get

# Generated at 2022-06-23 15:26:17.428521
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('remote_user')
    assert not is_reserved_name('foo')



# Generated at 2022-06-23 15:26:20.903615
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert(is_reserved_name('any_errors_fatal'))
    assert(is_reserved_name('post_tasks'))
    assert(not is_reserved_name('not_a_reserved_name'))

# Generated at 2022-06-23 15:26:24.002515
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, set) is True
    assert 'hosts' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES

# Generated at 2022-06-23 15:26:32.628403
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result1 = get_reserved_names(include_private=False)
    result2 = get_reserved_names(include_private=True)


# Generated at 2022-06-23 15:26:37.780684
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest

    def test_warn_if_reserved(capsys):
        reserved = ('hosts', 'roles')
        warn_if_reserved(reserved)
        # test will fail if either of these are not in the output
        out, err = capsys.readouterr()
        assert 'Found variable using reserved name: hosts' in out
        assert 'Found variable using reserved name: roles' in out

    test_warn_if_reserved(capsys)

# Generated at 2022-06-23 15:26:48.178743
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test reserved name warning '''


# Generated at 2022-06-23 15:26:56.318439
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # This function is just for simple unit tests, there are additional
    # tests in a higher level.
    from ansible.constants import mk_boolean

    # We can't use the function load_extra_vars because then we'll
    # have to fake the args, so instead we import it here.
    from ansible.cli.playbook import PlaybookCLI

    # In order to get the info from the args we need to call the
    # superclass.
    playbook = PlaybookCLI(args=dict())

    # We don't need to specify anything special.
    opts = playbook.parse_cli_args(args=[])

    # Get the vars and turn it into a dictionary
    vars = playbook.get_opt(opts, 'vars')
    var_dict = vars.copy()

    # Unset vars

# Generated at 2022-06-23 15:27:02.249831
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'debug' in _RESERVED_NAMES
    assert 'async' in _RESERVED_NAMES
    assert 'delay' in _RESERVED_NAMES
    assert 'become_user' in _RESERVED_NAMES
    assert 'become_method' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'vars' in _RESERVED_NAMES
    assert 'vars_files' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert not 'with_' in _RESERVED_NAMES

# Generated at 2022-06-23 15:27:04.457843
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'action' in reserved_names

# Generated at 2022-06-23 15:27:10.839202
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('block')
    assert is_reserved_name('block_rescue')
    assert is_reserved_name('block_always')
    assert is_reserved_name('task')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('vars')
    assert not is_reserved_name('meta')

# Generated at 2022-06-23 15:27:18.121763
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    d = dict(hosts='localhost', name='something', debug='')
    class test_warn_if_reserved:
        @staticmethod
        def warn(msg, category=None, filename='', lineno=None, line=None):
            assert msg.startswith('Found variable using reserved name: hosts')

    display.warning = test_warn_if_reserved.warn
    warn_if_reserved(d)
    warn_if_reserved(d, additional=['foobar'])

# Generated at 2022-06-23 15:27:26.426679
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['loop', 'vars', 'action'])
    warn_if_reserved(['vars'])

    try:
        warn_if_reserved(['vars', 'action', 'local_action', 'loop'], additional=['local_action', 'loop'])
    except:
        assert False, "Test failed: 'set(['local_action', 'loop'])' not subset of '_RESERVED_NAMES'"

    try:
        warn_if_reserved(['vars', 'action', 'local_action', 'loop'], additional=['local_action', 'loops'])
    except:
        assert False, "Test failed: 'set(['local_action', 'loops'])' is subset of '_RESERVED_NAMES'"

# Generated at 2022-06-23 15:27:37.400134
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # To run this test use:
    # python -m lib.ansible.playbook.reserved
    #
    import sys
    import tempfile
    import textwrap
    import yaml

    # Create a vars section with one variable that conflicts
    # with a reserved name
    test_vars = dict(name='localhost',
                     role='database',
                     action='destroy',
                     firstvar='firstval',
                     )
    yaml_vars = yaml.dump(test_vars, width=256)
    playbook = textwrap.dedent("""
    - hosts: localhost
      vars:
          {yaml_vars}
    """.format(yaml_vars=yaml_vars))

    # Write the playbook to a temporary file
    temp_playbook = tempfile.NamedTemporaryFile

# Generated at 2022-06-23 15:27:38.488418
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') is True

# Generated at 2022-06-23 15:27:42.283087
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name), "Expected reserved name: %s" % name
    assert not is_reserved_name('bogus')

# Generated at 2022-06-23 15:27:48.646922
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest
    myvars = dict()
    myvars['include'] = 'test'
    with pytest.raises(SystemExit):
        warn_if_reserved(myvars)
    myvars['vars'] = 'test'
    myvars['vvvars'] = 'test'
    warn_if_reserved(myvars)
    myvars['block'] = 'test'
    with pytest.raises(SystemExit):
        warn_if_reserved(myvars)

# Generated at 2022-06-23 15:27:50.574145
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['name', 'tags', 'hosts', 'vars', 'action', 'local_action']
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:27:59.868505
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # Set up test case
    test_vars = ['vars', 'action', 'any_errors_fatal', 'connection', 'delegate_to', 'environment', 'local_action',
                 'module_name', 'name', 'notify', 'run_once', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user',
                 'register', 'async', 'poll', 'until', 'retries', 'delay', 'tags', 'transport', 'ignore_errors']

    # Result should be no warnings
    warn_if_reserved(test_vars)

# Generated at 2022-06-23 15:28:03.561224
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")
    assert is_reserved_name("connection")
    assert is_reserved_name("delegate_to")
    assert is_reserved_name("remote_user")
    assert not is_reserved_name("test_name")

# Generated at 2022-06-23 15:28:06.710382
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts')
    assert is_reserved_name('loop')
    assert is_reserved_name('serial')

# Generated at 2022-06-23 15:28:09.591815
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved('foo') is None
    assert warn_if_reserved('hosts') is not None
    assert warn_if_reserved('connection') is not None

# Generated at 2022-06-23 15:28:12.152581
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['hosts', 'roles', 'vars'])
    assert warn_if_reserved(['private_something'])
    assert not warn_if_reserved(['public_something'])

# Generated at 2022-06-23 15:28:23.956556
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    import StringIO

    myvars = ['vars', 'when', 'hosts', 'roles', 'blocks']
    myvars2 = ['hosts', 'roles']
    output = StringIO.StringIO()

    sys.stdout = output
    warn_if_reserved(myvars)
    sys.stdout = sys.__stdout__

    # Checks to see if warnings have been printed
    assert 'Found variable using reserved name' in output.getvalue()

    # Checks to see if 'roles' keyword has not been printed
    output = StringIO.StringIO()
    sys.stdout = output
    warn_if_reserved(myvars2)
    sys.stdout = sys.__stdout__
    assert 'Found variable using reserved name' not in output.getvalue()

# Generated at 2022-06-23 15:28:28.932537
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = dict(
        play=dict(
            hosts='all',
            vars=dict(
                var_to_be_warned='a'),
        )
    )
    warn_if_reserved(myvars['play']['vars'])


# Generated at 2022-06-23 15:28:33.828092
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''This function tests the function get_reserved_names'''

    print("Start get_reserved_names test:")

    # All known reserved names
    expected_all_names = set()
    expected_all_names.add('become')
    expected_all_names.add('become_method')
    expected_all_names.add('become_user')
    expected_all_names.add('block')

# Generated at 2022-06-23 15:28:39.872446
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)

    assert is_reserved_name('_foo')
    assert is_reserved_name('vars')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')

    assert not is_reserved_name('foo')
    assert not is_reserved_name('foo_bar')

# Generated at 2022-06-23 15:28:42.804008
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_private = get_reserved_names(include_private=True)
    reserved_public = get_reserved_names(include_private=False)
    assert reserved_private != reserved_public



# Generated at 2022-06-23 15:28:44.365537
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names(include_private=False) == get_reserved_names())

# Generated at 2022-06-23 15:28:46.600449
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert 'connection' in _RESERVED_NAMES
    assert is_reserved_name('connection')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:28:53.995551
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import unittest
    import sys
    import os

    var_names = ['hosts', 'roles', 'tasks', 'action', 'vars', 'include', 'include_tasks', 'include_vars', 'tags', 'name', 'register', 'ignore_errors', 'when', 'notify', 'delegate_to', 'local_action', 'become', 'become_user', 'become_method']

    class TestReservedNames(unittest.TestCase):
        def test_warn_if_reserved_default(self):

            # setup stdout capture
            old_stdout = sys.stdout
            out = open(os.devnull, 'w')
            sys.stdout = out

            # run function
            warn_if_reserved(var_names)

            # reset stdout
            sys

# Generated at 2022-06-23 15:29:05.126933
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # needs to be set for warning output
    display.verbosity = 4
    # Disable color, display.deprecated() uses colored ansible-log instead
    display.color = False

    class Options(object):
        def __init__(self, verbosity=3, color=True, force_color=False):
            self.verbosity = verbosity
            self.no_log = True
            self.one_line = True
            self.colored = color
            self.force_color = force_color
    display.options = Options()

    warn_if_reserved(['vars'])
    warn_if_reserved(['role'])
    warn_if_reserved(['include'])
    warn_if_reserved(['connection'])
    warn_if_reserved(['boostrap_host'])
    warn_

# Generated at 2022-06-23 15:29:06.496307
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['name'])

# Generated at 2022-06-23 15:29:16.498383
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'action', 'tasks', 'tasks_from', 'handlers', 'pre_tasks', 'post_tasks', 'roles',
                      'block', 'block_rescue', 'block_always', 'gather_facts', 'tags', 'register',
                      'any_errors_fatal', 'no_log', 'become', 'become_user', 'become_method',
                      'become_flags', 'environment', 'remote_user', 'remote_port', 'connection', 'port',
                      'default_vars', 'vars_prompt', 'vars_files', 'vars_from', 'force_handlers', 'ignore_errors',
                      'serial', 'delegate_to'])

    warn_if_reserved(['serial', 'include'])

   

# Generated at 2022-06-23 15:29:19.478155
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)

    reserved = get_reserved_names(False)
    assert isinstance(reserved, set)



# Generated at 2022-06-23 15:29:24.535729
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest
    from ansible.compat.tests.mock import patch
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text

    myvars = {'roles': [], 'hosts': 'localhost',
              'task': [{'action': {'module': 'setup', 'args': ''},
                        'name': 'Gathering Facts'}]}
    with patch.object(Display, 'deprecated') as mock_warn:
        warn_if_reserved(myvars, additional=('deprecated'))
        assert mock_warn.call_count == 2
        mock_warn.assert_any_call('Found variable using reserved name: roles')
        mock_warn.assert_any_call('Found variable using reserved name: deprecated')



# Generated at 2022-06-23 15:29:36.063377
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:29:37.907724
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('action')
    assert not is_reserved_name('foo')


# Generated at 2022-06-23 15:29:46.416882
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=True)
    public = get_reserved_names(include_private=False)

    assert 'become' in reserved
    assert 'become' in public
    assert 'become_user' in reserved
    assert 'become_user' in public
    assert 'role_names' not in reserved
    assert 'role_names' in public
    assert 'role_names' in reserved
    assert 'tags' in reserved
    assert 'tags' in public
    assert 'when' in reserved
    assert 'when' in public
    assert 'private_role_vars' in reserved
    assert 'private_role_vars' not in public
    assert 'vars' in reserved
    assert 'vars' in public
    assert 'name' in reserved
    assert 'name' in public