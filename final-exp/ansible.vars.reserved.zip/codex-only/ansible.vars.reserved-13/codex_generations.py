

# Generated at 2022-06-23 15:19:53.987030
# Unit test for function get_reserved_names
def test_get_reserved_names():
    display.verbosity = 4

    # test data
    class_list = [Play, Role, Block, Task]

    # test false positive
    found = False
    missing = False
    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if attribute in get_reserved_names():
                if attribute in _RESERVED_NAMES:
                    # already in list
                    continue
                else:
                    # not in list
                    display.vvvv('%s should be in the list of reserved names' % attribute)
                    found = True

    # test false negative

# Generated at 2022-06-23 15:20:05.072604
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' make sure reserved names are correctly identified '''

    # LAME: hardcoded expected names, but it's hard to test this without adding more
    # FIXME: make this test not lame

# Generated at 2022-06-23 15:20:07.406992
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('actions')
    assert not is_reserved_name('not_a_reserved_name')

# Generated at 2022-06-23 15:20:17.238120
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert result == _RESERVED_NAMES
    result = get_reserved_names(include_private=False)
    assert result == frozenset(['vars', 'hosts', 'name', 'connection', 'gather_facts', 'become', 'become_user', 'tags', 'tasks', 'pre_tasks', 'post_tasks', 'roles', 'handlers', 'any_errors_fatal', 'remote_user', 'serial', 'no_log', 'run_once', 'sudo', 'sudo_user', 'failed_when', 'changed_when', 'when', 'delegate_to', 'notify', 'register', 'ignore_errors', 'check_mode', 'max_fail_percentage', 'deprecations', 'environment', 'action'])

#

# Generated at 2022-06-23 15:20:18.717060
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('notreservedname')


# Generated at 2022-06-23 15:20:27.427430
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert len(get_reserved_names()) != 0
    assert isinstance(get_reserved_names(include_private=False), set)
    assert len(get_reserved_names(include_private=False)) >= len(get_reserved_names())

    for name in get_reserved_names(include_private=False):
        assert isinstance(name, str)
        assert len(name) != 0
        assert name not in get_reserved_names(include_private=True) - get_reserved_names(include_private=False)
        assert name in get_reserved_names(include_private=True)

    for name in get_reserved_names(include_private=True):
        assert isinstance(name, str)

# Generated at 2022-06-23 15:20:28.837932
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:20:35.275508
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    myvars = ['vars', 'hosts', 'remote_user', 'roles', 'roles[0]', 'roles[0].hosts', 'roles[0].remote_user', 'roles[1]', 'roles[1].hosts', 'roles[1].remote_user']

    warn_if_reserved(myvars)

    assert True

# Generated at 2022-06-23 15:20:39.855470
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        # test warn_if_reserved() with a list of reserved variables
        warn_if_reserved(["hosts", "action", "local_action", "delegate_to"])
        # test warn_if_reserved() with a list of non-reserved variables
        warn_if_reserved(["foo", "bar"], ["foo", "bar"])
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-23 15:20:47.625510
# Unit test for function get_reserved_names
def test_get_reserved_names():
    myreserved = get_reserved_names()
    assert isinstance(myreserved, set)
    assert get_reserved_names(include_private=False).issubset(myreserved)
    assert 'name' in myreserved
    assert 'vars' in myreserved
    assert 'action' in myreserved
    assert 'local_action' in myreserved
    assert 'with_' in myreserved
    assert 'loop' in myreserved



# Generated at 2022-06-23 15:20:57.463036
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = ['action', 'gather_facts', 'local_action', 'loop', 'module', 'register', 'vars', 'with_items']
    assert warn_if_reserved(vars) is None


# Generated at 2022-06-23 15:21:00.320807
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['hosts', 'vars'])
    except NameError as unexpected:
        display.error(unexpected)
        assert False, "warn_if_reserved() should not raise exception"
    assert True

# Generated at 2022-06-23 15:21:11.068791
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    fn = warn_if_reserved

# Generated at 2022-06-23 15:21:21.512062
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' This function tests the get_reserved_names function '''

    # get the full set of reserved names
    all_reserved_names = get_reserved_names()

    # get the set of public names
    public_reserved_names = get_reserved_names(include_private=False)

    # make sure all public names are in all_reserved_names
    assert public_reserved_names.issubset(all_reserved_names)

    # make sure we have at least one public and one private name
    assert public_reserved_names and all_reserved_names and all_reserved_names.difference(public_reserved_names)

# Generated at 2022-06-23 15:21:22.702752
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    result = warn_if_reserved(['test', 'action'])
    assert result is None



# Generated at 2022-06-23 15:21:25.549120
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('my_var')
    assert not is_reserved_name('with_items')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')

# Generated at 2022-06-23 15:21:28.245418
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('name')

# Generated at 2022-06-23 15:21:29.412881
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')

# Generated at 2022-06-23 15:21:39.512209
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)

    assert 'hosts' in reserved
    assert 'tasks' in reserved
    assert 'roles' in reserved
    assert 'name' in reserved
    assert 'vars' in reserved
    assert 'tags' in reserved

    assert 'when' in reserved
    assert 'with_' in reserved
    assert 'delegate_to' in reserved
    assert 'register' in reserved
    assert 'ignore_errors' in reserved
    assert 'changed_when' in reserved
    assert 'failed_when' in reserved
    assert 'always_run' in reserved
    assert 'first_available_file' in reserved
    assert 'local_action' in reserved

    assert 'block' in reserved
    assert 'rescue' in reserved
    assert 'always' in reserved


# Generated at 2022-06-23 15:21:48.134619
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from unittest import TestCase

    class WarnIfReservedTestCase(TestCase):
        def test_warn_if_reserved_no_vars(self):
            warn_if_reserved(dict())

        def test_warn_if_reserved_no_reserved_vars(self):
            warn_if_reserved(dict(foo=dict()))

        def test_warn_if_reserved_reserved_vars(self):
            warn_if_reserved(dict(vars=dict()))

        def test_warn_if_reserved_reserved_vars_dict(self):
            warn_if_reserved(dict(vars=dict(foo=dict())))


# Generated at 2022-06-23 15:21:57.278467
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected = frozenset(['roles', 'tags', 'environment', 'role_path', 'serial', 'max_fail_pct', 'remote_user', 'connection', 'sudo', 'sudo_user', 'become', 'become_user', 'check', 'name', 'delegate_to', 'gather_facts', 'any_errors_fatal', 'hosts', 'gather_subset', 'port', 'failed_when', 'set_facts', 'sudo_password', 'vars_prompt', 'always_run',  'register', 'vars_files', 'action', 'local_action', 'with_', 'loop'])

    assert frozenset(get_reserved_names()) == expected

# Generated at 2022-06-23 15:22:07.211520
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    reserved: a set of strings used as reserved names
    myvars: a set of strings to potentially warn on
    '''

    # None should fail without warning
    myvars = None
    warn_if_reserved(myvars)

    # Empty should not warn
    myvars = set()
    warn_if_reserved(myvars)

    # Only non-reserved should not warn
    myvars = set('a')
    myvars.add('b')
    warn_if_reserved(myvars)

    # Non-reserved plus one reserved should warn
    myvars = set('a')
    myvars.add('b')
    myvars.add('action')
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:22:18.485904
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert isinstance(get_reserved_names(), set), "get_reserved_names() should return a set()"
    assert isinstance(get_reserved_names(include_private=False), set), "get_reserved_names() should return a set()"

    # We grabbed the reserved names, now let's test that we don't have duplicates
    # We want to do this to ensure we don't have hidden collisions in reserved names
    assert len(get_reserved_names()) == len(set(get_reserved_names())), "get_reserved_names() has duplicates. Please fix."
    assert len(get_reserved_names(include_private=False)) == len(set(get_reserved_names(include_private=False))), "get_reserved_names() has duplicates. Please fix."

# Unit test

# Generated at 2022-06-23 15:22:24.998178
# Unit test for function get_reserved_names
def test_get_reserved_names():
    small_reserved = ['become', 'async', 'register', 'until', 'retries', 'local_action']
    small_check = get_reserved_names(include_private=False)
    for name in small_reserved:
        assert name in small_check

    big_reserved = small_reserved + ['at', 'delegate_to', 'environment', 'first_available_file', 'loop', 'sudo', 'sudo_user']
    big_check = get_reserved_names(include_private=True)
    for name in big_reserved:
        assert name in big_check

# Generated at 2022-06-23 15:22:28.421852
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('handler')
    assert is_reserved_name('any_errors_fatal') is False
    assert is_reserved_name('tasks') is False


# Generated at 2022-06-23 15:22:33.315850
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in ['hosts', 'roles', 'vars', 'delegate_to', 'include', 'import_playbook', 'tags', 'name', 'sudo', 'async', 'register', 'when', 'notify']:
        assert(is_reserved_name(name))

    for name in ['spam', 'eggs', 'ham', 'sausage', 'bacon', 'beans', 'pie']:
        assert(not is_reserved_name(name))

# Generated at 2022-06-23 15:22:42.583244
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils._text import to_text
    from ansible.utils.display import Display

    display = Display()
    try:
        display.deprecated = False
        warn_if_reserved(['localhost', 'gather_facts', 'action'], set(['test']))
    except SystemExit as e:
        output = to_text(e)
        assert to_text('Found variable using reserved name: localhost') in output
        assert to_text('Found variable using reserved name: gather_facts') in output
        assert to_text('Found variable using reserved name: action') not in output
        assert to_text('Found variable using reserved name: test') in output
        return

    raise Exception("reserved name test did not exit with message")


# Generated at 2022-06-23 15:22:44.073136
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('when')
    assert not is_reserved_name('foo')


# Generated at 2022-06-23 15:22:55.401924
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Dummy class to supply _attribute - should be same as Play
    class DummyPlay(object):
        _attributes = ('name', 'hosts', 'roles', 'tasks', 'vars',
                       'handlers', 'pre_tasks', 'post_tasks', 'any_errors_fatal',
                       'serial', 'max_fail_percentage', 'remote_user', 'become',
                       'become_method', 'become_user', 'tags', 'gather_facts',
                       'vault_password', 'no_log', 'environment', 'clean_facts',
                       'deprecated')

    # test without private attibutes
    test_set = set(get_reserved_names(include_private=False))
    warn_if_reserved(test_set)
    # should have no output

   

# Generated at 2022-06-23 15:23:05.888137
# Unit test for function get_reserved_names
def test_get_reserved_names():
    myreserved = sorted(list(get_reserved_names()))

# Generated at 2022-06-23 15:23:14.091464
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.template import Templar
    from ansible.vars import VariableManager

    test_vars_dict = dict(
        connection=dict(
            choices=list(['smart', 'ssh', 'local']),
            default='smart',
        ),
    )

    test_vars = VariableManager()
    test_vars.extra_vars = dict(vars=test_vars_dict)
    test_templar = Templar(loader=None, variables=test_vars)

    # function warn_if_reserved should note the connection var
    warn_if_reserved(test_vars_dict)

    # function HostVars.get should not error on connection var
    test_hostvars = test_templar.hostvars

# Generated at 2022-06-23 15:23:16.032770
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('hosts')
    assert not is_reserved_name('roles')
    assert not is_reserved_name('vars')

# Generated at 2022-06-23 15:23:22.026133
# Unit test for function get_reserved_names
def test_get_reserved_names():

    class Test1:
        _attributes = dict(
            a=dict(x=1),
            d=dict(x=1, private=True),
            e=dict(private=True),
        )

    class Test2:
        _attributes = dict(
            b=dict(x=2),
            f=dict(x=2, private=True),
        )

    class Test3:
        _attributes = dict(
            c=dict(x=3),
            g=dict(x=3, private=True),
        )

    expected_public = set(['a', 'b', 'c', 'local_action', 'with_'])
    expected_private = set(['d', 'e', 'f', 'g', 'loop'])
    expected = expected_public.union(expected_private)

   

# Generated at 2022-06-23 15:23:24.359412
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_vars = ('include', 'vars', 'other')
    warn_if_reserved(test_vars)
    return

# Generated at 2022-06-23 15:23:32.712399
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names_from_get_reserved_names = _RESERVED_NAMES

    reserved_names_from_get_reserved_names.add('__init__')

    # Asserting that reserved set returned by get_reserved_names is different after adding __init__
    assert reserved_names_from_get_reserved_names != _RESERVED_NAMES

    # Asserting __init__ is a reserved name
    assert is_reserved_name('__init__')

    # Asserting __init__ is not a reserved name
    assert not is_reserved_name('__invalid')

# Generated at 2022-06-23 15:23:42.519564
# Unit test for function is_reserved_name
def test_is_reserved_name():
    print("=== Testing function is_reserved_name ===")
    # Test with a reserved name
    reserved_name = 'vars'
    result = is_reserved_name(reserved_name)
    assert result == True, 'is_reserved_name failed to identy reserved name "%s"' % reserved_name

    # Test with a non-reserved name
    not_reserved_name = 'test'
    result = is_reserved_name(not_reserved_name)
    assert result == False, 'is_reserved_name falsely identified name "%s" as reserved' % not_reserved_name

    print('Tests completed successfully')



# Generated at 2022-06-23 15:23:52.832146
# Unit test for function is_reserved_name
def test_is_reserved_name():
    tests = set(['name', 'other_name', 'name_with_underscore', '_with_underscore', '_with_underscore_and_dash',
                 '_with_underscore_and_dash_', '_class', '__class__', '_name', '__name', '_'])
    reserved = _RESERVED_NAMES.union(('name', 'other_name'))
    for name in tests:
        print('is_reserved_name(%s) = %s' % (name, is_reserved_name(name)))
        print('is_reserved_name(%s) = %s (with addtl vars name, other_name)' % (name, is_reserved_name(name, additional=reserved)))
        print()



# Generated at 2022-06-23 15:23:57.081117
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # at the time of writing, we have 30 public names, and
    # 45 private names, for a total of 75.
    assert len(get_reserved_names()) == 75
    assert len(get_reserved_names(include_private=False)) == 30



# Generated at 2022-06-23 15:23:58.385986
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 44



# Generated at 2022-06-23 15:24:08.875215
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:24:12.760221
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert('any_errors_fatal' in result)
    assert('ignore_errors' in result)
    assert('with_items' in result)
    assert('vars' in result)
    assert('hosts' in result)



# Generated at 2022-06-23 15:24:17.676279
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:24:18.385060
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)



# Generated at 2022-06-23 15:24:22.895735
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:24:29.101528
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in _RESERVED_NAMES
    assert 'import_role' in _RESERVED_NAMES
    assert 'include' in _RESERVED_NAMES
    assert 'private' not in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES
    assert 'loop' not in _RESERVED_NAMES

# Generated at 2022-06-23 15:24:38.011142
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    res = get_reserved_names()
    print(res)
    res = get_reserved_names(include_private=False)
    print(res)

    warn_if_reserved(dict(hosts='127.0.0.1').keys(), dict(hosts='127.0.0.1').keys())
    warn_if_reserved(dict(hosts='127.0.0.1').keys(), dict(hosts='127.0.0.1').keys())

    try:
        raise Exception('foo')
    except Exception:
        print(Exception)
    print([Exception])

# Generated at 2022-06-23 15:24:39.376508
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') is True
    assert is_reserved_name('foobar') is False

# Generated at 2022-06-23 15:24:49.170688
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:24:59.340344
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # check normal case
    display.verbosity = 5
    warn_if_reserved(['foo', 'vars', 'local_action'])
    display.verbosity = 1

    # check we don't warn for non-conflicting vars
    display.verbosity = 5
    warn_if_reserved(['foo', 'vars', 'because_foo'])
    display.verbosity = 1

    # check we warn even if vars is not added
    display.verbosity = 5
    warn_if_reserved(['foo', 'local_action'])
    display.verbosity = 1

# Generated at 2022-06-23 15:25:04.974194
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest

    # Need to reset display before each run or warnings from previous
    # runs will be displayed
    display.verbosity = 0
    d = display
    d.reset()

    d._display.verbosity = True
    d.colorize_errors = False

    warn_if_reserved({'name': 'foo'})
    # We did not warn
    assert d.display._warns == 0

    warn_if_reserved({'name': 'foo', 'hosts': 'bar'})
    # We warned one time
    assert d.display._warns == 1

# Generated at 2022-06-23 15:25:15.122134
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:21.084970
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.vars.clean import module_response_deepcopy
    test_result = True
    test_vars = {'connection': 'fake', 'hosts': 'localhost'}
    try:
        test_vars_c = module_response_deepcopy(test_vars)
        warn_if_reserved(test_vars_c)
    except Exception:
        test_result = False
    assert test_result is True

# Generated at 2022-06-23 15:25:22.790066
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert frozenset(['tasks']) == warn_if_reserved({'tasks': []})


# Generated at 2022-06-23 15:25:34.245834
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('roles') == True
    assert is_reserved_name('tasks') == True
    assert is_reserved_name('any_other_name') == False
    assert is_reserved_name('collect_facts') == True
    assert is_reserved_name('connector') == True
    assert is_reserved_name('name') == True
    assert is_reserved_name('become') == True
    assert is_reserved_name('gather_facts') == True
    assert is_reserved_name('tags') == True
    assert is_reserved_name('any_tags') == True
    assert is_reserved_name('skip_tags') == True
    assert is_reserved_name('environment') == True

# Generated at 2022-06-23 15:25:42.910210
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('action')
    assert is_reserved_name('private')
    assert is_reserved_name('vars_files')
    assert is_reserved_name('vars_prompt')
    assert is_reserved_name('vars')
    assert is_reserved_name('local_action')
    assert is_reserved_name('meta')
    assert is_reserved_name('handler')
    assert is_reserved_name('flush_handlers')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('pre_task')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('post_task')
    assert is_reserved_

# Generated at 2022-06-23 15:25:47.090246
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') == True
    assert is_reserved_name('foo') == False
    assert is_reserved_name('connection') == True
    assert is_reserved_name('action') == True
    assert is_reserved_name('loop') == True

# Generated at 2022-06-23 15:25:53.732340
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_names = [
        'any_errors_fatal',
        'block',
        'connection',
        'delegate_to',
        'delegate_facts',
        'environment',
        'handler',
        'ignore_errors',
        'name',
        'no_log',
        'notify',
        'roles',
        'run_once',
        'serial',
        'sudo',
        'sudo_user',
        'tags',
        'tasks',
        'transport',
        'vars',
        'when',
    ]

    warn_if_reserved(test_names)

# Generated at 2022-06-23 15:26:04.860262
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = set(['action', 'become', 'become_method', 'become_user', 'cacheable', 'connection', 'delegate_to',
                        'delegate_facts', 'environment', 'group', 'gather_facts', 'gather_subset', 'gather_timeout',
                        'ignore_errors', 'include', 'include_vars', 'local_action', 'loop', 'name', 'notify',
                        'no_log', 'register', 'remote_user', 'roles', 'serial', 'sudo', 'sudo_user', 'tags',
                        'transport', 'unsafe_writes', 'vars', 'when', 'with_'])

# Generated at 2022-06-23 15:26:15.642570
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert isinstance(get_reserved_names(False), frozenset)

    assert 'hosts' in get_reserved_names(False)
    assert 'hosts' in get_reserved_names(True)
    assert 'connection' in get_reserved_names(False)
    assert 'connection' in get_reserved_names(True)
    assert 'gather_facts' in get_reserved_names(False)
    assert 'gather_facts' in get_reserved_names(True)
    assert 'action' in get_reserved_names(False)
    assert 'action' in get_reserved_names(True)
    assert 'local_action' in get_reserved_names(False)

# Generated at 2022-06-23 15:26:17.855121
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('action') is True)
    assert(is_reserved_name('accelerate') is False)

# Generated at 2022-06-23 15:26:21.653763
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts': 'test'})
    warn_if_reserved({'private': 'test'})
    warn_if_reserved({'private': 'test'}, additional={'test'})



# Generated at 2022-06-23 15:26:24.818977
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # check that 'private' is included
    assert 'hosts' in get_reserved_names(include_private=True)

    # check that 'private' is not included
    assert 'hosts' not in get_reserved_names()



# Generated at 2022-06-23 15:26:29.343415
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import pprint

    #print(pprint.pprint(get_reserved_names()))

    result = get_reserved_names()
    assert len(result) > 0
    assert 'name' in result

    result = get_reserved_names(include_private=False)
    assert len(result) > 0
    assert 'name' in result

# Generated at 2022-06-23 15:26:36.984438
# Unit test for function get_reserved_names
def test_get_reserved_names():
    namelist = get_reserved_names()

    # This is an important list for the Playbook API. Adjust
    # with care.

# Generated at 2022-06-23 15:26:47.434802
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    def test_warning(varname):
        # Execute with a variable name that should generate a warning
        try:
            warn_if_reserved({varname: 'value'})
        except Exception as e:
            # FIXME: needs to be something more specific, but this is the best we have ATM
            if e.__class__.__name__ == 'AnsibleExitJson':
                raise AssertionError("warn_if_reserved({0}) did not produce a warning (it should have!)".format(varname))
            else:
                raise

    # Execute with a variable name that should NOT generate a warning
    warn_if_reserved({'somevar': 'value'})
    # Check for a bunch of known reserved variables and make sure it warns

# Generated at 2022-06-23 15:26:48.498596
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') is True

# Generated at 2022-06-23 15:26:56.805970
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)
    assert 'action' in reserved
    assert 'become' in reserved
    assert 'become_user' in reserved
    assert 'connection' in reserved
    assert 'environment' in reserved
    assert 'gather_facts' in reserved
    assert 'hosts' in reserved
    assert 'name' in reserved
    assert 'roles' in reserved
    assert 'serial' in reserved
    assert 'vars' in reserved
    assert 'vars_prompt' in reserved
    assert 'vars_files' in reserved
    assert 'vault_id' in reserved
    assert 'vault_password_file' in reserved
    assert 'tags' in reserved
    assert 'compile_roles' in reserved
    assert 'import_playbook' in reserved
   

# Generated at 2022-06-23 15:26:59.604022
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # FIXME: get a test for this
    assert is_reserved_name('hosts'), 'failed'
    assert not is_reserved_name('foo'), 'failed'

# Generated at 2022-06-23 15:27:00.557132
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) > 0

# Generated at 2022-06-23 15:27:06.631231
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('when')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('roles')

    assert not is_reserved_name('invalid_name')
    assert not is_reserved_name('i_am_ok')



# Generated at 2022-06-23 15:27:16.989290
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import mock
    import sys

    class Error(Exception):
        pass

    def _mockDisplay_warning(message):
        raise Error(message)

    __mockDisplay_warning = mock.patch.object(display, 'warning')
    __mockDisplay_warning.side_effect = _mockDisplay_warning

    # Now we can run the test: warn_if_reserved() should raise Error
    try:
        warn_if_reserved(['action', 'become'])
    except Error as message:
        assert message == ("Found variable using reserved name: action"
                           "\nFound variable using reserved name: become")
    else:
        assert False, "Expected Error"

# Generated at 2022-06-23 15:27:25.685260
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts'])
    warn_if_reserved(['connection'])
    warn_if_reserved(['any_errors_fatal'])
    warn_if_reserved(['remote_user'])
    warn_if_reserved(['sudo'])
    warn_if_reserved(['sudo_user'])
    warn_if_reserved(['transport'])
    warn_if_reserved(['remote_port'])
    warn_if_reserved(['environment'])
    warn_if_reserved(['become_method'])
    warn_if_reserved(['become_user'])
    warn_if_reserved(['strategy'])
    warn_if_reserved(['run_once'])

# Generated at 2022-06-23 15:27:28.024306
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = {'gather_facts': 'poop', 'hosts': 'bob'}
    warn_if_reserved(vars)
    assert isinstance(vars, dict)
    assert len(vars) == 2



# Generated at 2022-06-23 15:27:31.665974
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert 'hosts' in result
    assert 'roles' in result
    assert 'tasks' in result
    assert 'action' in result


# Generated at 2022-06-23 15:27:32.805938
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'private' not in get_reserved_names(False)
    assert 'private' in get_reserved_names(True)



# Generated at 2022-06-23 15:27:36.563548
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print("\n")
    print ("reserved names are:")
    public_list = get_reserved_names(include_private=False)
    private_list = get_reserved_names(include_private=True)
    print ('Public %s' % ' '.join(public_list))
    print ('Private %s' % ' '.join(private_list))
    assert len(public_list) == 35
    assert len(private_list) == 41
    print('\n')


# Some unit tests for warn_if_reserved

# Generated at 2022-06-23 15:27:44.600845
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest
    from ansible.vars.hostvars import HostVars

    host = HostVars({"testvar": "test"})
    values = {"testvar": "test2"}

    host.update(values)

    # With warning
    with pytest.raises(Exception):
        warn_if_reserved(values)
    # Without warning
    with pytest.raises(Exception) as excinfo:
        warn_if_reserved({"testvar": None})
    assert "testvar" not in str(excinfo.value)

# Generated at 2022-06-23 15:27:46.055427
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')


# Generated at 2022-06-23 15:27:51.527819
# Unit test for function get_reserved_names
def test_get_reserved_names():

    result = get_reserved_names()
    assert 'roles' in result
    assert 'private_key_file' in result
    assert 'delegate_to' in result
    assert 'force_handlers' in result
    assert 'sudo_password' in result

    result = get_reserved_names(include_private=False)
    assert 'roles' in result
    assert 'private_key_file' not in result
    assert 'delegate_to' in result
    assert 'force_handlers' not in result
    assert 'sudo_password' not in result

# Generated at 2022-06-23 15:28:03.348280
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    from io import StringIO

    out = StringIO()
    sys.stdout = out
    myvars = {'hosts': 'all', 'action': 'all', 'foofoo': "not reserved"}
    warn_if_reserved(myvars)
    sys.stdout = sys.__stdout__
    assert "Found variable using reserved name: action" in out.getvalue()
    out.close()


###########
# pylint: disable=unused-variable,undefined-variable
#
# This is done to prevent pylint from complaining about the variables being
# unused, as the variables are meant to be defined during import time, not
# during runtime.
#
# Additionally, this is done because the names are possible for users to
# use as variables, therefore we should not raise undefined variable errors
# on

# Generated at 2022-06-23 15:28:10.488783
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == set(['name', 'gather_facts', 'tags', 'action', 'include_tasks', 'set_facts', 'environment', 'register', 'remote_user', 'local_action', 'ignore_errors', 'any_errors_fatal', 'become', 'become_method', 'become_user', 'hosts', 'include', 'import_playbook', 'vars', 'vars_files', 'when', 'pre_tasks', 'post_tasks', 'role_path', 'roles', 'tasks', 'handlers', 'with_', 'pre_tasks'])

# Generated at 2022-06-23 15:28:18.221278
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved_names = get_reserved_names()

    assert(isinstance(reserved_names, set))
    assert('roles' in reserved_names)
    assert('tasks' in reserved_names)
    assert('handlers' in reserved_names)
    assert('hosts' in reserved_names)
    assert('action' in reserved_names)
    assert('connection' in reserved_names)
    assert('name' in reserved_names)
    assert('sudo' in reserved_names)
    assert('sudo_user' in reserved_names)
    assert('delegate_to' in reserved_names)
    assert('register' in reserved_names)
    assert('notify' in reserved_names)
    assert('when' in reserved_names)
    assert('tags' in reserved_names)

# Generated at 2022-06-23 15:28:20.025939
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('private')



# Generated at 2022-06-23 15:28:29.691900
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('play')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('block')
    assert is_reserved_name('hosts')
    assert is_reserved_name('user')
    assert is_reserved_name('vars')
    assert is_reserved_name('tags')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('name')
    assert is_reserved_name('include_vars')
    assert not is_reserved_name('namea')
    assert not is_reserved_name('role')

# Generated at 2022-06-23 15:28:31.656657
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'vars', 'foo', 'connection'])
    assert True

# Generated at 2022-06-23 15:28:34.258096
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    myvars = {'hosts': 'test', 'action': 'test'}
    warn_if_reserved(myvars)
    assert True

# Generated at 2022-06-23 15:28:39.572498
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    my_vars = ['var1', 'var2', 'var3', 'action', 'var4', 'var5']
    other_name = 'action'

    obj = warn_if_reserved(my_vars)
    assert (obj != other_name)

    obj = warn_if_reserved(my_vars, other_name)
    assert (obj == other_name)

# Generated at 2022-06-23 15:28:42.518447
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Create a dict with reserved names as keys and values (for test purposes)
    myvars = dict((n, n) for n in _RESERVED_NAMES)
    # this should just not raise an exception
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:28:50.672294
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test public names
    public_reserved_names = get_reserved_names(include_private=False)
    assert 'vars' in public_reserved_names
    assert 'no_log' in public_reserved_names
    assert 'notify' in public_reserved_names
    assert 'register' in public_reserved_names
    assert 'environment' in public_reserved_names

    # Test private names
    private_reserved_names = get_reserved_names(include_private=True)
    assert 'vars' in private_reserved_names
    assert 'no_log' in private_reserved_names
    assert 'notify' in private_reserved_names
    assert 'register' in private_reserved_names
    assert 'environment' in private_reserved_names

# Generated at 2022-06-23 15:28:56.761565
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Not really a test, but using the same loading mechanism
    from ansible.parsing.yaml import objects
    for varv in ['action', 'become', 'become_method', 'become_user', 'delegate_to', 'gather_facts', 'hosts', 'loop', 'roles', 'tags', 'tasks', 'vars', 'user']:
        warn_if_reserved(objects.AnsibleVars(loader=None, file=None, args=None, hash_behaviour='replace', vault_password=None)._load_vars(data=dict(vars=[varv]), cache={}))

# Generated at 2022-06-23 15:29:07.524498
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    """Verify we get the warning when using reserved names."""
    import os
    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]
    for aclass in class_list:
        aobj = aclass()
        reserved = set()
        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                reserved.add(attribute)
        warn_if_reserved(reserved)
    # test if we get a warning for not reserved names - should not
    reserved = set()
    reserved.add('something')
    reserved.add('something else')
    warn_if_reserved(reserved)

# Generated at 2022-06-23 15:29:09.350536
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('role')
    assert not is_reserved_name('playbook')


# Generated at 2022-06-23 15:29:09.893853
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    pass

# Generated at 2022-06-23 15:29:19.958952
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test warn_if_reserved function '''
    from ansible.compat.tests import unittest
    from ansible.utils.display import Display
    from ansible.utils.display import DisplayOne

    class TestDisplay(Display):
        ''' Used to capture warnings '''
        def __init__(self):
            self.msg = ''
            super(TestDisplay, self).__init__()

        def warning(self, msg):
            if not self.msg:
                self.msg = msg

    class TestDisplayOne(DisplayOne):
        ''' Used to capture verbose output '''
        def __init__(self):
            self.msg = ''
            super(TestDisplayOne, self).__init__()

        def display(self, msg, *args, **kwargs):
            self.msg = msg


# Generated at 2022-06-23 15:29:24.801723
# Unit test for function is_reserved_name
def test_is_reserved_name():
    try:
        # Don't use set literals below to make sure this test is always executed.
        # Otherwise, we could get syntax errors in Python versions < 2.7.
        assert(is_reserved_name('name'))
        assert(is_reserved_name('delegate_to'))
        assert(not is_reserved_name('foo'))
    except AssertionError:
        raise AssertionError("is_reserved_name returned unexpected result")

# Generated at 2022-06-23 15:29:35.264123
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('thisnameisnotreserved')
    assert is_reserved_name('block')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('register')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('handlers')
    assert is_reserved_name('vars')
    assert is_reserved_name('name')
    assert is_reserved_name('failure')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('pre_tasks')



# Generated at 2022-06-23 15:29:38.474200
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    def get_myvars():
        return set(['hosts', 'remote_user', 'handlers', 'tasks'])

    warn_if_reserved(get_myvars())
    warn_if_reserved(get_myvars(), additional=['x', 'y', 'z'])

# Generated at 2022-06-23 15:29:44.179181
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved = _RESERVED_NAMES

    for astr in ['hosts', 'name', 'gather_facts', 'action', 'local_action', 'with_', 'vars', 'tags']:
        assert is_reserved_name(astr)

    for astr in ['host', 'gather_fact', 'actions', 'local_actions', 'withs', 'var', 'tag']:
        assert not is_reserved_name(astr)