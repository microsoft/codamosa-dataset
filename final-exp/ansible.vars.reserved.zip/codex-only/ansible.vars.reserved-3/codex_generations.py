

# Generated at 2022-06-23 15:19:53.482069
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed

# Generated at 2022-06-23 15:19:57.535207
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('connection')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')


# Generated at 2022-06-23 15:20:02.694195
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'loop' in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names(include_private=False)
    assert 'loop' in get_reserved_names(include_private=True)
    assert 'tags' in get_reserved_names(include_private=True)
    assert 'tags' in get_reserved_names(include_private=False)

# Generated at 2022-06-23 15:20:10.159127
# Unit test for function get_reserved_names
def test_get_reserved_names():
    all_names = get_reserved_names(include_private=True)
    assert(set(['hosts', 'name', 'become', 'become_user', 'connection', 'gather_facts', 'serial', 'tags', 'roles', 'tasks', 'vars', 'any_errors_fatal', 'register', 'local_action', 'loop', 'with_']) == all_names)

    all_names = get_reserved_names(include_private=False)
    assert(set(['hosts', 'name', 'become', 'become_user', 'connection', 'gather_facts', 'serial', 'tags', 'roles', 'tasks', 'vars', 'any_errors_fatal', 'register', 'local_action', 'with_']) == all_names)



# Generated at 2022-06-23 15:20:12.216641
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('fail_on_missing_vars')
    assert not is_reserved_name('hosts')

# Generated at 2022-06-23 15:20:16.764884
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('block')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:20:19.579627
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in _RESERVED_NAMES
    assert 'async' in _RESERVED_NAMES
    assert 'delegate_to' in _RESERVED_NAMES
    assert 'loop' in _RESERVED_NAMES
    assert 'with_' in _RESERVED_NAMES



# Generated at 2022-06-23 15:20:28.113654
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:20:30.812458
# Unit test for function is_reserved_name
def test_is_reserved_name():
    name = 'hosts'  # 'hosts' is reserved
    assert is_reserved_name(name)

    name = 'monkey'  # 'monkey' is not reserved
    assert not is_reserved_name(name)

# Generated at 2022-06-23 15:20:39.205406
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    from ansible.module_utils import basic
    import os
    import time

    def fake_display_warning(msg):
        assert 'Found variable using reserved name: name' in msg

    old_display_warning = display.warning
    display.warning = fake_display_warning

    try:
        warn_if_reserved({"hosts": "all", "name": "test_play"}, additional={"name"})
    finally:
        display.warning = old_display_warning

    # test that we don't warn as name is not reserved
    try:
        warn_if_reserved({"hosts": "all", "name": "test_play"}, additional=set())
    except AssertionError as e:
        assert False, "warn_if_reserved() produced a warning unexpectedly: %s" % str(e)


# Generated at 2022-06-23 15:20:45.009873
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play import Play
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import Include
    from ansible.playbook.handler_task_include import Handler
    from ansible.playbook.vars_prompt import VarsPrompt
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode


# Generated at 2022-06-23 15:20:49.111578
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=True)
    assert 'remote_user' in reserved_names
    assert 'connection' in reserved_names
    assert 'vars' in reserved_names
    assert 'private' not in reserved_names  # we don't expose private


# Generated at 2022-06-23 15:20:51.210075
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()

    if 'handlers' in result:
        assert False


# Generated at 2022-06-23 15:20:52.900534
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved



# Generated at 2022-06-23 15:20:56.066219
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('with_items')
    assert is_reserved_name('roles')
    assert is_reserved_name('action')
    assert not is_reserved_name('other_role')

# Generated at 2022-06-23 15:21:02.003470
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=True)
    pub_reserved = get_reserved_names(include_private=False)
    #action and local_action are implicit
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'action' in pub_reserved
    assert 'local_action' in pub_reserved
    assert len(reserved) == len(pub_reserved) + 1
    # FIXME: remove when with_ is removed
    assert 'with_' in reserved
    assert 'loop' in reserved
    assert 'role_path' in reserved



# Generated at 2022-06-23 15:21:05.206555
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('delegate_to')
    assert not is_reserved_name('this_is_not_reserved')

# Generated at 2022-06-23 15:21:06.832841
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(_RESERVED_NAMES, frozenset)



# Generated at 2022-06-23 15:21:08.676701
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("foo") == False
    assert is_reserved_name("vars") == True

# Generated at 2022-06-23 15:21:15.802736
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars_dict1 = dict(action='/bin/foo', loop='{{loop}}', meta="{'rhel': 6}")
    vars_dict2 = dict(action='/bin/foo', loop='{{loop}}', meta='{"rhel": 6}')
    vars_dict3 = dict(action='/bin/foo', loop='{{loop}}', meta='{"rhel": 6}', acme='{"id": 42}')
    vars_dict4 = dict(action='/bin/foo', loop='{{loop}}', meta='{"rhel": 6}', acme='{"id": 42}',
                      loop_control='loop_var=foo')

# Generated at 2022-06-23 15:21:23.046972
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('tags')
    assert is_reserved_name('debug')
    assert is_reserved_name('connection')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('hosts')
    assert is_reserved_name('always_run')
    assert is_reserved_name('become')
    assert is_reserved_name('ignore_errors')
    assert is_reserved_name('no_log')
    assert is_reserved_name('hosts')
    assert is_reserved_name('environment')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('include')

# Generated at 2022-06-23 15:21:25.187855
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # print(_RESERVED_NAMES)
    # returns nothing, just tests for exceptions
    warn_if_reserved(['myvar', 'delegate_to', 'inventory_hostname'])

# Generated at 2022-06-23 15:21:36.547042
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    # check that certain words are in the set
    assert names.__contains__('hosts')
    assert names.__contains__('action')
    assert names.__contains__('vars')
    assert names.__contains__('when')
    assert names.__contains__('block')
    assert names.__contains__('delegate_to')
    assert names.__contains__('register')
    assert names.__contains__('failed_when')
    assert names.__contains__('ignore_errors')
    assert names.__contains__('tags')

    # check that a word is not in the set
    assert not names.__contains__('my_non_reserved_word')

    # check that set is same size with and without private attributes

# Generated at 2022-06-23 15:21:38.133890
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for value in get_reserved_names(include_private=False):
        assert is_reserved_name(value)

# Generated at 2022-06-23 15:21:38.782523
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    pass

# Generated at 2022-06-23 15:21:42.824954
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('loop')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:21:44.413564
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('tasks')

# Generated at 2022-06-23 15:21:56.277451
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    import sys
    from io import StringIO

    fake_stdout = StringIO()
    real_display = Display()
    real_display.verbosity = 2
    sys.stdout = fake_stdout
    real_display.warning = fake_stdout.write

    assert(is_reserved_name('roles'))
    assert(is_reserved_name('local_action'))
    assert(is_reserved_name('with_'))
    assert(is_reserved_name('vars'))
    assert(is_reserved_name('any_errors_fatal'))

    assert(not is_reserved_name('whatever_man'))

    # test that the warning is actually output
    # note: if this test fails, it means that the name has actually been

# Generated at 2022-06-23 15:21:57.482523
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')



# Generated at 2022-06-23 15:22:01.858502
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['foo', 'become', 'bar'])

    warn_if_reserved(['foo', 'delegate_to', 'bar'], additional=set(['delegate_to']))

# Generated at 2022-06-23 15:22:09.283683
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=False)

# Generated at 2022-06-23 15:22:17.452571
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

    # confirm public and private have proper number of expected elements
    assert(len(public) == len(private) - 8)

    # local_action is implicit with action
    assert(('local_action' in private and 'action' in public) or ('local_action' not in private and 'action' not in public))

    # loop implies with_
    assert(('loop' in private or 'loop' in public) or ('with_' not in private))

# Generated at 2022-06-23 15:22:18.951030
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)



# Generated at 2022-06-23 15:22:23.485375
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    display.verbosity = 1
    display.deprecated = True
    display.deprecated_args = True

    warn_if_reserved(['roles', 'name', 'with_', 'loop', '_bar', 'not_a_reserved_name'])
    assert display.deprecated == True
    assert display.deprecated_args == True

# Generated at 2022-06-23 15:22:29.683146
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(set(['hosts', 'name', 'tasks', 'vars', 'block']) == set(get_reserved_names(include_private=False)))
    assert(set(['hosts', 'name', 'private', 'tasks', 'vars', 'default_vars', 'vars_prompt', 'vars_files', 'block', 'action']) <= set(get_reserved_names(include_private=True)))


# Generated at 2022-06-23 15:22:36.884355
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('playbook')
    assert is_reserved_name('tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')

    assert not is_reserved_name('name of the game')
    assert not is_reserved_name('foo')



# Generated at 2022-06-23 15:22:45.658737
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['name', 'hosts', 'gather_facts', 'roles', 'vars', 'vars_files', 'tags', 'tasks', 'handlers', 'pre_tasks', 'post_tasks', 'block', 'include', 'private', 'any_errors_fatal', 'serial', 'max_fail_percentage', 'register', 'delegate_to', 'with_items', 'local_action', 'action', 'delegate_facts', 'notify', 'listen', 'pre_tasks', 'post_tasks', 'with_', 'loop', 'remote_user', 'become', 'become_user', 'become_method', 'become_flags', 'environment'])

# Generated at 2022-06-23 15:22:48.627103
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('name'))
    assert(is_reserved_name('tags'))
    assert(is_reserved_name('any_errors_fatal'))
    assert(is_reserved_name('remote_user'))
    assert(not is_reserved_name('foobar'))

# Generated at 2022-06-23 15:22:52.896821
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names(include_private=False)) == {'action', 'async', 'become', 'become_user', 'connection', 'delegate_to', 'environment', 'gather_facts', 'ignore_errors', 'local_action', 'max_fail_percentage', 'notify', 'poll', 'remote_user', 'register', 'run_once', 'serial', 'sudo', 'sudo_user', 'tags', 'until', 'when', 'with_'}



# Generated at 2022-06-23 15:22:59.899533
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this is a test function to verify the behaviour of warn_if_reserved '''
    # test a warning is printed upon normal use
    try:
        warn_if_reserved(['hosts'])
    except DeprecationWarning:
        pass
    else:
        print("Function warn_if_reserved didn't warn when it should have")

    # test a warning is not printed for safe variables
    try:
        warn_if_reserved(['testvar'])
    except DeprecationWarning:
        print("Function warn_if_reserved warned when it shouldn't have")
    else:
        pass


# Generated at 2022-06-23 15:23:02.719490
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert not is_reserved_name('with_sdasda')

# Generated at 2022-06-23 15:23:10.471429
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in _RESERVED_NAMES

    reserved_names_public = get_reserved_names(include_private=False)
    assert 'action' in reserved_names_public

    reserved_names_private = get_reserved_names(include_private=True)
    assert 'action' in reserved_names_private

    assert 'meta' in reserved_names_private and 'meta' not in reserved_names_public

    reserved_names_private_and_public = reserved_names_private.union(reserved_names_public)
    assert 'meta' in reserved_names_private_and_public

# Generated at 2022-06-23 15:23:20.021619
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function returns a list of reserved names associated with play objects '''

    # test for public reserved names

# Generated at 2022-06-23 15:23:31.676622
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for function get_reserved_names '''
    expected_public = (
        'any_errors_fatal', 'become', 'become_method',
        'become_user', 'block', 'connection', 'delegate_to', 'environment',
        'gather_facts', 'groups', 'hosts', 'ignore_errors', 'include',
        'include_role', 'local_action', 'meta', 'name', 'notify', 'post_tasks',
        'pre_tasks', 'remote_user', 'roles', 'serial', 'tags', 'tasks',
        'transport', 'when', 'with_',
    )

# Generated at 2022-06-23 15:23:33.843095
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('anything_else')
    assert is_reserved_name('name')

# Generated at 2022-06-23 15:23:44.427821
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    testobj = { 'hosts': 'myhost' }
    from ansible.compat.six import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader
    from ansible.vars import VariableManager

    # clear the warning registry before calling the function
    display._warning_registry = {}

    # create display and redirect stdout
    display.verbosity = 4
    buf = StringIO()
    display.display = buf

    # clear internal variables
    _RESERVED_NAMES = frozenset(get_reserved_names(include_private=False))

    # invalid vars
    testobj = { 'hosts': 'myhost', 'action': 'ping' }
    warn_if

# Generated at 2022-06-23 15:23:47.141556
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:23:53.605353
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(_RESERVED_NAMES == frozenset(['post_tasks', 'dependencies', 'connection', 'pre_tasks', 'roles', 'local_action', 'import_playbook', 'include', 'task_files', 'role_path', 'vars_files', 'block', 'handlers', 'register', 'vars', 'name', 'tags', 'with_items', 'gather_facts', 'tasks', 'action', 'notify', 'meta', 'async', 'with_', 'retries', 'changed_when', 'until', 'delegate_to']))

# Generated at 2022-06-23 15:24:00.965760
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('playbook')
    assert is_reserved_name('hosts')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('block')
    assert is_reserved_name('include_role')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('delegate_to')
    assert not is_reserved_name('other_name')


# Generated at 2022-06-23 15:24:06.588270
# Unit test for function is_reserved_name
def test_is_reserved_name():
    some_reserved_names = ['vars', 'action', 'local_action', 'with_', 'include_role', 'import_role', 'roles']
    for name in some_reserved_names:
        assert is_reserved_name(name)

    non_reserved_names = ['blah', 'bing', 'bong']
    for name in non_reserved_names:
        assert not is_reserved_name(name)

# Generated at 2022-06-23 15:24:18.562234
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible import errors
    from ansible.playbook import base
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.become import Become
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.utils.display import Display

    # setup fake vars collection
    def get_vars(self, loader, path, entities=None, cache=True):
        return dict()
    base.Base._get_vars = get_vars
    base.Base.display = Display()
    base.Base.vars_cache = dict()

# Generated at 2022-06-23 15:24:19.862152
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('action')



# Generated at 2022-06-23 15:24:21.465722
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts', 'roles', 'any_errors_fatal', 'become'])

# Generated at 2022-06-23 15:24:26.135483
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('notify')
    assert is_reserved_name('loop')

    assert not is_reserved_name('unknown')

# Generated at 2022-06-23 15:24:38.099762
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:24:41.052857
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.vars import VariableManager
    vars1 = VariableManager()
    vars1.extra_vars = dict(test_for='foo')
    warn_if_reserved(vars1.extra_vars)

# Generated at 2022-06-23 15:24:42.837183
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:24:51.619791
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'become' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'include' in reserved_names

    private_reserved_names = get_reserved_names(include_private=True)
    assert 'loop' in private_reserved_names
    assert 'any_errors_fatal' in private_reserved_names
    assert 'hosts' in private_reserved_names
    assert 'action' in private_reserved_names
    assert 'local_action' in private_reserved_names
    assert 'with_' in private_reserved_names

# Generated at 2022-06-23 15:24:55.538496
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('action')
    assert is_reserved_name('roles')
    assert not is_reserved_name('myvarname')

# Generated at 2022-06-23 15:24:58.326403
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts_all')
    assert not is_reserved_name('foo_bar')

# Generated at 2022-06-23 15:25:03.185567
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest

    with pytest.warns(UserWarning, match='Found variable using reserved name'):
        warn_if_reserved(['action'])

    with pytest.warns(UserWarning, match='Found variable using reserved name'):
        warn_if_reserved(['vars'])

    with pytest.warns(UserWarning, match='Found variable using reserved name'):
        warn_if_reserved(['vars'])

# Generated at 2022-06-23 15:25:13.142056
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    def test_module(*args, **kwargs):
        pass
    def test_module_with_vars(*args, **kwargs):
        pass

    fake_module_spec = 'ansible.module_utils.basic.AnsibleModule'
    module_spec = 'ansible.module_utils.basic.AnsibleModule'

# Generated at 2022-06-23 15:25:23.357364
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # test reserved names (warn_if_reserved should warn)
    with_ = True
    assert warn_if_reserved(['with_']) == with_
    assert warn_if_reserved(['tags']) == with_
    assert warn_if_reserved(['serial']) == with_
    assert warn_if_reserved(['run_once']) == with_
    assert warn_if_reserved(['any_errors_fatal']) == with_
    assert warn_if_reserved(['post_tasks']) == with_
    assert warn_if_reserved(['pre_tasks']) == with_
    assert warn_if_reserved(['vars_files']) == with_
    assert warn_if_reserved(['when']) == with_
    assert warn_if_res

# Generated at 2022-06-23 15:25:34.584298
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:37.634473
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved({'action': 'foo'})
    except AssertionError:
        pass
    else:
        raise RuntimeError('Test failed: reserved name not caught')



# Generated at 2022-06-23 15:25:40.909207
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-23 15:25:51.095914
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=False)

    assert type(reserved) == set
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'gather_facts' in reserved
    assert 'action' in reserved
    assert 'delegate_to' in reserved
    assert 'local_action' in reserved

    assert 'hosts_all' not in reserved
    assert 'with_all' not in reserved
    assert 'connection' not in reserved

    reserved = get_reserved_names(include_private=True)

    assert type(reserved) == set
    assert 'hosts_all' in reserved
    assert 'with_all' in reserved
    assert 'connection' in reserved
    assert 'connection_port' in reserved

# Generated at 2022-06-23 15:26:02.739944
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.role import Role

    role = Role.load(dict(name='test_role', vars=dict(vars=dict(action='hi'))))

    assert not is_reserved_name('hello')
    assert is_reserved_name('vars')
    assert is_reserved_name('any_errors_fatal')
    assert not is_reserved_name('no_log')

    assert is_reserved_name('become')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('hosts')
    assert is_reserved_name('tags')
    assert not is_reserved_name('become_user')

    assert not isinstance(role._role_vars, dict)

# Generated at 2022-06-23 15:26:14.054652
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible_collections.f5networks.f5_modules.tests.unit.compat import unittest

    class TestWarnIfReserved(unittest.TestCase):
        def test_is_reserved_name(self):
            for name in _RESERVED_NAMES:
                self.assertTrue(is_reserved_name(name), msg="%s is a reserved name." % name)

            names = ('not_a_reserved_name', 'and_another')
            for name in names:
                self.assertFalse(is_reserved_name(name), msg="%s is not a reserved name." % name)

        def test_warn_if_reserved(self):
            from ansible.utils.display import Display
            display = Display()
            display.warning = lambda msg: self.mess

# Generated at 2022-06-23 15:26:19.488872
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = dict(
        gather_facts='yes',
        action='show arp',
        any_errors_fatal=True,
        become_user='bob'
    )

    # This should only generate a single warning despite gather_facts,
    # and become_user being two of the reserved names
    warn_if_reserved(vars)

# Generated at 2022-06-23 15:26:22.784841
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'othervar'])
    warn_if_reserved(['action', 'othervar'], ['wildcard'])

# Generated at 2022-06-23 15:26:28.100352
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    
    assert 'vars' in names
    assert 'connection' in names
    assert 'gather_facts' in names
    assert 'gather_subset' in names
    assert 'remote_user' in names
    assert 'sudo' in names
    assert 'sudo_user' in names

    # implicit public
    assert 'local_action' in names
    assert 'with_' in names

# Generated at 2022-06-23 15:26:36.123725
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('name'))
    assert(is_reserved_name('when'))
    assert(is_reserved_name('local_action'))
    assert(is_reserved_name('with_'))
    assert(is_reserved_name('vars'))
    assert(is_reserved_name('vars_prompt'))
    assert(is_reserved_name('vars_files'))
    assert(is_reserved_name('vault_password_file'))
    assert(is_reserved_name('include'))
    assert(is_reserved_name('pre_tasks'))
    assert(is_reserved_name('tags'))
    assert(is_reserved_name('tasks'))

# Generated at 2022-06-23 15:26:40.420433
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_test_data = (
        {'include_private': True, 'expected': 39},
        {'include_private': False, 'expected': 31},
    )

    for test_data in reserved_test_data:
        assert len(get_reserved_names(test_data['include_private'])) == test_data['expected']

# Generated at 2022-06-23 15:26:44.600972
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # No guaranteed ordering, so we have to check each set individually
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names(include_private=False))

# Generated at 2022-06-23 15:26:54.172359
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print('Testing function get_reserved_names')
    # in the unit test we are using the full list
    # this is different to what we call in the code
    # which uses only the public reserved names
    name_list = sorted(get_reserved_names(include_private=True))

    print('Reserved names:')
    for name in name_list:
        print('\t%s' % name)

    print('Verifying all reserved names are reflected with either action or loop attributes')
    for name in name_list:
        if name.startswith('with_'):
            verify = 'loop'
        else:
            verify = 'action'

        if name == verify or name == 'local_action':
            continue

# Generated at 2022-06-23 15:27:03.974765
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:27:05.722071
# Unit test for function get_reserved_names
def test_get_reserved_names():
    results = get_reserved_names()
    assert 'environment' in results


# Generated at 2022-06-23 15:27:12.752767
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('playbook')
    assert is_reserved_name('vars')
    assert is_reserved_name('inventory')
    assert is_reserved_name('role_path')
    assert is_reserved_name('force_handlers')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('when')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('always_run')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('remote_user')
    assert is_reserved

# Generated at 2022-06-23 15:27:16.072665
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('pause')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('register')
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert is_reserved_name('with_items')
    assert not is_reserved_name('some_other_name')

# Generated at 2022-06-23 15:27:23.477132
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    my_vars = [
        'action',
        'local_action',
        'block',
        'roles',
        'loop',
        'with_',
        'vars',
        'name',
        'include',
        'include_role',
        'include_tasks',
        'tags',
        'tasks',
        'when',
        'post_tasks',
        'async',
        'poll',
        'become',
        'become_user',
        'become_method',
    ]
    warn_if_reserved(my_vars, frozenset(['async']))



# Generated at 2022-06-23 15:27:24.560054
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles') == True
    assert is_reserved_name('some_things') == False

# Generated at 2022-06-23 15:27:31.516850
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = _RESERVED_NAMES
    print("\ntest_is_reserved_name")
    for name in reserved_names:
        print("%r:%r" % (name,is_reserved_name(name)))

# Test function is_reserved_name
if __name__ == "__main__":
    test_is_reserved_name()

# Generated at 2022-06-23 15:27:33.805243
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('loop')
    assert not is_reserved_name('thereis')

# Generated at 2022-06-23 15:27:37.463921
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['hosts', 'hosts_as_json']) is None
    assert warn_if_reserved([]) is None
    # the check is on whether the name exists, not the value
    assert warn_if_reserved(['hosts'], {'hosts'}) is None

# Generated at 2022-06-23 15:27:48.384503
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_vars

    play_context = dict()

    host_vars = dict(magic=True)
    task_vars = dict(magic=False)
    extra_vars = dict(magic=True)
    templar = DictData(task_vars)

    display.options = dict(NOCOLOR=True)

    display.warning = lambda msg: msg[0]

    # Check host vars
    host = Host(name='localhost')
    host.vars = host_vars
    result = TaskResult(host=host, task=dict())

# Generated at 2022-06-23 15:27:55.531517
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    class FakeOpts(object):
        pass

    opts = FakeOpts()
    opts.roles = []
    opts.playbook = []
    opts.tags = []
    opts.skip_tags = []
    opts.extra_vars = dict()

    # should not warn
    warn_if_reserved(['foobar'])
    assert len(display._display.display_messages) == 0

    # should warn
    warn_if_reserved(['hosts'])
    assert len(display._display.display_messages) == 1

    # should warn
    warn_if_reserved(['hosts', 'foobar'])
    assert len(display._display.display_messages) == 2

    # should not warn
    display._display.display_messages = []
    warn

# Generated at 2022-06-23 15:27:58.104514
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['vars'])
    except Exception:
        assert False


# Generated at 2022-06-23 15:28:03.145894
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        class TestDisplay(object):
            def __init__(self, obj):
                self.obj = obj
            def warning(self, msg, *args, **kwargs):
                self.obj.assertIn('Found variable using reserved name: debug', msg)
        display = TestDisplay(self)
        warn_if_reserved(dict(debug='server'))
    finally:
        display = Display()

# Generated at 2022-06-23 15:28:04.646360
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("connection")


# Generated at 2022-06-23 15:28:05.652758
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['roles'])
    except AssertionError:
        pass

# Generated at 2022-06-23 15:28:13.389403
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # assert is_reserved_name
    assert is_reserved_name('roles')
    assert is_reserved_name('role_names')
    assert is_reserved_name('roles_path')
    assert is_reserved_name('name')
    assert is_reserved_name('include_vars')
    assert is_reserved_name('vars_files')
    assert is_reserved_name('tags')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('meta')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('tasks')

# Generated at 2022-06-23 15:28:21.824156
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # no error (empty set):
    test_1 = get_reserved_names()

    # error if we have a reserved variable
    test_2 = get_reserved_names()
    test_2.add('roles')

    # no error if we state we don't want private attributes
    test_3 = get_reserved_names(include_private=False)

    assert(test_1 == _RESERVED_NAMES)
    assert(test_2 != _RESERVED_NAMES)
    assert(test_3 != _RESERVED_NAMES)

# Generated at 2022-06-23 15:28:31.400547
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test with no arguments
    reserved_names = get_reserved_names()
    for name in reserved_names:
        assert is_reserved_name(name)

    # Test with the name and all upper case
    name = 'PRE_TASK'
    assert is_reserved_name(name.lower())
    assert is_reserved_name(name)
    assert is_reserved_name(name.upper())

    # Test with the name and some upper case
    name = 'preTask'
    assert is_reserved_name(name.lower())
    assert is_reserved_name(name)
    assert is_reserved_name(name.upper())

    # Test with the name and reversed casing
    name = 'PreTask'
    assert is_reserved_name(name.lower())
    assert is_res

# Generated at 2022-06-23 15:28:42.211234
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert_equals = _assert_equals(assert_equals)

# Generated at 2022-06-23 15:28:51.910318
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' make sure we have a passing test for warn_if_reserved '''


# Generated at 2022-06-23 15:28:55.021712
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('with_')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:28:59.432464
# Unit test for function get_reserved_names
def test_get_reserved_names():
    all_names = get_reserved_names()
    all_names.add('vars')
    for reserved_name in _RESERVED_NAMES:
        assert reserved_name in all_names
    assert len(all_names) == len(_RESERVED_NAMES) + 1

# Generated at 2022-06-23 15:29:10.287758
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this is just a unit test to ensure the above function is correct '''

    warn_if_reserved({'action': 'foo'})
    warn_if_reserved({'notify': 'foo'})
    warn_if_reserved({'local_action': 'foo'})
    warn_if_reserved({'role_name': 'foo'})
    warn_if_reserved({'with_': 'foo'})
    warn_if_reserved({'when': 'foo'})
    warn_if_reserved({'tags': 'foo'})
    warn_if_reserved({'name': 'foo'})

    warn_if_reserved({'delegate_to': 'foo'})
    warn_if_reserved({'become': 'foo'})

# Generated at 2022-06-23 15:29:12.356569
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert reserved == _RESERVED_NAMES

# Generated at 2022-06-23 15:29:14.005071
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'action': 'test'}, additional=['test'])



# Generated at 2022-06-23 15:29:23.421404
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # NOTE: This function is used by unit tests to test the code itself.
    # It can be removed if it's not used by unit tests anymore.
    class Foo:
        pass

    # check that it doesn't break with nothing to check
    reserved = set()
    warn_if_reserved(reserved)

    # check with a single known reserved name
    reserved.add('name')
    warn_if_reserved(reserved)

    # check with a known reserved name that's an object attribute
    foo = Foo()
    foo.name = 1
    warn_if_reserved(foo)

    # check with a known reserved name that is a dictionary key
    reserved.add('test')
    warn_if_reserved(reserved)

    # check with a known reserved name that is an object dictionary key
    foo = Foo()
    foo

# Generated at 2022-06-23 15:29:31.008371
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Test public reserved names are returned
    assert 'hosts' in get_reserved_names()

    # Test private reserved names are returned when requested
    assert 'hosts' in get_reserved_names(include_private=True)

    # Test private reserved names are not returned when not requested
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'delegate_to' in get_reserved_names(include_private=False)
    assert 'delegate_to' not in get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:29:39.538048
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # this test is used in the reserved variable checker
    # if this test fails, then reserved variable checking will be incorrect
    assert 'hosts' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()

    # this test will add methods to the public/private list
    # we need to ensure that our private list is still a subset of public
    assert set(get_reserved_names(include_private=False)).issubset(get_reserved_names(include_private=True))

# Generated at 2022-06-23 15:29:44.078058
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('private')
    assert is_reserved_name('private_raw_arguments')
    assert is_reserved_name('loop')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')

    assert not is_reserved_name('foobar')
    assert not is_reserved_name('delegated_vars')
    assert not is_reserved_name('register')