

# Generated at 2022-06-23 15:19:51.709297
# Unit test for function is_reserved_name
def test_is_reserved_name():
    names = ['name', 'become', 'become_user', 'sudo_user', 'sudo', 'remote_user', 'verbosity',
             'inventory', 'any_errors_fatal', 'max_fail_percentage', 'hosts', 'gather_facts',
             'host_key_checking', 'connect_timeout', 'serial', 'retries', 'start_at_task']
    for name in names:
        assert is_reserved_name(name) is True
    names = ['foo', 'bar']
    for name in names:
        assert is_reserved_name(name) is False

# Generated at 2022-06-23 15:20:00.673678
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display

    # create a fake display object to capture warnings and errors
    fake_display = Display()
    fake_display._verbosity = 4

    # create a list of variable names that should trigger a warning
    reserved_names = get_reserved_names(include_private=False)
    extra_names = set(['foo', 'bar', 'test_reserved'])
    reserved_names = reserved_names.union(extra_names)

    # clear all warnings
    fake_display._display.warnings = []

    # check that no warning is generated
    warn_if_reserved(reserved_names, additional=None)
    assert len(fake_display._display.warnings) == 0

    # check that a warning is generated

# Generated at 2022-06-23 15:20:05.493493
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert is_reserved_name('hosts')
    assert is_reserved_name('action')
    assert not is_reserved_name('wibble')
    assert is_reserved_name('any_errors_fatal')  # private but used by a lot of people
    assert not is_reserved_name('vars')  # we add this one internally, so safe to ignore

# Generated at 2022-06-23 15:20:10.103588
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Basic unit tests.
    assert 'delegate_to' in get_reserved_names()

    # Loop is a private attribute
    assert 'loop' in get_reserved_names()
    assert 'loop' in get_reserved_names(include_private=False)

# Generated at 2022-06-23 15:20:12.900266
# Unit test for function is_reserved_name
def test_is_reserved_name():
    test_dict = {'test1': True, 'test2': False}
    for play_var, expected in test_dict.iteritems():
        assert is_reserved_name(play_var) == expected

# Generated at 2022-06-23 15:20:20.415246
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test standard play and block reserved names
    warn_if_reserved(['name', 'hosts', 'tasks'])
    warn_if_reserved(['name', 'hosts', 'vars', 'tasks'])
    warn_if_reserved(['name', 'hosts', 'when', 'block'])
    warn_if_reserved(['name', 'hosts', 'vars', 'action', 'delegate_to', 'register'])
    warn_if_reserved(['name', 'hosts', 'vars', 'action', 'delegate_to', 'register'], additional=['action'])
    warn_if_reserved(['name', 'hosts', 'vars', 'action', 'delegate_to', 'register'], additional=['delegate_to'])
    warn_if_res

# Generated at 2022-06-23 15:20:31.129872
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    :return:
    '''

    # When ansible 2.6 is released, one can remove this test
    # and make sure we only have one entry per key

    # core, play, task and connection attributes
    assert 'strategy' in get_reserved_names()
    assert 'any_errors_fatal' in get_reserved_names()

    # block and task attributes
    assert 'async' in get_reserved_names()

    # FIXME: remove with_ once it is not only deprecated but removed
    assert 'with_' in get_reserved_names()

    # Job control
    assert 'async_poll_interval' in get_reserved_names()
    assert 'accelerate' in get_reserved_names()
    assert 'accelerate_ipv6' in get_reserved

# Generated at 2022-06-23 15:20:32.380500
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'action': 'foo'})

# Generated at 2022-06-23 15:20:40.429095
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:20:44.433612
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names(False)
    warn_if_reserved(reserved, set(['this', 'that', 'and_the_other']))

# Generated at 2022-06-23 15:20:46.727297
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('not_name') == False


# Generated at 2022-06-23 15:20:56.969143
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = SortedSet()

    # Use a set to compare
    foo = set(get_reserved_names(include_private=False))

    # public
    assert 'hosts' in foo
    assert 'roles' in foo

    # private
    assert 'host' in foo

    reserved.add(u'hosts')
    reserved.add(u'roles')
    reserved.add(u'action')
    reserved.add(u'local_action')
    reserved.add(u'any_errors_fatal')
    reserved.add(u'become')
    reserved.add(u'become_method')
    reserved.add(u'become_user')
    reserved.add(u'connection')
    reserved.add(u'delegate_facts')
    reserved.add(u'depth')


# Generated at 2022-06-23 15:21:00.287013
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('become')
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('my_var')

# Generated at 2022-06-23 15:21:08.546959
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Get all reserved names
    reserved_names = get_reserved_names(include_private=True)
    # Get all reserved names excluding private ones
    public_reserved_names = get_reserved_names(include_private=False)

    # Make sure there are no private reserved names which are not in public names
    assert len(reserved_names.difference(public_reserved_names)) == 0
    # Ensure all public names are in the reserved names list
    assert len(public_reserved_names.difference(reserved_names)) == 0

# Generated at 2022-06-23 15:21:12.762617
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # import sys
    # sys.argv.append('--collect-only')
    # from ansible.cli import CLI
    # cli = CLI()
    # cli.parse()

    # for p in cli.all_playbooks:
    #     print('%s' % p)
    #     vars = get_vars(p)
    #     warn_if_reserved(vars)

    pass

# Generated at 2022-06-23 15:21:15.495740
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:21:19.358510
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('action')
    assert not is_reserved_name('not_a_reserverd_name')

# Generated at 2022-06-23 15:21:23.538583
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in ['vars', 'roles', 'name', 'strategy', 'hosts', 'register']:
        assert is_reserved_name(name)

    for name in ['foobar']:
        assert not is_reserved_name(name)


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-v', __file__]))

# Generated at 2022-06-23 15:21:28.549445
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'hosts', 'user'}) == set(['hosts', 'user'])
    assert warn_if_reserved({'hosts', 'user', 'test'}, additional={'test'}) == set(['hosts', 'user', 'test'])
    assert warn_if_reserved({'hosts', 'user'}, additional={'test'}) == set(['hosts', 'user'])
    assert warn_if_reserved({'hosts', 'user', 'test', 'vars'}) == set(['hosts', 'user', 'test'])

# Generated at 2022-06-23 15:21:35.085019
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.splitter import load_lines_to_lines

    data = '''
    - hosts: localhost
      vars:
        var1: 1
        var2: 2
        var3: 3
        var4: 4
      tasks:
        - debug: msg={{ item }}
          with_items: "{{ var1 }}"
    '''

    lines = load_lines_to_lines(data)
    warn_if_reserved(lines[2])



# Generated at 2022-06-23 15:21:39.897852
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('include_role') is True
    assert is_reserved_name('action') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('ignore_errors') is True
    assert is_reserved_name('deprecated') is True
    assert is_reserved_name('not_a_reserved_name') is False

# Generated at 2022-06-23 15:21:43.247857
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert is_reserved_name('roles')
    assert is_reserved_name('action')
    assert not is_reserved_name('not_reserved')
    assert not is_reserved_name(42)  # test corner case

# Generated at 2022-06-23 15:21:44.509509
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert not warn_if_reserved(["not_reserved", "is_a_reserved_name"])
    assert warn_if_reserved(["is_a_reserved_name"])

# Generated at 2022-06-23 15:21:49.726613
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names, private_names = get_reserved_names(include_private=False), get_reserved_names(include_private=True)
    assert private_names - public_names == set(['loop', 'vars', 'include', 'tags', 'name', 'private'])

# Generated at 2022-06-23 15:21:50.912818
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name(u'any_errors_fatal')



# Generated at 2022-06-23 15:22:00.481484
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=False)
    print('reserved names: ', reserved)
    assert len(reserved) == 48
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'loop' in reserved
    assert 'vars' in reserved
    assert 'tags' in reserved
    assert 'gather_facts' in reserved

    reserved = get_reserved_names(include_private=True)
    print('reserved names: ', reserved)
    assert len(reserved) == 51
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'loop' in reserved
    assert 'vars' in reserved
    assert 'tags' in reserved
    assert 'gather_facts' in reserved
    assert 'merge_vars' in reserved

# Generated at 2022-06-23 15:22:05.596812
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert is_reserved_name('name') is True
    assert is_reserved_name('include_role') is True
    assert is_reserved_name('action') is False
    assert is_reserved_name('sudo') is False
    assert is_reserved_name('sudo_user') is False
    assert is_reserved_name('vars') is False

# Generated at 2022-06-23 15:22:15.296569
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert is_reserved_name('vars')
    assert not is_reserved_name('var')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('bar')
    assert not is_reserved_name('x')
    assert not is_reserved_name('y')
    assert not is_reserved_name('when')
    assert not is_reserved_name('roles')
    assert not is_reserved_name('task')
    assert not is_reserved_name('block')
    assert not is_reserved_name('play')

# Generated at 2022-06-23 15:22:18.672451
# Unit test for function get_reserved_names
def test_get_reserved_names():
    for rname in _RESERVED_NAMES:
        assert rname in _RESERVED_NAMES, \
               "{0} not in reserved names".format(rname)

# Generated at 2022-06-23 15:22:21.868377
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('no_log')
    assert is_reserved_name('vars')
    assert is_reserved_name('any_errors_fatal')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('bar')

# Generated at 2022-06-23 15:22:22.400414
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    pass

# Generated at 2022-06-23 15:22:26.552298
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    _RESERVED_NAMES = get_reserved_names()
    myvars = {'action': 'foo', 'delegate_to': 'bar', 'local_action': 'baz'}
    warn_if_reserved(myvars)


# Generated at 2022-06-23 15:22:34.100933
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:22:43.520974
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    import copy
    import StringIO

    # Back up stdout
    stdout_fd = sys.stdout.fileno()
    stdout_bak = os.dup(stdout_fd)

    # Try with non-reserved names
    new_stdout = StringIO.StringIO()
    os.dup2(new_stdout.fileno(), stdout_fd)
    warn_if_reserved(['test1', 'test2'])
    assert new_stdout.getvalue() == ''
    new_stdout.close()
    os.dup2(stdout_bak, stdout_fd)

    # Try with reserved names, including a variable constructed
    # from a reserved name
    new_stdout = StringIO.StringIO()

# Generated at 2022-06-23 15:22:48.291135
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved = []
    for name in _RESERVED_NAMES:
        reserved.append(is_reserved_name(name))
    assert all(reserved)
    assert not is_reserved_name("dummy_name")

# Generated at 2022-06-23 15:22:52.597002
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('any_errors_fatal')

    # private names are reserved as well
    assert is_reserved_name('loop')
    assert is_reserved_name('action')

    # this is not in a reserved name
    assert not is_reserved_name('variables')

# Generated at 2022-06-23 15:22:54.928357
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for reserved in _RESERVED_NAMES:
        assert is_reserved_name(reserved)



# Generated at 2022-06-23 15:22:58.141765
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    keys = {'vars', 'action', 'register'}
    assert warn_if_reserved(keys) == None


# Generated at 2022-06-23 15:23:07.847294
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:23:17.624544
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get reserved names
    pub = get_reserved_names(include_private=False)

    # test to make sure it includes some expected names
    assert 'roles' in pub
    assert 'tasks' in pub
    assert 'vars' in pub

    # test to make sure it does not include some private names
    assert 'action' not in pub
    assert 'remote_user' not in pub
    assert 'register' not in pub
    assert 'loop' not in pub
    assert 'delegate_to' not in pub

    # get reserved names including private
    priv = get_reserved_names(include_private=True)

    # test to make sure it includes some private names
    assert 'action' in priv
    assert 'remote_user' in priv

    # test to make sure it is the same size or greater than the public
   

# Generated at 2022-06-23 15:23:29.898254
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import mock
    import __builtin__

    with mock.patch('ansible.playbook.play_context.warn_if_reserved.display') as mock_display:
        warn_if_reserved(['vars', 'serial', 'tags', 'foobar'])
        assert mock_display.deprecated.call_count == 1
        mock_display.warning.called_once_with('Found variable using reserved name: foobar')

        # FIXME: consider using a real test suite for these tests instead of
        # using a try block in unit tests
        try:
            warn_if_reserved(['vars', 'serial', 'tags', 'foobar'], ['foobar'])
        except Exception as e:
            pass
        else:
            raise Exception('No Exception Raised')



# Generated at 2022-06-23 15:23:34.623613
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('hosts2') == False
    assert is_reserved_name('__magic__') == True
    assert is_reserved_name('__magic2__') == False

# Generated at 2022-06-23 15:23:42.728927
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_private = [
        'become',
        'become_method',
        'become_user',
        'block',
        'connection',
        'delegate_to',
        'environment',
        'failed_when',
        'ignore_errors',
        'local_action',
        'loop',
        'no_log',
        'notify',
        'register',
        'retries',
        'run_once',
        'sudo',
        'sudo_user',
        'transport',
        'when',
        'with_',
    ]


# Generated at 2022-06-23 15:23:47.986327
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # Verify that is_reserved_name returns True for all reserved names.
    for reserved_name in _RESERVED_NAMES:
        assert is_reserved_name(reserved_name) == True



# Generated at 2022-06-23 15:23:57.622030
# Unit test for function is_reserved_name

# Generated at 2022-06-23 15:24:07.990503
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test that the warn_if_reserved function correctly
        classifies reserved variables'''

    # List of variable names which should be considered reserved

# Generated at 2022-06-23 15:24:13.220413
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'action', 'become', 'become_method', 'become_user', 'block', 'connection', 'delegate_to', 'gather_facts', 'hosts', 'ignore_errors', 'name', 'no_log', 'notify', 'poll', 'register', 'remote_user', 'run_once', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'vars', 'with_items', 'ignore_unreachable', 'any_errors_fatal'}

    name = 'action'
    assert is_reserved_name(name)

    name = 'fake_name'
    assert not is_reserved_name(name)

# Generated at 2022-06-23 15:24:18.408497
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    assert(len(reserved) > 0)
    assert('hosts' in reserved)
    assert('roles' in reserved)
    assert('action' in reserved)
    assert('vars' in reserved)



# Generated at 2022-06-23 15:24:22.200198
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(_RESERVED_NAMES) == 53
    assert is_reserved_name('serial')
    assert is_reserved_name('name')

    assert 'serial' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES

    assert 'action' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES

    assert 'loop' in _RESERVED_NAMES
    assert 'with_' in _RESERVED_NAMES

# Generated at 2022-06-23 15:24:26.593588
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == frozenset(get_reserved_names()).difference(frozenset(get_reserved_names(include_private=True)))


# Generated at 2022-06-23 15:24:38.513215
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:24:40.089061
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('foo')
    assert is_reserved_name('roles')

# Generated at 2022-06-23 15:24:45.386339
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    # some examples
    assert 'action' in reserved
    assert 'block' in reserved
    assert 'hosts' in reserved
    assert 'name' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved

    reserved = get_reserved_names(include_private=False)
    assert 'with_' not in reserved

# Generated at 2022-06-23 15:24:53.036410
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text

    display.verbosity = 4

    class Capture(object):
        captured = None

        def __init__(self):
            self._stderr = None

        def __enter__(self):
            self._stderr = sys.stderr
            sys.stderr = self

        def __exit__(self, exc_type, exc_value, traceback):
            sys.stderr = self._stderr

        def write(self, out):
            self.captured = out

    # Make sure we don't warn on a non-reserved name.
    with Capture() as c:
        warn_if_reserved(['foo'])
        assert c.captured is None

    # Make sure we do warn

# Generated at 2022-06-23 15:24:55.087873
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('block')
    assert is_reserved_name('action')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:25:04.012041
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test reserved names in the form 'some_name'
    assert is_reserved_name('register')
    assert is_reserved_name('sudo')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('environment')
    # Test reserved names in the form 'some_name: mystring'
    assert is_reserved_name('name: mytext')
    assert is_reserved_name('role: mytext')
    assert is_reserved_name('include: mytext')
    assert is_reserved_name('import_role: mytext')
    assert is_reserved_name('include_role: mytext')
    assert is_reserved_name('include_tasks: mytext')
    assert is_reserved_name('import_tasks: mytext')

# Generated at 2022-06-23 15:25:05.970226
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('foo')


# Generated at 2022-06-23 15:25:10.278154
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test reserved names warning'''
    warn_if_reserved({'roles': 'somerole', 'vars': 'somevar'})
    warn_if_reserved({'roles': 'somerole', 'vars': 'somevar', 'become_user': 'whatever'})

# Generated at 2022-06-23 15:25:12.836448
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    display.warning = lambda x: x
    assert warn_if_reserved({'name': 'bad', 'connection': 'blah'}) == 'Found variable using reserved name: name\nFound variable using reserved name: connection'

# Generated at 2022-06-23 15:25:23.077240
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    myvars = PlayContext()
    # insert some vars
    myvars['hosts'] = 'foo'
    myvars['action'] = 'bar'
    myvars['all_hosts'] = 'baz'
    myvars['all_hosts_x'] = 'bazz'
    # assert warnings for two of four vars, two should not trigger warnings
    assert warn_if_reserved(myvars) == 1, "warn_if_reserved did not return expected value, got: %d, expected 1" % warn_if_reserved(myvars)
    # add another var, assert warning was added
    myvars['some_other_var'] = 'some_other_value'

# Generated at 2022-06-23 15:25:26.869144
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('pre_tasks')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('hosts')
    assert not is_reserved_name('library')

# Generated at 2022-06-23 15:25:38.022597
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:45.186507
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Hack to test for deprecation warnings in less than python3
    import warnings

    warnings.simplefilter("always")

    from ansible.utils import warning_if_deprecated


# Generated at 2022-06-23 15:25:53.792392
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert 'hosts' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES
    assert 'any_errors_fatal' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'gather_facts' in _RESERVED_NAMES
    assert 'vars' not in _RESERVED_NAMES
    assert 'pre_tasks' in _RESERVED_NAMES
    assert 'post_tasks' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES
    assert 'rescue' in _RESERVED_NAMES

# Generated at 2022-06-23 15:25:58.505685
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') is True
    assert is_reserved_name('private_role_var') is True
    assert is_reserved_name('tags') is False
    assert is_reserved_name('nazgul') is False



# Generated at 2022-06-23 15:26:05.534616
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:09.680983
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(False)
    assert 'roles' in reserved
    assert 'private' in reserved
    assert 'private1' not in reserved
    reserved = get_reserved_names(True)
    assert 'private' in reserved
    assert 'private1' in reserved

# Generated at 2022-06-23 15:26:10.779380
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['connection'])

# Generated at 2022-06-23 15:26:14.888851
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('tags')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert not is_reserved_name('dummy')


# Generated at 2022-06-23 15:26:20.250893
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' validate that all of the reserved names are unique and do not
        match any public names for the play objects
    '''
    public = get_reserved_names(include_private=False)
    reserved = get_reserved_names()

    assert isinstance(public, set)
    assert isinstance(reserved, set)

    assert set().union(public).union(reserved) == reserved

# Generated at 2022-06-23 15:26:22.867116
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('roles'))
    assert(not is_reserved_name('my_roles'))

# Generated at 2022-06-23 15:26:29.624764
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    myvars = PlayContext()
    myvars._set_variable('connection', 'local')
    myvars._set_variable('action', 'setup')
    myvars._set_variable('serial', 50)
    myvars._set_variable('gather_facts', True)
    myvars._set_variable('delegate_to', '127.0.0.1')
    myvars._set_variable('max_fail_percentage', 30)
    Templa

# Generated at 2022-06-23 15:26:31.796869
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test true cases
    assert is_reserved_name('hosts')
    # Test false cases
    assert not is_reserved_name('host')


# unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:38.448850
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # test that no warning is issued if there are no reserved names
    warn_if_reserved(set(['foo', 'bar']))
    # test that private reserved names are not warnings, outside of context
    warn_if_reserved(set(['foo', '_bar', 'bar']), additional=set(['_bar']))
    # test that private reserved names are not warnings, inside of context
    warn_if_reserved(set(['foo', '_bar', 'bar']), additional=set(['_bar', 'foo']))
    # test that private reserved names are warnings, outside of context
    warn_if_reserved(set(['foo', '_bar', 'bar']), additional=set(['_bar', 'foo', 'bar']))
    # test that private reserved names are warnings, inside of context
    warn_if_res

# Generated at 2022-06-23 15:26:48.815223
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:57.032055
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:27:06.588303
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest

    from ansible.compat.tests.mock import patch

    class RecordedDeprecation(object):
        def __init__(self):
            self.calls = 0

    def record_deprecation():
        recorded_deprecation.calls += 1

    recorded_deprecation = RecordedDeprecation()

    with patch('ansible.playbook.deprecate.record_deprecation', record_deprecation):
        warn_if_reserved(['a'])
        assert recorded_deprecation.calls == 0

        warn_if_reserved(['action'])
        assert recorded_deprecation.calls == 0

        warn_if_reserved(['vars'])
        assert recorded_deprecation.calls == 0


# Generated at 2022-06-23 15:27:14.059524
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    try:
        old_display = display.verbosity
        display.verbosity = 4
        warn_if_reserved(['gather_facts', 'roles', 'roles_path', 'post_tasks', 'pre_tasks', 'vars', 'vars_files', 'vars_prompt', 'handlers', 'handlers_path', 'include_role'])
    finally:
        display.verbosity = old_display

# Generated at 2022-06-23 15:27:23.515972
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:27:28.798996
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved_names = frozenset(['name', 'tasks', 'vars', 'register', 'with_', 'local_action', 'any_errors_fatal'])

    warn_if_reserved([])
    warn_if_reserved({})
    warn_if_reserved(['foo'])
    warn_if_reserved(['foo', 'bar'])

    assert not warn_if_reserved(['foo'])
    assert not warn_if_reserved(['foo', 'bar'])

    assert warn_if_reserved(['foo', 'name'])
    assert warn_if_reserved(['foo', 'name', 'bar'])
    assert warn_if_reserved(['foo', 'name', 'name', 'bar'])

# Generated at 2022-06-23 15:27:35.667887
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['role_name', 'tags', 'when', 'delegate_to', 'run_once', 'serial', 'tasks', 'handlers', 'pre_tasks', 'post_tasks', 'block', 'blockrescue', 'blockalways', 'post_validate', 'notify', 'vars_prompt', 'tags', 'any_errors_fatal', 'notify_content', 'registered', 'local_action', 'with_', 'when'])

# Generated at 2022-06-23 15:27:38.736337
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'tags' in reserved

# Generated at 2022-06-23 15:27:41.597230
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)
    assert not is_reserved_name('ham')

# Generated at 2022-06-23 15:27:50.787070
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.dataloader import DataLoader

    import tempfile
    import shutil
    import os
    import stat

    # we want no display of warnings by default
    display.WARNINGS = False

    datadir = os.path.join(os.path.dirname(__file__), 'reserved_play_data')
    tmpdir = tempfile.mkdtemp(dir=os.getcwd())

    # update the permissions of the reserved_play_data in the test directory
    # so it can be copied
    def update_permissions_recursive(dire):
        for root, dirs, files in os.walk(dire):
            for momo in dirs:
                os.chmod(os.path.join(root, momo), stat.S_IWRITE)

# Generated at 2022-06-23 15:27:59.783386
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # list of names to exclude
    exclude = ['vars', 'include']

    # loop through reserved names and make sure each name is available
    for name in get_reserved_names():
        if name in exclude:
            continue
        assert hasattr(Play(), name)

    # list of additional names that should show up in get_reserved_names
    additional = ['with_', 'local_action']

    # loop through additional names and make sure each name is in reserved names
    for name in additional:
        assert name in get_reserved_names()

# Generated at 2022-06-23 15:28:09.448089
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Tests for public attributes
    public = {'name', 'hosts', 'gather_facts', 'tags', 'vars', 'vars_prompt', 'vars_files', 'roles', 'roles_path', 'tasks', 'handlers', 'pre_tasks', 'post_tasks', 'serial', 'any_errors_fatal', 'max_fail_percentage', 'block', 'block_tasks', 'ignore_errors', 'delegate_to', 'run_once', 'connection', 'sudo', 'sudo_user', 'become', 'become_method', 'become_user', 'check_mode', 'diff', 'when', 'notify', 'async', 'poll', 'until', 'retries', 'delay', 'environment', 'register', 'run_once', 'local_action'}

# Generated at 2022-06-23 15:28:12.039137
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_case = [
        ('test_var', False),
        ('roles', False),
        ('hosts', False),
        ('with_', True),
        ('with_items', True),
        ('name', True),
    ]
    for name, result in test_case:
        assert result == is_reserved_name(name)

# Generated at 2022-06-23 15:28:18.400909
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    assert 'variable_manager' in reserved
    assert 'only_tags' in reserved
    assert 'inventory' in reserved
    assert 'name' in reserved
    assert 'serial' in reserved
    assert 'connection' in reserved
    assert 'remote_user' in reserved
    assert '_private_action' in reserved
    assert '_private_state' in reserved
    assert '_private_changed_when' in reserved

    assert 'private_role_vars' not in reserved
    assert 'private_inventory_vars' not in reserved
    assert 'private_play_vars' not in reserved
    assert 'private_keywords' not in reserved

# Generated at 2022-06-23 15:28:28.417885
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for reserved names '''

    names = get_reserved_names()

    assert isinstance(names, set)

    assert 'block' in names
    assert 'block' in get_reserved_names(include_private=False)

    assert 'include' in names
    assert 'include' in get_reserved_names(include_private=False)

    assert '_raw_params' in names
    assert '_raw_params' not in get_reserved_names(include_private=False)

    assert 'vars' in names
    assert 'vars' in get_reserved_names(include_private=False)

    assert 'local_action' in names
    assert 'local_action' not in get_reserved_names(include_private=False)

    assert 'action' in names
    assert 'action'

# Generated at 2022-06-23 15:28:31.383028
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('notify')
    assert is_reserved_name('with_items')
    assert not is_reserved_name('not_reserved')


# Generated at 2022-06-23 15:28:35.329907
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print(get_reserved_names(True))
    assert isinstance(get_reserved_names(True), set)
    print(get_reserved_names(False))
    assert isinstance(get_reserved_names(False), set)

# Generated at 2022-06-23 15:28:38.461794
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('with_items')
    assert is_reserved_name('roles')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:28:44.890401
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'roles' in reserved
    assert 'vars' in reserved
    assert 'block' in reserved
    assert 'block' in reserved
    assert 'local_action' in reserved
    assert 'conditional' in reserved
    assert 'when' in reserved
    assert 'with_' in reserved
    assert 'include' in reserved
    assert 'pre_tasks' in reserved
    assert 'post_tasks' in reserved



# Generated at 2022-06-23 15:28:48.565966
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = {'foo': 'bar', 'debug': True, 'vars': False, 'when': True}
    warn_if_reserved(myvars)

if __name__ == '__main__':
    test_warn_if_reserved()

# Generated at 2022-06-23 15:28:51.065309
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    testvar = ['the_hosts_file', 'the_environment_file', 'the_inventory_file']
    warn_if_reserved(testvar)
    assert is_reserved_name('the_hosts_file')

# Generated at 2022-06-23 15:28:58.775204
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=False)
    assert set(['action', 'async', 'block', 'cacheable', 'connection', 'delegate_to', 'gather_facts', 'ignore_errors', 'loop', 'max_fail_percentage', 'name', 'notify', 'notified_by', 'poll', 'register', 'remote_user', 'serial', 'tags', 'transport', 'until', 'sudo', 'sudo_user', 'vars_files', 'with_', 'when']) == reserved

    reserved = get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:29:01.106594
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('private')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:29:07.893656
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('play_hosts')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('vars')
    assert not is_reserved_name('awesome_var')
    assert not is_reserved_name('roles')
    assert not is_reserved_name('block')

# Generated at 2022-06-23 15:29:10.166108
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') == True
    assert is_reserved_name('playbook') == True
    assert is_reserved_name('foobarfoo') == False

# Generated at 2022-06-23 15:29:15.723373
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_dict = {'action': 'value',
                 'name': 'value',
                 'debug': 'value',
                 'local_action': 'value',
                 'with_': 'value',
                 'when': 'value',
                 'loop': 'value',
                 'other_key': 'value'}

    warn_if_reserved(test_dict)

    assert test_dict['other_key'] == 'value'

# Generated at 2022-06-23 15:29:17.928926
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('tasks')
    assert not is_reserved_name('custom')

# Generated at 2022-06-23 15:29:20.043297
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    d = {'vars': {'hosts': 'hostz'}, 'hosts': 'hostz'}
    warn_if_reserved(d)

# Generated at 2022-06-23 15:29:26.354932
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('become_user')
    assert is_reserved_name('with_items')
    assert not is_reserved_name('not_reserved')
    assert is_reserved_name('_private')
    assert not is_reserved_name('_private', include_private=False)



# Generated at 2022-06-23 15:29:31.465132
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''Check all reserved names are in the returned set.'''
    reserved_names = get_reserved_names(include_private=False)
    assert 'name' in reserved_names
    assert 'action' in reserved_names
    assert 'tags' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'vars_files' in reserved_names



# Generated at 2022-06-23 15:29:38.530895
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Ensure get_reserved_names function is returning expected values '''
    expected_public = set(['name', 'hosts', 'gather_facts', 'vars', 'vars_prompt', 'vars_files', 'task_filters', 'tags', 'skip_tags', 'allow_duplicates', 'any_errors_fatal', 'serial', 'max_fail_percentage', 'strategy',
        'pre_tasks', 'roles', 'post_tasks', 'handlers', 'become', 'become_user', 'become_method', 'remote_user', 'sudo', 'sudo_user', 'connection', 'timeout', 'environment', 'action', 'local_action'])

# Generated at 2022-06-23 15:29:46.618727
# Unit test for function warn_if_reserved