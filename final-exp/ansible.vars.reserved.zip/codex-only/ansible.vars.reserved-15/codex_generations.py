

# Generated at 2022-06-23 15:19:49.647280
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert is_reserved_name('action')
    assert is_reserved_name('tasks')
    assert is_reserved_name('name')
    assert get_reserved_names(include_private=False) == _RESERVED_NAMES - frozenset(['loop', 'any_errors_fatal', 'any_errors_fatal'])
    assert is_reserved_name('loop')

# Generated at 2022-06-23 15:19:50.822133
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('roles'))
    assert(not is_reserved_name('blarg'))

# Generated at 2022-06-23 15:19:52.153379
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'action': 'hi'}, additional=['a', 'b'])

# Generated at 2022-06-23 15:20:01.004506
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Testing public names
    public_reserved_names = get_reserved_names(include_private=False)
    assert 'hosts' in public_reserved_names
    assert 'tasks' in public_reserved_names

    # Testing private names
    private_reserved_names = get_reserved_names(include_private=True)
    assert 'strategy' in private_reserved_names
    assert 'vars_files' in private_reserved_names

    # local_action is implicit with 'action'
    assert 'local_action' in get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:20:09.312405
# Unit test for function get_reserved_names
def test_get_reserved_names():
    fn_name = test_get_reserved_names.__name__

    sn = get_reserved_names()
    assert 'hosts' in sn, '%s: did not find "hosts" in reserved names' % fn_name
    assert len(sn) > 30, '%s: expected length of reserved names > 30, got %d' % (fn_name, len(sn))

    sn = get_reserved_names(False)
    assert 'hosts' in sn, '%s: did not find "hosts" in reserved names' % fn_name
    assert 'become' in sn, '%s: did not find "become" in reserved names' % fn_name

# Generated at 2022-06-23 15:20:16.722418
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''unit tests for the get_reserved_names function'''
    # No private reserved names
    no_private = get_reserved_names(include_private=False)
    # All reserved names
    all_reserved = get_reserved_names(include_private=True)
    # Make sure we have all reserved names
    assert all_reserved == _RESERVED_NAMES
    # The set of reserved public names should be a subset of all reserved names
    assert no_private <= all_reserved
    # The set of reserved public names should not be empty
    assert no_private != set()

# Generated at 2022-06-23 15:20:17.477178
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True

# Generated at 2022-06-23 15:20:22.194801
# Unit test for function get_reserved_names
def test_get_reserved_names():
    p = Play()

    role = Role()
    role._role_name = 'test_role'

    block = Block()

    task = Task()

    a = get_reserved_names()
    assert 'gather_facts' in a
    assert 'delegate_to' in a

    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                continue
            else:
                assert attribute in a

# Generated at 2022-06-23 15:20:30.865639
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    var_name = 'vars'
    myvars = [var_name]
    assert not warn_if_reserved(myvars)
    var_name = 'action'
    myvars = [var_name]
    assert not warn_if_reserved(myvars)
    var_name = 'local_action'
    myvars = [var_name]
    assert not warn_if_reserved(myvars)
    var_name = 'with_'
    myvars = [var_name]
    assert not warn_if_reserved(myvars)
    var_name = 'bogus'
    myvars = [var_name]
    assert warn_if_reserved(myvars)

# Generated at 2022-06-23 15:20:36.737598
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles') is True
    assert is_reserved_name('pre_tasks') is True
    assert is_reserved_name('roles_path') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('roles_abspath') is True
    assert is_reserved_name('name_original') is True
    assert is_reserved_name('vars') is False
    assert is_reserved_name('test_if_reserved_name') is False

# Generated at 2022-06-23 15:20:41.185507
# Unit test for function is_reserved_name
def test_is_reserved_name():
    p = Play()
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'roles' in _RESERVED_NAMES
    assert is_reserved_name('roles') is True
    p.connection = 'foo'
    assert 'connection' in _RESERVED_NAMES
    assert is_reserved_name('connection') is True
    assert is_reserved_name('non_reserved_name') is False

# Generated at 2022-06-23 15:20:46.679278
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = get_reserved_names(include_private=True)
    reserved_names.add('vars')
    for reserved_name in reserved_names:
        assert is_reserved_name(reserved_name)
    assert not is_reserved_name('name_that_is_not_reserved')

# Generated at 2022-06-23 15:20:50.848249
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') is True
    assert is_reserved_name('action') is True
    assert is_reserved_name('any_other_key') is False



# Generated at 2022-06-23 15:20:56.183201
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == set(get_reserved_names(False))
    assert set(['handler', 'hosts', 'name', 'roles', 'tasks', 'vars']) == set(get_reserved_names(False))
    assert set(['handler', 'hosts', 'name', 'roles', 'tasks', 'vars', 'when']) == set(get_reserved_names(True))


# Generated at 2022-06-23 15:21:00.389393
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['hosts', 'roles', 'vars'])
    assert warn_if_reserved(['hosts', 'roles', 'vars', 'name'])
    assert warn_if_reserved(['hosts', 'roles', 'vars', 'ignore_errors'])



# Generated at 2022-06-23 15:21:11.142346
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:21:18.621388
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_vars = ['vars', 'gather_facts', 'hosts', 'remote_user']
    warn_if_reserved(test_vars)
    assert is_reserved_name('vars')
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('myvar')
    assert not is_reserved_name('hosts')
    assert not is_reserved_name('remote_user')

# Generated at 2022-06-23 15:21:26.005731
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved_names = get_reserved_names()

    # reserved names should not raise a warning
    warn_if_reserved(reserved_names)

    # file is not a reserved name, but the function should not error when
    # reserved is set to an empty set
    warn_if_reserved(['file'], set())

    # A non-reserved name should raise a warning
    from nose.plugins.skip import SkipTest
    # FIXME: remove this test after with_ is not only deprecated but removed
    if 'with_' not in reserved_names:
        raise SkipTest("This test is currently not valid due to with_ being deprecated")

    display.verbosity = 0
    from ansible.plugins.callback.default import CallbackModule
    display.verbosity = 0
    callback = CallbackModule()
    display.verbosity = 0

# Generated at 2022-06-23 15:21:29.621739
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('not_reserved')
    assert is_reserved_name('hosts')
    assert is_reserved_name('private_hosts')

# Generated at 2022-06-23 15:21:31.860506
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('not_a_reserved_name')

# Generated at 2022-06-23 15:21:41.724481
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert_equal = lambda a, b: a == b
    assert_not_equal = lambda a, b: a != b

    # Checking that there is not a duplicate in reserved names:
    reserved_name_list = get_reserved_names()
    reserved_name_list_length = len(reserved_name_list)
    reserved_name_set = set(reserved_name_list)
    reserved_name_set_length = len(reserved_name_set)
    assert_equal(
        reserved_name_list_length,
        reserved_name_set_length,
        'There is a duplicate in reserved names'
    )

    # Checking that get_reserved_names() return is the same with
    # and without including private attributes:
    reserved_public = get_reserved_names(include_private=False)


# Generated at 2022-06-23 15:21:49.671108
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        from ansible.tests.test_utils.display import Display
        dummy_display = Display()
    except ImportError:
        raise AssertionError("Unable to import Display class for test_warn_if_reserved")

    myvars = dict()
    myvars["hosts"] = "all"
    myvars["name"] = "Some role"
    myvars["with_dict"] = dict()
    myvars["with_list"] = list()
    myvars["vars"] = dict()

    # Mock display.warning to capture the call
    display._display = dummy_display
    dummy_display.warning = lambda msg: myvars.update({'warning': msg})
    warn_if_reserved(myvars)
    del dummy_display.warning

    assert 'warning' in my

# Generated at 2022-06-23 15:21:59.494989
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # check for expected values
    exp_pub = set(['action', 'gather_facts', 'hosts', 'name', 'serial', 'tasks', 'local_action', 'with_'])
    exp_priv = set(['_role', '_block', '_play', '_only_tags', '_skip_tags', '_vars_files', '_hosts', '_handlers',
                    '_block_parent', '_task_include', '_loop', '_parent'])
    exp_all = exp_pub.union(exp_priv)

    pub = get_reserved_names(False)
    priv = get_reserved_names(True)
    all = get_reserved_names(False)

    assert pub == exp_pub
    assert priv == exp_all
    assert all == exp_all


# Generated at 2022-06-23 15:22:08.285061
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') is True
    assert is_reserved_name('role') is True
    assert is_reserved_name('include_role') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('when') is True
    assert is_reserved_name('handler') is True
    assert is_reserved_name('tags') is True
    assert is_reserved_name('register') is True
    assert is_reserved_name('vars') is True
    assert is_reserved_name('vars_prompt') is True
    assert is_reserved_name('vars_files') is True
    assert is_reserved_name('pre_tasks') is True
    assert is_

# Generated at 2022-06-23 15:22:13.746843
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('vars')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('tasks')
    assert not is_reserved_name('new_keyword')

# Generated at 2022-06-23 15:22:16.391250
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('connection')
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('play')

# Generated at 2022-06-23 15:22:23.661730
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.tests.unit.mock.loader import DictDataLoader

    # these names are reserved for play internals
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name) is True

    # any other name is not reserved
    loader = DictDataLoader({'my_playbook.yml': '#'})
    for name in ['', 'var1', 'var2', 'var_3', 'var-4', 'some_verbose_variable_name']:
        assert is_reserved_name(name) is False

# Generated at 2022-06-23 15:22:29.568009
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=True)
    assert isinstance(reserved, set)
    assert len(reserved) > 35
    assert 'max_fail_percentage' in reserved

    reserved = get_reserved_names(include_private=False)
    # make sure we're not including 'private' attributes, still want +35
    assert len(reserved) == 35
    assert 'max_fail_percentage' in reserved

# Generated at 2022-06-23 15:22:30.879475
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('invalid_name')

# Generated at 2022-06-23 15:22:36.971508
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('include')
    assert is_reserved_name('include_role')
    assert is_reserved_name('import_playbook')
    assert is_reserved_name('tasks')
    assert is_reserved_name('vars')


# Generated at 2022-06-23 15:22:39.526305
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False).intersection(get_reserved_names(include_private=True)) == get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:22:42.416710
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert is_reserved_name('pre_tasks')
    assert not is_reserved_name('foo')


# Generated at 2022-06-23 15:22:46.394306
# Unit test for function get_reserved_names
def test_get_reserved_names():
    real_result = get_reserved_names()

    # Ensure these are always in the reserved names
    assert 'roles' in real_result
    assert 'hosts' in real_result
    assert 'block' in real_result

    # Ensure these are no longer in the reserved names
    assert 'with_' not in real_result
    assert 'local_action' not in real_result

# Generated at 2022-06-23 15:22:56.508381
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This test checks if the reserved names returned by get_reserved_names()
    # are correct.
    # Note that if a new attribute is added to a task or a play, will
    # will need to update this test. The same goes for new tasks or
    # plays.
    play = Play()
    task = Task()
    role = Role()
    block = Block()

    # The list of expected public reserved names.

# Generated at 2022-06-23 15:23:02.988736
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the functionality of get_reserved_names '''
    assert get_reserved_names(True) == _RESERVED_NAMES
    assert get_reserved_names(False) == frozenset(get_reserved_names() - frozenset(['with_', 'tags']))
    assert get_reserved_names(True) == get_reserved_names()
    assert get_reserved_names(False) == get_reserved_names(True) - frozenset(['with_', 'tags', 'loop'])
    assert get_reserved_names(True) == get_reserved_names(True) - frozenset(['with_', 'tags', 'loop'])

# Generated at 2022-06-23 15:23:05.298248
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)



# Generated at 2022-06-23 15:23:13.673365
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Make sure we do not add more reserved names to the list
    assert len(get_reserved_names()) == len(_RESERVED_NAMES), "Found an updated reserved name list. Please update the is_reserved_name unit test."

    # Make sure we found all reserved names
    all_attributes = set()
    class_list = [Play, Role, Block, Task]
    for aclass in class_list:
        all_attributes = all_attributes.union(set(aclass().__dict__['_attributes']))
    for attr in all_attributes:
        if not attr.startswith('_'):
            if attr not in ['local_action', 'with_'] and attr not in _RESERVED_NAMES:
                assert False, "Found a new reserved name: " + att

# Generated at 2022-06-23 15:23:15.293470
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'loop', 'local_action', 'with_', 'private', 'vars'])

# Generated at 2022-06-23 15:23:21.744914
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_text
    from ansible.parsing.utils.addresses import parse_address
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task

    fake_display = Display()
    from ansible.utils import color as ansible_color
    # Don't colorize display output for testing
    ansible_color.DISPLAY = fake_display
    ansible_color.C = ansible_color.ANSI_COLOR_CODES['none']

    real_warn = fake_display.warning


# Generated at 2022-06-23 15:23:32.764572
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=False)

    assert 'var_files' in reserved_names
    assert 'var_file' in reserved_names
    assert 'vars_files' in reserved_names
    assert 'vars_file' in reserved_names

    assert 'roles' in reserved_names
    assert 'role_path' in reserved_names

    assert 'connection' in reserved_names
    assert 'sudo' in reserved_names
    assert 'sudo_user' in reserved_names
    assert 'remote_user' in reserved_names
    assert 'become' in reserved_names
    assert 'become_user' in reserved_names
    assert 'environment' in reserved_names
    assert 'any_errors_fatal' in reserved_names
    assert 'serial' in reserved_names

# Generated at 2022-06-23 15:23:35.162726
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['name', 'hosts', 'roles']
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:23:43.146306
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function tests the get_reserved_names function
    '''

    # Test to make sure there are no duplicates in the reserved_names list
    reserved_names = get_reserved_names(True)
    len_reserved = len(reserved_names)
    len_no_dupes = len(set(reserved_names))
    assert len_reserved == len_no_dupes, "At least one duplicate name in reserved_names list"

    # Test to make sure that the length of the reserved_names list doesn't grow
    # without us testing it. Since this list is not in any way ordered, we should
    # count the first time then see if it matches subsequent lists

# Generated at 2022-06-23 15:23:52.891807
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test get_reserved_names()
    names = get_reserved_names()
    assert 'roles' in names
    assert 'tasks' in names
    assert 'action' in names
    assert 'local_action' in names
    assert 'with_' in names
    assert 'loop' in names
    assert 'when' in names
    assert 'block' in names
    assert 'rescue' in names
    assert 'always' in names
    assert 'delegate_to' in names
    assert 'delegate_facts' in names
    assert 'run_once' in names
    assert 'name' in names
    assert 'args' in names
    assert 'become' in names
    assert 'become_method' in names
    assert 'become_user' in names
    assert 'connection' in names

# Generated at 2022-06-23 15:23:58.877269
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Public set of names should exist
    assert len(get_reserved_names(False))

    # Private set of names should exist
    assert len(get_reserved_names(True))

    # Public set should be smaller than private set
    assert len(get_reserved_names(False)) < len(get_reserved_names(True))

    # Public set should be a subset of the private set
    assert get_reserved_names(False).issubset(get_reserved_names(True))


# Generated at 2022-06-23 15:24:09.374439
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''This function tests correctness of the ``get_reserved_names()`` function'''

# Generated at 2022-06-23 15:24:12.454338
# Unit test for function is_reserved_name
def test_is_reserved_name():

    not_reserved = 'foo'
    assert not is_reserved_name(not_reserved)

    reserved = 'loop'
    assert is_reserved_name(reserved)



# Generated at 2022-06-23 15:24:18.763518
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = {'roles': 'roles', 'action': 'action', 'with_': 'with_'}
    warn_if_reserved(vars)
    assert vars['roles'] == 'roles'
    assert vars['action'] == 'action'
    assert vars['with_'] == 'with_'
    assert len(vars) == 3

# Generated at 2022-06-23 15:24:26.190594
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # set with expected items in the set (can be added to)
    RESERVED_NAMES = frozenset(['block', 'block_keywords', 'block_start',
                                'block_end', 'delegate_to', 'delegate_facts', 'environment',
                                'failed_when', 'gather_facts', 'include', 'include_role',
                                'name', 'notify', 'register', 'roles', 'run_once', 'tags',
                                'tasks', 'when', 'meta', 'no_log', 'ignore_errors',
                                'always_run', 'local_action', 'with_'])

    reserved_names = get_reserved_names()
    assert(reserved_names == RESERVED_NAMES)

# Generated at 2022-06-23 15:24:38.141985
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:24:42.036446
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    display_data = []
    display.display = lambda msg, *args, **kwargs: display_data.append(msg % args)
    warn_if_reserved(['task', 'asd', 'attributes'])
    assert display_data == ['Found variable using reserved name: task', 'Found variable using reserved name: attributes']

# Generated at 2022-06-23 15:24:50.163437
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this unit test checks the reserved names for internal play objects '''

    reserved = frozenset(get_reserved_names())
    print_names = sorted(reserved)

    print("Currently reserved words (in order):\n")
    for word in print_names:
        print("%s" % word)

    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'vars' in reserved
    assert 'variables' in reserved
    assert 'name' in reserved
    assert 'any_errors_fatal' in reserved
    assert 'connection' in reserved
    assert 'gather_facts' in reserved
    assert 'tags' in reserved

# Generated at 2022-06-23 15:24:56.668825
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest
    myvars = ['vars', 'tasks', 'handlers', 'tasks', 'pre_tasks', 'post_tasks', 'any_errors_fatal', 'become', 'become_user', 'become_method', 'connection', 'environment', 'gather_facts', 'gather_subset', 'import_playbook', 'max_fail_percentage', 'name', 'no_log', 'notify', 'pre_tasks', 'post_tasks', 'roles', 'serial', 'tags', 'when']
    warn_if_reserved(myvars)
    warn_if_reserved(myvars, ['notify'])
    with pytest.raises(AssertionError):
        warn_if_reserved(myvars, ['notify', 'notify'])

# Generated at 2022-06-23 15:24:58.326916
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('my_role_name')
    assert is_reserved_name('action')

# Generated at 2022-06-23 15:25:09.540632
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' This is a unit test for the function warn_if_reserved '''

    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role

    class_list = [Play(), Block(), Task(), Role()]
    additional = ['vars', 'name', 'hosts', 'roles', 'pre_tasks', 'post_tasks']
    reserved = frozenset(get_reserved_names(False))

    def test_case(name, result):
        test_role = Role()
        test_role._load_name(name)
        varnames = frozenset(test_role.__dict__['vars'].keys())
        varnames.discard('vars')  # we

# Generated at 2022-06-23 15:25:18.032465
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['name', 'remote_user', 'name']) is None
    assert warn_if_reserved(['name', 'foo', 'name']) is None
    assert warn_if_reserved(['name', 'remote_user']) is None
    assert warn_if_reserved(['name', 'foo']) is None
    from ansible.utils.display import Display
    from ansible.utils.warns import deprecations
    from ansible import context
    d = Display()
    try:
        d.warning('foo')
        assert False
    except DeprecationWarning as e:
        pass
    assert len(context.CLIARGS['deprecation_warnings']) == 0
    assert len(deprecations.DEPRECATION_WARNINGS) == 1
    assert warn_if_

# Generated at 2022-06-23 15:25:20.152260
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'register', 'hosts'})

# Generated at 2022-06-23 15:25:21.126622
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name("roles"))

# Generated at 2022-06-23 15:25:31.949728
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:33.877885
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names(include_private=False)
    assert isinstance(names, set)
    assert len(names) >= 12

    names = get_reserved_names(include_private=True)
    assert isinstance(names, set)
    assert len(names) >= 26


# Generated at 2022-06-23 15:25:39.060519
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # run the function for a list of reserved names
    for name in get_reserved_names():
        assert is_reserved_name(name)

    # run the function for a list of random names
    randomnames = ['ansible', 'ansible- play', 'cisco', 'arista', 'juniper']
    for name in randomnames:
        assert not is_reserved_name(name)

# Generated at 2022-06-23 15:25:45.735703
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # pylint: disable=unused-variable

    play_source = dict(
        name="Dummy Play",
        hosts="all",
        gather_facts="no",
        tasks=[
            dict(
                action=dict(
                    module="shell",
                    args="echo dummy"
                ),
                loop="{{ somevar }}"
            )
        ]
    )

    # Should not throw exception

    try:
        play = Play().load(play_source, variable_manager=None, loader=None)
        play._is_play = True  # required by warn_if_reserved
        play.post_validate(play._ds, play._play_context)
        del play
    except Exception as err:
        raise AssertionError('warn_if_reserved() raised exception: %s' % err)

# Generated at 2022-06-23 15:25:52.470692
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert names
    assert 'roles' in names
    assert 'role_path' in names
    assert 'collect_facts' in names

    names = get_reserved_names(include_private=False)
    assert names
    assert 'roles' in names
    assert 'role_path' in names
    assert 'collect_facts' in names
    assert 'gather_facts' not in names
    assert 'become' not in names
    assert 'become_user' not in names
    assert 'become_method' not in names



# Generated at 2022-06-23 15:25:54.050076
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert reserved



# Generated at 2022-06-23 15:26:04.066480
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = _RESERVED_NAMES

    assert 'any_errors_fatal' in reserved
    assert 'ignore_errors' in reserved
    assert 'local_action' in reserved
    assert 'role_name' in reserved
    assert 'become' in reserved
    assert 'become_method' in reserved
    assert 'notify' in reserved
    assert 'register' in reserved
    assert 'loop' in reserved
    assert 'tags' in reserved
    assert 'when' in reserved
    assert 'with_' in reserved
    assert 'hosts' in reserved
    assert 'name' in reserved
    assert 'connection' in reserved
    assert 'vars' in reserved
    assert 'delegate_facts' in reserved

# Generated at 2022-06-23 15:26:10.331684
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    Exercises the warn_if_reserved function and checks for expected output.
    '''
    import sys
    import StringIO

    # Capture output of deprecations
    output = StringIO.StringIO()

    sys.stdout = output

    # Check for warning that matches a reserved name
    warn_if_reserved(['task'])
    assert('Found variable using reserved name: task' in output.getvalue())

# Generated at 2022-06-23 15:26:13.826780
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['roles', 'become', 'when', 'always_run'])
    warn_if_reserved(['vars', 'become', 'when', 'always_run'])

# Generated at 2022-06-23 15:26:24.499904
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset([
        'become',
        'become_method',
        'become_user',
        'block',
        'connection',
        'delegate_to',
        'environment',
        'handler',
        'hosts',
        'include',
        'include_role',
        'include_tasks',
        'meta',
        'no_log',
        'notify',
        'pre_tasks',
        'post_tasks',
        'register',
        'roles',
        'serial',
        'tags',
        'tasks',
        'vars',
        'vars_files',
        'action',
        'local_action',
        'with_'
    ])

# Generated at 2022-06-23 15:26:31.253812
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' returns True if the function is_reserved_name works correctly '''

    for name in ['hosts', 'gather_facts', 'roles', 'vars', 'any_errors_fatal', 'force_handlers', 'delegate_to']:
        assert is_reserved_name(name)

    for name in ['hostss', 'gather_factss', 'roless', 'varss', 'any_errors_fataaaal', 'force_handlerss', 'delegate_tooo']:
        assert not is_reserved_name(name)

    return True

# Generated at 2022-06-23 15:26:32.140745
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")
    assert not is_reserved_name("hoss")

# Generated at 2022-06-23 15:26:34.881598
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    expected = dict(
        msg="Found variable using reserved name: hosts",
        vars=dict(
            hosts='localhost',
        ),
    )

    warn_if_reserved(expected.get('vars'))

# Generated at 2022-06-23 15:26:36.324524
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('pre_tasks') == True
    assert is_reserved_name('foo') == False

# Generated at 2022-06-23 15:26:37.675904
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("name")
    assert not is_reserved_name("not_reserved")

# Generated at 2022-06-23 15:26:39.976423
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts") is True
    assert is_reserved_name("hosts_other") is False

# Generated at 2022-06-23 15:26:40.942619
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars'])

# Generated at 2022-06-23 15:26:44.068209
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'action'])
    warn_if_reserved(['vars', 'action', 'playbook', 'play', 'task', 'name', 'local_action', 'with_', '_private'])

# Generated at 2022-06-23 15:26:50.808332
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names()
    assert warn_if_reserved({'roles': 'foo', 'tasks': 'bar'}) is None
    assert warn_if_reserved({'roles': 'foo', 'tasks': 'bar'}, {'roles'}) is None
    assert warn_if_reserved({'roles': 'foo', 'tasks': 'bar'}, set()) is None
    assert warn_if_reserved({'roles': 'foo', 'tasks': 'bar', 'tags': None}, additional={'tags'}) is None

if __name__ == "__main__":
    test_warn_if_reserved()

# Generated at 2022-06-23 15:26:54.853074
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('host')
    assert is_reserved_name('name')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('action')
    assert not is_reserved_name('local_action')
    assert not is_reserved_name('with_')
    assert not is_reserved_name('when')

# Generated at 2022-06-23 15:27:04.675483
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test variables using reserved names
    vars1 = dict(
        name='foo',
        changed=True,
        with_=['foo', 'bar']
    )
    vars2 = dict(
        name='foo',
        changed=True,
        loop='foo',
        vars={'var1': 'foo'}
    )

    # Simple tests for no warnings
    vars3 = dict(
        name='foo',
        changed=True
    )
    vars4 = dict(
        name='foo',
        changed=True,
        vars={'var1': 'foo'}
    )
    vars5 = dict(
        name='foo',
        changed=True,
        with_=['foo', 'bar']
    )

    # Test for no warnings when 'with_' is not part of

# Generated at 2022-06-23 15:27:08.279399
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names1 = get_reserved_names()
    assert isinstance(names1, set)
    assert 'roles' in names1
    names2 = get_reserved_names(include_private=False)
    assert isinstance(names2, set)
    assert 'roles' in names2
    assert 'serial' in names2
    assert 'serial' not in names1

# Generated at 2022-06-23 15:27:10.796286
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    ansible_varname = AnsibleUnicode('hosts')
    assert is_reserved_name(ansible_varname)
    assert not is_reserved_name('host')

# Generated at 2022-06-23 15:27:21.347697
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = set()
    result.add('action')
    result.add('any_errors_fatal')
    result.add('become')
    result.add('become_user')
    result.add('block')
    result.add('connection')
    result.add('delegate_to')
    result.add('environment')
    result.add('ignore_errors')
    result.add('include')
    result.add('local_action')
    result.add('loops')
    result.add('name')
    result.add('no_log')
    result.add('notify')
    result.add('register')
    result.add('role')
    result.add('roles')
    result.add('serial')
    result.add('tags')
    result.add('tasks')

# Generated at 2022-06-23 15:27:24.721551
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # To test this function, we will add a constant in Play class:
    RESERVED = 'reserved'
    Play._reserved = RESERVED

    # The new value must be present in get_reserved_names
    assert RESERVED in get_reserved_names()

    # The new value must be present in _RESERVED_NAMES
    assert RESERVED in _RESERVED_NAMES

# Generated at 2022-06-23 15:27:36.374385
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)
    assert 'hosts' in reserved_names
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'vars' in reserved_names
    assert 'vars' in get_reserved_names(include_private=False)
    assert 'tasks' in reserved_names
    assert 'tasks' in get_reserved_names(include_private=False)
    assert 'when' in reserved_names
    assert 'when' in get_reserved_names(include_private=False)
    assert 'name' in reserved_names
    assert 'name' in get_reserved_names(include_private=False)



# Generated at 2022-06-23 15:27:47.391212
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        import __builtin__ as builtins  # python2
    except ImportError:
        import builtins

    mystr = 'mystr'
    mylist = ['mystr']
    mydict = {'mystr': 'ok'}
    myobj = 'ok'

    with display.override_verbosity(0):
        warn_if_reserved(mydict)
        warn_if_reserved(mylist)
        warn_if_reserved(mystr)
        warn_if_reserved(myobj)
        assert not display.verbosity

    with display.override_verbosity(1):
        warn_if_reserved(mydict)
        warn_if_reserved(mylist)
        warn_if_reserved(mystr)
        assert display.verbosity

# Generated at 2022-06-23 15:27:49.862323
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('name') == True)
    assert(is_reserved_name('foobar') == False)
    assert(is_reserved_name('roles') == True)
    assert(is_reserved_name('local_action') == True)

# Generated at 2022-06-23 15:28:01.631717
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = frozenset(['any_errors_fatal', 'become', 'become_user', 'block', 'block_id', 'collections', 'delegate_to',
                        'delegate_facts', 'environment', 'first_available_file', 'flush_handlers', 'ignore_errors',
                        'include', 'include_role', 'include_tasks', 'local_action', 'name', 'no_log', 'notify',
                        'post_tasks', 'pre_tasks', 'precedence', 'pre_tasks', 'register', 'roles', 'serial',
                        'serial_failure_threshold', 'serial_task_start_index', 'tags', 'tasks', 'transport',
                        'vars_files', 'when'])

# Generated at 2022-06-23 15:28:04.599489
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("delegate_to")
    assert is_reserved_name("environment")
    assert not is_reserved_name("not_reserved_name")



# Generated at 2022-06-23 15:28:13.511071
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:28:17.890978
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert 'foo' not in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'private' not in _RESERVED_NAMES
    assert 'private' in get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:28:20.947853
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)
    assert isinstance(get_reserved_names(include_private=False), frozenset)



# Generated at 2022-06-23 15:28:28.220185
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert_msg = "has incorrect value"

    assert 'hosts' in get_reserved_names(), assert_msg
    assert 'roles' in get_reserved_names(), assert_msg
    assert 'include_vars' in get_reserved_names(), assert_msg
    assert 'include_tasks' in get_reserved_names(), assert_msg
    assert 'dependencies' in get_reserved_names(), assert_msg
    assert 'pre_tasks' in get_reserved_names(), assert_msg
    assert 'post_tasks' in get_reserved_names(), assert_msg

# Generated at 2022-06-23 15:28:36.363277
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'vars': 'role vars'}) is None
    assert warn_if_reserved({'task': 'a task'}) is not None
    assert warn_if_reserved({'role': 'a role'}) is not None
    assert warn_if_reserved({'include_vars': 'included vars'}) is not None
    assert warn_if_reserved({'include_role': 'included role'}) is not None
    assert warn_if_reserved({'include_tasks': 'included tasks'}) is not None
    assert warn_if_reserved({'include': 'included play'}) is not None
    assert warn_if_reserved({'hostvars': 'host vars'}) is not None

# Generated at 2022-06-23 15:28:45.278904
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('vars')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('become')
    assert not is_reserved_name('my_hosts')
    assert not is_reserved_name('my_roles')
    assert not is_reserved_name('my_action')
    assert not is_reserved_name('my_become')

# Generated at 2022-06-23 15:28:50.594889
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'listen' in reserved_names
    assert 'become_user' in reserved_names
    assert 'connection' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'vars_files' in reserved_names
    assert 'vars_prompt' in reserved_names

    assert 'name' in reserved_names

# Generated at 2022-06-23 15:28:59.781818
# Unit test for function get_reserved_names
def test_get_reserved_names():

    test_input_exclude_private = False
    test_input_include_private = True
    test_output_exclude_private = {u'connection', u'gather_facts', u'hosts', u'ignore_errors', u'pre_tasks', u'post_tasks', u'roles', u'serial', u'start_at_task', u'stasks', u'steps', u'tasks'}
    test_output_include_private = {u'connection', u'delegate_to', u'gather_facts', u'hosts', u'ignore_errors', u'pre_tasks', u'post_tasks', u'roles', u'serial', u'start_at_task', u'stasks', u'steps', u'tasks', u'when', u'with_'}

# Generated at 2022-06-23 15:29:00.809693
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')

# Generated at 2022-06-23 15:29:11.304990
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('tasks') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('vars') is True
    assert is_reserved_name('variables') is True
    assert is_reserved_name('variable') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('with_') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('meta') is True
    assert is_reserved_name('action') is True
    assert is_reserved_name('loops') is True
    assert is_reserved_name

# Generated at 2022-06-23 15:29:12.894967
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = {'hosts': 'foo'}
    warn_if_reserved(vars)


# Generated at 2022-06-23 15:29:22.453225
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'hosts' in names
    assert 'vars' in names
    assert 'name' in names
    assert 'action' in names
    assert 'local_action' in names
    assert 'with_items' in names
    assert 'with_dict' in names
    assert 'with_fileglob' in names
    assert 'with_file' in names
    assert 'with_first_found' in names
    assert 'with_inventory_hostnames' in names
    assert 'with_sequence' in names
    assert 'with_lines' in names
    assert 'with_subelements' in names
    assert 'with_together' in names
    assert 'with_indexed_items' in names
    assert 'with_items' in names
    assert 'with_flattened' in names


# Generated at 2022-06-23 15:29:33.518201
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(False)
    private_names = get_reserved_names()

    assert 'name' in public_names
    assert 'roles' in public_names

    assert 'handler' in public_names
    assert 'notify' in public_names
    assert 'when' in public_names

    assert 'block' in public_names
    assert 'rescue' in public_names
    assert 'always' in public_names

    assert 'name' in private_names
    assert 'connection' in private_names
    assert 'gather_facts' in private_names
    assert 'vars_files' in private_names
    assert 'vars_prompt' in private_names
    assert 'vars' in private_names
    assert 'tasks_from' in private_names


# Generated at 2022-06-23 15:29:44.030758
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') == True
    assert is_reserved_name('role') == True
    assert is_reserved_name('register') == True
    assert is_reserved_name('vars') == True
    assert is_reserved_name('vars_files') == True
    assert is_reserved_name('vars_prompt') == True
    assert is_reserved_name('action') == True
    assert is_reserved_name('local_action') == True
    assert is_reserved_name('with_') == True
    assert is_reserved_name('name') == True
    assert is_reserved_name('cross_platform_target') == False
    assert is_reserved_name('nogood') == False

