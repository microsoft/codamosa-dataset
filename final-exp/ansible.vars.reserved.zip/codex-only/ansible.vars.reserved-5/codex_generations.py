

# Generated at 2022-06-23 15:19:52.211447
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    import warnings

    class TestWarning(object):
        def __init__(self, name):
            self.name = name

        def __str__(self):
            return self.name

    class TestStream(object):
        def __init__(self):
            self.output = ''

        def write(self, msg):
            self.output += msg

    class TestDisplay(object):
        def __init__(self):
            self._display = {}
            self._verbosity = 3

    display = TestDisplay()

    test_reserved_names = ['foo', 'vars']
    test_unreserved_names = ['bar', 'with_', 'connection']
    test_all_names = test_reserved_names + test_unreserved_names

    test_stderr = TestStream()
    sys

# Generated at 2022-06-23 15:20:01.167535
# Unit test for function is_reserved_name
def test_is_reserved_name():
    is_reserved_name("hosts")
    is_reserved_name("roles")
    is_reserved_name("block")
    is_reserved_name("action")
    is_reserved_name("when")
    is_reserved_name("vars")
    is_reserved_name("loop")
    is_reserved_name("any_errors_fatal")
    is_reserved_name("become")
    is_reserved_name("gather_facts")
    is_reserved_name("no_log")
    is_reserved_name("delegate_to")

    assert not is_reserved_name("host")
    assert not is_reserved_name("role")
    assert not is_reserved_name("block")

# Generated at 2022-06-23 15:20:09.397291
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test with public names
    public_names = ['gather_facts', 'hosts', 'name', 'tasks', 'vars',
                    'vars_prompt', 'vars_files', 'connection',
                    'remote_user', 'sudo', 'sudo_user',
                    'environment', 'no_log', 'tags', 'roles',
                    'any_errors_fatal', 'serial', 'max_fail_percentage',
                    'when', 'notify', 'handlers', 'register', 'ignore_errors',
                    'meta', 'block', 'become', 'become_user', 'become_method']
    # Test with private names
    private_names = ['action']
    # Test for names that are aliases for others
    alias_names = ['with_', 'local_action']

# Generated at 2022-06-23 15:20:19.038707
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' unit test for function get_reserved_names '''

    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import post_validate

    # this is a valid hostvars dictionary

# Generated at 2022-06-23 15:20:26.392847
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Testcase: empty list
    warn_if_reserved([])

    # Testcase: blacklisted name
    warn_if_reserved(['vars'])
    warn_if_reserved(['action'])
    warn_if_reserved(['hosts'])

    # Testcase: non-blacklisted name
    warn_if_reserved(['testcase'])


# Generated at 2022-06-23 15:20:31.188926
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved_names1 = get_reserved_names(include_private=False)
    reserved_names2 = get_reserved_names(include_private=True)

    assert(len(reserved_names1) > 0)
    assert(len(reserved_names2) > 0)
    assert(len(reserved_names1) < len(reserved_names2))

# Generated at 2022-06-23 15:20:35.762591
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)
    assert get_reserved_names().__contains__('tags')
    assert get_reserved_names().__contains__('gather_facts')
    assert get_reserved_names().__contains__('action')
    assert get_reserved_names().__contains__('block')

test_get_reserved_names()

# Generated at 2022-06-23 15:20:37.723523
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved_names = get_reserved_names(include_private=False)
    warn_if_reserved(reserved_names)



# Generated at 2022-06-23 15:20:49.524444
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.playbook.play import Play

    reserved = get_reserved_names(include_private=False)
    all_reserved = get_reserved_names(include_private=True)

    # public attributes of a play
    play = Play()
    for attribute in play.__dict__['_attributes']:
        if 'private' not in attribute:
            assert attribute in reserved
            assert attribute in all_reserved

    # private attributes of a play
    for attribute in play.__dict__['_attributes']:
        if 'private' in attribute:
            assert attribute not in reserved
            assert attribute in all_reserved

    # local_action is implicit with action
    if 'action' in reserved:
        assert 'local_action' in reserved

    # loop implies with_
    # FIXME: remove after with_ is

# Generated at 2022-06-23 15:20:51.116829
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'delegate_to': 'localhost'})

# Generated at 2022-06-23 15:20:57.931693
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('private')
    assert is_reserved_name('action')
    assert is_reserved_name('foo')
    assert not is_reserved_name('vars')
    assert not is_reserved_name('TEST')
    assert not is_reserved_name('TEST')
    assert not is_reserved_name('TESTS')
    assert not is_reserved_name('environment')
    assert not is_reserved_name('role_path')
    assert not is_reserved_name('role_paths')



# Generated at 2022-06-23 15:21:06.130154
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    assert warn_if_reserved({'hosts': 'foo'}) is None
    assert warn_if_reserved({'roles': 'foo'}) is None
    assert warn_if_reserved({'name': 'foo', 'action': 'foo'}) is not None
    assert warn_if_reserved({'name': 'foo', 'local_action': 'foo'}) is not None
    assert warn_if_reserved({'name': 'foo', 'with_': 'foo'}) is not None

# Generated at 2022-06-23 15:21:07.626824
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('some_name')

# Generated at 2022-06-23 15:21:10.640971
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'action': 'debug'}) == None, 'warn_if_reserved did not exit cleanly'
    assert warn_if_reserved({'invalid_var_name': 'debug'}) == None, 'warn_if_reserved did not exit cleanly'

# Generated at 2022-06-23 15:21:15.328482
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext

    warn_if_reserved(['vars'], additional=set(['task', 'role']))

    assert hasattr(PlayContext, '_play')
    assert hasattr(PlayContext, '_role')
    assert hasattr(PlayContext, '_task')

# Generated at 2022-06-23 15:21:17.068614
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('private') is False
    assert is_reserved_name('include')


# Generated at 2022-06-23 15:21:22.769308
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # Just for side effects...
    warn_if_reserved(['name', 'hosts'])
    warn_if_reserved(['name', 'hosts', 'action'], set(['action']))
    warn_if_reserved(['name', 'hosts', 'action'], set(['name']))
    warn_if_reserved(['name', 'hosts', 'action'], set(['hosts']))

# Generated at 2022-06-23 15:21:24.369094
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in get_reserved_names():
        assert is_reserved_name(name)
    assert not is_reserved_name('test_test')

# Generated at 2022-06-23 15:21:30.349986
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.tests import fake_loader, fake_play_context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import warn_if_reserved
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    hostvars = HostVars(loader=loader, play_context=PlayContext())
    variable_manager = VariableManager(loader=loader, host_vars=hostvars, play_context=PlayContext())

    reserved_names = get_reserved_names()


# Generated at 2022-06-23 15:21:30.991662
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    pass

# Generated at 2022-06-23 15:21:34.709287
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('action')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:21:39.939490
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('register')
    assert is_reserved_name('block')
    assert is_reserved_name('include')
    assert not is_reserved_name('foobar')


# Generated at 2022-06-23 15:21:48.304824
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # We test both private and public reserved names to make sure they're always returned in get_reserved_names()
    public_reserved_names = ['roles', 'pre_tasks', 'post_tasks', 'vars', 'any_errors_fatal', 'delegate_to', 'delegated_vars', 'gather_facts', 'hosts',
                             'name', 'notify', 'roles', 'tags', 'tasks', 'vars', 'action', 'local_action', 'with_', 'include', 'include_tasks', 'meta']
    private_reserved_names = ['block', 'block_end', 'block_start', 'deps', 'handler', 'loop', 'loop_control', 'task']
    reserved_names = frozenset(get_reserved_names(include_private=True))



# Generated at 2022-06-23 15:21:58.255010
# Unit test for function warn_if_reserved

# Generated at 2022-06-23 15:22:00.634487
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.utils.name_functions import is_legal_name
    sorted_names = sorted(get_reserved_names(include_private=False))
    for name in sorted_names:
        assert is_reserved_name(name)
        assert not is_legal_name(name)



# Generated at 2022-06-23 15:22:08.581428
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['hosts', 'roles']) == None
    assert warn_if_reserved(['hosts', 'roles', 'when', 'post_tasks']) == None
    assert warn_if_reserved(['hosts', 'roles', 'when', 'post_tasks'],
                            additional=['tasks', 'action']) == None
    assert warn_if_reserved(['hosts', 'roles', 'tasks']) == None
    assert warn_if_reserved(['hosts', 'roles', 'tasks'], additional=['action']) == None
    assert warn_if_reserved(['hosts', 'roles', 'tasks', 'action']) == None


# Generated at 2022-06-23 15:22:11.918659
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    fake_vars = dict(name='foo', host='localhost', connection='local', gather_facts=True)
    assert warn_if_reserved(fake_vars) is None

# Generated at 2022-06-23 15:22:20.640761
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

    assert 'hosts' in public
    assert 'hosts' in private
    assert 'roles' in public
    assert 'roles' in private

    assert 'hosts' in public

    # These attributes may be deprecated but they should be present
    # as they can appear in plays or roles. These tests should be
    # removed once these attributes are officially removed.

    assert 'with_' in public
    assert 'with_' in private

    assert 'with_first_found' in public
    assert 'with_first_found' in private

# Generated at 2022-06-23 15:22:26.404816
# Unit test for function get_reserved_names
def test_get_reserved_names():

    if sys.version_info < (2, 7):
        print("SKIP: Reserved names tests require Python 2.7 or later")
        pytest.skip("Reserved names tests require Python 2.7 or later")

    reserved_public = get_reseved_names(False)

    # testing with_
    assert 'loop' in reserved_public
    assert 'with_' in reserved_public

    # testing action
    assert 'action' in reserved_public
    assert 'local_action' in reserved_public

# Generated at 2022-06-23 15:22:28.456617
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({"name": "tricky_thingy"}, additional={"name": "tricky_thingy"}) == None


# Generated at 2022-06-23 15:22:37.400245
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:22:42.325575
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test reserved names
    for reserved_name in _RESERVED_NAMES:
        assert(is_reserved_name(reserved_name) is True)

    # Test non-reserved names
    assert(is_reserved_name('foobar') is False)
    assert(is_reserved_name('action') is False)
    assert(is_reserved_name('local_action') is False)

# Generated at 2022-06-23 15:22:45.698157
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('include_vars')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert not is_reserved_name('fake_name')
    assert not is_reserved_name('_private_name')

# Generated at 2022-06-23 15:22:49.004514
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    myvars = {}
    warn_if_reserved(myvars)

    myvars['roles'] = 1
    warn_if_reserved(myvars)



# Generated at 2022-06-23 15:22:58.733429
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=False)
    assert isinstance(result, set)
    assert result.issuperset(['name', 'hosts', 'gather_facts', 'roles', 'tasks',
                              'post_tasks', 'pre_tasks', 'vars_files', 'vars_prompt',
                              'vars', 'handlers', 'block'])

    # FIXME: find better way
    result = get_reserved_names()  # private as well
    assert isinstance(result, set)

# Generated at 2022-06-23 15:23:02.807224
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset([
        'action', 'name', 'register', 'local_action', 'with_', 'include', 'vars', 'vars_files', 'roles', 'tags', 'when', 'block'
    ])

# Generated at 2022-06-23 15:23:05.644285
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('any_keyword')
    assert is_reserved_name('when')
    assert not is_reserved_name('foo')


# Generated at 2022-06-23 15:23:10.924138
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # set up a set of names to verify against
    names = set(['name', 'action', 'local_action', 'loop', 'with_', 'vars', 'include'])

    # ensure that all warning conditions are found
    warn_if_reserved(names)

    # test with additional names that should also be warned about
    warn_if_reserved(names, additional=['pre_tasks', 'post_tasks'])

# Generated at 2022-06-23 15:23:13.455326
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['hosts', 'remote_user', 'sudo_user', 'vars']) is None



# Generated at 2022-06-23 15:23:17.284316
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected = frozenset(['become_user', 'block', 'connection', 'delegate_to', 'environment', 'ignore_errors', 'include', 'loop', 'loop_control', 'name', 'no_log', 'notify', 'register', 'roles', 'run_once', 'sudo', 'sudo_user', 'tags', 'task', 'tasks', 'when', 'with_'])
    assert get_reserved_names() == expected

# Generated at 2022-06-23 15:23:22.751256
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts') is True
    assert not is_reserved_name('not_in_set')
    assert is_reserved_name('not_in_set') is False

# Generated at 2022-06-23 15:23:33.896276
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()

    from ansible.plugins.task.copy import ActionModule as dummy_module
    # Dummy ActionModule to use instead of AnsibleModule for these tests
    class ActionModule(dummy_module):
        def __init__(self, task, connection, play_context, loader, templar, shared_loader_obj):
            super(ActionModule, self).__init__(task, connection, play_context, loader, templar, shared_loader_obj)
            display.display = MockDisplay(dict())
            self._supports_check_mode = True

    display.verbosity = 2
    myvars = dict()
    myvars['become'] = True  # use reserved varname

# Generated at 2022-06-23 15:23:44.460966
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:23:53.399189
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(include_private=False)
    private_names = get_reserved_names(include_private=True)

    assert "tags" in public_names
    assert "tags" in private_names  # tags can be in both public and private

    assert "action" in public_names
    assert "action" in private_names

    assert "local_action" not in public_names
    assert "local_action" in private_names

    assert "with_" not in public_names
    assert "with_" in private_names

    assert "loop_control" in public_names
    assert "loop_control" in private_names

    assert private_names.difference(public_names)
    assert len(public_names.union(private_names)) == len(private_names)

# Generated at 2022-06-23 15:24:02.863599
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    var1 = dict(myvar=3)
    var2 = dict(delegate_to=3)
    var3 = dict(vars=3)
    var4 = dict(additional=3)

    # Should not raise any warnings
    warn_if_reserved(var1)
    warn_if_reserved(var2, additional=['delegate_to'])
    warn_if_reserved(var3)
    warn_if_reserved(var4, additional=['additional'])

    # Should raise warnings for reserved words
    warn_if_reserved(var2, additional=['delegate_to'])
    warn_if_reserved(var2, additional=['additional'])
    warn_if_reserved(var2)

# Generated at 2022-06-23 15:24:12.186269
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # create test class which inherits Play() and adds an attribute
    class TestPlay(Play):
        _valid_attrs = Play._valid_attrs + ('new_attribute',)

    # valid variable names - none of these should raise
    reserved_names = get_reserved_names(include_private=False)
    for name in reserved_names:
        warn_if_reserved({name: 'test'})

    # note we add 'new_attribute' here deliberately to validate that warn_if_reserved picks it up...
    for name in get_reserved_names(include_private=True):
        warn_if_reserved({name: 'test'}, additional=set(['new_attribute']))

# Generated at 2022-06-23 15:24:13.116630
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:24:15.466725
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_only   = get_reserved_names(include_private=False)
    public_private = get_reserved_names()

    # ensure that public and private are not the same
    assert public_only != public_private

    # ensure that public_private is a superset of public_only
    assert public_private.issuperset(public_only)



# Generated at 2022-06-23 15:24:23.623055
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' a simple unit test for warn_if_reserved '''
    assert warn_if_reserved(['x', 'role', 'connection']) == None
    assert warn_if_reserved(['x', 'role', 'vars']) == None
    assert warn_if_reserved(['x', 'hosts', 'vars']) == None
    assert warn_if_reserved(['x', 'hosts', 'vars'], additional=['hosts']) != None
    assert warn_if_reserved(['x', 'hosts', 'foobar'], additional=['hosts']) == None

# Generated at 2022-06-23 15:24:25.131107
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Verify that 'strategy' is NOT reserved
    assert 'strategy' not in get_reserved_names(False)



# Generated at 2022-06-23 15:24:28.723452
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved({'action': 'foo', 'prefix': 'bar'})
    except (NameError, AttributeError):
        display.display('display.warning() not implemented')

# Generated at 2022-06-23 15:24:36.935788
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) == set
    assert len(get_reserved_names()) > 10
    assert 'become' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'name' in get_reserved_names()

# Generated at 2022-06-23 15:24:39.822654
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('test')

# Generated at 2022-06-23 15:24:48.664363
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed

# Generated at 2022-06-23 15:24:57.057439
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('notify')
    assert is_reserved_name('vars')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert not is_reserved_name('host')

# Generated at 2022-06-23 15:25:05.063586
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names(include_private=True)
    assert 'hosts' in names
    assert 'vars' in names
    assert 'roles' in names
    assert 'any_errors_fatal' in names
    assert 'action' in names
    assert 'gather_facts' in names
    assert 'tags' in names
    assert 'tasks' in names
    assert 'always_run' in names
    assert 'name' in names
    assert 'block' in names
    assert 'local_action' in names

    names = get_reserved_names(include_private=False)
    assert 'hosts' in names
    assert 'vars' in names
    assert 'roles' in names
    assert 'any_errors_fatal' in names
    assert 'action' in names

# Generated at 2022-06-23 15:25:10.277965
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # test namespace
    from ansible.utils.vars import is_reserved_name
    assert is_reserved_name('name')
    assert is_reserved_name('tags')
    assert is_reserved_name('loop')

    # test that a non-reserved name is not considered reserved
    assert not is_reserved_name('reservations')

# Generated at 2022-06-23 15:25:18.538067
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:25.369826
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts_all')
    assert is_reserved_name('hosts_all_all')
    assert is_reserved_name('hosts_all_children')
    assert is_reserved_name('hosts_all_plus')
    assert is_reserved_name('hosts_allexclude')
    assert is_reserved_name('hosts_dell')
    assert is_reserved_name('hostvars')
    assert not is_reserved_name('not_a_reserved_name')

# Generated at 2022-06-23 15:25:27.549392
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = frozenset(get_reserved_names())
    assert 'hosts' in reserved
    assert 'roles' in reserved



# Generated at 2022-06-23 15:25:38.607843
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = ['name', 'action', 'tasks', 'pre_tasks', 'post_tasks', 'gather_facts', 'delegate_to', 'delegate_facts', 'notify', 'async', 'poll', 'when', 'become', 'become_user', 'become_method', 'connection', 'register', 'local_action', 'transport', 'vars', 'tags', 'failed_when', 'ignore_errors', 'roles', 'run_once', 'any_errors_fatal', 'retries', 'delay', 'until', 'su', 'sudo', 'sudo_user', 'environment', 'no_log']
    msg = 'Found variable using reserved name: '
    for myvar in reserved:
        display.clear_warning()
        display.verbosity = 3
        warn_if_reserved([myvar])

# Generated at 2022-06-23 15:25:50.073677
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:57.707581
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = {
        'connection', 'delegate_to', 'gather_facts', 'hosts', 'name', 'roles',
        'serial', 'strategy', 'sudo', 'sudo_user', 'tags', 'tasks', 'vars_files',
        'vars', 'when', 'with_', 'local_action'}
    # get_reserved_names() returns a set of names.
    reserved_set = get_reserved_names()
    assert reserved_set == reserved_names

# Generated at 2022-06-23 15:26:05.107486
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=False)
    assert 'action' in result, \
        'action should be in the list of public attributes'
    assert 'with_' not in result, \
        'with_ should not be in the list of public attributes'

    result = get_reserved_names(include_private=True)
    assert 'action' in result, \
        'action should be in the list of all attributes'
    assert 'with_' in result, \
        'with_ should be in the list of all attributes'



# Generated at 2022-06-23 15:26:15.808990
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:24.710030
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests.mock import patch
    from io import StringIO

    fake_stderr = StringIO()
    with patch('sys.stderr', new=fake_stderr):
        warn_if_reserved(['action', 'local_action', 'with_', 'hosts', 'any_errors_fatal', 'remote_user'])
        assert ('Found variable using reserved name: action' in fake_stderr.getvalue()) is True
        assert ('Found variable using reserved name: with_' in fake_stderr.getvalue()) is True
        assert ('Found variable using reserved name: any_errors_fatal' in fake_stderr.getvalue()) is True



# Generated at 2022-06-23 15:26:33.691793
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:39.265001
# Unit test for function get_reserved_names
def test_get_reserved_names():
    play_names = set(p for p in Play().__dict__['_attributes'] if 'private' not in p)
    assert play_names.issubset(get_reserved_names(include_private=False))
    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names(include_private=False)
    assert 'loop' in get_reserved_names(include_private=False)
    assert 'tags' in get_reserved_names(include_private=False)
    assert 'until' in get_reserved_names(include_private=False)
    assert 'when' in get_reserved_names(include_private=False)

# Generated at 2022-06-23 15:26:41.052433
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:26:50.376609
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('async')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('hosts')
    assert is_reserved_name('ignore_errors')
    assert is_reserved_name('local_action')
    assert is_reserved_name('name')
    assert is_reserved_name('no_log')
    assert is_reserved_name('poll')
    assert is_reserved_name('register')
    assert is_reserved_name('roles')
    assert is_reserved_name('run_once')
    assert is_reserved_name('sudo')
    assert is_reserved_name('sudo_user')


# Generated at 2022-06-23 15:26:52.922565
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('delegate_facts')
    assert not is_reserved_name('test_foo')

# Generated at 2022-06-23 15:27:03.276941
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    unit test for get_reserved_names
    verify if reserved names are returned.
    '''

# Generated at 2022-06-23 15:27:07.230871
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') == True
    assert is_reserved_name('with_items') == True
    assert is_reserved_name('private_key_file') == True
    assert is_reserved_name('role_name') == True
    assert is_reserved_name('some_random_name') == False

# Generated at 2022-06-23 15:27:12.530508
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) > 0
    assert len(get_reserved_names(include_private=False)) > 0
    assert len(get_reserved_names(include_private=True)) > len(get_reserved_names(include_private=False))


# Generated at 2022-06-23 15:27:18.911473
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert is_reserved_name('role_path')
    assert is_reserved_name('blocks')
    assert is_reserved_name('error')
    assert is_reserved_name('loop')
    assert is_reserved_name('when')
    assert is_reserved_name('include')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('connection')
    assert is_reserved_name('serial')
    assert is_reserved_name('ignore_errors')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name

# Generated at 2022-06-23 15:27:20.526462
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('ansible_version')

# Generated at 2022-06-23 15:27:25.856008
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert not is_reserved_name('role')
    assert not is_reserved_name('Role')
    assert not is_reserved_name('role_one')

    assert is_reserved_name('hosts')
    assert is_reserved_name('host')
    assert not is_reserved_name('hostname')

    assert is_reserved_name('become')
    assert is_reserved_name('become_user')
    assert is_reserved_name('become_method')

# Generated at 2022-06-23 15:27:28.141491
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['foo', 'action', 'when'])

# Generated at 2022-06-23 15:27:36.690575
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'async' in reserved
    assert 'any_errors_fatal' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'name' in reserved
    assert 'include' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'loop' in reserved
    assert 'when' in reserved
    assert 'environment' in reserved
    assert 'with_' in reserved
    assert 'import_playbook' in reserved
    assert 'include_role' in reserved
    assert 'hosts' in reserved


# Generated at 2022-06-23 15:27:47.675450
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest

    class TestWIR(unittest.TestCase):
        def setUp(self):
            self.reserved = {'become',
                             'connection',
                             'delegate_to',
                             'gather_facts',
                             'no_log',
                             'register',
                             'remote_user',
                             'sudo',
                             'sudo_user',
            }

        @patch('ansible.utils.display.Display.warning')
        def test_warn(self, mock_warning):
            warn_if_reserved(self.reserved, set())
            mock_warning.assert_has_calls([])

# Generated at 2022-06-23 15:27:57.366473
# Unit test for function is_reserved_name
def test_is_reserved_name():
    varnames = ["vars", "name", "hosts", "roles", "tags", "action", "async", "delegate_to", "delegate_facts", "notify", "register", "until", "fail_when", "with_items", "local_action", "shell", "environment", "connection", "sudo", "sudo_user", "sudo_pass", "sudo_exe", "sudo_flags", "transport", "no_log", "run_once", "first_available_file", "ignore_errors", "remote_src", "local_src", "umask", "creates", "removes", "when", "chdir", "executable"]
    for name in varnames:
        assert is_reserved_name(name)
    assert not is_reserved_name("boo-yah")



# Generated at 2022-06-23 15:28:00.016768
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('name')
    assert is_reserved_name('sudo')
    assert is_reserved_name('sudo_user')
    assert is_reserved_name('tags')
    assert not is_reserved_name('garbage')


# Generated at 2022-06-23 15:28:01.706145
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name("name"))
    assert(not is_reserved_name("foobar"))

# Generated at 2022-06-23 15:28:05.695129
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # FIXME: determine if there is a better way to test this
    warn_if_reserved({'action': 'setup'}, additional={'meta'})
    warn_if_reserved({'action': 'setup', 'meta': {'tags': 'always'}}, additional={'meta'})

# Generated at 2022-06-23 15:28:15.115910
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY3

    def compare_output(output):
        if PY3:
            output = [to_native(o) for o in output]
        return output == [
            'Found variable using reserved name: when',
            'Found variable using reserved name: with_',
            'Found variable using reserved name: loop',
            'Found variable using reserved name: connection',
            'Found variable using reserved name: gather_facts',
        ]

    # Test the output of this function
    assert compare_output(display.get_captured_warnings()) is True

    assert is_reserved_name('when') is True
    assert is_reserved_name('with_') is True
    assert is_reserved_name('loop') is True

# Generated at 2022-06-23 15:28:17.440151
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('vars')
    assert not is_reserved_name('fake_vars')


# Generated at 2022-06-23 15:28:19.268180
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for n in _RESERVED_NAMES:
        assert is_reserved_name(n)

# Generated at 2022-06-23 15:28:21.395087
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'pre_tasks': "foo", 'tasks': 'bar'})

# Generated at 2022-06-23 15:28:22.553840
# Unit test for function get_reserved_names
def test_get_reserved_names():

    results = get_reserved_names()
    assert 'hosts' in results
    assert 'roles' in results



# Generated at 2022-06-23 15:28:24.210169
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['vars']) == None
    assert warn_if_reserved(['vars', 'name']) == 'Found variable using reserved name: name'

# Generated at 2022-06-23 15:28:33.863965
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # setup
    fake_filename = 'somefile'

    class FakeDisplay:
        def __init__(self):
            self.msg = None

        def warning(self, msg):
            self.msg = msg

    fake_display = FakeDisplay()
    display.add_handler(fake_display)

    # test
    try:
        warn_if_reserved({'when': 'test'})
    except Exception as errmsg:
        display.error(errmsg)
        display.display(msg=None, color='red', screen_only=True, log_only=False)
        raise Exception('warn_if_reserved() failed!')

    display.remove_handler(fake_display)

    # check
    if fake_display.msg is None:
        raise Exception('warn_if_reserved() failed!')

# Generated at 2022-06-23 15:28:44.555121
# Unit test for function is_reserved_name

# Generated at 2022-06-23 15:28:46.843031
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = {'action': 'test'}
    warn_if_reserved(vars)
    assert 'action' in vars

# Generated at 2022-06-23 15:28:55.201074
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' simple unit test for function get_reserved_names'''
    test_names_publiconly = set(['name', 'connection', 'delegate_to', 'gather_facts', 'remote_user', 'tags', 'sudo',
                                 'sudo_user', 'become_user', 'become_method', 'environment', 'register', 'ignore_errors',
                                 'check_mode', 'when', 'any_errors_fatal', 'notify', 'serial', 'failed_when', 'until',
                                 'retries', 'delay', 'first_available_file', 'local_action', 'transport',
                                 'with_'])

    test_names_include_private = set(test_names_publiconly)

# Generated at 2022-06-23 15:29:06.597198
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Reserve all tests and add them to _RESERVED_NAMES
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('vars')
    assert is_reserved_name('environment')
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('register')
    assert is_reserved_name('local_action')
    assert is_reserved_name('action')
    assert is_reserved_name('when')
    assert is_reserved_name('with_')

# Generated at 2022-06-23 15:29:08.879582
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Tests to confirm that get_reserved_names returns a list of reserved names '''
    assert get_reserved_names()

# Generated at 2022-06-23 15:29:10.003503
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')


# Generated at 2022-06-23 15:29:20.086606
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names =  get_reserved_names()
    assert 'roles' in reserved_names
    assert 'when' in reserved_names
    assert 'tags' in reserved_names
    assert 'hosts' in reserved_names
    assert 'vars' in reserved_names
    assert 'name' in reserved_names
    assert 'port' in reserved_names
    assert 'client_cert' in reserved_names
    assert 'client_key' in reserved_names
    assert 'ca_cert' in reserved_names
    assert 'user' in reserved_names
    assert 'password' in reserved_names
    assert 'LOG_PATH' in reserved_names
    assert 'connection' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'sudo_flags' in reserved_names
    assert 'sudo' in reserved_names

# Generated at 2022-06-23 15:29:28.046289
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become')
    assert is_reserved_name('block')
    assert is_reserved_name('become_user')
    assert is_reserved_name('roles')
    assert not is_reserved_name('hosts')
    assert is_reserved_name('hosts_all')
    assert is_reserved_name('hosts_all')
    assert not is_reserved_name('test_is_reserved_name')
    assert not is_reserved_name('test_is_reserved_name_')

# Generated at 2022-06-23 15:29:39.793045
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = set(get_reserved_names())
    assert 'name' in reserved_names
    assert 'run_once' in reserved_names
    assert 'any_errors_fatal' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'gather_subset' in reserved_names
    assert 'gather_timeout' in reserved_names
    assert 'become' in reserved_names
    assert 'become_method' in reserved_names
    assert 'become_user' in reserved_names
    assert 'connection' in reserved_names
    assert 'delegate_to' in reserved_names
    assert 'delegate_facts' in reserved_names
    assert 'environment' in reserved_names

# Generated at 2022-06-23 15:29:41.706220
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('tags')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('bogus')