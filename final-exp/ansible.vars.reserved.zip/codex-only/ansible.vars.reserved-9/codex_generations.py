

# Generated at 2022-06-23 15:19:42.247160
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' function get_reserved_names should return only public names when argument is omitted '''
    reserved = get_reserved_names()
    assert 'included_tasks' not in reserved
    assert 'register' in reserved


# Generated at 2022-06-23 15:19:44.921259
# Unit test for function get_reserved_names
def test_get_reserved_names():
    res = get_reserved_names(include_private=True)
    # TODO: test with_ implicit inclusion
    # TODO: outcome changes with different versions of modules

# Generated at 2022-06-23 15:19:48.349109
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'name' in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)

# Generated at 2022-06-23 15:19:51.363017
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert WARN_IF_RESERVED(['roles']) is True
    assert WARN_IF_RESERVED(['include', 'hosts']) is True



# Generated at 2022-06-23 15:19:59.024234
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    def assert_raises(myvars, additional=None, func=warn_if_reserved):
        raised = False
        try:
            func(myvars, additional)
        except AssertionError:
            raised = True
        assert raised

    assert_raises([1, 2, 3])
    assert_raises(['hosts', 'name'])
    assert_raises(['hosts'], additional=['hosts'])
    assert_raises(['hosts'], func=warn_if_private_reserved)



# Generated at 2022-06-23 15:20:06.101761
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This is a unit test for method get_reserved_names.
    It checks that the different classes have the expected number of reserved names,
    and that we do not get duplicates.
    '''
    names_list = get_reserved_names()

    # There should be some reserved names
    assert (names_list)

    # We should not get duplicate names
    assert (len(names_list) == len(set(names_list)))

    # We should not get more reserved names than expected
    assert (len(names_list) <= 61)

# Generated at 2022-06-23 15:20:16.570241
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:20:17.867606
# Unit test for function get_reserved_names
def test_get_reserved_names():
    "unit test for the function get_reserved_names"
    return get_reserved_names()



# Generated at 2022-06-23 15:20:19.496434
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = dict(hosts='localhost', verbosity=True)
    warn_if_reserved(myvars=vars, additional=['verbosity'])

# Generated at 2022-06-23 15:20:24.450084
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Unit test for function get_reserved_names '''

    test_set1 = set(['name', 'vars', 'vars_prompt', 'vars_files', 'role',
                     'environment', 'action', 'local_action', 'block', 'block_tasks'])
    test_set2 = set(['name', 'vars', 'vars_prompt', 'vars_files', 'role',
                     'environment', 'action', 'local_action', 'block', 'block_tasks',
                     'tags', 'when', 'loop', 'async_poll', 'async', 'poll', 'register', 'ignore_errors'])
    test_set = get_reserved_names()
    test_set_private = get_reserved_names(include_private = False)

    # Check set returned by function

# Generated at 2022-06-23 15:20:35.776038
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this unit test validates the warn_if_reserved() function '''

    def get_warnings(**kwargs):
        ''' function to simulate warnings printed by warn_if_reserved() '''

        # Reset display.warning() context
        display.verbosity = 2

        if 'warn_if_reserved' in globals():
            del globals()['warn_if_reserved']

        warn_if_reserved(kwargs['vars'], kwargs['additional'])

        # save and restore original values and then get results
        orig_verbosity = display.verbosity
        display.verbosity = 0
        warnings = display.warning.pop()
        display.verbosity = orig_verbosity

        return warnings

    # Test 1: vars = {}

# Generated at 2022-06-23 15:20:47.486253
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''Unit test for function warn_if_reserved'''
    from ansible.module_utils.six import StringIO
    backup = display.columns
    backup_stderr = display.stderr
    display.columns = 80
    display.stderr = StringIO()

# Generated at 2022-06-23 15:20:52.124909
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # make sure the reserved name list is not empty, or we'll have a problem
    assert len(get_reserved_names()) > 0

    # ensure that "name" is a reserved name, as it should be
    assert get_reserved_names().__contains__('name')

# Generated at 2022-06-23 15:20:59.899637
# Unit test for function is_reserved_name

# Generated at 2022-06-23 15:21:10.798267
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset({'gather_facts', 'hosts', 'name', 'any_errors_fatal', 'serial', 'connection', 'become', 'vars', 'vars_files', 'remote_user', 'roles', 'tags', 'environment', 'post_tasks', 'pre_tasks', 'handlers', 'blocks', 'tasks', 'action', 'local_action', 'with_'})

# Generated at 2022-06-23 15:21:18.426272
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('role_name') is True
    assert is_reserved_name('my_role_name') is False
    assert is_reserved_name('roles') is True
    assert is_reserved_name('roles_') is False
    assert is_reserved_name('include_role') is False
    assert is_reserved_name('include_tasks') is False
    assert is_reserved_name('import_playbook') is False

# Generated at 2022-06-23 15:21:25.372900
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert is_reserved_name('role_names')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('stat')
    assert is_reserved_name('always')
    assert is_reserved_name('changed_when')
    assert not is_reserved_name('myvar')

# Generated at 2022-06-23 15:21:30.328674
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('name')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:21:32.550752
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['vars'])
    except Exception:
        assert False, 'should not raise exception'

# Generated at 2022-06-23 15:21:37.922756
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # ensure is_reserved_name is symmetric to get_reserved_names
    assert set(get_reserved_names()).symmetric_difference(_RESERVED_NAMES) == set()
    # ensure is_reserved_name works
    assert is_reserved_name('name')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-23 15:21:46.314397
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class TestModule(object):
        pass
    class OptionsModule(object):
        pass

    args = TestModule()
    args.SOME_VARS = ['action', 'something']
    args.connection = 'local'
    args.module_path = None
    args.forks = 5
    args.become = False
    args.become_method = None
    args.become_user = None
    args.check = False
    args.diff = False
    args.inventory = None
    args.remote_user = 'ansible'
    args.tags = ['all']
    args.skip_tags = None
    args.one_line = None
    args.verbosity = 0
    args.extra_vars = 'somevar=somevalue'
    args.ask_pass = False
    args.private_key_

# Generated at 2022-06-23 15:21:48.504924
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(dict(action=42, loop=42, with_=42).keys(), ['additional_var'])



# Generated at 2022-06-23 15:21:49.968715
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert isinstance(warn_if_reserved({'action': 'foo'}), None)

# Generated at 2022-06-23 15:21:52.593260
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('foohost')
    assert is_reserved_name('hosts')

# Generated at 2022-06-23 15:22:01.695857
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import os
    import tempfile
    import unittest

    from ansible.compat.tests import mock

    class TestWarnIfReserved(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp(prefix='ansible_test_warn_reserved_')

            self.out_fd, self.out_file = tempfile.mkstemp(dir=self.tempdir)
            self.err_fd, self.err_file = tempfile.mkstemp(dir=self.tempdir)

            # Store original environ, and fixup PATH
            self.orig_environ = os.environ.copy()
            os.environ['PYTHONPATH'] = os.pathsep.join(sys.path)
            os.environ['PATH'] = os

# Generated at 2022-06-23 15:22:04.456760
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_word = "action"
    assert(is_reserved_name(reserved_word))
    test_word = "derp"
    assert(not is_reserved_name(test_word))

# Generated at 2022-06-23 15:22:10.586838
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # public names
    public_reserved = ['action', 'any_errors_fatal', 'connection', 'delegate_to', 'failed_when', 'force_handlers', 'gather_facts', 'handlers', 'hosts', 'included_files', 'name', 'notify', 'remote_user', 'register', 'roles', 'serial', 'sudo', 'sudo_user', 'tasks', 'vars_files', 'vars_prompt', 'when']

    # private names
    private_reserved = ['loop', 'loops', 'local_action', 'with_', 'with_items', 'with_file', 'with_subelements', 'with_first_found']

    # all names
    all_reserved = public_reserved + private_reserved

    # public names only
    public_results = get_

# Generated at 2022-06-23 15:22:16.223674
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    reserved_len = len(reserved)
    public_len = len(get_reserved_names(False))

    # make sure the private names aren't in the public list
    assert public_len < reserved_len
    # make sure we're not missing any names
    assert len(['gather_facts', 'hosts']) == 2

# Generated at 2022-06-23 15:22:25.796890
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' unit tests for function warn_if_reserved '''
    from ansible.module_utils.six import PY3
    import sys

    # PY3 has no cmp() and is based on rich comparisons
    # We cannot test stdout specifically, as that is done in print_function,
    # which is too late for us to test properly.
    # So, we capture the output in a string and test that.
    if PY3:
        from io import StringIO
        saved_stdout = sys.stdout
        sys.stdout = mystdout = StringIO()

    warn_if_reserved(['action', 'hosts', 'roles', 'vars'], set(['hosts', 'roles']))

# Generated at 2022-06-23 15:22:28.559355
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    fake_display = Display()
    warn_if_reserved(['action'], fake_display)
    assert fake_display.display == '<log> WARNING: Found variable using reserved name: action\n'



# Generated at 2022-06-23 15:22:29.868659
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('tags') == True
    assert is_reserved_name('my_action') == False

# Generated at 2022-06-23 15:22:39.442166
# Unit test for function is_reserved_name
def test_is_reserved_name():
    import sys

    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('loop')
    assert is_reserved_name('name')
    assert is_reserved_name('register')
    assert is_reserved_name('ignore_errors')
    assert is_reserved_name('assert')
    assert not is_reserved_name('not_a_reserved_name')

    assert is_reserved_name('tags')
    assert is_reserved_name('become')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('run_once')
    assert is_reserved_name('include')
    assert is_reserved_name

# Generated at 2022-06-23 15:22:41.370981
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('role_path')
    assert not is_reserved_name('my_var')



# Generated at 2022-06-23 15:22:46.307947
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names()

    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'with_' in reserved
    assert 'loop' in reserved
    assert 'delegate_to' in reserved
    assert 'register' in reserved
    assert 'tags' in reserved

    assert 'role_name' not in reserved
    assert 'async_poll' not in reserved
    assert 'async' not in reserved
    assert 'include_role' not in reserved

# Generated at 2022-06-23 15:22:48.418956
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'action' in reserved
    assert 'local_action' not in reserved
    assert 'include_vars' in reserved
    assert 'include' not in reserved

# Generated at 2022-06-23 15:22:54.693151
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved = _RESERVED_NAMES
    assert ('roles' in reserved) == is_reserved_name('roles')
    assert ('pre_tasks' in reserved) == is_reserved_name('pre_tasks')
    assert ('vars_prompt' in reserved) == is_reserved_name('vars_prompt')
    assert ('name' in reserved) == is_reserved_name('name')
    assert ('notreserved' in reserved) == is_reserved_name('notreserved')
    assert (('notreserved' not in reserved) == is_reserved_name('notreserved', additional=['notreserved']))
    assert ('action' in reserved) == is_reserved_name('action')

# Generated at 2022-06-23 15:23:00.150428
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('host') == True
    assert is_reserved_name('local_action') == True
    assert is_reserved_name('with_') == True
    assert is_reserved_name('some_other_non_reserved_name') == False

# Generated at 2022-06-23 15:23:03.994623
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(myvars={'tasks': 'foo'}, additional={'only_if': 'bar'})
    except Exception:
        raise AssertionError('warn_if_reserved should silently exit.')



# Generated at 2022-06-23 15:23:05.956999
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')



# Generated at 2022-06-23 15:23:07.668338
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['name', 'action', 'with_items', 'vars', 'local_action'])

# Generated at 2022-06-23 15:23:10.525011
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    fake_reservedvars = {'gather_facts': 'true', 'action': 'network_facts', 'with_items': 'lo0'}
    assert warn_if_reserved(fake_reservedvars) is None


# Generated at 2022-06-23 15:23:15.919092
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public, private = get_reserved_names(False), get_reserved_names(True)

    assert 'delegate_to' in public
    assert 'private' not in public

    assert 'delegate_to' in private
    assert 'private' in private

    assert 'notify' in public.union(private)
    assert 'notify' not in public.intersection(private)



# Generated at 2022-06-23 15:23:18.787205
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    varnames = frozenset(['x', 'y', 'z', 'a', 'b', 'c', 'action', 'roles', 'handler'])
    additional = frozenset(['action', 'roles', 'handler'])
    warn_if_reserved(varnames, additional)

# Generated at 2022-06-23 15:23:30.074023
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    reserved_names_private = get_reserved_names(include_private=False)
    assert 'name' in reserved_names, "'name' not in reserved_names"
    assert 'name' in reserved_names_private, "'name' not in reserved_names_private"
    assert 'hosts' in reserved_names, "'hosts' not in reserved_names"
    assert 'hosts' in reserved_names_private, "'hosts' not in reserved_names_private"
    assert 'any_errors_fatal' in reserved_names_private, "'any_errors_fatal' not in reserved_names"
    assert 'any_errors_fatal' not in reserved_names, "'any_errors_fatal' in reserved_names_private"



# Generated at 2022-06-23 15:23:33.591402
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert not warn_if_reserved({'var': 'v'})
    assert warn_if_reserved({'var': 'v', 'hosts': 'h'}, ['hosts'])

# Generated at 2022-06-23 15:23:44.238003
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert is_reserved_name('name')
    assert is_reserved_name('version')
    assert is_reserved_name('tasks')
    assert is_reserved_name('role_name')
    assert is_reserved_name('action')
    assert is_reserved_name('with_items')
    assert is_reserved_name('with_subelements')
    assert is_reserved_name('until')
    assert is_reserved_name('retries')
    assert is_reserved_name('register')
    assert is_reserved_name('loop')
    assert is_reserved_name('ignore_errors')
    assert is_

# Generated at 2022-06-23 15:23:48.475225
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars'])
    warn_if_reserved(['include_vars'])
    warn_if_reserved(['vars', 'include_vars'])



# Generated at 2022-06-23 15:23:57.044991
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'roles': 'foo'}) is None
    assert warn_if_reserved({'hosts': 'foo'}) is None
    assert warn_if_reserved({'post_tasks': 'foo'}) is None
    assert warn_if_reserved({'tasks': 'foo'}) is None
    assert warn_if_reserved({'roles': 'foo'}) is None
    assert warn_if_reserved({'any_errors_fatal': 'foo'}) is None
    assert warn_if_reserved({'local_action': 'foo'}) is None
    assert warn_if_reserved({'with_': 'foo'}) is None

# Generated at 2022-06-23 15:24:01.146688
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' unit test for warn_if_reserved '''

    warn_if_reserved(['foo', 'vars', 'role_name', 'name'])
    warn_if_reserved(['foo', 'role_name', 'name', 'become'], additional={'become'})

# Generated at 2022-06-23 15:24:05.206908
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = get_reserved_names()
    assert len(reserved_names) > 0

    # Verify that reserved name is found
    assert is_reserved_name('hosts')

    # Verify invalid name is not found
    assert not is_reserved_name('some_invalid_name')

# Generated at 2022-06-23 15:24:08.670364
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('random')

# Generated at 2022-06-23 15:24:13.246169
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this function tests if warn_if_reserved raises the desired warning '''
    myvars = ['name', 'when', 'action', 'register', 'local_action', 'loop', 'with_', 'vars', 'other']
    warn_if_reserved(myvars)
    # FIXME: add some assert statements

# Generated at 2022-06-23 15:24:22.876361
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # pylint: disable=redefined-outer-name
    result = get_reserved_names()

    assert 'include_tasks' in result
    assert 'handler' in result
    assert 'when' in result
    assert 'vars' in result
    assert 'roles' in result
    assert 'block' in result
    assert 'action' in result
    assert 'with_' in result
    assert 'local_action' in result
    assert 'delegate_to' in result
    assert 'any_errors_fatal' in result
    assert 'max_fail_percentage' in result
    assert 'ignore_errors' in result
    assert 'tags' in result
    assert 'name' in result

# Generated at 2022-06-23 15:24:25.327196
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('name')
    assert not is_reserved_name('foo')



# Generated at 2022-06-23 15:24:33.597515
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test reserved names
    warn_if_reserved(['name', 'notify'])
    # Test deprecation of with_
    warn_if_reserved(['loop'])
    # Test local_action
    warn_if_reserved(['action'])
    # Test that additional unreserved names don't trigger warnings
    warn_if_reserved(['notify'], set(['vars', 'with_items']))
    # Test that additional reserved names do trigger warnings
    warn_if_reserved(['notify'], set(['register']))

# Generated at 2022-06-23 15:24:37.488561
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'roles': 'role1'})


if __name__ == '__main__':
    test_warn_if_reserved()
    print(get_reserved_names())

# Generated at 2022-06-23 15:24:41.686372
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert is_reserved_name('private')
    assert not is_reserved_name('unreserved_name')
    assert not is_reserved_name('__init__')


# Generated at 2022-06-23 15:24:42.798031
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')


# Generated at 2022-06-23 15:24:51.618776
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:24:58.455483
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('vars')
    assert is_reserved_name('block')
    assert is_reserved_name('block:')

# Generated at 2022-06-23 15:25:03.555856
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # All the names in a reserved list should be reserved
    assert all(is_reserved_name(name) for name in _RESERVED_NAMES)

    # None of the names in a non-reserved list should be reserved
    non_reserved_names = ['myvar', 'my_var', 'my-var', 'myvar123', 'myvar_123']
    assert not any(is_reserved_name(name) for name in non_reserved_names)

# Generated at 2022-06-23 15:25:08.490678
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_play = dict(
        hosts='all',
        pre_tasks='test',
        post_tasks='test',
        tasks='test',
        handlers='test',
        vars='test',
        play_hosts='test',
        gather_facts='no'
    )

    warn_if_reserved(test_play)

# Generated at 2022-06-23 15:25:11.988817
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert _RESERVED_NAMES.issuperset(['roles'])
    assert _RESERVED_NAMES.issuperset(['tasks'])
    assert _RESERVED_NAMES.issuperset(['block'])



# Generated at 2022-06-23 15:25:17.564573
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test that the returned values are what is expected
    # this test is a bit tricky because it counts on the
    # presence of certain names
    reserved = get_reserved_names()

    # there's no guarantee that keywords like `with_` will
    # be private, but for now it is, so we can test for it.
    assert 'with_' in reserved

    # TODO: make test harder when with_ isn't a private keyword
    assert 'loop' in reserved

    assert 'environment' in reserved


# Generated at 2022-06-23 15:25:21.871848
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('when')
    assert is_reserved_name('tasks')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('variables')

# Generated at 2022-06-23 15:25:25.940884
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # If we call it with empty, it should not raise any warnings
    warn_if_reserved([])
    # Check for known values
    warn_if_reserved(['hosts'])
    warn_if_reserved(['hosts2'], ['hosts2'])

# Generated at 2022-06-23 15:25:37.235201
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests the function get_reserved_names '''

    # FIXME: determine if this is worth it, to test that a specific set is returned
    # vs. just verifying we get something back
    # public_result = ['name', 'hosts', 'gather_facts', 'vars', 'vars_files', 'tasks', 'tags', 'action', 'register', 'ignore_errors']
    # private_result = ['private', 'dep_chain', 'handlers', 'meta', 'post_tasks', '__ansible_role_names', '__ansible_roles_oneline_summary']

    # FIXME: make sure this is always ordered the same
    private_result = get_reserved_names(include_private=True)
    assert isinstance(private_result, set)
    assert 'private' in private

# Generated at 2022-06-23 15:25:48.735931
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert 'role' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'gather_facts' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'vars' in _RESERVED_NAMES
    assert 'any_errors_fatal' in _RESERVED_NAMES
    assert 'become' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES
    assert 'connection' in _RESERVED_NAMES
    assert 'delegate_to' in _RESERVED_NAMES

# Generated at 2022-06-23 15:25:50.086053
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-23 15:25:51.932543
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('connection')
    assert not is_reserved_name('foo')



# Generated at 2022-06-23 15:26:01.815006
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names(include_private=False)
    # warn_if_reserved will exit with a non-zero status if it sees a conflict
    try:
        warn_if_reserved(reserved)
        assert False, 'warn_if_reserved did not exit when given a conflict'
    except SystemExit:
        pass

    # now make sure we don't get a warning for non-conflicting vars
    warn_if_reserved(['foo'])

    # and make sure we don't get a warning for reserved vars that we're
    # told to ignore
    warn_if_reserved(reserved, additional=['bar'])

# Generated at 2022-06-23 15:26:05.744367
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test get_reserved_names function'''
    testobject = get_reserved_names()
    assert isinstance(testobject, set)
    assert len(testobject) >= 100



# Generated at 2022-06-23 15:26:07.046273
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts': 'localhost'})

# Generated at 2022-06-23 15:26:08.864170
# Unit test for function get_reserved_names
def test_get_reserved_names():
    for i in get_reserved_names():
        assert isinstance(i, str)

# Generated at 2022-06-23 15:26:19.022748
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Test that get_reserved_names returns the expected names.
    '''
    # This test assumes that get_reserved_names is working.
    # This test also assumes that get_reserved_names includes the names used here.

    # A simple test with no special names
    simple_body = (
        '- hosts: test\n'
        '  tasks:\n'
        '    - name: test\n'
        '      debug:\n'
        '        msg: test\n'
    )
    expected_simple = frozenset()
    actual_simple = frozenset(get_reserved_names())
    assert actual_simple == expected_simple

    # A test with all the special names but no task/handler names

# Generated at 2022-06-23 15:26:29.945496
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import json
    from ansible.utils.unsorted_list import UnsortedList
    d0 = UnsortedList()
    d0.extend(['a', 'b', 'b', 'd', 'a', 'e', 'f'])
    d1 = UnsortedList()
    d1.extend(['a', 'd', 'e', 'f'])
    d2 = UnsortedList()
    d2.extend(['a', 'd', 'e', 'f'])
    d3 = UnsortedList()
    d3.extend(['a', 'd', 'e', 'f'])
    d4 = UnsortedList()
    d4.extend(['a', 'd', 'e', 'f'])
    a = set()
    a.add(d0)

# Generated at 2022-06-23 15:26:37.407821
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    # Test none
    warn_if_reserved(None)

    # Test empty list
    warn_if_reserved([])

    # Test empty dict
    warn_if_reserved({})

    # Test no conflict
    warn_if_reserved(['foo', 'bar'])
    warn_if_reserved(['foo', 'bar', 'with_'])
    warn_if_reserved(['foo', 'bar', 'vars'])
    warn_if_reserved(['foo', 'bar', 'hosts'])
    warn_if_reserved(['foo', 'bar', 'action'])
    warn_if_reserved(['foo', 'bar', 'local_action'])

# Generated at 2022-06-23 15:26:47.863201
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.unittest import TestCase
    from ansible.module_utils._text import to_text
    from io import StringIO

    class TestPlayVars(TestCase):

        def setUp(self):
            self.display = Display()
            self.display.verbosity = 0

        def tearDown(self):
            self.display.verbosity = 0

        def test_play_vars_reserved_names(self):
            class TestPlay(Play):
                pass
            p = TestPlay()
            vars_ = {'gather_facts': True, 'name': 'foo', 'action': 'bar', 'become': False, 'roles': []}
            warn_if_reserved(vars_)
            self.assertTrue(True)


# Generated at 2022-06-23 15:26:49.962092
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('foo')
    assert is_reserved_name('tags')
    assert is_reserved_name('type')

# Generated at 2022-06-23 15:26:54.363242
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts': 'asdf'})
    warn_if_reserved({'hosts': 'asdf'}, additional=['hosts'])
    display.verbosity = 0
    warn_if_reserved({'hosts': 'asdf'})
    warn_if_reserved({'hosts': 'asdf'}, additional=['hosts'])
    display.verbosity = 4

# Generated at 2022-06-23 15:27:01.789358
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' Test the warn_if_reserved function'''

    # create a local copy of this global constant
    tmp_reserved = _RESERVED_NAMES

    # test if the function exits silently with no variables
    warn_if_reserved([])

    # test if the function displays a warning when using a reserved name
    for name in tmp_reserved:
        warn_if_reserved([name], additional=[name])

    # test if the function displays a warning when using a non reserved name
    warn_if_reserved(['a'], additional=['b'])

# Generated at 2022-06-23 15:27:08.739471
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests.mock import patch

    def mock_warning(msg):
        warnings.append(msg)

    warnings = []
    with patch('ansible.utils.display.Display.warning', mock_warning):
        warn_if_reserved({'hosts': 'all', 'gather_facts': False, 'foo': 'bar'})

    assert len(warnings) == 2
    # The order of the warnings is not deterministic
    assert 'Found variable using reserved name: gather_facts' in warnings
    assert 'Found variable using reserved name: hosts' in warnings

# Generated at 2022-06-23 15:27:11.323716
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('name') == True)
    assert(is_reserved_name('invalid') == False)

# Generated at 2022-06-23 15:27:18.173634
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # create set of reserved names
    reserved = get_reserved_names(include_private=False)

    # create set of variables names
    varnames = set()
    varnames.add('reserved')
    varnames.add('public')

    # check that warning message is displayed
    warn_if_reserved(varnames, reserved)

    # check that warning message is not displayed
    varnames.discard('reserved')
    warn_if_reserved(varnames, reserved)

# Generated at 2022-06-23 15:27:19.340338
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

    # Ensure that a collected reserved name is whitelisted
    assert 'register' in reserved



# Generated at 2022-06-23 15:27:23.650507
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' test is_reserved_name function '''
    assert(is_reserved_name('hosts'))
    assert(is_reserved_name('vars'))
    assert(is_reserved_name('roles'))
    assert(is_reserved_name('any_keys'))
    assert(is_reserved_name('connection'))
    assert(is_reserved_name('async'))
    assert(is_reserved_name('delegate_to'))



# Generated at 2022-06-23 15:27:24.292290
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')

# Generated at 2022-06-23 15:27:34.957605
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # imported via the main module
    from ansible.module_utils.basic import AnsibleModule

    # define Ansible arguments
    argument_spec = dict(
        var1=dict(required=True, type='str'),
        var2=dict(required=True, type='str'),
        action=dict(required=False, type='str'),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=False,
    )

    # supply the AnsibleModule arguments to the function
    warn_if_reserved(module.params)

    # exit the module and return the required JSON
    module.exit_json(changed=False)

# Generated at 2022-06-23 15:27:37.219487
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'connection': 'local', 'gather_facts': 'no', 'foo': 'bar'})

# Generated at 2022-06-23 15:27:40.743996
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(True) == _RESERVED_NAMES


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-23 15:27:43.670089
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('not_a_reserved_name')



# Generated at 2022-06-23 15:27:48.835163
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES
    assert 'pre_tasks' in _RESERVED_NAMES
    assert 'post_tasks' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES
    assert 'with_' in _RESERVED_NAMES



# Generated at 2022-06-23 15:27:55.612752
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Test that get_reserved_names returns the correct set
    reserved = get_reserved_names()
    assert reserved == _RESERVED_NAMES, reserved

    # Test that the set is updated when we add new objects
    class A(object):
        pass
    class_list = [A]
    reserved = get_reserved_names(include_private=False,
                                  class_list=class_list)
    assert '_attributes' in reserved
    assert 'action' in reserved
    assert 'local_action' not in reserved
    assert 'with_' not in reserved

    # Test that private and public are included as expected
    reserved = get_reserved_names(include_private=True)
    assert '_attributes' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
   

# Generated at 2022-06-23 15:27:59.685017
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'action': 'foo'})
    assert warn_if_reserved({'action': 'foo', 'vars': 'bar'}) == None
    assert warn_if_reserved({'vars': 'bar'}) == None


# Generated at 2022-06-23 15:28:05.104343
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('hosts')
    assert is_reserved_name('become')
    assert is_reserved_name('roles')
    assert is_reserved_name('vars')
    assert is_reserved_name('gather_facts')

    assert not is_reserved_name('bananas')
    assert not is_reserved_name('tags')



# Generated at 2022-06-23 15:28:13.144106
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    The set of reserved names is hardcoded to ensure that future changes in Ansible
    don't accidentally introduce a reserved word which causes an error when a user
    names a play task or variable attribute with that name.

    This test compares a list of names returned from get_reserved_names to that
    hardcoded list.
    '''


# Generated at 2022-06-23 15:28:19.170345
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert is_reserved_name('include')
    assert is_reserved_name('tags')
    assert is_reserved_name('roles')
    assert is_reserved_name('role_path')
    assert is_reserved_name('name')
    assert not is_reserved_name('not_a_reserved_name')

# Generated at 2022-06-23 15:28:23.955316
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('action')
    assert is_reserved_name('local_action')

    assert not is_reserved_name('bacon')

    # FIXME: remove after with_ is not only deprecated but removed
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')



# Generated at 2022-06-23 15:28:29.627142
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('role_path')
    assert not is_reserved_name('roles')
    assert is_reserved_name('with_items')
    assert is_reserved_name('include')
    assert is_reserved_name('roles')
    assert is_reserved_name('tags')
    assert not is_reserved_name('tags_custom')

# Generated at 2022-06-23 15:28:31.572730
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("name")
    assert not is_reserved_name("foobar")

# Generated at 2022-06-23 15:28:34.528630
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = ['vars']
    assert not warn_if_reserved(vars)
    vars.append('roles')
    assert warn_if_reserved(vars)

# Generated at 2022-06-23 15:28:39.062946
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_names = get_reserved_names()
    assert 'hosts' in test_names
    assert 'roles' in test_names
    assert 'action' in test_names
    assert 'local_action' in test_names
    assert 'connection' in test_names



# Generated at 2022-06-23 15:28:48.937441
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts_all')
    assert is_reserved_name('action')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('private_key_file')
    assert not is_reserved_name('aaa')
    assert not is_reserved_name('ambient')
    assert not is_reserved_name('amperized')
    assert not is_reserved_name('amateur')
    assert not is_reserved_name('amazed')
    assert not is_reserved_name('amaze')
    assert not is_reserved_name('amadavat')
    assert not is_reserved_name('amadavaty')

# Generated at 2022-06-23 15:28:54.353414
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('with_items')

    # extra sanity check
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')

# Generated at 2022-06-23 15:29:00.860292
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names()

    # valid variable names
    varnames = ['var', 'var123', 'var_localhost.localdomain_123']

    for var in varnames:
        warn_if_reserved(varnames)

    # variable name should not overlap with reserved name
    varnames = ['action', 'local_action']
    for var in varnames:
        warn_if_reserved(varnames)


# Generated at 2022-06-23 15:29:11.378394
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' Unit test for function warn_if_reserved '''
    from ansible.module_utils import basic

    # test an empty list
    for want in (None, set(), []):
        got = basic.warn_if_reserved(want)
        assert got == set()

    # test a list with no matching reserved names
    want = set(['test1', 'test2'])
    got = basic.warn_if_reserved(want)
    assert got == set()

    # test a list with matching reserved names
    want = set(['test1', 'test2', 'vars', 'name'])
    got = basic.warn_if_reserved(want)
    assert got == set(['vars', 'name'])


if __name__ == '__main__':
    import sys

# Generated at 2022-06-23 15:29:16.875943
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class foo:
        pass

    f = foo()
    f.a = 'b'
    f.c = 'd'
    warn_if_reserved(f.__dict__)

    f.__dict__['action'] = 'f'
    warn_if_reserved(f.__dict__)
    f.__dict__['loop'] = 'g'
    warn_if_reserved(f.__dict__)

# Generated at 2022-06-23 15:29:23.125990
# Unit test for function is_reserved_name
def test_is_reserved_name():
    '''
    reserved_names = get_reserved_names(include_private=True)
    for name in reserved_names:
        assert is_reserved_name(name)
    '''
    assert is_reserved_name('vars')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('environment')
    assert is_reserved_name('with_items')
    assert not is_reserved_name('this is not a reserved name')

# Generated at 2022-06-23 15:29:25.431905
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'hosts', 'hosts', 'hosts', 'hosts'])


# Generated at 2022-06-23 15:29:27.259062
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('hosts2')

# Generated at 2022-06-23 15:29:29.890762
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'fail_on_missing': True}) == None
    assert warn_if_reserved({'secret_var': 'password'}) == None


# Generated at 2022-06-23 15:29:34.097644
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'localhost' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'roles' in reserved_names
    assert 'any_errors_fatal' in reserved_names



# Generated at 2022-06-23 15:29:40.093385
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('vars')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('loop')
    assert is_reserved_name('name')
    assert not is_reserved_name('foo')
