

# Generated at 2022-06-23 15:19:48.715242
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert isinstance(result, set)
    assert 'become' in result
    assert 'include' in result

    result = get_reserved_names(False)
    assert isinstance(result, set)
    assert 'become' in result
    assert 'include' in result
    assert 'args' not in result

# Generated at 2022-06-23 15:19:54.131892
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['hosts', 'any_errors_fatal']
    with display.override_quiet():
        display.verbosity = 3
        warn_if_reserved(myvars)
        display.verbosity = 1
        warn_if_reserved(myvars)
        display.verbosity = 0
        warn_if_reserved(myvars)

# Generated at 2022-06-23 15:20:02.580523
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    import io

    stdout = sys.stdout
    test_out = io.StringIO()
    try:
        sys.stdout = test_out
        warn_if_reserved(['name', 'somethingelse'])
        assert test_out.getvalue() == u''
        warn_if_reserved(['name', 'somethingelse'], additional=['somethingelse'])
        assert test_out.getvalue() == u'Found variable using reserved name: somethingelse\n'
    finally:
        sys.stdout = stdout



# Generated at 2022-06-23 15:20:07.513377
# Unit test for function get_reserved_names
def test_get_reserved_names():
    pub = frozenset(get_reserved_names(include_private=False))
    assert 'name' in pub
    assert 'user' in pub

    pri = frozenset(get_reserved_names(include_private=True))
    assert 'name' in pri
    assert 'user' in pri
    assert '_raw_params' in pri
    assert 'environment' in pri
    assert 'ignore_errors' in pri



# Generated at 2022-06-23 15:20:18.024063
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    This will return result for warn_if_reserved function.
    '''
    myvars = dict()
    myvars['hosts'] = "hosts"
    myvars['roles'] = []
    myvars['tasks'] = []
    myvars['vars'] = []
    myvars['pre_tasks'] = []
    myvars['post_tasks'] = []
    myvars['handlers'] = []
    myvars['vars_files'] = []
    myvars['name'] = "ok"
    myvars['include'] = "include"
    myvars['import_playbook'] = "import_playbook"
    myvars['import_playbook'] = "import_playbook"
    myvars['block'] = []
   

# Generated at 2022-06-23 15:20:26.867885
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Tests are ordered as per order of declaration in code base
    # Tests assume that no attributes have been deprecated in code base
    # Tests assume that no attributes have been renamed in code base
    # Tests assume that no attributes have been added with reserved name

    # Test all public and private names
    result = get_reserved_names(True)
    assert 'name' in result
    assert 'connection' in result
    assert 'hosts' in result
    assert 'gather_facts' in result
    assert 'vars_prompt' in result
    assert 'vars_files' in result
    assert 'vars_files_encoding' in result
    assert 'vars_files_zipped' in result
    assert 'vars_files_dict' in result
    assert 'vars_files_dict_encrypted' in result

# Generated at 2022-06-23 15:20:33.509645
# Unit test for function get_reserved_names
def test_get_reserved_names():

    myvars = get_reserved_names()

# Generated at 2022-06-23 15:20:45.052258
# Unit test for function get_reserved_names
def test_get_reserved_names():
    my_reserved_names = get_reserved_names(include_private=False)

    cnfrm_reserved_public_names = frozenset(['any_errors_fatal', 'become_user', 'connection', 'delegate_to', 'environment',
                                             'gather_facts', 'get_url', 'gathering', 'group_by', 'hosts', 'ignore_errors',
                                             'import_playbook', 'include', 'include_role', 'local_action', 'notify',
                                             'register', 'roles', 'serial', 'strategy', 'sudo_user', 'sudo', 'tasks',
                                             'vars_files', 'vars_prompt', 'vars', 'when', 'with_'])

# Generated at 2022-06-23 15:20:51.848465
# Unit test for function get_reserved_names
def test_get_reserved_names():
    actual_result = get_reserved_names()
    assert actual_result is not None
    assert len(actual_result) > 0
    assert 'roles' in actual_result
    assert 'action' in actual_result
    assert 'gather_facts' in actual_result
    # assert 'name' in actual_result
    assert 'pre_tasks' in actual_result
    assert 'post_tasks' in actual_result
    assert 'task_include' in actual_result
    assert 'import_playbook' in actual_result


# Generated at 2022-06-23 15:20:54.427078
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ["vars", "hosts", "name", "foo"]

    # Should warn that name and hosts are reserved, but not vars and foo
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:21:01.352103
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:21:11.544583
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # Make sure it works for existing patterns
    display.deprecated = False
    display.deprecations = []
    display.warnings = []

    myvars = dict(hosts='webservers', action='reboot')
    warn_if_reserved(myvars)
    assert display.deprecations == []
    assert display.warnings == []

    # Make sure it works across multiple patterns
    display.deprecated = False
    display.deprecations = []
    display.warnings = []

    myvars = dict(hosts='webservers', action='reboot', include_tasks='httpd')
    warn_if_reserved(myvars)
    assert display.deprecations == []
    assert display.warnings == []

    # Make sure it works with no matches
    display.deprecated

# Generated at 2022-06-23 15:21:23.546964
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)
    assert len(reserved_names) > 1
    assert 'roles' in reserved_names
    assert 'register' in reserved_names
    assert 'name' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'block' in reserved_names
    assert 'no_log' in reserved_names
    assert 'include' in reserved_names
    assert 'include_vars' in reserved_names
    assert 'include_tasks' in reserved_names
    assert 'include_role' in reserved_names

    private_reserved_names = get_reserved_names(include_private=True)
    assert 'loop' in private_reserved_names

# Generated at 2022-06-23 15:21:24.973097
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host')


# Generated at 2022-06-23 15:21:36.354297
# Unit test for function is_reserved_name
def test_is_reserved_name():
    import os
    import sys
    import inspect

    # save display
    display_save = display.deprecate

    # disable display
    display.deprecate = lambda msg, version='': None


# Generated at 2022-06-23 15:21:38.930671
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    mydictionary = {'hosts': 'localhost', 'hostname': 'testhost'}
    display.verbosity = 4  # detect warnings
    warn_if_reserved(mydictionary)

# Generated at 2022-06-23 15:21:47.236508
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:21:49.969309
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    assert 'vars' in reserved_names
    assert 'action' in reserved_names
    assert 'private' not in reserved_names

# Generated at 2022-06-23 15:21:54.323873
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert {'action', 'connection', 'delegate_to', 'gather_facts', 'hosts', 'name', 'any_errors_fatal', 'remote_user', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'when', 'with_items', 'with_file', 'with_lines', 'with_together', 'with_dict', 'with_fileglob', 'with_sequence', 'vars', 'vars_files', 'roles', 'local_action', 'with_', 'loop'} == get_reserved_names()

# Generated at 2022-06-23 15:22:03.142651
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this function tests the warning printed by warn_if_reserved '''
    myvars = {'vars': {'name': 'my_name'}, 'hosts': 'all'}
    myvar2 = {'action': {'name': 'my_name'}, 'hosts': 'all'}
    myvar3 = {'hosts': 'all'}

    warn_if_reserved(myvars, ['action', 'hosts', 'vars'])
    warn_if_reserved(myvar2, ['action', 'hosts'])
    warn_if_reserved(myvar3)

# Generated at 2022-06-23 15:22:06.803316
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # assert 'hosts' in get_reserved_names()
    assert len(get_reserved_names()) > 50
    assert is_reserved_name('hosts')
    assert not is_reserved_name('xxx_hosts')
    assert not is_reserved_name('host')



# Generated at 2022-06-23 15:22:14.225320
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('role_name')
    assert is_reserved_name('private_key_file')
    assert is_reserved_name('private') is False
    assert is_reserved_name('tags')
    assert is_reserved_name('_name') is False
    assert is_reserved_name('name') is False
    assert is_reserved_name('not_a_reserved_name') is False

# Generated at 2022-06-23 15:22:23.862135
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    myvars = {'roles': 'foo', 'hosts': 'localhost', 'name': 'myhost', 'action': 'ping'}

    # test if we warn when we should
    try:
        warn_if_reserved(myvars)
    except:
        assert False, 'we should not get an exception here'

    # test if we do not warn when we should not
    try:
        warn_if_reserved(myvars, additional=['hosts'])
    except:
        assert False, 'we should not get an exception here'

    # test if we warn when we should
    try:
        warn_if_reserved(myvars, additional=['roles'])
        assert False, 'we should get an exception here'
    except:
        pass

# Generated at 2022-06-23 15:22:31.983484
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'hosts' in names
    assert 'roles' in names
    assert 'name' in names
    assert 'include_role' in names
    assert 'include' in names
    assert 'vars' in names
    assert 'tags' in names
    names = get_reserved_names(include_private=False)
    assert 'hosts' in names
    assert 'roles' in names
    assert 'name' in names
    assert 'include_role' in names
    assert 'include' in names
    assert 'vars' in names
    assert 'tags' in names
    assert 'local_action' in names
    assert 'with_' in names

# Generated at 2022-06-23 15:22:33.978954
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('flippy')

# Generated at 2022-06-23 15:22:41.844893
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:22:43.722046
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert 'action' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES

# Generated at 2022-06-23 15:22:48.035450
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(True)
    assert len(reserved_names) > 20

    reserved_names = get_reserved_names(False)
    assert len(reserved_names) > 15

# Generated at 2022-06-23 15:22:48.800103
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') == True

# Generated at 2022-06-23 15:22:51.118197
# Unit test for function get_reserved_names
def test_get_reserved_names():
    actual_result = get_reserved_names()
    assert 'hosts' in actual_result


# Unit test function warn_if_reserved

# Generated at 2022-06-23 15:22:53.394293
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'roles': [], 'vars': []})
    warn_if_reserved({'action': []})     # should warn

# Generated at 2022-06-23 15:23:01.259225
# Unit test for function is_reserved_name

# Generated at 2022-06-23 15:23:09.325454
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible import constants as C
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 5
    old_stdout = display.stdout
    try:
        display.stdout = C.DEFAULT_NULL_OUTPUT
        warn_if_reserved({'vars': 'anything'})
        warn_if_reserved({'vars': 'anything', 'debug': 'msg=foo'})
        warn_if_reserved({'playbook_dir': 'foo', 'playbook_file': 'bar'}, additional=['play_basedir', 'play_basedir'])
    finally:
        display.stdout = old_stdout



# Generated at 2022-06-23 15:23:18.955247
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_list = [u'action', u'any_errors_fatal', u'async', u'become',
                 u'become_user', u'block', u'changed_when', u'connection',
                 u'debug', u'delegate_to', u'environment', u'failed_when',
                 u'gather_facts', u'ignore_errors', u'include',
                 u'local_action', u'loop', u'loop_control', u'meta',
                 u'name', u'notify', u'no_log', u'register',
                 u'run_once', u'roles', u'tags', u'tasks',
                 u'terms', u'tags', u'vars', u'vars_files', u'when']

# Generated at 2022-06-23 15:23:30.119086
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected = {
        'action', 'async', 'become', 'become_user', 'become_flags', 'connection', 'delegate_to',
        'delay', 'environment', 'become_method', 'ignore_errors', 'local_action', 'loop',
        'poll', 'register', 'remote_user', 'serial', 'sudo', 'sudo_user', 'tags', 'until', 'when',
        'with_', 'with_items', 'when', 'block', 'rescue', 'always', 'otherwise', 'retries',
        'max_fail_percentage', 'ignore_unreachable', 'first_available_file', 'include', 'import_playbook'}
    assert get_reserved_names() == expected

# Generated at 2022-06-23 15:23:42.177510
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:23:45.146755
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # Create a special namespace for the test
    class namespace:
        pass

    myvars = namespace()
    myvars.tasks = namespace()
    myvars.tasks.action = 'logger foo'

    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:23:54.620471
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    vars = ['foo', 'hosts', 'roles', 'tasks']
    warn_if_reserved(vars)



# Generated at 2022-06-23 15:24:02.326557
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import unittest
    class TestWarnIfReserved(unittest.TestCase):
        def test_warn_if_reserved(self):
            # change to test display output here,
            # or replace with mock if it gets too complicated
            warn_if_reserved(dict(action='ping', host='localhost',
                                  local_action='ping', with_='items',
                                  loop='items', name='test',
                                  version=1, register='output',
                                  vars='vars'))
    unittest.main()


# Generated at 2022-06-23 15:24:08.674796
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('tasks')
    assert is_reserved_name('async')
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('tags')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('ignore_errors')
    assert not is_reserved_name('DONTIGNORE')
    assert not is_reserved_name('DONTIGNORE', additional=['DONTIGNORE'])
    assert is_reserved_name('DONTIGNORE', additional=[])

# Generated at 2022-06-23 15:24:09.956395
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) > 300

# Generated at 2022-06-23 15:24:12.759600
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert is_reserved_name('action')
    assert is_reserved_name('private')
    assert is_reserved_name('private')
    assert not is_reserved_name('xyz')



# Generated at 2022-06-23 15:24:13.502795
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')



# Generated at 2022-06-23 15:24:14.056500
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    warn_if_reserved({'meta'})

# Generated at 2022-06-23 15:24:19.324477
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class A(object):
        def __init__(self):
            self.name = 'test'
            self.test = 'test'
            self.something = 'test'
            self.test_test = 'test'
    a = A()
    warn_if_reserved(a.__dict__)



# Generated at 2022-06-23 15:24:27.290378
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This function has no side effects,
    so there is little that can be asserted.
    Instead, this is mostly a visual inspection.
    '''
    assert len(get_reserved_names(True)) == len(_RESERVED_NAMES)
    assert len(get_reserved_names(True)) == len(get_reserved_names(False))

    print('Private-only names:')
    for name in get_reserved_names(True).difference(get_reserved_names(False)):
        print('\t', name)

    print('Public-only names:')
    for name in get_reserved_names(False).difference(get_reserved_names(True)):
        print('\t', name)

# Generated at 2022-06-23 15:24:38.789200
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # using same role as in test_included_role
    # FIXME: internal role tests are probably not necessary and should be removed
    include_private = True
    reserved_names = get_reserved_names(include_private)
    # checks if all and only the names expected are reserved

# Generated at 2022-06-23 15:24:43.762802
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Arrange
    myvars = {
        'one': 1,
        'two': 2,
        'connection': 3,
        'vars': 4,
    }
    # Act
    warn_if_reserved(myvars)

    # Assert
    # Nothing to assert, this test is just checking that the function
    # doesn't raise an exception.

# Generated at 2022-06-23 15:24:48.002407
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # assert no warnings if valid variables are referenced
    warn_if_reserved(['hosts', 'vars', 'tasks'])
    display.clear_display()
    # assert warning if invalid variables are referenced
    warn_if_reserved(['burritos', 'with_items'])
    assert display.display.has_warnings()

# Generated at 2022-06-23 15:24:52.719531
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved_names = get_reserved_names()

    # Test all reserved names
    warn_if_reserved(reserved_names)

    # Test with an non reserved name
    warn_if_reserved(reserved_names + ['node'])

    # Test with an additional reserved name
    warn_if_reserved(reserved_names, ['node'])

    # Test with variable vars
    warn_if_reserved(reserved_names + ['vars'])

# Generated at 2022-06-23 15:24:54.024041
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('role')
    assert is_reserved_name('forks')

# Generated at 2022-06-23 15:24:56.852953
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for x in _RESERVED_NAMES:
        assert is_reserved_name(x)
        assert not is_reserved_name(x + '_extra')
    assert not is_reserved_name('__init__')
    assert is_reserved_name('no_log')

# Generated at 2022-06-23 15:24:57.472266
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()

# Generated at 2022-06-23 15:25:03.449004
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert (is_reserved_name('hosts'))
    assert (is_reserved_name('local_action'))
    assert (is_reserved_name('gather_facts'))
    assert (is_reserved_name('vars'))
    assert (is_reserved_name('roles'))
    assert (is_reserved_name('tasks'))

# Generated at 2022-06-23 15:25:13.351375
# Unit test for function is_reserved_name

# Generated at 2022-06-23 15:25:21.573176
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = ['action', 'any_errors_fatal', 'connection', 'delegate_to', 'environment', 'failed_when', 'ignore_errors', 'include', 'include_vars', 'loop', 'loop_control', 'name', 'notify', 'poll', 'register', 'retries', 'role', 'run_once', 'serial', 'tags', 'until', 'vars', 'when', 'with_', 'when', 'when']
    private_names = ['changed_when', 'local_action']
    assert get_reserved_names() == set(public_names + private_names)

# Generated at 2022-06-23 15:25:25.674809
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in ['name', 'roles', 'vars', 'meta', 'tasks']:
        assert is_reserved_name(name)
        assert not is_reserved_name('_' + name)
        assert not is_reserved_name(name + '_')

# Generated at 2022-06-23 15:25:29.720324
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = dict(name='Bob',
                  play=dict(roles=['common', 'web']),
                  tags=['web'],
                  when=5,
                  hosts='web',
                  connection='local')

    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:25:31.685608
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:25:36.950535
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # test with a bunch of reserved names...
    warn_if_reserved(['become', 'remote_user', 'roles'])
    # test with a reserved name...
    warn_if_reserved(['remote_user'])
    # test without any reserved names...
    warn_if_reserved(['unreserved_variable'])

# Generated at 2022-06-23 15:25:44.486277
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role

    # Calling warn_if_reserved with a variable that does not match
    # a reserved name does not cause a warning to be issued
    warn_if_reserved(['hello'])

    # Calling warn_if_reserved with a variable that matches
    # a reserved name causes a warning to be issued
    with display.override_output():
        warn_if_reserved(['with_items'])
        assert display.display._file.getvalue() == 'warning: Found variable using reserved name: with_items\n'
        warn_if_reserved(['become_user'])

# Generated at 2022-06-23 15:25:49.141197
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)
    assert 'name' in reserved_names
    assert 'private' in reserved_names
    assert 'private' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names(include_private=False)

# Generated at 2022-06-23 15:26:00.727317
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")
    assert is_reserved_name("tags")
    assert is_reserved_name("roles")
    assert is_reserved_name("name")
    assert is_reserved_name("failed_when")
    assert is_reserved_name("when")
    assert is_reserved_name("vars")
    assert is_reserved_name("delegate_to")
    assert is_reserved_name("gather_facts")
    assert is_reserved_name("local_action")
    assert is_reserved_name("with_")
    assert is_reserved_name("set_fact")
    assert is_reserved_name("block")
    assert is_reserved_name("ignore_errors")
    assert is_reserved_name("register")
   

# Generated at 2022-06-23 15:26:08.534266
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:18.855272
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode


# Generated at 2022-06-23 15:26:28.989539
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('debug')
    assert is_reserved_name('roles')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('from_yaml')
    assert is_reserved_name('from_json')
    assert is_reserved_name('from_task')
    assert is_reserved_name('task_includes')
    assert is_reserved_name('from_action')
    assert is_reserved_name('vars')
    assert is_reserved_name('task')
    assert is_reserved_name('block')
    assert is_reserved_name('notify')
    assert is_reserved_name('handler')

# Generated at 2022-06-23 15:26:36.958175
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    display = Display()
    display.display('test 1: action testing')
    warn_if_reserved(
        ['test', 'action'],
        additional=['action']
    )
    display.display('test 2: action, loop testing')
    warn_if_reserved(
        ['test', 'action', 'loop'],
        additional=['action', 'loop']
    )
    display.display('test 3: loop testing')
    warn_if_reserved(
        ['test', 'loop'],
        additional=['action', 'loop']
    )
    display.display('test 4: vars testing')
    warn_if_reserved(
        ['test', 'vars']
    )
    display.display('test 5: vars, with_ testing')
   

# Generated at 2022-06-23 15:26:39.449110
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()



# Generated at 2022-06-23 15:26:44.069181
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # Test normal, expected results
    assert is_reserved_name('gather_facts') is True

    # Test with the special case of 'vars'
    # 'vars' is a special case since it's not a reserved name for a play
    # but is a reserved keyword for templating
    assert is_reserved_name('vars') is False

# Generated at 2022-06-23 15:26:51.134257
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # FIXME: update when we move to pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.role import warn_if_reserved

    m = AnsibleModule(argument_spec=dict(context=dict(default={})))
    warn_if_reserved(m.params['context'], additional=set([]))
    warn_if_reserved(m.params['context'], additional=set(['_context']))


# unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:55.376664
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("name")
    assert is_reserved_name("any_errors_fatal")
    assert is_reserved_name("tags")
    assert is_reserved_name("register")
    assert is_reserved_name("notify")
    assert is_reserved_name("with_subelements")
    assert not is_reserved_name("foobar")

# Generated at 2022-06-23 15:26:58.651771
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' this test tests the function is_reserved_name() '''

    assert is_reserved_name('become')
    assert not is_reserved_name('meowmix')



# Generated at 2022-06-23 15:27:07.592308
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' This function will unit test the is_reserved_name function '''
    assert is_reserved_name('name')
    assert not is_reserved_name('rubbish')
    assert is_reserved_name('shell')
    assert is_reserved_name('action')
    assert is_reserved_name('playbook_dir')
    assert is_reserved_name('remote_user')
    assert not is_reserved_name('hosts')
    # some internal attributes we use for "vars:"
    assert is_reserved_name('_variable_manager')
    assert is_reserved_name('_loader')
    assert is_reserved_name('_host_count')
    assert is_reserved_name('runner_queue')
    assert is_reserved_name('stdout_callback')

# Generated at 2022-06-23 15:27:19.479196
# Unit test for function get_reserved_names
def test_get_reserved_names():
    foo = {'hosts', 'name', 'gather_facts', 'remote_user', 'su', 'su_user', 'sudo', 'sudo_user', 'become', 'become_user', 'become_method', 'connection', 'port', 'any_errors_fatal', 'serial', 'strategy', 'delegate_to', 'post_tasks', 'pre_tasks', 'roles', 'vars_files', 'vars_prompt', 'vars', 'handlers', 'tags', 'transport', 'notify', 'when', 'async', 'poll', 'notify_timeout_sec', 'environment', 'success_handler', 'failure_handler'}

# Generated at 2022-06-23 15:27:20.464126
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')


# Generated at 2022-06-23 15:27:23.896725
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # make sure the list is up-to-date
    assert len(_RESERVED_NAMES) > 10

    # check the function
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)
    assert not is_reserved_name("not a reserved name")

# Generated at 2022-06-23 15:27:29.690540
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert len(reserved_names) > 0

    # make sure the private names are around
    assert 'become' in reserved_names
    assert 'become_method' in reserved_names

    # make sure there are no dupes
    assert len(reserved_names) == len(set(reserved_names))

    # make sure there are no dupes when you ask public only
    public_only = get_reserved_names(include_private=False)
    assert len(public_only) == len(set(public_only))
    assert len(public_only) < len(reserved_names)



# Generated at 2022-06-23 15:27:36.251193
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    data = dict(
        one='boo',
        two='boo',
        three='boo',
        four='boo',
        five='boo',
        six='boo',
        seven='boo',
        eight='boo',
        nine='boo',
        ten='boo',
        eleven='boo',
        twelve='boo',
        thirteen='boo',
        fourteen='boo',
        fifteen='boo',
    )

    warn_if_reserved(data)

# Generated at 2022-06-23 15:27:47.232164
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Build the expected sets
    expected_public = set(['become',
                           'become_method',
                           'become_user',
                           'block',
                           'delegate_to',
                           'gather_facts',
                           'ignore_errors',
                           'local_action',
                           'loop',
                           'no_log',
                           'register',
                           'remote_user',
                           'sudo',
                           'sudo_user',
                           'tags',
                           'when',
                           'with_'])


# Generated at 2022-06-23 15:27:56.148095
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    This unit test is designed to exercise the get_reserved_names() function
    in the ansible.playbook.common module.

    This test will exercise both the private and public reserved names
    The correct result is the expected set of reserved words.

    :return:
    '''


# Generated at 2022-06-23 15:27:58.390016
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:28:04.730058
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # set for testing reserved names
    reserved_names = set(['name', 'hosts', 'gather_facts', 'roles', 'any_errors_fatal', 'serial', 'max_fail_percentage', 'remote_user', 'sudo', 'sudo_user', 'connection', 'tags', 'skip_tags', 'start_at_task', 'vars', 'vars_prompt', 'vars_files', 'delegate_to', 'register', 'environment', 'no_log', 'become', 'become_method', 'become_user', 'when', 'check_mode', 'transport', 'port', 'remote_addr', 'action', 'local_action', 'args', 'task_tags', 'loop', 'with_', 'items'])

    assert set(get_reserved_names()) == reserved_names

# Generated at 2022-06-23 15:28:13.738921
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test reserved names with private included
    reserved_names = list(get_reserved_names(include_private=True))

    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'with_items' in reserved_names
    assert 'include_role' in reserved_names
    assert 'loop' in reserved_names

    # Test reserved names without private included
    reserved_names = list(get_reserved_names(include_private=False))

    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names
    assert 'with_items' in reserved_names
    assert 'include_role' in reserved_names
    assert 'loop' not in reserved_names



# Generated at 2022-06-23 15:28:24.442211
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    assert isinstance(public, set), "Expected public to be a set, got %s" % type(public)
    assert 'name' in public, "Expected name in public. Got %s" % public
    assert 'roles' in public, "Expected roles in public. Got %s" % public
    assert not 'sudo' in public, "Did not expect sudo in public. Got %s" % public

    private = get_reserved_names(include_private=True)
    assert isinstance(private, set), "Expected private to be a set, got %s" % type(private)
    assert 'name' in private, "Expected name in private. Got %s" % private

# Generated at 2022-06-23 15:28:27.289214
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles') == True
    assert is_reserved_name('foobar') == False

# Generated at 2022-06-23 15:28:34.764435
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:28:38.634853
# Unit test for function get_reserved_names
def test_get_reserved_names():
    rsvd = get_reserved_names()
    assert 'roles' in rsvd
    assert 'hosts' in rsvd
    assert 'action' in rsvd
    assert 'vars' in rsvd
    assert 'name' in rsvd

# Generated at 2022-06-23 15:28:41.707381
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Create a test variable
    test_var = {
        'name': 1,
        'remote_user': 2,
        'vars': 3,
        'action': 4,
        'loop': 5,
        'private': 6
    }

    warn_if_reserved(test_var)
    assert True

# Generated at 2022-06-23 15:28:49.917461
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils.six import StringIO
    import sys

    # Test for name 'action' and 'local_action'
    myvars = {'localhost': {'action': 'ping', 'local_action': 'ping'}}
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        warn_if_reserved(myvars)
        output = out.getvalue().strip()
        assert output == 'Found variable using reserved name: action\nFound variable using reserved name: local_action'
    finally:
        sys.stdout = saved_stdout

    # Test for name 'loop' and 'with_'
    myvars = {'localhost': {'loop': 'ping', 'with_': 'ping'}}
    saved_stdout = sys

# Generated at 2022-06-23 15:28:52.086323
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert is_reserved_name('pre_tasks')
    assert not is_reserved_name('bad_name')

# Generated at 2022-06-23 15:28:58.027868
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == get_reserved_names(include_private=False)
    assert 'hosts' in get_reserved_names()
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names()
    assert 'local_action' not in get_reserved_names(include_private=False)
    assert 'name' in get_reserved_names(include_private=False)
    assert 'when' in get_reserved_names(include_private=False)
    assert 'with_items' in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names()



# Generated at 2022-06-23 15:29:09.167780
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:29:16.781588
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'roles' in get_reserved_names(include_private=False)
    assert 'vars' in get_reserved_names()
    assert 'vars' not in get_reserved_names(include_private=False)
    assert 'name' in get_reserved_names()
    assert 'name' not in get_reserved_names(include_private=False)



# Generated at 2022-06-23 15:29:18.309436
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True


# Generated at 2022-06-23 15:29:20.000600
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host')

# Generated at 2022-06-23 15:29:25.574019
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this is a test for warn_if_reserved '''
    warn_if_reserved(['vars'])
    warn_if_reserved(['vars', 'action'])
    warn_if_reserved(['vars', '_action'])
    warn_if_reserved(['vars', 'loop'])
    warn_if_reserved(['vars', '_loop'])
    warn_if_reserved(['vars', 'action_'])
    warn_if_reserved(['vars', 'loop_'])

# Generated at 2022-06-23 15:29:28.646772
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['hosts', 'action', 'loop', 'blarg']) == 'action'
    assert warn_if_reserved(['asdf', 'test']) == None


# Generated at 2022-06-23 15:29:40.341361
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.tests.unit.compat import unittest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class TestModuleArgs(object):
        def __init__(self):
            self.argument_spec = {}

    class TestAnsibleModule(basic.AnsibleModule):
        def __init__(self, argument_spec, **kwargs):
            super(TestAnsibleModule, self).__init__(argument_spec=argument_spec, **kwargs)

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.module = TestAnsibleModule(TestModuleArgs().argument_spec)

    reserved = get_reserved_names()

# Generated at 2022-06-23 15:29:41.275581
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True


# Generated at 2022-06-23 15:29:42.869510
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') == True
    assert is_reserved_name('asd') == False

# Generated at 2022-06-23 15:29:45.278432
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('ignore_unreachable')
    assert not is_reserved_name('test')
    assert not is_reserved_name('myvar')
    assert not is_reserved_name('private')