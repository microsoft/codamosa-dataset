

# Generated at 2022-06-23 15:19:49.168875
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # print("testing warn_if_reserved()")
    myvars = {
        "some_var": "some_value",
        "block": "some_value",
    }
    warn_if_reserved(myvars)
    myvars = get_reserved_names()
    myvars.add("some_var")
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:19:52.411507
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert is_reserved_name('action')
    assert is_reserved_name('private')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:20:03.685128
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('wait_for')
    assert is_reserved_name('loop')
    assert is_reserved_name('register')
    assert is_reserved_name('when')
    assert is_reserved_name('changed_when')
    assert is_reserved_name('failed_when')
    assert is_reserved_name('notify')
    assert is_reserved_name('ignore_errors')
    assert is_reserved_name('tags')
    assert not is_

# Generated at 2022-06-23 15:20:06.850314
# Unit test for function is_reserved_name
def test_is_reserved_name():
    result = is_reserved_name ("hosts")
    assert result == True


# Generated at 2022-06-23 15:20:16.916117
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils._text import to_text

    assert not is_reserved_name('random_junk')
    assert is_reserved_name('hosts')

    # mock return object for display.warning
    class MockReturn(object):
        def __init__(self):
            self.called = 0

        def __call__(self, msg):
            # Disgusting, but best way to get the warning message, since we
            # can't easily read it from stderr in a unit test
            if to_text(msg).startswith('Found variable using reserved name:'):
                self.called = self.called + 1

    mock_return = MockReturn()
    display.warning = mock_return

    myvars = {'hosts': 'junk'}

# Generated at 2022-06-23 15:20:17.942434
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')


# Generated at 2022-06-23 15:20:19.664863
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')

    assert not is_reserved_name('fake_key')

# Generated at 2022-06-23 15:20:30.637901
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' This function unit tests get_reserved_names'''
    from ansible.playbook import Play, Role, Block, Task

    reserved_names = get_reserved_names()

    for name in Play._attributes:
        if name not in reserved_names:
            assert False, '%s was not included in reserved_names for Play' % name

    for name in Role._attributes:
        if name not in reserved_names:
            assert False, '%s was not included in reserved_names for Role' % name

    for name in Block._attributes:
        if name not in reserved_names:
            assert False, '%s was not included in reserved_names for Block' % name


# Generated at 2022-06-23 15:20:32.168466
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from nose.plugins.skip import SkipTest
    raise SkipTest('test is not implemented')



# Generated at 2022-06-23 15:20:34.360262
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('any_errors_fatal') is False


# Generated at 2022-06-23 15:20:39.915935
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('private')
    assert is_reserved_name('vars')
    assert not is_reserved_name('private') and not is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')

# Generated at 2022-06-23 15:20:51.445394
# Unit test for function get_reserved_names
def test_get_reserved_names():

    class MyClass(object):
        _my_private_var = 'foo'
        my_public_var = 'bar'

    # Add some public and private vars to instance of MyClass and add it to _RESERVED_NAMES
    reserved_names = get_reserved_names()
    reserved_names.add('_my_private_var')
    reserved_names.add('my_public_var')

    # Check if all new reserved names are there
    assert '_my_private_var' in reserved_names
    assert 'my_public_var' in reserved_names

    # Check if we can pass '_my_private_var' and 'my_public_var' to warn_if_reserved
    myvars = MyClass()
    warn_if_reserved(myvars)

    # Check if we got

# Generated at 2022-06-23 15:20:57.007239
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    for name in reserved:
        if name in ['vars', 'with_', 'local_action']:
            pass
        else:
            assert '_' not in name, "%s has _ in name" % name
    assert 'any_errors_fatal' in reserved
    assert 'name' in reserved
    assert 'vars' in reserved
    assert 'with_' in reserved
    assert 'local_action' in reserved
    assert 'private' in reserved

# Generated at 2022-06-23 15:21:03.631780
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:21:11.606794
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Create the list of expected results
    expected_result = set()
    expected_result.add('name')
    expected_result.add('hosts')
    expected_result.add('gather_facts')
    expected_result.add('tasks')
    expected_result.add('handlers')
    expected_result.add('roles')
    expected_result.add('local_action')
    expected_result.add('with_')
    expected_result.add('vars_files')
    expected_result.add('vars_prompt')
    expected_result.add('vars')
    expected_result.add('any_errors_fatal')
    expected_result.add('serial')
    expected_result.add('notify')
    expected_result.add('environment')

# Generated at 2022-06-23 15:21:17.611829
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Ensure that at least one public reserved name exists in the list
    assert 'name' in get_reserved_names()

    # Ensure that at least one private reserved name exists in the list
    # FIXME: remove assert once with_ is not only deprecated but removed
    assert 'with_' in get_reserved_names(True)

# Generated at 2022-06-23 15:21:18.614556
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')


# Generated at 2022-06-23 15:21:25.488479
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved_names = get_reserved_names()

    assert all(name in reserved_names for name in ['name', 'action'])
    assert all(name in reserved_names for name in ['vars', 'private'])
    assert all(name in reserved_names for name in ['notify', 'block', 'pre_tasks'])

    reserved_names = get_reserved_names(include_private=False)
    assert 'private' not in reserved_names

    # local_action is implicit with action
    assert 'local_action' in reserved_names
    assert 'action' in reserved_names

    # loop implies with_
    assert 'loop' in reserved_names
    assert 'with_' in reserved_names


# Generated at 2022-06-23 15:21:33.201624
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('vars')
    assert is_reserved_name('include')
    assert is_reserved_name('tags')
    assert is_reserved_name('local_action')
    assert is_reserved_name('action')
    assert is_reserved_name('when')
    assert is_reserved_name('any_errors_fatal')
    assert not is_reserved_name('wat')


# Generated at 2022-06-23 15:21:36.003809
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest
    with pytest.raises(AssertionError):
        warn_if_reserved(['foo', 'action'])

# Generated at 2022-06-23 15:21:39.940252
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['action'])
    except:
        assert False, 'warn_if_reserved did not handle a reserved variable'

    try:
        warn_if_reserved(['not_reserved'])
    except:
        assert True, 'warn_if_reserved should not raise an exception for non-reserved'

# Generated at 2022-06-23 15:21:42.664948
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('loop')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('when')
    assert is_reserved_name('become')
    assert not is_reserved_name('junk')


# Unit test(s) for function get_attribute_names

# Generated at 2022-06-23 15:21:44.049480
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('private')
    assert not is_reserved_name('random_name')

# Generated at 2022-06-23 15:21:45.542465
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved((Play(),), additional=set(['foo', 'bar']))

# Generated at 2022-06-23 15:21:55.032379
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test that function warn_if_reserved behaves as expected

    # Create data
    myvars = ['fakeserver', 'playbook', 'play_hosts', 'play_name', 'inventory', 'included_file_name', 'included_file', 'strategy']
    expected_warnings = ['play_hosts', 'play_name', 'inventory', 'included_file_name', 'included_file']
    # Run function
    warn_if_reserved(myvars)
    # Check result
    assert display.warnings == expected_warnings, "warn_if_reserved does not produce the expected results"
    display.warnings = []

# Generated at 2022-06-23 15:22:05.788479
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names(True)
    assert 'hosts' in get_reserved_names(False)
    assert 'name' in get_reserved_names(True)
    assert 'name' in get_reserved_names(False)
    assert 'roles' in get_reserved_names(True)
    assert 'roles' in get_reserved_names(False)
    assert 'tasks' in get_reserved_names(True)
    assert 'tasks' in get_reserved_names(False)
    assert 'vars' in get_reserved_names(True)
    assert 'vars' in get_reserved_names(False)
    assert 'private' not in get_reserved_names(True)

# Generated at 2022-06-23 15:22:16.835696
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    class DummyVars(object):
        def __init__(self, vars_obj):
            self.vars_obj = vars_obj

        def get_vars(self):
            return self.vars_obj

    # Add two reserved names, they should be reported as warning
    warn_if_reserved(DummyVars({'action': 'foo',
                                'sudo': True}).get_vars(),
                     additional=set(['action', 'sudo']))

    # Add a regular name, no warning
    warn_if_reserved(DummyVars({'normal': 'foo'}).get_vars())

    # Add a special varname, no warning

# Generated at 2022-06-23 15:22:23.374362
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # get a set of public and private names
    reserved_names = get_reserved_names(include_private=False)
    reserved_names_private = get_reserved_names(include_private=True)

    # ensure private names are not returned without include_private
    assert(reserved_names.isdisjoint(reserved_names_private.difference(reserved_names)))

    # ensure that the sets are not empty
    assert (len(reserved_names) > 0)
    assert (len(reserved_names_private) > 0)

# Generated at 2022-06-23 15:22:30.800036
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('action')
    assert is_reserved_name('roles')
    assert is_reserved_name('register')
    assert is_reserved_name('tasks')
    assert is_reserved_name('vars')
    assert is_reserved_name('local_action')
    assert is_reserved_name('when')
    assert is_reserved_name('include_role')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('include')
    assert not is_reserved_name('my_var')

# Generated at 2022-06-23 15:22:40.590019
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # purpose of this test is just to ensure that the function
    # doesn't change the number of reserved names when it is
    # called.

    # Should be a set
    assert isinstance(_RESERVED_NAMES, frozenset)

    # Should not be empty
    assert len(_RESERVED_NAMES) > 0

    # Should contain some specific items
    assert 'playbook' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES

    # Test private names being included
    assert is_reserved_name('hosts')
    assert is_reserved_name('loop')
    assert is_reserved_name('block')

# Generated at 2022-06-23 15:22:48.418801
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Check we get a warning for a reserved word
    reserved_word = 'hosts'
    myvars = { 'x': 'y', reserved_word: 'whatever' }
    warn_if_reserved(myvars)
    # Check we don't get a warning for a reserved word when it's lower case
    reserved_word = 'hosts'
    myvars = { reserved_word: 'whatever' }
    warn_if_reserved(myvars)
    # Check we don't get a warning for a reserved word that is not present in the input
    reserved_word = 'hosts'
    myvars = { 'x': 'y' }
    warn_if_reserved(myvars)
    # Check that we don't get a warning for a reserved word when it's a vars entry

# Generated at 2022-06-23 15:22:49.744505
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'name', 'notify', 'with_foo'])

# Generated at 2022-06-23 15:22:55.073922
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Because the warning in this test is a display.warning,
    # it can never be called. An exception is raised in test_playbook
    # if the warning is not emitted since it's the only way to confirm
    # that the warning got called.
    if 'name' in _RESERVED_NAMES:
        warn_if_reserved(dict(name='foo'))

# Generated at 2022-06-23 15:23:02.056476
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert is_reserved_name('block')
    assert is_reserved_name('name')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('copy')


# Generated at 2022-06-23 15:23:12.398349
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    """
    Ensure that reserved names are detected as such.

    This only "works" if the warning message above has not changed
    If the functionality above changes, add a separate unit test.
    """
    from ansible.playbook.task import Task
    myplay = Play()
    myplay.vars = dict()

    myplay.vars['name'] = 'blah'
    myplay.vars['hosts'] = 'all'
    myplay.vars['user'] = 'root'
    myplay.vars['role'] = 'blah'

    mytask = Task()
    mytask._attributes = myplay.vars.keys()  # pylint: disable=protected-access
    mytask._load_vars(myplay)  # pylint: disable=protected-access

# Generated at 2022-06-23 15:23:19.749518
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'private' not in get_reserved_names()
    assert 'action' in get_reserved_names()
    assert 'loop' not in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'localhost' not in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'vars' not in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'import_playbook' not in get_reserved_names()


# Generated at 2022-06-23 15:23:31.468007
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' ensure we detect reserved names correctly '''
    import sys

    # This is a hack to get around the fact that the test framework
    # calls this file as a stand alone script, but in that case, we
    # can't get the correct object because we aren't being imported.
    # Since the test framework knows what we are doing, it should just
    # be setting a flag in the environment to tell us we are OK to
    # run this "as a script" without any errors.
    if 'ANSIBLE_TEST_UTILS_MODULE_RUNNING' not in os.environ:
        display.warning('You are trying to run the intrinsic tests for an Ansible module directly, this will not work.  Please use the test framework instead.')
        sys.exit(0)

    # Warn if a reserved names is found, and don't worry about the

# Generated at 2022-06-23 15:23:42.857716
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # get the list of reserved names to compare later
    reserved = _RESERVED_NAMES

    # test for expected results
    assert 'name' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'connection' in reserved
    assert 'remote_user' in reserved
    assert 'sudo' in reserved
    assert 'sudo_user' in reserved
    assert 'port' in reserved
    assert 'gather_facts' in reserved
    assert 'vars_files' in reserved
    assert 'vars' in reserved
    assert 'include' in reserved
    assert 'include_role' in reserved
    assert 'import_playbook' in reserved
    assert 'import_tasks' in reserved
    assert 'import_role' in reserved
    assert 'imports' in reserved
    assert 'pre_tasks'

# Generated at 2022-06-23 15:23:50.468081
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.executor.task_queue_manager import TaskQueueManager

    # We use the TaskQueueManager for testing here because it is a large class that we can assume uses all the reserved
    # names (as of this writing).
    test_dict = TaskQueueManager.define_module_params()

    test_dict['test'] = 123
    assert is_reserved_name('test') is True
    test_dict['test_any_name'] = 123
    assert is_reserved_name('test_any_name') is False

# Generated at 2022-06-23 15:23:56.112166
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # sanity check
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

    assert len(public) < len(private)

    assert 'gather_facts' in public
    assert 'action' in public
    assert 'vars' in public

    assert 'handlers' in private
    assert 'hosts' in private
    assert 'roles' in private



# Generated at 2022-06-23 15:23:58.648114
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['hosts', 'roles', 'roles_path']
    warn_if_reserved(myvars)


# Generated at 2022-06-23 15:24:00.879199
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host_list')



# Generated at 2022-06-23 15:24:11.491308
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'action' in get_reserved_names()
    assert 'changed_when' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names()
    assert 'notify' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'run_once' in get_reserved_names()
    assert 'until' in get_reserved_names()
    assert 'when' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'pause' in get_reserved_names()
    assert 'pause_for' in get_reserved_names()
    assert 'serial' in get_reserved_names()
    assert 'local_action' in get_reserved_names()

# Generated at 2022-06-23 15:24:16.650704
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)
    assert is_reserved_name('roles')
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('tags')

# Generated at 2022-06-23 15:24:18.807937
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['somevar', 'vars', 'with_something'])



# Generated at 2022-06-23 15:24:19.348574
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # TODO: write unit test
    return True

# Generated at 2022-06-23 15:24:23.939957
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['playbook', 'play', 'tasks', 'roles', 'hosts'])
    warn_if_reserved(['playbook', 'play', 'tasks', 'roles', 'hosts'], additional=set(['name']))
    warn_if_reserved(['playbook', 'play', 'tasks', 'roles', 'hosts', 'name'])



# Generated at 2022-06-23 15:24:26.775686
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['hosts'])
        raise AssertionError('this should have triggered a warning message')
    except AssertionError:
        raise
    except:
        pass

# Generated at 2022-06-23 15:24:38.633714
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import os
    import sys
    import json
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    display = Display()

    display.display('Testing Playbook/Reserved names...')

    filename = os.path.join(unfrackpath(os.path.dirname(__file__)), 'reserved_names.json')
    with open(filename) as data_file:
        sys.path.insert(0, unfrackpath(os.path.join(os.path.dirname(__file__), u'..', u'..')))
        private = frozenset(get_reserved_names(include_private=True))
        public = frozenset(get_reserved_names(include_private=False))

# Generated at 2022-06-23 15:24:39.422749
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # FIXME: not implemented
    pass

# Generated at 2022-06-23 15:24:40.436807
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') == True

# Generated at 2022-06-23 15:24:46.281438
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    global display

    display = Display()
    warn_if_reserved({'name': 'foo'})
    assert display.display.called_once
    display = Display()
    warn_if_reserved({'name': 'foo'}, additional=('name',))
    assert display.display.called_once
    display = Display()
    warn_if_reserved({'name': 'foo'}, additional=('foo',))
    assert not display.display.called

# Generated at 2022-06-23 15:24:49.517174
# Unit test for function get_reserved_names
def test_get_reserved_names():
    for reserved_name in _RESERVED_NAMES:
        assert reserved_name in get_reserved_names()

    for reserved_name in get_reserved_names(include_private=False):
        assert reserved_name not in get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:24:55.296252
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Arrange
    myvars = {'user': 'root', 'foo': 'bar', 'when': 'always', 'roles': 'foo'}
    # Act/Assert
    warn_if_reserved(myvars)



# Generated at 2022-06-23 15:25:04.138657
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:09.794577
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' returns some data to test reservered names '''
    reserved_names = get_reserved_names()
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'when' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'vars' not in reserved_names
    assert 'no_log' in reserved_names

# Generated at 2022-06-23 15:25:11.527100
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert isinstance(warn_if_reserved({'hosts': 'foobar'}), None)



# Generated at 2022-06-23 15:25:21.660725
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'tasks' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES
    assert 'include_tasks' in _RESERVED_NAMES
    assert 'include_role' in _RESERVED_NAMES
    assert 'include_vars' in _RESERVED_NAMES
    assert 'include' in _RESERVED_NAMES
    assert 'rescue' in _RESERVED_NAMES
    assert 'always' in _RESERVED_NAMES
    assert 'pre_tasks' in _RESERVED_NAMES
    assert 'post_tasks' in _RESERVED_NAMES

# Generated at 2022-06-23 15:25:28.535085
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Check a single reserved name
    assert is_reserved_name('hosts')
    # Negative test
    assert not is_reserved_name('foo')

    # Check a set of reserved names
    reserved_names = _RESERVED_NAMES
    assert is_reserved_name('hosts', reserved=reserved_names)
    assert is_reserved_name('action', reserved=reserved_names)
    assert not is_reserved_name('foo', reserved=reserved_names)

# Generated at 2022-06-23 15:25:33.269311
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test with a generic reserved name
    assert is_reserved_name('hosts')
    # Test with a private reserved name
    assert is_reserved_name('gather_facts')
    # Test with a non-reserved name
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:25:41.154617
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Expected result based on the current implementation
    name_list = ['any_errors_fatal', 'become', 'become_flags', 'become_method', 'become_user',
                 'block', 'block_args', 'connection', 'delegate_facts',
                 'gather_facts', 'name', 'post_tasks', 'pre_tasks', 'roles',
                 'serial', 'action', 'local_action', 'loop', 'with_']

    reserved_names = get_reserved_names()
    for name in name_list:
        assert(name in reserved_names)

    assert(len(reserved_names) == len(name_list))

# Generated at 2022-06-23 15:25:51.842785
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('block')
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('myvar')
    assert not is_reserved_name('roles_path')  # role_path is reserved, but roles_path is not, it's just a path
    assert not is_reserved_name('role_path')  # role_path is reserved, but roles_path is not, it's just a path
    assert not is_reserved_name('name')  # not reserved outside of a task

# Generated at 2022-06-23 15:25:53.844969
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' ensures deprecated attributes are warned '''
    warn_if_reserved(['loop', 'vars', 'other'])

# Generated at 2022-06-23 15:26:00.729822
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('tags')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('environment')
    assert is_reserved_name('roles')
    assert not is_reserved_name('foobar')
    assert not is_reserved_name('cloud_proxy')

# Generated at 2022-06-23 15:26:04.131553
# Unit test for function is_reserved_name
def test_is_reserved_name():
    global _RESERVED_NAMES
    for name in _RESERVED_NAMES:
        if not is_reserved_name(name):
            print("is_reserved_name() returned False for reserved name '{}'".format(name))
    for name in ['foo', 'with_items', 'action', 'vars', 'private']:
        if is_reserved_name(name):
            print("is_reserved_name() returned True for not-reserved name '{}'".format(name))


# Generated at 2022-06-23 15:26:07.847120
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_names = ['become', 'connection', 'delegate_to', 'environment', 'ignore_errors',
                  'local_action', 'tags', 'with_', 'block', 'block:rescue', 'block:always',
                  'registered_as', 'loop']

    for test_name in test_names:
        assert test_name in get_reserved_names(include_private=False)



# Generated at 2022-06-23 15:26:10.280227
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host')
    assert is_reserved_name('roles')

# Generated at 2022-06-23 15:26:19.594098
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' returns list of currently reserved names for play objects '''

    reserved = get_reserved_names()

    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'gather_facts' in reserved
    assert 'any_errors_fatal' in reserved
    assert 'become_user' in reserved
    assert 'async' in reserved
    # roles are special cases and not directly converted to vars
    assert 'pre_tasks' in reserved
    assert 'roles' in reserved
    assert 'tasks' in reserved
    assert 'post_tasks' in reserved
    assert 'vars' in reserved
    assert 'vars_files' in reserved
    assert 'delegate_to' in reserved
    assert 'run_once' in reserved
    assert 'connection' in reserved
    assert 'sudo' in reserved
   

# Generated at 2022-06-23 15:26:30.023313
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' Test that each reserved name is reported as such '''
    # list of known reserved names so we don't have to update test code

# Generated at 2022-06-23 15:26:37.454788
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:43.886394
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'vars', 'when', 'with_'])
    warn_if_reserved(['local_action'], additional=['local_action'])
    warn_if_reserved(['name', 'vars', 'when', 'with_'])
    warn_if_reserved(['action', 'vars', 'when', 'tags', 'with_'])
    warn_if_reserved(['action', 'vars', 'when', 'tags_', 'with_'])

# Generated at 2022-06-23 15:26:45.710001
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars') == False
    assert is_reserved_name('any_play_attribute') == True

# Generated at 2022-06-23 15:26:49.614333
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host')
    assert not is_reserved_name('host_aliases')

# Generated at 2022-06-23 15:26:54.969316
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected = {'when', 'connection', 'become_user', 'block', 'role_name', 'include_role', 'include_tasks', 'actions',
                'vars', 'register', 'ignore_errors', 'local_action', 'notify', 'role'}
    result = get_reserved_names(include_private=False)
    assert result == expected

    expected.add('delegate_to')
    result = get_reserved_names(include_private=True)
    assert result == expected

# Generated at 2022-06-23 15:27:03.998799
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('tasks')
    assert is_reserved_name('action')
    assert is_reserved_name('delegate_to')

    assert not is_reserved_name('myhosts')
    assert not is_reserved_name('myname')
    assert not is_reserved_name('mygather_facts')
    assert not is_reserved_name('mytasks')
    assert not is_reserved_name('myaction')
    assert not is_reserved_name('mydelegate_to')



# Generated at 2022-06-23 15:27:11.537885
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = frozenset(['hosts', 'roles', 'tasks', 'vars', 'pre_tasks', 'post_tasks', 'block', 'block', 'name', 'include', 'exclude', 'vars', 'vars_prompt', 'vars_files', 'vars_prompt', 'action', 'local_action', 'register', 'delegate_to', 'remote_user', 'ignore_errors', 'become', 'become_user', 'become_method', 'become_flags', 'check_mode', 'serial', 'with_', 'tags', 'run_once', 'connection', 'notify', 'only_if', 'delegate_facts', 'until', 'retries', 'delay'])
    assert sorted(get_reserved_names()) == sorted(reserved)  # we only care about the sorted

# Generated at 2022-06-23 15:27:20.623085
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    class FakeDisplay(object):
        def warning(*args, **kwargs):
            pass

    global display
    old_display = display

    try:
        display = FakeDisplay()

        warn_if_reserved({'hosts': 'foo'})
        warn_if_reserved({'hosts': 'foo', 'stranger': 'danger'})
        warn_if_reserved({'hosts': 'foo', 'stranger': 'danger', 'vars': 'bar'})
        warn_if_reserved({'stranger': 'danger', 'vars': 'bar'}, additional=set(['vars']))
    finally:
        display = old_display

# Generated at 2022-06-23 15:27:22.223839
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = set(get_reserved_names())
    assert reserved == _RESERVED_NAMES


# Generated at 2022-06-23 15:27:29.417962
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test_get_reserved_names '''

    # FIXME: this test is no longer useful, the class_list is hardcoded
    # this checks that we don't somehow loose reserved names from new play objects
    #public = set()
    #private = set()
    #result = set()
    #class_list = [Play, Role, Block, Task]

    #for aclass in class_list:
    #    aobj = aclass()
    #    for attribute in aobj.__dict__['_attributes']:
    #        if 'private' in attribute:
    #            private.add(attribute)
    #        else:
    #            public.add(attribute)
    #if 'action' in public:
    #    public.add('local_action')

    #if 'loop' in private or 'loop'

# Generated at 2022-06-23 15:27:30.318779
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:27:32.934483
# Unit test for function is_reserved_name
def test_is_reserved_name():
    name = 'hosts'
    assert is_reserved_name(name)==True
    name = 'host'
    assert is_reserved_name(name)==False

# Generated at 2022-06-23 15:27:42.022990
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from units.mock.loader import DictDataLoader

    loader = DictDataLoader({
        "foobar.yml": """
- hosts: all
  remote_user: test_user
  vars:
    dict_var:
      key1: value1
  tasks:
    - name: throw reserved warning
      command: echo {{ dict_var.func }}
      ignore_errors: True
""",
    })

    variable_manager = VariableManager()
    inventory = Host(name="foobar")

# Generated at 2022-06-23 15:27:47.227321
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Excluded variables for deprecated use.
    warn_if_reserved(['include'])
    warn_if_reserved(['register'])
    warn_if_reserved(['from_files'])
    warn_if_reserved(['from_vars'])
    warn_if_reserved(['loop'])
    warn_if_reserved(['run_once'])

# Generated at 2022-06-23 15:27:50.897235
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts_')  # technically this is allowed, but we made it reserved
    assert not is_reserved_name('host')
    assert not is_reserved_name('random_name')
    assert is_reserved_name('name')
    assert is_reserved_name('with_')
    assert is_reserved_name('_private_random_name')

# Generated at 2022-06-23 15:28:02.863629
# Unit test for function get_reserved_names
def test_get_reserved_names():

    def _assert(cond1, cond2, msg):
        if cond1 != cond2:
            raise AssertionError('%s: %s != %s' % (msg, cond1, cond2))


# Generated at 2022-06-23 15:28:11.915212
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test that reserved names are consistent with those in python classes
    reserved = get_reserved_names()
    assert 'hosts' in reserved
    assert 'name' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'connection' in reserved
    assert 'connection_plugins' in reserved
    assert 'any_errors_fatal' in reserved
    assert 'serial' in reserved
    assert 'gather_facts' in reserved
    assert 'delegate_to' in reserved
    assert 'sudo' in reserved
    assert 'sudo_user' in reserved
    assert 'become' in reserved
    assert 'become_user' in reserved
    assert 'become_method' in reserved
    assert 'async' in reserved
    assert 'poll' in reserved
    assert 'ignore_errors' in reserved

# Generated at 2022-06-23 15:28:15.640255
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars1 = dict(hosts='localhost', name='localhost')
    warn_if_reserved(vars1.keys())

# Generated at 2022-06-23 15:28:25.816212
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts', 'gather_facts'])
    warn_if_reserved(['hosts', 'gather_facts', 'roles'])
    warn_if_reserved(['hosts', 'gather_facts', 'roles', 'post_tasks'])
    warn_if_reserved(['hosts', 'gather_facts', 'roles', 'pre_tasks'])
    warn_if_reserved(['hosts', 'gather_facts', 'roles', 'include'])
    warn_if_reserved(['hosts', 'gather_facts', 'roles', 'tasks'])
    warn_if_reserved(['hosts', 'gather_facts', 'roles', 'vars'])

# Generated at 2022-06-23 15:28:29.922220
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = get_reserved_names()
    for res in reserved_names:
        assert is_reserved_name(res)
    for res in ('reserved', 'baz'):
        assert not is_reserved_name(res)

# Generated at 2022-06-23 15:28:40.962009
# Unit test for function is_reserved_name
def test_is_reserved_name():
    import unittest
    class TestIsReservedName(unittest.TestCase):
        ''' Unit tests for function is_reserved_name '''
        def setUp(self):

            class FakeModule(object):
                ''' dummy class to simulate an ansible module '''
                def __init__(self, params):
                    self.params = params

            self.fake_module = FakeModule({})

        def test_output_one(self):
            ''' test for failure if output is specified '''
            self.fake_module.params['output'] = 'something'
            self.assertTrue(is_reserved_name('output'))

        def test_output_two(self):
            ''' test for success if output is not specified '''
            self.assertFalse(is_reserved_name('output'))


# Generated at 2022-06-23 15:28:42.441989
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['hosts', 'vars', 'user', 'roles']) is None

# Generated at 2022-06-23 15:28:49.343088
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names(include_private=False)
    warn_if_reserved(reserved)

    # with_ should raise a warning now
    with_names = ['with_%s' % name for name in reserved]
    warn_if_reserved(with_names)

    # loop should not raise a warning now
    loop_names = ['loop_%s' % name for name in reserved]
    warn_if_reserved(loop_names)

    # local_action should raise a warning now
    local_action_names = ['local_action_%s' % name for name in reserved]
    warn_if_reserved(local_action_names)

# Generated at 2022-06-23 15:28:51.602131
# Unit test for function is_reserved_name
def test_is_reserved_name():
    print('Testing function is_reserved_name')
    assert is_reserved_name('block')
    assert not is_reserved_name('not_a_reserved_name')



# Generated at 2022-06-23 15:28:53.443123
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('user') == True
    assert is_reserved_name('root') == False

# Generated at 2022-06-23 15:28:55.303799
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('pre_tasks')
    assert not is_reserved_name('delegated_to')



# Generated at 2022-06-23 15:29:06.598041
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # 1. test with include_private=True
    # 1.1 no class should return attribute
    assert get_reserved_names(include_private=True) == set()
    # 1.2 all class should return attribute
    class_list = [Play, Role, Block, Task]
    class_attr = set()
    for aclass in class_list:
        aobj = aclass()
        for attribute in aobj.__dict__['_attributes']:
            class_attr.add(attribute)
    # find attributes in Task are also in Private Attrs of Role
    for attribute in Task.__dict__['_attributes']:
        if attribute in Role.__dict__['_attributes']:
            class_attr.discard(attribute)
    assert get_reserved_names(include_private=True) == class_attr


# Generated at 2022-06-23 15:29:13.694086
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Verify that get_reserved_names returns all reserved names in the public API
    public_reserved = get_reserved_names(include_private=False)
    for tested_name in _RESERVED_NAMES:
        assert tested_name in public_reserved
    # Verify that get_reserved_names returns an empty set when private names are set to False
    assert get_reserved_names(include_private=False) == public_reserved
    assert get_reserved_names(include_private=False) != get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:29:23.206148
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts': 'not_a_list'})
    warn_if_reserved({'name': 'not_a_list'})
    warn_if_reserved({'vars': 'not_a_list'})
    warn_if_reserved({'include_vars': 'not_a_list'})
    warn_if_reserved({'action': 'not_a_list'})
    warn_if_reserved({'local_action': 'not_a_list'})
    warn_if_reserved({'loop': 'not_a_list'})
    warn_if_reserved({'with_': 'not_a_list'})

    # these two are generally just noise
    display.verbosity = 3

# Generated at 2022-06-23 15:29:24.554199
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'roles' in get_reserved_names()



# Generated at 2022-06-23 15:29:36.114939
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('actions')
    assert is_reserved_name('connection')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('gather_fact')
    assert is_reserved_name('name')
    assert not is_reserved_name('names')
    assert is_reserved_name('role_name')
    assert not is_reserved_name('role')
    assert not is_reserved_name('roles')
    assert is_reserved_name('sudo_user')
    assert not is_reserved_name('sudouser')
    assert is_reserved_name('sudo')
    assert not is_reserved_

# Generated at 2022-06-23 15:29:43.237026
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # print ( get_reserved_names(True) )
    # print ( get_reserved_names(False) )

    assert 'hosts' in get_reserved_names(True)
    assert 'hosts' in get_reserved_names(False)
    assert 'name' in get_reserved_names(True)
    assert 'name' in get_reserved_names(False)
    assert 'roles' not in get_reserved_names(False)
    assert 'roles' in get_reserved_names(True)