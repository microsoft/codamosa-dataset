

# Generated at 2022-06-23 15:19:42.220423
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    for name in sorted(get_reserved_names(include_private=False)):
        assert is_reserved_name(name)
    assert not is_reserved_name('not a reserved name')

# Generated at 2022-06-23 15:19:53.179204
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class FakeDisplay:
        def __init__(self):
            self.warned = False

        def warning(self, msg):
            self.warned = True

    test_display = FakeDisplay()

    # No warnings for empty variables
    warn_if_reserved({}, test_display)
    assert(test_display.warned is False)

    # Display warning for each reserved name
    for name in _RESERVED_NAMES:
        test_display.warned = False
        warn_if_reserved({name}, test_display)
        assert(test_display.warned is True)

    # No warning for non-reserved name
    test_display.warned = False
    warn_if_reserved({'myvar'}, test_display)
    assert(test_display.warned is False)

    #

# Generated at 2022-06-23 15:20:01.277259
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'action': "", 'local_action': ""}) == None
    assert warn_if_reserved({'loop': ""}) == None
    assert warn_if_reserved({'with_': ""}) == None
    assert warn_if_reserved({'delegate_to': "",
                             'delegate_facts': "",
                             'register': "",
                             'run_once': "",
                             'any_errors_fatal': "",
                             'ignore_errors': "",
                             'serial': "",
                             'first_available_file': "",
                             'until': "",
                             'retries': "",
                             'delay': "",
                             'environment': ""
                             }) == None

# Generated at 2022-06-23 15:20:09.451448
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:20:15.622695
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # given a set of reserved names and a set to test
    reserved_names = set(['action', 'roles'])
    vars = set(['action', 'roles', 'always_run', 'foo'])
    test_set = set([])
    result_set = set(['action', 'roles'])

    # when warn_if_reserved is called
    warn_if_reserved(vars, additional=reserved_names)

    # then
    assert test_set == result_set

# Generated at 2022-06-23 15:20:20.243747
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts_all')
    assert not is_reserved_name('my_hosts')
    assert not is_reserved_name('my_hosts_all')
    assert is_reserved_name('name')
    assert is_reserved_name('vars')
    assert not is_reserved_name('var')
    assert not is_reserved_name('name_')
    assert not is_reserved_name('_vars')

# Generated at 2022-06-23 15:20:31.129177
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('name')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('ignore_errors')
    assert is_reserved_name('name')
    assert is_reserved_name('connection')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('when')
    assert is_reserved_name('become')
    assert is_reserved_name('become_user')
    assert is_reserved_name('become_method')
    assert is_reserved_name('become_flags')
    assert is_reserved_name('tags')

# Generated at 2022-06-23 15:20:37.746139
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('debug')
    assert is_reserved_name('include')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('fail_when')
    assert is_reserved_name('roles')
    assert not is_reserved_name('cheese')
    assert not is_reserved_name('var_files')
    assert not is_reserved_name('vars')
    assert not is_reserved_name('inventory')


__all__ = ['warn_if_reserved']

# Generated at 2022-06-23 15:20:39.648277
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = {'activity': 'test'}
    additional = {'connection'}
    warn_if_reserved(myvars, additional=additional)



# Generated at 2022-06-23 15:20:46.278901
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('loop')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:20:47.717451
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert not warn_if_reserved({})  # no warnings



# Generated at 2022-06-23 15:20:53.312551
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('connection')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('private')
    assert is_reserved_name('tags')



# Generated at 2022-06-23 15:21:00.676788
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('action')
    assert is_reserved_name('loop')
    assert is_reserved_name('name')
    assert is_reserved_name('async_status_poll')
    assert is_reserved_name('handlers')
    assert is_reserved_name('hosts')
    assert is_reserved_name('user')
    assert is_reserved_name('gather_subset')
    assert is_reserved_name('vars_files')
    assert is_reserved_name('vars_prompt')

# Generated at 2022-06-23 15:21:05.116490
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('private')
    assert not is_reserved_name('notprivate')
    assert not is_reserved_name('not_a_reserved_name')



# Generated at 2022-06-23 15:21:06.760843
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') is True
    assert is_reserved_name('foo') is False



# Generated at 2022-06-23 15:21:14.542209
# Unit test for function warn_if_reserved

# Generated at 2022-06-23 15:21:20.556499
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('become')
    assert is_reserved_name('name')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('foo')


# Generated at 2022-06-23 15:21:22.702484
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = [ 'foo', 'with_', 'vars', 'action', 'local_action' ]
    warn_if_reserved(myvars)


# Generated at 2022-06-23 15:21:25.388345
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert len(reserved_names) > 10

    # check is_reserved_name against get_reserved_names
    assert not is_reserved_name('foo')
    assert is_reserved_name('roles')

# Generated at 2022-06-23 15:21:36.637722
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test the function get_reserved_names() '''

    public_reserved_names = frozenset(get_reserved_names(include_private=False))
    private_reserved_names = frozenset(get_reserved_names(include_private=True))

    assert len(public_reserved_names) == 45
    assert len(private_reserved_names) == 114

    assert 'name' in public_reserved_names
    assert 'name' in private_reserved_names

    assert 'action' in public_reserved_names
    assert 'action' in private_reserved_names

    assert 'local_action' in private_reserved_names
    assert 'local_action' not in public_reserved_names

    assert 'with_' in private_reserved_names
    assert 'with_'

# Generated at 2022-06-23 15:21:46.029756
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts_all')
    assert is_reserved_name('host_all')
    assert is_reserved_name('host_pattern')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('name')
    assert is_reserved_name('vars')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('connection')
    assert is_reserved_name('no_log')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('serial')
    assert is_reserved_name('sudo')
    assert is_reserved_name('sudo_user')
    assert is_reserved_name

# Generated at 2022-06-23 15:21:52.605211
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test the function get_reserved_names with default args
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'roles' in reserved_names
    assert 'handlers' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'tasks' in reserved_names
    assert 'hosts' in reserved_names
    assert 'vars' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'gather_facts_task' in reserved_names
    assert 'serial' in reserved_names
    assert 'transport' in reserved_names
    assert 'gather_facts' in reserved_names
    assert 'tags' in reserved_names
    assert 'include_vars'

# Generated at 2022-06-23 15:21:54.692179
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    n = AnsibleUnicode('hosts')
    assert is_reserved_name(n)

# Generated at 2022-06-23 15:22:05.557029
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = frozenset([
        'gather_facts',
        'hosts',
        'name',
        'post_tasks',
        'pre_tasks',
        'roles',
        'serial',
        'tags',
        'tasks',
        'action',
        'block',
        'always',
        'delegate_to',
        'delegate_facts',
        'local_action',
        'with_',
        'when',
        'notify',
        'register'
    ])
    private = frozenset([
        'loop',
        'index',
        'ignore_errors',
        'meta'
    ])
    result = frozenset(get_reserved_names(include_private=True))
    assert result == public.union(private)

    result = frozenset

# Generated at 2022-06-23 15:22:12.568435
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(_RESERVED_NAMES == frozenset(
        ['any_errors_fatal', 'become', 'become_flags', 'become_method', 'connection', 'delegate_to', 'hosts', 'name',
         'roles', 'register', 'remote_user', 'serial', 'sudo', 'sudo_flags', 'sudo_user', 'tasks', 'transport',
         'vars', 'vars_files', 'block', 'local_action', 'with_', 'tags']))

# Generated at 2022-06-23 15:22:13.961884
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:22:16.056312
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert not warn_if_reserved(['priorities'])
    assert warn_if_reserved(['hosts'])

# Generated at 2022-06-23 15:22:18.708009
# Unit test for function get_reserved_names
def test_get_reserved_names():
    testclass = TestClass()
    testclass.test_get_reserved_names()


# Generated at 2022-06-23 15:22:27.488601
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved = get_reserved_names()
    print("Reserved names: " + str(reserved))
    assert is_reserved_name("name") == True
    assert is_reserved_name("namo") == False
    assert is_reserved_name("action") == True
    assert is_reserved_name("ac_tion") == False
    assert is_reserved_name("role_path") == True
    assert is_reserved_name("role_pat") == False
    assert is_reserved_name("when") == True
    assert is_reserved_name("whe") == False
    # this one is implicit
    assert is_reserved_name("local_action") == True
    # this one is implicit
    assert is_reserved_name("with_") == True


# Generated at 2022-06-23 15:22:32.064589
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # We need to reset in case other tests were run before this one.
    display.verbosity = 0
    display.deprecation = 0
    display.columns = 80
    display.warnings = []

    warn_if_reserved([u'action'], None)
    assert len(display.warnings) == 1
    assert display.warnings[0] == u'Found variable using reserved name: action'

    # TODO: Add additional tests for all the reserved names, but need to fix
    # the display.warnings warning format to make the string matchable.

# Generated at 2022-06-23 15:22:38.182935
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(set(['name', 'roles', 'block']))
    warn_if_reserved(set(['name', 'roles', 'tasks']))
    warn_if_reserved(set(['name', 'hosts', 'tasks']))
    warn_if_reserved(set(['name', 'hosts', 'block']))
    warn_if_reserved(set(['roles', 'hosts', 'block']))

# Generated at 2022-06-23 15:22:39.618552
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test all names
    reserved_all = get_reserved_names()
    assert len(reserved_all) > 0

    # test only public
    reserved_public = get_reserved_names(include_private=False)
    assert reserved_all >= reserved_public

# Generated at 2022-06-23 15:22:49.514681
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import unittest

    class TestWarnIfReserved(unittest.TestCase):
        def setUp(self):
            self.reserved = set()
            for attr in dir(self):
                if attr.startswith('test_') and hasattr(self, attr):
                    self.reserved.add(attr[5:])

        def test_non_reserved_name(self):
            warn_if_reserved(['playbook'], self.reserved)

        def test_reserved_name(self):
            warn_if_reserved(['playbook', 'name'], self.reserved)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestWarnIfReserved)

# Generated at 2022-06-23 15:22:59.127590
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # Test invalid cases
    assert not is_reserved_name('foo')
    assert not is_reserved_name('bar')
    assert not is_reserved_name('baz')

    # Test valid cases
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('private')
    assert is_reserved_name('vars')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('include_role')

# Generated at 2022-06-23 15:23:08.893974
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert len(get_reserved_names()) > 50
    assert 'hosts' in get_reserved_names()
    assert 'hosts' in get_reserved_names(include_private=True)
    assert 'delegate_to' in get_reserved_names()
    assert 'delegate_to' in get_reserved_names(include_private=True)
    assert 'private' not in get_reserved_names()
    assert 'private' in get_reserved_names(include_private=True)
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names(include_private=True)
    assert 'with_' in get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:23:14.845996
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' Unit tests for function is_reserved_name '''

    assert(is_reserved_name('action'))
    assert(is_reserved_name('hosts'))
    assert(is_reserved_name('with_items'))
    assert(is_reserved_name('_raw_params'))
    assert(is_reserved_name('_remove_candidate_items'))

    assert(not is_reserved_name('foobar'))
    assert(not is_reserved_name('__privatename__'))
    assert(not is_reserved_name('myname'))



# Generated at 2022-06-23 15:23:16.629204
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)
    assert isinstance(get_reserved_names(include_private=False), set)

# Generated at 2022-06-23 15:23:23.386917
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') is False
    assert is_reserved_name('roles') is True
    assert is_reserved_name('tasks') is True
    assert is_reserved_name('included_tasks') is True
    assert is_reserved_name('role_path') is True
    assert is_reserved_name('playbook_dir') is True
    assert is_reserved_name('post_tasks') is True
    assert is_reserved_name('pre_tasks') is True
    assert is_reserved_name('when') is True
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('remote_user') is True
    assert is_reserved_name('connection') is True

# Generated at 2022-06-23 15:23:26.136237
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)

    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert is_reserved_name('local_action')

    assert not is_reserved_name('name')
    assert not is_reserved_name('asdfs')


# Generated at 2022-06-23 15:23:32.095628
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("tasks")
    assert is_reserved_name("roles")
    assert is_reserved_name("include")
    assert is_reserved_name("name")
    assert is_reserved_name("any_errors_fatal")
    assert is_reserved_name("remote_user")
    assert is_reserved_name("post_validate")



# Generated at 2022-06-23 15:23:43.339222
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # We expect to get a list of all the reserved names.
    # We should not need to change this list if new reserved names are added, the
    # test should pass with the new list. The list should not be shortened
    # without a good reason. If this test fails, make sure it is supposed to fail
    # due to a change in reserved names, and not a bug!

    res = get_reserved_names()

# Generated at 2022-06-23 15:23:47.814013
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host')
    assert not is_reserved_name('ansible')

# Generated at 2022-06-23 15:23:57.501790
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'action' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'async_val' in get_reserved_names()
    assert 'delay' in get_reserved_names()
    assert 'run_once' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'always_run' in get_reserved_names()
    assert 'changed_when' in get_reserved_names()
    assert 'failed_when' in get_reserved_names()
    assert 'register' in get_reserved_names()
    assert 'ignore_errors' in get_reserved_names()
    assert 'environment' in get_reserved_names()
   

# Generated at 2022-06-23 15:24:06.336595
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = set(['hosts', 'roles', 'remote_user', 'any_errors_fatal', 'any_errors_fatal', 'serial', 'action', 'loop',
                'local_action', 'with_succeed_on_changed', 'sudo', 'sudo_user', 'become', 'become_user', 'tags',
                'when', 'run_once', 'connection', 'vars', 'async', 'poll', 'register', 'ignore_errors', 'always_run',
                'delegate_to', 'become_method', 'become_flags', 'environment', 'transport', 'remote_tmp'])
    assert not warn_if_reserved(vars)

# Generated at 2022-06-23 15:24:08.143394
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['roles', 'name', 'myvar'])

# Generated at 2022-06-23 15:24:13.870895
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('when')
    assert is_reserved_name('notify')
    assert is_reserved_name('rescue')
    assert not is_reserved_name('foobar')


# Generated at 2022-06-23 15:24:18.763664
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import mock
    import sys

    sys.modules['ansible.utils.display'] = mock.MagicMock()
    warn_if_reserved(['vars', 'failed_when'])
    assert sys.modules['ansible.utils.display'].warning.call_count == 1

# Generated at 2022-06-23 15:24:20.356703
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') == True
    assert is_reserved_name('local_action') == True
    assert is_reserved_name('with_') == True
    assert is_reserved_name('invalid') == False

# Generated at 2022-06-23 15:24:23.905021
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # It is expected that this function will warn if any of the reserved
    # names are used as a variable name.
    warn_if_reserved(['hosts'])
    # Warnings from warn_if_reserved are printed to stdout, and interfere
    # with the normal stdout of unit tests.

# Generated at 2022-06-23 15:24:27.445760
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test function warn_if_reserved '''
    import mock

    # Case 1: no warning raised if no reserved varnames
    assert(warn_if_reserved({'vars': 'foo'}) is None)

    # Case 2: warning raised
    with mock.patch('ansible.playbook.name_utils.display.warning') as mw:
        warn_if_reserved({'vars': 'foo', 'action': 'bar'})
        assert(mw.call_count == 1)

# Generated at 2022-06-23 15:24:32.661139
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name("hosts")
    assert is_reserved_name("name")
    assert is_reserved_name("roles")
    assert is_reserved_name("vars")
    assert not is_reserved_name("foobar")
    assert not is_reserved_name("foo_bar")


# Generated at 2022-06-23 15:24:37.751309
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert 'hosts' in _RESERVED_NAMES
    assert 'hosts' == get_reserved_names().pop()
    assert get_reserved_names().pop() == 'hosts'
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host')

# Generated at 2022-06-23 15:24:47.294019
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('user') is True
    assert is_reserved_name('gather_facts') is True
    assert is_reserved_name('vars') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('tasks') is True
    assert is_reserved_name('pre_tasks') is True
    assert is_reserved_name('post_tasks') is True
    assert is_reserved_name('become') is True
    assert is_reserved_name('become_user') is True
    assert is_reserved_name('become_method') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('always')

# Generated at 2022-06-23 15:24:59.088403
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('vars'))
    assert(is_reserved_name('hosts'))
    assert(is_reserved_name('name'))
    assert(is_reserved_name('action'))
    assert(is_reserved_name('local_action'))
    assert(is_reserved_name('tasks'))
    assert(is_reserved_name('handlers'))
    assert(is_reserved_name('roles'))
    assert(is_reserved_name('pre_tasks'))
    assert(is_reserved_name('post_tasks'))
    assert(is_reserved_name('block'))
    assert(is_reserved_name('include_role'))
    assert(is_reserved_name('import_role'))


# Generated at 2022-06-23 15:25:06.646867
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('playbook')
    assert is_reserved_name('block')
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('local_action')
    assert not is_reserved_name('with_')
    assert not is_reserved_name('with_dict')
    assert is_reserved_name('hostvars')
    assert is_reserved_name('omit')
    assert is_reserved_name('priority')
    assert is_reserved_name('tags')
    assert is_reserved_name('until')
    assert is_reserved_name('when')
    assert is_reserved_name('roles')

# Generated at 2022-06-23 15:25:16.287430
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['roles'])
    except SystemExit:
        pass

    try:
        warn_if_reserved(['hosts'])
    except SystemExit:
        pass

    try:
        warn_if_reserved(['action'])
    except SystemExit:
        pass

    try:
        warn_if_reserved(['vars'])
    except SystemExit:
        raise Exception('Failed on vars')

    try:
        warn_if_reserved(['vars', 'roles'])
    except SystemExit:
        pass

    try:
        warn_if_reserved(['vars', 'hosts'])
    except SystemExit:
        pass


# Generated at 2022-06-23 15:25:25.527809
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:36.800536
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:48.505731
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils.six import StringIO
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.utils.display import Display
    from test.units.compat import unittest

    class TestDisplay(Display):

        def __init__(self):
            self._display_messages = []

        def warning(self, msg):
            self._display_messages.append(msg)
    display = TestDisplay()

    class TestPlay(Play):

        def __init__(self):
            super(TestPlay, self).__init__()
            self.myvar = 'myvalue'


# Generated at 2022-06-23 15:25:51.343053
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('block')
    assert is_reserved_name('delegate_to')
    assert not is_reserved_name('hosts')
    assert not is_reserved_name('tasks')

# Generated at 2022-06-23 15:25:58.288082
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test lowercase name
    assert is_reserved_name('name')
    assert not is_reserved_name('role_name')

    # Test uppercase name
    assert is_reserved_name('NAMe')
    assert not is_reserved_name('role_NAMe')

    # Test mixed case name
    assert is_reserved_name('NaMe')
    assert not is_reserved_name('role_NaMe')

# Generated at 2022-06-23 15:26:03.136352
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('no_log')
    assert not is_reserved_name('vars')
    assert not is_reserved_name('dont_log')

# Generated at 2022-06-23 15:26:05.079059
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('do_not_reserve_me')

# Generated at 2022-06-23 15:26:07.333319
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'vars'])
    warn_if_reserved(['notify'])  # FIXME: should fail
    warn_if_reserved(['any_junk'])  # this should not print out a warning

# Generated at 2022-06-23 15:26:18.144411
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('gather_subset')
    assert is_reserved_name('roles')
    assert is_reserved_name('tags')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('task')
    assert is_reserved_name('tasks')
    assert is_reserved_name('block')
    assert is_reserved_name('block')
    assert is_reserved_name('name')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
   

# Generated at 2022-06-23 15:26:20.098849
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('foobar')


# Generated at 2022-06-23 15:26:26.140549
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test public
    assert 'action' in _RESERVED_NAMES
    # Test private
    assert 'pause_for' in _RESERVED_NAMES
    # Test added with other attributes
    assert 'local_action' in _RESERVED_NAMES
    # Test warning level name
    assert 'loop' in _RESERVED_NAMES
    # Test with_
    assert 'with_' in _RESERVED_NAMES



# Generated at 2022-06-23 15:26:30.080419
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test warn_if_reserved function '''

    try:
        warn_if_reserved(['some_var', 'other_var'])
    except Exception:
        assert False

    try:
        warn_if_reserved(['playbook', 'other_var'])
        assert False
    except Exception:
        assert True

# Generated at 2022-06-23 15:26:31.569036
# Unit test for function get_reserved_names
def test_get_reserved_names():
    results = get_reserved_names(include_private=True)
    assert 'name' in results

# Generated at 2022-06-23 15:26:35.107736
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert not is_reserved_name('foobar')
    assert not is_reserved_name('host')
    assert not is_reserved_name('var')

# FIXME: remove after with_ is not only deprecated but removed

# Generated at 2022-06-23 15:26:36.511809
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('gather_facts')
    assert not is_reserved_name('foobarbaz')

# Generated at 2022-06-23 15:26:46.316158
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert is_reserved_name('roles')
    assert is_reserved_name('include_role')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('private')
    assert is_reserved_name('block')
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('loop')
    assert is_reserved_name('with')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('_foo')
    assert not is_reserved_name('foo_')

# Generated at 2022-06-23 15:26:48.681162
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')

# Unit tests for function get_reserved_names

# Generated at 2022-06-23 15:26:56.939636
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host')
    assert is_reserved_name('roles')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('serial')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('task_name')
    assert is_reserved_name('listen')
    assert is_reserved_name('name')
    assert is_reserved_name('private')
    assert not is_reserved_name('self')
    assert is_reserved_name('when')
    assert not is_reserved_name('tags')

# Generated at 2022-06-23 15:27:06.511368
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # test reserved names
    assert is_reserved_name('name') == True
    assert is_reserved_name('roles') == True
    assert is_reserved_name('tasks') == True
    assert is_reserved_name('vars') == True
    assert is_reserved_name('handlers') == True
    assert is_reserved_name('tags') == True
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('gather_facts') == True
    assert is_reserved_name('delegate_to') == True
    assert is_reserved_name('register') == True
    assert is_reserved_name('with_items') == True
    assert is_reserved_name('with_dict') == True

# Generated at 2022-06-23 15:27:18.480180
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_reserved_names = sorted(get_reserved_names(include_private=False))
    private_reserved_names = sorted(get_reserved_names(include_private=True))

    assert isinstance(public_reserved_names, list)
    assert isinstance(private_reserved_names, list)

    assert u'action' in public_reserved_names
    assert u'local_action' in public_reserved_names
    assert u'loop' in public_reserved_names
    assert u'with_' in public_reserved_names
    assert u'with_fileglob' in public_reserved_names
    assert u'with_first_found' in public_reserved_names
    assert u'with_items' in public_reserved_names
    assert u'with_lines' in public

# Generated at 2022-06-23 15:27:19.111957
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    pass

# Generated at 2022-06-23 15:27:20.491238
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print(get_reserved_names())
    print(get_reserved_names(include_private=False))


# Generated at 2022-06-23 15:27:24.381543
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved_vars = ['name', 'gather_facts', 'roles', 'block', 'blockinfile']
    reserved_additional = ['asdf']

    warn_if_reserved(reserved_vars, reserved_additional)
    warn_if_reserved(reserved_vars)
    warn_if_reserved(reserved_additional)

# Generated at 2022-06-23 15:27:29.735920
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.errors import AnsibleError
    try:
        warn_if_reserved(['action', 'roles'])
    except AnsibleError:
        pass
    else:
        assert False, "AnsibleError exception not raised"

# Generated at 2022-06-23 15:27:39.248210
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Function get_reserved_names should return all of the reserved names associated
    with play objects
    '''

    reserved = get_reserved_names()
    reserved_public = get_reserved_names(include_private=False)

    for aclass in [Play, Role, Block, Task]:
        aobj = aclass()
        reserved_class = getattr(aobj, '_reserved_names', None)

        if not reserved_class:
            continue

        if reserved_class != reserved:
            raise AssertionError('Found reserved names list that did not equal all reserved names: %s' % aclass)

        for a_reserved_class in reserved_class:
            if 'private' in a_reserved_class:
                if a_reserved_class in reserved_public:
                    raise AssertionError

# Generated at 2022-06-23 15:27:49.665498
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('vars')
    assert is_reserved_name('vars_files')
    assert is_reserved_name('handlers')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('new_vars')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('block')
    assert is_reserved_name('rescue')
    assert is_reserved

# Generated at 2022-06-23 15:27:55.646279
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('action')
    assert is_reserved_name('name')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert is_reserved_name('loop')

    assert not is_reserved_name('abcd')

# Generated at 2022-06-23 15:27:57.361928
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-23 15:28:00.076116
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'become' in get_reserved_names(include_private=False)
    assert 'serial' in get_reserved_names(include_private=False)
    assert 'become_user' in get_reserved_names(include_private=True)
    assert '_role' in get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:28:09.758672
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.modules.system import ping
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestWarnIfReserved(unittest.TestCase):

        def setUp(self):
            self.display = Display()
            self.display.verbosity = 2

            self.warn_patcher = patch.object(self.display, 'warning')
            self.mock_warn = self.warn_patcher.start()

        def tearDown(self):
            self.warn_patcher.stop()

        def test_no_warnings(self):
            myvars = dict()
            reserved = get_reserved_names()

            for r in reserved:
                myvars[r] = r

# Generated at 2022-06-23 15:28:10.947016
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['action', 'local_action', 'name', 'register', 'notify', 'somevar', 'someothervar']
    warn_if_reserved(myvars)


# Generated at 2022-06-23 15:28:14.214565
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert not is_reserved_name('my_name')
    assert not is_reserved_name('my_task')

if __name__ == '__main__':
    test_is_reserved_name()

# Generated at 2022-06-23 15:28:16.936831
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # A name that is reserved
    name = 'hosts'

    assert(is_reserved_name(name))
    assert(not is_reserved_name('abc123'))

# Generated at 2022-06-23 15:28:18.134963
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('tasks')
    assert not is_reserved_name('other_tasks')

# Generated at 2022-06-23 15:28:28.180494
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook import Play
    myplay = Play().load({'hosts': 'all'})
    myplay.vars = {'name': 'myplay'}
    myplay.tasks = [
        {'hosts': 'all', 'connection': 'local', 'vars': {'name': 'all', 'gather_facts': False}, 'tasks': [
            {'debug': 'msg="this is a debug message"', 'name': 'debug'},
            {'debug': {'msg': 'this is another debug message'}, 'name': 'debug'},
            {'debug': {'msg': 'this is another debug message'}, 'name': 'debug'},
            {'debug': 'this is yet another debug message', 'name': 'debug'},
        ]},
    ]
    myplay.post

# Generated at 2022-06-23 15:28:34.287976
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=False)
    assert isinstance(reserved_names, set)
    assert 'roles' in reserved_names
    assert 'post_tasks' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'no_log' not in reserved_names
    assert 'include' in reserved_names
    assert 'tags' in reserved_names
    assert 'pre_task' in reserved_names
    assert 'connection' in reserved_names
    assert 'task' in reserved_names
    assert 'block' in reserved_names



# Generated at 2022-06-23 15:28:37.145762
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = {'name': 'foo', 'action': 'bar', 'with_': 'baz'}
    warn_if_reserved(vars)


# Unit tests


# Generated at 2022-06-23 15:28:47.609131
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    get_reserved_names()
    '''
    print("\n===== test_get_reserved_names =====")

    # this is the list of things we expect to have reserved

# Generated at 2022-06-23 15:28:50.329356
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for n in _RESERVED_NAMES:
        assert(is_reserved_name(n) is True)

    assert(is_reserved_name('name') is False)
    assert(is_reserved_name('var') is False)

# Generated at 2022-06-23 15:28:56.567823
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('local_action') == True
    assert is_reserved_name('action') == True
    assert is_reserved_name('with_') == True
    assert is_reserved_name('private') == True
    assert is_reserved_name('remote_user') == True
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('roles') == True
    assert is_reserved_name('block') == True
    assert is_reserved_name('when') == True
    assert is_reserved_name('include') == True
    assert is_reserved_name('include_vars') == True
    assert is_reserved_name('vars_prompt') == True
    assert is_reserved_name('vars_files') == True


# Generated at 2022-06-23 15:29:00.860492
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('block')
    assert is_reserved_name('vars')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:29:11.341753
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:29:13.247218
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('with_items')
    assert not is_reserved_name('not_reserved_name')


# Generated at 2022-06-23 15:29:15.178605
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'hosts': 'localhost', 'user': 'none'}) == None

# Generated at 2022-06-23 15:29:24.133322
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    from ansible.utils.warnings import deprecate

    class MockDisplay(object):
        def __init__(self):
            self.messages = []

        def warning(self, msg):
            self.messages.append(msg)

    saved_display = Display()
    md = MockDisplay()
    Display._display = md

    warn_if_reserved(['debug', 'private'])
    assert len(md.messages) == 2
    assert 'Found variable using reserved name' in md.messages[0]
    assert 'Found variable using reserved name' in md.messages[1]

    md.messages = []
    warn_if_reserved(['debug', 'private'], additional=['additional'])
    assert len(md.messages) == 3


# Generated at 2022-06-23 15:29:25.282166
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('delegate_to')

# Generated at 2022-06-23 15:29:29.943057
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['role_name',
              'role_path',
              'role_actions',
              'role_defaults',
              'role_tasks',
              'role_handlers',
              'role_meta',
              'vars']
    warn_if_reserved(myvars, additional=None)



# Generated at 2022-06-23 15:29:41.593330
# Unit test for function get_reserved_names