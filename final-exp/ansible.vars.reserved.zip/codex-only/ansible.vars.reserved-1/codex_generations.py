

# Generated at 2022-06-23 15:19:51.104790
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names_set1 = set(["become", "connection", "delegate_to", "environment", "no_log", "sudo", "sudo_user", "remote_user"])
    reserved_names_set2 = set(["become", "become_method", "become_user", "connection", "delegate_to", "environment", "no_log", "remote_user", "roles", "sudo", "sudo_flags", "sudo_user", "tags", "vars", "when"])

    assert set(get_reserved_names(True)) == reserved_names_set2
    assert set(get_reserved_names(False)) == reserved_names_set1


# Generated at 2022-06-23 15:19:55.751126
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == get_reserved_names(True)
    assert get_reserved_names(False).issuperset(get_reserved_names(True))
    assert len(get_reserved_names(False)) == len(get_reserved_names(True)) + 3


# Generated at 2022-06-23 15:19:59.068953
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    myvars = dict(
        myvar1 = 'foo',
        myvar2 = 'bar',
        action = 'baz',
    )
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:20:01.297528
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('dont_warn_me')

# Generated at 2022-06-23 15:20:03.927260
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # warn_if_reserved should not warn when calling with a variable name that is not reserved.
    warn_if_reserved(myvars={'foo_bar'})

# Generated at 2022-06-23 15:20:09.443912
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('vars_files')
    assert not is_reserved_name('vars-file')
    assert not is_reserved_name('vars_file')


# Generated at 2022-06-23 15:20:13.696164
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('private')
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert is_reserved_name('vars')
    assert is_reserved_name('include_vars')



# Generated at 2022-06-23 15:20:18.864078
# Unit test for function get_reserved_names
def test_get_reserved_names():
    print('_RESERVED_NAMES is: %s' % _RESERVED_NAMES)
    assert 'connection' in _RESERVED_NAMES
    assert 'with_items' in _RESERVED_NAMES
    assert 'environment' in _RESERVED_NAMES
    assert 'ignore_errors' in _RESERVED_NAMES
    assert 'loop' in _RESERVED_NAMES
    assert 'private' not in _RESERVED_NAMES

# Generated at 2022-06-23 15:20:27.534120
# Unit test for function get_reserved_names
def test_get_reserved_names():
    try:
        reserved_names_private = get_reserved_names(include_private=True)
        reserved_names_public = get_reserved_names(include_private=False)
    except BaseException as e:
        display.warning('test_get_reserved_names: failed with unexpected exception: %s' % str(e))


# Generated at 2022-06-23 15:20:37.038786
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()

# Generated at 2022-06-23 15:20:40.289740
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert not is_reserved_name('abcd')

# Generated at 2022-06-23 15:20:47.946130
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.config.manager import ConfigManager

    config_manager = ConfigManager()
    load_options = config_manager.options_list('playbook', keys=['vars'], transform=config_manager.key_to_list)

    try:
        display.display = 'off'
        warn_if_reserved(['action', 'name', 'local_action', 'with_'], additional=load_options)
    finally:
        display.display = 'stderr'

# Generated at 2022-06-23 15:20:52.941748
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('block')
    assert is_reserved_name('when')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert not is_reserved_name('bogus')

# Generated at 2022-06-23 15:20:56.735230
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # This test case checks if warn_if_reserved function works properly
    # As long as no warning is displayed, we are testing the function properly.
    try:
        warn_if_reserved({})
    except Warning as e:
        assert False, "test_warn_if_reserved test failed with %s" % str(e)

# Generated at 2022-06-23 15:21:00.353137
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    assert isinstance(public, set)
    assert len(public) > 0

    private = get_reserved_names(include_private=True)
    assert isinstance(private, set)
    assert len(private) > 0

    assert len(public) < len(private)
    assert public.issubset(private)



# Generated at 2022-06-23 15:21:07.150538
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

    assert 'roles' in public
    assert 'delegate_to' in public
    assert 'name' in private
    assert 'vars_prompt' in private
    assert 'include_vars' in private
    assert 'with_' in private
    assert 'local_action' in private

# Generated at 2022-06-23 15:21:10.488757
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for attribute in get_reserved_names():
        assert(is_reserved_name(attribute))

    assert(not is_reserved_name('somename'))
    assert(not is_reserved_name(None))
    assert(not is_reserved_name(''))


# Generated at 2022-06-23 15:21:15.475177
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert _RESERVED_NAMES == frozenset(('become', 'become_method', 'become_user', 'check_mode', 'connection',
                                         'delegate_to', 'gather_facts', 'hosts', 'name', 'no_log', 'notify', 'poll',
                                         'roles', 'serial', 'sudo', 'sudo_user', 'tasks', 'tags', 'when', 'environment',
                                         'environment_variables', 'action', 'local_action', 'loop', 'with_'))

# Generated at 2022-06-23 15:21:22.699193
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    private = get_reserved_names(include_private=False)
    assert 'connection' in names
    assert 'any_errors_fatal' in names
    assert 'gather_facts' in names
    assert 'roles' in names
    assert 'ignore_errors' in names
    assert 'import_role' in names
    assert 'include' in names
    assert 'include_vars' in names
    assert 'include_role' in names
    assert 'become' in names
    assert 'block' in names
    assert 'delegate_to' in names
    assert 'hosts' in names
    assert 'roles' in names
    assert 'tasks' in names
    assert 'notify' in names
    assert 'pause' in names
    assert 'register' in names
   

# Generated at 2022-06-23 15:21:32.900113
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars') == False, 'is_reserved_name("vars") should return False'
    assert is_reserved_name('roles') == False, 'is_reserved_name("roles") should return False'
    assert is_reserved_name('hosts') == True, 'is_reserved_name("hosts") should return True'
    assert is_reserved_name('name') == True, 'is_reserved_name("name") should return True'
    assert is_reserved_name('gather_facts') == True, 'is_reserved_name("gather_facts") should return True'
    assert is_reserved_name('included') == False, 'is_reserved_name("included") should return False'

# Generated at 2022-06-23 15:21:40.189298
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('delegate_to'))
    assert(is_reserved_name('hosts'))
    assert(is_reserved_name('gather_facts'))
    assert(is_reserved_name('roles'))
    assert(is_reserved_name('block'))
    assert(is_reserved_name('become'))
    assert(not is_reserved_name('BADNAME'))
    assert(not is_reserved_name('delegate-to'))
    assert(not is_reserved_name(''))

# Generated at 2022-06-23 15:21:47.676112
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('private')
    assert is_reserved_name('roles')
    assert is_reserved_name('connection')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('vars')
    assert is_reserved_name('environment')
    assert is_reserved_name('when')
    assert is_reserved_name('local_action')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('any_errors_fatal')
    assert not is_reserved_name('myvar')
    assert not is_reserved_name('a')

# Generated at 2022-06-23 15:21:50.422533
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('xhosts')
    assert not is_reserved_name('host')


# Generated at 2022-06-23 15:21:55.279166
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles') == True
    assert is_reserved_name('role_path') == True
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('block') == True
    assert is_reserved_name('local_action') == True



# Generated at 2022-06-23 15:21:59.102987
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('async')
    assert is_reserved_name('register')
    assert is_reserved_name('with_')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:22:08.028074
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # Test for with_
    for test_vars in (
            dict(with_=['test']),
            dict(with_items=['test']),
            dict(play=dict(with_=['test'])),
            dict(play=dict(with_items=['test']))
    ):
        display._display.reset_warnings()
        warn_if_reserved(test_vars)
        display._display.assert_warning_msg('Found variable using reserved name: with_')

    # Test for loop

# Generated at 2022-06-23 15:22:10.197906
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')



# Generated at 2022-06-23 15:22:16.752031
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'role_name' in get_reserved_names()
    assert 'include_role' in get_reserved_names()
    assert 'meta' in get_reserved_names()
    assert 'private' in get_reserved_names(False)
    assert not 'private' in get_reserved_names()

# Generated at 2022-06-23 15:22:19.721629
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('tags')
    assert not is_reserved_name('myhosts')



# Generated at 2022-06-23 15:22:24.845224
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Function is_reserved_name must not return True for empty strings
    assert not is_reserved_name('')
    assert not is_reserved_name(' ')

    # Function is_reserved_name must return True for non-empty strings matching reserved names
    assert is_reserved_name('tags')

    # Function is_reserved_name must return False for non-empty strings not matching reserved names
    assert not is_reserved_name('foo')



# Generated at 2022-06-23 15:22:32.581973
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' unit test for warn_if_reserved '''

    class TestSink(object):
        def __init__(self):
            self.ran = False

        def warning(self, text):
            self.ran = text
    testsink = TestSink()

    # Test 1 - passing a normal list should not run testsink
    warn_if_reserved(['foo', 'bar'], testsink.warning)
    assert testsink.ran is False

    # Test 2 - passing a list with a reserved name should run testsink
    warn_if_reserved(['foo', 'pre_tasks'], testsink.warning)
    assert testsink.ran == 'Found variable using reserved name: pre_tasks'
    testsink.ran = False

# Generated at 2022-06-23 15:22:34.253137
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('remote_user')
    assert not is_reserved_name('my_var')

# Generated at 2022-06-23 15:22:42.706129
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import StringIO
    sio = StringIO.StringIO()
    display.verbosity = 3
    display.display = sio

    warn_if_reserved({
        'roles': [],
        'tasks': [],
        'block': [],
        'notify': '',
        'action': '',
        'local_action': '',
        'with_': '',
        'loop': '',
        'post_tasks': [],
        'pre_tasks': [],
        'vars': '',
    })
    result = sio.getvalue().strip()
    sio.close()


# Generated at 2022-06-23 15:22:48.276310
# Unit test for function get_reserved_names
def test_get_reserved_names():
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.task
    module_list = [ansible.playbook, ansible.playbook.block, ansible.playbook.task]
    for aclass in module_list:
        reserved = get_reserved_names(include_private=False)
        reserved_priv = get_reserved_names(include_private=True)
        # Test reserved names
        assert 'serial' in reserved
        assert reserved_priv.__contains__('delegate_to')
        assert not reserved.__contains__('delegate_to')
        assert 'run_once' in reserved
        assert 'action' in reserved
        assert 'local_action' in reserved
        assert 'register' in reserved

        assert reserved.__contains__('roles')


# Generated at 2022-06-23 15:22:50.572149
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    goodvars = ['something_else', 'something_else2']
    badvars = ['pre_tasks']
    warn_if_reserved(goodvars)
    warn_if_reserved(badvars)



# Generated at 2022-06-23 15:22:59.776248
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    """
    Tests the warn_if_reserved function.
    """
    import sys
    class fake_stderr(object):
        """
        A fake stderr object that will call a function when it is written to.
        """
        def __init__(self, func):
            self.func = func
        def write(self, text):
            self.func(text)

    reserved_names = get_reserved_names(include_private=True)
    private_names = reserved_names - get_reserved_names(include_private=False)
    reserved_names = list(reserved_names)
    private_names = list(private_names)

    # Make sure the fake_stderr class works
    text = []

# Generated at 2022-06-23 15:23:01.534809
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-23 15:23:10.291909
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' Test is_reserved_name() function '''

    # Test non-reserved names
    assert not is_reserved_name('foobar')
    assert not is_reserved_name('foobartoo')

    # Test reserved names
    assert is_reserved_name('name')
    assert is_reserved_name('user')
    assert is_reserved_name('sudo')
    assert is_reserved_name('sudo_user')
    assert is_reserved_name('connection')
    assert is_reserved_name('tags')
    assert is_reserved_name('ignore_errors')
    # TODO: test the rest of the reserved names

# Generated at 2022-06-23 15:23:19.679046
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this test validates the return value of get_reserved_names '''

    assert get_reserved_names() is not None
    assert isinstance(get_reserved_names(), set)

    # test if public attributes are present
    assert 'hosts' in _RESERVED_NAMES
    assert 'connection' in _RESERVED_NAMES
    assert 'delegate_to' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES
    assert 'sudo' in _RESERVED_NAMES
    assert 'sudo_user' in _RESERVED_NAMES
    assert 'remote_user' in _RESERVED_NAMES
    assert 'any_errors_fatal' in _RESERVED_NAMES
    assert 'serial' in _RESER

# Generated at 2022-06-23 15:23:29.732963
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('vars')
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('with_items')
    assert is_reserved_name('until')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('when')
    assert not is_reserved_name('my_play')
    assert not is_reserved_name('my_task')
    assert not is_reserved_name('my_var')

# Generated at 2022-06-23 15:23:38.199380
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == {'become', 'become_user', 'block', 'block_rescue', 'block_start', 'block_when', 'connection', 'delegate_to', 'delegate_facts',
                                    'gather_facts', 'handlers', 'hosts', 'ignore_errors', 'name', 'notify', 'port', 'post_tasks', 'pre_tasks', 'register',
                                    'roles', 'serial', 'tasks', 'vars_files'}

# Generated at 2022-06-23 15:23:44.570694
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('chdir') is True
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('tasks') is True
    assert is_reserved_name('task') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('vars') is False
    assert is_reserved_name('vars_files') is False
    assert is_reserved_name('__my_var_name__') is False



# Generated at 2022-06-23 15:23:48.198139
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")
    assert is_reserved_name("name")
    assert not is_reserved_name("bogus")


# Generated at 2022-06-23 15:23:57.809077
# Unit test for function warn_if_reserved

# Generated at 2022-06-23 15:24:08.190881
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == frozenset(['action', 'name', 'register', 'delegate_to',
                                                                   'any_errors_fatal', 'remote_user', 'serial', 'tags',
                                                                   'transport', 'sudo_user', 'with_items', 'local_action',
                                                                   'when', 'delegate_facts', 'vars', 'with_', 'notify'])

# Generated at 2022-06-23 15:24:19.684608
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, set)

    # b_vars becomes variables for block
    assert 'variables' in _RESERVED_NAMES
    assert 'always' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES
    assert 'rollback' in _RESERVED_NAMES
    assert 'no_log' in _RESERVED_NAMES
    assert 'hosts' in _RESERVED_NAMES
    assert 'gather_facts' in _RESERVED_NAMES
    assert 'register' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_

# Generated at 2022-06-23 15:24:21.969836
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('foobar')



# Generated at 2022-06-23 15:24:25.994829
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class Test(object):
        def __init__(self):
            self.test1 = True
            self.test2 = True
            self.test3 = True

    assert warn_if_reserved(Test().__dict__) == None, "Failed to warn that reserved name is used"

# Generated at 2022-06-23 15:24:37.968688
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:24:39.559783
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Reserved name
    assert is_reserved_name('local_action')
    # Not reserved name
    assert not is_reserved_name('debug')

# Generated at 2022-06-23 15:24:41.425256
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['roles', 'action', 'task', 'block', 'with_items'])

# Generated at 2022-06-23 15:24:50.680213
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence

    assert isinstance(get_reserved_names(), frozenset)
    assert isinstance(get_reserved_names(include_private=False), frozenset)

    assert all(isinstance(i, str) for i in get_reserved_names())
    assert all(isinstance(i, str) for i in get_reserved_names(include_private=False))

    play = Play()
    role = Role()

    assert all(i in play._attributes for i in get_reserved_names())
    assert all(i in play._attributes for i in get_reserved_names(include_private=False))
    assert all(i in role._attributes for i in get_reserved_names())
   

# Generated at 2022-06-23 15:24:54.981232
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    warn_if_reserved(['action', 'with_', 'loop', 'vars'])
    warn_if_reserved(['action', 'vars'])



# Generated at 2022-06-23 15:25:02.552534
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.module_utils.common.removed import removed_module

    # Test valid reserved names
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)

    # Test mix of invalid and valid reserved names
    assert not is_reserved_name('foo1')

    # Test removed names
    with removed_module():
        assert is_reserved_name('sudo')
        assert is_reserved_name('sudo_user')
        assert is_reserved_name('su')
        assert is_reserved_name('su_user')
        assert is_reserved_name('connection')

# Generated at 2022-06-23 15:25:12.512620
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(False)
    private_names = get_reserved_names(True)

    assert isinstance(public_names, set)
    assert isinstance(private_names, set)
    assert public_names < private_names, "private_names should include public_names"

    # FIXME: remove after with_ is not only deprecated but removed
    assert "with_" in public_names, "'with_' is an implicit reserved name"

    # FIXME: remove after gather_facts is defaulted to True
    assert "gather_facts" in private_names, "'gather_facts' is a private reserved name"
    assert "gather_facts" in public_names, "'gather_facts' is an implicit reserved name"

    # FIXME: remove after remote_user is defaulted to 'root'


# Generated at 2022-06-23 15:25:17.207506
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), frozenset)
    assert is_reserved_name('action')
    assert not is_reserved_name('a_non_reserved_name')

    # This is a private attribute so it is not returned by default
    assert not is_reserved_name('_role')

    assert is_reserved_name('_role', include_private=True)

# Generated at 2022-06-23 15:25:26.181895
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    # Test using all reserved names
    myvars = list(get_reserved_names())
    warn_if_reserved(myvars)

    # Test using no reserved names
    myvars = list(set(myvars) - get_reserved_names())
    warn_if_reserved(myvars)

    # Test using only private reserved names
    myvars = list(get_reserved_names(include_private=True) - get_reserved_names())
    warn_if_reserved(myvars)

    # Test using only public reserved names

# Generated at 2022-06-23 15:25:37.506818
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_public  = ['become', 'become_user', 'block', 'connection', 'delegate_to', 'environment', 'name', 'pre_tasks', 'roles', 'run_once', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'when', 'with_items', 'with_file', 'with_lines', 'with_random_choice', 'with_sequence', 'with_together', 'with_subelements', 'with_dict', 'with_fileglob', 'with_first_found', 'with_inventory_hostnames', 'with_items', 'with_nested', 'with_together', 'with_subelements', 'with_fileglob', 'with_file', 'with_first_found', 'with_lines']

# Generated at 2022-06-23 15:25:41.998001
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('role_name') == True
    assert is_reserved_name('import_playbook') == True
    assert is_reserved_name('not_a_reserved_name') == False

# Generated at 2022-06-23 15:25:52.115824
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    from io import StringIO

    # capture output for comparison
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    # test that implicit local_action is reported
    myvars = ['action', 'any', 'other']
    warn_if_reserved(myvars)
    assert mystdout.getvalue().rstrip() == 'warning: Found variable using reserved name: local_action'

    # test that explicit local_action is reported
    myvars = ['local_action', 'any', 'other']
    warn_if_reserved(myvars)
    assert mystdout.getvalue().rstrip() == 'warning: Found variable using reserved name: local_action'

    # test that implicit with_ is reported
    # FIXME: remove after with_ is not only

# Generated at 2022-06-23 15:25:59.960105
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert isinstance(_RESERVED_NAMES, frozenset)

    # check if reserved names is up to date with latest development
    assert len(_RESERVED_NAMES) == len(set(_RESERVED_NAMES))

    # check if the varaibles known to be reserved are still reserved
    assert 'hosts' in _RESERVED_NAMES

    # check if known non-reserved names are still not reserved
    assert 'foobar' not in _RESERVED_NAMES



# Generated at 2022-06-23 15:26:05.987754
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name(u'vars')
    assert not is_reserved_name(u'vars_')
    assert is_reserved_name(u'name')
    assert is_reserved_name(u'action')
    assert is_reserved_name(u'local_action')
    assert is_reserved_name(u'loop')
    assert is_reserved_name(u'with_')
    assert not is_reserved_name(u'playbook')

# Generated at 2022-06-23 15:26:17.339486
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:20.049177
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('include')
    assert is_reserved_name('roles')
    assert not is_reserved_name('some_random_name')

# Generated at 2022-06-23 15:26:30.023149
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert isinstance(reserved, set)

    # Check some play attributes
    assert 'hosts' in reserved
    assert 'user' in reserved
    assert 'remote_user' in reserved
    assert 'name' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'tags' in reserved
    assert 'vars' in reserved
    assert 'become' in reserved

    # Check some block attributes
    assert 'block' in reserved
    assert 'name' in reserved
    assert 'rescue' in reserved
    assert 'always' in reserved

    # Check some task attributes
    assert 'action' in reserved
    assert 'async' in reserved
    assert 'local_action' in reserved
    assert 'poll' in reserved
    assert 'sudo' in reserved
   

# Generated at 2022-06-23 15:26:31.883434
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert is_reserved_name('loop')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-23 15:26:40.193811
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = {'name': 'myplay', 'hosts': 'all'}
    warn_if_reserved(vars)

    vars = {'name': 'myplay', 'hosts': 'all',
            'roles': 'master', 'gather_facts': 'no'}
    warn_if_reserved(vars)

    vars = {'roles': 'master', 'gather_facts': 'no', 'myvar': 'myvalue'}
    warn_if_reserved(vars)

    vars = {'roles': 'master', 'gather_facts': 'no', 'myvar': 'myvalue', 'include': 'myinclude'}
    warn_if_reserved(vars)

# Generated at 2022-06-23 15:26:50.262825
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    warnings = []

    class FakeDisplay(Display):
        def __init__(self):
            self.warnings = []

        def warning(self, msg):
            self.warnings.append(msg)

    global display
    orig_display = display
    display = FakeDisplay()

# Generated at 2022-06-23 15:26:51.372363
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars'])
    assert True

# Generated at 2022-06-23 15:26:54.973445
# Unit test for function is_reserved_name
def test_is_reserved_name():
    _reserved_names = list(get_reserved_names())
    assert(is_reserved_name(_reserved_names[0]))
    assert(not is_reserved_name('foobar'))

# Generated at 2022-06-23 15:26:56.022076
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['remote_user', 'role_name']) == None

# Generated at 2022-06-23 15:26:58.560524
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('roles')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:27:07.521884
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:27:10.724933
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['vars'], ['tags'])
        assert False
    except:
        assert True

# Generated at 2022-06-23 15:27:21.304442
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in _RESERVED_NAMES
    assert 'connection' in _RESERVED_NAMES
    assert 'serial' in _RESERVED_NAMES
    assert 'gather_facts' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES
    assert 'with_' in _RESERVED_NAMES
    assert 'includes' in _RESERVED_NAMES
    assert 'include' in _RESERVED_NAMES
    assert 'import_playbook' in _RESERVED_NAMES
    assert 'import_tasks'

# Generated at 2022-06-23 15:27:24.051340
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts', 'vars', 'roles', 'action'])
    warn_if_reserved(['hosts', 'vars', 'roles', 'action', 'private_stuff', 'loop'])

# Generated at 2022-06-23 15:27:25.174789
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['name', 'tasks'])



# Generated at 2022-06-23 15:27:36.916673
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:27:39.136248
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('connection')
    assert is_reserved_name('private')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:27:49.562256
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    display = Display()
    # myvars is a list of reserved names

# Generated at 2022-06-23 15:28:01.246928
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(dict(hosts='all', vars='all', action='all'))
    warn_if_reserved(dict(hosts='all', vars='all', include='all'))
    warn_if_reserved(dict(hosts='all', vars='all', import_tasks='all'))
    warn_if_reserved(dict(hosts='all', vars='all', import_role='all'))
    warn_if_reserved(dict(hosts='all', vars='all', include_role='all'))
    warn_if_reserved(dict(hosts='all', vars='all', pre_tasks='all'))
    warn_if_reserved(dict(hosts='all', vars='all', roles='all'))
    warn_if_reserved

# Generated at 2022-06-23 15:28:07.076436
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('local_action')
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert is_reserved_name('vars')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:28:14.138507
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play import Play
    class MyPlay(Play):
        pass

    # Test for variables that conflict with internally reserved names
    try:
        warn_if_reserved(['hosts', 'task'], additional=['roles', 'action'])
        assert False, 'Failed to warn'
    except SystemExit:
        pass

    warn_if_reserved(['foo', 'bar'], additional=['roles', 'action'])

    # Test for variables that conflict with internally reserved names
    # within a class that extends the Play class
    try:
        warn_if_reserved(['hosts', 'task'], additional=MyPlay._attributes)
        assert False, 'Failed to warn'
    except SystemExit:
        pass


# Generated at 2022-06-23 15:28:24.610741
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Create dict for testing, some will raise warnings and others will not
    test_dict = dict(warn_name="asdf",
                     safe_name="asdf",
                     warn_name_safe_name="asdf",
                     safe_name_in="asdf"
                     )
    # Localize _RESERVED_NAMES to prevent accidental modification in unit test
    local_reserved_names = _RESERVED_NAMES
    # Remove safe_name from _RESERVED_NAMES
    _RESERVED_NAMES = set(_RESERVED_NAMES) - set(["safe_name"])
    # Removing safe_name should result in no warnings
    warn_if_reserved(test_dict)
    # Re-add safe_name to _RESERVED_NAMES
    _RESERV

# Generated at 2022-06-23 15:28:34.229844
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch, MagicMock

    class TestPlayV2(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_reserved_vars_are_warned(self):
            with patch.object(display, 'warning') as mock_warn:
                warn_if_reserved(['tags', 'environment', 'remote_user'])

# Generated at 2022-06-23 15:28:44.940464
# Unit test for function get_reserved_names
def test_get_reserved_names():
    myreserved = get_reserved_names()
    assert 'name' in myreserved
    private = get_reserved_names(include_private=False)
    assert 'name' in private
    assert 'delegate_to' in private
    assert 'sudo' in private
    assert 'sudo_user' in private
    assert 'register' in private
    assert 'vars' in private
    assert 'with_' in private
    assert 'ignore_errors' in private
    assert 'environment' in private
    assert 'failed_when' in private
    assert 'always_run' in private
    assert 'tags' in private
    assert 'when' in private
    assert 'changed_when' in private
    assert 'hosts' in private
    assert 'roles' in private
    assert 'local_action' in private

# Generated at 2022-06-23 15:28:46.801088
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('hosts')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-23 15:28:51.787051
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(['name', 'hosts', 'gather_facts', 'become', 'playbook_dir', 'tasks', 'vars_files', 'handlers', 'post_tasks', 'vars', 'roles', 'tags', 'any_errors_fatal', 'user', 'pre_tasks', 'notify', 'vars_prompt', 'meta', 'serial', 'connection']) == set(get_reserved_names())

# Generated at 2022-06-23 15:28:54.613787
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('any_playbook_attribute') == True
    assert is_reserved_name('any_role_attribute') == True
    assert is_reserved_name('any_block_attribute') == True
    assert is_reserved_name('any_task_attribute') == True



# Generated at 2022-06-23 15:28:58.315478
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Check that 'name' is not a reserved name
    assert is_reserved_name('name') is False

    # Check that 'remote_user' is a reserved name
    assert is_reserved_name('remote_user') is True

# Generated at 2022-06-23 15:29:02.620384
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('with_') is True
    assert is_reserved_name('loop') is True
    assert is_reserved_name('my_var') is False

# Generated at 2022-06-23 15:29:12.572740
# Unit test for function warn_if_reserved

# Generated at 2022-06-23 15:29:15.543755
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Check for actual reserved words
    warn_if_reserved(['name', 'action'])

    # Check for silly variable names
    warn_if_reserved(['reserved', 'handlers', 'var'])

# Generated at 2022-06-23 15:29:24.411585
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # display.warning should be called twice, and display.deprecate twice
    display.deprecate = display.warning = lambda msg: None
    warn_if_reserved(dict(include_tasks=3, delegate_to=4, loop=5, with_=6))
    assert callable(display.warning) and display.warning.call_count == 2
    assert callable(display.deprecate) and display.deprecate.call_count == 2
    # display.warning should not be called again, but display.deprecate should be
    warn_if_reserved(dict(include_tasks=3, delegate_to=4, loop=5, with_=6))
    assert callable(display.warning) and display.warning.call_count == 2
    assert callable(display.deprecate) and display.dep

# Generated at 2022-06-23 15:29:29.237048
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # this test simply makes sure we get no errors if we call warn_if_reserved
    # with a list of vars that do not conflict with reserved names

    varlist = ['foo', 'bar', 'baz', 'some_long_variable_that_is_ok']
    warn_if_reserved(varlist)



# Generated at 2022-06-23 15:29:33.330692
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'action' in reserved
    assert 'local_action' not in reserved
    assert 'notify' in reserved
    assert 'with_' not in reserved
    assert 'vars' not in reserved
    assert 'when' in reserved

    reserved = get_reserved_names(include_private=False)
    assert 'action' in reserved
    assert 'local_action' not in reserved
    assert 'notify' in reserved
    assert 'with_' not in reserved
    assert 'vars' not in reserved
    assert 'when' in reserved


# Generated at 2022-06-23 15:29:39.946399
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    display = Display()
    # set the verbosity to 2 to make sure we see the warnings
    display.verbosity = 2

    # make sure reserved names trigger warnings
    names = _RESERVED_NAMES.copy()
    names.add('var')
    warn_if_reserved(names)

    # don't trigger if there are no reserved names
    names.pop()
    warn_if_reserved(names)

# Generated at 2022-06-23 15:29:43.491951
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('become_user')
    assert not is_reserved_name('playbook')
    assert not is_reserved_name('inventory')
    assert not is_reserved_name('tasks')
    assert not is_reserved_name('not_a_reserved_name')
