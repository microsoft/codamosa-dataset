

# Generated at 2022-06-23 15:19:55.440929
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import ansible.playbook.play_context
    from ansible.compat.tests import unittest

    def assertWarning(reserveds, method, vars):
        for reserved in reserveds:
            if method == 'reserved':
                self.assertTrue(ansible.playbook.play_context.is_reserved_name(reserved))
                # assert we get a warning with the reserved names
                with self.assertWarnsRegexp(UserWarning, reserved):
                    ansible.playbook.play_context.warn_if_reserved(vars)
            else:
                self.assertFalse(ansible.playbook.play_context.is_reserved_name(reserved))
                # assert we do not get a warning with the reserved names


# Generated at 2022-06-23 15:19:59.848841
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test with no additional parameters
    warn_if_reserved(['action', 'loop', 'test_me', 'other'], None)

    # Test with additional parameters
    warn_if_reserved(['action', 'loop', 'test_me', 'other'], ['action', 'additional'])

# Generated at 2022-06-23 15:20:07.094578
# Unit test for function get_reserved_names
def test_get_reserved_names():

    #print(_RESERVED_NAMES)
    assert 'hosts' in _RESERVED_NAMES
    assert 'roles' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'vars' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES
    assert 'connection' in _RESERVED_NAMES
    assert 'delegate_to' in _RESERVED_NAMES

# Generated at 2022-06-23 15:20:17.097744
# Unit test for function get_reserved_names
def test_get_reserved_names():
    class MyPlay(object):
        _valid_attrs = {'private': 'foo'}

        _valid_attrs_1 = {'name': 'foo'}


# Generated at 2022-06-23 15:20:28.360044
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:20:37.810681
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import unittest
    import ansible.utils.display

    class FakeWarnModule(ansible.utils.display.Display):
        def __init__(self):
            self.messages = []
            super(FakeWarnModule, self).__init__()

        def warning(self, msg):
            self.messages.append(msg)

    old_display = ansible.utils.display.Display()
    ansible.utils.display.Display = FakeWarnModule
    test_display = FakeWarnModule()
    test_vars = {'hosts': 'localhost'}
    test_names = get_reserved_names()
    for name in test_names:
        warn_if_reserved(test_vars, {name})
        # no warning should be given if no reserved name is used
        warn_if_

# Generated at 2022-06-23 15:20:42.582075
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:20:47.532429
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    private_reserved_names = get_reserved_names(include_private=False)

    private_names = reserved_names.difference(private_reserved_names)

    assert private_names == set(['loop'])

# Generated at 2022-06-23 15:20:50.076771
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('roles')
    assert not is_reserved_name('somename')

# Generated at 2022-06-23 15:20:59.766451
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.compat import StringIO

    myvars = {u'roles': [], u'hosts': [u'example.org'], u'vars': {u'gid': 1000, u'group': u'wheel'}}
    if PY3:
        myvars = {to_bytes(k, encoding='utf-8'): v for k, v in myvars.items()}

    myvars[u'roles'] = [u'foo']
    myvars[u'hosts'].append(u'bar')

    myvars['blarg'] = 'baz'
    old_stdout = display.get_all_stdout()

# Generated at 2022-06-23 15:21:00.384696
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    pass

# Generated at 2022-06-23 15:21:11.105583
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    """
    This function tests the warn_if_reserved function and returns a result
    dictionary.
    """
    # A test variable that contains
    testvars = {
        'roles': '',
        'role_name': '',
        'roles_path': '',
        'serial': '',
        'pre_tasks': '',
        'post_tasks': '',
        'hosts': '',
        'roles': '',
        'bogus': '',
        'vars': ''
    }
    # A dictionary of expected results

# Generated at 2022-06-23 15:21:12.280290
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['loop', 'action', 'with_', 'include'])

# Generated at 2022-06-23 15:21:24.193035
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class _Display(object):

        def __init__(self):
            self.warns = []

        def warning(self, msg):
            self.warns.append(msg)

    display = _Display()

    warn_if_reserved(['myvar', 'myvar2', 'name'])
    assert display.warns == ['Found variable using reserved name: name']

    display = _Display()
    warn_if_reserved(['myvar', 'myvar2', 'vars'])
    assert display.warns == []

    display = _Display()
    warn_if_reserved(['myvar', 'myvar2', 'name'], additional=['foo', 'bar'])
    assert set(display.warns) == set(['Found variable using reserved name: name', 'Found variable using reserved name: bar'])

# Generated at 2022-06-23 15:21:31.062783
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    class FakeDisplay:
        def __init__(self):
            self.warning_count = 0
        def warning(self,msg):
            self.warning_count += 1
            sys.stderr.write("%s\n" % msg)

    # This function isn't meant to do anything, but it gives us
    # a callable to pass to warn_if_reserved
    def do_nothing():
        pass

    module = { "vars": { "roles": [], "name": "", "action": do_nothing } }
    display = FakeDisplay()
    warn_if_reserved(module['vars'])
    assert display.warning_count == 0

    module = { "vars": { "roles": [], "name": "", "action": do_nothing, "tags": [] } }

# Generated at 2022-06-23 15:21:37.074459
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names(include_private=True)
    assert 'name' in reserved
    assert 'register' in reserved

    reserved = get_reserved_names(include_private=False)
    assert 'name' in reserved
    assert 'register' in reserved
    assert 'delegate_to' not in reserved
    assert 'delegate_facts' not in reserved

# Generated at 2022-06-23 15:21:40.906794
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('playbook')
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:21:49.066627
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    Simple function to help us test warn_if_reserved function
    '''

    class MockLogger:
        def __init__(self):
            self._messages = []

        def warning(self, message):
            self._messages.append(message)

        def info(self, message):
            self._messages.append(message)

    logger = MockLogger()
    display.logger = logger

    # Case 1: no vars
    vars = {}
    warn_if_reserved(vars)
    assert len(logger._messages) == 0, "Warnings should not be present in log"

    # Case 2: Single var
    vars = {'hosts': 'test-hosts'}
    warn_if_reserved(vars)

# Generated at 2022-06-23 15:21:51.234750
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = frozenset(['play', 'include', 'when', 'hosts'])
    vars = ['hosts', 'play']
    warn_if_reserved(vars, additional=reserved)


# Generated at 2022-06-23 15:21:52.720869
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('user')
    assert not is_reserved_name('unique_name')

# Generated at 2022-06-23 15:22:03.532771
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test the get_reserved_names function '''
    display.debug('testing get_reserved_names')

# Generated at 2022-06-23 15:22:10.353453
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # This test expects 49 reserved names
    # If you change anything below, MAKE SURE to update the expected number above too
    names = get_reserved_names(False)  # get public names only
    expected_names = set(['hosts', 'roles', 'vars', 'tasks', 'post_tasks', 'pre_tasks', 'name', 'action', 'local_action'])

    # check that we have all the public names in the public set
    assert set.issubset(expected_names, names)

    # check that we have all the public names in the full set
    names = get_reserved_names(True)  # get public names only
    # use the public set to build the additional ones

# Generated at 2022-06-23 15:22:15.163158
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('tags')
    assert not is_reserved_name('role')
    assert not is_reserved_name('local_action')
    assert not is_reserved_name('with_')

# Generated at 2022-06-23 15:22:24.844823
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from nose.tools import assert_equals
    assert_equals(is_reserved_name('name'), True)
    assert_equals(is_reserved_name('vars'), True)
    assert_equals(is_reserved_name('hosts'), True)
    assert_equals(is_reserved_name('roles'), True)
    assert_equals(is_reserved_name('tasks'), True)
    assert_equals(is_reserved_name('delegate_to'), True)
    assert_equals(is_reserved_name('delegate_facts'), True)
    assert_equals(is_reserved_name('name'), True)
    assert_equals(is_reserved_name('action'), True)

# Generated at 2022-06-23 15:22:28.363910
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become_user')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('whatever')
    assert is_reserved_name('name')


# Generated at 2022-06-23 15:22:32.518234
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('include') is True
    assert is_reserved_name('with_items') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('ignore_errors') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('vars') is False
    assert is_reserved_name('backup') is False
    assert is_reserved_name('my_vars') is False

# Generated at 2022-06-23 15:22:34.125978
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('kikoo')

# Generated at 2022-06-23 15:22:40.129239
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('tasks') is True
    assert is_reserved_name('name') is True
    assert is_reserved_name('action') is True
    assert is_reserved_name('transport') is True
    assert is_reserved_name('become_user') is True
    assert is_reserved_name('gather_facts') is True
    assert is_reserved_name('dummy') is False

# Generated at 2022-06-23 15:22:41.750183
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names()
    assert len(result) > 0
    assert 'gather_facts' in result

# Generated at 2022-06-23 15:22:45.169422
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    _myvars = { 'roles': 'roles', 'vars': 'vars'}
    warn_if_reserved(_myvars)

    _myvars = { 'vars': 'vars'}
    warn_if_reserved(_myvars, ['task'])

# Generated at 2022-06-23 15:22:54.267530
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play import Play

    display.current_level = Display.VERBOSITY_DEBUG
    display.verbosity = 4

    # Test for reserved name
    warn_if_reserved({'name': 'a reserved name'}, set(['name']))
    warn_if_reserved({'vars': 'included'}, set(['vars']))
    warn_if_reserved({'included': 'a reserved name'}, set(['included']))

    # Test different format
    warn_if_reserved({'name': 'a reserved name'})
    warn_if_reserved({'included': 'a reserved name'})

# Generated at 2022-06-23 15:23:03.657662
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('tasks')
    assert is_reserved_name('vars')
    assert is_reserved_name('roles')
    assert is_reserved_name('block')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('notify')
    assert is_reserved_name('become')
    assert is_reserved_name('roles')
    assert is_reserved_name('local_action')
    assert not is_reserved_name('orchestration')

# Generated at 2022-06-23 15:23:10.148647
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: how to auto test several variables instead of hardcoding?
    reserved = ['block', 'block_end', 'block_start', 'connection', 'delegate_to', 'environment',
                'ignore_errors', 'localhost', 'name', 'register', 'roles', 'serial', 'sudo', 'sudo_user',
                'tasks', 'with_', 'tags', 'when']

    assert reserved == sorted(get_reserved_names())



# Generated at 2022-06-23 15:23:15.919626
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    # Verify list has expected number of entries
    assert len(reserved_names) == 127

    # Verify a few specific entries are in list
    assert 'vars' in reserved_names
    assert 'roles' in reserved_names
    assert 'hosts' in reserved_names
    assert 'block' in reserved_names
    assert 'name' in reserved_names
    assert 'register' in reserved_names

# Generated at 2022-06-23 15:23:21.708847
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # Check that a foo name is not reserved
    foo_name = 'foo'
    myvars = {foo_name: None}
    warn_if_reserved(myvars)

    # Check that a foo name is not reserved, even if it is a bad name like vars
    foo_name = 'vars'
    myvars = {foo_name: None}
    warn_if_reserved(myvars)

    # Check that a foo name is reserved
    foo_name = 'tasks'
    myvars = {foo_name: None}
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:23:32.765633
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = frozenset(['hosts', 'name', 'gather_facts', 'connection', 'sudo', 'sudo_user',
                              'environment', 'no_log', 'any_errors_fatal', 'serial', 'max_fail_percentage',
                              'su',
                              'su_user', 'vars_files', 'vars_prompt', 'include', 'include_vars',
                              'when', 'roles',
                              'tags', 'environment', 'register', 'ignore_errors', 'failed_when', 'changed_when',
                              'block',
                              'local_action', 'transport'])


# Generated at 2022-06-23 15:23:43.906629
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.vars import warn_if_reserved
    from ansible.errors import AnsibleUndefinedVariable
    from mock import MagicMock
    import sys

    args = {'_original_file': 'test'}

    if sys.version_info[:2] < (2, 7):
        raise AssertionError("This test only works in Python 2.7 and greater")

    try:
        warn_if_reserved(args)
    except AnsibleUndefinedVariable:
        pass
    else:
        raise AssertionError("The function \"warn_if_reserved\" did not raise an UndefinedVariable exception")

    args = {'_original_file': 'test', 'vars': ''}

    try:
        warn_if_reserved(args)
    except AnsibleUndefinedVariable:
        raise Assert

# Generated at 2022-06-23 15:23:53.232648
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names(include_private=False)
    assert 'serial' in names
    assert 'environment' in names
    assert 'vars' in names
    assert 'roles' in names
    assert 'block' in names
    assert 'any_errors_fatal' in names
    assert 'gather_facts' in names
    assert 'tags' in names
    assert 'errors' in names
    assert 'name' in names
    assert 'include' in names
    assert 'handlers' in names
    assert 'register' in names
    assert 'ignore_errors' in names
    names = get_reserved_names(include_private=True)
    assert 'serial' in names
    assert 'environment' in names
    assert 'vars' in names
    assert 'roles' in names

# Generated at 2022-06-23 15:23:55.438518
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Check for docstrings on the function
    assert get_reserved_names.__doc__ is not None
    assert get_reserved_names.__doc__ != ''

# Generated at 2022-06-23 15:24:04.652115
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(_RESERVED_NAMES, frozenset)

    public = set()
    private = set()

    public_set = frozenset(['name', 'hosts', 'vars', 'roles', 'tasks', 'handlers', 'pre_tasks', 'post_tasks', 'any_errors_fatal', 'no_log', 'max_fail_percentage'])
    private_set = frozenset(['action', 'block', 'block_tasks', 'block_rescue', 'block_always', 'deprecated', 'role', 'include', 'rescue', 'always'])

    for name in _RESERVED_NAMES:
        if is_reserved_name(name):
            if name in public_set:
                public.add(name)

# Generated at 2022-06-23 15:24:11.614325
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    myvars = []
    additional = []
    g_reserved_names = get_reserved_names()

    for play in Play.__dict__['_attributes']:
        if 'private' in play:
            myvars.append(play)
        additional.append(play)

    additional.pop()  # remove private

    warn_if_reserved(myvars, additional)
    assert set(myvars).difference(g_reserved_names) == set()

    myvars = ['not in reserved names', 'vars']
    warn_if_reserved(myvars)
    assert myvars[0] in g_reserved_names



# Generated at 2022-06-23 15:24:12.226656
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    assert(_RESERVED_NAMES)

    return

# Generated at 2022-06-23 15:24:15.002142
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert 'hosts' in get_reserved_names()
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'no_log' in get_reserved_names()
    assert 'no_log' not in get_reserved_names(include_private=False)



# Generated at 2022-06-23 15:24:16.701035
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("action")

# Generated at 2022-06-23 15:24:23.151431
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    my_vars = {'hosts': 'something'}
    warn_if_reserved(my_vars)


if __name__ == '__main__':

    test_warn_if_reserved()
    print(get_reserved_names())

    #reserved_names = set(get_reserved_names())
    #print reserved_names
    #print "action" in reserved_names
    #print "local_action" in reserved_names
    #print "loop" in reserved_names
    #print "with_" in reserved_names

# Generated at 2022-06-23 15:24:25.625723
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    vars = dict(
        no_warn = 'foo',
        with_ = 'bar',
        delegate_to = 'baz',
        block = 'warp'
    )
    warn_if_reserved(vars)

# Generated at 2022-06-23 15:24:37.576499
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert (get_reserved_names()) == set(['action', 'become', 'connection', 'delegate_to', 'environment',
                                          'fetch', 'ignore_errors', 'any_errors_fatal', 'local_action', 'loop_control',
                                          'notify', 'role', 'retries', 'sudo', 'sudo_user', 'tags', 'transport',
                                          'until', 'vars', 'when', 'with_'])


# Generated at 2022-06-23 15:24:40.824463
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('role_path')
    assert is_reserved_name('name')
    assert not is_reserved_name('my_var')

# Generated at 2022-06-23 15:24:50.200737
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert is_reserved_name('action') is True
    assert is_reserved_name('with_') is False
    assert is_reserved_name('with_items') is False
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('tasks') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('role_paths') is True
    assert is_reserved_name('playbook_file') is True
    assert is_reserved_name('delegate_to') is True
    assert is_reserved_name('notify') is True
    assert is_reserved_name('loop') is False
    assert is_reserved_name('meta') is True
    assert is_reserved_name('block') is True


# Generated at 2022-06-23 15:25:01.924706
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:03.694784
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert not is_reserved_name('xyz')

# Generated at 2022-06-23 15:25:13.682726
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import unittest
    from ansible.compat.tests import mock

    class TestWarnIfReserved(unittest.TestCase):

        def setUp(self):
            self.mock_display = mock.MagicMock(name='display')
            display.warning = self.mock_display.warning
            # Make sure _RESERVED_NAMES is populated
            global _RESERVED_NAMES
            _RESERVED_NAMES

        def test_no_vars(self):
            vars = list()
            warn_if_reserved(vars)
            self.assertEqual(self.mock_display.warning.call_count, 0)

        def test_no_conflicts(self):
            vars = ['one', 'two']
            warn

# Generated at 2022-06-23 15:25:22.788697
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.plugins.loader import become_loader
    from ansible.module_utils import basic

    myvars = ['become', 'become_user', 'become_method', 'become_exe']

    for plugin in become_loader.all():
        try:
            myvars.append(plugin.become_conf.config_key)
        except AttributeError:
            pass

    try:
        myvars.append(basic.AnsibleModule.argument_spec.get('become_user')[0])
    except AttributeError:
        pass

    warn_if_reserved(myvars, getattr(basic, '_RESERVED_NAMES', set()))

# Generated at 2022-06-23 15:25:31.209257
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(len(get_reserved_names(include_private=True)) == 10)
    assert(len(get_reserved_names(include_private=False)) == 7)
    assert('action' in get_reserved_names(include_private=False))
    assert('local_action' in get_reserved_names(include_private=False))
    assert('name' in get_reserved_names(include_private=True))
    assert('become_user' in get_reserved_names(include_private=True))
    assert('connection' in get_reserved_names(include_private=False))

# Generated at 2022-06-23 15:25:40.707130
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from unittest import TestCase

    class TestWarnIfReserved(TestCase):

        def test_find_reserved(self):
            # passing a list of reserved names should not warn
            warn_if_reserved(list(_RESERVED_NAMES))

            # passing a list of reserved, non-reserved and duplicated names should warn for the reserved ones
            warn_if_reserved(list(_RESERVED_NAMES).extend(['test1', 'test2', 'test1']))

    # import Ansible's testbase to catch the warnings
    from ansible.plugins.loader import testbase
    testbase._t = TestWarnIfReserved()
    testbase._t.test_find_reserved()

# Generated at 2022-06-23 15:25:44.256522
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    hostvars = {'action': 'foo', 'name': 'bar', 'vars': 'baz'}
    warn_if_reserved(hostvars)



# Generated at 2022-06-23 15:25:47.436439
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert not is_reserved_name('host')
    assert not is_reserved_name('name')

# Generated at 2022-06-23 15:25:51.150850
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for res in _RESERVED_NAMES:
        assert is_reserved_name(res)

    assert not is_reserved_name('foo')
    assert not is_reserved_name('environment')  # this is a module option

# Generated at 2022-06-23 15:25:52.134625
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'hosts', 'name'])

# Generated at 2022-06-23 15:26:03.592282
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import ansible.plugins.loader as p_loader
    old_display = display.verbosity
    display.verbosity = 4

# Generated at 2022-06-23 15:26:04.644185
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('wildcard')
    assert is_reserved_name('roles')


# Generated at 2022-06-23 15:26:06.857848
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'tasks' in get_reserved_names()
    assert 'vars' in get_reserved_names()



# Generated at 2022-06-23 15:26:08.705886
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved([], additional=['name', 'action', 'loop'])

# Generated at 2022-06-23 15:26:09.319396
# Unit test for function is_reserved_name
def test_is_reserved_name():
    pass

# Generated at 2022-06-23 15:26:19.215751
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'tags' in reserved
    assert 'when' in reserved
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'include_role' in reserved
    assert 'register' in reserved
    assert 'run_once' in reserved
    assert 'environment' in reserved
    assert 'vars' in reserved
    assert 'vars_files' in reserved
    assert 'vars_prompt' in reserved
    assert 'vars_prompt_unless' in reserved
    assert 'connection' in reserved
    assert 'gather_facts' in reserved
    assert 'gather_subset' in reserved

    assert 'loop' in reserved
    assert 'with_' in reserved

    assert 'Name' in reserved
    assert 'min_fail_percentage' in reserved


# Generated at 2022-06-23 15:26:22.685113
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('loop'))
    assert(not is_reserved_name('dummy'))

# Generated at 2022-06-23 15:26:31.686408
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('action') == True
    assert is_reserved_name('pre_tasks') == False  # only reserved in Role
    assert is_reserved_name('include_tasks') == False  # only reserved in Role
    assert is_reserved_name('blocks') == True
    assert is_reserved_name('vars') == True  # vars is always reserved
    assert is_reserved_name('task') == False  # only reserved in Task
    assert is_reserved_name('roles') == True
    assert is_reserved_name('loops') == False  # only reserved in Task
    assert is_reserved_name('become') == False  # only reserved in Task


# Generated at 2022-06-23 15:26:35.573130
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(None) == None
    assert warn_if_reserved({}) == None
    assert warn_if_reserved({'a': 1}) == None
    assert warn_if_reserved({'action': 1}) != None
    assert warn_if_reserved({'action': 1}, additional={'action': 1}) == None

# Generated at 2022-06-23 15:26:45.337366
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.action import Action
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.plugins.loader import get_all_plugin_loaders

    global display
    # Prevent log messages from being displayed
    class FakeDisplay(object):
        def __getattr__(self, _):
            return lambda *a, **kw: None
    display = FakeDisplay()



# Generated at 2022-06-23 15:26:49.657956
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name(AnsibleUnsafeText('roles'))

# Generated at 2022-06-23 15:26:57.668720
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('vars')
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('pre_tasks')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('bar')
    assert is_reserved_name('block')
    assert is_reserved_name('register')
    assert is_reserved_name('environment')
    assert is_reserved_name('always_run')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('become_user')
    assert is_reserved_name('become_method')

# Generated at 2022-06-23 15:27:03.906341
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_private_names = frozenset(['become', 'become_user', 'block', 'block:detached', 'connection',
                                        'delegate_facts', 'include_role', 'include_tasks', 'local_action', 'loop',
                                        'max_fail_percentage', 'no_log', 'pre_tasks', 'post_tasks', 'register',
                                        'retry_files_enabled', 'role', 'roles', 'run_once', 'serial', 'strategy',
                                        'su', 'su_user', 'sudo', 'sudo_user', 'tags', 'tasks', 'tasks:detached',
                                        'vars', 'vars_prompt', 'vars_files', 'when'])

# Generated at 2022-06-23 15:27:09.451592
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # check that all internal reserved names are considered reserved by is_reserved_name
    assert _RESERVED_NAMES.issubset(frozenset([is_reserved_name(x) for x in _RESERVED_NAMES]))

    # check that names not reserved internally are also not considered reserved by is_reserved_name
    assert not frozenset(_RESERVED_NAMES).issubset(frozenset(['not'+x for x in _RESERVED_NAMES if not x.startswith('not')]))

# Generated at 2022-06-23 15:27:20.484201
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this unit test checks that the reserved names are up to date '''


# Generated at 2022-06-23 15:27:27.233285
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('delegate_facts')
    assert is_reserved_name('become')
    assert is_reserved_name('become_method')
    assert is_reserved_name('become_user')
    assert is_reserved_name('become_user_method')
    assert is_reserved_name('become_flags')
    assert is_reserved_name('environment')
    assert is_reserved_name('register')
    assert is_reserved_name('ignore_error')
    assert not is_reserved_name('with_')
    assert not is_reserved_name('loop')

# Generated at 2022-06-23 15:27:34.958723
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_public = get_reserved_names(include_private=False)
    assert len(test_public) == 79, 'Did not get 79 public reserved names'

    test_private = get_reserved_names(include_private=True)
    assert len(test_private) == 83, 'Did not get 83 names including private names'

    # Don't test the names since they could change in the future, test the difference
    assert len(test_private.difference(test_public)) == 4, 'Private names do not match'

# Generated at 2022-06-23 15:27:46.684278
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys

    # This is to catch the print statement and capture the result
    class DummyStream(object):
        def __init__(self):
            self.data = []

        def write(self, s):
            self.data.append(s)

        def __str__(self):
            return "".join(self.data)

    # save stdout so we can restore it at the end
    saved_stdout = sys.stdout

    # prep our dummy stdout
    sys.stdout = DummyStream()

    # create a list of vars that is and is not reserved
    myreserved = ['hosts', 'roles', 'any_errors_fatal']
    myvars = ['foo', 'bar', 'baz', 'vars', 'changed_when']

# Generated at 2022-06-23 15:27:48.565750
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    result = warn_if_reserved(['name', 'vars', 'action', 'loop', 'register'])
    assert result is None

# Generated at 2022-06-23 15:27:59.960467
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert_reserved_names = frozenset(['action', 'block', 'block_rescue', 'block_always', 'connection',
                                       'delegate_to', 'delegate_facts', 'environment', 'fails_on', 'gather_facts',
                                       'hosts', 'ignore_errors', 'no_log', 'notify', 'notify_again', 'notify_failed',
                                       'notify_slack', 'post_tasks', 'pre_tasks', 'roles', 'role_names', 'run_once',
                                       'serial', 'tags', 'tasks', 'vars', 'vars_files', 'vars_prompt', 'vault_password_files',
                                       'with_', 'local_action', 'name', 'static', 'tags', 'tasks', 'vars'])

# Generated at 2022-06-23 15:28:07.562416
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test that nothing is printed when warn_if_reserved is called with a list containing only
    # variables that do not conflict with reserved words.
    with display.capture():
        warn_if_reserved(['foo', 'bar', 'not_a_reserved_name'])

    # Test that warning is printed when warn_if_reserved is called with a list containing a variable
    # that conflicts with a reserved word.
    with display.capture() as captured:
        warn_if_reserved(['foo', 'bar', 'action', 'other_var'])

    assert 'action' in captured.out

# Generated at 2022-06-23 15:28:09.110212
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("roles")
    assert not is_reserved_name("joe")

# Generated at 2022-06-23 15:28:17.080559
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    play_vars = dict(name="no_warn", host="localhost", tags="all", connection="local", remote_user="root", remote_port="22")
    role_vars = dict(name="no_warn", user="root")
    task_vars = dict(name="no_warn", metattr="yes", remote_user="root")

    # FIXME(a_tal): this is not very helpful. We should assert on the warnings
    warn_if_reserved(play_vars)
    warn_if_reserved(role_vars)
    warn_if_reserved(task_vars)

    play_vars['remote_port'] = 22
    warn_if_reserved(play_vars)
    warn_if_reserved(play_vars, additional=['remote_port'])

# Generated at 2022-06-23 15:28:19.678492
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts', 'pre_tasks'])
    warn_if_reserved(['hosts'])



# Generated at 2022-06-23 15:28:23.903243
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:28:28.558977
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this function provides a unit test for function warn_if_reserved '''

    # test for no warnings
    warn_if_reserved(['not_a_reserved_name'])

    # test for a warning
    warn_if_reserved(['action'])

# Generated at 2022-06-23 15:28:32.088408
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=True)
    assert 'any_errors_fatal' in result

    result = get_reserved_names(include_private=False)
    assert 'any_errors_fatal' in result
    assert 'post_validate' not in result

# Generated at 2022-06-23 15:28:42.800562
# Unit test for function get_reserved_names
def test_get_reserved_names():

    public_names = ['hosts', 'vars', 'name', 'roles', 'gather_facts', 'remote_user', 'delegate_to', 'tags', 'action', 'register', 'local_action', 'with_']
    private_names = ['task', 'pre_tasks', 'post_tasks', 'handlers', 'block', 'serial', 'when', 'vars_files', 'default_vars']
    all_names = public_names + private_names

    assert set(public_names).issubset(set(get_reserved_names(include_private=False))), "public names in get_reserved_names is not the same as the expectation"


# Generated at 2022-06-23 15:28:47.722926
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Users may use the reserved variables, so don't warn about
    # these by default.
    for x in (u'foo', u'bar', u'vars'):
        assert not is_reserved_name(x)
    # These are reserved, and we should warn about them.
    for x in (u'become', u'hosts', u'roles'):
        assert is_reserved_name(x)


# Generated at 2022-06-23 15:28:50.929507
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(False)
    assert 'post_tasks' not in reserved
    assert 'action' in reserved
    assert 'local_action' not in reserved
    assert 'local_action' in get_reserved_names(True)
    assert 'notify' in get_reserved_names(True)



# Generated at 2022-06-23 15:28:51.850374
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'pre_tasks' in set(get_reserved_names())



# Generated at 2022-06-23 15:28:54.673031
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # test not reserved
    assert is_reserved_name('my_var') is False

    # test reserved
    assert is_reserved_name('name') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('action') is True



# Generated at 2022-06-23 15:29:05.805548
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.plugins.loader import action_loader

    # No warnings issued for valid variables
    vars_valid = {'valid_1': 'one',
                  'valid_2': 'two'}
    warn_if_reserved(vars_valid)

    # Warning for variable with reserved name
    vars_reserved = {'vars': 'three',
                     'valid_2': 'two'}
    warn_if_reserved(vars_reserved)

    # No warnings issued for valid variables with additional reserved names
    additional = ('valid_1', 'valid_2')
    vars_additional = {'valid_1': 'one',
                       'valid_2': 'two'}
    warn_if_reserved(vars_additional, additional)

    # Warning issued for variable with added additional reserved name
   

# Generated at 2022-06-23 15:29:08.560510
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_names = get_reserved_names()
    assert isinstance(test_names, set)
    assert len(test_names) > 4


# Generated at 2022-06-23 15:29:10.758353
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('any_keyword')
    assert is_reserved_name('command')
    assert not is_reserved_name('somename')



# Generated at 2022-06-23 15:29:20.725852
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check if get_reserved_names returns the correct data
    public_names = set(['name', 'hosts', 'connection', 'gather_facts', 'tasks', 'vars', 'tags', 'register', 'vars_files', 'roles', 'roles_path', 'post_tasks', 'pre_tasks', 'include', 'deps', 'handlers',
                  'block', 'block_rescue', 'block_always', 'pre_tasks', 'post_tasks', 'include', 'any_errors_fatal', 'force_handlers', 'serial', 'action', 'local_action', 'with_', 'task_tags', 'become',
                  'become_user', 'become_method', 'become_flags', 'environment', 'no_log', 'run_once'])

# Generated at 2022-06-23 15:29:31.264381
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import os
    import shutil

    data_root = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'data', 'reserved_vars')
    playbook_path = os.path.join(data_root, 'playbook.yml')

    # Given a playbook with a reserved variable
    display.verbosity = 4
    display.reset_warnings()

    myplay = Play.load(playbook_path, variable_manager=None, loader=None)

    # when we warn about reserved names
    warn_if_reserved(myplay.vars)

    # then we should get a warning about it
    assert(display.warnings[0] == 'Found variable using reserved name: delegate_to')

    display.verbosity = 0



# Generated at 2022-06-23 15:29:35.752001
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('post_tasks')
    assert not is_reserved_name('rolez')
    assert not is_reserved_name('post_taskz')

# Generated at 2022-06-23 15:29:39.620498
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = frozenset(['hosts', 'roles'])
    try:
        warn_if_reserved(myvars)
        assert False, 'should have raised an exception'
    except Exception:
        assert True

# Generated at 2022-06-23 15:29:46.398902
# Unit test for function get_reserved_names