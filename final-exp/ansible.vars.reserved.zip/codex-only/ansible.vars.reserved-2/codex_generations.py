

# Generated at 2022-06-23 15:19:54.041001
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Check if the function is still returning reserved and private
    reserved = get_reserved_names(include_private=False)

    private = get_reserved_names(include_private=True) - reserved

    assert len(reserved) > 0
    assert len(private) > 0

    reserved_and_private = reserved.union(private)

    # Check if the var name or key names are not in the reserved

# Generated at 2022-06-23 15:19:57.307412
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert is_reserved_name('role_path')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:19:58.742018
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert isinstance(get_reserved_names(), set)


# Generated at 2022-06-23 15:20:04.857394
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest
    reserved_names = _RESERVED_NAMES
    print(reserved_names)
    localhost = {
        'hosts': 'localhost',
        'vars': {'vars': 'foo'}
    }
    with pytest.raises(AssertionError) as excinfo:
        warn_if_reserved(localhost)
    assert 'Found variable using reserved name' in str(excinfo.value)

# Generated at 2022-06-23 15:20:07.407844
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('my_action')



# Generated at 2022-06-23 15:20:10.455123
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert(len(reserved_names) > 15)
    assert(len(reserved_names) < 50)

# Generated at 2022-06-23 15:20:13.353839
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    warn_if_reserved({'name': 'foo', 'hosts': 'bar'})
    warn_if_reserved({'name': 'foo', 'hosts': 'bar'}, additional=set(['bam']))

# Generated at 2022-06-23 15:20:22.983785
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('block')
    assert is_reserved_name('task')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('when')
    assert is_reserved_name('notify')
    assert is_reserved_name('async')
    assert is_reserved_name('async_poll_interval')
    assert is_reserved_name('items')
    assert is_reserved_name('include')
    assert is_reserved_name('include_tasks')
    assert is_reserved_name('pre_tasks')

# Generated at 2022-06-23 15:20:31.720034
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Testing the list of reserved names.
    # It may be a bit brittle, but this is the simplest way to do it.

    #test public names
    public = get_reserved_names(include_private=False)
    assert 'hosts' in public
    assert 'roles' in public
    assert 'name' in public
    assert 'connection' in public
    assert 'sudo' in public
    assert 'sudo_user' in public
    assert 'remote_user' in public
    assert 'environment' in public

    #test private names
    private = get_reserved_names(include_private=True)
    assert 'delegate_to' in private
    assert 'local_action' in private
    assert 'with_' in private
    assert 'tags' in private
    assert 'register' in private

    #test complete name list


# Generated at 2022-06-23 15:20:36.276019
# Unit test for function is_reserved_name
def test_is_reserved_name():
    try:
        assert is_reserved_name('hosts')
        assert is_reserved_name('roles')
        assert is_reserved_name('private_key_file')
        assert is_reserved_name('connection')
        assert not is_reserved_name('not_reserved_name')
    except AssertionError:
        raise AssertionError("test_is_reserved_name failed")

# Generated at 2022-06-23 15:20:46.070725
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # Random list of names to check for
    list_of_names_to_check = ['hosts', 'random_name', 'max_fail_percentage',
                              'block', 'remote_user', 'any_errors_fatal',
                              'gather_facts', 'vars', 'random_name', 'hosts',
                              'roles']

    # Iterate through list of names
    for name in list_of_names_to_check:
        if is_reserved_name(name):
            assert name in _RESERVED_NAMES
        else:
            assert name not in _RESERVED_NAMES

# Generated at 2022-06-23 15:20:53.341313
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('become')
    assert is_reserved_name('tags')
    assert is_reserved_name('run_once')
    assert is_reserved_name('connection')

    assert not is_reserved_name('display_skipped_hosts')
    assert not is_reserved_name('user')
    assert not is_reserved_name('not_a_reserved_name')


# Generated at 2022-06-23 15:20:56.182921
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['name', 'action'])
    except:
        assert False
    try:
        warn_if_reserved(['name', 'private'])
        assert False
    except Exception:
        pass

# Generated at 2022-06-23 15:20:57.895166
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'foo', 'vars'])


# FIXME: probably a better home for this function

# Generated at 2022-06-23 15:21:01.711521
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved({'vars': {'action': []}})
    except Exception as e:
        raise AssertionError('warn_if_reserved: %s' % e) from e

# Generated at 2022-06-23 15:21:11.704550
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    # create a short list of items to look for

# Generated at 2022-06-23 15:21:16.570161
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(include_private=False)
    private = get_reserved_names(include_private=True)

    assert 'name' in public
    assert 'private' not in public
    assert 'private' in private

# Generated at 2022-06-23 15:21:26.308932
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    Unit test for function warn_if_reserved
    '''
    import pytest
    from ansible.module_utils._text import to_bytes
    from io import StringIO

    # Raise error when a reserved name is passed (using the default set)
    with pytest.raises(SystemExit) as cm:
        warn_if_reserved(['name'])
    assert cm.value.code == 1

    # No error when a non-reserved name is passed
    warn_if_reserved(['foo'])

    # No error when a reserved name is passed and using the alternate set
    warn_if_reserved(['foo'], additional=['name'])

    # Raise error when a mix of reserved and non-reserved names is passed
    with pytest.raises(SystemExit) as cm:
        warn

# Generated at 2022-06-23 15:21:30.732813
# Unit test for function is_reserved_name
def test_is_reserved_name():

    if 'vars' in _RESERVED_NAMES:
        assert is_reserved_name('vars')

    if 'with_' in _RESERVED_NAMES:
        assert is_reserved_name('with_')

# Generated at 2022-06-23 15:21:32.164908
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'hosts', 'roles'})

# Generated at 2022-06-23 15:21:40.106387
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = [
        'hosts', 'roles', 'vars', 'minions', 'environment', 'command', 'sudo',
        'sudo_user', 'notify', 'pre_tasks', 'post_tasks', 'any_errors_fatal',
        'always_run', 'remote_user', 'log_path', 'environment', 'no_log',
        'register', 'ignore_errors', 'roles', 'block', 'when', 'other_var'
    ]
    warn_if_reserved(myvars)
    assert is_reserved_name('other_var') is False

# Generated at 2022-06-23 15:21:41.918525
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'roles': 'foo'})
    warn_if_reserved({'private': 'foo'}, additional=('private',))

# Generated at 2022-06-23 15:21:47.781616
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(True)

    # list of variable names that must exist in the set of reserved names
    reserved_name_list = frozenset([
        'action', 'loop', 'name', 'tags', 'when', 'with_', 'local_action'
    ])

    # Make sure all reserved names are expected
    assert not reserved_name_list.difference(reserved_names)

    # Make sure there are no other reserved names
    assert not any([name.startswith('_') for name in reserved_names.difference(reserved_name_list)])

# Generated at 2022-06-23 15:21:57.903327
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' this function tests the warn_if_reserved function '''

    class d(object):
        pass

    def assert_warn_if_reserved(var_names, warning_count):
        ''' Test warn_if_reserved with a given list of var names '''

        d.display = Display()
        warn_if_reserved(var_names, additional=('foo', 'bar'))
        assert d.display.warning_count == warning_count

    assert_warn_if_reserved([], 0)
    assert_warn_if_reserved(['foo', 'bar'], 0)  # because of additional
    assert_warn_if_reserved(['action'], 1)  # because of action
    assert_warn_if_reserved(['foo', 'action'], 1)  # because of action

# Generated at 2022-06-23 15:22:00.202158
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'local_action'])

# Generated at 2022-06-23 15:22:02.641489
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('host') is False

# Generated at 2022-06-23 15:22:04.787450
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test warn_if_reserved '''

    # ensure that we can call the function
    warn_if_reserved({})

# Generated at 2022-06-23 15:22:06.157567
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('tags')
    assert not is_reserved_name('boogers')

# Generated at 2022-06-23 15:22:17.175543
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = get_reserved_names(False)

    assert 'tags' in public
    assert 'pre_tasks' in public
    assert 'post_tasks' in public
    assert 'roles' in public
    assert 'vars' in public
    assert 'include' in public
    assert 'deps' in public
    assert 'blocks' in public
    assert 'ignore_errors' in public
    assert 'group_by' in public
    assert 'gather_facts' in public
    assert 'hosts' in public
    assert 'include_role' in public
    assert 'import_role' in public
    assert 'handlers' in public
    assert 'tasks' in public
    assert 'action' in public
    assert 'local_action' in public
    assert 'with_' in public


# Generated at 2022-06-23 15:22:23.952075
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'become', 'vars'])
    warn_if_reserved(['vars'])
    warn_if_reserved(['action', 'become', 'vars', 'invalid_name'], additional=['invalid_name'])
    warn_if_reserved(['action', 'become', 'vars', 'invalid_name'], additional=['invalid_name_2'])
    warn_if_reserved(['action', 'become', 'vars'], additional=['invalid_name'])

# Generated at 2022-06-23 15:22:26.940706
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # test for a bug where loop attribute was not being properly handled
    reserved_names = get_reserved_names()
    assert "loop" in reserved_names

# Generated at 2022-06-23 15:22:31.638542
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = frozenset(get_reserved_names(include_private=False))
    private_names = frozenset(get_reserved_names(include_private=True))

    assert('action' in reserved_names)
    assert('loop' not in reserved_names)

    assert('action' in private_names)
    assert('loop' in private_names)

    assert('name' in reserved_names)
    assert('private' not in reserved_names)
    assert('private' in private_names)



# Generated at 2022-06-23 15:22:35.833288
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('vars')
    assert is_reserved_name('private')
    assert is_reserved_name('private_action_plugin')
    assert not is_reserved_name('notareallyreservedname')

# Generated at 2022-06-23 15:22:39.786176
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    """
    >>> from ansible.utils.vars import warn_if_reserved
    >>> warn_if_reserved(['name', 'public_name', 'private_name', 'register', 'run_once'])
    >>>
    """


# Generated at 2022-06-23 15:22:49.515158
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    import unittest

    class TestRedirect(object):
        def __init__(self):
            self.content = ''

        def write(self, str):
            self.content = self.content + str

    old_stdout = sys.stdout
    sys.stdout = TestRedirect()


# Generated at 2022-06-23 15:22:59.128459
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' these are the names we currently reserve in playbooks '''
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('user')
    assert is_reserved_name('vars')
    assert is_reserved_name('vars_files')
    assert is_reserved_name('tags')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('serial')
    assert is_reserved_name('max_fail_percentage')
    assert is_

# Generated at 2022-06-23 15:23:07.802489
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['playbook'])
    warn_if_reserved(['playbook', 'playbook', 'playbook'])
    warn_if_reserved(['playbook', 'roles', 'hosts'])
    warn_if_reserved(['hosts'])
    warn_if_reserved(['hostvars'])
    warn_if_reserved(['hostvars', 'hosts'])
    warn_if_reserved(['roles'])
    warn_if_reserved(['role_params'])
    warn_if_reserved(['role_params', 'roles'])
    warn_if_reserved(['vars'])



# Generated at 2022-06-23 15:23:15.223361
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.vars import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    # Create needed objects
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Group('group')
    inventory.add_host(Host(name='host'))
    variable_manager.set_inventory(inventory)

    def run_warnings(vars_path):
        # Set ansible_connection to whatever is set in vars
        file_vars = variable_manager.set_vars_from_file(loader, vars_path)
        display.verbosity = 3
        warn_if_reserved(file_vars)

    # Get the path the the test vars file
    import os

# Generated at 2022-06-23 15:23:22.549548
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    Basic unit tests for warn_if_reserved
    '''
    reserved = _RESERVED_NAMES
    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'register' in reserved
    assert 'ignore_errors' in reserved

    reserved_private = get_reserved_names(include_private=False)
    assert 'name' in reserved_private
    assert 'hosts' in reserved_private
    assert 'register' in reserved_private
    assert 'ignore_errors' in reserved_private

    reserved_private = get_reserved_names(include_private=True)
    assert 'name' in reserved_private
    assert 'hosts' in reserved_private
    assert 'register' in reserved_private
    assert 'ignore_errors' in reserved_private
    assert '_role' in reserved

# Generated at 2022-06-23 15:23:25.306401
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert not is_reserved_name('foo')


# Generated at 2022-06-23 15:23:36.977220
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['become'])
    warn_if_reserved(['become', 'become_user'])
    warn_if_reserved(['become_user'])
    warn_if_reserved(['gather_facts'])
    warn_if_reserved(['gather_facts', 'tags'])
    warn_if_reserved(['tags'])
    warn_if_reserved(['tasks'])
    warn_if_reserved(['tasks', 'pre_tasks'])
    warn_if_reserved(['pre_tasks'])
    warn_if_reserved(['post_tasks'])
    warn_if_reserved(['vars'])
    warn_if_reserved(['vars', 'vars_files'])  #

# Generated at 2022-06-23 15:23:46.124382
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('include')
    assert is_reserved_name('role')

    #
    # The deprecated 'loop' is routed to 'with_' but we don't want to
    # have the user directly access this since the deprecation warning
    # is under 'loop'.
    #
    assert not is_reserved_name('with_')

    assert is_reserved_name('loop')
    assert not is_reserved_name('_loop')

    assert not is_reserved_name('name')
    assert is_reserved_name('_name')

    if 'block' in _RESERVED_NAMES:
        # block is only a reserved name in 2.4 or later
        assert is_reserved_name('block')

# Generated at 2022-06-23 15:23:49.250563
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert len(reserved) > 0
    assert 'connection' in reserved
    assert 'hosts' in reserved
    assert 'gather_facts' in reserved
    assert 'roles' in reserved
    assert 'vars' in reserved

# Generated at 2022-06-23 15:23:51.415623
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('a_non_reserved_name')



# Generated at 2022-06-23 15:24:01.907776
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # If the reserved names list changes, this will fail and allow you to
    # update the reserved names list by copying the printed set into the above
    # unit test function.
    import os
    import inspect
    from ansible.playbook.play_context import PlayContext

    # This list of names should be maintained for backwards compatibility for
    # the reserved name testing. It is required due to the way the PlayContext
    # object is accessed by plugins. In the future, this would be better
    # maintained by dependency injection (i.e. a global object set in the
    # constructor of the object).

# Generated at 2022-06-23 15:24:03.585687
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved = get_reserved_names()

    for name in reserved:
        assert is_reserved_name(name)

# Generated at 2022-06-23 15:24:08.041521
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' test is_reserved_name '''

    res = get_reserved_names()
    for word in res:
        assert is_reserved_name(word) is True

    for word in ['foo', 'bar', 'baz']:
        assert is_reserved_name(word) is False

# Generated at 2022-06-23 15:24:09.129637
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")

# Generated at 2022-06-23 15:24:19.093551
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test the returned items, then the type and the count
    assert ('hosts' in get_reserved_names())
    assert ('action' in get_reserved_names())
    assert ('connection' in get_reserved_names(include_private=False))
    assert ('name' not in get_reserved_names(include_private=False))
    assert ('become' in get_reserved_names())
    assert ('name' in get_reserved_names())

    assert (len(get_reserved_names()) == 41)
    assert (len(get_reserved_names(include_private=False)) == 35)

    assert (type(get_reserved_names()) == set)

# Generated at 2022-06-23 15:24:21.123308
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('foo')
    assert is_reserved_name('tags')
    assert is_reserved_name('hosts')

# Generated at 2022-06-23 15:24:23.694460
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:24:34.683462
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # Set up a vars object with some reserved names
    myvars = dict()
    myvars['roles'] = dict()
    myvars['roles']['appserver'] = dict()
    myvars['roles']['appserver']['hosts'] = 'app1'
    myvars['roles']['appserver']['tasks'] = list()

    myvars['roles']['webserver'] = dict()
    myvars['roles']['webserver']['hosts'] = 'web1'
    myvars['roles']['webserver']['tasks'] = list()

    myvars['hosts'] = dict()
    myvars['hosts']['app1'] = dict()

# Generated at 2022-06-23 15:24:43.399399
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()

    # Auxiliary function to check if attribute is not private
    def is_public(attr):
        return 'private' not in attr

    # We assume there is not errors in the function get_reserved_names
    # It is tested in set_is_reserved_name unit test

    # Tests for required attributes for Play
    for attr in ['name', 'hosts', 'gather_facts', 'vars_files']:
        msg = 'Error in Play class, missing attribute: %s' % attr
        assert attr in names, msg

    # Tests for optional attributes for Play

# Generated at 2022-06-23 15:24:51.916346
# Unit test for function get_reserved_names
def test_get_reserved_names():

    reserved = get_reserved_names()

    assert 'name' in reserved
    assert 'hosts' in reserved
    assert 'gather_facts' in reserved
    assert 'remote_user' in reserved
    assert 'roles' in reserved
    assert 'become' in reserved
    assert 'become_user' in reserved
    assert 'become_method' in reserved
    assert 'become_ask_pass' in reserved
    assert 'action' in reserved

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in reserved

    # local_action is implicit with action
    assert 'local_action' in reserved

    # FIXME: need role deps/includes
    assert 'include' in reserved
    assert 'include_tasks' in reserved
    assert 'tasks'

# Generated at 2022-06-23 15:24:56.787882
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.module_utils.six import string_types
    assert isinstance(_RESERVED_NAMES, frozenset)
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)
        assert isinstance(name, string_types)

# Generated at 2022-06-23 15:24:58.052635
# Unit test for function is_reserved_name
def test_is_reserved_name():

    reserved = get_reserved_names(include_private=True)
    for one in reserved:
        assert is_reserved_name(one)

# Generated at 2022-06-23 15:24:59.234979
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become') == True
    assert is_reserved_name('localhost') == False

# Generated at 2022-06-23 15:25:01.183342
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action') == True
    assert is_reserved_name('foobar') == False


# Generated at 2022-06-23 15:25:11.491055
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert 'hosts' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'vars' in _RESERVED_NAMES
    assert 'vars_files' in _RESERVED_NAMES
    assert 'block' in _RESERVED_NAMES
    assert 'block_rescue' in _RESERVED_NAMES
    assert 'action' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES
    assert 'loop' in _RESERVED_NAMES
    assert 'with_' in _RESERVED_NAMES
    assert 'with_' in _RESERVED_NAMES

    assert 'dude' not in _RESERVED_NAMES

# Generated at 2022-06-23 15:25:19.408647
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import tempfile
    from os import path
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    fake_loader = DataLoader()
    fake_inventory = Inventory(loader=fake_loader)
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)


# Generated at 2022-06-23 15:25:26.920841
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('gather_subset')
    assert is_reserved_name('action')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('when')
    assert is_reserved_name('become_method')
    assert is_reserved_name('become_user')
    assert is_reserved_name('become')
    assert is_reserved_name('sudo')
    assert is_reserved_name('sudo_user')
    assert is_reserved_name('register')
    assert is_reserved_name('local_action')  # also checks 'action'
    assert is_reserved_name('with_')  # also checks 'loop'
    assert is_reserved_name

# Generated at 2022-06-23 15:25:38.065835
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') == True
    assert is_reserved_name('tasks') == True
    assert is_reserved_name('action') == True
    assert is_reserved_name('local_action') == True
    assert is_reserved_name('task') == True
    assert is_reserved_name('with_') == True
    assert is_reserved_name('include') == True
    assert is_reserved_name('include_role') == True
    assert is_reserved_name('register') == True
    assert is_reserved_name('vars') == True
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('roles') == True
    assert is_reserved_name('pre_tasks') == True
    assert is_res

# Generated at 2022-06-23 15:25:47.908908
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'name' in reserved_names
    assert 'tags' in reserved_names
    assert 'connection' in reserved_names
    assert 'delegate_to' in reserved_names
    assert 'hosts' in reserved_names
    assert 'roles' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names

    reserved_names = get_reserved_names(include_private=False)
    assert 'vars_files' not in reserved_names
    assert 'run_once' not in reserved_names



# Generated at 2022-06-23 15:25:49.586880
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('myhosts')

# Generated at 2022-06-23 15:25:52.195849
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['action'])
    except DeprecationWarning:
        pass
    else:
        assert False, 'DeprecationWarning not raised'

# Generated at 2022-06-23 15:26:03.634979
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    with patch.object(display, 'warning') as mock_display_warning:
        myvars = {'vars': 'foo', 'delegate_to': 'bar', 'vault_password': 'baz'}

        warn_if_reserved(myvars, {'delegate_to'})

        assert mock_display_warning.call_count == 1
        assert {'delegate_to'} == set(mock_display_warning.call_args[0])

        # make sure it doesn't fail on a non-dict
        warn_if_reserved('delegate_to')

        # make sure it doesn't fail on a non-string

# Generated at 2022-06-23 15:26:14.518025
# Unit test for function get_reserved_names
def test_get_reserved_names():
    new_names = get_reserved_names(False)
    assert isinstance(new_names, set)
    assert 'action' in new_names
    assert 'with_' in new_names
    assert 'connection' in new_names
    assert 'vars' in new_names  # 'vars' is a reserved name for the module
    assert 'hosts' in new_names
    assert 'delegate_to' in new_names
    assert 'run_once' in new_names
    assert 'environment' in new_names
    assert 'ignore_errors' in new_names
    assert 'register' in new_names
    assert 'any_errors_fatal' in new_names
    assert 'always_run' in new_names
    assert 'ignore_unreachable' in new_names
    assert 'name' in new_

# Generated at 2022-06-23 15:26:16.940834
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('host-name')

# Generated at 2022-06-23 15:26:23.279856
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('become')
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert is_reserved_name('when')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:26:24.876145
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert(warn_if_reserved(set(['gather_facts'])) is None)


# Generated at 2022-06-23 15:26:29.984820
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)
    assert len(reserved_names) > 0
    assert 'become' in reserved_names
    assert 'roles' in reserved_names
    assert 'sudo' in reserved_names
    assert 'import_playbook' not in reserved_names
    assert 'register' in reserved_names



# Generated at 2022-06-23 15:26:33.243537
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test default
    reserved_names = get_reserved_names()
    assert(len(reserved_names) > 100)
    assert('name' in reserved_names)

    # test private
    reserved_names = get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:26:38.048721
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.plugins import module_loader
    from ansible.plugins.loader import module_loaders

    module_loader.add_directory(module_loader._get_path_to_original_module('.'))
    module_names = [module_name for module_loader in module_loaders for module_name in module_loader.all()]
    assert not any(is_reserved_name(module_name) for module_name in module_names)

# Generated at 2022-06-23 15:26:40.337719
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=True) == _RESERVED_NAMES



# Generated at 2022-06-23 15:26:49.610003
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Check that we get the expected number of reserved names
    # (Note: if this test fails, it is likely that a new reserved name has been
    # added and this test hasn't been updated yet.)

    public_reserved_names = get_reserved_names(include_private=False)
    private_reserved_names = get_reserved_names(include_private=True)

    assert len(public_reserved_names) == 48
    assert len(private_reserved_names) == 51

    # Check that the public and private reserved names are disjoint
    assert len(public_reserved_names.intersection(private_reserved_names)) == 0

    # Check for some specific reserved names
    assert 'name' in public_reserved_names and 'name' in private_reserved_names
    assert is_reserved_name

# Generated at 2022-06-23 15:26:51.815930
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # the reserved names list is dynamic, so just make sure that the function returns True
    # for one of the names
    assert is_reserved_name("pre_tasks")

# Generated at 2022-06-23 15:26:59.696040
# Unit test for function is_reserved_name
def test_is_reserved_name():
    ''' This function is a unit test for is_reserved_name '''

    # test all reserved names
    for name in get_reserved_names():
        assert is_reserved_name(name) is True, name

    # test names that aren't reserved
    assert is_reserved_name('name') is False
    assert is_reserved_name('user') is False
    assert is_reserved_name('become') is False
    assert is_reserved_name('with_inventory_hostnames') is False
    assert is_reserved_name('with_fileglob') is False

# Generated at 2022-06-23 15:27:05.277000
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('role_path')
    assert is_reserved_name('from_yaml')
    assert is_reserved_name('name')
    assert is_reserved_name('register')
    assert is_reserved_name('vars')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('private')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('bar')

# Generated at 2022-06-23 15:27:11.397646
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' check that reserved names are properly returned '''

# Generated at 2022-06-23 15:27:20.484421
# Unit test for function is_reserved_name
def test_is_reserved_name():
    '''
    function test_is_reserved_name contains two tests:
    1) is_reserved_name returns True for a reserved name
    2) is_reserved_name returns False for a non reserved name
    '''

    class TestModule(object):
        def __init__(self):
            self.exit_json = lambda x, y: None

    mod = TestModule()

    # Test 1
    assert is_reserved_name('hosts'), "Expected a reserved name of 'hosts'!"
    # Test 2
    assert not is_reserved_name('test'), "Expected a non-reserved name of 'test'!"



# Generated at 2022-06-23 15:27:22.048373
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name)

# Generated at 2022-06-23 15:27:27.673655
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = dict(
        name='myplay',
        hosts='webservers',
        become='yes',
        become_method='sudo',
        become_user='root',
        gather_facts='yes',
        tasks=[],
        handlers=[]
    )
    warn_if_reserved(myvars)

    # with the following vars, all should be warned
    # gather_facts should not be warned as it is not in the reserved list
    myvars['hosts'] = 'hosts'
    myvars['name'] = 'name'
    myvars['tasks'] = 'tasks'
    myvars['handlers'] = 'handlers'
    warn_if_reserved(myvars)



# Generated at 2022-06-23 15:27:34.363250
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    Test the warn_if_reserved function.
    '''
    # Test using private names
    display.verbosity = 1
    data = list(get_reserved_names(include_private=True))
    warn_if_reserved(data)

    # Test using public names
    display.verbosity = 1
    data = list(get_reserved_names(include_private=False))
    warn_if_reserved(data)

# Generated at 2022-06-23 15:27:37.728798
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['name', 'hosts', 'gather_facts']
    warn_if_reserved(myvars)
    assert len(display._task_deprecations) == 3

# Generated at 2022-06-23 15:27:39.136446
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved('include', 'something_not_reserved')
    assert True

# Generated at 2022-06-23 15:27:45.779021
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('action') == True
    assert is_reserved_name('local_action') == False  # this one is implied by action
    assert is_reserved_name('foo') == False

    display.deprecated('test_docstring_playbook.test_playbook_syntax() is deprecated and will be removed in a future release')

# Generated at 2022-06-23 15:27:53.018759
# Unit test for function is_reserved_name
def test_is_reserved_name():
    names = get_reserved_names()

    # Valid reserved names
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('hosts_all') is True
    assert is_reserved_name('hosts_all_ungrouped') is True
    assert is_reserved_name('hosts_all_ungrouped_names') is True
    assert is_reserved_name('hosts_all_ungrouped_addresses') is True
    assert is_reserved_name('inventory_hostname') is True
    assert is_reserved_name('inventory_hostname_short') is True
    assert is_reserved_name('groups') is True
    assert is_reserved_name('group_names') is True

# Generated at 2022-06-23 15:28:03.660999
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import warnings
    import ansible.playbook.name_match as name_match

    # Catch and check a DeprecationWarning
    with warnings.catch_warnings(record=True) as w:
        # Cause a warning.
        name_match.warn_if_reserved({'test'}, {'test'})
        assert len(w) == 1
        assert issubclass(w[-1].category, DeprecationWarning)
        assert "Found variable using deprecated name" in str(w[-1].message)

    # Catch and check a warning
    with warnings.catch_warnings(record=True) as w:
        # Cause a warning.
        name_match.warn_if_reserved({'delegate_to'})
        assert len(w) == 1

# Generated at 2022-06-23 15:28:12.403099
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    display.verbosity = 3

# Generated at 2022-06-23 15:28:15.235373
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('private')

# Generated at 2022-06-23 15:28:16.738338
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('delegate_to')


# Generated at 2022-06-23 15:28:18.552711
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('when') == True
    assert is_reserved_name('foo') == False

# Generated at 2022-06-23 15:28:28.486102
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset(['role', 'block', 'any_errors_fatal', 'post_tasks', 'name', 'connection', 'gather_facts', 'any_errors_fatal', 'post_tasks', 'name', 'tasks', 'gather_facts', 'tags', 'when', 'always', 'local_action', 'loop', 'with_', 'register', 'ignore_errors', 'when'])

# Generated at 2022-06-23 15:28:29.752166
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')



# Generated at 2022-06-23 15:28:31.746546
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(_RESERVED_NAMES) > 1, 'reserved names list is empty'

# Generated at 2022-06-23 15:28:38.614195
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    public_reserved = get_reserved_names(include_private=False)

    assert isinstance(reserved, set)
    assert isinstance(public_reserved, set)
    assert 'include' in reserved
    assert not 'pre_tasks' in public_reserved
    assert 'pre_tasks' in reserved
    assert not 'vars' in reserved
    assert 'vars' in public_reserved



# Generated at 2022-06-23 15:28:42.436790
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert 'name' in get_reserved_names(include_private=False)
    assert 'serial' not in get_reserved_names()
    assert 'serial' in get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:28:50.601275
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('block')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('async')
    assert is_reserved_name('poll')
    assert is_reserved_name('handlers')
    assert is_reserved_name('vars')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('file')
    assert is_reserved_name('meta')
    assert is_reserved_name('include')

    assert is_

# Generated at 2022-06-23 15:28:54.352260
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set(['hosts', 'name', 'environment', 'roles'])
    private = set(['any_errors_fatal', 'become', 'delegate_to', 'serial', 'connection'])

    ret = get_reserved_names()
    assert ret == public.union(private)

    ret = get_reserved_names(include_private=False)
    assert ret == public



# Generated at 2022-06-23 15:29:05.478913
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Action _must_ be in the public list
    public_reserved_names = set(['hosts', 'name', 'remote_user', 'sudo', 'sudo_user', 'tags', 'action'])

    # These are the names that must be in private
    private_reserved_names = set(['connection', 'delegate_to', 'notify', 'register', 'until', 'retries', 'delay',
                                  'loop', 'loop_with_items', 'with_items', 'with_nested', 'with_fileglob',
                                  'with_sequence', 'with_random_choice', 'with_first_found', 'with_dict', 'with_dict',
                                  'with_file', 'with_together'])

    # With loop in the private list, with_ must also be

# Generated at 2022-06-23 15:29:13.479441
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert is_reserved_name('action')
    assert is_reserved_name('become')
    assert is_reserved_name('become_user')
    assert is_reserved_name('become_method')
    assert is_reserved_name('check_mode')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('name')
    assert is_reserved_name('tags')
    assert is_reserved_name('with_items')

    assert not is_reserved_name('foo')
    assert not is_reserved_name('with_bar')

# Generated at 2022-06-23 15:29:16.924970
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(set(['foo', 'gather_facts', 'hosts']))
    except SystemExit:
        pass
    else:
        assert False, "warn_if_reserved failed to detect an invalid variable name"

# Generated at 2022-06-23 15:29:25.329111
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:29:36.734415
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=False)

    # uncomment to print the list reserved_names
    #display.display(reserved_names)

    reserved_names_private = get_reserved_names(include_private=True)

    # uncomment to print the list reserved_names_private
    #display.display(reserved_names_private)

    assert set(reserved_names) == {'connection', 'delegate_to', 'gather_facts', 'local_action', 'name', 'tags', 'tasks', 'when', 'with_'}

# Generated at 2022-06-23 15:29:44.029525
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    orig_stdout = sys.stdout
    try:
        import StringIO
        sys.stdout = StringIO.StringIO()
        # Test 1
        warn_if_reserved(["testname"])
        result = sys.stdout.getvalue()
        assert result == ''

        # Test 2
        warn_if_reserved(["name", "testname"])
        result = sys.stdout.getvalue()
        assert 'Found variable using reserved name: name' in result
    finally:
        sys.stdout = orig_stdout