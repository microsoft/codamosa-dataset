

# Generated at 2022-06-23 15:19:55.032534
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    This test method needs to be in the same file as the warn_if_reserved method
    There is no practical way to import the module containing warn_if_reserved
    into a test without loading the module globally, which could have unintended consequences
    '''

    # This is a very simple check to see if any warnings were triggered, so it will not
    # detect all issues. A more thorough check would need to be added to a unit test
    from ansible.errors import AnsibleError
    from ansible.module_utils.six import StringIO

    test_output = StringIO()
    warn_if_reserved({'action': 'setup'}, ['test_reserved_name'])

# Generated at 2022-06-23 15:20:05.661224
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names() return results '''


# Generated at 2022-06-23 15:20:08.753654
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved = get_reserved_names()  # non-private names
    warn_if_reserved(reserved)



# Generated at 2022-06-23 15:20:11.964631
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # we'll use this function to unit test using assert_warn
    # see lib/ansible/utils/assertions.py in the test directory
    warn_if_reserved(['roles', 'name', 'include_vars'])

# Generated at 2022-06-23 15:20:16.840668
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    from ansible.plugins import module_loader
    myvars = set(module_loader.all(class_only=True))
    myvars.add('myvar')
    myvars.add('action')
    myvars.add('loop')
    myvars.add('debug')

    warn_if_reserved(myvars)  # should not fail, as _RESERVED_NAMES is frozen

# Generated at 2022-06-23 15:20:19.122388
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['name', 'private', 'register', 'when'])
    warn_if_reserved(['name', 'private', 'register', 'when'], additional=['gather_facts'])

# Generated at 2022-06-23 15:20:24.408577
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('local_action')
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert not is_reserved_name('bogus_name')

# Generated at 2022-06-23 15:20:29.449844
# Unit test for function is_reserved_name
def test_is_reserved_name():
    errmsg = "Expected the name '%s' to be considered reserved."
    assert is_reserved_name('name'), errmsg % 'name'
    assert is_reserved_name('action'), errmsg % 'action'
    assert is_reserved_name('roles'), errmsg % 'roles'
    assert not is_reserved_name('foobar'), errmsg % 'foobar'

# Generated at 2022-06-23 15:20:35.998939
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class TestVars(object):
        def __init__(self):
            self.baz = True
            self.tasks = True

        def __contains__(self, name):
            return name in ('foo', 'bar', 'tasks')

    vars = TestVars()

    display.verbosity = 3
    warn_if_reserved(vars, set())

    display.verbosity = 2
    warn_if_reserved(vars, set())

    display.verbosity = 1
    warn_if_reserved(vars, set())

# Generated at 2022-06-23 15:20:47.717212
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("any_playbook_keyword")
    assert is_reserved_name("connection")
    assert is_reserved_name("hosts")
    assert is_reserved_name("name")
    assert is_reserved_name("tags")
    assert is_reserved_name("when")
    assert is_reserved_name("roles")
    assert is_reserved_name("include_role")
    assert is_reserved_name("include")
    assert is_reserved_name("tasks")
    assert is_reserved_name("pre_tasks")
    assert is_reserved_name("post_tasks")
    assert is_reserved_name("notify")
    assert is_reserved_name("handlers")
    assert is_reserved_name("block")


# Generated at 2022-06-23 15:20:57.542524
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils._text import to_text
    from ansible import constants as C
    from ansible.module_utils.six import PY3
    import sys


# Generated at 2022-06-23 15:21:09.222025
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names() function '''

    public = set()
    private = set()
    tester = set()

    class_list = [Play, Role, Block, Task]
    for aclass in class_list:
        aobj = aclass()

        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    # local_action is implicit with action
    if 'action' in public:
        public.add('local_action')

    # loop implies with_
    if 'loop' in private or 'loop' in public:
        public.add('with_')

    tester = public.union(private)

    public.remove('any_errors_fatal')
    public

# Generated at 2022-06-23 15:21:12.798664
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    fakevars = dict(strategy='free',
                    serial=0,
                    serial_override=True,
                    connect_timeout=5,
                    action='setup',
                    pre_tasks=[{'action': 'set_fact', 'name': 'foo', 'value': 'bar'}])
    warn_if_reserved(fakevars)

# Generated at 2022-06-23 15:21:18.220802
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert 'name' in get_reserved_names()
    assert 'name' in _RESERVED_NAMES

    try:
        warn_if_reserved({'name': 'foo'})
    except KeyError:
        assert False, 'failed to warn about reserved name'

# Generated at 2022-06-23 15:21:20.565949
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert isinstance(get_reserved_names(), set)
    assert is_reserved_name('foobar') is False
    assert is_reserved_name('action') is True


# Generated at 2022-06-23 15:21:22.703102
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    print(reserved_names)
    assert 'serial' in reserved_names

test_get_reserved_names()

# Generated at 2022-06-23 15:21:26.055982
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert len(reserved) > 100
    assert 'hosts' in reserved
    assert 'tasks' in reserved
    assert 'include' in reserved
    assert 'vars' in reserved
    assert 'roles' in reserved

# Generated at 2022-06-23 15:21:37.059605
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Types of reserved names
    assert 'action' in _RESERVED_NAMES
    assert 'local_action' in _RESERVED_NAMES
    assert 'delegate_to' in _RESERVED_NAMES
    assert 'tags' in _RESERVED_NAMES
    assert 'when' in _RESERVED_NAMES
    assert 'become_user' in _RESERVED_NAMES
    assert 'become' in _RESERVED_NAMES
    assert 'become_method' in _RESERVED_NAMES
    assert 'become_flags' in _RESERVED_NAMES
    assert 'become_exe' in _RESERVED_NAMES

    # Types of reserved names (deprecated)
    assert 'with_' in _RESERVED_

# Generated at 2022-06-23 15:21:46.332449
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(False) == frozenset(['gather_facts', 'vars_prompt', 'vars_files', 'vars', 'local_action', 'action', 'tags', 'any_errors_fatal', 'serial', 'delegate_facts', 'hosts', 'name', 'tasks', 'meta', 'become', 'become_user', 'become_method', 'register', 'no_log', 'notify', 'ignore_errors', 'with_'])

# Generated at 2022-06-23 15:21:47.167683
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')

# Generated at 2022-06-23 15:21:50.676671
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in get_reserved_names():
        assert is_reserved_name(name) is True

    from ansible.utils.boolean import boolean
    assert is_reserved_name(boolean('FALSE')) is False

# Generated at 2022-06-23 15:21:52.496525
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['hosts', 'other_reserved'], ['other_reserved', 'foobar'])

# Generated at 2022-06-23 15:21:56.809927
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in _RESERVED_NAMES
    assert 'vars' in _RESERVED_NAMES
    assert 'name' in _RESERVED_NAMES
    assert 'name' not in get_reserved_names(include_private=False)


# Generated at 2022-06-23 15:22:03.449242
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Test with empty list
    warn_if_reserved([])

    # Test with empty list with additional reserved names
    warn_if_reserved([], ['foo', 'bar'])

    # Test with list containing no reserved names
    warn_if_reserved(['foo', 'bar'])

    # Test with list containing reserved names
    warn_if_reserved(['foo', 'tags', 'bar'])

# Generated at 2022-06-23 15:22:09.580211
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names(include_private=False)
    assert('action' in reserved_names)
    assert('when' in reserved_names)
    assert('with_' in reserved_names)
    assert('failed_when' in reserved_names)
    assert('changed_when' in reserved_names)
    assert('vars' in reserved_names)
    assert('tags' in reserved_names)
    assert('any_errors_fatal' in reserved_names)
    assert('block' in reserved_names)
    assert('task' in reserved_names)
    assert('with_items' in reserved_names)
    assert('register' in reserved_names)

# Generated at 2022-06-23 15:22:13.855125
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    my_variable = AnsibleUnicode('action')
    assert is_reserved_name(my_variable)



# Generated at 2022-06-23 15:22:15.944889
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert len(reserved) > 0
    assert 'hosts' in reserved
    assert 'connection' in reserved

# Generated at 2022-06-23 15:22:19.922814
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # reserved names test
    warn_if_reserved(['name', 'hosts', 'vars', 'tasks'], ['test'])

    # non-reserved names test
    warn_if_reserved(['test'], ['var'])

# Generated at 2022-06-23 15:22:21.448123
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('become')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:22:26.979372
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Test that the reserved names don't change
    reserved_names = get_reserved_names()
    assert 'tags' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names

    # Test that the number of reserved names is at least as great as
    # the number of attributes of just the block object
    block = Block()
    assert len(reserved_names) >= len(block.__dict__['_attributes'])



# Generated at 2022-06-23 15:22:34.722234
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) > 0
    assert isinstance(get_reserved_names(), set)
    assert sorted(get_reserved_names()) == sorted(get_reserved_names(include_private=False))
    assert {'action', 'loop'} < get_reserved_names()
    assert {'action', 'loop'} < get_reserved_names(include_private=False)
    assert 'local_action' in get_reserved_names()
    assert 'local_action' not in get_reserved_names(include_private=False)
    assert 'with_' in get_reserved_names()
    assert 'with_' not in get_reserved_names(include_private=False)



# Generated at 2022-06-23 15:22:37.936958
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Field name with no conflicts
    assert is_reserved_name('not_a_special_name') is False

    # Field name 'hosts' conflicts with reserved word
    assert is_reserved_name('hosts') is True

# Generated at 2022-06-23 15:22:38.612029
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['roles', 'private'])

# Generated at 2022-06-23 15:22:43.105897
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # If we run the function we expect to get a set of strings
    assert(type(get_reserved_names()) is set)

    # If we pass a valid include_private parameter we expect to get a set of strings
    assert(type(get_reserved_names(include_private=False)) is set)

    # If we pass an invalid include_private parameter we expect to get a set of strings
    assert(type(get_reserved_names(include_private=1)) is set)


# Generated at 2022-06-23 15:22:54.877731
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' function to test_warn_if_reserved '''

    # empty dictionary
    myvars = {}
    additional = None
    warn_if_reserved(myvars, additional)

    # no conflict with reserved name
    myvars = {'test': 'value'}
    warn_if_reserved(myvars, additional)

    # conflict with reserved name
    myvars = {'test': 'value', 'playbook': 'test'}
    warn_if_reserved(myvars, additional)

    # conflict with reserved name and custom additional
    myvars = {'test': 'value', 'playbook': 'test', 'additional': 'test'}
    additional = set()
    additional.add('additional')
    warn_if_reserved(myvars, additional)

# Generated at 2022-06-23 15:23:01.141877
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('become')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('ignore_unreachable')
    assert is_reserved_name('when')

    assert not is_reserved_name('foo')
    assert not is_reserved_name('bar')

# Generated at 2022-06-23 15:23:10.170300
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' Test warn_if_reserved function '''
    from ansible.playbook.task import Task
    from ansible.playbook import Play
    from ansible.playbook.role import Role

    # These are the items that should be found
    warning_test = {
        'action': [Task, Play],
        'loop': [Task]
    }

    # Test warnings
    for attribute, classes in warning_test.items():
        for aclass in classes:
            aobj = aclass()
            if attribute in aobj.__dict__['_attributes']:
                warn_if_reserved(attribute)

    # These are the items that should not be found
    no_warning_test = {
        'become_user': [Task, Play],
        'vars': [Task, Play, Role],
    }



# Generated at 2022-06-23 15:23:17.407895
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('include_role') is True
    assert is_reserved_name('gather_facts') is True
    assert is_reserved_name('when') is True
    assert is_reserved_name('async') is True
    assert is_reserved_name('poll') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('remote_user') is True
    assert is_reserved_name('connection') is True
    assert is_reserved_name('sudo') is True
    assert is_reserved_name('sudo_user') is True
    assert is_reserved_name('sudo_pass') is True
   

# Generated at 2022-06-23 15:23:21.268633
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in get_reserved_names():
        assert is_reserved_name(name)

    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-23 15:23:23.788589
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('action'))
    assert(not is_reserved_name('blah'))

# Generated at 2022-06-23 15:23:31.010535
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = _RESERVED_NAMES

    assert 'vars' in reserved
    assert 'hosts' in reserved
    assert 'roles' in reserved
    assert 'action' in reserved
    assert 'local_action' in reserved
    assert 'private' in reserved
    assert 'import_role' in reserved
    assert 'include_role' in reserved
    assert 'post_tasks' in reserved
    assert 'pre_tasks' in reserved
    assert 'block' in reserved
    assert 'register' in reserved
    assert 'always_run' in reserved

# Generated at 2022-06-23 15:23:42.646409
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''
    Tests warn_if_reserved
    '''

    # This test checks that we warn only if the variable name matches exactly a reserved name


# Generated at 2022-06-23 15:23:48.634022
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # valid
    assert(is_reserved_name('hosts'))
    assert(is_reserved_name('name'))

    # invalid
    assert(not is_reserved_name('bogus_name'))
    assert(not is_reserved_name('tasks'))

# Generated at 2022-06-23 15:23:58.644293
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # create list of existing vars
    my_vars = ['vars']
    my_vars.extend(get_reserved_names())

    # check that no warning is raised when we expect none
    def test_none(names, warning=False):
        warn_if_reserved(names, my_vars, warning)

    def test_warning(names, warning=True):
        warn_if_reserved(names, my_vars, warning)

    # test all combinations of private and public names
    for priv in get_reserved_names(include_private=True):
        for pub in get_reserved_names():
            test_none([pub])
            test_none([priv, pub])
            test_none([priv, pub, 'test_var'])

# Generated at 2022-06-23 15:24:09.073266
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("vars")
    assert is_reserved_name("private")
    assert is_reserved_name("private_key")
    assert is_reserved_name("gather_facts")
    assert is_reserved_name("connection")
    assert is_reserved_name("sudo")
    assert is_reserved_name("sudo_user")
    assert is_reserved_name("shell")
    assert is_reserved_name("known_hosts")
    assert is_reserved_name("remote_tmp")
    assert is_reserved_name("local_tmp")
    assert is_reserved_name("remote_user")
    assert is_reserved_name("sudo_user")
    assert is_reserved_name("transport")

# Generated at 2022-06-23 15:24:10.309209
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("hosts")

# Generated at 2022-06-23 15:24:11.754437
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert reserved_names

    for name in reserved_names:
        assert is_reserved_name(name)



# Generated at 2022-06-23 15:24:15.692744
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['foo', 'action', 'other']
    warn_if_reserved(myvars)
    # check to see if any warning was logged
    display.verbosity = 1
    display.warning.assert_called_with('Found variable using reserved name: action')

# Generated at 2022-06-23 15:24:20.309628
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('bogus')


__all__ = ['get_reserved_names', 'warn_if_reserved', 'is_reserved_name', 'test_is_reserved_name']

# Generated at 2022-06-23 15:24:27.164685
# Unit test for function is_reserved_name

# Generated at 2022-06-23 15:24:35.308565
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    print(reserved_names)
    assert 'hosts' in reserved_names
    assert 'pre_tasks' in reserved_names
    assert 'roles' in reserved_names
    assert 'tasks' in reserved_names
    assert 'vars' in reserved_names
    assert 'playbook' in reserved_names
    assert 'action' in reserved_names
    assert 'local_action' in reserved_names
    assert 'name' in reserved_names
    assert 'tags' in reserved_names


# Generated at 2022-06-23 15:24:38.828210
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test against reserved names
    assert is_reserved_name('include') is True
    assert is_reserved_name('vars') is True

    # Test against non-reserved names
    assert is_reserved_name('nrs_include') is False
    assert is_reserved_name('nrs_vars') is False

# Generated at 2022-06-23 15:24:43.803729
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(myvars=dict(action=dict()), additional=dict(foo=list()))
        warn_if_reserved(myvars=dict(loop=list(), foo=list()), additional=dict(bar=dict()))
        warn_if_reserved(myvars=dict(vars=dict()))
    except:
        pass

# Generated at 2022-06-23 15:24:52.118925
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('become')
    assert is_reserved_name('gather_facts')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('force_handlers')
    assert is_reserved_name('serial')
    assert is_reserved_name('sudo_user')
    assert is_reserved_name('connection')
    assert is_reserved_name('vars')

    assert not is_reserved_name('roles')
    assert not is_reserved_name('tasks')
    assert not is_reserved_name('pre_tasks')
    assert not is_reserved_name('post_tasks')


# Generated at 2022-06-23 15:25:00.104922
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    #Dictionary to store names of functions
    test_names = {'warn_if_reserved': warn_if_reserved,
                  'get_reserved_names': get_reserved_names,
                  'is_reserved_name': is_reserved_name}

    # Test if the function names are printed in the name
    assert 'warn_if_reserved' in test_names.keys()
    assert 'get_reserved_names' in test_names.keys()
    assert 'is_reserved_name' in test_names.keys()


# Generated at 2022-06-23 15:25:06.428606
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved_names = get_reserved_names()
    assert 'playbook' in reserved_names
    assert 'roles' in reserved_names
    assert 'block' in reserved_names
    assert 'action' in reserved_names
    assert 'task' in reserved_names
    assert 'local_action' in reserved_names
    assert 'with_' in reserved_names



# Generated at 2022-06-23 15:25:12.799304
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'any_errors_fatal' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names()
    assert 'include' in get_reserved_names(include_private=True)
    assert 'name' not in get_reserved_names(include_private=False)


# Unit tests for disallow_executable_api

# Generated at 2022-06-23 15:25:23.116636
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import copy

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Block, Task]

    # make a unique set of all attributes across all objects
    all_attrs = set()
    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            # keep private attributes for later use
            all_attrs.add(attribute['name'])

    # new PEP8 attribute names

# Generated at 2022-06-23 15:25:34.345160
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert Play.vars_prompt not in reserved_names
    assert Play.vars_files not in reserved_names
    assert Play.vars_prompt not in reserved_names
    assert Play.vars_prompt not in reserved_names
    assert 'connection' in reserved_names
    assert 'sudo' in reserved_names
    assert 'sudo_user' in reserved_names
    assert 'remote_user' not in reserved_names
    assert 'roles' in reserved_names
    assert 'serial' in reserved_names
    assert 'remote_user' in reserved_names
    assert 'hosts' in reserved_names
    assert 'name' in reserved_names
    assert 'when' in reserved_names
    assert 'loop' in reserved_names

# Generated at 2022-06-23 15:25:36.202100
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') == True
    assert is_reserved_name('not_reserved') == False

# Generated at 2022-06-23 15:25:39.578482
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('private')
    assert is_reserved_name('local_action')
    assert is_reserved_name('with_')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:25:43.510138
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test reserved names warning '''

    test_list = ['roles', 'tasks', 'pre_tasks', 'post_tasks', 'include_role']
    myvars = ['roles', 'tasks', 'pre_tasks', 'post_tasks', 'include_role']
    test_object = warn_if_reserved(myvars)
    assert not test_object



# Generated at 2022-06-23 15:25:45.558133
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(["name", "hosts", "vars", "actions"]) != 0

# Generated at 2022-06-23 15:25:46.161860
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    pass

# Generated at 2022-06-23 15:25:54.295753
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'task' in reserved_names, "%s should have contained 'task'" % reserved_names
    assert 'vars' in reserved_names, "%s should have contained 'vars'" % reserved_names
    assert 'action' in reserved_names, "%s should have contained 'action'" % reserved_names
    assert 'private' not in reserved_names, "%s should not have contained 'private'" % reserved_names
    assert 'become' not in reserved_names, "%s should not have contained 'become'" % reserved_names
    assert 'become_user' in reserved_names, "%s should have contained 'become_user'" % reserved_names
    reserved_names = get_reserved_names(include_private=True)

# Generated at 2022-06-23 15:26:01.608528
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # pylint: disable=unused-variable
    with Display():
        # test with private names
        warn_if_reserved(['hosts', 'roles', 'post_tasks', 'pre_tasks'],
                         additional=set(['tags', 'gather_facts']))

        # test without private names
        warn_if_reserved(['hosts', 'roles', 'post_tasks', 'pre_tasks'])


# Generated at 2022-06-23 15:26:08.475860
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # Reserved names should return True
    assert is_reserved_name('any_playbook_keyword') is True
    assert is_reserved_name('become_user') is True
    assert is_reserved_name('delegate_to') is True

    # Non reserved names should return False
    assert is_reserved_name('any_normal_keyword') is False
    assert is_reserved_name('_any_private_keyword') is False

# Generated at 2022-06-23 15:26:10.933944
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(True == is_reserved_name('hosts'))
    assert(False == is_reserved_name('host'))

# Generated at 2022-06-23 15:26:14.021986
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    class TestPlay(object):
        vars = dict(action='test')

    play = TestPlay()

    warn_if_reserved(play.vars)

# Generated at 2022-06-23 15:26:24.876977
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:31.224730
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # FIXME: add reserved names from not-implemented features
    reserved = frozenset(['become', 'become_user', 'tags', 'hosts', 'roles', 'tasks', 'vars', 'block', 'action',
                          'local_action', 'delegate_to', 'ignore_errors', 'loop', 'with_',
                          'async', 'poll', 'when', 'name', 'register', 'notify', 'first_available_file'])

    assert(reserved == _RESERVED_NAMES)

# Generated at 2022-06-23 15:26:40.024703
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:50.090284
# Unit test for function is_reserved_name

# Generated at 2022-06-23 15:26:51.996516
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('bogus') == False)
    assert(is_reserved_name('connection') == True)

# Generated at 2022-06-23 15:26:55.975030
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars'])
    warn_if_reserved(['vars', 'action'])
    warn_if_reserved(['vars', 'local_action'])
    warn_if_reserved(['vars', 'with_'])

# Generated at 2022-06-23 15:26:57.369077
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts': 'localhost'})



# Generated at 2022-06-23 15:27:02.764945
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    myvars = {}
    myvars['hosts'] = AnsibleUnicode('all')
    myvars['tasks'] = []
    myvars['vars'] = {}
    myvars['vars']['foo'] = AnsibleUnicode('bar')

    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:27:10.418190
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:27:21.092445
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names(include_private=False) == set(['block', 'connection', 'delegate_to', 'any_errors_fatal', 'gather_facts', 'hosts', 'max_fail_percentage', 'meta', 'name', 'notify', 'post_tasks', 'pre_tasks', 'roles', 'run_once', 'serial', 'sudo', 'sudo_user', 'tags', 'tasks', 'when', 'with_', 'with_items', 'with_fileglob', 'with_first_found', 'with_sequence', 'with_flattened', 'with_indexed_items', 'with_random_choice', 'with_nested', 'with_hashed_items', 'with_subelements', 'with_dict', 'action', 'local_action'])
    assert get_res

# Generated at 2022-06-23 15:27:27.583468
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    assert private == set(['private_role_vars', 'private_vars'])

# Generated at 2022-06-23 15:27:36.533922
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES == frozenset(['roles', 'role_path', 'gather_facts', 'no_log', 'any_errors_fatal', 'any_unreachable_fatal', 'serial', 'max_fail_percentage', 'block', 'tasks', 'ignore_errors', 'local_action', 'block', 'when', 'rescue', 'always', 'name', 'sudo', 'sudo_user', 'setup', 'action', 'async', 'poll', 'notify', 'with_', 'env', 'transport', 'become', 'become_user', 'become_method', 'other_hosts'])

# Generated at 2022-06-23 15:27:38.238978
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('foo')
    assert is_reserved_name('role')

# Generated at 2022-06-23 15:27:40.894222
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'name'])
    warn_if_reserved(['vars', 'name', 'action'])

# Generated at 2022-06-23 15:27:50.431462
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names_list = get_reserved_names()
    assert 'connection' in names_list
    assert 'sudo' in names_list
    assert 'sudo_user' in names_list
    assert 'vars' in names_list
    assert 'vars_prompt' in names_list
    assert 'tags' in names_list
    assert 'name' in names_list
    assert 'roles' in names_list
    assert 'hosts' in names_list
    assert 'gather_facts' in names_list
    assert 'become' in names_list
    assert 'register' in names_list
    assert 'notify' in names_list
    assert 'delegate_to' in names_list
    assert 'run_once' in names_list
    assert 'environment' in names_list
    assert 'no_log'

# Generated at 2022-06-23 15:27:54.342961
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' Test for function get_reserved_names '''
    print("Testing reserved names")
    print(get_reserved_names())

# Generated at 2022-06-23 15:28:04.553417
# Unit test for function get_reserved_names
def test_get_reserved_names():
    from ansible.utils.display import Display
    from ansible.playbook.play import Play

    display = Display()
    display.verbosity = 3

    key_word_list = ['name', 'include', 'include_role', 'import_playbook', 'import_tasks', 'roles', 'pre_tasks', 'tasks', 'post_tasks', 'hosts', 'vars', 'vars_files', 'tags', 'gather_facts', 'register', 'environment']
    reserved_key_word_list = get_reserved_names()

    play = Play()

    # test get_reserved_names

# Generated at 2022-06-23 15:28:06.917588
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert is_reserved_name('include')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:28:15.665072
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('block')
    assert is_reserved_name('playbook')
    assert is_reserved_name('tasks')
    assert is_reserved_name('handlers')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('become')
    assert is_reserved_name('become_user')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('become_method')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('remote_tmp')
    assert is_reserved_name('become_flags')
    assert is_

# Generated at 2022-06-23 15:28:25.853379
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    reserved_names_wo_private = get_reserved_names(include_private=False)
    assert 'name' in reserved_names
    assert 'name' in reserved_names_wo_private
    assert 'hosts' in reserved_names
    assert 'hosts' in reserved_names_wo_private
    assert 'action' in reserved_names
    assert 'action' in reserved_names_wo_private
    assert 'local_action' in reserved_names
    assert 'loop' not in reserved_names
    assert 'with_' not in reserved_names
    assert 'remote_user' in reserved_names
    assert 'remote_user' in reserved_names_wo_private
    assert 'become' in reserved_names
    assert 'become' in reserved_names_wo_private


# Generated at 2022-06-23 15:28:34.819548
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class TestDisplay:
        def __init__(self):
            self.res = []

        def warning(self, msg):
            self.res.append(msg)

    # FIXME: remove loop/with_ dependency
    myvars = set(['gather_facts', 'tasks', 'name', 'hosts', 'action', 'local_action', 'loop', 'with_'])
    mydisplay = TestDisplay()
    display.display = mydisplay
    warn_if_reserved(myvars)
    mydisplay.res.sort()

# Generated at 2022-06-23 15:28:39.520166
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('action')
    assert not is_reserved_name('anyothername')
    assert not is_reserved_name('vars')
    print('is_reserved_name tested ok')

# Generated at 2022-06-23 15:28:41.314235
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'action' in reserved
    assert 'local_action' in reserved

# Generated at 2022-06-23 15:28:45.080699
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'block' in get_reserved_names()

    assert 'private' not in get_reserved_names()

    assert 'private' in get_reserved_names(include_private=True)



# Generated at 2022-06-23 15:28:52.842288
# Unit test for function is_reserved_name

# Generated at 2022-06-23 15:28:57.489880
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Note: can't test for 'vars' since that is added implicitly
    assert 'block' in get_reserved_names()
    assert len(get_reserved_names()) > 50
    assert len(_RESERVED_NAMES) > 50

# Generated at 2022-06-23 15:29:01.408716
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    # This fails because the reserved name 'action' is implicit with 'local_action'
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'loop' in get_reserved_names()



# Generated at 2022-06-23 15:29:06.142639
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for attribute in get_reserved_names():
        assert is_reserved_name(attribute)

    assert not is_reserved_name('foo_bar')
    assert not is_reserved_name('foobar')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:29:07.477505
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert _RESERVED_NAMES == get_reserved_names()

# Generated at 2022-06-23 15:29:17.436311
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils.six import PY3

    assert warn_if_reserved([]) is None
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    original_display = display.display
    protected_display = StringIO()
    display.display = protected_display.write

# Generated at 2022-06-23 15:29:23.201909
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({}) is None
    assert warn_if_reserved({'action': 'foo', 'playbook_path': 'bar'}) is None
    assert warn_if_reserved({'action': 'foo', 'playbook_path': 'bar', 'vars': 'foo'}) is None
    assert warn_if_reserved({'action': 'foo', 'playbook_path': 'bar', 'vars': 'foo'}, additional=('foo',)) is None



# Generated at 2022-06-23 15:29:33.896373
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # no warnings should be raised
    vars = {'foo': 'bar'}
    warn_if_reserved(vars)

    # no warnings should be raised
    vars = {'baz': 'bar', 'hosts': 'localhost'}
    warn_if_reserved(vars)

    # warning should be raised because the vars dict has a reserved name
    vars = {'baz': 'bar', 'connection': 'localhost'}
    warn_if_reserved(vars)

    # no warnings should be raised
    vars = {'baz': 'bar', 'become_user': 'root'}
    warn_if_reserved(vars)

    # no warnings should be raised because additional is not given
    vars = {'become_user': 'root'}
    warn_if_

# Generated at 2022-06-23 15:29:34.544619
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # FIXME: add tests
    pass

# Generated at 2022-06-23 15:29:42.630277
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils.basic import AnsibleModule

    reserved = get_reserved_names(include_private=False)  # exclude private names
    reserved.add('other_reserved_name')
    reserved.add('reserved_with_underscores')

    # Create a bunch of reserved names and non-reserved names
    vars = {}
    for name in reserved:
        vars['ok_name'] = 'ok_value'
    for name in reserved:
        vars[name] = 'reserved_value'

    m = AnsibleModule(argument_spec={'vars': {'type': 'dict', 'default': {}}})

    # Call the function
    warn_if_reserved(vars, additional=reserved)

    # Extract the module json results, to test the result

# Generated at 2022-06-23 15:29:45.308444
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert len(_RESERVED_NAMES) > 10  # just check that we have some items
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert not is_reserved_name('not_a_reserved_name')

