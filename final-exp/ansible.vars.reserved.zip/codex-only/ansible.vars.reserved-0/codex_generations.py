

# Generated at 2022-06-23 15:19:42.736390
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:19:54.037978
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ansible_playbook_names = ['name', 'hosts', 'gather_facts', 'any_errors_fatal', 'force_handlers',
                              'serial', 'max_fail_percentage', 'remote_user', 'sudo_user', 'sudo', 'sudo_flags',
                              'connection', 'transport', 'become', 'tags', 'vars', 'vars_files', 'roles',
                              'role_names', 'tasks', 'tags', 'handlers', 'pre_tasks', 'post_tasks',
                              'pre_tasks', 'post_tasks', 'vars', 'vars_files', 'include_vars',
                              'pre_tasks', 'post_tasks', 'vars', 'vars_files', 'cacheable']


# Generated at 2022-06-23 15:20:02.877120
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(dict(playbook_basedir='/tmp/foo'))
    warn_if_reserved(dict(playbook_basedir=[1,2,3]))
    warn_if_reserved(dict(playbook_basedir=[1,2,3]), additional=['foo', 'bar'])
    warn_if_reserved(dict(playbook_basedir=[1,2,3], foo='bar'))
    warn_if_reserved(dict(playbook_basedir=[1,2,3], foo='bar'), additional=['playbook_basedir', 'foo'])

# Generated at 2022-06-23 15:20:05.981903
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Test reserved names
    assert is_reserved_name('hosts')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('this_is_not_a_reserved_name')



# Generated at 2022-06-23 15:20:12.067269
# Unit test for function is_reserved_name
def test_is_reserved_name():

    names = ['playbook_dir', 'playbook_path', 'play', 'plays', 'roles', 'role_path',
            'block', 'tasks', 'tasks_path', 'vars', 'role_names', 'include_role',
            'include_tasks', 'include_playbook']

    for name in names:
        assert is_reserved_name(name)


# Generated at 2022-06-23 15:20:14.612119
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved({'action': {'module': 'fake', 'args': 'fake'}})
    except SystemExit:
        assert False

# Generated at 2022-06-23 15:20:24.098805
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:20:27.479398
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'name' in get_reserved_names()
    assert get_reserved_names(include_private=False).intersection(get_reserved_names()) == get_reserved_names(include_private=False)

# Generated at 2022-06-23 15:20:32.420933
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'vars': 'handled internally'})
    warn_if_reserved({'action': 'conflicts with local_action'})
    warn_if_reserved({'local_action': 'conflicts with action'})
    warn_if_reserved({'loop': 'conflicts with with_'})
    warn_if_reserved({'with_': 'conflicts with loop'})


# Generated at 2022-06-23 15:20:35.107794
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('local_action')
    assert is_reserved_name('vars')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:20:38.022659
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # No statements should be printed out
    warn_if_reserved(['name', 'test_var'])
    # Test that a statement will be printed out
    warn_if_reserved(['name', 'action', 'test_var'])

# Generated at 2022-06-23 15:20:39.211052
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'delegate_to'])

# Generated at 2022-06-23 15:20:41.759701
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = {'reserved_var': 'foo'}
    warn_if_reserved(myvars)


# Generated at 2022-06-23 15:20:51.727478
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for varname in ['action', 'name', 'hosts', 'gather_facts', 'serial', 'max_fail_percentage', 'any_errors_fatal',
                    'remote_user', 'connection', 'become', 'become_method', 'become_user', 'vars', 'vars_files',
                    'vars_prompt', 'vault_password_files', 'tags', 'skip_tags', 'when', 'delegate_to', 'notify',
                    'local_action', 'rescue', 'always', 'pre_tasks', 'post_tasks', 'environment', 'no_log',
                    'register']:
        assert is_reserved_name(varname) is True

# Generated at 2022-06-23 15:20:59.639057
# Unit test for function is_reserved_name
def test_is_reserved_name():
    class Foo(object):
        pass
    o = Foo()
    o.playbook = Play()
    o.play = Play()
    o.role = Role()
    o.block = Block()
    o.task = Task()

    # returns False if name is not reserved
    assert not is_reserved_name('a')
    assert not is_reserved_name('b')

    # returns True if name is reserved
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('serial')
    assert is_reserved_name('action')
    assert is_reserved_name('block')
    assert is_reserved_name('blocks')
    assert is_reserved_name('tags')

    # check if function is_reserved_name works with objects
    assert not is_reserved

# Generated at 2022-06-23 15:21:01.366893
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['vars', 'name', 'random'])

# Generated at 2022-06-23 15:21:11.545146
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_bytes
    import ansible.constants as C

    display = Display()
    saved_display = C.DEFAULT_DISPLAY_ARGS
    saved_warn = C.ACTION_WARNINGS
    C.DEFAULT_DISPLAY_ARGS = {'verbosity': 1}
    C.ACTION_WARNINGS = True

# Generated at 2022-06-23 15:21:23.547368
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:21:25.434309
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert not is_reserved_name('something else')


# Generated at 2022-06-23 15:21:29.921919
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved = get_reserved_names()
    for name in reserved:
        assert is_reserved_name(name)

    for name in ('not', 'a', 'reserved', 'name'):
        assert not is_reserved_name(name)

# Generated at 2022-06-23 15:21:40.202112
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('when') == True
    assert is_reserved_name('task') == False
    assert is_reserved_name('role') == False
    assert is_reserved_name('block') == False
    assert is_reserved_name('action') == True
    assert is_reserved_name('handler') == True
    assert is_reserved_name('with_') == True
    assert is_reserved_name('local_action') == True
    assert is_reserved_name('include_role') == True
    assert is_reserved_name('include_tasks') == True
    assert is_reserved_name('include_vars') == True
    assert is_reserved_name('pre_tasks') == True
    assert is_reserved_name('post_tasks') == True


# Generated at 2022-06-23 15:21:41.752425
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert not is_reserved_name('foobar')

# Generated at 2022-06-23 15:21:42.584439
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:21:49.979797
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # Get reserved names and check for expected names in the result.
    reserved_names = get_reserved_names()
    assert 'any_errors_fatal' in reserved_names
    assert 'connection' in reserved_names
    assert 'ignore_errors' in reserved_names


# Generated at 2022-06-23 15:21:59.778098
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_reserved = set()
    private_reserved = set()

    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private_reserved.add(attribute)
            else:
                public_reserved.add(attribute)

    # local_action is implicit with action
    if 'action' in public_reserved:
        public_reserved.add('local_action')

    # loop implies with_
    if 'loop' in private_reserved or 'loop' in public_reserved:
        public_reserved.add('with_')


# Generated at 2022-06-23 15:22:02.666831
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('banana')
    assert is_reserved_name('action')
    assert is_reserved_name('become_user')
    assert is_reserved_name('include_role')
    assert is_reserved_name('vars')

# Generated at 2022-06-23 15:22:08.635532
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    invalid_vars = [
        'action', 'delegate_to', 'local_action', 'loop', 'with_', 'include', 'roles',
        'vars', 'include_vars', 'import_playbook', 'import_role',
    ]
    warn_if_reserved(invalid_vars)

    # FIXME: remove after with_ is not only deprecated but removed
    invalid_vars = ['loop']
    warn_if_reserved(invalid_vars, additional=set(['with_']))

    valid_vars = ['something_else']
    warn_if_reserved(valid_vars)

# Generated at 2022-06-23 15:22:19.600404
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(['action']) == None
    assert warn_if_reserved(['not_a_reserved_name']) == None
    assert warn_if_reserved(['action', 'not_a_reserved_name']) == None
    assert warn_if_reserved(['action', 'not_a_reserved_name', 'local_action']) == None
    assert warn_if_reserved(['action', 'not_a_reserved_name', 'with_']) == None
    assert warn_if_reserved(['action', 'not_a_reserved_name', 'loop']) == None
    assert warn_if_reserved(['action', 'not_a_reserved_name', 'lookup_plugins']) == None

# Generated at 2022-06-23 15:22:22.792573
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    assert 'roles' in _RESERVED_NAMES
    assert 'tasks' in _RESERVED_NAMES
    assert 'pre_tasks' in _RESERVED_NAMES
    assert 'post_tasks' in _RESERVED_NAMES

# Generated at 2022-06-23 15:22:25.544521
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved = get_reserved_names()
    for name in reserved:
        assert is_reserved_name(name)
    assert not is_reserved_name("hosts")
    assert not is_reserved_name("user")



# Generated at 2022-06-23 15:22:33.414305
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Set up a fake module object with a _load_params method which does nothing
    module = type('FakeModule', (), {'_load_params' : lambda self: None})

    # Warn if 'action' is a variable
    args = {'action' : 'ping', 'vars' : {'action' : True}, 'module' : module}
    warn_if_reserved(args, {'action'})

    # Warn if 'module' is a variable
    args = {'action' : 'ping', 'vars' : {'module' : True}, 'module' : module}
    warn_if_reserved(args, {'module'})

    # Skip other variables

# Generated at 2022-06-23 15:22:39.267559
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("roles")
    assert is_reserved_name("role_path")
    assert is_reserved_name("name")
    assert is_reserved_name("local_action")
    assert is_reserved_name("with_")
    assert not is_reserved_name("space")
    assert not is_reserved_name("the")
    assert not is_reserved_name("moon")



# Generated at 2022-06-23 15:22:41.376843
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    x = dict(action='test', loop='test', foo='test', bar='test', role_name='test', tasks='test', foo_dah='test')
    warn_if_reserved(x)

# Generated at 2022-06-23 15:22:49.063867
# Unit test for function get_reserved_names
def test_get_reserved_names():
    test_reserved_names = get_reserved_names()

    # Check inclusion of all previously checked names
    assert 'name' in test_reserved_names
    assert 'any_errors_fatal' in test_reserved_names
    assert 'environment' in test_reserved_names
    assert 'sudo' in test_reserved_names
    assert 'sudo_user' in test_reserved_names
    assert 'transport' in test_reserved_names
    assert 'vars' in test_reserved_names

    # Check that some names that should not be included are not
    assert 'my_var' not in test_reserved_names
    assert 'my_var_name' not in test_reserved_names

    # Check that private names are included when told to be

# Generated at 2022-06-23 15:22:55.905033
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['a', 'b', 'tasks', 'asdfg']
    warn_if_reserved(myvars)
    myvars = ['a', 'b', 'metadatas', 'asdfg']
    warn_if_reserved(myvars)
    myvars = ['a', 'b', 'asdfg']
    warn_if_reserved(myvars)


if __name__ == '__main__':
    test_warn_if_reserved()

# Generated at 2022-06-23 15:23:00.806360
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('vars')
    assert is_reserved_name('include')
    assert is_reserved_name('with_')
    assert not is_reserved_name('tasks')
    assert not is_reserved_name('roles')

# Generated at 2022-06-23 15:23:06.360562
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'hosts': 'localhost', 'vars': 'variable'})
    warn_if_reserved({'hosts': 'localhost', 'vars': 'variable', 'role_name': 'question'})
    warn_if_reserved({'hosts': 'localhost', 'vars': 'variable', 'priority': 'system'})
# test end

if __name__ == '__main__':
    test_warn_if_reserved()

# Generated at 2022-06-23 15:23:14.383472
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'vars_prompt' in get_reserved_names()
    assert 'prompt' not in get_reserved_names()
    assert 'block' not in get_reserved_names()
    assert 'pre_tasks' not in get_reserved_names()
    assert 'post_tasks' not in get_reserved_names()
    assert 'notify' not in get_reserved_names()
    assert 'handlers' not in get_reserved_names()


# Generated at 2022-06-23 15:23:17.280740
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.playbook.play_context import PlayContext
    # test reserved name
    pc = PlayContext()
    pc._merge_dicts(dict(remote_user='root'), dict(connection='ssh', action='something'))
    result = pc.serialize()
    assert 'action' in result
    assert 'something' in result

# Generated at 2022-06-23 15:23:22.913493
# Unit test for function get_reserved_names
def test_get_reserved_names():
    expected_public = set(['roles', 'post_tasks', 'no_log', 'private', 'port', 'become_user', 'any_errors_fatal',
                           'transport', 'remote_user', 'pre_tasks', 'become_method', 'handler_tasks', 'meta', 'tags',
                           'sudo', 'serial', 'tasks', 'become', 'role_path', 'vars', 'notify', 'sudo_user', 'serial',
                           'serial_batch', 'forks', 'serial_batch', 'serial_batch_size', 'connection',
                           'remote_addr', 'environment', 'local_action', 'when', 'with_'])

# Generated at 2022-06-23 15:23:27.850668
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:23:30.478495
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved(set(['connection', 'vars', 'invalid_var'])) is None

# Generated at 2022-06-23 15:23:42.394962
# Unit test for function is_reserved_name
def test_is_reserved_name():

    assert is_reserved_name('hosts') is True
    assert is_reserved_name('vars') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('action') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('block') is True
    assert is_reserved_name('async') is True
    assert is_reserved_name('delegate_to') is True
    assert is_reserved_name('delay') is True
    assert is_reserved_name('environment') is True
    assert is_reserved_name('first_available_file') is True
    assert is_reserved_name('inventory_hostname') is True
    assert is_reserved_name('notify') is True


# Generated at 2022-06-23 15:23:52.831944
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function tests that get_reserved_names is indeed returning a hardcoded list of reserved names '''
    # FIXME: need to find a way to keep this updated with Play or any other structure having the notion of reserved keyowrd


# Generated at 2022-06-23 15:24:03.408598
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test set of normal reserved names
    base_reserved = get_reserved_names(include_private=False)
    assert len(base_reserved) > 0
    assert 'hosts' in base_reserved
    assert 'hosts' in _RESERVED_NAMES
    assert '_raw_params' not in base_reserved
    assert '_raw_params' in _RESERVED_NAMES
    assert 'become' in _RESERVED_NAMES

    # test set of all reserved names
    all_reserved = get_reserved_names(include_private=True)
    assert len(all_reserved) > len(base_reserved)
    assert 'become' in all_reserved
    assert '_raw_params' in all_reserved
    assert '_raw_params'

# Generated at 2022-06-23 15:24:05.073427
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert not warn_if_reserved({'loop':1, 'when':1, 'with_':1})

# Generated at 2022-06-23 15:24:07.110214
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(['vars', 'name', 'foo'])
    except:
        assert False, 'warn_if_reserved raised an exception'


# Generated at 2022-06-23 15:24:13.027388
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.executor.play_iterator import PlayIterator
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

    display.verbosity = 3
    pi = PlayIterator()
    tqm = TaskQueueManager(pi, None, None)
    vars_manager = VariableManager()
    warn_if_reserved(vars_manager.vars)

# Generated at 2022-06-23 15:24:23.800693
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert isinstance(warn_if_reserved(['vars']), None)
    assert isinstance(warn_if_reserved(['action', 'vars']), None)
    assert isinstance(warn_if_reserved(['action', 'vars', 'block']), None)
    assert isinstance(warn_if_reserved(['action', 'vars', 'block', 'include_role']), None)
    assert isinstance(warn_if_reserved(['action', 'vars', 'async']), None)
    assert isinstance(warn_if_reserved(['no_log', 'vars']), None)
    assert isinstance(warn_if_reserved(['async', 'vars']), None)

# Generated at 2022-06-23 15:24:28.468791
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this unit tests the internal function get_reserved_names '''
    result = frozenset(get_reserved_names())
    assert _RESERVED_NAMES == result, "Failure: result '%s' does not equal expected value '%s'" % (result, _RESERVED_NAMES)

# Generated at 2022-06-23 15:24:33.027892
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    test_vars = set(['roles', 'async', 'gather_facts', 'hosts', 'serial'])
    test_additional = set(['no_log', 'register', 'only_if'])
    warn_if_reserved(test_vars, test_additional)



# Generated at 2022-06-23 15:24:36.935958
# Unit test for function get_reserved_names
def test_get_reserved_names():
    private_names = set(get_reserved_names(include_private=False))
    assert 'roles' in private_names
    assert 'loops' not in private_names


# Generated at 2022-06-23 15:24:39.497987
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'action' in names



# Generated at 2022-06-23 15:24:41.355433
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert not is_reserved_name('not_a_role')

# Generated at 2022-06-23 15:24:50.681314
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    reserved_names = _RESERVED_NAMES
    reserved_names_with_temp = reserved_names.union(set(['temp']))

    # test valid scenario, no warning expected
    warn_if_reserved(['temp', 'item', 'vars'], additional=set(['temp']))

    # test case when name is not reserved, no warning expected
    warn_if_reserved(['temp', 'item', 'vars'], additional=set(['temp1']))

    # test case when name is reserved, warning expected
    warn_if_reserved(['temp', 'item', 'vars'])

    # test case to see that expected warning is generated

# Generated at 2022-06-23 15:24:55.613258
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('roles')
    assert is_reserved_name('block')
    assert is_reserved_name('rescue')

    assert not is_reserved_name('a_name')
    assert not is_reserved_name('roles_file')  # this is not reserved, but we do emit a warning for it

# Generated at 2022-06-23 15:25:00.910396
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    #
    # Test warn_if_reserved functionality
    #
    def _run_test(myvars, additional=None):

        # fake stdout method to capture warns
        def fake_display_warning(msg):
            output['warns'].append(msg)

        fake_display = Display()
        fake_display.warning = fake_display_warning

        output = dict(warns=[])

        # fake warn_if_reserved
        def fake_warn_if_reserved(myvars, additional=None):
            warn_if_reserved(myvars, additional=None)

        warn_if_reserved(myvars, additional=None)
        warn_if_reserved(myvars, additional=None)
        warn_if_reserved(myvars, additional=None)

    _run_

# Generated at 2022-06-23 15:25:03.035736
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names = get_reserved_names()
    assert 'roles' in names
    assert 'include' in names
    assert 'when' in names
    assert 'meta' in names

# Generated at 2022-06-23 15:25:12.981219
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import pytest
    from ansible.vars import post_validate
    from ansible.utils.vars import merge_hash

    def my_var_vars(play_context, current_task=None, include_deps=True):
        return {'reserved_name': 'reserved_value'}

    class MockPlay:
        def __init__(self):
            self.name = 'play_name'
            self.vars = {}
            self.roles = []
            self.tasks = []

    class MockTask:
        def __init__(self):
            self.name = 'task_name'
            self.vars = {'foo': 'bar'}
            self.role = None

    class MockRole:
        def __init__(self):
            self.name = 'role_name'

# Generated at 2022-06-23 15:25:23.196499
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # simple test case
    myvars = ('foo', 'bar', 'roles', 'name')
    warn_if_reserved(myvars)

    # no warnings
    myvars = ('foo', 'bar', 'roles', 'vars')
    warn_if_reserved(myvars)

    # test additional
    myvars = ('foo', 'bar', 'roles', 'name')
    warn_if_reserved(myvars, additional=('state'))
    myvars = ('foo', 'bar', 'roles', 'state')
    warn_if_reserved(myvars, additional=('state'))

    # test as role
    myvars = ('foo', 'bar', 'roles', 'name')

# Generated at 2022-06-23 15:25:25.850691
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('not_reserved')

# Generated at 2022-06-23 15:25:31.685381
# Unit test for function is_reserved_name
def test_is_reserved_name():
    tests = [
        ('hosts', True),
        ('tasks', True),
        ('vars', True),
        ('gather_facts', True),
        ('pre_tasks', True),
        ('post_tasks', True),
        ('post_tas', False),
    ]
    for varname, expect in tests:
        assert is_reserved_name(varname) == expect

# Generated at 2022-06-23 15:25:41.587568
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:51.976221
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_attrs = get_reserved_names()
    assert 'vars' in reserved_attrs
    assert 'name' in reserved_attrs
    assert 'action' in reserved_attrs
    assert 'local_action' in reserved_attrs
    assert 'delegate_to' in reserved_attrs
    assert 'delegate_facts' in reserved_attrs
    assert 'register' in reserved_attrs
    assert 'when' in reserved_attrs
    assert 'async' in reserved_attrs
    assert 'force_handlers' in reserved_attrs
    assert 'loop' in reserved_attrs
    assert 'with_' in reserved_attrs
    assert '_raw_params' in reserved_attrs
    assert '_role_name' in reserved_attrs
    assert '_block' in reserved_attrs

# Generated at 2022-06-23 15:26:00.627588
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test reserved names to see if it's valid
        required for PR against Ansible '''

    test_array = ['name', 'tags', 'when', 'become', 'connection', 'remote_user', 'port', 'roles',
                  'any_errors_fatal', 'serial', 'post_tasks', 'pre_tasks', 'gather_facts',
                  'hosts', 'vars', 'delegate_to', 'run_once']

    ret_array = get_reserved_names()

    for item in test_array:
        assert(item in ret_array)

# Generated at 2022-06-23 15:26:01.768184
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('tags') == True
    assert is_reserved_name('bogus_name') == False

# Generated at 2022-06-23 15:26:03.834351
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # Ansible 2.2.0 added 'tags' and 'when' as reserved names
    # This test ensures that future changes don't break the API
    # or cause unexpected warnings on valid playbook content
    assert 'tags' in _RESERVED_NAMES
    assert 'when' in _RESERVED_NAMES

# Generated at 2022-06-23 15:26:05.534609
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert type(get_reserved_names()) == set
    assert type(get_reserved_names(False)) == set

# Generated at 2022-06-23 15:26:16.170146
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # unit tests for get_reserved_names
    test_names = get_reserved_names()
    assert 'hosts' in test_names
    assert 'roles' in test_names
    assert 'tasks' in test_names
    assert 'pre_tasks' in test_names
    assert 'post_tasks' in test_names
    assert 'become' in test_names

    assert 'any_errors_fatal' in test_names
    assert 'always_run' in test_names
    assert 'become_method' in test_names
    assert 'become_user' in test_names
    assert 'delegate_to' in test_names
    assert 'environment' in test_names
    assert 'listen' in test_names
    assert 'no_log' in test_names
    assert 'register'

# Generated at 2022-06-23 15:26:18.784837
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert len(reserved) > 0
    assert isinstance(reserved, set)
    assert 'action' in reserved



# Generated at 2022-06-23 15:26:28.985102
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:26:31.065014
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert is_reserved_name('action')
    assert not is_reserved_name('ansible_user')

# Generated at 2022-06-23 15:26:33.784464
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    var_names = [
        'test_action',
        'test_vars',
        'test_include_role',
        'test_import_playbook',
        'test_private_test',
    ]
    warn_if_reserved(var_names)



# Generated at 2022-06-23 15:26:37.075995
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible import constants as C
    display.verbosity = 3
    myvars = set()
    myvars.add('async')
    myvars.add('dead')
    myvars.add('user')
    warn_if_reserved(myvars)
    display.verbosity = C.DEFAULT_VERBOSITY

# Generated at 2022-06-23 15:26:42.169072
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=False)
    assert 'vars' in reserved
    assert 'tags' in reserved

    reserved = get_reserved_names(include_private=True)
    assert 'vars' in reserved
    assert 'tags' in reserved
    assert 'hosts' in reserved
    assert 'name' in reserved



# Generated at 2022-06-23 15:26:45.553389
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES
    assert get_reserved_names(include_private=False) == get_reserved_names().difference(get_reserved_names(False))

# Generated at 2022-06-23 15:26:54.362933
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # list of reserved names
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'vars' in get_reserved_names()
    assert 'vars_files' in get_reserved_names()
    assert 'tasks' in get_reserved_names()

    # list of private names
    assert '_private' in get_reserved_names(include_private=True)
    assert '_private' not in get_reserved_names(include_private=False)

    # list with implicit names
    assert 'local_action' in get_reserved_names()
    assert 'with_' in get_reserved_names(include_private=False)

# Generated at 2022-06-23 15:26:59.245700
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names(False)) > 0
    assert len(get_reserved_names(True)) > 0
    assert len(get_reserved_names(True)) > len(get_reserved_names(False))
    assert get_reserved_names() == _RESERVED_NAMES


# Generated at 2022-06-23 15:27:03.140954
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test reserved words'''

    display.verbosity = 4
    warn_if_reserved(['roles', 'na', 'loop', 'with_items', 'name'], ['roles', 'na'])
    #assert('roles' not in _RESERVED_NAMES)

# Generated at 2022-06-23 15:27:07.172847
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    # Shows the list of reserved names
    # print("\nThe following are the reserved names:")
    # for name in sorted(reserved_names):
    #    print("- %s" % name)

    assert len(reserved_names) > 50



# Generated at 2022-06-23 15:27:19.065622
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # reserved names should be a set
    assert isinstance(get_reserved_names(), set)

    # reserved names should not be empty
    assert len(get_reserved_names()) != 0

    # iteratively compare the list of reserved names against
    # different classes in the playbook objects hierarchy.
    # if the name is found in the class' attribute list, then
    # it can be assumed that it is used by the class.
    #
    # this is not an exhaustive test, but proves that the function
    # get_reserved_names is not returning an empty set

    public_names = get_reserved_names(include_private=False)
    private_names = get_reserved_names(include_private=True)

    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        a

# Generated at 2022-06-23 15:27:25.432162
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert is_reserved_name('when')
    assert is_reserved_name('role_name')
    assert is_reserved_name('block')
    assert is_reserved_name('name')
    assert is_reserved_name('async')
    assert is_reserved_name('local_action')
    assert is_reserved_name('notify')
    assert is_reserved_name('with_')

    assert not is_reserved_name('vars')
    assert not is_reserved_name('hosts')
    assert not is_reserved_name('tags')

    assert is_reserved_name('register')

    assert not is_reserved_name('_private')
    assert not is_reserved_name('_private_loop')
   

# Generated at 2022-06-23 15:27:27.420796
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("local_action")



# Generated at 2022-06-23 15:27:29.836729
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(myvars=['async', 'with_'])

# Generated at 2022-06-23 15:27:36.345194
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    import sys
    if sys.version_info[0] >= 3 and sys.version_info[1] >= 4:
        from unittest import mock
    else:
        import mock

    myvars = {'hosts': 'localhost', 'roles': 'test'}
    with mock.patch('ansible.utils.display.Display.warning') as mock_warning:
        warn_if_reserved(myvars)
    mock_warning.assert_called_with('Found variable using reserved name: roles')

# Generated at 2022-06-23 15:27:38.838852
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert 'action' in reserved_names
    assert 'loop' in reserved_names
    assert 'with_' not in reserved_names

# Generated at 2022-06-23 15:27:49.381054
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible import context
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.playbook.play_context import PlayContext

    context._init_global_context(opt_help.parse_cli_args([]))
    pc = PlayContext()

# Generated at 2022-06-23 15:27:51.693621
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars') is False
    assert is_reserved_name('name') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('include_role') is True

# Generated at 2022-06-23 15:27:58.320818
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('vars') == True)
    assert(is_reserved_name('become') == True)
    assert(is_reserved_name('sudo') == True)
    assert(is_reserved_name('sudo_user') == True)
    assert(is_reserved_name('all') == True)
    assert(is_reserved_name('any') == True)
    assert(is_reserved_name('block') == True)
    assert(is_reserved_name('blockinfile') == True)
    assert(is_reserved_name('changed_when') == True)
    assert(is_reserved_name('command') == True)
    assert(is_reserved_name('comment') == True)
    assert(is_reserved_name('connection') == True)

# Generated at 2022-06-23 15:28:08.031763
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test get_reserved_names'''


# Generated at 2022-06-23 15:28:09.551926
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'hosts': 'hosts'}, additional={'hosts'}) is None

# Generated at 2022-06-23 15:28:10.063608
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    pass

# Generated at 2022-06-23 15:28:11.461254
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert not is_reserved_name('fake_name')

# Generated at 2022-06-23 15:28:17.540751
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'roles' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'action' in get_reserved_names()



# Generated at 2022-06-23 15:28:19.724571
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('roles'))
    assert(not is_reserved_name('rolez'))

# Generated at 2022-06-23 15:28:26.042185
# Unit test for function get_reserved_names
def test_get_reserved_names():
    public_names = get_reserved_names(include_private=False)
    private_names = get_reserved_names(include_private=True)

    # 'local_action' should show up when include_private is true or false
    assert 'local_action' in public_names
    assert 'local_action' in private_names

    # 'loop' and 'with_' should only show up when include_private is true
    assert 'loop' in private_names
    assert 'with_' in private_names
    assert 'loop' not in public_names
    assert 'with_' not in public_names

    # can't think of any way to test for the rest of these, since
    # we want to be able to add more reserved names as we go and
    # don't want to have to update tests every single time
    assert isinstance

# Generated at 2022-06-23 15:28:34.876126
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('action') == True
    assert is_reserved_name('roles') == True
    assert is_reserved_name('handlers') == True
    assert is_reserved_name('post_tasks') == True
    assert is_reserved_name('tags') == True
    assert is_reserved_name('when') == True
    assert is_reserved_name('name') == True
    assert is_reserved_name('become') == True
    assert is_reserved_name('vars') == False
    assert is_reserved_name('vars_prompt') == True
    assert is_reserved_name('vars_files') == True
    assert is_reserved_name('notify') == True
   

# Generated at 2022-06-23 15:28:37.911928
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = ['thingy', 'password', 'action', 'otherstuff', 'loop', 'delegate_to']
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:28:45.710824
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    display = Display()
    try:
        display.warning = lambda x: True
        warn_if_reserved(['become'])
    except Exception:
        raise AssertionError('warn_if_reserved did not recognize that "become" is a reserved name')

    try:
        display.warning = lambda x: True
        warn_if_reserved(['hosts'])
    except Exception:
        raise AssertionError('warn_if_reserved did not recognize that "hosts" is a reserved name')

# Generated at 2022-06-23 15:28:50.258482
# Unit test for function is_reserved_name
def test_is_reserved_name():
    fsnr = is_reserved_name
    assert fsnr('action')
    assert fsnr('name')
    assert fsnr('notify')
    assert not fsnr('foobar')
    assert not fsnr('notify_')
    assert fsnr('become')
    assert fsnr('with_-')
    assert fsnr('_raw_params')
    assert fsnr('_attributes')

# Generated at 2022-06-23 15:28:54.289249
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'action': 'test'})
    assert not warn_if_reserved({'action': 'test'}, additional={'action'})
    assert warn_if_reserved({'vars': 'test'})
    assert warn_if_reserved({'vars': 'test', 'action': 'test'})
    assert warn_if_reserved({'vars': 'test', 'vars_prompt': 'test'})

# Generated at 2022-06-23 15:28:57.855202
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    myvars = {'name': 'test', 'local_action': 'test', 'include': 'test', 'roles': 'test', 'tasks': 'test', 'playbook': 'test'}
    warn_if_reserved(myvars)

# Generated at 2022-06-23 15:29:01.025693
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert not is_reserved_name('TEST_RESERVED_VARIABLE')



# Generated at 2022-06-23 15:29:07.849245
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=False)

    # make sure an implicit name is in list
    assert('local_action' in reserved)

    # make sure a private name is NOT in list
    assert('loop' not in reserved)

    # make sure a name we expect is in list
    assert('async' in reserved)

    # make sure a name is not in list
    assert('snarf' not in reserved)



# Generated at 2022-06-23 15:29:10.563806
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    variables = [
        "action",
        "local_action",
        "with_",
        "loop"
    ]
    warn_if_reserved(variables)


# Generated at 2022-06-23 15:29:13.735616
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    r = get_reserved_names(include_private=False)
    # checking that the length is not zero and that the test var is not in the list
    assert len(r) > 0 and 'test' not in r

# Generated at 2022-06-23 15:29:16.246245
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(dict(debug=True))
    warn_if_reserved(dict(action=True, local_action=True))
    warn_if_reserved(dict(yum=True, action=True, local_action=True))


# Generated at 2022-06-23 15:29:24.865997
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # test reserved
    assert is_reserved_name('hosts')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('loop')
    assert is_reserved_name('with_')
    assert is_reserved_name('roles')
    assert is_reserved_name('include_role')
    assert is_reserved_name('block')
    assert is_reserved_name('tasks')
    assert is_reserved_name('rescue')
    assert is_reserved_name('always')
    assert is_reserved_name('connection')
    assert is_reserved_name('delegate_to')

    # test non-reserved
    assert not is_reserved_name('reserved')

# Generated at 2022-06-23 15:29:27.516342
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('inventory')
    assert is_reserved_name('hosts')
    assert not is_reserved_name('my_inventory')

# Generated at 2022-06-23 15:29:28.555011
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['action', 'othervar', 'with_items', 'notify'])

# Generated at 2022-06-23 15:29:36.320162
# Unit test for function get_reserved_names
def test_get_reserved_names():
    set_reserved_names = set(get_reserved_names(False))
    set_reserved_names_private = set(get_reserved_names(True))

    assert 'hosts' in set_reserved_names
    assert 'with_' in set_reserved_names

    assert 'name' in set_reserved_names_private
    assert 'author' in set_reserved_names_private
    assert 'vars' in set_reserved_names_private



# Generated at 2022-06-23 15:29:40.142935
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['invocation', 'action'])
    warn_if_reserved(['become', 'block'])
    warn_if_reserved(['roles'])
    warn_if_reserved(['tags'])

# Generated at 2022-06-23 15:29:46.919375
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('any_playbook_attribute')
    assert is_reserved_name('any_block_attribute')
    assert is_reserved_name('any_task_attribute')
    assert is_reserved_name('any_role_attribute')

    # special case for loop
    assert is_reserved_name('loop')

    # special case for action
    assert is_reserved_name('action')

    # these are not reserved names, so should return false
    assert not is_reserved_name('foo')
    assert not is_reserved_name('baz')
    assert not is_reserved_name('tasks')
    assert not is_reserved_name('handlers')
    assert not is_reserved_name('roles')
    assert not is_reserved_name('block')
   