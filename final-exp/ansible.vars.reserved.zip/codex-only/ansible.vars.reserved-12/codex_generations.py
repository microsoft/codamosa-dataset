

# Generated at 2022-06-23 15:19:47.111780
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert is_reserved_name('when')
    assert is_reserved_name('loop')
    assert is_reserved_name('block')

# Generated at 2022-06-23 15:19:49.545550
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) == 69
    assert len(get_reserved_names(include_private=False)) == 54



# Generated at 2022-06-23 15:20:01.058752
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils._text import to_text

    # make sure we're on Python2
    if not is_sequence(globals().keys()):
        raise AssertionError("This test is designed to only run on Python2")

    def test_warn_if_reserved_helper(arg):
        warn_if_reserved(arg)

    # check if we get a warning for the reserved vars

# Generated at 2022-06-23 15:20:09.369210
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.compat.tests import unittest

    class TestPlaybookReservedNames(unittest.TestCase):

        def test_default_names(self):
            testcases = [
                'action',
                'tasks',
                'pre_tasks',
                'post_tasks',
                'roles',
                'handlers',
                'vars',
                'any_errors_fatal',
                'delegate_to',
                'environment',
                'gather_facts',
                'hosts',
                'name',
                'notify',
                'run_once',
                'sudo',
                'sudo_user',
                'tags',
                'when',
                'connection',
                'remote_user',
                'no_log',
            ]
            warn_if_reserved

# Generated at 2022-06-23 15:20:18.992614
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ansible_vars = {'name': 'test', 'vars': {'a': 'b', 'c': 'd'}}

    result = get_reserved_names()
    assert isinstance(result, set), 'expected a set'
    assert len(result) > 0, 'expected a set with some elements'
    assert is_reserved_name('name')
    assert not is_reserved_name('host'), 'host should not be a reserved name'
    assert not is_reserved_name('a'), 'a should not be a reserved name'
    assert not is_reserved_name('vars'), 'vars should not be a reserved name'

    result_private = get_reserved_names(include_private=False)
    assert isinstance(result_private, set), 'expected a set'

# Generated at 2022-06-23 15:20:26.689931
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['somevar', 'someothervar', 'vars', 'serial', 'othervar'])
    # no warnings should result as we whitelisted 'serial' and 'vars'
    warn_if_reserved(['somevar', 'someothervar', 'vars', 'serial', 'othervar'], ['serial', 'vars'])
    # no warnings should result as we didn't add 'vars'

# Generated at 2022-06-23 15:20:27.884112
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert(get_reserved_names() == _RESERVED_NAMES)

# Generated at 2022-06-23 15:20:37.339087
# Unit test for function get_reserved_names
def test_get_reserved_names():
    '''
    Make sure that the list of reserved names does not change without notice.
    '''
    # FIXME: make this a unit test
    # FIXME: create a unit test for warn_if_reserved

    # FIXME: change these tests to expect exact keywords
    # FIXME: make sure we are not missing any attributes

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    # get a set of reserved names and turn them into a dict
    reserved_names = set(get_reserved_names())

    # we will build a dict to store all the object names
    object_dict = {}

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
       

# Generated at 2022-06-23 15:20:41.623441
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        display.warning = warn_if_reserved  # override display.warning
        warn_if_reserved(set(['action', 'tasks']))
        assert False, "Warnings should be raised"
    except AssertionError:
        pass



# Generated at 2022-06-23 15:20:44.696438
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('ansible_ssh_port')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:20:51.566089
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['roles', 'roles_path', 'include', 'include_vars', 'vars'])

    # should warn
    warn_if_reserved(['roles'])
    warn_if_reserved(['include_vars'])
    warn_if_reserved(['vars'])

    # should not warn
    warn_if_reserved(['include'])
    warn_if_reserved(['notify'])
    warn_if_reserved(['notify', 'roles'])

# Generated at 2022-06-23 15:20:59.577267
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'tasks' in reserved
    assert 'roles' in reserved
    assert 'action' in reserved
    assert 'with_' in reserved
    assert 'tags' in reserved
    assert 'name' in reserved
    assert 'become' in reserved
    assert 'sudo' in reserved
    assert 'sudo_user' in reserved
    assert 'connection' in reserved
    assert 'gather_facts' in reserved

    private = get_reserved_names(include_private=False)
    assert 'private' not in private
    assert 'vars_' not in private
    assert 'vars_files' not in private
    assert 'deprecated' not in private
    assert 'register' not in private
    assert 'block' not in private
    assert 'handlers' not in private

    # no duplicate

# Generated at 2022-06-23 15:21:01.712182
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('remote_user')
    assert not is_reserved_name('foo')

# Generated at 2022-06-23 15:21:03.240722
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("path")



# Generated at 2022-06-23 15:21:07.689017
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert 'name' in reserved
    assert 'gather_facts' in reserved
    assert 'pre_tasks' in reserved
    assert 'roles' in reserved

    assert len(get_reserved_names(include_private=False)) < len(reserved)

# Generated at 2022-06-23 15:21:08.832185
# Unit test for function get_reserved_names
def test_get_reserved_names():

    assert 'roles' in get_reserved_names()



# Generated at 2022-06-23 15:21:13.590287
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(False)
    # Check the length of the list
    assert len(result) == 50
    # Check if some reserved names are part of the list
    assert 'roles' in result

    result = get_reserved_names(True)
    # Check the length of the list
    assert len(result) == 76
    # Check if some reserved names are part of the list
    assert 'delegate_to' in result

# Generated at 2022-06-23 15:21:21.851143
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == frozenset([
        'action',
        'block',
        'handler',
        'hosts',
        'include',
        'include_role',
        'include_tasks',
        'local_action',
        'notify',
        'pre_tasks',
        'post_tasks',
        'pre_handler',
        'pre_tasks',
        'role_name',
        'serial',
        'tasks',
        'when',
        'with_'])

# Generated at 2022-06-23 15:21:22.774540
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert warn_if_reserved({'tasks'}) == None



# Generated at 2022-06-23 15:21:28.435224
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names()
    assert type(reserved) is set
    assert 'roles' in reserved
    assert 'block' in reserved
    assert 'local_action' in reserved  # implicit with action
    assert 'with_' in reserved  # with_ implies loop
    assert 'loop' in reserved  # FIXME: remove after with_ is not only deprecated but removed
    assert 'vars' in reserved
    assert 'action' in reserved
    assert 'vars_prompt' in reserved
    assert 'vars_files' in reserved
    assert 'public_vars' in reserved
    assert 'private_vars' in reserved
    assert 'handlers' in reserved
    assert 'tasks' in reserved



# Generated at 2022-06-23 15:21:30.328241
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Make sure we have a value on which to test
    assert is_reserved_name('hosts')


# Generated at 2022-06-23 15:21:34.195063
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'hosts' in get_reserved_names()
    assert 'name' in get_reserved_names()
    assert 'roles' in get_reserved_names()


# Generated at 2022-06-23 15:21:37.329453
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('name')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('foo_bar')

# Generated at 2022-06-23 15:21:40.229934
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('xyz')
    assert not is_reserved_name(None)
    assert is_reserved_name('any_errors_fatal')

# Generated at 2022-06-23 15:21:42.135538
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('hosts') is True)
    assert(is_reserved_name('foobarbaz') is False)

# Generated at 2022-06-23 15:21:43.047730
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')

# Generated at 2022-06-23 15:21:46.987178
# Unit test for function is_reserved_name
def test_is_reserved_name():

    reserved = [
        'gather_facts', 'strategy', 'any_errors_fatal', 'ignore_errors', 'serial', 'git_facts', 'pre_tasks', 'roles',
        'tasks', 'post_tasks', 'vars_prompt', 'vars_files', 'vars', 'handlers', 'notify', 'changed_when', 'failed_when',
        'tags', 'delegate_to', 'register', 'until', 'retries', 'local_action', 'transport', 'become', 'become_user',
        'become_method', 'become_flags', 'when'
    ]

    for name in reserved:
        assert is_reserved_name(name) is True

# Generated at 2022-06-23 15:21:50.073860
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' this function unit tests the get_reserved_names function'''

    names = set(get_reserved_names())
    assert 'hosts' in names and 'roles' in names and 'tasks' in names

# Generated at 2022-06-23 15:21:51.129415
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Placeholder for a test
    assert True

# Generated at 2022-06-23 15:21:54.151047
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Existing reserved name
    assert is_reserved_name('any_errors_fatal')

    # Non-existing reserved name
    assert not is_reserved_name('non_existing_name')

# Generated at 2022-06-23 15:22:02.805906
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' This tests the function get_reserved_names '''


# Generated at 2022-06-23 15:22:09.588974
# Unit test for function get_reserved_names
def test_get_reserved_names():
    exclusions = {'loop', 'with_', 'without_', 'with_items', 'with_fileglob', 'with_first_found', 'with_glob',
                  'with_nested', 'with_sequence', 'with_together', 'with_dict', 'with_dict_file', 'with_file',
                  'with_filetree', 'with_flattened', 'with_indexed_items', 'with_items', 'with_subelements',
                  'with_together', 'with_random_choice', 'with_sequence', 'with_subelements', 'with_nested', 'with_filetree', 'with_subelements',
                  'when', 'roles'}
    privates = {'private', 'api_version', 'serial', 'delegate_facts', 'no_log'}
    publics

# Generated at 2022-06-23 15:22:17.645179
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # check that the reservered names do not change without us knowing
    assert get_reserved_names() == _RESERVED_NAMES, \
        "reserved names have changed, please update _RESERVED_NAMES"

    # check that the special cases we've set up are accounted for
    assert 'with_' in _RESERVED_NAMES, \
        "the with_ special case does not work as expected"

    assert 'local_action' in _RESERVED_NAMES, \
        "the local_action special case does not work as expected"

# Generated at 2022-06-23 15:22:19.165571
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('hosts')
    assert is_reserved_name('_hosts')
    assert not is_reserved_name('bar')

# Generated at 2022-06-23 15:22:27.095671
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # Public reserved names
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('vars')
    assert is_reserved_name('delegate_to')

    # Private reserved names
    assert is_reserved_name('_role_path')
    assert is_reserved_name('_role_name')

# Generated at 2022-06-23 15:22:34.753062
# Unit test for function is_reserved_name
def test_is_reserved_name():
    # check for empty names
    assert not is_reserved_name('')
    assert not is_reserved_name(None)

    # check for names of NoneType
    assert not is_reserved_name(None)

    # check for invalid names
    assert not is_reserved_name('iamnotarealname')

    # Check for names of zero length
    assert not is_reserved_name('')

    # Check for names of non-zero length
    assert is_reserved_name('any_role_or_block_attribute')
    assert is_reserved_name('name')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('run_once')
    assert is_reserved_name('hosts')
    assert is_reserved_name('tags')
   

# Generated at 2022-06-23 15:22:41.131105
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    ''' test function to ensure warn_if_reserved works as expected '''
    # noop when no variables are passed
    warn_if_reserved([])
    # warn on reserved names
    warn_if_reserved(['vars'])
    warn_if_reserved(['action'])
    warn_if_reserved(['loop'])
    warn_if_reserved(['with_'])
    # noop on non-reserved names
    warn_if_reserved(['foobar'])

# Generated at 2022-06-23 15:22:44.595088
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved(['my_var', 'action', 'roles', 'delegate_to', 'when'])
    display.warning = lambda x: None
    warn_if_reserved(['my_var', 'action', 'roles', 'delegate_to', 'when'])

# Generated at 2022-06-23 15:22:46.828165
# Unit test for function is_reserved_name
def test_is_reserved_name():

    # loop implies with_
    # FIXME: remove after with_ is not only deprecated but removed
    assert is_reserved_name('with_')
    assert is_reserved_name('loop')

# Generated at 2022-06-23 15:22:51.329403
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert 'delegate_to' in get_reserved_names()
    # FIXME: remove after with_ is not only deprecated but removed
    assert 'with_' in get_reserved_names()
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('with_')



# Generated at 2022-06-23 15:22:59.163223
# Unit test for function get_reserved_names
def test_get_reserved_names():
    fail_list = []
    reserved_names = set(get_reserved_names(include_private=False))
    for name in get_reserved_names(include_private=True):
        if name.startswith('_'):
            if name not in reserved_names:
                fail_list.append('Private attribute "%s" should not be listed in public names' % name)
        else:
            if name in reserved_names:
                fail_list.append('Public attribute "%s" is listed in private names' % name)
    if fail_list:
        raise AssertionError('get_reserved_names failed:\n%s' % '\n'.join(fail_list))

# Generated at 2022-06-23 15:23:04.244484
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert(is_reserved_name('tags'))
    assert(not is_reserved_name('name'))
    assert(is_reserved_name('action'))
    assert(is_reserved_name('local_action'))
    assert(is_reserved_name('with_'))
    assert(not is_reserved_name('vars'))

# Generated at 2022-06-23 15:23:14.771147
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.pytest_runner import run_tests

    from units.compat.mock import patch
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    with patch('ansible.utils.display.Display.warning') as mock_warning:
        warn_if_reserved(dict(foo=1, action=None))
        mock_warning.assert_called_once_with('Found variable using reserved name: action')

    myvars = dict(strategy=None, vars=dict(foo=1), ansible_ssh_host=None)
    with patch('ansible.utils.display.Display.warning') as mock_warning:
        warn_if_reserved(myvars)

# Generated at 2022-06-23 15:23:16.738451
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    var_to_test = ['foo', 'vars', 'action']
    warn_if_reserved(var_to_test)

# Generated at 2022-06-23 15:23:21.792459
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        import __builtin__
        has_builtin = True
    except ImportError:
        has_builtin = False

    if has_builtin:
        __builtin__._ = lambda x: x

    class MockDisplay:
        def __init__(self):
            self.warning = lambda x: x

    try:
        __builtin__.display = MockDisplay()
        warn_if_reserved(['roles', 'hosts'])
        warn_if_reserved(['tags', 'roles', 'hosts'], ['tags'])
    finally:
        if has_builtin:
            del __builtin__.display


# Generated at 2022-06-23 15:23:32.764420
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        warn_if_reserved(dict(hosts='localhost', remote_user='root'))
    except Exception:
        assert False
    try:
        warn_if_reserved(dict(hosts='localhost', user='root'))
    except Exception:
        assert False
    try:
        warn_if_reserved(dict(hosts='localhost', connection='local'))
    except Exception:
        assert False
    try:
        warn_if_reserved(dict(hosts=['localhost', 'otherhost'], connection='local'))
    except Exception:
        assert False
    try:
        warn_if_reserved(dict(hosts=['localhost', 'otherhost'], user='root', connection='local'))
    except Exception:
        assert False



# Generated at 2022-06-23 15:23:43.891731
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' test the get_reserved_names function '''

    from ansible.utils.display import Display
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook import Play
    from ansible.constants import DEFAULT_HANDLER_NAME

    display = Display()

    class_list = [Play, Role, Block, Task]

    handler = Task()
    handler.action = 'debug'
    handler.name = DEFAULT_HANDLER_NAME
    handler.private = handler.private + (handler.action,)

    task = Task()
    task.action = 'debug'
    task.name = 'debug'
    task.private = task.private + (task.action,)

    block = Block()


# Generated at 2022-06-23 15:23:47.899913
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved = get_reserved_names(include_private=True)
    assert len(reserved) != 0
    assert isinstance(reserved, frozenset)

# Generated at 2022-06-23 15:23:55.250771
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')
    assert is_reserved_name('include')
    assert is_reserved_name('include_role')

    assert not is_reserved_name('name')
    assert not is_reserved_name('foo')
    assert not is_reserved_name('bar')
    assert not is_reserved_name('')
    assert not is_reserved_name(None)


# Generated at 2022-06-23 15:24:04.521303
# Unit test for function get_reserved_names
def test_get_reserved_names():

    public = frozenset([
        'action', 'hosts', 'name', 'remote_user', 'any_errors_fatal', 'become',
        'become_user', 'become_method', 'delegate_to', 'environment', 'gather_facts',
        'local_action', 'no_log', 'notify', 'register', 'serial', 'tags', 'until', 'when',
        'run_once', 'check_mode', 'transport', 'vars', 'vars_files', 'vars_prompt',
        'vault_password_files', 'with_items', 'when',
    ])


# Generated at 2022-06-23 15:24:12.069251
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # test reserved variables
    test_vars = ['hosts', 'roles']
    warn_if_reserved(test_vars)
    # test not reserved variables
    test_vars = ['foo', 'bar']
    warn_if_reserved(test_vars)
    # test reserved and not reserved variables
    test_vars = ['hosts', 'bar']
    warn_if_reserved(test_vars)

__all__ = ['get_reserved_names', 'warn_if_reserved']

# Generated at 2022-06-23 15:24:12.646140
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name("action")

# Generated at 2022-06-23 15:24:19.324403
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # test public names
    public = get_reserved_names(include_private=False)
    assert Play().dump_attributes() == public, 'Reserved public names don\'t match with Play attributes'

    # test all names
    all = get_reserved_names(include_private=True)
    assert Play().dump_attributes(include_private=True) == all, 'Reserved names don\'t match with Play attributes'

# Generated at 2022-06-23 15:24:24.484918
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # Setup
    myvars1 = frozenset(['ansible_play_hosts', 'hosts'])
    try:
        # Execute
        warn_if_reserved(myvars1)
    except:
        # Verify
        assert False, 'warn_if_reserved() threw exception unexpectedly.'
    # Cleanup - None necessary


if __name__ == '__main__':
    # Unit test this module

    test_warn_if_reserved()

# Generated at 2022-06-23 15:24:27.636278
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('myvarname')
    assert not is_reserved_name('vars')
    assert is_reserved_name('hosts')

# Generated at 2022-06-23 15:24:30.265717
# Unit test for function is_reserved_name
def test_is_reserved_name():
    my_list = get_reserved_names(False)

    for i in my_list:
        assert is_reserved_name(i) == True

# Generated at 2022-06-23 15:24:33.027509
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # check all of the results are lowercase
    for name in _RESERVED_NAMES:
        assert name.islower(), name

    # TODO: better unit test?

# Generated at 2022-06-23 15:24:38.310544
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name') == True
    assert is_reserved_name('hosts') == True
    assert is_reserved_name('vars') == True
    assert is_reserved_name('vars.foo') == True
    assert is_reserved_name('playbooks') == False
    assert is_reserved_name('play_hosts') == False
    assert is_reserved_name('play_name') == False
    assert is_reserved_name('vars.play_hosts') == False


# Generated at 2022-06-23 15:24:48.207812
# Unit test for function get_reserved_names
def test_get_reserved_names():

    # Check if the number of reserved names is 78
    assert(len(get_reserved_names()) == 78)

    # Check if some of the reserved names are present in the output
    assert('hosts' in get_reserved_names())
    assert('name' in get_reserved_names())
    assert('task' in get_reserved_names())

    # Check if the function works well for False as parameter
    assert('hosts' in get_reserved_names(False))
    assert('name' in get_reserved_names(False))
    assert('task' in get_reserved_names(False))
    assert('private' not in get_reserved_names(False))
    assert('notify' not in get_reserved_names(False))

# Generated at 2022-06-23 15:25:00.555437
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = get_reserved_names()
    assert is_reserved_name('action') is True
    assert is_reserved_name('local_action') is True
    assert is_reserved_name('local_action') == is_reserved_name('action')
    assert is_reserved_name('role') is True
    assert is_reserved_name('roles') is True
    assert is_reserved_name('FAKE') is False
    assert is_reserved_name('block') is True
    assert is_reserved_name('tasks') is True
    assert is_reserved_name('handlers') is True
    assert is_reserved_name('pre_tasks') is True
    assert is_reserved_name('post_tasks') is True

# Generated at 2022-06-23 15:25:11.093724
# Unit test for function get_reserved_names
def test_get_reserved_names():
    global _RESERVED_NAMES

    public = set()
    private = set()
    result = set()

    # FIXME: find a way to 'not hardcode', possibly need role deps/includes
    class_list = [Play, Role, Block, Task]

    for aclass in class_list:
        aobj = aclass()

        # build ordered list to loop over and dict with attributes
        for attribute in aobj.__dict__['_attributes']:
            if 'private' in attribute:
                private.add(attribute)
            else:
                public.add(attribute)

    for attribute in public:
        assert attribute not in private
        assert attribute in _RESERVED_NAMES

    for attribute in private:
        assert attribute in _RESERVED_NAMES

# Generated at 2022-06-23 15:25:13.332159
# Unit test for function is_reserved_name
def test_is_reserved_name():
    for name in _RESERVED_NAMES:
        assert is_reserved_name(name) is True

    assert is_reserved_name('foo') is False

# Generated at 2022-06-23 15:25:17.111423
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert 'pre_tasks' in get_reserved_names()
    assert 'block' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'meta' in get_reserved_names()



# Generated at 2022-06-23 15:25:26.128479
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:25:37.421206
# Unit test for function get_reserved_names
def test_get_reserved_names():
    bad_reserved = ['my_func', 'my_loop', 'my_block', 'my_task', 'my_task2', 'block2', 'task_w_loop', 'task_wo_loop']

    for bad_name in bad_reserved:
        assert not is_reserved_name(bad_name), "Name '%s' should not be reserved" % bad_name

    reserved = list(get_reserved_names())
    for bad_name in bad_reserved:
        assert bad_name not in reserved, "Name '%s' should not be reserved" % bad_name


# Generated at 2022-06-23 15:25:45.024244
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert not is_reserved_name('foobar')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('include_tasks')
    assert not is_reserved_name('pulser')
    assert is_reserved_name('action')
    assert is_reserved_name('local_action')
    assert is_reserved_name('include')
    assert is_reserved_name('include_role')


# Generated at 2022-06-23 15:25:52.728697
# Unit test for function get_reserved_names
def test_get_reserved_names():
    result = get_reserved_names(include_private=False)

    assert 'hosts' in result
    assert 'gather_facts' in result
    assert 'roles' in result
    assert 'tasks' in result
    assert 'vars' not in result
    assert 'tags' in result
    assert 'dep_tags' in result

    result = get_reserved_names(include_private=True)

    assert 'hosts' in result
    assert 'gather_facts' in result
    assert 'roles' in result
    assert 'tasks' in result
    assert 'vars' in result
    assert 'tags' in result
    assert 'dep_tags' in result

# Generated at 2022-06-23 15:26:00.938931
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_bytes

    def _get_reserved_names(obj):
        for name in obj.__dict__['_attributes']:
            if not 'private' in name:
                if name not in _RESERVED_NAMES:
                    raise AnsibleError('%s is not listed as reserved variable' % name)

    r = Play()
    for c in [Play, Role, Block, Task]:
        _get_reserved_names(c())

# Generated at 2022-06-23 15:26:04.760370
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert set(get_reserved_names()) == {
        'action',
        'any_errors_fatal',
        'become',
        'become_flags',
        'become_method',
        'become_user',
        'block',
        'blocks',
        'connection',
        'delegate_facts',
        'environment',
        'hosts',
        'ignore_errors',
        'local_action',
        'name',
        'notify',
        'roles',
        'serial',
        'tasks',
        'when',
        'with_',
    }


# Generated at 2022-06-23 15:26:15.642663
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('name')
    assert is_reserved_name('hosts')
    assert is_reserved_name('roles')
    assert is_reserved_name('tasks')
    assert is_reserved_name('vars')
    assert is_reserved_name('tasks')
    assert is_reserved_name('connection')
    assert is_reserved_name('local_action')
    assert is_reserved_name('tags')
    assert is_reserved_name('vars_files')
    assert is_reserved_name('vars_prompt')
    assert is_reserved_name('handlers')
    assert is_reserved_name('pre_tasks')
    assert is_reserved_name('post_tasks')

# Generated at 2022-06-23 15:26:22.768565
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class Test:
        def __init__(self):
            self.myvar = 'myvar'
            self._myvar_private = 'myvar'
            self.vars = 'vars'
            self.loop = 'loop'
            self.action = 'action'
            self.include_vars = 'include_vars'
            self._private = 'private'

    a = Test()
    warn_if_reserved(a.__dict__)

    assert True, "No exceptions raised by warn_if_reserved function"

# Generated at 2022-06-23 15:26:29.545516
# Unit test for function get_reserved_names
def test_get_reserved_names():
    names_no_private = get_reserved_names(False)
    assert( len(names_no_private) == 32 )
    assert( 'name' in names_no_private )
    assert( 'roles' in names_no_private )
    assert( 'vars' in names_no_private )
    assert( 'tags' in names_no_private )

    names_private = get_reserved_names(True)
    assert( len(names_private) == 39 )
    assert( 'register' in names_private )
    assert( 'sudo' in names_private )

# Generated at 2022-06-23 15:26:37.504254
# Unit test for function is_reserved_name
def test_is_reserved_name():
    from ansible.playbook.role_include import IncludeRole
    assert is_reserved_name('hosts')
    # task
    assert is_reserved_name('action')
    assert is_reserved_name('loop')
    assert is_reserved_name('register')
    assert is_reserved_name('until')
    assert is_reserved_name('retries')
    assert is_reserved_name('delegate_to')
    assert is_reserved_name('tags')
    assert is_reserved_name('run_once')
    assert is_reserved_name('ignore_errors')
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('changed_when')
    assert is_reserved_name('failed_when')
    assert is_reserved

# Generated at 2022-06-23 15:26:45.297287
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('any_errors_fatal')
    assert is_reserved_name('remote_user')
    assert is_reserved_name('environment')
    assert is_reserved_name('tags')
    assert is_reserved_name('hosts')
    assert is_reserved_name('vars')
    assert not is_reserved_name('become')
    assert not is_reserved_name('become_user')
    assert not is_reserved_name('private')
    assert not is_reserved_name('become_method')
    assert not is_reserved_name('sudo')

# Generated at 2022-06-23 15:26:48.904293
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ret = get_reserved_names(include_private=True)
    assert type(ret) == set
    ret = get_reserved_names(include_private=False)
    assert type(ret) == set

# Generated at 2022-06-23 15:26:59.059087
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    try:
        import __builtin__
        has_builtins = True
    except ImportError:
        has_builtins = False

    # Make sure the function returns None
    assert warn_if_reserved({'with_': 'foo'}) is None

    # Warn about a reserved name being used as a variable
    if has_builtins:
        __builtin__._ = []
    else:
        _ = []
    warn_if_reserved({'_': 'foo'})
    assert len(_) == 0

    # Warn about a reserved name being used as a variable
    if has_builtins:
        __builtin__._ = []
    else:
        _ = []
    warn_if_reserved({'_': 'foo'}, additional=set(['foo']))
    assert len(_) == 0

# Generated at 2022-06-23 15:27:07.903557
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    # make sure that we have the reserved names
    assert len(_RESERVED_NAMES) > 0

    # make sure that private names are not included
    assert is_reserved_name('roles') is False

    # additonal name that should always be reserved
    assert is_reserved_name('vars') is True

    #
    # add name in _RESERVED_NAMES, should not warn
    #

    # names in _RESERVED_NAMES should not trigger warning
    for x in _RESERVED_NAMES:
        assert is_reserved_name(x) is True

    #
    # additional name that should *always* be reserved
    #

    # name 'vars' should always be reserved
    assert is_reserved_name('vars') is True

    # name 'tags'

# Generated at 2022-06-23 15:27:19.704296
# Unit test for function is_reserved_name

# Generated at 2022-06-23 15:27:27.283914
# Unit test for function get_reserved_names
def test_get_reserved_names():
    a1 = set()
    a2 = set()
    b1 = set(['_role_name', 'any_errors_fatal', 'remote_user', 'serial',
            'roles', 'blk', 'first_available_file'])

    for a in _RESERVED_NAMES:
        a1.add(a)
    a1.remove('strategy')

    for a in get_reserved_names():
        a2.add(a)
    a2.remove('strategy')

    assert a1 == a2

    for a in _RESERVED_NAMES:
        b1.add(a)
    b1.remove('strategy')

    for a in get_reserved_names(include_private=True):
        assert a in b1

# Generated at 2022-06-23 15:27:31.330464
# Unit test for function get_reserved_names
def test_get_reserved_names():
    rnames = get_reserved_names()
    assert "name" in rnames
    assert "tags" in rnames
    assert "become_user" in rnames
    assert "connection" in rnames

# Generated at 2022-06-23 15:27:32.784481
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert get_reserved_names() == _RESERVED_NAMES

# Generated at 2022-06-23 15:27:38.636784
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    warn_if_reserved({'name': 'billy',
                      'with_items': 'blah',
                      'vars': {'name': 'bob'},
                      'include_vars': 'blah.yml'})

    # Should not raise warning
    warn_if_reserved({'name': 'billy',
                      'role_name': 'blah',
                      'vars': {'name': 'bob'},
                      'include_vars': 'blah.yml'})



# Generated at 2022-06-23 15:27:46.321055
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert not is_reserved_name('results')
    assert not is_reserved_name('success')

# with_ is still a "reserved word" and people still use it, to capture
# the warning, we must add it to _RESERVED_NAMES
_RESERVED_NAMES = _RESERVED_NAMES.union(set(get_reserved_names(False)).intersection(set(['loop', 'with_'])))

# Generated at 2022-06-23 15:27:53.157402
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:27:57.549335
# Unit test for function warn_if_reserved
def test_warn_if_reserved():

    # passing in a variable that conflicts with a play object attribute should warn
    warn_if_reserved(['hosts'])
    warn_if_reserved(['hosts'])
    warn_if_reserved(['hosts'])
    warn_if_reserved(['hosts'])

    # this one should not as it's not a play object attribute
    warn_if_reserved(['not_reserved'])

    # this one should warn
    warn_if_reserved(['include_role'])

# Generated at 2022-06-23 15:28:04.048573
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:28:11.353287
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert frozenset(get_reserved_names(True)) == _RESERVED_NAMES
    assert frozenset(get_reserved_names(False)) == frozenset(['tags', 'name', 'action', 'register', 'local_action', 'delegate_to', 'notify', 'listen', 'async',
                                                              'poll', 'environment', 'tags', 'when', 'with_', 'become', 'become_user', 'become_method',
                                                              'connection', 'ignore_errors', 'failed_when', 'failed_if', 'changed_when', 'block', 'role'])


# Generated at 2022-06-23 15:28:15.439175
# Unit test for function get_reserved_names
def test_get_reserved_names():
    assert len(get_reserved_names()) >= 33
    assert len(get_reserved_names(include_private=False)) >= 32

# Generated at 2022-06-23 15:28:17.389852
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('action')
    assert not is_reserved_name('bad_wolf')

# Generated at 2022-06-23 15:28:27.276046
# Unit test for function get_reserved_names
def test_get_reserved_names():
    ''' This is a unit test for the function get_reserved_names '''

    # test no params
    assert 'name' in get_reserved_names()
    assert 'hosts' in get_reserved_names()
    assert 'tasks' in get_reserved_names()
    assert 'action' in get_reserved_names()

    # test no private
    assert 'name' in get_reserved_names(include_private=False)
    assert 'hosts' in get_reserved_names(include_private=False)
    assert 'tasks' in get_reserved_names(include_private=False)
    assert 'action' in get_reserved_names(include_private=False)
    assert 'delegate_to' not in get_reserved_names(include_private=False)

    # test

# Generated at 2022-06-23 15:28:32.217753
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    assert is_reserved_name('any_errors_fatal') is True
    assert is_reserved_name('others') is False
    assert is_reserved_name('include_role') is False
    assert is_reserved_name('include') is False
    assert is_reserved_name('include_tasks') is False
    assert is_reserved_name('import_tasks') is False

# Generated at 2022-06-23 15:28:33.484751
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('when')

# Generated at 2022-06-23 15:28:37.552328
# Unit test for function is_reserved_name
def test_is_reserved_name():
    reserved_names = get_reserved_names()

    for reserved_name in reserved_names:
        assert is_reserved_name(reserved_name)
    for reserved_name in reserved_names:
        assert not is_reserved_name(reserved_name + "wrong")

# Generated at 2022-06-23 15:28:40.219674
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()
    assert isinstance(reserved_names, set)
    assert 'roles' in reserved_names



# Generated at 2022-06-23 15:28:47.522438
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    set1 = set(['action', 'name', 'delegate_to', 'local_action'])
    set2 = set(['loop', 'with_', 'type', 'with_first_found'])

    # test both sets
    warn_if_reserved(set1)
    warn_if_reserved(set2)

    # test both sets together
    warn_if_reserved(set1.union(set2))

    # test a variable name not in either set, ensure no warning
    warn_if_reserved(set(['foo']))

# Generated at 2022-06-23 15:28:51.128294
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('vars')
    assert is_reserved_name('var')
    assert is_reserved_name('name')
    assert is_reserved_name('action')
    assert not is_reserved_name('obviously_not_a_reserved_name')

# Generated at 2022-06-23 15:29:00.962165
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    from ansible.utils.display import Display
    from ansible.utils.color import stringc

    import os
    import sys
    import tempfile

    class args:
        syntax_check = True

    myargs = args()

    fd, test_file = tempfile.mkstemp()

# Generated at 2022-06-23 15:29:03.049074
# Unit test for function get_reserved_names
def test_get_reserved_names():
    # We expect no private reserved name here
    assert len(_RESERVED_NAMES) == 18

# Generated at 2022-06-23 15:29:06.393645
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    '''This function ensures that the warn_if_reserved function
    can be called without exceptions.
    '''

    warn_if_reserved(['apt_key'])

# Generated at 2022-06-23 15:29:09.783232
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('roles')
    assert is_reserved_name('with_items')
    assert is_reserved_name('become')
    assert not is_reserved_name('I_am_not_reserved')

# Generated at 2022-06-23 15:29:19.153711
# Unit test for function get_reserved_names
def test_get_reserved_names():
    reserved_names = get_reserved_names()

    assert 'vars' in reserved_names
    assert 'action' in reserved_names
    assert 'register' in reserved_names
    assert 'delegate_to' in reserved_names
    assert 'hosts' in reserved_names
    assert 'with_items' in reserved_names
    assert 'include' in reserved_names
    assert 'when' in reserved_names
    assert 'run_once' in reserved_names
    assert 'private' not in reserved_names
    reserved_names_private = get_reserved_names(include_private=True)
    assert 'private' in reserved_names_private
    assert len(reserved_names_private) > len(reserved_names)


# Generated at 2022-06-23 15:29:26.660343
# Unit test for function warn_if_reserved

# Generated at 2022-06-23 15:29:28.943928
# Unit test for function get_reserved_names
def test_get_reserved_names():
    rv = get_reserved_names()
    assert isinstance(rv, set)
    assert 'tags' in rv



# Generated at 2022-06-23 15:29:31.616734
# Unit test for function is_reserved_name
def test_is_reserved_name():
    assert is_reserved_name('role') is True
    assert is_reserved_name('when') is True
    assert is_reserved_name('roles') is False

# Generated at 2022-06-23 15:29:43.031769
# Unit test for function get_reserved_names

# Generated at 2022-06-23 15:29:48.478825
# Unit test for function warn_if_reserved
def test_warn_if_reserved():
    class Dummy(object):
        def __init__(self, vars):
            self.vars = vars or {}

    dummy = Dummy({})
    warn_if_reserved(dummy.vars)

    dummy = Dummy({'hosts': '127.0.0.1'})
    warn_if_reserved(dummy.vars)

    dummy = Dummy({'hosts': '127.0.0.1', 'action': 'ping'})
    warn_if_reserved(dummy.vars)