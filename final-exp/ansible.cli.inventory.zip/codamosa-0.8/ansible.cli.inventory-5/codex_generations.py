

# Generated at 2022-06-10 22:20:02.162350
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    my_mod = AnsibleModule(
        argument_spec = dict(),
    )

    my_cli = InventoryCLI(
        runas_pass='',
        inventory=None,
        subset=None,
        module_paths=None
    )
    assert my_cli._remove_internal({"a": "b", "ansible_group_priority":"1", "_ansible_no_log":"True", "ansible_become_method":"su"}) == {"a": "b"}


# Generated at 2022-06-10 22:20:05.137773
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():

    #Create test objects
    loader = DataLoader()
    inv = Inventory(loader=loader, groups=[])
    vm = VariableManager(loader=loader, inventory=inv)
    InventoryCLI.json_inventory(top=inv)



# Generated at 2022-06-10 22:20:17.119158
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    icli = InventoryCLI()
    # python 2.6 fix
    icli.set_options({})
    icli.post_process_args({})
    assert icli.dump({'foo': 'bar', 'bar': 'baz'}) == '{\n    "foo": "bar", \n    "bar": "baz"\n}'



if __name__ == '__main__':
    from ansible import context
    from ansible.plugins.inventory.manager import InventoryManager


# Generated at 2022-06-10 22:20:31.686971
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    data = '''
[group]
host1
host2

[group:children]
subgroup1
subgroup2

[subgroup1]
host3
host4

[subgroup2]
host5
host6

[subgroup3]
host7
host8
'''
    data_file = NamedTemporaryFile(delete=False)
    data_file.write(to_bytes(data))
    data_file.close()

# Generated at 2022-06-10 22:20:41.231523
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():

    args = "--list"
    cli = InventoryCLI(args.split())
    output = cli.json_inventory(cli._get_group('all'))
    assert output['_meta']['hostvars']['quux']['foo'] == 'bar'
    assert output['example.org']['hosts'][0] == 'quux'
    assert output['example.org']['children'][0] == 'test_group'
    assert output['example.org']['vars']['test_var'] == 1


# Generated at 2022-06-10 22:20:44.246507
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_file_path = "path/to/inventory_file"
    cli_args = set_cli_args(["--list"], inventory_file_path)
    
    CLIARGS_original = context.CLIARGS
    context.CLIARGS = cli_args
    
    inventory_cli = InventoryCLI()
    inventory_cli.run()
    
    context.CLIARGS = CLIARGS_original
    

# Generated at 2022-06-10 22:20:50.904027
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():

    class MockHost(object):
        def __init__(self, name):
            self.name = name

    class MockGroup(object):
        def __init__(self, name):
            self.name = name

        def get_vars(self):
            if self.name == 'group_vars_all':
                return {'ansible_group_priority': 1}
            elif self.name == 'group_vars_B':
                return {'ansible_group_priority': 2,
                        'group_var': 'group var B'}
            elif self.name == 'group_vars_C':
                return {'ansible_group_priority': 3,
                        'group_var': 'group var C'}

# Generated at 2022-06-10 22:20:58.714741
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    pass
    # FIXME: This is not working with the new '_play_prereqs' private method
    # inv = InventoryCLI()
    # for x in ('--host', '--graph', '--list'):
    #     context.CLIARGS[x] = None
    # assert inv.run() == True
    # context.CLIARGS['list']  = True
    # assert inv.run() == True

# Generated at 2022-06-10 22:21:02.855849
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():

    context.CLIARGS = ImmutableDict(parse_args(['--list']))
    cli = InventoryCLI(args=[])
    # FIXME: this doesn't test anything
    cli.run()




# Generated at 2022-06-10 22:21:11.663918
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    """Function to test parsing of inventory as yaml with method InventoryCLI.yaml_inventory
    """
    # Create a strategy instance
    invcli = InventoryCLI()
    base_path = os.path.dirname(__file__)
    inventory_path = os.path.join(base_path, '../../test/test_inventories/inventory')
    # Set a strategy to use for a configuration management system
    invcli.inventory = InventoryManager(loader=DataLoader(), sources=inventory_path)

    # Create groups
    top = Group('all')
    all_group = Group('all')
    all_group.parent_groups.append(top)
    top.child_groups.append(all_group)
    group_one = Group('group_one')
    group_one.parent_groups.append(top)
   

# Generated at 2022-06-10 22:21:34.722319
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    inventory = InventoryCLI()
    import ansible.parsing.dataloader
    loader = ansible.parsing.dataloader.DataLoader()
    inventory_data = loader.load_from_file('./inventory/hosts.yml')
    top = inventory_data.get_group('all')
    yaml_inventory1 = inventory.yaml_inventory(top)
    host_variable1 = yaml_inventory1.get('dbserver').get('hosts').get('dbserver1').get('ansible_host')
    assert host_variable1 == "192.168.0.11"
    print("Host variable: " + host_variable1)

# Generated at 2022-06-10 22:21:42.255619
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    import ansible.plugins.loader as plugin_loader
    from ansible.cli import CLI
    from ansible.inventory import Inventory

    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'data'))
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), 'inventory'))
    plugin_loader.add_directory(os.path.join('/', 'etc', 'ansible', 'inventory'))

    inv = Inventory(
        loader=CLI.CLI.get_file_loader(),
        variable_manager=CLI.CLI.get_variable_manager(),
        host_list=[os.path.join(os.path.dirname(__file__), 'hosts')]
        )

    # Test using the inventory

# Generated at 2022-06-10 22:21:43.288493
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    assert True

# Generated at 2022-06-10 22:21:44.396423
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    inventorycli = InventoryCLI()

# Generated at 2022-06-10 22:21:53.063274
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    inventory_path = 'tests/integration/inventory'
    host_pattern = 'all'
    graph = False
    yaml = False
    toml = False
    show_vars = False # TODO: need to fix this to test inventory_graph method

    if graph:
        display.verbosity = 1 # inventory_graph method need verbosity
        inv = InventoryCLI(inventory_path, host_pattern, graph, yaml, toml, show_vars)
        res = inv.run()

# Generated at 2022-06-10 22:22:02.945018
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # This test runs only when TOML is installed.
    try:
        import toml
    except ImportError:
        pytest.skip("TOML is not installed.")

    # empty inventory
    groups = [Group('all')]
    results = InventoryCLI._get_toml_group_info(groups, has_ungrouped=False)
    assert toml.dumps(results) == ''

    # one group
    test_group = Group('test')
    test_group.vars = {'foo': 'bar'}
    groups.append(test_group)
    results = InventoryCLI._get_toml_group_info(groups, has_ungrouped=False)


# Generated at 2022-06-10 22:22:15.845760
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager())
    inventory.add_group('group1')
    inventory.add_group('group1_child')
    inventory.add_group('group2')
    inventory.add_group('group2_child')
    inventory.add_group('ungrouped')

    inventory.add_host(Host('server1'))
    inventory.add_host(Host('server2'))
    inventory.add_host(Host('server3'))
    inventory.add_host(Host('server4'))
    inventory.add_host(Host('server5'))

# Generated at 2022-06-10 22:22:26.632343
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    class MockInventory:
        def __init__(self):
            MockHost = namedtuple('MockHost', ['name'])
            MockGroup = namedtuple('MockGroup', ['name', 'child_groups', 'hosts'])
            self.all = MockGroup('all', [MockGroup('child', [], [MockHost('child_host')]), MockGroup('unreachable', [], [MockHost('unreachable_host')])], [])
            self.groups = {'all': self.all, 'child': self.all.child_groups[0], 'unreachable': self.all.child_groups[1]}

    class MockContext:
        CLIARGS = {'export': True, 'list': True}

    ic = InventoryCLI()
    ic.inventory = MockInventory()

# Generated at 2022-06-10 22:22:37.942350
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.cli.inventory import InventoryCLI
    from ansible.plugins.loader import collection_loader
    from ansible import context
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import yaml

    assert getattr(context, 'INVENTORY_UNPARSED_SUCCESS', None) is None

    context.CLIARGS = {'list': True, 'yaml': True, 'verbosity': 0, }
    context.CLIARGS = {'yaml': True, }

    loader = DataLoader()

# Generated at 2022-06-10 22:22:41.213563
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    assert InventoryCLI.dump({'foo': 'bar'}) == '{\n    "foo": "bar"\n}'

# Generated at 2022-06-10 22:23:22.172926
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # Testing simple group starting with @
    group = Group('@testgroup')
    group.name = 'testgroup'
    group.add_host(Host('testhost'))
    #results = InventoryCLI._graph_group(group)
    #assert results == '@testgroup:\n  |--testhost'
    # Testing simple group starting with @ with vars
    for internal in INTERNAL_VARS:
        group.vars[internal] = 'test'
    results = InventoryCLI._graph_group(group)
    assert results == '@testgroup:\n  |--testhost'
    # Testing with child groups
    child_group = Group('childgroup')
    child_group.vars['childgroupvar'] = 'childgroupvar'
    child_group.add_host(Host('childgrouphost'))
   

# Generated at 2022-06-10 22:23:31.928333
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # Dict for test
    args = {'list': True, 'host': True, 'graph': True, 'output_file': None}
    # print(args)
    #
    # Create object of Class
    cli = InventoryCLI(args)

    # Test 1
    print("\nTest 1")

    # Create object of Class
    cli._play_prereqs()

    # Test 2
    print("\nTest 2")

    # Initialize var
    context.CLIARGS['export'] = True

    # Test 3
    print("\nTest 3")

    # Initialize var
    group = cli._get_group('all')

    # Test 4
    print("\nTest 4")

    # Initialize var
    print(cli.yaml_inventory(group))

    # Test 5
   

# Generated at 2022-06-10 22:23:33.413927
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    InventoryCLI.run() == None

# Generated at 2022-06-10 22:23:45.131912
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
  from ansible import constants as C
  from ansible.cli.inventory import InventoryCLI
  from ansible.inventory.manager import InventoryManager
  import json
  import os
  import tempfile
  inv = tempfile.mkdtemp()
  test_inventory_dir = os.path.dirname(__file__) + os.sep + 'data' + os.sep + 'inventory'
  src_inv = test_inventory_dir + os.sep + 'sample_inventory'
  dst_inv = os.path.join(inv, 'sample_inventory')
  os.symlink(src_inv, dst_inv)
  loader = DataLoader()
  inventory_manager = InventoryManager(loader=loader, sources=src_inv)

# Generated at 2022-06-10 22:23:55.679733
# Unit test for method inventory_graph of class InventoryCLI

# Generated at 2022-06-10 22:24:07.025266
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # Set up unit test infrastructure
    class Shell():
        def __init__(self):
            self.vars = dict(
                variable_manager = '',
                loader = '',
                options = ''
            )
    shell = Shell()
    class PluginLoader():
        def __init__(self, path):
            pass
    class MockLoader():
        def __init__(self):
            pass
        def _get_paths(self):
            return [dict(
                path = '',
                name = 'mock_loader'
            )]
    loader = MockLoader()
    shell.vars['loader'] = loader
    class MockOptions():
        def __init__(self):
            self.inventory = dict(
                plugin = '',
                script = ''
            )
            self.show_vars = False
           

# Generated at 2022-06-10 22:24:15.553775
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    '''test_InventoryCLI_dump
    tests the dump method of
    ansible.cli.inventory.InventoryCLI
    '''

    # create an instance of InventoryCLI
    test_inv = InventoryCLI()
    test_inv_data = {}
    test_inv_data['x1'] = 'data'
    test_inv_data['x2'] = 10

    # create some test data to be passed to dump
    test_inv_data_toml = {
        'table1': {
            'key1': 'text data',
            'key2': 99,
            'key3': {
                'key4': False
            },
            'key5': datetime.datetime.now(),
        }
    }

    # run the dump method with YAML set
    test_inv.exit = False

# Generated at 2022-06-10 22:24:19.233289
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    top = Group()
    top.name = 'all'
    tester = InventoryCLI()
    with pytest.raises(AnsibleError):
        results = tester.toml_inventory(top)


# Generated at 2022-06-10 22:24:31.562914
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    path = './ansible/inventory/tests/toml_data'
    inv_dir = os.path.dirname(path)
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=path)

    top = inventory.groups.get('all')

    cli = InventoryCLI([])
    re = cli.toml_inventory(top)

    with open(path, 'r') as f:
        data = f.read()
    expected_re = toml.loads(data.encode())

    assert re == expected_re


# Generated at 2022-06-10 22:24:38.760719
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    import tempfile
    import traceback
    import os
    import shutil
    import filecmp
    import toml

    TEST_DIR = tempfile.mkdtemp()

    class Options(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    # Create a test inventory and a test group
    # This part is based on the code from Ansible CLI inventory implementation
    test_playbook = os.path.join(TEST_DIR, 'test_playbook.yaml')
    with open(test_playbook, 'wb') as f:
        f.write(b'---')

    context.CLIARGS = Options(playbook=test_playbook)

# Generated at 2022-06-10 22:25:50.271405
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    pass  # TODO: Implement test for method yaml_inventory of class InventoryCLI

# Generated at 2022-06-10 22:25:52.674415
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    cli = InventoryCLI(args=['--list'])
    data = {}
    result = cli.dump(data)
    assert result == u'{}'

# Generated at 2022-06-10 22:26:03.671597
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    from ansible.cli import CLI

    # Generator to create InventoryCLI object for testing
    def get_InventoryCLI(args):
        inventoryCLI = InventoryCLI(args)
        inventoryCLI.options = CLI.base_parser(
            runas_opts=False,
            module_opts=False,
            as_opts=False,
            connection_opts=False,
            runtask_opts=False,
            vault_opts=False,
            fork_opts=False,
            subset_opts=False,
            check_opts=False,
            inventory_opts=True,
            whitelist_opts=[],
        ).parse_args(args)
        return inventoryCLI

    # Test case

# Generated at 2022-06-10 22:26:12.164710
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    ########################################################################################
    #
    # Unit test for method yaml_inventory of class InventoryCLI
    #
    ########################################################################################

    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # initialize
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    cli_inventory = InventoryCLI(Options(), inv_manager, variable_manager)

    # construct test data
    top = inv_manager.hosts['all']
    top_name = top.name
   

# Generated at 2022-06-10 22:26:15.736810
# Unit test for method dump of class InventoryCLI

# Generated at 2022-06-10 22:26:17.328531
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    assert InventoryCLI.yaml_inventory("top") == "yaml_inventory"


# Generated at 2022-06-10 22:26:27.988034
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    class TestArgs(object):
        def __init__(self, args):
            for arg in args:
                setattr(self, arg, args[arg])

    testargs = {
        'graph': True,
        'list': False,
        'host': False,
        'pattern': 'all',
        'verbosity': 1,
        'output_file': None,
        'inventory': C.INVENTORY_UNPARSED_SUFFIX,
        'yaml': False,
        'toml': False,
        'show_vars': False
    }

    testargs = TestArgs(testargs)

    class TestInventory(InventoryCLI):
        def __init__(self):
            self.graph = ''

        def _graph_group(self, group, depth=0):
            self.graph

# Generated at 2022-06-10 22:26:36.209476
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():

    '''
    This test is to test the inventory_graph method of class InventoryCLI
    '''

    file_path = os.path.dirname(os.path.realpath(__file__))
    file_path = os.path.join(file_path, 'test_inventory')
    test_inv = InventoryCLI(["--list", "--yaml", "--host", "test1", "--graph"], file_path)
    test_inv.run()
    assert test_inv is not None

# Generated at 2022-06-10 22:26:37.220319
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    pass

# Generated at 2022-06-10 22:26:48.617638
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # create dummies for loader and inventory
    loader = DataLoader()
    inventory = InventoryManager(loader=loader)
    host = Host("test-host")
    inventory.add_host(host)
    group = Group("test-group")
    group.add_host(host)
    inventory.add_group(group)
    group2 = Group("test-group2")
    group2.add_host(host)
    inventory.add_group(group2)
    # create dummy object for context.CLIARGS

# Generated at 2022-06-10 22:27:51.533454
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_path = os.path.join(DATA_PATH, 'inventory')
    inventory = InventoryManager(loader=DataLoader(), sources=[inventory_path])
    inventory.parse_sources()
    context.CLIARGS = {'list': True}
    cmd = InventoryCLI(args=[], inventory=inventory)
    res = cmd.run()
    assert res

# Generated at 2022-06-10 22:27:52.278609
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    pass

# Generated at 2022-06-10 22:27:54.651241
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    from ansible.cli.inventory import InventoryCLI
    a = InventoryCLI([])
    a.run()


# Generated at 2022-06-10 22:28:05.350864
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    m = mock.mock_open()
    with mock.patch('ansible.cli.inventory.open', m):
        args = mock.MagicMock(list=False, graph=False, host=False, yaml=False, version=False, inventory_filename=None,
                              subcommand="inventory")
        top = mock.Mock()
        top.name = "all"
        top.hosts = []
        top.child_groups = []
        groups = mock.MagicMock()
        groups.get = lambda x: top
        top.child_groups = groups
        inventory = mock.MagicMock()
        inventory.groups = groups
        inventory.hosts = []
        inventory.parse_inventory(args)
        cli = InventoryCLI(args)
        assert cli.toml_inventory(top) == {}


# Generated at 2022-06-10 22:28:07.374891
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    inv = InventoryCLI()
    top = inv._get_group('all')
    results = inv.json_inventory(top)
    print (results)


# Generated at 2022-06-10 22:28:12.592229
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    argv = ['inventory.py', '--list']
    result = InventoryCLI().parse(args=argv)
    assert result.func == InventoryCLI.run, 'The method run must be called'
    assert result.list == True, '--list is set'


# Generated at 2022-06-10 22:28:24.006080
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    C.INVENTORY_EXPORT = None
    C.INVENTORY_HOST = None
    C.INVENTORY_GRAPH = None
    C.INVENTORY_LIST = None
    C.INVENTORY_OUTPUT_FILE = None
    C.INVENTORY_VERBOSITY = None
    C.INVENTORY_YAML = None
    C.INVENTORY_TOML = None
    C.INVENTORY_SHOW_VARS = None
    i = InventoryCLI()
    i.post_process_args(C)

    @mock.patch('ansible.cli.inventory.InventoryCLI.run')
    def test_run(self):
        InventoryCLI.run(InventoryCLI)
    test_run()


# Generated at 2022-06-10 22:28:34.916058
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    # Test when --host is passed with hostname
    # Test will be successful if the function returns
    # with the value of the hostname
    hostname = 'test'
    options = {'host': hostname}
    inventory = InventoryCLI(args=[])
    # Call post_process_args to validate options
    try:
        inventory.post_process_args(options)
    except AnsibleOptionsError:
        assert True, 'Arguments containing hostname is valid'
    # Test will be successful if the function returns
    # with the value of the hostname
    # and the function raises an exception
    # when the option is missing the hostname

# Generated at 2022-06-10 22:28:36.655051
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    inventory_cli = InventoryCLI()
    results = inventory_cli.inventory_graph()
    assert results



# Generated at 2022-06-10 22:28:41.419204
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    class OPTIONS(object):
        def __init__(self):
            self.pattern = 'all'
            self.list = True
            self.yaml = False
            self.toml = True
            self.host = False
            self.graph = False
            self.export = True
            self.output_file = None
            self.args = None
            self.verbosity = None
            self.show_vars = False
        def __getattr__(self, attr):
            return False

    context.CLIARGS = OPTIONS()
    cli_options = InventoryCLI(args=[])
    loader, inventory, vm = cli_options._play_prereqs()

    class Source(object):
        def __init__(self):
            self.name = 'inventory'
