

# Generated at 2022-06-10 22:20:07.713637
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():

    from ansible.cli.inventory import InventoryCLI
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import io

    test_inventory = {
        'all': {
            'children': ['ungrouped'],
            'vars': {
                'ansible_connection': 'local'
            }
        },
        'ungrouped': {
            'hosts': ['localhost']
        }
    }

    loader = DataLoader()

    inv_manager = InventoryManager(loader, sources=io.StringIO(json.dumps(test_inventory)))

    cli_invent = InventoryCLI(['-i', 'localhost,', '--list'])
   

# Generated at 2022-06-10 22:20:16.214460
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    args = [
            '--list',
            '--host',
            'example.com',
            '--yaml',
            '--user',
            'root'
        ]
    with patch.object(InventoryCLI, '_get_host_variables', return_value={'foo': 'bar'}):
        with patch.object(InventoryCLI, 'dump') as mock_dump:
            cli = InventoryCLI(args=args)
            cli.run()
            assert mock_dump.called


# Generated at 2022-06-10 22:20:23.340327
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # Create the object under test
    i = InventoryCLI()

    # Create inventory
    i.inventory = create_inventory()

    # Set context
    context.CLIARGS = {
        'host': None,
        'list': False,
        'graph': False,
        'yaml': True,
        'toml': False,
        'show_vars': False,
        'export': None,
        'output': None,
        'verbose': None,
        'version': False,
    }

    # Create test volumes
    expected = """\
foo
bar
"""

    actual = i.dump(['foo', 'bar'])

    # Assertions
    assert actual == expected


# Generated at 2022-06-10 22:20:36.038417
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # inventory = InventoryManager("/Users/kevin/source/ansible/python/ansible/tests/units/modules/test_files/inventory")
    inventory = InventoryManager("/Users/kevin/source/ansible/python/ansible/tests/units/modules/test_files/services_inventory")
    inventory.data = {}
    invcli = InventoryCLI(None)
    invcli.inventory = inventory
    invcli.verbosity = 0
    invcli.host = 0
    invcli.graph = 0
    invcli.list = 1
    invcli.export = True
    invcli.host = None

    print(json.dumps(invcli.json_inventory(inventory.groups['all']), indent=4))


# Generated at 2022-06-10 22:20:46.839077
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, host_list=['tests/unit/inventory/inventory_hosts'],
                                 sources=['tests/unit/inventory/inventory_hosts',
                                          'tests/unit/inventory/inventory_group_vars',
                                          'tests/unit/inventory/inventory_host_vars'])
    icli = InventoryCLI(None, None)
    icli.loader = None
    icli.inventory = inventory
    icli.vm = None
    top = icli._get_group('all')

    test_pass = True
    result = icli.json_inventory(top)

# Generated at 2022-06-10 22:20:53.679846
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
  fake_graph_group = create__fake_graph_group()

  display_vars_arguments = {}
  display_vars_arguments[0] = {'value': 'host'}
  display_vars_arguments[1] = 2

  json_inventory_arguments = {}
  json_inventory_arguments[0] = create_fake_json_inv(all_hosts=[])
  json_inventory_arguments[1] = 'toml'

  yaml_inventory_arguments = {}
  yaml_inventory_arguments[0] = create_fake_json_inv(all_hosts=[])
  # yaml_inventory_arguments[1] = 'toml'

  toml_inventory_arguments = {}
  toml_inventory_arguments[0] = create_fake_json_

# Generated at 2022-06-10 22:21:06.083665
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # the following top group name is for testing purpose
    top_group_name = 'all'

    # when the json_inventory is called, the self.inventory.groups has
    # to be set, but that is not the case for our unit tests.
    def mock_inventory_groups(self):
        return {top_group_name: None}

    # In our unit tests, we do not have a group named 'all', so we will
    # create a fake group for this purpose, but it will have no host, which
    # is the behavior we need for our unit tests.
    all_group_class_object = type(top_group_name, (), {'hosts': None})
    def mock_get_group(self, gname):
        if gname == top_group_name:
            return all_group_class_object()

   

# Generated at 2022-06-10 22:21:18.839625
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    """
    Implementation of unittest TestCase for class InventoryCLI, method run
    """

    #################################################################
    #
    # Setup
    #
    #################################################################

    # Setup command line arguments used by class
    context.CLIARGS = ImmutableDict(connection='local', module_path=None, forks=10, become=False,
                                    become_method=None, become_user=None, check=False, diff=False,
    )

    # create CLI object
    cli = InventoryCLI(args=[])

    # setup variables
    # setup valid group name
    group_name = 'my_group'

    # setup valid host name
    host_name = 'my_host'

    # setup group object
    group = Mock()
    group.name = group_name
    group.vars = {}



# Generated at 2022-06-10 22:21:29.891634
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    inv_cli = InventoryCLI(args=['-i', '/test/inventory'])
    inv_cli.options, inv_cli.args = inv_cli.parser.parse_args(['-i', '/test/inventory'])
    result = inv_cli.post_process_args(inv_cli.options)
    assert result.inventory == '/test/inventory'
    assert result.list
    assert not result.host
    assert not result.graph
    assert not result.pattern
    assert result.verbosity == 0

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-10 22:21:36.406869
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    result = InventoryCLI()
    result._graph_name
    result._graph_group
    result.inventory_graph
    result._remove_internal
    result._show_vars
    result._get_group_variables
    result._get_host_variables
    result._get_group
    result.dump
    result.json_inventory
    result.yaml_inventory
    result.toml_inventory
    result._remove_empty
    result.run
    result.post_process_args

test_InventoryCLI_inventory_graph()

# Generated at 2022-06-10 22:22:15.530858
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
  g = Group()
  g.name = "all"
  g.populate_hosts_and_groups()
  top = g
  cli = InventoryCLI()
  types = [toml.dumps(entry) for entry in cli.toml_inventory(top).values()]
  assert(types.count('[hosts]\n') > 0)
  assert(types.count('[children]\n') > 0)
  assert(types.count('[vars]\n') > 0)
  assert(types.count('[hosts]\n') > 0)
  assert(types.count('[children]\n') > 0)
  assert(types.count('[vars]\n') > 0)

# Generated at 2022-06-10 22:22:24.484839
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # initialize necessary objects
    loader = DataLoader()

    # initialize needed objects
    inventory = InventoryManager(loader=loader, sources=[])
    vm = VariableManager(loader=loader, inventory=inventory)

    # create instance of InventoryCLI
    inv_cli = InventoryCLI(None, '/tmp/ansible-inventory')

    # set instance variables for InventoryCLI
    inv_cli.loader = loader
    inv_cli.inventory = inventory
    inv_cli.vm = vm

    all_group = inventory.groups.get('all')
    res = inv_cli.json_inventory(all_group)
    print(res)



# Generated at 2022-06-10 22:22:26.544527
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    args = [
        '--list',
        '--list',
        '--list',
    ]
    cli = InventoryCLI(args)


# Generated at 2022-06-10 22:22:37.331030
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    def mock_get_vars(self):
        return {'test': 1}

    def mock_get_hosts(self):
        return [InventoryHost('test1')]

    def mock_get_host_variables(self, host):
        if host.name == 'test1':
            return {'test': 1}
        return {}

    group = mock.Mock()
    group.name = 'test'
    group.child_groups = []
    group.hosts = []
    top = group # top is group itself
    group.get_vars = mock.Mock(side_effect=mock_get_vars)
    group.get_hosts = mock.Mock(side_effect=mock_get_hosts)

# Generated at 2022-06-10 22:22:46.490105
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # A helper function to set up the inventory for testing 
    def setup_inventory_for_testing(inventory_path):
        if os.path.exists(inventory_path):
            os.remove(inventory_path)
        f = open(inventory_path, "w+")
        f.write("[test_group]\n")
        f.write("localhost\n")
        f.write("[test_group:vars]\n")
        f.write("a=1\n")
        f.write("[children]\n")
        f.write("test_group\n")
        f.close()
        return inventory_path

    def remove_inventory_for_testing(inventory_path):
        if os.path.exists(inventory_path):
            os.remove(inventory_path)

    inventory_path

# Generated at 2022-06-10 22:22:51.439200
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # Test function to perform basic test of InventoryCLI class
    print("*****\nTest InventoryCLI class\n*****\n")
    myClass = InventoryCLI()
    myClass.run()
    print("\n*****\nUnit Test Done\n*****\n")


if __name__ == '__main__':
    test_InventoryCLI_run()

# Generated at 2022-06-10 22:22:58.131259
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    from ansible.plugins.inventory.ini import InventoryModule
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    inventory_filename = os.path.join(os.path.dirname(__file__), '/inventory')

    inv_data = InventoryModule()._load_inventory_from_source([inventory_filename], None, None)

    loader = DataLoader()
    inv_manager = InventoryManager(loader, sources=['/inventory'])
    inventory = inv_manager.inventory

    inv_cli = InventoryCLI(['--graph'])
    inv_cli.inventory = inventory
    # Have to set this to a non-default value for the inventory to be created

# Generated at 2022-06-10 22:23:07.296295
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    # yaml_inventory(self, top)
    # test example provided in documentation

    from ansible.cli.inventory import InventoryCLI
    from ansible.plugins.loader import inventory_loader, group_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = inventory_loader.get('auto', loader=loader)
    inv_loader = group_loader.get(inventory.inventory_loader_name, loader=loader)

    top = inv_loader.get('all')

    icli = InventoryCLI()

    res = icli.yaml_inventory(top)
    assert res == {'all': {'children': {'ungrouped': {}}, 'hosts': {}}}



# Generated at 2022-06-10 22:23:20.454354
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # FIXED: test fails due to differences in output line endings
    display.verbosity = 0
    ansible_options = ['-i', './lib/ansible/inventory/test/hosts', '-l', 'yaml_group']
    cli_args = context.CLIARGS
    context.CLIARGS = InventoryCLI.parse()
    cli_args.update(dict((k, v) for (k, v) in six.iteritems(vars(context.CLIARGS)) if v is not None))
    context.CLIARGS = ImmutableDict(cli_args)
    cli = InventoryCLI(args=ansible_options)
    cli.post_process_args(context.CLIARGS)
    top = cli._get_group('all')
    toml_str

# Generated at 2022-06-10 22:23:29.893908
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    cli_args = {
        'connection': 'local',
        'graph': True,
        'inventory-file': '~/.ansible/cp/ansible_local.yml',
        'module-path': '/Users/agumbrecht/ownCloud2/Agile/devops-setup/ansible/library',
        'pattern': 'all',
        'remaining_args': [],
        'subset': None,
        'syntax': None,
        'timeout': 10,
        'tree': None,
        'verbosity': 0,
    }
    inv = InventoryCLI()
    inv.post_process_args(cli_args)
    results = inv.run()
    print(results)


# Generated at 2022-06-10 22:24:31.834697
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    inventory_cli = InventoryCLI(args=["ansible-inventory", "--graph", "all"])
    results = inventory_cli.post_process_args(context.CLIARGS)
    assert results['graph'] is True


# Generated at 2022-06-10 22:24:42.549047
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    from ansible.errors import AnsibleError
    from ansible import context
    from ansible.cli import CLI
    from ansible.module_utils.six import PY3
    from ansible.parsing.ajson import AnsibleJSONEncoder

    class FakeOptions():
        def __init__(self, verbosity, host=None):
            self.verbosity = verbosity
            self.host = host

    class FakeCLI(CLI):
        def __init__(self, options):
            self.options = options

        def post_process_args(self, options):
            return options

        def parse(self):
            return options

    class FakeLoader():
        pass

    class FakeInventory():
        def get_hosts(self, string):
            host = FakeHost()
            host.name = 'host'
           

# Generated at 2022-06-10 22:24:53.147391
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    import toml
    # empty inventory, 'all' group only
    inventory = '''
    [all]
    '''
    inv = InventoryManager(loader=DataLoader(), sources=inventory)
    result = InventoryCLI.toml_inventory(inv.groups['all'])
    assert toml.dumps(result) == inventory.strip() + '\n\n'

    # empty inventory, 'all' group only, with group variables
    inventory = '''
    [all]
    var1 = 1
    var2 = null
    '''
    inv = InventoryManager(loader=DataLoader(), sources=inventory)
    result = InventoryCLI.toml_inventory(inv.groups['all'])
    assert toml.dumps(result) == inventory.strip() + '\n\n'

    # empty inventory, 'all'

# Generated at 2022-06-10 22:25:00.578223
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    inv_data = cp.read_file(cp.MODULE_DATA_PATH + 'inventory_simple')
    # create a temporary file
    inv_file = temppath()

    # Write the temporary file
    cp.write_file(inv_file, inv_data)
    inv_obj = InventoryCLI(args=[])
    # User either --list or --host or --graph option for testing post_process_args
    # as we need only one of these options to test
    inv_obj.options.list = True
    # Use inventory file
    inv_obj.options.inventory = inv_file
    # Host pattern
    inv_obj.options.pattern = 'all'
    inv_obj.options.graph = False
    inv_obj.options.host = False
    inv_obj.options.export = True

# Generated at 2022-06-10 22:25:14.440506
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    inventory_cli = InventoryCLI()
    stuff = dict(
        a=dict(
            hosts=["host1", "host2"],
            vars=dict(
                key1="value1",
                key2=True,
                key3=False,
                key4=10,
                key5="value5",
            )
        )
    )
    assert inventory_cli.dump(stuff) == '{\n    "a": {\n        "hosts": [\n            "host1", \n            "host2"\n        ], \n        "vars": {\n            "key1": "value1", \n            "key2": true, \n            "key3": false, \n            "key4": 10, \n            "key5": "value5"\n        }\n    }\n}'

# Generated at 2022-06-10 22:25:23.207447
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    class_ = InventoryCLI
    ref_ = None
    data = {'a': 1, 'b': 2}
    options = {'list': False, 'host': False, 'graph': False, 'yaml': False, 'toml': False}

    # Initialize needed objects
    # test the basic functionality of dump
    test_obj = class_()
    res = test_obj.dump(data)
    assert res == json.dumps(data, cls=AnsibleJSONEncoder, sort_keys=True, indent=4, preprocess_unsafe=True, ensure_ascii=False)

    # test_obj = class_(options)
    # res = test_obj.dump(data)
    # assert ref_ == res

    # test the yaml output option
    options['yaml'] = True
    test_

# Generated at 2022-06-10 22:25:34.169019
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # Create mock inventory object
    mock_inventory = MagicMock()
    # Format:
    # mock_inventory.groups.get().child_groups = [group1, group2, group3]
    # group1.child_groups = []
    # group1.hosts = [host1]
    # host1.name = 'host1.example.com'
    # host1.get_vars() = {'key1': 'value1', 'key2': 'value2'}
    # group1.name = 'group1'
    # group1.get_vars() = {'key1': 'value1', 'key2': 'value2'}
    # group2.child_groups = [subgroup]
    # subgroup.child_groups = []
    # subgroup.hosts = [host2]
    #

# Generated at 2022-06-10 22:25:42.692178
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # function for testing with mocks
    def _mock_method(obj, method_name, return_value):
        mock_method = MagicMock(return_value=return_value)
        setattr(obj, method_name, mock_method)
        return mock_method

    # load the inventory
    loader = DataLoader()
    inv_mgr = InventoryManager(loader, sources=[])
    vars_mgr = VariableManager()

    # create mock group with name
    mock_group = MagicMock()
    mock_group.name = "test"

    # create mock subgroup(s)
    subgroup = MagicMock()
    subgroup

# Generated at 2022-06-10 22:25:48.078354
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    script = InventoryCLI(args=['--list', 'localhost,', '--yaml'])
    script.run()


# Run all tests
if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-10 22:25:53.642556
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    invent = InventoryCLI()
    assert invent.dump({'a':1, 'b':1}) == '{\n    "a": 1,\n    "b": 1\n}'
    assert invent.dump({'a':1, 'b':1}, yaml=True) == 'a : 1\nb : 1\n'


# Generated at 2022-06-10 22:26:57.392116
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    from ansible.cli.inventory import InventoryCLI
    from ansible.parsing.dataloader import DataLoader

    inventory_args = {
        'host': 'localhost',
        'graph': True,
        'list': True,
        'verbosity': 0,
        'pattern': 'all',
        'subset': None,
        'refresh': False,
        'enable_plugins': None,
        'disable_plugins': None,
        'export': False,
        'output': None,
        'yaml': False,
        'json': True,
        'toml': False,
        'show_vars': False}


# Generated at 2022-06-10 22:26:59.874709
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    testvar= { "testkey": "testvalue" }
    InventoryCLI().dump(testvar)


# Generated at 2022-06-10 22:27:07.394511
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    host = Mock()
    host.name = "host_0"
    host_vars = dict(subgroup_0=dict(subsub=dict(subsubsub=dict(key='value', key_0='value_0'))))
    host.get_vars = Mock(side_effect=lambda: host_vars)
    subgroup_0 = Mock()
    subgroup_0.name = "subgroup_0"
    subgroup_0.hosts = [host]
    subgroup_0.child_groups = []
    subgroup_0.get_vars = Mock(side_effect=lambda: dict(subsub=dict(subsubsub=dict(key='value', key_0='value_0'))))
    group = Mock()
    group.name = "top_group"

# Generated at 2022-06-10 22:27:10.203355
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    inventory = InventoryCLI([])
    assert inventory.dump({}) == '{}'
    assert inventory.dump({"name": "ansible"}) == '{"name": "ansible"}'

# Generated at 2022-06-10 22:27:22.179542
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    from ansible.plugins.loader import group_loader, host_loader, vars_loader
    from ansible.plugins.inventory.ini import InventoryModule
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    class FakeOptions(object):
        def __init__(self):
            self.inventory = 'data/inventory/test_inventory.ini'
            self.list = False
            self.graph = False
            self.yaml = True
            self.output_file = None
            self.export = False
            self.host = None
            self.verbosity = 0
            self.args = None

# Generated at 2022-06-10 22:27:23.963019
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    pass # TODO: Write unit test for method inventory_graph of class InventoryCLI


# Generated at 2022-06-10 22:27:32.901766
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    for dir in [path.dirname(__file__)]:
        dir += "/.."

        if not path.isdir(dir):
            continue

        inven_dir = path.join(dir, "contrib/inventory")

        if path.isdir(inven_dir):
            break
    else:
        dir = path.dirname(__file__)
        inven_dir = path.join(dir, "../contrib/inventory")

    f = "hosts"
    cmd = "--list"
    inv_cli = InventoryCLI()
    inv_cli.parser.add_argument("-i", "--inventory", default=f, type=str)
    inv_cli.parser.add_argument("--list", action="store_true")

# Generated at 2022-06-10 22:27:46.513170
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # Create a instance of class InventoryCLI
    cli = InventoryCLI()
    # create a variable name inventory
    inventory = MagicMock()
    # create a variable name group
    group = MagicMock()
    # create a variable name host
    host = MagicMock()
    # create a variable name top
    top = MagicMock()
    # Set attribute 'pattern' of variable top with value 'all'
    top.pattern = 'all'
    # Set attribute 'name' of variable top with value 'all'
    top.name = 'all'
    # Set attribute 'child_groups' of variable top with value []
    top.child_groups = []
    # Set attribute 'name' of variable top with value 'all'
    top.name = 'all'
    # Set attribute 'hosts' of variable top with value []


# Generated at 2022-06-10 22:27:55.782005
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    top = Mock()
    top.child_groups = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n']
    top.name = 'top'
    top.vars = {'a': 'b'}
    top.hosts = []
    top.priority = '1'
    group1 = Mock()
    group1.name = 'a'
    group1.vars = {'a': 'b'}
    group1.hosts = ['f']
    group1.priority = '2'
    group2 = Mock()
    group2.name = 'b'
    group2.vars = {'a': 'b'}
    group2.hosts = ['g']
    group2.priority = '2'
    group3 = Mock()


# Generated at 2022-06-10 22:27:58.015338
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    c = InventoryCLI()
    c.inventory_graph()


# Generated at 2022-06-10 22:29:31.599342
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # Prepare for test
    ds = DynamicallyParsedInventory()
    ds.parse("")
    context.CLIARGS = {}
    context.CLIARGS['graph'] = True
    context.CLIARGS['pattern'] = 'all'
    context.CLIARGS['verbosity'] = 0
    context.CLIARGS['show_vars'] = False
    icli = InventoryCLI()
    icli.inventory = ds
    icli.loader = DataLoader()
    icli.vm = VariableManager()
    context.CLIARGS['graph'] = False
    # Test
    assert icli.inventory_graph() == '''@all:'''
    # Test a case with vars and child groups
    icli.inventory.add_group("child1")
    icli.inventory