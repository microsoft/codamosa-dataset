

# Generated at 2022-06-16 20:02:53.298986
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # FIXME: write unit test
    pass


# Generated at 2022-06-16 20:03:05.242396
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # Create a mock inventory
    inventory = InventoryManager(loader=None, sources=None)
    # Create a mock group
    group = Group(inventory=inventory, name='test_group')
    # Create a mock host
    host = Host(inventory=inventory, name='test_host')
    # Create a mock variable
    variable = Variable(name='test_variable', value='test_value')
    # Add the variable to the host
    host.set_variable(variable)
    # Add the host to the group
    group.add_host(host)
    # Create a mock inventory source
    inventory_source = InventorySource(name='test_inventory_source')
    # Add the group to the inventory source
    inventory_source.add_group(group)
    # Add the inventory source to the inventory
    inventory.add_source(inventory_source)

# Generated at 2022-06-16 20:03:13.930798
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    # Create an instance of class InventoryCLI
    inventory_cli = InventoryCLI()
    # Create an instance of class Inventory
    inventory = Inventory()
    # Create an instance of class Group
    group = Group()
    # Create an instance of class Host
    host = Host()
    # Create an instance of class Host
    host1 = Host()
    # Create an instance of class Host
    host2 = Host()
    # Create an instance of class Host
    host3 = Host()
    # Create an instance of class Host
    host4 = Host()
    # Create an instance of class Host
    host5 = Host()
    # Create an instance of class Host
    host6 = Host()
    # Create an instance of class Host
    host7 = Host()
    # Create an instance of class Host
    host8 = Host()
    # Create an instance

# Generated at 2022-06-16 20:03:14.878654
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    # TODO: implement
    pass

# Generated at 2022-06-16 20:03:20.277759
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # Initialize needed objects
    loader, inventory, vm = InventoryCLI._play_prereqs()
    # Initialize needed objects
    inventory_cli = InventoryCLI()
    # Initialize needed objects
    context.CLIARGS = {'pattern': 'all', 'graph': True, 'show_vars': True}
    # Call method
    inventory_cli.inventory_graph()


# Generated at 2022-06-16 20:03:29.692082
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # Create an instance of class InventoryCLI
    inventory_cli = InventoryCLI()
    # Create an instance of class Inventory
    inventory = Inventory()
    # Create an instance of class Host
    host = Host()
    # Create an instance of class Group
    group = Group()
    # Create an instance of class VariableManager
    variable_manager = VariableManager()
    # Create an instance of class Options
    options = Options()
    # Create an instance of class PlayContext
    play_context = PlayContext()
    # Create an instance of class AnsibleOptions
    ansible_options = AnsibleOptions()
    # Create an instance of class AnsibleOptions
    ansible_options = AnsibleOptions()
    # Create an instance of class AnsibleOptions
    ansible_options = AnsibleOptions()
    # Create an instance of class AnsibleOptions
    ansible

# Generated at 2022-06-16 20:03:38.050992
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # Create an instance of InventoryCLI
    inventory_cli = InventoryCLI()
    # Create an instance of Inventory
    inventory = Inventory()
    # Create an instance of Group
    group = Group()
    # Create an instance of Host
    host = Host()
    # Create an instance of VariableManager
    variable_manager = VariableManager()
    # Create an instance of Options
    options = Options()
    # Create an instance of PlaybookExecutor
    playbook_executor = PlaybookExecutor()
    # Create an instance of PlayContext
    play_context = PlayContext()
    # Create an instance of Play
    play = Play()
    # Create an instance of Task
    task = Task()
    # Create an instance of TaskResult
    task_result = TaskResult()
    # Create an instance of Playbook
    playbook = Playbook()
    #

# Generated at 2022-06-16 20:03:47.060353
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    # Test with no options
    options = {}
    inventory_cli = InventoryCLI()
    inventory_cli.post_process_args(options)
    assert options['verbosity'] == 0
    assert options['list'] == False
    assert options['host'] == False
    assert options['graph'] == False
    assert options['yaml'] == False
    assert options['toml'] == False
    assert options['show_vars'] == False
    assert options['export'] == False
    assert options['output_file'] == None
    assert options['pattern'] == 'all'
    assert options['args'] == None
    # Test with options

# Generated at 2022-06-16 20:03:52.935148
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # Setup
    inventory = InventoryCLI()
    inventory.inventory = Inventory(loader=DictDataLoader({}))
    inventory.inventory.add_group('all')
    inventory.inventory.add_group('group1')
    inventory.inventory.add_group('group2')
    inventory.inventory.add_group('group3')
    inventory.inventory.add_group('group4')
    inventory.inventory.add_group('group5')
    inventory.inventory.add_group('group6')
    inventory.inventory.add_group('group7')
    inventory.inventory.add_group('group8')
    inventory.inventory.add_group('group9')
    inventory.inventory.add_group('group10')
    inventory.inventory.add_group('group11')
    inventory.inventory.add_group('group12')
    inventory

# Generated at 2022-06-16 20:03:59.756527
# Unit test for method inventory_graph of class InventoryCLI

# Generated at 2022-06-16 20:04:29.820410
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # Create a group named 'all'
    group_all = Group('all')
    # Create a group named 'ungrouped'
    group_ungrouped = Group('ungrouped')
    # Create a group named 'group1'
    group_group1 = Group('group1')
    # Create a group named 'group2'
    group_group2 = Group('group2')
    # Create a group named 'group3'
    group_group3 = Group('group3')
    # Create a group named 'group4'
    group_group4 = Group('group4')
    # Create a group named 'group5'
    group_group5 = Group('group5')
    # Create a group named 'group6'
    group_group6 = Group('group6')
    # Create a group named 'group7'
    group_group

# Generated at 2022-06-16 20:04:41.918798
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.vars.hostvars import HostVarsInventorySource
    from ansible.vars.hostvars import HostVarsPath
    from ansible.vars.hostvars import HostVarsVarsPlugin
    from ansible.vars.hostvars import HostVarsGroup

# Generated at 2022-06-16 20:04:47.792041
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    # FIXME: this is a hack to get around the fact that the inventory
    #        plugin is not loaded when running unit tests
    from ansible.plugins.loader import inventory_loader
    inventory_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../plugins/inventory'))

    # FIXME: this is a hack to get around the fact that the vars_plugins
    #        plugin is not loaded when running unit tests
    from ansible.plugins.loader import vars_loader
    vars_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../plugins/vars'))

    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-16 20:04:55.982812
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # Initialize needed objects
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    vm = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-16 20:05:04.567564
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_toml'])
    inv_manager.parse_sources()
    inv_manager.add_group('all')
    inv_manager.add_host(Host(name='host1', port=22))
    inv_manager.add_host(Host(name='host2', port=22))
    inv_manager.add_host(Host(name='host3', port=22))

# Generated at 2022-06-16 20:05:12.103567
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # Test with a group that has no hosts
    top = MockGroup()
    top.name = 'all'
    top.child_groups = [MockGroup()]
    top.child_groups[0].name = 'ungrouped'
    top.child_groups[0].hosts = []
    top.child_groups[0].child_groups = []
    top.child_groups[0].vars = {}
    top.child_groups[0].priority = 1
    top.hosts = []
    top.vars = {}
    top.priority = 1
    assert InventoryCLI.toml_inventory(None, top) == {'all': {'children': ['ungrouped']}, 'ungrouped': {'hosts': {}}}

    # Test with a group that has hosts
    top = MockGroup()
    top

# Generated at 2022-06-16 20:05:21.042341
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # Create a mock inventory
    inventory = MockInventory()
    # Create a mock group
    group = MockGroup()
    # Create a mock host
    host = MockHost()
    # Add the host to the group
    group.hosts.append(host)
    # Add the group to the inventory
    inventory.groups.append(group)
    # Create a mock CLIARGS
    context.CLIARGS = {'list': True}
    # Create a mock InventoryCLI
    inventory_cli = InventoryCLI()
    # Call the method json_inventory
    results = inventory_cli.json_inventory(group)
    # Assert the result

# Generated at 2022-06-16 20:05:29.928966
# Unit test for method toml_inventory of class InventoryCLI

# Generated at 2022-06-16 20:05:40.127396
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # Create an instance of InventoryCLI
    inventory_cli = InventoryCLI()
    # Create an instance of AnsibleOptions
    ansible_options = AnsibleOptions()
    # Create an instance of Display
    display = Display()
    # Create an instance of Options
    options = Options()
    # Create an instance of CLI
    cli = CLI(ansible_options)
    # Create an instance of PlayContext
    play_context = PlayContext()
    # Create an instance of VariableManager
    variable_manager = VariableManager()
    # Create an instance of Inventory
    inventory = Inventory(loader=None, variable_manager=variable_manager, host_list=None)
    # Create an instance of Host
    host = Host(name="test_host")
    # Create an instance of Group
    group = Group(name="test_group")
    #

# Generated at 2022-06-16 20:05:42.175042
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # FIXME: write unit test
    pass


# Generated at 2022-06-16 20:06:30.595869
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    from ansible.inventory.yaml import InventoryYAMLParser
    from ansible.inventory.script import InventoryScript
    from ansible.inventory.dir import InventoryDirectory
    from ansible.inventory.custom import InventoryCustomSource
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader

# Generated at 2022-06-16 20:06:36.250000
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # Create a mock inventory
    inventory = Mock()
    inventory.groups = {'all': Mock()}
    inventory.groups['all'].child_groups = []
    inventory.groups['all'].hosts = []

    # Create a mock loader
    loader = Mock()

    # Create a mock variable manager
    vm = Mock()

    # Create a mock options
    options = Mock()
    options.list = True
    options.host = False
    options.graph = False
    options.yaml = False
    options.toml = False
    options.show_vars = False
    options.export = False
    options.output_file = None
    options.pattern = 'all'

    # Create a mock context

# Generated at 2022-06-16 20:06:44.057472
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.loader import vars_loader, inventory_loader
    from ansible.plugins.vars import vars_plugins
    from ansible.plugins.inventory import inventory_plugins
    from ansible.utils.vars import combine_vars
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import json
    import os
    import sys
    import pytest
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file

# Generated at 2022-06-16 20:06:55.404956
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.inventory import toml
    from ansible.plugins.inventory.toml import HAS_TOML
    from ansible.plugins.inventory.ini import HAS_INI_PARSER
    from ansible.plugins.inventory.yaml import HAS_YAML
    from ansible.plugins.inventory.ini import HAS_INI_PARSER
    from ansible.plugins.inventory.script import HAS_JSON
    from ansible.plugins.inventory.script import HAS_YAML

# Generated at 2022-06-16 20:07:06.285435
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # create a mock inventory
    inventory = InventoryManager(loader=None, sources=None)
    inventory.add_host(Host('testhost'))
    inventory.add_group(Group('testgroup'))
    inventory.add_child('testgroup', 'testhost')
    inventory.set_variable('testhost', 'testvar', 'testvalue')
    inventory.set_variable('testgroup', 'testvar', 'testvalue')

    # create a mock inventory source
    source = InventorySource(name='test', source=None, inventory=inventory)
    source.set_option('testvar', 'testvalue')

    # create a mock inventory plugin
    plugin = InventoryModule(loader=None, sources=[source])
    plugin.get_host_variables = MagicMock(return_value={'testvar': 'testvalue'})

# Generated at 2022-06-16 20:07:12.428190
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # Test with a group with no children
    top = Mock()
    top.name = 'all'
    top.child_groups = []
    top.hosts = []
    assert InventoryCLI.toml_inventory(InventoryCLI(), top) == {}

    # Test with a group with children
    top = Mock()
    top.name = 'all'
    top.child_groups = []
    top.hosts = []
    child = Mock()
    child.name = 'child'
    child.child_groups = []
    child.hosts = []
    top.child_groups.append(child)
    assert InventoryCLI.toml_inventory(InventoryCLI(), top) == {'all': {'children': ['child']}, 'child': {}}

    # Test with a group with children and hosts

# Generated at 2022-06-16 20:07:21.984621
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # Create a mock inventory
    inventory = Mock()

# Generated at 2022-06-16 20:07:23.992295
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # FIXME: write unit test
    pass


# Generated at 2022-06-16 20:07:33.625360
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.inventory.toml import HAS_TOML
    from ansible.plugins.inventory.yaml import HAS_YAML
    from ansible.plugins.inventory.ini import HAS_INI
    from ansible.plugins.inventory.ini import HAS_INI_PARSER
    from ansible.plugins.inventory.ini import HAS_INIPARSE
    from ansible.plugins.inventory.ini import HAS_CONFIGPARSER
    from ansible.plugins.inventory.ini import HAS_CONFIGPARSE
    from ansible.plugins.inventory.ini import HAS_CONFIGPARSER_IN

# Generated at 2022-06-16 20:07:39.616073
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # Test with no hosts
    top = Mock()
    top.name = 'all'
    top.child_groups = []
    top.hosts = []
    top.vars = {}
    top.get_vars.return_value = {}
    top.get_hosts.return_value = []
    top.get_host.return_value = None
    top.get_group.return_value = None
    top.get_groups.return_value = []
    top.get_group_variables.return_value = {}
    top.get_variable.return_value = None
    top.get_variables.return_value = []
    top.get_host_variables.return_value = {}
    top.get_host_variable.return_value = None

# Generated at 2022-06-16 20:09:38.847931
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # Create a mock inventory object
    inventory = Mock()
    inventory.groups = {'all': Mock(), 'ungrouped': Mock()}
    inventory.groups['all'].name = 'all'
    inventory.groups['all'].child_groups = [inventory.groups['ungrouped']]
    inventory.groups['ungrouped'].name = 'ungrouped'
    inventory.groups['ungrouped'].child_groups = []
    inventory.groups['ungrouped'].hosts = []
    inventory.groups['ungrouped'].priority = 1
    inventory.groups['ungrouped'].vars = {}
    inventory.groups['ungrouped'].get_vars = Mock(return_value={})
    inventory.groups['ungrouped'].get_hosts = Mock(return_value=[])
    inventory.groups

# Generated at 2022-06-16 20:09:43.181951
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # FIXME: This is a stub.
    #       It needs to be implemented.
    #       It should return a string.
    return "This is a stub."


# Generated at 2022-06-16 20:09:51.960832
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # Create a mock inventory
    inventory = InventoryManager(loader=None, sources=None)
    # Create a mock group
    group = Group(name='test_group')
    # Create a mock host
    host = Host(name='test_host')
    # Add the host to the group
    group.add_host(host)
    # Add the group to the inventory
    inventory.add_group(group)
    # Create a mock variable manager
    variable_manager = VariableManager(loader=None, inventory=inventory)
    # Create a mock options
    options = Mock()
    # Create a mock context
    context._init_global_context(options)
    # Create a mock CLI
    cli = InventoryCLI(args=['--list'])
    # Create a mock loader
    loader = DataLoader()
    # Create a mock display


# Generated at 2022-06-16 20:09:58.547531
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    # Test with no options
    options = {}
    inventory_cli = InventoryCLI()
    inventory_cli.post_process_args(options)
    assert options['verbosity'] == 0
    assert options['list'] == False
    assert options['host'] == False
    assert options['graph'] == False
    assert options['yaml'] == False
    assert options['toml'] == False
    assert options['show_vars'] == False
    assert options['export'] == False
    assert options['output_file'] == None
    assert options['args'] == []
    assert options['pattern'] == 'all'

    # Test with options

# Generated at 2022-06-16 20:10:08.392107
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # create a dummy class for testing
    class DummyInventoryCLI(InventoryCLI):
        def __init__(self):
            pass

    # create a dummy object for testing
    dummy_InventoryCLI = DummyInventoryCLI()

    # create a dummy dictionary for testing
    dummy_dict = {'key1': 'value1', 'key2': 'value2'}

    # test if the dump method returns a string
    assert isinstance(dummy_InventoryCLI.dump(dummy_dict), str)

    # test if the dump method returns a string
    assert isinstance(dummy_InventoryCLI.dump(dummy_dict), str)

    # test if the dump method returns a string
    assert isinstance(dummy_InventoryCLI.dump(dummy_dict), str)

    # test

# Generated at 2022-06-16 20:10:15.928858
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import cache_

# Generated at 2022-06-16 20:10:28.891670
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # Create a test inventory
    test_inventory = Inventory(loader=None, variable_manager=None, host_list=None)
    test_inventory.groups = {'all': Group('all'), 'test_group': Group('test_group')}
    test_inventory.groups['all'].child_groups = [test_inventory.groups['test_group']]
    test_inventory.groups['test_group'].parent_groups = [test_inventory.groups['all']]
    test_inventory.groups['test_group'].hosts = [Host('test_host')]
    test_inventory.groups['test_group'].hosts[0].vars = {'test_var': 'test_value'}

# Generated at 2022-06-16 20:10:37.041245
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    from ansible.cli.inventory import InventoryCLI
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.vars import vars_loader
    from ansible.errors import AnsibleError
    from ansible.errors import AnsibleOptionsError
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text

# Generated at 2022-06-16 20:10:42.706226
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # FIXME: This test is not working as expected.
    #        It is not clear what is the expected output.
    #        The test is disabled for now.
    return
    # Create a fake inventory
    inventory = Inventory(loader=None)

# Generated at 2022-06-16 20:10:51.982325
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import json
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.inventory.toml import toml_dumps, HAS_TOML
    if HAS_TOML:
        import toml
    # test json
    context.CLIARGS = {'yaml': False, 'toml': False}
    test_data = {'a': 1, 'b': 2, 'c': 3}
    test_result = json.dumps(test_data, cls=AnsibleJSONEncoder, sort_keys=True, indent=4, preprocess_unsafe=True, ensure_ascii=False)
    assert InventoryCLI.dump(test_data) == test