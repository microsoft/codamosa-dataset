

# Generated at 2022-06-24 17:54:52.635936
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)


# Generated at 2022-06-24 17:54:55.284215
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)

    assert inventory_c_l_i_0.post_process_args(None) == None


# Generated at 2022-06-24 17:55:03.268925
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)

    int_0 = 4652
    result = inventory_c_l_i_0.json_inventory(int_0)
    assert type(result) == dict

# Generated at 2022-06-24 17:55:06.466360
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    results_tuple_0 = Record.objects.filter(string_0="string_1")
    top_0 = results_tuple_0[0]
    inventory_c_l_i_2 = InventoryCLI("string_1")
    assert not inventory_c_l_i_2.inventory_graph(top_0)


# Generated at 2022-06-24 17:55:13.730829
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    inventory_c_l_i_0 = InventoryCLI(-0.337828)
    dict_0 = dict()
    dict_0['l'] = 'data_0'
    dict_0['p'] = 'data_1'
    dict_0['w'] = 'data_2'
    dict_0['f'] = 'data_3'
    dict_0['e'] = 'data_4'
    dict_0['a'] = 'data_5'
    dict_0['j'] = 'data_6'
    dict_0['u'] = 'data_7'
    dict_0['t'] = 'data_8'
    dict_0['m'] = 'data_9'
    dict_0['v'] = 'data_10'
    dict_0['b'] = 'data_11'
   

# Generated at 2022-06-24 17:55:26.307830
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    inventory_c_l_i_0 = InventoryCLI()
    group_0 = Mock()
    group_0.child_groups = []
    group_0.hosts = []
    group_0.name = Mock()
    result = inventory_c_l_i_0.yaml_inventory(group_0)
    inventory_c_l_i_0 = InventoryCLI()
    group_0 = Mock()
    group_0.child_groups = []
    group_0.hosts = []
    group_0.name = Mock()
    result = inventory_c_l_i_0.yaml_inventory(group_0)
    inventory_c_l_i_0 = InventoryCLI()
    group_0 = Mock()
    group_0.child_groups = []

# Generated at 2022-06-24 17:55:31.066355
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    import pdb
    #pdb.set_trace()
    # Arrange
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # Act
    # Assert
    assert True



# Generated at 2022-06-24 17:55:34.249441
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    top = {}
    # inventory_c_l_i_0 = InventoryCLI()
    # assert inventory_c_l_i_0.json_inventory(top) ==


# Generated at 2022-06-24 17:55:37.433454
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)
    ArgumentParser_0 = object()
    parser_0 = inventory_c_l_i_0.post_process_args(ArgumentParser_0)

# Generated at 2022-06-24 17:55:39.748331
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    int_0 = 7430
    long_0 = -2486185729

    inventory_c_l_i_0 = InventoryCLI(int_0)

    # Invoke method
    inventory_c_l_i_0.json_inventory(long_0)



# Generated at 2022-06-24 17:56:10.279844
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    inventory = ansible.inventory.host_list.HostsList()
    inventory_0 = ansible.inventory.host_list.HostsList()
    inventory_1 = ansible.inventory.host_list.HostsList()
    inventory_2 = ansible.inventory.host_list.HostsList()
    inventory_3 = ansible.inventory.host_list.HostsList()
    inventory_4 = ansible.inventory.host_list.HostsList()
    inventory_5 = ansible.inventory.host_list.HostsList()
    inventory_6 = ansible.inventory.host_list.HostsList()
    inventory_7 = ansible.inventory.host_list.HostsList()
    inventory_8 = ansible.inventory.host_list.HostsList()
    inventory_9 = ansible.inventory.host

# Generated at 2022-06-24 17:56:24.760791
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    var_0 = {}
    var_1 = InventoryCLI()
    var_2 = []
    var_2.append(var_0)
    var_3 = var_2
    var_2 = {}
    var_2['name'] = "all"
    var_2['children'] = []
    var_2['hosts'] = {}
    var_2['vars'] = {}
    var_2['_meta'] = {}
    var_2['_meta']['hostvars'] = {}
    var_3.append(var_2)
    var_4 = var_1.toml_inventory('all')
    var_5 = var_4['all']['children']
    var_4.update(var_5)
    var_5 = var_4['all']['hosts']
   

# Generated at 2022-06-24 17:56:27.149766
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    print("\n" + __name__ + " - Unit test for method InventoryCLI.toml_inventory")
    print("TODO")


# Generated at 2022-06-24 17:56:30.565754
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    import ansible.plugins.inventory.cli

    # Test case from class InventoryCLI
    var_0 = {}
    var_0 = InventoryCLI().toml_inventory(**var_0)

    assert var_0 == None


# Generated at 2022-06-24 17:56:45.270249
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    var_0 = {}
    var_1 = inventory.Inventory()
    var_1._vars_plugins=None
    var_2 = vars_plugins.VarsModule()
    var_2._options=None
    var_2._param_options=None
    var_1._vars_plugins = var_2
    var_3 = group(hosts=None,name="all",vars=None)
    var_3.hosts=None
    var_3.name="all"
    var_3.vars=None
    var_1.groups=var_3
    var_1.groups=var_3
    var_4 = vm.VarsPlugin()
    var_4._options=None
    var_4._param_options=None
    var_1._vars_plugins = var_4


# Generated at 2022-06-24 17:56:48.952700
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    print
    i = InventoryCLI(args=['/etc/ansible/hosts'])
    i.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 17:56:50.040433
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    assert False



# Generated at 2022-06-24 17:56:52.566914
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # initialize the inventory class
    var_1 = InventoryCLI()

    # normal call
    # var_1.toml_inventory(self, top)


# Generated at 2022-06-24 17:56:53.614187
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    var_0 = []


# Generated at 2022-06-24 17:57:01.586969
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    # Setup inventory and connector.
    c = Connection(InventoryCLI())
    var_0 = {}
    
    c.inventory.hosts = {}
    c.inventory.hosts['all'] = []
    c.inventory.hosts['all'].append(Host(name='all'))
    
    # Execute method under test
    c.yaml_inventory(top=c.inventory.hosts['all'][0])
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # Teardown method
    test_method_teardown_0(c)
    



# Generated at 2022-06-24 17:57:21.314616
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = -480.6437
    inventory_c_l_i_0 = InventoryCLI(float_0)
    options = Options()

    # AssertionError: False is not True
    with pytest.raises(AssertionError):
        assert inventory_c_l_i_0.run(options)


# Generated at 2022-06-24 17:57:26.848344
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)

    string_0 = 'test string'
    result = inventory_c_l_i_0.dump(string_0)
    print(result)


# Generated at 2022-06-24 17:57:33.366565
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # --inventory=path/to/file is the default value.
    context.CLIARGS['inventory'] = 'path/to/file'
    # inventory_c_l_i_0 = InventoryCLI(context.CLIARGS)
    # result = inventory_c_l_i_0.json_inventory()

    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top = inventory_c_l_i_0._get_group('all')
    result = inventory_c_l_i_0.json_inventory(top)
    assert type(result) is dict
    assert 'foo' in result  # Contents of path/to/file is {'foo': {}}


# Generated at 2022-06-24 17:57:38.070417
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():

    inventory_c_l_i_0 = InventoryCLI(sys.argv)
    context.CLIARGS['host'] = 'test_hosts'
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:57:48.997525
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    context.CLIARGS = {'host': False, 'graph': True, 'list': False, 'verbosity': 2,
                       'inventory': 'local_hosts', 'subset': [],
                       'pattern': 'all', 'syntax': 'yaml', 'refresh': False,
                       'graphviz': False, 'yaml': False, 'toml': False,
                       'show_vars': False, 'export': True, 'output_file': None,
                       'override_ansible_cfg': None, 'config_file': None}

# Generated at 2022-06-24 17:57:52.744393
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)
    
    try:
        inventory_c_l_i_0.run()
        assert False
    except SystemExit:
        assert True

# test case for _graph_group method of class InventoryCLI

# Generated at 2022-06-24 17:57:59.002634
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 739.75303426
    inventory_c_l_i_0 = InventoryCLI(float_0)
    with pytest.raises(AnsibleOptionsError) as pytest_wrapped_e:
        inventory_c_l_i_0.inventory_graph()
    assert 'Pattern must be valid group name when using --graph' in str(pytest_wrapped_e.value)


# Generated at 2022-06-24 17:58:09.183605
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible.plugins.loader import inventory_loader
    from ansible.plugins.inventory import toml
    from ansible.parsing.dataloader import DataLoader

    import pytest
    if not toml.HAS_TOML:
        pytest.skip("The python 'toml' library is required to test TOML inventory output, please install it and re-run the tests")


# Generated at 2022-06-24 17:58:18.121276
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)
    cli_options_0 = SimpleNamespace()
    cli_options_0.args = "all"
    cli_options_0.debug = False
    cli_options_0.graph = False
    cli_options_0.help = False
    cli_options_0.host = False
    cli_options_0.list = True
    cli_options_0.output_file = None
    cli_options_0.pattern = "all"
    cli_options_0.show_vars = False
    cli_options_0.verbosity = 0
    cli_options_0.version = False
    cli_options_0.yaml = False

# Generated at 2022-06-24 17:58:22.995702
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # context.CLIARGS = sys.argv[2:]
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:59:04.080696
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    import re
    import textwrap
    # String representation of the Ansible inventory graph returned by inventory_graph

# Generated at 2022-06-24 17:59:07.829784
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = -4591.3623
    inventory_c_l_i_0 = InventoryCLI(float_0)
    bool_0 = True
    str_0 = "HI"
    str_1 = inventory_c_l_i_0.dump(bool_0, str_0)
    print(str_1)
    exit()


# Generated at 2022-06-24 17:59:10.084718
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # Tests are not compiled because of missing dependencies
    # FIXME: implement
    assert False

# Generated at 2022-06-24 17:59:16.162895
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)
    group_0 = inventory_c_l_i_0._get_group('M__all')
    inventory_c_l_i_0.inventory_graph(group_0)


# Generated at 2022-06-24 17:59:24.305198
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    int_0 = -1012
    inventory_c_l_i_0 = InventoryCLI(int_0)
    int_1 = -1953
    dict_0 = {'top': int_1}
    dict_1 = {'top': dict_0}
    dict_2 = inventory_c_l_i_0.json_inventory(dict_1)
    assert dict_2 == dict_0


# Generated at 2022-06-24 17:59:32.589244
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    # Initialize float_0 for testing
    float_0 = -2330.8404
    # Do not enable verbosity
    context.CLIARGS['verbosity'] = 0
    # Initialize inventory_c_l_i_0 for testing
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # Get method of InventoryCLI
    ansible_options_error_0 = inventory_c_l_i_0.post_process_args({})
    # Assert no error has been thrown when no error occurs
    assert ansible_options_error_0 is None


# Generated at 2022-06-24 17:59:33.400039
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:59:38.358905
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_c_l_i_1 = InventoryCLI(-7.0)
    inventory_c_l_i_1.run()

if __name__ == '__main__':
    test_case_0()
    test_InventoryCLI_run()

# Generated at 2022-06-24 17:59:43.895479
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    arg0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(arg0)
    arg1 = 2330.8404

    # Testing exception handling
    try:
        result = inventory_c_l_i_0.dump(arg1)
    except Exception as exception:
        print('Exception: {}'.format(exception))


# Generated at 2022-06-24 17:59:54.571910
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    options = context.CLIARGS
    options['verbosity'] = 2
    options['list'] = False
    options['host'] = False
    options['graph'] = True
    options['yaml'] = False
    options['toml'] = False
    options['show_vars'] = False
    options['export'] = False
    options['output_file'] = None
    options['args'] = False
    inventory_c_l_i_0 = InventoryCLI(options)
    output = inventory_c_l_i_0.run()
    print(output)

if __name__ == "__main__":
    test_case_0()
    test_InventoryCLI_run()

# Generated at 2022-06-24 18:01:25.073044
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)
    dict_0 = dict()
    dict_0['dict_0'] = dict_0
    dict_1 = dict()
    dict_0['dict_1'] = dict_1
    dict_2 = dict()
    dict_0['dict_2'] = dict_2
    dict_3 = dict()
    dict_0['dict_3'] = dict_3
    dict_4 = dict()
    dict_0['dict_4'] = dict_4
    dict_5 = dict()
    dict_0['dict_5'] = dict_5
    dict_6 = dict()
    dict_0['dict_6'] = dict_6
    dict_7 = dict()

# Generated at 2022-06-24 18:01:32.161311
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = -9356.613
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top_0 = inventory_c_l_i_0.loader.load_from_file(to_bytes('test/inventory/hosts', errors='surrogate_or_strict'), fail_on_parser_error=False)
    assert type(inventory_c_l_i_0.yaml_inventory(top_0)) == dict


# Generated at 2022-06-24 18:01:35.313311
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    inventory_c_l_i_1 = InventoryCLI("")
    inventory_c_l_i_1.inventory_graph()


# Generated at 2022-06-24 18:01:41.247016
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # TODO:
    #  test dump()
    #  ensure your tests pass with:
    #    -x
    #    -v
    #    -vv
    #    -vvv
    #    -q

    # initialize
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)

    # call method
    result_0 = inventory_c_l_i_0.dump()

    # validate
    assert result_0 == None


# Generated at 2022-06-24 18:01:47.191577
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    inventory_c_l_i_0 = InventoryCLI('c09')
    group_0 = list()
    int_0 = 967
    inventory_c_l_i_0.validate_conflicts(int_0)
    inventory_c_l_i_0.run()
    inventory_c_l_i_0.validate_conflicts(float_0)
    inventory_c_l_i_0.run()
    inventory_c_l_i_0.validate_conflicts(float_0)
    inventory_c_l_i_0.validate_conflicts(int_0)
    inventory_c_l_i_0.validate_conflicts(int_0)
    inventory_c_l_i_0.validate_conflicts(int_0)
    inventory_c

# Generated at 2022-06-24 18:01:51.953252
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # Test with stuff = None
    stuff = None
    inventory_c_l_i = InventoryCLI(stuff)
    result = inventory_c_l_i.dump(stuff)
    assert isinstance(result, six.text_type)


# Generated at 2022-06-24 18:01:57.119061
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():

    assert InventoryCLI.dump({"A": "a"}) == '{\n    "A": "a"\n}'
    # assert InventoryCLI.dump([1, 2, 3]) == '[1, 2, 3]'
    # assert InventoryCLI.dump(True) == 'true'
    # assert InventoryCLI.dump(1) == '1'
    # assert InventoryCLI.dump(1.33) == '1.33'
    # assert InventoryCLI.dump(1.333) == '1.333'
    # assert InventoryCLI.dump(None) == 'null'


# Generated at 2022-06-24 18:02:03.249552
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)
    _f = inventory_c_l_i_0.dump("8K?c{+0@kz")
    assert _f == "8K?c{+0@kz"


# Generated at 2022-06-24 18:02:06.239861
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = -2330.8404
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 18:02:12.613941
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = -1936.3314
    inventory_c_l_i_0 = InventoryCLI(float_0)
    stuff_0 = [3, 4, 7, 4, 1]
    assert inventory_c_l_i_0.dump(stuff_0) == "[3, 4, 7, 4, 1]"
