

# Generated at 2022-06-24 17:54:57.691617
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    # test_case_0
    top = inventory_c_l_i_0._get_group('all')
    results = inventory_c_l_i_0.toml_inventory(top)

if __name__ == "__main__":
    test_case_0()
    test_InventoryCLI_toml_inventory()

# Generated at 2022-06-24 17:55:11.041811
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    stuff_0 = {}
    import json
    from ansible.parsing.ajson import AnsibleJSONEncoder
    try:
        results = json.dumps(stuff_0, cls=AnsibleJSONEncoder, sort_keys=True, indent=4, preprocess_unsafe=True, ensure_ascii=False)
    except TypeError as e:
        results = json.dumps(stuff_0, cls=AnsibleJSONEncoder, sort_keys=False, indent=4, preprocess_unsafe=True, ensure_ascii=False)

# Generated at 2022-06-24 17:55:13.549560
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:55:15.432246
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    test_case_0()


# Generated at 2022-06-24 17:55:17.934168
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    assert inventory_c_l_i_0 is not None
    print('End of test_InventoryCLI_toml_inventory')


# Generated at 2022-06-24 17:55:28.757350
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)

    group_0 = Group(str_0)
    group_1 = Group(str_0)
    group_1.hosts = ()
    group_1.child_groups = ()
    top = Group(str_0)
    top.child_groups = (group_0, group_1)
    top.hosts = ()
    top.child_groups = ()
    str_1 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_1)

    toml_results = inventory_c_l_i_0.toml_inventory(top)

    # Check the type output

# Generated at 2022-06-24 17:55:32.792701
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    top = inventory_c_l_i_0._get_group('all')
    inventory_c_l_i_0.toml_inventory(top)


# Generated at 2022-06-24 17:55:40.777883
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    from ansible.parsing.dataloader import DataLoader
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = 'inventory'
    data_loader_0 = DataLoader()
    str_2 = '%s:'
    str_3 = '@all'
    str_4 = '@test_group:'
    top = inventory_c_l_i_0._get_group(str_3)
    test_group = inventory_c_l_i_0._get_group(str_4)
    inventory_c_l_i_0.inventory.groups.clear()

# Generated at 2022-06-24 17:55:42.657928
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.json_inventory()


# Generated at 2022-06-24 17:55:48.692814
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    inventory_c_l_i_0 = InventoryCLI(ansible_playbook_dir)
    top_0 = inventory_c_l_i_0._get_group(inventory_c_l_i_0.pattern)
    assert inventory_c_l_i_0.yaml_inventory(top_0) == {'all': {'children': ['ungrouped', 'monitoring', 'monitoring1'], 'hosts': {}, 'vars': {'ansible_group_priority': 1}}}


# Generated at 2022-06-24 17:56:05.058365
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    pass


# Generated at 2022-06-24 17:56:10.505270
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    # Initialize needed objects
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)

    args_dict = {}
    args_dict['host'] = True
    args_dict['graph'] = False
    args_dict['list'] = False
    args_dict['yaml'] = False
    args_dict['toml'] = False
    args_dict['show_vars'] = False
    #args_dict['ignore_vars_plugins'] = False
    args_dict['export'] = False
    args_dict['output_file'] = None
    args_dict['verbosity'] = 2
    args_dict['args'] = ['local']

    # Call method
    cliargs = inventory_c_l_i_0.post_

# Generated at 2022-06-24 17:56:18.523541
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    print (" Test post_process_args: ")
    
    str_0 = 'host'
    str_1 = 'show_vars'
    #TODO: test __init__ method
    inventory_c_l_i_0 = InventoryCLI(str_0, str_1)
    
    print (" Test post_process_args completed.")


# Generated at 2022-06-24 17:56:29.198391
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    import os
    import threading
    import ansible
    import ansible.plugins
    import ansible.plugins.inventory
    import ansible.cli
    import test.ansible_test_init
    import ansible.constants
    import ansible.errors
    import ansible.playbook
    import ansible.utils
    import ansible.utils.display
    import ansible.executor
    import ansible.parsing
    import ansible.parsing.yaml
    import ansible.parsing.yaml.objects
    import ansible.parsing.ajson
    import ansible.plugins.action
    import ansible.plugins.action.copy
    import ansible.plugins.callback
    import ansible.plugins.strategy
    import ansible.plugins.strategy.linear
    import ansible.p

# Generated at 2022-06-24 17:56:34.853417
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import yaml

    # Case 0
    try:
        InventoryCLI.dump(yaml.dump(yaml.dump((1,2,3), Dumper=AnsibleDumper, default_flow_style=False, allow_unicode=True), cls=AnsibleJSONEncoder, sort_keys=True, indent=4, preprocess_unsafe=True, ensure_ascii=False))
    except TypeError:
        assert True
    else:
        assert False

if __name__ == '__main__':
    test_InventoryCLI_dump()

# Generated at 2022-06-24 17:56:35.838359
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    print(InventoryCLI.dump(self, stuff))


# Generated at 2022-06-24 17:56:48.076276
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # create inventory
    loader, inventory, vm = InventoryCLI()._play_prereqs()
    # create InventoryCLI
    inventory_c_l_i_0 = InventoryCLI()
    # create InventoryFile, Group, Host and VariableManager
    group_0 = Group(name="localhost")
    host_0 = Host(name="localhost")
    variable_manager_0 = VariableManager()
    inventory_file_0 = InventoryFile(loader=loader, variable_manager=variable_manager_0, host_list=[host_0,])
    # create str
    str_0 = "localhost"
    # create AnsibleOptions

# Generated at 2022-06-24 17:56:51.875399
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    display.verbosity = 3
    loader_0 = DataLoader()
    inventory_c_l_i_0 = InventoryCLI(loader_0)
    stuff_0 = {}
    display.display(InventoryCLI.dump(stuff_0))


# Generated at 2022-06-24 17:57:01.177413
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_1 = 'async_status jid=%s'
    inventory_c_l_i_1 = InventoryCLI(str_1)
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_2 = 'async_status jid=%s'
    inventory_c_l_i_2 = InventoryCLI(str_2)
    str_3 = 'async_status jid=%s'
    inventory_c_l_i_3 = InventoryCLI(str_3)
    str_4 = 'async_status jid=%s'
    inventory_c_l_i_4 = InventoryCLI(str_4)

# Generated at 2022-06-24 17:57:15.395505
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = ['InventoryCLI', '--tree', '/etc/ansible']
    str_1 = 'InventoryCLI'
    str_2 = '--tree'
    str_3 = '/etc/ansible'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    list_0 = [str_1, str_2, str_3]
    dict_0 = dict()
    dict_0['tree'] = str_3
    dict_0['pattern'] = 'all'
    dict_0['output_file'] = None
    dict_0['playbook_basedir'] = None
    dict_0['verbosity'] = 0
    dict_0['list'] = False
    dict_0['inventory'] = None
    dict_0['meta'] = None

# Generated at 2022-06-24 17:57:38.011758
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    test_case_0()
    inventory_c_l_i_0 = InventoryCLI('async_status jid=%s')
    group = inventory_c_l_i_0.inventory.groups.get(inventory_c_l_i_0.pattern)
    result = inventory_c_l_i_0._graph_group(group)
    assert type(result) is list
    assert result[0] == '@all:'


# Generated at 2022-06-24 17:57:48.954344
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    stuff_1 = { }
    import json
    from ansible.parsing.ajson import AnsibleJSONEncoder
    try:
        result_1 = json.dumps(stuff_1, cls=AnsibleJSONEncoder, sort_keys=True, indent=4, preprocess_unsafe=True, ensure_ascii=False)
    except TypeError as e:
        result_1 = json.dumps(stuff_1, cls=AnsibleJSONEncoder, sort_keys=False, indent=4, preprocess_unsafe=True, ensure_ascii=False)
        display.warning("Could not sort JSON output due to issues while sorting keys: %s" % to_native(e))
    results = InventoryCLI.dump(stuff_1)

    assert(results == result_1)

# Unit

# Generated at 2022-06-24 17:57:54.597221
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    try:
        inventory_c_l_i_0.run()
    except AnsibleError as error_0:
        print("ansible error: %s" % error_0.message)
    except Exception as exception_0:
        print("exception: %s" % exception_0)


# Generated at 2022-06-24 17:57:57.721828
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)



# Generated at 2022-06-24 17:57:59.081069
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    test_case_0()

if __name__ == "__main__":
    test_InventoryCLI_run()

# Generated at 2022-06-24 17:58:04.873798
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    top = object()

    inventory_c_l_i = InventoryCLI()
    result = inventory_c_l_i.json_inventory(top)
    assert result == {'_meta': {'hostvars': {}}}


# Generated at 2022-06-24 17:58:15.582085
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    from ansible.utils.constants import DEFAULT_VAULT_ID_MATCH
    host_0 = Host('localhost')
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = 'C:\\Users\\matthew\\AppData\\Local\\Temp\\ansible-tmp-1585831457.34-304599188192412.BZwrGt\\ansible-local-9583EhxW8\\ansible-tmp-1585831457.34-304599188192412.BZwrGt'
    _ = inventory_c_l_i_0.get_host_variables(host_0, str_1)
    str_2 = 'async_status jid=%s'

# Generated at 2022-06-24 17:58:26.234563
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible.plugins.inventory.toml import toml_loads
    import sys
    import io
    class JSONtoTOML(io.TextIOBase):
        def __init__(self, json_string):
            self.json_string = bytes(json_string, encoding='utf-8')
        def read(self, *args):
            import json
            import toml
            return toml.dumps(json.loads(self.json_string))

    class TOMLtoJSON(io.TextIOBase):
        def __init__(self, toml_string):
            self.toml_string = bytes(toml_string, encoding='utf-8')
        def read(self, *args):
            import json
            import toml
            return json.dumps(toml.loads(self.toml_string))

# Generated at 2022-06-24 17:58:33.423507
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    c_l_i_args_0 = parser_0.parse_args(['-l'])
    context_0.CLIARGS = c_l_i_args_0
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:58:43.432982
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    stuff_0 = ["hi", "hi", {"hi": "hi"}, set([1, 2, 3]), [3, 1, 2]]
    str_1 = "\n".join(('- hi', '- hi', '- hi: hi', '- [1, 2, 3]', '- [3, 1, 2]'))
    assert inventory_c_l_i_0.dump(stuff_0) == str_1, "Wrong output"
    stuff_1 = {"hi": "hi"}
    str_2 = "{\n    \"hi\": \"hi\"\n}\n"
    assert inventory_c_l_i_0.dump(stuff_1) == str_2

# Generated at 2022-06-24 17:59:30.618812
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import json
    print('dump=', json.dumps(figr_0, cls=AnsibleJSONEncoder, sort_keys=True, indent=4, preprocess_unsafe=True, ensure_ascii=False))


# Generated at 2022-06-24 17:59:33.756871
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_0 = 'import_role`'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    dict_0 = {'status': 'ok', 'msg': 'successful'}
    inventory_c_l_i_1 = inventory_c_l_i_0.dump(dict_0)


# Generated at 2022-06-24 17:59:43.136999
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    inventory_c_l_i_0 = InventoryCLI()
    dict_0 = {}
    str_0 = 'z√_O¡'
    dict_0['_MEg0k'] = str_0
    dict_0['t'] = 'qP@'
    dict_0['F_'] = 'Mi'
    dict_0['p'] = '!MY'
    dict_0['U'] = 'U:°'
    dict_0['o5xG'] = '^'
    dict_0['F'] = 'Cv@'
    dict_0['i'] = 'Z#'
    dict_0['~'] = 'p'
    dict_0['p_'] = 'h'
    dict_0['2'] = '!¥'

# Generated at 2022-06-24 17:59:44.407985
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    pass


# Generated at 2022-06-24 17:59:55.915852
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = 'ansible_network_os'
    group_1 = Group(str_1)
    str_2 = 'all'
    top_1 = Group(str_2)
    str_3 = 'ansible_ssh_user'
    host_1 = Host(str_3)
    inventory_c_l_i_0.vm = MagicMock()
    str_4 = 'localhost'
    host_2 = Host(str_4)
    top_1.hosts = [host_1,host_2]
    str_5 = 'ansible_network_os'
    group_2 = Group(str_5)
    top_1.child

# Generated at 2022-06-24 18:00:00.743685
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    stuff_0 = 'stuff_0'
    # Place your code here
    try:
        dump_0 = inventory_c_l_i_0.dump(stuff_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 18:00:03.045877
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)


# Generated at 2022-06-24 18:00:04.476608
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    pass


# Generated at 2022-06-24 18:00:15.151914
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # Test 1: argument host
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.inventory_graph()
    # Test 2: argument graph
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.inventory_graph()
    # Test 3: argument list
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.inventory_graph()


# Generated at 2022-06-24 18:00:22.020279
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.parser
    str_1 = 'hosts:\n  - test_hosts\n'
    bool_0 = False
    bool_1 = True
    str_2 = 'hosts:\n  - test_hosts'
    str_3 = 'Hosts:\n  - test_hosts'
    str_4 = 'hosts:\n  - test_hosts\n  - test_hosts_1'
    str_5 = 'hosts:\n  - test_hosts\n  - test_hosts_1\n  - test_hosts_2'
    dict_0 = dict()

# Generated at 2022-06-24 18:02:31.863481
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 18:02:37.821736
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = 'vars_plugins'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    top_0 = None
    inventory_c_l_i_0.yaml_inventory(top_0)


# Generated at 2022-06-24 18:02:46.407881
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    # Mock inventory
    inventory_0 = Inventory('/dev/null', None, context.CLIARGS)
    # Mock group
    group_0 = Group('all')
    # Mock group
    group_1 = Group('all')
    group_1.child_groups.append(group_0)
    # Mock class Host
    class Host():
        def __init__(self, name):
            self.name = name
    # Mock host
    host_0 = Host('host_0')
    group_1.hosts.append(host_0)
    # Mock host
    host_1 = Host('host_1')

# Generated at 2022-06-24 18:02:55.833196
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    argparse_namespace_0 = argparse.Namespace()
    argparse_namespace_0.extra_args = ''
    argparse_namespace_0.show_play_help = False
    argparse_namespace_0.start_at_task = None
    argparse_namespace_0.skip_tags = []
    argparse_namespace_0.subset = None
    argparse_namespace_0.tags = []
    argparse_namespace_0.step = None
    argparse_namespace_0.vault_password_file = './passwordfile.txt'

# Generated at 2022-06-24 18:02:59.256677
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    top = Mock()
    result = inventory_c_l_i_0.yaml_inventory(top)
    assert isinstance(result, dict)
    # Verify the values of the attributes of the return value
    assert result == {}

# Generated at 2022-06-24 18:03:12.396456
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_0 = 'async_status jid=%s'
    str_1 = 'async_status jid=%s'
    str_2 = 'async_status jid=%s'
    str_3 = 'async_status jid=%s'
    str_4 = 'async_status jid=%s'
    str_5 = 'async_status jid=%s'
    str_6 = 'async_status jid=%s'
    str_7 = 'async_status jid=%s'
    str_8 = 'async_status jid=%s'

# Generated at 2022-06-24 18:03:15.752345
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # Set up test values

    # Instantiate object
    inventory_c_l_i_0 = InventoryCLI()
    # Call run() method
    return_value = inventory_c_l_i_0.run()


# Generated at 2022-06-24 18:03:24.699748
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = '_run'
    str_2 = 'rq'
    str_3 = '--list'
    str_4 = '-i'
    str_5 = 'inventory'
    str_6 = '-l'
    str_7 = 'host'
    str_8 = '-c'
    str_9 = 'local'
    str_10 = 'all'
    str_11 = 'path'
    str_12 = 'roles/foobar'
    str_13 = 'json_query'
    str_14 = 'test'
    answer_0 = inventory_c_l_i_0.run()

# Generated at 2022-06-24 18:03:32.794294
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_0 = 'vars_plugins'
    inventory_c_l_i_0.post_process_args(str_0)
    str_0 = '--tree'
    str_1 = 'async_status jid=%s'
    str_2 = 'vars_plugins'
    str_3 = 'override_ansible_cfg'
    inventory_c_l_i_0.base_parser = str_3
    str_3 = 'filter_loader'
    inventory_c_l_i_0.cmdline = str_3
    str_3 = 'inventory_loader'
    inventory_c_l_i_0.inventory = str_

# Generated at 2022-06-24 18:03:39.618621
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    str_0 = 'async_status jid=%s'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = 'async_status jid=%s'
    group_0 = Group(str_1)
    top_0 = group_0
    str_2 = 'async_status jid=%s'
    group_1 = Group(str_2)
    group_0.child_groups.append(group_1)
    str_3 = 'async_status jid=%s'
    group_2 = Group(str_3)
    group_1.child_groups.append(group_2)
    str_4 = 'async_status jid=%s'
    group_3 = Group(str_4)