

# Generated at 2022-06-24 17:54:48.522397
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    group_0 = Group("")
    inventory_c_l_i_0.yaml_inventory(group_0)


# Generated at 2022-06-24 17:54:52.317250
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_1, inventory_c_l_i_1, options_2 = 587.208077, InventoryCLI("-h"), "--host"
    inventory_c_l_i_1.post_process_args(options_2)


# Generated at 2022-06-24 17:54:56.221649
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    assert inventory_c_l_i_0.toml_inventory() == "NotImplementedError: Please use the TOML inventory plugin"

# Generated at 2022-06-24 17:55:01.729764
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 567.5800867208937
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.inventory_graph()


# Generated at 2022-06-24 17:55:12.624103
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_1 = 660.8849358499982
    inventory_c_l_i_0 = InventoryCLI(float_1)
    inventory_sources_0 = inventory_c_l_i_0.inventory_sources
    inventory_0 = BaseInventory(float_1, inventory_sources_0)
    inventory_c_l_i_0.inventory = inventory_0
    group_0 = Group(float_1, inventory_0)
    inventory_0.groups['all'] = group_0

    # Verify that the correct result is returned
    json_inventory_0 = inventory_c_l_i_0.json_inventory(group_0)
    assert json_inventory_0 is not None
    assert json_inventory_0.get('all') == {'children': [], 'hosts': []}


# Generated at 2022-06-24 17:55:18.632195
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)

# Generated at 2022-06-24 17:55:23.384332
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # {{{ TODO: Write description for method InventoryCLI.dump
    # }}}
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.dump()


# Generated at 2022-06-24 17:55:24.850143
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    inventory_c_l_i_0 = None
    options = None

    assert inventory_c_l_i_0.post_process_args(options) == None


# Generated at 2022-06-24 17:55:30.311866
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():

    # Input Parameters
    top = None

    # Output Parameters
    result = None

    # Expected Output
    expected_result = None

    # Call the function to test
    result = toml_inventory(top)

    assert result == expected_result


# Generated at 2022-06-24 17:55:37.120720
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top_0 = inventory_c_l_i_0.inventory.groups.get('all')
    result_dict_0 = inventory_c_l_i_0.json_inventory(top_0)
    assert ('all' in result_dict_0)
    assert ('hostvars' in result_dict_0['_meta'])
    assert ('children' in result_dict_0['all'])


# Generated at 2022-06-24 17:55:53.317714
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.run()

test_case_0()
test_InventoryCLI_run()

# Generated at 2022-06-24 17:56:04.799874
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 67.28154294707776
    inventory_c_l_i_0 = InventoryCLI(float_0)
    float_0 = 7.903182049365908
    dict_0 = dict()
    dict_0['str_0'] = 'value_0'
    dict_0['str_1'] = 'value_1'
    dict_0['str_2'] = 'value_2'
    dict_0['str_3'] = 'value_3'
    dict_0['str_4'] = 'value_4'
    dict_0['str_5'] = 'value_5'
    dict_0['str_6'] = 'value_6'
    dict_0['float_0'] = float_0
    dict_0['int_0'] = 17
    inventory_

# Generated at 2022-06-24 17:56:08.856374
# Unit test for method inventory_graph of class InventoryCLI

# Generated at 2022-06-24 17:56:11.986128
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # Results of run are printed to stdout
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:56:25.932236
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top = Host(float_0)
    top = top.set_variable('ANSIBLE_' + 'INVENTORY_UNPARSED_FAILED', '')
    top = top.set_variable('ANSIBLE_' + 'INVENTORY_ENABLED', '')
    top = top.get_group('all')
    top = top.get_host(float_0)
    top = top.get_host(float_0)
    top = top.get_host('')
    top = top.set_variable('ANSIBLE_' + 'INVENTORY_ENABLED', '')

# Generated at 2022-06-24 17:56:29.655446
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    #assert inventory_c_l_i_0.inventory_graph() == expected_value



# Generated at 2022-06-24 17:56:35.471474
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    test_0 = 0

    group_0 = Group()
    group_0.name = 'all'
    group_0.child_groups = {}

    group_1 = Group()
    group_1.name = 'foo'
    group_1.child_groups = {}
    group_1.parent_group = 'all'

    host_0 = Host()
    host_0.name = 'localhost'

    host_1 = Host()
    host_1.name = 'foohost'

    group_1.hosts = [host_0, host_1]

    group_0.child_groups = [group_1]


    inventory_c_l_i_0 = InventoryCLI(test_0)
    class_name_0 = inventory_c_l_i_0.json_inventory(group_0)

# Generated at 2022-06-24 17:56:47.983349
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    import sys

    def _test_run_mock_init(self, float_0):
        pass

    def _test_run_mock_post_process_args(self, params):
        pass

    def _test_run_mock_main(self):
        pass

    def _test_run_mock_run(self):
        pass

    sys.modules["ansible"] = "ansible"
    sys.modules["ansible.cli"] = "ansible.cli"
    sys.modules["ansible.cli.common"] = "ansible.cli.common"
    sys.modules["ansible.cli.common.base"] = "ansible.cli.common.base"
    sys.modules["ansible.cli.doc"] = "ansible.cli.doc"

# Generated at 2022-06-24 17:56:50.608410
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-24 17:56:55.210024
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_1 = 890.1324154383932
    inventory_c_l_i_1 = InventoryCLI(float_1)
    float_1 = 890.1324154383932
    inventory_c_l_i_1 = InventoryCLI(float_1)


# Generated at 2022-06-24 17:57:19.537021
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    inventory_c_l_i_0 = InventoryCLI(0.0)
    inventory_c_l_i_0._graph_group = 0.0
    arg_0 = 'host'
    arg_1 = 0.0
    result_0 = inventory_c_l_i_0._graph_name(arg_0, arg_1)
    result_1 = inventory_c_l_i_0._graph_group(arg_0, arg_1)
    result_2 = inventory_c_l_i_0.inventory_graph()
    assert result_0 == 'host'
    assert result_1 == '@all:'
    assert result_2 == '@all:'


# Generated at 2022-06-24 17:57:25.307281
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # initialize object
    float_0 = 1.0
    inventory_c_l_i_0 = InventoryCLI(float_0)

    # test method
    inventory_c_l_i_0.run()

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-24 17:57:26.558632
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    pass


# Generated at 2022-06-24 17:57:29.704647
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # FIXME: need to setup test environment for unit test of dump

    # Test with all possible inputs
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    string_0 = inventory_c_l_i_0.dump(float_0)
    print(string_0)


# Generated at 2022-06-24 17:57:35.985271
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 780.5137345369095
    inventory_c_l_i_0 = InventoryCLI(float_0)
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    stuff_0 = to_text(yaml.dump(stuff, Dumper=AnsibleDumper, default_flow_style=False, allow_unicode=True))
    assert stuff_0 == {u'hosts': [u'host3', u'host2', u'host1'], u'vars': {u'foo': u'bar'}, u'children': [u'child1', u'child2']}

# Generated at 2022-06-24 17:57:38.566117
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    inventory_c_l_i_0 = InventoryCLI(72.0)
    top = ''
    inventory_c_l_i_0.toml_inventory(top)

# Generated at 2022-06-24 17:57:47.373029
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    dict_0 = {}
    dict_0['test'] = {'hosts': [], 'children': ['test_child']}
    dict_0['test_child'] = {'hosts': [], 'children': []}
    dict_0['test_child']['hosts'].append('test_host1')
    dict_0['test_child']['hosts'].append('test_host2')
    dict_0['_meta'] = {'hostvars': {'test_host1': {}, 'test_host2': {}}}
    test_group_0 = MockGroup('test', {'groups': [], 'hosts': []})
    test_group_

# Generated at 2022-06-24 17:57:52.052786
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    # Setup input from test data
    float_0 = 318.6313589832631
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top = ''
    # Run method
    results = inventory_c_l_i_0.json_inventory(top)
    assert_equals(results, "")


# Generated at 2022-06-24 17:58:00.726288
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    host_0 = 'host'
    verbosity_0 = 1
    group_names_0 = '_group_names'
    group_names_1 = 'all'
    graph_0 = '--graph'
    inventory_c_l_i_0 = InventoryCLI(verbosity_0)
    group_0 = Mock()
    group_0.name = group_names_1
    group_0.child_groups = [{group_names_1}]
    group_0.hosts = [{host_0}]
    if context.CLIARGS['graph']:
        results = inventory_c_l_i_0.inventory_graph()
    assert results == None


# Generated at 2022-06-24 17:58:06.377148
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    group_0 = Group()
    group_0.name = 'all'
    group_0.hosts = [InventoryCLI(float_0), InventoryCLI(float_0), InventoryCLI(float_0), InventoryCLI(float_0), InventoryCLI(float_0)]
    group_0.vars = {'yawl': 'yearn', 'vamps': 'wooers', 'looby': 'dister', 'sangs': 'embells'}

# Generated at 2022-06-24 17:58:32.351360
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 845.6639
    inventory_c_l_i_0 = InventoryCLI(float_0)
    dk_format = 'json'
    myvars_0 = {'var1': 'val1', 'var2': 'val2'}
    try:
        inventory_c_l_i_0.dump(myvars_0)
    except:
        print("Uncaught exception was raised")


# Generated at 2022-06-24 17:58:35.718784
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_c_l_i_0 = InventoryCLI(0.4369)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:58:44.682216
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    group_0 = Mock(spec_set=Group)
    group_0.child_groups = set()
    group_0.hosts = set()
    group_0.name = "b5X"
    group_0.vars = {}
    group_0.get_vars.return_value = {}
    group_0.child_groups = set()
    group_0.hosts = set()
    group_0.name = "n!Q"
    group_0.vars = {}
    group_0.get_vars.return_value = {}
    group_0.child_groups = set()
    group_0.hosts = set()
    group_

# Generated at 2022-06-24 17:58:52.243111
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    top = 'bar'
    inventory_c_l_i_0 = InventoryCLI(top)
    inventory_c_l_i_0.validate_conflicts = MagicMock(name='validate_conflicts')
    top_0 = inventory_c_l_i_0._get_group(top)
    inventory_c_l_i_0.validate_conflicts = MagicMock(name='validate_conflicts')
    inventory_c_l_i_0.toml_inventory(top_0)


# Generated at 2022-06-24 17:59:02.522495
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    arg_0 = Group()
    arg_1 = arg_0
    arg_2 = arg_0
    arg_3 = arg_0
    arg_4 = arg_0
    arg_5 = arg_0
    arg_6 = arg_0
    arg_7 = arg_0
    arg_8 = arg_0
    arg_9 = arg_0
    arg_10 = arg_0
    arg_11 = arg_0
    arg_12 = arg_0
    arg_13 = arg_0
    arg_14 = arg_0
    arg_15 = arg_0
    arg_16 = arg_0
    arg_17 = arg_0
    arg_

# Generated at 2022-06-24 17:59:08.717113
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    top = [
        {'name': 'foo', 'hosts': ['1.1.1.1', '2.2.2.2'], 'children': ['hosts1', 'hosts2']},
        {'name': 'hosts1', 'hosts': ['3.3.3.3']},
        {'name': 'hosts2', 'hosts': ['4.4.4.4']}
    ]

    result = InventoryCLI.toml_inventory(top)

# Generated at 2022-06-24 17:59:15.297388
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    ansible_options_error_0 = AnsibleOptionsError()
    float_0 = 954.6337846726582

    try:
        inventory_c_l_i_1 = InventoryCLI(float_0)
        inventory_c_l_i_1.run()
    except AnsibleOptionsError:
        pass


# Generated at 2022-06-24 17:59:22.345543
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():

    top = {}
    def format_group(group):
        results = {}
        results[group.name] = {}

        results[group.name]['children'] = []
        for subgroup in sorted(group.child_groups, key=attrgetter('name')):
            if subgroup.name == 'ungrouped' and not has_ungrouped:
                continue
            if group.name != 'all':
                results[group.name]['children'].append(subgroup.name)
            results.update(format_group(subgroup))

        if group.name != 'all':
            for host in sorted(group.hosts, key=attrgetter('name')):
                if host.name not in seen:
                    seen.add(host.name)

# Generated at 2022-06-24 17:59:33.209570
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.pattern = 'all'
    inventory_c_l_i_0.output_file = 'deadbeef'
    inventory_c_l_i_0.host = False
    inventory_c_l_i_0.graph = False
    inventory_c_l_i_0.action = 'inventory_c_l_i_0.action'
    inventory_c_l_i_0.show_vars = True
    inventory_c_l_i_0.verbosity = 3
    inventory_c_l_i_0.inventory = 'hosts'

# Generated at 2022-06-24 17:59:37.573825
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)

    inventory_c_l_i_0.inventory_graph()


# Generated at 2022-06-24 18:00:02.009447
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    inventory_c_l_i_0 = InventoryCLI()
    inventory_c_l_i_0.inventory_graph()
    inventory_c_l_i_0.output_list()


# Generated at 2022-06-24 18:00:14.368130
# Unit test for method toml_inventory of class InventoryCLI

# Generated at 2022-06-24 18:00:19.121907
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = 77.73453843398605
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 18:00:21.219213
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_c_l_i_0 = InventoryCLI(789.0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 18:00:23.820431
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 47.77
    inventory_c_l_i_0 = InventoryCLI(float_0)
    results_0 = inventory_c_l_i_0.dump(None)
    assert results_0 == None


# Generated at 2022-06-24 18:00:26.156511
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
        stuff = {'test': 'example'}
        results = '{\n    "test": "example"\n}'
        x = InventoryCLI(1)
        assert x.dump(stuff) == results


# Generated at 2022-06-24 18:00:29.773348
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top = inventory_c_l_i_0._get_group('all')
    i_g_0 = inventory_c_l_i_0._graph_group(top)
    inventory_c_l_i_0.inventory_graph()


# Generated at 2022-06-24 18:00:35.938330
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    global C
    C.INVENTORY_EXPORT = True

# Generated at 2022-06-24 18:00:43.353921
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    """Test of method run of class InventoryCLI"""

    inventory_c_l_i_0 = InventoryCLI(float(38615))

    # Test with 'list' option
    sys.argv[1:] = ['--list']
    inventory_c_l_i_0.run()

    # Test with 'host' option
    sys.argv[1:] = ['--host', 'test']
    inventory_c_l_i_0.run()

    # Test with 'graph' option
    sys.argv[1:] = ['--graph']
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 18:00:47.204058
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = 786.588549183533
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 18:02:03.587026
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # Declare objects and variables
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top = test_case_0()
    results = inventory_c_l_i_0.toml_inventory(top)
    assert_equal(results, test_case_0(), "Call to toml_inventory of class InventoryCLI failed")


# Generated at 2022-06-24 18:02:14.617807
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    int_0 = 64
    inventory_c_l_i_0 = InventoryCLI(int_0)

    # Test the call to post_process_args method
    inventory_c_l_i_0.post_process_args()

    int_0 = 8189
    inventory_c_l_i_0 = InventoryCLI(int_0)

    # Test the call to post_process_args method
    inventory_c_l_i_0.post_process_args()

    int_0 = 5
    inventory_c_l_i_0 = InventoryCLI(int_0)

    # Test the call to post_process_args method
    inventory_c_l_i_0.post_process_args()

    int_0 = 461

# Generated at 2022-06-24 18:02:17.078984
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = 631.0248599091118
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 18:02:18.374143
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    pass


# Generated at 2022-06-24 18:02:19.537503
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    pass # TODO: Implement test or mark method as abstract


# Generated at 2022-06-24 18:02:31.899996
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    args = ['ansible', '-m', 'setup', '-i', './test/test_inventory_current_working_directory.json', 'localhost']
    context.CLIARGS = context._parser.parse_args(args)
    context.CLIARGS['list'] = True
    # create inventory with host 127.0.0.1 that doesn't exist

# Generated at 2022-06-24 18:02:37.296178
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = 961.484444444444444444444444444444
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.run()



# Generated at 2022-06-24 18:02:42.376426
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_0 = 15.216
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top_0 = inventory_c_l_i_0._get_group('all')
    inventory_c_l_i_0.json_inventory(top_0)


# Generated at 2022-06-24 18:02:43.931436
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = 890.1324154383932
    inventory_c_l_i_0 = InventoryCLI(float_0)


# Generated at 2022-06-24 18:02:46.321778
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # Tests performance of this method on a large dataset
    try:
        inventory_c_l_i_0 = InventoryCLI(0.5)
    except AnsibleOptionsError:
        pass
