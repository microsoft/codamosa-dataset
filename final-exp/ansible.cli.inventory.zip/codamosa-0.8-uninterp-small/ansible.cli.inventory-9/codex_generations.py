

# Generated at 2022-06-24 17:54:52.795461
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_2 = InventoryCLI(str_0)
    options_0 = inventory_c_l_i_2.post_process_args()


# Generated at 2022-06-24 17:54:56.782665
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    start_at_0 = inventory_c_l_i_0._get_group(context.CLIARGS['pattern'])  # replace by valid value
    assert inventory_c_l_i_0.inventory_graph() == ''


# Generated at 2022-06-24 17:55:02.914548
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    assert not inventory_c_l_i_0.inventory_graph()


# Generated at 2022-06-24 17:55:06.331120
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    
    # This test is considered only for coverage perpose, since it is not
    # possible to check the type of object in the output
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:55:10.262519
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = '\'MdIPx'
    str_1 = '(h4nZ:LoX'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_2 = 't/5d\x7f'
    inventory_c_l_i_1 = InventoryCLI(str_1)
    inventory_c_l_i_2 = InventoryCLI(str_2)


# Generated at 2022-06-24 17:55:12.963265
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)

    inventory_c_l_i_0.run()

# Generated at 2022-06-24 17:55:25.855731
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = ']G'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    argparse_d_e_f_a_ult_0 = help_0
    argparse_n_0_0 = '@H^'
    argparse_a_c_t_i_0_0 = 'store_true'
    argparse_d_e_0_0 = 'list'

# Generated at 2022-06-24 17:55:31.631120
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    try:
        import json
    except ImportError:
        print('Could not import json module.')
        exit(1)

    print(json.dumps({
        'foo': 'bar',
        'baz': False,
        'null': None,
        'integer': 1,
        'list': [1, 2, 3],
        'dictionary': {'foo': 'bar', 'baz': 'bop'}
    }))


# Generated at 2022-06-24 17:55:37.635556
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    inventory_c_l_i_0 = InventoryCLI('str_0')
    str_0 = 'str_0'
    top_0 = inventory_c_l_i_0._get_group('all')
    results_0 = inventory_c_l_i_0.json_inventory(top_0)
    assert results_0 == {'_meta': {'hostvars': {}}, 'all': {'hosts': [], 'children': ['ungrouped']}, 'ungrouped': {'hosts': ['127.0.0.1'], 'vars': {}, 'children': []}}


# Generated at 2022-06-24 17:55:43.011291
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_1 = 'gpbM5AEHab.P\t^,$R/'
    inventory_c_l_i_1 = InventoryCLI(str_1)
    stuff = 'stuff'
    yaml_1 = 'yaml 1'
    yaml_2 = 'yaml 2'
    toml_1 = 'toml 1'
    toml_2 = 'toml 2'
    json_1 = 'json 1'
    json_2 = 'json 2'
    results = 'results'
    context.CLIARGS['yaml'] = 1
    context.CLIARGS['toml'] = 1
    results = 'results'
    context.CLIARGS['json'] = 1

    # import yaml
    # from ansible.parsing.yaml.dumper import AnsibleD

# Generated at 2022-06-24 17:56:06.435849
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    inventory_c_l_i_0 = InventoryCLI('-i src/inventory -l')
    try:
        dump_fut = inventory_c_l_i_0.dump(None)
    except NotImplementedError:
        pass


# Generated at 2022-06-24 17:56:14.101361
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    yaml_0 = YAML()
    yaml_0.default_flow_style=False
    yaml_0.allow_unicode=True
    yaml_0.Dumper=AnsibleDumper
    inventory_c_l_i_0.yaml=yaml_0
    inventory_c_l_i_0.graph=True
    inventory_c_l_i_0.num_workers=20
    inventory_c_l_i_0.list=True
    print(inventory_c_l_i_0.json_inventory(None))


# Generated at 2022-06-24 17:56:16.121042
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    inventory_c_l_i_0 = InventoryCLI("general_inventory")
    options_0 = inventory_c_l_i_0.post_process_args("test_options")


# Generated at 2022-06-24 17:56:28.737577
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_0 = 'pepvI8CKW.3\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = 'Tsq:s!lU4y'
    str_2 = 'R9j\t-_$0[0'
    str_3 = '\tjy^B>p`1'
    str_4 = 'Yh8\teLKej'
    assert inventory_c_l_i_0.dump(str_1) == 'Tsq:s!lU4y'
    assert inventory_c_l_i_0.dump(str_2) == 'R9j\t-_$0[0'

# Generated at 2022-06-24 17:56:32.609638
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    # No exception thrown for method yaml_inventory of class InventoryCLI
    try:
        str_0 = 'GPBm5AEHAb.P\t^,$r/'
        inventory_c_l_i_0 = InventoryCLI(str_0)
        inventory_c_l_i_0.yaml_inventory(None)
    except Exception as e:
        print(e)


# Generated at 2022-06-24 17:56:46.566793
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # Test case 1
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)

    class AnsibleOptionsError_0(Exception):
        pass
    class AnsibleOptionsError_1(Exception):
        pass
    class AnsibleError_0(Exception):
        pass
    class AnsibleError_1(Exception):
        pass
    def test_case(x_0, x_1):
        try:
            if x_0:
                if x_1:
                    raise AnsibleOptionsError_0
                raise AnsibleOptionsError_1
        except AnsibleOptionsError_0:
            print('AnsibleOptionsError_0')
            return False

# Generated at 2022-06-24 17:56:57.186529
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    hosts_0 = get_hosts()
    inventory_c_l_i_0 = InventoryCLI(hosts_0)
    top_0 = inventory_c_l_i_0._get_group('all')
    json_inventory_0 = inventory_c_l_i_0.json_inventory(top_0)

# Generated at 2022-06-24 17:57:05.095935
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper

    temp = {'a': {'b': 'c'}}
    temp_str = yaml.dump(temp, Dumper=AnsibleDumper, default_flow_style=False)
    InventoryCLI.dump(temp)

# Generated at 2022-06-24 17:57:10.967035
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # Why is top being defined in this method?
    top = "top"
    inventory_c_l_i_0 = InventoryCLI("inventory_c_l_i_0")
    assert(inventory_c_l_i_0.toml_inventory(top) == None)


# Generated at 2022-06-24 17:57:15.725203
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    str_0 = '_54Xszs2Z.,^o`N'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_0 = '\\7h*i.`'
    result = inventory_c_l_i_0.inventory_graph(str_0)
    print(result)


# Generated at 2022-06-24 17:57:45.065706
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    #
    # Initialize test variables
    #
    import random
    import sys
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager

    #
    # Initialize the CLI object
    #
    cli_obj_0 = CLI(sys.argv)

    #
    # Initialize Ansible Configuration
    #
    config_manager_obj_0 = ConfigManager()
    config_manager_obj_0._parser = cli_obj_0.parser
    config_manager_obj_0.options = cli_obj_0.options
    config_manager_obj_0.args = ['ansible-inventory']
    config_manager_obj_0.ensure_value('config_file', '')

    #
    # Initialize test arguments
    #

# Generated at 2022-06-24 17:57:51.533323
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:58:01.145384
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
  str_0 = 'GPBm5AEHAb.P\t^,$r/'
  inventory_c_l_i_0 = InventoryCLI(str_0)
  
  str_0 = 'GPBm5AEHAb.P\t^,$r/'
  inventory_c_l_i_0.post_process_args(str_0)
  
  str_0 = 'GPBm5AEHAb.P\t^,$r/'
  str_1 = None
  inventory_c_l_i_0.post_process_args(str_0, str_1)
  
  str_0 = 'GPBm5AEHAb.P\t^,$r/'
  str_1 = None
  str_2 = {}
  inventory_c_l_i

# Generated at 2022-06-24 17:58:09.901579
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    str_0 = '^"~7V'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = '`R^"sj'
    str_2 = 'wT;Tj'
    str_3 = 'mX *'
    str_4 = ':B%c'
    str_5 = 'WF,l'
    str_6 = '9o) `N'
    str_7 = 'Q'
    str_8 = '*x'
    str_9 = '+~'
    str_10 = 'C'
    str_11 = 'G;H}'
    str_12 = '9X'
    str_13 = '$f'
    str_14 = '+'
    str_15 = 'P'
    str_16

# Generated at 2022-06-24 17:58:16.465394
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    str_0 = 'KCH7s+$ZDYW8Vj`6z`"x'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = '_z'
    str_2 = 'h'
    str_3 = '5'
    str_4 = ']'
    str_5 = 'P'
    dict_0 = {str_1:str_2, str_3:str_4, str_5:str_2}
    inventory_c_l_i_0.json_inventory(dict_0)


# Generated at 2022-06-24 17:58:25.641521
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    test_CLIARGS = dict(verbosity=0, list=False, host=False, graph=False, pattern='', yaml=False, toml=False, show_vars=False, export=False, output_file=None)

    context.CLIARGS = test_CLIARGS
    test_case_0()

    test_CLIARGS = dict(verbosity=0, list=False, host='', graph=False, pattern='', yaml=False, toml=False, show_vars=False, export=True, output_file=None)
    context.CLIARGS = test_CLIARGS

    test_case_0()


# Generated at 2022-06-24 17:58:31.490892
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    result_str_0 = inventory_c_l_i_0.yaml_inventory()


# Generated at 2022-06-24 17:58:39.960612
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    print( dataclasses.is_dataclass(InventoryCLI) )
    print( inspect.isclass(InventoryCLI) )

    # Init dependency
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)

    # Init input param
    stuff = 0

    # Invoke method
    stuff = inventory_c_l_i_0.dump(stuff)


# Generated at 2022-06-24 17:58:52.323738
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    inventory_c_l_i_0 = InventoryCLI('display_name_1')

# Generated at 2022-06-24 17:58:54.920433
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = '-v'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.run()

# Generated at 2022-06-24 17:59:21.362467
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # Setup
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    list_0 = []
    # Setup Call
    str_return_0 = InventoryCLI.dump(list_0)
    assert str_return_0 == '[]'
    # Setup Second Call
    str_return_1 = InventoryCLI.dump(list_0)
    assert str_return_1 == '[]'


# Generated at 2022-06-24 17:59:26.685158
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)

    command_0 = inventory_c_l_i_0.load_plugins()
    assert True


# Generated at 2022-06-24 17:59:30.204618
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    inventory_c_l_i_0 = InventoryCLI('GPBm5AEHAb.P\t^,$r/')
    inventory_c_l_i_0.post_process_args(sys.argv)

# Generated at 2022-06-24 17:59:31.197104
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # Case 0
    # TODO: write test case
    assert False


# Generated at 2022-06-24 17:59:33.880261
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_c_l_i_0 = InventoryCLI('')
    inventory_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_InventoryCLI_run()
    print('Done')

# Generated at 2022-06-24 17:59:39.928283
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = '"9X?e'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    top_0 = '9X?e'
    result_0 = inventory_c_l_i_0.yaml_inventory(top_0)
    assert '9X?e' in result_0


# Generated at 2022-06-24 17:59:47.782238
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = '.{+;K\x0e\x0b!\x11'
    inventory_c_l_i_1 = InventoryCLI(str_1)
    inventory_c_l_i_1.json_inventory(str_1)


# Generated at 2022-06-24 17:59:49.489068
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # Remove the following line and add your test code here.
    assert False


# Generated at 2022-06-24 17:59:55.877189
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # 1: TypeError: the first argument must be a string
    str_1 = 'i.s\x83\x12\x19\x06\x80'
    inventory_c_l_i_1 = InventoryCLI(str_1)
    stuff_1 = {'foo': 'bar'}
    # results = inventory_c_l_i_1.dump(stuff_1)
    # assert results == '{"foo": "bar"}'


# Generated at 2022-06-24 18:00:04.562785
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    # Given
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)

    # When
    top = inventory_c_l_i_0._get_group('all')
    yaml_inventory_0 = inventory_c_l_i_0.yaml_inventory(top)

    # Then
    assert yaml_inventory_0 is not None


# Generated at 2022-06-24 18:00:52.779433
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    assert True


# Generated at 2022-06-24 18:00:59.898235
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = 'b\'\''
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = '*{T.'
    opts = {'verbosity': 2, 'pattern': str_1, 'version': False, 'inventory_file': ['ansible.cfg'], 'syntax': False, 'host': False, 'graph': False, 'list': True, 'yaml': False, 'output': None, 'toml': False, 'show_vars': False}
    assert inventory_c_l_i_0.post_process_args(opts) == opts

    str_2 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_1 = InventoryCLI(str_2)

# Generated at 2022-06-24 18:01:03.323026
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    assert(inventory_c_l_i_0.yaml_inventory(str_0) != None)


# Generated at 2022-06-24 18:01:15.520348
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    top = inventory_c_l_i_0._get_group('all')

# Generated at 2022-06-24 18:01:16.880232
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    test_case_1()


# Generated at 2022-06-24 18:01:21.796455
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    str_0  = '\x02\x00\x16\x00'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    # Test return type
    assert isinstance(inventory_c_l_i_0.inventory_graph(), str)


# Generated at 2022-06-24 18:01:24.644795
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    str_0 = 'De,a$S('
    inventory_c_l_i_0 = InventoryCLI(str_0)



# Generated at 2022-06-24 18:01:35.390614
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    results = to_text(yaml.dump(stuff, Dumper=AnsibleDumper, default_flow_style=False, allow_unicode=True))

    import json
    from ansible.parsing.ajson import AnsibleJSONEncoder
    try:
        results = json.dumps(stuff, cls=AnsibleJSONEncoder, sort_keys=True, indent=4, preprocess_unsafe=True, ensure_ascii=False)
    except TypeError as e:
        results = json.dumps(stuff, cls=AnsibleJSONEncoder, sort_keys=False, indent=4, preprocess_unsafe=True, ensure_ascii=False)

# Generated at 2022-06-24 18:01:37.135417
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    str_0 = 'Ks[s`W\t'
    inventory_c_l_i_0 = InventoryCLI(str_0)


# Generated at 2022-06-24 18:01:39.373692
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    toml_inventory_0 = InventoryCLI.toml_inventory(inventory_c_l_i_0, top)


# Generated at 2022-06-24 18:03:26.721913
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    inventory_c_l_i_0 = InventoryCLI(context.CLIARGS)
    inventory_c_l_i_0.toml_inventory()

# Generated at 2022-06-24 18:03:33.332820
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    for str_1 in (
            'z7V,h~{uL1^8Qv0FuoN[]s=\'IwD,W8rvkJT%(t/1.,Ie(<`EZ,3q%c)$PYmKppuf#k q',
            'g2QKj#F/,L<_H(q}c%$\nuA+j!R$8hdvzH9X?>:j+D&W:2SkJbMk=j}n^BY;wW,rC_pT?9{jt(b '):
        with pytest.raises(UnboundLocalError):
            test_case_0()


# Generated at 2022-06-24 18:03:37.597221
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = '>*Qg9X^.`7'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    argv_0 = ['-h']
    options_0 = inventory_c_l_i_0.parse(argv_0)
    options_1 = inventory_c_l_i_0.post_process_args(options_0)
    assert options_1.host == True


# Generated at 2022-06-24 18:03:42.564627
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    toml_inventory_0 = InventoryCLI.toml_inventory(InventoryCLI, InventoryCLI)
    assert not toml_inventory_0

    yaml_inventory_0 = InventoryCLI.yaml_inventory(InventoryCLI, InventoryCLI)
    assert not yaml_inventory_0

    json_inventory_0 = InventoryCLI.json_inventory(InventoryCLI, InventoryCLI)
    assert not json_inventory_0


# Generated at 2022-06-24 18:03:43.646167
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    test_case_0()


# Generated at 2022-06-24 18:03:48.185064
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)


# Generated at 2022-06-24 18:03:54.602784
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    inventory_c_l_i_2 = InventoryCLI('Yah1wFU8tdkM')
    group_0 = inventory_c_l_i_2._get_group('all')

    try:
        inventory_c_l_i_2.toml_inventory(group_0)
    except:
        assert False, 'Error raised - could not run toml_inventory'
    else:
        assert True


# Generated at 2022-06-24 18:03:58.985486
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    start_at = self._get_group(context.CLIARGS['pattern'])

    if start_at:
        return '\n'.join(self._graph_group(start_at))

    return ''


# Generated at 2022-06-24 18:04:06.052125
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_0 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0_dump_0 = inventory_c_l_i_0.dump(test_case_0)


# Generated at 2022-06-24 18:04:09.764231
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    str_1 = 'GPBm5AEHAb.P\t^,$r/'
    inventory_c_l_i_1 = InventoryCLI(str_1)
    str_2 = '#UTA0gB@&'
    inventory_c_l_i_1.json_inventory(str_2)
