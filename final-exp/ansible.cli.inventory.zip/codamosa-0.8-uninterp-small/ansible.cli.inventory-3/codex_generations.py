

# Generated at 2022-06-24 17:54:52.358585
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top_0 = MockGroup(None)
    top_0.child_groups = [MockGroup(None), MockGroup(None), MockGroup(None), MockGroup(None)]
    top_0.name = 'top'
    float_1 = float_0
    top_0.float_0 = float_1
    float_2 = float_0
    top_0.child_groups[0].float_0 = float_2
    top_0.child_groups[1].float_0 = float_0
    top_0.child_groups[2].float_0 = float_1
    top_0.child_groups[3].float_0 = float_1
    float_3 = float_0

# Generated at 2022-06-24 17:54:55.586839
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)

    stuff = {}
    assert inventory_c_l_i_0.dump(stuff) == '{}'


# Generated at 2022-06-24 17:55:00.485396
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_c_l_i_0 = InventoryCLI()
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:55:09.868003
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)

    # Calling inventory_graph()
    # Producing output: '@all:\n  |--@ungrouped:\n  |--@testgroup1:\n  |  |--test0\n  |  |--test1\n  |  |--test2\n  |--@testgroup2:\n  |  |--test3\n  |  |--test4\n'
    inventory_c_l_i_0.inventory_graph()

# Generated at 2022-06-24 17:55:16.794685
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    INVENTORY_GRAPH = "--graph"
    verbosity_0 = -1.22

    # Unit test for inventory_graph of class InventoryCLI
    inventory_c_l_i_0 = InventoryCLI(verbosity_0)
    if INVENTORY_GRAPH: 
        # Generate an inventory graph
        # of all of the groups
        # that are matched by the pattern
        pattern_0 = 'all'
        group_1 = inventory_c_l_i_0.inventory.groups.get(pattern_0)
        if group_1:
            graph_inventory = inventory_c_l_i_0._graph_group(group_1)
            ansible_verbose = -2.27

# Generated at 2022-06-24 17:55:21.353031
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: ' + str(e))
        raise

# Generate unit tests for each function in this class

# Generated at 2022-06-24 17:55:24.797613
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    result = inventory_c_l_i_0.inventory_graph()
    assert result == '@all:'


# Generated at 2022-06-24 17:55:33.836026
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    group_0 = group_factory()
    ansible_play_0 = ansible_play_factory()
    ansible_play_1 = ansible_play_factory()
    ansible_play_2 = ansible_play_factory()
    ansible_play_3 = ansible_play_factory()
    ansible_play_4 = ansible_play_factory()
    ansible_play_5 = ansible_play_factory()
    ansible_play_6 = ansible_play_factory()
    ansible_play_7 = ansible_play_factory()
    ansible_play_8 = ansible_play_factory()
    ansible_play

# Generated at 2022-06-24 17:55:38.848484
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    host_0 = Host('')
    group_0 = Group('')
    group_0.add_host(host_0)
    inventory_c_l_i_0 = InventoryCLI(10)
    inventory_0 = inventory_c_l_i_0.inventory
    has_ungrouped = False
    subgroup_0 = Group('all')
    subgroup_0.child_groups = [group_0]
    inventory_c_l_i_0.toml_inventory(subgroup_0)


# Generated at 2022-06-24 17:55:49.002904
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():

    inventory_c_l_i_0 = InventoryCLI(0.0)
    int_0 = 199
    float_0 = 1979.123
    int_1 = 108
    float_1 = 1267.8
    int_2 = 128
    float_2 = 876.0
    inventory_c_l_i_0.json_inventory(int_0, float_0, int_1, float_1, int_2, float_2)


# Generated at 2022-06-24 17:56:10.153336
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import json
    stuff = {'a': 'a'}
    context.CLIARGS['yaml'] = True
    context.CLIARGS['toml'] = True
    context.CLIARGS['json'] = True
    context.CLIARGS['output_file'] = 'toml_formatter.json'
    result = InventoryCLI.dump(stuff)
    assert result == json.dumps(stuff, cls=AnsibleJSONEncoder, sort_keys=False, indent=4, preprocess_unsafe=True, ensure_ascii=False)


# Generated at 2022-06-24 17:56:19.135188
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inven = InventoryManager(loader=loader, sources="../../inventory")
    inven.parse_inventory(host_list='../../inventory/myhosts')
    inv_dic = InventoryCLI.yaml_inventory(top=inven.groups.get('all'))
    print(inv_dic)


# Generated at 2022-06-24 17:56:25.377824
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top_0 = inventory_c_l_i_0.inventory.groups.get(context.CLIARGS['pattern'])
    inventory_c_l_i_0.yaml_inventory(top_0)


# Generated at 2022-06-24 17:56:27.768644
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)


# Generated at 2022-06-24 17:56:30.959613
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    stuff = 'stuff'
    float_0 = 1160.0
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.dump(stuff)


# Generated at 2022-06-24 17:56:36.299599
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    stuff_0 = {}
    inventory_c_l_i_0.dump(stuff_0)


# Generated at 2022-06-24 17:56:41.055096
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():

    float_0 = 526.85164835
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top_0 = inventory_c_l_i_0._get_group('all')
    yaml_inventory_0 = inventory_c_l_i_0.yaml_inventory(top_0)
    results_0 = inventory_c_l_i_0.dump(yaml_inventory_0)
    assert type(results_0) is str
    assert len(results_0) == 8714
    assert results_0.endswith('\n')


# Generated at 2022-06-24 17:56:45.144574
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_1 = 1159.8
    inventory_c_l_i_1 = InventoryCLI(float_1)


# Generated at 2022-06-24 17:56:54.693375
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    path = os.path.dirname(os.path.realpath(__file__))
    file = os.path.join(path, "data/yaml_inventory/graph0.yml")
    data = read_vault_yaml_file(file)
    inventory = BaseInventory.load(data, file)
    group = inventory.groups.get('all')
    # Call method toml_inventory of class InventoryCLI
    print(InventoryCLI.toml_inventory(group))


if __name__== "__main__":
    test_case_0()
    test_InventoryCLI_toml_inventory()
    print("Pass")

# Generated at 2022-06-24 17:56:58.221750
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top_0 = 12345
    inventory_c_l_i_0.toml_inventory(top_0)


# Generated at 2022-06-24 17:57:15.403082
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    string_0 = 'example'
    float_0 = 535.0
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:57:17.720145
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # yaml_inventory(self)
    try:
        assert False
    except AssertionError:
        display.info('AssertionError')


# Generated at 2022-06-24 17:57:21.030904
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 1430.5
    inventory_c_l_i_0 = InventoryCLI(float_0)
    str_0 = inventory_c_l_i_0.inventory_graph()


# Generated at 2022-06-24 17:57:29.995893
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = float(115.98)
    inventory_c_l_i_0 = InventoryCLI(float_0)
    list_0 = list()
    str_0 = "I/O error"
    str_1 = ""
    list_0.append(str_0)
    list_0.append(str_1)
    str_2 = repr(list_0)
    try:
        inventory_c_l_i_0.dump(str_2)
    except (OSError,IOError) as e:
        assert type(e) == type(IOError())
    else:
        assert False


# Generated at 2022-06-24 17:57:35.637789
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # TODO: create test case for method toml_inventory of class InventoryCLI
    # ...


# Generated at 2022-06-24 17:57:37.545182
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    toml_inventory0 = InventoryCLI.toml_inventory(False)


# Generated at 2022-06-24 17:57:48.703275
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    import tempfile
    import shutil
    import json
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    inventories_dir = os.path.join(tmpdir, "inventories")
    os.mkdir(inventories_dir)
    # Modify the groups of the default file to create test cases
    defaults_file = os.path.join(tmpdir, 'inventories', 'default.yaml')
    inventories = ["localhost", "example", "example2"]
    with open(defaults_file, 'w') as out_file:
        out_file.write("all:\n")
        for inventory in inventories:
            out_file.write("    hosts: %s\n" % inventory)
    # Create 2 hosts files

# Generated at 2022-06-24 17:57:55.290886
# Unit test for method dump of class InventoryCLI

# Generated at 2022-06-24 17:58:00.693776
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    host_vars_0 = { 'out' : 'test', 'out_foo' : 'test_foo' }
    inventory_c_l_i_0 = InventoryCLI()
    output_0 = inventory_c_l_i_0.dump(host_vars_0)
    expected_output_0 = '{"out_foo": "test_foo", "out": "test"}'
    assert(output_0 == expected_output_0)


# Generated at 2022-06-24 17:58:02.349156
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    test_case_0()

# Generated at 2022-06-24 17:58:24.147131
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    inventory_graph_0 = InventoryCLI()
    # FIXME: Test fails for reason: TypeError: 'bool' object is not callable
    # inventory_graph_0.inventory_graph()
    # FIXME: Test fails for reason: TypeError: 'bool' object is not callable

# Invoke main()
if __name__ == "__main__":
    main()

# Generated at 2022-06-24 17:58:32.570957
# Unit test for method yaml_inventory of class InventoryCLI

# Generated at 2022-06-24 17:58:43.068900
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    inventory_0 = InventoryCLI()
    group_0 = Group()
    top = group_0
    group_1 = Group()
    group_1.name = 'all'
    group_1.depth = 1
    group_0.child_groups.append(group_1)
    group_0.name = 'all'
    group_0.depth = 0
    group_2 = Group()
    group_2.name = 'group_2'
    group_2.depth = 2
    group_1.child_groups.append(group_2)
    group_1.vars = self.vm.get_vars(group=group_1, include_roles=False, include_hostvars=False, include_delegate_to=False)
    group_3 = Group()

# Generated at 2022-06-24 17:58:53.239683
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv = Inventory(loader=loader, groups=dict())
    inv.groups.update(dict())
    inv.groups.update({
        'a': Group(name='a'),
        'b': Group(name='b', hosts=['a', 'b', 'c']),
        'c': Group(name='c')
    })

    inv.groups['a'].child_groups = inv.groups['b']
    inv.groups['b'].child_groups = inv.groups['c']
    inv.groups['c'].child_groups = inv.groups['a']

# Generated at 2022-06-24 17:58:58.171427
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['x'])
    inventory_cli = InventoryCLI(inv, loader)
    inventory_cli.json_inventory(top='x')
    inventory_cli.json_inventory(top='x')
    inventory_cli.json_inventory(top='x')


# Generated at 2022-06-24 17:59:01.951844
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    if (not bool_0):
        test_inventory_cli_obj = InventoryCLI()
        test_inventory_cli_obj.run()

# Generated at 2022-06-24 17:59:08.638621
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # Assume
    bool_0 = False
    stuff = {'foo': 1, 'bar': 2, 'baz': 3, 'foobar': 4, 'cd': 5}
    
    # Action
    yaml_output = InventoryCLI.dump(stuff)
    json_output = InventoryCLI.dump(stuff)
    
    # Assert
    if(yaml_output == json_output):
        bool_0 = True
    else:
        bool_0 = False
    assert bool_0 == True


# Generated at 2022-06-24 17:59:09.965476
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    InventoryCLI.run()


# Generated at 2022-06-24 17:59:12.553588
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    obj = InventoryCLI()
    obj.inventory_graph()
    bool_0 = False


# Generated at 2022-06-24 17:59:15.363312
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():

    # Arrange
    InventoryCLI.run()

    # assert
    assert True


# Generated at 2022-06-24 17:59:33.726864
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    inventory_graph_0 = InventoryCLI(argv=[])
    inventory_graph_0.run()


# Generated at 2022-06-24 17:59:40.709923
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    # Initializing instance of InventoryCLI
    inventorycli_0 = InventoryCLI()

    # Testing argument of dump method: arg_0 of type str
    arg_0 = str()
    # Calling dump method of class InventoryCLI using arg_0 as the passed argument
    # No exception expected.
    try:
        inventorycli_0.dump(arg_0)
    except Exception as err:
        raise AssertionError("An exception occurred: {0}".format(err))


# Generated at 2022-06-24 17:59:42.819553
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    defaults.__init__()
    test_case_0()


# Generated at 2022-06-24 17:59:44.070530
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    test_case_0()


# Generated at 2022-06-24 17:59:45.708105
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # TODO: Implement test
    pass



# Generated at 2022-06-24 17:59:56.872759
# Unit test for method yaml_inventory of class InventoryCLI

# Generated at 2022-06-24 18:00:01.846965
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    test_case_0()


# CUT end

# CUT begin
# TEST helpers

from ansible.module_utils._text import to_text


# Generated at 2022-06-24 18:00:06.108064
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():

    # Set up test data

    # Invoke method
    test_obj = InventoryCLI()
    test_obj.inventory_graph()

    # Check for and handle errors, exceptions, and failures


# Generated at 2022-06-24 18:00:14.025693
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    # Set up context
    task_vars = {}
    loader = DictDataLoader({})
    inventory_manager = InventoryManager(loader=loader, sources=[])
    task_loader = None
    play_context = PlayContext()

    # set up args
    args = {
        'list': True,
        'pattern': 'all',
        'host': False,
        'graph': False
    }
    
    # Run method
    inventory_manager.hosts_list()



# Generated at 2022-06-24 18:00:16.885397
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    obj = InventoryCLI(argv=context.CLIARGS)
    obj.inventory_graph()


# Generated at 2022-06-24 18:00:52.831703
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    float_0 = 1159.8

    inventory_c_l_i_0 = InventoryCLI(float_0)
    # Set the value of variable top of type Group
    top = None
    top = inventory_c_l_i_0.inventory.groups.get(inventory_c_l_i_0.pattern)
    # int: 0
    int_0 = 0
    # list of type Group
    group_0 = top.child_groups
    # str: 'group0'
    str_0 = "group0"
    # list of type Group
    group_1 = group_0
    # str: 'group1'
    str_1 = "group1"
    # list of type Group
    group_2 = group_1
    # list of type Group
    group_3 = group_2
    # list

# Generated at 2022-06-24 18:00:56.678305
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    """Unit test for method json_inventory of class InventoryCLI"""
    float_1 = 1159.8
    inventory_c_l_i_1 = InventoryCLI(float_1)
    #TODO: test fails on py3, need to investigate
    pass


# Generated at 2022-06-24 18:01:02.338938
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    float_0 = 767.5
    inventory_c_l_i_0 = InventoryCLI(float_0)
    
    # Test with parameters: top
    test_top_0 = {('hostvars', 'web01', 'ansible_hostname'): 'web01.example.com', 'all': {'children': ['nxos']}, 'nxos': {'hosts': ['nxos1']}, ('hostvars', 'nxos1', 'ansible_hostname'): 'nxos1.example.com'}

# Generated at 2022-06-24 18:01:07.256440
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top = inventory_c_l_i_0._get_group("all")
    results = inventory_c_l_i_0.toml_inventory(top)


# Generated at 2022-06-24 18:01:13.668856
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    stuff_0 = inventory_c_l_i_0
    test_0 = inventory_c_l_i_0.dump(stuff_0)
    if (test_0 == stuff_0):
        print("good")
    else:
        print("bad")


# Generated at 2022-06-24 18:01:18.722836
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_0 = 1159.8
    str_0 = "h&|>W8@$D~m]0"
    inventory_c_l_i_0 = InventoryCLI(float_0)
    argv = [1]
    argv[0] = str_0
    inventory_c_l_i_0.post_process_args(argv)


# Generated at 2022-06-24 18:01:21.975731
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    assert isinstance(inventory_c_l_i_0.inventory_graph(), str)


# Generated at 2022-06-24 18:01:25.251880
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # No test coverage


# Generated at 2022-06-24 18:01:30.184102
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():

    import toml

    float_a = 1159.8
    inventory_c_l_i_a = InventoryCLI(float_a)

    results = inventory_c_l_i_a.toml_inventory(float_a)
    print(toml.dumps(results))


# Generated at 2022-06-24 18:01:36.437917
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = float(randint(0, int(35.33)))

    inventory_c_l_i_0 = InventoryCLI(float_0)
    group_0 = None
    # Call method yaml_inventory of InventoryCLI instance inventory_c_l_i_0
    inventory_c_l_i_0_yaml_inventory_ret_0 = unittest_config_test_ansible_inventory_cli_0.InventoryCLI.yaml_inventory(inventory_c_l_i_0, group_0)
    # Call method _get_group_variables of InventoryCLI instance inventory_c_l_i_0
    inventory_c_l_i_0__get_group_variables_ret_0 = unittest_config_test_ansible_inventory_cli_0.InventoryCL

# Generated at 2022-06-24 18:02:23.048401
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
  inventory_c_l_i_1 = InventoryCLI('')
  # TODO: Test for or check call of method yaml_inventory of class InventoryCLI


# Generated at 2022-06-24 18:02:25.581091
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    float_0 = 1190.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top = None
    assert_equal(inventory_c_l_i_0.toml_inventory(top), None)


# Generated at 2022-06-24 18:02:34.454199
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)

    # Call method json_inventory for class InventoryCLI
    # with param [{'group_vars/all': {'ansible_ssh_host': '127.0.0.1', 'ansible_connection': 'local', 'ansible_ssh_port': '22', 'ansible_ssh_user': 'root', 'foo': [1, 2, 3]}, 'host_vars/foo': {'host_specific_var': 'bar'}}]
    # <class 'dict'>
    results = inventory_c_l_i_0.json_inventory(['group_vars/all', 'host_vars/foo'])
    print(results)


# Generated at 2022-06-24 18:02:37.318600
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    global c_l_i_0
    test_case_0()
    try:
        c_l_i_0.toml_inventory()
    except TypeError:
        pass
    else:
        display.error("TypeError not raised when calling toml_inventory with no arguments")


# Generated at 2022-06-24 18:02:39.703143
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    # see inventory/inventory_loader.py for the corresponding test case
    return


# Generated at 2022-06-24 18:02:42.920797
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 = 1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.inventory_graph()


# Generated at 2022-06-24 18:02:43.812117
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
  pass


# Generated at 2022-06-24 18:02:46.824549
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    float_0 =  1159.8
    inventory_c_l_i_0 = InventoryCLI(float_0)
    assert inventory_c_l_i_0.inventory_graph() == 0, 'Failed assertion inventory_graph'



# Generated at 2022-06-24 18:02:52.255870
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_0 = 1.0
    inventory_c_l_i_0 = InventoryCLI(float_0)
    output_file_0 = '/dev/null'
    options_0 = dict(
        verbosity=float_0,
        graph=float_0,
        host=float_0,
        list=float_0,
        pattern='/etc',
        show_vars=float_0,
        output_file=output_file_0,
        export=float_0,
        debug=float_0,
    )
    float_0 = 1.0
    inventory_c_l_i_0.inventory_c_l_i_0(float_0)
    options_0 = inventory_c_l_i_0.options

# Generated at 2022-06-24 18:02:58.700305
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # TODO: test more
    from io import StringIO
    from ansible.inventory.helpers import get_group_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    import json

    display.VERBOSITY = 3
