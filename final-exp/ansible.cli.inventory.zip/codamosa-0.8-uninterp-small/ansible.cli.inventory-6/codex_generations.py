

# Generated at 2022-06-24 17:54:51.161482
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 7.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    stuff_0 = {}
    # bool_0 = bool(stuff_0)
    # assert bool_0 == True, 'AssertionError: bool_0 == True'
    # stuff_0 = bool_0
    # output_0 = inventory_c_l_i_0.dump(stuff_0)
    # assert (output_0 == "")
    # assert (stuff_0 == {})

# Generated at 2022-06-24 17:54:59.865239
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # Test case where outfile is None and no hosts match pattern
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    context.CLIARGS['graph'] = True
    try:
        inventory_c_l_i_0.run()
    except AnsibleError:
        outstream = sys.stdout.getvalue()
        sys.stdout.seek(0)
        sys.stdout.truncate(0)
        assert(outstream == '')
    else:
        assert(False)

    # Test case where outfile is None and an invalid host is specified
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    context.CLIARGS['host'] = ['foo']

# Generated at 2022-06-24 17:55:08.915509
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    args = []
    options = {'show_vars': False, 'graph': False, 'list': False, 'host': False}
    inventory_c_l_i_0 = InventoryCLI(args, options)

    try:
        inventory_c_l_i_0.post_process_args(options)
        assert False
    except Exception as e:
        assert str(e) == 'No action selected, at least one of --host, --graph or --list needs to be specified.'


# Generated at 2022-06-24 17:55:16.036561
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():

    # Array initialization
    global debug_0
    debug_0 = ['f', 'y', 'x', 'A', 'p', 'M', 'q', 'c', 'o', 'a', 'i', 'J', 'X', 'n', 'Q', 'O', 'D', 'h']

    # Declaration
    global pager_0
    global display_0
    global playbook_filename_0
    global playbook_path_0
    if (True):
        inventory_c_l_i_0 = InventoryCLI(True)
        inventory_c_l_i_0.test_case_0()

    # If

# Generated at 2022-06-24 17:55:17.935259
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    test_case_0()

# Generated at 2022-06-24 17:55:20.776700
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    import ansible.parsing.toml as toml
    # test toml_inventory
    with open("test/test.toml.txt") as file:
        toml_str = file.read()
        d = toml.loads(toml_str)
        toml_str = d
        assert toml_str == toml_inventory(d)
# END test_InventoryCLI_toml_inventory


# Generated at 2022-06-24 17:55:26.974899
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():

    # Setup test case
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)

    # Setup parameters
    top = None

    # Run test case
    results = inventory_c_l_i_0.json_inventory(top)

    # Test assert statements
# TODO: Some assert statements not implemented yet
#    assert (results == expected), 'Invocation of method json_inventory of class InventoryCLI returns wrong results'



# Generated at 2022-06-24 17:55:29.426155
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # Test exception handling
    # N/A


# Generated at 2022-06-24 17:55:35.614421
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top = inventory_c_l_i_0._get_group('all')
    assert top.name == 'all'
    assert next(g.name for g in top.child_groups if g.name == 'all') is not None
    assert next((h.name for h in top.hosts if h.name == 'dark')) is not None


# Generated at 2022-06-24 17:55:38.460518
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():

    # run test case
    test_case_0()


# Generated at 2022-06-24 17:56:26.587426
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    print('Testing json_inventory of class InventoryCLI')
    # Create an object of class InventoryCLI
    inventory_c_l_i_0 = InventoryCLI('/home/bri/.ansible/tmp/ansible-local-150091258.65-132707813727286/tmpq2qzpyyv')
    # Test the function
    inventory_c_l_i_0.json_inventory()


# Generated at 2022-06-24 17:56:39.966673
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # unit test for method inventory_graph
    # of class InventoryCLI

    group_0 = dict()
    group_0['foo'] = dict()
    group_0['foo']['children'] = []
    group_0['foo']['hosts'] = []
    group_0['foo']['vars'] = dict()

    group_1 = dict()
    group_1['foo'] = dict()
    group_1['foo']['children'] = []
    group_1['foo']['hosts'] = []
    group_1['foo']['vars'] = dict()

    group_2 = dict()
    group_2['foo'] = dict()
    group_2['foo']['children'] = []
    group_2['foo']['hosts'] = []

# Generated at 2022-06-24 17:56:45.929575
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top = inventory_c_l_i_0._get_group('all')
    inventory_c_l_i_0.json_inventory(top)


# Generated at 2022-06-24 17:56:58.594887
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = 1275;
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # verify there is one argument in argv
    assert argv.__len__() == 1, "Argument list is empty"
    assert argv[0].__eq__("test3.py"), "First argument is incorrect"
    # test case 1
    argv.append("test3.py")
    test_case_0()
    # test case 2
    argv.append("test3.py")
    test_case_0()
    # test case 3
    argv.append("test3.py")
    test_case_0()
    # test case 4
    argv.append("test3.py")
    test_case_0()


test_InventoryCLI_run()

# Generated at 2022-06-24 17:57:01.440369
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # Set up parameters for method
    self = InventoryCLI()
    top = self._get_group('all')
    if True:
        raise Exception ('For testing purposes only')
    # Call method
    InventoryCLI.inventory_graph(top)


# Generated at 2022-06-24 17:57:09.549885
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    test_case_0()
    test_case_2()
    test_case_5()
    test_case_7()

    assert inventory_c_l_i_0.dump() == to_text('\n')


# Generated at 2022-06-24 17:57:14.825073
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    top_0 = inventory_c_l_i_0.inventory.groups[0]
    inventory_c_l_i_0.yaml_inventory(top_0)

if __name__ == "__main__":
    test_InventoryCLI_yaml_inventory()

# Generated at 2022-06-24 17:57:19.736582
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_c_l_i_0 = InventoryCLI()
    try:
        inventory_c_l_i_0.run()
    except SystemExit as e:
        if e.code == 0:
            pass
        else:
            assert False
    else:
        assert False


# Generated at 2022-06-24 17:57:27.430504
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    inventory_c_l_i_0 = InventoryCLI(749.9)
    inventory_c_l_i_0.inventory = '0123456789[]_'
    top, inventory_c_l_i_0.inventory = '0123456789[]_', inventory_c_l_i_0.inventory
    inventory_c_l_i_0.yaml_inventory(top)


# Generated at 2022-06-24 17:57:31.137948
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # Should raise exception, since there is some problem with the arguments
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        inventory_c_l_i_0.post_process_args(float_0)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 1


# Generated at 2022-06-24 17:58:02.419829
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_c_l_i_0 = InventoryCLI()
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:58:14.488787
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    #options.pattern='all'
    context.CLIARGS['list']=True
    context.CLIARGS['yaml']=True
    context.CLIARGS['basedir']='/tmp/playbooks'
    context.CLIARGS['verbosity']=1
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.post_process_args=MagicMock(name='post_process_args')
    inventory_c_l_i_0.post_process_args.return_value=None
    inventory_c_l_i_0.run()

if __name__ == '__main__':
    test_case_0()
    test_InventoryCLI_run()

# Generated at 2022-06-24 17:58:16.312734
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    result = InventoryCLI.toml_inventory()
    assert not result


# Generated at 2022-06-24 17:58:22.592635
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():

#    top = self._get_group('all')
    yaml_inventory_0 = 999999999999999999
#    assert self.yaml_inventory(top) == yaml_inventory_0
#    print(self.yaml_inventory(top))

#    results = self.dump(results)


# Generated at 2022-06-24 17:58:27.688353
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    """
    toml_inventory test stub with parameters:
    top -- TODO
    """
    float_0 = 1275.12
    if not PY2:
        inventory_c_l_i_0 = InventoryCLI(float_0)

if __name__ == '__main__':

    test_case_0()
    test_InventoryCLI_toml_inventory()

# Generated at 2022-06-24 17:58:31.425863
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # TODO: unknown type
    assert "{'test': {'hello': 'world', 'test_float': 1275.12}}" == inventory_c_l_i_0.dump()


# Generated at 2022-06-24 17:58:37.419588
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_0 = 1275.12
    options = Mock(verbosity=2, debug=3)
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # Call method
    options = inventory_c_l_i_0.post_process_args(options)
    assert options.verbosity == 2


# Generated at 2022-06-24 17:58:40.741638
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    test_case_0()

if __name__ == '__main__':
    ansible_test_utils.run_test(InventoryCLI, test_InventoryCLI_toml_inventory)

# Generated at 2022-06-24 17:58:49.542137
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    inventory_c_l_i = InventoryCLI(1)
    top = inventory_c_l_i._get_group('all')
    # results = inventory_c_l_i.json_inventory(top)
    # assert isinstance(results, dict)
    # assert '_meta'
    # assert 'hostvars'
    # assert 'all'
    # assert 'children'
    # assert 'hosts'
    # assert 'vars'


# Generated at 2022-06-24 17:58:57.979257
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    dict_0 = dict()
    dict_0["__ansible_vault"] = False
    dict_0['hello'] = 'world'
    dict_0['number'] = -3
    dict_0['number2'] = 3
    dict_0['number3'] = -4
    dict_0['bool'] = False
    dict_0['bool2'] = True
    dict_0['list'] = ['a', 2, 'c']
    dict_0['dict'] = {'hello': 'world', 'number': -3, 'number2': 3, 'number3': -4, 'bool': False, 'bool2': True, 'list': ['a', 2, 'c']}
    dict_0

# Generated at 2022-06-24 17:59:42.556448
# Unit test for method run of class InventoryCLI

# Generated at 2022-06-24 17:59:48.892819
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    print('Test function toml_inventory of class InventoryCLI')
    inventoryCLI = InventoryCLI(args=['ansible-inventory','--list'])
    int_0 = 999999999999999999
    top = inventoryCLI._get_group('all')
    result = inventoryCLI.toml_inventory(top)
    assert result is not None, "The result should not be None"

# Generated at 2022-06-24 17:59:52.536754
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    json_inventory_0 = InventoryCLI()
    json_inventory_1 = {  }
    _top_0 = json_inventory_0.json_inventory(json_inventory_1)


# Generated at 2022-06-24 17:59:56.827352
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    top = None
    obj = InventoryCLI()
    actual = obj.yaml_inventory(top)


# Generated at 2022-06-24 17:59:59.470744
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    # Source: JSON file
    # Argument: n/a
    # Expected result: n/a
    # Actual result: n/a
    pass


# Generated at 2022-06-24 18:00:02.714894
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    int_0 = 999999999999999999


# Generated at 2022-06-24 18:00:06.696826
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # create an instance of class InventoryCLI
    # run method of class InventoryCLI
    InventoryCLI.run(InventoryCLI)
    # verify results
    assert int_0 == 999999999999999999

# Generated at 2022-06-24 18:00:13.328565
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible import constants as C
    my_loader = DataLoader()
    my_options = Options(listtags=False, listtasks=False, listhosts=False, syntax=False, connection='ssh',
                         module_path=None, forks=100, remote_user='user', private_key_file=None,
                         ssh_common_args=None, ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None,
                         become=False, become_method='sudo', become_user='root', verbosity=0, check=False, start_at_task=None)
    myplaybook = Playbook.load('/etc/ansible/playbooks/test.yaml', loader=my_loader, variable_manager=None)

# Generated at 2022-06-24 18:00:15.096917
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_cli = InventoryCLI()
    inventory_cli.run()


# Generated at 2022-06-24 18:00:21.936464
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
  top = Group('all')
  seen = set()
  has_ungrouped = False
  results = {}
  group = Group('all')
  results['all'] = {}
  results['all']['children'] = []
  subgroup = Group(('all', 'fuzzy'))
  if subgroup.name == 'ungrouped' and not has_ungrouped:
    pass
  if group.name != 'all':
    results['all']['children'].append('fuzzy')
  results.update(format_group(subgroup))
  if has_ungrouped:
    pass
  subgroup = Group(('all', 'ungrouped'))
  if subgroup.name == 'ungrouped' and not has_ungrouped:
    pass

# Generated at 2022-06-24 18:01:15.802613
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    # TODO: improve this test case method
    float_0 = 1223.58
    inventory_c_l_i_0 = InventoryCLI(float_0)
    group_0 = GroupData(str_0='hostname')
    group_0.vars = dict_0 = {'password': 'lorem ipsum'}
    # Switch that defines on which platform the test is running.
    # Assumes the env variable 'TESTENV' is set on the main machine.
    # Note: This code isnt run on the main machine and if so, the exception fails.
    try:
        str_0 = os.environ['TESTENV']
    except KeyError:
        str_0 = 'default'
        print('KeyError exception in test_InventoryCLI_inventory_graph')

# Generated at 2022-06-24 18:01:22.045501
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    assert inventory_c_l_i_0 is not None
    assert type(float_0) is float
    with pytest.raises(TypeError):
        assert inventory_c_l_i_0.post_process_args(float_0) is None


# Generated at 2022-06-24 18:01:28.723974
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():

    # Setup
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)



    # Exercise

    string_0 = '0.3.0'
    boolean_0 = True
    inventory_c_l_i_0._display_version(string_0, boolean_0)


# Generated at 2022-06-24 18:01:31.786097
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = 1012.91
    inventory_c_l_i_0 = InventoryCLI(float_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 18:01:35.247238
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    top = {'foo': 'bar'}
    inventory_c_l_i_0 = InventoryCLI(0.6)
    assert inventory_c_l_i_0.yaml_inventory(top) == {'foo': 'bar'}


# Generated at 2022-06-24 18:01:40.151241
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_1 = 1212.11
    inventory_c_l_i_2 = InventoryCLI(float_1)
    dict_6 = dict()
    dict_6['a'] = 'b'
    dict_6['c'] = 'd'
    dict_6['e'] = 'f'
    inventory_c_l_i_2.dump(dict_6)

# Generated at 2022-06-24 18:01:46.523907
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    inventory_l_i_0 = InventoryCLI(1275.12)
    string_0 = '''
    [
      {
        "name": "test_group_1", 
        "hosts": [
          "test_host_1", 
          "test_host_2"
        ], 
        "children": []
      }, 
      {
        "name": "test_group_2", 
        "hosts": [
          "test_host_3", 
          "test_host_4"
        ], 
        "children": []
      }
    ]'''

# Generated at 2022-06-24 18:01:49.425923
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    # unit tests for method post_process_args
    # TODO: implement this method
    raise NotImplementedError()


# Generated at 2022-06-24 18:01:55.716672
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    # Test 0:
    #   Test with sample options
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    sample_output_file = "output.txt"
    sample_options = Options(args='all',
                             host=True,
                             toml=True,
                             show_vars=True,
                             export=True,
                             output_file=sample_output_file)
    if inventory_c_l_i_0.post_process_args(sample_options) != sample_options:
        raise Exception("Argument not handled properly")


# Generated at 2022-06-24 18:02:05.622200
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    dict_0 = {'value_0': 0, 'value_1': 1, 'value_2': 2}
    result = inventory_c_l_i_0.dump(dict_0)
    assert result == '{\n    "value_0": 0,\n    "value_1": 1,\n    "value_2": 2\n}\n', 'Return value of dump() method must be equal to \'{\n    "value_0": 0,\n    "value_1": 1,\n    "value_2": 2\n}\n\', got \'%s\' instead' % result


# Generated at 2022-06-24 18:03:32.511978
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)
    # Create a dictionary representing the values of the command line options
    # and arguments.
    # This would be the same dictionary returned by parser.parse_args().
    options = {'list': False, 'verbosity': False, 'path': ['/usr/local/ansible'], 'host': False, 'output_file': False, 'pattern': '*', 'export': False, 'graph': False, 'yaml': True, 'toml': False}
    # Call method to test.
    result = inventory_c_l_i_0.post_process_args(options)
    # Test successful.
    assert result == options


# Generated at 2022-06-24 18:03:39.509650
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    inventory_c_l_i_0 = InventoryCLI()
    str_0 = 'yaml'
    context.CLIARGS_0 = {str_0: str_0}
    context.CLIARGS_1 = context.CLIARGS_0
    context.CLIARGS_2 = context.CLIARGS_1

    # exception
    str_0 = 'host'
    context.CLIARGS_0 = {str_0: str_0}
    context.CLIARGS_1 = context.CLIARGS_0
    context.CLIARGS_2 = context.CLIARGS_1
    with pytest.raises(AnsibleOptionsError):
        inventory_c_l_i_0.run()
    float_0 = float('nan')

# Generated at 2022-06-24 18:03:42.565020
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    results = {'all': {'children': ['test_group']}, 'test_group': {'hosts': ['test_host1', 'test_host2']}}
    assert results == InventoryCLI._get_group_variables(group)

# Generated at 2022-06-24 18:03:49.814383
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    from ansible import context
    from ansible.cli import CLI
    from ansible.errors import AnsibleError
    from ansible.inventory import Inventory, Host, Group
    from ansible.mock import patch
    from ansible.parsing.dataloader import DataLoader
    import sys

    class Args(object):
        def __init__(self):
            self.list = True
            self.yaml = True
            self.verbosity = 4


    def create_inventory():
        cli = CLI(Args())
        loader = DataLoader()
        inventory = Inventory(loader=loader, variable_manager=cli.variable_manager)

        web = Host('web1')
        web.set_variable('ansible_connection', 'local')
        group1 = Group('group1')

# Generated at 2022-06-24 18:03:53.376604
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    float_0 = 1275.12
    inventory_c_l_i = InventoryCLI(float_0)

    try:
        inventory_c_l_i.run()
    except:
        if (not (isinstance(float_0, float))):
            raise TypeError('method expected a float as the second argument')

# Call module function test_InventoryCLI_run to invoke its test case
test_InventoryCLI_run()

if __name__ == '__main__':
    InventoryCLI()

# Generated at 2022-06-24 18:03:57.861940
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_1 = 5201.95757
    inventory_c_l_i_0 = InventoryCLI(float_1)
    int_0 = 4398
    inventory_c_l_i_0.dump(int_0)


# Generated at 2022-06-24 18:04:01.680594
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 1275.12
    inventory_c_l_i_1 = InventoryCLI(float_0)
    float_1 = 1275.12
    inventory_c_l_i_1.dump(float_1)


# Generated at 2022-06-24 18:04:05.748565
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    float_0 = 1275.12
    inventory_c_l_i_0 = InventoryCLI(float_0)


# Generated at 2022-06-24 18:04:12.129083
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    context.CLIARGS = context.CLIARGS.copy()
    context.CLIARGS['list'] = True
    context.CLIARGS['pattern'] = ""
    
    # Test setup and teardown
    inventory_c_l_i_0 = InventoryCLI()
    import tempfile
    tempfile_0 = tempfile.NamedTemporaryFile()
    context.CLIARGS['output_file'] = tempfile_0
    tempfile_0.close()
    try:
        inventory_c_l_i_0.run()
    except Exception as e:
        assert True
    else:
        assert False

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])