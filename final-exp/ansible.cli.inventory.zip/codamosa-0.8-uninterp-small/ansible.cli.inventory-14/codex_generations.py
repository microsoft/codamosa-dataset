

# Generated at 2022-06-24 17:54:44.910166
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_5 = '--version'
    inventory_c_l_i_5 = InventoryCLI(str_5)
    # inventory_c_l_i_5.run()


if __name__ == "__main__":
    test_case_0()
    test_InventoryCLI_run()

# Generated at 2022-06-24 17:54:55.182434
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    from ansible.cli import CLI
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.options import Options
    from ansible.plugins.loader import get_all_plugin_loaders


# Generated at 2022-06-24 17:55:06.865063
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    top_str_arg_0 = "<module 'ansible.inventory.manager' from '/root/ansible/lib/ansible/inventory/manager.pyc'>"
    depth_int_arg_0 = 2
    test_0 = inventory_c_l_i_0.inventory_graph(top_str_arg_0, depth_int_arg_0)

# Generated at 2022-06-24 17:55:12.732314
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = '$M'
    options_0 = Options()
    options_0.list = True
    inventory_c_l_i_0 = InventoryCLI(str_0)
    res = inventory_c_l_i_0.post_process_args(options_0)
    assert res is not None
    #
    # If the following assertion fails, the next assertion will error
    #
    assert 'list' in vars(options_0)
    assert options_0.list == False


# Generated at 2022-06-24 17:55:17.509688
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.yaml_inventory(None)


# Generated at 2022-06-24 17:55:28.588116
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    print("Test post_process_args method of class InventoryCLI")

    str_1 = '$M'
    inventory_c_l_i_1 = InventoryCLI(str_1)
    arg_1 = "all"
    arg_2 = '-i M'
    arg_3 = ''
    arg_4 = '-l'
    arg_5 = '-g'
    arg_6 = '-y'
    arg_7 = '-v'
    arg_8 = '--toml'
    arg_9 = '--vars'
    arg_10 = '--export'
    arg_11 = "--output"
    arg_12 = "test"
    arg_13 = ['--list', '--yaml', '-v', 'all', '-i', 'M']

# Generated at 2022-06-24 17:55:31.359217
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.yaml_inventory()



# Generated at 2022-06-24 17:55:39.300216
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_0 = '$MA'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    dict_0['joe'] = 'my name is joe'
    dict_0['uid'] = 3
    str_1 = inventory_c_l_i_0.dump(dict_0)
    assert str_1 == '{ "foo": "bar", "joe": "my name is joe", "uid": 3 }', 'str_1 == "{ \"foo\": \"bar\", \"joe\": \"my name is joe\", \"uid\": 3 }"'
    str_2 = '$MA'
    inventory_c_l_i_1 = InventoryCLI(str_2)
    dict_1 = dict()
   

# Generated at 2022-06-24 17:55:40.253802
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    test_case_0()


# Generated at 2022-06-24 17:55:45.273425
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    # TODO
    # error could not convert string to float: -

# Generated at 2022-06-24 17:56:10.279372
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    dict_0 = {}
    dict_0['host'] = 0
    dict_0['graph'] = 1
    dict_0['pattern'] = 'all'
    dict_0['verbosity'] = 4
    dict_0['list'] = 1
    dict_0['yaml'] = 1
    dict_0['output_file'] = None
    dict_0['check'] = 1
    dict_0['toml'] = 1
    dict_0['export'] = 0
    dict_0['args'] = None
    dict_0['connection'] = ''
    dict_0['forks'] = 5
    dict_0['module_path'] = None
    dict_0['acquire_cache_timeout']

# Generated at 2022-06-24 17:56:17.372895
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    print("BEGIN test_InventoryCLI_json_inventory")
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = '/tmp/test_file_0'
    context.CLIARGS['pattern'] = str_1
    dict_0 = {}
    dict_1 = {}
    dict_0[str_1] = dict_1
    dict_0['_meta'] = dict_0['_meta']
    dict_1['hostvars'] = dict_0[str_1]
    dict_1['vars'] = dict_0['_meta']
    dict_1['children'] = dict_0['_meta']
    dict_2 = {}
    dict_1['hosts'] = dict_2

# Generated at 2022-06-24 17:56:23.748427
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    #e.g. options = {'verbose': True, 'connection': 'smart', 'module_path': ['/path/to/mymodules'], 'forks': 50, 'remote_user': 'vlaxcom', 'private_key_file': '~/.ssh/id_rsa', 'ssh_common_args': '', 'ssh_extra_args': '', 'sftp_extra_args': '', 'scp_extra_args': '', 'become': True, 'become_method': 'sudo', 'become_user': 'root', 'verbosity': 0, 'check': False}
    #e.g. args = ['all', '-m', 'ping']

# Generated at 2022-06-24 17:56:27.719494
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)

    # Asserts if the method raises any exception
    try:
        inventory_c_l_i_0.run()
    except Exception:
        raise AssertionError('Exception raised')

# Generated at 2022-06-24 17:56:34.596440
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    print("Test: InventoryCLI.dump")

    import json
    import yaml
    load_test_json_file = open("test_json_file.json", 'r')
    load_test_yaml_file = open("test_yaml_file.yaml", 'r')
    test_json_dict = json.loads(load_test_json_file.read())
    test_yaml_dict = yaml.load(load_test_yaml_file.read())
    yaml.Dumper.ignore_aliases = lambda *args: True

    # Case: Test for the yaml dump
    print("|--- Case 0: Test for the yaml dump")
    inventory_c_l_i_0 = InventoryCLI('$M')

# Generated at 2022-06-24 17:56:38.816507
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    global str_0
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.run()

# Generated at 2022-06-24 17:56:49.717714
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    from json import dumps as json_dumps
    from ansible.parsing.ajson import AnsibleJSONEncoder
    import yaml
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import toml
    from ansible.parsing.yaml.objects import AnsibleMapping
    input_0 = {'a': 1, 'b': 2}
    output_0 = json_dumps(input_0,
        sort_keys=True,
        indent=4,
        preprocess_unsafe=True,
        ensure_ascii=False,
        cls=AnsibleJSONEncoder,
        )

# Generated at 2022-06-24 17:56:51.920835
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_0 = '*^5'
    assert(InventoryCLI.dump(str_0) == '*^5')


# Generated at 2022-06-24 17:57:01.085551
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_0 = None
    int_0 = 0
    str_1 = "Xzvjm'T\x6d)QnZ(Bq\x63\x39\x7a\x35lH"
    str_2 = 'dg"S\x63\x5f\x5e\x5a"\x4b\x35\x5a\x4f\x59\x6a\x42\x31\x2b'
    dict_1 = dict()
    dict_1['hosts'] = [str_1, str_2]
    dict_1['vars'] = dict()
    dict_1['children'] = list()
    dict_0

# Generated at 2022-06-24 17:57:12.477766
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    """
    A test for the dump method.
    """
    str_0 = "a\\b\tc"
    dict_0 = {str_0: str_0}
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_1 = inventory_c_l_i_0.dump(dict_0)
    assert str_1 == '{\n    "a\\\\b\\tc": "a\\\\b\\tc"\n}'

if __name__ == '__main__':
    test_case_0()
    test_InventoryCLI_dump()

# Generated at 2022-06-24 17:57:37.036254
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    str_0 = '&'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    # Test with argument enabled
    try:
        InventoryCLI._graph_name()
    except Exception as e:
        print(e)
    else:
        print('Success: test_InventoryCLI_inventory_graph')


# Generated at 2022-06-24 17:57:40.400753
# Unit test for method yaml_inventory of class InventoryCLI
def test_InventoryCLI_yaml_inventory():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    top_0 = inventory_c_l_i_0.inventory.groups["all"]
    inventory_c_l_i_0.yaml_inventory(top_0)


# Generated at 2022-06-24 17:57:51.173017
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_1 = '$M'
    options_1 = {}
    options_1['args'] = []
    options_1['list'] = '--'
    options_1['pattern'] = 'all'
    options_1['subset'] = 'all'
    options_1['debug'] = ''
    options_1['verbose'] = '-'
    options_1['version'] = ''
    options_1['inventory'] = ''
    options_1['yaml'] = ''
    options_1['toml'] = ''
    options_1['graph'] = ''
    options_1['host'] = ''
    options_1['output'] = None
    options_1['export'] = ''
    options_1['syntax'] = ''
    options_1['syntax_check'] = ''

# Generated at 2022-06-24 17:57:54.873714
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    str_0 = '$M'
    stuff_0 = 'X'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    assert_equal(inventory_c_l_i_0.dump(stuff_0), 'X')


# Generated at 2022-06-24 17:57:59.178911
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    from ansible.parsing.ajson import AnsibleJSONEncoder
    my_dict = {'A': 'B'}
    ansible_json_encoder = AnsibleJSONEncoder()
    assert InventoryCLI.dump(ansible_json_encoder.encode(my_dict)) == '{"A": "B"}'

# Generated at 2022-06-24 17:58:04.377202
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    inventory_c_l_i_0 = InventoryCLI("hosts")
    top = inventory_c_l_i_0._get_group("all")
    inventory_c_l_i_0.toml_inventory(top) # expected no exception

# Generated at 2022-06-24 17:58:14.146090
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    argv = ['--list']
    parser = CLI.base_parser(
        constants.DEFAULT_MODULE_PATH,
        constants.DEFAULT_EXECUTABLE,
        constants.DEFAULT_MODULE_NAME,
        'connection',
        'become',
        'module_path',
        'forks',
        'remote_user',
        'private_key_file',
        'ssh_common_args',
        'ssh_extra_args',
        'sftp_extra_args',
        'scp_extra_args',
        'become_method',
        'become_user',
        'verbosity',
        'check',
        'timeout',
        'diff',
    )
    parser = InventoryCLI.add_args(parser)
    (options, args) = parser.parse_

# Generated at 2022-06-24 17:58:15.457198
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    test_case_0()


# Generated at 2022-06-24 17:58:18.220876
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)


# Generated at 2022-06-24 17:58:20.919864
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    options = {}
    inventory_c_l_i_0.post_process_args(options)


# Generated at 2022-06-24 17:59:03.374897
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    inventory_c_l_i_0 = InventoryCLI(None)
    import ansible.module_utils
    class test_module:
        def __init__(self):
            self.params = None
            self.result = None
    class test_api:
        def __init__(self):
            self.module = test_module()
    c_l_i_args = ansible.module_utils.basic._ANSIBLE_ARGS
    c_l_i_args = c_l_i_args.split()
    c_l_i_args.append('--list')
    c_l_i_args.append('--toml')
    context.CLIARGS = context.CLIARGS._replace(list=True, toml=True)

# Generated at 2022-06-24 17:59:07.154104
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    str_0 = '$X'
    inventory_c_l_i_1 = InventoryCLI(str_0)
    InventoryCLI.post_process_args(inventory_c_l_i_1)
    InventoryCLI.run(inventory_c_l_i_1)


# Generated at 2022-06-24 17:59:10.969410
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.run()


# Generated at 2022-06-24 17:59:21.522610
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    try:
        inventory_c_l_i_0.run()
    except Exception as e:
        assert isinstance(e, AnsibleOptionsError) == True
    str_1 = '$S'
    inventory_c_l_i_1 = InventoryCLI(str_1)
    try:
        inventory_c_l_i_1.run()
    except Exception as e:
        assert isinstance(e, AnsibleOptionsError) == True
    str_2 = '$K'
    inventory_c_l_i_2 = InventoryCLI(str_2)
    try:
        inventory_c_l_i_2.run()
    except Exception as e:
        assert isinstance

# Generated at 2022-06-24 17:59:25.930522
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    str_0 = 'a'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_0 = ''
    inventory_c_l_i_0.inventory_graph(str_0)


# Generated at 2022-06-24 17:59:34.817066
# Unit test for method post_process_args of class InventoryCLI
def test_InventoryCLI_post_process_args():
    '''
    Unit test for function post_process_args of class InventoryCLI
    '''
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    str_0 = '$M'
    dict_0 = {'list' : True, 'host' : True, 'export' : True}
    dict_1 = inventory_c_l_i_0.post_process_args(dict_0)
    str_1 = '------'
    str_2 = '$M'
    dict_0 = {'list' : True, 'host' : True, 'export' : True}
    dict_2 = inventory_c_l_i_0.post_process_args(dict_0)
    str_3 = '------'

# Generated at 2022-06-24 17:59:40.204955
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    str_d = '$M'
    inventory_c_l_i_d = InventoryCLI(str_d)
    str_e = '$M'
    group_e = inventory_c_l_i_d._get_group(str_e)
    inventory_c_l_i_d.inventory_graph()


# Generated at 2022-06-24 17:59:42.652722
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    myvars = {}
    results = test_case_0.dump(myvars)

# Generated at 2022-06-24 17:59:54.707611
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    inventory_c_l_i_0 = InventoryCLI('$M')
    str_0 = '--list'
    context.CLIARGS['list'] = str_0
    str_1 = 'all'
    context.CLIARGS['pattern'] = str_1
    context.CLIARGS['graph'] = 1
    str_2 = '$M'
    context.CLIARGS['yaml'] = str_2
    context.CLIARGS['json'] = '$M'
    context.CLIARGS['toml'] = '$M'
    str_3 = '$M'
    context.CLIARGS['host'] = str_3
    str_4 = '$M'
    context.CLIARGS['output_file'] = str_4
    context.CONFIG = Configuration

# Generated at 2022-06-24 17:59:58.774894
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    # Call function inventory_graph of class InventoryCLI
    inventory_c_l_i_0.inventory_graph()


# Generated at 2022-06-24 18:02:00.768201
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    """
    Test the functionality of inventory_c_l_i_0.run
    """
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 18:02:03.564142
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    print("tests.units.inventory_c_l_i.inventory_c_l_i.InventoryCLI.inventory_graph")

    str_0 = '0'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    inventory_c_l_i_0.inventory_graph()


# Generated at 2022-06-24 18:02:09.719792
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    inventory_c_l_i_0 = InventoryCLI('$M')
    str_0 = '`E#N'
    assert str_0 == inventory_c_l_i_0.json_inventory(str_0)


if __name__ == '__main__':
    # Run test for method json_inventory of class InventoryCLI
    test_InventoryCLI_json_inventory()

# Generated at 2022-06-24 18:02:13.789530
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = '$M'
    InventoryCLI(str_0)


if __name__ == '__main__':
    # test_case_0()
    # test_InventoryCLI_run()
    #  print('here.....')
    pass

# Generated at 2022-06-24 18:02:21.349773
# Unit test for method dump of class InventoryCLI
def test_InventoryCLI_dump():
    string_0_str = '$M'
    inventory_cli_0 = InventoryCLI(string_0_str)
    json_0_dict = {'meh0': 'foo', 'meh1': 'bar'}
    json_0_dump = inventory_cli_0.dump(json_0_dict)
    assert type(json_0_dump) == str
    assert isinstance(json_0_dump, basestring)
    pytest_log = pytest.logger.get_log()
    pass


# Generated at 2022-06-24 18:02:32.930916
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)
    #
    #
    # Unit test for method dump of class InventoryCLI
    def test_InventoryCLI_dump():
        str_0 = '$M'
        inventory_c_l_i_0 = InventoryCLI(str_0)

        #
        #
        # Unit test for method _get_host_variables of class InventoryCLI
        def test_InventoryCLI_get_host_variables():
            str_0 = '$M'
            inventory_c_l_i_0 = InventoryCLI(str_0)

            #
            #
            # Unit test for method _get_group_variables of class InventoryCLI

# Generated at 2022-06-24 18:02:34.808209
# Unit test for method run of class InventoryCLI
def test_InventoryCLI_run():
    # Initialize needed objects
    str_0 = '$M'
    inventory_c_l_i_0 = InventoryCLI(str_0)

if __name__ == '__main__':
    test_case_0()
    test_InventoryCLI_run()

# Generated at 2022-06-24 18:02:45.216482
# Unit test for method toml_inventory of class InventoryCLI
def test_InventoryCLI_toml_inventory():
    from ansible.plugins.inventory.toml import HAS_TOML, TOML_AVAILABLE

    class FakeLoader(object):
        '''
        fake class only used for this unittest
        '''
        path_cache = {}

    class FakeInventory(object):
        '''
        fake class only used for this unittest
        '''
        def __init__(self):
            self._sources = {}
            self.groups = {}
            self.hosts = {}

        def get_hosts(self):
            return self.hosts

    class FakeGroup(object):
        '''
        fake class only used for this unittest
        '''
        def __init__(self, name, priority=1, child_groups={}):
            self.name = name
            self.priority = priority


# Generated at 2022-06-24 18:02:48.225738
# Unit test for method inventory_graph of class InventoryCLI
def test_InventoryCLI_inventory_graph():
    inventory_c_l_i_0 = InventoryCLI()
    str_0 = '$M'
    x_0 = InventoryCLI.inventory_graph(inventory_c_l_i_0, str_0)
    assert x_0 == None


# Generated at 2022-06-24 18:02:53.627304
# Unit test for method json_inventory of class InventoryCLI
def test_InventoryCLI_json_inventory():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader_0 = DataLoader()
    class_0 = InventoryManager(loader_0, None, None)
    var_mgr_0 = VariableManager()
    class_0.set_variable_manager(var_mgr_0)
    inventory_c_l_i_0 = InventoryCLI('abc')
    inventory_c_l_i_0.inventory = class_0
    inventory_c_l_i_0.vm = var_mgr_0
    str_0 = 'all'
    top_0 = inventory_c_l_i_0._get_group(str_0)
    json_inventory_0 = inventory_c_l