

# Generated at 2022-06-17 04:24:55.898947
# Unit test for function main

# Generated at 2022-06-17 04:24:59.735117
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:25:01.231003
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()



# Generated at 2022-06-17 04:25:04.929957
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    module = DnfModule()
    module.base = dnf.Base()
    module.base.read_all_repos()
    module.base.fill_sack()
    module.list_items('updates')


# Generated at 2022-06-17 04:25:12.553386
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    # Setup
    dnf_module = DnfModule()
    dnf_module.base = dnf.Base()
    dnf_module.base.read_all_repos()
    dnf_module.base.fill_sack()
    dnf_module.module = AnsibleModule(argument_spec={})
    dnf_module.module.params = {
        'list': 'installed',
    }

    # Test
    dnf_module.list_items(dnf_module.module.params['list'])

    # Verify
    assert dnf_module.module.exit_json.call_count == 1

# Generated at 2022-06-17 04:25:20.821139
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    # Setup
    dnf_module = DnfModule()
    dnf_module.base = Mock()
    dnf_module.module = Mock()
    dnf_module.module.check_mode = False

# Generated at 2022-06-17 04:25:31.476399
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = DnfModule(
        base=None,
        conf_file=None,
        disable_gpg_check=None,
        disablerepo=None,
        enablerepo=None,
        installroot=None,
        list=None,
        names=None,
        state=None,
        update_cache=None,
        update_only=None,
        download_only=None,
        download_dir=None,
        autoremove=None,
        allowerasing=None,
        with_modules=None,
    )
    assert module.base is None
    assert module.conf_file is None
    assert module.disable_gpg_check is None
    assert module.disablerepo is None
    assert module.enablerepo is None
    assert module.installroot is None
    assert module.list

# Generated at 2022-06-17 04:25:42.405440
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    # Setup
    dnf_module = DnfModule()
    dnf_module.module = MagicMock()
    dnf_module.module.check_mode = False

# Generated at 2022-06-17 04:25:46.772535
# Unit test for method list_items of class DnfModule

# Generated at 2022-06-17 04:25:49.183107
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:28:03.359657
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    # Setup
    dnf_module = DnfModule()
    dnf_module.base = MagicMock()
    dnf_module.base.sack = MagicMock()
    dnf_module.base.sack.query = MagicMock()
    dnf_module.base.sack.query.available = MagicMock()
    dnf_module.base.sack.query.installed = MagicMock()
    dnf_module.base.sack.query.available.run = MagicMock()
    dnf_module.base.sack.query.installed.run = MagicMock()
    dnf_module.base.sack.query.available.run.return_value = [MagicMock()]
    dnf_module.base.sack.query.installed

# Generated at 2022-06-17 04:28:11.354991
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = DnfModule(
        conf_file=None,
        disable_gpg_check=False,
        disablerepo=None,
        enablerepo=None,
        installroot=None,
        list=None,
        name=None,
        state=None,
        update_cache=False,
        update_only=False,
        autoremove=False,
        download_only=False,
        download_dir=None,
        with_modules=False,
        module=None
    )
    assert module.conf_file is None
    assert module.disable_gpg_check is False
    assert module.disablerepo is None
    assert module.enablerepo is None
    assert module.installroot is None
    assert module.list is None
    assert module.name is None

# Generated at 2022-06-17 04:28:22.198933
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = DnfModule(
        conf_file=None,
        disable_gpg_check=False,
        disablerepo=None,
        enablerepo=None,
        installroot=None,
        list=None,
        name=None,
        state=None,
        update_cache=False,
        update_only=False,
        autoremove=False,
        download_only=False,
        download_dir=None,
        with_modules=False,
    )
    assert module.conf_file is None
    assert module.disable_gpg_check is False
    assert module.disablerepo is None
    assert module.enablerepo is None
    assert module.installroot is None
    assert module.list is None
    assert module.name is None
    assert module.state is None
    assert module

# Generated at 2022-06-17 04:28:32.015130
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    # Test with no args
    module = DnfModule()
    module.ensure()
    # Test with args
    module = DnfModule(
        autoremove=True,
        conf_file='/etc/dnf/dnf.conf',
        disable_gpg_check=True,
        disablerepo=['*'],
        download_only=True,
        enablerepo=['*'],
        installroot='/',
        list='available',
        name=['python3'],
        state='installed',
        update_cache=True,
        update_only=True,
        with_modules=True,
    )
    module.ensure()


# Generated at 2022-06-17 04:28:42.494463
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    """Test for method run of class DnfModule"""
    # Test with no arguments
    dnf_module = DnfModule()
    dnf_module.run()
    # Test with arguments
    dnf_module = DnfModule(
        autoremove=True,
        conf_file='/etc/dnf/dnf.conf',
        disable_gpg_check=True,
        disablerepo=['repo1', 'repo2'],
        download_only=True,
        enablerepo=['repo3', 'repo4'],
        installroot='/root',
        list='available',
        name=['package1', 'package2'],
        state='installed',
        update_cache=True,
        update_only=True,
        with_modules=True
    )

# Generated at 2022-06-17 04:28:50.198907
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    # Create an instance of class DnfModule
    dnf_module = DnfModule()

    # Set the module arguments
    dnf_module.module.params = {
        'conf_file': 'conf_file',
        'disable_gpg_check': True,
        'disablerepo': 'disablerepo',
        'enablerepo': 'enablerepo',
        'installroot': 'installroot',
        'list': 'list',
        'names': 'names',
        'state': 'state',
        'update_cache': True,
        'update_only': True,
        'validate_certs': True,
    }

    # Set up the base class
    dnf_module.base = dnf.Base()

    # Run the method list_items of class DnfModule
   

# Generated at 2022-06-17 04:28:55.593305
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:29:02.499684
# Unit test for method run of class DnfModule

# Generated at 2022-06-17 04:29:11.818436
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = DnfModule(
        base=None,
        conf_file=None,
        disable_gpg_check=False,
        disablerepo=None,
        enablerepo=None,
        installroot=None,
        list=None,
        names=None,
        state=None,
        update_cache=False,
        update_only=False,
        download_only=False,
        autoremove=False,
        download_dir=None,
        with_modules=False,
        allowerasing=False,
    )
    assert module.base is None
    assert module.conf_file is None
    assert module.disable_gpg_check is False
    assert module.disablerepo is None
    assert module.enablerepo is None
    assert module.installroot is None
    assert module.list

# Generated at 2022-06-17 04:29:16.608334
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yumdnf import yumdnf_argument_spec
    module = AnsibleModule(
        **yumdnf_argument_spec
    )
    module_implementation = DnfModule(module)
    try:
        module_implementation.run()
    except dnf.exceptions.RepoError as de:
        module.fail_json(
            msg="Failed to synchronize repodata: {0}".format(to_native(de)),
            rc=1,
            results=[],
            changed=False
        )

if __name__ == '__main__':
    main()