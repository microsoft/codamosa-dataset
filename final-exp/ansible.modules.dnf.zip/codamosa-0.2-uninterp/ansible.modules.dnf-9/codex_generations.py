

# Generated at 2022-06-17 04:24:55.851097
# Unit test for constructor of class DnfModule
def test_DnfModule():
    """Unit test for constructor of class DnfModule."""
    module = DnfModule(
        conf_file=None,
        disable_gpg_check=False,
        disablerepo=None,
        enablerepo=None,
        installroot=None,
        list=None,
        name=None,
        state=None,
        update_cache=False,
        update_only=False,
        validate_certs=False,
        autoremove=False,
        download_only=False,
        download_dir=None,
        with_modules=False,
    )
    assert module.conf_file is None
    assert module.disable_gpg_check is False
    assert module.disablerepo is None
    assert module.enablerepo is None
    assert module.installroot is None
    assert module

# Generated at 2022-06-17 04:25:09.384054
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    # Initialize the class
    dnf_module = DnfModule()
    # Set the arguments
    dnf_module.autoremove = False
    dnf_module.base = None
    dnf_module.conf_file = None
    dnf_module.disable_gpg_check = False
    dnf_module.disablerepo = None
    dnf_module.download_dir = None
    dnf_module.download_only = False
    dnf_module.enablerepo = None
    dnf_module.ensure_latest = False
    dnf_module.filenames = None
    dnf_module.groups = None
    dnf_module.installroot = None
    dnf_module.list = None

# Generated at 2022-06-17 04:25:18.838976
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    # Initialize the class
    dnf_module = DnfModule()
    # Set the list to be used
    dnf_module.list = 'installed'
    # Call the method
    dnf_module.list_items(dnf_module.list)
    # Check the results

# Generated at 2022-06-17 04:25:23.938838
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    module = DnfModule()
    module.ensure()


# Generated at 2022-06-17 04:25:31.979087
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    """Test method run of class DnfModule"""
    # Setup
    dnf_module = DnfModule()
    dnf_module.module = Mock()
    dnf_module.module.check_mode = False
    dnf_module.module.params = {'name': ['foo', 'bar'], 'state': 'installed'}
    dnf_module.base = Mock()
    dnf_module.base.transaction = Mock()
    dnf_module.base.transaction.install_set = ['foo', 'bar']
    dnf_module.base.transaction.remove_set = []
    dnf_module.base.resolve = Mock(return_value=True)
    dnf_module.base.do_transaction = Mock(return_value=1)


# Generated at 2022-06-17 04:25:35.780626
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    # Test with no arguments
    module = DnfModule()
    module.list_items(None)
    # Test with valid arguments
    module = DnfModule()
    module.list_items('updates')
    # Test with invalid arguments
    module = DnfModule()
    module.list_items('invalid')

# Generated at 2022-06-17 04:25:44.349784
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yumdnf import yumdnf_argument_spec
    from ansible.module_utils.yumdnf import DnfModule
    from ansible.module_utils.yumdnf import dnf
    from ansible.module_utils.yumdnf import to_native
    from ansible.module_utils.yumdnf import to_text
    from ansible.module_utils.yumdnf import LooseVersion
    from ansible.module_utils.yumdnf import dnf_version_less_than
    from ansible.module_utils.yumdnf import dnf_version_greater_than
    from ansible.module_utils.yumdnf import dnf_version_equal

# Generated at 2022-06-17 04:25:52.988385
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = DnfModule(
        base=None,
        conf_file=None,
        disable_gpg_check=False,
        disablerepo=None,
        enablerepo=None,
        installroot=None,
        list=None,
        names=None,
        state=None,
        update_cache=False,
        update_only=False,
        autoremove=False,
        download_only=False,
        download_dir=None,
        allowerasing=False,
        with_modules=False,
    )
    assert module is not None


# Generated at 2022-06-17 04:25:55.764407
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    # Test with a module that has no arguments
    module = DnfModule()
    module.run()


# Generated at 2022-06-17 04:26:05.305292
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.yumdnf import yumdnf_argument_spec
    from ansible.module_utils.yumdnf import DnfModule
    import dnf
    import dnf.exceptions
    import dnf.module.module_base
    import dnf.subject
    import dnf.util
    import dnf.yum.misc
    import dnf.yum.rpmtrans
    import dnf.yum.rpmutils
    import dnf.yum.transactioninfo
    import dnf.yum.transaction
    import dnf.yum.history
    import dnf.yum.config
    import dnf.yum.configmanager
    import dnf

# Generated at 2022-06-17 04:28:16.510712
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    # Test with no arguments
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    dnf = DnfModule(module)
    dnf.run()
    assert dnf.base.conf.best == True
    assert dnf.base.conf.assumeyes == True
    assert dnf.base.conf.installroot == '/'
    assert dnf.base.conf.disable_gpg_check == False
    assert dnf.base.conf.assumeno == False
    assert dnf.base.conf.debuglevel == 2
    assert dnf.base.conf.errorlevel == 2
    assert dnf.base.conf.obsoletes == True
    assert dnf.base.conf.plugins == True

# Generated at 2022-06-17 04:28:17.429893
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:28:27.043344
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = DnfModule(
        conf_file=None,
        disable_gpg_check=False,
        disablerepo=[],
        enablerepo=[],
        installroot='/',
        list=None,
        names=[],
        state=None,
        update_cache=False,
        update_only=False,
        autoremove=False,
        download_only=False,
        download_dir=None,
        with_modules=False,
        allowerasing=False,
        conf_file_path='/etc/dnf/dnf.conf',
        module=None,
        base=None,
        module_base=None,
    )
    assert module.conf_file is None
    assert module.disable_gpg_check is False
    assert module.disablerepo == []

# Generated at 2022-06-17 04:28:30.914272
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    # Test with no args
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    dnf = DnfModule(module)
    dnf.ensure()


# Generated at 2022-06-17 04:28:41.385985
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = DnfModule()
    assert module.base is None
    assert module.module_base is None
    assert module.conf_file == '/etc/dnf/dnf.conf'
    assert module.disable_gpg_check is False
    assert module.disablerepo == []
    assert module.enablerepo == []
    assert module.installroot == '/'
    assert module.list is None
    assert module.names == []
    assert module.state == 'installed'
    assert module.update_cache is False
    assert module.update_only is False
    assert module.autoremove is False
    assert module.download_only is False
    assert module.download_dir is None
    assert module.with_modules is False
    assert module.allowerasing is False


# Generated at 2022-06-17 04:28:48.859631
# Unit test for constructor of class DnfModule
def test_DnfModule():
    """Unit test for constructor of class DnfModule."""
    module = DnfModule(
        conf_file=None,
        disable_gpg_check=False,
        disablerepo=[],
        enablerepo=[],
        installroot='/',
        list=None,
        names=[],
        state=None,
        update_cache=False,
        update_only=False,
        autoremove=False,
        download_only=False,
        download_dir=None,
        with_modules=False,
    )
    assert module.conf_file is None
    assert module.disable_gpg_check is False
    assert module.disablerepo == []
    assert module.enablerepo == []
    assert module.installroot == '/'
    assert module.list is None

# Generated at 2022-06-17 04:29:00.425694
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    dnf_module = DnfModule()
    dnf_module.base = dnf.Base()
    dnf_module.base.conf.substitutions['releasever'] = '22'
    dnf_module.base.read_all_repos()
    dnf_module.base.fill_sack()
    dnf_module.list_items('available')
    dnf_module.list_items('installed')
    dnf_module.list_items('updates')
    dnf_module.list_items('obsoletes')
    dnf_module.list_items('extras')
    dnf_module.list_items('recent')
    dnf_module.list_items('repos')

# Generated at 2022-06-17 04:29:02.082675
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-17 04:29:05.403970
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    # Test with no args
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    dnf = DnfModule(module)
    dnf.ensure()


# Generated at 2022-06-17 04:29:20.384591
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    # Setup
    dnf_module = DnfModule()
    dnf_module.base = dnf.Base()
    dnf_module.base.read_all_repos()
    dnf_module.base.fill_sack()
    dnf_module.base.repos.all().pkgdir = '/var/cache/dnf/packages'
    dnf_module.base.conf.destdir = '/var/cache/dnf/packages'
    dnf_module.base.conf.best = True
    dnf_module.base.conf.assumeyes = True
    dnf_module.base.conf.installonlypkgs = ['kernel']
    dnf_module.base.conf.installonly_limit = 3