

# Generated at 2022-06-11 07:01:47.080129
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    """Test list_items of DnfModule"""

    class MockException(Exception):
        pass

    class MockModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            AnsibleModule.__init__(self, *args, **kwargs)

        def fail_json(self, *args, **kwargs):
            raise MockException(args, kwargs)

        def exit_json(self, *args, **kwargs):
            raise MockException(args, kwargs)


# Generated at 2022-06-11 07:01:58.800929
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    dnfmodule = DnfModule(
        base = None,
        basecmd = None,
        download_only = None,
        download_dir = None,
        enablerepo = None,
        disablerepo = None,
        list = None,
        name = None,
        names = None,
        state = None,
        conf_file = None,
        disable_gpg_check = None,
        installroot = None,
        update_cache = None,
        update_only = None,
        autoremove = None,
        with_modules = None,
        module = None,
        module_base = None
    )
    dnfmodule.run()
    assert dnfmodule.base is not None
    assert dnfmodule.module_base is not None


# Generated at 2022-06-11 07:02:08.017138
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    module = DnfModule()

    mock_path = os.path.join(os.getcwd(), 'DNF_MODULE_TEST', 'mock_files', 'DnfModule_is_lockfile_pid_valid')
    module.module.params['lockfile'] = os.path.join(mock_path, 'dnf._lock.lck')

    with patch('os.path.exists') as mock_method:
        # dnf._lock.lck does not exist, return False
        mock_method.return_value = False
        result1 = module.is_lockfile_pid_valid()
        assert result1 == False

        # simulate one of the case where the lockfile is valid, return True
        mock_method.return_value = True

# Generated at 2022-06-11 07:02:09.199463
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
  r = DnfModule().list_items("available")
  assert r is None

# Generated at 2022-06-11 07:02:14.774434
# Unit test for function main
def test_main():
    test1 = dict(
        state=None,
        name=None,
        list=None,
        autoremove=None,
        clean_requirements_on_remove=False,
        conf_file=None,
        disable_excludes=None,
        disable_gpg_check=None,
        enablerepo=None,
        disablerepo=None,
        installroot=None,
        download_only=False,
        skip_broken=False,
        update_cache=False,
        update_only=False,
        valid_exit_codes=[0],
        noop_value=None,
        repository_policy=None,
        debug_level=None,
        path_conf_file=None)

# Generated at 2022-06-11 07:02:19.112800
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    with pytest.raises(AnsibleFailJson):
        # Setup test
        dnf_module = DnfModule(
            base=Mock(),
            check=False,
            conf_file=None,
            disable_gpg_check=None,
            disabling_excludes=None,
            disablerepo=None,
            enable_excludes=None,
            enablerepo=None,
            list='',
            names=[],
            state=None,
            update_cache=False,
            update_only=False,
            validate_certs=None,
            verbose=False,
            autoremove=False,
        )

# Generated at 2022-06-11 07:02:27.478901
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # Test with parameters
    module = DnfModule(
        conf_file='conf_file',
        disable_gpg_check=True,
        disablerepo=['repo1', 'repo2'],
        download_only=True,
        download_dir='download_dir',
        enablerepo=['repo1', 'repo2'],
        installroot='installroot',
        list='aur',
        names=['pkg1', 'pkg2'],
        state='absent',
        update_cache=True,
        update_only=True,
        with_modules=False
    )

    assert module.conf_file == 'conf_file'
    assert module.disable_gpg_check == True
    assert module.disablerepo == ['repo1', 'repo2']
    assert module.download

# Generated at 2022-06-11 07:02:31.544236
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    dnf_module = DnfModule()
    pid = os.getpid()
    assert dnf_module._is_lockfile_pid_valid(pid)
    assert not dnf_module._is_lockfile_pid_valid(0)

# Generated at 2022-06-11 07:02:42.154953
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():

    # Mocking out dnf.Base()
    class MockBase(object):
        class MockConf(object):
            def __init__(self):
                self.best = False
                self.clean_requirements_on_remove = None
                self.destdir = None
                self.downloadonly = False
                self.tsflags = []

        class MockModule(object):
            def __init__(self):
                pass

            def disable(self, pkg):
                pass

            def enable(self, pkg):
                pass

            def install(self, pkg):
                pass

            def remove(self, pkg):
                pass

            def upgrade(self, pkg):
                pass


# Generated at 2022-06-11 07:02:49.781486
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = DnfModule()
    assert module.base is None
    assert module.names == []
    assert module.conf_file == "/etc/dnf/dnf.conf"
    assert module.disable_gpg_check is False
    assert module.disablerepo is []
    assert module.enablerepo is []
    assert module.installroot == "/"
    assert module.list is None
    assert module.state == "present"
    assert module.update_cache is False
    assert module.update_only is False
    assert module.enable_module is False
    assert module.disable_module is False
    assert module.autoremove is False
    assert module.download_only is False
    assert module.download_dir is None
    assert module.with_modules is False


# Generated at 2022-06-11 07:04:48.281658
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    pass

# Generated at 2022-06-11 07:04:54.139865
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    pkg = DnfModule()
    v = pkg.list_items('available')
    assert v == 'available packages'

    v = pkg.list_items('installed')
    assert v == 'installed packages'

    v = pkg.list_items('updates')
    assert v == 'updates'

    try:
        v = pkg.list_items('unknown')
    except SystemExit as e:
        assert e.code == 1


# Generated at 2022-06-11 07:05:00.797473
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    base = MagicMock()
    conf_file = MagicMock()
    disable_gpg_check = MagicMock()
    disablerepo = MagicMock()
    enablerepo = MagicMock()
    installroot = MagicMock()
    list = MagicMock()
    module_base = MagicMock()
    module = MagicMock()
    names = MagicMock()
    state = MagicMock()
    with patch.object(dnf.module.DnfModule, '_base') as _base:
        _base.return_value = base
        dnf.module.DnfModule.list_items(conf_file, disable_gpg_check, disablerepo, enablerepo, installroot, list, module_base, module, names, state)


# Generated at 2022-06-11 07:05:09.772785
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    module = DnfModule(conf_file='/etc/dnf/dnf.conf', disable_gpg_check=False, disablerepo=[], enablerepo=['*'], installroot='/', list='available', names=[], state='installed', update_cache=False, update_only=False, validate_certs=True, with_modules=False, autoremove=False, download_only=False, download_dir='/etc/dnf/cache/dnf')
    module.list_items('available')
    assert_equals(module.module.fail_json.called, False)

# Generated at 2022-06-11 07:05:16.029975
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    test_obj = DnfModule(base=None, conf_file=None, disable_gpg_check=None, disablerepo=None, enablerepo=None, enable_plugin=None, installroot=None, list=None, namespace=None, state=None, update_cache=None, update_only=None, autoremove=None, download_dir=None)
    rc, out, err = test_obj.is_lockfile_pid_valid(lockfile='/var/run/dnf.pid')
    assert rc == 0

# Generated at 2022-06-11 07:05:24.719612
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():

    class Args:
        # FIXME: CHANGEME
        # Should be an object
        list = None

    args = Args()

    dnf_module = DnfModule(
        # FIXME: CHANGEME
        # Argument parsing is disabled so we can run unit tests. As a result
        # all "nondefault" arguments must be provided.
        argument_spec={},
        # FIXME: CHANGEME
        # Dnf does not require arguments.
        supports_check_mode=True
    )
    dnf_module.list_items(args.list)


# Generated at 2022-06-11 07:05:27.796100
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    """Test method run of class DnfModule"""

    with pytest.raises(Exception):
        DnfModule({"name": None}).run()



# Generated at 2022-06-11 07:05:34.984554
# Unit test for constructor of class DnfModule
def test_DnfModule():
    """
    Unit test for constructor of class DnfModule
    """

    if LooseVersion(dnf.__version__) < LooseVersion('2.0.2'):
        pytest.skip("Unit test for DnfModule() is disabled for dnf < 2.0.2")

    with pytest.raises(TypeError) as error:
        DnfModule(None)
    assert "argument of type 'NoneType' is not iterable" in str(error.value)

    results = dict(
        msg="Cache updated",
        changed=False,
        results=[],
        rc=0
    )


# Generated at 2022-06-11 07:05:46.194727
# Unit test for constructor of class DnfModule
def test_DnfModule():
    """Unit test for constructor of class DnfModule."""

    module = DnfModule({})

    assert not module.base
    assert not module.download_only
    assert not module.module_base
    assert not module.allowerasing
    assert module.autoremove
    assert not module.conf_file
    assert module.disable_gpg_check
    assert not module.disablerepo
    assert not module.download_dir
    assert not module.enablerepo
    assert not module.exclude
    assert not module.installroot
    assert not module.list
    assert not module.names
    assert not module.skip_broken
    assert not module.state
    assert not module.update_cache
    assert not module.update_only
    assert not module.with_modules



# Generated at 2022-06-11 07:05:53.901894
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    # Test the case where no args are supplied
    def test_case1():
        module_args = {}
        m = DnfModule(module_args)
        m.list_items(None)

    # Test the case where all args supplied are valid
    def test_case2():
        module_args = {
            'conf_file': '/etc/yum.conf',
            'disablerepo': ['foo'],
            'enablerepo': ['bar'],
            'installroot': '/var/tmp/bar',
            'list': ['enabled', 'installed', 'available', 'updates', 'upgrades',
                     'extras', 'obsoletes', 'all', 'recent', 'releases'],
            'releasever': '1.2.3',
        }
        m = DnfModule(module_args)
