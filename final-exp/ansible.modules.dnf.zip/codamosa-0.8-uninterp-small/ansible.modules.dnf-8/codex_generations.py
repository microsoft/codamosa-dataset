

# Generated at 2022-06-25 02:24:17.275384
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    pass


# Generated at 2022-06-25 02:24:19.000030
# Unit test for constructor of class DnfModule
def test_DnfModule():
    test_case_0()

if __name__ == '__main__':
    test_DnfModule()

# Generated at 2022-06-25 02:24:28.091781
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_1 = DnfModule(
        _ansible_no_log=False,
        _ansible_verbosity=3,
        ansible_loop_var=None,
        autoremove=False,
        conf_file=None,
        disable_gpg_check=False,
        download_only=False,
        download_dir=None,
        enablerepo=[],
        env='base',
        exclude=None,
        list='installed',
        name=[],
        names=[],
        quiet=False,
        releasever=None,
        repositories=[],
        security=False,
        skip_broken=False,
        state='latest',
        update_cache=False,
        update_only=False,
        with_modules=True
    )
    var_1.run()

# Unit test

# Generated at 2022-06-25 02:24:36.577143
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    print('\nTesting DnfModule.ensure\n')
    # In case of failure, any additional error message (str)
    # In case of success, None
    var_0 = test_case_0()
    if var_0 is None:
        print('\nSuccess\n')
    else:
        print('\nFailure: ', var_0, '\n')
    return var_0
test_DnfModule_ensure()

# This can be used to run the test cases as command line code from an IDE

# Generated at 2022-06-25 02:24:38.578836
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_1 = DnfModule()
    var_1.ensure()

test_case_0()

# Generated at 2022-06-25 02:24:43.299946
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    import dnf
    import dnf.base
    import dnf.module.module_base
    import dnf.subject
    import dnf.util
    var_0 = dnf.base.Base()
    var_1 = dnf.module.module_base.ModuleBase(var_0)
    var_2 = dnf.subject.Subject('')
    var_3 = var_2.get_best_query(var_0.sack)
    var_4 = dnf.util.am_i_root()
    var_5 = dnf.util.ensure_dir(var_0.conf.destdir)
    var_6 = dnf.exceptions.DepsolveError()
    var_7 = dnf.exceptions.Error()
    var_8

# Generated at 2022-06-25 02:24:45.701031
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_1 = DnfModule()
    var_2 = DnfModule()
    var_3 = DnfModule()
    var_3.list_items(value_a)
    var_3.list_items(value_b)
    var_3.list_items(value_c)



# Generated at 2022-06-25 02:24:48.844660
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        raise Exception("Error occurred during one of the execution steps.")


# Generated at 2022-06-25 02:24:49.712261
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-25 02:24:52.410306
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_DnfModule = DnfModule()
    var_DnfModule.ensure()


# Generated at 2022-06-25 02:27:37.657185
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    main = DnfModule(
        autoremove=False,
        conf_file=None,
        disable_gpg_check=False,
        disablerepo=None,
        download_dir=None,
        download_only=False,
        enablerepo=None,
        disableexcludes=None,
        enable_plugin=None,
        installroot=None,
        list=None,
        names=[],
        state='present',
        update_cache=False,
        update_only=None,
        validate_certs=False,
        with_modules=False,
    )
    main.ensure()

if __name__ == '__main__':
    test_case_0()
    #test_DnfModule_ensure()

# Generated at 2022-06-25 02:27:43.923208
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    setup_testcase(test_DnfModule_list_items)
    var_0 = DnfModule()
    var_1 = dnf.base.Base()
    var_0.base = var_1
    var_2 = dnf.conf.Conf()
    var_0.base._conf = var_2
    var_2.basecachedir = '/var/cache/dnf'
    var_2.basecmd = 'dnf'
    var_2.best = False
    var_2.cachedir = '/var/cache/dnf'
    var_2.config_file_path = ['/etc/dnf/dnf.conf']
    var_2.debuglevel = 2
    var_2.defaultyes = False
    var_2.diskspacecheck = True
    var_

# Generated at 2022-06-25 02:27:45.272110
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = DnfModule()
    var_0.ensure()


# Generated at 2022-06-25 02:27:51.976349
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # Create object of class DnfModule
    obj = DnfModule()
    var = None

    # Test function _add_comps_data
    obj._add_comps_data()
    var = None

    # Test function _add_comps_id_to_package
    var = obj._add_comps_id_to_package(var)

    # Test function _base
    var = obj._base(var, var, var, var, var)

    # Test function _check_module_updates
    var = obj._check_module_updates(var, var)

    # Test function _decompose_module_specs
    var = obj._decompose_module_specs(var)

    # Test function _enable_repos_by_pattern
    var = obj._enable_repos_by_

# Generated at 2022-06-25 02:28:00.557698
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    # 
    # Variables setup
    # 
    pkg_specs = ['httpd', 'dhclient']

    # 
    # Method testing
    # 

# Generated at 2022-06-25 02:28:02.620606
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_0 = DnfModule()
    var_0.run()


# Generated at 2022-06-25 02:28:05.299866
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    param_0 = main()



if __name__ == "__main__":
    test_case_0()
    test_DnfModule_is_lockfile_pid_valid()

# Generated at 2022-06-25 02:28:06.288316
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_0 = main()
    var_0.run()


# Generated at 2022-06-25 02:28:09.606810
# Unit test for function main
def test_main():
    mock_options = options()
    mock_options.conf_file = None
    mock_options.disable_gpg_check = False
    mock_options.disablerepo = None
    mock_options.enablerepo = None
    mock_options.installroot = None

    with patch.object(DnfModule, '_base', return_value=None) as mock_base:
        assert main() == mock_base.return_value


# Generated at 2022-06-25 02:28:10.563403
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    DnfModule.list_items()
