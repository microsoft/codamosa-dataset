

# Generated at 2022-06-25 02:24:21.026983
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    print('')
    module = DnfModule()
    module.ensure()
    module.run()

# Calling method
test_DnfModule_ensure()

# Main method
if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:24:23.263461
# Unit test for function main
def test_main():
    pass

# Boilerplate code to execute main()
if __name__ == '__main__':
    test_main()
    #main()

# Generated at 2022-06-25 02:24:26.109365
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # Initialize instance of class DnfModule
    dnf_module_instance = DnfModule()
    assert(isinstance(dnf_module_instance, DnfModule))



# Generated at 2022-06-25 02:24:27.316319
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # Test DnfModule with no arguments
    var_DnfModule_0 = DnfModule()


# Generated at 2022-06-25 02:24:38.942332
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_1 = DnfModule()
    var_2 = "available"
    var_3 = [u"Available Packages", u"Available Groups", u"Available Environments"]
    var_4 = "base"
    var_5 = [u"test1", u"test2"]
    try:
        var_1.list_items(var_2)
    except SystemExit as e:
        var_6 = e.code
    var_7 = {var_3[1]: var_5}
    try:
        var_1.list_items(var_3[1])
    except SystemExit as e:
        var_8 = e.code
    var_9 = {var_3[2]: var_5}

# Generated at 2022-06-25 02:24:40.996379
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    dnf_module_0 = DnfModule()
    dnf_module_0.list_items()


# Generated at 2022-06-25 02:24:41.715975
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = DnfModule()


# Generated at 2022-06-25 02:24:48.797913
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os import yumdnf

# Generated at 2022-06-25 02:24:49.904101
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_1 = DnfModule(dict())
    var_1.run()


# Generated at 2022-06-25 02:24:53.762925
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_0 = main()
    var_1 = main()
    var_2 = main()
    var_3 = main()
    var_4 = main()
    var_5 = main()
    var_6 = main()
    var_7 = main()
    var_8 = main()

# Generated at 2022-06-25 02:27:30.386423
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_1 = DnfModule()
    var_1.ensure()

    # var_5 = Mock()
    # var_5.return_value = 0
    # var_1.base._sig_check_pkg = var_5
    # var_1.ensure()

    # var_6 = Mock()
    # var_6.return_value = 1
    # var_1.base._sig_check_pkg = var_6
    # var_7 = Mock()
    # var_7.return_value = 0
    # var_1.base._get_key_for_package = var_7
    # var_1.ensure()

    # var_8 = Mock()
    # var_8.return_value = 1
    # var_1.base._sig_check_pkg = var_

# Generated at 2022-06-25 02:27:35.515559
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_1 = DnfModule()
    var_2 = None
    var_1.list_items(var_2)
    return

if __name__ == '__main__':
    # All Ansible modules should import module_utils from ansible.module_utils
    # This is so that we can call the main() function and not have to worry about
    # intercepting stdout.
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-25 02:27:38.067634
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    var_1 = dnf.lock.dnf.lockfile.is_lockfile_pid_valid()


# Generated at 2022-06-25 02:27:40.012987
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_1 = dnf.module.DnfModule()

    var_1.run()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 02:27:45.368219
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = DnfModule({})
    module.run()
    module.list_items(["foo", "bar"])
    module.ensure()
    module._base({
        "conf_file": None,
        "disable_gpg_check": False,
        "disablerepo": [],
        "enablerepo": [],
        "installroot": "/"
    })
    module._sanitize_dnf_error_msg_install(
        "spec",
        dnf.exceptions.MarkingError("msg", "pkgspec", "modtype")
    )

if __name__ == '__main__':
    module = DnfModule({})
    module.run()

# Generated at 2022-06-25 02:27:47.031573
# Unit test for function main
def test_main():
    sphinx_test_main(__file__, 'dnf')

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:27:50.757819
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        import traceback
        print(traceback.format_exc())
        assert ()

if __name__ == '__main__':
    test_main()

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.dnf import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:27:55.020840
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Exception in testcase test_main")
        raise Exception
# Test case list
tests = [test_main]

# Build and run test suite if invoked as main script
if __name__ == '__main__':
    for test in tests:
        test()
    print("{0} test cases passed".format(len(tests)))

# Generated at 2022-06-25 02:28:01.607601
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_1 = DnfModule()
    var_1._base = MagicMock(name='_base')
    var_1.base = MagicMock(name='base')
    var_1.base.conf = MagicMock(name='conf')
    var_1.base.conf.substitutions = MagicMock(name='substitutions')
    var_1.base.conf.substitutions = {}
    var_2 = list()
    var_1.list_items(var_2)


# Generated at 2022-06-25 02:28:02.749163
# Unit test for constructor of class DnfModule
def test_DnfModule():
    DnfModule()
