

# Generated at 2022-06-25 02:24:06.094774
# Unit test for function main
def test_main():
    try:
        _main()
    except SystemExit as e:
        assert str(e) == "1"
    except Exception as e:
        print('Caught exception: ' + repr(e))
        raise e


# Generated at 2022-06-25 02:24:07.665206
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_1 = DnfModule()
    print("It is a static method, it has no self para!")


# Generated at 2022-06-25 02:24:13.664819
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    try:
        self = DnfModule(
            all=None,
            autoremove=None,
            cachedir=None,
            conf_file=None,
            disable_gpg_check=None,
            disablerepo=None,
            download_dir=None,
            download_only=None,
            enablerepo=None,
            installroot=None,
            list='available',
            name=None,
            names=None,
            state=None,
            update_cache=None,
            update_only=None,
            with_modules=None,
        )
        list = 'all'
        var_0 = self.list_items(list)
    except Exception as e:
        var_0 = "Caught exception: " + str(e)
    return var_0


# Generated at 2022-06-25 02:24:21.366405
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    if not is_py2:
        print("SKIP: because Python 2.6 doesn't have argparse")
        return
    var_0 = DnfModule(module_args='', check_invalid_arguments=None, bypass_checks=None)
    # Caught exception: <class 'dnf.exceptions.Error'>

# Generated at 2022-06-25 02:24:23.675327
# Unit test for constructor of class DnfModule
def test_DnfModule():
    import pytest
    with pytest.raises(TypeError):
        DnfModule(1, False)


# Generated at 2022-06-25 02:24:27.046043
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_1 = DnfModule()
    var_1.run()


if __name__ == "__main__":
    test_case_0()
    test_DnfModule_run()

# Generated at 2022-06-25 02:24:27.914389
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_0 = main()


# Generated at 2022-06-25 02:24:31.118131
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_1 = DnfModule()
    var_1.run()
    # print(dir(var_1))


# Generated at 2022-06-25 02:24:36.981317
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    # Constructing object
    var_0 = DnfModule()

    # Calling function as it was invoked by AnsibleModule.run_command()
    var_0.run()

if __name__ == '__main__':
    test_case_0()
    test_DnfModule_run()

# vim: syntax=python:sws=4:sw=4:ts=4:et:

# Generated at 2022-06-25 02:24:39.288993
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    # Test 1
    var_1 = DnfModule()
    var_1.ensure()


# Generated at 2022-06-25 02:27:10.794063
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    # Init object
    dnf_module_obj = DnfModule()
    # Call run of object
    dnf_module_obj.run()



if __name__ == '__main__':
    func_name = _input('Enter function to test (blank to test all): ')

    if func_name == 'test_DnfModule_run':
        test_DnfModule_run()
    elif func_name == 'test_case_0':
        test_case_0()

# Generated at 2022-06-25 02:27:15.971763
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    _dnfmodule = DnfModule()
    list = "some_string"
    var_0 = _dnfmodule.list_items(list)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 02:27:17.606057
# Unit test for constructor of class DnfModule
def test_DnfModule():
    dnf_module = DnfModule()
    assert dnf_module != None


# Generated at 2022-06-25 02:27:20.087814
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    # The following statements construct an instance of class DnfModule
    # whose attributes are assigned values as specified by the test case.
    var_0 = DnfModule()
    var_0.run()


# Generated at 2022-06-25 02:27:27.774888
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    # If a lockfile is empty, we will not remove it, but a new lockfile
    # will be created as expected.
    # As the old lockfile is already empty, we can just pass in any pid.
    # This simulates an empty lockfile.
    if var_0.is_lockfile_pid_valid(12345) == True :
        print('Test case 0 pass')
    else:
        print('Test case 0 fail')

test_DnfModule_is_lockfile_pid_valid()
test_case_0()

# Generated at 2022-06-25 02:27:33.724717
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    var__x = DnfModule()
    var_user = None
    var_pid = 0
    result = var__x.is_lockfile_pid_valid(var_user, var_pid)
    assert result == True
    assert var__x.pidfile_path == "/run/dnf.pid"



# Generated at 2022-06-25 02:27:34.613585
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-25 02:27:40.012941
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    obj_0 = DnfModule()
    if var_0.is_lockfile_pid_valid(DnfModule) in var_0:
        sys.exit(1)

if __name__ == '__main__':
    # Test case 0
    test_case_0()

    # Unit test for method is_lockfile_pid_valid of class DnfModule
    # test_DnfModule_is_lockfile_pid_valid()

# Generated at 2022-06-25 02:27:41.511592
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = DnfModule()
    var_1 = var_0.ensure()
    assert var_1 == False


# Generated at 2022-06-25 02:27:42.706590
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_1 = dnf.module.DnfModule()


# Generated at 2022-06-25 02:30:20.693904
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_0 = DnfModule()



# Generated at 2022-06-25 02:30:30.251420
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():

    mock_AnsibleModule = MagicMock(name="AnsibleModule")
    mock_AnsibleModule.params = params_list_items
    mock_dnf = MagicMock(name="dnf")
    mock_dnf.subject.Subject().get_best_query().available().run()
    mock_dnf.subject.Subject().get_best_query().installed().run()

    # Mock chdir - do not change directory for unit testing
    @contextmanager
    def chdir(path):
        yield

    mock_os = MagicMock(name="os")
    mock_os.chdir.side_effect = chdir


# Generated at 2022-06-25 02:30:32.786592
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_list = ['installed', 'available', 'updates', 'extras', 'obsoletes', 'recent', 'repos', 'repo_sack']
    var_0 = main()
    var_1 = var_0.list_items(var_list)


# Generated at 2022-06-25 02:30:34.269149
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_1 = main()
    main.DnfModule(id='0')


# Generated at 2022-06-25 02:30:40.247759
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_0 = DnfModule()
    var_1 = {"installed": "yes", "pkg.version": "1.2.3", "pkg.release": "45.el7", "pkg.arch": "x86_64", "pkg.summary": "A test package for dnf.", "repo": "main"}
    var_2 = {"installed": "yes", "pkg.version": "1.2.3", "pkg.release": "45.el7", "pkg.arch": "x86_64", "pkg.summary": "A test package for dnf.", "repo": "main"}

# Generated at 2022-06-25 02:30:48.363557
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    print("Testing method ensure of class DnfModule")

    var_0 = DnfModule()
    var_0.autoremove = False
    var_0.base_with_auth = None
    var_0.conf_file = "ConfFile"
    var_0.disable_gpg_check = False
    var_0.disablerepo = [ "DisableRepo" ]
    var_0.download_dir = None
    var_0.download_only = False
    var_0.enablerepo = [ "EnableRepo" ]
    var_0.env_group_cache = {}
    var_0.env_group_cache_time = None
    var_0.environments = None
    var_0.ensure = None
    var_0.exclude = [ "Exclude" ]
    var_

# Generated at 2022-06-25 02:30:57.063768
# Unit test for function main

# Generated at 2022-06-25 02:30:58.183118
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    module = dnf.ModulePackage()
    assert callable(module.is_lockfile_pid_valid)


# Generated at 2022-06-25 02:30:59.347172
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = DnfModule()
    var_0.run()


# Generated at 2022-06-25 02:31:01.451660
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    from ansible_collections.ansible.community.plugins.modules.package.dnf import DnfModule

    obj_DnfModule = DnfModule()
    obj_DnfModule.run()
