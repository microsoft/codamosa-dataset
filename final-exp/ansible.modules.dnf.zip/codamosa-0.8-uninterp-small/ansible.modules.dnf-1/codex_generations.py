

# Generated at 2022-06-25 02:24:22.635670
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_1 = DnfModule()
    var_1.run()


# Generated at 2022-06-25 02:24:24.100574
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:24:26.531996
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    error_msg_0 = "unknown error"
    dnf_module_0 = DnfModule()
    dnf_module_0.ensure()


# Generated at 2022-06-25 02:24:32.629453
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_0 = DnfModule(
        autoremove=False,
        conf_file=None,
        disable_gpg_check=False,
        disablerepo=[],
        download_dir=None,
        download_only=False,
        enablerepo=[],
        installroot='/',
        list=None,
        name=[],
        state='installed'
    )

# Generated at 2022-06-25 02:24:34.420790
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_0 = main()
    var_0.list_items('')


# Generated at 2022-06-25 02:24:35.042585
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    var_1 = main()


# Generated at 2022-06-25 02:24:36.404432
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_0 = DnfModule()


# Generated at 2022-06-25 02:24:37.711570
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = DnfModule()
    var_0.ensure()


# Generated at 2022-06-25 02:24:43.846498
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = main()
    assert var_0.base is not None, "base should not be None"
    assert var_0.base.conf.best is True, "base.conf.best should be True"
    assert var_0.base.conf.best is True, "base.conf.best should be True"
    assert var_0.base.conf.best is True, "base.conf.best should be True"
    assert var_0.base.conf.best is True, "base.conf.best should be True"
    assert var_0.state == "installed", "var_0.state is not 'installed'"


# Generated at 2022-06-25 02:24:45.448932
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = AnsibleModule({ 'name': ['test_name']})
    obj = DnfModule(module=module)
    assert obj.module is module
    assert obj.name is ['test_name']


# Generated at 2022-06-25 02:27:26.416683
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_0 = DnfModule()
    var_1 = "results"
    var_1 = []
    var_0.list_items(var_1)


# Generated at 2022-06-25 02:27:36.709801
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    var_0 = DnfModule()
    var_0.base = None
    var_1 = DnfModule()
    var_1.base = None
    var_2 = DnfModule()
    var_2.base = None
    var_3 = DnfModule()
    var_3.base = None
    var_4 = DnfModule()
    var_4.base = None
    var_5 = DnfModule()
    var_5.base = None
    var_6 = DnfModule()
    var_6.base = None
    var_7 = DnfModule()
    var_7.base = None
    var_8 = DnfModule()
    var_8.base = None
    var_9 = DnfModule()
    var_9.base = None

# Generated at 2022-06-25 02:27:39.353900
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_0 = main()
    # List the installed packages.
    var_1 = var_0.list_items('installed')
    # List the available packages.
    var_2 = var_0.list_items('available')
    assert True


# Generated at 2022-06-25 02:27:40.100013
# Unit test for function main
def test_main():
    assert main() == 'Success'

# Generated at 2022-06-25 02:27:45.607472
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
  var_0 = DnfModule('dnf', 'module', '/etc/ansible/roles/dnf/tests/module_utils/dnf_module.py', None, 'root', 'localhost', '/home/root/.ansible/tmp/ansible-tmp-1553976466.76-244330642331532/AnsiballZ_dnf.py', 'dnf', 'state=present', 'names=foo', 'autoremove=no', 'disable_gpg_check=False', 'disablerepo=', 'enablerepo=', 'installroot=/', 'list=', 'conf_file=/etc/dnf/dnf.conf', 'download_only=False', 'download_dir=', 'update_cache=False', 'with_modules=False', 'update_only=False', 'allowerasing=False')


# Generated at 2022-06-25 02:27:46.705704
# Unit test for constructor of class DnfModule
def test_DnfModule():
    dnf_module_0 = DnfModule()


# Generated at 2022-06-25 02:27:47.828457
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = main()
    var_0.ensure()


# Generated at 2022-06-25 02:27:49.502551
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = DnfModule()
    # Call method ensure of class DnfModule
    var_0.ensure()


# Generated at 2022-06-25 02:27:51.026591
# Unit test for constructor of class DnfModule
def test_DnfModule():
    params = dict()
    instance = DnfModule()
    res = instance.main(params)
    print (res)


# Generated at 2022-06-25 02:27:53.254178
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    from ansible.modules.package.dnf import DnfModule

    test_object = DnfModule()
    test_object.ensure()
