

# Generated at 2022-06-25 02:24:13.561981
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # Create an object of DnfModule class
    module = DnfModule()

    # Check the class attributes
    assert getattr(module, 'allowerasing') == True
    assert getattr(module, 'autoremove') == False
    assert getattr(module, 'base') == None
    assert getattr(module, 'conf_file') == None
    assert getattr(module, 'disable_gpg_check') == False
    assert getattr(module, 'disablerepo') == [ u'*' ]
    assert getattr(module, 'download_only') == False
    assert getattr(module, 'download_dir') == None
    assert getattr(module, 'enablerepo') == None
    assert getattr(module, 'exclude') == []
    assert getattr(module, 'installroot') == None

# Generated at 2022-06-25 02:24:18.528534
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    main = DnfModule()
    main.base = Mock()
    main._base = Mock()
    main.base.sack.query().installed().run = Mock()
    main._mark_package_install = Mock()
    main._sanitize_dnf_error_msg_install = Mock()
    main.allowerasing = None
    main.autoremove = False
    main.conf_file = None
    main.download_only = False
    main.download_dir = None
    main.enablerepo = ['enablerepo']
    main.disablerepo = ['disablerepo']
    main.disable_gpg_check = False
    main.filenames = ['filename']
    main.groups = ['group']
    main.installroot = '/'
    main.list = None

# Generated at 2022-06-25 02:24:20.983933
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = DnfModule(module)
    var_0.ensure()


# Generated at 2022-06-25 02:24:29.259724
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    test_case_0()


if __name__ == "__main__":
    test_DnfModule_run()

# Generated at 2022-06-25 02:24:33.640932
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    var_1 = main()
    var_2 = var_1.is_lockfile_pid_valid('/var/run/dnf.pid')
    assert(var_2 == False)


# Generated at 2022-06-25 02:24:43.030802
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # Test case 1:
    # Test with each argument available.
    var_1 = DnfModule(
        conf_file=dict(type='str', default=None, aliases=['conf_path']),
        disable_gpg_check=None,
        disablerepo=None,
        enablerepo=None,
        installroot=None,
        name=None,
        list=None,
        state=None,
        enable_gpg=None,
        autoremove=None,
        autoupdate=None,
        update_cache=None,
        update_only=None,
        download_only=None,
        download_dir=None,
        with_modules=None
    )

    # Test case 2:
    # Test dnf api version.
    # We expect a lower version than 2.0.

# Generated at 2022-06-25 02:24:47.924515
# Unit test for method list_items of class DnfModule

# Generated at 2022-06-25 02:24:55.253821
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # check_mode
    module = DnfModule(dm_kwargs={'check_mode': True})
    assert module.check_mode == True
    assert module.base == None

    # conf_file
    module = DnfModule(dm_kwargs={'conf_file': '/etc/dnf/dnf.conf'})
    assert module.conf_file == '/etc/dnf/dnf.conf'

    # disable_gpg_check
    module = DnfModule(dm_kwargs={'disable_gpg_check': True})
    assert module.disable_gpg_check == True

    # disablerepo
    module = DnfModule(dm_kwargs={'disablerepo': ['a', 'b', 'c']})

# Generated at 2022-06-25 02:24:56.115724
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False


# Generated at 2022-06-25 02:24:58.827614
# Unit test for function main
def test_main():
    assert False


# Generated at 2022-06-25 02:27:15.147257
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_1 = DnfModule()
    var_1.list_items()



# Generated at 2022-06-25 02:27:18.515826
# Unit test for constructor of class DnfModule
def test_DnfModule():
    from ansible.module_utils.basic import AnsibleModule
    # construct instance of class
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    dnf = DnfModule(module)
    # check attributes were set correctly
    assert dnf.module == module


# Generated at 2022-06-25 02:27:20.381892
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    pass

if __name__ == '__main__':
    test_case_0()
    test_DnfModule_run()

# Generated at 2022-06-25 02:27:25.569356
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    print('start test_DnfModule_ensure')
    var_0 = main()
    var_0.ensure()
    print('end test_DnfModule_ensure')


# Generated at 2022-06-25 02:27:28.063592
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_1 = DnfModule()
    var_1.run()

if __name__ == "__main__":
    test_case_0()
    test_DnfModule_run()

# Generated at 2022-06-25 02:27:31.591120
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    lock_file = '/run/dnf.pid'
    DnfModule.isLockfilePidValid(lock_file)


# Generated at 2022-06-25 02:27:39.446446
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    module = DnfModule()
    module.base = module._base('conf_file', 'disable_gpg_check', 'disablerepo', 'enablerepo', 'installroot')
    module.names = []
    module.noarch = 'noarch'
    module.nevra = 'nevra'
    module.pkgs = 'pkgs'
    module.update_cache = 'update_cache'
    module.update_cache_values = 'update_cache_values'
    module.run()
    module.saved_run()
    module.saved_run()
    module.saved_run()
    module.saved_run()
    module.saved_run()
    module.saved_run()
    module.saved_run()
    module.saved_run()
    module.s

# Generated at 2022-06-25 02:27:40.660821
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    # Mock the arguments
    DnfModule.list_items(arg_0)


# Generated at 2022-06-25 02:27:41.850671
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    # Ensuring that ensure() executes withou a problem.
    DnfModule().ensure()
    return


# Generated at 2022-06-25 02:27:42.874963
# Unit test for constructor of class DnfModule
def test_DnfModule():
    DnfModule()
