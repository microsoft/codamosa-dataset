

# Generated at 2022-06-25 02:24:09.280867
# Unit test for method run of class DnfModule
def test_DnfModule_run():
  test_case_0()

if __name__ == '__main__':
    test_DnfModule_run()

# Generated at 2022-06-25 02:24:11.336409
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_0 = main()
    var_1 = var_0.run()
    return var_1


# Generated at 2022-06-25 02:24:12.875083
# Unit test for function main
def test_main():
    assert True == True



# Generated at 2022-06-25 02:24:22.454083
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    # Create a test case dict with mandatory keys
    test_case_0 = dict.fromkeys([u'conf_file', u'disable_gpg_check', u'disablerepo', u'enablerepo', u'installroot', u'list', u'names', u'state'])
    # Populate the test case dict with inputs
    test_case_0[u'conf_file'] = None
    test_case_0[u'disable_gpg_check'] = None
    test_case_0[u'disablerepo'] = None
    test_case_0[u'enablerepo'] = None
    test_case_0[u'installroot'] = None
    test_case_0[u'list'] = None
    test_case_0[u'names'] = None

# Generated at 2022-06-25 02:24:26.138827
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    dnfmodule = DnfModule()
    dnfmodule.run()

if __name__ == '__main__':
    import cProfile
    cProfile.run("test_case_0()")
    # test_DnfModule_run()

# Generated at 2022-06-25 02:24:27.736619
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_0 = DnfModule()
    var_1 = var_0._base()
    var_3 = var_0.list_items('', '', '', '', False, False)


# Generated at 2022-06-25 02:24:32.287048
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    dnf_module = main()
    fbpid = ''
    var_0 = dnf_module.is_lockfile_pid_valid(fbpid)
    #assert var_0


# Generated at 2022-06-25 02:24:41.856139
# Unit test for constructor of class DnfModule

# Generated at 2022-06-25 02:24:43.891326
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    lockfile_pid = 'var_0'
    obj = DnfModule()
    obj.is_lockfile_pid_valid(lockfile_pid)


# Generated at 2022-06-25 02:24:47.298709
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_1 = DnfModule()
    var_2 = var_1.run()
    assert var_2 == None, "test_DnfModule_run"

if __name__ == '__main__':
    test_case_0()
    test_DnfModule_run()

# Generated at 2022-06-25 02:27:14.694926
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 02:27:16.129129
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # DnfModule class instantiation test
    var_1 = DnfModule()


# Generated at 2022-06-25 02:27:17.527065
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_1 = dnf.module.DnfModule()
    var_1.run()

# Function to test main

# Generated at 2022-06-25 02:27:18.688649
# Unit test for constructor of class DnfModule
def test_DnfModule():
    with pytest.raises(Exception):
        DnfModule()


# Generated at 2022-06-25 02:27:28.593844
# Unit test for constructor of class DnfModule
def test_DnfModule():
    global var_0
    # Testing "conf_file"
    var_0 = DnfModule(
        conf_file="examples/dnf.conf",
        disable_gpg_check=False,
        disablerepo=None,
        enablerepo=None,
        installroot=None
    )
    # Testing "disable_gpg_check"
    var_0 = DnfModule(
        conf_file=None,
        disable_gpg_check=True,
        disablerepo=None,
        enablerepo=None,
        installroot=None
    )
    # Testing "disablerepo"

# Generated at 2022-06-25 02:27:37.975402
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_1 = ['packages']
    var_2 = 'installed'
    var_3 = 1
    var_4 = 'name'
    var_5 = 'name'
    var_6 = 'epel-release'
    var_7 = 'arch'
    var_8 = 'noarch'
    var_9 = 'epoch'
    var_10 = 0
    var_11 = 'version'
    var_12 = '7-11'
    var_13 = 'release'
    var_14 = 'metalink'
    var_15 = 'repo_sigtype'
    var_16 = 'Package'
    var_17 = 'summary'
    var_18 = 'Extra Packages for Enterprise Linux repository configuration'
    var_19 = 'description'
    var_20 = ''

# Generated at 2022-06-25 02:27:44.181026
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # Test case 0
    dnfModule = DnfModule()
    assert dnfModule.names == None
    assert dnfModule.conf_file == None
    assert dnfModule.update_cache == None
    assert dnfModule.state == None
    assert dnfModule.disable_gpg_check == None
    assert dnfModule.disablerepo == None
    assert dnfModule.enablerepo == None
    assert dnfModule.autoremove == None
    assert dnfModule.install_repoquery == None
    assert dnfModule.download_only == None
    assert dnfModule.download_dir == None
    assert dnfModule.update_only == None
    assert dnfModule.security == None
    assert dnfModule.bugfix == None
   

# Generated at 2022-06-25 02:27:45.841899
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_1 = test_case_0()
    var_1 = DnfModule()
    var_1.run()


# Generated at 2022-06-25 02:27:47.497681
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_0 = DnfModule()
    var_1 = main()
    var_0.list_items(var_1)


# Generated at 2022-06-25 02:27:48.627088
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    run_test_case_0()
    run_test_case_1()
