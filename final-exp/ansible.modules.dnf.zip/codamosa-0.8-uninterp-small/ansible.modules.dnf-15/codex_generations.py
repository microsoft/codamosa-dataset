

# Generated at 2022-06-25 02:24:05.066533
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # Call constructor without parameters
    var_1 = DnfModule()

if __name__ == '__main__':
    test_case_0()
    test_DnfModule()
#End of test cases

# Generated at 2022-06-25 02:24:08.794445
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    test_case_0()

test_DnfModule_run()

# Generated at 2022-06-25 02:24:16.341204
# Unit test for constructor of class DnfModule

# Generated at 2022-06-25 02:24:18.463001
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_1 = main()
    var_1.test_DnfModule()


# Generated at 2022-06-25 02:24:21.157252
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    dnfmodule = DnfModule()
    dnfmodule.ensure()

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:24:29.370896
# Unit test for function main
def test_main():
    with patch("__builtin__.open") as mock_open:
        mock_open.return_value = MagicMock(spec=file)
        # mock open to return our own custom file handle
        with patch("os.path.exists", MagicMock(return_value=True)):
            # mock exists to return false so we don't accidentally overwrite
            # existing files
            with patch("ansible.module_utils.six.moves.builtins.open", mock_open):
                # Ensure that the filehandle is set to utf-8 in py2
                if PY2:
                    with patch("__builtin__.open", mock_open):
                        test_case_0()
                else:
                    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:24:33.387178
# Unit test for constructor of class DnfModule
def test_DnfModule():
    print("Testing DnfModule constructor")

    # Init args
    args = {}
    # Init kwargs
    module = DnfModule()



# Generated at 2022-06-25 02:24:42.806975
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    if bool(1).__class__.__name__ != "bool":
        print("Wrong type returned by bool(1)")
        return

    if bool(2).__class__.__name__ != "bool":
        print("Wrong type returned by bool(2)")
        return

    if bool(3).__class__.__name__ != "bool":
        print("Wrong type returned by bool(3)")
        return

    if bool(4).__class__.__name__ != "bool":
        print("Wrong type returned by bool(4)")
        return

    if bool(5).__class__.__name__ != "bool":
        print("Wrong type returned by bool(5)")
        return


# Generated at 2022-06-25 02:24:45.829101
# Unit test for method run of class DnfModule
def test_DnfModule_run():
  dnf_module = DnfModule()
  # Test exceptions
  try:
    dnf_module.run()
  except:
    pass
  else:
    assert False, "Unreachable code!"

# Test case with assertions

# Generated at 2022-06-25 02:24:48.607182
# Unit test for function main
def test_main():
    
    # call the function
    var_0 = main()
    
    
    


# Generated at 2022-06-25 02:27:30.123364
# Unit test for function main

# Generated at 2022-06-25 02:27:31.029450
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_module = DnfModule()
    var_module.run()

# Generated at 2022-06-25 02:27:35.185480
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    _names = []
    _pattern = []
    _disablerepo = []
    _enablerepo = []
    _list = "installed"
    var_0 = DnfModule(_names, _pattern, _disablerepo, _enablerepo, _list)

    var_0.list_items(_list)


# Generated at 2022-06-25 02:27:42.629064
# Unit test for method run of class DnfModule

# Generated at 2022-06-25 02:27:43.929793
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    dnf_module_obj = DnfModule()
    dnf_module_obj.ensure()


# Generated at 2022-06-25 02:27:44.953334
# Unit test for constructor of class DnfModule
def test_DnfModule():
    dnfModule = DnfModule()



# Generated at 2022-06-25 02:27:46.672415
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    var_0 = DnfModule()
    var_1 = var_0.is_lockfile_pid_valid()


# Generated at 2022-06-25 02:27:48.062244
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_0 = DnfModule()
    var_0.list_items(list)


# Generated at 2022-06-25 02:27:53.918310
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    # init dnf module
    dnf_module = DnfModule()
    # init base
    dnf_module.base = dnf_module._base('null', False, 'null', 'null', 'null')
    dnf_module.base.conf.installroot = 'null'
    dnf_module.base._setup_excludes()
    dnf_module.base.read_all_repos()
    dnf_module.base.fill_sack()
    # set state as 'installed'
    dnf_module.state = 'installed'
    # call ensure
    dnf_module.ensure()


# Generated at 2022-06-25 02:27:56.162196
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_0 = main()
    var_1 = DnfModule(var_0)
    assert isinstance(var_1, DnfModule)
