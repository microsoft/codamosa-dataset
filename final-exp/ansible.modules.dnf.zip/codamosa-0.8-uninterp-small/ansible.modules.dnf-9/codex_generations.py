

# Generated at 2022-06-25 02:24:13.819341
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    import dnf.exceptions

    class Smoke_DnfModule(object):
        @staticmethod
        def fail_json(*args, **kwargs):
            if 'msg' in kwargs:
                return kwargs['msg']
            return args[0]

        @staticmethod
        def exit_json(*args, **kwargs):
            if 'changed' in kwargs:
                return kwargs['changed']
            return args[0]

    class Smoke_Dnf(object):
        def __init__(self, *args, **kwargs):
            self.rpm_probe = None
            self.conf = None
            self.repos = None
            self.sack = None

        def __enter__(self):
            return self


# Generated at 2022-06-25 02:24:23.585990
# Unit test for function main
def test_main():
    # Setup mock
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception(kwargs["msg"])
        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    mock_module = MockModule()
    # Setup mock
    class MockDnfModule(object):
        def __init__(self, module):
            self.module = module
        def run(self):
            pass

    tmp_path = tempfile.mkdtemp()

# Generated at 2022-06-25 02:24:25.069407
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    set_up()
    test_case_0()
    tear_down()


# Generated at 2022-06-25 02:24:27.622534
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    dnf_module_obj = DnfModule()
    dnf_module_obj.run()

# main function

# Generated at 2022-06-25 02:24:29.534163
# Unit test for constructor of class DnfModule
def test_DnfModule():
    test_case_0()

if __name__ == '__main__':
    test_DnfModule()

# Generated at 2022-06-25 02:24:32.377319
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    # No test for method run of class DnfModule
    pass


# Generated at 2022-06-25 02:24:33.681585
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_0 = main()
    try:
        var_0.list_items(['updates'])
    except dnf.exceptions.Error:
        pass


# Generated at 2022-06-25 02:24:34.280087
# Unit test for constructor of class DnfModule
def test_DnfModule():
    main()


# Generated at 2022-06-25 02:24:43.534111
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    output = munch.Munch()
    sub = munch.Munch()
    output.sub = sub
    var_0 = DnfModule(module=munch.Munch())
    var_1 = str()
    var_2 = str()
    var_3 = str()
    var_4 = str()
    var_5 = [var_2, var_3, var_4]
    var_6 = []

# Generated at 2022-06-25 02:24:48.076871
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    # Pass
    var_0 = test_case_0()

# Invoke module entry point
if __name__ == "__main__":
    try:
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore')
            import dnf
            import dnf.module
            import dnf.module.module_base
    except ImportError:
        print('dnf is required for this module')
        sys.exit(1)

    run_command()

# Generated at 2022-06-25 02:27:08.248097
# Unit test for function main
def test_main():
    var_0 = AnsibleModule(
        **yumdnf_argument_spec
    )
    assert var_0 is not None


# Generated at 2022-06-25 02:27:09.380654
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_1 = DnfModule()


# Generated at 2022-06-25 02:27:09.987559
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-25 02:27:12.176232
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = DnfModule()
    var_0.list = []
    var_0.state = None
    var_0.ensure()


# Generated at 2022-06-25 02:27:20.055818
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = DnfModule()
    var_0.base = mock.mock_dnf_base()
    var_0.module = mock.MockAnsibleModule()
    var_0.base.conf.best = False
    var_0.base.conf.destdir = False
    var_0.base.conf.installroot = '/'
    var_0.base.conf.assumeno = False
    var_0.base.conf.assumeyes = False
    var_0.base.conf.downloadonly = False
    var_0.module.params = {'name': None, 'state': 'present'}
    var_0.state = 'present'
    var_0.list = None
    var_0.names = []

# Generated at 2022-06-25 02:27:20.892995
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    main()


# Generated at 2022-06-25 02:27:28.615805
# Unit test for function main
def test_main():
    import dnf.module_wrapper
    save_dnf_module_wrapper_dnf_module_AnsibleModule = dnf.module_wrapper.dnf_module_AnsibleModule
    save_dnf_module_wrapper_dnf_exceptions = dnf.module_wrapper.dnf_exceptions
    save_dnf_module_wrapper_dnf_module = dnf.module_wrapper.dnf_module
    save_dnf_module_wrapper_dnf_sack = dnf.module_wrapper.dnf_sack
    save_dnf_module_wrapper_dnf_conf = dnf.module_wrapper.dnf_conf
    save_dnf_module_wrapper_dnf_package_spec = dnf.module_wrapper.dnf_package_spec
    save_

# Generated at 2022-06-25 02:27:34.409033
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_0 = dnf.conf.Conf()
    var_0.best = True
    var_0.installonlypkgs = []
    var_0.installonly_limit = 3
    var_0.override_install_langs = []
    var_0.persistdir = '/var/lib/dnf'
    var_0.plugins = True
    var_0.releasever = None
    var_0.tsflags = ['nodocs']
    var_1 = dnf.conf.Conf()
    var_1.best = True
    var_1.installonlypkgs = []
    var_1.installonly_limit = 3
    var_1.override_install_langs = []
    var_1.persistdir = '/var/lib/dnf'

# Generated at 2022-06-25 02:27:37.603514
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()

if __name__ == '__main__':
    # Run unit tests
    test_main()

# Generated at 2022-06-25 02:27:39.659239
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    module_inst = DnfModule()
    pid = 1015
    var_1 = module_inst.is_lockfile_pid_valid(pid)
    print(str(var_1))


# Generated at 2022-06-25 02:32:17.902121
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = DnfModule()
    assert(var_0.ensure() == 0)


# Generated at 2022-06-25 02:32:23.537020
# Unit test for function main
def test_main():
    import tempfile
    import shutil
    # noinspection PyTypeChecker
    faketty = -1
