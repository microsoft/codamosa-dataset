

# Generated at 2022-06-25 02:24:14.754410
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_1 = DnfModule()
    var_1.list_items(list_var_1)

if __name__ == '__main__':
    test_case_0()

# End of ansible/module_utils/dnf_utils.py

# Generated at 2022-06-25 02:24:15.998393
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_1 = main()
    var_1.list_items()


# Generated at 2022-06-25 02:24:18.734824
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    module = DnfModule()
    # the default value of output_spec should be None
    assert module.list_items() == None


# Generated at 2022-06-25 02:24:21.187802
# Unit test for constructor of class DnfModule
def test_DnfModule():
    var_1 = DnfModule(module=None)
    assert var_1 != None


# Generated at 2022-06-25 02:24:23.078969
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    dnfmoduleobject = DnfModule()
    dnfmoduleobject.list_items(var_0)

# Generated at 2022-06-25 02:24:24.152153
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_1 = main()


# Generated at 2022-06-25 02:24:25.160995
# Unit test for constructor of class DnfModule
def test_DnfModule():
    test_case_0()


# Generated at 2022-06-25 02:24:32.681761
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_0 = DnfModule()
    with patch.object(var_0, '_base', return_value='foo'), patch.object(var_0, 'module_base', return_value='foo'), patch.object(var_0, 'list_items', return_value='foo'), patch.object(var_0, 'base', return_value='foo'):
        assert var_0.ensure() == 'foo'


# Generated at 2022-06-25 02:24:37.789913
# Unit test for function main
def test_main():
    var_0 = main()
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:24:43.079343
# Unit test for function main
def test_main():
    var_0 = None
    var_1 = '{"packages": [], "msg": "Cache updated"}'
    var_2 = dnf.exceptions.DepsolveError('DepsolveError occurred')

    try:
        test_case_0()
    except dnf.exceptions.DepsolveError as e:
        var_0 = str(e)
    assert var_0 == var_2


# Generated at 2022-06-25 02:27:16.331215
# Unit test for function main
def test_main():
    var_1 = type(main)
    var_2 = main()
    var_3 = type(var_2)
    assert var_1 == var_3

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-25 02:27:26.740299
# Unit test for constructor of class DnfModule
def test_DnfModule():
    module = ansible_module_DnfModule()
    p = module.DnfModule(
        name=["xeyes"],
        state=None,
        enablerepo=[],
        conf_file=None,
        disable_gpg_check=False,
        disablerepo=[],
        installroot=None,
        list="installed",
        enable_plugin=None,
        releasever=None,
        autoremove=False,
        disable_plugin=None,
        download_only=False,
        exclude=[],
        download_dir=None,
        update_only=False,
        install_repoquery=True,
        update_cache=False,
        skip_broken=True,
        allowerasing=False
    )
    assert p

if __name__ == '__main__':
    py

# Generated at 2022-06-25 02:27:30.115464
# Unit test for function main
def test_main():
    var_0 = main()
    assert type(var_0) == DnfModule


# Generated at 2022-06-25 02:27:31.748886
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_1 = DnfModule()
    var_1.ensure()


# Generated at 2022-06-25 02:27:34.043864
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    _obj = main()
    _pid = 1
    _ret = _obj.is_lockfile_pid_valid(_pid)


# Generated at 2022-06-25 02:27:36.710286
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    var_DnfModule = DnfModule()
    var_pid = 1
    var_return = var_DnfModule.is_lockfile_pid_valid(var_pid)
    assert var_return is False


# Generated at 2022-06-25 02:27:38.359607
# Unit test for function main
def test_main():
    # test for pass
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-25 02:27:42.330729
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # Verify that a new instance of the class can be created
    var = DnfModule()
    assert isinstance(var, DnfModule)


# Generated at 2022-06-25 02:27:43.255436
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    main()


# Generated at 2022-06-25 02:27:45.907694
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    cmd = DnfModule(dict(state='present', list='updates'),
                    check_rc=False)
    result = cmd._base()
    cmd.list_items(result)
    assert result == dict(state='present', list='updates')
