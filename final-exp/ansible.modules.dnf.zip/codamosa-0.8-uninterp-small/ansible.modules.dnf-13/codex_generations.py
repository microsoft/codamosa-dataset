

# Generated at 2022-06-25 02:24:14.671534
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_1 = DnfModule()
    var_1.base = DnfModule()
    var_1.module = DnfModule()
    var_1.base.module = DnfModule()
    var_1.base.base = DnfModule()
    var_1.base.base.base = DnfModule()
    var_2 = DnfModule()
    var_1.base.base.base.module_base = var_2
    var_1.list_items("list")


# Generated at 2022-06-25 02:24:24.842743
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    default_config_file = '/etc/dnf/dnf.conf'
    default_installroot = '/'
    module_base = dnf.module.module_base.ModuleBase(dnf.base.Base, None)
    module_base.base = dnf.base.Base(module_base)
    module_base.base.output = dnf.cli.output.Output(module_base)
    module_base.base.logging.setup(dnf.logging.STDERR, dnf.logging.DEBUG, False)
    module_base.base.message_config = dnf.cli.output.CliMessageConfig(module_base)
    module_base.base.conf = dnf.conf.Conf()

# Generated at 2022-06-25 02:24:30.367768
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    var_1 = DnfModule(autoremove=None, base=None, check_options={'conf_file': 'string', 'disable_gpg_check': True, 'disablerepo': 'string', 'enablerepo': 'string', 'installroot': 'string'}, conf_file='string', download_dir=None, download_only=None, disable_gpg_check=True, disablerepo='string', enablerepo='string', list='string', installroot='string', names=[], releasever='string', state='installed', update_cache=None, update_only=None, with_modules=None)
    var_1.ensure()


# Generated at 2022-06-25 02:24:34.168996
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    var_1 = DnfModule()
    var_2 = var_1.is_lockfile_pid_valid()
    if var_2 == None:
        raise Exception("assert_error")


# Generated at 2022-06-25 02:24:36.534865
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    test_case_0()

if __name__ == "__main__":
    ret = test_DnfModule_run()

# Generated at 2022-06-25 02:24:39.777146
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    var_0 = main()
    var_0.run()


if __name__ == '__main__':
    try:
        test_case_0()
    except TypeError:
        pass

# Generated at 2022-06-25 02:24:40.700486
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-25 02:24:42.465405
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    var_0 = DnfModule()
    var_1 = var_0.is_lockfile_pid_valid(None)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 02:24:47.690697
# Unit test for method run of class DnfModule
def test_DnfModule_run():
    # Test setup
    module_params = {'download_only': False, 'name': ['python-dnf', 'python2-dnf'], 'state': None}
    dnf_module = DnfModule(dnf_base.base, module_params)
    # UNIT TEST: Method run of class DnfModule with test case 0
    print("> test_case_0: ")
    dnf_module.run()
    print("< test_case_0: passed")

test_DnfModule_run()

# Generated at 2022-06-25 02:24:52.372109
# Unit test for method list_items of class DnfModule
def test_DnfModule_list_items():
    var_0 = main()
    # Test case 0:
    # Test if the list items are being populated correctly
    var_0.list = 'installed'
    var_0.list_items(var_0.list)
    assert "cowsay" in var_0.module.result['results']
    var_0.list = 'available'
    var_0.list_items(var_0.list)
    assert "cowsay" in var_0.module.result['results']
    var_0.list = 'upgradable'
    var_0.list_items(var_0.list)
    assert "NetworkManager" in var_0.module.result['results']
    var_0.list = 'extras'
    var_0.list_items(var_0.list)

# Generated at 2022-06-25 02:27:18.995586
# Unit test for constructor of class DnfModule
def test_DnfModule():
    main()

# if __name__ == '__main__':
#     main()

# Generated at 2022-06-25 02:27:23.390689
# Unit test for constructor of class DnfModule
def test_DnfModule():
    # Test instantiation and str method
    module = DnfModule()
    test_str = str(module)
    assert test_str is not None


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:27:25.225454
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    # Init class
    var_0 = DnfModule()
    # Call method
    var_1 = var_0.is_lockfile_pid_valid()


# Generated at 2022-06-25 02:27:26.469190
# Unit test for method ensure of class DnfModule
def test_DnfModule_ensure():
    dnf_module = DnfModule()
    # This method is not implemented yet
    pass


# Generated at 2022-06-25 02:27:27.274117
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:27:36.642370
# Unit test for constructor of class DnfModule
def test_DnfModule():
    cm = DnfModule(AnsibleModule, dnf_base=None)
    assert cm.base is not None
    assert isinstance(cm.base, dnf.Base)
    cm = DnfModule(AnsibleModule, dnf_base=dnf.Base())
    assert cm.base is not None
    assert isinstance(cm.base, dnf.Base)
    try:
        cm = DnfModule(AnsibleModule, dnf_base=False)
        assert False, "Should have failed"
    except dnf.exceptions.Error as e:
        assert e.msg == "dnf_base argument takes dnf.Base() or None"


# Generated at 2022-06-25 02:27:37.818005
# Unit test for constructor of class DnfModule
def test_DnfModule():
    my_object = DnfModule()


# Generated at 2022-06-25 02:27:42.706400
# Unit test for method is_lockfile_pid_valid of class DnfModule
def test_DnfModule_is_lockfile_pid_valid():
    # Test case 0
    var_0 = DnfModule()
    var_1 = var_0.is_lockfile_pid_valid()
    assert var_1 == True


# Generated at 2022-06-25 02:27:49.604438
# Unit test for method list_items of class DnfModule

# Generated at 2022-06-25 02:27:52.277550
# Unit test for constructor of class DnfModule
def test_DnfModule():
    #
    # Test of constructor
    #
    var_0 = DnfModule()
    var_0.run()

if __name__ == '__main__':
    test_case_0()

    test_DnfModule()