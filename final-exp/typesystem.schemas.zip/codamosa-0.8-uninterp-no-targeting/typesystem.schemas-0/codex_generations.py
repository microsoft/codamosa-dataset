

# Generated at 2022-06-22 06:08:26.001783
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    ref_definitions = SchemaDefinitions()
    class Item(Schema):
        id = Reference(to="UUID", definitions=ref_definitions)
        name = Reference(to="Name", definitions=ref_definitions)

    class UUID(Schema):
        uuid = Field(format="uuid")

    ref_definitions["UUID"] = UUID
    ref_definitions["Name"] = Field()

    uuid = {"uuid": "00000000-0000-0000-0000-000000000001"}
    Item(id=uuid, name="test")
    del ref_definitions["UUID"]

    assert Item.fields["id"].target_string == "UUID"
    assert Item.fields["name"].target_string == "Name"
    assert Item.fields["id"].target is None
    assert Item.fields

# Generated at 2022-06-22 06:08:30.677328
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String
    from typesystem import Schema
    class MySchema(Schema):
        my_string = String()

    my_schema = MySchema(my_string="my string")
    assert my_schema.__iter__() == ['my_string']


# Generated at 2022-06-22 06:08:34.335581
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schema_definitions = SchemaDefinitions()
    assert hasattr(schema_definitions, '_definitions')
    assert isinstance(schema_definitions._definitions, dict)
    assert len(schema_definitions._definitions) == 0
    assert schema_definitions == {}


# Generated at 2022-06-22 06:08:39.058434
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    field = Boolean()
    class TestSchema(Schema):
        test_field = field

    schema = TestSchema(test_field=True)
    assert list(schema) == ['test_field']


# Generated at 2022-06-22 06:08:45.511258
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Given a Schema of fields
    class MySchema(Schema):
        foo = String()
        bar = String(default="")
    # and a Schema with a default value
    schema1 = MySchema(foo="a")
    schema2 = MySchema(foo="a")
    schema3 = MySchema(foo="b")
    # Then:
    # The two schemas are equal
    assert schema1 == schema2
    # The first schema is not equal to the third schema
    assert not schema1 == schema3


# Generated at 2022-06-22 06:08:55.383334
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class PersonSchema(Schema, metaclass=SchemaMetaclass):
        def __init__(self):
            self.name = "Person"
            self.id = 1234

    class EmployeeSchema(PersonSchema, metaclass=SchemaMetaclass):
        def __init__(self):
            self.name = "Employee"
            self.id = 5678
            self.title = "Dev"

        def test_method(self):
            return "Test"

    assert EmployeeSchema().name == "Employee"
    assert EmployeeSchema().id == 5678
    assert EmployeeSchema().title == "Dev"
    assert EmployeeSchema().test_method() == "Test"



# Generated at 2022-06-22 06:09:07.313534
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class BaseSchema(Schema):
        foo = Field()
        bar = Field()

    class MySchema(Schema):
        foo = Field()
        bar = Field()
        baz = Field()

    class BaseSchema2(Schema):
        foo2 = Field()

    class MySchema2(Schema, BaseSchema, BaseSchema2):
        foo = Field()
        baz = Field()

    assert MySchema2.fields == {
        'foo': Field(name='foo'),
        'bar': Field(name='bar'),
        'baz': Field(name='baz'),
        'foo2': Field(name='foo2')
    }
    assert MySchema2.__bases__ == (BaseSchema, BaseSchema2)



# Generated at 2022-06-22 06:09:13.674546
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from .models import PhysicalAddress
    from .serializers import PhysicalAddressSerializer

    address1 = PhysicalAddress("address_id", "street_name", "city", "state", "zip_code", True)

    serializer = PhysicalAddressSerializer(address1)
    serialized_address1 = serializer.serialize()

    serializer.target_string = "Address"
    serialized_address1_2 = serializer.serialize()

    assert serialized_address1 == serialized_address1_2



# Generated at 2022-06-22 06:09:16.982987
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import pytest
    from unittest.mock import Mock
    s1 = Schema()
    s2 = Schema(fields={'a':2}, b=3, y=20)
    assert s1 == s2

# Generated at 2022-06-22 06:09:17.603560
# Unit test for constructor of class Reference
def test_Reference():
    pass

# Generated at 2022-06-22 06:09:38.276816
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert SchemaDefinitions()._definitions == dict()
    assert SchemaDefinitions(dict())._definitions == dict()
    assert SchemaDefinitions(**dict())._definitions == dict()
    assert SchemaDefinitions(1, 2)._definitions == dict()
    assert SchemaDefinitions(1, 2, **dict())._definitions == dict()
    assert SchemaDefinitions(1, a=2, **dict())._definitions == {'a': 2}


# Generated at 2022-06-22 06:09:47.464016
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    a_list_of_numbers = [1,2,3]
    a_dict_of_strings = {"a":"alpha","b":"beta","c":"gamma"}
    a_dict_of_numbers = {"a":1,"b":2,"c":3}
    a_list_of_dicts = [a_dict_of_numbers]
    a_dict_of_dicts = {"1":a_dict_of_numbers,"2":a_dict_of_strings, "3":[a_dict_of_numbers]}
    assert(a_dict_of_numbers == a_dict_of_dicts["1"])
    assert(a_list_of_dicts[0] == a_dict_of_dicts["3"][0])
    a_dict_of_dicts["2"]

# Generated at 2022-06-22 06:09:52.777598
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class User(Schema):
        email = types.email()
        name = types.string()
        age = types.integer()

    user1 = User({'email': 'example@example.com', 'name': 'Jane Doe', 'age': 19})
    user2 = User(email='example@example.com', name='Jane Doe', age=19)
    user3 = User(email='example@example.com', name='Jane Doe', age=29)
    user4 = User(email='example@example.com', name='Jane Doe')

    assert user1 == user2
    assert user2 == user1
    assert user1 != user3
    assert user3 != user1
    assert user1 != user4


# Generated at 2022-06-22 06:09:58.834025
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    print("Start testing __getitem__")

    import os.path
    import sys
    import pytest
    from typesystem import Structure

    sys.path.append(os.path.abspath('./test'))

    from schema2_example import *
    
    t = SchemaDefinitions()
    t.__setitem__('test', test_schema)

    assert t.__getitem__('test') == test_schema

    print("End testing __getitem__")


# Generated at 2022-06-22 06:10:02.818792
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    sample_obj = Schema(test=1)
    assert sample_obj == Schema(test=1)
    assert sample_obj == {'test': 1}
    assert list(iter(sample_obj)) == ['test']
    assert list(iter(sample_obj)) == ['test']

# Generated at 2022-06-22 06:10:14.166453
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Base(Schema):
        pass
    class Bar(Schema, metaclass=SchemaMetaclass):
        x = String()
        z = String()
    class Foo(Schema):
        y = String()
        x = String()
        y = String()
        z = String()
    print(Foo)
    foo = Foo(x="x", y="y", z="z")
    print(list(foo.__iter__()))
    print(list(Foo.__iter__()))
    print(isinstance(foo, MutableMapping))
    print(issubclass(Foo, MutableMapping))
    print(isinstance(Foo, MutableMapping))
    print(isinstance(Foo, Mapping))
    print(isinstance(Foo, Schema))

# Generated at 2022-06-22 06:10:24.451382
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class AClass(Schema):
        a_field_without_default = Field(type="integer")
        a_field_with_default = Field(type="integer", default=5)

    a_instance = AClass(
        a_field_without_default=13,
        a_field_with_default=5,
        not_a_field_name_of_a_class=30
    )
    a_instance_string_representation = repr(a_instance)
    assert a_instance_string_representation == "AClass(a_field_without_default=13, not_a_field_name_of_a_class=30, a_field_with_default=5)"
    # print(a_instance_string_representation)

# Generated at 2022-06-22 06:10:27.550538
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test_object = SchemaDefinitions()
    assert isinstance(test_object, SchemaDefinitions)


# Generated at 2022-06-22 06:10:32.410357
# Unit test for method validate of class Reference
def test_Reference_validate():
    assert Reference(to=float, definitions={float: float}).validate(0) == 0
    assert Reference(to=float, definitions={float: float}).validate(0.0) == 0.0
    assert Reference(to=float, definitions={float: float}).validate(3.14) == 3.14


# Generated at 2022-06-22 06:10:38.009767
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Test(Schema):
        one = int
        two = bool
        def __init__(self, **kwargs):
            super().__init__(**kwargs) 
    assert list(Test(one=1, two=True)) == ['one', 'two']
    assert list(Test(one=1)) == ['one']
    assert list(Test(two=True)) == ['two']
    assert list(Test()) == []

# Generated at 2022-06-22 06:10:50.618421
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Test for negative condition 'x is not in self._definitions'
    definition = SchemaDefinitions()
    key = 1
    try:
        definition.__delitem__(key)
    except Exception as e:
        if 'x is not in self._definitions' in str(e):
            pass
        else:
            assert False
    # Test for negative condition 'x is not in self._definitions'
    definition = SchemaDefinitions()
    key = 1
    try:
        del definition[key]
    except Exception as e:
        if 'x is not in self._definitions' in str(e):
            pass
        else:
            assert False


# Generated at 2022-06-22 06:10:51.912388
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert True


# Generated at 2022-06-22 06:10:55.067223
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sdef = SchemaDefinitions()
    sdef["apples"] = "apples"
    assert sdef["apples"] == "apples"


# Generated at 2022-06-22 06:11:03.477861
# Unit test for constructor of class SchemaMetaclass

# Generated at 2022-06-22 06:11:04.137667
# Unit test for constructor of class Reference
def test_Reference():
  pass

# Generated at 2022-06-22 06:11:15.697990
# Unit test for constructor of class Schema
def test_Schema():
    # test success
    schema = Schema({"foo": 1})
    assert schema.foo == 1
    # test success
    class Foo(Schema):
        foo = Field(primitive=str)
    schema = Foo({"foo": "bar"})
    assert schema.foo == "bar"
    # test success
    class Foo(Schema):
        foo = Field(primitive=str)
    schema = Foo(Foo({"foo":"bar"}))
    assert schema.foo == "bar"
    # test success
    class Foo(Schema):
        foo = Field(primitive=str, default="bar")
    schema = Foo()
    assert schema.foo == "bar"
    # test success
    class Foo(Schema):
        foo = Field(primitive=str)
    schema = Foo(foo="bar")


# Generated at 2022-06-22 06:11:18.617071
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():

    class TestSchema(Schema):
        field = Integer()

    assert TestSchema.fields == {"field": Integer()}

test_SchemaMetaclass___new__()

# Generated at 2022-06-22 06:11:25.911226
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import IntegerField

    class ObjectA(Schema):
        field_a = IntegerField()

    obj = ObjectA(field_a=100)

    refA = Reference(to=ObjectA)
    assert refA.target == ObjectA
    assert refA.validate(obj) == obj

    refB = Reference(to="ObjectA")
    assert refB.target_string == "ObjectA"
    assert refB.validate(obj) == obj

    definitions = SchemaDefinitions()
    definitions["ObjectA"] = ObjectA
    refB = Reference(to="ObjectA", definitions=definitions)
    assert refB.target_string == "ObjectA"
    assert refB.validate(obj) == obj

# Generated at 2022-06-22 06:11:34.139444
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions["a"] = 1
    assert "a" in schema_definitions
    assert len(schema_definitions) == 1
    del schema_definitions["a"]    
    assert len(schema_definitions) == 0

if __name__ == "__main__":
    import sys
    import doctest

    verbose_flag = False
    if "-v" in sys.argv:
        verbose_flag = True
        sys.argv.remove("-v")

    doctest.testmod(verbose=verbose_flag)

# Generated at 2022-06-22 06:11:35.548495
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    value = obj.__len__()
    assert value == 0


# Generated at 2022-06-22 06:11:59.944608
# Unit test for method serialize of class Reference
def test_Reference_serialize():
  class A1(Schema):
    a = Field()
  class A2(Schema):
    b = Field()
  definitions = SchemaDefinitions()
  definitions["A1"] = A1
  definitions["A2"] = A2
  a1 = A1(a=1)
  a2 = A2(b=2)
  ref1 = Reference(to="A1", definitions=definitions)
  ref2 = Reference(to="A2", definitions=definitions)
  assert ref1.serialize(a1) == {'a': 1}
  assert ref2.serialize(a2) == {'b': 2}

# Generated at 2022-06-22 06:12:05.694849
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schemaDefinitions = SchemaDefinitions()
    assert schemaDefinitions._definitions == {}
    assert list(schemaDefinitions) == []
    assert len(schemaDefinitions) == 0


# Generated at 2022-06-22 06:12:08.174443
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchemaField(Field):
        pass

    class TestSchema(Schema):
        field = TestSchemaField

    assert TestSchema.fields["field"] is TestSchemaField



# Generated at 2022-06-22 06:12:12.252274
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # These are all examples and may not be tested
    x=SchemaDefinitions()
    x=SchemaDefinitions(**x)
    x=SchemaDefinitions(*x)


# Generated at 2022-06-22 06:12:20.165626
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        bar = String()
    class Foo(Schema):
        bar = String()
    foo_1 = Foo(bar = "abc")
    assert foo_1 == foo_1
    foo_2 = Foo(bar = "abc")
    assert foo_1 == foo_2
    foo_3 = Foo(bar = "def")
    assert not (foo_1 == foo_3)


# Generated at 2022-06-22 06:12:23.608066
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    obj = SchemaDefinitions(*[{'a': 1}, {'b': 2}, {'c': 3}])
    assert obj == {'a': 1, 'b': 2, 'c': 3}, 'SchemaDefinitions constructor failed'


# Generated at 2022-06-22 06:12:28.659197
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    input_1        = SchemaDefinitions()
    expected_value = 0
    actual_value   = len(input_1)
    # Raise an exception if the two values do not compare equal.
    msg = "__len__() method returned: {} expected: {}".format(actual_value, expected_value)
    assert actual_value == expected_value, msg

# Generated at 2022-06-22 06:12:29.684002
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    #TODO
    pass


# Generated at 2022-06-22 06:12:35.583106
# Unit test for function set_definitions
def test_set_definitions():
    class User(Schema):
        id = Field()
        name = Field()

    class Comment(Schema):
        user = Reference(User)

    definitions = SchemaDefinitions()
    field = Comment.fields["user"]
    set_definitions(field, definitions)
    assert field.definitions == definitions

# Generated at 2022-06-22 06:12:42.543602
# Unit test for constructor of class Schema
def test_Schema():
    import typesystem
    class Schema_Test(Schema):
        nickname = typesystem.String(max_length=10)
        age = typesystem.Integer(minimum=0, maximum=120)
    schema_dict = {'nickname': 'John', 'age': 25}
    schema_obj = Schema_Test(schema_dict)
    assert schema_obj['nickname'] == 'John'
    assert schema_obj['age'] == 25
    print('Pass test_Schema')


# Generated at 2022-06-22 06:13:01.697828
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    class MyClass(object):
        pass
    test = SchemaDefinitions()
    test['foo'] = MyClass
    assert test['foo'] == MyClass


# Generated at 2022-06-22 06:13:11.317850
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    schema_definitions = {
        'title': 'SchemaDefinitions',
        'type': 'object',
        'properties': {
            'SchemaDefinitions': {
                'type': 'object',
                'properties': {
                    'required': {
                        'type': 'array',
                        'items': {
                            'type': 'string'
                        },
                        'uniqueItems': True
                    }
                },
                'additionalProperties': False
            }
        }
    }

    # case 1: test normal
    schema_definitions_test = SchemaDefinitions()
    schema_definitions_test.fields = {
        'required': {
            'type': 'array',
            'items': {
                'type': 'string'
            },
            'uniqueItems': True
        }
    }
    schema

# Generated at 2022-06-22 06:13:16.911546
# Unit test for function set_definitions
def test_set_definitions():
    class Simple(Schema):
        pass

    class Container(Schema):
        content = Reference("Simple")

    assert Container.fields["content"].definitions is None
    definitions = SchemaDefinitions({"Simple": Simple})
    set_definitions(Container.fields["content"], definitions)
    assert Container.fields["content"].definitions is not None
    assert Container.fields["content"].definitions["Simple"] is Simple
    assert Container.fields["content"].target is Simple

# Generated at 2022-06-22 06:13:21.709600
# Unit test for constructor of class Reference
def test_Reference():
    try:
        Reference("name")  # Type hinting error
    except AssertionError:
        pass
    else:
        assert False, "Expected AssertionError"
    Reference("name", definitions={})  # No problem

test_Reference()



# Generated at 2022-06-22 06:13:29.709427
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    # Test that SchemaDefinitions works as a MutableMapping
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    assert "foo" not in definitions
    definitions["foo"] = "bar"
    assert len(definitions) == 1
    assert "foo" in definitions
    assert definitions["foo"] == "bar"
    del definitions["foo"]
    assert len(definitions) == 0
    assert "foo" not in definitions

    class Foo(Schema):
        a = Field()

    assert Foo.fields["a"].has_default()
    assert "a" in Foo.fields

    class Bar(Foo):
        b = Field()

    assert Bar.fields["a"].has_default()
    assert Bar.fields["b"].has_default()
    assert "a" in Bar.fields


# Generated at 2022-06-22 06:13:32.946023
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    if (
        len(SchemaDefinitions())
    ) != 0:
        return False
    return True


# Generated at 2022-06-22 06:13:41.046740
# Unit test for method validate of class Reference
def test_Reference_validate():
    m2 = Reference("Referenced")
    Referenced = SchemaMetaclass.__new__(
        SchemaMetaclass,
        'Referenced',
        (),
        {
            'a': 'B',
            'b': 2,
            'fields': {
                'a': 'B',
                'b': 2
            }
        },
        SchemaDefinitions(
            {
                'Referenced': 'Referenced'
            }
        )
    )
    obj = Referenced(B='B', b=2)
    assert m2.validate(obj) == obj

# Generated at 2022-06-22 06:13:45.942842
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():

    class TestSchema(Schema):
        foo = Field()
        baz = Field()
        bar = Field(default="10")

    schema = TestSchema(foo=1, baz="world")
    assert list(schema) == ["foo", "baz"]


# Generated at 2022-06-22 06:13:48.179160
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert SchemaDefinitions({1: 2}).__getitem__(1) == 2


# Generated at 2022-06-22 06:13:59.936956
# Unit test for constructor of class Reference
def test_Reference():
    assert getargspec(Reference.__init__).args == ['self', 'to', 'definitions', '**kwargs']
    assert getargspec(Reference.__init__).defaults == (None,)
    assert getargspec(Reference.__init__).varargs == None
    assert getargspec(Reference.__init__).kwonlyargs == []
    assert getargspec(Reference.__init__).kwonlydefaults == None

# Generated at 2022-06-22 06:14:31.310810
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema()) == 0



# Generated at 2022-06-22 06:14:37.637859
# Unit test for constructor of class Schema
def test_Schema():
    try:
        class ExampleSchema(Schema):
            name = String()
            age = Integer()
    except TypeError as e:
        print(e)
    else:
        assert ExampleSchema.__name__ == 'ExampleSchema'
        assert ExampleSchema.fields == {
            'name': String(),
            'age': Integer()
        }


# Generated at 2022-06-22 06:14:45.394689
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    class A(Schema):
        a = Field(type_=int)
        b = Field(type_=str)

    class B(Schema):
        c = Field(type_=dict)
        d = Field(type_=str)

    with pytest.raises(AssertionError):
        class C(Schema):
            e = Field(type_=int)
            f = Field(type_=str)
        definitions['A'] = A
        definitions['B'] = B
        definitions['A'] = C


# Generated at 2022-06-22 06:14:57.376428
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test with a class definition
    class Pojo(Schema):
        a: int
        b: int

    pojo = Pojo(a=1, b=2)
    assert len(pojo) == 2

    # Test with a dictionary containing the class definition
    pojo_dict = {
        "a": 1,
        "b": 2
    }
    pojo = Pojo(pojo_dict)
    assert len(pojo) == 2

    # Test with a dictionary not containing the class definition
    pojo_dict = {
        "b": 2
    }
    pojo = Pojo(pojo_dict)
    assert len(pojo) == 1

    # Test with a object containing the class definition
    class Obj:
        a = 1
        b = 2

    pojo_obj = Obj()
   

# Generated at 2022-06-22 06:14:59.877877
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class MySchema(Schema):
        test_field = Field()
    assert hasattr(MySchema, 'fields')


# Generated at 2022-06-22 06:15:10.586071
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    def dict_():
        return dict()

    def dict_keywords():
        _dict = dict
        return _dict()

    def dict_kwargs():
        return dict(kwarg=dict)

    def dict__args_kwargs():
        _dict = dict
        return dict(_dict, kwarg=_dict)

    def dict_kwargs_args():
        _dict = dict
        return dict(kwarg=_dict, *[_dict])

    def dict_to_callable__args_kwargs():
        _dict = dict
        return _dict(_dict, kwarg=_dict)

    def dict_to_callable_kwargs_args():
        _dict = dict
        return _dict(kwarg=_dict, *[_dict])

    def SchemaDefinitions__call__():
        _SchemaDef

# Generated at 2022-06-22 06:15:14.836708
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    instance = SchemaDefinitions()
    instance['key'] = 'value'
    assert instance['key'] == 'value'
    try:
        assert instance['unknown_key']
    except KeyError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-22 06:15:18.042134
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    try:
        s = SchemaDefinitions(foo=1)
        assert s.get('foo') == 1
    except:
        return False
    return True



# Generated at 2022-06-22 06:15:22.628230
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions['first'] = 1
    # try to set the same definition twice
    try:
        definitions['first'] = 2
    except Exception as e:
        if e.__str__() != 'Definition for \'first\' has already been set.':
            raise AssertionError()

# Generated at 2022-06-22 06:15:32.796208
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Book(Schema):
        title = String()
        author = String()
        isbn = String()

    class School(Schema):
        books = Array(Reference(to='Book'))

    school = School(books=[Book(), Book()])
    assert school.books[0].title is None
    assert school.books[0].author is None
    assert school.books[0].isbn is None
    assert school.books[1].title is None
    assert school.books[1].author is None
    assert school.books[1].isbn is None
    
    school = School(books=[Book(title='title1', author='author1'), Book(title='title1', author='author1')])
    assert school.books[0].title == 'title1'
    assert school.books[0].author == 'author1'

# Generated at 2022-06-22 06:16:09.831621
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = Field()

    person = Person(name="Matt")
    assert person["name"] == "Matt"
    try:
        person["age"]
    except KeyError as error:
        assert error.args == ("age",)
    else:
        assert False


# Generated at 2022-06-22 06:16:19.909931
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import String, Integer
    assert SchemaMetaclass.__bases__ == (type,)
    class TestSchema(Schema):
        name = String()
        age = Integer()
    assert TestSchema.fields == {'name': String(), 'age': Integer()}
    assert TestSchema(name='freewind', age=18).__dict__ == {'name': 'freewind', 'age': 18, '_target': TestSchema}
    try:
        TestSchema(x=1)
    except TypeError:
        assert True
    else:
        assert False
    try:
        TestSchema()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 06:16:24.157335
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    a = SchemaDefinitions()
    assert len(a) == 0
    a['a'] = 1
    a['b'] = 2
    a['c'] = 3

    for k in a:
        assert k in ['a', 'b', 'c']


# Generated at 2022-06-22 06:16:31.442530
# Unit test for function set_definitions
def test_set_definitions():
    foo = Object(properties = {"a": Integer(), "b": Integer()})
    bar = Array(items = foo)
    definitions = SchemaDefinitions()
    for thing in [foo, bar]:
        set_definitions(thing, definitions)
    assert isinstance(foo.properties["a"], Integer)
    assert isinstance(foo.properties["b"], Integer)
    assert isinstance(bar.items, Object)
    assert isinstance(bar.items.properties["a"], Integer)
    assert isinstance(bar.items.properties["b"], Integer)

# Generated at 2022-06-22 06:16:32.723477
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
  pass


# Generated at 2022-06-22 06:16:39.522226
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Case: no definition is defined
    d = SchemaDefinitions()
    assert len(d) == 0

    # Case: a definition is added
    class Foo(Schema):
        bar = Field()
        baz = Field()
    d = SchemaDefinitions()
    d["foo"] = Foo
    assert len(d) == 1
    with pytest.raises(AssertionError):
        d["foo"] = Foo


# Generated at 2022-06-22 06:16:44.594322
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()

    schema_definitions.__setitem__('key', 'value')
    schema_definitions.__delitem__('key')
    try:
        schema_definitions.__getitem__('key')
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 06:16:55.124927
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Test(Schema):
        pass

    try:
        SchemaMetaclass("ClassName", (), {})
    except TypeError as e:
        assert e.args[0] == "Can't instantiate abstract class SchemaMetaclass with abstract methods fields"
    except Exception as e:
        assert False

    try:
        SchemaMetaclass("ClassName", (object,), {})
    except TypeError as e:
        assert e.args[0] == "Can't instantiate abstract class SchemaMetaclass with abstract methods fields"
    except Exception as e:
        assert False

    class Test2(Test):
        def __init__(self) -> None:
            self.a = None
            self.b = None


# Generated at 2022-06-22 06:16:59.914000
# Unit test for constructor of class Reference
def test_Reference():
    class HeroSchema(Schema):
        name = String()

    class VillanSchema(Schema):
        name = String()

    class SidekickSchema(Schema):
        name = String()

    class CharacterSchema(Schema):
        name = String()
        hero = Reference(HeroSchema)
        villain = Reference(VillanSchema)
        sidekick = Reference(SidekickSchema)

    assert CharacterSchema.validate(
        {"name": "Batman", "hero": {"name": "The Batman"}}
    ) == CharacterSchema(name="Batman", hero=HeroSchema(name="The Batman"))



# Generated at 2022-06-22 06:17:04.638751
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    try:
        Schema().__eq__(1)
    except TypeError as e:
        pass
    else:
        raise AssertionError("Expected Exception but no exception was raised")

    a = Schema()
    b = Schema()
    assert a.__eq__(b) == True
