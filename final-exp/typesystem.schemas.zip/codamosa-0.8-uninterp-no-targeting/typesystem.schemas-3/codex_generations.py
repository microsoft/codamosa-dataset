

# Generated at 2022-06-22 06:08:06.262680
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Child(Schema):
        field1 = String(min_length=1, max_length=255)
        field2 = String(max_length=255)
    child1 = Child({"field1":"field1", "field2":"field2"})
    child2 = Child({"field1":"field1", "field2":"field2"})
    assert (child1 == child2) == True


# Generated at 2022-06-22 06:08:16.081257
# Unit test for constructor of class Schema
def test_Schema():
    class SubSchema(Schema):
        color = Field(type=str, null=True)
    class MySchema(Schema):
        # Print the schema
        print("the schema is: ", MySchema)
        name = Field(type=str, max_length=255)
        age = Field(type=int, null=True)
        address = Field(type=str)
        sub_schema = SubSchema()
    # Create a class instance
    schema = MySchema(name="zixin", age=23, address="Nanjing University")
    # Print the created instance
    print("data instance is:", schema)
    # If __init__ runs successfully, it will print correct information 
    assert schema.name == "zixin"
    assert schema.age == 23

# Generated at 2022-06-22 06:08:21.901150
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Foo(Schema):
        int_field: typing.Any

    ref = Reference(to='Foo')
    foo = Foo(int_field=5)
    foo_dict = {'int_field': 5}

    assert(ref.serialize(foo) == foo_dict)


# Generated at 2022-06-22 06:08:24.894125
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class MySchema(Schema):
        pass
    print(MySchema)
    assert MySchema() == MySchema()
    MySchema.fields["id"] = Field(type=int)

# Generated at 2022-06-22 06:08:35.256201
# Unit test for constructor of class Schema
def test_Schema():
    # No value for required fields
    try:
        state = Schema()
    except TypeError as e:
        assert(str(e) == 'name is a required argument for Schema()')

    # Non-string values for string-valued fields
    try:
        state = Schema(name=0)
    except TypeError as e:
        assert(str(e) == '0 is not of type str')
    try:
        state = Schema(name=True)
    except TypeError as e:
        assert(str(e) == 'True is not of type str')
    try:
        state = Schema(name={})
    except TypeError as e:
        assert(str(e) == 'dict is not of type str')

    # Non-numeric values for numeric-valued fields

# Generated at 2022-06-22 06:08:43.273696
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class SchemaA(Schema):
        name = str
        age = int
        gender = str

        def __repr__(self):
            return "SchemaA(name=%s, age=%d, gender=%s)" \
                % (self.name, self.age, self.gender)

    a = SchemaA(name='Tom', age=10, gender='male')
    assert a.__repr__() == "SchemaA(name=Tom, age=10, gender=male)"


# Generated at 2022-06-22 06:08:47.782821
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Point(Schema):
        x = Float()
        y = Float()
    point = Point(x=2.0, y=3.0)
    point1 = Point(x=2.0, y=3.0)
    if point != point1:
        raise Exception("Couldn't compare two objects of the same class.")
    if point == point1:
        print("Comparison successful.")


# Generated at 2022-06-22 06:08:50.763705
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Demo(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")

    demo = Demo(field1="value1", field2=None)

    assert demo["field1"] == "value1"
    assert demo["field2"] == None

# Generated at 2022-06-22 06:08:58.902633
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import Integer, String
    class User(Schema):
        id = Integer()
        name = String(max_length=100)
    class UserRef(Schema):
        user = Reference(User)
    ref = UserRef(user={"name": "Alice", "id": 123})
    print(ref)
    print(type(ref))
    print(type(ref.user))

if __name__ == "__main__":
    test_Reference_validate()

# Generated at 2022-06-22 06:09:02.118362
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    attrs = {'name': "test"}
    test_obj = Schema(attrs)

    result = Reference("test").serialize(test_obj)
    assert result == attrs

# Generated at 2022-06-22 06:09:16.274194
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    test_definitions = SchemaDefinitions()

    test_definitions["a"] = Field()
    test_definitions["b"] = Field()

    assert test_definitions["a"] == Field()
    assert test_definitions["b"] == Field()



# Generated at 2022-06-22 06:09:17.643216
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    instance = SchemaDefinitions()
    assert len(instance) == 0


# Generated at 2022-06-22 06:09:25.699475
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class SimpleSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=130)

    assert SimpleSchema.fields["name"] == String(max_length=100)
    assert SimpleSchema.fields["age"] == Integer(minimum=0, maximum=130)
    assert len(SimpleSchema.fields) == 2


# Generated at 2022-06-22 06:09:32.069186
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test is_sparse=False
    a = Schema(a=1, b=2, c=3)
    assert len(a) == 3
    # Test is_sparse=True
    a = Schema(a=1, b=2)
    assert len(a) == 2

# Generated at 2022-06-22 06:09:35.144500
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String

    class Product(Schema):
        name = String()

    assert set(Product()) == set()
    assert set(Product(name="Wombat")) == {"name"}



# Generated at 2022-06-22 06:09:40.335099
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import Number
    from datetime import datetime

    class UserSchema(Schema):
        id = Number()
        email = Number()
        name = Number()
        created_at = Number()

    user = UserSchema(id=1, email='admin@gmail.com', created_at=datetime.now())
    assert repr(user) == "UserSchema(id=1, email='admin@gmail.com')"


# Generated at 2022-06-22 06:09:42.964405
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Init
    definitions = SchemaDefinitions()

    # Act
    result = len(definitions)

    # Assert
    assert result == 0


# Generated at 2022-06-22 06:09:50.859143
# Unit test for method validate of class Reference
def test_Reference_validate():
    definition_example = SchemaDefinitions(
        {
            "example_1": Array,
            "example_2": Array(
                items=Object(
                    properties={"key_1": Integer(default=1), "key_2": String()}
                )
            ),
        }
    )
    assert Reference(
        "example_1", definitions=definition_example
    ).validate([]) == []
    assert Reference(
        "example_1", definitions=definition_example
    ).validate([1, 2]) == [1, 2]
    assert Reference(
        "example_2", definitions=definition_example
    ).validate([{"key_1": 10, "key_2": "value"}]) == [
        {"key_1": 10, "key_2": "value"}
    ]

# Generated at 2022-06-22 06:09:54.328882
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    a = SchemaDefinitions(b = 2)
    try:
        a[1]
        return False
    except KeyError as e:
        return str(e) == "'1'"


# Generated at 2022-06-22 06:09:57.437850
# Unit test for constructor of class Reference
def test_Reference():
    assert isinstance(Reference(to=int), Reference)


# Generated at 2022-06-22 06:10:16.608896
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from collections import OrderedDict
    from datetime import date
    from decimal import Decimal as D
    from typesystem import Schema, String, Integer, Number, Date, Time, Choice, Boolean

    class Product(Schema):
        name = String()
        price = Number()

    class Order(Schema):
        customer_name = String()
        placed_at = Date()
        shipped_at = Date(required=False)
        products = Array(of=Reference("Product"))
        total_price = Number()

    class Shipment(Schema):
        # For ease of testing, this is being initialized with a list.
        products = [
            {"name": "ham", "price": D("0.99")},
            {"name": "cheese", "price": D("2.99")},
        ]
        ready_at = Time

# Generated at 2022-06-22 06:10:23.009360
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class Book(Schema):
        title = Field(allow_null=True)
        author = Field(allow_null=True)

    class Author(Schema):
        name = Field()

    class User(Schema):
        favourite_books = Reference(to="Book", allow_null=True)
        favourite_author = Reference(to=Author)

    set_definitions(User.make_validator(), definitions)
    assert definitions["Book"] == Book
    assert definitions["Author"] == Author

# Generated at 2022-06-22 06:10:25.734867
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    with pytest.raises(AssertionError):
        definitions['test'] = 'test'


# Generated at 2022-06-22 06:10:36.522143
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class InnerField1(Field):
        pass

    class InnerField2(Field):
        pass

    class InnerSchema1(Schema):
        field1 = InnerField1()
        field2 = InnerField2()

    class InnerSchema2(Schema):
        field1 = InnerField1()
        field2 = InnerField2()
        field3 = InnerField1()

    class InnerSchema3(Schema):
        field1 = InnerField1()
        field2 = InnerField2()
        field3 = InnerField1()
        field4 = InnerSchema1()
        field5 = InnerSchema2()

    class InnerSchema4(Schema):
        field1 = InnerField1(has_default=True)
        field2 = InnerField2(has_default=False)

# Generated at 2022-06-22 06:10:41.035180
# Unit test for method __len__ of class Schema
def test_Schema___len__():
  class Testschema(Schema):
    field1 = Field()
    field2 = Field()

  # A new object of class Testschema has 2 length if it is fully populated
  assert len(Testschema(field1=1, field2=2)) == 2


# Generated at 2022-06-22 06:10:43.156432
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    
    assert len(definitions) == 0


# Generated at 2022-06-22 06:10:44.593569
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    SchemaDefinitions()
    SchemaDefinitions([], {})


# Generated at 2022-06-22 06:10:49.760898
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.schema import Schema

    class ObjectSchema(Schema):
        one = Field(type='str')
        two = Field(type='str')

    one = ObjectSchema(one='one', two='two')
    two = ObjectSchema(one='one', two='two')
    assert one == two



# Generated at 2022-06-22 06:10:56.275494
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema = Schema(
        {"name": "Jeff", "age": 25},
        definitions={
            "Person": Schema(
                {"name": Field(str), "age": Field(int)}, definitions=None
            )
        },
    )
    schema2 = schema.validate_or_error(schema)
    assert len(schema2.value) == 2


# Generated at 2022-06-22 06:10:57.787745
# Unit test for constructor of class Reference
def test_Reference():
    y = Reference('asdf')
    assert y.to == 'asdf'


# Generated at 2022-06-22 06:11:24.612436
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    class UserSchema(Schema):
        username = String(title="Username", description="A name.")
        password = String(title="Password", description="A password.")

    class PostSchema(Schema):
        id = Integer(title="Id", description="A unique integer.")
        user = Reference(UserSchema, title="User", description="A user.")

    class CommentSchema(Schema):
        id = Integer(title="Id", description="A unique integer.")
        user = Reference(UserSchema, title="User", description="A user.")

    class GroupSchema(Schema):
        name = String(title="Name", description="A unique name.")
        posts = Array(Reference(PostSchema, title="Post", description="A post."))

# Generated at 2022-06-22 06:11:31.833790
# Unit test for method validate of class Reference
def test_Reference_validate():
    dix = {
        'myStr': 'a string',
        'myInt': 42
    }
    assert(Reference('mySchema').validate(dix) == {
        'myStr': 'a string',
        'myInt': 42
    })

    class mySchema(Schema):
        myStr = String()
        myInt = Integer()

    assert(Reference(mySchema).validate(dix) == {
        'myStr': 'a string',
        'myInt': 42
    })

# Generated at 2022-06-22 06:11:35.209610
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    my_map = dict(a=1, b=2, c=3)
    schema_definitions = SchemaDefinitions(my_map)
    assert len(schema_definitions) == 3


# Generated at 2022-06-22 06:11:43.792461
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    results = []
    result = ""
    schema = Schema(value = "value")
    schema1 = Schema(value = "value1")
    schema2 = Schema(value = "value2")
    schema3 = Schema(value = "value3")
    for result in schema:
        results.append(result)
    for result in schema1:
        results.append(result)
    for result in schema2:
        results.append(result)
    for result in schema3:
        results.append(result)
    assert results == ["value", "value1", "value2", "value3"], "result is not correct"


# Generated at 2022-06-22 06:11:51.991133
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer(minimum=0)

    p = Person(dict(name='michael', age=16))
    assert p.name == 'michael'
    assert p.age == 16


# Generated at 2022-06-22 06:12:00.236831
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Referenced(Schema):
        a = Field(type="string")

    class ValidReference(Schema):
        r = Reference(to=Referenced)

    r = Referenced(a="foo")
    v = ValidReference(r=r)
    assert isinstance(v.r, Referenced)
    assert v.r.validate() == r.validate()
    assert v.validate() == r.validate()
    assert ValidReference.validate(r) == r.validate()
    assert v.validate_or_error() == r.validate()

# Generated at 2022-06-22 06:12:08.135033
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schema_foo = SchemaDefinitions({"foo": "bar"})
    assert(schema_foo["foo"] == "bar")
    schema_foo.__setitem__("baz", "qux")
    assert(schema_foo["baz"] == "qux")
    schema_foo.__delitem__("baz")
    def expected_exception():
        # "baz" does not exist, and thus should throw a KeyError
        schema_foo["baz"]
        return
    try:
        expected_exception()
    except KeyError as e:
        pass
    else:
        print("No exception thrown")

# Generated at 2022-06-22 06:12:10.612935
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    result = len(obj)
    assert isinstance(result, int)


# Generated at 2022-06-22 06:12:19.076808
# Unit test for constructor of class Reference
def test_Reference():
    to = 'string'
    definitions = {'string': ""}
    allow_null = False
    field = Reference(to, definitions, allow_null)
    assert field.to == to
    assert field.definitions == definitions
    assert field.allow_null == allow_null

if __name__ == "__main__":
    test_Reference()

# Generated at 2022-06-22 06:12:23.738335
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference(to=1, definitions=None)
    assert ref.to == 1
    assert ref.definitions == None
    assert ref._target_string == None
    assert ref._target == None
    assert ref.allow_null == False
    assert ref.errors == {"null": "May not be null."}


# Generated at 2022-06-22 06:12:39.843282
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    assert len(obj) == 0


# Generated at 2022-06-22 06:12:51.556030
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="Dylan", age=29)
    assert person == Person(name="Dylan", age=29)
    assert person != Person(name="Bob", age=29)
    assert person["age"] == 29
    assert person["name"] == "Dylan"
    assert person.serialize() == {"age": 29, "name": "Dylan"}

    # try:
    #     person.validate(None)
    # except ValidationError as error:
    #     assert error.messages()[0].text == "May not be null."
    # else:
    #     raise AssertionError("Should have raised.")

    definitions = SchemaDefinitions()

    class Movie(Schema):
        title = String()
        director

# Generated at 2022-06-22 06:12:56.160223
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    # Test method __len__ for an empty class
    class Empty(Schema):
        pass

    assert len(Person()) == 0
    assert len(Empty()) == 0
    assert len(Person({"name": "John Doe", "age": 42})) == 2



# Generated at 2022-06-22 06:13:05.754301
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = String()
        b = String(default="2")
        d = String()
    schema = TestSchema(a="1", d="4")
    assert repr(schema) == "TestSchema(a='1', b='2', d='4')"
    schema.b = "3"
    assert repr(schema) == "TestSchema(a='1', b='3', d='4')"
    schema.b = "2"
    assert repr(schema) == "TestSchema(a='1', d='4')"

# Generated at 2022-06-22 06:13:10.449222
# Unit test for function set_definitions
def test_set_definitions():
    class User(Schema):
        id = Integer()
    class Task(Schema):
        assigned_to = Reference(User)

    definitions = SchemaDefinitions()
    definitions[User.__name__] = User
    set_definitions(Task.assigned_to, definitions)
    assert Task.assigned_to.target == User

# Generated at 2022-06-22 06:13:14.818369
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Model(Schema):
        id = Field(type='integer')

    model = Model(id=100)
    assert list(model.__iter__()) == ['id']
    model = Model()
    assert list(model.__iter__()) == []


# Generated at 2022-06-22 06:13:19.985578
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
        gender = String()

    p = Person({'name': 'Carl', 'age': 30, 'gender': 'male'})
    assert p.__repr__() == 'Person(name="Carl", age=30, gender="male")'

# Generated at 2022-06-22 06:13:24.478244
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    try:
        from collections.abc import Iterator
    except ImportError:
        from collections import Iterator
    defs = SchemaDefinitions({"foo": "bar"})
    assert isinstance(defs.__iter__(), Iterator)
    assert "foo" in defs


# Generated at 2022-06-22 06:13:34.291888
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions['key'] = 1
    
    try:
        del schema_definitions['key1']
    except KeyError as e:
        assert str(e) == "'key1'"
    else:
        assert False

    assert len(schema_definitions) == 1
    assert {'key': 1} == dict(schema_definitions)

    del schema_definitions['key']
    assert len(schema_definitions) == 0
    assert {} == dict(schema_definitions)


# Generated at 2022-06-22 06:13:39.802233
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    obj = dict(foo = 1)
    reference = Reference(to = 'foo')
    assert reference.serialize(obj) == dict(foo = 1)
    assert reference.serialize(None) == None

# Generated at 2022-06-22 06:14:08.720166
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema({"name": "Homer Simpson", "age": 38})) == "Schema(name='Homer Simpson', age=38)"

test_Schema___repr__()

# Generated at 2022-06-22 06:14:14.714601
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        id = Field(type="string")
        name = Field(type="string")
        age = Field(type="integer")
    value = TestSchema(name="joe")
    lst = [i for i in value]
    assert (lst == ["name"])


# Unit tests for method __repr__ of class Schema

# Generated at 2022-06-22 06:14:18.547599
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    definitions = SchemaDefinitions({"A": 1})
    assert len(definitions) == 1
    definitions["B"] = 2
    assert len(definitions) == 2

# Generated at 2022-06-22 06:14:28.062131
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    try:
        assert len(s) == 0
    except Exception:
        print("Constructor of class SchemaDefinitions did not work properly")
        return [0]
    s = SchemaDefinitions([(1, "a"), (2, "b")], c = "c", d = "d")
    try:
        assert len(s) == 4
    except Exception:
        print("Constructor of class SchemaDefinitions did not work properly")
        return [0]
    del s[1]
    try:
        assert len(s) == 3
    except Exception:
        print("Constructor of class SchemaDefinitions did not work properly")
        return [0]
    return [1]


# Generated at 2022-06-22 06:14:31.655357
# Unit test for constructor of class Reference
def test_Reference():
    class test_Reference(Reference):
        errors = {"null": "May not be null."}

        def __init__(self):
            super(Reference, self).__init__("test_type")
    return test_Reference()

# Generated at 2022-06-22 06:14:34.323304
# Unit test for method __len__ of class Schema
def test_Schema___len__():
	class Bar(Schema):
		bar = Field(type="number")

	class Foo(Schema):
		foo = Field(type="number")
		bar = Field(type=Bar)

	foo = Foo(foo=1, bar=Bar(bar=2))

	assert len(foo) == 2


# Generated at 2022-06-22 06:14:38.166384
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
    class Bar(Schema):
        bar = int

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert Foo.fields["foo"].definitions is definitions

# Generated at 2022-06-22 06:14:45.246321
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    '''
    >>> from string import ascii_letters, digits
    >>> class User(Schema):
    ...   name = String(min_length=3, max_length=50)
    ...   age = Integer()
    >>> schema_iter = iter(User)
    >>> next(schema_iter)
    'name'
    >>> next(schema_iter)
    'age'
    >>> try:
    ...    next(schema_iter)
    ... except StopIteration as e:
    ...     e
    '''


# Generated at 2022-06-22 06:14:50.463688
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()
    try:
        obj = schema_definitions["foo"]
    except:
        pass
    assert obj is None

# Generated at 2022-06-22 06:14:57.733877
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import Number, String

    class Example(Schema):
        age = Number()
        name = String()

    assert isinstance(Example.fields.get("age"), Number)
    assert isinstance(Example.fields.get("name"), String)
    example = Example(age=40, name="Bob")
    assert isinstance(example, Example)
    assert hasattr(example, "age")
    assert hasattr(example, "name")
    assert example.age == 40
    assert example.name == "Bob"
    assert example["age"] == 40
    assert example["name"] == "Bob"
    assert example.is_sparse is False
    assert example == Example(age=40, name="Bob")
    assert example != Example(age=40, name="Alice")



# Generated at 2022-06-22 06:15:20.772352
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        name = String()
        age = Integer()

    metrics = Person.make_validator()
    assert isinstance(metrics, Object)
    assert len(metrics.properties) == 2
    assert "name" in metrics.properties
    assert isinstance(metrics.properties["name"], String)
    assert "age" in metrics.properties
    assert isinstance(metrics.properties["age"], Integer)
    assert len(metrics.required) == 2
    assert "name" in metrics.required
    assert "age" in metrics.required


# Generated at 2022-06-22 06:15:29.688530
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import Integer, String
    from typesystem.schema import Schema

    class Thing(Schema):
        name = String()
        age = Integer()

        class Meta:
            # does nothing, but this is a kwarg of SchemaMetaclass
            strict = False

    thing = Thing(name="bob", age=42)
    assert thing.is_sparse is False

    assert 42 == thing["age"]
    assert thing.age == 42

    iterable = iter(thing)
    index = 0
    for key in iterable:
        if index == 0:
            assert "name" == key
        else:
            assert "age" == key
        index += 1



# Generated at 2022-06-22 06:15:33.593630
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        num = Field(type_class=int)

    a = A(num=5)
    assert(a == A(num=5))
    a = A({'num': 5})
    assert(a == A({'num': 5}))


# Generated at 2022-06-22 06:15:39.756386
# Unit test for function set_definitions
def test_set_definitions():
    class Item(Schema):
        name = Field(type="string")

    class User(Schema):
        name = Field(type="string")
        item = Reference(to=Item.__name__)

    definitions = SchemaDefinitions()

    assert User.fields["item"].definitions is None
    set_definitions(User.fields["item"], definitions)
    assert User.fields["item"].definitions is not None
    assert User.fields["item"].definitions == definitions

# Generated at 2022-06-22 06:15:50.910024
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass(Schema):
        desc = "A simple class"
        field1 = String(min_length=6)
        field2 = Integer(minimum=7)

    assert isinstance(TestSchemaMetaclass.fields, dict)
    assert len(TestSchemaMetaclass.fields) == 2

    # Check if fields are sorted by their position in source code
    assert list(TestSchemaMetaclass.fields.keys()) == ["field1", "field2"]

    # Check if the constructor of a Schema class accepts a dict
    test_data1 = {"field1": "abcdef", "field2": 8}
    instance1 = TestSchemaMetaclass(test_data1)
    assert isinstance(instance1, TestSchemaMetaclass)
    assert instance1.field1 == "abcdef"

# Generated at 2022-06-22 06:15:53.870757
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    schema_definitions = SchemaDefinitions()

    key = "key"
    value = "value"
    schema_definitions["key"] = "value"
    assert schema_definitions[key] == value

# Generated at 2022-06-22 06:16:01.799361
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import Boolean, Integer, String


    class AnimalSchema(Schema):
        name = String()
        type = String()
        limb_count = Integer()


    class Animal(AnimalSchema):
        pass


    class Dog(Animal):
        animal_type = "dog"
        tail_length = Integer()


    class Cat(Animal):
        animal_type = "cat"
        declawed = Boolean()


    definitions = SchemaDefinitions()
    dog = Dog(name="fido", type="dog", limb_count=4, tail_length=10)
    cat = Cat(name="fluffy", type="cat", limb_count=4, declawed=True)
    animal = Reference(Animal, definitions=definitions)
    dog_animal = animal.validate(dog)
    cat_animal

# Generated at 2022-06-22 06:16:04.596098
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions({"A": "a", "B": "b"})
    assert definitions["A"] == "a"


# Generated at 2022-06-22 06:16:06.604522
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # assert False, "TODO: implement!"
    pass


# Generated at 2022-06-22 06:16:10.802586
# Unit test for method serialize of class Reference
def test_Reference_serialize():
	REFERENCE_INSTANCE = Reference('schema1')
	assert REFERENCE_INSTANCE.serialize(None) is None
	assert REFERENCE_INSTANCE.serialize({'a':1}) == {'a':1}



# Generated at 2022-06-22 06:16:30.357735
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    s = SchemaDefinitions()
    definition_key = 'definition_key'
    definition_value = 'definition_value'
    s[definition_key] = definition_value
    assert isinstance(s, MutableMapping)
    assert isinstance(s, Mapping)
    assert s[definition_key] == definition_value



# Generated at 2022-06-22 06:16:34.857640
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    class P:
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            pass
    definitions = SchemaDefinitions()
    definitions["p"] = P
    assert len(definitions) == 1


# Generated at 2022-06-22 06:16:39.247768
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions["abc"] = "abc"
    del definitions["abc"]
    # The definition is deleted from definitions
    assert "abc" not in definitions
    # The del operation does not raise any exception
    del definitions["abc"]


# Generated at 2022-06-22 06:16:51.657068
# Unit test for constructor of class Reference
def test_Reference():
    class Character(Schema):
        first_name = Field(type=str)
        last_name = Field(type=str)
        age = Field(type=int)

    class User(Schema):
        name = Reference(to="Character")
        title = Field(type=str)

    u = User(name=Character(first_name="John", last_name="Smith", age=24), title="student")
    assert u.name.first_name == "John"
    assert u.name.last_name == "Smith"
    assert u.name.age == 24
    assert u.title == "student"

    assert User.name.target_string == "Character"
    assert u.name.target_string == "Character"
    assert User.name.target.__name__ == "Character"
    assert u.name.target

# Generated at 2022-06-22 06:16:55.040583
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["Test"] = 1
    assert definitions["Test"] == 1
    definitions["Test"] = 2


# Generated at 2022-06-22 06:16:58.114533
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    some_data = 1
    definition = SchemaDefinitions({'a':some_data,'b':some_data,'c':some_data})
    for i in definition:
        if i not in {'a','b','c'}:
            return False
    return True


# Generated at 2022-06-22 06:17:10.167266
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema()) == "Schema()"
    assert repr(Schema(id=1)) == "Schema(id=1)"
    assert repr(Schema(id=1, name="n")) == "Schema(id=1, name='n')"
    assert repr(Schema(id=1, name="n", is_active=False)) == "Schema(id=1, name='n', is_active=False)"
    assert repr(Schema(id=1, name="n", is_active=False, items=[])) == "Schema(id=1, name='n', is_active=False, items=[])"

# Generated at 2022-06-22 06:17:13.629349
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    assert len(SchemaDefinitions()) == 0

# Generated at 2022-06-22 06:17:19.845531
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Schema1(Schema):
        name = fields.String(allow_null=True)
        age = fields.Integer(allow_null=True)

    if (len(Schema1()) != 0):
        return False
    if not (Schema1(name="Amy", age=32) == Schema1(name="Amy", age=32)):
        return False

    return True


# Generated at 2022-06-22 06:17:25.729576
# Unit test for constructor of class Schema
def test_Schema():
    """
    Schema is an abstract class that defines the interface
    and provides some simple defaults.
    """
    class Foo(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        # Change to age = Field(type="number") and you'll see the error
        # that you expect.
        # In this case the error is:
        # AttributeError: 'Foo' object has no attribute 'age'
        # rather than:
        # TypeError: age must be a number.

    my_foo = Foo(name="Tim", age=49)
    assert my_foo.name == "Tim"
    assert my_foo.age == 49

    # There is also a simple test for `schema2.py` in
    # `tests/test_schema.py`

# Unit test