

# Generated at 2022-06-22 06:07:50.867736
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions({"key1": "value1", "key2": "value2"})
    assert set(definitions.__iter__()) == set(["key1", "key2"])


# Generated at 2022-06-22 06:07:53.667678
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # TODO: Implement test.
    raise NotImplementedError()


# Generated at 2022-06-22 06:07:57.080892
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Schema1(Schema):
        date_created_ = DateTime()
        date_updated_ = DateTime()
        user_id_ = UUID()
    assert len(Schema1()) == 3


# Generated at 2022-06-22 06:07:59.980581
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    """Test __delitem__ method of SchemaDefinitions class"""
    # Arrange
    # TODO
    # Act
    # TODO
    # Assert
    # TODO



# Generated at 2022-06-22 06:08:05.821129
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.fields import String

    class Person(Schema):
        first_name = String(max_length=100)
        last_name = String(max_length=100)

    person = Person(first_name="Jane", last_name="Doe")
    assert person.first_name == "Jane"
    assert person.last_name == "Doe"



# Generated at 2022-06-22 06:08:07.291227
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert False # TODO: implement your test here


# Generated at 2022-06-22 06:08:08.777120
# Unit test for constructor of class Reference
def test_Reference():
    assert hasattr(Reference, '__init__')
test_Reference()


# Generated at 2022-06-22 06:08:18.984586
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test for case in which the input argument is of class 'Schema'
    import bson
    import datetime
    import dateutil.tz
    import decimal
    import doctest
    import re
    import sys
    import uuid
    from bson.binary import Binary, UUID_SUBTYPE
    from bson.codec_options import DEFAULT_CODEC_OPTIONS, TypeCodec, CodecOptions
    from bson.dbref import DBRef
    from bson.errors import BSONError, InvalidDocument
    from bson.int64 import Int64
    from bson.json_util import CANONICAL_JSON_OPTIONS, JSONOptions, RELAXED_JSON_OPTIONS
    from bson.max_key import MaxKey
    from bson.min_key import MinKey

# Generated at 2022-06-22 06:08:28.459320
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd1 = SchemaDefinitions()
    sd2 = SchemaDefinitions()
    sd2["schema2"] = "s2"
    sd1["schema1"] = "s1"
    assert "schema1" in sd1
    assert "schema2" in sd2
    assert "schema1" not in sd2
    assert "schema2" not in sd1
    # this should raise an exception:
    # sd1["schema1"] = "x"
    sd1["schema3"] = "s3"
    del sd1["schema1"]
    assert "schema1" not in sd1



# Generated at 2022-06-22 06:08:32.847990
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema, definitions=SchemaDefinitions()):
        a = Float()

    assert len(A.fields) == 1
    assert isinstance(A.fields["a"], Float)
    assert len(A.definitions) == 1
    assert A.definitions["A"] is A


# Generated at 2022-06-22 06:08:53.805159
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    s = SchemaDefinitions()
    assert isinstance(s, MutableMapping)
    assert isinstance(s, collections.abc.Mapping)
    assert len(s) == 0
    assert s == {}
    s["key1"] = 1
    assert len(s) == 1
    assert s == {"key1": 1}
    s["key2"] = 2
    assert len(s) == 2
    assert s == {"key1": 1, "key2": 2}
    del s["key1"]
    assert len(s) == 1
    assert s == {"key2": 2}



# Generated at 2022-06-22 06:08:56.879674
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String

    class Comment(Schema):
        content = String()

    definitions = SchemaDefinitions()
    cls = SchemaMetaclass('a', (), {}, definitions=definitions)

    assert 'Comment' in definitions


# Generated at 2022-06-22 06:09:00.535434
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class R(Schema):
        a = int
    r = R(a=1)
    assert len(r) == 1
    # Implicitly test the Message class of typesystem
    r = R()
    assert val_messages(r) == ["Schema has no attribute 'a'."]
    assert len(r) == 0


# Generated at 2022-06-22 06:09:11.206110
# Unit test for constructor of class Schema
def test_Schema():
    import collections
    import typing
    from abc import ABCMeta
    from collections.abc import Mapping, MutableMapping
    from typesystem.base import ValidationError, ValidationResult
    from typesystem.fields import Array, Field, Object
    from typesystem.schema import set_definitions, SchemaDefinitions, SchemaMetaclass, Reference

    def set_definitions(field: Field, definitions: SchemaDefinitions) -> None:
        """
        Recursively set the definitions that string-referenced `Reference` fields
        should use.
        """
        if isinstance(field, Reference) and field.definitions is None:
            field.definitions = definitions

# Generated at 2022-06-22 06:09:12.045292
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert True
    # This is a stub

# Generated at 2022-06-22 06:09:22.737889
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    import sys
    import pytest
    import typesystem

    attempts = 0
    while True:
        attempts += 1
        if attempts > 10:
            raise Exception("Recursion limit reached.")
        try:
            break
        except RecursionError:
            sys.setrecursionlimit(sys.getrecursionlimit() * 2)

    class TestSchemaDefinitions___iter__:
        """Unit test for method __iter__ of class SchemaDefinitions."""

        def test_SchemaDefinitions___iter__(self) -> None:
            """Test method __iter__ of class SchemaDefinitions"""

            class TestSchema(typesystem.Schema):
                int_field = typesystem.Integer()

            definitions = typesystem.SchemaDefinitions()

            assert len(definitions) == 0

            definitions["test_schema"] = TestSche

# Generated at 2022-06-22 06:09:28.602496
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema_definitions = SchemaDefinitions()
    key = None
    value = None

    # Test with a key already set
    try:
        assert key not in schema_definitions._definitions
        schema_definitions._definitions[key] = value
        schema_definitions[key] = value
        assert False
    except AssertionError:
        pass

    # Test with a key not set
    try:
        assert key not in schema_definitions._definitions
        schema_definitions[key] = value
        assert schema_definitions._definitions[key] == value
        assert True
    except AssertionError:
        assert False



# Generated at 2022-06-22 06:09:38.722471
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    class DemoClass:
        __qualname__ = 'test_SchemaDefinitions___delitem___<locals>.DemoClass'

        def __init__(self, demo: typing.Any):
            self.demo = demo

    init = {'is_delete': True, 'demo': 'demo'}
    definition = DemoClass(init)
    schema_definition = SchemaDefinitions({})
    schema_definition['DemoClass'] = definition
    assert definition.demo == schema_definition['DemoClass'].demo
    del schema_definition['DemoClass']
    with pytest.raises(KeyError) as exception_info:
        schema_definition['DemoClass']
    assert 'DemoClass' == exception_info.value.args[0]


# Generated at 2022-06-22 06:09:44.120453
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema1(Schema):
        first_name = String(max_length=100)
        last_name = String(max_length=100)

    t1 = TestSchema1({'first_name': 'John', 'last_name': 'Smith'})
    assert t1['first_name'] == 'John'
    assert t1['last_name'] == 'Smith'
    assert len(t1) == 2


# Generated at 2022-06-22 06:09:50.954184
# Unit test for constructor of class Schema
def test_Schema():
    import datetime

    class Person(Schema):
        name = String()
        age = Integer()
        dob = DateTime()
        title = String(default="My Title")

    p1 = Person(name="Bob", age=10, dob="1983-06-18")
    p2 = Person(name="Bob", age=10, dob=datetime.datetime(1983, 6, 18))

    assert p1.name == "Bob"
    assert p1.age == 10
    assert p1.dob == datetime.datetime(1983, 6, 18)
    assert p1.dob == p2.dob
    assert p1.title == "My Title"



# Generated at 2022-06-22 06:10:01.637922
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sd = SchemaDefinitions()
    assert (len(sd) == 0)
    sd['a'] = 'b'
    assert (len(sd) == 1)
    assert (sd['a'] == 'b')


# Generated at 2022-06-22 06:10:06.079333
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Todo(Schema):
        name = Field(type=str, required=True)
        done = Field(type=bool, required=False)
    A = Todo({"name": "write code", "done": False})
    B = Todo({"name": "write code", "done": True})
    assert A != B



# Generated at 2022-06-22 06:10:10.971739
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Foo(Schema):
        a = Field(type="string")
        b = Field(type="string")

    foo = Foo(a="Hello", b="World")

    assert repr(foo) == "Foo(a='Hello', b='World')"

# Generated at 2022-06-22 06:10:23.086241
# Unit test for method validate of class Reference
def test_Reference_validate():
    from unittest import TestCase
    from typesystem.definitions import String, Integer
    class TestSchema(Schema):
        field = String(required=True)
        other_field = Integer(maximum=100)

    field = Reference(to=TestSchema)

    # test a valid value
    value = {"field": "test", "other_field": 10}
    assert field.validate(value) == value

    # test a value with an extra field
    value = {"field": "test", "other_field": 10, "extra_field": "test"}
    try:
        field.validate(value)
    except ValidationError as e:
        assert e.error_code == 'additional_properties'
    else:
        raise AssertionError('Validation should have failed')

    # test a value with a missing

# Generated at 2022-06-22 06:10:34.878013
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    class Foo():
        pass
    foo = Foo()
    foo.name = "foo"
    foo.class_name = "Foo"
    foo.method_name = "__delitem__"
    foo.instance_count = 1
    foo.method_count = 1
    foo.test_arguments = {}
    foo.test_results = {}

# Generated at 2022-06-22 06:10:41.155499
# Unit test for constructor of class Reference
def test_Reference():
    # Test the default constructor of the class Reference
    with pytest.raises(Exception):
        Reference(to=123)
    with pytest.raises(Exception):
        Reference(to="test")
    with pytest.raises(Exception):
        Reference(to="test", definitions = {"test": "test"})


# Generated at 2022-06-22 06:10:46.737019
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import pytest
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    p = Person(name="John")
    assert p["name"] == "John"
    with pytest.raises(KeyError) as excinfo:
        p["age"]
    assert str(excinfo.value) == "'age'"



# Generated at 2022-06-22 06:10:53.789017
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Setup
    class ExampleSchema(Schema):
        """
        Example schema for testing the metaclass.
        """
        name = Field(type='string')
        age = Field(type='integer', minimum=0, maximum=150)
        height = Field(type='integer', minimum=0, maximum=250)

    example = ExampleSchema(name='Lucy', age=18, height=170)
    assert example.name == 'Lucy'
    assert example.age == 18
    assert example.height == 170
    # Teardown


# Generated at 2022-06-22 06:11:00.478415
# Unit test for constructor of class Schema
def test_Schema():
    class Child(Schema):
        name = Field(type="string")
        age = Field(type="string")
        
    class Parent(Schema):
        name = Field(type="string")
        age = Field(type="string")
        child = Reference("Child")
    
    child = Child({'name': 'Tom', 'age': '6'})
    parent = Parent(name="John", age="20", child=child)
    assert parent['name'] == 'John'
    assert parent['age'] == '20'
    assert parent['child']['name'] == 'Tom'
    assert parent['child']['age'] == '6'
    
    

# Generated at 2022-06-22 06:11:08.092668
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference.__init__.__defaults__ == (None,)


Reference.__init__.__defaults__ == (None,)
definitions = SchemaDefinitions()
test_SchemaMetaclass = SchemaMetaclass("test_SchemaMetaclass", (), {"test": 1}, definitions)
assert test_SchemaMetaclass is not object
assert test_SchemaMetaclass.test == 1
assert len(definitions) == 1
assert definitions[test_SchemaMetaclass.__name__] is test_SchemaMetaclass


# Generated at 2022-06-22 06:11:23.787085
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert Schema().__repr__() == "Schema()"

# Generated at 2022-06-22 06:11:33.344408
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    def1 = {'obj1': 'classA', 'obj2': 'classB'}
    def2 = {'obj3': 'classC'}
    new_SchemaDefinitions = SchemaDefinitions(def1)
    new_SchemaDefinitions.__setitem__('obj4', 'classD')
    assert new_SchemaDefinitions._definitions == {'obj1': 'classA', 'obj2': 'classB', 'obj4': 'classD'}
    new_SchemaDefinitions.__setitem__('obj4', 'classD')
    assert new_SchemaDefinitions._definitions == {'obj1': 'classA', 'obj2': 'classB'}

# Generated at 2022-06-22 06:11:44.485503
# Unit test for constructor of class Schema
def test_Schema():
    class User(Schema):
        username = String()
        full_name = String(allow_null=True)

    user = User(username="john", full_name=None)
    assert user.username == "john"
    assert user.full_name is None
    assert user.is_sparse is False

    user = User(dict(username="john", full_name=None))
    assert user.username == "john"
    assert user.full_name is None
    assert user.is_sparse is False

    user = User(username="john")
    assert user.username == "john"
    assert user.full_name is None
    assert user.is_sparse is True

    class User(Schema):
        username = String()
        full_name = String(allow_null=True)
        user_type = String

# Generated at 2022-06-22 06:11:53.461910
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    class Contents(Schema):
        a = Field()
        b = Field()

    class Example(Schema):
        c = Field()
        d = Field()
        ref = Reference("Contents")
        definitions = SchemaDefinitions(Contents=Contents)

    assert Example(c=1, d=2, ref={"a": 3, "b": 4}).ref.definitions["Contents"] == Contents


test_SchemaDefinitions___setitem__()

# Generated at 2022-06-22 06:12:02.591222
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from copy import copy

    example_schema = Schema(
        a=Integer(10),
        b=String(max_length=5),
        # c = None,
    )

    schema_dict = copy(example_schema.__dict__)
    expected = list(schema_dict.keys())
    actual = list(example_schema.__iter__())
    assert actual == expected

    example_schema.c = String()
    schema_dict['c'] = String()
    expected = list(schema_dict.keys())
    actual = list(example_schema.__iter__())
    assert actual == expected


# Generated at 2022-06-22 06:12:09.598057
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class TestSchema(Schema):
        a = Reference("B")
        fields = {"a": a}

    class B(Schema):
        b = str
        fields = {"b": b}

    ref = TestSchema.fields["a"]
    defs = SchemaDefinitions()
    defs["B"] = B
    ref.definitions = defs

    test = B({"b": "b"})

    assert ref.serialize(test) == {"b": "b"}

# Generated at 2022-06-22 06:12:23.446694
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Base:
        def __init__(self, a, b):
            self.a = a
            self.b = b
    class A1(Base):
        def __init__(self, a, b, c):
            super(A1, self).__init__(a, b)
            self.c = c
    class A2(Base):
        def __init__(self, a, b, d):
            super(A2, self).__init__(a, b)
            self.d = d
    # case 1
    o1 = A1(1, 2, 3)
    r1 = Reference(__name__ + '.A1').serialize(o1)
    assert r1['a'] == 1 and r1['b'] == 2 and r1['c'] == 3
    # case 2
    o

# Generated at 2022-06-22 06:12:27.292962
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()

    assert repr(Person(name="bob")) == "Person(name='bob')"
# END Unit test for method __repr__ of class Schema


# Generated at 2022-06-22 06:12:32.984967
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions()
    assert list(definitions) == []

    definitions['foo'] = 1
    assert len(definitions) == 1
    assert list(definitions) == ['foo']

    definitions['bar'] = 2
    assert len(definitions) == 2
    assert sorted(definitions) == ['bar', 'foo']

    del definitions['foo']
    assert len(definitions) == 1
    assert sorted(definitions) == ['bar']



# Generated at 2022-06-22 06:12:39.106215
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert Schema.__len__
    my_schema_1 = Schema()
    my_schema_1.fields = {'key_1': 'value_1', 'key_2': 'value_2'}
    assert len(my_schema_1) == 2


# Generated at 2022-06-22 06:12:55.469947
# Unit test for method __len__ of class Schema
def test_Schema___len__():
	v_Schema0 = Schema({"name": "test"})
	assert ((len(v_Schema0)) == 1)

# Generated at 2022-06-22 06:12:58.147141
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Base(metaclass=SchemaMetaclass):
        pass

    class Subclass(Base):
        pass


test_SchemaMetaclass()

# Generated at 2022-06-22 06:13:08.310830
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # dict
    test_value = '''{'a': 1, 'b': 2}'''
    test_value_type = type(eval(test_value))
    # Schema
    class ABC(Schema):
        a = '''int'''
        b = '''int'''
    # int
    test_key = '''1'''
    test_key_type = type(eval(test_key))
    # unit
    result = ABC(eval(test_value)).__getitem__(eval(test_key))
    # verify
    assert isinstance(result, test_key_type)



# Generated at 2022-06-22 06:13:15.645097
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Example(Schema):
        property_one = Field(required=True)
        property_two = Field(required=False)

    schema = Example()
    schema.property_one = 'foo'
    schema.property_two = 'bar'
    #obj = {'property_one': 'foo', 'property_two': 'bar'}
    obj = dict(schema)
    target = Reference('Example', definitions={'Example': Example})
    result = target.serialize(obj)

    assert result == {'property_one': 'foo','property_two': 'bar'}

# Generated at 2022-06-22 06:13:18.054089
# Unit test for method serialize of class Reference
def test_Reference_serialize():
  # Test serialize when obj is None
  assert(Reference.serialize(None) == None)

# Generated at 2022-06-22 06:13:28.968536
# Unit test for constructor of class Reference
def test_Reference():
    import json
    import typesystem
    class Item(Schema):
        id = typesystem.Integer(minimum=1, maximum=100)
    item_schema = Item.make_validator()

    class Resource(Schema):
        schema = Reference(to=item_schema)
        data = Reference(to="Item")

        class Meta:
            definitions = {
                "Item": Item.make_validator(),
            }
    resource_schema = Resource.make_validator()
    data = {
        "schema": {
            "id": 99,
        },
        "data": {
            "id": 99,
        },
    }
    resource_schema.validate(data)
    print(json.dumps(data))

# Generated at 2022-06-22 06:13:34.019783
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Create the testing objects
    mapping = {"a": 1, "b": 2, "c": 3}
    schema_definitions = SchemaDefinitions(mapping)

    # Assert the precondition
    assert schema_definitions["b"] == 2

    # Execute the code under test
    del schema_definitions["b"]

    # Assert the postcondition
    assert schema_definitions["b"] != 2



# Generated at 2022-06-22 06:13:39.413972
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import String, Number

    class User(Schema):
        id = Number()
        name = String()

    user = User(id=123, name="Foo")
    assert user["id"] == 123
    assert user["name"] == "Foo"
    assert set(user.keys()) == {"id", "name"}
    assert user.is_sparse == False


# Generated at 2022-06-22 06:13:43.053457
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    assert isinstance(definitions, SchemaDefinitions)


# Generated at 2022-06-22 06:13:44.114996
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    pass


# Generated at 2022-06-22 06:14:06.171054
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test 1:
    # Schema tests
    class Person(Schema):
        id: int
        age: int

    p = Person(id=1, age=7)
    assert p.serialize() == {"id": 1, "age": 7}

    # Test 2:
    # Schema tests
    class Person(Schema):
        id: int
        name: str

    p = Person(id=1, name="Anna")
    assert p.serialize() == {"id": 1, "name": "Anna"}

# Generated at 2022-06-22 06:14:08.964622
# Unit test for constructor of class Schema
def test_Schema():
    class Model(Schema):
        id = Field(type_=str)
        name = Field(type_=str)
    assert Model(id="1", name="Keith") == Model(id="1", name="Keith")

# Generated at 2022-06-22 06:14:20.641087
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from pprint import pprint
    from structures.schema import Schema
    from structures.schema import Boolean
    from structures.schema import Integer
    from structures.schema import Number
    from structures.schema import Text


    class BooleanSchema(Schema):
        fields = {
            "full": Boolean(),
            "sparse": Boolean(),
        }
    class IntegerSchema(Schema):
        fields = {
            "full": Integer(),
            "sparse": Integer(),
        }
    class NumberSchema(Schema):
        fields = {
            "full": Number(),
            "sparse": Number(),
        }
    class TextSchema(Schema):
        fields = {
            "full": Text(),
            "sparse": Text(),
        }



# Generated at 2022-06-22 06:14:29.193445
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    import pytest
    from typesystem.base import String  # noqa
    from typesystem.exceptions import ValidationError

    class Color(Schema):
        code = String(max_length=7)

    definitions = SchemaDefinitions()
    definitions["color"] = Color
    definitions["color"] = Color
    with pytest.raises(Exception) as excinfo:
        definitions["color"] = Color
    assert str(excinfo.value) == "Definition for 'color' has already been set."
    assert Color.target_string == "color"


# Generated at 2022-06-22 06:14:39.740714
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class ASchema(Schema):
        a: int = 0
        b: str = ""

    a1 = ASchema(a = 1, b = "a")
    a2 = ASchema(a = 2, b = "b")
    assert(a1 != a2)

    a3 = ASchema(a = 1, b = "a")
    assert(a1 == a3)

    a4 = ASchema(a = 1)
    assert(a1 != a4)
    assert(a1 == ASchema(a = 1, b = ""))


# Generated at 2022-06-22 06:14:42.395000
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass #TODO: Implement union type for argument obj of method serialize

    obj = Schema()
    if hasattr(obj, key):
        yield key


# Generated at 2022-06-22 06:14:45.445159
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():

    class Author(Schema):
        first_name = Field(str)
        last_name = Field(str)

    assert Author.fields == {"first_name": Field(str), "last_name": Field(str)}

# Generated at 2022-06-22 06:14:54.939163
# Unit test for function set_definitions
def test_set_definitions():
    class User(Schema):
        name = Field()

    class Comment(Schema):
        author = Reference(User)
        content = Field()

    assert Comment.author.target_string == User.__name__

    class Post(Schema):
        author = Reference(User)
        comments = Array(items=Reference(Comment))

    assert Post.author.target_string == User.__name__
    assert Post.comments.items.target_string == Comment.__name__
    assert Comment.author.target_string == User.__name__

# Generated at 2022-06-22 06:14:58.143948
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # type: () -> None
    """
    __setitem__(self, key: typing.Any, value: typing.Any) -> None
    Set key to value in self.
    """
    pass



# Generated at 2022-06-22 06:15:01.114287
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    S1 = Schema.__eq__
    S2 = Schema.__eq__
    print(S1 == S2)



# Generated at 2022-06-22 06:15:32.376412
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Foo(Schema):
        a = True
        b = 2

        def __init__(self):
            self.a = 0
    my_foo = Foo()
    my_foo.c = 4
    assert set(my_foo) == {'a', 'c'}
    assert set(Foo) == {'a', 'b'}

# Generated at 2022-06-22 06:15:39.210256
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    assert len(schema_definitions) == 0
    
    schema_definitions = SchemaDefinitions({'a': 1})
    assert len(schema_definitions) == 1
    schema_definitions['b'] = 2
    assert len(schema_definitions) == 2
    del schema_definitions['b']
    assert len(schema_definitions) == 1
    del schema_definitions['a']
    assert len(schema_definitions) == 0


# Generated at 2022-06-22 06:15:44.035735
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions['x'] = 1
    def func():
        definitions['x'] = 2
    try:
        func()
    except AssertionError as err:
        assert str(err) == r"Definition for 'x' has already been set."
    else:
        assert False, "Exceptions were not propagated"


# Generated at 2022-06-22 06:15:46.280119
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['test'] = typing.Any
    assert 'test' in definitions.keys()
    del(definitions['test'])
    assert 'test' not in definitions.keys()


# Generated at 2022-06-22 06:15:51.989452
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import String, Integer
    class SchemaMetaclass(ABCMeta):
        def __new__(cls, name, bases, attrs, definitions=None):
            fields: typing.Dict[str, Field] = {}
            for key, value in list(attrs.items()):
                if isinstance(value, Field):
                    attrs.pop(key)
                    fields[key] = value
            for base in reversed(bases):
                base_fields = getattr(base, "fields", {})
                for key, value in base_fields.items():
                    if isinstance(value, Field) and key not in fields:
                        fields[key] = value
            if definitions is not None:
                for field in fields.values():
                    set_definitions(field, definitions)

# Generated at 2022-06-22 06:15:53.575959
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Add code here.
    return None


# Generated at 2022-06-22 06:16:01.159851
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from .typing import Int, Str, Bool
    from .fixtures import fixture_book_schema, fixture_book_value, fixture_author_value
    try:
        book_schema = Schema(
            {
                "id": Int(minimum=0),
                "title": Str(max_length=200),
                "author": Reference(fixture_author_value),
                "price": Int(minimum=0),
                "in_stock": Bool(),
            }
        )
        book_value = book_schema.validate(fixture_book_value)
        assert book_value == fixture_book_value
    except Exception as error:
        print(error)


# Generated at 2022-06-22 06:16:10.103406
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s_def = SchemaDefinitions()
    assert len(s_def) == 0

    s_def['abc'] = 123
    s_def['def'] = 234
    assert len(s_def) == 2
    assert s_def['abc'] == 123
    assert s_def['def'] == 234
    assert isinstance(s_def, SchemaDefinitions)
    iter_s_def = iter(s_def)
    assert next(iter_s_def) == 'abc'
    assert next(iter_s_def) == 'def'

    # The exception was not caught in the statement.
    try:
        s_def['abc'] = 234
    except:
        pass
    assert len(s_def) == 2
    assert s_def['abc'] == 123

    del s_def['abc']
   

# Generated at 2022-06-22 06:16:20.838732
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.boolean import Boolean
    from typesystem.integer import Integer

    class Foo(Schema):
        bar = Boolean()
        baz = Integer()

    foo1 = Foo(bar=True)
    foo2 = Foo(bar=True)
    assert foo1 == foo2

    foo3 = Foo(bar=False)
    assert foo3 != foo1

    foo4 = Foo(bar=True, baz=42)
    foo5 = Foo(bar=True, baz=42)
    assert foo4 == foo5

    foo6 = Foo(bar=False, baz=42)
    assert foo6 != foo5

    foo7 = Foo(bar=True, baz=43)
    assert foo7 != foo5

    foo8 = Foo(bar=False, baz=43)
    assert foo8 != foo

# Generated at 2022-06-22 06:16:23.360272
# Unit test for method validate of class Reference
def test_Reference_validate():
    field = Reference("Test")
    result = field.validate("test", strict=True)
    assert result == "test"
    

# Generated at 2022-06-22 06:17:20.818966
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        name = String()

    class Employee(Schema):
        name = String()
        department = Reference(Person)
    reference = Reference(Person)

    section = reference.serialize(section)
    assert section



# Generated at 2022-06-22 06:17:29.236810
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    print("\nUnit test for method __repr__ of class Schema")

    class Person(Schema):
        first_name = Field(str)
        last_name = Field(str)
        age = Field(str)

    # example from documentation
    person = Person(first_name="Arthur", last_name="Dent", age="42")
    print(person)

    # example from documentation
    person = Person({"first_name": "Arthur", "last_name": "Dent", "age": "42"})
    print(person)

    # example from documentation
    person = Person(Person({"first_name": "Arthur", "last_name": "Dent", "age": "42"}))
    print(person)

    # example from documentation

# Generated at 2022-06-22 06:17:34.443007
# Unit test for constructor of class Reference
def test_Reference():
    with pytest.raises(ValueError) as pytest_wrapped_e:
        Reference("Target")
    assert pytest_wrapped_e.match(r"String reference missing 'definitions'.")
    assert str(pytest_wrapped_e.value) == (
        "String reference missing 'definitions'."
    )

# Generated at 2022-06-22 06:17:36.144891
# Unit test for method validate of class Reference
def test_Reference_validate():
    assert Reference("to", minimum=0).validate(10) == 10

