

# Generated at 2022-06-22 06:08:12.959383
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class obj:
        pass
    ref = Reference("klass")
    assert ref.serialize(obj()) is not None

# Generated at 2022-06-22 06:08:23.008751
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    definitions = SchemaDefinitions()
    class Person(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        id = Field(type="integer")
        name = Field(type="string")

    person = Person(id=1, name="John Smith")
    assert len(person) == 2, "Test - failed"
    person = Person(id=1)
    assert len(person) == 1, "Test - failed"
    person = Person()
    assert len(person) == 0, "Test - failed"



# Generated at 2022-06-22 06:08:25.237049
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
   definitions = SchemaDefinitions()
   definitions['test_def'] = 'test'
   del definitions['test_def']

# Generated at 2022-06-22 06:08:31.566823
# Unit test for function set_definitions
def test_set_definitions():
    class SubSchema(Schema):
        a = Field()
        b = Reference("TestSchema")

    class Schema(Schema):
        a = Field()
        b = Reference("TestSchema")

    def_ = SchemaDefinitions()

    set_definitions(SubSchema, def_)
    assert Schema.fields["b"].definitions == def_
    assert SubSchema.fields["b"].definitions == def_



# Generated at 2022-06-22 06:08:34.897953
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    a = Schema()
    b = Schema()
    assert a == b


# Generated at 2022-06-22 06:08:41.728734
# Unit test for method validate of class Reference
def test_Reference_validate():

    class SubSchema(Schema):
        a = Field()
        b = Field()

    class RefSchema(Schema):
        c = Reference(SubSchema)

    s = RefSchema.validate({"c": {"a": "a", "b": "b"}})
    assert not s.is_sparse
    assert s.c.a == "a"
    assert s.c.b == "b"


# Generated at 2022-06-22 06:08:45.094223
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class X(object, metaclass=SchemaMetaclass):
        a = Field()
        b = Field()
    x = X({'a':1, 'b':2})
    assert x.a == 1
    assert x.b == 2


# Generated at 2022-06-22 06:08:45.835265
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    return

# Generated at 2022-06-22 06:08:56.942842
# Unit test for constructor of class Reference
def test_Reference():
    from typing import Dict, Set, Tuple
    from typesystem.base import SchemaDefinitions
    from typesystem.fields import Field, Reference, String
    from typesystem.schemas import Schema

    definitions = SchemaDefinitions()

    class FooSchema(Schema):
        foo = String()

    class BarSchema(Schema):
        foo = Reference(FooSchema)
        bar = String()

    # Create a new type based on the schema class
    Bar = BarSchema
    # Assert TypeError message due to required 'to' argument
    try:
        Reference(Boolean(), name="test")
    except TypeError as e:
        assert str(e) == "__init__() missing 1 required positional argument: 'to'"

    # Assert TypeError message due to invalid type for 'to' argument

# Generated at 2022-06-22 06:08:59.694392
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Human(Schema):
        name = String()

    class Company(Schema):
        name = String()

    class Employee(Schema):
        company = Reference(to="Company")

    x = Company(name="A")
    y = Employee(company=x)
    assert y.company.serialize(x) == x

# Generated at 2022-06-22 06:09:09.894900
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test __new__ of SchemaMetaclass
    assert True == True



# Generated at 2022-06-22 06:09:20.088596
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_class_1 = SchemaMetaclass('name_1',(Mapping,),{
        'fields' : {
            'name' : Object(type = str, required = True),
            'age' : Object(type = int, required = True),
            'job' : Object(type = str),
            'address' : {
                'town' : Object(type = str, required = True),
                'country' : Object(type = str, required = True)
            }
        }
    })
    schema_instance_1 = schema_class_1({
        'name' : 'Jim',
        'age' : 37,
        'address' : {
            'town' : 'Auch',
            'country' : 'France'
        }
    })

# Generated at 2022-06-22 06:09:29.413086
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        first_name = String()
        last_name = String()
    class Address(Schema):
        street = String()
        city = String()
        postal_code = String()

    class Office(Schema):
        people = Array(Reference(to=Person))
        address = Reference(to=Address)

    office = Office(
        people=[{"first_name": "John", "last_name": "Doe"}],
        address={"street": "123 Main St.", "city": "Anytown", "postal_code": "12345"}
    )
    assert office.people[0].first_name == "John"
    assert office.address.street == "123 Main St."
    pass

# Generated at 2022-06-22 06:09:39.019682
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        first_name = String()
        last_name = String()
        title = String(allow_null=True)
        user_type = Enum(values=["user", "admin"])
        user_id = Integer()
        user_time = Time()

    try:
        Reference(to=User, name="user").validate(None)
    except ValidationError:
        pass
    else:
        raise AssertionError(
            "It should be raise ValidationError for an empty input when allow_null = False in"
            " Reference"
        )

    user = Reference(to=User, name="user", allow_null=True)
    assert user.validate(None) == None


# Generated at 2022-06-22 06:09:45.608923
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    from hypothesis import given
    from . import strategies

    @given(strategies.schema_definitions)
    def test(definitions: SchemaDefinitions) -> None:
        result = iter(definitions)
        keys = list(definitions.keys())
        short_result = list(result)
        assert short_result == keys
        for key in short_result:
            assert iter([definitions[key]]) == iter([definitions[key]])

    test()


# Generated at 2022-06-22 06:09:54.680233
# Unit test for constructor of class Schema
def test_Schema():
    data = {
        'id': '123e4567-e89b-12d3-a456-426655440000',
        'first_name': 'Jim',
        'last_name': 'Bob',
        'age': 18
    }
    MySchema = Schema(**data)
    print(MySchema)
    print(MySchema.__dict__)
    MySchema2 = Schema(data)
    print(MySchema2)
    print(MySchema2.__dict__)
    MySchema3 = Schema(MySchema2)
    print(MySchema3)
    print(MySchema3.__dict__)


# Generated at 2022-06-22 06:10:01.054503
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    s=SchemaDefinitions()
    assert len(s) == 0
    s["a"] = "b"
    assert len(s) == 1
    s["a"] = "c"
    assert len(s) == 1
    s["b"] = "c"
    assert len(s) == 2




# Generated at 2022-06-22 06:10:12.964428
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        print("hello there")
        x = Field()
        y = Field()
        z = Field()

    test_schema = TestSchema(x=1, y=1, z=2)
    assert len(test_schema) == 2
    assert len(test_schema) == 2
    assert len(test_schema) == 2
    assert len(test_schema) == 2
    assert len(test_schema) == 2
    assert len(test_schema) == 2
    assert len(test_schema) == 2
    assert len(test_schema) == 2
    assert len(test_schema) == 2
    assert len(test_schema) == 2
    assert len(test_schema) == 2
    assert len(test_schema)

# Generated at 2022-06-22 06:10:21.558499
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    class TestDefinitions(SchemaDefinitions):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
    definitions = TestDefinitions()

    assert len(definitions) == 0

    definitions['a'] = 1
    definitions['b'] = 2
    assert len(definitions) == 2

    definitions['c'] = 3
    definitions['d'] = 4
    assert len(definitions) == 4

# Generated at 2022-06-22 06:10:26.482801
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from io import StringIO
    from unittest.mock import *
    from .example_schema import *
    reference = Reference("MySchema", allow_null=True)
    assert reference.serialize(MySchema(a=1, b=2)) == {'a': 1, 'b': 2}
    assert reference.serialize(None) is None

# Generated at 2022-06-22 06:10:51.788673
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(to="Pet").serialize(None) == None



# Generated at 2022-06-22 06:10:58.492434
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem import String
    class Point(Schema):
        x = String()
        y = String()
    point = Point(x='1.0', y='2.0')
    ref = Reference(Point)
    ret = ref.serialize(point)
    assert ret == {'x': '1.0', 'y': '2.0'}
    ret = ref.validate(point)
    assert ret == point
    ret = ref.validate_or_error(point)
    assert ret.value == point


# Generated at 2022-06-22 06:11:10.597408
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    '''
    Test __iter__ of class Schema.
    '''
    fields = {'test': Reference('test')}
    class DictTest(Schema):
        fields = {**fields, 'test2': Reference('test')}

    d = DictTest({'test': 7, 'test2': {'test': 'test'}})
    d2 = DictTest(test='test')
    d3 = DictTest({'test': {'test': 'test'}})
    d4 = DictTest({'test2': 7})
    d5 = DictTest(test2=7)
    d6 = DictTest()
    d7 = DictTest({})
    i = iter(d) # i is an iterator

# Generated at 2022-06-22 06:11:16.859811
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import sys
    import os
    cwd = os.getcwd()
    sys.path.append(cwd)
    # import the module
    import class_schema

    # create an object of the class 'Schema'
    obj = class_schema.Schema()

    assert obj.__iter__() == obj.fields.keys()


# Generated at 2022-06-22 06:11:18.906680
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    dictionary = SchemaDefinitions(dict, string="hello")
    assert dictionary._definitions == dict(string="hello")


# Generated at 2022-06-22 06:11:28.272182
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from pytest import raises
    from . import Schema

    class Person(Schema):
        id = int
        name = str
        age = int

    person_0 = Person(id=1, name='name_0', age=0)

    assert (repr(person_0) == '<Person: id=1, name=\'name_0\', age=0>')

    with raises(ValueError):
        Person(id='id_0', name='name_0', age='age_0')

    person_0 = Person(id='id_0', name='name_0', age='age_0', extra=0)

# Generated at 2022-06-22 06:11:30.900512
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class MySchema(Schema):
        field1 = Array(Int())

    assert list(MySchema.fields.keys()) == ["field1"]



# Generated at 2022-06-22 06:11:31.929722
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    obj = SchemaDefinitions()


# Generated at 2022-06-22 06:11:36.914214
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Test that two schemas with the same attributes are equal.
    class TestSchema1(Schema):
        test: Field = Field()
    test1 = TestSchema1(test=1)
    test2 = TestSchema1(test=1)
    assert test1 == test2
    # Test that two schemas with different attributes are not equal.
    test1 = TestSchema1(test=1)
    test2 = TestSchema1(test=2)
    assert test1 != test2
    # Test that a schema and a object are not equal.
    test1 = TestSchema1(test=1)
    assert test1 != 1


# Generated at 2022-06-22 06:11:45.524317
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import typesystem
    definitions = SchemaDefinitions()
    class Pet(Schema, metaclass=typesystem.SchemaMetaclass, definitions=definitions):
        name = typesystem.String(max_length=100)
        competition = typesystem.String()
    pet = Pet(name="Fluffy", competition="Best in Show")
    assert pet["name"] == "Fluffy"
    assert pet["competition"] == "Best in Show"
    assert pet["age"] == 0
    # Fail: AssertionError: Definition for 'age' has already been set.


# Generated at 2022-06-22 06:12:54.693280
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
  schema_definitions = SchemaDefinitions()
  assert schema_definitions is not None


# Generated at 2022-06-22 06:13:05.207804
# Unit test for method __new__ of class SchemaMetaclass

# Generated at 2022-06-22 06:13:07.789891
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # call the method __iter__ of class SchemaDefinitions
    SchemaDefinitions({}).__iter__()


# Generated at 2022-06-22 06:13:14.743861
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem import Schema, String, Integer, Reference
    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=130, exclusive_maximum=True)
    person = Person(name='Nico', age=30)
    person_ref = Reference(Person)
    assert person_ref.serialize(person) == {'name': 'Nico', 'age': 30}


# Generated at 2022-06-22 06:13:23.573774
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    definitions = SchemaDefinitions()
    class FooBar(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        foo = String(max_length=20)
        bar = Integer()
    assert len(definitions) == 1
    assert list(definitions.keys()) == ['FooBar']
    assert list(definitions.values()) == [FooBar]
    foo_bar = FooBar.validate({'foo': 'ok', 'bar': 10})
    assert foo_bar.foo == 'ok'
    assert foo_bar.bar == 10


# Generated at 2022-06-22 06:13:29.787820
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    obj1 = Schema({"p1": 1, "p2": 'ok'})
    obj2 = Schema({"p1": 1, "p2": 'not ok'})
    obj3 = Schema({"p1": 1, "p2": 'ok', "p3": 'extra'})
    assert obj1 == obj1
    assert obj1 != obj2
    assert obj1 != obj3
    assert obj2 != obj3

# Generated at 2022-06-22 06:13:32.224006
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference("toString")
    assert r.to == "toString"

# Generated at 2022-06-22 06:13:34.103390
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    x = SchemaDefinitions()
    y = x.__iter__()


# Generated at 2022-06-22 06:13:46.557045
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    SchemaMetaclass(
        name = 'SchemaMetaclass',
        bases = [],
        attrs = {
            '_meta': {},
            '_definitions': {},
            'fields': {
                'a': {'_creation_counter': 0,
                      '_allow_null': True,
                      '_required': False},
                'b': {'_creation_counter': 1,
                      '_allow_null': True,
                      '_required': False}
                }
            },
        definitions = {
            'a': {
                '_allow_null': True, '_creation_counter': 0, '_required': False
                },
            'b': {
                '_allow_null': True, '_creation_counter': 1, '_required': False
                }})
# Test of class Sche

# Generated at 2022-06-22 06:13:53.538851
# Unit test for constructor of class Schema
def test_Schema():
    a = Schema()
    assert a.fields == {}
    a = Schema(name="wz")
    assert a.fields == {}
    a = Schema(name="wz", attr="tom")
    assert a.fields == {}
    a = Schema({"name": "wz", "attr": "tom"})
    assert a.fields == {}
    b = Schema({"name": "wz"}, {"attr": "tom"})
    assert b.fields == {}



# Generated at 2022-06-22 06:15:27.528133
# Unit test for constructor of class SchemaMetaclass

# Generated at 2022-06-22 06:15:34.181547
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import Integer, String
    class Person(Schema):
        age = Integer()
        name = String()
        condition = String(default='healthy')

    person = Person(age=27, name='Steven')
    assert repr(person) == "Person(age=27, name='Steven', condition='healthy') [sparse]"
    assert repr(Person(age=27, name='Steven', condition='good')) == "Person(age=27, name='Steven', condition='good')"


# Generated at 2022-06-22 06:15:38.753234
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    class Child(Schema):
        name = String()
    class Parent(Schema):
        child = Reference(Child)
    parent = Parent.validate({"child": {"name": "Bob"}})
    assert parent.child == Child(name="Bob")

# Generated at 2022-06-22 06:15:40.594941
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    instance_dict = {}
    assert not instance_dict
    assert type(instance_dict) is dict


# Generated at 2022-06-22 06:15:46.173684
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Author(Schema):
        name = String(max_length=20)
        age = Integer()
    class Comment(Schema):
        name = String(max_length=100)
        content = String()
    class Article(Schema):
        title = String(max_length=100, required=True)
        author = Reference(Author)
        comments = Array(Reference(Comment), required=False)
    assert Article.fields.keys() == {"title", "author", "comments"}
    assert "name" in Author.fields.keys()
    assert "title" in Article.fields.keys()
    assert "content" in Comment.fields.keys()

# Generated at 2022-06-22 06:15:50.289090
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():

    class UserSchema(Schema):
        name = String(required=True)
        password = String(required=True)
    
    # test the constructor is called
    assert UserSchema.fields['name'] is not None


# Generated at 2022-06-22 06:15:53.623502
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions({'key1': 'value1'})
    del definitions['key1']
    assert len(definitions) == 0
    assert definitions == {}
    assert definitions._definitions == {}


# Generated at 2022-06-22 06:16:01.718095
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schema_definitions = SchemaDefinitions()
    assert schema_definitions._definitions == {}
    schema_definitions = SchemaDefinitions([1])
    assert schema_definitions._definitions == {}
    schema_definitions = SchemaDefinitions([1], [2])
    assert schema_definitions._definitions == {}
    schema_definitions = SchemaDefinitions([1], "a", "b")
    assert schema_definitions._definitions == {}
    schema_definitions = SchemaDefinitions(a=1, b=2)
    assert schema_definitions._definitions == {'a':1, 'b':2}
    schema_definitions = SchemaDefinitions([1], a=1, b=2)
    assert schema_definitions._definitions == {'a':1, 'b':2}

#

# Generated at 2022-06-22 06:16:11.214827
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        definitions = SchemaDefinitions()

        def __init__(
            self,
            required_ref: typing.Union[Reference, Schema] = None,
            optional_ref: typing.Union[Reference, Schema] = None,
        ) -> None:
            super().__init__()
            self.required_ref = required_ref
            self.optional_ref = optional_ref

        required_ref = Reference(to='RequiredSchema', definitions=definitions)
        optional_ref = Reference(to='OptionalSchema', definitions=definitions, required=False)

    class RequiredSchema(Schema):
        required_value = Field(required=True)

    class OptionalSchema(Schema):
        optional_value = Field(required=False)

    TestSchema()

# Generated at 2022-06-22 06:16:19.251868
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    try:
        class Foo(Schema):
            a = String()
            b = String()
        foo1 = Foo(a = "Hello", b = "World")
        foo2 = Foo(a = "Apple", b = "World")
        foo3 = Foo(a = "Hello", b = "World")
        assert(foo1 == foo3)
        assert(foo1 != foo2)
    except AssertionError:
        assert(False)
    else:
        assert(True)

