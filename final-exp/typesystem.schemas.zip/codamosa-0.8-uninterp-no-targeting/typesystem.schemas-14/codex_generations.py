

# Generated at 2022-06-22 06:08:13.851147
# Unit test for constructor of class Schema
def test_Schema():
    # __init__(self, *args, **kwargs)
    """Test for arguments passed to constructor"""
    # Arrange
    fields = {"field1": Field(key="field1"), "field2": Field(key="field2")}
    item = {"field1": 'example1'}
    item_2 = {'field2': 'example2'}
    test_schema = Schema(item)
    # Act
    test_schema.__init__(item)
    test_schema.__init__(item_2)
    # Assert
    assert test_schema.field1 == 'example1'
    assert test_schema.field2 == 'example2'



# Generated at 2022-06-22 06:08:24.691071
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema(Schema):
        a = String()
        b = String(required=True)
        c = String(has_default=True)

    foo = TestSchema()
    assert foo.a is None
    assert foo.b is None
    assert foo.c == 'default'

    foo = TestSchema(a='hello')
    assert foo.a == 'hello'
    assert foo.b is None
    assert foo.c == 'default'

    def test_foo():
        foo = TestSchema(a='hello', e='hello')
    try:
        test_foo()
    except:
        pass
    else:
        raise Exception('test failed')


# Generated at 2022-06-22 06:08:31.782331
# Unit test for function set_definitions
def test_set_definitions():
    class TestObject(Object):
        pass

    class TestSchema(Schema):
        first_name = String(max_length=100)
        second_name = Reference(TestObject)

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.first_name, definitions)
    set_definitions(TestSchema.second_name, definitions)
    assert TestSchema.second_name.definitions is definitions
    assert TestSchema.second_name.target.__class__ is TestObject

# Generated at 2022-06-22 06:08:44.280849
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from datetime import date, datetime, time

    class Person(Schema):
        name = String()
        age = Integer()
        born = Date()

    moe = Person(name="Moe", age=40, born=date(1978, 4, 11))
    larry = Person(name="Larry", age=42, born=date(1976, 1, 2))
    curly = Person(name="Curly", age=30, born=datetime(1990, 2, 14))

    assert moe == Person(name="Moe", age=40, born=date(1978, 4, 11))
    assert moe != Person(name="Moe", age=40, born=date(1978, 9, 11))
    assert moe != Person(name="Moe", age=40)

# Generated at 2022-06-22 06:08:46.416851
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    obj1 = SchemaDefinitions()
    assert obj1.__class__==SchemaDefinitions

# Generated at 2022-06-22 06:08:48.494477
# Unit test for method validate of class Reference
def test_Reference_validate():
    """
    TODO: write unittests
    """
    pass


# Generated at 2022-06-22 06:08:49.958475
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference("test", definitions=None, allow_null=False)

# Generated at 2022-06-22 06:08:55.839898
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    c = Schema()
    print(c)
    assert str(c) == 'Schema()'
    class MySchema(Schema):
        foo = Integer()
    d = MySchema(foo=1, bar='baz')
    print(d)
    print(d.foo)
    print(d.bar)
    assert str(d) == "MySchema(foo=1) [sparse]"


# Generated at 2022-06-22 06:09:01.608795
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    print("test_SchemaDefinitions___iter__")
    definitions = SchemaDefinitions({"a": "A", "b": "B"})
    assert len(list(iter(definitions))) == 2
    assert "a" in definitions
    assert "b" in definitions
    assert "c" not in definitions
    print("End test_SchemaDefinitions___iter__")


# Generated at 2022-06-22 06:09:07.803806
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    #
    #  This test checks if a returned value is an integer. We do not check if the return value is correct, because we
    #  cannot know this.
    #
    # Arrange
    definitions = SchemaDefinitions()
    definitions['ref'] = MockSchema()

    # Act
    result = len(definitions)

    # Assert
    assert isinstance(result, int)


# Generated at 2022-06-22 06:09:21.009673
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Object(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    obj = Object(name="Bob", age=42)

    assert obj['name'] == "Bob"
    assert obj['age'] == 42

    obj1 = Object(name="Bob")
    assert not obj1.is_sparse


# Generated at 2022-06-22 06:09:28.847747
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test with an item with a correct value
    class ExampleSchema(Schema):
        foo = Field(type=str)

    item = ExampleSchema(foo="bar")
    assert item["foo"] == "bar"

    # Test with an item with a value of a wrong type
    with pytest.raises(TypeError):
        class ExampleSchema(Schema):
            foo = Field(type=int)

        item = ExampleSchema(foo="bar")
        assert item["foo"] == "bar"

    # Test with an item that does not have a value for the field
    with pytest.raises(KeyError):
        class ExampleSchema(Schema):
            foo = Field(type=int)

        item = ExampleSchema()
        assert item["foo"] == "bar"


# Generated at 2022-06-22 06:09:36.722839
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    def test_getitem__1(SchemaDefinitions, key):
        assert isinstance(SchemaDefinitions, SchemaDefinitions)
        assert (key in SchemaDefinitions)
        assert (isinstance(key, str) or isinstance(key, types.ModuleType) or isinstance(key, type))
        assert (isinstance(SchemaDefinitions[key], str) or isinstance(SchemaDefinitions[key], types.ModuleType) or isinstance(SchemaDefinitions[key], type))
    def test_getitem__2(SchemaDefinitions, key):
        assert isinstance(SchemaDefinitions, SchemaDefinitions)
        assert (not (key in SchemaDefinitions))
        assert (isinstance(key, str) or isinstance(key, types.ModuleType) or isinstance(key, type))

# Generated at 2022-06-22 06:09:42.084203
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    test_obj = SchemaDefinitions()
    target_name = 'foo'
    test_obj[target_name] = 'bar'
    test_obj[target_name]
    assert test_obj
    del test_obj[target_name]
    assert target_name not in test_obj
    assert not test_obj


# Generated at 2022-06-22 06:09:48.354440
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions["test_schema_1"] = "test_value_1"
    definitions["test_schema_2"] = "test_value_2"
    assert len(definitions) == 2
    del definitions["test_schema_1"]
    assert len(definitions) == 1
    assert "test_schema_2" in definitions
    assert "test_schema_1" not in definitions
    del definitions["test_schema_2"]
    assert len(definitions) == 0
    assert "test_schema_2" not in definitions
    assert "test_schema_1" not in definitions


# Generated at 2022-06-22 06:09:50.663503
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():

    d = {"key": "value"}
    s = SchemaDefinitions(d)
    del s["key"]
    assert len(s) == 0


# Generated at 2022-06-22 06:09:55.206831
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class S1(Schema):
        a = Field()
        #
    assert S1(a=1) == S1(a=1)
    assert S1(a=1) != S1(a=2)
    assert S1(a=1) != S1(b=2)

# Generated at 2022-06-22 06:10:07.428805
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = Field()

    class PersonArray(Schema):
        persons = Array(Reference("Person"))

    class ArrayOfArray(Schema):
        arr = Array(Array(Reference("Person")))

    class ArrayOfArrayOfArray(Schema):
        arr = Array(Array(Array(Reference("Person"))))

    definitions = SchemaDefinitions()
    assert definitions.get("Person") is None
    assert definitions.get("PersonArray") is None
    assert definitions.get("ArrayOfArray") is None
    assert definitions.get("ArrayOfArrayOfArray") is None

    set_definitions(PersonArray.make_validator(), definitions)
    assert definitions.get("Person") is Person
    assert definitions.get("PersonArray") is PersonArray
    assert definitions.get("ArrayOfArray") is None

# Generated at 2022-06-22 06:10:11.063885
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
  definitions = SchemaDefinitions()
  definitions["key"] = "value"
  assert definitions["key"] == "value"


# Generated at 2022-06-22 06:10:18.321596
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class PersonSchema(Schema):
        name = Field()
        age = Field()
        city = Field()

    person = PersonSchema(name="Jane", age=22, city="London")
    repr_person = repr(person)
    assert repr_person == "PersonSchema(age=22, city='London', name='Jane')"


# Generated at 2022-06-22 06:10:43.208008
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema({"x": 1, "y": 2, "z": 3})
    assert schema.x == 1
    assert schema.y == 2
    assert schema.z == 3


# Generated at 2022-06-22 06:10:45.742709
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    defs = SchemaDefinitions()
    defs['a'] = {"key": "value"}
    assert defs['a'] == {"key": "value"}

# Generated at 2022-06-22 06:10:51.291857
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import Boolean, Integer

    class Person(Schema):
        name = String(max_length=10)
        age = Integer(minimum=1, maximum=150)
        alive = Boolean(default=True)

    person = Person(name="Fred", age=30)
    assert person.name == "Fred"
    assert person.age == 30
    assert person.alive == True


# Generated at 2022-06-22 06:11:00.391482
# Unit test for constructor of class Reference
def test_Reference():
    # Tests passing a string to to parameter
    args = "testString"
    ref = Reference(to=args)
    assert ref.to == "testString", "string to"
    assert ref.allow_null, "allow_null"

    # Tests passing a Schema class to to parameter
    class TestSchema(Schema):
        pass

    ref = Reference(to=TestSchema)
    assert ref.to == TestSchema, "schema to"
    assert ref.allow_null, "allow_null"

    # Tests passing a string to to parameter and dict to definitions parameter
    definitions = {"key": "value"}
    ref = Reference(to="testString", definitions=definitions)
    assert ref.to == "testString", "string to"
    assert ref.definitions == definitions, "definitions"
    assert ref.allow

# Generated at 2022-06-22 06:11:12.526250
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema:
        first_field = Reference('first_field')
        second_field = Reference('second_field')
        third_field = Reference('third_field')
        definitions = SchemaDefinitions()
        definitions['first_field'] = Array(Integer())
        definitions['second_field'] = Object(properties={'inner_field': String()})

    set_definitions(TestSchema.first_field, TestSchema.definitions)
    set_definitions(TestSchema.second_field, TestSchema.definitions)
    set_definitions(TestSchema.third_field, TestSchema.definitions)

    assert TestSchema.first_field.definitions == TestSchema.definitions
    assert TestSchema.first_field.to == 'first_field'
    assert TestSchema.first_field

# Generated at 2022-06-22 06:11:23.492617
# Unit test for method __iter__ of class SchemaDefinitions

# Generated at 2022-06-22 06:11:27.388067
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        foo = Object(properties={
            "bar": Reference("Foo", definitions={
                "Foo": Object(properties={
                    "baz": String(max_length=10)
                })
            })
        })

# Generated at 2022-06-22 06:11:29.681456
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Return of a Schema instance with all fields set
    # is a string
    assert type(Schema().__repr__()) is str


# Generated at 2022-06-22 06:11:35.800722
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from hypothesis import given
    from hypothesis.strategies import dictionaries, just, none, one_of, tuples
    from hypothesis_jsonschema import from_schema

    class ExampleSchema(Schema):
        a = Field(description="description of field a")
        b = Field(description="description of field b")

        def __eq__(self, other):
            return True

    @given(from_schema({"type": "object", "properties": ExampleSchema.fields}))
    def test(obj):
        example_schema1 = ExampleSchema(obj)
        example_schema2 = ExampleSchema(obj)
        assert example_schema1 == example_schema2

    test()


# Generated at 2022-06-22 06:11:42.859086
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # __eq__ schema_a == schema_a
    schema_a = Schema(a=1, b=2)
    assert schema_a == schema_a
    # __eq__ schema_a == schema_b
    schema_b = Schema(a=1, b=2)
    assert schema_a == schema_b
    # __eq__ schema_a != schema_c
    schema_c = Schema(a=1, b=3)
    assert not (schema_a == schema_c)


# Generated at 2022-06-22 06:12:02.690140
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    sd = SchemaDefinitions()
    assert len(sd) == 0
    sd['key1'] = 1
    assert len(sd) == 1
    sd['key2'] = 2
    assert len(sd) == 2
    sd['key3'] = 3
    assert len(sd) == 3

# Generated at 2022-06-22 06:12:14.553839
# Unit test for method validate of class Reference
def test_Reference_validate():
    # CREATE A RECURSIVELY DEFINED TYPE
    C = Reference('C')
    class C(Schema): 
        c = C
        def __init__(self, c=None):
            super().__init__()
            self.c = c

    # TEST THE RECURSIVELY DEFINED TYPE
    x = C()
    y = C(x)
    assert x.validate(x) == x
    assert x.validate(y) == y

    # TEST A NOT RECURSIVELY DEFINED TYPE
    class D(Schema): 
        d = String() 
        def __init__(self, d=None):
            super().__init__()
            self.d = d

    D = Reference('D')
    class D(Schema): 
        d = String() 

# Generated at 2022-06-22 06:12:20.903315
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.fields import Integer, Text

    class Person(Schema):
        name = Text(allow_null=False, description="The name of the person.")
        age = Integer(description="The age of the person.")

    julie = Person(name="Julie", age=22)
    john = Person(name="John", age=45)
    assert julie == julie
    assert john != julie



# Generated at 2022-06-22 06:12:23.297375
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class CustomSchema(Schema):
        name = String()

    result = CustomSchema(name='name') == CustomSchema(name='name')
    assert result is True


# Generated at 2022-06-22 06:12:32.830457
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import Boolean, Integer, String
    import random
    class mySchema(Schema):
        name = String(max_length=10)
        age = Integer(required=False)
        alive = Boolean(default=True, required=False)
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        def __eq__(self, other):
            if not isinstance(other, self.__class__):
                return False
            return (self.name == other.name) and (self.age == other.age) and (self.alive == other.alive)
        __hash__ = None
    expected = "mySchema(name='test', age=5, alive=True)"

# Generated at 2022-06-22 06:12:39.099791
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    d = SchemaDefinitions()
    d[3] = "a"
    d[4] = "b"
    d[1] = "c"

    result = d.__iter__()
    assert len(result) == 3
    assert list(result)[0] == 3


# Generated at 2022-06-22 06:12:43.272692
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        id = Field(type="string")
        name = Field(type="string")

    person = Person(id="1", name="John")
    assert person.__repr__() == 'Person(id="1", name="John")'


# Generated at 2022-06-22 06:12:46.281683
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference("test")
    assert ref.target_string == "test"
    assert ref.to == "test"


# Generated at 2022-06-22 06:12:50.144556
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    assert len(schema_definitions) == 0
    schema_definitions["key"] = "value"
    assert len(schema_definitions) == 1
    del schema_definitions["key"]
    assert len(schema_definitions) == 0


# Generated at 2022-06-22 06:13:04.026932
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import String
    class Car(Schema):
        name = String()
        price = String()

    class User(Schema):
        name = String()
        car = Reference(to=Car)

    # setup the validator
    validator = User.make_validator()

    # pass a valid data, expect to pass
    user = {
        "name": "kool",
        "car": {"name":"Ferrari","price": "expensive"}
    }
    validator.validate(user)
    assert True

    # pass a valid data, expect to pass
    user = {
        "name": "kool",
        "car": {"name":"Ferrari","price": "expensive"},
        "fake": "fake"
    }

# Generated at 2022-06-22 06:13:22.962204
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Test(Schema):
        test = Reference("Test", definitions=definitions)
    assert isinstance(Test.test.target, type)

# Generated at 2022-06-22 06:13:28.088624
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Geo(Schema):
        latitude = Float()
        longitude = Float()

    class User(Schema):
        name = String()
        position = Geo()

    user = User({"name": "Eve", "position": {"latitude": 10.0, "longitude": 20.0}})
    assert user["name"] == "Eve"
    assert user["position"] == {"latitude": 10.0, "longitude": 20.0}



# Generated at 2022-06-22 06:13:28.808918
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert False #FIXME

# Generated at 2022-06-22 06:13:32.062545
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    dict = {}
    asche = Schema(dict)
    assert len(asche) == 0
    dict = {"a": 1}
    asche = Schema(dict)
    assert len(asche) == 1


# Generated at 2022-06-22 06:13:34.417881
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    assert len(schema) == 0

test_Schema___len__()


# Generated at 2022-06-22 06:13:42.607667
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions['a'] = 'A'
    assert len(schema_definitions) == 1
    assert list(schema_definitions.keys()) == ['a']
    del schema_definitions['a']
    assert len(schema_definitions) == 0
    assert [key for key in schema_definitions.keys()] == []


# Generated at 2022-06-22 06:13:50.916608
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
        self._definitions = dict(*args, **kwargs)  # type: dict

    d1 = {"a":"a"};
    d2 = {"a":"a","b":"b"};
    assert (SchemaDefinitions(d1)._definitions == d1)
    assert (SchemaDefinitions(d2)._definitions == d2)
    with pytest.raises(AssertionError):
        assert (SchemaDefinitions(d1) == d2)


# Generated at 2022-06-22 06:13:52.349164
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
  schema = Schema(name='a')
  assert schema['name'] == 'a'

# Generated at 2022-06-22 06:13:59.587334
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Animal(Schema):
        """A definition for an animal."""

        name = Field(description="The name of the animal.", max_length=100)

    class Farm(Schema):
        cow = Reference(Animal)

    my_animal = Animal(name="Bessie")
    my_farm = Farm(cow=my_animal)
    assert my_farm.cow == my_animal



# Generated at 2022-06-22 06:14:01.613696
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from . import Schema
    ds = {'a': 1, 'b': 2, 'c': 3}
    s = Schema(ds)
    assert len(s) == len(ds)


# Generated at 2022-06-22 06:14:18.104781
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions["test"] = "test"
    assert "test" in schema_definitions
    del schema_definitions["test"]
    assert "test" not in schema_definitions

# Generated at 2022-06-22 06:14:22.872182
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema(Schema):
        class Meta:
            fields = {'foo': 'bar'}

    assert TestSchema.__name__ == 'TestSchema'
    assert TestSchema.__module__ == '__main__'
    assert TestSchema.Meta.fields['foo'] == 'bar'


# Generated at 2022-06-22 06:14:26.569555
# Unit test for function set_definitions
def test_set_definitions():
    def_dict = SchemaDefinitions()
    ref_field = Reference("TestSchema")
    
    set_definitions(ref_field, def_dict)
    assert ref_field.definitions == def_dict

# Generated at 2022-06-22 06:14:30.783585
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    """
    This method test that two class Schema are equal
    """
    class Class(Schema):
        test = Field(required=True)
    a = Class(test=True)
    b = Class(test=True)
    assert a == b


# Generated at 2022-06-22 06:14:39.089551
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema(Schema, metaclass=SchemaMetaclass):
        bar = Field()
    
    class TestSchema2(TestSchema, metaclass=SchemaMetaclass):
        foo = Field()
        field_bar = TestSchema.fields["bar"]

    assert TestSchema.fields == {"bar": Field()}
    assert TestSchema2.fields == {"bar": Field(), "foo": Field()}
    assert TestSchema2.field_bar == TestSchema.fields["bar"]



# Generated at 2022-06-22 06:14:43.391164
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Point(Schema):
        x = Field(type="integer")
        y = Field(type="integer")
    p = Point(x=1, y=2)
    ref = Reference(Point)
    assert ref.serialize(p) == {'x': 1, 'y': 2}

# Generated at 2022-06-22 06:14:46.885391
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class ColorSchema(Schema):
        blue: int = Field(required=True)
        pink: int = Field(required=False, default=0)

        blue.validate("some_value")
        SchemaMetaclass("", "", "")

# Generated at 2022-06-22 06:14:58.986180
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import logging
    import os.path
    import tempfile

    # Stupid hack.
    __file__ = os.path.normpath(os.path.abspath(__file__))
    __path__ = os.path.dirname(__file__)
    __parent__ = os.path.dirname(__path__)
    __package__ = os.path.basename(__parent__)

    import json
    import typesystem
    from typesystem import types

    class A(typesystem.Schema):
        a = types.String()
        b = types.String()

    class B(typesystem.Schema):
        a = types.String()
        b = types.String()

    class MyRef(typesystem.Reference):
        def serialize(self, obj):
            ref_class = self.target
            return

# Generated at 2022-06-22 06:15:08.559322
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    obj1 = Schema(
        a=Field.number(),
        b=Field.number(),
        c=Field.number(),
        d=Field.number(),
        definitions=SchemaDefinitions(),
    )
    obj1.a = 1
    obj1.b = 2
    obj1.c = 3
    obj1.d = 4
    str1 = repr(obj1)
    assert str1 != 'Schema(a=1, b=2, c=3, d=4)'
    assert str1 == 'Schema(a=1, b=2, c=3, d=4) [sparse]'

# Generated at 2022-06-22 06:15:10.485043
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["hello"] = 1
    definitions["hello"] = 2

# Generated at 2022-06-22 06:15:29.351100
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    pass


# Generated at 2022-06-22 06:15:31.877693
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    data = SchemaDefinitions({'a':1})
    del data['a']
    # AssertionError: Definition for 'a' has already been set.



# Generated at 2022-06-22 06:15:42.046670
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    d = SchemaDefinitions()
    assert len(d) == 0
    d["key"] = "value"
    assert len(d) == 1
    for key in d:
        assert key == "key"
        assert d[key] == "value"
    assert d["key"] == "value"
    d["key"] = "value2"
    assert d["key"] == "value2"
    del d["key"]
    assert len(d) == 0
    assert len(d) == 0
    d = SchemaDefinitions({'key': 'value'})
    assert len(d) == 1
    d = SchemaDefinitions(key='value')
    assert len(d) == 1
    d = SchemaDefinitions([('key', 'value')])
    assert len(d) == 1


# Generated at 2022-06-22 06:15:43.490544
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    obj = SchemaDefinitions()  # pass


# Generated at 2022-06-22 06:15:51.211554
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    try:
        # Setup
        obj = SchemaDefinitions()
        
        # Invocation
        result = obj[key]

        # Testing
        # No assert as this is supposed to raise an exception
    except Exception as e:
        # Verification
        assert isinstance(e, KeyError)


# Generated at 2022-06-22 06:15:55.044306
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Integer

    class Example(Schema):
        foo = Integer()

    assert len(Example()) == 0
    assert len(Example(foo=1)) == 1
    assert len(Example(foo=1, invalid=True)) == 1


# Generated at 2022-06-22 06:15:59.471133
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():

    # testing correct function __new__
    class BaseSchema(Schema):
        pass

    class SimpleSchema(Schema):
        field1 = Integer()
        field2 = String()

    assert SimpleSchema.fields == {'field1': Integer(), 'field2': String()}



# Generated at 2022-06-22 06:16:10.898288
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import String, Integer

    class Person(Schema):
        name = String()
        age = Integer(minimum=0)

    class Address(Schema):
        number = Integer(minimum=0, maximum=9)
        street = String()

    class Contact(Schema):
        email = String()
        phone = String()

    class Employee(Schema):
        person = Object(properties=Person.fields)
        address = Object(properties=Address.fields)
        contact = Object(properties=Contact.fields)

    def expect(schema):
        assert isinstance(schema,Schema)
        assert isinstance(schema.fields,dict)
        assert len(schema.fields)>0
        for k,v in schema.fields.items():
            assert isinstance(k,str)

# Generated at 2022-06-22 06:16:23.098672
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test cases, each test case is a tuple of (in, out)
    test_cases = [
        (
            (
                "type_system.schema.SchemaMetaclass",
                (),
                {"__module__": "type_system.schema", "__qualname__": "type_system.schema.Foo", "__doc__": None},
                {"fields": {"bar": 1}},
            ),
            {"__module__": "type_system.schema", "__qualname__": "type_system.schema.Foo", "__doc__": None, "fields": {"bar": 1}},
        ),
    ]
    for test_case in test_cases:
        in_dict , expected_out_dict = test_case[0], test_case[1]
        out_dict = Schema

# Generated at 2022-06-22 06:16:26.475998
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typing import Optional
    class Student(Reference):
        id: int
        name: str
    students = [Student(id=i,name=f"student{i}") for i in range(5)]
    print(students)
    assert students[0].serialize(students[0]) == {'id':0, 'name': 'student0'}

# Generated at 2022-06-22 06:17:03.220773
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from pytest import raises
    schema = Schema()
    ref = Reference(to = None)
    exc = raises(AttributeError, lambda: ref.serialize(schema))
    assert str(exc.value) == "'NoneType' object has no attribute 'validate'"

# Generated at 2022-06-22 06:17:11.522733
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class BaseSchema(Schema):
        field1 = String()
        field2 = String()
    class SubSchema(BaseSchema):
        field3 = String()
    def test_SchemaMetaclass_1(self=None):
        assert 'field1' in SubSchema.fields
        assert 'field2' in SubSchema.fields
        assert 'field3' in SubSchema.fields
        assert len(SubSchema.fields) == 3
    test_SchemaMetaclass_1()


# Generated at 2022-06-22 06:17:15.498767
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    try:
        iter(SchemaDefinitions())
    except Exception:
        raise AssertionError("lambda")
    else:
        pass


# Generated at 2022-06-22 06:17:16.856276
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-22 06:17:19.117989
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["test"] = "test"
    return definitions["test"] == "test"


# Generated at 2022-06-22 06:17:19.794060
# Unit test for constructor of class Reference
def test_Reference():
    pass

# Generated at 2022-06-22 06:17:24.436842
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    assert not definitions
    value = {"fido": "dog", "zeus": "dog"}
    definitions = SchemaDefinitions(value)
    assert len(definitions) == 2
    assert definitions
    assert definitions["fido"] == "dog"


# Generated at 2022-06-22 06:17:25.914119
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    SchemaMetaclass___new__()



# Generated at 2022-06-22 06:17:30.391025
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Test: calling __len__ on an instance of SchemaDefinitions
    # should return the length of the definitions
    definitions = SchemaDefinitions()
    definitions["name"] = "value"
    assert len(definitions) == 1



# Generated at 2022-06-22 06:17:34.068720
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name="Charles", age="26")
    assert p.name == "Charles"
    assert p.age == 26
