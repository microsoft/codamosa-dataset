

# Generated at 2022-06-22 06:08:26.031142
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():

    # Initialize class
    class Test(Schema):
        field1 = Field()
        field2 = Field()

    # Validate that each field is in the fields dictionary
    for field in Test.fields.values():
        assert field in Test.fields.values()


# Generated at 2022-06-22 06:08:32.980266
# Unit test for constructor of class Reference
def test_Reference():
    class Test(object):
        def __init__(self, a, b=None):
            self.a = a
            self.b = b

    test_obj = Test("test", "test2")
    v_test = Reference("test_name", definitions={'test_name': Test})
    assert v_test.validate(test_obj) == test_obj
    assert v_test.serialize(test_obj) == {'a': 'test', 'b': 'test2'}



# Generated at 2022-06-22 06:08:39.534518
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class User(Schema):
        first_name = Field(str)
        last_name = Field(str, default="Smith")
    u = User(first_name="Bob", last_name="Doe")
    l = 0
    for i in u.__iter__():
        l += 1
    assert l == 2


# Generated at 2022-06-22 06:08:41.516761
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions()
    with pytest.raises(TypeError):
        definitions.__getitem__(1)


# Generated at 2022-06-22 06:08:49.589299
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        name = String()
    
        def __init__(self,name):
            self.name = name

        def __eq__(self, other):
            if not isinstance(other, self.__class__):
                return False
            return self.name == other.name
        
        def __hash__(self) -> int:
            hash_value = 0
            hash_value += hash(self.name)
            return hash_value

        def __repr__(self) -> str:
            class_name = self.__class__.__name__
            return f"{class_name}({self.name!r})"
    
    class UserSchema(Schema):
        email_address = String()
        user = Reference(User)
    

# Generated at 2022-06-22 06:08:50.765551
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert True



# Generated at 2022-06-22 06:08:55.632334
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    print("test_Schema___getitem__")
    schema = Schema({"a": 1, "b": 2})
    assert schema["a"] == 1
    assert schema["b"] == 2


# Generated at 2022-06-22 06:09:01.448331
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Test case 1
    test_obj = SchemaDefinitions()
    test_definitions = dict()
    test_obj._definitions = test_definitions
    assert test_obj is not None
    test_obj.__delitem__("")
    assert test_obj._definitions is not None
    assert test_obj._definitions == test_definitions


# Generated at 2022-06-22 06:09:04.927854
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class A(Schema):
        a = Field(type="string")
    a = A.validate({"a" : "a"})
    assert a['a'] == a.a


# Generated at 2022-06-22 06:09:07.294936
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    schema = Field()
    field = Reference(to=schema)
    set_definitions(field, definitions)
    assert field.definitions is definitions
    assert field.target is schema

# Generated at 2022-06-22 06:09:21.396746
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Case 1:
    s = Schema(
        {"category": "music", "format": "vinyl", "genre": "jazz"}
    )
    assert s["category"] == "music"
    assert s["format"] == "vinyl"
    assert s["genre"] == "jazz"

    # Case 2:
    assert "abc" not in s
    try:
        s["abc"]
    except KeyError:
        pass
    else:
        assert False




# Generated at 2022-06-22 06:09:28.889606
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    assert list(definitions.keys()) == []
    definitions["test"] = 1
    assert len(definitions) == 1
    assert list(definitions.keys()) == ["test"]
    assert list(definitions.values()) == [1]
    assert list(definitions.items()) == [("test", 1)]
    assert "test" in definitions
    del definitions["test"]
    assert len(definitions) == 0
    assert list(definitions.keys()) == []
    definitions["test"] = 1
    definitions["test2"] = 2
    definitions["test3"] = 3
    definitions["test4"] = 4
    assert len(definitions) == 4

# Generated at 2022-06-22 06:09:33.092814
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class A(Schema):
        a1 = Field(type="string")
        a2 = Field(type="string")
        a3 = Field(type="string")
    a = A(a1="b")
    assert set(a.__iter__()) == set(['a1'])



# Generated at 2022-06-22 06:09:38.667739
# Unit test for method validate of class Reference
def test_Reference_validate():
    # set up the SchemaDefinitions dict with two schemas
    definitions = SchemaDefinitions()
    class schema_1(Schema):
        field_1 = Integer()
    class schema_2(Schema):
        field_2 = String()
    definitions['schema_1'] = schema_1
    definitions['schema_1'] = schema_2

    # test that a schema_1 can be successfully validated
    schema_1_validated = schema_1.validate('{"field_1": 1}')
    assert schema_1_validated.field_1 == 1
    # test that a string reference works
    reference_to_schema_1 = Reference(to='schema_1', definitions=definitions)

# Generated at 2022-06-22 06:09:45.487334
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class User(Schema):
        name = Field()
        email = Field()
    class ExampleSchema(Schema):
        user = Reference(to=User)
        message = Field()
    u = User({"name": "Jonathan", "email": "jonathan@example.org"})
    s = ExampleSchema({"user": u, "message": "Hello world!"})
    assert s.serialize() == {'user': {'name': 'Jonathan', 'email': 'jonathan@example.org'}, 'message': 'Hello world!'}



# Generated at 2022-06-22 06:09:46.065922
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    pass

# Generated at 2022-06-22 06:09:48.106579
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    print(SchemaDefinitions.__getitem__.__doc__)
    definitions = SchemaDefinitions()
    assert definitions["test"] == None


# Generated at 2022-06-22 06:09:52.842011
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    assert ("test", "test") not in definitions
    definitions["test"] = "test"
    assert ("test", "test") in definitions
    try:
        definitions["test"] = "test"
        assert False
    except AssertionError as e:
        pass


# Generated at 2022-06-22 06:09:58.875998
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    # create fields objects
    schema_field = Object(properties={"a": Field(), "b": Field()})
    
    # create a class
    class Schema(metaclass=SchemaMetaclass):
        a = Field()
        b = Field()
        # add schema field to class
        schema_field

    # test the fields in the class
    assert(list(Schema.fields.keys()) == ["a", "b", "schema_field"])
    
test_SchemaMetaclass()

# Generated at 2022-06-22 06:10:02.069487
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Noop(Schema):
        pass
    assert len(Noop()) == 0
    class One(Schema):
        a = Field(String)
    assert len(One()) == 0
    assert len(One(a="x")) == 1



# Generated at 2022-06-22 06:10:17.797758
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    def test():
        class Test(Schema):
            x = Field(name="x")
            y = Field(name="y")

        v = Test(x=2, y=3)
        assert isinstance(v, Schema)
        assert v.x == 2 and v.y == 3
        assert Reference(Test).serialize(v) == {'x': 2, 'y': 3}
    test()



# Generated at 2022-06-22 06:10:22.929559
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    def set_definitions_inner(definitions: SchemaDefinitions):
        definitions['Key'] = ['Value']
        definitions['Key'] = ['Value']

    schema_definitions = SchemaDefinitions()

    try:
        set_definitions_inner(schema_definitions)
    except TypeError:
        assert False, 'Test failed'
    else:
        assert True, 'Test succeeded'

# Generated at 2022-06-22 06:10:27.006199
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()

    assert len(definitions) == 0

    def add_definitions(definitions):
        definitions['a'] = 1
        definitions['b'] = 2
        definitions['c'] = 3

    add_definitions(definitions)

    assert len(definitions) == 3


# Generated at 2022-06-22 06:10:35.206999
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class BaseSchema(Schema):
        name = String()


# Generated at 2022-06-22 06:10:44.084524
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    assert len(s) == 0

    s = SchemaDefinitions({"a": 1, "b": 2})

    # Test __getitem__
    assert s["a"] == 1
    assert s["b"] == 2
    # Test __iter__
    assert list(s) == ["a", "b"]
    # Test __len__
    assert len(s) == 2
    # Test __setitem__
    assert "c" not in s
    s["c"] = 3
    assert s["c"] == 3
    # Test __delitem__
    del s["c"]
    assert s == {"a": 1, "b": 2}
    

# Generated at 2022-06-22 06:10:54.138295
# Unit test for function set_definitions
def test_set_definitions():
    def test_scenario(field: Field, definitions: SchemaDefinitions) -> None:
        set_definitions(field, definitions)
        assert field.definitions == definitions

    # Reference
    definitions = SchemaDefinitions()
    ref = Reference("Person", definitions=definitions)
    test_scenario(ref, definitions)
    # Reference already has a definition
    ref = Reference("Person", definitions=SchemaDefinitions())
    test_scenario(ref, definitions)

    # Array
    ref = Array(Reference("Person", definitions=definitions))
    test_scenario(ref, definitions)
    # Array has a list of References
    ref = Array([Reference("Person", definitions=definitions)])
    test_scenario(ref, definitions)

    # Array of Array with a Reference

# Generated at 2022-06-22 06:11:04.556722
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field1 = Reference("not_a_real_field")
        field2 = Object(properties={"field2": String()})
        field3 = Array(items=Reference("not_a_real_field"))
        field4 = Array(items=Array(items=Integer(maximum=64)))

    assert TestSchema.fields["field1"].definitions is None
    assert TestSchema.fields["field2"].properties["field2"].definitions is None
    assert TestSchema.fields["field3"].items.definitions is None
    assert TestSchema.fields["field4"].items.items.maximum == 64

    set_definitions(TestSchema, SchemaDefinitions())

    assert TestSchema.fields["field1"].definitions is not None
    assert TestSchema.fields

# Generated at 2022-06-22 06:11:07.740016
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    d = SchemaDefinitions()
    d["A"] = "B"
    assert d["A"] == "B"
    d["A"] = "C"  # Should not raise

# Generated at 2022-06-22 06:11:13.205362
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    definitions["alice"] = "bob"
    assert len(definitions) == 1
    definitions["charlie"] = "delta"
    assert len(definitions) == 2
    #TODO write more tests


# Generated at 2022-06-22 06:11:19.514927
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        last_name = String()
        first_name = String(default="Bill")

    person = Person(first_name="Lisa", last_name="Simpson")
    assert person.__iter__() == {'first_name', 'last_name'}
    assert list(person.__iter__()) == ['first_name', 'last_name']


# Generated at 2022-06-22 06:11:34.880590
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    s = SchemaDefinitions()
    assert s[1] == dict[1]

# Generated at 2022-06-22 06:11:38.554625
# Unit test for function set_definitions
def test_set_definitions():
    class Inner(Schema):
        foo = Field()

    class Outer(Schema):
        inner = Reference(Inner)

    definitions = SchemaDefinitions()
    set_definitions(Outer, definitions)
    assert definitions["Inner"] == Inner



# Generated at 2022-06-22 06:11:43.530837
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import Boolean
    from typesystem.fields import Integer

    class Foo(Schema):
        enabled = Boolean()
        number = Integer()

    f = Foo(enabled=True, number=2)
    assert f['enabled'] == True
    assert f['number'] == 2


# Generated at 2022-06-22 06:11:48.520260
# Unit test for method validate of class Reference
def test_Reference_validate():
    result=Reference.validate(None)
    assert result == None

# Generated at 2022-06-22 06:11:53.048915
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Foo(Schema):
        id = Integer()
    foo1 = Foo(id=12)
    ref_obj = Reference(Foo)
    foo2 = ref_obj.validate(foo1)
    assert foo1 == foo2


# Generated at 2022-06-22 06:11:55.792107
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    '''
    Test for method __getitem__ of class Schema
    (unicode-escape)
    '''
    # test
    assert True == True

# Generated at 2022-06-22 06:11:59.594560
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    assert isinstance(s, MutableMapping)
    assert len(s._definitions) == 0
    assert s.__class__.__name__ == 'SchemaDefinitions'


# Generated at 2022-06-22 06:12:08.891049
# Unit test for method validate of class Reference

# Generated at 2022-06-22 06:12:18.197904
# Unit test for method validate of class Reference

# Generated at 2022-06-22 06:12:20.400947
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    obj = SchemaDefinitions(1, 2)
    # Test __init__
    if obj is None:
        pass


# Generated at 2022-06-22 06:13:16.942471
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema2(Schema):
        id = Field(type="integer")
        name = Field(type="string")

    schema = TestSchema2(id=123, name="Allen")
    assert schema["id"] == 123
    assert schema["name"] == "Allen"
    assert len(schema) == 2
    for item in schema:
        assert item in ["id", "name"]
    assert TestSchema2.fields["id"] == TestSchema2.fields["name"]


# Generated at 2022-06-22 06:13:26.520386
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    with pytest.raises(AssertionError):
        assert Schema(18)
    with pytest.raises(TypeError):
        assert Schema(type("Test", (Schema, ), {"a": Field(type="number")}), a=18)
    assert Schema(type("Test", (Schema, ), {"a": Field(type="number")}), a=18)
    with pytest.raises(TypeError):
        assert Schema(type("Test", (Schema, ), {"a": Field(type="number"), "b": Field(type="number")}), a=18)

# Generated at 2022-06-22 06:13:30.636711
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Field()

    class FooRef(Schema):
        foo = Reference("Foo")

    defs = SchemaDefinitions()
    set_definitions(FooRef().fields["foo"], defs)
    assert defs["Foo"] == Foo

# Generated at 2022-06-22 06:13:36.719708
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference.serialize(3) == 3
    assert Reference.serialize("coucou") == "coucou"
    assert Reference.serialize([3, "coucou"]) == [3, "coucou"]
    assert Reference.serialize({'key': 'value'}) == {'key':'value'}


# Generated at 2022-06-22 06:13:41.769973
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test 1
    schema = Schema()
    schema.fields = {'name': 'Pierre', 'age': 34}
    assert schema['name'] == 'Pierre'



# Generated at 2022-06-22 06:13:51.230497
# Unit test for constructor of class Schema
def test_Schema():
    # test for for initializing an instance of Schema
    schema1 = Schema()
    assert schema1.fields == {}

    # test for for initializing an instance of Schema
    schema2 = Schema({"fields": {}})
    assert schema2.fields == {}
    assert type(schema2) == Schema

    schema3 = Schema(fields={})
    assert schema3.fields == {}
    assert type(schema3) == Schema

    with pytest.raises(TypeError):
        Schema(fields=None)

    with pytest.raises(TypeError):
        Schema(None)



# Generated at 2022-06-22 06:14:01.289099
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Address(Schema):
        number = Field(int)
        street = Field(str)
        city = Field(str)
        state = Field(str)
        postal_code = Field(str)
    address = Address(number=123, street='Main St')
    assert repr(address) == "Address(number=123, street='Main St') [sparse]"
    other = Address(number=123, street='Main St')
    dct = {'number': 123, 'street': 'Main St'}
    assert repr(Address(dct)) == "Address(number=123, street='Main St') [sparse]"
    assert repr(Address()) == "Address([sparse])"
    assert repr(address) == repr(other)
    assert repr(address) != repr(dct)


# Generated at 2022-06-22 06:14:01.943706
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    ...

# Generated at 2022-06-22 06:14:06.032882
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = {'is_sparse': bool,}
    definitions = SchemaDefinitions(definitions)
    field = bool
    definitions['is_sparse'] = field
    assert  definitions['is_sparse'] == bool


# Generated at 2022-06-22 06:14:08.846027
# Unit test for function set_definitions
def test_set_definitions():
    class User(Schema):
        id = Field()

    definitions = SchemaDefinitions()
    set_definitions(Reference("User"), definitions)
    assert definitions["User"] == User

# Generated at 2022-06-22 06:14:46.486673
# Unit test for constructor of class Schema
def test_Schema():
    class Test(Schema):
        field1 = Field(required=True)
        field2 = Field(required=False)
    test = Test(field1='test1', field2='test2')
    assert test.field1 == 'test1'
    assert test.field2 == 'test2'
    assert str(test) == "Test(field1='test1', field2='test2')"
    assert repr(test) == "Test(field1='test1', field2='test2')"
    assert test == Test(field1='test1', field2='test2')
    assert test != Test(field1='test1')
    assert list(test) == ['field1', 'field2']
    assert len(test) == 2


# Generated at 2022-06-22 06:14:48.997395
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(to="A").serialize(None) == None
    assert Reference(to="A").serialize({}) == {}

# Generated at 2022-06-22 06:15:00.559609
# Unit test for constructor of class Schema
def test_Schema():
    
    class Payload(Schema):
        id = 'asd'
        name = 'asd'
        image = 'asd'
        message = 'asd'

    payload = Payload()
    print(payload)

    class Person(Schema):
        first_name = 'asd'
        last_name = 'asd'
        city = 'asd'
        state = 'asd'
    
    person = Person(first_name='asd')
    print(person)
    
    class Person(Schema):
        first_name = 'asd'
        last_name = 'asd'
        city = 'asd'
        state = 'asd'

    person = Person(first_name='asd', last_name='asd', city='cid', state='sad')
   

# Generated at 2022-06-22 06:15:02.292938
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schema = SchemaDefinitions()
    assert isinstance(schema, SchemaDefinitions) == True
    return



# Generated at 2022-06-22 06:15:13.888566
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem.types as types
    import typesystem.fields as fields
    definitions = types.SchemaDefinitions()
    class TestClass(metaclass=types.SchemaMetaclass, definitions=definitions):
        string_field = types.String(max_length=10)
        int_field = types.Integer(minimum=0, maximum=10)
        reference_field = types.Reference('Example')
    assert(len(definitions) == 1)
    assert(isinstance(definitions['TestClass'], type))
    assert(isinstance(definitions['TestClass'].fields['string_field'], fields.String))
    assert(isinstance(definitions['TestClass'].fields['int_field'], fields.Integer))

# Generated at 2022-06-22 06:15:16.838584
# Unit test for constructor of class Schema
def test_Schema():
    SchemaClass = Schema
    assert SchemaClass.fields == {}
    obj = SchemaClass()
    assert len(obj) == 0


# Generated at 2022-06-22 06:15:27.854015
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Book(Schema):
        title = String()
        author = String()
        isbn = String()
        publisher = String()

    class Author(Schema):
        name = String()
        email = String()
        books = Array(items=Reference(Book))
        book_ref = Reference(Book)

    test_author = Author(
        name='test',
        email='test@test.com',
        books=[
            Book(
                title='test_title',
                author='test',
                isbn='123456',
                publisher='test_publisher'
            )
        ],
        book_ref=Reference(Book)
        )
    assert test_author.validate({'name': 'test'}) == {'name': 'test'}

# Generated at 2022-06-22 06:15:36.396282
# Unit test for function set_definitions
def test_set_definitions():
    class ChildSchema(Schema):
        __doc__ = "docstring"

        i = Field(Integer, description="A property")
        s = Field(String, description="A property")

    class ParentSchema(Schema):
        a = Field(Integer, description="A property")
        b = Field(Integer, description="A property")
        c = Reference("ChildSchema", description="A property", nullable=True)

    definitions = SchemaDefinitions()

    # Test Reference field `c` of `ParentSchema`:
    assert (
        ParentSchema.fields["c"].definitions is None
    ), "Field definitions not set."
    set_definitions(ParentSchema.fields["c"], definitions)
    assert (
        ParentSchema.fields["c"].definitions is definitions
    ), "Field definitions not set."

# Generated at 2022-06-22 06:15:41.162093
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import json
    import typesystem

    type_schema = typesystem.Schema.type("Schema")
    value__len__, error__len__ = type_schema.validate__len__("Schema")
    assert error__len__ == None

# Generated at 2022-06-22 06:15:43.822541
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    defns = SchemaDefinitions({"a": 1, "b": 2})
    del defns["a"]
    assert not hasattr(defns, "_a")


# Generated at 2022-06-22 06:16:50.890700
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    class A(Schema):
        pass
    class B(Schema):
        pass
    a_fields = A.fields
    b_fields = B.fields
    a_fields_count = len(a_fields)
    b_fields_count = len(b_fields)
    a_fields_count_new = a_fields_count if a_fields_count <= b_fields_count else b_fields_count
    b_fields_count_new = b_fields_count if a_fields_count <= b_fields_count else a_fields_count
    assert a_fields_count_new == 0
    assert b_fields_count_new == 0
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    definitions['A'] = A
    assert A == definitions['A']
    assert A == dict

# Generated at 2022-06-22 06:16:59.968264
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class Foo(Schema):
        person = Reference(Person)
        persons = Reference(Person, list=True)
        people = Reference(Person, list=True, default=[])

    foo = Foo(
        person=Person(name="John", age=23),
        persons=[Person(name="Jane", age=24), Person(name="Jane", age=25)],
    )
    assert foo.person == {"name": "John", "age": 23}
    assert foo.persons == [{"name": "Jane", "age": 24}, {"name": "Jane", "age": 25}]
    assert foo.people == []



# Generated at 2022-06-22 06:17:04.225618
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    obj = SchemaDefinitions()
    #Test whether the key will be added.
    obj['a'] = 1
    assert obj['a'] == 1
    #Test whether the value will be added.
    assert obj._definitions['a'] == 1


# Generated at 2022-06-22 06:17:12.089952
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Setup data
    name = "Person"
    bases = []
    attrs = {'age': 42, 'money': 'dollar'}
    definitions: SchemaDefinitions = SchemaDefinitions()
    # Execute the code to be tested
    type = SchemaMetaclass.__new__(SchemaMetaclass, name, bases, attrs, definitions)
    # Verify the outcome
    assert type is not None
    assert type.__name__ == name
    assert type.fields['age'] == 42
    assert type.fields['money'] == 'dollar'

# Generated at 2022-06-22 06:17:22.467621
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import copy
    import pytest
    from typesystem.fields import String

    class Person(Schema):
        name = String()
        age = String()

    def test_cases() -> typing.List[typing.Tuple[Person, typing.Iterator[str]]]:
        return [
            (Person(), iter([])),
            (Person(name="Bob"), iter(["name"])),
            (Person(age="23"), iter(["age"])),
            (Person(name="Bob", age="23"), iter(["name", "age"])),
        ]

    for case in test_cases():
        value = copy.copy(case[0])
        actual = value.__iter__()
        expected = copy.copy(case[1])
        assert list(actual)  == list(expected)



# Generated at 2022-06-22 06:17:25.400282
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    def check(key, expected):
        actual = SchemaDefinitions.__getitem__(key)
        assert actual == expected, f"Expected {expected!r}, got {actual!r}."
    check(None, None)


# Generated at 2022-06-22 06:17:28.184267
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    assert len(s) == 0
    assert type(s) == SchemaDefinitions


# Generated at 2022-06-22 06:17:35.441131
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    properties = {'name': String(max_length=30), 'age': Integer(minimum=0)}
    test_class = Object(properties=properties)
    test_field = Reference(to=test_class)
    assert test_field.target == test_class, "Target not correct!"
    test_obj = test_class({'name': 'Alice', 'age': 22})
    assert test_field.serialize(test_obj) == {'name': 'Alice', 'age': 22}, "Serialization not correct!"

# Generated at 2022-06-22 06:17:37.758593
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    instance = SchemaDefinitions({'x': object})
    instance.__delitem__('x')
    assert not 'x' in instance


# Generated at 2022-06-22 06:17:46.675416
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    """
    class Foo(Schema):
        a = Integer()
        b = String(allow_null=True)

    >>> foo = Foo(a=1, b="hello")
    >>> foo["a"]
    1
    >>> foo["b"]
    'hello'
    >>> foo["c"]
    Traceback (most recent call last):
       ...
    KeyError: 'c'
    >>> foo = Foo(a=2)
    >>> foo["b"]
    Traceback (most recent call last):
       ...
    KeyError: 'b'
    """
    pass

