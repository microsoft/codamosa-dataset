

# Generated at 2022-06-22 06:08:10.298655
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=22)
    assert(len(person) == 2)

# Generated at 2022-06-22 06:08:13.900258
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    foo = String()
    bar = String()
    definitions["Foo"] = foo
    try:
        definitions["Foo"] = bar
        assert False, "UNEXPECTED VALUE"
    except AssertionError as e:
        assert str(e) == r"Definition for 'Foo' has already been set."



# Generated at 2022-06-22 06:08:17.300615
# Unit test for method validate of class Reference
def test_Reference_validate():
    with pytest.raises(Exception) as e:
        Reference("obj", allow_null=False, definitions=SchemaDefinitions).validate(None)
    assert e.type == ValidationError



# Generated at 2022-06-22 06:08:25.046832
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    '''
    Tests object representation of Schema, which is basically a dictionary.
    The serialized attribute was tested in test-seralize.py
    '''
    class Person(Schema):
        name = String()
        age = Integer()
        hometown = String(required=False)

    person = Person(dict(name='Jane', age=37))
    assert person['name'] == 'Jane'
    assert person['age'] == 37
    assert person['hometown'] == ''
    assert person['something_else'] == ''

# Generated at 2022-06-22 06:08:28.255186
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # setup
    definitions = SchemaDefinitions()
    definitions[1] = 1
    # test
    del definitions[1]
    # assert
    assert 1 not in definitions._definitions

# Generated at 2022-06-22 06:08:29.589313
# Unit test for constructor of class Schema
def test_Schema():
    assert bool(Schema)


# Generated at 2022-06-22 06:08:35.088415
# Unit test for function set_definitions
def test_set_definitions():
	class ExampleSchema(Schema):
		test = Reference('test')

	test_defs = SchemaDefinitions()
	test_defs['test'] = ExampleSchema
	set_definitions(ExampleSchema.fields['test'], test_defs)
	assert ExampleSchema.fields['test'].definitions == test_defs

if __name__ == '__main__':
	test_set_definitions()

# Generated at 2022-06-22 06:08:38.413342
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions(a="spam")
    assert len(schema_definitions) == 1


# Generated at 2022-06-22 06:08:39.068324
# Unit test for function set_definitions
def test_set_definitions():
    pass

# Generated at 2022-06-22 06:08:40.463148
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd = SchemaDefinitions()
    assert len(sd) == 0



# Generated at 2022-06-22 06:09:02.119316
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    """
    Test result of serialize of Reference class
    """
    from typing import Any
    from unittest.mock import Mock
    
    mock_obj: Mock(Any) = Mock()
    mock_obj.serialize = lambda obj: 'test'
    ref: Reference = Reference('test')
    ref._target = mock_obj
    
    assert ref.serialize(None) is None
    assert ref.serialize('test') == 'test'

# Generated at 2022-06-22 06:09:04.242671
# Unit test for function set_definitions
def test_set_definitions():
    definition = SchemaDefinitions()
    schema = Schema()
    set_definitions(schema, definition)

# Generated at 2022-06-22 06:09:13.480521
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    t1 = None
    t2 = None
    t3 = None
    t4 = None
    t5 = None
    t6 = None
    t7 = None
    t8 = None
    t9 = None
    t10 = None
    t11 = None
    t12 = None
    t13 = None
    t14 = None
    t15 = None
    t16 = None
    t17 = None
    t18 = None
    t19 = None
    t20 = None
    t21 = None
    t22 = None
    t23 = None
    t24 = None
    t25 = None
    t26 = None
    t27 = None
    t28 = None
    t29 = None
    t30 = None
    t31 = None
    t32 = None
    t33 = None
   

# Generated at 2022-06-22 06:09:14.951731
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema(a=1, b=2)
    s.a
    s.b


# Generated at 2022-06-22 06:09:21.616346
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    print('Running test_Schema___getitem__...')
    class User(Schema):
        id = Field(type=int)
        name = Field(type=str)

    user = User(id=1, name='John Doe')
    assert user["id"] == 1
    assert user["name"] == 'John Doe'
    try:
        user["age"]
        pass
    except KeyError:
        assert True
    else:
        assert False, 'test_Schema___getitem__ fail'


# Generated at 2022-06-22 06:09:32.475459
# Unit test for constructor of class Schema

# Generated at 2022-06-22 06:09:36.352190
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class SimpleSchema(Schema, metaclass=SchemaMetaclass):
        name = Field()

    assert SimpleSchema.__name__ == "SimpleSchema"
    assert SimpleSchema.fields == {"name": Field(name="name")}


# Generated at 2022-06-22 06:09:40.951760
# Unit test for constructor of class Schema
def test_Schema():
  # Arrange
  class SampleSchema(Schema):
    name = Field(str)
    price = Field(float)

  name = 'Coke'
  price = 1.50
  expected = {'name': 'Coke', 'price': 1.50}

  # Act
  actual = SampleSchema(name, price)

  # Assert
  assert actual.name == expected['name']
  assert actual.price == expected['price']


# Generated at 2022-06-22 06:09:50.540397
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    from typesystem.base import String
    from typesystem import Schema, Reference
    class Person(Schema):
        name = String()
    definitions["Person"] = Person
    class User(Schema):
        person = Reference("Person")
    definitions["User"] = User
    assert isinstance(definitions["User"], type)
    assert issubclass(definitions["User"], Schema)
    assert isinstance(definitions["User"].fields["person"], Reference)
    assert isinstance(definitions["User"].fields["person"].target, type)
    assert issubclass(definitions["User"].fields["person"].target, Schema)
    assert isinstance(definitions["User"].fields["person"].target.fields["name"], String)


# Generated at 2022-06-22 06:10:00.445396
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Create a class PhoneNumber
    class PhoneNumber(Schema):
        country_code = Field(int, required=True)
        number = Field(str, required=True)

    # Create a class Person
    class Person(Schema):
        name = Field(str, required=True)
        addresses = Array(String, required=False)
        phone_number = Object(PhoneNumber, required=False)

    # Create a instance of Person
    p1 = Person.validate(
        {
            "name": "John Smith",
            "addresses": ["1 Apple Street", "2 Banana Street"],
            "phone_number": {"country_code": 1, "number": "555-555-5555"},
        }
    )

    # Create a instance of Person

# Generated at 2022-06-22 06:10:16.014707
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    """
    1
    """
    a = SchemaDefinitions()
    a["hello"] = "world"
    a["hello"]



# Generated at 2022-06-22 06:10:19.209473
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from .models import Author, Book
    author = Author(name="Test User", age=10)
    book = Book(title="Unit Testing", author=author)
    assert len(book) == 2



# Generated at 2022-06-22 06:10:29.665874
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from .compat import TYPE_CHECKING, expected_warnings

    class MySchema(Schema):
        firstname = Field(required=True)
        lastname = Field(required=True)
        age = Field(required=True)
        nickname = Field()
        height = Field()

    @expected_warnings(["temporary class"])
    def get_schema_fields_keys(schema):
        return list(schema)

    assert get_schema_fields_keys(MySchema(firstname="A", lastname="B", age=1)) == [
        "firstname",
        "lastname",
        "age",
    ]

# Generated at 2022-06-22 06:10:34.411908
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions({'one': 1, 'two': 2})
    #  Sort fields by their actual position in the source code,
    # using Field._creation_counter
    assert definitions == {'one': 1, 'two': 2}


# Generated at 2022-06-22 06:10:45.206240
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field()
        b = Field()

    # Test 1: check argument `a` and `b`
    obj = TestSchema(a = 0, b = 1)
    assert obj.a == 0 and obj.b == 1
    # Test 2: check argument `a` and `b`
    obj = TestSchema({'a':0, 'b':1})
    assert obj.a == 0 and obj.b == 1
    # Test 3: check argument `a` and `b`
    obj = TestSchema(TestSchema(a = 0, b = 1))
    assert obj.a == 0 and obj.b == 1
    # Test 4: check argument `a` and `b`
    obj = TestSchema(a = 0)
    assert obj.a == 0 and obj

# Generated at 2022-06-22 06:10:46.676183
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj=SchemaDefinitions()

    res=obj.__len__()
    assert res==0

# Generated at 2022-06-22 06:10:51.755120
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class SubSchema(Schema):
        name = String()

    class MySchema(Schema):
        ref = Reference(SubSchema)

    schema = MySchema({"name": "abc"})
    assert schema.ref.serialize(schema) == {"name": "abc"}
    assert schema.serialize() == {"ref": {"name": "abc"}}



# Generated at 2022-06-22 06:10:56.968602
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import typesystem
    schema = typesystem.Schema(x = typesystem.String())
    assert(repr(schema) == 'Schema(x="")')
    schema = typesystem.Schema(x = typesystem.String(), y=typesystem.Integer())
    assert (repr(schema) == 'Schema(x="", y=0)')

# Generated at 2022-06-22 06:11:08.197524
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from .fields import Boolean, Field, Float, Integer, String

    class SimpleClass(Schema):
        name = Field(type=String)

    class SubClass(SimpleClass):
        age = Field(type=Integer)

    assert SubClass.fields.keys() == {"name", "age"}

    class SubClass2(SubClass):
        height = Field(type=Float)

    assert SubClass2.fields.keys() == {"name", "age", "height"}

    class SubClass3(SubClass2):
        active = Field(type=Boolean)

    assert SubClass3.fields.keys() == {"name", "age", "height", "active"}

    class SubClass4(SubClass2):
        name = Field(type=Integer)

    assert SubClass4.fields.keys() == {"name", "age", "height"}



# Generated at 2022-06-22 06:11:19.594686
# Unit test for function set_definitions
def test_set_definitions():

    fields: typing.Dict[str, Field] = {}

    # Reference field
    fields["field_1"] = Reference('model_2', additionalProperties=False, default=None)

    # Array field with Reference item
    field_2 = Array(Reference('model_2'))

    # Array field with list items
    field_3 = Array([Reference('model_2'), Reference('model_3'), Reference('model_4')])

    # Object field with multiple field properties
    properties = {
        "field_4": Reference('model_2'),
        "field_5": Reference('model_3'),
        "field_6": Reference('model_4'),
    }

# Generated at 2022-06-22 06:12:06.278129
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        s = Field(String())
    class B(A):
        d = Field(Dict(["a", "b"], s))
    definitions = SchemaDefinitions()
    set_definitions(B(), definitions)
    assert B.d.items[0].definitions is definitions

# Generated at 2022-06-22 06:12:12.975593
# Unit test for method validate of class Reference
def test_Reference_validate():
    """
    Test case: Valid value
    """
    class A(Schema):
        x = Field()
        y = Field()
    class B(Schema):
        a = Reference(A)
        b = Field()

    val = {'x': 'x_val', 'y': 'y_val'}
    b_obj = B.validate({'a': val, 'b': 'b_val'})
    assert b_obj.a == val

# Generated at 2022-06-22 06:12:15.224169
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert hasattr(Schema, '__len__'), 'Class does not have method __len__'


# Generated at 2022-06-22 06:12:20.941936
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()

    person1 = Person()
    person2 = Person(name='Alice', age=20)

    # test empty instance
    assert person1['name'] == None
    assert person1['age'] == None

    # test populated instance
    assert person2['name'] == 'Alice'
    assert person2['age'] == 20

# Generated at 2022-06-22 06:12:29.870489
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    from typesystem.fields import String
    from typesystem.object import (DEFAULT_MESSAGES,
                                   ObjectOptions, get_field_options)
    from typesystem.schema import SchemaMetaclass
    from typesystem.types import (Boolean, Float, Integer, Number, String,
                                  Union)


    # This is an auto-generated test.

# Generated at 2022-06-22 06:12:42.174014
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Foo(Schema):
        a = String()
        b = Integer()
        c = Integer()

    assert dict(Foo.fields) == {"a": String(), "b": Integer(), "c": Integer()}

    class Foo_Sub(Foo):
        c = Float()

    assert dict(Foo_Sub.fields) == {"a": String(), "b": Integer(), "c": Float()}

    assert list(Foo_Sub.fields.keys()) == ["a", "b", "c"]
    a = Foo_Sub(a="foo", b=2, c=3.0)
    assert a.a == "foo"
    assert a.b == 2
    assert a.c == 3.0
    b = Foo_Sub({"a": "foo", "b": 2, "c": 3.0})
   

# Generated at 2022-06-22 06:12:46.234816
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        test = "test"
    assert TestSchema(test = 'test').__repr__() == "TestSchema(test='test')"


# Generated at 2022-06-22 06:12:56.854548
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema(Schema):
        a = Integer()
        b = String()
        c = Integer(default=1)
        d = String(default="")
        e = Integer(default=1, allow_null=True)
        f = String(default="", allow_null=True)
        g = Integer(default=1, allow_null=False)
        h = String(default="", allow_null=False)


# Generated at 2022-06-22 06:13:02.458157
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert Schema(item1="1", item2="2") == Schema(item1="1", item2="2")
    assert not (Schema(item1="1", item2="2") == Schema(item1="3", item2="4"))


# Generated at 2022-06-22 06:13:08.935162
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    try:
        d = SchemaDefinitions()
        assert d is not None
        assert len(d) == 0
    except:
        assert False


# Generated at 2022-06-22 06:13:33.171302
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert_equal(SchemaDefinitions({'key1': 'value1'})['key1'], 'value1')
    assert_equal(SchemaDefinitions({'key1': 'value1', 'key2': 'value2'})['key2'], 'value2')
    assert_raises(KeyError, lambda: SchemaDefinitions({'key1': 'value1'})['key2'])


# Generated at 2022-06-22 06:13:38.243516
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    test_schemaDefinitions = SchemaDefinitions()
    assert list(test_schemaDefinitions) == []
    test_schemaDefinitions['1'] = 1
    assert list(test_schemaDefinitions) == ['1']
    test_schemaDefinitions['2'] = 2
    assert list(test_schemaDefinitions) == ['1', '2']


# Generated at 2022-06-22 06:13:47.389238
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    test_class = SchemaDefinitions()
    assert len(test_class) == 0

    test_class["a"] = 2
    assert len(test_class) == 1

    test_class["b"] = 3
    assert len(test_class) == 2

    del test_class["a"]
    assert len(test_class) == 1
    assert test_class["b"] == 3

    del test_class["b"]
    assert len(test_class) == 0

# Generated at 2022-06-22 06:13:48.880391
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert "Schema({argument_str}){sparse_indicator}"


# Generated at 2022-06-22 06:13:54.742303
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        a = Field(type="string")
        b = Field(type="integer")

    obj = MySchema(a="hello", b=42)
    repr(obj)
    obj = MySchema(a="hello")
    repr(obj)
    obj = MySchema()
    repr(obj)

# Generated at 2022-06-22 06:14:03.068078
# Unit test for function set_definitions
def test_set_definitions():
    definition = SchemaDefinitions()
    a = Reference(
        "B", definitions=definition, description="A reference to B",
    )
    b = Object(
        properties={"name": Field(description="Name of object B")},
        definitions=definition,
    )
    set_definitions(a, definition)
    assert a.definitions is definition
    assert b.definitions is definition



# Generated at 2022-06-22 06:14:12.532776
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        first_name = Field()
        last_name = Field()

    assert Person(
        {"first_name": "John", "last_name": "Smith"}
    ) == Person(first_name="John", last_name="Smith")
    assert Person(first_name="John", last_name="Smith") == Person(
        first_name="John", last_name="Smith"
    )
    assert Person(first_name="John") != Person(first_name="John", last_name="Smith")
    assert Person(first_name="John") == Person(first_name="John")
    assert Person(first_name="John", last_name="Smith").is_sparse is False
    assert Person(first_name="John").is_sparse is True

# Generated at 2022-06-22 06:14:19.691483
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    class Car(Schema):
        make = String()
        model = String()

    class CarSchema(Schema):
        color = String()
        car = Reference("Car")

    definitions = SchemaDefinitions({"Car": Car})

# Generated at 2022-06-22 06:14:24.431534
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    _definitions = SchemaDefinitions()
    assert isinstance(_definitions, SchemaDefinitions)
    assert not callable(_definitions)
    assert not isinstance(_definitions, Mapping)
    assert not isinstance(_definitions, MutableMapping)
    assert len(_definitions) == 0



# Generated at 2022-06-22 06:14:25.619843
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    pass # FIXME



# Generated at 2022-06-22 06:14:55.171110
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # set up:
    class BookSchema(Schema):
        name = String(max_length=100)
        status = String(max_length=100)
    class_name = 'BookSchema'
    name = 'name'
    status = 'status'
    book = BookSchema(name="The World According to Garp", status="Read")
    # check if the method returns an iterator
    assert isinstance(iter(book), collections.abc.Iterator)
    # check if the iterator returns the right value
    assert [name, status] == [key for key in book]
    # check if the method returns an iterator
    assert isinstance(iter(book), collections.abc.Iterator)
    # check if the method returns an iterator
    assert isinstance(iter(book), collections.abc.Iterator)
    # check if the iterator returns the

# Generated at 2022-06-22 06:15:04.333623
# Unit test for function set_definitions
def test_set_definitions():
    class SubSchema(Schema):
        def_field = String()

    class MySchema(Schema):
        main_field = String()
        schema_field = Object(properties={"prop_field": String()})
        array_field = Array(items=String())
        ref_field = Reference("SubSchema")

    definitions = SchemaDefinitions()
    set_definitions(MySchema, definitions)

    assert definitions["SubSchema"] == SubSchema
    assert MySchema.ref_field.definitions == definitions
    assert MySchema.array_field.items.definitions == definitions
    assert MySchema.schema_field.properties["prop_field"].definitions == definitions

# Generated at 2022-06-22 06:15:12.118491
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions_dict=dict()
    definitions=SchemaDefinitions(definitions_dict)
    assert len(definitions) == 0
    definitions['test_schema'] = 123
    assert len(definitions) == 1
    assert definitions['test_schema'] == 123
    try:
        definitions['test_schema'] = 123
        assert False
    except:
        assert True
    assert 'test_schema' in definitions
    del definitions['test_schema']
    assert 'test_schema' not in definitions


# Generated at 2022-06-22 06:15:19.568613
# Unit test for method serialize of class Reference
def test_Reference_serialize():

    class ASchema(Schema):
        a = String(required=True)
        b = Integer(required=True)

    class SchemaTest(Schema):
        reference_a = Reference(to=ASchema)

    value = SchemaTest({"reference_a": {"a": "astring", "b": 2}})

    expected = value.reference_a
    result = Reference.serialize(value.reference_a)

    assert result == expected

# Generated at 2022-06-22 06:15:21.434620
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    assert len(SchemaDefinitions(dict(), dict())) == 0
    assert len(SchemaDefinitions({"a": 1, "b": 2, "c": 3})) == 3

# Generated at 2022-06-22 06:15:25.782268
# Unit test for constructor of class Reference
def test_Reference():
    obj = Reference('test', to='test', definitions=1)
    assert obj.allow_null
    assert obj.required == False
    assert obj.to == 'test'
    assert obj.definitions == 1
    assert obj.errors == {"null": "May not be null."}


# Generated at 2022-06-22 06:15:35.743072
# Unit test for method validate of class Reference
def test_Reference_validate():
    target_obj = {}
    target_obj['a'] = 'a'
    target_obj['b'] = 'b'
    target_obj['c'] = target_obj.copy()
   
    test_obj_1 = target_obj.copy()
    test_obj_1['d'] = 'd'
    test_obj_1['e'] = target_obj.copy()

    test_obj_2 = test_obj_1.copy()
    test_obj_2['d'] = 'd'
    test_obj_2['e'] = target_obj.copy()
    test_obj_2['f'] = test_obj_1.copy()

    test_obj_3 = test_obj_1.copy()
    test_obj_3['d'] = 'd'

# Generated at 2022-06-22 06:15:36.975476
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert True
    # TODO: Write unit test for method __eq__ of class Schema.
    raise NotImplementedError()


# Generated at 2022-06-22 06:15:41.179518
# Unit test for constructor of class Reference
def test_Reference():
    class FooSchema(Schema):
        pass
    assert Reference(to=FooSchema).to == FooSchema
    assert Reference(to="FooSchema").to == "FooSchema"
    assert Reference(to="FooSchema").target_string == "FooSchema"

# Generated at 2022-06-22 06:15:44.094878
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Order(Schema):
        order_id = String()
        price = Number()

    assert list(Order(order_id='order-1234', price=123.45)) == ['order_id', 'price']



# Generated at 2022-06-22 06:16:02.982720
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    definitions.add_class(1)
    assert len(definitions) == 1

# Generated at 2022-06-22 06:16:06.976323
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class test_SchemaMetaclass___new__Schema(Schema):
        def __init__(self):
            super().__init__()


    assert test_SchemaMetaclass___new__Schema.fields == {}

# Generated at 2022-06-22 06:16:19.433959
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    import typesystem

    def assert_schema():
        class TestSchema(Schema, metaclass=SchemaMetaclass):
            pass

        # TestSchema.__dict__.keys() returns all the fields of the object
        # as a dictionary of {name: value}
        assert set(TestSchema.__dict__.keys()) == {"fields"}
        assert isinstance(TestSchema.fields, dict)
        assert TestSchema.fields == {}
        assert TestSchema.__name__ == "TestSchema"

    # Each test case is a tuple where the first element is the arguments for
    # the SchemaMetaclass constructor, and the second element is the expected
    # result of the call to `SchemaMetaclass.__new__`

# Generated at 2022-06-22 06:16:26.152809
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert Schema().__repr__() == 'Schema()'
    assert Schema(foo='bar').__repr__() == "Schema(foo='bar')"
    assert Schema(foo=['bar']).__repr__() == "Schema(foo=['bar'])"
    assert Schema(foo=[Schema(bar=1)]).__repr__() == "Schema(foo=[Schema(bar=1)])"

test_Schema___repr__()

# Generated at 2022-06-22 06:16:31.865858
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    fields = {
        'name': str
    }
    class_name = 'Book'
    fields_field = 'fields'
    class_name_field = 'class_name'
    result_fields = {}
    result_class_name = 'Book'

    class Book(Schema, metaclass=SchemaMetaclass):
        fields = fields

    book = Book(Book)
    assert book[fields_field] == result_fields
    assert book[class_name_field] == result_class_name

# Generated at 2022-06-22 06:16:32.730675
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    pass


# Generated at 2022-06-22 06:16:36.091799
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        name = Field(str)
        email = Field(str)

    class Post(Schema):
        user = Reference(User)

    user_data = {
        "name": "John Doe",
        "email": "John@example.com",
    }

    post = Post(user=user_data)
    print(post.user)
    assert isinstance(post.user, User)
    assert post.user == User(user_data)


# Generated at 2022-06-22 06:16:48.239231
# Unit test for constructor of class Schema

# Generated at 2022-06-22 06:16:57.451382
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.base import Object
    from .objects import Person
    from .pets import Pet
    assert repr(Schema(name=Object(description="Name"))) == "Schema(name={'description': 'Name'})"
    assert repr(Person(name="Bob"))== "Person(name='Bob')"
    assert repr(Pet(name="Fluffy", owner=Person(name="Bob")))=="Pet(name='Fluffy', owner={'name': 'Bob'})"

# Generated at 2022-06-22 06:17:01.317212
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    s = Schema()
    ref = Reference(Schema)
    s2 = s.serialize(ref)
    assert isinstance(s2, dict)



# Generated at 2022-06-22 06:17:41.741233
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["key"] = "value"
    assert definitions["key"] == "value"
    assert len(definitions) == 1
    assert list(definitions.keys()) == ["key"]
    assert list(definitions.values()) == ["value"]
    assert list(definitions.items()) == [("key", "value")]


# Generated at 2022-06-22 06:17:49.577095
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class User(Schema):
        id = Reference(to="integer")
        first_name = String(max_length=128)
        last_name = String(max_length=128)
        age = Integer(minimum=18, maximum=70)
        class Meta:
            strict = True