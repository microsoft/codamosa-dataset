

# Generated at 2022-06-22 06:08:05.093008
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        name = Field(str)
        age = Field(int)
    test1 = TestSchema(name="Qiang", age=20)
    test2 = TestSchema(name="Qiang", age=20)
    assert test1 == test2
    test3 = TestSchema(name="Qiang", age=10)
    assert test1 != test3

# Generated at 2022-06-22 06:08:09.289020
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    def_obj = SchemaDefinitions()
    k = 'A'
    v = 'B'
    def_obj[k] = v
    result = iter(def_obj)
    assert k in result
    assert "C" not in result


# Generated at 2022-06-22 06:08:16.379589
# Unit test for method validate of class Reference
def test_Reference_validate():
    import pickle
    from typesystem.typing import String, Integer
    class Resource(Schema):
        c = Integer()
        d = String()

    class Response(Schema):
        a = Integer()
        b = Reference(Resource)

    response = Response(a=1, b=Resource(c=2, d="test"))

    response_dict = pickle.loads(pickle.dumps(response))
    assert(response_dict.a == 1)
    assert(response_dict.b.c == 2)
    assert(response_dict.b.d == "test")

test_Reference_validate()

# Generated at 2022-06-22 06:08:19.375067
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    
    x = Schema({"a":1})
    assert x.__repr__() == "Schema(a=1)"
    
    

# Generated at 2022-06-22 06:08:23.495117
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        email = String()

    class User(Schema):
        user_id = String()
        profile = Reference('Person')



# Generated at 2022-06-22 06:08:27.209415
# Unit test for method serialize of class Reference
def test_Reference_serialize():
	object_1 = {"test": "toto"}
	my_test = Reference.serialize(object_1)
	assert my_test == {"test": "toto"}, "serialize method should return test:toto"


# Generated at 2022-06-22 06:08:31.034573
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()

    assert not definitions

    definitions["foo"] = {}

    assert len(definitions) == 1

    assert "foo" in definitions

    del definitions["foo"]

    assert not definitions



# Generated at 2022-06-22 06:08:34.844652
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert True
    ds = DataSet.from_csv('Selections.csv')
    assert ds is not None




# Generated at 2022-06-22 06:08:42.722159
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    '''
    If a validator is not built from a string, it should contain a reference
    to its schema. This unit test ensures that __getitem__ in the class 
    SchemaDefinitions returns the correct schema when given the validator.
    '''
    class TestSchema(Schema):
        field = Field(str)
    definitions = SchemaDefinitions()
    definitions[TestSchema.__name__] = TestSchema
    validator = TestSchema.make_validator()
    assert definitions[validator] == TestSchema


# Generated at 2022-06-22 06:08:50.961500
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        field = Field(name="field")

    empty = MySchema()
    assert len(empty) == 0

    data = {"field": "test"}
    schema = MySchema(data)
    assert len(schema) == 1

    # If a field is not present in the data, it should not be counted
    class MySchemaWithDefaults(MySchema):
        field = Field(name="field", default="default")

    schema = MySchemaWithDefaults(data)
    assert len(schema) == 0

    # Schema is also sparse if it does not define a value for every field
    class SparseSchema(MySchema):
        field2 = Field(name="field2")

    schema = SparseSchema(data)
    assert len(schema) == 1



# Generated at 2022-06-22 06:09:09.988086
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import Object, String

    class Pet(Schema):
        name = String()

    class Person(Schema):
        pet = Reference(Pet)

    class Dog(Pet):
        woof = String()

    class PersonWithDog(Person):
        pet = Reference(Dog)

    dog_json = {
        "pet": {
            "name": "Rufus",
            "woof": "woof"
        }
    }
    person_with_dog = PersonWithDog.validate(dog_json)
    assert getattr(person_with_dog, "pet").name == "Rufus"
    assert getattr(getattr(person_with_dog, "pet"), "woof") == "woof"

    dog_json.pop("pet")
    person_with_dog = PersonWithDog.valid

# Generated at 2022-06-22 06:09:14.240189
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class AnimalSchema(Schema):
        name = Field(type="string")
        qty = Field(type="integer")

    schema = AnimalSchema(
        name="lion",
        qty="1"
    )
    expected = 2
    assert len(schema) == expected, f"Expected: {expected}, found: {len(schema)}"


# Generated at 2022-06-22 06:09:21.343326
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Set Up
    # Initialize a test set of definitions.
    definitions = SchemaDefinitions()

    # Exercise
    # Attempt to set the same definition twice.
    try:
        definitions['a'] = 1
        definitions['a'] = 2
    # Verify
    # Check that __setitem__() raises an exception when the definition has
    # already been set.
    except AssertionError:
        pass
    else:
        assert False, "Exception not raised."

    # Tear Down
    # No need to delete the definition.


# Generated at 2022-06-22 06:09:24.353229
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    a = 1
    b = 2
    c = 3
    schema = Schema({"a": a, "b": b, "c": c})
    assert len(schema) == 3



# Generated at 2022-06-22 06:09:29.473274
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    assert len(schema_definitions) == 0


# Generated at 2022-06-22 06:09:37.187930
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # 测试列表元素不存在时
    definitions1 = SchemaDefinitions()
    definitions1['asd'] = 'as'
    assert definitions1['asd'] == 'as'
    assert len(definitions1._definitions) == 1
    # 测试列表元素已经存在时
    try:
        definitions1['asd'] = 'as'
    except AssertionError:
        pass
    else:
        assert False


# Generated at 2022-06-22 06:09:41.282891
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    assert definitions["a"] == None
    try:
        definitions["a"]
    except KeyError:
        pass
    else:
        assert False, "Unexpected KeyError not raised."
    definitions["aa"] = "aa"
    assert definitions["aa"] == "aa"
    assert definitions.get("aa") == "aa"
    assert definitions.get("bb") == None
    assert definitions.get("bb", "bb") == "bb"
    try:
        definitions["b"] = "b"
        definitions["b"] = "b"
    except AssertionError:
        pass
    else:
        assert False, "Unexpected AssertionError not raised."
    try:
        assert definitions["b"]
    except KeyError:
        pass

# Generated at 2022-06-22 06:09:50.787260
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import fibs
    class Human(Schema):
        name = fibs.String()
        age = fibs.Integer(minimum=0)
        eyes = fibs.String()
    class Species(Schema):
        name = fibs.String()
        hands = fibs.Integer(minimum=0)
        human = fibs.Reference(Reference, Human)
    class Life(Schema):
        name = fibs.String()
        species = fibs.Reference(Reference, Species)
    life1 = Life(name="life1", species=Species(name="sp1", hands=2, human=Human(name="hum1", age=10, eyes="blue")))

# Generated at 2022-06-22 06:09:52.794987
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    c = SchemaDefinitions()
    assert len(c) == 0


# Generated at 2022-06-22 06:10:00.164872
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    foo_schema = Schema({"foo": String()})
    obj = foo_schema({"foo": "bar"})
    reference = Reference(foo_schema, definitions=None)
    result = reference.serialize(obj)
    expected = {'foo': 'bar'}
    assert result == expected


# Generated at 2022-06-22 06:10:19.266833
# Unit test for method validate of class Reference
def test_Reference_validate():
    # test for the case when value is None and self.allow_null is True
    ref = Reference(Array(String(description="test", enum=["test"])))
    ref.allow_null = True
    value = ref.validate(None)
    assert value is None

    # test for the case when value is None and self.allow_null is False
    ref = Reference(Array(String(description="test", enum=["test"])))
    try:
        value = ref.validate(None)
    except ValidationError as error:
        assert error.field_name == "__root__"
        assert error.sub_errors[0].field_name == "null"
        assert error.sub_errors[0].text == "May not be null."



# Generated at 2022-06-22 06:10:23.547488
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Foo(Schema):
        bar = Field(description="I am a bar")

    obj = Foo(bar='I am a string')
    assert obj.__repr__() == "Foo(bar='I am a string')"

# Generated at 2022-06-22 06:10:29.863902
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    def test_method():
        from typesystem.schema import Schema
        from typesystem.fields import String
        class Person(Schema):
            name = String()
            age = String()
        person = Person(name='joe', age='46')
        assert len(person) == 2
        assert sorted(person) == ['age', 'name']
    test_method()


# Generated at 2022-06-22 06:10:36.240901
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    ClassDefinitions = SchemaDefinitions()
    class Customer(Schema, metaclass=SchemaMetaclass, definitions=ClassDefinitions):
        name = String()
        address = String()
        id = Integer()
    """
    Print the output if we want to check the fields of the class
    print(Customer.fields)
    print(Customer.fields["name"])
    print(Customer.fields["address"])
    """


# Generated at 2022-06-22 06:10:47.238710
# Unit test for constructor of class Schema
def test_Schema():
    from datetime import date

    from typesystem import types

    # A class with some properties.
    class Person(Schema):
        first_name = types.String(min_length=3)
        last_name = types.String(min_length=3)
        age = types.Integer()

    # Create an instance using *args.
    p = Person({"first_name": "John", "last_name": "Smith", "age": 42})
    assert p.first_name == "John"
    assert p.last_name == "Smith"
    assert p.age == 42
    assert p.is_sparse is False

    # Check __dict__.
    assert isinstance(p.__dict__, dict)

    # Create an instance using **kwargs.

# Generated at 2022-06-22 06:10:52.078214
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    m = SchemaDefinitions({"foo": "bar"})
    assert m["foo"] == "bar"




# Generated at 2022-06-22 06:11:00.164198
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String(max_length=256)
        age = Integer(minimum=0)

    class User(Schema):
        id = String(max_length=256)
        name = String(max_length=256)
        person = Reference(Person)

    dic = dict(id="user1", name="Hans", person=dict(name="Michael", age=20))
    result = User.validate(dic, strict=True)
    assert result.id == "user1"
    assert result.name == "Hans"
    assert result.person.name == "Michael"
    assert result.person.age == 20

# Test case for Property name: target_string

# Generated at 2022-06-22 06:11:02.142775
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    obj = Schema({})
    assert obj['name'] is not None

# Generated at 2022-06-22 06:11:05.704161
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert True

# Generated at 2022-06-22 06:11:10.751711
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import typesystem
    class Person(Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer()
    alice = Person(dict(name='alice', age=30))
    assert len(alice) == 1
    assert len(Person()) == 0


# Generated at 2022-06-22 06:11:20.027495
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # not implemented yet
    pass


# Generated at 2022-06-22 06:11:25.172598
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        field = Reference("Bar")

    class Bar(Schema):
        field = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["field"], definitions)
    set_definitions(Bar.fields["field"], definitions)

# Generated at 2022-06-22 06:11:28.881686
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference('to')
    assert r.to == 'to'
    assert r.definitions == None
    assert r.errors == {"null": "May not be null."}

# Generated at 2022-06-22 06:11:36.890940
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import pytest
    from typesystem import Integer

    class MySchema(Schema):
        integer = Integer()

    assert repr(MySchema(integer=12)) == "MySchema(integer=12)"
    assert repr(MySchema(integer=None)) == "MySchema(integer=None)"
    assert repr(MySchema()) == "MySchema() [sparse]"
    with pytest.raises(TypeError, match="is an invalid keyword argument for MySchema()."):
        assert repr(MySchema(bar=12))


# Generated at 2022-06-22 06:11:37.702441
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    """__iter__"""
    assert True


# Generated at 2022-06-22 06:11:40.859844
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    fields = {'key1':1, 'key2':2}
    s = SchemaDefinitions(fields)
    assert s['key2'] == 2


# Generated at 2022-06-22 06:11:49.477434
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Setup
    schema_definitions = SchemaDefinitions()
    schema_definitions.__setitem__('key1', 'value1')
    schema_definitions.__setitem__('key2', 'value2')
    schema_definitions.__setitem__('key3', 'value3')
    schema_definitions.__setitem__('key4', 'value4')
    schema_definitions.__setitem__('key5', 'value5')
    # Exercise
    actual = schema_definitions.__len__()
    # Verify
    assert isinstance(actual, int)
    assert 5 == actual


# Generated at 2022-06-22 06:11:58.301664
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test exception raises
    # KeyError
    schema = Schema({'key': 'value'})
    print(schema)
    try:
        schema.__getitem__('key2')
    except KeyError as err:
        print(err)
    try:
        schema.__getitem__(None)
    except KeyError as err:
        print(err)

    # Test return value
    schema = Schema({'key': 'value'})
    print(schema)
    print('{!r}'.format(schema.__getitem__('key')))
    print(schema)
    print(type(schema.__getitem__('key')))
    print(schema)
    print(schema.__getitem__('key') == 'value')
    # KeyError
    schema = Schema

# Generated at 2022-06-22 06:12:05.446784
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions[1] = 2
    assert 1 in definitions
    del definitions[1]
    assert 1 not in definitions


# Generated at 2022-06-22 06:12:07.978353
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class ProductSchema(Schema):
        id = Field(type="integer", minimum=1)

    schema = ProductSchema(id=1)

    assert schema['id'] == 1


# Generated at 2022-06-22 06:12:31.183877
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import Integer, String

    class PersonSchema(Schema):
        name = String()
        age = Integer()

    p = PersonSchema(name="Alice", age=20)
    assert p.name == "Alice"
    assert p.age == 20

    p2 = PersonSchema(dict(name="Alice", age=20))
    assert p == p2

    p3 = PersonSchema(p)
    assert p == p3

    p4 = PersonSchema(name="Alice")
    assert p4.name == "Alice"
    assert p4.age == None


# Generated at 2022-06-22 06:12:44.545449
# Unit test for method validate of class Reference
def test_Reference_validate():
    from dataclasses import dataclass
    from typesystem.fields import Boolean, Field

    @dataclass(frozen=True)
    class User:
        name: str
        active: bool
    @dataclass(frozen=True)
    class Foo:
        user: User = None
        active: bool = None
        name: str = None
    @dataclass(frozen=True)
    class Bar:
        user: User = None
        active: bool = None
        name: str = None
    @dataclass(frozen=True)
    class Baz:
        user: User = None
        active: bool = None
        name: str = None
    @dataclass(frozen=True)
    class Qux:
        user: User = None
        active: bool = None

# Generated at 2022-06-22 06:12:50.456826
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Create a new instance of SchemaDefinitions
    obj = SchemaDefinitions()
    # Set a value to obj
    obj['a'] = 'a'
    # Delete a key in obj
    del obj['a']
    pass_ = False
    try:
        # Get the key is deleted above
        obj['a']
    except KeyError:
        # Check the key is deleted
        pass_ = True
    assert pass_



# Generated at 2022-06-22 06:12:56.547079
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference("", allow_null=True)
    assert isinstance(r, Reference)
    assert isinstance(r, Field)
    assert r.to == ""
    assert r.definitions is None
    assert r.allow_null == True



# Generated at 2022-06-22 06:13:00.882457
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Product(Schema):
        id = Field(type="string", description="Product ID")
        name = Field(type="string", description="Name of the product")
    print(Product.fields)


# Generated at 2022-06-22 06:13:11.788723
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # pylint: disable=C0110
    class SubSchema(Schema):
        pass

    assert SubSchema.fields == {}

    class MySchema(Schema):
        pass

    assert MySchema.fields == {}

    class MySchema(Schema):
        prop = Field()

    assert MySchema.fields == {"prop": MySchema.prop}

    class MySchema(Schema):
        prop = Field()

    assert MySchema.fields == {"prop": MySchema.prop}

    class MySchema(Schema):
        prop = Field()
        prop = Field()

    assert MySchema.fields == {"prop": MySchema.prop}

    class MySchema(Schema):
        prop = Field()
        prop = Field()


# Generated at 2022-06-22 06:13:19.394983
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    import json
    import pytest
    from typesystem.types import String

    fields = {"name": String()}
    class Person(Schema):
        fields = fields

    ref_fields = {"person": Reference(to="Person", definitions={ "Person": Person })}
    class PersonRef(Schema):
        fields = ref_fields

    person1 = Person(name="John Doe")

    person_ref1 = PersonRef(person=person1)
    assert json.dumps(person_ref1, ensure_ascii=False) == '{"person": {"name": "John Doe"}}'

    # Error with person = None
    with pytest.raises(TypeError):
        person_ref2 = PersonRef(person=None)

    # Error with person = {}
    with pytest.raises(TypeError):
        person_

# Generated at 2022-06-22 06:13:22.473457
# Unit test for method validate of class Reference
def test_Reference_validate():
    assert Reference(str).validate('123', strict=True) == '123'

# Generated at 2022-06-22 06:13:34.104104
# Unit test for constructor of class Schema
def test_Schema():
    obj = object()
    # It should accept an arbitrary object and return an object that
    # has an attribute for every field. It should not accept a
    # non-mapping object.
    class A(Schema):
        b = Field()
        c = Field()

    A(obj)
    A(dict())
    try:
        A(42)
    except TypeError:
        pass
    else:
        assert False
    # It should accept an object with corresponding attributes.
    obj.b = 42
    obj.c = 1337
    a = A(obj)
    assert a.b == 42
    assert a.c == 1337
    # It should accept a mapping.
    a = A({"b": 42, "c": 1337})
    assert a.b == 42
    assert a.c == 1337
   

# Generated at 2022-06-22 06:13:37.183037
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # Initialize the class
    obj = SchemaDefinitions()
    assert isinstance(obj._definitions, dict)

# Generated at 2022-06-22 06:14:12.407747
# Unit test for method validate of class Reference
def test_Reference_validate():
    class A(Schema):
        name = Field(type="string")
        def __repr__(self):
            return f"A({self.name!r})"
    class B(Schema):
        a = Reference(to=A)
    a = A("AAA")
    b = B(a)
    assert b.a == a
    b.a = None
    assert b.a is None
    # b.a = "hogehoge"
    # assert b.a == "hogehoge"

test_Reference_validate()

# Generated at 2022-06-22 06:14:21.140117
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    class TestSchema(Schema):
        age = Integer()
        name = String()

    class TestSchema2(Schema):
        age = Integer()
        name = String()
    schema = TestSchema(age=3, name="name")
    def_dict = {'TestSchema2': TestSchema2}
    def_dict[schema.__class__.__name__] = schema
    assert def_dict == {'TestSchema2': TestSchema2, 'TestSchema': TestSchema(age=3, name='name')}



# Generated at 2022-06-22 06:14:25.675291
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Item(Schema):
        name = String()
        price = Integer()
    item = Item(name="Apple", price=3)
    assert type(item) == Item
    assert isinstance(item, Schema)
    assert item.fields == Item.fields

# Generated at 2022-06-22 06:14:32.317245
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():

    # Ellipsis (...) and NotImplemented (...) are valid args.
    sd = SchemaDefinitions("Fruit", "Vegetable")
    # Test: Type of len(sd) is <class 'int'>
    assert type(len(sd)) is int, "Type of len(sd) is <class 'int'>"
    # Test: result of len(sd) equals 2
    assert len(sd) == 2, "result of len(sd) equals 2"


# Generated at 2022-06-22 06:14:36.818680
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String(title='Name')
        age = Integer(title='Age')
    p = Person(name='Max', age=30)
    assert len(p) == 2
    assert list(iter(p)) == ['name', 'age']

# Generated at 2022-06-22 06:14:42.982970
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    _args = ()
    _kwargs = {}
    # Make an instance which *MUST* be valid
    valid_instance = SchemaDefinitions(*_args, **_kwargs)
    # Construct a second instance for testing with invalid values
    test_instance = SchemaDefinitions(*_args, **_kwargs)
    assert valid_instance.__getitem__('') is None



# Generated at 2022-06-22 06:14:54.849206
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Integer, String
    class Test1(Schema):
        "Test 1"
        name = String(max_length=10)
        age = Integer(minimum=13)
    class Test2(Test1):
        "Test 2"
    class Test3(Test2):
        "Test 3"
        weight = Integer(minimum=0)
    class Test4(Schema):
        "Test 4"
        name = Integer(title='Name')
    class Test5(Test4):
        "Test 5"
        title = String(max_length=20)

    assert Test1.fields['name'] == String(max_length=10)
    assert Test2.fields['name'] == String(max_length=10)
    assert Test1.fields['age'] == Integer(minimum=13)
    assert Test2.fields

# Generated at 2022-06-22 06:15:04.554140
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        a = Reference('A')
        b = Array(Reference('B', allow_null=True))

    class A(Schema):
        pass

    class B(Schema):
        pass

    definitions = SchemaDefinitions({
        'A': A,
        'B': B,
    })

    assert Foo.a.definitions is None
    set_definitions(Foo.a, definitions)
    assert Foo.a.definitions is definitions
    assert Foo.a.target is A

    assert Foo.b.definitions is None
    set_definitions(Foo.b, definitions)
    assert Foo.b.definitions is definitions
    assert Foo.b.items.definitions is definitions
    assert Foo.b.items.target is B

# Generated at 2022-06-22 06:15:09.236618
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = 1
        b = 2
        c = 3

    assert TestSchema(a=1, b=2, c=3).__iter__() == TestSchema(c=3, b=2, a=1).__iter__()


# Generated at 2022-06-22 06:15:13.569425
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        published_at = DateTime(format="iso")

    schema = TestSchema(published_at=1549915754)
    assert schema["published_at"] == "2019-02-12T23:39:14.000000Z"


# Generated at 2022-06-22 06:16:21.995131
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
  s = SchemaDefinitions({"p1":4})
  # Test __getitem__
  assert s["p1"] == 4
  # Test __iter__
  for i in s:
    assert i == "p1"
  # Test __len__
  assert len(s) == 1
  # Test __setitem__
  s["p2"] = 5
  assert s["p2"] == 5
  # Test __delitem__
  del s["p1"]
  assert len(s) == 1
  del s["p2"]
  assert len(s) == 0


# Generated at 2022-06-22 06:16:24.924205
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert list(SchemaDefinitions().__iter__()) == []
    assert list(SchemaDefinitions({"a": 1, "b": 2}).__iter__()) == ["a", "b"]


# Generated at 2022-06-22 06:16:28.934031
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["a"] = 1
    try:
        definitions["a"] = 2
        assert False
    except AssertionError:
        assert True
    else:
        assert False



# Generated at 2022-06-22 06:16:35.780957
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    d = SchemaDefinitions()
    d["a"] = 1
    d["b"] = 2
    d["a"] = 3
    assert d["a"] == 3
    assert d["b"] == 2
    try:
        d["a"] = 4
    except Exception as e:
        assert e.args[0] == "Definition for 'a' has already been set."
        # assertion is True
    else:
        assert False


# Generated at 2022-06-22 06:16:44.818306
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    my_def = SchemaDefinitions({"test_key":"test_value"})
    assert my_def._definitions == {"test_key":"test_value"}
    my_def.__setitem__("test_key_2","test_value_2")
    assert my_def._definitions == {"test_key":"test_value","test_key_2":"test_value_2"}

    try:
        my_def.__setitem__("test_key","test_value")
        raise AssertionError()
    except AssertionError as ae:
        pass
    except:
        raise AssertionError()


# Generated at 2022-06-22 06:16:55.957960
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test_SchemaDefinitions = SchemaDefinitions()
    assert list(test_SchemaDefinitions.keys()) == []
    assert len(test_SchemaDefinitions) == 0
    assert list(test_SchemaDefinitions.items()) == []
    assert test_SchemaDefinitions.get("key", "value") == "value"
    assert test_SchemaDefinitions.get("key") == None
    assert list(test_SchemaDefinitions.values()) == []
    assert list(test_SchemaDefinitions.keys()) == []
    test_SchemaDefinitions["key"] = "value"
    assert len(test_SchemaDefinitions) == 1
    assert test_SchemaDefinitions.pop("key", None) == "value"
    assert test_SchemaDefinitions.pop("key", None) == None

# Unit

# Generated at 2022-06-22 06:16:57.724040
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()

    definitions.__delitem__("key1")


# Generated at 2022-06-22 06:17:01.575581
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(to="dict").serialize({"a": 1}) == {"a": 1}
    assert Reference(to="dict").serialize(None) == None

# Generated at 2022-06-22 06:17:07.279353
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sd = SchemaDefinitions()
    sd.__setitem__('foo', 'bar')
    assert sd['foo'] == 'bar'
    assert sd.__len__() == 1
    assert sd.__contains__('foo') == True
    assert sd.__contains__('foobar') == False
    sd.__delitem__('foo')
    assert sd.__contains__('foo') == False

# Generated at 2022-06-22 06:17:11.162865
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions({"abc": "abc"})
    assert definitions['abc'] == 'abc'
    try:
        definitions['xyz']
        assert False
    except KeyError:
        pass
