

# Generated at 2022-06-22 06:08:45.172456
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Base(Schema):
        foo = "foo"
    
    class _Schema(Schema):
        bar = "bar"
        baz = "baz"
    
    def setUp(self):
        self.s = _Schema(bar=1, baz=2)
    
    def test_should_return_an_iterator(self):
        """
        >> > s = Schema(bar=1, baz=2)
        >> > s.__iter__()
        < listiterator object at 0x7fae5f8ddba8 >
        """
        self.assertIsInstance(self.s.__iter__(), listiterator)


# Generated at 2022-06-22 06:08:48.955698
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        name = String()
        location = String()

    schema = TestSchema(name="name", location="location")
    assert list(schema) == ["name", "location"]

# Generated at 2022-06-22 06:08:59.932965
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class A(Schema):
        a = Reference(int, allow_null=False, description=0)
        b = Reference(dict, allow_null=False, description=1)

    class B(Schema):
        c = Reference(list, allow_null=False, description=2)
        d = Reference(float, allow_null=False, description=3)
    
    val1 = A({"a": 1, "b": {"w":"x"}})
    val2 = B({"c": [1,2,3], "d": 4.5})

    def check(obj, serialized):
        assert obj.serialize() == serialized

    check(val1, {"a": 1, "b": {"w":"x"}})

# Generated at 2022-06-22 06:09:05.185064
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class _MockSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
        d = Field()

    schema = _MockSchema({'a': 1,'c': 3})
    assert list(schema.__iter__()) == [ 'a', 'c' ]



# Generated at 2022-06-22 06:09:13.276786
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Setup
    class Test(Schema):
        a = Field()
        b = Field()
    obj = Test(a=1, b=2)
    classes = [
        Field,
        MutableMapping,
        typing.Iterator[str],
        Schema,
        object,
    ]
    # Exercise
    class_name = type(obj).__name__
    attribute_names = ", ".join(f"'{attribute}'" for attribute in sorted(obj))
    context = f"when called on '{class_name}' object with attributes {attribute_names}"
    iterator = obj.__iter__()
    class_name = type(iterator).__name__
    # Verify
    assert type(iterator) in classes
    attribute_names = ", ".join(f"'{attribute}'" for attribute in sorted(iterator))

# Generated at 2022-06-22 06:09:18.925074
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from .fields import String
    import sys

    class NoteSchema(Schema, metaclass=SchemaMetaclass):
        id = String()
        text = String()

    assert NoteSchema.fields["id"].__class__.__name__ == "String"
    assert NoteSchema.fields["text"].__class__.__name__ == "String"



# Generated at 2022-06-22 06:09:27.791925
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typing import Optional


    class MySchema(Schema):
        foo = Field(String(), default="bar")
        bar = Field(String(), required=True)
        baz = Field(Array(String()))


    myschema = MySchema(bar="baz", baz=["foo", "bar"])
    assert repr(myschema) == "MySchema(bar='baz', baz=['foo', 'bar'])"

    myschema = MySchema(baz=["foo", "bar"])
    assert repr(myschema) == "MySchema(bar='bar', baz=['foo', 'bar']) [sparse]"

# Generated at 2022-06-22 06:09:30.080677
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions({"x": "y"})
    assert len(definitions) == 1


# Generated at 2022-06-22 06:09:39.892397
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=100)
    class Address(Schema):
        street = String(max_length=100)
        city = String(max_length=100)
    class Customer(Schema):
        name = String(max_length=100)
        address = Reference(Address)
        friends = Array(Reference(Person))
    aj = Customer(name="AJ", address=Address(street="1 Main St", city="San Francisco"), friends=[Person(name="Foo", age=42), Person(name="Bar", age=43)])
    serialized_aj = Reference.serialize(aj)
    assert serialized_aj['name'] == "AJ"

# Generated at 2022-06-22 06:09:49.665343
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        pass
    
    try:
        a = Foo()
    except TypeError as e:
        assert True
    else:
        assert False, "Unexpected behavior"

    class Foo(Schema):
        a = Field(str)
        b = Field(str, required=False)
    
    a = Foo(a='a')
    assert a.a == 'a'

    class Foo(Schema):
        a = Field(str, required=False)
        b = Field(str, required=False)
    
    a = Foo()
    assert a.a == None
    assert a.b == None

    class Foo(Schema):
        a = Field(str, required=False)
        b = Field(int, required=False)
    
    b = Foo(b='b')


# Generated at 2022-06-22 06:10:10.715899
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__(): # change to better name
    from typesystem import Integer, Schema
    from typesystem.fields import Boolean, String
    from typesystem.exceptions import ValidationError
    from typesystem.schema import SchemaMetaclass, SchemaDefinitions
    import numbers
    import pytest
    class Addresses(metaclass=SchemaMetaclass):
        fields = {
            "address": String(required=True),
            "city": String(required=True),
            "zip": String(required=True),
        }

    
    # test is get from input with key exist in defitions
    def test_schemaDefinitions_getitem_exist_in_definitions_return_class():
        schema_definitions = SchemaDefinitions()
        schema_definitions['Addresses'] = Addresses

# Generated at 2022-06-22 06:10:21.977677
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Author(Schema):
        name = String
        email = String
        reference = Reference(to="Author", title="Author reference")

    schema = Author(
        name="Dan Gittik",
        reference=Author(name="Shaked", email="shaked@couri.es")
    )
    _reference = schema.reference.serialize(schema.reference)
    _schema = schema.serialize()
    assert _reference == {'email': 'shaked@couri.es', 'name': 'Shaked'}
    assert _schema == {'email': '', 'name': 'Dan Gittik', 'reference': {'email': 'shaked@couri.es', 'name': 'Shaked'}}

# Generated at 2022-06-22 06:10:23.789999
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    schema_definitions = SchemaDefinitions()
    assert schema_definitions._definitions == {}


# Generated at 2022-06-22 06:10:26.710273
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    obj = SchemaDefinitions()
    obj['a'] = 'TypeError'
    del obj['a']
    assert len(obj) == 0
    assert obj['a'] == 'TypeError'


# Generated at 2022-06-22 06:10:28.684282
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    args = []
    kwargs = {}
    assert isinstance(SchemaDefinitions(*args, **kwargs), SchemaDefinitions)


# Generated at 2022-06-22 06:10:29.620518
# Unit test for method validate of class Reference
def test_Reference_validate():
    pass






# Generated at 2022-06-22 06:10:32.410164
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    x = SchemaDefinitions()
    x["key"] = "value"
    x.__getitem__("key") == "value"


# Generated at 2022-06-22 06:10:37.147689
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    from typesystem import Integer, String, Schema
    from ast import literal_eval
    
    class PersonSchema(Schema):
        name = String(max_length=30)
        age = Integer(minimum=0)
        
    definitions = literal_eval("{'PersonSchema': PersonSchema}")
    assert definitions == {'PersonSchema': PersonSchema}


# Generated at 2022-06-22 06:10:41.665468
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    sd = SchemaDefinitions()
    sd["foo"] = "123"
    del sd["foo"]
    #assert len(sd) == 0
    #print(sd)
    #assert "foo" not in sd
test_SchemaDefinitions___delitem__()


# Generated at 2022-06-22 06:10:52.399109
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem
    import datetime

    class Address(Schema):
        street = typesystem.String()
        city = typesystem.String()
        state = typesystem.String()
        zip_code = typesystem.String()

        def __eq__(self, other):
            # Equal if street, city and state are the same.
            return (
                self.street == other.street
                and self.city == other.city
                and self.state == other.state
            )

    class User(Schema):
        id = typesystem.Integer()
        username = typesystem.String()
        address = Reference(Address)
        created_at = typesystem.DateTime()
        details = typesystem.String(required=False)


# Generated at 2022-06-22 06:11:06.725898
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    assert len(obj) == 0
    obj['a'] = 'a'
    obj['b'] = 'b'
    obj['c'] = 'c'
    assert len(obj) == 3


# Generated at 2022-06-22 06:11:08.195030
# Unit test for constructor of class Schema
def test_Schema():
    class MySchema(Schema):
        pass


# Generated at 2022-06-22 06:11:10.960949
# Unit test for constructor of class Reference
def test_Reference():
    R = Reference
    assert R(to=str).to == str
    assert R(to="str").to == "str"
    assert R(to="str").target == str
    assert R(to=str, definitions={"str": str}).to == str


# Generated at 2022-06-22 06:11:22.757326
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    import copy
    import types
    from typesystem.definitions import Schema

    class Product(Schema):
        foo = Field()

    class Order(Schema):
        product = Reference(to="Product")

    def test(product: types.ModuleType.__dict__['Product'],
             definitions: types.ModuleType.__dict__['SchemaDefinitions'],
             order: types.ModuleType.__dict__['Order'],
             ) -> None:
        definitions["Product"] = copy.deepcopy(Product)
        definitions["Order"] = copy.deepcopy(Order)
        assert "Product" in definitions
        assert "Order" in definitions
        assert Order.fields["product"].target is Product
        assert definitions["Order"] is Order
        assert definitions["Product"] is Product



# Generated at 2022-06-22 06:11:26.902713
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Test(Schema):
        a = Field()
        b = Field()
        c = Field()

    test = Test(a=1, c=3)

    assert repr(test) == "Test(a=1, c=3) [sparse]"

# Generated at 2022-06-22 06:11:28.965168
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    a_schema = Schema(a='a')
    assert [(x) for x in a_schema.__iter__()] == ['a']


# Generated at 2022-06-22 06:11:39.547704
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem
    import typesystem.fields as fields
    import pickle
    import typesystem.types.dict as dict_
    import typesystem.types.text as text
    class Person(Schema):
        name = fields.String()
        age = fields.Number()
        __module__ = typesystem.__name__
        __qualname__ = "Person"
    assert isinstance(Person.fields, dict)
    assert len(Person.fields) == 2
    assert isinstance(Person.fields["name"], fields.String)
    assert isinstance(Person.fields["age"], fields.Number)
    validator = Person.make_validator()
    assert isinstance(validator, fields.Object)
    assert validator.properties == Person.fields
    assert validator.required == ["name", "age"]

# Generated at 2022-06-22 06:11:40.151326
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass

# Generated at 2022-06-22 06:11:46.140994
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert Schema.__len__.__annotations__ == {'self': typing.Solution}
    assert Schema(a=1).__len__() == 1
    assert Schema(b=2, c=3).__len__() == 2
    assert Schema().__len__() == 0
    assert Schema(b = 2, c = 3).__len__() == 2


# Generated at 2022-06-22 06:11:50.182692
# Unit test for method validate of class Reference
def test_Reference_validate():
    # sample value
    dict_test = {"name": "test", "age": 22}
    # create a object of class Reference
    ref = Reference("test")
    ret = ref.validate(dict_test)
    # expected output or result
    expected = dict_test
    # check if function return the expected result
    assert ret == expected


# Generated at 2022-06-22 06:12:11.029377
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Nested(Schema):
        name = 'name'
        type = int
        definitions = None

    class MySchema(Schema):
        nested = Reference(Nested)
        definitions = None

    n = Nested('boom') # MySchema(nested='boom')
    res = MySchema.validate(n)
    assert isinstance(res, MySchema)
    assert res.nested.name == 'boom'
    m = MySchema.validate({'nested': {'name': 'boom', 'type': int}})
    assert isinstance(m, MySchema)
    assert m.nested.name == 'boom'
    assert m.nested.type == int

# Generated at 2022-06-22 06:12:19.417209
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.primitives import String

    class TheSchema(Schema):
        name = String(required=True)
        category = String()

    assert set(TheSchema.fields.keys()) == {'name', 'category'}
    assert list(TheSchema.fields.values()) == [
        String(required=True), String()
    ]



# Generated at 2022-06-22 06:12:21.578080
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class TestSchema(Schema):
        pass
    ref = Reference('TestSchema')
    val = TestSchema({})
    assert ref.serialize(val) == {}

# Generated at 2022-06-22 06:12:27.607563
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import String, Integer
    from typesystem.fields import Field

    class AuthorSchema(Schema):
        id = Integer()
        name = String(min_length=4, max_length=50)

    class BookSchema(Schema):
        id = Integer()
        title = String(min_length=1, max_length=100)
        author = Reference(AuthorSchema)

    author = AuthorSchema(id=1, name='user1')
    book1 = BookSchema(id=2, title='book1', author=author)
    book2 = BookSchema(id=2, title='book1', author=author)
    book3 = BookSchema(id=3, title='book1', author=author)

    assert book1 == book2
    assert book1 != book3


# Unit test

# Generated at 2022-06-22 06:12:32.906788
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    data = {
        "a": 1,
        "b": 2,
        "c": 3,
    }

    schema = Schema(data)

    assert data["a"] == schema["a"]
    assert data["b"] == schema["b"]
    assert data["c"] == schema["c"]


# Generated at 2022-06-22 06:12:41.343799
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from .test_base import Person, Address

    person = Person(
        name="John Smith",
        age=42,
        address=Address(
            street="123 E 6th St",
            city="Austin",
            state="TX",
            zipcode="78660"
        )
    )

    actual = person['name']
    assert actual == 'John Smith'

    actual = person['address']
    assert actual == {'street': '123 E 6th St', 'city': 'Austin', 'state': 'TX', 'zipcode': '78660'}


# Generated at 2022-06-22 06:12:46.964095
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    attrs = {}
    attrs['fields'] = {}
    base = {}
    s = SchemaMetaclass.__new__(SchemaMetaclass, 'any', base, attrs)
    print('#' * 52 + '  Constructor of class SchemaMetaclass')
    print(s.fields)
    print(s)
    print(s.__class__)
    print(s.__doc__)

# Constructor of class Schema

# Generated at 2022-06-22 06:12:49.739013
# Unit test for method validate of class Reference
def test_Reference_validate():
    r_Field = Reference('Field')
    r_Field.definitions = {'Field': Field}
    assert r_Field.validate('name', strict=False) == 'name'


# Generated at 2022-06-22 06:12:54.651543
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    s = SchemaDefinitions({"a":1})
    assert s["a"]==1


# Generated at 2022-06-22 06:12:57.546519
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    actual = "Actually, this code should be implemented in method __iter__" \
        + " of class SchemaDefinitions."


# Generated at 2022-06-22 06:13:23.717398
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class ISchema(Schema):
        foo = Array(String())

    obj = ISchema(foo=["bar", "baz"])
    assert obj.__len__() == 1
    

# Generated at 2022-06-22 06:13:26.194016
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class S(Schema):
        a = Field(String)
    assert S.fields['a'] is not None
    assert S.__name__ == 'S'


# Generated at 2022-06-22 06:13:29.528167
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class SimpleSchema(Schema):
        a = Field()
    simple_schema = SimpleSchema(a=1)
    a = simple_schema['a']
    assert a == 1



# Generated at 2022-06-22 06:13:35.688451
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    import os
    import typesystem
    schema = typesystem.Schema(
        {"first_name": typesystem.String, "last_name": typesystem.String},
    )
    os = Reference(schema)
    data = os.serialize(Reference(schema))
    assert data == {"first_name": None, "last_name": None}


# Generated at 2022-06-22 06:13:41.584998
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    assert len(schema_definitions) == 0
    schema_definitions["a"] = 0
    assert len(schema_definitions) == 1


# Generated at 2022-06-22 06:13:53.591058
# Unit test for method validate of class Reference
def test_Reference_validate():
    import unittest
    import typesystem
    from unittest.mock import patch

    class User(typesystem.Schema):
        name = typesystem.String(min_length=2, max_length=10)
        email = typesystem.String(format="email")

    user = User({"name": "John Doe", "email": "john@example.com"})
    user_list = [
        {"name": "John Doe", "email": "john@example.com"},
        {"name": "Foo Bar", "email": "foo@example.com"},
    ]

    class Person(typesystem.Schema):
        user = Reference("User")

    class UserArray(typesystem.Schema):
        users = typesystem.Array(Reference("User"))

    class UserDict(typesystem.Schema):
        users

# Generated at 2022-06-22 06:13:57.334933
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem.fields import String

    class User(Schema):
        name = String()

    assert User.fields["name"] is not None and User.fields["name"].__class__.__name__ == "String"



# Generated at 2022-06-22 06:14:09.041763
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    d = SchemaDefinitions()
    d['item1'] = "value1"
    d['item2'] = "value2"
    d['item3'] = "value3"
    assert(len(d) == 3)
    assert(d['item1'] == "value1")
    assert(d['item2'] == "value2")
    assert(d['item3'] == "value3")
    del d['item2']
    assert(len(d) == 2)
    assert(d['item1'] == "value1")
    assert(d['item3'] == "value3")
    with pytest.raises(KeyError) as excinfo:
        _ = d['item2']
    assert('item2' in str(excinfo.value))


# Generated at 2022-06-22 06:14:14.199247
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():

    foo_schema = Schema({"foo": 2})
    bar_schema = Schema({"bar": 3})

    # Case 1: equal
    assert foo_schema == foo_schema

    # Case 2: not equal
    assert foo_schema != bar_schema


# Generated at 2022-06-22 06:14:25.676283
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem.base import String
    class FooSchema(Schema, metaclass=SchemaMetaclass):
            foo = String()
    def test_fields():
        assert FooSchema.fields == {'foo': String()}
    def test_validate():
        foo = FooSchema.validate({'foo':'Hello'})
        assert foo.foo == 'Hello'
    def test_repr():
        foo = FooSchema({'foo':'Hello'})
        assert repr(foo) == "FooSchema(foo='Hello')"
    def test_eq():
        foo1 = FooSchema({'foo':'Hello'})
        foo2 = FooSchema({'foo':'Hello'})
        assert foo1 == foo2
        assert not foo1 == 1
        assert not foo1 == FooSche

# Generated at 2022-06-22 06:14:53.800803
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    SD = SchemaDefinitions()
    SD.__setitem__(1,2)
    SD.__setitem__(2,4)
    SD.__setitem__(3,6)
    assert ([key for key in SD.__iter__()] == [3,2,1]), 'Unexpected behavior of __iter__ in SchemaDefinitions.'


# Generated at 2022-06-22 06:14:59.370087
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String

    class DefinitionBase(metaclass=SchemaMetaclass):
        class Meta:
            definitions = SchemaDefinitions()

    class Definition(DefinitionBase):
        name = String()


# Generated at 2022-06-22 06:15:02.728443
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        pass

    obj = MySchema()
    ret = repr(obj)
    assert repr(obj) != ""
    assert repr(obj) == "MySchema()"
    return


# Generated at 2022-06-22 06:15:04.980777
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    pass



# Generated at 2022-06-22 06:15:16.149060
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import pytest
    from schemata.base import Schema
    class MySchema(Schema):
        name = str
    assert MySchema.__repr__() == 'MySchema(name=None)'
    my_schema = MySchema(name='test name')
    assert my_schema.__repr__() == "MySchema(name='test name')"
    class MySchemaWithMoreProperties(MySchema):
        name = str
        age = int
        height = float
    assert MySchemaWithMoreProperties.__repr__() == 'MySchemaWithMoreProperties(name=None, age=None, height=None)'
    my_schema_with_more_properties = MySchemaWithMoreProperties(name='test name', age=33, height=175.5)
   

# Generated at 2022-06-22 06:15:20.824275
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class ExampleSchema(Schema):
        field_one = Field()
        field_two = Field()
    expected = {'field_one': Field(), 'field_two': Field()}
    print(ExampleSchema.fields)
    assert ExampleSchema.fields == expected

# Generated at 2022-06-22 06:15:23.969340
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    test_SchemaDefinitions = SchemaDefinitions()

    class Person(Schema):
        name = StringField()

    Person(name="Mark")

    assert Person.fields["name"] == StringField()



# Generated at 2022-06-22 06:15:30.717375
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    method = SchemaDefinitions.__delitem__
    definitions = SchemaDefinitions()
    name = "Referenced"
    cls = type(name, (Schema,), {})
    definitions[name] = cls
    method(definitions, name)
    assert name not in definitions


# Generated at 2022-06-22 06:15:33.821694
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    schema = object()
    definitions['test'] = schema
    assert definitions._definitions['test'] == schema
    del definitions['test']
    assert definitions._definitions == {}


# Generated at 2022-06-22 06:15:38.007826
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String(required=True)
        email = String(required=True)
        age = Integer()

    data = {'name': 'Tim', 'email': 'tim@example.com'}
    person = Person.validate(data)
    assert len(person) == 2

# Generated at 2022-06-22 06:16:25.951887
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Point(Schema):
        x = Number()
        y = Number()
        z = Number()

    a = Point(x=1, y=2)
    b = Point(x=1, y=2)
    assert a == b


# Generated at 2022-06-22 06:16:29.476837
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert (SchemaDefinitions()._definitions == {})
    assert (SchemaDefinitions([('a','b')])._definitions == {'a': 'b'})
    assert (SchemaDefinitions(a = 'b')._definitions == {'a': 'b'})


# Generated at 2022-06-22 06:16:32.149449
# Unit test for constructor of class Schema
def test_Schema():
    u = Schema()

    assert isinstance(u, Schema)

    assert u.__repr__() == 'Schema() [sparse]'


# Generated at 2022-06-22 06:16:37.690153
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Create a schema definitions object and populate it with items
    actual = SchemaDefinitions()
    actual["Key1"] = 1
    actual["Key2"] = 2
    actual["Key3"] = 3
    # The expected value of the lenght of the object
    expected = 3
    # Evaluate
    assert len(actual) == expected


# Generated at 2022-06-22 06:16:50.519568
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field()
        age = Field()

    p = Person(name="foo", age=23)
    assert p.name == "foo"
    assert p.age == 23
    assert p == Person(name="foo", age=23)
    assert p != Person(name="foo", age=22)
    assert p != Person(name="foo", age=23, baz="bar")
    assert p == Person(Person(name="foo", age=23))
    assert p == Person({"name": "foo", "age": 23})
    assert p != Person({"name": "foo", "age": 22})
    assert p != Person({"name": "foo", "age": 23, "baz": "bar"})


# Generated at 2022-06-22 06:16:56.599296
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # Pass
    # Call function
    definitions = SchemaDefinitions({"a": 1})
    result = definitions.__getitem__("a")
    assert result == 1

    # Fail
    # Call function
    try:
        result = definitions.__getitem__("b")
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-22 06:16:58.076261
# Unit test for method validate of class Reference
def test_Reference_validate():
    s=Reference("hello")
    s.validate("hello")


# Generated at 2022-06-22 06:17:04.894674
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    assert definitions['key'] == definitions._definitions['key']
    assert definitions.pop('key') == definitions._definitions.pop('key')
    assert definitions.popitem('key') == definitions._definitions.popitem('key')
    assert definitions.clear() == definitions._definitions.clear()
    assert definitions.get('key') == definitions._definitions.get('key')


# Generated at 2022-06-22 06:17:16.609998
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem

    class BaseSchema(typesystem.Schema):
        field_1 = typesystem.String()

    class SubSchema(BaseSchema):
        field_2 = typesystem.Integer()

    required_fields = ['field_1', 'field_2']
    fields = ['field_1', 'field_2']
    assert SubSchema.required_fields == required_fields
    assert SubSchema.fields == fields
    assert SubSchema().field_1 is None
    assert SubSchema().field_2 is None
    assert not BaseSchema().is_sparse
    assert not SubSchema().is_sparse
    assert BaseSchema(field_1='abc').field_1 == 'abc'
    assert BaseSchema(field_1='abc').field_2 is None

# Generated at 2022-06-22 06:17:26.103084
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema = SchemaDefinitions()

    class ReferenceTest(Schema):
        foo = Reference("Foreign", definitions = schema)
        bar = Reference("Foreign", definitions = schema)

    class Foreign(Schema):
        a = Field(type = int)
        b = Field(type = str)

    schema["Foreign"] = Foreign

    schema["ReferenceTest"] = ReferenceTest

    good_target = {'a' : 1, 'b' : 'hello'}

    bad_target = {'a' : 1, 'b' : 2}

    test1 = ReferenceTest(foo = good_target, bar = bad_target)

    error = test1.validate_or_error(test1)

    error_msg = ' '.join([message.text for message in error.messages()])
