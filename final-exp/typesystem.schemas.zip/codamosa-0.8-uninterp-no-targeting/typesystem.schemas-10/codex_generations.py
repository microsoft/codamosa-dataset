

# Generated at 2022-06-22 06:08:03.671778
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    obj = SchemaDefinitions()
    with pytest.raises(NotImplementedError):
        obj.__iter__()


# Generated at 2022-06-22 06:08:11.028739
# Unit test for function set_definitions
def test_set_definitions():
    class Schema1(Schema):
        field1 = String()

    class Schema2(Schema):
        field1 = Reference(Schema1)

    definitions = SchemaDefinitions()
    Schema2(field1=Schema1(field1="bar"))
    assert Schema2.fields["field1"].definitions is None
    set_definitions(Schema2.fields["field1"], definitions)
    assert Schema2.fields["field1"].definitions == definitions

# Generated at 2022-06-22 06:08:18.154007
# Unit test for constructor of class Schema

# Generated at 2022-06-22 06:08:21.901214
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class SubSchema(Schema):
        test = Field()

    schema = SubSchema()
    schema2 = SubSchema()
    assert schema == schema2


# Generated at 2022-06-22 06:08:22.966351
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema()) == 0


# Generated at 2022-06-22 06:08:33.399147
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # method test_instance_method_1
    definition_1 = SchemaDefinitions()
    definition_1["A"] = "Adam"
    for key in definition_1:
        assert key == "A"
    assert len(definition_1) == 1

    # method test_instance_method_2
    definition_2 = SchemaDefinitions()
    definition_2["B"] = "Ben"
    for key in definition_2:
        assert key == "B"
    assert len(definition_2) == 1

    # method test_instance_method_3
    definition_3 = SchemaDefinitions()
    definition_3["C"] = "Charles"
    for key in definition_3:
        assert key == "C"
    assert len(definition_3) == 1

    # method test_instance_method_4
    definition

# Generated at 2022-06-22 06:08:40.174408
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import fields

    class Person(Schema):
        name = fields.String(max_length=100)
        age = fields.Integer(minimum=18)
        occupation = fields.String()

    person = Person({"name": "Alice", "age": 21, "occupation": "Tester"})
    assert person.name == "Alice"
    assert person.age == 21
    assert person.occupation == "Tester"


# Generated at 2022-06-22 06:08:43.129275
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    try:
        import pytest

        with pytest.raises(KeyError):
            SchemaDefinitions().__getitem__('')
    except ImportError:
        pass


# Generated at 2022-06-22 06:08:48.776228
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class TestSchema(Schema):
        fields = {
            "name": "name",
            "id": 123,
            "age": 45,
            "male": True,
            "address": "Whitley",
        }

    assert TestSchema.__repr__ == '<function Schema.__repr__ at 0x7feae388f510>'
    assert TestSchema().__repr__ == "TestSchema(name='name', id=123, age=45, male=True, address='Whitley')"


# Generated at 2022-06-22 06:08:53.555292
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Schema's __getitem__ should return a serialized version of the field value
    from typesystem.fields import String
    from typesystem import Schema

    class MySchema(Schema):
        foo = String()

    schema = MySchema(foo='bar')

    assert schema['foo'] == 'bar'


# Generated at 2022-06-22 06:09:02.744833
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    _obj = SchemaDefinitions()
    _ret = len(_obj)



# Generated at 2022-06-22 06:09:09.328040
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions()
    definitions.__getitem__(key='key')
    assert hasattr(definitions, '__getitem__') == True


# Generated at 2022-06-22 06:09:16.411964
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    import typesystem
    import typesystem.fields
    class TestDefinitionOne(typesystem.Schema):
        id = typesystem.fields.Integer()
        name = typesystem.fields.String()
    definitions = SchemaDefinitions()
    definitions.update({"TestDefinitionOne":TestDefinitionOne})
    tdo = TestDefinitionOne(id = 1, name = "one")
    assert definitions["TestDefinitionOne"] == TestDefinitionOne
    assert tdo.id == 1
    assert tdo.name == "one"
    return


# Generated at 2022-06-22 06:09:19.458265
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    """Test the method __iter__ of class SchemaDefinitions"""
    sd = SchemaDefinitions()
    assert isinstance(sd, SchemaDefinitions)
    assert not list(sd)
    sd[1]=1
    assert len(sd)==1
    iter_sd = iter(sd)
    assert len(list(iter_sd))==len(sd)
    sd[2]=2
    assert len(sd)==2
    assert len(list(iter_sd))==len(sd)


# Generated at 2022-06-22 06:09:23.907174
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Pet(Schema):
        type = String(enum=["dog", "cat"])
        name = String()
        age = Integer()
        weight = Number()
    pet = Pet(name="Felix", type="cat", weight=4.5)
    assert sorted(pet) == ['age', 'name', 'type', 'weight']


# Generated at 2022-06-22 06:09:29.463264
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    assert("__init__" in definitions.__dict__.keys())


# Generated at 2022-06-22 06:09:31.658475
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
  # no need to test anything, just instantiate the class
  SchemaMetaclass(ABCMeta)

# Generated at 2022-06-22 06:09:34.742242
# Unit test for method __len__ of class Schema
def test_Schema___len__():

    class User(Schema):
        email = String(format="email")
        password = String(min_length=8)

    assert len(User(email="a.a@a.a", password="12345678")) == 2

# Generated at 2022-06-22 06:09:39.892014
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    class TestSchema(Schema):
        id = Integer()
    definitions[TestSchema.__name__] = TestSchema
    assert TestSchema == definitions[TestSchema.__name__]
    try:
        definitions[TestSchema.__name__] = TestSchema
    except asserttionError:
        pass
    else:
        assert False, "Shouldn't allow duplicate definitions"


# Generated at 2022-06-22 06:09:49.699605
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class SchemaTest(Schema):
        field = Field()

    # Run the tests
    # Should contain 1 item
    assert len(SchemaTest()) == 1
    # Should contain 0 items
    assert len(SchemaTest({'test': 1})) == 0
    # Should contain 1 item
    assert len(SchemaTest(field=1)) == 1
    # Should contain 0 items
    assert len(SchemaTest({'test': 1}, field=1)) == 0

    # Should raise TypeError
    try:
        SchemaTest(1)
    except TypeError:
        pass
    else:
        assert False, "Should raise TypeError"

    # Should raise TypeError
    try:
        SchemaTest(1, field=12)
    except TypeError:
        pass

# Generated at 2022-06-22 06:10:06.694457
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = String()

    class Bar(Schema):
        bar = String()

    class Baz(Schema):
        foo = Object(properties={"a": Reference("Bar", definitions=Foo.definitions)})
        bar = Object(properties={"a": Reference(Bar, definitions=Foo.definitions)})
        baz = Object(
            properties={"a": Array(items=[Reference("Bar", definitions=Foo.definitions)])}
        )
        bax = Object(properties={"a": Array(items=[Reference(Bar, definitions=Foo.definitions)])})


if __name__ == "__main__":
    test_set_definitions()

# Generated at 2022-06-22 06:10:08.670232
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test_definition = SchemaDefinitions()
    print(test_definition)
    print(type(test_definition))



# Generated at 2022-06-22 06:10:14.220947
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestModel(Schema):
        field_1 = String()
        field_2 = String()
    model = TestModel(field_1="test_1", field_2="test_2")
    assert len(model) == 2


# Generated at 2022-06-22 06:10:25.864028
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    import pytest
    import typesystem

    def test_normal_case():
        class TestSchemaDefinitions:
            def __init__(self):
                self.definitions = typesystem.SchemaDefinitions()
                class TestSchema(typesystem.Schema):
                    pass
                self.test_class = TestSchema
            def __call__(self):
                self.return_value = self.definitions[self.test_class.__name__]
                return self.return_value

        test_schema_definitions = TestSchemaDefinitions()
        _test_class = test_schema_definitions.test_class
        assert test_schema_definitions() == _test_class
        assert test_schema_definitions.return_value == _test_class



# Generated at 2022-06-22 06:10:36.553290
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        param1 = Field(type=str)
        param2 = Field(type=int)
        param3 = Field(type=str, default="default")
        param4 = Field(type=str, default="default", allow_null=True)
        param5 = Field(type=str, default=None, allow_null=True)
        param6 = Field(type=str, required=False, allow_null=True)
    assert TestSchema().param1 == None
    assert TestSchema().param2 == None
    assert TestSchema().param3 == "default"
    assert TestSchema().param4 == "default"
    assert TestSchema().param5 == None
    assert TestSchema().param6 == None

# Generated at 2022-06-22 06:10:37.182327
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    pass


# Generated at 2022-06-22 06:10:40.465936
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Test(Schema):
        foo = Integer()
    data = Test.validate({'foo':'10'})
    assert data['foo'] == 10


# Generated at 2022-06-22 06:10:51.386873
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import copy
    import sys
    import types
    import unittest
    from collections.abc import Mapping, MutableMapping

    from typesystem import String, fields

    class Foo(Schema):
        name = String()

    def is_non_string_iterable(obj):
        if not hasattr(obj, "__iter__") or isinstance(obj, str):
            return False
        if isinstance(obj, (tuple, list)):
            return True
        try:
            iter(obj)
        except TypeError:
            return False
        else:
            return True

    class TestSchema(unittest.TestCase):
        def test_create_schema(self):
            foo = Foo(name="Foo")
            self.assertEqual(foo.name, "Foo")

# Generated at 2022-06-22 06:10:58.234750
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Test SchemaDefinitions.__iter__ with an empty instance.
    schema_definitions = SchemaDefinitions()
    assert not [item for item in schema_definitions]

    # Test SchemaDefinitions.__iter__ with a nonempty instance.
    class Child(Schema):
        pass

    class Parent(Schema):
        child = Reference(Child)

    schema_definitions["Child"] = Child
    schema_definitions["Parent"] = Parent

    assert [item for item in schema_definitions] == ["Child", "Parent"]



# Generated at 2022-06-22 06:11:02.252579
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Define the test item
    definitions = SchemaDefinitions()

    # Execute the code to be tested
    result = len(definitions)

    # Verify the result
    assert result == 0



# Generated at 2022-06-22 06:11:17.626592
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    assert True

# Generated at 2022-06-22 06:11:24.183113
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    class Person(Schema):
        name = String()

    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    definitions["Person"] = Person
    assert len(definitions) == 1
    assert definitions["Person"] is Person
    try:
        definitions["Person"] = Person
    except AssertionError:
        pass
    else:
        assert False, "Definition for 'Person' has already been set."


# Generated at 2022-06-22 06:11:28.405497
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    def_ =  {'key_1': 'value_1', 'key_2': 'value_2', 'key_3': 'value_3'}
    iter_ = iter(SchemaDefinitions(def_))
    res = {}
    for key in iter_:
        res.update({key: def_[key]})
    assert res == def_


# Generated at 2022-06-22 06:11:29.039195
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass

# Generated at 2022-06-22 06:11:30.500910
# Unit test for constructor of class Schema
def test_Schema():
    assert type(Schema({})) == Schema


# Generated at 2022-06-22 06:11:33.846950
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.fields import String

    class Person(Schema):
        first_name = String()
        last_name = String()

    person = Person(first_name='Hans', last_name='Zimmer')

    ref = Reference(Person)
    assert ref.serialize(person) == {'first_name': 'Hans', 'last_name': 'Zimmer'}

# Generated at 2022-06-22 06:11:36.223601
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference('to').to == 'to'
    assert Reference('to').definitions is None


# Generated at 2022-06-22 06:11:46.862853
# Unit test for constructor of class Reference
def test_Reference():
    class ReferenceTestClass(Reference):
        def __init__(self, to, to_reference2=None, **kwargs):
            if to_reference2 is None:
                to_reference2 = Reference(to, **kwargs)
            super().__init__(to, to_reference2, **kwargs)

    class OnlyReferenceTestClass(Reference):
        def __init__(self, to, **kwargs):
            super().__init__(to, **kwargs)

    class Store(Schema):
        name = str

    class User(Schema):
        email = str

    # Nested Referenece
    ref1 = ReferenceTestClass(User)
    assert isinstance(ref1, Field)

    # Only Reference
    ref2 = OnlyReferenceTestClass(User)
    assert isinstance(ref2, Field)



# Generated at 2022-06-22 06:11:57.534676
# Unit test for function set_definitions
def test_set_definitions():
    class SubSchema(Schema):
        sub_field = Reference("Field")
        references = Array(Reference("Field"))
        reference_property = Object(properties={
            "field": Reference("Field")
        })

    class Schema(Schema):
        definitions = SchemaDefinitions()
        field = Reference("Field")
        sub_schema = SubSchema()
        sub_schemas = Array(SubSchema())

    set_definitions(Schema, Schema.definitions)

    assert Schema.field.definitions == Schema.definitions
    assert Schema.sub_schema.definitions == Schema.definitions
    assert Schema.sub_schemas.definitions == Schema.definitions

# Generated at 2022-06-22 06:12:07.638460
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person:
        first_name = String(required=True)
        last_name = String()
        age = Integer()

        def __init__(self, first_name: str, last_name: str, age: int) -> None:
            self.first_name = first_name
            self.last_name = last_name
            self.age = age

        def __eq__(self, other: typing.Any) -> bool:
            if not isinstance(other, self.__class__):
                return False
            return (
                self.first_name == other.first_name
                and self.last_name == other.last_name
                and self.age == other.age
            )


# Generated at 2022-06-22 06:12:24.917462
# Unit test for method validate of class Reference
def test_Reference_validate():
    # test with string references
    foo = Schema(bar = Reference("bar"))
    bar = Schema(bar = "test_string")
    definitions = SchemaDefinitions()
    definitions["bar"] = bar
    foo.validate_or_error("test_string")
    assert foo.validate("test_string") == "test_string"

# Generated at 2022-06-22 06:12:30.972525
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Test case 1 of 1
    test_instance = SchemaDefinitions({"t1": "t2"})
    test_key = "t1"

    try:
        del test_instance[test_key]
    except Exception as err:
        print("Exception when calling SchemaDefinitions.__delitem__:")
        print(err)
    else:
        assert "t1" not in test_instance


# Generated at 2022-06-22 06:12:37.639856
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Check when len(self.fields)==0
    class MySchema(Schema):
        pass
    obj = MySchema()
    assert len(obj) == 0
    # Check when len(self.fields)!=0
    class MySchema(Schema):
        name = Field()
    obj = MySchema()
    assert len(obj) == 0

# Generated at 2022-06-22 06:12:47.409414
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class PlanetSchema(Schema, metaclass=SchemaMetaclass):
        name = String()
        diameter_km = Integer()

        class orbits:
            class StarSchema(Schema, metaclass=SchemaMetaclass):
                name = String()
                age_billion_years = Float()
    assert "orbits" in PlanetSchema.fields
    assert isinstance(PlanetSchema.fields["orbits"], Object)
    assert PlanetSchema.fields["orbits"].required == ["StarSchema"]
    assert "StarSchema" in PlanetSchema.fields["orbits"].properties
    assert "name" in PlanetSchema.fields["orbits"].properties["StarSchema"].properties
    assert "age_billion_years" in PlanetSchema.fields["orbits"].properties["StarSchema"].properties


# Generated at 2022-06-22 06:12:55.544574
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Schema, String

    class PostSchema(Schema):
        title = String()

    definitions = SchemaDefinitions()
    post = PostSchema()

    assert post.fields == {"title": String()}
    assert post.title == None
    assert PostSchema.validate({"title": "This is a post"}) == PostSchema(
        title="This is a post"
    )
    assert definitions[PostSchema.__name__] == PostSchema



# Generated at 2022-06-22 06:13:02.066106
# Unit test for constructor of class Reference
def test_Reference():
    class User(Schema):
        username = String()

    class Post(Schema):
        created_by = Reference(to=User)

    post = Post(created_by={"username": "jane"})
    assert isinstance(post.created_by, User)
    assert post.created_by.username == "jane"


# Generated at 2022-06-22 06:13:07.009762
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class A(Schema):
        a1 = Field(type=str, required=True)
        a2 = Field(type=str, required=False)

    a = A(a1='a1', a2='a2')
    assert set(list(a)) == {'a1', 'a2'}



# Generated at 2022-06-22 06:13:08.085260
# Unit test for constructor of class Reference
def test_Reference():
    pass


# Generated at 2022-06-22 06:13:11.360000
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definition = SchemaDefinitions()
    class Test:
        pass
    definition["Test"] = Test
    assert definition["Test"] == Test


# Generated at 2022-06-22 06:13:15.910954
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    test_obj = SchemaDefinitions()
    key = "test"
    value = 1
    with pytest.raises(AssertionError) as excinfo:
        test_obj.__setitem__(key, value)
    assert str(excinfo.value) == r"Definition for 'test' has already been set."



# Generated at 2022-06-22 06:13:43.711149
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass


# Generated at 2022-06-22 06:13:46.261335
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Schema

    class Person(Schema):
        name = String()

    person = Person(name="Alex")
    assert len(person) == 1



# Generated at 2022-06-22 06:13:58.675531
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert len(SchemaDefinitions()) == 0
    assert len(SchemaDefinitions(b=2)) == 1
    assert SchemaDefinitions(b=2)['b'] == 2
    assert SchemaDefinitions()['a'] == ...
    assert SchemaDefinitions(b=2, c=3) == SchemaDefinitions(b=2, c=3)
    assert SchemaDefinitions(b=2, c=2) != SchemaDefinitions(b=2, c=3)
    assert SchemaDefinitions(a=1, b=2, c=3) != SchemaDefinitions(b=2, c=3)
    assert SchemaDefinitions(b=2) == SchemaDefinitions(b=2, c=3) == SchemaDefinitions(b=2)

# Generated at 2022-06-22 06:14:01.855811
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    sd = SchemaDefinitions({"a":"b"})
    assert len(sd) == 1
    sd["c"] = "d"
    assert len(sd) == 2
    del sd["a"]
    assert len(sd) == 1


# Generated at 2022-06-22 06:14:06.775567
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from Schema import Schema
    schema = Schema({})
    assert len(schema) == 0
    schema = Schema({
        'a': 'a',
        'b': 'b',
        'c': 'c'
    })
    assert len(schema) == 3


# Generated at 2022-06-22 06:14:11.119614
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Setup test data
    self = SchemaDefinitions()
    self._definitions = {}

    # Exercise SUT
    result = self.__len__()

    # Verify
    assert result == 0, "__len__ returned {!r} should be 0".format(result)

# Generated at 2022-06-22 06:14:17.953352
# Unit test for method validate of class Reference
def test_Reference_validate():
    from .constants import Comment
    from .objects import Review
    from .types import Reference
    print('test_Reference_validate')
    review = Review(
        id=12,
        tags=["photo", "nice"],
        comment=Reference(to=Comment),
        rating=4
    )
    print(review)
    review.validate(strict=False)


# Generated at 2022-06-22 06:14:23.215441
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # null
    class MemberSchema(Schema):
        name = String(max_length=10)
    schema = MemberSchema(name='Alicia')
    print(schema)

    # not null
    class StudentSchema(Schema):
        name = String(max_length=10)
        age = Integer()
    schema = StudentSchema()
    print(schema)

# Generated at 2022-06-22 06:14:30.403119
# Unit test for function set_definitions
def test_set_definitions():
    class B(Schema):
        value = Reference("A")

    class A(Schema):
        value = Reference("B")

    definitions = SchemaDefinitions()
    assert A.fields["value"].definitions is None
    assert B.fields["value"].definitions is None
    set_definitions(A.fields["value"], definitions)
    assert A.fields["value"].definitions == definitions
    assert B.fields["value"].definitions == definitions

# Generated at 2022-06-22 06:14:32.069547
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions()
    definitions.__setitem__('key', 'value')
    assert definitions.__getitem__('key') == 'value'


# Generated at 2022-06-22 06:15:40.054370
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # call the constructor with no parameters
    x = SchemaDefinitions()
    assert x == {}

    # call the constructor with a single parameter
    x = SchemaDefinitions({0: 0, 1: 1})
    assert x == {0: 0, 1: 1}

    # call the constructor with a positional parameter and another parameter
    x = SchemaDefinitions({0: 0}, {1: 1})
    assert x == {0: 0, 1: 1}

    # call the constructor with parameters of different types
    x = SchemaDefinitions({0: 0, 1: 1}, {2: 2})
    assert x == {0: 0, 1: 1, 2: 2}

    # call the constructor with keyword parameters
    x = SchemaDefinitions(**{0: 0, 1: 1})

# Generated at 2022-06-22 06:15:43.917037
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        name = String()

    s = MySchema()

    assert set(iter(s)) == set()

    s = MySchema(name='s')

    assert set(iter(s)) == set(['name'])

# Generated at 2022-06-22 06:15:50.385414
# Unit test for method validate of class Reference
def test_Reference_validate():
    '''
    Test if the method validate returns the right value for the given input
    '''

    # Arrange
    Person = type(
        "Person",
        (),
        {
            "__init__": lambda self, name: setattr(self, "name", name),
            "__eq__": lambda self, other: self.name == other.name,
            "__repr__": lambda self: f"{self.__class__.__name__}(name={self.name!r})",
        },
    )
    class PersonReference(Reference):
        errors = {"null": "May not be null.", "invalid_reference": "Reference must be a string."}

    person_reference = PersonReference(to=Person)
    person = Person(name="bob")

# Generated at 2022-06-22 06:15:53.725953
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    assert len(schema_definitions) == 0

    schema_definitions["foo"] = "bar"
    assert len(schema_definitions) == 1



# Generated at 2022-06-22 06:15:55.937492
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions({'__len__': None})
    assert len(definitions) == 1
    del definitions['__len__']
    assert len(definitions) == 0


# Generated at 2022-06-22 06:16:05.859342
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        count = Field()

    class Bar(Schema):
        foo = Reference(foo=Foo)

    class Baz(Schema):
        bar = Reference(bar=Bar)
        bar_list = Array(items=Reference(bar=Bar))
        foo_list = Array(items=Reference(foo=Foo))

    definitions = SchemaDefinitions()
    set_definitions(Baz.make_validator(), definitions=definitions)

# Generated at 2022-06-22 06:16:08.312697
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    sd = SchemaDefinitions
    sd = sd()
    sd.__delitem__("a")
    assert True == True


# Generated at 2022-06-22 06:16:14.356190
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Input data
    definitions={'mydef': 42}
    schema_definitions = SchemaDefinitions(definitions)
    # Expected output
    expected = {'mydef': 42}
    # Actual output
    del schema_definitions['mydef']
    assert expected == schema_definitions._definitions


# Generated at 2022-06-22 06:16:21.262543
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sch = SchemaDefinitions({'a':'c'})
    assert sch['a'] == 'c'
    sch['b'] = 'd'
    assert sch['b'] == 'd'
    assert len(sch) == 2
    sch['c'] = 'e'
    assert sch['c'] == 'e'
    assert len(sch) == 3
    del sch['b']
    assert len(sch) == 2


# Generated at 2022-06-22 06:16:29.425989
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import sys
    import os
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    os.environ["PYTHONUNBUFFERED"] = "1"
    os.environ["PYTHONIOENCODING"] = "utf-8"
    sys.setrecursionlimit(2147483647)
    # Setup and call the method
    cls = Schema
    schema = cls()
    expected = 0
    result = len(schema)