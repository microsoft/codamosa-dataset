

# Generated at 2022-06-22 06:08:27.411740
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import pytest
    from typesystem import Schema, String, Integer, Reference

    class UserSchema(Schema):
        name = String()
        age = Integer(minimum=0)

    class AddressSchema(Schema):
        street = String()
        city = String()

    class Person(Schema):
        name = String()
        address = Reference(to='AddressSchema')

    class Order(Schema):
        user = Reference(to='UserSchema')
        address = Reference(to='AddressSchema')

    user = UserSchema(name='John', age=31)

    address = AddressSchema(street='1 Main St.', city='New York')

    person_1 = Person(name='John', address=address)
    person_2 = Person(name='John', address=address)

    order_1 = Order

# Generated at 2022-06-22 06:08:38.760581
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String(max_length=100)
        age = Number(multiple_of=10)
        created_at = Date()
    assert Person(None, name="Jane", age = 35, created_at = "2019-01-01").__repr__() == "Person(name='Jane', age=35, created_at=datetime.date(2019, 1, 1))"
    assert Person.validate(
        {"name": "Jane", "age": 35, "created_at": "2019-01-01"}
    ).__repr__() == "Person(name='Jane', age=35, created_at=datetime.date(2019, 1, 1))"
    assert Person.validate(
        {"age": 35, "created_at": "2019-01-01"}
    ).__re

# Generated at 2022-06-22 06:08:47.645589
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    def _test(schema_1, schema_2, expectation):
        actual = schema_1 == schema_2
        assert actual == expectation, (
            f"Expected: {expectation}."
            f"Received: {actual}."
            f"Object 1: {schema_1}."
            f"Object 2: {schema_2}."
            f"Type of Object 1: {type(schema_1)}."
            f"Type of Object 2: {type(schema_2)}."
        )

    # Test 1 of 2
    test_schema_1_1 = Schema()
    test_schema_2_1 = Schema()
    _test(test_schema_1_1, test_schema_2_1, True)
    # Test 2 of 2
    test_schema

# Generated at 2022-06-22 06:08:58.864940
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from operator import itemgetter
    from itertools import chain
    from typesystem.fields import String

    class Person(Schema):
        first_name = String(max_length=100)
        last_name = String(max_length=100)
        age = String(max_length=100)

    person1 = Person(first_name="Lokesh", last_name="Patel", age="25")
    person2 = Person(first_name="fname1", last_name="lname1", age="25")


# Generated at 2022-06-22 06:09:10.154584
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class User:
        def __init__(self, id, name):
            self.id=id
            self.name=name

    class Project:
        def __init__(self, id, name):
            self.id=id
            self.name=name

    class Person:
        def __init__(self, id, name):
            self.id=id
            self.name=name

    class ProjectSchema(Schema):
        id = String()
        name = String()
        users = Array(items=Reference('User'))
        owner = Reference('User')

    class UserSchema(Schema):
        id = String()
        name = String()
        projects = Array(items=Reference('Project'))

    class PersonSchema(Schema):
        id = String()
        name = String()

# Generated at 2022-06-22 06:09:14.459055
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()
    p1 = Person(name='name1', age=10)
    p2 = Person(name='name1', age=10)
    p3 = Person(name='name2', age=20)
    assert p1 == p2
    assert p1 != p3


# Generated at 2022-06-22 06:09:18.736525
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import String
    from typesystem import Schema
    class Query(Schema):
        query = String()

    s1 = Query({"query": "query"})

    s2 = Query({"query": "query"})

    assert (s1 == s2)



# Generated at 2022-06-22 06:09:25.962797
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    """Test whether function __len__ works correctly."""
    # Call function to be tested
    schema_definitions = SchemaDefinitions(
        {'a': 1, 'b': 2, 'c': 3}
    )
    len_schema_definitions = len(schema_definitions)
    # Check output
    assert len_schema_definitions == 3, 'Test for __len__ failed!'
    
    

# Generated at 2022-06-22 06:09:37.000950
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Base(Schema):
        name = String(max_length=8)

    class Child(Schema):
        name = String(max_length=8)
        parents = Array(Reference(Base), min_length=1)

    base1 = Base(name="Oscar")
    base2 = Base(name="Fernanda")
    child = Child(name="Sofia", parents=[base1, base2])
    child_ref = Reference(Child)
    child_ref.validate(child)
    child_ref.validate(child.serialize())
    child_ref.validate(child.serialize()[0])
    child_ref.validate(child.serialize()[1])
    child_ref.validate(child.serialize()[2])

# Generated at 2022-06-22 06:09:43.907161
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Object
    class MySchema(Schema):
        property1 = Object(properties={"property2": Field(type="string")})
    __ds_schema_definition_0 = MySchema
    class MySchemaWithReference(Schema):
        my_ref = Reference(to="MySchema")
    __ds_schema_definition_1 = MySchemaWithReference
__ds_schema_subclass_0 = MySchema
__ds_schema_subclass_1 = MySchemaWithReference

# Generated at 2022-06-22 06:10:05.005573
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    x = Schema_test()
    y = Schema_test()
    assert (x == y)
    y.a = 1
    assert (not x == y)
    y.a = 0
    y.b = 1
    assert (not x == y)
    y.b = 0
    y.c = 1
    assert (not x == y)
    y.c = 0
    y.d = 1
    assert (not x == y)
    y.d = 0
    y.e = 1
    assert (not x == y)
    y.e = 0
    y.f = 1
    assert (not x == y)
    y.f = 0
    y.g = 1
    assert (not x == y)
    y.g = 0
    y.h = 1

# Generated at 2022-06-22 06:10:07.593669
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    x = SchemaDefinitions({"one": 1, "two": 2})
    assert 2 == len(x) 


# Generated at 2022-06-22 06:10:16.992844
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    import typesystem

    class Person(Schema):
        name = typesystem.String()
        age = typesystem.Integer()

    schema_definitions = SchemaDefinitions()

    # Test that the right error message is raised when a definition is already set
    try:
        schema_definitions.__setitem__("Person", Person)
    except AssertionError as e:
        assert str(e) == r"Definition for 'Person' has already been set."
    else:
        raise AssertionError("The test should have failed.")

    # Test that the definition is set when it doesn't exist
    schema_definitions.__setitem__("Dog", Person)
    assert schema_definitions["Dog"] == Person



# Generated at 2022-06-22 06:10:28.960687
# Unit test for method validate of class Reference

# Generated at 2022-06-22 06:10:32.803737
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definition_set = SchemaDefinitions()
    definition_set['test'] = 1
    assert definition_set['test'] == 1
    del definition_set['test']
    assert 'test' not in definition_set


# Generated at 2022-06-22 06:10:35.897823
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Test 1
    definitions = SchemaDefinitions()
    definitions['a'] = "aaa"
    definitions['b'] = "bbb"
    definitions['c'] = "ccc"
    for key in definitions:
        print(key)

# Generated at 2022-06-22 06:10:47.895568
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class B(Schema):
        n = Field(description="Number", type="Integer")
        a1 = Field(description="Array of numbers", type="Array[Integer]", default=[])
        a2 = Field(description="Array of numbers", type="Array[Integer]", default=[1])
        a3 = Field(description="Array of numbers", type="Array[Integer]", default=[1, 2])
        a4 = Field(description="Array of numbers", type="Array[Integer]", default=[1, 2, 3])
        a5 = Field(description="Array of numbers", type="Array[Integer]", default=[1, 2, 3, 4])
        a6 = Field(description="Array of numbers", type="Array[Integer]", default=[1, 2, 3, 4, 5])

# Generated at 2022-06-22 06:10:50.398825
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    test_obj = SchemaDefinitions({'dict1': 'key1 value'})
    assert test_obj['dict1'] == 'key1 value'


# Generated at 2022-06-22 06:11:00.002346
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    global SchemaDefinitions
    class SchemaDefinitions(MutableMapping):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            self._definitions = dict(*args, **kwargs)  # type: dict
        def __getitem__(self, key: typing.Any) -> typing.Any:
            return self._definitions[key]
        def __iter__(self) -> typing.Iterator[typing.Any]:
            return iter(self._definitions)
        def __len__(self) -> int:
            return len(self._definitions)
        def __setitem__(self, key: typing.Any, value: typing.Any) -> None:
            assert (key not in self._definitions), r"Definition for {key!r} has already been set."

# Generated at 2022-06-22 06:11:12.042109
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import String

    class AuthorSchema(Schema):
        name = String()

    class PostSchema(Schema):
        title = String()
        author = Reference(AuthorSchema)

    class CommentSchema(Schema):
        content = String()

    class PostWithCommentsSchema(PostSchema, CommentSchema):
        pass

    definitions = SchemaDefinitions(post=PostSchema)
    post = PostSchema(title="The Title")
    assert post.validate_or_error({"title": "The Title"}) == (post, None)

    post = PostWithCommentsSchema(title="The Title", content="Nice post")
    assert (
        post.validate_or_error({"title": "The Title", "content": "Nice post"})
        == (post, None)
    )

# Generated at 2022-06-22 06:11:29.146114
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sd = SchemaDefinitions()
    sd[1] = 'test1'
    assert sd[1] == 'test1'
    assert sd._definitions[1] == 'test1'


# Generated at 2022-06-22 06:11:32.612355
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    class Owner(Schema):
        owner = Reference(Person)

    assert Owner.fields == {"owner": Reference("Person")}

# Generated at 2022-06-22 06:11:35.952304
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from .test_fields import String

    class User(Schema):
        user_id = String(max_length=100)

    assert User.fields["user_id"] == String(max_length=100)

# Generated at 2022-06-22 06:11:36.594023
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    _definitions = SchemaDefinitions()

# Generated at 2022-06-22 06:11:39.905629
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Check that setting the same definition twice throws an error.
    sd = SchemaDefinitions()
    sd['key'] = 42
    try:
        sd['key'] = 41
        assert False, "Expected exception"
    except Exception as e:
        assert str(e) == 'Definition for \'key\' has already been set.'

    # Check that a valid definition is set.
    sd = SchemaDefinitions()
    sd['key'] = 42
    assert sd['key'] == 42


# Generated at 2022-06-22 06:11:50.222552
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert SchemaDefinitions()._definitions=={}
    assert SchemaDefinitions('this is a key','this is a value')._definitions=={}
    assert SchemaDefinitions(a='this is a key',b='this is a value')._definitions=={'a':'this is a key','b':'this is a value'}
    assert SchemaDefinitions(a='this is a key',b='this is a value')._definitions=={'a':'this is a key','b':'this is a value'}
    with raises(AssertionError):
        SchemaDefinitions(a='this is a key',b='this is a value',a='this is a key')._definitions=={'a':'this is a key','b':'this is a value'}


# Generated at 2022-06-22 06:12:01.001555
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        name = Field(type=str)

    class TestSchema2(Schema):
        name = Field(type=str)

    TestSchema_v = TestSchema.validate
    TestSchema2_v = TestSchema2.validate

    d = SchemaDefinitions()
    ref = Reference(to=TestSchema.__name__, definitions=d)
    assert ref.target == TestSchema
    validate = ref.validate
    assert ref.validate(TestSchema_v(name="franz")) == TestSchema_v(name="franz")
    assert ref.validate(TestSchema2_v(name="franz")) == TestSchema2_v(name="franz")

# Generated at 2022-06-22 06:12:05.364500
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    # Test that serialize() serializes an object of class Reference
    # Test that serialize() raises TypeError if obj is None
    # Test that serialize() returns a dict
    obj = Reference('to', 'definitions')
    print(obj.serialize(obj))

test_Reference_serialize()

# Generated at 2022-06-22 06:12:15.971860
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Test(Schema, metaclass=SchemaMetaclass):
        a = String(max_length=1)
        b = String(max_length=2)
        c = String(max_length=3)
    f1 = Test.fields
    assert f1["a"].max_length == 1
    assert f1["b"].max_length == 2
    assert f1["c"].max_length == 3
    assert Test.__name__ == "Test"
    t = Test(a="", b="", c="")
    assert t.__repr__() == "Test(a='', b='', c='')"
    assert t.__repr__() == "Test(a='', b='', c='')"
    assert t == Test(a="", b="", c="")

# Generated at 2022-06-22 06:12:24.963024
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typing import Union, Type
    from typesystem.fields import String, Integer

    class AddressSchema(Schema):
        line_1 = String()
        line_2 = String()
        city = String()
        state = String()


    class PersonSchema(Schema):
        name = String()
        age = Integer(minimum=18)
        address = Reference(AddressSchema)
        addresses = Reference(AddressSchema, multiple=True)



# Generated at 2022-06-22 06:12:51.458580
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema1(Schema):
        field1 = Field(required=True)
        field2 = Field(required=True)

    class TestSchema2(Schema):
        field1 = Field(required=True)
        field2 = Field(required=True)

    class TestSchema3(Schema):
        field1 = Field(required=True)
        field2 = Field(required=True)
        field3 = Field(required=True)

    assert TestSchema1("test_value") == TestSchema1("test_value")

    assert TestSchema1("test_value") != TestSchema1("test_value2")

    assert TestSchema1("test_value") == TestSchema2("test_value")

    assert TestSchema1("test_value") != TestSchema3("test_value")


# Generated at 2022-06-22 06:12:58.294814
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert ['name', 'email'] == list(Person({'name' : 'Alan', 'email' : 'alan@abc.com'}))
    try:
        assert ['name', 'email'] == list(Person({'name' : 'Alan', 'email' : 'alan@abc.com', 'age' : '20'}))
    except:
        assert True


# Generated at 2022-06-22 06:13:02.560348
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    definitions['aaa'] = '1' # type: ignore
    assert len(definitions) == 1


# Generated at 2022-06-22 06:13:16.689907
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test Schema's __getitem__ with valid inputs and no default values
    class SimpleSchema(Schema):
        field1 = Integer()
        field2 = String()

    instance = SimpleSchema({"field1": 1, "field2": "two"})
    assert len(instance) == 2
    assert instance["field1"] == 1
    assert instance["field2"] == "two"

    # Test Schema's __getitem__ with valid inputs and default values
    class TestSchema(Schema):
        field1 = Integer()
        field2 = String()
        field3 = String(default="three")

    instance = TestSchema({"field1": 1, "field2": "two"})
    assert len(instance) == 3
    assert instance["field1"] == 1
    assert instance["field2"] == "two"

# Generated at 2022-06-22 06:13:22.564053
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():

	
	result = SchemaDefinitions()
	
	# When setting the first item, assert not raised
	result[1] = 1
	
	try:

		# When setting the second item, assert raised
		result[1] = 1
		assert False, "Expected an AssertionError to be raised"

	except AssertionError:
		pass



# Generated at 2022-06-22 06:13:29.529354
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    data = {"num1": 12, "num2": 34, "bool": True, "str": "string"}
    class A(Schema):
        num1 = Field(required=True, type="integer")
        num2 = Field(required=True, type="integer")
        bool = Field(required=True, type="boolean")
        str = Field(required=True, type="string")
    a = A(data)
    assert len(a.fields) == len(list(a))


# Generated at 2022-06-22 06:13:38.046074
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class SubSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    s = SubSchema()

    # Test case:
    # 1. try to iterate over SubSchema (schema which has not been initialized
    #     and has no attribute field1)
    # 2. check that iterator contains field2 and field3
    # 3. check that field2 and field3 exist in schema s

    for key in s:
        assert key in ("field2", "field3")
        assert hasattr(s, key)


# Generated at 2022-06-22 06:13:49.000484
# Unit test for function set_definitions
def test_set_definitions():
    class DefObject(Object):
        test = String()
    class TestSchema(Schema):
        field = Reference('DefObject')
    classm = TestSchema.__dict__.get('field').__class__
    print(classm.__name__)
    definitions = SchemaDefinitions()
    set_definitions(TestSchema.__dict__.get('field'), definitions)
    definitions['DefObject'] = DefObject
    reference_field = TestSchema.__dict__.get('field')
    assert reference_field.target is not None
    assert reference_field.target is DefObject

# Generated at 2022-06-22 06:13:50.479260
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    instance = SchemaDefinitions()
    assert False



# Generated at 2022-06-22 06:14:00.936102
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema(Schema):
        a = Integer()
        b = Integer()

    assert TestSchema().fields["a"].__class__.__name__ == "Integer"
    assert TestSchema().fields["b"].__class__.__name__ == "Integer"

    class TestSubSchema(TestSchema):
        c = Integer()

    assert TestSubSchema().fields["a"].__class__.__name__ == "Integer"
    assert TestSubSchema().fields["b"].__class__.__name__ == "Integer"
    assert TestSubSchema().fields["c"].__class__.__name__ == "Integer"

    assert TestSchema().__class__.__name__ == "TestSchema"
    assert TestSubSchema().__class__.__name__ == "TestSubSchema"

# Generated at 2022-06-22 06:14:19.466949
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert callable(SchemaDefinitions)


# Generated at 2022-06-22 06:14:30.835765
# Unit test for function set_definitions
def test_set_definitions():
    yaml = """
    type: object
    properties:
        prop1:
            type: object
            properties:
                prop1_1:
                    type: object
                    properties:
                        prop1_1_1:
                            type: string
    """
    prop1 = Field.from_yaml(yaml)
    prop2 = Field.from_yaml(yaml)
    prop3 = Field.from_yaml(yaml)
    prop1.validators.append(Reference("MySchema"))
    prop2.validators.append(Reference("MySchema"))
    prop3.validators.append(Reference("MySchema"))
    definitions = SchemaDefinitions()
    set_definitions(prop1, definitions)
    set_definitions(prop2, definitions)

# Generated at 2022-06-22 06:14:36.718954
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Employee(Schema):
        first_name = String()
        title = String()

    class Company(Schema):
        title = String()
        employees = Array(items=Reference(to=Employee))

    employees = [Employee(first_name="Alice", title="CTO"), Employee(first_name="Bob", title="Developer")]
    company = Company(title="ACME Inc.", employees=employees)

    assert company.title == "ACME Inc."
    assert company.employees[0].first_name == "Alice"
    assert company.employees[0].title == "CTO"
    assert company.employees[1].first_name == "Bob"
    assert company.employees[1].title == "Developer"

# Generated at 2022-06-22 06:14:40.602642
# Unit test for method validate of class Reference
def test_Reference_validate():
    ref = Reference(
        to=str,
        definitions={str: str},
        allow_null=False,
    )
    assert ref.validate('test') == 'test'


# Generated at 2022-06-22 06:14:43.856750
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sd = SchemaDefinitions()
    sd['key'] = 'value'
    assert sd == {'key': 'value'}


# Generated at 2022-06-22 06:14:55.824878
# Unit test for method validate of class Reference
def test_Reference_validate():
    import pytest
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    class Dog(Schema):
        name = String()

    class PetSchema(Schema):
        pet = Reference(to=Dog)

    pet_schema = PetSchema(pet={"name": "Lucy"})
    pet_schema2 = PetSchema(pet={"name": "Lucy"})
    pet_schema3 = PetSchema({"name": "Lucy"})

    assert pet_schema.pet == pet_schema2.pet
    assert pet_schema.pet != pet_schema3.pet

    with pytest.raises(TypeError):
        PetSchema(pet={"names": "Lucy"})



# Generated at 2022-06-22 06:15:01.921810
# Unit test for method validate of class Reference
def test_Reference_validate():
    ref = Reference(to='A')
    ref.validate(0)
    ref.validate(None)
    ref.validate(False)
    from typesystem import Integer
    A = Schema(Integer)
    ref.validate(1, strict=True)
    ref.validate(1, strict=False)
    ref.validate(None, strict=True)
    ref.validate(None, strict=False)


# Generated at 2022-06-22 06:15:09.830375
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.exceptions import ValidationError
    from typesystem.objects import Object
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    assert len(Person()) == 0

    try:
        person = Person(name="foo")
    except ValidationError:
        pass
    else:
        assert False, "The person should be invalid."

    person = Person(name="foo", age=30)

    assert len(person) == 2



# Generated at 2022-06-22 06:15:17.083637
# Unit test for constructor of class Schema
def test_Schema():
    # First we define the fields in the schema.
    fields = {'name': '', 'age': 0, 'gender': ''}
    # Next we create a schema object with the fields.
    s = Schema(fields)
    # We make a dictionary by running the fields through the Schema method make_validator()
    print(s.make_validator())
    # We call the validate method to check whether the fields in the schema are valid
    print(s.validate(s))

test_Schema()

# Generated at 2022-06-22 06:15:28.068802
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        is_active = Boolean()

    class Address(Schema):
        street = String(max_length=100)
        city = String(max_length=50)
        state = String(max_length=2)

    definitions = SchemaDefinitions()
    definitions["Person"] = Person
    definitions["Address"] = Address

    class Order(Schema):
        price = Number(minimum=0)
        customer = Reference(to="Person", definitions=definitions)
        shipping_address = Reference(to="Address", definitions=definitions)


# Generated at 2022-06-22 06:15:55.551062
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = {"a": 1, "b": 2}
    schema_definitions = SchemaDefinitions()
    for key, value in definitions.items():
        schema_definitions[key] = value
    assert schema_definitions == definitions

    assert "a" in schema_definitions
    assert "c" not in schema_definitions
    assert schema_definitions["a"] == 1
    schema_definitions["a"] = 3
    assert schema_definitions["a"] == 3

    assert len(schema_definitions) == 2
    assert list(schema_definitions) == ["a", "b"]
    assert dict(schema_definitions) == {"a": 3, "b": 2}

    del schema_definitions["a"]
    assert len(schema_definitions) == 1

# Generated at 2022-06-22 06:15:58.220283
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Foo(Schema):
        bar = Field()

    foo = Foo(bar=1)

    result = foo.__len__()
    assert result == 1


# Generated at 2022-06-22 06:16:08.871539
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    """Unit test for method __iter__ of class SchemaDefinitions."""

    # Auto-generated by Spyder 4.1.1
    # Template generated on Wed Sep 18 2019 23:17:28 GMT+0000 (Coordinated Universal Time)

    # --- Setup code starts ---
    import sys
    import os
    import types
    foo = types.ModuleType("foo")
    sys.modules["foo"] = foo
    import datetime
    import typesystem
    foo.datetime = datetime
    foo.typesystem = typesystem
    def setUpModule():
        sys.modules["foo.datetime"] = foo.datetime
        sys.modules["foo.typesystem"] = foo.typesystem
    def tearDownModule():
        del sys.modules["foo.datetime"]
        del sys.modules["foo.typesystem"]
        del sys

# Generated at 2022-06-22 06:16:15.237600
# Unit test for constructor of class Reference
def test_Reference():
    name = "name"
    age = "age"
    class Fruit(Schema):
        name = typesystem.String(max_length=10)
        age = typesystem.Integer(minimum=0, maximum=100)

    apple = Fruit(name=name, age=age)
    expected = {name:name, age:age}
    assert apple == expected


# Generated at 2022-06-22 06:16:18.796252
# Unit test for function set_definitions
def test_set_definitions():
    class a(Schema):
        a = Reference("b")

    definitions = SchemaDefinitions()
    set_definitions(a.a, definitions)
    assert a.a.definitions == definitions

# Generated at 2022-06-22 06:16:23.203106
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(UserSchema(username='test', password='test')) == "UserSchema(password='test', username='test')"
    assert repr(PostSchema(title='test', author=None)) == "PostSchema(author=None, title='test')"


# Generated at 2022-06-22 06:16:27.139055
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():

    class MySchema(Schema):
        text = Field(String())

    test_schema = MySchema(
        text="lorem ipsum"
    )
    result = test_schema["text"]
    print(result)



# Generated at 2022-06-22 06:16:28.708647
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    assert definitions is not None


# Generated at 2022-06-22 06:16:40.395698
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    first_id = id(definitions)

    class Base:
        to = "Child"

        nested = Reference(to)

    class Child(Schema):
        pass

    class Middle(Schema):
        nested = Reference(to)

    Base.nested.definitions = definitions
    Middle.nested.definitions = definitions

    assert Base.nested.definitions is None
    assert Middle.nested.definitions is None

    set_definitions(Base.nested, definitions)
    # check that definitions are unchanged
    assert id(definitions) == first_id

    assert Base.nested.definitions is definitions
    assert Middle.nested.definitions is None

    set_definitions(Middle.nested, definitions)
    # check that definitions are unchanged

# Generated at 2022-06-22 06:16:43.614680
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema = Schema({"name": "Jessica"})
    assert schema["name"] == "Jessica"
    with pytest.raises(KeyError):
        schema["missing"]


# Generated at 2022-06-22 06:17:18.295398
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typing import Any
    import uuid

    class Book(Schema):
        id = Field(uuid.UUID)
        title = Field(str)


# Generated at 2022-06-22 06:17:25.333731
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # Test initialization with an empty dict
    my_definitions = SchemaDefinitions()

    # Test access to definition when it does not exist
    try:
        definition = my_definitions[0]
    except KeyError:
        pass
    else:
        raise RuntimeError("KeyError not raised.")

    # Test initialization with a dict
    my_definitions = SchemaDefinitions({1: 2, 3: 4})

    # Test access to definition when it does exist
    assert my_definitions[1] == 2
    assert my_definitions[3] == 4



# Generated at 2022-06-22 06:17:27.200952
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions({'A': 1})
    del schema_definitions['A']
    return len(schema_definitions) == 0



# Generated at 2022-06-22 06:17:30.645054
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import Integer

    class Language(Schema):
        id = Integer()

    assert isinstance(Language.fields["id"], Integer)


# Generated at 2022-06-22 06:17:41.193678
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test case insensitivity of field names
    class People(Schema):
        name = StringField()

    assert hasattr(People, "name")
    assert hasattr(People, "NAME") is False

    People = SchemaMetaclass(
        "People", (Schema,), {"name": StringField()}, definitions=None
    )
    assert hasattr(People, "name")
    assert hasattr(People, "NAME") is False

    # Test fields are sorted by creation order
    class Order(Schema):
        first = StringField()
        second = StringField()

    assert "first" in Order.fields
    assert "second" in Order.fields
    assert list(Order.fields.keys())[0] == "first"
    assert list(Order.fields.keys())[1] == "second"

    Order = Schema

# Generated at 2022-06-22 06:17:46.045239
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    d1 = {}
    d2 = {'key_1': 1, 'key_2': 2}
    d3 = {'key_1': 1, 'key_2': 2, 'key_3': 3}
    d4 = {'key_1': 1, 'key_2': 2, 'key_3': 3, 'key_4': 4}
    d5 = {'key_1': 1, 'key_2': 2, 'key_3': 3, 'key_4': 4, 'key_5': 5}
    d6 = {'key_1': 1, 'key_2': 2, 'key_3': 3, 'key_4': 4, 'key_5': 5, 'key_6': 6}

# Generated at 2022-06-22 06:17:49.961321
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class subSchema(Schema):
        a = int

    x = Reference(to=subSchema, allow_null=True)
    d  = {'a':1}
    y = x.serialize(d)
    assert y['a'] == 1


# Check that function serialize is a property of class Reference

# Generated at 2022-06-22 06:17:54.634788
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    args = ()
    kwargs = {"a":"1"}
    obj = SchemaDefinitions(*args, **kwargs)

    expected = 1
    actual = len(obj)
    assert actual == expected



# Generated at 2022-06-22 06:18:02.641118
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema = type('schema',(Schema,),{})
    definitions = SchemaDefinitions()
    #general case
    g_key = 'g_key'
    g_value = 1
    definitions[g_key] = g_value
    assert definitions[g_key] == g_value
    #assertion error case
    a_key = 'a_key'
    a_value = 2
    definitions[a_key] = a_value
    try:
        definitions[a_key] = a_value
        assert 0
    except AssertionError:
        pass
