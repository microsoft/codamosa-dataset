

# Generated at 2022-06-22 06:08:08.879563
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Test:
        x = 2
        y = 3
    base = Test()
    same = Test()
    base == same


# Generated at 2022-06-22 06:08:17.309775
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    x = SchemaDefinitions({"a": "b"})
    x["a"] = "b"
    x["a"] = "b"
    x["a"] = "b"
    x["a"]
    for key in x:
        print(key)
    len(x)
    x.__delitem__(0)
    x.__delitem__(0)
    x.__delitem__(0)
    x.__delitem__(0)
    x["a"] = "b"
    x["a"] = "b"
    x["a"] = "b"
    x["a"] = "b"
    x.__delitem__(0)
    x.__delitem__(0)
    x.__delitem__(0)
    x.__delitem__(0)


# Generated at 2022-06-22 06:08:21.135470
# Unit test for constructor of class Reference

# Generated at 2022-06-22 06:08:26.248532
# Unit test for constructor of class Schema
def test_Schema():
    class S(Schema):
        name = Field(str)
        age = Field(int, default=0)
        number = Field(float, default=0.0)
        nullable = Field(str, null=True, default=None)
    assert isinstance(S, Schema)



# Generated at 2022-06-22 06:08:37.639615
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    _id = "5d35f83b-5bb0-46b5-8597-20e81c509f98"
    _id_2 = "2"
    # 1
    mapping = SchemaDefinitions(
        {
            "id": "5d35f83b-5bb0-46b5-8597-20e81c509f98",
            "username": "xzhou",
            "email": "xzhouemail@gmail.com",
            "password": "testing",
            "password2": "testing",
            "register_on": "2019-07-26T15:18:35.980262",
        }
    )
    mapping_1_0 = mapping.__getitem__("id")
    mapping_1_1 = mapping.__getitem__("username")
    mapping_1_2

# Generated at 2022-06-22 06:08:41.865154
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class MySchema(Schema):
        a = Field()
        b = Field()
    my_schema1 = MySchema(a=2,b=1)
    try:
        my_schema1.__getitem__('a')
    except Exception as e:
        raise e


# Generated at 2022-06-22 06:08:49.821511
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    # Create empty class
    from typesystem.fields import Integer, String
    class TestSchema(Schema):
        pass
    # Check it has correct members
    assert isinstance(TestSchema.fields, dict)
    assert not TestSchema.fields
    # Create class with fields, assert they are correctly sorted
    class TestSchema(Schema):
        first = Integer()
        second = Integer()
        third = Integer()
    assert isinstance(TestSchema.fields, dict)
    assert set(TestSchema.fields) == {'first', 'second', 'third'}
    # Create class with a reference field, assert it is correctly added
    TestReference = Reference("TestReference", definitions=dict())
    class TestSchema(Schema):
        reference = TestReference()
    assert isinstance(TestSchema.fields, dict)


# Generated at 2022-06-22 06:08:53.788544
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    d =  SchemaDefinitions()
    d["key"] = "value"
    del d['key']

# Generated at 2022-06-22 06:08:57.449598
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    """
    Test __getitem__ of class SchemaDefinitions
    """
    obj1 = SchemaDefinitions()
    value_key = True
    value_item = True
    returned_item = obj1.__getitem__(value_key)
    assert returned_item == value_item

test_SchemaDefinitions___getitem__()


# Generated at 2022-06-22 06:08:58.978917
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    result = obj.__len__()
    assert result == 0


# Generated at 2022-06-22 06:09:13.555584
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    item = Schema.validate({
        "name": "test", 
        "is_test": True,
        "count": 9
    })
    assert repr(item) == "Schema(name='test', is_test=True, count=9)"

# Generated at 2022-06-22 06:09:19.485701
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Base(Schema):
        id = Field(type="string")

    class Sub(Base, Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert Base.fields == {"id": Base.id}
    assert Sub.fields == {"id": Base.id, "name": Sub.name, "age": Sub.age}


# Generated at 2022-06-22 06:09:26.880179
# Unit test for method __len__ of class Schema
def test_Schema___len__():
  from unittest.mock import MagicMock
  from unittest.mock import patch

  # Patching
  referred_value = MagicMock(return_value=False)
  target_value = MagicMock(return_value=False)

  with patch('builtins.hasattr', new=referred_value):
    with patch('builtins.isinstance', new=target_value):

      # Arrange
      schema = Schema([], **{})


      # Act
      result = len(schema)


      # Assert
      assert result == 0

# Generated at 2022-06-22 06:09:31.693608
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    my_def = SchemaDefinitions(
        {"a": 1, "b": 2}, {"c": 3, "d": 4}, a=5, b=6
    )
    assert my_def == {"a": 5, "b": 6, "c": 3, "d": 4}


# Generated at 2022-06-22 06:09:33.430338
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Foo(Schema):
        foo = Integer(default=0)

    assert Foo().__getitem__("foo") == 0


# Generated at 2022-06-22 06:09:37.629874
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    '''
    Ensure that adding duplicate definitions fails.
    '''
    test_SchemaDefinitions___setitem__.stderr = capture_stderr(
    lambda: SchemaDefinitions().__setitem__('x',1)
    )
    assert True # TODO: implement your test here


# Generated at 2022-06-22 06:09:47.051572
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import pytest

    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer

    class Person(Schema):
        name = Field()
        age = Integer(description="Age in years")

    class Address(Schema):
        city = Field()
        state = Field()

    class Employee(Person):
        salary = Integer()
        address = Address()

    employee = Employee(name="Bob", salary=25000, address=Address(city="Lakeside", state="CA"))
    expected = 'Employee(address=Address(city="Lakeside", state="CA"), name="Bob", salary=25000)'
    actual = repr(employee)


# Generated at 2022-06-22 06:09:52.776950
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class FooSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    foo = FooSchema(a = 123, b = 456, c = 789)
    bar = FooSchema(a = 123, b = 456, c = 789)
    baz = FooSchema(a = 123, b = 456, c = 789, d = 500)
    qux = FooSchema(a = 123, b = 456)
    assert foo == bar
    assert foo != baz
    assert foo != qux
    assert foo != {'a':123, 'b':456, 'c':789}
    assert foo != 123
    assert foo != '123'

# Generated at 2022-06-22 06:10:05.741326
# Unit test for constructor of class Schema
def test_Schema():
    # Declare attributes
    class BaseSchema(Mapping,metaclass=SchemaMetaclass):
        fields: typing.Dict[str, Field] = {}
        a = True
        b = True
        c = True
        d = True
        e = True
        f = True
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            if args:
                assert len(args) == 1
                assert not kwargs
                item = args[0]
                if isinstance(item, dict):
                    for key in self.fields.keys():
                        if key in item:
                            setattr(self, key, item[key])

# Generated at 2022-06-22 06:10:14.290174
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class S1(Schema):
        a = Field(type="integer")
        b = Field(type="string", required=True)
        c = Field(type="string", default="hello")

    v = S1()
    assert repr(v) == "S1(b=None)"
    v.b = "world"
    assert repr(v) == "S1(b='world')"
    del v.b
    v.a = 123
    v.c = "bye"
    assert repr(v) == "S1(a=123)"



# Generated at 2022-06-22 06:10:30.466657
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class FooSubSchema(Schema):
        bar = Field(validators=[])
    class FooSchema(Schema):
        foo = Reference(to=FooSubSchema)
    data = {"bar": "bar"}
    schema = FooSchema.validate(data)
    result = FooSchema.validate(schema)
    assert data == result.foo

# Generated at 2022-06-22 06:10:35.102631
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    print("Test SchemaDefinitions class")
    # Unit test for method __getitem__ of class SchemaDefinitions
    schema_def = SchemaDefinitions()
    schema_def["abc"] = 1
    assert schema_def["abc"]==1
    print("Successfully tested SchemaDefinitions class")

# Generated at 2022-06-22 06:10:41.271991
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions['1'] = 'a'
    schema_definitions['2'] = 'b'
    del schema_definitions['1']
    assert len(schema_definitions) == 1
    assert schema_definitions['2'] == 'b'


# Generated at 2022-06-22 06:10:46.491680
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    instances = dict()
    instances[(1,)] = SchemaDefinitions([(1,)]), ["1"], None
    for key, (instance, expected_result, expected_exception) in instances.items():
        with pytest.raises(expected_exception):
            result = instance.__iter__()
            assert expected_result == result


# Generated at 2022-06-22 06:10:48.238026
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    len(obj) == 0


# Generated at 2022-06-22 06:10:59.747245
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import enum
    import typing
    class SchemaMetaclass(ABCMeta):

        def __new__(cls, name, bases, attrs, definitions=None):
            fields: typing.Dict[str, Field] = {}

            for key, value in list(attrs.items()):
                if isinstance(value, Field):
                    attrs.pop(key)
                    fields[key] = value

            # If this class is subclassing other Schema classes, add their fields.
            for base in reversed(bases):
                base_fields = getattr(base, 'fields', {})
                for key, value in base_fields.items():
                    if isinstance(value, Field) and key not in fields:
                        fields[key] = value

            # Add the definitions to any `Reference` fields that we're including.

# Generated at 2022-06-22 06:11:04.230518
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference.__init__.__annotations__ == {
        'to': typing.Union[str, typing.Type[Schema]],
        'definitions': typing.Mapping,
        'kwargs': typing.Dict[str, typing.Any],
        'return': None
    }

# Generated at 2022-06-22 06:11:06.978290
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class A(Schema):
        a = String()

    value = A({'a':'12'})

    assert list(value) == ['a']


# Generated at 2022-06-22 06:11:10.802643
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        field = Field()

    my_schema = MySchema()
    assert repr(my_schema) == 'MySchema(field=None)'



# Generated at 2022-06-22 06:11:20.675958
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.base import String, Integer
    
    class UserStruct(Schema):
        age = Integer(required=False)
        name = String(required=True)

    user = UserStruct(name="Foo")
    if isinstance(user, Mapping):
        assert list(user.keys()) == ['name']
        assert list(user.values()) == ['Foo']
        assert len(user) == 1
        assert ('age' in user) == False

    assert repr(user) == "UserStruct(name='Foo')"
    user.age = 32
    assert repr(user) == "UserStruct(name='Foo', age=32)"
    user.name = "Bar"
    assert repr(user) == "UserStruct(age=32, name='Bar')"



# Generated at 2022-06-22 06:11:34.810148
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def1 = 'd1'
    def2 = 'd2'
    sd = SchemaDefinitions(def1, def2)
    if (type(sd) != SchemaDefinitions) or (len(sd) != 2):
        return False
    for item in sd:
        print(item)
        if item not in [def1, def2]:
            return False
    return True



# Generated at 2022-06-22 06:11:40.227044
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestSchema(Schema):

        field_1 = "foo"
        field_2 = "bar"
        field_3 = "baz"

    test_schema = TestSchema()

    assert test_schema.field_1 == "foo"
    assert test_schema.field_2 == "bar"
    assert test_schema.field_3 == "baz"



# Generated at 2022-06-22 06:11:44.042172
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    class A(Schema):
        pass
    definitions['A'] = A()
    assert isinstance(definitions['A'], type)
    assert definitions['A'] == A


# Generated at 2022-06-22 06:11:57.453901
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    def test_SchemaMetaclass_obj(self):
        assert self._definitions == {}, "schema_definitions: class SchemaDefinitions has no attribute '_definitions'"
        args = [1, 2, 3]
        kwargs = {'a': 1}
        assert self._definitions == {}, "schema_definitions: class SchemaDefinitions has no attribute '_definitions'"
        self._definitions = dict(*args, **kwargs)  # type: dict
        assert self._definitions == {}, "schema_definitions: class SchemaDefinitions has no attribute '_definitions'"


# Generated at 2022-06-22 06:12:05.733645
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    liers = 'i am a lier'
    good_man = 'i am a good man'
    definitions = SchemaDefinitions()
    definitions[liers] = 'liers'
    definitions[good_man] = 'good man'
    assert len(definitions) == 2
    assert definitions[liers] == 'liers'
    assert definitions[good_man] == 'good man'
    del definitions[liers]
    assert len(definitions) == 1
    assert definitions[good_man] == 'good man'


# Generated at 2022-06-22 06:12:09.640665
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():

    # Setup
    sut = SchemaDefinitions() 
    key = 'key'
    sut._definitions[key] = 'value'

    # Test
    result = sut.__getitem__(key)

    # Verify
    assert result == 'value'


# Generated at 2022-06-22 06:12:12.975964
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class ExampleObject(object):
        def __getitem__(self, key):
            return key

    serialization = Reference(ExampleObject).serialize(ExampleObject())
    assert serialization == {"a": "a"}

# Generated at 2022-06-22 06:12:17.735783
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema1(Schema):
        id = str
        name = str
    test = TestSchema1({'id': '1', 'name': 'test'})
    fields = test.fields
    assert set(iter(test)) == set(fields.keys())

# Generated at 2022-06-22 06:12:20.979825
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Point1(Schema):
        x: int
        y: int
    p1 = Point1(1,2)
    assert list(p1.__iter__()) == ['x', 'y']


# Generated at 2022-06-22 06:12:24.916429
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    """Unit test for method __delitem__ of class SchemaDefinitions"""
    obj = SchemaDefinitions({'key': 'value'})
    assert isinstance(obj, SchemaDefinitions)
    assert isinstance(obj, MutableMapping)
    assert isinstance(obj, Mapping)
    obj.__delitem__('key')


# Generated at 2022-06-22 06:13:14.099986
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.compat import Iterator
    from typesystem.compat import Iterable
    from typesystem.compat import Sequence
    from typesystem.compat import List
    from typesystem.compat import Tuple
    from typesystem.compat import Set
    from typesystem.compat import Mapping
    from typesystem.compat import MutableMapping
    from typesystem.compat import Dict
    from typesystem.compat import MappingView
    from typesystem.compat import MutableMappingView
    from typesystem.compat import ItemsView
    from typesystem.compat import KeysView
    from typesystem.compat import ValuesView
    from typesystem.compat import MappingProxyType
    from typesystem.compat import SequenceProxyType
    from typesystem.compat import ListProxyType

# Generated at 2022-06-22 06:13:25.426911
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields.compound import Dict
    from typesystem.types import Boolean, Primitive

    class Person_target(Schema):
        id = Primitive()
        name = Primitive()

    class Person(Schema):
        target = Reference("Person_target")
        id = Primitive()
        name = Primitive()

    print("create a Person instance")
    test1 = Person(id="id_test", name="name_test")

    print("create a Person instance with the content of target")
    test2 = Person({"target": {"id": "id_test", "name": "name_test"}})

    print("create a Person_target instance")
    test3 = Person_target(id="id_test", name="name_test")

    print("create a Person instance with the content of target")
    test

# Generated at 2022-06-22 06:13:35.918317
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    import sys
    import types
    import unittest

    class SchemaDefinitionsTests(unittest.TestCase):
        """Test the SchemaDefinitions class."""

        # -- 1. Test: setattr of '_definitions'
        def test___setattr___1(self):
            """Test: setattr of '_definitions'"""
            obj = SchemaDefinitions()
            try:
                obj._definitions = "foo"
                self.fail()
            except AttributeError:
                pass

        # -- 2. Test: setattr of '_definitions'
        def test___setattr___2(self):
            """Test: setattr of '_definitions'"""
            obj = SchemaDefinitions()

# Generated at 2022-06-22 06:13:44.375346
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions({
        'JsonString': String(format='json'), 'JsonInteger': String(format='json')
    })
    # Assert fails due to assertion failure
    with pytest.raises(AssertionError) as e_info:
        definitions.__getitem__('JsonString')
        assert e_info.match('Definition for .* has already been set')


# Generated at 2022-06-22 06:13:55.643696
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Color(Schema):
        name = Reference(to="Name", required=True)
        value = Reference(to="Value", required=True)
        isPrimary = Reference(to="Boolean", required=False)

    class Name(Schema):
        code = Reference(to="Code", required=True)
        text = Reference(to="Text", required=True)

    class Code(Schema):
        value = Reference(to="Value", required=True)
        language = Reference(to="Language", required=True)

    class Value(Schema):
        value = Reference(to="Text", required=True)

    class Text(Schema):
        value = Reference(to="UTF8String", required=True)

    class Language(Schema):
        code = Reference(to="UTF8String", required=True)


# Generated at 2022-06-22 06:14:08.803902
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import json
    import os.path
    import typesystem

    # Example of the class 'Schema'.
    class Person(typesystem.Schema):
        id = typesystem.Integer()
        first_name = typesystem.String()
        last_name = typesystem.String()

    # Example of the class 'Person'.
    class Person():
        fields = {'id': Integer(), 'first_name': String(), 'last_name': String()}

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            if args:
                assert len(args) == 1
                assert not kwargs
                item = args[0]

# Generated at 2022-06-22 06:14:17.098068
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        myfield = Field(int)
        myotherfield = Field(int)

    ms1 = MySchema(myfield=1)
    # print(ms1.__repr__())
    assert ms1.__repr__() == "MySchema(myfield=1)"

    ms2 = MySchema(myotherfield=2)
    assert ms2.is_sparse == True
    assert ms2.__repr__() == "MySchema(myotherfield=2) [sparse]"


# Generated at 2022-06-22 06:14:21.491776
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Child(Schema):
        name = Field(str, max_length=10)

    class Parent(Schema):
        child = Reference("Child")

    parent = Parent.validate({"child": {"name": "testing"}})
    assert parent.child.name == "testing"


# Generated at 2022-06-22 06:14:32.806910
# Unit test for method validate of class Reference
def test_Reference_validate():
    print("Executing test_Reference_validate()...")
    T = TypeVar("T")
    T1 = TypeVar("T1", bound=Reference)

    class Reference_Mock(Reference[T]):
        def __init__(self, value):
            super().__init__(None, None, None)
            self.value = value

        def validate(self, value: T, *, strict: bool = False) -> T:
            return self.value

    reference_mock = Reference_Mock("valid_value")
    assert reference_mock.validate("valid_value") == "valid_value"

    class Test_Reference(Reference):
        def __init__(self) -> None:
            super().__init__(None, None)


# Generated at 2022-06-22 06:14:39.021692
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    v1=Schema({"a":1,"b":2,"c":3})
    v2=Schema()
    v3=Schema({"a":1,"b":2,"c":3,"d":4})
    assert v1["a"]==1
    with pytest.raises(KeyError):
        assert v2["a"]==1
    with pytest.raises(KeyError):
        assert v3["d"]==3


# Generated at 2022-06-22 06:15:38.158078
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # test for when entry is present in definitions
    definitions = SchemaDefinitions({"cat": "dog"})
    assert next(iter(definitions)) == "cat"

    # test for when entry is not present in definitions
    definitions = SchemaDefinitions()
    try:
        next(iter(definitions))
        assert False
    except StopIteration:
        assert True



# Generated at 2022-06-22 06:15:41.178916
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    print('Testing method __delitem__')
    schema_definitions = SchemaDefinitions()
    schema_definitions.__delitem__('test_string')
    print('Passed!')


# Generated at 2022-06-22 06:15:47.991561
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.schema import Schema
    from typesystem.fields import String, Integer
    class Ref(Schema):
        name = String()
        age = Integer()
    class TestRef(Schema):
        ref = Reference(Ref)
    ref = {'name': 'Jim', 'age': 15}
    result = TestRef.validate({"ref": ref})
    assert ref == result["ref"]


# Generated at 2022-06-22 06:15:52.680682
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    obj = SchemaDefinitions()
    pass


# Generated at 2022-06-22 06:16:00.401888
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    print("test_SchemaDefinitions___iter__")
    #
    print("1")
    definitions = SchemaDefinitions()
    definitions["a"] = 1
    definitions["b"] = 2
    assert list(definitions) == ["a", "b"]
    #
    print("2")
    definitions = SchemaDefinitions(dict(a=1, b=2))
    assert list(definitions) == ["a", "b"]
    #
    print("3")
    definitions = SchemaDefinitions(a=1, b=2)
    assert list(definitions) == ["a", "b"]



# Generated at 2022-06-22 06:16:08.094893
# Unit test for function set_definitions
def test_set_definitions():
    dfs = SchemaDefinitions()
    set_definitions(Field(name="foo", required=True), dfs)
    assert "foo" in dfs
    set_definitions(Object(properties=dict(foo=Field.string(name="foo"))), dfs)
    assert "foo" in dfs
    set_definitions(Array(Array(name="foo", items=Field.string())), dfs)
    assert "foo" in dfs
    set_definitions(
        Reference(name="foo", definitions=dfs, to=Field.string(name="foo"))
    )
    assert "foo" in dfs

# Generated at 2022-06-22 06:16:12.644964
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class MySchema(Schema):
        ...
    # Test 1: evaluate if structure of schemas is the same
    assert MySchema() == MySchema()

    # Test 2: evaluate if structure of schemas is different
    assert not MySchema() == object()


# Generated at 2022-06-22 06:16:13.383368
# Unit test for constructor of class Reference
def test_Reference():
    pass

# Generated at 2022-06-22 06:16:15.933396
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    SD = SchemaDefinitions()
    SD['test'] = 'test case'
    assert SD['test'] == 'test case'


# Generated at 2022-06-22 06:16:24.790387
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class FooSchema(Schema):
        x = Field(int)

    class BarSchema(Schema):
        y = Field(str)

    class BazSchema(Schema):
        foo = Reference(FooSchema)
        bar = Reference(BarSchema)

    obj = BazSchema(foo=FooSchema(x=1))
    assert dict(obj) == {'foo': {'x': 1}}

    obj = BazSchema(bar=BarSchema(y='abc'))
    assert dict(obj) == {'bar': {'y': 'abc'}}

    obj = BazSchema(foo=FooSchema(x=1), bar=BarSchema(y='abc'))

# Generated at 2022-06-22 06:17:19.631091
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    class Person(Schema):
        name = String(max_length=100, required=True)
        age = String(max_length=100, required=True)
        address = String(max_length=100, required=True)

    person = Person({'name': 'Pascal', 'age': '35', 'address': 'Erfurt'})
    assert len(person) == 3
    result = dict(person)
    assert result == {'age': '35', 'name': 'Pascal', 'address': 'Erfurt'}
    # Should throw ValidationError if one of the required fields is missing

# Generated at 2022-06-22 06:17:20.706142
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    SchemaDefinitions()


# Generated at 2022-06-22 06:17:26.397139
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=50, required=True)
        email = String(format="email", required=True)
        age = Integer(minimum=0, maximum=140, required=False)

    person = Person({'name': 'John Smith', 'email': 'john@example.com', 'age': 35})

    assert person['name'] == "John Smith"
    assert person['email'] == "john@example.com"
    assert person['age'] == 35

# Generated at 2022-06-22 06:17:37.843301
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(metaclass=SchemaMetaclass):
        pass
    def raise_Exception() -> None:
        class A(metaclass=SchemaMetaclass):
            a = 1
    print(A == A)
    print(isinstance(A, Mapping))
    print(type(A) == type(A))
    a1 = A()
    print(isinstance(a1, Mapping))
    print(type(a1) == type(a1))
    print(a1 == a1)
    a2 = A()
    print(a2 == a2)
    print(a1 == a2)
    a3 = A({"a": 2})
    print(a3 == a3)
    print(a1 == a3)
    a4 = A(a=2)

# Generated at 2022-06-22 06:17:41.097585
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
  schema_definitions1 = SchemaDefinitions()
  schema_definitions1["key1"] = "value1"
  assert "key1" in schema_definitions1.__iter__()
