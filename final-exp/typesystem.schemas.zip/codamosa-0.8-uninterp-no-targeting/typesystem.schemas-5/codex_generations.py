

# Generated at 2022-06-22 06:08:32.618943
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.schema import Schema
    from typesystem.types import String


    class FooSchema(Schema):
        foo = String()

    foo = FooSchema(foo='bar')
    assert isinstance(foo, FooSchema)
    assert list(foo) == ['foo']
    foo.baz = 'quux'
    assert list(foo) == ['foo', 'baz']



# Generated at 2022-06-22 06:08:44.486764
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    from datetime import date
    from datetime import datetime
    from datetime import time
    from decimal import Decimal
    from typesystem import Any
    from typesystem import Boolean
    from typesystem import Date
    from typesystem import DateTime
    from typesystem import Float
    from typesystem import Integer
    from typesystem import Number
    from typesystem import String
    from typesystem import Time
    from typesystem import ValidationError
    from typesystem import object_
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Reference

    # Construct arguments.
    definitions = SchemaDefinitions()

    # Call function or method.
    assert len(definitions) == 0

    # Construct arguments.

# Generated at 2022-06-22 06:08:50.166251
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass
    # obj = Schema(name='', age=0)
    # obj[''] # KeyError: ''
    # obj['name'] # ''
    # obj['age'] # 0
    # obj[''] = 'value'
    # obj['name'] # 'value'
    # obj['age'] # 0


# Generated at 2022-06-22 06:08:55.629703
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # Create an instance of SchemaDefinitions
    definitions = SchemaDefinitions()
    # Create an instance of object
    test_schema = object()
    # Store result into definitions
    definitions["TestSchema"] = test_schema
    # Check if the result of __getitem__ is the same as test_schema
    assert definitions["TestSchema"] == test_schema


# Generated at 2022-06-22 06:08:58.276076
# Unit test for method validate of class Reference
def test_Reference_validate():
    assert Reference("Address").validate(None) is None
    Reference("Address").validate('{"street": "Foo","city": "Bar"}')


# Generated at 2022-06-22 06:08:59.873288
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    pass #TODO


# Generated at 2022-06-22 06:09:05.083395
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class User(Schema):
        first_name = Field(type=str)
        last_name = Field(type=str)
    user = User(first_name='John', last_name='Doe')
    expected = "User(first_name='John', last_name='Doe')"
    assert str(user) == expected



# Generated at 2022-06-22 06:09:09.242338
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import copy
    import json
    import random
    import string
    class A(Schema):
        x = Field()
        y = Field()
    a = A({'x': 'x', 'y': 'y'})
    print(a)
    print([k for k in a])


# Generated at 2022-06-22 06:09:19.677117
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class S(Schema):
        a = 1
        b = 2
        c = 3
        d = 4

    class S2(S):
        a = 1
        b = 2
        c = 3
        d = 4

    assert repr(S()) == "S(a=1, b=2, c=3, d=4)"
    assert repr(S2()) == "S2(a=1, b=2, c=3, d=4)"
    assert repr(S(a=5)) == "S(a=5)"
    assert repr(S2(a=5)) == "S2(a=5)"
    assert repr(S(b=6)) == "S(a=1, b=6)"
    assert repr(S2(b=6)) == "S2(a=1, b=6)"

# Generated at 2022-06-22 06:09:25.282007
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()

    instance1 = TestSchema(field1=1)
    instance2 = TestSchema(field1=1)
    instance3 = TestSchema(field1=2)
    assert instance1 == instance2
    assert instance1 != instance3



# Generated at 2022-06-22 06:09:39.180686
# Unit test for method validate of class Reference
def test_Reference_validate():
    field=Reference(name='test')
    assert field.validate(not None, strict=False) is not None

# Generated at 2022-06-22 06:09:48.706078
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Arrange
    def_1 = SchemaDefinitions()
    def_2 = SchemaDefinitions()
    def_1["s1"] = "s1"
    def_1["s2"] = "s2"
    def_1["s3"] = "s3"
    def_2["s4"] = "s4"
    def_2["s5"] = "s5"
    def_2["s6"] = "s6"
    # Act
    del def_1["s1"]
    del def_2["s6"]
    # Assert
    assert len(def_1) == 2
    assert len(def_2) == 2
test_SchemaDefinitions___delitem__()


# Generated at 2022-06-22 06:09:50.944073
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String, Integer
    class Person(Schema):
        name = String()
        age = Integer()
    
    p = Person(name="abc",age=1)
    for i in p:
        print(i)
    assert 1 == 1


# Generated at 2022-06-22 06:09:55.160135
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    dic = {}
    x = SchemaDefinitions(*dic)
    assert len(x)  == 0
    dic = {'nsd_id': nsdfile}
    x = SchemaDefinitions(*dic)
    assert len(x) == 1



# Generated at 2022-06-22 06:09:59.223442
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    d = SchemaDefinitions(a=10)
    assert [i for i in d] == ['a']


# Generated at 2022-06-22 06:10:03.140607
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Setup
    self=SchemaDefinitions()
    key = "key"
    value = "value"

    # Exercise
    self.__setitem__(key, value)

    # Verify
    assert self._definitions[key] == value


# Generated at 2022-06-22 06:10:12.543270
# Unit test for method validate of class Reference
def test_Reference_validate():
    class A(Schema):
        name = Field(type=str)

    class B(Schema):
        a = Reference(to="A")
        b = Field(type=str)

    c = B.validate({"a": {"name": "a_name"}, "b": "b"})
    assert c == {"a": {"name": "a_name"}, "b": "b"}

    c = B.validate({"a": {"name": "a_name"}})
    assert c == {"a": {"name": "a_name"}}


# Generated at 2022-06-22 06:10:14.058442
# Unit test for constructor of class Reference
def test_Reference():
    assert(Reference.__init__('to'))

# Generated at 2022-06-22 06:10:17.697228
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class User(Schema):
        name = String()

    assert User.fields == {'name': String()}


# Generated at 2022-06-22 06:10:21.469287
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    obj = SchemaDefinitions()
    key = 'a'
    obj.__delitem__(key)
    assert key not in obj


# Generated at 2022-06-22 06:11:03.488908
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class A(Schema):
        field1 = Object({})
        field2 = Object({'a':1})
        field3 = Reference('A')
        field4 = Reference('A', definitions={'A': A})

    a = A({'field1':{'field1_1':1}})
    print(a.__getitem__('field1'))
    print(a['field2'])
    print(a['field1']['field1_1'])


# Generated at 2022-06-22 06:11:06.593749
# Unit test for constructor of class Schema
def test_Schema():
    a = Schema(name='Keyan')
    print(a)

test_Schema()

# Generated at 2022-06-22 06:11:18.277847
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # type: () -> None
    """Unit test for method __iter__ of class Schema."""
    from typesystem import String
    class ExampleSchema(Schema):
        example = String()
    import pytest
    @pytest.fixture
    def test_schema():
        return ExampleSchema()
    @pytest.fixture
    def test_schema_populated(test_schema):
        test_schema.example = "Example"
        return test_schema
    def TestSchema___iter__(test_schema, expected_schema_keys):
        # type: (ExampleSchema, typing.Sequence[typing.Any]) -> None
        '''Unit test for method __iter__ of class ExampleSchema.'''
        # Test valid use cases.

# Generated at 2022-06-22 06:11:26.218285
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class U(Schema):
        a = Field(integer=True)
        b = Field(integer=True)

    class V(U):
        c = Field(integer=True)
        d = Field(integer=True)

        def get_c(self):
            return self.c

    class W(Schema):
        pass

    u1 = U(a=1, b=2)
    u2 = U(b=2, a=1)
    u3 = U(a=1, b=2, c=3)
    v1 = V(a=1, b=2, c=3)
    v2 = V(a=1, b=2)
    v3 = V(a=1)
    w1 = W()
    w2 = W()
    
    assert u1 == u2


# Generated at 2022-06-22 06:11:29.148122
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    defn = SchemaDefinitions(a=1, b=2)
    assert len(defn) == 2
    assert defn["a"] == 1
    assert defn["b"] == 2

# Generated at 2022-06-22 06:11:31.289546
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference("String")
    assert r.to == 'String'
    assert r._target_string == 'String'
    assert r.definitions == None
    assert r.target == 'String'

# Generated at 2022-06-22 06:11:34.078781
# Unit test for method validate of class Reference
def test_Reference_validate():
    student = Reference(to='Student', required=True)
    student_obj = student.validate({'first_name':'Sam', 'last_name':'Iliff'})
    assert student_obj.first_name == 'Sam'
    assert student_obj.last_name == 'Iliff'


# Generated at 2022-06-22 06:11:40.460557
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    definitions["test"] = "test"
    for field in [
        Reference(
            "test",
            nullable=True,
            definitions=definitions
        ),
        Array(
            String()
        ),
        Object(
            String()
        ),
        String(),
        Array(
            Reference(
                "test",
                definitions=definitions
            )
        ),
    ]:
        set_definitions(field, definitions)

# Generated at 2022-06-22 06:11:50.701161
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    inner_schema = {
        "foo": Reference(to="Bar"),
    }
    outer_schema = {
        "baz": Array(items=Reference(to="Bar")),
        "qux": Object(properties=inner_schema),
    }
    set_definitions(Object(properties=outer_schema), definitions)
    assert isinstance(outer_schema["baz"], Array)
    assert isinstance(outer_schema["baz"].items, Reference)
    assert outer_schema["baz"].items.definitions == definitions
    assert isinstance(outer_schema["qux"], Object)
    assert isinstance(outer_schema["qux"].properties["foo"], Reference)

# Generated at 2022-06-22 06:11:58.037185
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test schema without defined fields
    schema = Schema()
    assert schema.is_sparse

    class TestSchema(Schema):
        a = Field()
        b = Field(attribute="bb", default="B default")
        c = Field()

    schema = TestSchema(a="a value", b="b value", c="c value")
    assert schema["a"] == "a value"
    assert schema["b"] == "b value"
    assert schema["c"] == "c value"

    try:
        schema["d"]
    except KeyError:
        pass
    else:
        assert False, "KeyError expected"


# Generated at 2022-06-22 06:12:38.177068
# Unit test for method __new__ of class SchemaMetaclass

# Generated at 2022-06-22 06:12:46.193818
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    res = SchemaDefinitions()
    assert isinstance(res, typing.MutableMapping) and isinstance(res, object) # type: ignore
    assert len(res) == 0
    assert isinstance(res, typing.MutableMapping) and isinstance(res, object) # type: ignore
    assert len(res) == 0
    assert isinstance(res, typing.MutableMapping) and isinstance(res, object) # type: ignore
    assert len(res) == 0
    assert isinstance(res, typing.MutableMapping) and isinstance(res, object) # type: ignore
    assert len(res) == 0


# Generated at 2022-06-22 06:12:47.215333
# Unit test for method validate of class Reference
def test_Reference_validate():
    pass


# Generated at 2022-06-22 06:12:57.298882
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Test empty definitions
    definitions = SchemaDefinitions()
    test_key = 'key'
    try:
        # Test missing key error
        del(definitions[test_key])
        result = False
    except KeyError:
        result = True
    assert result

    # Test missing key error
    test_value = 'value'
    definitions[test_key] = test_value
    assert definitions[test_key] == test_value
    del(definitions[test_key])
    try:
        # Test missing key error
        del(definitions[test_key])
        result = False
    except KeyError:
        result = True
    assert result

    # Test repeated definition error
    definitions[test_key] = test_value

# Generated at 2022-06-22 06:13:09.208684
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.primitives import Integer, String

    class Foo(Schema):
        one = Integer()
        two = Integer()
        three = Integer()

    assert len(Foo(one=1, two=2)) == 2
    assert len(Foo(one=1, two=2, three=3)) == 3
    assert len(Foo()) == 0

    class Bar(Schema):
        one = Integer(default=1)
        two = Integer(default=2)
        three = Integer()

    assert len(Bar()) == 2
    assert len(Bar(three=3)) == 3

    class Baz(Schema):
        name = String()

    assert len(Baz()) == 0
    assert len(Baz(name="Hello")) == 1



# Generated at 2022-06-22 06:13:12.043474
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    test_to = Schema # type: ignore
    definitions['test'] = test_to
    target = definitions['test']
    assert target == test_to


# Generated at 2022-06-22 06:13:15.301709
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert (
        Reference(to="schemaname").serialize(dict(key="value")) == dict(key="value")
    ), "Error in serialize() of Reference class"
    print("test_Reference_serialize() passed")



# Generated at 2022-06-22 06:13:17.360528
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # TODO: test that __len__ is working properly
    assert True


# Generated at 2022-06-22 06:13:23.623130
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Set up test data
    target = Mock()
    target.validate = Mock(return_value = 'blah')
    definitions = {'test_def': target}
    ref = Reference('test_def', definitions = definitions)

    # Test
    result = ref.validate('test')

    # Verify
    target.validate.assert_called_once_with('test')
    assert result == 'blah'


# Generated at 2022-06-22 06:13:28.112599
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class User(Schema):
        username = Field(type=str)

    class Author(Reference):
        to = "User"

    author = Author(username="george")
    assert author.serialize(author) == {"username": "george"}
    assert  author.serialize(None) == None

# Generated at 2022-06-22 06:14:09.149940
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    a = Schema()
    assert [] == list(a)


# Generated at 2022-06-22 06:14:11.459110
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Movie(Schema):
        name = Field()

    assert Movie.fields == {"name": Field()}


# Generated at 2022-06-22 06:14:15.041921
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Foo(Schema):
        a = Field()
    f = Foo(a=0)
    assert Reference(Foo).serialize(f) == {'a': 0}

# Generated at 2022-06-22 06:14:22.570594
# Unit test for constructor of class Reference
def test_Reference():
  # Test when string reference is given (to='').
  # This test doesn't cover the if condition.
  class TestSchema(Schema):
    x = Reference(to='')
  assert TestSchema.fields['x'].to == ''

  # Test when Reference object is given (to = Reference).
  # This test doesn't cover the else condition.
  class TestSchema1(Schema):
    x = Reference(to=Reference)
  assert TestSchema1.fields['x'].to == Reference


# Generated at 2022-06-22 06:14:26.267506
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    schema_definitions = SchemaDefinitions()
    schema_definitions.__setitem__('abc', 'd')
    assert list(schema_definitions.__iter__()) == ['abc']


# Generated at 2022-06-22 06:14:31.657401
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    for _ in range(100):
        definitions = SchemaDefinitions()
        for key in list(range(random.randint(0, 100))):
            value = random.randint(0, 100)
            definitions[key] = value
        for index, key in enumerate(definitions):
            assert key == index
            assert definitions[index] == index


# Generated at 2022-06-22 06:14:35.012430
# Unit test for constructor of class Reference
def test_Reference():
    definitions = {'X':1}
    obj = Reference('Y', definitions = definitions)
    assert obj.to == 'Y'
    assert obj.definitions == definitions
    assert obj.target_string == 'Y'
    assert obj._target == 1


# Generated at 2022-06-22 06:14:40.538672
# Unit test for method validate of class Reference
def test_Reference_validate():
    value = {'name': '1', 'age': 3}
    schema = Schema(
        name = String(),
        age = Integer()
    )

    reference = Reference(schema)
    validate = reference.validate(value)
    print(validate)

if __name__ == "__main__":
    test_Reference_validate()

# Generated at 2022-06-22 06:14:41.211137
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    SchemaDefinitions()

# Generated at 2022-06-22 06:14:48.486127
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
  class S1(Schema):
      foo = String()

  class S2(Schema):
      foo = String()
      bar = Boolean()

  # Equal
  assert S1(foo="bar") == S1(foo="bar")
  # Not equal
  assert S1(foo="bar") != S2(foo="bar")
  assert S1(foo="bar") != S1(foo="baz")
  # None is not equal
  assert S1(foo="bar") is not None



# Generated at 2022-06-22 06:15:50.002330
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Check that the method raises an error when an entry is deleted from an empty SchemaDefinitions object
    definitions = SchemaDefinitions()
    with pytest.raises(KeyError):
        definitions.__delitem__('test1')


# Generated at 2022-06-22 06:15:51.840565
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    assert len(SchemaDefinitions()) == 0
    assert len(SchemaDefinitions({"a": 1})) == 1


# Generated at 2022-06-22 06:15:57.711089
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        id = Field(type="integer")
        name = Field(type="string")

    # Example of a Reference that has type as a str.
    class Developer(Schema):
        person = Reference(to="Person")

    # Example of a Reference that has type as a Class.
    class PersonSchema(Schema):
        employeer = Reference(to=Person.__class__)

    person = Person(id=1, name="John")
    developer = Developer(person=person)
    person_schema = PersonSchema(employeer=person)

    assert developer.person == person
    # Testing if Reference serialize works with a string name of the class.
    assert developer.person == developer.serialized()["person"]

    assert person_schema.employeer == person
    # Testing if Reference serialize works

# Generated at 2022-06-22 06:16:08.962435
# Unit test for constructor of class Reference
def test_Reference():
    test_definitions = schemaDefinitions()
    test_schema = schema()
    test_to = 'test string'
    test_kwargs = {}
    test_field = Reference(test_to, test_definitions, **test_kwargs)
    assert test_field.to == test_to
    assert test_field.definitions == test_definitions
    test_kwargs['test_key'] = 'test_value'
    test_field = Reference(test_to, test_definitions, **test_kwargs)
    assert test_field.to == test_to
    assert test_field.definitions == test_definitions
    assert test_field.test_key == 'test_value'
    
    assert test_field.target_string == test_to
    assert test_field.target == test_field.definitions

# Generated at 2022-06-22 06:16:13.572909
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
      name = String()
      age = Integer()
    p1 = Person(name='Kim', age=31)
    p2 = Person(name='Kim', age=31)
    assert p1 == p2
    p3 = Person(name='Kim', age=32)
    assert p1 != p3

# Generated at 2022-06-22 06:16:18.208928
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class SimpleDict(Schema):
        a = Field()
        b = Field()
        c = "xx"
    simple_dict = SimpleDict(a=1, b=2)
    assert simple_dict["a"] == 1
    assert simple_dict["b"] == 2
    assert simple_dict["c"] == "xx"

# Generated at 2022-06-22 06:16:25.188749
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from .fixtures import (
        FooSchema,
        FooSchemaWithOptionalProperty,
        FooSchemaWithOptionalProperty2,
    )
    foo = FooSchema()
    expected_result = ['id', 'foo', 'bar']
    if (list(foo) == expected_result):
        print('Unit Test \'test_Schema___iter__\' passed!')
    else:
        print('Unit Test \'test_Schema___iter__\' failed.')


# Generated at 2022-06-22 06:16:27.688286
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    pass


# Generated at 2022-06-22 06:16:33.895882
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class ExampleSchema(Schema):
        a = Field()
        b = Field()
    schema_1 = ExampleSchema(a=1, b=2)
    schema_2 = ExampleSchema(a=1, b=2)
    schema_3 = ExampleSchema(a=1, b=4)
    assert schema_1 == schema_2
    assert not (schema_1 == schema_3)

# Generated at 2022-06-22 06:16:45.440875
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import sys
    import datetime

    from unittest.mock import patch

    from typesystem import String, Integer, Boolean, Date, DateTime, Object

    from .utils import get_test_schema

    #  Test normal operation
    class Test(get_test_schema("Test")):
        a = String()
        b = Integer()
        c = Boolean()
        d = Date()
        e = DateTime()

    item = Test()
    item.a = "a"
    item.b = 2
    item.c = True
    item.d = datetime.date(2017, 7, 22)
    item.e = datetime.datetime(2017, 7, 22, 5, 10, 15)
    items = list(item)