

# Generated at 2022-06-22 06:08:20.754871
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["A"] = {"a": "A"}

    assert definitions["A"] == {"a": "A"}

    definitions["B"] = {"b": "B"}

    assert definitions["B"] == {"b": "B"}

    try:
        definitions["C"] = {"c": "C"}
        assert False, "expect ValueError on redefinition"
    except ValueError:
        pass


# Generated at 2022-06-22 06:08:26.217054
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Initialization
    a = SchemaDefinitions()
    # Test
    a._definitions = {}
    b = a.__iter__()
    c = a.__iter__()
    # Assertion
    assert type(b) == type(c)
    assert b != c


# Generated at 2022-06-22 06:08:35.111842
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    # Only run this test when the class being tested is SchemaMetaclass.
    if SchemaMetaclass.__name__ != 'SchemaMetaclass':
        return
    # Test initialization of definitions and fields
    definitions = SchemaDefinitions()
    class User(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        username = String(max_length=100)
        password = String(max_length=100)
    class Project(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        name = String(max_length=100)
        owner = Reference(User)
    assert len(definitions) == 2, 'expected length for definitions is 2'
    assert len(User.fields) == 2, 'expected length for User.fields is 2'
    assert len(Project.fields)

# Generated at 2022-06-22 06:08:43.509810
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    a = {"name":"Rajesh","fname":"Kumar","sex":"Male","age":30,"city":"Bengaluru","height":5.6,"dob":date(1989,10,13), "married":True, "children":None}
    b = {"name":"Rajesh","fname":"Kumar","sex":"Male","age":30,"city":"Bengaluru","height":5.6,"dob":date(1989,10,13), "married":True, "children":None}
    assert  a == b


test_Schema___eq__()

# Generated at 2022-06-22 06:08:47.327048
# Unit test for function set_definitions
def test_set_definitions():
    class TestCase(Schema):
        field = Reference("TestCase")
    definitions = SchemaDefinitions({
        "TestCase": TestCase,
    })
    set_definitions(TestCase.field, definitions)
    assert TestCase.field.target is TestCase
    assert TestCase.field.target_string == "TestCase"

# Generated at 2022-06-22 06:08:49.174455
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["test"] = 1
    assert definitions["test"] == 1
    assert definitions._definitions["test"] == 1


# Generated at 2022-06-22 06:08:53.565493
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.schema import Schema

    class FooSchema(Schema):
        a = StringField(max_length=10)
        b = StringField(max_length=10)


    foo = FooSchema(a=None, b=None)
    foo



# Generated at 2022-06-22 06:08:56.945728
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    _args = ()
    _kwargs = {}
    schema = SchemaDefinitions(*_args, **_kwargs)
    key = str()
    value = object()
    expected_value = value

    # Act
    schema[key] = value

    # Assert
    assert schema[key] == expected_value

# Generated at 2022-06-22 06:08:57.732555
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert True


# Generated at 2022-06-22 06:08:59.804329
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema({'items': [0, 1, 2]})
    assert len(schema) == 1
    assert list(schema) == ['items']


# Generated at 2022-06-22 06:09:11.014924
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass

# Generated at 2022-06-22 06:09:20.610662
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions(mock_1 = 'mock_1')
    assert s['mock_1'] == 'mock_1'
    s['mock_2'] = 'mock_2'
    assert s['mock_2'] == 'mock_2'
    s.__setitem__('mock_3', 'mock_3')
    assert s['mock_3'] == 'mock_3'
    # test the case of duplicate definition
    s['mock_1'] = 'mock_1'
    assert s['mock_1'] == 'mock_1'
    s.__delitem__('mock_1')
    assert 'mock_1' not in s


# Generated at 2022-06-22 06:09:27.919381
# Unit test for constructor of class Schema
def test_Schema():
    class Coordinates(Schema):
        latitude = Float()
        longitude = Float()
    coordinates = Coordinates(latitude=32.564, longitude=15.964)
    print(coordinates)
    print("Checking validate")
    try:
        coordinates = Coordinates(a=32.564, longitude=15.964)
    except TypeError as e:
        print("Passed")
    else:
        print("Failed")
    print("Checking validate_or_error")
    try:
        coordinates, error = Coordinates.validate_or_error(a=32.564, longitude=15.964)
    except TypeError as e:
        print("Failed")
    else:
        print("Passed")

test_Schema()

# Generated at 2022-06-22 06:09:32.638381
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    from typesystem.base import Field, Object

    def check():
        d = SchemaDefinitions()
        d['equals'] = Object()
        try:
            d['equals'] = Object()
            return False
        except Exception:
            return True
    assert check()


# Generated at 2022-06-22 06:09:36.768625
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class MySchema(Schema, metaclass=SchemaMetaclass):
        name = String(max_length=10)
        age = Integer()

    assert isinstance(MySchema.name, Field)
    assert isinstance(MySchema.name, Field)
    assert MySchema.name == String(max_length=10)
    assert MySchema.age == Integer()
    assert MySchema.fields == {'name': String(max_length=10), 'age': Integer()}



# Generated at 2022-06-22 06:09:38.906172
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    assert len(schema_definitions) == 0

    schema_definitions["key1"] = "value1"
    assert len(schema_definitions) == 1

    schema_definitions["key2"] = "value2"
    assert len(schema_definitions) == 2


# Generated at 2022-06-22 06:09:41.379420
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    my_schema = Schema()
    # Line 28
    assert my_schema.__len__() == 0

# Generated at 2022-06-22 06:09:49.481317
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # we need to create a new subclass for each test
    # so that the __repr__ function doesn't change
    class TestSchema(Schema):
        field1 = str
        field2 = int


    obj = TestSchema()

    assert repr(obj) == "TestSchema()"

    obj = TestSchema(field1="hello")

    assert repr(obj) == "TestSchema(field1='hello')"

    obj = TestSchema(field1="hello", field2=42)

    assert repr(obj) == "TestSchema(field1='hello', field2=42)"

test_Schema___repr__()


# Generated at 2022-06-22 06:09:50.913428
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    test_definitions = SchemaDefinitions()
    test_definitions['test_key'] = 'test_value'
    assert test_definitions._definitions['test_key'] == 'test_value'


# Generated at 2022-06-22 06:09:54.374895
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert getattr(Schema(), '__iter__')() == iter([])
    assert getattr(Schema(), '__iter__')() != iter(["a", "b"])


# Generated at 2022-06-22 06:10:06.569976
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    print(s)
    assert len(s) == 0

# Generated at 2022-06-22 06:10:10.716927
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    try:
        SchemaDefinitions.__setitem__({"a": 1}, "a", 2)
        raise AssertionError("Expected exception TypeError")
    except TypeError:
        pass


# Generated at 2022-06-22 06:10:22.572290
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        name = String(max_length=10)

    definitions = {
        "User": User,
    }
    user1 = {"name": "charlie"}
    user2 = User(user1)
    ref1 = Reference("User", definitions)
    ref2 = ref1.validate(user1)
    assert ref2 == user2
    ref3 = ref1.validate(user2)
    assert ref3 == user2
    ref4 = Reference("User", definitions, allow_null=True)
    ref5 = ref4.validate(None)
    assert ref5 is None
    try:
        Reference("User", definitions).validate(None)
    except ValidationError:
        pass
    else:
        assert False


# Generated at 2022-06-22 06:10:25.927939
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    first_schema = Schema(definitions)
    assert first_schema in definitions.values()
    class SecondSchema(Schema):
        pass
    assert SecondSchema in definitions.values()

# Generated at 2022-06-22 06:10:35.606809
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class BaseSchema(Schema):
        base_field = String()

        def __init__(self):
            super().__init__()

    class SchemaA(Schema):
        from tests.fields import String, Integer, Number
        string1 = String()
        string2 = String()
        integer = Integer()
        number = Number()

        def __init__(self):
            super().__init__()

    class SchemaB(Schema):
        from tests.fields import String, Integer
        string = String(required=True)
        integer = Integer(required=True)

        def __init__(self):
            super().__init__()

    class SchemaC(SchemaA, BaseSchema):
        from tests.fields import String, Integer
        string3 = String()
        string4 = String()


# Generated at 2022-06-22 06:10:39.763215
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Integer()

    class B(A):
        b = Integer()

    schema_dict = B.__dict__

    assert schema_dict["fields"]["a"] == Integer()
    assert schema_dict["fields"]["b"] == Integer()

# Generated at 2022-06-22 06:10:48.695622
# Unit test for function set_definitions
def test_set_definitions():
    class MyField(Field):
        pass

    class Ref1(Reference):
        pass

    class Ref2(Reference):
        pass

    class MySchema(Schema):
        field1 = MyField()
        field2 = Array(items=Ref1(to="Ref2"))
        field3 = Array(items=[Ref1(to="Ref2"), Ref2(to="Ref1")])

        # Verify that MySchema can have Reference fields that have
        # a target string before it is defined, and that this definition
        # is added to the definition mapping.
        field4 = Ref1(to="Ref2")

    # Set a subset of the definitions.
    definitions = SchemaDefinitions({"Ref2": Ref2})
    set_definitions(MySchema.field2.items, definitions)

# Generated at 2022-06-22 06:10:59.779088
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem import Schema, Integer, Object
    from typesystem.fields import String

    class User(Schema):
        id = Integer()
        name = String()

    class Post(Schema):
        title = String(required=True)
        author = Reference(User)

    post = Post({'title': 'hello', 'author': User({'id': 1, 'name': 'xiaoming'})})
    print(post.author)
    print(post)
    print(type(post))
    print(type(post.title))
    print(type(post.author))
    print(type(post.author.id))
    print(type(post.author.name))
    print(post.author.serialize(post.author))



# class Post(Schema):
#     title = String(required=True)

# Generated at 2022-06-22 06:11:11.852643
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # we test only for __init__
    # def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
    # we test if we can create a new SchemaDefinitions
    # we have to run six tests
    # 1. if it is initialized with no parameters
    # 2. if it is initialized with several parameters
    # 3. if it is initialized with several parameters and kwargs
    # 4. if it is initialized with kwargs only
    # 5. if it is initialized with a list only
    # 6. if it is initialized with a list and kwargs
    test1 = SchemaDefinitions()
    assert isinstance(test1, SchemaDefinitions)
    test2 = SchemaDefinitions(1,2,3,4,5,6,7)

# Generated at 2022-06-22 06:11:15.064493
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Foo(Schema, metaclass=SchemaMetaclass):
        bar = Integer()
        baz = String()

    assert Foo.fields == {"bar": Integer(), "baz": String()}


# Generated at 2022-06-22 06:11:26.902703
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    x = SchemaDefinitions()
    try:
        x[""]
    except KeyError as e:
        return True
    assert False



# Generated at 2022-06-22 06:11:37.270283
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        name = Field(str, description="Name.")
        age = Field(int, description="Age.")

    class ReferenceSchema(Schema):
        person = Reference(Person)
        # usage:
        # data = ReferenceSchema.validate(
        #     {
        #         "name": "Jane Doe",
        #         "age": 17
        #     }
        # )
        # print(data.person)
        # print(data.person.serialize())
        # data.person.name = "Jane Doe"
        # print(data.person)
        # data.person.name = "John Doe"
        # print(data.person)

    assert type(ReferenceSchema().person) is Person
    assert type(Person().serialize()) is dict

# Generated at 2022-06-22 06:11:43.290276
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    x = SchemaDefinitions(a=0, b=1, c=2)
    x.__delitem__('a')
    with raises(KeyError): x.__getitem__('a')
    assert x.__getitem__('c') == 2
    assert x.__getitem__('b') == 1



# Generated at 2022-06-22 06:11:51.990892
# Unit test for method __len__ of class Schema
def test_Schema___len__():

    class TestSchema(Schema):
        a = Integer(default=0)
        b = Integer()

    assert len(TestSchema()) == 1
    assert len(TestSchema(a=1)) == 2
    assert len(TestSchema(a=1, b=2)) == 2

# Generated at 2022-06-22 06:12:00.627946
# Unit test for constructor of class Reference
def test_Reference():
    ref_field = Reference(to="vegetable", definitions=None)
    assert ref_field.allow_null is True
    assert ref_field.required is False
    assert ref_field.to == "vegetable"
    assert ref_field.definitions == None
    assert ref_field.target_string == "vegetable"
    assert ref_field.target == "vegetable"
    assert ref_field.validate(None) == None

    ref_field = Reference(to="vegetable", definitions={"vegetable": "fruit"})
    assert ref_field.target == "fruit"

# Generated at 2022-06-22 06:12:08.484281
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Book(Schema):
        title = Field()
        authors = Array(Field())
    book = Book(title='Asimov Explores the Solar System', authors=['Asimov', 'McAuley'])
    assert book['title'] == 'Asimov Explores the Solar System'
    try:
        book['foo']
    except KeyError as e:
        assert e.args[0] == 'foo'
    try:
        book['authors']
    except KeyError as e:
        assert e.args[0] == 'authors'
    try:
        book['title', 'authors']
    except KeyError as e:
        assert e.args[0] == ('title', 'authors')


# Generated at 2022-06-22 06:12:11.617110
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    obj = Schema(foo = 1, bar = 2)
    serialized_as_dict = {'foo': 1, 'bar': 2}
    assert Reference.serialize(obj) == serialized_as_dict


# Generated at 2022-06-22 06:12:23.483226
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        id = Field()
        name = Field()
        age = Field()

    class Employee(Schema):
        id = Field()
        name = Field()
        age = Field()
        employee_type = Reference(Person)

    employee1 = Person(id=1, name="Bob", age=25)
    data = {
        "id": 1,
        "name": "Bob",
        "age": 25,
        "employee_type": employee1,
    }
    employee = Employee.validate(data)
    assert employee == Employee(
        id=1, name="Bob", age=25, employee_type=Person(id=1, name="Bob", age=25)
    )
    assert isinstance(employee, Employee)

# Generated at 2022-06-22 06:12:28.564355
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Foo(Schema):
        bar = Field(int)
    foo = Foo()

    assert set(foo.__iter__()) == set(['bar'])

    foo = Foo(bar=1)
    assert set(foo.__iter__()) == set(['bar'])
    assert len(foo) == 1


# Generated at 2022-06-22 06:12:33.072611
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    Object1 = Schema
    Object1.name = 'Object1'
    Object1.age = 'Object1.age'
    definitions = SchemaDefinitions()
    definitions['Object1'] = 1
    assert len(definitions) == 1

# Generated at 2022-06-22 06:12:52.260032
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    
    c=[]
    class B(Schema):
        ab = Reference("A", definitions=c)
    class A(Schema):
        a = Reference("B", definitions=c)
        b = Reference("B", definitions=c)
    c.append([("A", A),("B", B)])
    a = A()
    a.b = B()
    a.a = a.b
    a.b.ab = a
    assert a.b.ab.b.ab.a.b.ab.b.ab.a == a
    assert a.b.ab.b.ab.a.b.ab.b.ab.a.b == a.b
    assert a.b.ab.b.ab.a.b.ab.b.ab.a.b.ab == a.b.ab
   

# Generated at 2022-06-22 06:12:55.890533
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema = Schema(a = 3, b = 4, c = 5)
    assert repr(schema) == "Schema(a=3, b=4, c=5)"


# Generated at 2022-06-22 06:13:08.503547
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import datetime
    from typing import Any, Dict, Union


    # Test case 1
    obj_schema = Schema({"title": 1, "price": 2})
    assert obj_schema.__eq__({"title": 1, "price": 2})

    # Test case 2
    obj_schema = Schema({"title": 1, "price": 1})
    assert obj_schema.__eq__({"title": 1, "price": 1})

    # Test case 3
    obj_schema = Schema({"title": 1, "price": 2})
    assert obj_schema.__eq__({"title": 1, "price": 1})

    # Test case 4
    obj_schema = Schema({"title": 1, "price": 2})

# Generated at 2022-06-22 06:13:17.984353
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        foo = String(description="foo")
        bar = Integer(description="bar")

    assert Foo(foo="foo", bar=1) != Foo(foo="foo", bar=2)
    assert Foo(foo="foo", bar=1) != Foo(foo="foo")
    assert Foo(foo="foo", bar=1) != Foo(bar=1)
    assert Foo(foo="foo", bar=1) != Foo()
    assert Foo() != Foo(foo="foo")
    assert Foo() != Foo(bar=1)
    assert Foo(foo="foo", bar=1) == Foo(foo="foo", bar=1)
    assert Foo() == Foo()

    assert Foo.validate({"foo": "foo", "bar": 1}) == Foo(foo="foo", bar=1)
    assert Foo.valid

# Generated at 2022-06-22 06:13:21.493416
# Unit test for constructor of class Schema
def test_Schema():
    expected = SchemaDefinitions()
    assert isinstance(expected, MutableMapping)
    assert isinstance(expected, SchemaDefinitions)
    assert expected._definitions == {}


# Generated at 2022-06-22 06:13:24.047794
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference(to=3)
    assert ref.to == 3
    assert ref.allow_null == False
    assert ref.target == 3
    

# Generated at 2022-06-22 06:13:35.795975
# Unit test for function set_definitions
def test_set_definitions():
    class SubSub(Schema):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        d = Integer()

    class Sub(Schema):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        a = Reference(SubSub)
        b = Reference('SubSub')
        c = Reference('SubSub', definitions={'SubSub': SubSub})

    def test_definition(schema):
        # assert SubSub.get_validator() == schema
        assert SubSub.validate(schema) == SubSub(schema)

    test_definition(SubSub(d=1))
    test_definition(SubSub.validate({'d': 1}))

# Generated at 2022-06-22 06:13:36.870029
# Unit test for function set_definitions
def test_set_definitions():
    # TODO
    pass


# Generated at 2022-06-22 06:13:47.827968
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import pytest
    from typesystem.types import String
    fields = {"a": String(required=True), "b": String(required=False)}
    Schema1 = type("Schema1", (Schema,), fields)
    s1_1 = Schema1(a="a", b="b")
    s1_2 = Schema1(a="a", b="b")
    s1_3 = Schema1(a="a", b="c")
    s1_4 = Schema1(a="a")
    s2 = Schema(a="a", b="c")
    assert s1_1 == s1_1
    assert s1_1 == s1_2
    assert s1_1 != s1_3
    assert s1_1 != s1_4
    assert s1_1 != s

# Generated at 2022-06-22 06:13:56.747503
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Dog(Schema):
        name = String(allow_null=False)
        age = Integer(allow_null=False)
    class Person(Schema):
        name = String(allow_null=False)
        dog = Reference(to='Dog', allow_null=False)

    res = Person.validate({
        'name': 'Aiolos',
        'dog': {
            'name': 'Totoro',
            'age': 10
        }
    })
    assert res.name == 'Aiolos'
    assert res.dog.name == 'Totoro'
    assert res.dog.age == 10


# Generated at 2022-06-22 06:14:21.852438
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    field = Object(properties={"abc": Reference("abc")})
    set_definitions(field, definitions)
    assert field.properties["abc"].definitions == definitions



# Generated at 2022-06-22 06:14:29.964691
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    with pytest.raises(TypeError):
        assert Schema() == ''
    with pytest.raises(TypeError):
        assert Schema() == None
    with pytest.raises(TypeError):
        assert Schema('') == Schema()
    with pytest.raises(TypeError):
        assert Schema(None) == Schema()
    assert Schema() == Schema()
    assert Schema('') == Schema('')
    assert Schema(None) == Schema(None)


# Generated at 2022-06-22 06:14:40.715287
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    name_field = String(max_length=30)
    schema = Object(properties={"name": name_field}, additional_properties=False)
    class User(Schema):
        name = String(max_length=30)
    user1 = User(name="Foo")
    assert user1.serialize() == {"name": "Foo"}
    assert schema.serialize(user1) == {"name": "Foo"}

    class Post(Schema):
        user = Reference(User)
    post1 = Post(user=user1)
    assert post1.serialize() == {"user": {"name": "Foo"}}
    assert schema.serialize(post1) == {"user": {"name": "Foo"}}

# Generated at 2022-06-22 06:14:43.341656
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class BasicSchema(Schema):
        pass
    assert "fields" in dir(BasicSchema)
    assert BasicSchema.fields == {}


# Generated at 2022-06-22 06:14:55.337723
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        first_name = Field(text, required=True)
        last_name = Field(text, required=True)

    class Address(Schema):
        address = Field(text, required=True)
        city = Field(text, required=True)

    class User(Schema):
        person = Reference(to=Person)
        addresses = Array(Reference(to=Address), required=True)

    definitions = SchemaDefinitions()
    assert User.person.definitions is None
    assert User.addresses.items is not None
    assert User.addresses.items.definitions is None
    set_definitions(User, definitions)
    assert User.person.definitions is definitions
    assert User.addresses.items is not None
    assert User.addresses.items.definitions is definitions


# Unit

# Generated at 2022-06-22 06:14:56.356207
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass


# Generated at 2022-06-22 06:15:06.968095
# Unit test for constructor of class Schema
def test_Schema():
    class ChildSchema(Schema):
        m_name = String()
        m_age = Integer()
        m_interests = Array(String())

    class ParentSchema(Schema):
        m_name = String()
        m_age = Integer()
        m_children = Array(ChildSchema())

    m_data = {
        "m_name": "John",
        "m_age": 52,
        "m_children": [
            {"m_name": "Bob", "m_age": 16, "m_interests": ["Eating", "Playing"]},
            {"m_name": "Alice", "m_age": 15, "m_interests": ["Sleeping"]},
        ],
    }
    p = ParentSchema(m_data)

    assert m_data == dict(p)

# Generated at 2022-06-22 06:15:11.639540
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions['key'] = 'value'

# Generated at 2022-06-22 06:15:18.565200
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions(): 
    schemaDefinitions = SchemaDefinitions()
    schemaDefinitions['key1'] = 'value1'
    print(schemaDefinitions['key1'])
    print(len(schemaDefinitions))
    print(schemaDefinitions)
    schemaDefinitions['key1'] = 'value2'
    print(schemaDefinitions)
    del schemaDefinitions['key1']
    print(schemaDefinitions)


# Generated at 2022-06-22 06:15:22.629381
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Test(Schema):
        field = Reference(to="Test")
    te = Test(field=Test)
    func_return = Reference.serialize(te, obj={'field': {'field': {'field': {...}}}})
    assert obj == func_return

# Generated at 2022-06-22 06:15:40.005704
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    s["test"] = 1


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-22 06:15:41.802354
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(to='User').serialize({'name': 'User'}) == {'name': 'User'}



# Generated at 2022-06-22 06:15:44.448160
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Setup
    definitions = SchemaDefinitions()
    # Exercise
    definitions['key'] = 'value'
    # Verify
    assert definitions['key'] == 'value'



# Generated at 2022-06-22 06:15:45.599890
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    pass


# Generated at 2022-06-22 06:15:56.865251
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    
    #define test object
    test = SchemaDefinitions()
    test_len = len(test)
    print(test_len)
    
    test2 = SchemaDefinitions(None, None)
    test2_len = len(test2)
    print(test2_len)
    
    test3 = SchemaDefinitions(None, None, car = "ford", truck = "toyota")
    test3_len = len(test3)
    print(test3_len)
    
    test4 = SchemaDefinitions(None, None, car = "ford", truck = "toyota", airport = "JFK")
    test4_len = len(test4)
    print(test4_len)
    

# Generated at 2022-06-22 06:16:08.408662
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    jsonschema_definition = {
        'adapter': {'required': True, 'type': 'string'},
        'id': {'required': True, 'type': 'integer'},
        'name': {'required': True, 'type': 'string'}
    }

    # Test case 1
    s = SchemaDefinitions()
    s['definition'] = jsonschema_definition
    assert s['definition'] == jsonschema_definition

    # Test case 2
    s = SchemaDefinitions()
    try:
        s['definition'] = jsonschema_definition
        s['definition'] = jsonschema_definition
    except:
        pass
    else:
        assert False

    return


# Generated at 2022-06-22 06:16:18.686024
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class User(Schema):
        id = Field(type="integer")
        first_name = Field(type="string")
        last_name = Field(type="string")

    user = User(id=12, first_name="Jane", last_name="Doe")
    assert user["id"] == 12
    assert user["first_name"] == "Jane"
    assert user["last_name"] == "Doe"
    assert list(user) == ["id", "first_name", "last_name"]
    assert len(user) == 3
    with pytest.raises(KeyError):
        user["unknown"]


# Generated at 2022-06-22 06:16:28.458512
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # test case 1
    class TestSchemaMethod___repr___1(Schema):
        foo = Field(type_=str)

    obj = TestSchemaMethod___repr___1(foo="test")

# Generated at 2022-06-22 06:16:32.096770
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # __getitem__(self, key: typing.Any) -> typing.Any:
    # Set up
    definitions = SchemaDefinitions()

    # Assert
    assert definitions['value'] == 'value'



# Generated at 2022-06-22 06:16:35.558714
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    test = SchemaDefinitions({1: 1, 2: 2})
    expected = 2
    actual = len(test)
    assert expected == actual


# Generated at 2022-06-22 06:17:12.639060
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Integer

    class Person(Schema):
        age = Integer
    
    person = Person(age=18)
    
    assert person.__getitem__('age') == 18

# Generated at 2022-06-22 06:17:18.527234
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    S = Schema
    a1 = S(S.ANNOTATION_SECTIONS, S.DATA_SECTIONS, S.INCLUDE_SECTION)
    a2 = S(S.ANNOTATION_SECTIONS, S.DATA_SECTIONS, S.INCLUDE_SECTION)
    assert a1 == a2



# Generated at 2022-06-22 06:17:25.224428
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    def serialize(self: Reference, obj: typing.Any) -> typing.Any:
        if obj is None:
            return None
        return list(obj)
    Reference.serialize = serialize
    class TestRef(Schema):
        name = Reference("abc")
    class Test(Schema):
        n = TestRef()
    test = Test.validate({"name": ["a","b","c"]})
    if test:
        print("True")
    else:
        print("False")
test_Reference_serialize()

# Generated at 2022-06-22 06:17:28.462604
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    """
    Write a unit test for Schema.__repr__()
    """
   # raise NotImplementedError("Not implemented!")



# Generated at 2022-06-22 06:17:39.524317
# Unit test for method validate of class Reference
def test_Reference_validate():
    def test_Reference_validate_0():
        """Test validate_or_error of class Reference with allow_null=False"""
        rf = Reference('to', allow_null=False)
        result = rf.validate_or_error(None)
        assert result.is_error()
        assert result.value is None
        assert result.error.messages()[0].text == 'May not be null.'
        assert result.error.messages()[0].code == 'null'

    def test_Reference_validate_1():
        """Test validate_or_error of class Reference with allow_null=True"""
        rf = Reference('to', allow_null=True)
        result = rf.validate_or_error(None)
        assert result.is_valid()
        assert result.value is None

# Generated at 2022-06-22 06:17:48.702766
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class EmptySchema(Schema):
        pass

    # 1. EmptySchema has no fields
    schema = EmptySchema()
    assert len(schema) == 0 # test result 1

    # 2. EmptySchema has no non-null fields
    class EmptyNonNullSchema(Schema):
        name = String()
        age = Integer()

    schema = EmptyNonNullSchema()
    assert len(schema) == 0 # test result 2

    # 3. EmptySchema has some non-null fields
    schema = EmptyNonNullSchema(name = 'abc', age=20)
    assert len(schema) == 2 # test result 3

