

# Generated at 2022-06-22 06:08:30.677527
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Item(Schema):
        name = Field(type_=str)
        age = Field(type_=int)
    class Course(Schema):
        scores = Field(type_=[Item])
        age = Field(type_=int)
        id = Field(type_=str)
    ite = Item(name = "Paul", age = 18)
    cour = Course(scores = [ite], age = 18, id = "1")
    assert cour == Reference(Course).serialize(cour)
    
    

# Generated at 2022-06-22 06:08:38.305365
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import types, validators, errors

    class Person(Schema):
        name = types.String(validators=[validators.Length(min=2)])
        age = types.Integer(default=1)
        optional = types.Integer()

    person = Person(name="Bob")

    assert len(person) == 2


# Generated at 2022-06-22 06:08:43.281774
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer(minimum=0)

    person1 = Person(name='José', age=19)
    person2 = Person(name='José', age=19)
    person3 = Person(name='José', age=18)
    assert person1 == person2
    assert person1 != person3


# Generated at 2022-06-22 06:08:44.935495
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    x = SchemaDefinitions()
    assert len(x._definitions) == 0


# Generated at 2022-06-22 06:08:49.281333
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()

    p = Person(name='John', age=12)
    print(p)    # Person(name='John', age=12)

test_Schema___repr__()

# Generated at 2022-06-22 06:08:57.964933
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Prepare data
    definitions = SchemaDefinitions()
    cls1 = Schema.make_validator()
    cls2 = Schema.make_validator()
    definitions[cls1.__name__] = cls1
    definitions[cls2.__name__] = cls2
    expected = {cls1.__name__: cls1}

    # Unit test execution
    del definitions[cls2.__name__]

    # Post condition
    assert expected == definitions


# Generated at 2022-06-22 06:08:59.931504
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    assert issubclass(SchemaMetaclass, ABCMeta)


# Generated at 2022-06-22 06:09:05.134470
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer(minimum=18)
        address = String()

    person = Person(name='Jack', address='Beijing')
    assert person.is_sparse
    a = list(person)
    assert len(a) == 2
    assert a == ['name', 'address']


# Generated at 2022-06-22 06:09:13.256294
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import Integer, Schema
    from typing import Any, Callable
    # Definition of a model referenced as Student
    class Student(Schema):
        id: Integer
        name: str
    # The Schema where the model Student is used
    class Job(Schema):
        lead: Reference(Student) # type: ignore
        crew: Array(Reference(Student)) # type: ignore
    # Function used to validate the model Job
    validate: Callable[[Any], Any]
    validate = Job.make_validator()
    # Valid model Job
    valid_job = {
        "lead": {
            "id": 1,
            "name": "John Doe"
        },
        "crew": [
            {
                "id": 2,
                "name": "Jane Doe"
            }
        ]
    }
    #

# Generated at 2022-06-22 06:09:17.925106
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    S = Schema
    class Schema0(S):
        field0 = S.fields['field0'] = Field()
    assert len(Schema0()) == 0
    schema0 = Schema0()
    schema0.field0 = 3
    assert len(schema0) == 1


# Generated at 2022-06-22 06:09:33.784378
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Arrange
    schemaDefinitions = SchemaDefinitions()
    schemaDefinitions["key1"] = "value1"
    schemaDefinitions["key2"] = "value2"

    # Act
    iterObject = schemaDefinitions.__iter__()

    # Assert
    assert iterObject.__next__() == "key1"
    assert iterObject.__next__() == "key2"
    try:
        iterObject.__next__()
    except StopIteration as e:
        assert True
        return
    assert False


# Generated at 2022-06-22 06:09:37.925738
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class User(Schema):
        id = Integer()
        username = String()

    assert (User.fields) == {'id': Integer(), 'username': String()}
    assert (User.make_validator()) == Object(properties={'id': Integer(), 'username': String()}, required=['id', 'username'], additional_properties=None)
    assert (User('{}')) == User(id=None, username=None)
    assert (User(id=7, username='foo')) == User(id=7, username='foo')
    assert (User(**{'id': 7, 'username': 'foo'})) == User(id=7, username='foo')
    assert (User(**{'id': 7})) == User(id=7, username=None)



# Generated at 2022-06-22 06:09:43.332799
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Child(Schema):
        c_str = String()

    class Parent(Schema):
        p_str = String()
        c = Reference(Child)

    try:
        Parent(p_str="string", c=Child(c_str="string"))
    except Exception as e:
        assert False
    else:
        assert True



# Generated at 2022-06-22 06:09:49.549044
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # test the case of two objects being equal
    class FooSchema(Schema):
        foo = Field()
    obj1 = FooSchema(foo="bar")
    obj2 = FooSchema(foo="bar")
    assert obj1 == obj2

    # test the case of two objects not being equal
    assert not FooSchema(foo="bar") == FooSchema(foo="baz")
    assert not FooSchema(foo="bar") == FooSchema(bar="bar")
    assert not FooSchema(foo="bar") == FooSchema(foo="bar", bar="bar")


# Generated at 2022-06-22 06:09:50.824363
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    obj = SchemaDefinitions()
    print(list(obj.__iter__()))



# Generated at 2022-06-22 06:09:53.538636
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    """
    Tests the method __delitem__ of class SchemaDefinitions
    """
    # fail

    # pass


# Generated at 2022-06-22 06:09:58.557264
# Unit test for method validate of class Reference
def test_Reference_validate():
    class A(Schema):
        prop = String()
    
    reference = Reference(A)
    assert not reference.validate({'prop': 'str'}).is_sparse


# Generated at 2022-06-22 06:10:09.380116
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
	f = Field(name='f')
	class A(Schema):
		f1 = f
		f2 = f
		f3 = f
		f4 = f
		f5 = f
	a1 = A({'f1': 1, 'f2': 2, 'f3': 3, 'f4': 4, 'f5': 5})
	a2 = A({'f1': 1, 'f2': 2, 'f3': 3})
	a3 = A(f1=1, f2=2, f3=3)
	a4 = A(f1=1, f2=2, f3=3, f4=4, f5=5)
	a5 = A(f1=1, f2=2)

# Generated at 2022-06-22 06:10:18.229657
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # class A(Schema):
    #     a = Field(type='string')
    #     b = Field(type='string')
    #     c = Field(type='string')
    #     d = Field(type='string')
    #     e = Field(type='string')
    #     f = Field(type='string')
    # a = A()
    # assert len(a) == 0
    pass



# Generated at 2022-06-22 06:10:26.985686
# Unit test for method validate of class Reference
def test_Reference_validate():
  from typesystem.fields import Integer, String
  from typesystem.schemas import Schema, Reference
  class Person(Schema):
    name = String()
    age = Integer(default="1987")
  serialized_ref = Reference('Person')
  Person_ref = Reference(Person)
  Person_ref_deserialized = serialized_ref.validate({"age": "2018", "name": "Eleni"})

  assert(Person_ref == Person_ref_deserialized)
  assert(Person_ref.name, "Eleni")
  assert(Person_ref.age, 2018)

# Generated at 2022-06-22 06:10:42.932780
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.fields import String
    from typesystem.schema import Schema

    class Foo(Schema):
        name = String()

    foo_a = Foo(name='foo')
    foo_b = Foo(name='foo')
    assert foo_a == foo_b

    foo_c = Foo(name='bar')
    assert foo_a != foo_c


# Generated at 2022-06-22 06:10:45.842958
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    a = SchemaMetaclass.__new__(SchemaMetaclass, "Meta", (), {})
    assert type(a) == type


# Generated at 2022-06-22 06:10:52.782675
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class AuthorSchema(Schema):
        id = Field(type=int)
        name = Field(type=str)
    
    class SnapshotSchema(Schema):
        revision = Field(type=str)
        author = Reference(to=AuthorSchema)
        comment = Field(type=str)

    author = AuthorSchema(id=1, name="Emmanuel")
    snapshot = SnapshotSchema(revision="r1", author=author, comment="test")
    assert snapshot["author"] == dict(author)



# Generated at 2022-06-22 06:10:58.855180
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Pet(Schema):
        name = Field(str)
        species = Field(str, default="dog")

    assert "name" in Pet.fields
    assert "species" in Pet.fields
    assert Pet.fields["species"].has_default() is True
    pet = Pet(name="Fluffy", species="cat")
    assert pet["name"] == "Fluffy"
    assert pet["species"] == "cat"
    pet2 = Pet(name="Bob")
    assert pet2["name"] == "Bob"
    assert pet2["species"] == "dog"
    assert pet == pet2



# Generated at 2022-06-22 06:11:02.358839
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    test_data = [{"test_key": "test_value"}]
    obj = Schema(test_data)
    assert len(obj) == 1



# Generated at 2022-06-22 06:11:08.482061
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schemaDefinitions_ = SchemaDefinitions()
    schemaDefinitions_[1] = 1
    del schemaDefinitions_[1]
    assert 1 not in schemaDefinitions_


# Generated at 2022-06-22 06:11:14.486804
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions(dict1=1)
    assert len(definitions) == 1
    definitions["dict2"] = 2
    assert len(definitions) == 2
    del definitions["dict1"]
    assert len(definitions) == 1
    definitions["dict1"] = 1
    definitions["dict3"] = 3
    assert len(definitions) == 3

# Generated at 2022-06-22 06:11:17.106750
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema(required={'name': 'Jane'})
    # FIXME
    # assert len(schema) == 2


# Generated at 2022-06-22 06:11:17.725396
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    pass

# Generated at 2022-06-22 06:11:23.952063
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class A(Schema):
        a = String(max_length=10)
        b = String(max_length=10)
        c = String(max_length=10)
    a = A(a='abc', c='abc')
    assert a['a'] == 'abc'
    assert a['c'] == 'abc'
    assert a['b'] is None
    assert a['d'] is None


# Generated at 2022-06-22 06:11:32.975103
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    instance = SchemaDefinitions()
    assert len(instance) == 0


# Generated at 2022-06-22 06:11:36.276543
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # no values
    definition = SchemaDefinitions()
    assert len(definition) == 0

    # with values
    definition = SchemaDefinitions({
        'key': 'value'
    })
    assert len(definition) == 1


# Generated at 2022-06-22 06:11:38.548555
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema()) == 'Schema()', "repr error"
    assert repr(Schema(arg1=1, arg2=2, arg3=3)) == 'Schema(arg1=1, arg2=2, arg3=3)', "repr error"



# Generated at 2022-06-22 06:11:42.087882
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema()) == 0
    assert len(Schema(dict())) == 0
    assert len(Schema(object())) == 0
    assert len(Schema(to=42)) == 1



# Generated at 2022-06-22 06:11:44.041926
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    cls = isinstance(list, typing.Any)
    assert cls is list



# Generated at 2022-06-22 06:11:48.029713
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    data_in = Schema(id=1, name='king of kings')
    data_out = {"id": 1, "name": "king of kings"}
    reference = Reference(to=Schema)

    result = reference.serialize(data_in)

    assert result == data_out

# Generated at 2022-06-22 06:11:50.100897
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Implement your test here
    raise NotImplementedError


# Generated at 2022-06-22 06:11:52.414107
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    test_schema = Schema(dict())

    actual = test_schema.__repr__()
    expected = "Schema([])"

    assert actual == expected


# Generated at 2022-06-22 06:11:55.032545
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions["key"] = "value"
    del definitions["key"]
    assert "key" not in definitions

# Generated at 2022-06-22 06:12:05.632139
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import copy
    import json
    import jsonschema
    from box import Box

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        registered = Field(type="boolean")

    person = Person(name="guido", age=54, registered=True)

    assert person["name"] == "guido"
    assert person["age"] == 54
    assert person["registered"] is True
    assert sorted(person.keys()) == ["age", "name", "registered"]
    assert len(person) == 3
    assert str(person) == "Person(age=54, name='guido', registered=True)"

    person = Person(name="guido", registered=True)

    assert person["name"] == "guido"
    assert person["registered"] is True

# Generated at 2022-06-22 06:12:33.728841
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.types import (
        Array,
        Boolean,
        Date,
        DateTime,
        Float,
        Integer,
        String,
    )

    class PetSchema(Schema):
        name = String()
        type = String()
        is_vaccinated = Boolean(default=False)

    class PuppySchema(PetSchema):
        birth_date = Date()
        last_vaccination_date = Date(allow_null=True)

    class DogSchema(PuppySchema):
        height = Integer(min_value=0, max_value=99)
        weight = Float(min_value=0)

    data = {"name": "John", "type": "dog", "height": 23, "weight": 20.5}
    dog = DogSchema(data)
    print(dog)

# Generated at 2022-06-22 06:12:39.794250
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    class TestSchema(Schema):
        field1 = Field(str)
        field2 = Field(str)

    v, _ = TestSchema.validate_or_error({"field1": "V1", "field2": "V2"})
    definitions = SchemaDefinitions()
    definitions["TestSchema"] = TestSchema
    del definitions["TestSchema"]
    assert definitions == {}


# Generated at 2022-06-22 06:12:51.505951
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    print('Testing Schema___len__')
    from typing import Tuple, List
    from typesystem import Integer, String

    class SimpleSchema(Schema):
        name = String(min_length=3, max_length=12)
        age = Integer(minimum=1, exclusive_minimum=True)

    simple_schema = SimpleSchema({"name":"Aditya", "age":2})
    assert len(simple_schema) == 2

    class SimpleSchema2(Schema):
        name = String(min_length=3, max_length=12)
        age = Integer(minimum=1, exclusive_minimum=True)

    simple_schema2 = SimpleSchema2(name="Aditya", age=2)
    assert len(simple_schema2) == 2


# Generated at 2022-06-22 06:12:56.980433
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Names(Schema):
        first = String()
        last = String()

    names = Names(first="Ovidiu", last="Costin")
    assert len(names) == 2
    assert list(names) == ["first", "last"]
    assert names["first"] == "Ovidiu"
    assert names["last"] == "Costin"



# Generated at 2022-06-22 06:13:00.664668
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions()
    definitions[1] = 10
    assert len(definitions) == 1
    assert next(iter(definitions)) == 1


# Generated at 2022-06-22 06:13:10.255389
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class MySchema(Schema):
        name = Field(str)

    my_schema = MySchema({'name': 'me'})
    assert my_schema.serialize() == {'name': 'me'}

    class MySchema(Schema):
        name = Field(str)
        ref = Reference(to='MySchema')
    my_schema = MySchema({'name': 'me'})
    assert my_schema.serialize() == {'name': 'me', 'ref': None}
    assert my_schema.serialize({'name': 'me'}) == {'name': 'me', 'ref': {'name': 'me'}}

# Generated at 2022-06-22 06:13:12.663940
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test = SchemaDefinitions({"key1": "value1"})
    assert len(test) == 1
    assert test["key1"] == "value1"

# Generated at 2022-06-22 06:13:15.032973
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    d = {'a': 1, 'b': 2}
    c = Schema(d)
    assert c.__repr__() == "Schema(a=1, b=2)"


# Generated at 2022-06-22 06:13:18.400210
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    from typing import Any, Dict, List, Set
    from typesystem.fields import Boolean, Integer, Number, String, Array, Object
    from typesystem.schema import SchemaDefinitions
    definitions = SchemaDefinitions({'test-key':'test-value'})
    assert definitions['test-key'] == 'test-value' # type: ignore


# Generated at 2022-06-22 06:13:25.925013
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Node(Schema):
        name = Field(type_=str)
        parent = Reference("Node")

    assert isinstance(Node.fields, dict)
    assert Node.fields["name"]._creation_counter == 1
    assert Node.fields["parent"]._creation_counter == 2
    assert Node.fields["parent"].to == "Node"
    assert Node.fields["name"].type_ == str

# Generated at 2022-06-22 06:14:03.955484
# Unit test for constructor of class Schema
def test_Schema():
    # Base test
    class Person(Schema):
        name = String(required=True)
        age = Integer()

    person = Person(name="Joel", age=20)
    assert person.name == "Joel"
    assert person.age == 20

    # If we have a 'dict' or 'OrderedDict' argument, we get values from the
    # appropriate keys.
    person = Person(dict(name="Joel", age=20))
    assert person.name == "Joel"
    assert person.age == 20

    # If we have an object argument, we get values from its attributes.
    class PersonObject:
        name: str
        age: int = None

    person_object = (PersonObject(),)
    person = Person(person_object)
    assert person.name == person_object[0].name


# Generated at 2022-06-22 06:14:05.655891
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    value0 = SchemaDefinitions()[0]
    assert False



# Generated at 2022-06-22 06:14:11.584209
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Setup
    class Article(Schema):
        title = Field(String)
        content = Field(String)
        rating = Field(Integer)
        is_published = Field(Boolean)
    article = Article(title='title', content='content')

    # Exercise
    actual_repr = article.__repr__()

    # Verify
    expected_repr = "Article(title='title', content='content')"
    assert actual_repr == expected_repr


# Generated at 2022-06-22 06:14:17.097030
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        name: str
        age: int

    person = Person(name="Bob", age=22)
    assert person.fields['name'].serialize(person.name) == 'Bob'
    assert person.fields['age'].serialize(person.age) == 22

# Generated at 2022-06-22 06:14:21.544710
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    repr1 = Schema({'salary': 50000, 'age': 30, 'name': 'abc'}).__repr__()
    assert repr1 == 'Schema(age=30, name=\'abc\', salary=50000)'
    repr2 = Schema({'salary': 50000, 'age': 30, 'name': 'abc', 'id': None}).__repr__()
    assert repr2 == 'Schema(age=30, name=\'abc\', salary=50000, [sparse])'
    repr3 = Schema({'salary': 50000, 'age': 30, 'name': 'abc', 'id': None, 'extra': None}).__repr__()
    assert repr3 == 'Schema(age=30, name=\'abc\', salary=50000, [sparse])'

test

# Generated at 2022-06-22 06:14:32.851808
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def_test = SchemaDefinitions()
    keys = [1, 2, 3]
    values = ["one", "two", "three"]

    def_test[keys[0]] = values[0]
    def_test[keys[1]] = values[1]
    def_test[keys[2]] = values[2]

    assert def_test[keys[0]] == values[0]
    assert def_test[keys[1]] == values[1]
    assert def_test[keys[2]] == values[2]
    assert list(def_test.keys()) == keys
    assert list(def_test.values()) == values
    assert list(def_test.items()) == [(keys[0], values[0]),
                                      (keys[1], values[1]),
                                      (keys[2], values[2])]

# Generated at 2022-06-22 06:14:42.395605
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class person_schema(Schema):
        name = String()
        age = Integer()

    class child_schema(Schema):
        child = Reference(to = person_schema)

    class family_schema(Schema):
        father = Reference(to = person_schema)
        mother = Reference(to=person_schema)
        children = Array(child_schema)

    family = family_schema({
        "father": {"name":"Jon", "age": 25},
        "mother": {"name":"Danaerys", "age":30},
        "children": [{"child": {"name":"Aegon", "age":5}},
                    {"child": {"name":"Rhaenys", "age":3}}]
    })

    # The method serialize of class Reference takes the object obj and returns its dict representation

# Generated at 2022-06-22 06:14:51.149914
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert iter(SchemaDefinitions()) == iter({})
    assert iter(SchemaDefinitions({})) == iter({})
    assert iter(SchemaDefinitions({1: 2})) == iter({1: 2})
    assert iter(SchemaDefinitions(a=1, b=2)) == iter({'a': 1, 'b': 2})
    assert iter(SchemaDefinitions({'a': 1, 'b': 2})) == iter({'a': 1, 'b': 2})


# Generated at 2022-06-22 06:15:02.787072
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class Person(Schema):
        age = Field(type="integer")
        name = Field(type="string")

    person1 = Person(age = 42, name = "Mike")
    person2 = Person(age = 42, name = "Mike")
    person3 = Person(age = 42, name = "Jack")
    person4 = Person(age = 32, name = "Mike")
    person5 = Person(age = 42)
    person6 = Person(name = "Mike")
    person7 = Person()

    assert repr(person1) == "Person(age=42, name='Mike')"
    assert repr(person5) == "Person(age=42) [sparse]"
    assert repr(person6) == "Person(name='Mike') [sparse]"
    assert repr(person7) == "Person() [sparse]"



# Generated at 2022-06-22 06:15:05.678347
# Unit test for method validate of class Reference
def test_Reference_validate():
    Reference_test = Reference(to="Test")
    Reference_test.validate({"test": "test"})

# Generated at 2022-06-22 06:16:14.542744
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    instance = SchemaDefinitions(
        dict=Object(properties={"first_name": String()}, additional_properties=False),
        int=Integer()
    )
    assert list(instance.__iter__()) == ["dict", "int"]


# Generated at 2022-06-22 06:16:26.105157
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class A(Schema):
        x = Integer()
        y = String()

    class B(A):
        z = Boolean()

    class C(B):
        a = Integer()

    class D(A):
        a = Integer()

    test_a = A(x=0, y="")
    assert test_a == A(x=0, y=""), repr(test_a)
    assert test_a.x == 0

    test_b = B(x=0, z=False)
    assert test_b == B(x=0, z=False), repr(test_b)
    assert test_b.z is False

    test_c = C(x=0, z=False, a=1)

# Generated at 2022-06-22 06:16:33.604573
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Prover
    from pram.rule import Rule
    from pram.data import GroupSizeProbe, ProbeMsgMode

    from pram.entity import Group, GroupQry, GroupSplitSpec, Site

    from pram.rule import IterAlways
    from pram.sim import Simulation

    from typesystem.schema import Schema

    class LocationSchema(Schema):
        longitude = float()
        latitude = float()

    # Model
    class ContactModel(Rule):
        def apply(self, pop, group, iter, t):
            if group.has_attr({ 'location': (42.3601001, -71.09416) }):
                return [
                    GroupSplitSpec(p=0.7, attr_set={ })
                ]

    # Probe

# Generated at 2022-06-22 06:16:37.115676
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    d = SchemaDefinitions()
    assert isinstance(d, SchemaDefinitions)
    assert isinstance(d, MutableMapping)
    assert len(d) == 0


# Generated at 2022-06-22 06:16:49.208395
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class TestClass(Schema):
        pass
    assert TestClass.fields == {}
    assert TestClass() == TestClass()
    assert TestClass() == TestClass({})
    assert TestClass() == TestClass(TestClass())
    assert TestClass() == TestClass({"a": 1})
    assert TestClass() == TestClass(TestClass({"a": 1}))

    class Blah(TestClass):
        field1 = String()
    assert Blah.fields == {"field1": String()}

    class Blah(TestClass):
        field1 = String()
        field2 = String()
    assert Blah.fields == {"field1": String(), "field2": String()}

    class Blah(TestClass):
        field1 = String()
        field2 = String()


# Generated at 2022-06-22 06:16:55.091818
# Unit test for constructor of class Reference
def test_Reference():
    test_Reference = Reference(to="test_Reference")
    assert test_Reference.to == "test_Reference"
    assert test_Reference.definitions == None
    assert test_Reference.target_string == "test_Reference"


# Generated at 2022-06-22 06:16:56.121470
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
  _test_SchemaMetaclass___new__()

# Generated at 2022-06-22 06:17:07.835111
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem

    class TopSchema(typesystem.Schema):
        '''
        Top level schema.
        '''
        name = typesystem.Text()
        age = typesystem.Integer()
        data = Reference('ChildSchema')

    assert TopSchema.fields == {
        'name': TopSchema.name,
        'age': TopSchema.age,
        'data': TopSchema.data
    }

    class TopSchema(typesystem.Schema):
        '''
        Top level schema.
        '''
        name = typesystem.Text()
        age = typesystem.Integer()
        data = Reference('ChildSchema')

# Generated at 2022-06-22 06:17:19.526518
# Unit test for method validate of class Reference
def test_Reference_validate():
    def add_assertions(self):
        self.assertIsInstance(self.result, ValidationResult, f"Result should be a ValidationResult object but is a <{type(self.result).__name__}>")
        self.assertIs(self.result.value, None, "Value should be <None>, was <{self.result.value}>.")
        self.assertIsInstance(self.result.error, ValidationError, f"Error should be a ValidationError object but is a <{type(self.result.error).__name__}>.")
        self.assertEqual(self.result.error.text, "May not be null.", f"Error text should be 'May not be null.' but was <{self.result.error.text}>.")


# Generated at 2022-06-22 06:17:20.155395
# Unit test for constructor of class Reference
def test_Reference():
    pass