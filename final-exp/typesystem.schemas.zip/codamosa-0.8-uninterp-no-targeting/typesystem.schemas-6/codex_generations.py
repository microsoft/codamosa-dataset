

# Generated at 2022-06-22 06:08:15.055008
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import typesystem
    import datetime
    import pytest

    class User(Schema):
        id = typesystem.Integer(description="The unique identifier for a user.")
        email = typesystem.String(description="The email address of the user.")
        joined_at = typesystem.Date(description="The date-time the user joined.")

    user1 = User(id=123, email="foo@example.com", joined_at=datetime.date(2000, 1, 1))
    user2 = User(id=123, email="foo@example.com", joined_at=datetime.date(2000, 1, 1))

    assertion = user1 == user2
    assert assertion

    # Test different type

# Generated at 2022-06-22 06:08:16.055065
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert True


# Generated at 2022-06-22 06:08:21.479214
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class A(Schema):
        val = Field(Integer)
    
    class B(Schema):
        a = Reference(to="A")
    
    b = B(a=A(val=1))
    b.a.serialize(A(val=2))

# Generated at 2022-06-22 06:08:32.137157
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import String, Integer
    class TestSchema(Schema):
        a = String()
        b = Integer()

    test_schema = TestSchema(a='test', b=1)
    assert dict(test_schema) == {'a': 'test', 'b': 1}

    test_schema = TestSchema(a='test', b=1)
    assert test_schema['a'] == 'test'

    test_schema = TestSchema(a='test', b=1)
    assert test_schema['b'] == 1

    test_schema = TestSchema(a='test', b=1)
    try:
        test_schema['c']
        assert False
    except KeyError as error:
        assert str(error) == "'c'"


# Generated at 2022-06-22 06:08:42.940133
# Unit test for method validate of class Reference
def test_Reference_validate():
    class FooSchema(Schema):
        foo = Field(str)

    class BarSchema(Schema):
        bar = Reference(to=FooSchema)

    bar_schema = BarSchema(bar={'foo': 'bar'})
    assert bar_schema.validate(bar_schema) == bar_schema
    assert bar_schema.validate({'bar': {'foo': 'bar'}}) == bar_schema
    #assert bar_schema.validate({'foo': 'bar'}) == bar_schema
    #assert bar_schema.validate({'bar': {'foo': 1}}) == bar_schema



# Generated at 2022-06-22 06:08:51.169740
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from io import StringIO
    from sys import stderr
    from unittest import TestCase, main

    class PrintLogger(TestCase):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._output = StringIO()

        @property
        def output(self) -> str:
            return self._output.getvalue()

        def fail(self, msg: str = None) -> None:
            assert msg is not None
            print(msg, file=self._output)
            assert False


# Generated at 2022-06-22 06:08:58.584024
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    """
    Test for method __getitem__ of class SchemaDefinitions
    """
    # Passing KeyError
    s = SchemaDefinitions()
    with pytest.raises(KeyError):
        s.__getitem__("key")
    # Passing correct
    s._definitions = {"key":  3}
    assert s.__getitem__("key") == 3


# Generated at 2022-06-22 06:09:00.449731
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    #__delitem__(key: Any) -> None
    pass



# Generated at 2022-06-22 06:09:08.040761
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()

    try:
        definitions["key1"]
        assert 0
    except:
        assert 1

    definitions["key1"] = "value1"
    definitions["key2"] = "value2"
    assert(definitions["key1"] == "value1")
    assert(definitions["key2"] == "value2")

    del definitions["key1"]
    try:
        definitions["key1"]
        assert 0
    except:
        assert 1


# Generated at 2022-06-22 06:09:18.439994
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Parent(Schema):
        parent_1 = Field(type=int)
        parent_2 = Field(type=str)

    class Child(Parent):
        child_1 = Field(type=bool)
        child_2 = Field(type=str)
        parent_1 = Field(type=str)

    class Grandchild(Child):
        grandchild_1 = Field(type=int)
        grandchild_2 = Field(type=str)
        parent_2 = Field(type=int)
        parent_1 = Field(type=Object)

    Child.__name__ = "Child"
    Child._definition = "child"

    Grandchild.__name__ = "Grandchild"
    Grandchild._definition = "grandchild"

    child_1 = Child()
    result = child_1.fields

# Generated at 2022-06-22 06:09:29.209758
# Unit test for method validate of class Reference
def test_Reference_validate():
    Reference('name' in people).validate({"name": "Alice", "age": 0}) 
    
    

# Generated at 2022-06-22 06:09:37.332831
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(str).serialize(None) == None
    assert Reference(str).serialize('anything') == 'anything'
    assert Reference(int).serialize(1) == 1
    assert Reference(int).serialize(None) == None
    class A(object):
        def __init__(self, name):
            self.name = name
    class B(Reference):
        def __init__(self, to, **kwargs):
            super(B, self).__init__(to, **kwargs)
    assert B(A).serialize(A('aa')) == {'name': 'aa'}

# Generated at 2022-06-22 06:09:42.858212
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import typesystem
    class SimpleForm(typesystem.Schema):
        title = typesystem.String(title="Simple example")
        description = typesystem.String(description="A simple example")
        type = typesystem.String(default="simple", read_only=True)

        class Meta:
            title = "Simple Form"
            description = "Simple Example"
    assert repr(SimpleForm()) == "SimpleForm()"

# Generated at 2022-06-22 06:09:45.892791
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem import String
    from typesystem.schema import Schema

    class Person(Schema):
        name = String()

    p = Person.validate({'name':'George'})
    assert p.serialize()['name'] == 'George'

# Generated at 2022-06-22 06:09:52.916289
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Blog(Schema):
        title = Field(type=str)
        link = Field(type=str)
        author = Field(type=str, null=True)
        position = Field(type=int, null=True)

    class User(Schema):
        name = Field(type=str)
        blogs = Field(type=Array(items=Reference(to=Blog)))
        favourite_blog = Field(type=Reference(to=Blog), null=True)
        favourite_position = Field(type=Reference(to=Blog), null=True)


# Generated at 2022-06-22 06:09:59.320437
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    person = Person({'name': 'Peter', 'age': 42})

    assert person['name'] == 'Peter'
    assert person['age'] == 42


# Generated at 2022-06-22 06:10:01.777621
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions()
    definitions['k1']=1
    assert definitions['k1']==1


# Generated at 2022-06-22 06:10:03.819901
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    test_obj = SchemaDefinitions()
    test_obj[1] = 2
    assert test_obj[1] == 2


# Generated at 2022-06-22 06:10:14.168445
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.fields import String

    class DefinitionA(Schema):
        b = Reference("B")
        c = Reference("C")

    class DefinitionB(Schema):
        d = Reference("D")

    class DefinitionC(Schema):
        e = Reference("E")

    class DefinitionD(Schema):
        f = Reference("F")

    class DefinitionE(Schema):
        g = Reference("G")

    class DefinitionF(Schema):
        pass

    class DefinitionG(Schema):
        h = String()


# Generated at 2022-06-22 06:10:25.864288
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    definitions: SchemaDefinitions = SchemaDefinitions()
    class TestSchema(Schema, meta=SchemaMetaclass, definitions=definitions):
        field_one = Field(required=True)
        field_two = Field(required=True)
    class TestSchemaTwo(Schema, meta=SchemaMetaclass, definitions=definitions):
        field_three = Reference(to='TestSchema', definitions=definitions)
    # Check definition as a whole
    assert definitions == {'TestSchema': TestSchema, 'TestSchemaTwo': TestSchemaTwo}
    # Check fields from TestSchema
    assert TestSchema.fields == {'field_one': Field(required=True), 'field_two': Field(required=True)}
    # Check fields from TestSchemaTwo

# Generated at 2022-06-22 06:11:03.470826
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class New(Schema):
        foo = String()
        bar = Integer()
    class New2(New):
        foo = Integer()
    test = New({"foo":"hello", "bar":1})
    test2 = New2({"foo":2, "bar":1})
    print(test)
    #assert str(test) == "New(bar=1, foo='hello')"
    print(test2)
    #assert str(test2) == "New(bar=1, foo='hello')"

    @classmethod
    def make_validator(cls):
        return "New"
    print(test.make_validator())
    assert test.make_validator() == "New"
    print(test2.make_validator())
    assert test2.make_validator() == "New"

   

# Generated at 2022-06-22 06:11:13.537632
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = {'a': ['b']}
    schema_definitions = SchemaDefinitions(definitions)

    assert hasattr(schema_definitions, '_definitions')
    assert schema_definitions._definitions is not None

    assert len(schema_definitions) > 0
    assert schema_definitions['a'] == ['b']

    schema_definitions['b'] = 'c'
    assert len(schema_definitions) > 1
    assert schema_definitions['b'] == 'c'

    with pytest.raises(KeyError):
        schema_definitions['c']

    schema_definitions['a'] = 'd'
    assert len(schema_definitions) > 1
    assert schema_definitions['a'] == 'd'
    assert schema_definitions['b'] == 'c'



# Generated at 2022-06-22 06:11:16.748077
# Unit test for constructor of class Reference
def test_Reference():
    field = Reference(to="test")
    assert issubclass(field.target, Schema)
    assert field.target.__name__ == "test"
    assert field.target_string == "test"
    assert field.definitions != None

# Generated at 2022-06-22 06:11:20.413441
# Unit test for constructor of class Reference
def test_Reference():
    reference = Reference(str, to="test")
    assert reference is not None
    assert reference.to is not None
    assert reference.definitions is None
    assert reference._target_string is not None
    assert "test" == reference._target_string


# Unit test to test getter of attribute target_string

# Generated at 2022-06-22 06:11:24.949905
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class MyClass(Schema):
        myint = 42
        mylist = [1, 2, 3]
    assert Reference("MyClass").serialize(MyClass) == {'myint': 42, 'mylist': [1, 2, 3]}



# Generated at 2022-06-22 06:11:27.047507
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    var = SchemaDefinitions()
    set_definitions
    pass

# Generated at 2022-06-22 06:11:36.271722
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    fields = {'name': String(required=True),
              'age': Integer(),
              'male': Boolean(),
              'address': String()}
    UserSchema = SchemaMetaclass(name='UserSchema',
                                 bases=(object,),
                                 attrs=fields)
    user = UserSchema({'name': 'John',
                       'age': 25,
                       'male': True,
                       'address': '123 main street'})
    user2 = UserSchema(name='John',
                       age=25,
                       male=True,
                       address='123 main street')
    assert user == user2
    assert user['name'] == user2['name']



# Generated at 2022-06-22 06:11:39.697096
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference('to', definitions={'to' : {}}).to == 'to'
    assert Reference('to', definitions={'to' : {}}).definitions == {'to' : {}}

# Generated at 2022-06-22 06:11:40.646306
# Unit test for constructor of class Schema
def test_Schema():
    # TODO:
    pass

# Generated at 2022-06-22 06:11:50.859993
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    def check_equal(name, A, B):
        if not(A == B):
            print(name, ": FAIL")
            print(A)
            print(B)
        else:
            print(name, ": OK")

    # Test 1
    A=SchemaDefinitions()
    A["a"]=1
    B=SchemaDefinitions(a=1)
    check_equal("test 1", A, B)

    # Test 2
    A=SchemaDefinitions()
    A["a"]=1
    A["b"]=2
    A["c"]=3
    B=SchemaDefinitions(a=1, b=2, c=3)
    check_equal("test 2", A, B)

    # Test 3
    A=SchemaDefinitions(b=2)
    A

# Generated at 2022-06-22 06:12:07.560813
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert False



# Generated at 2022-06-22 06:12:15.298399
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        pass
    
    class MyNested(Schema):
        pass

    class MyReference(Schema):
        schema = Reference(MySchema)
        my_nested = Reference(MyNested)
    
    definitions = SchemaDefinitions()
    set_definitions(MyReference, definitions)

    assert MyReference.fields["schema"].definitions == definitions
    assert MyReference.fields["my_nested"].definitions == definitions



# Generated at 2022-06-22 06:12:18.221334
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    import pytest
    class Student(Schema):
        id = Field(type="integer")
        name = Field(type="string")
    dic = {'id': 5, 'name': 'Atsushi'}
    ref = Reference(Student)
    assert ref.serialize(dic) == dic



# Generated at 2022-06-22 06:12:20.848610
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Arrange
    class Contact(Schema):
        name = String(required=True)
        age = Integer(required=False)
    c = Contact(name = 'Flasky', age = 3)
    # Act
    result = c.__getitem__('name')
    # Assert
    assert (result == 'Flasky')


# Generated at 2022-06-22 06:12:27.257327
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    assert len(s) == 0
    s = SchemaDefinitions({'a': 1, 'b': 2})
    assert len(s) == 2
    try:
        s['c'] = 3
        s['c'] = 4
    except AssertionError as e:
        print(e)
    assert len(s) == 2
    s['d'] = 4
    assert len(s) == 3
    assert s['a'] == 1

    s = SchemaDefinitions(a=1, b=2)
    assert len(s) == 2
    try:
        s['c'] = 3
        s['c'] = 4
    except AssertionError as e:
        print(e)
    assert len(s) == 2
    s['d'] = 4
    assert len

# Generated at 2022-06-22 06:12:29.094126
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class X():
        fields = {}
    assert 'fields' in X.__dict__


# Generated at 2022-06-22 06:12:37.540143
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class FooSchema(Schema):
        name = String(format="uuid")
        age = Integer()

    s = FooSchema(name="c4ca4238-a0b9-3382-8dcc-509a6f75849b", age=42)
    s2 = FooSchema(name="c4ca4238-a0b9-3382-8dcc-509a6f75849b", age=42)

    assert s is not s2
    assert s == s2

# Generated at 2022-06-22 06:12:47.005897
# Unit test for method validate of class Reference
def test_Reference_validate():
    target_obj = Schema({"a": 1})
    target_field = Reference(target_obj)
    assert target_field.validate({"a": 1}) == target_obj
    assert target_field.validate({"a": 2}) == Schema({"a": 2})
             
    target_str = 'target'
    target_field = Reference(target_str)
    assert target_field.target_string == target_str
    assert target_field.allow_null
             
    item = Schema({"a": 1})
    target_field = Reference(item)
    assert target_field.validate({"a": 1}) == item
    assert target_field.validate({"a": 2}) == Schema({"a": 2})

# Generated at 2022-06-22 06:12:54.950165
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    obj = Schema()
    class_name = obj.__class__.__name__
    arguments = [key for key in obj.fields.keys() if hasattr(obj, key)]
    argument_str = ", ".join([f"{key}={value!r}" for key, value in arguments.items()])
    sparse_indicator = " [sparse]" if obj.is_sparse else ""
    return f"{class_name}({argument_str}){sparse_indicator}"

# Generated at 2022-06-22 06:13:00.776862
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
  from typesystem.fields.base import BaseField
  class Meta(SchemaMetaclass):
    pass

  class A(metaclass=Meta):
    x = BaseField()
    y = BaseField()

  assert list(A.fields.keys()) == ['x', 'y']


# Generated at 2022-06-22 06:13:56.199108
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    s = SchemaDefinitions()
    s['hello'] = 'world'
    s['foo'] = 'bar'
    assert len(s) == 2
    del s['foo']
    assert len(s) == 1

# Generated at 2022-06-22 06:14:09.125156
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Test1(Schema):
        test_field1 = Field(int, default=0)
        test_field2 = Field(int, default=1)

    class Test2(Schema):
        test_field1 = Field(int, default=0)
        test_field2 = Field(int, default=1)

    assert "fields" in Test1.__dict__
    assert Test1.__dict__["fields"] == {"test_field1": Test1.__dict__["test_field1"],
                                        "test_field2": Test1.__dict__["test_field2"]}

    assert "fields" in Test2.__dict__

# Generated at 2022-06-22 06:14:10.587638
# Unit test for constructor of class Reference
def test_Reference():
    # The following call should succeed
    Reference(to='Foo')

# Generated at 2022-06-22 06:14:21.088142
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Test valid
    to = Schema(type = "string")
    definition = SchemaDefinitions()
    definition["to"] = to
    reference = Reference(to = "to", definitions = definition)
    reference.validate("hello")

    # Test invalid due to null
    to = Schema(type="string")
    definition = SchemaDefinitions()
    definition["to"] = to
    reference = Reference(to="to", definitions=definition, allow_null=False)
    try:
        reference.validate(None)
    except ValidationError as ex:
        assert ex.path == [] and ex.errors == [{'code': 'null', 'message': 'May not be null.', 'type': 'value'}]

# Generated at 2022-06-22 06:14:23.476822
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    sd = SchemaDefinitions()
    sd['s'] = 's'
    assert sd['s'] == 's'


# Generated at 2022-06-22 06:14:28.681036
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class PersonSchema(Schema):
        name = Field(str)
        age = Field(int)

    person = PersonSchema(name='Andrew', age=24)
    person_dict = {
        'name': 'Andrew',
        'age': 24,
    }

    assert person_dict == person


# Generated at 2022-06-22 06:14:32.081011
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    definitions.__setitem__("definitions", "value")
    definitions.__setitem__("value", "definitions")
    assert(len(definitions) == 2)


# Generated at 2022-06-22 06:14:42.871442
# Unit test for function set_definitions
def test_set_definitions():
    d1 = SchemaDefinitions()
    d2 = SchemaDefinitions()

    class MySchema(Schema):
        f1 = Reference(to="Foo")
        f2 = Reference(to="Bar")
        f3 = Reference(to="Fizz")
        f4 = Reference(to="Buzz")

    class Foo(Schema):
        x = Field()

    class Bar(Schema):
        y = Field()

    class Fizz(Schema):
        a = Field()

    class Buzz(Schema):
        b = Field()

    for key, value in {
        "Foo": Foo,
        "Bar": Bar,
        "Fizz": Fizz,
        "Buzz": Buzz,
        "MySchema": MySchema,
    }.items():
        d1[key] = value
       

# Generated at 2022-06-22 06:14:43.942254
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    a = Schema.__getitem__()

# Generated at 2022-06-22 06:14:49.201563
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Human(Schema, definitions=definitions):
        name = String()

    class Pet(Schema, definitions=definitions):
        name = String()
        owner = Reference("Human")

    pet = Pet(name="Poppy", owner=dict(name="Alice"))
    assert pet.owner.name == "Alice"

# Generated at 2022-06-22 06:15:52.714197
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference("to", definitions={})
    assert ref._target_string == "to"
    assert ref._target == {}
    ref = Reference("to", definitions="definitions")
    assert ref._target_string == "to"
    assert ref._target == "definitions"

test_Reference()

# Generated at 2022-06-22 06:15:58.161517
# Unit test for constructor of class Reference
def test_Reference():
    class SimpleSchema(Schema):
        foo: str

    reference = Reference(to='SimpleSchema')
    definitions = SchemaDefinitions({'SimpleSchema': SimpleSchema})
    reference.definitions = definitions

    assert reference.target is SimpleSchema
    assert reference.target_string == 'SimpleSchema'


# Unit tests for constructor of class Schema

# Generated at 2022-06-22 06:16:02.163595
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Model(Schema):
        property = Field()
    schema = Model(property = "random")
    assert len(schema) == 1


# Generated at 2022-06-22 06:16:10.848387
# Unit test for constructor of class Schema
def test_Schema():
    pass
    # # No default value when calling constructor
    # # It should return a new instance of Schema
    # try:
    #     s = Schema()
    # except:
    #     raise AssertionError("Calling the constructor returns an object")
    # assert type(s) == Schema
    #
    # # Check that a dictionary is passed as input when calling the constructor
    # try:
    #     s = Schema({"test":"test"})
    # except:
    #     raise AssertionError("Calling constructor with dictionary returns an object")
    # assert type(s) == Schema
    #
    # # Check that the object field is set with the input dictionary
    # assert s.test == "test"


# Generated at 2022-06-22 06:16:18.848922
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Human(Schema):
        name = String()
        age = Integer(minimum=0)
        father = Reference("Human")

    assert Human().__repr__() == "Human(name=None, age=None)"

    # For some reason, father field is also added to __repr__()
    # even though it is not in the object itself
    assert Human(name="Jane Doe", age=20).__repr__() == "Human(name='Jane Doe', age=20, father=None)"

# Generated at 2022-06-22 06:16:21.940786
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    obj = SchemaDefinitions()
    try:
        obj.__iter__()
    # exception raised.
    except AssertionError:
        pass


# Generated at 2022-06-22 06:16:27.299765
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema = SchemaDefinitions(
        {
            "a": "b",
            "b": {
                "c": "d",
                "d": {
                    "e": "f",
                    "f": "g",
                },
            },
        },
    )
    assert schema["a"] == "b"
    assert schema["b"] == {
        "c": "d",
        "d": {
            "e": "f",
            "f": "g",
        },
    }

# Generated at 2022-06-22 06:16:29.912257
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    global definitions
    definitions = SchemaDefinitions() # type: SchemaDefinitions
    definitions[str] = int
    definitions[str]


# Generated at 2022-06-22 06:16:33.845806
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    obj = SchemaDefinitions()
    def test_assertion(result):
        assert result == True, "Expected True, but got: " + str(result)
    test_assertion((obj._definitions == {}))


# Generated at 2022-06-22 06:16:45.384462
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass:
        def __new__(
            cls: type,
            name: str,
            bases: typing.Sequence[type],
            attrs: dict,
            definitions: typing.Mapping = None,
        ) -> type:
            fields: typing.Dict[str, Field] = {}
            for key, value in list(attrs.items()):
                if isinstance(value, Field):
                    attrs.pop(key)
                    fields[key] = value
            for base in reversed(bases):
                base_fields = getattr(base, "fields", {})
                for key, value in base_fields.items():
                    if isinstance(value, Field) and key not in fields:
                        fields[key] = value
            for field in fields.values():
                set_definitions