

# Generated at 2022-06-26 10:31:13.585132
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema(name = "John Doe")
    schema_1 = Schema(name = "John Doe")
    assert schema_0 == schema_1
    schema_1 = Schema(name = "Jane Doe")
    assert not schema_0 == schema_1
    assert not schema_0 == None


# Generated at 2022-06-26 10:31:15.454776
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_1 = Schema()
    schema_2 = Schema()
    assert schema_1 == schema_2, "Test failed"


# Generated at 2022-06-26 10:31:16.317441
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert Schema().__repr__() == "Schema()"


# Generated at 2022-06-26 10:31:17.673319
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():

    # Given
    schema_0 = Schema()

    # When
    result = schema_0['missing']

    # Then
    assert False

# Generated at 2022-06-26 10:31:23.675050
# Unit test for function set_definitions
def test_set_definitions():
    class Schema_1(object):
        item = Reference("schema_2", to=schema_2)
        obj = Object()
        array = Array()

    class Schema_2(object):
        pass

    schema_1 = Schema_1
    schema_2 = Schema_2

    definitions = SchemaDefinitions()
    set_definitions(schema_1.item, definitions)
    assert(schema_1.item.definitions == definitions)
    set_definitions(schema_1.obj, definitions)
    assert(schema_1.obj.definitions == definitions)
    set_definitions(schema_1.array, definitions)
    assert(schema_1.array.definitions == definitions)

if __name__ == "__main__":
    test_case_0()
   

# Generated at 2022-06-26 10:31:25.805906
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    schema_0_iter = iter(schema_0)
    assert not hasattr(schema_0_iter, "__next__")
    assert not hasattr(schema_0_iter, "__iter__")


# Generated at 2022-06-26 10:31:27.426115
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    schema_0.__iter__()


# Generated at 2022-06-26 10:31:32.968745
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    actual = [key for key in schema_0]
    expected = []
    assert actual == expected
    class_name = schema_0.__class__.__name__
    message = "%s.__iter__() is broken" % class_name
    raise AssertionError(message)



# Generated at 2022-06-26 10:31:38.638513
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    result_0 = schema_0 == schema_0
    result_1 = schema_0 == schema_0
    result_2 = schema_0 == schema_0
    assert result_0 is result_1
    assert result_0 is result_2


# Generated at 2022-06-26 10:31:44.882084
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    a = Schema()
    b = Schema()
    assert a == b
    assert a == a
    assert a != dict()
    assert a != []


# Generated at 2022-06-26 10:32:05.096235
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # The number of fields for schema_0
    schema_0_expected = 0
    schema_0_actual = len(schema_0.fields)
    assert schema_0_expected == schema_0_actual, f"Expected {schema_0_expected} fields, got {schema_0_actual} fields"
    schema_1_expected = 1
    schema_1_actual = len(schema_1.fields)
    assert schema_1_expected == schema_1_actual, f"Expected {schema_1_expected} fields, got {schema_1_actual} fields"
    schema_2_expected = 2
    schema_2_actual = len(schema_2.fields)

# Generated at 2022-06-26 10:32:06.165091
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert True


# Generated at 2022-06-26 10:32:18.134263
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test that the definitions is properly populated for the Schema
    # subclass and its fields.

    # Test that the schema field is properly sorted and indexed.
    schema_2 = Schema(first=None, second=None, third=None)
    assert schema_2.fields == {
        "first": Field(name="first"),
        "second": Field(name="second"),
        "third": Field(name="third"),
    }

    # Test that the schema field is properly sorted and indexed.
    schema_3 = Schema(last=None, first=None, second=None, third=None)
    assert schema_3.fields == {
        "first": Field(name="first"),
        "second": Field(name="second"),
        "third": Field(name="third"),
    }

    # Test that the attributes are properly copied over in

# Generated at 2022-06-26 10:32:21.828294
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert len(list(schema_0.__iter__())) == 0


# Generated at 2022-06-26 10:32:25.876140
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar", required=True)
    set_definitions(Foo.fields["bar"], SchemaDefinitions())
    assert isinstance(Foo.fields["bar"].definitions, SchemaDefinitions)

# Generated at 2022-06-26 10:32:29.682509
# Unit test for constructor of class Schema
def test_Schema():
    # test_case_0
    schema_0 = Schema()
    schema_0_check_fields = {"fields": {}}
    for key, value in schema_0_check_fields.items():
        assert key in schema_0.__dict__
        assert schema_0.__dict__[key] == value


# Generated at 2022-06-26 10:32:30.842235
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()

# Generated at 2022-06-26 10:32:40.792097
# Unit test for constructor of class Schema
def test_Schema():
    schema_1 = Schema(age=25, name='hongyan')
    assert schema_1.age == 25
    assert schema_1.name == 'hongyan'
    schema_3 = Schema(
        {'age': 25, 'name': 'hongyan'}
    )
    assert schema_3.age == 25
    assert schema_3.name == 'hongyan'


# Generated at 2022-06-26 10:32:52.671117
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Schema_0(Schema):
        string_field_0 = Field(type="string")
        integer_field_0 = Field(type="integer")
        boolean_field_0 = Field(type="boolean")
        float_field_0 = Field(type="number")
    def test_Schema___eq___1():
        instance_0 = Schema_0()
        instance_1 = Schema_0()
        check_0 = instance_0 == instance_1
        assert check_0 is True
    def test_Schema___eq___2():
        instance_0 = Schema_0(string_field_0="aqz", boolean_field_0=True)
        instance_1 = Schema_0(string_field_0="aqz", boolean_field_0=True)
        check_0 = instance

# Generated at 2022-06-26 10:32:54.930217
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema.__init__.__doc__ == "__init__()"



# Generated at 2022-06-26 10:33:16.825636
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    # A ValueError should have been thrown.
    with pytest.raises(AttributeError):
        box_0 = Box(
            'w',
            color='red',
            weight=2,
            definitions=schema_definitions_0,
        )


# Generated at 2022-06-26 10:33:19.840996
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_0 = Schema()
    # No exception should be thrown
    result = schema_0.__getitem__(0)
    assert result is not None


# Generated at 2022-06-26 10:33:23.468183
# Unit test for constructor of class Schema
def test_Schema():
    def test_func(schema_definitions_0):
        return type(
            "foo", (SchemaDefinitions,), {"name": "foo"}, schema_definitions_0
        )

    with pytest.raises(AssertionError):
        test_func(schema_definitions_0)
    assert test_func(SchemaDefinitions())

# Generated at 2022-06-26 10:33:28.520647
# Unit test for function set_definitions
def test_set_definitions():
    test_schema_definitions_0 = SchemaDefinitions()
    test_field_0 = Field()
    set_definitions(test_field_0, test_schema_definitions_0)
    test_array_0 = Array()
    set_definitions(test_array_0, test_schema_definitions_0)
    test_object_0 = Object()
    set_definitions(test_object_0, test_schema_definitions_0)


# Generated at 2022-06-26 10:33:41.259051
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    _schema_0 = Schema.__new__(Schema)
    _schema_0._fields = {'0': Field.__new__(Field)}
    _schema_0.__init__()
    _schema_0_it = _schema_0.__iter__()
    _schema_0_it_0 = next(_schema_0_it)
    _schema_0_it_1 = next(_schema_0_it)
    next(_schema_0_it_1)
    try:
        assert (_schema_0_it_0 == '0')
        assert (_schema_0_it_1 == '0')
    except AssertionError:
        raise AssertionError
    else:
        pass
    finally:
        pass



# Generated at 2022-06-26 10:33:43.527130
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:33:45.572017
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:33:56.459379
# Unit test for constructor of class Schema
def test_Schema():
    # Initialization from dict
    class User(Schema, definitions=schema_definitions_0):
        user_id = Integer(format="uuid")
        username = String()
        password = String()
        first_name = String(required=False)
        last_name = String(required=False)

    user_input = {"user_id": "234", "username": "bob@example.com"}
    user_0 = User(user_input)
    assert user_0.user_id == "234"
    assert user_0.username == "bob@example.com"
    assert not hasattr(user_0, "password")
    assert not hasattr(user_0, "first_name")
    assert not hasattr(user_0, "last_name")

    # Initialization from object

# Generated at 2022-06-26 10:33:59.386221
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class ExampleSchema(Schema):
        field_0 = Field(type="string")
    instance_0 = ExampleSchema()
    assert len(instance_0) == 1


# Generated at 2022-06-26 10:34:10.297604
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()

    # Test 0
    schema_0 = Schema(schema_definitions_0)
    # PASS: Test 0
    # FAIL: Test 1

    # Test 2
    schema_0 = Schema(schema_definitions_0)
    # PASS: Test 2
    # FAIL: Test 3

    # Test 4
    schema_0 = Schema(schema_definitions_0)
    # PASS: Test 4
    # FAIL: Test 5

    # Test 6
    schema_0 = Schema(schema_definitions_0)
    # PASS: Test 6
    # FAIL: Test 7

    # Test 8
    schema_0 = Schema(schema_definitions_0)
    # PASS: Test 8
    # FAIL: Test 9



# Generated at 2022-06-26 10:34:25.418310
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Instantiate the Schema
    schema_obj_0 = Schema(schema_definitions_0)

    # Call the method
    schema_obj_0.__iter__()


# Generated at 2022-06-26 10:34:35.829862
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    test_cases = [
        Schema,
        Schema({"a": 1}),
        Schema({"a": 1, "b": 2}),
        Schema(a=1),
        Schema(a=1, b=2),
        Schema(a=1, b=2),
        Schema(a=1, b=2),
        Schema(a=2, b=1),
        Schema(A=1, B=2),
        Schema(A=1, B=2),
    ]
    for left in test_cases:
        for right in test_cases:
            assert (left == right) == (left is right)
            assert (left != right) == (left is not right)


# Generated at 2022-06-26 10:34:39.122803
# Unit test for constructor of class Schema
def test_Schema():
    class TestCaseSchema0(Schema, metaclass=SchemaMetaclass):
        pass
    TestCaseSchema0()
    TestCaseSchema0(dict())



# Generated at 2022-06-26 10:34:46.556426
# Unit test for constructor of class Schema
def test_Schema():
    # Constructing a Schema object
    # 1. With a dictionary as the argument
    # 2. With an object as the argument
    # 3. With both dictionary and object arguments
    # 4. With keyword arguments
    # 5. With both dictionary and keyword arguments
    # 6. With keyword arguments that are incompatible with the fields defined in the class
    # 7. With both dictionary and keyword arguments that are incompatible with the fields defined in the class
    # 8. With a sparse dictionary argument and keyword arguments
    # 9. With a sparse dictionary argument and keyword arguments that are incompatible with the fields defined in the class
    # 10. With a sparse dictionary argument
    # 11. With a sparse object argument
    class InnerSchema(Schema):
        thing = Field()
    class OuterSchema(Schema):
        schema = Reference(InnerSchema)
    schema_definitions_

# Generated at 2022-06-26 10:34:48.553585
# Unit test for constructor of class Schema
def test_Schema():
    test_schema = Schema("")



# Generated at 2022-06-26 10:34:52.973570
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Reference.__new__(Reference, 'to', 'definitions')
    assert type(schema_0) == Reference


# Generated at 2022-06-26 10:35:02.533774
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from copy import deepcopy
    from typing import Any, List, Tuple, Union, cast
    from unittest import mock
    schema_definitions_0 = SchemaDefinitions()

    class NoDefinitions(Schema, metaclass=SchemaMetaclass):
        pass

    class Order(Schema, metaclass=SchemaMetaclass):
        order_id = Field(format="uuid", required=True)
        customer = Reference("Customer", required=True)
        price = Field(type="number")
        description = Field(type="string")
        # Testing a field with a default value that isn't None
        items = Array(Field("Item"), default=[])

    schema_definitions_0["Order"] = Order

# Generated at 2022-06-26 10:35:04.063129
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0_0 = TestSchema_0()
    schema_0_1 = TestSchema_0()
    assert (schema_0_0 == schema_0_1)



# Generated at 2022-06-26 10:35:05.099094
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    test_0 = SchemaDefinitions() # type: SchemaDefinitions
    test_case_0()


# Generated at 2022-06-26 10:35:17.604731
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    class User(Schema, definitions=schema_definitions_0):
        nickname = String(required=True)
        first_name = String()
        last_name = String()
        email = String(format="email")
        age = Number(minimum=0)
        country = String(enum=["FR", "GB", "PT", "ES"])
    user_0 = User()
    user_0 = User({
    })
    user_0 = User({
        'nickname': '',
        'first_name': '',
        'last_name': '',
        'email': '',
        'country': '',
    })
    user_1 = User(nickname='', first_name='', last_name='', email='')
    assert user_

# Generated at 2022-06-26 10:35:29.264624
# Unit test for function set_definitions
def test_set_definitions():
    Test = SchemaDefinitions()
    class TestTrue: 
        Test = SchemaDefinitions
    TestFalse = ""
    assert Test == TestTrue.Test

# Generated at 2022-06-26 10:35:31.990061
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert len(schema_definitions_0) == 0
    assert list(schema_definitions_0) == []
    try:
        schema_definitions_0.__iter__()
    except TypeError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-26 10:35:33.993335
# Unit test for constructor of class Schema
def test_Schema():
    # Test Schema is type MutableMapping
    assert issubclass(Schema, typing.Mapping)



# Generated at 2022-06-26 10:35:39.089329
# Unit test for function set_definitions
def test_set_definitions():
    field = Field(name="title")
    definitions = SchemaDefinitions()
    
    set_definitions(field, definitions)
    # Should not raise exception
    assert field.definitions == definitions


# Generated at 2022-06-26 10:35:41.764316
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    value_0 = set_definitions(schema_definitions_0, schema_definitions_0)


# Generated at 2022-06-26 10:35:42.912848
# Unit test for constructor of class Schema
def test_Schema():
    test_case_0()



# Generated at 2022-06-26 10:35:51.682773
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.base import Field

    class MySchema(Schema):
        field_0 = Field()
        field_1 = Field()

    # The `Schema` class has a property `fields` that is a
    # mapping of the declared fields.
    assert "field_0" in MySchema.fields
    assert "field_1" in MySchema.fields

    # The __repr__ of a Schema returns a string
    # that can be evaluated.
    instance = MySchema()
    repr_ = repr(instance)
    eval_ = eval(repr_)

    # The repr of a Schema instance is a string representation
    # of the constructor.
    assert repr_ == "MySchema()"

    # The repr can be evaluated.
    assert isinstance(eval_, MySchema)

    # The

# Generated at 2022-06-26 10:36:02.999262
# Unit test for function set_definitions
def test_set_definitions():

    class IpAddress(Schema):
        def __init__(
            self,
            ipaddress: typing.Union[str, None] = None,
            country: typing.Union[str, None] = None,
        ):
            self.ipaddress = ipaddress
            self.country = country
            super().__init__()

    class Login(Schema):
        def __init__(
            self,
            username: typing.Union[str, None] = None,
            ipaddress: typing.Union[IpAddress, None] = None,
        ):
            self.username = username
            self.ipaddress = ipaddress
            super().__init__()


# Generated at 2022-06-26 10:36:06.986161
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_0 = Schema()
    set_definitions(schema_0, schema_definitions_0)
# Error handler for method __new__ of class SchemaMetaclass

# Generated at 2022-06-26 10:36:09.591732
# Unit test for constructor of class Schema
def test_Schema():
    print("Test case 0:")
    test_case_0()


if __name__ == "__main__":
    test_Schema()

# Generated at 2022-06-26 10:36:22.188923
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema(strict=True)

    assert list(schema) == []


# Generated at 2022-06-26 10:36:30.720863
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()

    class TestSchema(Schema, metaclass=SchemaMetaclass):
        field_0 = Field()

    test_schema_0 = TestSchema(field_0=field_0)
    assert test_schema_0.__len__() == 1
    assert test_schema_0.__len__() == 1


# Generated at 2022-06-26 10:36:33.131366
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert repr(schema_0) == "Schema()"


# Generated at 2022-06-26 10:36:42.669475
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name='John', age=32)
    len(person) == 2
    person_1 = Person(age=32)
    len(person_1) == 1
    person_2 = Person(name='John')
    len(person_2) == 1


# Generated at 2022-06-26 10:36:47.570897
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    #  NOTE: Can't test __iter__ right now as `fields` is stored as a class attribute,
    # not an instance attribute.
    #  NOTE: Can't test __iter__ right now as `fields` is stored as a class attribute,
    # not an instance attribute.


# Generated at 2022-06-26 10:36:51.038428
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    class_name = "Schema"
    arguments = ", ".join([])
    sparse_indicator = " [sparse]" if False else ""

    # This is preferred to `assert Schema().__repr__() == f"Schema({arguments}){sparse_indicator}"`
    assert repr(Schema()) == f"{class_name}({arguments}){sparse_indicator}"

# Generated at 2022-06-26 10:37:01.266017
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    nadeem_0 = User.validate({"name": "Nadeem", "age": 38})
    nadia_0 = User.validate({"name": "Nadia", "age": 38})
    assert not (nadeem_0 == nadia_0)
    nadeem_1 = User.validate({"name": "Nadeem", "age": 38})
    assert nadeem_0 == nadeem_1
    assert nadeem_1 == nadeem_0
    assert not (nadeem_1 == nadia_0)
    assert not (nadia_0 == nadeem_1)


# Generated at 2022-06-26 10:37:03.646249
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # test definition
    value, error = schema_definitions_0.__iter__() #@noqa
    # tests
    assert True



# Generated at 2022-06-26 10:37:12.215304
# Unit test for function set_definitions
def test_set_definitions():
    ID = Field(type=str)
    ADDRESS = Field(type = dict)
    items = Reference("Address", definitions = references_0)
    List_0 = Array(items = items)
    ITEMS = Reference("List", definitions = references_0)
    BILL = Object(properties = {'items': ITEMS}, required = ['items'])
    definition_keys = ['Address', 'List', 'Bill']
    definitions = {'Address': ADDRESS, 'List': List_0, 'Bill': BILL}
    for key in definition_keys:
        schema_definitions_0[key] = definitions[key]
    key = 'items'
    value = ITEMS
    set_definitions(value, schema_definitions_0)
    

# Generated at 2022-06-26 10:37:24.126679
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    class Schema_0(Schema, metaclass=SchemaMetaclass):
        pass
    assert Schema_0.__name__ == "Schema_0"
    schema_0 = Schema_0()
    assert schema_0.fields == {}
    schema_1 = Schema_0({})
    assert schema_1.fields == {}
    class Schema_1(Schema, metaclass=SchemaMetaclass):
        field_0 = String()
    assert Schema_1.__name__ == "Schema_1"
    assert Schema_1.fields["field_0"] == String()
    schema_2 = Schema_1({})
    assert schema_2.fields == {"field_0": String()}
    assert schema_2.fields

# Generated at 2022-06-26 10:37:43.487787
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()

    class ExampleSchema_0(Schema):
        name = Field(key=True)
        age = Field(type_name='int')
        color = Field(type_name='str')
        set_definitions(ExampleSchema_0, schema_definitions_0)
        schema_definitions_0[ExampleSchema_0.__name__] = ExampleSchema_0

    example_object_0 = ExampleSchema_0(
        name='bob',
        age=100,
        color='blue',
    )

    assert len(example_object_0) == 3


# Generated at 2022-06-26 10:37:52.359244
# Unit test for constructor of class Schema
def test_Schema():
    # Testing arguments
    user = Schema(
        id=123,
        name="John Smith",
        age=35,
        occupation="gardener",
        requires_gardener=True,
    )
    assert user.id == 123
    assert user.name == "John Smith"
    assert user.age == 35
    assert user.occupation == "gardener"
    assert user.requires_gardener == True
    assert user.optional_field == None



# Generated at 2022-06-26 10:37:56.626739
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    class A(Schema):
        definitions = schema_definitions_0
        foo = String()

    a_0 = A()
    a_0.foo = "foo"
    a_0["foo"]
    a_0["foo"]



# Generated at 2022-06-26 10:38:00.384872
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_class_0 = Schema
    schema_0 = Schema()
    schema_1 = Schema()
    var_0 = schema_0 == schema_1
    var_1 = isinstance(var_0, bool)
    assert var_1


# Generated at 2022-06-26 10:38:07.629229
# Unit test for constructor of class Schema
def test_Schema():
    SomeSchema = Schema
    assert isinstance(SomeSchema, SchemaMetaclass)

    # Test with positional arguments.
    schema_0 = SomeSchema({})

    # Test with keyword arguments.
    schema_1 = SomeSchema(id=0)
    # Unit test for `make_validator` of class Schema
    assert callable(SomeSchema.make_validator)

    # Test with positional arguments.
    validator = SomeSchema.make_validator()

    # Test with keyword arguments.
    validator = SomeSchema.make_validator(strict=True)


# Generated at 2022-06-26 10:38:12.701801
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Test case of normal input
    schema_definitions_0 = SchemaDefinitions()
    class_0 = Schema(schema_definitions_0)
    class_1 = Schema(schema_definitions_0)
    value_0 = class_0.__eq__(class_1)
    assert (value_0 is True)


# Generated at 2022-06-26 10:38:20.866854
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = SchemaMetaclass.__new__(SchemaMetaclass, 'SchemaClass', (), {}, schema_definitions_0)
    schema_0.fields.fields = {}
    schema_1 = SchemaMetaclass.__new__(SchemaMetaclass, 'SchemaClass', (), {}, schema_definitions_0)
    schema_0.fields.fields = {}
    assert ((schema_0.__eq__(schema_1) is True))


# Generated at 2022-06-26 10:38:25.209629
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    field_instance_0 = Field()
    attribute_names_0 = dir(field_instance_0)
    attribute_count_0 = 0
    for name_0 in attribute_names_0:
        if hasattr(field_instance_0, name_0): attribute_count_0 += 1
    assert attribute_count_0 == 29
    test_case_0()

test_SchemaMetaclass___new__()

# Generated at 2022-06-26 10:38:32.004774
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    definitions = SchemaDefinitions()
    TestCreateSchema0._create_test_schema(TestCreateSchema0, definitions)
    TestCreateSchema1._create_test_schema(TestCreateSchema1, definitions)
    TestCreateSchema2._create_test_schema(TestCreateSchema2, definitions)
    TestCreateSchema3._create_test_schema(TestCreateSchema3, definitions)
    TestCreateSchema4._create_test_schema(TestCreateSchema4, definitions)
    TestCreateSchema5._create_test_schema(TestCreateSchema5, definitions)
    TestCreateSchema6._create_test_schema(TestCreateSchema6, definitions)
    TestCreateSchema7._create_test_schema(TestCreateSchema7, definitions)
    TestCreateSchema8

# Generated at 2022-06-26 10:38:35.240388
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()  # No Arguments
    try:
        assert len(schema_0) == 0
    except Exception as e:
        print(e)


# Generated at 2022-06-26 10:39:03.552467
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    class Test1(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        one = Field()
        two = Field()
        three = Field()
        four = Field()
        _creation_order = [
            "four",
            "one",
            "three",
            "two",
        ]
        def __init__(self) -> None:
            pass

# Generated at 2022-06-26 10:39:13.898609
# Unit test for function set_definitions
def test_set_definitions():
    # simple test
    fields_0 = {"first_name": String(), "last_name": String()}
    fields_1 = {"first_name": String(), "last_name": String()}
    ref_0 = Reference("Person")
    fields_1["nickname"] = ref_0
    Person = Schema.make_validator(fields=fields_0, definitions=schema_definitions_0)
    Other = Schema.make_validator(fields=fields_1, definitions=schema_definitions_0)
    set_definitions(ref_0, schema_definitions_0)
    assert schema_definitions_0 == {"Person": Person, "Other": Other}

    # complex test
    fields_2 = {"first_name": String(), "last_name": Array(String())}
    User = Schema.make

# Generated at 2022-06-26 10:39:16.370805
# Unit test for constructor of class Schema
def test_Schema():
    obj = Schema()
    assert obj is not None


# Generated at 2022-06-26 10:39:19.789177
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class User(Schema):
        user_id = Integer(minimum=1)

    print("Testing method __eq__ of class Schema")

    assert User(user_id=1) == User(user_id=1), "Equals check failed."
    assert User(user_id=1) != User(user_id=2), "Equals check failed."
    assert User(user_id=1) != "foo", "Equals check failed."
    assert User(user_id=1) != 1, "Equals check failed."


# Generated at 2022-06-26 10:39:23.323885
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    # Test with a class with no fields
    class TestSchema_0(Schema, metaclass=SchemaMetaclass):
        fields = {}
    obj_0 = TestSchema_0()
    assert len(obj_0) == 0


# Generated at 2022-06-26 10:39:34.086873
# Unit test for function set_definitions
def test_set_definitions():
    class TestClass(Schema):
        class Meta:
            definitions = {
                "int": Field(primitive_type="integer"),
                "str": Field(primitive_type="string"),
            }
        a = Reference("int")
        b = Reference("str")

    assert TestClass.Meta.definitions["int"] is Field(primitive_type="integer")
    assert TestClass.Meta.definitions["str"] is Field(primitive_type="string")
    assert TestClass.a.definitions["int"] is Field(primitive_type="integer")
    assert TestClass.a.definitions["str"] is Field(primitive_type="string")
    assert TestClass.b.definitions["int"] is Field(primitive_type="integer")

# Generated at 2022-06-26 10:39:45.240691
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.fields import String
    from typesystem.reference import Reference
    schema_definitions_0 = SchemaDefinitions()
    class Object(Schema):
        fields = {"one": String()}
    assert len(schema_definitions_0) == 0
    set_definitions(Object, schema_definitions_0)
    assert len(schema_definitions_0) == 1
    assert Object in schema_definitions_0
    class Object_0(Schema):
        fields = {"two": Reference("Object")}
    assert len(schema_definitions_0) == 1
    set_definitions(Object_0, schema_definitions_0)
    assert len(schema_definitions_0) == 2
    assert Object_0 in schema_definitions_0
    assert Object in schema_definitions_

# Generated at 2022-06-26 10:39:47.627945
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    result = True
    assert result == False


# Generated at 2022-06-26 10:39:52.714029
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class User(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        name = Field(type="string")

    schema_definitions_0 is User.definitions
    obj_0 = User(name="Pete")
    assert isinstance(obj_0, Mapping)
    for key in obj_0:
        value = obj_0[key]
    obj_1 = User(name="Pete")
    obj_0 == obj_1
    bool_0 = obj_0.is_sparse
    str_0 = repr(obj_0)
    validator_0 = User.make_validator()
    obj_2 = User.validate({"name": "Pete"})
    result_0 = User.valid

# Generated at 2022-06-26 10:39:57.785521
# Unit test for constructor of class Schema
def test_Schema():
    result = Schema()
    assert isinstance(result, Schema)
    assert result.fields == {}
