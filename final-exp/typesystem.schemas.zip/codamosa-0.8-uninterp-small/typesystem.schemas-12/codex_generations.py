

# Generated at 2022-06-26 10:31:12.944615
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    output = schema_0.__repr__()
    assert output == 'Schema()'


# Generated at 2022-06-26 10:31:19.448428
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    iterator_0 = schema_definitions_0.__iter__()
    # Testing constructor of class Schema
    class TestSchema (Schema):
        fields = {
            "name": Field(type="string"),
            "age": Field(type="integer", description="The age of the person."),
        }

    obj = TestSchema(name="Alice", age=42)
    assert obj.name == "Alice"
    assert obj.age == 42

    # Make sure we can pass in an empty dict
    obj = TestSchema({})

    # Test validation errors
    try:
        TestSchema(name=None)
        assert False
    except ValidationError as error:
        assert error.message == "name: May not be null."

    # Test validation errors when parsing

# Generated at 2022-06-26 10:31:20.821723
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    try:
        test_case_0()
    except:
        print('Exception raised while calling test case(s)')


# Generated at 2022-06-26 10:31:24.048867
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    class User(Schema):
        username = String(max_length=100)
        age = Integer()
    user_0 = user_1 = User(username="bob", age=42)
    assert user_0 == user_1, f"Expected: {user_0!r} Actual: {user_1!r}"


# Generated at 2022-06-26 10:31:27.744935
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_value_0 = Schema()
    schema_value_1 = Schema()
    bool_value_0 = schema_value_0.__eq__(schema_value_1)


# Generated at 2022-06-26 10:31:33.786580
# Unit test for constructor of class Schema
def test_Schema():
    # Test validity of __init__ signature
    try:
        Schema()
        Schema([])
        Schema(a=1)
        Schema({'a': 1})
    except TypeError:
        test_failed = True
    else:
        test_failed = False
    assert not test_failed, "Failed to initialize object of type `Schema`"


# Generated at 2022-06-26 10:31:36.748605
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    dummy_Schema_instance_0 = Schema()
    dummy_Schema_instance_0.__iter__()



# Generated at 2022-06-26 10:31:43.132927
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.fields import String

    class Base(Schema):
        name = String()

    class BaseDefs(metaclass=SchemaMetaclass, definitions=SchemaDefinitions()):
        field = Reference(to="Base")

    class Child(Base):
        pass

    class ChildDefs(metaclass=SchemaMetaclass, definitions=SchemaDefinitions()):
        field = Reference(to="Child")

    assert BaseDefs.fields["field"].target is Base
    assert ChildDefs.fields["field"].target is Child

# Generated at 2022-06-26 10:31:45.804465
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Init
    class Person(Schema):
        name = Field(str)
        age = Field(int)
    tom = Person(name="Tom", age=35)
    assert len(tom) == 2


# Generated at 2022-06-26 10:31:49.582948
# Unit test for method validate of class Reference
def test_Reference_validate():
    # 'allow_null' is True by default.
    ref = Reference(None, allow_null=True)
    assert ref.validate(None) is None
    with pytest.raises(ValidationError):
        ref.validate(None, strict=True)

# Generated at 2022-06-26 10:32:17.396640
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0["Base"] = "https://example.com"

    def test_field(field: Field) -> Field:
        set_definitions(schema_definitions_0, field)

    # Check that Reference instances get the definitions object set when
    # they're created with a string, and don't get the definitions object
    # set when they're created with a class, but later get the definitions
    # object set when they're passed to set_definitions.
    reference_0 = Reference(
        to="Base",
        definitions=schema_definitions_0,
        allow_null=True,
        description="Reference to a resource.",
    )
    assert reference_0._target == "https://example.com"

# Generated at 2022-06-26 10:32:21.007729
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    global schema_definitions_0
    
    class TestSchema(Schema, definitions=schema_definitions_0):
        test_field = Field(int)
    schema = TestSchema()
    schema.test_field = 1
    
    test_result = []
    expected_result = [1]
    for res in schema:
        test_result.append(res)
    
    assert test_result == expected_result


# Generated at 2022-06-26 10:32:24.137190
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    try:
        assert 0 == schema_definitions_0.__len__()
    except:
        raise RuntimeError


# Generated at 2022-06-26 10:32:28.137600
# Unit test for function set_definitions
def test_set_definitions():
    string = String(format = "regex") 
    assert string.definitions is None
    schema_definitions_1 = SchemaDefinitions()

    definitions = set_definitions(string, schema_definitions_1)
    assert string.definitions == schema_definitions_1


# Generated at 2022-06-26 10:32:29.656454
# Unit test for constructor of class Schema
def test_Schema():
    test_case_0()



# Generated at 2022-06-26 10:32:34.115593
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = Schema(schema_definitions_0)
    class_0.fields = {}
    assert tuple(class_0) == ()


# Generated at 2022-06-26 10:32:46.275313
# Unit test for constructor of class Reference
def test_Reference():
    # class init tests
    instance = Reference("DummyString")
    assert instance.to == "DummyString"
    assert instance.definitions == None
    
    # getter tests
    # target_string getter
    target_string = instance.target_string
    assert target_string == "DummyString"
    
    # target getter
    target = instance.target
    assert target == None
    
    # validate tests
    # case 0
    value = None
    strict = False
    instance.allow_null = True
    result = instance.validate(value, strict=strict)
    assert result == None
    
    # case 1
    value = None
    strict = False
    instance.allow_null = False

# Generated at 2022-06-26 10:32:48.788260
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    set_definitions("Pets", "Pets", "", "", "", "")
    return



# Generated at 2022-06-26 10:32:50.876324
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert 0 == len(schema_0)


# Generated at 2022-06-26 10:32:55.439484
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    schema_0.__getitem__('key')
    assert True # TODO: may fail!


# Generated at 2022-06-26 10:33:05.668743
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    assert False


# Generated at 2022-06-26 10:33:09.562834
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Case 0: len(x) for an unpopulated schema
    test_case_0()
    schema_0 = Employees(schema_definitions_0)
    assert len(schema_0) == 0


# Generated at 2022-06-26 10:33:13.723077
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    test_schemas = [Schema()]
    for schema in test_schemas:
        assert len(schema) == 0
        assert isinstance(len(schema), int)


# Generated at 2022-06-26 10:33:23.774136
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema_0(Schema):
        field_0 = Array(String())
    with pytest.raises(TypeError):
        TestSchema_0(dict())
    schema_0 = TestSchema_0(dict(field_0=[]))
    result = schema_0 == schema_0
    assert result
    assert schema_0 == schema_0  # type: ignore
    result = schema_0 != schema_0
    assert not result
    with pytest.raises(KeyError):
        element = schema_0['missing']
    with pytest.raises(KeyError):
        element = schema_0['field_1']
    result = len(schema_0) == 1
    assert result

# Generated at 2022-06-26 10:33:31.128468
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    schema_1 = Schema()
    schema_2 = Schema()
    schema_3 = Schema()
    schema_4 = Schema()
    schema_5 = Schema()
    schema_6 = Schema()
    schema_7 = Schema()
    schema_8 = Schema()
    schema_9 = Schema()
    schema_10 = Schema()
    schema_11 = Schema()
    schema_12 = Schema()
    schema_13 = Schema()
    schema_14 = Schema()
    schema_15 = Schema()
    schema_16 = Schema()
    schema_17 = Schema()
    schema_18 = Schema()
    schema_19 = Schema()
    schema_20 = Schema()
    schema_21 = Schema()
   

# Generated at 2022-06-26 10:33:42.722372
# Unit test for function set_definitions
def test_set_definitions():
    class FooDefinition(Schema):
        title = Field(str)
        active = Field(bool, default=False)

    class BarDefinition(Schema):
        description = Field(str)
        class_name = Field(str)
        foo = Reference("FooDefinition")

    schema_definitions_0 = SchemaDefinitions()
    set_definitions(BarDefinition.fields["foo"], schema_definitions_0)
    assert schema_definitions_0 == {
        "BarDefinition": BarDefinition,
        "FooDefinition": FooDefinition,
    }, schema_definitions_0


if __name__ == "__main__":
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-26 10:33:46.733977
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Article(Schema):
        title = Field()
        type = Field()

    assert list(Article({'title': 1, 'type': 2})) == ['title', 'type']


# Generated at 2022-06-26 10:33:51.306678
# Unit test for function set_definitions
def test_set_definitions():
    field_0 = String(max_length=1)
    assert(field_0.max_length == 1)
    assert(field_0.trim_whitespace == None)
    assert(field_0.is_optional == None)


# Generated at 2022-06-26 10:33:55.479160
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_item_0 = Schema()
    schema_item_1 = Schema()
    schema_0 = Schema([schema_item_0, schema_item_1])
    assert list(schema_0.__iter__()) == list(schema_0.keys())



# Generated at 2022-06-26 10:34:01.563060
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    test_case_0()
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0_class = schema_definitions_0.__class__
    repr_call_result_0 = repr(schema_definitions_0)
    assert repr_call_result_0 == 'SchemaDefinitions()', repr_call_result_0



# Generated at 2022-06-26 10:34:12.694232
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema()
    set_definitions(schema_0, schema_definitions_0)



# Generated at 2022-06-26 10:34:17.048449
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema(schema_definitions_0)
    assert len(schema_0) == 0
    schema_0.schema = schema_definitions_0
    schema_0 = Schema(schema_definitions_0)
    assert len(schema_0) == 0

# Generated at 2022-06-26 10:34:18.889810
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(schema_definitions_0) == 0


# Generated at 2022-06-26 10:34:31.509132
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import random
    from typesystem.schema import Schema

    random.seed(1)

    schema_definitions_0 = SchemaDefinitions()

    class Class1(Schema, definitions=schema_definitions_0):
        def __init__(self, a=0, b="foo"):
            assert (
                isinstance(a, int)
                and isinstance(b, str)
                and len(b) >= 1
                and len(b) <= 4
            )
            self.a = a
            self.b = b
    assert str(repr(Class1(1, "bar"))) == "Class1(a=1, b='bar')"
    assert str(repr(Class1(a=1, b="bar"))) == "Class1(a=1, b='bar')"


# Generated at 2022-06-26 10:34:42.061672
# Unit test for constructor of class Reference
def test_Reference():
    schema_definitions_0 = SchemaDefinitions()
    to_0 = "SomeSchema"
    target_0 = None
    to_1 = "SomeSchema"
    target_1 = None
    to_2 = "SomeSchema"
    target_2 = None
    to_3 = "SomeSchema"
    target_3 = None
    to_4 = "SomeSchema"
    target_4 = None
    to_5 = "SomeSchema"
    target_5 = None
    to_6 = "SomeSchema"
    target_6 = None
    to_7 = "SomeSchema"
    target_7 = None
    to_8 = "SomeSchema"
    target_8 = None
    to_9 = "SomeSchema"
    target_9 = None

# Generated at 2022-06-26 10:34:45.091299
# Unit test for constructor of class Reference
def test_Reference():
    def test_Reference_0():
        # Constructor test 0
        def test_Reference_0_0():
            test_Reference_0_0_0 = Reference(to="")


# Generated at 2022-06-26 10:34:48.366717
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema(**{})
    assert list(schema_0) == []



# Generated at 2022-06-26 10:34:53.180446
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_int_0 = Integer()
    schema_0 = Schema(fields={'x': schema_int_0})
    # Check that the number of defined fields is correct.
    assert len(schema_0) == 1


# Generated at 2022-06-26 10:34:55.365439
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    test_case_0()


if __name__ == "__main__":
    # Run test methods
    test_Schema___repr__()

# Generated at 2022-06-26 10:34:57.644930
# Unit test for constructor of class Schema
def test_Schema():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 10:35:06.672303
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import types

    assert issubclass(type, types.TypeType)



# Generated at 2022-06-26 10:35:19.937150
# Unit test for constructor of class Schema
def test_Schema():
    field1 = Field(name="field1", required=False)
    field2 = Field(name="field2", required=False)
    class Schema0(Schema, definitions=schema_definitions_0):
        field1 = field1
        field2 = field2
    Schema1 = Schema0(field1=field1, field2=field2, definitions=schema_definitions_0)
    assert hasattr(Schema1, 'field1') == True
    assert hasattr(Schema1, 'field2') == True
    assert hasattr(Schema1, 'fields') == True
    assert hasattr(Schema1, 'make_validator') == True
    assert hasattr(Schema1, 'validate') == True
    assert hasattr(Schema1, 'validate_or_error') == True


# Generated at 2022-06-26 10:35:21.007673
# Unit test for constructor of class Schema
def test_Schema():
    test_case_0()


test_Schema()

# Generated at 2022-06-26 10:35:29.555029
# Unit test for constructor of class Schema
def test_Schema():
    from typing import Any, Dict, List
    from typesystem.fields import Object

    schema_definitions_0 = SchemaDefinitions()
    class Address(Schema):

        street = String(max_length=100)
        city = String(max_length=50)
        state = String(max_length=20)
        zip = String(max_length=10)

    class Phone(Schema):

        number = String(max_length=20)
        type = String(max_length=10)

    class Customer(Schema):

        name = String(max_length=100)
        email = String(max_length=100)
        address = Reference(Address, definitions=schema_definitions_0)
        phone_numbers = Array(items=Reference(Phone, definitions=schema_definitions_0))

    obj

# Generated at 2022-06-26 10:35:33.599052
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    Field.__new__(Field)
    class ChildSchema_0(Schema, metaclass=SchemaMetaclass):
        fields = {'a': 'a', 'b': 'b'}
        definitions = schema_definitions_0


# Generated at 2022-06-26 10:35:35.791179
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    print(Schema.__dict__['__iter__'])

# Generated at 2022-06-26 10:35:40.848394
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import String

    class Person(Schema):
        name = String()

    definition = SchemaDefinitions()

    Person({"name": "John"}, definitions=definition)
    Person({"name": 100})


# Generated at 2022-06-26 10:35:46.583079
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    meta_cls: type
    name: str
    bases: typing.Sequence[type]
    attrs: dict
    definitions: SchemaDefinitions 
    test_case_0_result = SchemaMetaclass.__new__(meta_cls, name, bases, attrs, definitions)
    assert test_case_0_result == test_case_0_expected_result
test_case_0_expected_result = test_case_0()

# Generated at 2022-06-26 10:35:48.917585
# Unit test for constructor of class Reference
def test_Reference():
    to = ""
    definitions = {}
    field = Reference(to, definitions)
    assert field.to == to
    assert field.definitions == definitions
    assert field._creation_counter == 0

# Generated at 2022-06-26 10:35:49.981869
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert True


# Generated at 2022-06-26 10:36:20.504605
# Unit test for method __len__ of class Schema
def test_Schema___len__():
  import copy
  import json
  import random
  import unittest

  from nose.tools import assert_equal

  from typesystem import (
      Array,
      Boolean,
      DefinitionError,
      Integer,
      Object,
      Schema,
      String,
  )

  class User(Schema):
      id = Integer
      name = String
      is_active = Boolean

  user = User.validate({'id': 1, 'name': 'Alice', 'is_active': True})

  # Test length of a schema with all fields populated.
  assert_equal(len(user), 3)

  # Test length for schemas that are sparsely populated.
  assert_equal(len(User()), 0)
  assert_equal(len(User(id=1, name='Alice')), 2)

# Generated at 2022-06-26 10:36:23.738674
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    iterator_0 = iter(schema_0)


# Generated at 2022-06-26 10:36:32.611421
# Unit test for function set_definitions
def test_set_definitions():
    class SimpleType(Schema):
        a = Int()

    class ReferenceType(Schema):
        simple = Reference(to='SimpleType')

    schema_definitions_1 = SchemaDefinitions()
    set_definitions(ReferenceType.fields['simple'], schema_definitions_1)
    assert schema_definitions_1.get('SimpleType') == SimpleType


# Generated at 2022-06-26 10:36:46.615499
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions = SchemaDefinitions()
    class_ = type(
        "ExampleSchema0",
        (Schema,),
        {
            "name": String(),
            "age": Integer(),
            "dob": DateTime(),
            "something": String(),
        },
        definitions=schema_definitions,
    )
    schema_instance_0 = class_()
    schema_instance_1 = class_(name="a", age=0, dob=datetime(1,1,1), something="b")
    len_0 = len(schema_instance_0)
    assert len_0 >= 0 and len_0 <= 4
    len_1 = len(schema_instance_1)
    assert len_1 >= 3 and len_1 <= 4


# Generated at 2022-06-26 10:36:54.890996
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    m: typing.Mapping[str, typing.Any] = {}
    c: Schema = Schema(m)
    c.fields = {"c": None, "d": None, "a": None, "b": None}
    c.a = 123
    c.b = 456
    c.d = 789


# Generated at 2022-06-26 10:37:03.637369
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema.make_validator(schema_definitions_0)
    #  (0)
    expected_result_0 = 'Object(properties={}, required=[])'
    actual_result_0 = schema_0.__repr__()
    assert actual_result_0 == expected_result_0
    #  (1)
    schema_definitions_1 = SchemaDefinitions()
    schema_1 = Schema.make_validator(schema_definitions_1)
    expected_result_1 = 'Object(properties={}, required=[])'
    actual_result_1 = schema_1.__repr__()
    assert actual_result_1 == expected_result_1
    #  (2)

# Generated at 2022-06-26 10:37:12.506174
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    object_14 = object()
    object_15 = object()
    object_16 = object()
    object_17 = object()
    object_18 = object()
    object_19 = object()
    object_20 = object()
    object_21 = object()
    object_22 = object()
   

# Generated at 2022-06-26 10:37:22.487065
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema()

    # Test non-sparse
    # Error raised as len(schema_0) is greater than number of elements in schema_0.fields
    with pytest.raises(AttributeError):
        len(schema_0) == len(schema_0.fields)

    # Test sparse
    # Error raised as len(schema_0) is less than number of elements in schema_0.fields
    schema_1 = Schema()
    schema_1.name = "test"
    with pytest.raises(AttributeError):
        len(schema_1) == len(schema_1.fields)


# Generated at 2022-06-26 10:37:31.096333
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    expected = None
    actual = schema_0.__iter__()
    assert actual == expected, "actual: {} expected: {}".format(actual, expected)



# Generated at 2022-06-26 10:37:38.247884
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field_0 = Integer()

    class TestSchema_0(Schema):
        field_0 = Integer()
        field_1 = Reference("TestSchema")

    test_schema = TestSchema()
    test_schema_0 = TestSchema_0()
    set_definitions(test_schema, schema_definitions_0)
    set_definitions(test_schema_0, schema_definitions_0)



# Generated at 2022-06-26 10:38:19.104494
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Test data
    reference_0 = []
    reference_1 = []
    reference_2 = []
    schema_definition_0 = SchemaDefinitions()
    reference_3 = []
    reference_4 = []
    reference_5 = []
    reference_6 = []
    reference_7 = []
    reference_8 = []
    reference_9 = []
    reference_10 = []
    schema_definition_1 = SchemaDefinitions()
    reference_11 = []
    reference_12 = []
    reference_13 = []
    reference_14 = []
    reference_15 = []
    reference_16 = []
    reference_17 = []
    reference_18 = []
    reference_19 = []
    reference_20 = []
    schema_definition_2 = SchemaDefinitions()
    reference_21 = []
   

# Generated at 2022-06-26 10:38:24.283845
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class BookSchema(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        author = Reference('AuthorSchema')
        title = Field(str)

    book = BookSchema({'title':'The title'})
    iterator = iter(book)
    assert next(iterator) == 'title'


# Generated at 2022-06-26 10:38:26.781736
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema()
    schema_1 = Schema(schema_0)
    assert type(schema_1) == Schema


# Generated at 2022-06-26 10:38:32.803260
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()

    class Foo_1(Schema):
        x = Field()
        y = Field()

    schema_definitions_0["Foo"] = Foo_1
    foo_0 = Foo_1(x=1, y=2)
    foo_1 = Foo_1(x=2, y=2)
    foo_2 = Foo_1(x=1, y=1)
    foo_3 = Foo_1(x=2, y=1)
    foo_4 = Foo_1(x=1, y=3)
    foo_5 = Foo_1(x=2, y=3)
    foo_6 = Foo_1(x=2)
    foo_7 = Foo_1(x=3)
    # Line 13

# Generated at 2022-06-26 10:38:37.091711
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0['Foo'] = Foo
    reference_0 = Reference(to=schema_definitions_0['Foo'], definitions=schema_definitions_0)
    with pytest.raises(ValidationError):
        field_1 = reference_0.validate(None)



# Generated at 2022-06-26 10:38:41.233520
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0["test_case_0"] = test_case_0

    class test_class_0(Schema):
        property_0 = Reference("test_case_0")
        property_1 = None
    assert iter(test_class_0()) == iter(["property_0"])



# Generated at 2022-06-26 10:38:53.259285
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test with value that creates an instance of class SchemaMetaclass
    arg_0 = collections.namedtuple("x", [])
    arg_0.__bases__ = []
    arg_0.__dict__ = {}
    arg_1 = collections.namedtuple("x", [])
    arg_1.__bases__ = []
    arg_1.__dict__ = {}
    arg_2 = collections.namedtuple("x", [])
    arg_2.__bases__ = []
    arg_2.__dict__ = {}
    arg_3 = collections.namedtuple("x", [])
    arg_3.__bases__ = []
    arg_3.__dict__ = {}
    test_obj = SchemaMetaclass()

# Generated at 2022-06-26 10:39:01.161694
# Unit test for constructor of class Schema
def test_Schema():
    args = ()
    kwargs = {'strict': True}
    TestSchema = Schema
    TestSchema.__init__(TestSchema, *args)
    TestSchema.__init__(TestSchema, **kwargs)
    TestSchema.__init__(TestSchema, *args, **kwargs)

    TestSchema.validate_or_error(TestSchema, *args, **kwargs)


# Generated at 2022-06-26 10:39:02.871273
# Unit test for constructor of class Schema
def test_Schema():
    pass


# Generated at 2022-06-26 10:39:10.985660
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = Schema.__class__
    class_1 = Schema
    field_0 = Field
    schema_0 = Schema(id=field_0(id=field_0(id=field_0(id=field_0(id=field_0())))))
    assert schema_0.__repr__() == "Schema(id={}) [sparse]"


# Generated at 2022-06-26 10:40:23.565592
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    """
     Tests for the auto-generated method SchemaMetaclass.__new__
    """
    new_type = SchemaMetaclass.__new__(  # type: ignore
        SchemaMetaclass, "name", bases, attrs, definitions
    )
    assert new_type == "name"
    assert new_type == "name"



# Generated at 2022-06-26 10:40:27.952622
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = Schema
    str_0 = class_0.__name__
    str_1 = str_0
    assert str_1 == 'Schema'


# Generated at 2022-06-26 10:40:31.280206
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    schema_0 = schema_0.__len__()


# Generated at 2022-06-26 10:40:45.199846
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_1 = SchemaDefinitions()
    schema_0 = Schema()
    assert schema_0.fields == {}
    schema_1 = Schema(schema_0)
    assert schema_1.fields == {}
    schema_2 = Schema(schema_0, field_1 = Array(Integer()))
    assert schema_2.fields == {'field_1': Array(Integer())}
    schema_3 = Schema(field_2 = Array(Integer()))
    assert schema_3.fields == {'field_2': Array(Integer())}
    schema_4 = Schema(field_3 = Array(Integer()), field_4 = Array(Integer()))
    assert schema_4.fields == {'field_3': Array(Integer()), 'field_4': Array(Integer())}

    # Test exception

# Generated at 2022-06-26 10:40:58.308120
# Unit test for constructor of class Schema
def test_Schema():
    def test_0():
        schema_definitions_0 = SchemaDefinitions()
        object_0 = Schema(**{})
        object_1 = Schema(schema_definitions_0)

    def test_1():
        """
        __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None
        """
        schema_definitions_0 = SchemaDefinitions()

        # Test normal instantiation of schema with no-args
        object_0 = Schema(**{})
        assert isinstance(object_0, Schema) is True
        assert object_0.fields == {}

        # Test normal instantiation of schema with all-kwargs
        object_1 = Schema(schema_definitions_0)
        assert isinstance(object_1, Schema) is True
       