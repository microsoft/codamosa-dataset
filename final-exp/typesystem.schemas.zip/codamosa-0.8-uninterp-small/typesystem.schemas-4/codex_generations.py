

# Generated at 2022-06-26 10:31:15.133811
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_0 = Schema()
    with pytest.raises(KeyError):
        schema_0.__getitem__(0)


# Generated at 2022-06-26 10:31:20.988494
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions =SchemaDefinitions()

    a_reference = Reference(to="a", definitions=schema_definitions)
    set_definitions(a_reference, schema_definitions)
    assert a_reference.definitions == schema_definitions

    a_array_1 = Array(items=a_reference)
    set_definitions(a_array_1, schema_definitions)
    assert a_array_1.items.definitions == schema_definitions

    a_array_2 = Array(items=[a_reference])
    set_definitions(a_array_2, schema_definitions)
    assert a_array_2.items[0].definitions == schema_definitions

    a_array_3 = Array(items=(a_reference, a_reference))

# Generated at 2022-06-26 10:31:26.671813
# Unit test for method validate of class Reference
def test_Reference_validate():
    import json
    from typing import List, List, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, bool, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional, Optional

# Generated at 2022-06-26 10:31:39.195548
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    class Car(Schema):
        colour = Field()
        year = Field()

    class Boat(Schema):
        colour = Field()
        year = Field()


# Generated at 2022-06-26 10:31:51.416389
# Unit test for function set_definitions
def test_set_definitions():
    test_field = Field(name="test_field", required=True)
    test_reference = Reference(name="test_reference", to="string")
    test_array = Array(name="test_array", items=test_reference)
    test_object = Object(name="test_object", properties={"field_1": test_reference})

    test_schema_definitions = SchemaDefinitions()

    set_definitions(test_field, test_schema_definitions)
    set_definitions(test_reference, test_schema_definitions)
    set_definitions(test_array, test_schema_definitions)
    set_definitions(test_object, test_schema_definitions)

    assert test_schema_definitions == {}



# Generated at 2022-06-26 10:31:54.998324
# Unit test for function set_definitions
def test_set_definitions():
    assert set_definitions(Field(), SchemaDefinitions()) # pass
    assert set_definitions(Array(), SchemaDefinitions()) # pass
    assert set_definitions(Object(1,2), SchemaDefinitions()) # pass

# Generated at 2022-06-26 10:31:58.140025
# Unit test for function set_definitions
def test_set_definitions():
    set_definitions(False, [])



# Generated at 2022-06-26 10:32:00.377402
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    test_0 = Schema()
    assert set(test_0.__iter__()) == set()


# Generated at 2022-06-26 10:32:07.029774
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class T(Schema):
        field_0 = Field()

    instance_0 = T(field_0=1)
    instance_1 = T(field_0=1)
    instance_2 = T(field_0=2)
    instance_3 = T(field_0=1, field_1=2)
    int_0 = instance_0
    int_1 = instance_1
    int_2 = instance_2
    str_0 = instance_1
    str_1 = instance_2
    # Warning: Undefined variable 'str_2'
    int_3 = instance_3
    # Warning: Undefined variable 'str_3'
    assert instance_0 == int_0
    assert instance_0 == int_1
    assert instance_0 == str_0
    assert not instance_0 == int_2


# Generated at 2022-06-26 10:32:09.546802
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema(**{"first": "Ken", "last": "Thompson"})
    assert len(schema_0) == 2


# Generated at 2022-06-26 10:32:23.493983
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema()


# Generated at 2022-06-26 10:32:27.279297
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    new_type = SchemaMetaclass.__new__(SchemaMetaclass, 'Schema', (), {}, schema_definitions_0)
    assert type(new_type) == type


# Generated at 2022-06-26 10:32:34.896549
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class Schema_0(Schema, metaclass=SchemaMetaclass):
        fields = {}
    expected_result = (0 == len(Schema_0()))
    actual_result = (0 == len(Schema_0()))
    run_and_verify_test(expected_result, actual_result, test_case_0)


# Generated at 2022-06-26 10:32:46.648332
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import error_messages, fields

    test_Reference_0 = Reference(to="test_target_0", definitions=test_case_0.schema_definitions_0)
    assert test_Reference_0.to == "test_target_0"
    assert test_Reference_0.definitions == test_case_0.schema_definitions_0
    assert test_Reference_0.target == test_case_0.schema_definitions_0["test_target_0"]
    assert isinstance(test_Reference_0.errors, error_messages.ErrorMessages)
    assert test_Reference_0.errors.messages == {"null": "May not be null."}
    assert test_Reference_0.allow_null is False
    assert test_Reference_0.description is None
    assert test_Reference_

# Generated at 2022-06-26 10:32:48.744030
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # test with valid parameter (self)
    schema_0 = Schema()
    for s in schema_0:
        pass



# Generated at 2022-06-26 10:32:52.119528
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert setup_Schema_0.__eq__(setup_Schema_1)
    assert not setup_Schema_0.__eq__(setup_Schema_2)



# Generated at 2022-06-26 10:32:55.212174
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema(arg0=None, arg1=None)
    assert isinstance(schema_0.__iter__(), typing.Iterator)



# Generated at 2022-06-26 10:33:03.719572
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Create a new class.
    # Create a new class.
    class_name = "SomeClass"
    bases = ()
    attrs = {}
    class_ = SchemaMetaclass.__new__(
        SchemaMetaclass,  # type: ignore
        class_name,
        bases,
        attrs,
        definitions=None,
    )
    # class_ should be a type object.
    assert isinstance(class_, type)
    # Check that the attributes of class_ have been correctly set.
    assert class_name == class_.__name__
    assert bases == class_.__bases__
    assert attrs == class_.__dict__


# Generated at 2022-06-26 10:33:08.685173
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema(Schema):
        field_0 = Reference('ToDo')

    todo_schema = TestSchema.validate([])
    assert todo_schema == TestSchema(field_0=None)


# Generated at 2022-06-26 10:33:14.393349
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = Schema(schema_definitions_0)
    class_0.fields = {"r0": "r1"}
    assert class_0.__iter__() == {"r0": "r1"}


# Generated at 2022-06-26 10:33:43.982191
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        id = Integer(name="id")
        name = String(max_length=64, name="name")

    reference_0 = Reference(
        to=User,
        definitions=SchemaDefinitions(),
        description="Describes a user of the API.",
        allow_null=False,
    )
    value_0 = reference_0.validate({"id": 1, "name": "alice"})
    assert isinstance(value_0, User)
    assert value_0.id == 1
    assert value_0.name == "alice"

    reference_1 = Reference(
        User,
        definitions=schema_definitions_0,
        description="Describes a user of the API.",
        allow_null=False,
    )
    value_1 = reference_1.validate

# Generated at 2022-06-26 10:33:51.655762
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_1 = SchemaDefinitions()
    class UserSchema(Schema):
        first_name = String(max_length=255)
        last_name = String(max_length=255)
    user_schema_0 = UserSchema(first_name='John', last_name='Doe')
    assert tuple(user_schema_0) == (
        'first_name',
        'last_name',
    )


# Generated at 2022-06-26 10:33:52.927629
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    assert len(schema) == 0


# Generated at 2022-06-26 10:33:59.970032
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema0(Schema, metaclass=schema_definitions_0):
        first_name = Field()
        last_name = Field()
    class TestSchema1(Schema, metaclass=schema_definitions_0):
        first_name = Field()
        last_name = Field()
    class TestSchema2(Schema, metaclass=schema_definitions_0):
        first_name = Field()
        last_name = Field()
    class TestSchema3(Schema, metaclass=schema_definitions_0):
        first_name = Field()
        last_name = Field()
    class TestSchema4(Schema, metaclass=schema_definitions_0):
        first_name = Field

# Generated at 2022-06-26 10:34:02.531144
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    assert schema_0 is not None

# Generated at 2022-06-26 10:34:11.519282
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    # assert schema_0.__len__() == 0
    schema_0 = Schema()
    schema_1 = Schema(schema_0)
    # assert schema_1.__len__() == 0
    schema_0 = Schema()
    schema_1 = Schema(schema_0)
    # assert schema_1.__len__() == 0
    schema_class_2 = Schema(name=str, age=int)
    schema_2 = Schema(schema_class_2(name='Hugh', age=21))
    # assert schema_2.__len__() == 2

# Generated at 2022-06-26 10:34:17.906694
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test that creating a class with a field of type
    # `typesystem.Reference` that has a string target but no `definitions`
    # attribute raises an exception.
    class Schema_0(Schema):
        field_0 = Reference(to="Reference_0")
    try:
        _ = Schema_0()
    except:
        pass
    else:
        assert False

test_case_0()



# Generated at 2022-06-26 10:34:30.995090
# Unit test for constructor of class Reference
def test_Reference():
    reference_instance_0 = Reference(to='', definitions=None, default=None, enum=None, enum_values=None)
    assert reference_instance_0.validation_regex is None
    assert reference_instance_0.description is None
    assert reference_instance_0.example is None
    assert reference_instance_0.title is None
    assert reference_instance_0.validation_error is not None
    assert reference_instance_0.to is ''
    assert reference_instance_0.target_string is ''
    assert reference_instance_0.target is None
    assert reference_instance_0.definitions is None
    assert reference_instance_0.allow_null is False
    assert reference_instance_0.has_default is False
    assert reference_instance_0.default is None
    assert reference_instance_0.enum

# Generated at 2022-06-26 10:34:34.676344
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()

    try:
        int_0 = len(schema_definitions_0)
    except TypeError:
        int_0 = -1
    assert int_0 == 0



# Generated at 2022-06-26 10:34:44.163618
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    class_name_0 = schema_0.__class__.__name__
    assert class_name_0 == "Schema"
    fields_0 = schema_0.fields
    assert fields_0 == {}
    schema_0_0 = Schema(schema_definitions_0)
    class_name_0_0 = schema_0_0.__class__.__name__
    assert class_name_0_0 == "Schema"
    fields_0_0 = schema_0_0.fields
    assert fields_0_0 == {}
    item = tuple(schema_0_0)
    assert item == ()

# Generated at 2022-06-26 10:35:18.726547
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class MySchema(Schema, definitions=schema_definitions_0):
        class_attribute_0 = '\x7f'
        class_attribute_1 = '!'
        class_attribute_2 = '\xbb'
    schema_0 = MySchema()
    # The returned iterator should iterate over ['class_attribute_0', 'class_attribute_1', 'class_attribute_2'].
    assert list(schema_0.__iter__()) == ['class_attribute_0', 'class_attribute_1', 'class_attribute_2']


# Generated at 2022-06-26 10:35:26.093837
# Unit test for constructor of class Schema
def test_Schema():
    schema_1_fields = {'name': Field(max_length=10), 'age': Field(minimum=18)}
    schema_1_attrs = {'fields': schema_1_fields}
    test_0_schema_1 = SchemaMetaclass.__new__(SchemaMetaclass, 'Person', (object,), schema_1_attrs, None)
    name = 'Bill'
    age = 19
    person = test_0_schema_1(name = name, age = age)
    assert(person == {'name': name, 'age': age})


# Generated at 2022-06-26 10:35:32.738367
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class_type_0 = Schema
    class_type_0.validate({})
    class_type_0.validate({"hello": "world"}, strict=True)
    class_type_0.validate_or_error({})
    class_type_0.validate_or_error({"hello": "world"}, strict=True)
    class_type_0.make_validator()
    class_type_0.make_validator(strict=False)
    # TODO: investigate why this fails with is not None assertion error
    # class_type_0.__class__.__call__(class_type_0, {})
    # class_type_0.__class__.__call__(class_type_0, {"hello": "world"})

# Generated at 2022-06-26 10:35:33.735535
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    test_case_0()

# Generated at 2022-06-26 10:35:40.384250
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Initialize arguments
    args = []

    # Set up context
    schema_definitions_0 = SchemaDefinitions()

    # Call method(s)
    result = Schema.__iter__(schema_definitions_0, *args)

    assert isinstance(result, Iterator)



# Generated at 2022-06-26 10:35:49.839912
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class Copy(Schema):
        url = String()
        resource = Reference('Resource', definitions=schema_definitions_0)
    schema_definitions_0['Copy'] = Copy
    class Scene(Schema):
        number = String()
        raw = String()
        copies = Array(Reference('Copy', definitions=schema_definitions_0))
    schema_definitions_0['Scene'] = Scene
    schema_definitions_0 = SchemaDefinitions()
    class Title(Schema):
        filename = String()
        scenes = Array(Reference('Scene', definitions=schema_definitions_0))
    schema_definitions_0['Title'] = Title
    schema_definitions_0 = SchemaDefinitions()
    class Book(Schema):
        filename = String

# Generated at 2022-06-26 10:36:01.730152
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Create the class argument `attrs`
    attrs = {}
    # Create the positional argument `bases`
    bases = tuple()
    # Create the positional argument `name`
    name = "MySchema"
    # Create the positional argument `definitions`
    definitions = SchemaDefinitions()
    # Evaluate method `__new__`
    first_result = SchemaMetaclass.__new__(SchemaMetaclass, name, bases, attrs, definitions)
    # Verify the result
    assert isinstance(first_result, type)
    assert issubclass(first_result, Schema)
    assert issubclass(first_result, Mapping)
    assert first_result.__name__ == "MySchema"
    # Evaluate method `__new__`

# Generated at 2022-06-26 10:36:13.507320
# Unit test for constructor of class Schema
def test_Schema():
    book_schema = Schema(
        {
            "title": "Refactoring",
            "author": "Martin Fowler",
            "isbn": "ISBN-13: 978-0201485677",
            "publication_date": datetime.date(2018, 7, 22),
        }
    )
    assert book_schema.is_sparse is False
    assert book_schema.title == "Refactoring"
    assert book_schema.author == "Martin Fowler"
    assert book_schema.isbn == "ISBN-13: 978-0201485677"
    assert book_schema.publication_date == datetime.date(2018, 7, 22)

# Generated at 2022-06-26 10:36:18.638490
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    user1 = User(name='foo')
    user2 = User(name='bar')

    assert user1 == User(name='foo')
    assert not (user1 == User(name='bar'))

    assert user1 != user2
    assert not (user1 != User(name='foo'))

# Generated at 2022-06-26 10:36:33.945788
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    """
    Tests __repr__ for case 0 of Schema class
    """
    schema_definitions_0 = SchemaDefinitions()
    class Pet(Schema):
        __qualname__ = "Pet"
        name = Field(str)
        age = Field(int)
    schema_definitions_0[Pet.__qualname__] = Pet
    pet_0 = Pet("fluffy", age=2)
    pet_1 = Pet("humuhumu", age=2)
    assert (pet_0 != pet_1)
    assert (len(pet_0) == 2)
    assert (pet_0["age"] == 2)
    assert (
        repr(pet_0)
        == "Pet(name='fluffy', age=2)"
    )



# Generated at 2022-06-26 10:37:11.728045
# Unit test for constructor of class Schema
def test_Schema():
    test = Schema(class_name=None, fields={})
    assert test is not None


# Generated at 2022-06-26 10:37:12.554281
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    test_case_0()


# Generated at 2022-06-26 10:37:14.559383
# Unit test for constructor of class Schema
def test_Schema():
    test_ = Schema(test_case_0())


# Generated at 2022-06-26 10:37:25.697807
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.compat import name_of_type
    from typesystem.fields import String
    from typesystem.schema import SchemaMetaclass
    from typesystem.schema import Schema
    # Testing class SchemaMetaclass

    def create_SchemaMetaclass_instance_0():
        # Test has 1 assert: AssertionError.
        # The following call:
        SchemaMetaclass(
            # name: str
            "Foo",
            # bases: typing.Sequence[type]
            [Schema],
            # attrs: dict
            {"foo": String()},
            # definitions: SchemaDefinitions
            schema_definitions_0,
        )


# Generated at 2022-06-26 10:37:36.842467
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_cls_0 = type(
        "Person",
        (Schema,),
        {"fields": {"name": {"type": "string"}, "age": {"type": "integer"}}},
        schema_definitions_0,
    )
    schema_instance_0 = schema_cls_0()
    missing_fields = [field for field in schema_instance_0 if not hasattr(schema_instance_0, field)]
    msg = r"'Person' instance has missing fields: {missing_fields!r}"
    assert not missing_fields, msg.format(missing_fields=missing_fields)


# Generated at 2022-06-26 10:37:38.375127
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert Schema(foo=1).__eq__(Schema(foo=1)) == True


# Generated at 2022-06-26 10:37:44.233005
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema(Schema, metaclass=SchemaMetaclass):
        test_field_0 = Field()
        test_field_1 = Field()
        test_field_2 = Field()
    schema_instance_0 = TestSchema(test_field_0=1, test_field_1=1, test_field_2=1)
    assert schema_instance_0 == schema_instance_0
    assert tuple(schema_instance_0) == ('test_field_0', 'test_field_1', 'test_field_2')


# Generated at 2022-06-26 10:37:46.771121
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    test_case_0()


# Generated at 2022-06-26 10:37:48.239205
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()



# Generated at 2022-06-26 10:37:59.444878
# Unit test for constructor of class Reference
def test_Reference():
    a = SchemaDefinitions()
    # for case 0
    a = Reference(to = "test_class", definitions = schema_definitions_0)
    assert type(a) == Reference
    assert isinstance(a, Field)
    assert a.to == "test_class"
    assert a.definitions == schema_definitions_0
    assert a.description == 'Reference to another schema.'
    assert a.allow_null == False
    assert a.required == False
    assert a.name == None
    assert a.error_messages == {
        'null': 'May not be null.'
    }
    target_string = a.target_string
    assert a.target_string == target_string
    target = a.target
    assert a.target == target
    # validate
    value, error = a.validate_or

# Generated at 2022-06-26 10:39:45.519303
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Arrange
    strict = True
    target = Array(items=String())
    to = None
    allow_null = True
    test_Reference = Reference(to=to, allow_null=allow_null, definitions=None)

    value = [["a"]]
    result = target.validate(value, strict=strict)

    # Act
    actual_result = test_Reference.validate(value, strict=strict)

    # Assert
    assert value == actual_result, "Expected value to be equal to actual_result"



# Generated at 2022-06-26 10:39:52.620699
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    definitions = SchemaDefinitions()

    class TestSchema0(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        name = Field(type="string")

    TestSchema0.validate({})  # no exceptions

    class TestSchema1(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        name = Field(type="string")
        address = Field(type="string")

    TestSchema1.validate({})  # no exceptions

# Generated at 2022-06-26 10:39:58.555116
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():

    from typesystem.definitions.schema import Schema
    schema_0 = Schema()
    str_0 = schema_0.__iter__()
    assert True



# Generated at 2022-06-26 10:40:05.300899
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Car(Schema):
        make = Field(str)
        model = Field(str, required=False)
        year = Field(int)

    schema_definitions_0 = SchemaDefinitions()

    schema_0 = Car(make="ford",year=2009)
    value_0 = schema_0.__getitem__("make")
    value_1 = schema_0.__getitem__("model")
    value_2 = schema_0.__getitem__("year")

    # This should fail with a KeyError
    # value_3 = schema_0.__getitem__("color")


# Generated at 2022-06-26 10:40:15.438982
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Document(Schema):
        uuid = str

    class DocumentSchema(Schema):
        document = Reference('Document')
    doc_dict = {'document': {'uuid': 'test'}}
    doc_schema = DocumentSchema(doc_dict)
    # Uncomment the following to test that an exception is raised
    # doc_schema = DocumentSchema({'document': {'uuid': None}})
    # Uncomment the following to test that an exception is raised
    # doc_schema = DocumentSchema({'document': None})
    print(doc_schema.document)

if __name__ == "__main__":
    test_case_0()
    test_Reference_validate()

# Generated at 2022-06-26 10:40:24.417101
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_1['test_schema_4'] = Schema.make_validator(strict=True)
    schema_1 = Schema(strict=True).validate(schema_definitions_1, strict=True)
    schema_1_instance = schema_1.validate(schema_1, strict=True)
    assert not schema_1_instance == {}


# Generated at 2022-06-26 10:40:37.085193
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    field = Field()

    name = 'Test'
    bases = (Schema,)
    attrs = {'foo': field}
    definitions = SchemaDefinitions()

    # Call SchemaMetaclass.__new__() as if it were called from the body of
    # the class statement for a class with the given arguments.
    new_type = SchemaMetaclass.__new__(
        SchemaMetaclass, name, bases, attrs, definitions)

    # Test the output
    assert hasattr(new_type, 'fields')
    assert len(new_type.fields) == 1
    assert list(new_type.fields.keys()) == ['foo']
    assert list(new_type.fields.values())[0] is field

    # Test that Reference fields are correctly configured
    field = Reference('Test')
    attrs

# Generated at 2022-06-26 10:40:41.882926
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    assert schema_0 == schema_0
    try:
        assert False
        raise RuntimeError("AssertionError expected")
    except AssertionError:
        pass


# Generated at 2022-06-26 10:40:47.999632
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Create a new Schema named "Test" with fields
    Test = type("Test", (), {"fields": {"my_field": Field()}})

    # Instantiate an instance of class "Test" named "test"
    test = Test()

    # Create a new empty integer variable named "length"
    length = 0

    # Iterate over the fields in the Schema "test"
    for i in test.fields:
        # Increment the integer variable "length" by one
        length += 1

    # Assert that that the integer variable "length" equals 1
    assert length == 1


# Generated at 2022-06-26 10:40:53.845658
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert (len(list(schema_0.__iter__())) == 0)
    assert((len(list(schema_0.__iter__())) == 0))
