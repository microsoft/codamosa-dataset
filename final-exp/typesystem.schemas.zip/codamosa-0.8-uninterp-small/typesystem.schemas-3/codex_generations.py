

# Generated at 2022-06-26 10:31:16.318874
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()

    # Call method __getitem__
    schema_0 = Schema()
    schema_0.__getitem__("lxfqxv")


# Generated at 2022-06-26 10:31:18.612500
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = SchemaMetaclass(str, list(), dict(), schema_definitions_0)
    assert isinstance(class_0, type)
    assert class_0.__name__ == str


# Generated at 2022-06-26 10:31:21.389034
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Test that the __repr__ method returns the correct string
    schema = Schema(
        name="foo",
        bar=True,
        baz=45,
        quux=None,
    )

    assert repr(schema) == "Schema(bar=True, baz=45, name='foo')"


# Generated at 2022-06-26 10:31:22.982489
# Unit test for constructor of class Reference
def test_Reference():
    # Test arguments
    to = "string"
    definitions = typing.Union[str, Schema]()
    # No exception thrown
    Reference(to, definitions)



# Generated at 2022-06-26 10:31:28.100862
# Unit test for constructor of class Schema

# Generated at 2022-06-26 10:31:32.040075
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    class Pupil(Schema, metaclass=SchemaMetaclass):
        pupil_id = fields.Integer()
        pupil_name = fields.String()
    pupil_0 = Pupil(pupil_id=5, pupil_name=5)
    pupil_1 = Pupil(pupil_id=5, pupil_name=5)
    pupil_2 = Pupil(pupil_id=5, pupil_name=5)
    pupil_3 = Pupil(pupil_id=4, pupil_name=4)
    pupil_4 = Pupil(pupil_name=5)
    pupil_5 = Pupil(pupil_id=5)
    pupil_6 = Pupil()


# Unit

# Generated at 2022-06-26 10:31:36.005064
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    instance = Schema()
    assert (
        repr(instance) == "Schema()"
    ), f"{instance.__repr__()} does not match 'Schema()'"


test_case_0()

# Generated at 2022-06-26 10:31:44.553754
# Unit test for constructor of class Reference
def test_Reference():
    to = "Any"
    definitions = SchemaDefinitions()

    # No parameter given
    reference_0 = Reference(to=to, definitions=definitions)
    assert reference_0.to == "Any"
    assert reference_0.definitions == definitions
    assert reference_0.label == None
    assert reference_0.description == ""
    assert reference_0.allow_null == False
    assert reference_0.error_messages == {"null": "May not be null."}

    # All parameters given
    label = "Any"
    description = "Any"
    allow_null = True
    error_messages = {"Any": "Any"}
    reference_1 = Reference(to=to, definitions=definitions, label=label, description=description, allow_null=allow_null, error_messages=error_messages)


# Generated at 2022-06-26 10:31:54.591141
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    def test_case_0():
        class Bar(Schema):
            name = String()

        class Foo(Schema):
            name = String()
            bar = Object("Bar", properties={"foo": Bar(required=True)})
        foo = Foo({"name": "foo", "bar": {"foo": {"name": "foo"}}})

    def test_case_1():
        class Bar(Schema):
            name = String()

        class Foo(Schema):
            name = String()
            bar = Object("Bar", properties={"foo": Bar(required=True)})
        foo = Foo({"name": "foo", "bar": {"foo": {"name": "foo"}}})

    def test_case_2():
        class Bar(Schema):
            name

# Generated at 2022-06-26 10:32:05.181698
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    schema_fields_0 = {}
    schema_class_name_0 = "TestSchema"
    schema_kwargs_0 = {}
    schema_bases_0 = ()
    schema_class_0 = SchemaMetaclass(
        schema_class_name_0, schema_bases_0, schema_kwargs_0, schema_definitions_0
    )
    schema_attrs_0 = {"fields": schema_fields_0}
    schema_mcs_0 = type(schema_class_0)
    schema_mcs_0.__new__(
        schema_mcs_0, schema_class_name_0, schema_bases_0, schema_attrs_0, schema_definitions_0
    )
    schema_inst_

# Generated at 2022-06-26 10:32:20.409630
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    class Schema_0(Schema):
        field_0 = Field()
        field_1 = Field()
        field_2 = Field()
        field_3 = Field()
    instance_test_case_0 = Schema_0(field_0=3, field_1=3, field_2=3)
    assert 3 == len(instance_test_case_0)


# Generated at 2022-06-26 10:32:20.987223
# Unit test for constructor of class Schema
def test_Schema():
    test_schema = Schema()



# Generated at 2022-06-26 10:32:24.137185
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()

    assert (len(schema_definitions_0) == 0)


# Generated at 2022-06-26 10:32:34.896633
# Unit test for constructor of class Schema
def test_Schema():
    """
    Schema constructor
    """
    schema_definitions_0 = SchemaDefinitions()

    with pytest.raises(AssertionError):
        class Person(Schema):
            first_name = String()
            last_name = String()

        person = Person(1, 2, 3)

    with pytest.raises(AssertionError):
        class Person(Schema):
            first_name = String()
            last_name = String()

        person = Person(None, None, None)

    class Person(Schema):
        first_name = String()
        last_name = String()

    class Person2(Schema):
        first_name = String()
        last_name = String()

    class Author(Schema):
        name = Object(properties={"name": String()})

# Generated at 2022-06-26 10:32:41.318794
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    assert [key for key in schema_0] == []


# Generated at 2022-06-26 10:32:53.027156
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        pass
    class B(Schema):
        pass
    class C(Schema):
        pass
    class D(Schema):
        pass
    class E(Schema):
        pass
    class F(Schema):
        pass
    class G(Schema):
        pass
    class H(Schema):
        pass
    class I(Schema):
        pass
    class J(Schema):
        pass


    schema_definitions_1 = SchemaDefinitions()
    set_definitions(A,schema_definitions_1)
    set_definitions(B,schema_definitions_1)
    set_definitions(C,schema_definitions_1)
    set_definitions(D,schema_definitions_1)

# Generated at 2022-06-26 10:32:56.531482
# Unit test for constructor of class Reference
def test_Reference():
    target = "target"
    definitions = "definitions"
    schema_0 = Reference(target, definitions)
    assert schema_0.target_string == target
    assert schema_0.target == definitions


# Generated at 2022-06-26 10:32:58.513050
# Unit test for constructor of class Reference
def test_Reference():
    schema_definitions_0 = SchemaDefinitions()
    try:
        Reference(to="", definitions=schema_definitions_0)
    except (AssertionError):
        print("AssertionError")
    except (TypeError):
        print("TypeError")


test_Reference()

# Generated at 2022-06-26 10:33:00.307865
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:33:11.008571
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    # test_object_0 is the instance that will be tested by this unit test.
    test_object_0 = SchemaMetaclass("test_object_0", [], {}, schema_definitions_0)
    try:
        # Call method __new__ with arguments test_object_0, "test_object_0", [], {}, schema_definitions_0
        # method __new__ returns schema_definitions_0
        schema_definitions_0 = test_object_0.__new__("test_object_0", [], {}, schema_definitions_0)
    except Exception as e:
        print("Error, unexpected exception:", e)
    else:
        print("Expected exception; did not occur.")


# Generated at 2022-06-26 10:33:29.285225
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    test_case_0()


# Generated at 2022-06-26 10:33:42.276625
# Unit test for method validate of class Reference
def test_Reference_validate():

    class Item(Schema):
        slug = Field(name="slug", type=str)
        price = Field(name="price", type=int)

    class ItemList(Schema):
        items = Field(name="items", type=Array(Reference(Item, definitions=schema_definitions_0)), required=True)

    test_data_0 = [
        {"slug": "big-mac", "price": 2},
        {"slug": "cheeseburger", "price": 1},
        {"slug": "mcflurry", "price": 1},
    ]
    test_data_1 = [
        {"slug": "big-mac", "price": 2},
        {"slug": "cheeseburger", "price": 1},
        {"slug": "mcflurry", "price": 1},
    ]

# Generated at 2022-06-26 10:33:43.368064
# Unit test for constructor of class Schema
def test_Schema():
    #test_case_0()
    pass



# Generated at 2022-06-26 10:33:51.177767
# Unit test for constructor of class Reference
def test_Reference():
    to = "test_to"
    definitions = {"test": 1}
    test_Reference_0 = Reference(to)
    assert test_Reference_0.to == "test_to"
    assert test_Reference_0.definitions is None
    test_Reference_1 = Reference(to, definitions=definitions)
    assert test_Reference_1.to == "test_to"
    assert test_Reference_1.definitions == {"test": 1}
    return

# Generated at 2022-06-26 10:33:55.717018
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_1 = SchemaDefinitions()
    Reference(to="Foo", definitions=schema_definitions_1)
    assert (
        len(schema_definitions_1._definitions) == 0
    ), f"Expected: 0, Actual: {len(schema_definitions_1._definitions)}"


# Generated at 2022-06-26 10:34:05.874842
# Unit test for constructor of class Reference
def test_Reference():
    definitions = SchemaDefinitions()

    class Person(Schema):
        name = Field(str)
        age = Field(int)
        home = Reference("Address", definitions=definitions)

    class Address(Schema):
        street = Field(str)
        city = Field(str)

    definitions["Address"] = Address

    person = Person(
        name="Alice",
        age=42,
        home=Address(
            street="Citing Road", city="San Francisco"
        ),
    )
    print(person)

    assert person["name"] == "Alice"
    assert person["age"] == 42
    assert person["home"]["street"] == "Citing Road"
    assert person["home"]["city"] == "San Francisco"

# Generated at 2022-06-26 10:34:10.842154
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_1 = SchemaDefinitions()
    class FooSchema(Schema):
        foo = Field()
        bar = Field()

    foo_schema_1 = FooSchema()

    assert sorted(foo_schema_1.__iter__()) == ['bar', 'foo']


# Generated at 2022-06-26 10:34:23.711980
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = String()

    class Company(Schema):
        people = Array(items=Reference("Person"))

    assert Company.fields["people"].definitions is None
    schema_definitions_0 = SchemaDefinitions()
    set_definitions(Company.fields["people"], schema_definitions_0)
    assert Company.fields["people"].definitions == schema_definitions_0


# Generated at 2022-06-26 10:34:29.402667
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    test_case_0()
    currtest = Schema()
    currtest['a'] = 4
    assert currtest['a'] == 4
    currtest['b'] = 3
    currtest['c'] = 2
    assert currtest['c'] == 2
    v1 = currtest.__getitem__('c')
    assert v1 == 2


# Generated at 2022-06-26 10:34:33.344887
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert (
        Schema(type_=str, max_length=255).__eq__(
            Schema(type_=str, max_length=255)
        )
        is True
    )


# Generated at 2022-06-26 10:35:17.223042
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    class Dummy(Schema):
        pass
    Dummy_0 = Dummy()
    Dummy_1 = Dummy(field=0)
    Dummy_2 = Dummy(field=0, field_0=1)
    assert len(Dummy_0) == 0
    assert len(Dummy_1) == 1
    assert len(Dummy_2) == 2


# Generated at 2022-06-26 10:35:17.826929
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-26 10:35:19.469567
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    a = SchemaDefinitions()
    assert len(a) == 0


# Generated at 2022-06-26 10:35:20.122080
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass



# Generated at 2022-06-26 10:35:28.842902
# Unit test for constructor of class Schema
def test_Schema():
    # Test issue #24
    class FooSchema(Schema):
        foo = Field(str)

    foo = FooSchema()
    assert isinstance(foo, FooSchema)
    assert foo.foo is None

    foo = FooSchema({"foo": ""})
    assert isinstance(foo, FooSchema)
    assert foo.foo == ""

    foo = FooSchema(foo="")
    assert isinstance(foo, FooSchema)
    assert foo.foo == ""

    foo = FooSchema(foo=None)
    assert isinstance(foo, FooSchema)
    assert foo.foo is None

    schema_definitions_0 = SchemaDefinitions()

    class FooSchema(Schema):
        foo = Field(str)


    foo = FooSchema()

# Generated at 2022-06-26 10:35:30.262127
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    user_schema_0 = Schema()
    str_0 = str(user_schema_0)
    

# Generated at 2022-06-26 10:35:42.318886
# Unit test for method validate of class Reference

# Generated at 2022-06-26 10:35:46.944480
# Unit test for constructor of class Schema
def test_Schema():
    field_0 = Object()
    field_1 = Object()
    definition_0 = {'field_0': field_0, 'field_1': field_1}
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0, field_1, field_0)


# Generated at 2022-06-26 10:35:53.948197
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    class_name_0 = "Person"
    arguments_0 = { }
    argument_str_0 = ""
    sparse_indicator_0 = " [sparse]"
    ret_val_0 = f"{class_name_0}({argument_str_0}){sparse_indicator_0}"
    class Person(Schema, definitions = schema_definitions_0):
        format = "email"
        email = String()
        first_name = String(required = False)
        last_name = String(required = False)

        def has_email(self):
            pass

    ret_val_1 = scheme_Person.__repr__()

    assert (ret_val_0 == ret_val_1)


# Generated at 2022-06-26 10:35:56.986180
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    set_definitions(schema_definitions_0, schema_definitions_0)


# Generated at 2022-06-26 10:37:15.724184
# Unit test for function set_definitions
def test_set_definitions():
    class_0 = type.__new__(Reference, "Reference", (Field,), {"__module__": ""})
    class_1 = type.__new__(Object, "Object", (Field,), {"__module__": "", "properties": {}})
    class_2 = type.__new__(Array, "Array", (Field,), {"__module__": "", "items": None})
    class_3 = type.__new__(Schema, "Schema", (object,), {"__module__": "", "fields": {}})

    set_definitions(class_0, None)
    set_definitions(class_1, None)
    set_definitions(class_2, None)
    set_definitions(class_3, None)


# Generated at 2022-06-26 10:37:22.006904
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    class User(Schema, definitions=schema_definitions_0):
        id = Field(type="integer")
        name = Field()
        age = Field(type="number")

    user_0 = User(
        id=0,
        name="Qohelet",
        age=26,
    )
    assert len(user_0) == 3


# Generated at 2022-06-26 10:37:27.236941
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()

    def definitions_test_0(x : "TestSchema")-> Field:
        return x

    # Set schema_definitions_0['TestSchema'] = definitions_test_0
    assert (schema_definitions_0['TestSchema'] == definitions_test_0)


# Class TestSchema used for unit test for class Schema

# Generated at 2022-06-26 10:37:35.848993
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    arg0 = type('Schema', (Schema,), {'fields': {'field_0': Field(description='description_0'), 'field_1': Field(description='description_1')}})
    arg1 = schema_definitions_0
    arg2 = arg0('', arg1=arg1)
    arg3 = arg2.__iter__()
#    assert arg3 == ['field_0', 'field_1']


# Generated at 2022-06-26 10:37:43.856832
# Unit test for constructor of class Schema
def test_Schema():
    # Scenario 1 - data = {'name': 'foo', 'age': 12}
    schema = Schema(name='foo', age=12)
    assert schema.name == 'foo'
    assert schema.age == 12
    # Scenario 2 - data = {'name': 'foo'}
    schema = Schema(name='foo')
    assert schema.name == 'foo'
    assert schema.age == None
    # Scenario 3 - data = {'name': 'foo', 'age': 12, 'skills': [1, 2, 3]}
    schema = Schema(name='foo', age=12, skills=[1, 2, 3])
    assert schema.name == 'foo'
    assert schema.age == 12
    assert schema.skills == [1, 2, 3]
    # Scenario 4 - data = {'sk

# Generated at 2022-06-26 10:37:54.709526
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    """
    Example 0
    ---------
    In class 'Person', if arguments are a list of key, value pairs, this
    should be shown in a dictionary literal in the representation.

    >>> class Person(Schema):
    ...     first_name = String()
    ...     last_name = String()
    ...     age = Integer()
    ...
    >>> repr(Person(first_name="Joe", last_name="Bloggs", age=44))
    "Person({'age': 44, 'first_name': 'Joe', 'last_name': 'Bloggs'})"
    """
    pass


# Generated at 2022-06-26 10:37:55.603556
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass



# Generated at 2022-06-26 10:37:56.840912
# Unit test for constructor of class Schema
def test_Schema():
    # Test all the possible parameters
    pass



# Generated at 2022-06-26 10:37:59.241048
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    _obj = Schema()
    _r = iter(_obj)
    assert isinstance(_r, typing.Iterator)


# Generated at 2022-06-26 10:38:02.447246
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    assert isinstance(schema_0, Schema)


# Generated at 2022-06-26 10:38:47.023192
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    case_0_instance_0 = Schema()
    case_0_instance_1 = Schema()
    assert (case_0_instance_0 == case_0_instance_1)


# Generated at 2022-06-26 10:38:49.081000
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()


# Generated at 2022-06-26 10:38:55.285206
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        x = Field(Integer())
        y = Field(Integer(), default=5)
    assert repr(TestSchema(x=10)) == 'TestSchema(x=10)'
    assert repr(TestSchema(x=10, y=7)) == 'TestSchema(x=10, y=7)'
    assert repr(TestSchema()) == 'TestSchema(y=5)'
    assert repr(TestSchema(y=None)) == 'TestSchema(y=None)'
    assert repr(TestSchema(y=None)) == 'TestSchema(y=None)'
    assert repr(TestSchema(y=None)) == 'TestSchema(y=None)'
    assert repr(TestSchema(y=None)) == 'TestSchema(y=None)'

# Unit test

# Generated at 2022-06-26 10:39:01.654783
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = Field(type_=str)
        age = Field(type_=int)
        class Meta:
            type_name = "Person"
    schema_definitions_0 = SchemaDefinitions()
    Person.fields["name"] = Field(type_=str, required=True)
    Person.validate({"name": "George"}, strict=False)

# Generated at 2022-06-26 10:39:13.334559
# Unit test for constructor of class Reference
def test_Reference():
    from datetime import datetime

    class B(Schema):
        id = Field(type="string")

    class A(Schema):
        b = Reference("B")

    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_1["B"] = B

    # Test 1
    _value = A({})
    _result = _value.b
    assert isinstance(_result, type(None))

    # Test 2
    _value = A(B(id="123"))
    _result = _value.b
    assert _result == {'id':'123'}

    # Test 3
    _value = A({"b":B(id="123")})
    _result = _value.b
    assert _result == {'id':'123'}

    # Test 4
    _value = A

# Generated at 2022-06-26 10:39:21.568698
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_1 = SchemaDefinitions()
    class User(Schema):
        name = Field(type="string")
        age = Field(type="number", default=10)
    user = User(name="John Doe")
    assert isinstance(user, User)
    assert user.name == "John Doe"
    assert user.age == 10


# Generated at 2022-06-26 10:39:33.260834
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Tests for cases with multiple classes

    # Trying to make a schema with conflicting definitions:

    class A(Schema):
        _id = Field(String)

    class B(Schema):
        _id = Field(String)

    with pytest.raises(AssertionError) as e:
        class C(A, B):
            pass
    assert "Definition for 'A' has already been set." in str(e.value)

    # Trying to make a schema with no definitions:

    class D(Schema):
        class_id = Reference("A")

    with pytest.raises(AssertionError) as e:
        class E(D):
            pass
    assert "String reference missing 'definitions'." in str(e.value)

    # Trying to make a schema that references a definition that doesn't exist:


# Generated at 2022-06-26 10:39:44.928167
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = test_case_0()
    # Test with __getattr__ and __getattribute__ as methods to return an object’s attributes.
    # Test with __init__ as a method that initializes the object’s state.
    # Test with __getitem__ as a method to return an item from the object’s container.

    from typing import Any, Iterator, List
    from typesystem import Schema, Object

    class TestSchema(Schema):
        a = Object(properties={"b": str})

    schema = TestSchema(a={"b": "x"})
    assert list(schema) == ["a"]
    assert list(schema.a) == ["b"]
    assert schema.a.b == "x"


# Generated at 2022-06-26 10:39:54.588295
# Unit test for constructor of class Schema
def test_Schema():
    field_0 = str
    fields_0 = {
        "a": field_0,
        "b": field_0,
    }
    schema_0 = Schema(
        "b",
        fields=fields_0,
    )
    assert isinstance(schema_0, Mapping)
    result = schema_0 == schema_0
    assert result is True
    assert schema_0.fields == fields_0
    assert schema_0.is_sparse is True
    schema_1 = Schema(
        "a",
        fields=fields_0,
    )
    assert isinstance(schema_1, Mapping)
    result = schema_1 == schema_1
    assert result is True
    assert schema_1.fields == fields_0
    assert schema_1.is_sparse is True
    schema

# Generated at 2022-06-26 10:40:00.862104
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()

    class UserSchema(Schema, definitions=schema_definitions_0):
        username = Field()
        password = Field()

        def __init__(self, password: str, username: str):
            self.password = password
            self.username = username

    user_schema_0 = UserSchema(password="password", username="username")
    assert len(user_schema_0) == 2


# Generated at 2022-06-26 10:40:46.585638
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Test with an example.
    class GeoLocation(Schema):
        latitude: float
        longitude: float
        timestamp: float = None

    geo_location_0 = GeoLocation(latitude=0.0, longitude=0.0)
    assert repr(geo_location_0) == "GeoLocation(latitude=0.0, longitude=0.0)"


# Generated at 2022-06-26 10:40:57.639578
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.types import Boolean
    a_1 = String('name', title='Name', max_length=5, min_length=2)
    a_2 = Boolean('is_staff', title='Is staff', true_values=(1, '1'), false_values=(0, '0'))
    a_0 = Schema('User', title='User', definitions=schema_definitions_0, fields={'name': a_1, 'is_staff': a_2})
    a_3 = Reference(a_0, title='A reference')
    assert isinstance(a_3, Reference)
