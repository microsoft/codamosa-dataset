

# Generated at 2022-06-26 10:31:31.642700
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    test_case_0()



# Generated at 2022-06-26 10:31:38.344235
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema(Schema, metaclass=SchemaMetaclass):
        schema_definitions = schema_definitions_0
        a = Field(type="string")
        b = Field(type="string")
    assert repr(TestSchema()) == 'TestSchema()'


# Generated at 2022-06-26 10:31:39.665542
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:31:48.736566
# Unit test for function set_definitions
def test_set_definitions():
    # Test if the function will throw an exception when encountering a `Reference` field
    # that already has a `definitions` property set.
    field_0 = Reference("Self")
    field_0.definitions = {}
    definitions_0 = SchemaDefinitions()
    with pytest.raises(AssertionError) as error:
        set_definitions(field_0, definitions_0)
    assert "Definition for 'Self' has already been set." in str(error.value)


# Generated at 2022-06-26 10:31:51.028606
# Unit test for constructor of class Schema
def test_Schema():
    try:
        Schema()
    except TypeError as e:
        assert "argument for Schema()" in str(e)
    else:
        assert False


# Generated at 2022-06-26 10:32:03.196011
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    class Meta_0(SchemaMetaclass):
        def __new__(cls: type, name: str, bases: typing.Sequence[type], attrs: dict, definitions: SchemaDefinitions = None) -> type:
            fields: typing.Dict[str, Field] = {}
            for key, value in list(attrs.items()):
                if isinstance(value, Field):
                    attrs.pop(key)
                    fields[key] = value

            # If this class is subclassing other Schema classes, add their fields.

            for base in reversed(bases):
                base_fields = getattr(base, "fields", {})

# Generated at 2022-06-26 10:32:08.893756
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = type.__new__(
        SchemaMetaclass, "Class0", (), {"fields": {},}, schema_definitions_0,
    )
    instance_0 = Schema()
    str_0 = repr(instance_0)
    assert str_0 == "Class0()"


# Generated at 2022-06-26 10:32:16.137592
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = schema_definitions_0["SomeSchema"]
    try:
        print(schema_0)
    except Exception as inst:
        print(type(inst))
        print(inst.args)
        print(inst)


if __name__ == "__main__":
    test_cases = [
        test_case_0,
    ]
    for test_case in test_cases:
        test_case()

# Generated at 2022-06-26 10:32:25.961144
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class Schema_0(Schema):
        p0 = 1
        p1 = 2
        p2 = 3
        p3 = 4
        p4 = 5
    schema_definitions_0['Schema_0'] = Schema_0
    schema_0 = Schema_0()
    for _ in schema_0:
        pass


# Generated at 2022-06-26 10:32:28.926870
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    result_0 = len(schema_0)
    assert result_0 == 0


# Generated at 2022-06-26 10:32:43.718623
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    print("Test __eq__ of Schema")
    schema_definitions_0 = SchemaDefinitions()
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 10:32:46.338389
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0


# Generated at 2022-06-26 10:32:51.240576
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # This test currently fails due to the properties of the fields
    # not being serialized to.
    class A(Schema):
        name = Field(type=str)

    a0 = A({"name": "a"})
    a1 = A({"name": "a"})
    assert a0 == a1



# Generated at 2022-06-26 10:32:56.489390
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Statements below are expected to raise a KeyError exception.
    try:
        schema_0 = Schema()
        schema_0['schema_0']
    except KeyError:
        pass
    else:
        assert False, "Expected a KeyError exception to be raised."


# Generated at 2022-06-26 10:33:05.065875
# Unit test for constructor of class Schema
def test_Schema():
    # Class defined without SchemaDefinitions
    class FooSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        description = Field(type="string", allow_null=True)
    foo_value = {
        "name": "Tom",
        "age": 20,
        "description": None
    }
    # Class definition with SchemaDefinitions
    schema_definitions_1 = SchemaDefinitions()
    class BarSchema(Schema,metaclass=SchemaMetaclass, definitions=schema_definitions_1):
        name = Field(type="string")
        age = Field(type="integer")
        password = Field(type="string")

# Generated at 2022-06-26 10:33:10.022217
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class Foo(Schema):
        bar = Field()

    foo = Foo(bar=42)
    expected = "Foo(bar=42)"
    assert foo.__repr__() == expected

    foo = Foo()
    expected = "Foo([sparse])"
    assert foo.__repr__() == expected



# Generated at 2022-06-26 10:33:21.827993
# Unit test for constructor of class Schema
def test_Schema():
    Case = typing.TypeVar("Case", bound="test_Schema")

    class test_Schema(Schema, metaclass=SchemaMetaclass):

        class_attribute_0: typing.Any = None

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super(test_Schema, self).__init__(*args, **kwargs)

        @classmethod
        def validate(cls: typing.Type[Case], value: typing.Any, *, strict: bool = False) -> Case:
            value = super(test_Schema, cls).validate(value, strict=strict)  # type: ignore
            return cls(value)


# Generated at 2022-06-26 10:33:22.680421
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass


# Generated at 2022-06-26 10:33:30.048726
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    _test_SchemaMetaclass___new__(schema_definitions_0)
    schema_definitions_1 = SchemaDefinitions()
    _test_SchemaMetaclass___new__(schema_definitions_1)
    schema_definitions_2 = SchemaDefinitions()
    _test_SchemaMetaclass___new__(schema_definitions_2)
    schema_definitions_3 = SchemaDefinitions()
    _test_SchemaMetaclass___new__(schema_definitions_3)
    schema_definitions_4 = SchemaDefinitions()
    _test_SchemaMetaclass___new__(schema_definitions_4)


# Generated at 2022-06-26 10:33:33.059055
# Unit test for constructor of class Schema
def test_Schema():
    # Test that __init__() initializes fields correctly
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()


# Generated at 2022-06-26 10:33:54.950702
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    class MediaType(Schema, metaclass=SchemaMetaclass):
        """
        MediaType object allows for a HTTP Content-Type to be referenced.
        """

    # Basic test, using hardcoded values.
    # __init__ has the following arguments:
    # value: None
    # strict: True
    obj_0 = MediaType()

    # Check the return value of __repr__.
    at_most_n_0 = "at most 255"
    min_len_0 = 2
    max_len_0 = 255
    class Parameter(Schema, metaclass=SchemaMetaclass):
        """
        Parameter object allows for a parameter of a media type to be
        referenced.
        """

# Generated at 2022-06-26 10:34:04.638670
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    obj = SchemaMetaclass(
        "Pet",
        (),
        {},
        definitions=schema_definitions_0,
    )
    assert isinstance(obj, SchemaMetaclass)
    assert isinstance(obj, type)
    assert obj.__name__ == "Pet"
    assert obj.__qualname__ == "Pet"
    assert obj.__module__ == "__main__"


assert "Pet" in schema_definitions_0
assert schema_definitions_0["Pet"] is Pet
assert "Pet" in schema_definitions_0
assert schema_definitions_0["Pet"] is Pet



# Generated at 2022-06-26 10:34:16.593695
# Unit test for constructor of class Reference
def test_Reference():
    to_0 = None
    assert to_0 is not None
    definitions_0 = None
    assert definitions_0 is not None
    reference_0 = Reference(to_0, definitions=definitions_0)
    to_1 = "asdf"
    assert to_1 is not None
    definitions_1 = {
        "asdf": Schema,
    }
    assert definitions_1 is not None
    reference_1 = Reference(to_1, definitions=definitions_1)
    to_2 = "asdf"
    assert to_2 is not None
    definitions_2 = {
        "asdf": None,
    }
    assert definitions_2 is not None
    reference_2 = Reference(to_2, definitions=definitions_2)
    reference_3 = Reference("asdf")
    reference_3 = Reference

# Generated at 2022-06-26 10:34:29.457203
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()

    def _test(expected: bool, self_: Schema, other: typing.Any):
        assert isinstance(
            bool(self_ == other),
            bool,
            "The result has type `bool`, not `%s`" % type(bool(self_ == other)),
        )
        if expected:
            assert bool(self_ == other), "Expected `%s` but got `%s`" % (
                expected,
                bool(self_ == other),
            )
        else:
            assert not bool(self_ == other), "Expected `%s` but got `%s`" % (
                expected,
                bool(self_ == other),
            )

    # Test with a Schema instance

# Generated at 2022-06-26 10:34:31.904257
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0.__setitem__("test_0", "test_1")
    assert schema_definitions_0.__getitem__("test_0") == "test_1"
    schema_definitions_0.__setitem__("test_2", "test_3")
    assert schema_definitions_0.__getitem__("test_2") == "test_3"


# Generated at 2022-06-26 10:34:40.061173
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    mock_field = String()
    to_be_called = False
    def call_schema_0() -> None:
        nonlocal to_be_called
        to_be_called = True
    mock_field.definitions = call_schema_0
    set_definitions(mock_field, schema_definitions_0)
    success = not to_be_called
    message = "Expected to_be_called to be False, but it was True"
    assert success, message


# Generated at 2022-06-26 10:34:43.513493
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    case_0 = test_case_0()
    assert len(case_0.schema_definitions_0) == 0
    # Check that case_0.schema_definitions_0._definitions is unchanged
    assert len(case_0.schema_definitions_0._definitions) == 0


# Generated at 2022-06-26 10:34:52.834447
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_1 = SchemaDefinitions()

    class A(Schema, metaclass=SchemaMetaclass):
        pass

    class B(Schema, metaclass=SchemaMetaclass):
        pass

    # Case 1
    with pytest.raises(AssertionError):
        set_definitions(A(), schema_definitions_1)
    set_definitions(B(), schema_definitions_1)


# Generated at 2022-06-26 10:34:56.478880
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0['TestSchema'] = Schema
    assert schema_definitions_0['TestSchema'] == Schema
    assert len(schema_definitions_0) == 1


# Generated at 2022-06-26 10:35:05.563401
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.base import String

    definitions_0 = SchemaDefinitions()
    schema_0: Field = Object(properties={'id': String()})
    schema_1: Field = Object(properties={'name': String()})
    schema_2: Field = Object(properties={'age': String()})
    schema_3: Field = Object(properties={'salary': String()})
    schema_4 = Array(items=Object(properties={'adress': String()}))
    schema_5: Field = Object(properties={'phone': String()})
    schema_6: Field = Object(properties={'photo': String()})
    schema_7: Field = Object(properties={'email': String()})
    schema_8: Field = Object(properties={'password': String()})

# Generated at 2022-06-26 10:35:24.726178
# Unit test for function set_definitions
def test_set_definitions():
    # Case 0
    schema_definitions_0 = SchemaDefinitions()
    field_0 = Reference(to="Foo", definitions=schema_definitions_0)
    set_definitions(field_0, schema_definitions_0)
    assert field_0.definitions is schema_definitions_0
    assert field_0.to == "Foo" and field_0.allow_null == True


# Generated at 2022-06-26 10:35:30.842089
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test case for class `SchemaMetaclass` and method `__new__`
    schema_metaclass_0 = SchemaMetaclass  # type: SchemaMetaclass
    schema_metaclass_1 = SchemaMetaclass(
        "Iterator", (), {}, schema_definitions_0
    )  # type: SchemaMetaclass
    schema_metaclass_2 = SchemaMetaclass(
        "Iterator", (), {}, schema_definitions_0
    )  # type: SchemaMetaclass
    assert not (schema_metaclass_1 == schema_metaclass_2)


# Generated at 2022-06-26 10:35:32.402376
# Unit test for constructor of class Schema
def test_Schema():
    # Initialize of Schema
    test_Schema_0 = Schema()



# Generated at 2022-06-26 10:35:41.146440
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class Foo(Schema, definitions=schema_definitions_0):
        foo = "foo"
        bar = "bar"
    foo = Foo()
    __item_0 = foo.__iter__()
    assert str(__item_0) == '<dict_keyiterator object at 0x106ba0380>'

    assert 'foo' in foo
    assert 'bar' not in foo
    assert 'baz' not in foo


# Generated at 2022-06-26 10:35:44.178521
# Unit test for constructor of class Schema
def test_Schema():
    field_0 = {}   # type: dict
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(field_0, schema_definitions_0)


# Generated at 2022-06-26 10:35:47.903411
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Foo(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        foo = Reference("Foo")
    assert definitions["Foo"] == Foo
    assert Foo.fields["foo"].target == Foo


# Generated at 2022-06-26 10:35:51.143135
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Case 0
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    expected_0 = 0
    actual_0 = len(schema_0)
    assert expected_0 == actual_0, "Test Case 0: Failed"


# Generated at 2022-06-26 10:35:57.116488
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import String

    class TestSchema(Schema):
        name = String(max_length=100)
        age = String()

    schema = TestSchema(name="John Doe", age="20")
    assert repr(schema) == "TestSchema(age='20', name='John Doe')"

# Generated at 2022-06-26 10:36:05.907031
# Unit test for function set_definitions
def test_set_definitions():
    """
    Test the set_definitions function
    """
    # setup
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    # We're only setting definitions on a reference field
    reference_field_0 = Reference("test")
    reference_field_1 = Array(Reference("test"))
    # Will not set the definitions on a non reference field
    int_field_0 = Field(type=int)
    string_field_0 = Field(type=str)

    # call function
    set_definitions(reference_field_0, schema_definitions_0)
    set_definitions(reference_field_1, schema_definitions_1)
    set_definitions(int_field_0, schema_definitions_0)

# Generated at 2022-06-26 10:36:14.742314
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Method resolution order-1: SchemaMetaclass inherits from ABCMeta
    _test_SchemaMetaclass___new__class_mro_0 = [SchemaMetaclass, ABCMeta, type]
    # 
    schema_definitions_0 = SchemaDefinitions()
    # Method resolution order-2: type(Schema) == SchemaMetaclass
    _test_SchemaMetaclass___new__class_mro_1 = type(Schema)
    # 
    schema_definitions_1 = SchemaDefinitions()
    # Method resolution order-3: type("BaseSchema", (Schema,), {}) == SchemaMetaclass
    _test_SchemaMetaclass___new__class_mro_2 = type("BaseSchema", (Schema,), {})
    # 
    schema

# Generated at 2022-06-26 10:36:33.541464
# Unit test for constructor of class Reference
def test_Reference():

    assert Reference(to='to').to == 'to'
    assert Reference(to='to').definitions == None
    assert Reference(to='to')._target == None
    assert Reference(to='to')._target_string == None

# Generated at 2022-06-26 10:36:47.536541
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class BarSchema(Schema):
        name = String(
            min_length=1,
            max_length=100,
            error_messages={
                "null": "May not be null.",
                "min_length": "Ensure this value has at least 1 characters",
                "max_length": "Ensure this value has at most 100 characters",
            },
            help_text="The name of the bar.",
        )

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)

# Generated at 2022-06-26 10:36:53.173156
# Unit test for constructor of class Schema
def test_Schema():
    from unittest import TestCase

    from typesystem.fields import Array, Boolean, String

    class TestSchema0(Schema):
        name = String(min_length=2, max_length=10)
        active = Boolean(default=True)
        id = Array(items=String)
        value = Array(items=Array(items=Boolean))

    try:
        TestSchema0()
    except Exception:
        TestCase().fail("Expected constructor to succeed.")
    else:
        TestCase().assertEqual(TestSchema0.fields["name"].validate("a"), "a")
        TestCase().assertEqual(TestSchema0.fields["active"].validate(True), True)
        TestCase().assertEqual(TestSchema0.fields["active"].validate(False), False)
       

# Generated at 2022-06-26 10:36:55.073423
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    test_case_0()



# Generated at 2022-06-26 10:37:03.711435
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # __len__: Return the number of fields, sparsely populated.

    class ExampleSchema(Schema):
        first_name = Field(str)
        last_name = Field(str, default="Unknown")
        age = Field(int, default=10)

    schema_0 = ExampleSchema(first_name="Barack", last_name="Obama")
    len(schema_0) == 2

    schema_1 = ExampleSchema(last_name="Obama", age=57)
    len(schema_1) == 2

    schema_2 = ExampleSchema()
    len(schema_2) == 0

    class TestSchema(Schema):
        value = Field(int)

    schema_3 = TestSchema(value=37)
    len(schema_3) == 1



# Generated at 2022-06-26 10:37:06.330899
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    test_Schema = Schema()
    assert test_Schema.fields == {}
    assert repr(test_Schema) == "Schema()"


# Generated at 2022-06-26 10:37:16.278889
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    # Test case 0
    # This test case is used to verify that the constructor of the class Schema
    # can create an instance of this class without inputting any arguments.
    schema_0 = Schema()
    # Test case 1
    # This test case is used to verify that the constructor of the class Schema
    # can create an instance of this class by inputting the instance of class SchemaDefinitions as well as several Field objects.
    class Schema_1(Schema, metaclass=SchemaMetaclass):
        fields = {"name": String(), "email": String(), "age": Integer()}
    schema_1 = Schema_1(schema_definitions_0)
    # Test case 2
    # This test case is used to verify that the constructor of the class Schema


# Generated at 2022-06-26 10:37:27.022032
# Unit test for constructor of class Reference
def test_Reference():
    schema_definitions_0 = SchemaDefinitions()
    # Constructor test
    class_0 = Reference(
        to="Pet",
        definitions=schema_definitions_0
    )
    class_0.validate(None)
    class_0.serialize(None)
    setattr(class_0, "to", "Pet")
    setattr(class_0, "definitions", schema_definitions_0)
    assert class_0.to == "Pet"
    assert class_0.definitions == schema_definitions_0
    # Accessor for property target_string
    assert class_0.target_string == "Pet"
    # Accessor for property target
    assert class_0.target == Pet

# Generated at 2022-06-26 10:37:36.841542
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    assert isinstance(schema_definitions_0, SchemaDefinitions)

    definitions_0 = SchemaDefinitions()
    assert isinstance(definitions_0, SchemaDefinitions)

    int_field_0 = Field()
    assert isinstance(int_field_0, Field)

    person_field_0 = Field()
    assert isinstance(person_field_0, Field)

    person_field_0.set_definitions(definitions_0)

    assert isinstance(definitions_0, SchemaDefinitions)


# Generated at 2022-06-26 10:37:42.010819
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class test_case_1(Schema):
        name = String()

    schema_obj = test_case_1(name="test_case_1")
    assert schema_obj.__repr__() == "test_case_1(name='test_case_1')"

    schema_obj = test_case_1()
    assert schema_obj.__repr__() == "test_case_1() [sparse]"



# Generated at 2022-06-26 10:39:12.098129
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    # Initialise the test class
    test_class = Schema(**{'key_0': 0})

    # Invoke the method to be tested
    test_method = Schema.__repr__(test_class)

    # Assert that the result is correct
    assert test_method == "Schema({})".format(**{'key_0': 0})


# Generated at 2022-06-26 10:39:22.117104
# Unit test for function set_definitions
def test_set_definitions():
    class Address(Schema):
        street = Field()
        city = Field()
        state = Field()

    schema_definitions = SchemaDefinitions()
    field = Reference(to="Address", definitions=schema_definitions)
    set_definitions(field, schema_definitions)
    assert isinstance(field.definitions, SchemaDefinitions)
    assert field.definitions is schema_definitions
    assert "Address" in field.definitions
    assert field.definitions["Address"] is Address



# Generated at 2022-06-26 10:39:33.575611
# Unit test for constructor of class Schema
def test_Schema():
    class ChildSchema(Schema):
        name = String()
        age = Integer()

    class ParentSchema(Schema):
        name = String()
        children = Array(items=ChildSchema)

    schema_definitions_1 = SchemaDefinitions()
    parent_schema_0 = ParentSchema(name="Julian", age=7, children=[])
    assert parent_schema_0.name == "Julian"
    assert parent_schema_0.children == []
    # ParentSchema(name="Julian", age=7, children=[])
    print(parent_schema_0)

    parent_schema_1 = ParentSchema(name="Julian", children=[ChildSchema(name="Tobias")])
    assert parent_schema_1.name == "Julian"

# Generated at 2022-06-26 10:39:42.076950
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Tests that SchemaDefinitions.__getitem__() produces expected output
    schema_definitions_0 = SchemaDefinitions()

    class User(Schema):
        name = Field()

    schema_definitions_0["User"] = User

    def test(self, *args, **kwargs):
        try:
            schema_definitions_0["User"]
        except Exception as e:
            assert False

    test()



# Generated at 2022-06-26 10:39:44.485089
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    int_0 = len(schema_0)


# Generated at 2022-06-26 10:39:49.071410
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = schema_definitions_0['schema_0']()
    schema_0.__len__()


# Generated at 2022-06-26 10:39:51.199164
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_0 = Schema()
    str_0 = schema_0.__getitem__(schema_0)


# Generated at 2022-06-26 10:40:01.678805
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Test for valid class Instance
    first_schemaInstance = schema_definitions_0["First"]()
    second_schemaInstance = schema_definitions_0["Second"]()
    assert (first_schemaInstance == first_schemaInstance) is True
    assert (second_schemaInstance == second_schemaInstance) is True
    assert (first_schemaInstance == second_schemaInstance) is False


# Generated at 2022-06-26 10:40:02.823108
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 10:40:15.334463
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Setup
    def __new__(schema_metaclass: typing.Type[SchemaMetaclass], name: str, bases: typing.Sequence[type], attrs: dict, definitions: typing.Optional[dict]) -> type:
        fields: dict = {}
        for key, value in attrs.items():
            if isinstance(value, Field):
                attrs.pop(key)
                fields[key] = value
        for base in reversed(bases):
            base_fields = getattr(base, "fields", {})
            for key, value in base_fields.items():
                if isinstance(value, Field) and key not in fields:
                    fields[key] = value
        if definitions is not None:
            for field in fields.values():
                set_definitions(field, definitions)