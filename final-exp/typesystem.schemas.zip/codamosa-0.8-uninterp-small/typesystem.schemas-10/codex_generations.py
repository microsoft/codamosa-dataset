

# Generated at 2022-06-26 10:31:22.601569
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_2 = SchemaDefinitions()
    schema_definitions_3 = SchemaDefinitions()

    class Schema_0(Schema):
        schema_definitions_4 = References(
            to="Schema_1", definitions=schema_definitions_2
        )
        schema_definitions_5 = References(
            to="Schema_1", nullable=True, definitions=schema_definitions_3
        )
        schema_definitions_6 = References(
            to="Schema_1", nullable=False, definitions=schema_definitions_1
        )

    assert schema_definitions_3.definitions == {
        "Schema_1": Schema_0
    }

# Generated at 2022-06-26 10:31:27.839027
# Unit test for method __setitem__ of class SchemaDefinitions

# Generated at 2022-06-26 10:31:40.077826
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class SchemaTestCase(Schema):
        test_attribute0 = Field()
        test_attribute1 = Field()
        test_attribute2 = Field()
        test_attribute3 = Field()
        test_attribute4 = Field()
    class_name = SchemaTestCase.__name__
    arguments = {"test_attribute2": 10}
    sparse_indicator = " [sparse]"
    expected = f"{class_name}(test_attribute2={arguments['test_attribute2']!r}){sparse_indicator}"
    actual = repr(SchemaTestCase(**arguments))
    assert expected == actual
    actual = repr(SchemaTestCase(**arguments))
    assert expected == actual
    class_name = SchemaTestCase.__name__


# Generated at 2022-06-26 10:31:51.846013
# Unit test for constructor of class Reference
def test_Reference():
    # Test for TypeError raised for missing keyword argument
    # to
    try:
        Reference()
        assert False, "Expected TypeError to be raised"
    except TypeError:
        pass
    # Test for TypeError raised for keyword argument to
    # with incorrect type
    try:
        Reference(to=1)
        assert False, "Expected TypeError to be raised"
    except TypeError:
        pass
    # Test for TypeError raised for keyword argument
    # definitions
    try:
        Reference(to='x')
        assert False, "Expected TypeError to be raised"
    except TypeError:
        pass
    # Test for TypeError raised for keyword argument
    # definitions

# Generated at 2022-06-26 10:32:03.086477
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import Field, Text

    class Person(Schema):
        name = Text()

    assert Person.validate({"name": "Fred"}).name == "Fred"
    assert Person.validate(Person(name="Fred")).name == "Fred"
    assert Person.validate_or_error({"name": "Fred"}).value.name == "Fred"

    try:
        Person.validate_or_error({"age": 30})
    except ValidationError as error:
        assert error.messages[0].text == "unknown field"
        assert error.messages[0].field_name == "age"
    else:
        assert False, "Validation should have failed"



# Generated at 2022-06-26 10:32:07.659843
# Unit test for function set_definitions
def test_set_definitions():
    fields = {}
    field = Field()
    definitions = {"field": field}
    for key, value in definitions.items():
        assert (
            key not in fields
        ), r"Definition for {key!r} has already been set."
        fields[key] = value

# Generated at 2022-06-26 10:32:14.631912
# Unit test for function set_definitions
def test_set_definitions():
    foo = Schema(
        test_property=String(max_length=10)
    )
    sch = Schema(
        foo=Reference(to=foo)
    )
    defs = SchemaDefinitions()
    set_definitions(sch, defs)
    assert sch.foo.target_string == 'foo'
    assert sch.foo.definitions == defs


# Generated at 2022-06-26 10:32:29.789949
# Unit test for constructor of class Schema
def test_Schema():
    # Test #1
    schema_definitions_0 = SchemaDefinitions()
    definitions_0 = schema_definitions_0

    class TestSchema(Schema, definitions=definitions_0):

        foo = Field()
    schema_0 = TestSchema(foo="bar")
    assert schema_0.foo == "bar"
    assert schema_0.is_sparse
    assert schema_0 == TestSchema(foo="bar")

    # Test #2
    schema_definitions_1 = SchemaDefinitions()
    definitions_1 = schema_definitions_1

    class TestSchema(Schema, definitions=definitions_1):

        foo = Field()
    schema_1 = TestSchema(foo="bar")
    assert schema_1.foo == "bar"
    assert schema_1.is_sparse


# Generated at 2022-06-26 10:32:43.612414
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_1 = SchemaDefinitions()
    class Test(Schema, definitions=schema_definitions_1):
        b = Integer(minimum=0)
        def __iter__(self):
            return super().__iter__()
    test_schema_0 = Test(b=0)
    try:
        for _ in test_schema_0:
            pass
    except Exception as e:
        print(e)
        print(test_schema_0)
    assert (
        list(test_schema_0) == ["b"]
    ), f"Expected: list(test_schema_0) == ['b'] Actual: list(test_schema_0) = {list(test_schema_0)}"


# Generated at 2022-06-26 10:32:54.442555
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()

    def test_case_0():
        class_0 = Schema
        name_0 = "HelloWorld"
        bases_0 = [Schema]
        attrs_0 = {
            "__module__": "example",
            "__qualname__": "example.HelloWorld",
            "message": String(
                description="Greeting to the world",
                title="Message",
                default="Hello World!",
            ),
            "count": Integer(
                description="Number of times to say hello",
                title="Count",
                default=1,
            ),
        }
        definitions_0 = schema_definitions_0


# Generated at 2022-06-26 10:33:32.106599
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    # RandomException raised: 'obj must be str or have a fileno() method.'
    try:
        SchemaMetaclass.__new__()
        assert False
    except Exception as e:
        assert e == 'obj must be str or have a fileno() method.'
    # RandomException raised: 'obj must be str or have a fileno() method.'
    try:
        SchemaMetaclass.__new__(
            'name',
            'bases',
            'attrs',
            definitions=schema_definitions_0,
        )
        assert False
    except Exception as e:
        assert e == 'obj must be str or have a fileno() method.'



# Generated at 2022-06-26 10:33:44.010707
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    # set_definitions() should have no effect on fields that have definitions set
    class B(Schema):
        a = Reference("C")

    assert B.a.definitions is schema_definitions_0
    set_definitions(B.a, schema_definitions_0)
    assert B.a.definitions is schema_definitions_0
    # set_definitions() should set definitions on fields that are None
    class C(Schema):
        b = Reference("D")

    assert C.b.definitions is None
    set_definitions(C.b, schema_definitions_0)
    assert C.b.definitions is schema_definitions_0
    # set_definitions() should recursively set definitions on child fields

# Generated at 2022-06-26 10:33:45.935631
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:33:51.480630
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema(Schema):
        field_0: str
    try:
        assert len(TestSchema.fields) == 1
    except AssertionError as e:
        print("AssertionError: ", e.args)
        raise


# Generated at 2022-06-26 10:33:52.396952
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass


# Generated at 2022-06-26 10:33:58.613264
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass___new__Schema(Schema):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)

    schema_definitions_0 = SchemaDefinitions()
    TestSchemaMetaclass___new__Schema.__new__(
        TestSchemaMetaclass___new__Schema,
        'TestSchemaMetaclass___new__Schema',
        (),
        {},
        definitions=schema_definitions_0,
    )


# Generated at 2022-06-26 10:34:09.530801
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    classes = [
        ('DirectSchema', Schema),
        ('FieldOnSchema', Schema),
        ('SparseSchema', Schema),
        ('SuperSchema', Schema),
    ]
    for class_name, base in classes:
        # class_name: str
        # base: type

        class_attrs = {
            '__module__': 'typesystem.schemas',
            '__qualname__': 'typesystem.schemas.' + class_name,
        }
        if base is not Schema:
            class_attrs['__qualname__'] += '.' + class_name
        namespace = {}
        exec('class %s(%s): pass' % (class_name, base.__name__), namespace)
        defined_class = namespace[class_name]

        assert defined_class

# Generated at 2022-06-26 10:34:16.404312
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    definitions = SchemaDefinitions()

    class MySchema(Schema):
        foo = Field(type="string")
        bar = Reference("AnotherSchema", definitions=definitions)

    class AnotherSchema(Schema):
        foo: Field = Field(type="string")

    return (
        MySchema.fields,
        MySchema({"foo": "abc", "bar": {"foo": "abc"}}),
    )


# Generated at 2022-06-26 10:34:23.114280
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test for case with Schema
    args = ()
    kwargs = {'definitions': {}}
    obj = Schema(*args, **kwargs)
    method = getattr(obj, "__len__")
    result = method()
    assert isinstance(result, int)
    assert [0] == [result]


# Generated at 2022-06-26 10:34:23.901612
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    test_case_0()

test_case_0()
# test_Schema___getitem__()

# Generated at 2022-06-26 10:34:41.610448
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    assert len(schema)  == 0


# Generated at 2022-06-26 10:34:49.014459
# Unit test for constructor of class Schema
def test_Schema():
    # metaclass is ommited, as it's provided by the metaclass 'SchemaMetaclass'
    
    schema_definitions_1 = SchemaDefinitions()
    # 

    class Thing(Schema):
        foo = Field(String())
        bar = Field(Integer())

    test_thing = Thing(foo='123', bar='456')
    test_thing.validate()

    test_thing_2 = Thing({'foo': '123', 'bar': '456'})
    test_thing_2.validate()

    test_thing_3 = Thing(test_thing)
    test_thing_3.validate()

    thing_validator = Thing.make_validator()
    thing_validator.validate({'foo': '123', 'bar': '456'})

    thing_validator_2

# Generated at 2022-06-26 10:34:55.665066
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_1 = SchemaDefinitions()
    class_name = schema_definitions_1.__class__.__name__
    try:
        schema_definitions_1.__len__()
    except NotImplementedError:
        assert False, (
            "Method __len__ should be implemented for class " + class_name
            + "."
        )
    assert True


# Generated at 2022-06-26 10:34:57.283625
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    s = Schema()
    assert str(s) == 'Schema()'


# Generated at 2022-06-26 10:35:03.816353
# Unit test for function set_definitions
def test_set_definitions():
    class AddressSchema(Schema):
        street = Field(label="Street")
        city = Field(label="City")
        zip = Field(label="ZIP")
    class UserSchema(Schema):
        name = Field(label="Name")
        age = Field(label="Age")
        address = Reference(to=AddressSchema)
    class EmployeeSchema(Schema):
        employee_id = Field(label="Employee ID")
        user = Reference(to=UserSchema)
        location = Reference(to="LocationSchema")
    class LocationSchema(Schema):
        location = Field(label="Location")
        field = Field(label="Field")
    def test_case_1():
        schema_definitions_1 = SchemaDefinitions()

# Generated at 2022-06-26 10:35:06.406835
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_0 = Schema()
    schema_0.fields = {'field_0': String()}
    schema_0.field_0 = "Hello"
    try:
        assert schema_0['field_0'] == "Hello"
    except KeyError:
        raise AssertionError


# Generated at 2022-06-26 10:35:08.029085
# Unit test for function set_definitions
def test_set_definitions():
    # Test Cases
    test_case_0()



# Generated at 2022-06-26 10:35:21.007894
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()

    class ArtistSchema(metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        id = Integer()
        name = String()
        age = Integer(default=lambda: 21 + 10)

    assert isinstance(schema_definitions_0, SchemaDefinitions)
    assert isinstance(ArtistSchema, type)
    assert isinstance(ArtistSchema.validate, classmethod)
    assert isinstance(ArtistSchema.validate_or_error, classmethod)
    assert isinstance(ArtistSchema.fields, dict)
    assert isinstance(ArtistSchema.fields["id"], Integer)
    assert isinstance(ArtistSchema.fields["name"], String)
    assert isinstance(ArtistSchema.fields["age"], Integer)
    assert Artist

# Generated at 2022-06-26 10:35:25.369312
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    assert repr(schema_0) == 'Schema()'
    schema_1 = Schema(a=1)
    assert repr(schema_1) == 'Schema(a=1)'


# Generated at 2022-06-26 10:35:32.144532
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    field_0 = Object(
        properties={
            "new_key": Reference("Object"),
            "new_key2": Object(properties={"new_key3": String(max_length=16)}),
        },
        required=["new_key", "new_key2"],
    )
    set_definitions(field_0, schema_definitions_0)
    assert field_0.properties["new_key"].definitions == schema_definitions_0
    assert (
        field_0.properties["new_key2"].properties["new_key3"].definitions
        == schema_definitions_0
    )



# Generated at 2022-06-26 10:35:56.009514
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_1 = SchemaDefinitions()

    class PersonSchema(Schema, definitions=schema_definitions_1):
        name = String()
        age = Integer()

    person = PersonSchema(name="Bob", age=30)
    keys = list(person.keys())
    assert len(keys) == 2
    assert "name" in keys
    assert "age" in keys


# Generated at 2022-06-26 10:36:05.160756
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    # Basic test.
    class ExampleObject0(Schema):
        id = Field()
        name = Field()
        created_at = Field()

    class ExampleObject1(ExampleObject0):
        class Meta:
            strict = True

    example_object_0 = ExampleObject0(
        id=0, name="name", created_at="created_at"
    )
    # Creating a schema from an existing object.
    class ExampleObject2(Schema):
        id = Field()
        name = Field()
        created_at = Field()

    class ExampleObject3(ExampleObject2):
        class Meta:
            strict = True

    example_object_2 = ExampleObject2(
        name="name", created_at="created_at", id=0
    )
   

# Generated at 2022-06-26 10:36:09.500959
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        prop0 = String()
        prop1 = String()
    dict1 = {"prop0": "foo", "prop1": "bar"}
    test_schema_obj = TestSchema(dict1)

# Generated at 2022-06-26 10:36:12.947475
# Unit test for constructor of class Schema
def test_Schema():
    import json
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema()



# Generated at 2022-06-26 10:36:21.418092
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_class_0 = SchemaMetaclass(
        'TestSchema',
        (),
        {
            '__module__': 'test_case_0',
            '__qualname__': 'TestSchema',
            'fields': {
                '_creation_counter': 0,
                'test_0': Field(
                    'test_0',
                    (str,),
                    {
                        'default': None,
                        'description': None,
                        'title': None,
                        'type': 'str'
                    })
            }
        },
        schema_definitions_0,
    )


# Generated at 2022-06-26 10:36:30.819439
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.base import Definition
    from typesystem.fields import Array, Integer

    class TestTarget(Definition):
        test_field_1 = Integer()
        test_field_2 = Integer()

    assert TestTarget.fields.keys() == {"test_field_1", "test_field_2"}

    class TestReference(Reference):
        definitions = SchemaDefinitions()
        definitions["TestReference"] = TestTarget

    assert TestReference.target == TestTarget



# Generated at 2022-06-26 10:36:34.703746
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    reference_0 = Reference(to = 'x')
    set_definitions(field = reference_0, definitions = schema_definitions_0)
    assert reference_0.definitions is schema_definitions_0


# Generated at 2022-06-26 10:36:46.452610
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    class_name_0 = "Schema"
    fields_0 = {
        'x': Integer(minimum=0, maximum=10),
        'y': Integer(minimum=0, maximum=10)
    }
    class_0 = SchemaMetaclass(class_name_0, (), fields_0)
    obj = class_0(2, 3)
    obj.x = 2
    obj.y = 3
    value_0 = obj == obj
    value_1 = obj == 2
    assert value_0 or not value_1  # pass


# Generated at 2022-06-26 10:36:55.318331
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Pet(Schema):
        name = Field(description="Name of the pet.")

    pet_0 = Pet()
    value_0 = pet_0

    # Test for method __getitem__ of class Schema
    def test_Schema___getitem__0():
        assert value_0 == pet_0
    test_Schema___getitem__0()


# Generated at 2022-06-26 10:37:03.779553
# Unit test for function set_definitions
def test_set_definitions():
    class Address(Schema):
        city = Field()
        country = Field()

    class User(Schema):
        id = Field(primary_key=True)
        first_name = Field()
        last_name = Field()
        age = Field()
        address = Reference(Address, definitions={"Address": Address})

    class Group(Schema):
        id = Field(primary_key=True)
        name = Field()
        users = Array(Reference(User, definitions={"User": User}))

    assert User.fields["address"].definitions == {"Address": Address}
    test_group = Group.validate(
        {"id": "Administrators", "name": "Administrators", "users": []}
    )
    assert isinstance(test_group.id, str)

# Generated at 2022-06-26 10:37:29.403046
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Testing with default argument for strict...
    # Testing with default argument for definitions...
    schema_definitions_0 = SchemaDefinitions()
    schema_field_0 = Array(items=Integer())
    schema_field_1 = Integer()
    schema_field_2 = String()
    schema_field_3 = String()
    schema_type_0 = typing.TypeVar("schema_type_0", bound="Schema")
    class SchemaA(Schema, metaclass=SchemaMetaclass):
        items = schema_field_0
        index = schema_field_1
        name = schema_field_2
    schema_field_4 = Array(items=schema_definitions_0[SchemaA])
    schema_field_5 = Integer()
    schema_field_6 = String()
    schema_field_

# Generated at 2022-06-26 10:37:38.399378
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    class Dummy_0(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        dummy_0_0 = int()
        dummy_0_1 = int()
    dummy_instance_0 = Dummy_0(dummy_0_0=1, dummy_0_1=2)
    result = schema_definitions_0
    assert dummy_instance_0.__repr__() == "Dummy(dummy_0_0=1, dummy_0_1=2)"

# Generated at 2022-06-26 10:37:42.056447
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    object0 = Schema()
    object1 = Schema([])
    object2 = Schema([[[[[[object0]]]]]])
    assert str(object0) == "<Schema>"
    assert str(object1) == "<Schema>"
    assert str(object2) == "<Schema>"


# Generated at 2022-06-26 10:37:55.378851
# Unit test for method __repr__ of class Schema

# Generated at 2022-06-26 10:37:59.855098
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_1 = SchemaDefinitions()

    class TestSchema_1(Schema):

        m0 = Reference("entry", definitions=schema_definitions_1)

    obj_1 = TestSchema_1(m0=5).__iter__()
    assert isinstance(obj_1, typing.Iterator)


# Generated at 2022-06-26 10:38:03.046091
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    schema_1 = Schema()
    result = schema_0 == schema_1
    assert result
    print(schema_0)
    print(schema_1)

# Generated at 2022-06-26 10:38:04.854721
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert Schema.__len__(schema_definitions_0) == 0


# Generated at 2022-06-26 10:38:10.126618
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    def check_len(schema, expected):
        assert len(schema) == expected
    schema_0 = Schema({'a': 0, 'c': 2, 'b': 1})
    expected_0 = 3
    check_len(schema_0, expected_0)
    schema_1 = Schema({'a': 0, 'b': 1})
    expected_1 = 2
    check_len(schema_1, expected_1)
    schema_2 = Schema({'c': 2, 'b': 1})
    expected_2 = 2
    check_len(schema_2, expected_2)


# Generated at 2022-06-26 10:38:21.943793
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_1 = SchemaDefinitions()
    schema_definition_1 = {
        "id": 0,
        "type": "string",
    }
    schema_definition_2 = {
        "id": 1,
        "type": "number",
    }
    schema_definitions_1["number"] = schema_definition_1
    schema_definitions_1["string"] = schema_definition_2
    schema_definitions_2 = SchemaDefinitions()
    schema_definition_3 = {
        "ref": "#/definitions/string",
    }
    schema_definition_4 = {
        "type": "object",
        "properties": {
            "ref": schema_definition_3,
        },
    }
    schema_definitions_2["string"] = schema_definition_4
    set

# Generated at 2022-06-26 10:38:29.423414
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    class BasicObjectSchema(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        __qualname__ = 'BasicObjectSchema'
        name = Field(description='The name of the object.\n    ')
        quantity = Field(description='The number of objects.\n    ')
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()
        test_case_0()


# Generated at 2022-06-26 10:38:57.356957
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    case_0 = getattr(test_case_0, "__wrapped__", test_case_0)
    try:
        case_0()
    except TypeError:
        pass


# Generated at 2022-06-26 10:39:04.907078
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import types
    import typing
    class StrictSchema(Schema):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            self.strict = True
            super(args)

    person_0 = StrictSchema([1])
    assert person_0 == 'StrictSchema(age=1)'

    person_1 = StrictSchema([1, 2])
    assert person_1 == 'StrictSchema(age=1, name=2)'

    person_2 = StrictSchema([1, 2, 3])
    assert person_2 == 'StrictSchema(age=1, name=2, [sparse])'

    person_3 = StrictSchema([1, 2, 3, 4])

# Generated at 2022-06-26 10:39:11.365320
# Unit test for function set_definitions
def test_set_definitions():
    class Schema1(Schema):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    schema_definitions_1 = SchemaDefinitions()
    set_definitions(Schema1, schema_definitions_1)
    assert schema_definitions_1['Schema1'] == Schema1


# Generated at 2022-06-26 10:39:17.589976
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test for method __iter__ of class Schema
    # GIVEN
    test_case_0()
    # WHEN
    actual = len(schema_definitions_0)

    # THEN
    assert actual == 0


# Generated at 2022-06-26 10:39:21.833300
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    try:
        arry = Schema(schema_definitions_0)
        print("Success")
    except Exception:
        print("An exception was raised")



# Generated at 2022-06-26 10:39:27.797558
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema(Schema, metaclass=SchemaMetaclass):
        a = Field()
    instance = TestSchema(a='a')
    assert list(instance.__iter__()) == ['a']


# Generated at 2022-06-26 10:39:32.982160
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert Schema(foo=42) == Schema(foo=42)
    assert Schema(foo=42, bar=21) == Schema(foo=42, bar=21)
    assert Schema(foo=42, bar=21) != Schema(foo=43, bar=21)
    assert Schema(foo=42, bar=21) != Schema(foo=42, bar=22)



# Generated at 2022-06-26 10:39:36.812237
# Unit test for method validate of class Reference
def test_Reference_validate():
    try:
        test = Reference.validate(None)
    except TypeError as error:
        print(error)
    else:
        print(test)



# Generated at 2022-06-26 10:39:39.092017
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:39:42.648528
# Unit test for constructor of class Schema
def test_Schema():
    from mytypesystem import Integer, String

    class TestSchema(Schema):
        id = Integer()
        name = String()

    schema_0 = TestSchema(id=1, name="foo")



# Generated at 2022-06-26 10:40:23.206572
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_1 = SchemaDefinitions()
    class User(Schema, definitions=schema_definitions_1):
        id = Field(type="string")
        name = Field(type="string")
    user_0 = User(id="12345", name="John Smith")


# Generated at 2022-06-26 10:40:28.192925
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = SchemaMetaclass(
        "TestSchema",  # name
        (),  # bases
        {},  # attrs
        schema_definitions_0  # definitions
    )
    schema_0 = Schema(
        **{
            "field0": "field0_value",
            "field1": "field1_value",
            "field2": "field2_value",
        }
    )
    field_keys_0 = []
    for key in schema_0:
        field_keys_0.append(key)
    assert field_keys_0 == ["field0", "field1", "field2"]



# Generated at 2022-06-26 10:40:38.137428
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_1 = SchemaDefinitions()
    class FooSchema(Schema):
        bar = Field()
        baz = Field()
        bing = Field()
    expected_length: int = 3
    foo_schema: FooSchema = FooSchema()
    foo_schema.bar = 3
    assert len(foo_schema) == expected_length
    foo_schema.baz = 7
    assert len(foo_schema) == expected_length
    foo_schema.bing = 9
    assert len(foo_schema) == expected_length
    expected_length: int = 2
    foo_schema: FooSchema = FooSchema()
    foo_schema.bar = 3
    assert len(foo_schema) == expected_length
    foo_schema.baz = 7

# Generated at 2022-06-26 10:40:44.550529
# Unit test for constructor of class Schema
def test_Schema():
    class Item(Schema):
        name = String(max_length=50)
        size = String(enum=["small", "medium", "large"])

    class Container(Schema):
        items = Array(of=Reference(to="Item"), max_items=100)
    pass



# Generated at 2022-06-26 10:40:46.767527
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Setup
    class TestSchemaTest(Schema, definitions=schema_definitions_0):
        pass

    # Test
    assert TestSchemaTest in schema_definitions_0
    # Cleanup - none necessary



# Generated at 2022-06-26 10:40:58.840993
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class_name_0 = Schema.__name__
    class_name_1 = Schema.__name__
    class_name_2 = Reference.__name__
    class_name_3 = Reference.__name__
    class_name_4 = Reference.__name__
    class_name_5 = Schema.__name__
    class_name_6 = Schema.__name__
    class_name_7 = Schema.__name__
    class_name_8 = Schema.__name__
    class_name_9 = Schema.__name__

    class One(metaclass=SchemaMetaclass, definitions=schema_definitions_0):

        @dataclass
        class Embedded(Schema):
            one: int