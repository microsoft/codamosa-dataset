

# Generated at 2022-06-26 10:31:39.540520
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    assert schema_0.fields == {}

    schema_1 = Schema(allow_null=False)
    assert schema_1.fields == {}

    schema_2 = Schema(**{"allow_null": False})
    assert schema_2.fields == {}

    schema_3 = Schema(**{"allow_null": False, "description": "A representation of a person with a name"})
    assert schema_3.fields == {}
    assert schema_3.description == "A representation of a person with a name"

    schema_4 = Schema(
        allow_null=False,
        description="A representation of a person with a name",
        title="Person",
    )
    assert schema_4.fields == {}
    assert schema_4.description == "A representation of a person with a name"


# Generated at 2022-06-26 10:31:46.652862
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    #  __iter__: Returns an iterator over the fields.
    assert isinstance(schema_0.__iter__(), collections.abc.Iterator)
    #  __iter__: Returns an iterator over the fields.
    assert isinstance(schema_0.__iter__(), collections.abc.Iterator)


# Generated at 2022-06-26 10:31:48.938398
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert isinstance(schema_0.__iter__(), collections.abc.Iterator)


# Generated at 2022-06-26 10:31:51.535294
# Unit test for constructor of class Reference
def test_Reference():
    a = Reference("x")
    assert a.to == 'x'
    assert a.allow_null == False
    assert a.error_messages == {'null': 'May not be null.'}


# Generated at 2022-06-26 10:31:54.280438
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.compat import case

    with case("test case 0"):
        schema_0 = Schema()



# Generated at 2022-06-26 10:31:58.650794
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()

    expected_result = "Schema()"
    assert schema_0.__repr__() == expected_result


# Generated at 2022-06-26 10:32:00.082327
# Unit test for constructor of class Schema
def test_Schema():
    pass


# Generated at 2022-06-26 10:32:11.514438
# Unit test for method __iter__ of class Schema
def test_Schema___iter__(): 
    schema_0 = Schema()
    schema_0.__class__ = SchemaMetaclass

# Generated at 2022-06-26 10:32:16.965146
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    data = {'a': 1, 'b': 2, 'c': 3}
    obj = Schema(data)
    assert obj['a'] == 1 and obj['c'] == 3 and obj['b'] == 2
    try:
        obj['d']
    except KeyError:
        assert True


# Generated at 2022-06-26 10:32:27.777954
# Unit test for function set_definitions
def test_set_definitions():
    class BaseSchema(Schema):
        a = Reference("c")
        b = Reference("c")

    class Definitions(SchemaDefinitions):
        pass

    definitions = Definitions()
    definitions["c"] = Schema()

    BaseSchema()

    assert BaseSchema.fields["a"].definitions is definitions
    assert BaseSchema.fields["b"].definitions is definitions

    schema_1 = Schema()
    schema_1.fields["a"] = Reference("c")

    assert schema_1.fields["a"].definitions is definitions



# Generated at 2022-06-26 10:32:43.100968
# Unit test for function set_definitions
def test_set_definitions():
    # Create a schema without any definitions
    schema_0 = Schema()
    # Set the definitions property by calling the set_definitions function
    set_definitions(schema_0, SchemaDefinitions)
    # Make sure the definitions property is set
    assert schema_0.definitions is not None


# Generated at 2022-06-26 10:32:52.939068
# Unit test for method validate of class Reference
def test_Reference_validate():
    target = Object(properties={"a": Integer(minimum=5)})
    definitions = SchemaDefinitions()
    ref = Reference("a", definitions=definitions)
    setattr(ref, "_target", target)

    # test result from validation of a non-reference value
    result = ref.validate("test")
    assert result == "test"

    # test result from validation of a reference value
    val = ref.validate({"a": 4})
    assert val == {"a": 4}

    # test error from validation of a reference value that fails validation
    with pytest.raises(ValidationError):
        ref.validate({"a": 3})


# Generated at 2022-06-26 10:33:03.538473
# Unit test for function set_definitions
def test_set_definitions():
    class Vehicle(Schema):
        brand = Reference(to="CarBrand")
        model = str()

    class CarBrand(Schema):
        name = str()
        logo = str()

    class Car(Schema):
        brand = Reference(to=CarBrand)
        model = str()

    bmw = Car(brand=CarBrand(name="BMW", logo="bmw.png"), model="E90")
    print(bmw)
    bmw_validator = Car.make_validator()
    print(bmw_validator)
    print(bmw_validator.validate(bmw))
    print(bmw_validator.validate_or_error(bmw))
    bmw_serialized = bmw_validator.serialize(bmw)

# Generated at 2022-06-26 10:33:12.486997
# Unit test for function set_definitions
def test_set_definitions():
    class DummyClass(Schema):
        pass

    schema_1 = Schema()
    definitions = SchemaDefinitions()
    
    # Test case 1: a reference to another schema
    field_key = 'field_1'
    field_value = Reference(to=DummyClass, definitions=definitions)
    schema_1.fields[field_key] = field_value
    assert schema_1.fields[field_key].definitions is None
    set_definitions(schema_1.fields[field_key], definitions)
    assert schema_1.fields[field_key].definitions is definitions

    # Test case 2: a field containing an array
    field_key = 'field_2'
    field_value = Array(String)
    schema_1.fields[field_key] = field_value
    assert schema_1

# Generated at 2022-06-26 10:33:22.979267
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    # Set the definitions on a Reference field
    schema_1 = Reference
    set_definitions(schema_1, definitions)
    assert schema_1.definitions == definitions

    # Test a simple array of Reference fields
    schema_2 = [
        Reference,
        Reference,
    ]
    set_definitions(schema_2, definitions)
    assert schema_2[0].definitions == definitions
    assert schema_2[1].definitions == definitions

    # Test an array of Reference fields with nested arrays
    schema_3 = [
        Reference,
        [Reference],
    ]
    set_definitions(schema_3, definitions)
    assert schema_3[0].definitions == definitions
    assert schema_3[1][0].definitions == definitions

    # Test an object
   

# Generated at 2022-06-26 10:33:30.531172
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema().validate()
    assert repr(schema_0) == "Schema()"
    schema_1 = Schema(
        {
            "a": Schema({
                "b": Schema({
                    "d": Schema({
                        "g": Schema({
                            "i": Schema({
                                "k": Schema({
                                    "m": Schema({
                                        "o": Schema({
                                            "q": Schema({
                                                "s": Schema({
                                                    "u": Schema({
                                                        "w": Schema()
                                                    })
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        }
    ).validate()

# Generated at 2022-06-26 10:33:32.504995
# Unit test for constructor of class Reference
def test_Reference():
    reference = Reference(int)
    assert isinstance(reference, Reference)

# Generated at 2022-06-26 10:33:41.639836
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    print("\n### Unit test for method __repr__ of class Schema ###\n")
    print("# Test Case 0:")
    test_case_0()
    print("\n# Test Case 1:")
    schema_1 = Schema(a=1, b=2)
    print(schema_1)
    print("\n# Test Case 2:")
    schema_2 = Schema(a=1, b=2, sparse=True)
    print(schema_2)


# Generated at 2022-06-26 10:33:50.065085
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Set up objects
    namespace = {}
    baseargs = []
    d = {'__module__': 'source'}
    # Run the test
    try:
        # This should fail because the two fields are the same
        SchemaMetaclass.__new__(SchemaMetaclass, 'blah', baseargs, d)
    except AssertionError as e:
        assert "'field_0' has already been added" in str(e)


# Generated at 2022-06-26 10:33:53.180368
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class_schema_0 = Schema()
    class_schema_1 = Schema()
    var_1 = isinstance(class_schema_0, class_schema_1)
    assert var_1 == False


# Generated at 2022-06-26 10:34:19.741598
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    foo = Reference("foo", definitions=definitions)
    bar = Reference("bar", definitions=definitions)
    baz = Reference("baz", definitions=definitions)
    qux = Array(Reference("qux", definitions=definitions))

    foobaz = Object(properties={"foo": foo, "bar": bar, "baz": baz})
    qux = Array(qux)

    set_definitions(foobaz, definitions)
    assert foobaz.properties["foo"].definitions is definitions
    assert foobaz.properties["bar"].definitions is definitions
    assert foobaz.properties["baz"].definitions is definitions

    set_definitions(qux, definitions)
    assert qux.items.items.definitions is definitions



# Generated at 2022-06-26 10:34:27.811333
# Unit test for function set_definitions
def test_set_definitions():
    # Basic check that function works
    class_0 = type('class_0', (Schema,), {'one': Reference('class_1')})
    class_1 = type('class_1', (Schema,), {})
    
    test_dict = SchemaDefinitions()
    test_dict['class_1'] = class_1
    set_definitions(class_0.one, test_dict)
    assert class_0.one.target is class_1

# Generated at 2022-06-26 10:34:39.037432
# Unit test for function set_definitions
def test_set_definitions():
    # Set up a dictionary for the definitions.
    definitions = SchemaDefinitions()
    
    # Create a Reference which references the definitions.
    reference = Reference(to="Person", definitions=definitions)
    assert reference.target is None
    assert reference.target_string == "Person"
    
    # Create an Object to be nested.
    nested_object = Object(properties={"name": "Bob"})
    
    # Create an Array to be nested.
    nested_array = Array(items={"name": "Bob"})
    
    # Create a Schema which is to be added to the definitions.
    class Person(Schema):
        name = "Bob"
        age = 12
    assert definitions["Person"] is None
    
    # Create a Schema which is to be nested.

# Generated at 2022-06-26 10:34:48.456297
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():

    # Variable to store lambda function as a callable
    test_function = lambda: None
    # Calling Schema() with no parameters
    schema_1 = Schema()
    # Lambda function to iterate over the items and check if all the values 
    # are of type string
    [test_function(key, type(key)) for key in schema_1]
    for key in schema_1:
        if not isinstance(key, str):
            return False
    # Returning True as all the values in the iteration are of type string
    return True


# Generated at 2022-06-26 10:34:52.243901
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():

    schema_0 = Schema()

    # Test for method __iter__ of class 'Schema'
    assert set(schema_0.__iter__()) == set()


# Generated at 2022-06-26 10:35:02.027682
# Unit test for function set_definitions
def test_set_definitions():
    class TestDefinitions(SchemaDefinitions):
        """
        Wrapper to make testing easier
        """
        def __init__(self) -> None:
            self.definitions = {}
            super().__init__()

    class TestSchema:
        """
        Base class for testing
        """
        def __init__(self, foo: str, bar: str) -> None:
            self.foo = foo
            self.bar = bar

    class SubSchema(TestSchema):
        """
        Subclass of TestSchema
        """
        pass

    test_definitions = TestDefinitions()

    test_schema = TestSchema("Hello", "World")
    test_schema.definitions = test_definitions
    assert test_schema.definitions["TestSchema"] == TestSchema

    sub_sche

# Generated at 2022-06-26 10:35:09.230674
# Unit test for constructor of class Schema
def test_Schema():
    print("\n")
    print("Test case 0")
    test_case_0()

    print("\n")
    print("Test case 1")
    class ObjectType(Schema):
        a = Field(String)
        b = Field(Integer)

        def __init__(self, a: str, b: int) -> None:
            super().__init__(a=a, b=b)

    # Create a new instance of ObjectType
    print("\n")
    print("Test case 1.1")
    instance_0 = ObjectType("hello", 2)
    print("Returned: ", instance_0)
    print("Expected: <__main__.ObjectType a='hello' b=2>")
    assert str(instance_0) == "<__main__.ObjectType a='hello' b=2>"



# Generated at 2022-06-26 10:35:11.931573
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference(to="test")
    assert ref.target_string == "test"
    assert not hasattr(ref, "_target")


# Generated at 2022-06-26 10:35:20.961708
# Unit test for function set_definitions
def test_set_definitions():
    class ClassA(Schema):
        a_field = Reference("ClassB", required=True)

    class ClassB(Schema):
        b_field = Reference("ClassA", required=True)

    def_schema = SchemaDefinitions()
    set_definitions(ClassA.fields["a_field"], def_schema)
    set_definitions(ClassB.fields["b_field"], def_schema)
    assert "ClassA" in def_schema
    assert "ClassB" in def_schema


# Generated at 2022-06-26 10:35:22.907313
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    instance = Schema()
    expected = 0
    actual = len(instance)
    assert actual == expected



# Generated at 2022-06-26 10:35:51.714504
# Unit test for function set_definitions
def test_set_definitions():
    class DefinitionsSubclass(Object):
        properties = {
            "parent": Reference("ObjectType"),
        }
    assert DefinitionsSubclass.properties["parent"].definitions is None
    definitions = SchemaDefinitions()
    set_definitions(DefinitionsSubclass, definitions)
    assert DefinitionsSubclass.properties["parent"].definitions == definitions



# Generated at 2022-06-26 10:35:55.198663
# Unit test for constructor of class Schema
def test_Schema():
    schema_1 = Schema({'field1': 'hello'})
    assert schema_1.field1 == 'hello'


# Generated at 2022-06-26 10:36:00.846833
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Schema0(Schema):
        a = Field()
    class Schema1(Schema):
        a = Reference(to=Schema0)

    schema1 = Schema1()
    s0 = Schema0(a="test")
    assert isinstance(s0, Schema0)
    s1 = Schema1(a=s0)
    assert isinstance(s1, Schema1)


# Generated at 2022-06-26 10:36:02.260021
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass

# Generated at 2022-06-26 10:36:10.856363
# Unit test for function set_definitions
def test_set_definitions():
    class Pet(Schema):
        name = Field()

    class Dog(Pet):
        breed = Field()

    class Person(Schema):
        name = Field()
        pets = Array(Reference("Pet"))

    definitions = SchemaDefinitions()
    set_definitions(Person.pets, definitions)
    assert definitions["Pet"] == Pet
    assert definitions["Dog"] == Dog


# A schema that uses a string-referenced definition.

# Generated at 2022-06-26 10:36:13.712186
# Unit test for constructor of class Schema
def test_Schema():
    # Testing constructor with positional argument
    schema_0 = Schema()
    assert type(schema_0) == Schema


# Generated at 2022-06-26 10:36:21.846097
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    
    schema_0 = Schema()
    
    # Test if `schema_0` is an instance of `Schema`
    test_0_schema_0 = isinstance(schema_0, Schema)
    
    # Test if `iter(schema_0)` is an instance of `collections.abc.Iterator`
    test_1_iter_schema_0 = isinstance(iter(schema_0), collections.abc.Iterator)
    
    assert (test_0_schema_0 == True) & (test_1_iter_schema_0 == True)


# Generated at 2022-06-26 10:36:30.817663
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    # assertRaises(TypeError, 'schema_0.__iter__()')

    a = []

    # Exception raised:
    # In call to len(schema_0.__iter__())
    # TypeError: object of type 'generator' has no len()
    # a.append(len(schema_0.__iter__()))
    assert a == [0]



# Generated at 2022-06-26 10:36:31.729731
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    schema_1 = Schema()
    assert schema_0 == schema_1


# Generated at 2022-06-26 10:36:38.263744
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema()
    assert Schema().fields
    assert Schema().is_sparse
    assert not Schema().fields
    assert Schema("string")
    assert Schema("string", field="value")
    assert not hasattr(Schema("other"), "field")
    assert not hasattr(Schema("other"), "field")
    assert not hasattr(Schema("other", field="value"), "field")
    assert Schema("other", field="value").is_sparse
    assert Schema("other").is_sparse
    assert not Schema("string").is_sparse
    assert Schema("string", field="value").is_sparse
    assert Schema("string").is_sparse
    assert not Schema("string", field="value", field="value").fields

# Generated at 2022-06-26 10:36:55.806899
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    try:
        test_Schema___getitem__0()
    except Exception:
        raise TypeError

# Generated at 2022-06-26 10:37:00.602179
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    schema_0 = Schema()
    schema_1 = Schema()
    set_definitions(schema_0, definitions)
    set_definitions(schema_1, definitions)
    assert schema_0.definitions is definitions
    assert schema_1.definitions is definitions

# Generated at 2022-06-26 10:37:04.088875
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    # Modify
    schema_0_schema_0 = Schema()
    assert schema_0 == schema_0_schema_0


# Generated at 2022-06-26 10:37:05.537731
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema = Schema()
    assert repr(schema) == 'Schema()'


# Generated at 2022-06-26 10:37:15.253132
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Character(Schema):
        name = String(required=True)
        age = Integer()

    definition = SchemaDefinitions()
    definition["Character"] = Character

    class PlayWithCharacter(Schema):
        name = String(required=True)
        submitted_at = Float()
        character = Reference(to="Character", definitions=definition)

    play_with_character = PlayWithCharacter.validate({
        "name": "John Doe",
        "character": {
            "name": "Jack",
            "age": 23
        }
    })
    assert play_with_character.character.name == "Jack"
    assert play_with_character.character.age == 23

if __name__ == "__main__":
    test_Reference_validate()

# Generated at 2022-06-26 10:37:16.160235
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    test_case_0()


# Generated at 2022-06-26 10:37:17.372900
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    assert len(schema) == 0



# Generated at 2022-06-26 10:37:27.565432
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():

    # This is a test for the metaclass of Schema. We need to be able to run
    # this test even when Schema is not yet defined. We use the somewhat
    # hacky technique of using the builtin type() function to create the
    # metaclass instance and then call its __new__ method directly.

    class Meta(SchemaMetaclass):
        pass

    class MySchema(metaclass=Meta):
        a = 1
        b = 2

        fields = {"a": "a", "b": "b"}

        def __init__(self):
            pass

    assert MySchema.a == 1
    assert MySchema.b == 2
    assert MySchema.fields == {"a": "a", "b": "b"}



# Generated at 2022-06-26 10:37:30.901575
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    x = Schema.__getitem__(schema_0, key=key)
    assert isinstance(x, str) or x is None


# Generated at 2022-06-26 10:37:34.001530
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert repr(schema_0) == 'Schema()'

# Generated at 2022-06-26 10:38:17.738183
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Test the validate method of Reference class
    definitions = SchemaDefinitions()

    class ChildSchema(Schema, metaclass=SchemaMetaclass):
        id = Field()

    class ParentSchema(Schema, metaclass=SchemaMetaclass):
        first_name = Field()
        last_name = Field()
        child = Reference("ChildSchema")  # type: ignore

    class GrandparentSchema(Schema, metaclass=SchemaMetaclass):
        parents = Array(Reference("ParentSchema"))  # type: ignore

    class GrandparentSchema2(Schema, metaclass=SchemaMetaclass):
        id = Field()
        parents = Array(Reference("ParentSchema"))  # type: ignore


# Generated at 2022-06-26 10:38:20.045425
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class S0(Schema):
        x = Field()
    s0 = S0(x=1)
    return s0["x"]


# Generated at 2022-06-26 10:38:23.391468
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Testing with no arguments
    test_schema = Schema()
    assert test_schema.__iter__() == [key for key in test_schema.fields if hasattr(test_schema, key)]


# Generated at 2022-06-26 10:38:27.113263
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import unittest

    class Test_SchemaMetaclass___new__(unittest.TestCase):
        def test_case_0(self):
            schema_0 = Schema()

    unittest.main(verbosity=2)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 10:38:28.541858
# Unit test for constructor of class Reference
def test_Reference():
    field_0 = Reference("test", description='test', help_text='test', label='test', name='test', to='test')
    assert field_0.to == 'test'

# Generated at 2022-06-26 10:38:35.530940
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert str(repr(schema_0)) == "Schema()"
    schema_1 = Schema(a=1)
    assert str(repr(schema_1)) == "Schema(a=1)"
    schema_2 = Schema(a=1, b=2)
    assert str(repr(schema_2)) == "Schema(a=1, b=2)"

# Generated at 2022-06-26 10:38:37.797287
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    class_names = []
    for key in schema_0:
        class_names.append(key)
    assert not class_names

test_case_0()

# Generated at 2022-06-26 10:38:41.293222
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Schema
    # Test case 0
    schema_0 = Schema()
    key = ''
    try:
        value = schema_0.__getitem__(key)
    except KeyError:
        value = None
    expected_value = None
    assert value == expected_value


# Generated at 2022-06-26 10:38:43.947570
# Unit test for constructor of class Reference
def test_Reference():
    assert issubclass(Reference, Field)
    obj = Reference(string)
    assert obj.to == string

# Generated at 2022-06-26 10:38:54.099061
# Unit test for constructor of class Reference
def test_Reference():
    def test_0():
        name = "Reference"
        # Test type of 'to'
        to = "1"
        # Test type of 'definitions'
        definitions = {"1": "2"}
        # Test type of 'default_value'
        default_value = 1
        # Test type of 'allow_null'
        allow_null = True
        # Test type of 'validators'
        validators = [lambda x: x]
        # Test type of 'description'
        description = "description"
        # Test type of 'name'
        name = "name"
        # Test type of 'title'
        title = "title"
        # Test type of 'meta'
        meta = {"key": "value"}

# Generated at 2022-06-26 10:39:44.898628
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Example0(Schema):
        field_0 = Array(Field())
        field_1 = Array(Field())

    # Test with arguments: arg_0 = Example0(arg_1 = 1128), arg_1 = Example0(arg_1 = -113)
    arg_0 = Example0(arg_1 = 1128)
    arg_1 = Example0(arg_1 = -113)
    assert (arg_0 != arg_1)

    class Example1(Schema):
        field_0 = Array(Field())
        field_1 = Array(Field())

    # Test with arguments: arg_0 = Example0(arg_1 = -148), arg_1 = Example1()
    arg_0 = Example0(arg_1 = -148)
    arg_1 = Example1()

# Generated at 2022-06-26 10:39:46.273930
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()

# Generated at 2022-06-26 10:39:50.070690
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_1 = type(
        'Schema',
        (),
        {'fields': {}},
    )()
    assert schema_1 == Schema()


# Generated at 2022-06-26 10:39:51.308642
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(schema_0) == 0


# Generated at 2022-06-26 10:39:56.338996
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    result = str(schema_0)
    assert result == "Schema()"


# Generated at 2022-06-26 10:40:01.109823
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    schema_1 = Schema()
    schema_2 = Schema()
    l = []
    for e in schema_2:
        l.append(e)
    assert l == []
    l = []
    for e in schema_1:
        l.append(e)
    assert l == []
    l = []
    for e in schema_0:
        l.append(e)
    assert l == []


# Generated at 2022-06-26 10:40:03.321183
# Unit test for constructor of class Schema
def test_Schema():
    assert str(test_case_0()) == '<__main__.Schema object at 0x7f4c4c0e0b00>'



# Generated at 2022-06-26 10:40:07.767897
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_0 = Schema()

    reference_0 = Reference(to=schema_0)
    reference_0.validate(value=None)



# Generated at 2022-06-26 10:40:09.823920
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert tuple(schema_0) == tuple([])


# Generated at 2022-06-26 10:40:17.031054
# Unit test for function set_definitions
def test_set_definitions():
    schema_1 = Schema(
        foo=Field(), foo_2=Field(), foo_3=Field()
    )
    schema_1_fields = schema_1.fields

    #  Unit test for "assert ( key not in self._definitions )"
    def_schema_2 = SchemaDefinitions()
    def_schema_2[schema_1] = "value 1"
    assert set_definitions(schema_1_fields['foo'], def_schema_2) is None
    assert set_definitions(schema_1_fields['foo_2'], def_schema_2) is None
    assert set_definitions(schema_1_fields['foo_3'], def_schema_2) is None

