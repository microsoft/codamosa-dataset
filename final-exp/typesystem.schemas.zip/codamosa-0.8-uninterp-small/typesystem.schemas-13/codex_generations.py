

# Generated at 2022-06-26 10:31:19.504670
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema(
        first_name="Luke",
        last_name="Skywalker",
    )
    for field in schema:
        assert field in ("first_name", "last_name")


# Generated at 2022-06-26 10:31:25.398908
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_2 = SchemaDefinitions()
    field_1 = Field(required=False, default="foo")
    field_2 = Field(required=True)
    field_3 = Field(required=True)
    reference_1 = Reference("Foo")
    reference_2 = Reference("Foo")
    reference_3 = Reference("Foo")
    set_definitions(field_1, schema_definitions_1)
    assert field_1.definitions is schema_definitions_1
    set_definitions(field_2, schema_definitions_1)
    assert field_2.definitions is schema_definitions_1
    set_definitions(field_3, schema_definitions_2)
    assert field_3.definitions is schema_def

# Generated at 2022-06-26 10:31:37.494195
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
# Test case 0
    schema_definitions_0 = SchemaDefinitions()
    schema_fields_0 = {
        'a': Field(),
        'b': Field(),
        'c': Field(),
        'd': Field(),
        'e': Field(),
        'f': Field(),
    }
    schema_properties_0 = {
        'a': Field(),
        'b': Field(),
        'c': Field(),
        'd': Field(),
        'e': Field(),
        'f': Field(),
    }
    test_class_0 = SchemaMetaclass('test_class', (), {}, schema_definitions_0)

# Generated at 2022-06-26 10:31:45.093452
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class Object1(Schema):
        __qualname__ = 'Object1'
        int1 = Array(
            items=Array(
                items=Number(
                    maximum=5.0,
                    exclusive_maximum=True,
                    minimum=0.0,
                    exclusive_minimum=True,
                )
            )
        )
        int2 = Integer(multiple_of=2)
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self._set_fields()

    # Check default target
    assert isinstance(Object1.fields, dict)

    # Check default target
    assert Object1.is_sparse == False

    # Check default target


# Generated at 2022-06-26 10:31:46.340039
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:31:48.323901
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    ref = Reference('test')
    assert ref.serialize({'a': 1}) == {'a': 1}



# Generated at 2022-06-26 10:31:49.665249
# Unit test for constructor of class Schema
def test_Schema():
    # Constructor test case 0

    result = Schema()


# Generated at 2022-06-26 10:31:54.042627
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()

    # Test cases
    class BaseSchema0(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        class Meta:
            title = "Base Schema 0"
            strict = True
        field0 = Field()
        field1 = Field()

    assert len(BaseSchema0) == 2

    schema0 = BaseSchema0()

    assert len(schema0) == 0

    schema1 = BaseSchema0(field0=0)

    assert len(schema1) == 1


# Generated at 2022-06-26 10:32:02.185368
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    string_ref_field_0 = Reference(to='test')
    field_0 = Array(items=string_ref_field_0)
    set_definitions(field_0, schema_definitions_0)


if __name__ == "__main__":
    monkeypatch.setattr(typesystem.fields.utils, 'get_constraints', lambda *args, **kwargs : None)
    test_set_definitions()

# Generated at 2022-06-26 10:32:04.338256
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert [field for field in Schema().__iter__()] == []



# Generated at 2022-06-26 10:32:26.216870
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Set up some test input
    class_name = "test_case_0"
    schema_definitions_0 = SchemaDefinitions()
    # Call the method under test
    with pytest.raises(NameError):
        eval("{class_name}(schema_definitions_0)".format(class_name=class_name))


# Generated at 2022-06-26 10:32:28.174569
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    schema_1 = Schema()
    assert (schema_0 == schema_1)


# Generated at 2022-06-26 10:32:30.204218
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass # TODO: implement your test here



# Generated at 2022-06-26 10:32:31.805629
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    result = Schema.__iter__
    assert result is not None



# Generated at 2022-06-26 10:32:44.007171
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():  # type: () -> None
    schema_definitions_1 = SchemaDefinitions()
    class_name_1 = "Pet"
    bases_1 = [
        object,
    ]
    attrs_1 = {
        'name': String,
        'type': String,
        'tag': Number,
    }
    name_1 = class_name_1
    definitions_1 = schema_definitions_1
    expected_1 = Schema
    actual_1 = SchemaMetaclass.__new__(SchemaMetaclass, name_1, bases_1, attrs_1, definitions_1)
    assert actual_1 == expected_1



# Generated at 2022-06-26 10:32:50.757360
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_1 = SchemaDefinitions()
    class Case_1(Schema, metaclass=SchemaMetaclass):
        case_1_field_0 = Reference(to='Case_2')
    class Case_2(Schema, metaclass=SchemaMetaclass):
        case_2_field_0 = Reference(to='Case_1')
    set_definitions(Case_1.case_1_field_0, schema_definitions_1)
    set_definitions(Case_2.case_2_field_0, schema_definitions_1)
    assert Case_1.case_1_field_0.definitions == Case_2.case_2_field_0.definitions


# Generated at 2022-06-26 10:32:55.976276
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        name = Field()

    schema_0 = MySchema(name="test")
    expected_0 = False
    actual_0 = schema_0.is_sparse
    assert expected_0 == actual_0



# Generated at 2022-06-26 10:32:57.882910
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference(str)


# Generated at 2022-06-26 10:33:05.270170
# Unit test for function set_definitions
def test_set_definitions():
    def test_set_definitions(self):
        schema_definitions_0 = SchemaDefinitions()
        schema_definitions_0["Schema_definitions_0"] = {"schema_definitions_0": "schema_definitions_0"}
        schema_definitions_0["Schema_definitions"] = schema_definitions_0
        field = self.make_validator()
        self.assertTrue(isinstance(field, type(self.Validator)))
        class_name = self.__class__.__name__
        self.assertEqual(field.__class__.__name__, class_name)
        self.assertEqual(field.__class__.__name__, "Validator_0")
        errors_0 = Schema.errors

# Generated at 2022-06-26 10:33:11.907824
# Unit test for constructor of class Schema
def test_Schema():
    definitions = SchemaDefinitions()
    class_name = 'Person'
    bases = (Schema,)
    attrs = {'name': Field()}
    schema_definitions_0 = SchemaDefinitions()
    object_0 = SchemaMetaclass(class_name, bases, attrs, schema_definitions_0)
# This test should raise TypeError
    try:
        object_1 = Schema('a', 'b', 'c', 'd')
        raise Exception
    except TypeError:
        print('test_case_1 passed')



# Generated at 2022-06-26 10:33:22.374144
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    Schema_instance_0 = Schema()
    assert (
        list(Schema_instance_0) == []
    ), "'__iter__' method of 'Schema' class returned wrong value."



# Generated at 2022-06-26 10:33:30.016046
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    from typesystem.base import String, Boolean, Integer
    from typesystem import Object as typesystem_Object

    class Schema_0(Schema):
        name = String()
        age = Integer()
        married = Boolean()

    field_0 = typesystem_Object(
        properties={"name": String(), "age": Integer(), "married": Boolean()},
        required=["name", "age", "married"],
        additional_properties=False,
    )
    obj_0 = Schema_0(name="Alice", age=32, married=True)
    assert obj_0.fields == {"name": String(), "age": Integer(), "married": Boolean()}

# Generated at 2022-06-26 10:33:42.836193
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_definitions_2 = SchemaDefinitions({})
    source_value_4 = int
    to_5 = str
    definitions_7 = schema_definitions_2
    strict_8 = bool
    source_value_4 = source_value_4
    to_5 = to_5
    definitions_7 = definitions_7
    strict_8 = strict_8
    def test_lambda_3(value):
        return (value is None)
    class TestObject(Schema):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    TestObject.fields['myfield'] = Array(items=Int(maximum=10))
    schema_definitions_2['TestObject'] = TestObject
    ref = Reference(TestObject)

# Generated at 2022-06-26 10:33:51.565655
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class_name = "PetSchema"
    argument_str = "name=\'Rover\', species=\'dog\', age=3, owner_name=\'Bob\'"
    sparse_indicator = ""
    expected_value = class_name + '(' + argument_str + sparse_indicator + ')'
    container = Schema(name = 'Rover', species = 'dog', age = 3, owner_name = 'Bob')
    actual_value = repr(container)
    assert actual_value == expected_value


# Generated at 2022-06-26 10:33:59.311375
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()

    class Animal(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):

        name = Field(str)
        family = Field(str)
        carnivore = Field(bool)
        age = Field(int)

        def eat(self, food: typing.Any) -> typing.Any:
            return "nom nom nom"

    class Cat(Animal):

        name = Field(str, default="Cat")
        family = Field(str, default="Felidae")
        carnivore = Field(bool, default=True)
        age = Field(int, default=0)

    class Dog(Animal, metaclass=SchemaMetaclass, definitions=schema_definitions_0):

        name = Field(str, default="Dog")
        family

# Generated at 2022-06-26 10:34:09.821779
# Unit test for function set_definitions
def test_set_definitions():
    f = Field()
    defs = SchemaDefinitions()
    set_definitions(f, defs)
    assert f.definitions is defs

    s = Schema()
    set_definitions(s.fields["properties"], defs)
    assert s.fields["properties"].definitions is defs

    class A(Schema):
        foo = Integer()

    set_definitions(A.fields["foo"], defs)
    assert A.fields["foo"].definitions is defs

    class B(A):
        bar = String()
        baz = Reference(to="Foo")

    set_definitions(B.fields["baz"], defs)
    assert B.fields["baz"].definitions is defs


# Generated at 2022-06-26 10:34:19.455556
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    test_case_0()
    schema_definitions_0 = SchemaDefinitions()

    class StatsSchema(Schema):
        total = Field(type="integer")
        per_page = Field(type="integer", default=25)
        current_page = Field(type="integer")
        last_page = Field(type="integer")

    schema_0 = StatsSchema(total=4, current_page=1, last_page=1)
    repr_0 = repr(schema_0)

    class StatsModel(Schema):
        class Meta:
            definitions = schema_definitions_0

        total = Field(type="integer")
        per_page = Field(type="integer", default=25)
        current_page = Field(type="integer")
        last_page = Field(type="integer")

    schema_1

# Generated at 2022-06-26 10:34:31.767056
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.fields import Reference
    from typesystem.schema import SchemaDefinitions
    from typesystem.schema import set_definitions
    schema_definitions_1 = SchemaDefinitions()
    a_name_1 = "<lambda>.a"
    a_2 = Reference(to=a_name_1, definitions=schema_definitions_1)
    b_name_1 = "<lambda>.b"
    b_2 = Reference(to=b_name_1, definitions=schema_definitions_1)
    array_1 = Array(items=a_2)
    object_1 = Object(properties={'b': b_2})
    set_definitions(field=array_1, definitions=schema_definitions_1)

# Generated at 2022-06-26 10:34:34.038567
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    a = Schema()
    b = Schema()

    assert a != b


# Generated at 2022-06-26 10:34:36.605215
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class A0(Schema):
        pass

    obj = A0()
    length = len(obj)
    assert length == 0



# Generated at 2022-06-26 10:34:57.174424
# Unit test for function set_definitions
def test_set_definitions():
    test_value = "test"
    string_field = Field(type="string")
    array_field = Array(items=string_field)
    object_field = Object(properties={"test": string_field})
    fields = [string_field, array_field, object_field]
    for field in fields:
        set_definitions(field, test_value)
        assert field.definitions == test_value
        assert string_field.definitions == test_value
        assert array_field.items.definitions == test_value
        assert array_field.definitions == test_value
        assert object_field.definitions == test_value
        assert string_field.definitions == test_value
        assert object_field.properties["test"].definitions == test_value

# Unit tests for class SchemaMetaclass

# Generated at 2022-06-26 10:35:06.238362
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_1 = SchemaDefinitions()
    class_0 = Schema(schema_definitions_1)
    assert len(class_0) == 0
    class_1 = Schema(schema_definitions_1)
    assert len(class_1) == 0
    class_2 = Schema(schema_definitions_1)
    assert len(class_2) == 0
    class_2 = Schema(schema_definitions_1)
    assert len(class_2) == 0
    class_3 = Schema(schema_definitions_1)
    assert len(class_3) == 0
    class_4 = Schema(schema_definitions_1)
    assert len(class_4) == 0
    class_5 = Schema(schema_definitions_1)


# Generated at 2022-06-26 10:35:19.429042
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    end_user_0 = Schema(schema_definitions_0)
    schema_definitions_1 = SchemaDefinitions()
    end_user_1 = Schema(schema_definitions_1)
    schema_definitions_2 = SchemaDefinitions()
    end_user_2 = Schema(schema_definitions_2)

    # Test with a valid arg
    assert isinstance(end_user_0.__iter__(), collections.abc.Iterator)

    # Test with a valid arg
    assert isinstance(end_user_1.__iter__(), collections.abc.Iterator)

    # Test with a valid arg
    assert isinstance(end_user_2.__iter__(), collections.abc.Iterator)


# Generated at 2022-06-26 10:35:22.993660
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    global schema_definitions_0
    schema_definitions_0 = SchemaDefinitions()
    data_0 = Foo(int_prop=42)

    assert repr(data_0) == "Foo(int_prop=42)"


# Generated at 2022-06-26 10:35:24.182371
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert 0 == Schema().__len__()


# Generated at 2022-06-26 10:35:31.401842
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Address(Schema):
        street = String()

    class Business(Schema):
        name = String()
        address = Reference(Address, definitions=schema_definitions_0)

    class Person(Schema):
        name = String()
        address = Reference(Address, definitions=schema_definitions_0)
        business = Reference(Business, definitions=schema_definitions_0)

    address = Address(street="123 Fake Street")
    business = Business(name="Acme Inc.", address=address)
    person = Person(name="John Smith", business=business)
    person = person.validate()

    assert person.business.__class__ == Business
    assert person.business.address.__class__ == Address
    assert person.business.address.street == "123 Fake Street"

# Generated at 2022-06-26 10:35:33.077185
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    try:
        schema_0 = Schema()
    except Exception:
        pass
    else:
        sys.exit(1)


# Generated at 2022-06-26 10:35:45.246797
# Unit test for function set_definitions
def test_set_definitions():
    a = Reference('a')
    b = Reference('b')
    c = Reference('c')
    d = Reference('d')
    
    schema = Object(properties = {
        'a' : a,
        'b' : b,
        'c' : c,
        'd' : d
            })
    
    # Test with a single layer Schema object
    test_definitions_0 = SchemaDefinitions()
    set_definitions(schema, test_definitions_0)
    
    assert a.definitions == test_definitions_0
    assert b.definitions == test_definitions_0
    assert c.definitions == test_definitions_0
    assert d.definitions == test_definitions_0
    

    # Test with a deeper layer Schema object
    e = Reference('e')

# Generated at 2022-06-26 10:35:46.494058
# Unit test for constructor of class Reference
def test_Reference():
    test_case_0()

# Generated at 2022-06-26 10:35:47.951876
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(definitions=schema_definitions_0)
    assert len(schema_0) == 0


# Generated at 2022-06-26 10:36:05.161055
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:36:13.339602
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert list(schema_0) == []
    schema_1 = Schema()
    assert list(schema_1) == []
    schema_2 = Schema()
    assert list(schema_2) == []
    schema_3 = Schema()
    assert list(schema_3) == []
    schema_4 = Schema()
    assert list(schema_4) == []
    schema_5 = Schema()
    assert list(schema_5) == []
    schema_6 = Schema()
    assert list(schema_6) == []


# Generated at 2022-06-26 10:36:16.866238
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0: Schema = Schema({})
    len_0 = len(schema_0)
    assert isinstance(len_0, int)


# Generated at 2022-06-26 10:36:23.213610
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():

    class Animal(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        name = Field(type="string")

    class Cat(Animal, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        lives = Field(type="integer", default=9)

    class Dog(Animal, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        barks = Field(type="boolean", default=True)

    print(Animal.fields)
    print(Cat.fields)
    print(Dog.fields)


# Generated at 2022-06-26 10:36:25.264381
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:36:32.141995
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test Schema.__iter__ with valid values
    actual_0 = list(test_case_0().__iter__())   # test_case_0 is a Schema instance
    expected_0 = []
    assert actual_0 == expected_0



# Generated at 2022-06-26 10:36:38.448969
# Unit test for function set_definitions
def test_set_definitions():
    test_schema_0 = Schema

    test_schema_0_fields = {
        "address": Object(properties={"city": String()}),
        "name": String(),
        "parents": Array(items=Reference(to="Person")),
        "pets": Array(items=Reference(to="Pet")),
    }

    test_schema_0.fields = test_schema_0_fields

    for key, value in test_schema_0.fields.items():
        assert (
            key not in test_schema_0_fields
        ), "test_set_definitions_1: condition is False"
        test_set_definitions(value, schema_definitions_0)

# Generated at 2022-06-26 10:36:48.716365
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()

    class ExampleSchema_0(Schema, metaclass=SchemaMetaclass):
        field_a = Field(type="string")
        field_b = Field(type="number")

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)

        @classmethod
        def make_validator(cls: typing.Type["ExampleSchema_0"], *, strict: bool = False) -> "ExampleSchema_0":
            required = [key for key, value in cls.fields.items() if not value.has_default()]
            return Object(properties=cls.fields, required=required, additional_properties=False if strict else None)


# Generated at 2022-06-26 10:36:56.140970
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    val_0 = Schema(schema_definitions_0)
    #  The return type is an iterator of strings,
    #  so we need to convert it to a list to make it comparable
    classes_0 = list(val_0.__iter__())
    classes_1 = []
    assert classes_0 == classes_1



# Generated at 2022-06-26 10:37:04.007334
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Test for method __repr__ (line 160)
    class TestSchema(Schema):
        field_0 = Field()

    # Call method __repr__ (line 161)
    try:
        TestSchema.__repr__()
    except Exception as exception:
        assert type(exception) == AttributeError
        assert str(exception) == ("type object 'TestSchema' has no attribute " "'__repr__'")
    else:
        raise AssertionError(
            "Return type mismatch, expected {type}, got {ret_type}".format(
                type=Exception, ret_type=type(exception)
            )
        )
    # Call method __repr__ (line 162)

# Generated at 2022-06-26 10:37:37.592339
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()

    class ItemType(Schema):
        name = Field(type=str)

    class PurchaseOrder(Schema):
        # We will use this schemas as a validator
        total = Field(type=float, required=True)
        products = Array(type=ItemType)

    assert len(PurchaseOrder.fields) == 2


# Generated at 2022-06-26 10:37:41.138531
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema = Schema()
    other = Schema()
    self = schema.__eq__(other)
    assert self == True
    other = None
    self = schema.__eq__(other)
    assert self == False


# Generated at 2022-06-26 10:37:47.339169
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    try:
        assert schema_definitions_0.__len__() == 0
        print("assertion successful")
    except AssertionError:
        print('AssertionError: assertion unsuccessful')


# Generated at 2022-06-26 10:37:48.748550
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert Schema.__len__ == Mapping.__len__


# Generated at 2022-06-26 10:37:55.312162
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()

    class Address(Schema):
        title = String()
        city = String()
        person = Reference(Person)

    address = Address(
        {
            "title": "123 Main St.",
            "city": "Portland",
            "person": {"name": "Joe Bloggs", "age": 30},
        }
    )

# Generated at 2022-06-26 10:37:56.552989
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:37:59.230504
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_1 = SchemaDefinitions()
    class_0 = Schema(schema_definitions_1)
    assert class_0.fields == {}



# Generated at 2022-06-26 10:38:08.231977
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0["Listing"] = Listing

    # Build instance for Listing
    listing_0 = Listing(
        id="912b8a5e-a764-4b69-a532-f5bd5f7b5c37",
        listingId="listingId_0",
        createdAt="createdAt_0",
        title="title_0",
        description="description_0",
        price=17.7,
        fee=19.7,
        currency="currency_0",
    )

    # Build instance for Listing

# Generated at 2022-06-26 10:38:19.033713
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    class MySchema(Schema):
        count = Field(primitive=int)
        items = Array(primitive=int)

    my_schema_0 = MySchema(count=1, items=[2, 3, 4, 5])
    my_schema_1 = MySchema(count=2, items=[3, 4, 5, 6])
    my_schema_2 = MySchema(count=1, items=[2, 3, 4, 5])
    my_schema_3 = MySchema()
    assert my_schema_0 != my_schema_1
    assert my_schema_0 != my_schema_2
    assert my_schema_0 != my_schema_3

# Generated at 2022-06-26 10:38:23.049898
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test the case where __getitem__ is called with an invalid key.
    # This should raise an exception.
    with pytest.raises(KeyError):
        schema_0 = Schema()
        schema_0.__getitem__(key=1)



# Generated at 2022-06-26 10:39:03.931613
# Unit test for constructor of class Reference
def test_Reference():
    schema_definitions = SchemaDefinitions()
    target_string = "target_string"
    to = "to"
    reference = Reference(to, schema_definitions)
    assert (
        reference.to == to
    ), "Expected {}, but got {}".format(to, reference.to)
    assert (
        reference.definitions == schema_definitions
    ), "Expected {}, but got {}".format(schema_definitions, reference.definitions)
    assert (
        reference.target_string == target_string
    ), "Expected {}, but got {}".format(target_string, reference.target_string)
    to = "to1"
    target_string = "target_string1"
    reference = Reference(to, schema_definitions)

# Generated at 2022-06-26 10:39:14.010563
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # TODO: update this test
    schema_0 = Schema()
    schema_1 = Schema()
    schema_2 = Schema()
    schema_3 = Schema()
    schema_4 = Schema()
    schema_5 = Schema()
    schema_6 = Schema()
    schema_7 = Schema()
    schema_8 = Schema()
    schema_9 = Schema()
    schema_10 = Schema()
    schema_11 = Schema()
    schema_12 = Schema()
    schema_13 = Schema()
    schema_14 = Schema()
    schema_15 = Schema()
    schema_16 = Schema()
    schema_17 = Schema()
    schema_18 = Schema()
    schema_19 = Schema()
    schema_20 = Schema()
   

# Generated at 2022-06-26 10:39:24.381627
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # test object creation
    test_object_0 = Schema()
    test_object_1 = Schema()
    test_object_2 = Schema()
    # assert __repr__ return type
    assert isinstance(test_object_0.__repr__(), str)
    assert isinstance(test_object_1.__repr__(), str)
    assert isinstance(test_object_2.__repr__(), str)
    # assert __repr__ return value
    assert test_object_0.__repr__() == "Schema()"
    assert test_object_1.__repr__() == "Schema()"
    assert test_object_2.__repr__() == "Schema()"


# Generated at 2022-06-26 10:39:28.332156
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test with no arguments
    # should raise a TypeError exception:
    with pytest.raises(TypeError):
        SchemaMetaclass()


# Generated at 2022-06-26 10:39:31.547389
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    assert schema_definitions_0.__getitem__('to') == {'to': 'to', 'definitions': None}

# Generated at 2022-06-26 10:39:41.376336
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class schema_0(Schema):
        line_number = Field()

    # Test cases for method __new__ of class SchemaMetaclass
    assert schema_0.fields["line_number"]._creation_counter == 0
    assert schema_0.fields["line_number"].name == "line_number"
    assert isinstance(schema_0.fields["line_number"], Field)
    assert isinstance(schema_0.fields.keys(), dict_keys)


# Generated at 2022-06-26 10:39:45.445472
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    schema__len__returned = schema.__len__()
    assert isinstance(schema__len__returned, int)


# Generated at 2022-06-26 10:39:50.668667
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema.__new__(Schema)
    schema_0.fields = {}
    assert list(schema_0.__iter__()) == list(schema_0.fields.keys())


# Generated at 2022-06-26 10:39:54.908105
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:40:00.697363
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    field_0 : Any = Reference('TestSchema')
    set_definitions(field_0, schema_definitions_0)
    assert field_0.definitions == schema_definitions_0
