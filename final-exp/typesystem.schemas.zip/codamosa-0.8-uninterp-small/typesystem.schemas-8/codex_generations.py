

# Generated at 2022-06-26 10:31:18.493132
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    test_schema = Schema()
    assert len(test_schema) == 0


# Generated at 2022-06-26 10:31:20.077681
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    def cases():
        yield Schema
        yield Schema(name="Bob")
    for case in cases():
        case.__len__()


# Generated at 2022-06-26 10:31:20.960496
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema()
    assert schema.fields == {}


# Generated at 2022-06-26 10:31:23.724655
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_0 = Schema()
    schema_0_fields = schema_0.fields
    schema_0_fields_keys = schema_0_fields.keys()
    for key in schema_0_fields_keys:
        if not hasattr(schema_0, key):
            raise KeyError(key)


# Generated at 2022-06-26 10:31:25.453576
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    Schema__iter__return_value = Schema.__iter__()  # type: typing.Any
    assert isinstance(Schema__iter__return_value, typing.Iterator[str])


# Generated at 2022-06-26 10:31:27.938790
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # test_case_0
    schema_metaclass_0 = SchemaMetaclass()
    assert schema_metaclass_0 is not None


# Generated at 2022-06-26 10:31:37.270130
# Unit test for constructor of class Reference
def test_Reference():
    reference_0 = Reference(to="")
    assert reference_0.to == ""
    assert reference_0.definitions is None
    assert reference_0.allow_null is False
    assert reference_0.required is False
    assert reference_0.serialize is Field.serialize
    assert reference_0.validate is None
    assert reference_0.validate_or_error is None
    assert reference_0.target_string == ""
    assert reference_0.target is None
    assert reference_0.validation_error("null") is ValidationError



# Generated at 2022-06-26 10:31:41.161179
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Arrange
    class SimpleObject0(Schema):
        a = 1
    # Act
    simple_object_0 = SimpleObject0()
    # Assert
    assert repr(simple_object_0) == "SimpleObject0(a=1) [sparse]"


# Generated at 2022-06-26 10:31:44.680420
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class DummySchema(Schema):
        pass
    schema = DummySchema()
    assert list(schema) == []



# Generated at 2022-06-26 10:31:47.717469
# Unit test for constructor of class Schema
def test_Schema():
    class PersonSchema(Schema):
        class Meta:
            pass

        name = String()
        age = Integer()

    PersonSchema()
    assert PersonSchema._meta.strict == False



# Generated at 2022-06-26 10:31:58.652041
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    a = Schema()
    b = Schema()
    assert a==b


# Generated at 2022-06-26 10:31:59.336590
# Unit test for constructor of class Schema
def test_Schema():
    model_schema = Schema({"foo":Field()})


# Generated at 2022-06-26 10:32:02.493312
# Unit test for constructor of class Reference
def test_Reference():
    to_string = 'Sample_string'
    definitions = SchemaDefinitions()
    allow_null = True
    reference = Reference(to=to_string, definitions=definitions, allow_null=allow_null)


# Generated at 2022-06-26 10:32:10.087283
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Instances of SchemaMetaclass should be types.
    assert type(SchemaMetaclass) is type
    # SchemaMetaclass should subclass ABCMeta.
    assert issubclass(SchemaMetaclass, ABCMeta)
    # SchemaMetaclass should not be an abstract class.
    assert not SchemaMetaclass.__abstractmethods__
    # SchemaMetaclass should have a valid constructor.
    schema_metaclass_0 = SchemaMetaclass()


# Generated at 2022-06-26 10:32:20.146628
# Unit test for function set_definitions
def test_set_definitions():
    class Parent:
        age = Integer()

        class Meta:
            extra = 'allow'

    class Child(Parent, metaclass=SchemaMetaclass):
        name = String()
        
    child = Child(name='Alex', age=10)
    child_dict = {'name': 'Alex', 'age': 10}

    assert child.name == 'Alex'
    assert child.age == 10
    assert child.serialize() == child_dict
    assert child == Child(child_dict)

    class GrandChild(Child, metaclass=SchemaMetaclass):
        address = String()

    grand_child = GrandChild(name='Alex', age=10, address='Nairobi, Kenya')

# Generated at 2022-06-26 10:32:30.513057
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    """
    Test __eq__ of Schema
    """
    #Setup
    case_0 = Schema()
    case_1 = Schema()
    case_2 = Schema()
    case_2.bool_ = True
    case_3 = Schema()
    case_3.bool_ = False
    # Exercise
    assert case_0 == case_1
    assert not case_0 == case_2
    assert not case_2 == case_0
    assert case_2 == case_3
    assert not case_3 == case_2
    case_0.bool_ = True
    case_0.bool_ = False
    assert case_0 == case_2
    assert case_0 == case_3
    assert case_2 == case_0
    assert case_3 == case_0


# Generated at 2022-06-26 10:32:32.532136
# Unit test for function set_definitions
def test_set_definitions():
    field = Field()
    definitions = SchemaDefinitions
    set_definitions(field, definitions)

# Generated at 2022-06-26 10:32:38.830869
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_metaclass_0 = SchemaMetaclass()
    assert isinstance(schema_metaclass_0, type)


# Generated at 2022-06-26 10:32:40.550386
# Unit test for function set_definitions
def test_set_definitions():
    schema_metaclass_1 = SchemaMetaclass()


# Generated at 2022-06-26 10:32:42.824296
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema
    result = schema.__len__()
    assert len(result) > 0



# Generated at 2022-06-26 10:32:55.130982
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test cases of method __len__
    cases = [
        ((), 0),
        (({'s': Type('s', str)},), 1),
        (({'s': Type('s', str), 'n': Type('n', int)},), 2),
    ]

    for args, expected in cases:
        # Build a Schema object
        schema = Schema(*args)

        # Calculation
        actual = schema.__len__()

        # Check
        assert expected == actual


# Generated at 2022-06-26 10:33:00.632124
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Integer

    fields = {"test": Integer()}

    class SchemaStub(Schema, metaclass=SchemaMetaclass, fields=fields):
        ...

    instance = SchemaStub(test=10)

    assert len(instance) == 1


# Generated at 2022-06-26 10:33:03.213707
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    res = Schema.__eq__(Schema(), Schema())
    assert res
    assert type(res) is bool


# Generated at 2022-06-26 10:33:06.203801
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class_0 = Schema
    value_0 = Schema()
    value_1 = Schema()
    assert class_0.__eq__(value_0, value_1) is False


# Generated at 2022-06-26 10:33:09.069885
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field = None

    assert TestSchema() == TestSchema()


# Generated at 2022-06-26 10:33:21.289867
# Unit test for function set_definitions
def test_set_definitions():
    def _check_definitions(field: Field) -> None:
        if isinstance(field, Reference):
            assert field.definitions is not None
        elif isinstance(field, Array):
            if field.items is not None:
                if isinstance(field.items, (tuple, list)):
                    for child in field.items:
                        _check_definitions(child)
                else:
                    _check_definitions(field.items)
        elif isinstance(field, Object):
            for child in field.properties.values():
                _check_definitions(child)

    # Check that all the fields in the schema get the given definitions
    class Question(Schema):
        id = String()
        username = String()
        published_at = String()

    definitions = SchemaDefinitions()
    _check_definitions

# Generated at 2022-06-26 10:33:24.280551
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    tester = Schema({'a': 1, 'b': 'two'})
    assert tester['a'] == 1
    assert tester['b'] == 'two'
    try:
        tester['c']
    except KeyError:
        pass


# Generated at 2022-06-26 10:33:27.220968
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        name = Field()
        age = Field(default=0)

    obj = MySchema(name="Bob")
    match = repr(obj) == "MySchema(name='Bob', age=0)"
    assert match



# Generated at 2022-06-26 10:33:33.155785
# Unit test for function set_definitions
def test_set_definitions():
    def _validate_field(field: Field) -> None:
        if isinstance(field, Reference) and field.definitions is None:
            raise ValueError("Reference field has no definitions.")
        elif isinstance(field, Array):
            if field.items is not None:
                if isinstance(field.items, (tuple, list)):
                    for child in field.items:
                        _validate_field(child)
                else:
                    _validate_field(field.items)
        elif isinstance(field, Object):
            for child in field.properties.values():
                _validate_field(child)

    def _validate_schema(schema_class: type) -> None:
        definitions = SchemaDefinitions()
        definitions[schema_class.__name__] = schema_class

# Generated at 2022-06-26 10:33:44.451171
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    try:
        # Check that an error is raised if a non-dict
        # object is passed as the first argument
        schema_0.__getitem__("")
    except Exception:
        pass
    else:
        raise Exception("The test should have raised an error")
    try:
        # Check that an error is raised if a non-dict
        # object is passed as the first argument
        schema_0.__getitem__(schema_0)
    except Exception:
        pass
    else:
        raise Exception("The test should have raised an error")
    # Check that an error is raised if no attribute is given
    try:
        schema_0.__setattr__("")
    except Exception:
        pass
    else:
        raise Exception("The test should have raised an error")
   

# Generated at 2022-06-26 10:33:58.742903
# Unit test for function set_definitions
def test_set_definitions():
    # Create schema definitions
    schema_definitions_0 = SchemaDefinitions()
    # Create a reference and add it to the schema definitions
    reference_0 = Reference("Person", schema_definitions_0)
    # Create an object and add it to the schema definitions
    object_0 = Object(schema_definitions_0)
    # Set the definitions for the object and the reference
    set_definitions(reference_0, schema_definitions_0)
    set_definitions(object_0, schema_definitions_0)
    # Assert that the schema definitions were set properly for the reference
    assert reference_0.definitions is schema_definitions_0
    # Assert that the schema definitions were set properly for the object
    assert object_0.definitions is schema_definitions_0


# Generated at 2022-06-26 10:34:04.150350
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class User(Schema):
        user_id = Integer(description="The unique identifier for the user.")
    class Comment(Schema):
        comment_id = Integer(description="The unique identifier for the comment.")
        user = Reference(to=User)
    set_definitions(Comment.fields["user"], definitions)
    assert definitions[User.__name__] == User


# Generated at 2022-06-26 10:34:11.380608
# Unit test for constructor of class Schema
def test_Schema():
    # Testing scenario where arguments is a dict
    SomeSchema = Schema({"arg1": 'some_value', "arg2": 10})
    assert isinstance(SomeSchema, Schema)

    # Testing scenario where arguments is an object
    SomeSchema = Schema(object)
    assert isinstance(SomeSchema, Schema)

    # Testing regular scenario
    SomeSchema = Schema(arg1='some_value', arg2=10)
    assert isinstance(SomeSchema, Schema)

# Generated at 2022-06-26 10:34:17.095153
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    a = Schema(foo=1, bar=2)
    assert len(a) == 2
    assert list(a) == ["foo", "bar"]
    a = Schema(bar=1, foo=2)
    assert len(a) == 2
    assert list(a) == ["foo", "bar"]


# Generated at 2022-06-26 10:34:18.261030
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass



# Generated at 2022-06-26 10:34:25.592563
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_class_0 = type('schema_class_0', (Schema,), {})
    schema_instance_0 = schema_class_0()
    object_0 = schema_instance_0.__repr__()
    assert object_0 is not None
    assert str(object_0) == "schema_class_0()"


# Generated at 2022-06-26 10:34:30.213446
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    schema_1 = Schema(a = 1)
    schema_2 = Schema(a = 1, b = 2)
    schema_3 = Schema(a = 1, b = 2, c = 3)
    schema_4 = Schema(a = 1, b = 2, c = 3, d = 4)
    schema_5 = Schema(a = 1, b = 2, c = 3, d = 4, e = 5)
    schema_6 = Schema(a = 1, b = 2, c = 3, d = 4, e = 5, f = 6)
    schema_7 = Schema(a = 1, b = 2, c = 3, d = 4, e = 5, f = 6, g = 7)

# Generated at 2022-06-26 10:34:37.102720
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    TestCase = [
        {
            "message": "",
            "hope": "",
            "error": "",
            "method": "",
        },
    ]
    for data in TestCase:
        with pytest.raises(data["error"]):
            message = data["message"]
            hope = data["hope"]
            error = data["error"]
            method = data["method"]
            # run test
            pass


# Generated at 2022-06-26 10:34:45.372183
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    schema_

# Generated at 2022-06-26 10:34:49.729070
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    _test_func = test_case_0
    assert list(_test_func().fields.items()) == list(_test_func().__iter__())


# Generated at 2022-06-26 10:34:56.709180
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    return



# Generated at 2022-06-26 10:34:59.310142
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = type('Schema',(Schema,), dict(fields = dict()))
    obj_0 = schema_0()

    assert obj_0 == obj_0


# Generated at 2022-06-26 10:35:08.092826
# Unit test for constructor of class Schema
def test_Schema():
    to_0 = Array(Reference("Person"))
    definitions_0 = SchemaDefinitions()
    __args__ = (
        to_0,
        definitions_0,
    )
    __kwargs__ = {}
    # Type hinting error
    # __return__ = typing.Type["Schema"]
    __return__ = None
    __self__ = Schema(*__args__, **__kwargs__)
    assert __return__ == __self__
    to_1 = Reference("Person")
    definitions_1 = definitions_0
    __args__ = (
        to_1,
        definitions_1,
    )
    __kwargs__ = {}
    # Type hinting error
    # __return__ = typing.Type["Schema"]
    __return__ = None

# Generated at 2022-06-26 10:35:09.416737
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    test_case_0()


# Generated at 2022-06-26 10:35:16.979689
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = Schema(schema_definitions_0)
    try:
        # Try to iterate over instance of Schema
        for key in class_0:
            continue
    except KeyError as e:
        # This traceback should be ignored
        pass
    except Exception:
        raise AssertionError()


# Generated at 2022-06-26 10:35:18.544983
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    print(Schema({}).__len__())


# Generated at 2022-06-26 10:35:20.274229
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Create an instance of class Schema
    schema_0 = Schema()
    with pytest.raises(Exception):
        schema_0.__eq__


# Generated at 2022-06-26 10:35:25.288413
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    f1 = Field(type=str)
    set_definitions(f1, schema_definitions_0)

    f2 = Reference("some_target",title="some_title",type=str,definitions=schema_definitions_0)
    set_definitions(f2, schema_definitions_0)


# Generated at 2022-06-26 10:35:28.842230
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    instance = Schema()
    assert hasattr(instance, "__iter__")
    assert callable(instance.__iter__)
    result = instance.__iter__()
    try:
        assert type(result) is typing.Iterator
    except Exception as e:
        print(type(e))
        print(e)


# Generated at 2022-06-26 10:35:33.113718
# Unit test for constructor of class Reference
def test_Reference():
    schema_definitions_0 = SchemaDefinitions()
    target_6 = File(min_length=0, max_length=65535, media_types=['*/*'])
    assert hasattr(target_6, 'definitions')
    raw_7 = None
    assert target_6.validate_or_error(raw_7) == ValidationResult(value=None, error=None)
    raw_8 = '6489'
    assert target_6.validate_or_error(raw_8) == ValidationResult(value='6489', error=None)


# Generated at 2022-06-26 10:35:52.678077
# Unit test for constructor of class Schema
def test_Schema():
    print("Unit test for constructor of class Schema")
    schema = schema_definitions_0.validate(
        {
            "a": 1,
            "b": "1",
            "c": ["a", "b"]
        }
    )
    print("The result of validate() method is: ", schema)

    schema_1 = schema_definitions_0.validate(
        {
            "a": 1,
            "b": "1",
            "c": ["a", "b"]
        }
    )
    print("The result of validate() method is: ", schema_1)
    print()
    assert (schema == schema_1), "test for constructor failed!"



# Generated at 2022-06-26 10:36:02.696772
# Unit test for function set_definitions
def test_set_definitions():
    test_cases = [
        SchemaDefinitions(),
        SchemaDefinitions({2: 3}),
        SchemaDefinitions(kwargs={'key': 'value'}),
        SchemaDefinitions(kwargs={'key': 'value'}, args=([], )),
    ]
    for i in test_cases:
        # noinspection DuplicatedCode
        array = Array(items=String())
        reference = Reference("A")
        object = Object()

        set_definitions(array, i)
        set_definitions(reference, i)
        set_definitions(object, i)
        # noinspection PyUnreachableCode
        assert reference.definitions == i, 'ReferenceDefinitionsTestFailed'

# Generated at 2022-06-26 10:36:04.522531
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0[Array] = Array


# Generated at 2022-06-26 10:36:11.633019
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    schema_class_0 = SchemaMetaclass(
        "SchemaClass0", (object,), {"bar": Field(name="bar")}, definitions=schema_definitions_0
    )
    instances_0 = [schema_class_0(bar=1), schema_class_0(bar=2)]
    assert instances_0[0] != instances_0[1]



# Generated at 2022-06-26 10:36:18.240422
# Unit test for constructor of class Schema
def test_Schema():
    data_0 = {"a": "string", "b": 5, "c": "other"}
    schema_0 = Schema(data_0)

    # Check types of returned values
    assert(isinstance(schema_0, Schema))
    assert(isinstance(schema_0.is_sparse, bool))
    assert(isinstance(schema_0.__repr__(), str))


# Generated at 2022-06-26 10:36:22.421443
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()

    class schema_0(Schema):
        fields = {
            "id": Integer(minimum=1.0, maximum=100.0),
            "text": String(min_length=1, max_length=100),
        }

    schema_0(id=0, text="foo")


# Generated at 2022-06-26 10:36:34.914879
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    result_0 = next(iter(schema_0))
    assert result_0 == "__weakref__"
    result_0 = len(schema_0)
    assert result_0 == 1
    result_0 = next(iter(schema_0))
    assert result_0 == "__weakref__"
    schema_0 = Schema()
    result_0 = next(iter(schema_0))
    assert result_0 == "__weakref__"
    result_0 = len(schema_0)
    assert result_0 == 1
    result_0 = next(iter(schema_0))
    assert result_0 == "__weakref__"


# Generated at 2022-06-26 10:36:38.907959
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    schema_0.iter()



# Generated at 2022-06-26 10:36:43.175373
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    class Object2(Schema):
        x = Field()
        y = Field()
    instance_0 = Object2()
    instance_1 = Object2()
    assert instance_0 == instance_1


# Generated at 2022-06-26 10:36:46.701649
# Unit test for function set_definitions
def test_set_definitions():
    array_0 = Array(items=Reference(to="Person"))
    schema_definitions_0 = SchemaDefinitions()
    set_definitions(array_0, schema_definitions_0)


# Generated at 2022-06-26 10:37:02.933166
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:37:05.752769
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    object_0 = Schema()
    try:
        object_0.__iter__()
    except AttributeError as exception_0:
        print(exception_0.args[0])



# Generated at 2022-06-26 10:37:13.257395
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_1 = SchemaDefinitions()

    class Point(Schema):
        x = Field(type="number")
        y = Field(type="number")

        class Meta:
            definitions = schema_definitions_1

    class Line(Schema):
        start = Reference(to=Point)
        end = Reference(to=Point)

        class Meta:
            definitions = schema_definitions_1

    line = Line({"start": {"x": 0, "y": 0}, "end": {"x": 1, "y": 1}})
    print(line.start, line.end)
    print(line)


# Generated at 2022-06-26 10:37:20.269892
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class EmptySchema(Schema):
        fields = {}
    assert EmptySchema().__iter__() == EmptySchema().fields.__iter__()
    schema_definitions_0 = SchemaDefinitions()
    class SomeSchema(Schema):
        fields = {'field': Field()}
    assert SomeSchema().__iter__() == SomeSchema().fields.__iter__()


# Generated at 2022-06-26 10:37:26.424623
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Initialize arguments with dummy values
    name = 'my string'
    bases = [
        'my string',
    ]
    attrs = {
        'my string': 'my string',
    }
    definitions = SchemaDefinitions()

    # Call method(s) and assert result
    assert bool(SchemaMetaclass.__new__(SchemaMetaclass, name, bases, attrs, definitions))


# Generated at 2022-06-26 10:37:29.205815
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:37:36.052595
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = Schema(schema_definitions_0)
    class_0_instance_0 = class_0(schema_definitions_0)
    class_0_instance_1 = class_0(schema_definitions_0)
    assert class_0_instance_0 == class_0_instance_1


# Generated at 2022-06-26 10:37:43.984013
# Unit test for constructor of class Schema
def test_Schema():
    # Test that an instance of Schema is created correctly
    schema_definitions_0 = SchemaDefinitions()
    class ProductSchema_0(Schema, definitions=schema_definitions_0):
        name = Field(max_length=255)
        sku = Field(max_length=255)
        slug = Field(max_length=255)
    def test_0():
        product = ProductSchema_0(name="Test", sku="TEST", slug="test-product")
        assert product.is_sparse == False, "Value of parameter 'is_sparse' is not correct."
        assert product.name == "Test", "Value of parameter 'name' is not correct."
        assert product.sku == "TEST", "Value of parameter 'sku' is not correct."

# Generated at 2022-06-26 10:37:46.759278
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # See test/test_reference.py
    assert True

# Generated at 2022-06-26 10:37:52.111005
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert issubclass(Schema, Mapping) is True
    assert hasattr(Schema, 'fields') is True
    assert type(Schema.fields) is dict
    assert isinstance(Schema.__mro__, tuple) is True
    assert Schema.__mro__[-2] is SchemaMetaclass


# Generated at 2022-06-26 10:38:27.754480
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert True == True


# Generated at 2022-06-26 10:38:37.560761
# Unit test for method validate of class Reference
def test_Reference_validate():
    from copy import copy
    from typesystem.fields import Primitive, String
    from dataclasses import dataclass
    from typesystem.exceptions import ValidationError

    @dataclass
    class Type0:
        name: str

    @dataclass
    class Type1:
        name: str
        ref: 'Type2'

    @dataclass
    class Type2:
        name: str
        ref: Type0

    test_data = {
        "name": "foo"
    }

    test_a = Type0.validate(test_data)
    test_b = Reference(to=Type0).validate_or_error(test_data)
    test_c = Reference(to=Type0).serialize(test_a)

    assert test_b.error is None

# Generated at 2022-06-26 10:38:41.355431
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Create an instance of the class
    schema = Schema()
    try:
        # Call the method and get the result
        result = schema.__repr__()
    except Exception as e:
        # If an exception occurred, fail the test
        assert False, str(e)
    # Verify the expected result


# Generated at 2022-06-26 10:38:53.297891
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    assert isinstance(schema_definitions_1, SchemaDefinitions)
    fields_0 = Array(items=String(max_length=20))
    set_definitions(fields_0, schema_definitions_1)
    fields_1 = Array(items=String(max_length=10))
    set_definitions(fields_1, schema_definitions_1)
    fields_2 = Array(items=String(max_length=10))
    set_definitions(fields_2, schema_definitions_1)
    fields_3 = Array(items=String(max_length=20))
    set_definitions(fields_3, schema_definitions_1)

# Generated at 2022-06-26 10:38:55.324870
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    foo = Schema()
    assert foo == foo


# Generated at 2022-06-26 10:38:56.035286
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert Schema().__eq__(Schema())


# Generated at 2022-06-26 10:38:58.117261
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    test_obj = Schema()
    test_obj.__len__()

# Generated at 2022-06-26 10:39:01.518426
# Unit test for function set_definitions
def test_set_definitions():
    field = Reference(to="A")
    definitions = SchemaDefinitions({"A": Reference(to="B")})
    set_definitions(field, definitions)
    assert field.definitions == definitions



# Generated at 2022-06-26 10:39:13.282126
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Author(Schema):
        name = String(default="")
        email = String(default="")
        num_posts = Integer(default=0)
        sign_off = String(default="")

    author_0 = Author(name="A", email="B", num_posts=2, sign_off="C")
    author_1 = Author(name="A", email="B", num_posts=2, sign_off="C")
    author_2 = Author(name="A", email="B", num_posts=2, sign_off="D")
    author_3 = Author(name="A", email="B")
    author_4 = Author()

    if author_0 == author_1:
        pass
    else:
        raise RuntimeError("Expected True.")

    if author_0 != author_2:
        pass


# Generated at 2022-06-26 10:39:22.389439
# Unit test for constructor of class Reference
def test_Reference():
    to_0 = None
    definitions_0 = None
    schema_definitions_0 = SchemaDefinitions()
    # expected: ValueError("Reference() missing 1 required positional argument: 'to'")

    # actual: ValueError("Reference() missing 1 required positional argument: 'to'")
    # exception occurred: ValueError("Reference() missing 1 required positional argument: 'to'")
    # ValueError("Reference() missing 1 required positional argument: 'to'")
    assert False



# Generated at 2022-06-26 10:40:59.991801
# Unit test for method validate of class Reference
def test_Reference_validate():
    to = ["Choice"]
    target = [
        Choice(
            choices=[Text(max_length=3), Text(max_length=4), Text(max_length=5)],
            validate_choices=True,
        )
    ]
    text = [Text()]
    value = [
        "hello",
        "hello world",
        "hello world! How are you doing",
        "hello world! How are you doing today"
    ]