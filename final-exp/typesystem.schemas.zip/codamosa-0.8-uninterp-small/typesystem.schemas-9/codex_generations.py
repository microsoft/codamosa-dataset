

# Generated at 2022-06-26 10:31:15.531028
# Unit test for constructor of class Schema
def test_Schema():
    # Test whether all fields are set correctly based on given parameters
    foo_field = Field()
    bar_field = Field()
    schema_definitions_1 = SchemaDefinitions()
    schema_1 = Schema(foo=foo_field, bar=bar_field, definitions=schema_definitions_1)
    print(schema_1.fields)
    assert schema_1.fields == {"foo":foo_field, "bar":bar_field}
    # Test whether the exception is raised correctly
    schema_definitions_2 = SchemaDefinitions()
    schema_2 = Schema(foo=foo_field, bar=bar_field, definitions=schema_definitions_2)

# Generated at 2022-06-26 10:31:21.419064
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field_0 = Integer()
        field_1 = Field()
    schema_instance_0 = TestSchema()
    schema_instance_0.field_0 = 59
    schema_instance_0.field_1 = 59
    assert schema_instance_0.__repr__() == 'TestSchema(field_0=59, field_1=59)'
    schema_instance_1 = TestSchema()
    if sys.version_info.major >= 3:
        assert schema_instance_1.__repr__() == 'TestSchema([sparse])'
    else:
        assert schema_instance_1.__repr__() == 'TestSchema(sparse)'
    schema_instance_1.field_0 = 0

# Generated at 2022-06-26 10:31:22.111158
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    test_case_0()


# Generated at 2022-06-26 10:31:27.494108
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class test_case_1(Schema):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
        fields = {
            "list": Array(item=Integer()),
            "int": Integer(),
            "str": String(),
            "dict": Object(properties={"val": Integer()})
        }
    obj_0 = test_case_1.validate(
        {
            "list": [1, 2, 3],
            "int": 1,
            "str": "str",
            "dict": {"val": 1},
            "another": "val"
        },
        strict=False
    )
    obj_0___iter__0

# Generated at 2022-06-26 10:31:36.749258
# Unit test for function set_definitions
def test_set_definitions():
    class PersonReference(Reference):
        pass
    
    class PersonSchema(Schema):
        age = Integer() 
        name = String() 
        references = Array(PersonReference())
    
    schema_definitions_0 = SchemaDefinitions()
    person = PersonSchema(age = 10, name = "hi", references = [1,2,3])
    #parameter field is of type Field
    field = PersonReference()
    set_definitions(field, schema_definitions_0)
    assert field.definitions is not None


# Generated at 2022-06-26 10:31:39.368100
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    for x_0 in schema_0:
        print(x_0)


# Generated at 2022-06-26 10:31:44.926074
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    schema = Schema(definitions = schema_definitions_0, strict = False)


# Generated at 2022-06-26 10:31:46.523275
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema = Schema({"foo": "bar"})
    assert schema["foo"] == "bar"


# Generated at 2022-06-26 10:31:58.581671
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_1["Foo"] = Foo

    class Foo(Schema, metaclass=SchemaMetaclass):
        id = String(required=True)
        ref = String(format="uuid")

    schema_definitions_2 = SchemaDefinitions()
    schema_definitions_2["Bar"] = Bar

    class Bar(Schema, metaclass=SchemaMetaclass):
        foo = Reference("Foo", definitions=schema_definitions_2)

    schema_definitions_3 = SchemaDefinitions()
    schema_definitions_3["Baz"] = Baz
    schema_definitions_3["Qux"] = Qux


# Generated at 2022-06-26 10:32:03.611092
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class FooBar(Schema):
        foo = Field(type=str)
        bar = Field(type=str)

    foo_bar = FooBar(foo="foo", bar="bar")
    assert len(foo_bar) == 2

    foo_bar = FooBar(foo="foo", bar="bar", baz="baz")
    assert len(foo_bar) == 2


# Generated at 2022-06-26 10:32:29.293760
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()

    class Person(Schema):
        name = Field(
            type="string",
            description="The name of the person.",
            pattern=r'^\s*$',
        )
        age = Field(type="integer", description="A persons age.")
        address = Reference(
            to="Address",
            definitions=schema_definitions_0,
            description="The address of the person.",
        )

    person = Person({"name": "Sarah", "age": 29})
    assert person == Person(name="Sarah", age=29)
    assert person["name"] == "Sarah"
    assert person["age"] == 29
    assert person["address"] is None


# Generated at 2022-06-26 10:32:43.612574
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # __iter__ method should return an iterator object

    def __init__(self, *args: typing.Any, **kwargs: typing.Any):
        if args:
            assert len(args) == 1
            assert not kwargs
            item = args[0]
            if isinstance(item, dict):
                for key in self.fields.keys():
                    if key in item:
                        setattr(self, key, item[key])
            else:
                for key in self.fields.keys():
                    if hasattr(item, key):
                        setattr(self, key, getattr(item, key))
            return

        for key, schema in self.fields.items():
            if key in kwargs:
                value = kwargs.pop(key)

# Generated at 2022-06-26 10:32:52.895117
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    child = Reference('ChildSchema', definitions)
    parent = Reference('ParentSchema', definitions)
    child_schema = Object(properties={
        'child': child
    })
    parent_schema = Object(properties={
        'parent': parent
    })
    definitions['ChildSchema'] = child_schema
    definitions['ParentSchema'] = parent_schema

    assert(child.definitions == definitions)
    assert(parent.definitions == definitions)
    set_definitions(parent, definitions)
    assert(child.definitions == definitions)
    assert(parent.definitions == definitions)


# Generated at 2022-06-26 10:32:58.461476
# Unit test for constructor of class Reference
def test_Reference():
    print("Testing constructor of class Reference:")
    print("Calling constructor without arguments:")
    reference_0 = Reference("reference_0")
    print("Testing done for:")
    print("Calling constructor without arguments:")
    schema_definitions_0 = SchemaDefinitions()

test_Reference()



# Generated at 2022-06-26 10:32:59.972473
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass


# Generated at 2022-06-26 10:33:02.293299
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    assert 1==len(schema_0)


# Generated at 2022-06-26 10:33:03.660335
# Unit test for constructor of class Reference
def test_Reference():
    reference_0 = Reference(schema_definitions_0)


# Generated at 2022-06-26 10:33:12.533043
# Unit test for function set_definitions
def test_set_definitions():
    try:
        set_definitions(None, None)
    except Exception as e:
        assert False, f"`test_set_definitions` raised exception: {e.__class__.__name__}: {e}"

    definitions = {"name": "test"}
    field = Object(properties={"a": "test"}, definitions=definitions)
    set_definitions(field, definitions)
    assert field.definitions == {"name": "test"}
    field = Object(properties={"a": "test"})
    set_definitions(field, definitions)
    assert field.definitions == {"name": "test"}

    definitions = {"name": "test"}
    field = Array(items=[Object(properties={"a": "test"}, definitions=definitions)])
    set_definitions(field, definitions)

# Generated at 2022-06-26 10:33:22.090155
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import unittest
    import sys

    class Test_Schema___iter__(unittest.TestCase):
        def test_ret(self):
            from io import StringIO
            from unittest.mock import patch

            saved_stdout = sys.stdout
            try:
                out = StringIO()
                sys.stdout = out

                schema_definitions = SchemaDefinitions()
                schema_definitions["TestObj"] = TestObj

                TestObj(name="John Doe", age="a")
                result = out.getvalue().strip()
                self.assertEqual(result, "name")
            finally:
                sys.stdout = saved_stdout



# Generated at 2022-06-26 10:33:23.810340
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0['test'] = 'test'


# Generated at 2022-06-26 10:33:45.189586
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test case 0
    schema_definitions_0 = SchemaDefinitions()
    # SchemaMetaclass.__new__()
    schema_metaclass_0 = SchemaMetaclass.__new__(type, '', (), {}, schema_definitions_0)
    assert isinstance(schema_metaclass_0, type)
    assert not hasattr(schema_metaclass_0, 'fields')
# Test case 1: class has no fields.
    # we need to define the new module to test the __new__ of class
    class User(Schema, definitions=schema_definitions_0):
        pass
    # SchemaMetaclass.__new__()
    schema_metaclass_1 = SchemaMetaclass.__new__(type, '', (), {}, schema_definitions_0)

# Generated at 2022-06-26 10:33:53.914264
# Unit test for function set_definitions
def test_set_definitions():
    class T1(Schema):
        class Meta:
            definitions = SchemaDefinitions()
        f1 = Reference(to=1)
        f2 = Reference(to=2)
    class T2(Schema):
        class Meta:
            definitions = SchemaDefinitions()
        f1 = Reference(to=1)
        f2 = Reference(to=1)
    def check(schema):
        assert schema.fields['f1'].target == 2
        assert schema.fields['f2'].target == 1
    check(T1)
    check(T2)


# Generated at 2022-06-26 10:33:57.674426
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    set_definitions(field_0, schema_definitions_0)



# Generated at 2022-06-26 10:34:08.409925
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import String
    from typesystem import Schema, Reference
    from typesystem import Object, Array, Integer
    schema_definitions_0 = SchemaDefinitions()
    class Node(Schema):
        contents = Array(String)
    class NodeRef(Reference):
        to = "Node"
    class DocumentSchema(Schema):
        nodes = Array(NodeRef)
    schema_definitions_0["Node"] = Node
    schema_definitions_0["NodeRef"] = NodeRef
    schema_definitions_0["DocumentSchema"] = DocumentSchema
    arg0 = [["0", "1"]]
    arg1 = {"nodes":[arg0]}
    schema_0 = DocumentSchema.validate(arg1)

# Generated at 2022-06-26 10:34:11.546271
# Unit test for constructor of class Schema
def test_Schema():
    print("test_Schema")
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
# Unit tests for class Schema



# Generated at 2022-06-26 10:34:12.964985
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Validating object returned by Schema, will throw exception if invalid.
    obj = Schema(to=str, definitions=SchemaDefinitions())
    # TODO: Replace this assert with a proper unit test assertion
    assert True



# Generated at 2022-06-26 10:34:20.597368
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class_names_0 = [
        "Schema",
        "Mapping",
        "ABCMeta",
        "type"
    ]
    class_names = []
    for i in range(len(class_names_0)):
        class_names.append(class_names_0[i])
    class_0 = globals()[class_names[0]]
    class_1 = globals()[class_names[1]]
    class_2 = globals()[class_names[2]]
    class_3 = globals()[class_names[3]]
    class_arguments = {}
    class_arguments["Schema"] = {}
    class_arguments["Mapping"] = {}
    class_arguments["ABCMeta"] = {}
    class_

# Generated at 2022-06-26 10:34:22.560619
# Unit test for constructor of class Schema
def test_Schema():
  assert Schema.fields == {}

# Generated at 2022-06-26 10:34:34.244514
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Animal(Schema):
        name = Field(type=str)
        age = Field(type=int)
        tags = Array(items=Field(type=str))

    class Dog(Animal):
        sound = Field(type=str)

    class Cat(Animal):
        sound = Field(type=str)

    class Zoo(Schema):
        dog = Reference(to=Dog)
        cats = Reference(to=Cat)
        animals = Array(items=Reference(to="Animal"))
        empty = Field(type=list)

    class ZooWithoutDefinitions(Schema):
        dog = Reference(to=Dog)
        cats = Reference(to=Cat)
        animals = Array(items=Reference(to="Animal"))
        empty = Field(type=list)


# Generated at 2022-06-26 10:34:43.858591
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0.__setitem__("Str", "Str")
    schema_definitions_0.__setitem__("Schema", Schema)
    schema_definitions_0.__setitem__("SchemaMetaclass", SchemaMetaclass)
    schema_definitions_0.__setitem__("Reference", Reference)
    schema_definitions_0.__setitem__("Mapping", Mapping)
    schema_definitions_0.__setitem__("MutableMapping", MutableMapping)
    schema_definitions_0.__setitem__("SchemaDefinitions", SchemaDefinitions)
    schema_definitions_0.__setitem__("ABCMeta", ABCMeta)

# Generated at 2022-06-26 10:35:33.820555
# Unit test for function set_definitions
def test_set_definitions():
    # Check for set_definitions for all the possible cases
    schema_definitions = SchemaDefinitions()
    class A(Schema):
        name = Field()
    a = A()
    set_definitions(a,schema_definitions)
    a1 = A(name = "abc")
    set_definitions(a1,schema_definitions)
    class B(Schema):
        b = Reference("A")
    b = B()
    set_definitions(b,schema_definitions)
    b1 = B(b = a1)
    set_definitions(b1,schema_definitions)
    class C(Schema):
        c = Reference("A")
    c = C(c = "abc")
    set_definitions(c,schema_definitions)

# Generated at 2022-06-26 10:35:46.238313
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():

    schema_definitions_0 = SchemaDefinitions()
    class TestSchema0(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        field_0 = Field(required=False)

    class TestSchema1(TestSchema0):
        field_0 = Field(required=False)

    class TestSchema2(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        field_0 = Field(required=False)

    class TestSchema3(TestSchema2):
        field_0 = Field(required=False)

    for _ in range(6):
        testSchema0 = TestSchema0()
        testSchema1 = TestSchema1()
        testSchema2 = TestSchema2()
        testSchema

# Generated at 2022-06-26 10:35:53.595182
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_1 = SchemaDefinitions()
    # SchemaClass_1 = Custom Schema that contains a Reference field with None as
    # the value of "definitions"
    # Field_1 = Reference field within SchemaClass_1 with None as the value of
    # "definitions"
    definitions_1 = {'SchemaClass_1': SchemaClass_1, 'Field_1': Field_1}
    expected_result_1 = {'SchemaClass_1': SchemaClass_1, 'Field_1': Field_1}
    assert set_definitions(schema_definitions_1, definitions_1) == expected_result_1
    schema_definitions_2 = SchemaDefinitions()
    # SchemaClass_2 = Custom Schema that contains a Reference field with a
    # SchemaDefinitions instance as

# Generated at 2022-06-26 10:35:56.029793
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert isinstance(schema_0, Schema)


# Generated at 2022-06-26 10:35:59.292517
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String(max_length=100)

    person_1 = Person(name="John Doe")
    len(person_1)
    len(Person())


# Generated at 2022-06-26 10:36:00.797130
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:36:13.424804
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0, fields={})
    assert [key for key in iter(schema_0)] == []
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0, fields={"field_0": None})
    assert [key for key in iter(schema_0)] == []
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0, fields={"field_0": None})
    schema_0.field_0 = None
    assert [key for key in iter(schema_0)] == ["field_0"]
    schema_definitions_0 = SchemaDefinitions()

# Generated at 2022-06-26 10:36:15.352422
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert isinstance(schema_definitions_0.__iter__(), collections.abc.Iterator)


# Generated at 2022-06-26 10:36:21.574831
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    class StringSchema(Schema,schema_definitions=schema_definitions_0):
        string = String()
    instance = StringSchema(string='foo')
    expected1 = "foo"
    obtained1 = instance.__getitem__('string')
    assert obtained1 == expected1
    with raises(KeyError):
        instance.__getitem__('foo')


# Generated at 2022-06-26 10:36:27.784740
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    class_1 = SchemaMetaclass(
        str,
        (),
        {},
        definitions=schema_definitions_0,
    )


# Generated at 2022-06-26 10:37:17.452847
# Unit test for constructor of class Reference
def test_Reference():
    with pytest.raises(AttributeError):
        Reference("to")
    with pytest.raises(AssertionError):
        Reference("to" , definitions=schema_definitions_0)
    with pytest.raises(AssertionError):
        Reference("to" , definitions=schema_definitions_0)


# Generated at 2022-06-26 10:37:21.805564
# Unit test for constructor of class Schema
def test_Schema():
    class Employee(Schema):
        name = String(required=True)
        age = Integer()
    
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 10:37:26.867092
# Unit test for constructor of class Reference
def test_Reference():
    assert issubclass(Reference, Field)
    assert isinstance(Reference.__init__, types.FunctionType)
    assert isinstance(Reference.__doc__, str)
    assert isinstance(Reference.to, str)
    assert isinstance(Reference.definitions, str)
    assert Reference.errors == {'null': 'May not be null.'}


# Generated at 2022-06-26 10:37:39.153887
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()

    class Person(Schema, definitions=schema_definitions_0):

        class Meta:
            _creation_counter = 0

        _creation_counter_1 = 3
        name = Field(default="", label="", description="")
        _creation_counter_2 = 2
        age = Field(label="", description="")
        _creation_counter_3 = 1
        sex = Field(label="", description="")
        _creation_counter_4 = 0
        dob = Field(label="", description="")

        _creation_counter_5 = 4
        def get_age(self) -> int:
            return self.age

    assert repr(Person()) == "Person(name='', sex=None)"

# Generated at 2022-06-26 10:37:53.267433
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.base import Type, ValidationError

    class BaseField(Type):
        errors = {"null": "May not be null."}

        def __init__(self, *, allow_null: bool = False, **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)
            self.allow_null = allow_null

        def validate(self, value: typing.Any, *, strict: bool = False) -> typing.Any:
            if value is None and self.allow_null:
                return None
            elif value is None:
                raise self.validation_error("null")
            else:
                return value


# Generated at 2022-06-26 10:38:02.120592
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import Object, String

    class Book(Schema):
        title = String()

    class Author(Schema):
        books = Array(items=Reference(to=Book))

        class Meta:
            definitions = schema_definitions_0

    ref = Reference(to=Author)
    assert ref.target == Author

    class Library(Schema):
        authors = Array(items=Reference(to=Author))
        books = Array(items=Reference(to="Book"))

        class Meta:
            definitions = schema_definitions_0

    references = Library.fields["books"].items
    assert references.target_string == "Book"
    assert references.target == Book

# Generated at 2022-06-26 10:38:07.152284
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # create a class
    class TestClass(Schema):
        pass
    # check if the class is created
    assert isinstance(TestClass, Schema)
    # check if the class is created
    assert isinstance(TestClass(), TestClass)
    # create two instances of the class
    object_1 = TestClass()
    object_2 = TestClass()
    # check if the instances are equal
    assert object_1 == object_2

# Generated at 2022-06-26 10:38:17.991058
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_definitions_1 = SchemaDefinitions()
    definition_1_2 = Schema()
    definition_1_2.fields = {
        "name": fields.String(max_length=255),
        "last_modified": fields.DateTime(),
    }
    definition_1_2.__name__ = "ExampleDefinition1"
    schema_definitions_1["ExampleDefinition1"] = definition_1_2
    example_schema_2 = Schema()
    example_schema_2.fields = {
        "ref": Reference(to="ExampleDefinition1", definitions=schema_definitions_1),
    }
    example_schema_2.__name__ = "ExampleSchema2"
    schema_definitions_1["ExampleSchema2"] = example_schema_2

# Generated at 2022-06-26 10:38:18.842821
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    test_case_0()
    print("passed")

# Generated at 2022-06-26 10:38:24.000094
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from copy import deepcopy
    from typesystem.base import Field
    from typesystem.types import Integer

    schema = SchemaDefinitions()

    schema["Test"] = Integer()

    test = schema["Test"]
    test = deepcopy(test)
    test._creation_counter = 0
    assert test.__repr__() == "Integer(required=True, description=None, name=None)"

# Generated at 2022-06-26 10:40:15.279600
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    assert not len(schema_definitions_0)
    assert not len(schema_definitions_1)

    class BaseSchema(Schema, metaclass=SchemaMetaclass):
        name = Field()

    class SubSchema0(BaseSchema, metaclass=SchemaMetaclass):
        age = Field()

    class SubSchema1(BaseSchema, metaclass=SchemaMetaclass):
        age = Field()

    assert len(schema_definitions_0) == 0
    assert len(schema_definitions_1) == 0

    class SubSchema2(Schema, metaclass=SchemaMetaclass):
        name = Field()
        age = Field

# Generated at 2022-06-26 10:40:26.662319
# Unit test for constructor of class Reference
def test_Reference():
    test_item = Reference(to="str", nullable=True, additional_properties=False)
    assert test_item.to == "str"
    assert test_item.allow_null == True
    assert test_item.additional_properties == False
    assert test_item.definitions == None
    assert test_item.errors["null"] == "May not be null."
    test_item_1 = Reference(to="str", definitions=schema_definitions_0)
    assert test_item_1.to == "str"
    assert test_item_1.definitions == schema_definitions_0
    assert test_item_1.errors["null"] == "May not be null."
    test_item_2 = Reference(to="str", nullable=False)
    assert test_item_2.to == "str"
   

# Generated at 2022-06-26 10:40:28.385033
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass

# Utility functions



# Generated at 2022-06-26 10:40:36.286077
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()
    class MySchema(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_0):
        schema_id = 'MySchema'
        value = Field()
    my_schema_0 = MySchema(value=1)
    actual = my_schema_0.__repr__()
    expected = 'MySchema(value=1)'
    assert actual == expected


# Generated at 2022-06-26 10:40:46.650309
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # class A(Schema):
    #     id = Integer(primary=True)
    #     x = Integer()

    # class B(Schema):
    #     id = Integer(primary=True)
    #     x = Integer()

    # assert A(id=1, x=2) == A(id=1, x=2)
    # assert A(id=1, x=2) != A(id=2, x=2)
    # assert A(id=1) == A(id=1)
    # assert A(id=1) != B(id=1)
    pass



# Generated at 2022-06-26 10:40:56.324401
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_fields_0 = {}
    schema_0 = Schema("mySchema", (), schema_fields_0, schema_definitions_0)
    schema_definitions_0["mySchema"] = schema_0
    schema_definitions_0["mySchema"]
    schema_definitions_0.__iter__()
    for key in schema_definitions_0:
        print(key)
