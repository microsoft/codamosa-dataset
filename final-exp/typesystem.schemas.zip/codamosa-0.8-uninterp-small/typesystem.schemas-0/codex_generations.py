

# Generated at 2022-06-26 10:31:28.067348
# Unit test for constructor of class Schema
def test_Schema():
    # Test the __init__ constructor of the Schema class.
    pass


# Generated at 2022-06-26 10:31:40.233820
# Unit test for method validate of class Reference
def test_Reference_validate():
    def test_Reference_validate_with_valid_data():
        schema_0 = Schema()
        value_0 = Reference(to="Schema")
        value_1 = value_0.validate(schema_0)
        assert value_1 == schema_0
        assert value_1 is not schema_0
    test_Reference_validate_with_valid_data()

    def test_Reference_validate_with_invalid_data():
        schema_0 = Schema()
        value_0 = Reference(to="Schema")

        with pytest.raises(ValidationError) as error:
            value_0.validate(None)
        assert error.value.messages()[0].text == "May not be null."
    test_Reference_validate_with_invalid_data()


# Unit test

# Generated at 2022-06-26 10:31:41.898362
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert len(schema_0) == 0


# Generated at 2022-06-26 10:31:51.360126
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    animal_validator = Object(
        properties={
            "name": String(max_length=30),
            "age": Integer(minimum=0),
        },
        required=["name"],
    )

    class Animal(Schema):
        name = String(max_length=30)
        age = Integer(minimum=0)

    class Sheep(Schema):
        name = String(max_length=30)
        age = Integer(minimum=0)
        wool_type = String(enum=["LONG", "MEDIUM", "FINE", "CROSSBRED"])

    assert animal_validator.properties == Animal.fields

    assert isinstance(Animal.fields["name"], String)
    assert isinstance(Animal.fields["age"], Integer)

    assert isinstance(Sheep.fields["name"], String)

# Generated at 2022-06-26 10:31:53.424150
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_1 = Schema()
    schema_2 = Schema()
    assert schema_1 == schema_2


# Generated at 2022-06-26 10:32:00.793414
# Unit test for function set_definitions
def test_set_definitions(): 
    definitions = SchemaDefinitions()
    set_definitions(String(), definitions)
    assert not definitions
    set_definitions(
        Reference(to="person"),
        SchemaDefinitions(
            person=Schema(
                given_name=String(max_length=12),
                surname=String(max_length=12),
            )
        ),
    )


# Generated at 2022-06-26 10:32:05.099030
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    TestClass = type(
        "TestClass", (Schema,), {"test_field_0": Field(required=True)}
    )
    assert "test_field_0" in TestClass(test_field_0="test value 0")


# Generated at 2022-06-26 10:32:08.405482
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Object
    from typesystem import String

    class Pet(Schema):
        name = String()

    assert set(Pet()) == {'name'}



# Generated at 2022-06-26 10:32:10.362846
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    assert schema_0.__eq__(schema_0) is True


# Generated at 2022-06-26 10:32:20.278039
# Unit test for function set_definitions
def test_set_definitions():
    class SchemaX(Schema):
        definition_1 = Object(title="definition 1")
        definition_2 = Object(title="definition 2")

    definition_1 = SchemaX.fields["definition_1"]
    definition_2 = SchemaX.fields["definition_2"]

    class SchemaY(Schema):
        definition_3 = Object(title="definition 3")
        definition_4 = Object(title="definition 4")

    definition_3 = SchemaY.fields["definition_3"]
    definition_4 = SchemaY.fields["definition_4"]

    class SchemaZ(Schema):
        definition_5 = Object(title="definition 5")

    definition_5 = SchemaZ.fields["definition_5"]

    # definition_1 = definition_2 = definition_3 = definition_4 = definition_5

# Generated at 2022-06-26 10:32:43.137628
# Unit test for function set_definitions
def test_set_definitions():
    # Init SchemaDefinitions
    definitions = SchemaDefinitions()
    form = SchemaDefinitions()

    # Test case 1: test with field: reference
    # Init reference field
    reference = Reference(u"Name")
    set_definitions(reference, definitions)
    assert definitions == form

    # Test case 2: test with field: object
    # Init object field
    object_field = Object()
    set_definitions(object_field, definitions)
    assert definitions == form

    # Test case 3: test with field: array
    # Init array field
    array_field = Array()
    set_definitions(array_field, definitions)
    assert definitions == form

    # Test case 4: test with field: field
    # Init field
    test_field = Field()
    set_definitions(test_field, definitions)


# Generated at 2022-06-26 10:32:52.571780
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    definitions["pet"] = Schema
    class Cat(metaclass=SchemaMetaclass):
        species = Field(description="E.g. 'cat' or 'dog'")
        name = Field(description="The name of the pet")
    class Person(metaclass=SchemaMetaclass):
        name = Field(description="The name of the person")
        pet = Reference(to="pet", definitions=definitions)
    assert Cat.make_validator() is Cat.fields.get("species")
    assert Person.make_validator() is Person.fields.get("pet")


# Generated at 2022-06-26 10:33:01.974451
# Unit test for function set_definitions
def test_set_definitions():
    person_schema = {
        "name": "string",
        "age": {"type": "integer"},
        "email": {"type": "string", "format": "email"},
    }
    company_schema = {
        "name": "string",
        "member": {"$ref": "#/definitions/person"},
    }
    definitions = SchemaDefinitions(
        {"person": person_schema, "company": company_schema}
    )
    definitions = SchemaDefinitions(
        {"person": person_schema, "company": company_schema}
    )
    assert "person" in definitions
    assert "company" in definitions

# Generated at 2022-06-26 10:33:05.397667
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    expected_result_0 = iter(dict())
    actual_result_0 = schema_0.__iter__()
    assert expected_result_0 == actual_result_0


# Generated at 2022-06-26 10:33:10.239776
# Unit test for function set_definitions
def test_set_definitions():
    array_0 = Array()
    schema_0 = Schema()
    str = ""
    dict_0 = {}
    assert set_definitions(array_0, dict_0) is None
    assert set_definitions(array_0, str) is None
    assert set_definitions(array_0, schema_0) is None


# Generated at 2022-06-26 10:33:15.077139
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.integer import Integer
    from typesystem.string import String
    class Person(Schema):
        name = String()
        age = Integer()

    p = Person(name='bob')
    assert (len(p) == 1)



# Generated at 2022-06-26 10:33:24.846350
# Unit test for function set_definitions
def test_set_definitions():
    class Schema0(Schema):
        string_field = Field(type="string")
        text_field = Field(type="text")
        array_field = Array(
            items=("string_field", "text_field"),
            min_items=2,
            max_items=2,
        )
        reference_field = Reference("reference_schema")

    class Schema1(Schema):
        string_field = Field(type="string")
        text_field = Field(type="text")
        array_field = Array(
            items=("string_field", "text_field"),
            min_items=2,
            max_items=2,
        )
        reference_field = Reference("reference_schema")

    class ReferenceSchema(Schema):
        string_field = Field(type="string")
       

# Generated at 2022-06-26 10:33:30.325123
# Unit test for function set_definitions
def test_set_definitions():
    class ExampleSchema(Schema):
        x = Reference("y")

    definitions = SchemaDefinitions()
    set_definitions(ExampleSchema.fields["x"], definitions)

    assert ExampleSchema.fields["x"].definitions is definitions

    class ExampleSchema2(Schema):
        y = String()

    definitions[ExampleSchema2.__name__] = ExampleSchema2

    assert ExampleSchema.fields["x"].definitions is definitions
    assert ExampleSchema.fields["x"].target is ExampleSchema2.fields["y"]



# Generated at 2022-06-26 10:33:32.937399
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert isinstance(Schema().__len__(), int)
    assert Schema().__len__() == 0


# Generated at 2022-06-26 10:33:41.258835
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Assert that two equivalent Schema instances evaluate to equal
    schema_0 = Schema()
    schema_1 = Schema()
    assert schema_0 == schema_1

    # Assert that two inequivalent Schema instances evaluate to not equal
    schema_0 = Schema(field_0=1)
    schema_1 = Schema(field_1=1)
    assert not schema_0 == schema_1


# Generated at 2022-06-26 10:33:50.059168
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()

    assert schema_0.fields == {}


Schema.fields[str] = Schema

# Generated at 2022-06-26 10:33:54.949327
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    schema_0 = Schema()
    schema_1 = Schema()
    field = Reference(to=schema_0, definitions=definitions, title="Field")
    set_definitions(field, definitions)
    assert (
        field.definitions == definitions
    ), "Reference Field.definitions should be the same as definitions"


# Generated at 2022-06-26 10:34:05.149864
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Test 1
    # Create a sparse schema and test its repr
    schema_1 = Schema()
    assert repr(schema_1) == "Schema([sparse])"
    # Test 2
    # Create a schema with a non-key field and test its repr
    schema_2 = Schema(a=3)
    assert repr(schema_2) == "Schema(a=3, [sparse])"
    # Test 3
    # Create a schema with a key field and test its repr
    schema_3 = Schema(name="bob")
    assert repr(schema_3) == "Schema(name='bob')"


# Generated at 2022-06-26 10:34:08.633736
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    try:
        assert 0 == len(test_case_0())
    except Exception as e:
        print(f"Failed test_Schema___len__: {e}")


# Generated at 2022-06-26 10:34:18.950642
# Unit test for method validate of class Reference
def test_Reference_validate():
    # case 0
    schema_0 = Object(properties={"a": Integer()}, required=["a"])
    assert schema_0.validate({}) is ValidationError

    # case 1
    schema_1 = Reference(to=schema_0)
    assert None == schema_1.validate(None)
    assert ValidationError == schema_1.validate(1)

    # case 2
    schema_2 = Reference(to="schema_0")
    assert None == schema_2.validate(None)
    assert ValidationError == schema_2.validate(1)

    # case 3
    schema_3 = Reference(to="schema_0", definitions={"schema_0": schema_0})
    assert None == schema_3.validate(None)
    assert ValidationError == schema_3.valid

# Generated at 2022-06-26 10:34:22.765201
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    args = [0,0,0]
    obj = Schema(args[0])
    result = iter(obj)
    assert iter(result) == iter(result)


# Generated at 2022-06-26 10:34:34.454920
# Unit test for constructor of class Schema
def test_Schema():
    class A(Schema):
        pass

    a = A({})

    class B(Schema):
        f = Field(str)
        i = Field(int)

    b = B({
        'f': 'foo',
        'i': 1
    })
    assert b.f == 'foo'
    assert b.i == 1

    c = B(f='foo', i=1)
    assert c.f == 'foo'
    assert c.i == 1

    d = B(f='foo')
    assert d.f == 'foo'
    assert d.i == None

    e = B(i=1)
    assert e.f == None
    assert e.i == 1


# Generated at 2022-06-26 10:34:40.916335
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.fields import String
    from typesystem.schema import Reference

    class User(Schema):
        username = String()

    class Answer(Schema):
        user = Reference(User)
        text = String()

    user = User(username="qinqin")
    answer = Answer(user=user, text="Hello world!")
    assert answer.user.username == "qinqin"
    assert answer.text == "Hello world!"



# Generated at 2022-06-26 10:34:44.301373
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field = Field()
    instance = TestSchema()
    assert isinstance(iter(instance), collections.abc.Iterator)


# Generated at 2022-06-26 10:34:47.369593
# Unit test for constructor of class Reference
def test_Reference():
    if(Reference is not None):
        assert True
    else:
        assert False


# Generated at 2022-06-26 10:35:03.368908
# Unit test for function set_definitions
def test_set_definitions():
    class SchemaBook(Schema):
        title = Field()

    class SchemaAuthor(Schema):
        name = Field()

    class Schema0(Schema):
        author = Reference("SchemaAuthor")
        book = Reference(SchemaBook)
        books = Array(items=Reference(SchemaBook))

    definitions = SchemaDefinitions()
    set_definitions(Schema0.author, definitions)
    assert Schema0.author.definitions is definitions
    assert Schema0.book.definitions is definitions
    assert Schema0.books.definitions is definitions
    assert Schema0.books.items.definitions is definitions


# Generated at 2022-06-26 10:35:12.620756
# Unit test for function set_definitions
def test_set_definitions():
    test_schema = Schema()
    test_ref = Reference(to="MySchema")

    test_array_child = Array(items="MySchema")
    set_definitions(test_array_child, {})
    assert isinstance(test_array_child.items, Reference)
    assert test_array_child.items.definitions is None
    
    test_array_children = Array(items=[test_schema, test_ref])
    set_definitions(test_array_children, {})
    for item in test_array_children.items:
        assert isinstance(item, Reference)
        assert item.definitions is None

    test_object = Object(properties={"my_property": test_schema})
    set_definitions(test_object, {})

# Generated at 2022-06-26 10:35:24.539689
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import PositiveInt
    from typesystem import String
    from typesystem import Type
    from typesystem import schema
    
    # Check equality between two equivalent objects
    class Schema0(schema.Schema):
        field1 = Type(description='description1', name='name1')
    class Schema1(schema.Schema):
        field1 = Type(description='description1', name='name1')
    obj_equivalent_0 = Schema0()
    obj_equivalent_1 = Schema1()
    assert (obj_equivalent_0 == obj_equivalent_1) == True

    # Check equality between one object and an equivalent object with additional attributes
    class Schema2(schema.Schema):
        field1 = Type(description='description1', name='name1')

# Generated at 2022-06-26 10:35:31.881368
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Case 1:
    schema_1 = Schema()

    # Case 2:
    class A(Schema):
        bar = Field()

    # Case 3:
    class B(A):
        foobar = Field()

    # Case 4:
    class C(B):
        pass

    # Case 5:
    class D(B):
        foobar = Field(description="new description")

    # Case 6:
    class E(D):
        bar = Field(description="new description")

    # Case 7:
    class F(Schema):
        foo = Field()

    # Case 8:
    class G(Schema):
        foobar = Field()

    # Case 9:
    class H(G):
        bar = Field()

    # Case 10:

# Generated at 2022-06-26 10:35:33.439243
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    x = iter(schema_0)
    

# Generated at 2022-06-26 10:35:37.495875
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    try:
        schema_0 = Schema()
    except Exception as e:
        raise e
    else:
        assert schema_0._Schema__iter__() == ()


# Generated at 2022-06-26 10:35:48.636419
# Unit test for function set_definitions
def test_set_definitions():
    # Check method checks children recursively
    # Initialize with a single field and an array
    # parent_field = Object(properties = {'field_0': Integer(), 'field_1': Array(
    #     items=String(max_length=1), min_length=2, max_length=10)})

    parent_field = Object(properties = {'field_0': Integer(), 'field_1': Array(
        items=String(max_length=1), min_length=2, max_length=10)})
    
    definitions = SchemaDefinitions()

    set_definitions(parent_field, definitions)

    assert definitions == {} or definitions == None, "Test failed!"

    # Test for recursive function
    schema_0 = Schema()

# Generated at 2022-06-26 10:36:00.660560
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert schema_0.__len__() == 0
    schema_1 = Schema()
    assert schema_1.__len__() == 0
    schema_2 = Schema(arg1=None, arg2=None)
    assert schema_2.__len__() == 2
    schema_3 = Schema(arg1=None, arg2=None)
    assert schema_3.__len__() == 2
    schema_4 = Schema(arg1=None, arg2=12)
    assert schema_4.__len__() == 2
    schema_5 = Schema(arg1=None, arg2=12)
    assert schema_5.__len__() == 2
    schema_6 = Schema(arg1=None)
    assert schema_6.__len__() == 1


# Generated at 2022-06-26 10:36:04.013574
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert schema_0.__iter__() is not None

# Generated at 2022-06-26 10:36:14.098965
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_0 = Schema()
    schema_0 = Schema()
    schema_1 = Schema()
    schema_0 = Schema()
    schema_1 = Schema()
    schema_0 = Schema()
    schema_1 = Schema()
    schema_0 = Schema()
    schema_1 = Schema()
    schema_0 = Schema()
    schema_1 = Schema()
    schema_0 = Schema()
    schema_1 = Schema()
    schema_0 = Schema()
    schema_1 = Schema()
    schema_0 = Schema()
    schema_1 = Schema()
    schema_0 = Schema()
    schema_1 = Schema()
    schema_0 = Schema()
    schema_1 = Schema()
    schema_0 = Schema()
   

# Generated at 2022-06-26 10:36:26.859852
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    instance = Schema()
    assert instance.__len__() == 0


if __name__ == "__main__":
    test_case_0()
    test_Schema___len__()

# Generated at 2022-06-26 10:36:27.713765
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert repr(schema_0) == 'Schema()'



# Generated at 2022-06-26 10:36:29.017966
# Unit test for constructor of class Schema
def test_Schema():
    test_case_0()
    assert True

# Generated at 2022-06-26 10:36:35.864254
# Unit test for function set_definitions
def test_set_definitions():
    class User(Schema):
        id = Field(type="integer")
        name = Field(type="string")
    class Job(Schema):
        job_id = Field(type="integer")
        job_name = Field(type="string")
        job_user = Reference(to="User")
    job_definitions = SchemaDefinitions()
    set_definitions(Job.fields["job_user"],
                    job_definitions)
    assert job_definitions == {
        "User": User
    }, "Should be equal to `{'User': User}`"


# Generated at 2022-06-26 10:36:45.133069
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert len(schema_0) == 0
    map_1 = {}
    assert len(map_1) == 0
    schema_0 = Schema(map_1)
    assert len(schema_0) == 0
    map_1 = {"key_0": "value_0"}
    assert len(map_1) == 1
    schema_0 = Schema(map_1)
    assert len(schema_0) == 1


# Generated at 2022-06-26 10:36:47.166796
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert schema_0.__repr__() == 'Schema()'



# Generated at 2022-06-26 10:36:59.487843
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class_name = "SchemaMetaclass"
    # The call SchemaMetaclass.__new__(...) does not work because
    # SchemaMetaclass is a slot wrapper for abc.ABCMeta
    result = SchemaMetaclass.__new__.__get__(SchemaMetaclass)(
        SchemaMetaclass,
        "name",
        (object,),
        {},
        SchemaDefinitions(),
    )
    assert isinstance(result, type)
    assert result.__name__ == "name"
    assert result.fields == dict()


# Generated at 2022-06-26 10:37:08.772923
# Unit test for function set_definitions
def test_set_definitions():
    class SchemaA(Schema):
        field_a = Field()
        field_b = Field()
    class SchemaB(Schema):
        field_c = Reference("SchemaC")
        field_d = Field()
    class SchemaC(Schema):
        field_e = Field()
    class SchemaD(Schema):
        field_f = Reference("SchemaC")
        field_g = Field()

    definitions = SchemaDefinitions()
    set_definitions(SchemaB.fields["field_c"], definitions)
    set_definitions(SchemaD.fields["field_f"], definitions)

# Generated at 2022-06-26 10:37:09.677572
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert Schema() == Schema()


# Generated at 2022-06-26 10:37:12.616860
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test the empty case
    s = Schema()
    for e in s:
        assert False
    for k in s:
        assert False
    for v in s.values():
        assert False
    for k, v in s.items():
        assert False


# Generated at 2022-06-26 10:37:35.263104
# Unit test for function set_definitions
def test_set_definitions():
    # An empty schema
    class User0(Schema):
        name = String(required=True)

    # A non-empty schema referencing User0
    class Address0(Schema):
        s = String()
        user = Reference("User0")

    invalid_definitions = {}
    set_definitions(Address0, invalid_definitions)

    valid_definitions = SchemaDefinitions()
    valid_definitions["User0"] = User0
    set_definitions(Address0, valid_definitions)



# Generated at 2022-06-26 10:37:47.387610
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from pytest import raises
    from typesystem.fields import Integer

    class TestSchema(Schema):
        first_field = Integer()

    schema_0 = TestSchema()
    assert not (schema_0 == 'str')
    assert not (schema_0 == 3)
    with raises(TypeError):
        schema_0 == None

    schema_1 = TestSchema()
    schema_1.first_field = 1
    assert not (schema_1 == 'str')
    assert not (schema_1 == 3)
    with raises(TypeError):
        schema_1 == None

    schema_2 = TestSchema()
    schema_2.first_field = 2
    assert not (schema_2 == 'str')
    assert not (schema_2 == 3)

# Generated at 2022-06-26 10:37:49.203083
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_2 = Schema()
    assert repr(schema_2) == "Schema()"

# Generated at 2022-06-26 10:38:00.314910
# Unit test for constructor of class Schema
def test_Schema():
    # 1. Valid initialization
    test_case_1 = Schema.validate({"name": "Max"}, strict=True)
    test_case_2 = Schema.validate({"name": "Max", "age": 20}, strict=True)
    test_case_3 = Schema.validate({"name": "Max", "age": 20, "country": "USA"})

    # 2. Invalid initialization
    # Missing required name attribute
    try:
        test_case_4 = Schema.validate({"age": 20}, strict=True)
    except ValidationError:
        pass
    else:
        assert False

    # Missing required country attribute
    try:
        test_case_5 = Schema.validate({"name": "Max", "age": 20})
    except ValidationError:
        pass

# Generated at 2022-06-26 10:38:05.893638
# Unit test for function set_definitions
def test_set_definitions():
    # Case 0
    class TestCase0(Schema):
        pass
    definitions = SchemaDefinitions()
    set_definitions(TestCase0, definitions=definitions)
    # Case 1
    class TestCase1(Schema):
        foo = Reference("bar")
    class_definitions = SchemaDefinitions()
    set_definitions(TestCase1, definitions=class_definitions)


# Generated at 2022-06-26 10:38:08.328354
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_1 = Schema(name="Teddy")
    assert(schema_1["name"] == "Teddy")


# Generated at 2022-06-26 10:38:19.103477
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.fields import Integer, String
    from typesystem.types import AnyType
    class TestArray(Array):
        def __init__(self, items, definitions=None, **kwargs):
            super().__init__(items, definitions=definitions, **kwargs)
    class TestObject(Object):
        def __init__(self, properties, definitions=None, **kwargs):
            super().__init__(properties, definitions=definitions, **kwargs)
    class TestReference(Reference):
        def __init__(self, to, definitions=None, **kwargs):
            super().__init__(to, definitions=definitions, **kwargs)

# Generated at 2022-06-26 10:38:26.044843
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class_name = 'Test'
    bases = (Schema,)
    attrs = {'field1': Field()}
    definitions = SchemaDefinitions()
    attrs = SchemaMetaclass(class_name, bases, attrs, definitions=definitions)
    assert isinstance(attrs, type)
    assert isinstance(attrs.fields, dict)
    assert attrs.fields['field1'] == Field()
    assert isinstance(definitions, SchemaDefinitions)
    assert 'Test' in definitions._definitions.keys()
    assert definitions._definitions['Test'] == attrs


# Generated at 2022-06-26 10:38:27.575953
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema()
    assert schema.fields.keys() == set()


# Generated at 2022-06-26 10:38:32.263285
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Reference to a class
    schema_0 = Schema()
    ref_0 = Reference(schema_0)
    # validate an object whose type is not a subclass of Schema
    ref_0.validate({})

    # Reference to a string
    schema_1 = Schema()
    ref_0 = Reference(schema_1.__name__)

    # Reference to a class
    schema_2 = Schema()
    ref_0 = Reference(schema_2)
    # validate an object whose type is a subclass of Schema
    ref_0.validate(schema_2.validate({}))

# Generated at 2022-06-26 10:39:08.680869
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    with pytest.raises(TypeError):
        schema_0 = Schema()
        schema_0.__iter__()


# Generated at 2022-06-26 10:39:15.289665
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test 1: No attribute is set
    schema_1 = Schema()
    assert [key for key in schema_1] == []
    assert dict(schema_1) == {}

    # Test 2:
    schema_2 = Schema(a=1, b=2, c=3)
    assert [key for key in schema_2] == ["a", "b", "c"]
    assert dict(schema_2) == {"a": 1, "b": 2, "c": 3}

    # Test 3:
    schema_3 = Schema(d=4, e=5, f=6)
    assert [key for key in schema_3] == ["d", "e", "f"]
    assert dict(schema_3) == {"d": 4, "e": 5, "f": 6}

# Unit test

# Generated at 2022-06-26 10:39:17.436009
# Unit test for constructor of class Schema
def test_Schema():
    assert test_case_0() == None

# Generated at 2022-06-26 10:39:22.047165
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    try:
        assert repr(schema_0) == "Schema()"
    except:
        raise AssertionError("Assertion failed on statement 'assert repr(schema_0) == \"Schema()\"'")


# Generated at 2022-06-26 10:39:23.263841
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema = Schema()
    assert schema.fields == {}

# Generated at 2022-06-26 10:39:25.724800
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Case 0
    assert repr(schema_0) == "Schema()"



# Generated at 2022-06-26 10:39:30.906728
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        x = Field()
    class Bar(Schema):
        y = Reference(to=Foo)

    definitions = SchemaDefinitions()
    set_definitions(Bar.fields["y"], definitions)
    assert definitions == {"Foo": Foo}

# Generated at 2022-06-26 10:39:33.930812
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    N = 'a'
    schema = Schema(**N)
    schema.__iter__()

# Generated at 2022-06-26 10:39:39.237193
# Unit test for function set_definitions
def test_set_definitions():
    # Setup
    field = Field()
    defs = SchemaDefinitions()

    # Execution
    set_definitions(field, defs)

    # Verification
    assert field.definitions == defs


# Generated at 2022-06-26 10:39:44.092161
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_0 = Schema()
    reference_0 = Reference(
        to = schema_0,
        definitions = {schema_0.__class__.__name__: schema_0},
    )
    validated_value = reference_0.validate(
        value = schema_0,
    )
    assert validated_value == schema_0


# Generated at 2022-06-26 10:40:29.125978
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    schema_1 = Schema(email="example@gmail.com", name="emily")
    schema_2 = Schema({"email":"example@gmail.com", "name":"emily"})
    schema_3 = Schema(schema_1)
    assert schema_1.email == "example@gmail.com"
    assert schema_1.name == "emily"
    assert schema_2.email == "example@gmail.com"
    assert schema_2.name == "emily"
    assert schema_3.email == "example@gmail.com"
    assert schema_3.name == "emily"


# Generated at 2022-06-26 10:40:38.403123
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_1 = Schema(
            a = 1,
            b = 2,
            c = 4
    )
    # Test 1
    result = set()
    for key in schema_1:
        result.add(key)
    assert result == {'a', 'b', 'c'}
    # Test 2
    schema_2 = Schema(
            a = 1,
            b = 2,
            c = 3
    )
    result = set()
    for key in schema_2:
        result.add(key)
    assert result == {'a', 'b', 'c'}
    # Test 3
    schema_3 = Schema(
            a = 1,
            b = 2,
            c = 3
    )
    result = set()
    for key in schema_3:
        result.add

# Generated at 2022-06-26 10:40:45.513840
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import String

    class SimpleSchema(Schema):
        name = String(required=True)

    schema = SimpleSchema(name="Foo")
    assert repr(schema) == "SimpleSchema(name='Foo')"

    schema = SimpleSchema()
    assert repr(schema) == "SimpleSchema() [sparse]"



# Generated at 2022-06-26 10:40:49.080806
# Unit test for function set_definitions
def test_set_definitions():
    schema_0 = Schema()
    definitions = SchemaDefinitions()
    set_definitions(schema_0, definitions)

# Generated at 2022-06-26 10:40:56.186162
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Schema_0(Schema):
        pass

    instance_0 = Schema_0()
    instance_1 = Schema_0()
    instance_2 = Schema_0()
    instance_2_1 = Schema_0()
    assert instance_0 == instance_1
    assert instance_0 != instance_2
