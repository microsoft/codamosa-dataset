

# Generated at 2022-06-26 10:31:28.457624
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Success case:
    # Test if the right iterator is returned when class Schema
    # is called.
    schema_0 = Schema()
    assert_equal(schema_0.__iter__(), iter([]))


# Generated at 2022-06-26 10:31:35.233799
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Field()
        baz = Reference("Bar", required=True)
        qux = Reference(Bar)

    class Bar(Schema):
        foo = Field()

    definitions = SchemaDefinitions()
    set_definitions(Foo.make_validator(), definitions)
    assert len(definitions) == 1


# Tests for Reference and Reference.validate

# Generated at 2022-06-26 10:31:38.245910
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    value_1 = (schema_0 == object())
    assert value_1



# Generated at 2022-06-26 10:31:41.969590
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    with pytest.raises(AssertionError):
        class TestCase0(Schema):
            def __init__(self, *args: typing.Any, **kwargs: typing.Any):
                super().__init__(*args, **kwargs)
        _ = TestCase0()



# Generated at 2022-06-26 10:31:51.351170
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_metaclass_0 = SchemaMetaclass
    definitions_0 = SchemaDefinitions()
    name_0 = 'Schema'
    bases_0 = (Mapping,)
    attrs_0 = {'fields': {}}
    schema_0 = schema_metaclass_0.__new__(schema_metaclass_0, name_0, bases_0, attrs_0, definitions_0)
    name_1 = 'Person'
    bases_1 = (schema_0,)
    attrs_1 = {'first_name': CharField(max_length=32), 'last_name': CharField(max_length=32)}

# Generated at 2022-06-26 10:32:03.510246
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String, Integer
    from typing import Dict, List, NamedTuple
    from typesystem.schemas import SchemaDefinitions

    definitions = SchemaDefinitions()
    assert definitions == {}

    class Person(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        first_name = String()
        last_name = String()
        age = Integer(minimum=0, maximum=130)

    assert definitions == {"Person": Person}

    assert Person.fields == {"first_name": String(), "last_name": String(), "age": Integer(minimum=0, maximum=130)}

    assert Person.first_name.name == "first_name"


# Generated at 2022-06-26 10:32:07.612938
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema = Schema()
    key = "key"
    try:
        schema.__getitem__(key)
        assert not "Exception should be thrown"
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 10:32:16.334830
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        foo = Reference("integer")
        bar = Reference("string")
        baz = Reference("float")

    definitions = SchemaDefinitions()
    definitions["integer"] = 123
    definitions["string"] = "hello"
    definitions["float"] = 0.25
    set_definitions(TestSchema, definitions)

    assert TestSchema.fields["foo"]._target == 123
    assert TestSchema.fields["bar"]._target == "hello"
    assert TestSchema.fields["baz"]._target == 0.25



# Generated at 2022-06-26 10:32:27.118693
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Test if function raises AssertionError when called with positional arguments
    try:
        schema_0 = Schema()
        schema_0.__repr__()
    except TypeError:
        print('Test passes!')
    except AssertionError:
        print('AssertionError raised!')
    else:
        print('Test fails!')

    # Test if function returns correct value

    # Test if function returns incorrect type

    # Test if function returns correct value when called with named arguments



# Generated at 2022-06-26 10:32:30.470217
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(schema_0) == "Schema()"


schema_1 = Schema(x=3.14, y=3)


# Generated at 2022-06-26 10:32:44.986853
# Unit test for function set_definitions
def test_set_definitions():
    class SomeField(Field):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            kwargs.setdefault("required", True)
            super().__init__(*args, **kwargs)
    
    definitions = SchemaDefinitions({'SomeField': SomeField})
    reference = Reference(to='Nonexistent')
    set_definitions(reference, definitions)
    assert reference.definitions == definitions


# Generated at 2022-06-26 10:32:54.766028
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert isinstance(schema_0, Mapping)
    assert isinstance(schema_0, Schema)
    isinstance(schema_0.is_sparse, bool)
    assert isinstance(schema_0, Mapping)
    assert isinstance(schema_0, Schema)
    isinstance(schema_0.is_sparse, bool)
    assert isinstance(schema_0, Mapping)
    assert isinstance(schema_0, Schema)
    isinstance(schema_0.is_sparse, bool)
    assert isinstance(schema_0, Mapping)
    assert isinstance(schema_0, Schema)
    isinstance(schema_0.is_sparse, bool)

# Generated at 2022-06-26 10:32:58.374188
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    try:
        assert not (schema_0 == Schema())
    except:
        raise RuntimeError


# Generated at 2022-06-26 10:33:01.178707
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert schema_0.__repr__() == 'Schema()'
    

    
    
    
    

# Generated at 2022-06-26 10:33:09.320467
# Unit test for function set_definitions
def test_set_definitions():
    schema_1 = Schema()
    schema_2 = Schema()
    definitions = SchemaDefinitions({"schema_1": schema_1, "schema_2": schema_2})
    reference = Reference("schema_1")
    set_definitions(reference, definitions)
    assert(reference.definitions == definitions)
    assert(reference.target == schema_1)
    reference = Reference("schema_2")
    set_definitions(reference, definitions)
    assert(reference.definitions == definitions)
    assert(reference.target == schema_2)


# Generated at 2022-06-26 10:33:13.321223
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema = Schema() # noqa
    assert schema == schema
    assert not (schema != schema)
    assert not (schema is schema)


# Generated at 2022-06-26 10:33:15.078619
# Unit test for constructor of class Schema
def test_Schema():
    try:
        Schema.validate({})
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 10:33:17.108155
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema()
    assert schema.fields == {}



# Generated at 2022-06-26 10:33:20.434280
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    ## Checking that the method __iter__ of class Schema returns an iterator over length 0
    assert len(list(schema_0.__iter__())) == 0


# Generated at 2022-06-26 10:33:22.218404
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_1 = Schema()
    assert len(schema_1) == 0


# Generated at 2022-06-26 10:33:42.195017
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class schema_0(Schema):
        pass

    assert len(schema_0()) == 0

    # The number changes when the schema has attributes.
    class schema_1(Schema):
        test = Field(required=False)

    assert len(schema_1()) == 1

    class schema_2(Schema):
        test = Field(required=False)
        test2 = Field(required=False)
        test3 = Field(required=False)
        test4 = Field(required=False)
        test5 = Field(required=False)

    assert len(schema_2()) == 5



# Generated at 2022-06-26 10:33:52.967777
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert schema_0.__repr__() == "Schema()"

    schema_1 = Schema(1, 2, 3)
    assert schema_1.__repr__() == "Schema(1, 2, 3)"

    schema_2 = Schema(1, 2, 3)
    assert schema_2.__repr__() == "Schema(1, 2, 3)"

    meta = SchemaMetaclass(
        "Test", (object,), {}, SchemaDefinitions()
    )
    schema_3 = meta(1, 2, 3)
    assert schema_3.__repr__() == "Test(1, 2, 3)"


# Generated at 2022-06-26 10:33:56.071932
# Unit test for function set_definitions
def test_set_definitions():
    schema_0 = Schema()
    definitions = SchemaDefinitions()
    set_definitions(schema_0, definitions)
    assert definitions == {Schema.__name__: Schema}


# Generated at 2022-06-26 10:33:57.474927
# Unit test for constructor of class Reference
def test_Reference():
    assert isinstance(Reference(str), Reference)



# Generated at 2022-06-26 10:33:59.792707
# Unit test for function set_definitions
def test_set_definitions():
    schema = Schema()
    field = Field()
    definitions = SchemaDefinitions()
    set_definitions(field, definitions)


# Generated at 2022-06-26 10:34:02.025049
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    assert (repr(schema_0)) == "Schema()"
    return



# Generated at 2022-06-26 10:34:03.942013
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema({"a": 1, "b": 2})
    assert len(schema) == 2


# Generated at 2022-06-26 10:34:06.432608
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_1 = Schema(dict())
    iter(schema_1)
    schema_2 = Schema(dict())
    iter(schema_2)



# Generated at 2022-06-26 10:34:17.975378
# Unit test for method validate of class Reference
def test_Reference_validate():
    # mock definition
    class definition_dict(dict):
        def __getitem__(self, key):
            if key == 'testTarget':
                return Reference('testTarget', definitions=definition_dict(), **{})
            elif key == 'TestTarget':
                return Reference('TestTarget', definitions=definition_dict(), **{})
            else:
                return None

    # mock obj
    class obj:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)
        def validate_or_error(self, value):
            return ("return_validate_or_error_value",)

    # mock obj
    class array(list):
        def append(self, item):
             self.__add__(item)

    # mock reference


# Generated at 2022-06-26 10:34:31.027522
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_1 = Schema(
        properties={
            "num": Field(type="number"),
            "arr": Field(type="array", items=Field(type="string")),
        }
    )
    data_1 = {"num": 42, "arr": ["hello", "world"]}
    schema_2 = Schema(properties={"ref": Reference(to=schema_1)})
    data_2 = {"ref": data_1}
    schema_3 = Schema(
        properties={
            "ref": Reference(to=schema_1, allow_null=True, nullable=True),
            "other": Field(type="number"),
        }
    )
    data_3 = {"ref": data_1, "other": 42}

# Generated at 2022-06-26 10:34:42.521547
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:34:48.211761
# Unit test for constructor of class Schema
def test_Schema():
    def run_test():
        schema = Schema(name="Test", age=40)
        assert schema.name == "Test"
        assert schema.age == 40
        assert schema.fields == dict(name=None, age=None)

    run_test()



# Generated at 2022-06-26 10:34:56.147287
# Unit test for method validate of class Reference
def test_Reference_validate():
    definitions = SchemaDefinitions()
    ref = Reference("Person", definitions=definitions)
    assert ref.validate(None) == None
    definitions["Person"] = Person
    ref = Reference("Person", definitions=definitions)
    
    value = ref.validate({'name':'Daniel', 'age':23})
    assert isinstance(value, Person)
    assert value.name == 'Daniel'
    assert value.age == 23
    
    
    
    
    
    
    

# Generated at 2022-06-26 10:35:02.950533
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0["SchemaChild_0"] = SchemaChild_0 = type("SchemaChild_0", (Schema,), {"fields": {}})
    schema_definitions_0["SchemaGrandchild_0"] = SchemaGrandchild_0 = type("SchemaGrandchild_0", (Schema,), {"fields": {}})
    schema_definitions_0["SchemaGrandgrandchild_0"] = SchemaGrandgrandchild_0 = type("SchemaGrandgrandchild_0", (Schema,), {"fields": {}})
    schema_definitions_0["SchemaGrandgrandchild_1"] = SchemaGrandgrandchild_1 = type("SchemaGrandgrandchild_1", (Schema,), {"fields": {}})
    schema_definitions_

# Generated at 2022-06-26 10:35:03.541247
# Unit test for constructor of class Reference
def test_Reference():
    pass

# Generated at 2022-06-26 10:35:05.047822
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert isinstance(Schema({}), Schema)
    assert not isinstance(object(), Schema)

# Generated at 2022-06-26 10:35:06.165931
# Unit test for function set_definitions
def test_set_definitions():
    pass #TODO: implement your test here


# Generated at 2022-06-26 10:35:08.082751
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    data_0 = Schema()
    assert repr(data_0) == "Schema()"

# Generated at 2022-06-26 10:35:17.233190
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from unittest import TestCase
    from unittest.mock import Mock
    from parameterized import parameterized, param

    test_cases = [
        param(
            "Returns the number of fields whose values are not None.",
        ),
    ]

    @parameterized.expand(test_cases)
    def test_len(test_case_str):
        class_0 = Schema() # type: Schema
        len_0 = len(class_0) # type: int



# Generated at 2022-06-26 10:35:24.113491
# Unit test for function set_definitions
def test_set_definitions():
    class SchemaA(Schema):
        a = Field()

    class SchemaB(Schema):
        a = Reference("SchemaA")

    schema_definitions_0 = SchemaDefinitions()

    # Ensure that the Reference field doesn't have a target set yet
    assert SchemaB.make_validator().properties["a"].target == None

    # Set the definitions for our schema
    set_definitions(SchemaB, schema_definitions_0)

    # Ensure that the Reference field now has a target
    assert SchemaB.make_validator().properties["a"].target == SchemaA

    # Ensure that other fields are not affected by the function
    assert SchemaB.fields["a"].target == None



# Generated at 2022-06-26 10:35:40.763414
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    """
    This method tests the __new__ method of the SchemaMetaclass class.
    """
    # Try to create a definition for a Schema
    definitions_0 = SchemaDefinitions()
    schema_0 = SchemaMetaclass.__new__(SchemaMetaclass, str(), (), {}, definitions_0)


# Generated at 2022-06-26 10:35:48.349473
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Initialize the required variables
    schema_field_0 = Object({})
    schema_definitions_0 = SchemaDefinitions()

    # Call the function on a mock for the class object
    try:
        # Create a mock for class Schema
        schema_mock_0 = Mock(spec=Schema)
        # Construct the object from the mock
        schema_object_0 = Schema(*(), **{})
        # Call the method __repr__ of the class object
        schema_result_0 = schema_object_0.__repr__()

    except ValidationError as error:
        pass



# Generated at 2022-06-26 10:36:00.351849
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    schema_1 = Schema(schema_definitions_0)
    bool_0 = schema_0 == schema_1
    bool_1 = schema_0 == schema_0
    bool_2 = schema_1 == schema_1
    bool_3 = schema_0 == schema_definitions_0
    bool_4 = schema_1 == schema_definitions_0
    bool_5 = schema_1 == schema_definitions_0
    bool_6 = schema_0 == schema_definitions_0
    assert bool_0 == bool_1 == bool_2 == bool_3 == bool_4 == bool_5 == bool_6
    assert bool_0 == False
    assert not bool_1
    assert bool

# Generated at 2022-06-26 10:36:07.027214
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert schema_0.__repr__() == 'Schema()'
    schema_1 = Schema(name='d')
    assert schema_1.__repr__() == "Schema(name='d')"


# Generated at 2022-06-26 10:36:15.108262
# Unit test for function set_definitions
def test_set_definitions():
    class Address0(Schema):
        street_address = Field(str)

    class Comment0(Schema):
        author_name = Field(str)
        text = Field(str)

    schema_definitions_0 = SchemaDefinitions()
    class Article0(Schema):
        author = Reference(Address0, definitions=schema_definitions_0)
        title = Field(str)
        comments = Array(Reference(Comment0))
    address0 = Address0(street_address='1 Main St.')
    comment0 = Comment0(author_name='Dr. Seuss', text='Good book.')
    article0 = Article0(author=address0, title='In the Hat', comments=[comment0])
    not_address0 = Address0(street_address='2 Main St.')

# Generated at 2022-06-26 10:36:20.793981
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    class Message(Schema):
        author = Reference(Person, definitions=schema_definitions_0)
        content = Field(str)

    schema_definitions_0["Person"] = Person

    person_0 = Person(name="Maurice Moss", age=35)


# Generated at 2022-06-26 10:36:34.523101
# Unit test for function set_definitions
def test_set_definitions():
    definitions_0 = SchemaDefinitions()
    field_0 = String()
    set_definitions(field_0, definitions_0)
    schema_0 = SchemaMetaclass(
        "Schema0",
        (),
        {},
        definitions_0,
    )
    set_definitions(schema_0, definitions_0)
    array_0 = Array(String())
    set_definitions(array_0, definitions_0)
    object_0 = Object(properties={})
    set_definitions(object_0, definitions_0)
    reference_0 = Reference("0", definitions_0)
    set_definitions(reference_0, definitions_0)

# Generated at 2022-06-26 10:36:38.770634
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema()
    output = schema.__iter__()
    assert output is not None



# Generated at 2022-06-26 10:36:42.618759
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    # Test case 0
    schema_definitions_0['key0'] = 'value0'
    assert(schema_definitions_0['key0'] == 'value0')


# Generated at 2022-06-26 10:36:50.829298
# Unit test for function set_definitions
def test_set_definitions():
    
    #Test case 1
    schema_definitions_1 = SchemaDefinitions()
    obj_1: Reference = Reference(to="test_string")
    set_definitions(field=obj_1, definitions=schema_definitions_1)
    assert obj_1.definitions == schema_definitions_1

    #Test case 2
    schema_definitions_2 = SchemaDefinitions()
    obj_2_f1: Reference = Reference(to="test_string_1")
    obj_2_f2: Reference = Reference(to="test_string_2")
    obj_2: Array = Array(items=[obj_2_f1, obj_2_f2])
    set_definitions(field=obj_2, definitions=schema_definitions_2)

# Generated at 2022-06-26 10:37:21.054716
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema_0(Schema, metaclass=SchemaMetaclass):
        prop_0 = Field(integer)
        prop_1 = Field(string)
        prop_2 = Field(boolean)
    ret_0 = isinstance(TestSchema_0(prop_0=1, prop_1='a string value', prop_2=True), Schema)
    ret_1 = isinstance(TestSchema_0(prop_1='a string value', prop_2=True), Schema)
    ret_2 = isinstance(TestSchema_0(prop_0=1, prop_2=True), Schema)
    ret_3 = isinstance(TestSchema_0(prop_0=1, prop_1='a string value'), Schema)


# Generated at 2022-06-26 10:37:28.802708
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema_0(Schema):
        """
        The schema for TestSchema_0
        """
        foo = String(max_length=10)
        bar = Integer(minimum=10)
    field_0 = TestSchema_0(
        {"foo": "foo", "bar": 10},
        definitions=schema_definitions_0,
    )
    if "foo" not in field_0:
        raise AssertionError("Failed to retrieve key `foo` from `field_0`")
    if "bar" not in field_0:
        raise AssertionError("Failed to retrieve key `bar` from `field_0`")


# Generated at 2022-06-26 10:37:30.494190
# Unit test for function set_definitions
def test_set_definitions():
    schema = Schema()
    assert schema.fields == {}


# Generated at 2022-06-26 10:37:32.436309
# Unit test for constructor of class Reference
def test_Reference():
  reference = Reference('')


# Generated at 2022-06-26 10:37:33.810798
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    print(SchemaMetaclass)



# Generated at 2022-06-26 10:37:39.504053
# Unit test for method validate of class Reference
def test_Reference_validate():
    definitions = SchemaDefinitions()
    item_0 = Reference('Planet')
    set_definitions(item_0, definitions)
    value_0 = {
        'name': 'Mercury',
        'temperature_range': (-173.15, 427.15)
    }
    result_0 = item_0.validate(value_0)
    assert result_0 == value_0
# Test for class SchemaMetaclass


# Generated at 2022-06-26 10:37:46.825409
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test for method __iter__ of class Schema (1/1)
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema(Schema):
        name = String(title="Name")
    schema = TestSchema(name="Foo")
    assert list(schema.__iter__()) == ["name"]


# Generated at 2022-06-26 10:37:48.288440
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert Schema().__repr__() == "Schema()"



# Generated at 2022-06-26 10:37:55.559799
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    from typing import Sequence
    from typesystem.fields import String
    class TestSchema_0(schema_definitions_0):
        name = String(max_length=100)
    result = TestSchema_0(name="name").__iter__()
    assert isinstance(result, Sequence) is False
    print('Test case 0: __init__(SchemaDefinitions, str)')
    print('Pass\n')



# Generated at 2022-06-26 10:37:57.201331
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert list(schema_0) == []


# Generated at 2022-06-26 10:38:21.816755
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_1['str'] = str
    schema_definitions_2 = SchemaDefinitions()
    schema_definitions_2['float'] = float
    schema_definitions_3 = SchemaDefinitions()
    schema_definitions_3['NoneType'] = None
    schema_definitions_4 = SchemaDefinitions()
    schema_definitions_4['bool'] = bool
    schema_definitions_5 = SchemaDefinitions()
    schema_definitions_5['abs'] = abs
    class Test_Schema(metaclass=SchemaMetaclass, definitions=schema_definitions_5):
        def __init__(self) -> None:
            pass

# Generated at 2022-06-26 10:38:27.078713
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()
    class TestSchema(Schema):
        foo: Field = field()
        bar: Field = field()
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0.__setitem__('mario', TestSchema)
    testSchema_0 = TestSchema(foo=1, bar=2)
    value_0 = testSchema_0.__len__()
    assert value_0 == 2


# Generated at 2022-06-26 10:38:34.345770
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():   
    def new_Schema(schema_definitions_0):
        @dataclass
        class NestedSchema(Schema):
            nested_key: str
        @dataclass
        class Schema(Schema):
            key: str
            nested: NestedSchema
        return Schema(
            {
                "key": "value",
                "nested": NestedSchema({"nested_key": "value"}),
            }
        )

    assert len(new_Schema(schema_definitions_0)) == 2


# Generated at 2022-06-26 10:38:37.250900
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    class String(Schema):
        value = String()
    string__0 = String(value='test')
    str_0 = string__0['value']
    assert str_0 == 'test'


# Generated at 2022-06-26 10:38:41.584099
# Unit test for method validate of class Reference
def test_Reference_validate():
    def test_Reference_validate_0():
        to = "test1"
        definitions = "test2"
        target_string = "test3"
        Reference_object = Reference(to=to, definitions=definitions, target_string=target_string)
        value = "test"
        strict = True
        Reference_object.validate(value, strict=strict)
        assert True



# Generated at 2022-06-26 10:38:45.780966
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_definitions_1 = SchemaDefinitions()
    
    
    
    
    
    
    
    
    
    
    
    return 0

# Generated at 2022-06-26 10:38:52.892492
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()

    class test_schema_0(Schema):
        field_0 = None

        class Meta:
            definitions = schema_definitions_0

    test_schema_0.fields["field_0"] = Field(
        name="field_0",
        description="This is a description.",
        required=True,
        nullable=False,
        default=None,
    )

    assert len(test_schema_0()) == 1



# Generated at 2022-06-26 10:38:57.845849
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_definitions_0 = SchemaDefinitions()
    value_0 = 12
    reference_0 = Reference("test_Reference", schema_definitions_0, nullable=False)
    reference_0.validate(value_0)



# Generated at 2022-06-26 10:39:00.864738
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert schema_0.__repr__() == 'Schema()'


# Generated at 2022-06-26 10:39:06.175216
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    #  Call __eq__
    assertReflectionEquals(schema_0, schema_0)



# Generated at 2022-06-26 10:39:17.959207
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()


# Generated at 2022-06-26 10:39:19.442548
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    return None



# Generated at 2022-06-26 10:39:24.287434
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()

    class Person(Schema, definitions=schema_definitions_0):
        forename = Field()
        surname = Field()

    person_0 = Person(forename="alice", surname="smith")
    assert len(person_0) is 2
    assert len(repr(person_0)) is 46
    assert repr(person_0) == "Person(forename='alice', surname='smith')"



# Generated at 2022-06-26 10:39:34.488788
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    # error = None
    # try:
    #     class Schema_0(Schema):
    #         pass
    # except Exception as e:
    #     error = e
    # assert error is not None, "type mismatch"

    # error = None
    # try:
    #     class Schema_0(Schema):
    #         pass
    #     class Schema_1(Schema):
    #         pass
    #     schema_0 = Schema_0(value={})
    #     schema_1 = Schema_1(value={})
    #     obj_0 = schema_0 == schema_1
    # except Exception as e:
    #     error = e
    # assert error is None, "unexpected error"
    # assert obj_0

# Generated at 2022-06-26 10:39:45.350073
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # No arguments -> raises TypeError
    with pytest.raises(TypeError):
        SchemaMetaclass.__new__(SchemaMetaclass)

    # Too many arguments -> raises TypeError
    with pytest.raises(TypeError):
        SchemaMetaclass.__new__(SchemaMetaclass, 0, 1, 2, 3)

    # 1 positional argument -> raises TypeError
    with pytest.raises(TypeError):
        SchemaMetaclass.__new__(SchemaMetaclass, 0)

    # 2 positional arguments -> returns value
    assert SchemaMetaclass.__new__(SchemaMetaclass, 0, 1) == 0

    # 1 positional argument and type keyword arguments -> raises TypeError
    with pytest.raises(TypeError):
        SchemaMetaclass.__new__

# Generated at 2022-06-26 10:39:47.827754
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:39:55.481684
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        name = String(required=True)
        age = Integer()

    user_schema = User.make_validator()

    user_data = {"name": "foo", "age": 20}
    user = User.validate(user_data)
    assert user.name == "foo"
    assert user.age == 20

    user_data = {"name": "foo"}
    user = User.validate(user_data)
    assert user.name == "foo"
    assert user.age is None


    class MyObject(Schema):
        user = Reference(User)

    obj = MyObject.validate({"user": user_data})
    assert obj.user.name == "foo"
    assert obj.user.age == 20


# Generated at 2022-06-26 10:39:58.333464
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert schema_0.__repr__() == "Schema() [sparse]"



# Generated at 2022-06-26 10:40:00.835708
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()



# Generated at 2022-06-26 10:40:06.204825
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Validate with a string ref.
    ref_0 = Reference(to="Test")
    assert True  # TBD: something that mimics the interface and is iterable.

    # Validate with a schema class ref.
    class Test0(Schema):
        a = "abc"
    ref_1 = Reference(to=Test0)
    assert True  # TBD: something that mimics the interface and is iterable.

    # Validate with no ref, which should fail.
    ref_2 = Reference()
    try:
        assert ref_2.validate()
        assert False  # Exception should be raised instead of reaching this line.
    except NotImplementedError:
        pass


# Generated at 2022-06-26 10:40:33.263110
# Unit test for constructor of class Schema
def test_Schema():

    from typesystem.base import Field as test_Field
    from typesystem.fields import String as test_String

    class test_C1(Schema):
        field_0 = test_String

    instance_of_test_C1 = test_C1()



# Generated at 2022-06-26 10:40:38.744278
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    person = Person(name="John Smith", age=42)
    person2 = Person(name="John Smith", age=42)
    person3 = Person(name="Jane Smith", age=43)

    assert person == person2
    assert person != person3


# Generated at 2022-06-26 10:40:45.152485
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    class Entity(Schema):
        id = Integer(required=True)
        name = String(required=True)
        foo = Integer()
        bar = Reference("Entity", definitions=schema_definitions_0)
    entity_0 = Entity(id=0, name="foo", foo=None, bar=None)


# Generated at 2022-06-26 10:40:46.902069
# Unit test for constructor of class Reference
def test_Reference():
    schema_definitions_0 = SchemaDefinitions()
    to = "Address"
    definitions = schema_definitions_0
    ref = Reference(to=to, definitions=definitions)



# Generated at 2022-06-26 10:40:53.988067
# Unit test for method validate of class Reference
def test_Reference_validate():
    type_0 = Reference(None)
    type_0.validate(None, strict=True)
    # Make sure we include a test for each error code.
    type_0.validate(None, strict=False)
    type_0.validate(None, strict=False)
