

# Generated at 2022-06-26 10:31:27.048587
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    mapping_0 = Schema(dict_0)
    int_0 = mapping_0.__getitem__('field_0')



# Generated at 2022-06-26 10:31:39.624290
# Unit test for constructor of class Reference
def test_Reference():
    to = typing.Union[str, typing.Type[Schema]]  # Type of parameter 'to'
    to = str()
    to = typing.Type[Schema]()
    definitions = typing.Mapping()  # Type of parameter 'definitions'
    definitions = dict()
    definitions = SchemaDefinitions()
    strict = False  # Type of parameter 'strict'
    strict = True
    # No exception should be raised
    ref_0 = Reference(to,definitions,allow_null=strict,description='',format='',title='')
    # No exception should be raised
    ref_0 = Reference(to,definitions,allow_null=strict,description='',format='',title='',default=schema_definitions_0,)
    # No exception should be raised

# Generated at 2022-06-26 10:31:43.010755
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Arrange
    schema_definitions_0 = SchemaDefinitions()
    dict_0 = {}

    # Act
    schema_0 = Schema(dict_0, schema_definitions_0)
    result = iter(schema_0)

    # Assert
    assert result is not None


# Generated at 2022-06-26 10:31:51.184914
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    dict_0 = {}
    test_0 = schema_definitions_0 == dict_0
    assert test_0 == False
    test_1 = dict_0 == schema_definitions_0
    assert test_1 == False
    dict_1 = {}
    test_2 = dict_0 == dict_1
    assert test_2 == True
    test_3 = dict_1 == dict_0
    assert test_3 == True
    test_4 = schema_definitions_0 == dict_1
    assert test_4 == False
    test_5 = dict_1 == schema_definitions_0
    assert test_5 == False


# Generated at 2022-06-26 10:31:52.077477
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    test_case_0()



# Generated at 2022-06-26 10:31:59.898105
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import String, Integer

    class User(Schema):
        name = String()
        age = Integer()

    user = User(name="Foo", age=42)
    assert user["name"] == "Foo"
    assert user["age"] == 42
    with pytest.raises(KeyError):
        user["email"]


# Generated at 2022-06-26 10:32:02.223428
# Unit test for constructor of class Reference
def test_Reference():
    schema_definitions_0 = SchemaDefinitions()
    dict_0 = {}
    assert isinstance(Reference("", definitions=schema_definitions_0), Reference)


# Generated at 2022-06-26 10:32:08.270165
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Arrange
    schema_definitions_0 = SchemaDefinitions()
    dict_0 = {}
    # Act
    actual_result_0 = schema_definitions_0.__iter__()
    expected_result_0 = iter(dict_0)
    # Assert
    assert actual_result_0 == expected_result_0



# Generated at 2022-06-26 10:32:10.281859
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    test_it = Schema
    # __eq__ called by:
    # - equals
    # - test_it.__eq__


# Generated at 2022-06-26 10:32:17.038342
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    def test_repr_concordance(arg_0 = test_case_0(), arg_1 = test_case_0(), arg_2 = test_case_0()):
        try:
            assert eval(repr(arg_0)) == arg_1
        except Exception:
            return False
        else:
            return True
    assert test_repr_concordance()



# Generated at 2022-06-26 10:32:27.939253
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Arrange
    to = str_0

    # Assert
    assert isinstance(Reference(to).target, Field)


# Generated at 2022-06-26 10:32:38.640668
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    str_0 = 'string_0'
    str_1 = 'string_1'
    str_2 = 'string_2'
    schema_0 = Schema(str_0)
    schema_1 = Schema(str_1)
    schema_2 = Schema(str_2)
    assert (schema_0 != schema_1) == True
    assert (schema_0 == schema_2) == True


# Generated at 2022-06-26 10:32:48.115399
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        def test_fields(self):
            return{}
    obj = TestSchema()
    ret_obj = obj.__iter__()
    assert ret_obj is not None  # __iter__ returns NoneType
    assert isinstance(ret_obj, str)  # __iter__ returns generator object
    # __iter__ returns a generator object with length = 0
    assert next(ret_obj) == str_0
    return True # no error case


# Generated at 2022-06-26 10:32:53.402693
# Unit test for method validate of class Reference
def test_Reference_validate():

    print("Testing validate()...")

    # Arrange

    # Act
    try:
        str_1 = Reference(str_0)
        str_2 = str_1.validate()
    except:
        pass

    # Assert


if __name__ == '__main__':

    print(test_case_0())
    print(test_Reference_validate())

# Generated at 2022-06-26 10:32:59.786748
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import String

    class Person(Schema):
        first_name = String()
        last_name = String()

    person = Person(first_name="Joe", last_name="Montana")
    result = repr(person)
    assert result == "Person(first_name='Joe', last_name='Montana')"



# Generated at 2022-06-26 10:33:03.066823
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class_0 = Schema({'field_0': 12})
    result = class_0.__iter__()
    assert result is None


# Generated at 2022-06-26 10:33:06.063024
# Unit test for function set_definitions
def test_set_definitions():
    str_0 = set_definitions(str_0, str_0)
    ret_0 = {'fields': {}}
    assert (str_0 == ret_0), "Failed"


# Generated at 2022-06-26 10:33:13.532827
# Unit test for function set_definitions
def test_set_definitions():
    # Test cases
    str_0 = 'field_0'
    str_1 = 'field_1'
    str_2 = 'field_2'
    str_3 = 'field_3'
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    # All literal values are referenced as an int value
    # This is to ensure that mutable default values are allocated in the heap
    # so their addresses change at every instantiation
    # The defintions set below can be thought of as a dictionary in the form of
    # {key:value}. The keys are instances of the Schema class with their values
    # as field_type
    # The values are instances of Field with their values as fields

# Generated at 2022-06-26 10:33:17.514860
# Unit test for function set_definitions
def test_set_definitions():
    field_0 = None
    print(field_0)
    definitions_0 = SchemaDefinitions
    print(definitions_0)
    set_definitions(field_0, definitions_0)
    print(field_0)


# Generated at 2022-06-26 10:33:19.480322
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass # TODO: This test needs an implementation.


# Generated at 2022-06-26 10:33:31.439773
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema(**{'test_0': 0})
    for element_0 in schema_0:
        print(element_0)
    print(len(schema_0))


# Generated at 2022-06-26 10:33:43.717659
# Unit test for function set_definitions
def test_set_definitions():
    # Initialize test variables
    to = "test_case"
    test_definitions = SchemaDefinitions()
    ref_field = Reference(to, definitions=test_definitions)
    test_array = Array(items=ref_field)
    test_obj = Object(properties={"test_key": test_array})
    test_dict = {"test_key": test_obj}

    # Test if set_definitions can be called without any errors
    set_definitions(ref_field, test_definitions)
    set_definitions(test_obj, test_definitions)
    set_definitions(test_array, test_definitions)
    set_definitions(test_array, test_definitions)

    # Test and check if set_definitions correctly sets the definitions of Reference objects

# Generated at 2022-06-26 10:33:45.734176
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    assert schema_0 == schema_0



# Generated at 2022-06-26 10:33:49.206725
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema()) == 'Schema()'
    assert repr(Schema(a=1)) == 'Schema(a=1)'




# Generated at 2022-06-26 10:33:50.761075
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert list(sorted(schema_0)) == []


# Generated at 2022-06-26 10:33:57.409030
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_1 = Schema()
    schema_2 = Schema(
        arg_1 = "hello",
        arg_2 = "hello",
        arg_3 = "hello",
    )
    schema_3 = Schema(
        arg_1 = "hello",
        arg_2 = "hello",
        arg_3 = "hello",
    )
    assert len(tuple(schema_1)) == 0
    assert len(tuple(schema_2)) == 3
    assert len(tuple(schema_3)) == 3


# Generated at 2022-06-26 10:34:01.059242
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_0 = Schema()
    result_0: Schema = schema_0
    try:
        result_0.__getitem__({'key': 'key'})
    except KeyError:
        pass


# Generated at 2022-06-26 10:34:10.355693
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schemas = []
    def add_schema(schema: Schema):
        schemas.append(schema)
    
    schema_0 = Schema()
    add_schema(schema_0)
    schema_1 = Schema(name='schema_1')
    add_schema(schema_1)
    schema_2 = Schema(name='schema_2', age=10)
    add_schema(schema_2)
    
    for i, schema in enumerate(schemas):
        for index, key in enumerate(schema):
            assert index == 0
            assert key == "name"
        assert i == 2


# Generated at 2022-06-26 10:34:20.709387
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_1 = Schema()
    assert len(schema_1) == 0
    schema_2 = Schema(a=1, b=2)
    assert len(schema_2) == 2
    schema_3 = Schema(a=1, b=2, c=None)
    assert len(schema_3) == 2


# Generated at 2022-06-26 10:34:30.686168
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert schema_0.__repr__() == "Schema()"

    schema_1 = Schema({})
    assert schema_1.__repr__() == "Schema()"

    schema_2 = Schema(sparse=True)
    assert schema_2.__repr__() == "Schema(sparse=True) [sparse]"

    schema_3 = Schema(sparse=True, extra=True)
    assert schema_3.__repr__() == "Schema(extra=True, sparse=True) [sparse]"



# Generated at 2022-06-26 10:34:40.864527
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    for v_key in schema_0:
        pass
    test_case_0()


# Generated at 2022-06-26 10:34:47.564402
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    def test_case_0():
        schema_0 = Schema()
        assert schema_0.fields == {}
        assert schema_0 == {}
        assert schema_0.is_sparse == False
        assert schema_0.__repr__() == "Schema()"
        assert schema_0.__len__() == 0
        assert schema_0.__getitem__("") == KeyError

    def test_case_1():
        class Person(Schema):
            name = Field(String())
            age = Field(Integer(), default=0)
        person_0 = Person({"name": "Ivan"})
        assert person_0.fields == {"name": Field(String()), "age": Field(Integer(), default=0)}
        assert person_0 == {"name": "Ivan", "age": 0}
        assert person

# Generated at 2022-06-26 10:34:50.205692
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_0 = Schema()
    with pytest.raises(KeyError):
        schema_0.__getitem__(None)


# Generated at 2022-06-26 10:34:52.657425
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    assert len(schema) == 0


# Generated at 2022-06-26 10:34:54.833559
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_1 = Schema()
    schema_2 = Schema()
    assert schema_1 == schema_2


# Generated at 2022-06-26 10:34:56.548528
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema = Schema()
    assert repr(schema) == 'Schema()'


# Generated at 2022-06-26 10:34:58.007165
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert repr(schema_0) == 'Schema()'


# Generated at 2022-06-26 10:34:59.383663
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    schema_0.__len__()
   

# Generated at 2022-06-26 10:35:08.150622
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema()
    assert schema.fields == {}
    schema = Schema(name='Leo')
    assert schema.fields == {}
    schema = Schema(name='Leo', number=32)
    assert schema.fields == {}
    schema = Schema(number='32')
    assert schema.fields == {}
    schema = Schema(name='Leo', unknown_keyword_argument=32)
    assert schema.fields == {}
    schema = Schema(name='Leo', **{'name': 3})
    assert schema.fields == {}
    schema = Schema(name='Leo', **{'name': 'Leo'})
    assert schema.fields == {}
    schema = Schema(**{'name': 'Leo'})
    assert schema.fields == {}

# Generated at 2022-06-26 10:35:10.634675
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_1 = Schema()
    assert len(schema_1) == 0


# Generated at 2022-06-26 10:35:26.278573
# Unit test for function set_definitions
def test_set_definitions():
    schema_0 = Schema()
    schema_1 = Schema()

    set_definitions(schema_0, schema_1)
    assert schema_0 == schema_1, 'The data must be equal'


# Generated at 2022-06-26 10:35:27.710150
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert list(schema_0.__iter__()) == []


# Generated at 2022-06-26 10:35:29.369414
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    var_0 = schema_0.__iter__()
    assert var_0 == []



# Generated at 2022-06-26 10:35:30.556857
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    assert isinstance(schema_0, Schema)



# Generated at 2022-06-26 10:35:33.552246
# Unit test for constructor of class Schema
def test_Schema():
    test_case_0()


# Unit test main
if __name__ == "__main__":
    args = list(sys.argv)
    sys.exit(pytest.main(args))

# Generated at 2022-06-26 10:35:46.061751
# Unit test for method validate of class Reference
def test_Reference_validate():
    definitions = SchemaDefinitions()
    class Person(Schema, metaclass=SchemaMetaclass):
        name = Field()

    class Comment(Schema, metaclass=SchemaMetaclass):
        message = Field()
        author = Reference(Person, definitions=definitions)

    author = Person(name="Fred")
    comment = Comment(message="I am Groot.", author=author)
    print(comment.author.name)
    assert comment.author.name == "Fred"
    comment = Comment(message="I am Groot.", author={"name": "Fred"})
    print(comment.author.name)
    assert comment.author.name == "Fred"
    def test_case_1():
        comment = Comment(message="I am Groot.", author=None)


# Generated at 2022-06-26 10:35:49.761636
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    schema_1 = Schema()

    assert not isinstance(schema_1, SchemaMetaclass)
    assert isinstance(schema_1, Schema)
    assert isinstance(schema_0, Schema)
    assert schema_1 == schema_0

# Generated at 2022-06-26 10:35:51.862569
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    schema_0.__iter__()


# Generated at 2022-06-26 10:35:54.294119
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert __new__(test_case_0) == None



# Generated at 2022-06-26 10:35:58.678667
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    actual_0 = repr(schema_0)
    expected_0 = "Schema()"
    assert actual_0 == expected_0, f"\nexpected: {expected_0}\nactual:   {actual_0}"


# Generated at 2022-06-26 10:36:09.675701
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    """Test if __iter__ of Schema can work normally."""
    schema_1 = Schema()
    assert tuple(schema_1.__iter__()) == ()



# Generated at 2022-06-26 10:36:13.930210
# Unit test for constructor of class Schema
def test_Schema():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-26 10:36:17.779081
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    schema_1 = Schema()
    result = schema_0 == schema_1
    assert result
    assert isinstance(result, bool)


# Generated at 2022-06-26 10:36:23.846912
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # No error should be raised.
    class Person(Schema):
        pass

    # No error should be raised.
    class Person(Schema):
        name = Field(max_length=255)
        age = Field(minimum=0, maximum=150)

    # These two tests should fail, since they are trying to define the same
    # `Field` twice.
    try:
        class Person(Schema):
            name = Field(max_length=255)
            name = Field(max_length=255)
    except NameError:
        pass
    else:
        raise AssertionError("Did not detect duplicate field.")



# Generated at 2022-06-26 10:36:33.088829
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    print('Test Case #0')
    schema_0 = Schema()
    try:
        for key in schema_0:
            pass
    except Exception as e:
        print(e)

    schema_1 = Schema()
    try:
        for key in schema_1:
            pass
    except Exception as e:
        print(e)

    print('\n')


# Generated at 2022-06-26 10:36:46.367995
# Unit test for constructor of class Schema
def test_Schema():
    assert not hasattr(Schema, "speed")
    assert not hasattr(Schema, "distance")
    assert not hasattr(Schema, "time")

    Schema.speed = schema_0 = Field(name="speed")
    Schema.distance = schema_1 = Field(name="distance")
    Schema.time = schema_2 = Field(name="time")
    assert hasattr(Schema, "speed")
    assert hasattr(Schema, "distance")
    assert hasattr(Schema, "time")
    assert hasattr(Schema, "fields")
    assert hasattr(Schema, "validate")
    assert hasattr(Schema, "validate_or_error")



# Generated at 2022-06-26 10:37:01.065606
# Unit test for constructor of class Schema
def test_Schema():
    schema_1 = Schema()
    if(schema_1.fields != {}):
        raise Exception("test_Schema 1 failed.\n Schema.fields != {}")
    schema_2 = Schema(1, 2, 3, 4)
    if(schema_2.fields != {}):
        raise Exception("test_Schema 2 failed.\n Schema(1,2,3,4).fields != {}")
    schema_3 = Schema(a=1, b=2)
    if(schema_3.fields != {}):
        raise Exception("test_Schema 3 failed.\n Schema(a=1, b=2).fields != {}")
    schema_4 = Schema({'a': 1, 'b': 2})

# Generated at 2022-06-26 10:37:09.471303
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    try:
        schema_0 = Schema()
        result = schema_0.__repr__()
        assert result is not None
        schema_1 = Schema()
        result = schema_1.__repr__()
        assert result is not None
        schema_2 = Schema()
        result = schema_2.__repr__()
        assert result is not None
        schema_3 = Schema()
        result = schema_3.__repr__()
        assert result is not None
        schema_4 = Schema()
        result = schema_4.__repr__()
        assert result is not None
    except Exception as e:
        print(e)


# Generated at 2022-06-26 10:37:14.913615
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test Case "0"
    schema_0 = Schema()
    # Test Case "1"
    schema_1 = Schema({"a": 0})
    # Test Case "2"
    schema_2 = Schema(a=0)
    assert len(list(schema_0)) == 0
    assert len(list(schema_1)) == 1
    assert len(list(schema_2)) == 1


# Generated at 2022-06-26 10:37:21.515165
# Unit test for constructor of class Schema
def test_Schema():
    schema_def = {
        'root': Schema(name=1, age=2, height=3, weight=4)
    }
    assert('root' in schema_def)
    assert(schema_def['root'].name == 1)
    assert(schema_def['root'].age == 2)
    assert(schema_def['root'].height == 3)
    assert(schema_def['root'].weight == 4)


# Generated at 2022-06-26 10:37:44.592455
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    schema_1 = Schema(key_0=Field())
    schema_2 = Schema(key_0=Field(), key_1=Field())

    result_0 = list(schema_0)
    result_1 = list(schema_1)
    result_2 = list(schema_2)
    # Check that the properties of the "sparse" schema are not included.
    assert result_0 == []
    # Check that the properties of the "sparse" schema are not included.
    assert result_1 == ["key_0"]
    # Check that the properties of the "sparse" schema are not included.
    assert result_2 == ["key_0", "key_1"]


# Generated at 2022-06-26 10:37:45.535254
# Unit test for method validate of class Reference
def test_Reference_validate():
    reference = Reference(to = "int")
    assert reference.validate(5) == 5


# Generated at 2022-06-26 10:37:48.144241
# Unit test for constructor of class Reference
def test_Reference():
    x = Schema()
    y = Reference(to=x)
    assert y.to == x
    assert y.definitions == None


# Generated at 2022-06-26 10:37:51.800543
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert isinstance(schema_0.__iter__(), type(iter({})))
    assert isinstance(schema_0.__iter__(), typing.Iterator)


# Generated at 2022-06-26 10:37:53.218572
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    Schema.getitem()


# Generated at 2022-06-26 10:38:03.380183
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()
    assert len(schema) == 0
    schema = Schema()

# Generated at 2022-06-26 10:38:09.673269
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Initialize class
    reference = Reference(to="Test")
    # Validate None
    result = reference.validate(None)
    assert result is None

    # Initialize schema
    schema = Schema(foo="bar")
    # Validate schema
    result = reference.validate(schema, strict=True)
    assert isinstance(result, Schema)
    assert result.foo == "bar"

    # Initialize schema with wrong type
    schema = {
        "foo": 1
    }
    # Validate schema
    try:
        result = reference.validate(schema)
    except ValidationError as error:
        pass



# Generated at 2022-06-26 10:38:14.926684
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    schema_1 = Schema(schema_0)
    assert type(schema_0) is Schema
    assert type(schema_1) is Schema
    assert schema_0 == schema_1


# Generated at 2022-06-26 10:38:18.886536
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        pass
    
    schema_0 = TestSchema()
    schema_1 = TestSchema()
    result = schema_0.__eq__(schema_1)
    assert result == True, "'result' should be equal to True"



# Generated at 2022-06-26 10:38:26.363252
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()

    set_definitions(Foo, definitions)
    set_definitions(Bar, definitions)
    set_definitions(Baz, definitions)

    for schema in [Foo, Bar, Baz]:
        for name, field in schema.fields.items():
            assert field.definitions is not None

    assert Foo.fields["bar"].target is Bar
    assert Bar.fields["baz"].target is Baz



# Generated at 2022-06-26 10:38:49.347564
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    # "Schema()"
    assert str(schema_0) == 'Schema()'



# Generated at 2022-06-26 10:38:52.234680
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_definitions_0 = SchemaDefinitions()
    schema_1 = Schema(
        definitions=schema_definitions_0,
    )
    assert not hasattr(schema_1, "fields")


# Generated at 2022-06-26 10:38:56.385564
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema()) == 0
    assert len(Schema({"a": 1, "b": 2, "c": 3, "d": 4})) == 4



# Generated at 2022-06-26 10:38:57.903209
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema()


# Generated at 2022-06-26 10:39:00.588197
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
  it = SchemaMetaclass("child", (object, ), {}, False)
  return it


# Generated at 2022-06-26 10:39:03.425651
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert schema_0.__len__() == 0


# Generated at 2022-06-26 10:39:13.850387
# Unit test for constructor of class Schema
def test_Schema():
    # Test case: invoking constructor with no argument
    schema_0 = Schema()

    assert(schema_0.__class__.__name__ == "Schema")

    # Test case: invoking constructor with one argument
    schema_1 = Schema({"a":0})
    assert(schema_1.a == 0)

    # Test case: invoking constructor with a non-dict arg, but attribute 'a'
    # is not defined in the Schema class.
    schema_2 = Schema(schema_1)
    assert(schema_2.a == 0)

    # Test case: invoking constructor with a non-dict arg, but attribute 'a'
    # is not defined in class schema_3
    class schema_3(Schema):
        def __init__(self, d: typing.Dict):
            super().__

# Generated at 2022-06-26 10:39:24.675061
# Unit test for constructor of class Schema
def test_Schema():
    user = {
        "name": "Dmitri",
        "age": 35,
        "email": "dmitri@example.com",
        "homepage": "https://example.com/",
        "interests": ["Python", "music", "toys"],
    }
    user_schema = Schema(
        name=String(max_length=30),
        age=Integer(minimum=0),
        email=String(format="email"),
        homepage=String(format="url"),
        interests=Array(items=String(max_length=50)),
        created_at=DateTime(),
        last_seen=DateTime(),
    )
    user = user_schema(**user)
    assert user.name == "Dmitri"
    assert user.age == 35

# Generated at 2022-06-26 10:39:34.641490
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    repeated_0_0 = False
    repeated_0_1 = False
    repeated_0_2 = False
    repeated_0_3 = False
    repeated_0_4 = False
    repeated_0_5 = False
    repeated_0_6 = False
    for i in schema_0:
        if i == 'fields':
            repeated_0_0 = True
        elif i == 'allow_null':
            repeated_0_1 = True
        elif i == 'default':
            repeated_0_2 = True
        elif i == 'description':
            repeated_0_3 = True
        elif i == 'title':
            repeated_0_4 = True
        elif i == '_creation_counter':
            repeated_0_5 = True

# Generated at 2022-06-26 10:39:42.830695
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    #  See https://github.com/samuelcolvin/typesystem/issues/216
    class Schema0(Schema):
        field: int

    assert Schema0.fields == {"field": Field(int)}
    definitions = SchemaDefinitions()
    assert Schema0("test_case_0", (Schema,), {"field": int}, definitions) is Schema0
    assert definitions == {"test_case_0": Schema0}


# Generated at 2022-06-26 10:40:35.977118
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert schema_0.__repr__() == "Schema()"



# Generated at 2022-06-26 10:40:38.692946
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema()
    assert iter(schema) is not None


# Generated at 2022-06-26 10:40:45.613122
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class S(Schema):
        pass

    s = S()
    assert repr(s) == "S()"

    s = S(wibble="wobble")
    assert repr(s) == 'S(wibble="wobble")'

    s = S(wibble=1)
    assert repr(s) == "S(wibble=1)"



# Generated at 2022-06-26 10:40:55.054290
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_1 = Schema()
    assert len(schema_1) == 0

    class Person(Schema):
        pass

    person_1 = Person()
    assert len(person_1) == 0

    class Person(Schema):
        name = Field(type="string", max_length=100)

    person_1 = Person(name="Jane Doe")
    assert len(person_1) == 1

