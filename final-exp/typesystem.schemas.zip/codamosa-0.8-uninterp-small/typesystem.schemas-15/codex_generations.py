

# Generated at 2022-06-26 10:31:24.438768
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema(**kwargs)
    schema_1 = Schema(**kwargs)
    exception_expected = False
    try:
        if schema_0 == schema_1:
            return True
        else:
            return False
    except:
        exception_expected = True
    if (not exception_expected):
        raise AssertionError()
    return True


# Generated at 2022-06-26 10:31:27.937777
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    dict_0 = {
        "field_0": 1,
    }
    schema_0 = Schema(**dict_0)
    assert len(schema_0) == 1

# Generated at 2022-06-26 10:31:28.913833
# Unit test for constructor of class Schema
def test_Schema():
    dict_0 = {}
    schema_0 = Schema(dict_0)
    assert schema_0.is_sparse == False

# Generated at 2022-06-26 10:31:31.375622
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    dict_0 = {}
    schema_0 = Schema(**dict_0)
    assert schema_0.__repr__() == "Schema()"

# Generated at 2022-06-26 10:31:42.550521
# Unit test for function set_definitions
def test_set_definitions():
    class dictionary_0(Schema):
        pass
    class dictionary_1(Schema):
        pass
    class dictionary_2(Schema):
        pass
    class dictionary_3(Schema):
        pass
    class dictionary_4(Schema):
        pass
    class dictionary_5(Schema):
        pass
    class dictionary_6(Schema):
        pass
    class dictionary_7(Schema):
        pass
    class dictionary_8(Schema):
        pass
    class dictionary_9(Schema):
        pass
    class dictionary_10(Schema):
        pass
    class dictionary_11(Schema):
        pass
    class dictionary_12(Schema):
        pass
    class dictionary_13(Schema):
        pass
    class dictionary_14(Schema):
        pass

# Generated at 2022-06-26 10:31:45.490348
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    dict_0 = {}
    schema_0 = Schema(**dict_0)

    assert type(schema_0.__len__()) is int
    assert schema_0.__len__() == 0


# Generated at 2022-06-26 10:31:49.148327
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test with the following requirements:
    # - Schema().fields = {}

    dict_0 = {}
    schema_0 = Schema(**dict_0)
    assert schema_0.__len__() == len(schema_0.fields)


# Generated at 2022-06-26 10:31:53.549089
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Creating a Schema
    SchemaObj = Schema()
    # Adding the attributes to the schema
    SchemaObj.color = "red"
    SchemaObj.value = "#f00"
    result = iter(SchemaObj)
    # Check the result
    assert list(result) == ["color", "value"]


# Generated at 2022-06-26 10:31:55.344661
# Unit test for method validate of class Reference
def test_Reference_validate():
    assert Reference(int).validate(1) == 1


# Generated at 2022-06-26 10:31:58.770381
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    dict_0 = {}
    schema_0 = Schema(**dict_0)


# Generated at 2022-06-26 10:32:17.157915
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.fields import String

    class MySchema(Schema):
        name = String()

    schema_definitions_0 = SchemaDefinitions()
    field_0 = MySchema(name="Joe")
    field_1 = MySchema(name="Joe")
    assert field_0 == field_1
    field_2 = MySchema(name="Joe", other=1)
    assert field_0 != field_2
    assert field_2.is_sparse
    field_3 = MySchema(schema_definitions_0, name="Joe")
    assert field_0 == field_3


# Generated at 2022-06-26 10:32:20.250245
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    dict_0 = {}
    schema_definitions_0 = SchemaDefinitions(**dict_0)
    try:
        test_Schema___iter__0 = Schema(**dict_0)
        for value_0 in test_Schema___iter__0:
            pass
    except:
        raise RuntimeError


# Generated at 2022-06-26 10:32:24.230743
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_definitions_0 = SchemaDefinitions()
    reference_0 = Reference(to="Person", definitions=schema_definitions_0)


# Generated at 2022-06-26 10:32:31.740796
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    dict_0 = {}
    schema_definitions_0 = SchemaDefinitions(**dict_0)
    @schema_definitions_0
    class ReferenceValidationSchema(Schema):
        a = Reference(to='C', definitions=schema_definitions_0)
    dict_1 = {}
    schema_definitions_1 = SchemaDefinitions(**dict_1)
    @schema_definitions_1
    class C(Schema):
        c = String()
    dict_2 = {}
    schema_definitions_2 = SchemaDefinitions(**dict_2)
    @schema_definitions_2
    class B(Schema):
        b = Reference(to=C, definitions=schema_definitions_2)

# Generated at 2022-06-26 10:32:45.097291
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    dict_0 = {}
    schema_definitions_0 = SchemaDefinitions(**dict_0)
    dict_1 = {}
    dict_2 = {}
    fields_0 = dict_2
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_5["Field"] = dict_6
    dict_4["fields"] = dict_5
    dict_3["Schema"] = dict_4
    dict_1["__class__"] = dict_3
    dict_1["fields"] = fields_0
    schema_0 = Schema(**dict_1)
    str_0 = "KeyError"
    str_1 = "key"
    str_2 = "'foo'"
    str_3 = " "
    str_4 = "is"


# Generated at 2022-06-26 10:32:54.824578
# Unit test for function set_definitions
def test_set_definitions():
    dict_0 = {}
    schema_definitions_0 = SchemaDefinitions(**dict_0)
    dict_1 = {}
    schema_0 = Schema(**dict_1)
    array_0 = Array()
    reference_0 = Reference(to=schema_0, definitions=schema_definitions_0)
    dict_2 = {}
    dict_3 = {}
    dict_3['definitions'] = schema_definitions_0
    dict_3['items'] = array_0
    array_1 = Array(**dict_3)
    dict_4 = {}
    dict_5 = {}
    dict_5['items'] = array_1
    schema_1 = Schema(**dict_5)
    array_2 = Array()

# Generated at 2022-06-26 10:33:04.363969
# Unit test for function set_definitions
def test_set_definitions():
    a = Array(items=Integer())
    b = Array(items=Integer)
    c = Array(items=Reference(to=Integer))
    d = Array(items=(Integer(), String()))
    e = Array(items=(Integer, String))
    f = Array(items=(Reference(to=Integer), Reference(to=String)))
    g = Object(properties={"hello": String(), "world": Integer()})
    h = Object(properties={"hello": String, "world": Integer})
    i = Object(properties={"hello": Reference(to=String), "world": Reference(to=Integer)})
    definitions = SchemaDefinitions()
    set_definitions(a, definitions)
    set_definitions(b, definitions)
    set_definitions(c, definitions)
    set_definitions(d, definitions)
    set_

# Generated at 2022-06-26 10:33:08.642182
# Unit test for function set_definitions
def test_set_definitions():
    import typesystem
    # Setup test case
    field_0 = typesystem.Integer()
    definitions_0 = SchemaDefinitions()
    # Test code
    set_definitions(field_0, definitions_0)


# Generated at 2022-06-26 10:33:10.524619
# Unit test for constructor of class Schema
def test_Schema():
    schema_0: Schema = Schema()



# Generated at 2022-06-26 10:33:22.146733
# Unit test for constructor of class Reference
def test_Reference():
    # (schema: typing.Union[str, typing.Type[Schema]], definitions: typing.Mapping = None, **kwargs: typing.Any) -> None
    from typing import Mapping, Any
    to_0: str = 'SomeClass'
    definitions_0: None = None
    kwargs_0: Dict[str, Any] = {}
    instance_0 = Reference(to_0, definitions_0, **kwargs_0)
    assert isinstance(instance_0.to, str)
    assert instance_0.to == 'SomeClass'
    assert not hasattr(instance_0, 'definitions')
    assert instance_0.kwargs == {}
    assert instance_0.metadata == {}
    assert instance_0.errors == {"null": "May not be null."}
    #test_to_error(

# Generated at 2022-06-26 10:33:39.030943
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        bar = Field(type=str)
        baz = Field(type=int)
        qux = Field(type=bool)

    foo = Foo(bar="hello", baz=123, qux=True)
    assert foo["bar"] == "hello"
    assert foo["baz"] == 123
    assert foo["qux"] == True
    assert sorted(foo) == ["bar", "baz", "qux"]



# Generated at 2022-06-26 10:33:44.488439
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert hasattr(SchemaMetaclass, "__new__"), "class SchemaMetaclass has no attribute '__new__'"


# Generated at 2022-06-26 10:33:55.812448
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import Object, String
    from typesystem.exceptions import TypeSystemError

    class Book(Schema):
        title = String(max_length=128)

    # Test empty Schema
    book: Book = Book({})
    assert (
        book.title is None
    ), "It should return title as None, but returns {book.title}"

    book = Book({"title": "example"})
    assert book.title == "example", "It should return title as example, but returns {book.title}"

    book = Book({"title": "a" * 129})
    assert book.title is None, "It should return title as None, but returns {book.title}"

    book = Book(title="example")
    assert book.title == "example", "It should return title as example, but returns {book.title}"

   

# Generated at 2022-06-26 10:33:57.992424
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(schema_0) == 0


# Generated at 2022-06-26 10:34:01.772571
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    try:
        assert repr(schema_0) == 'Schema()'
        assert True
    except AssertionError:
        print(repr(schema_0))
        print('AssertionError')


# Generated at 2022-06-26 10:34:03.652554
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert schema_0.__len__() == 0
 

# Generated at 2022-06-26 10:34:13.637081
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    schema_0 = Schema()
    assert issubclass(
        type(schema_0),
        SchemaMetaclass,
    ), "schema_0 has wrong type."
    assert isinstance(
        schema_0,
        Mapping,
    ), "schema_0 is not an instance of Mapping."
    assert isinstance(
        schema_0,
        Schema,
    ), "schema_0 is not an instance of Schema."
    assert isinstance(
        schema_0,
        typing.Mapping,
    ), "schema_0 is not an instance of typing.Mapping."



# Generated at 2022-06-26 10:34:24.139680
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert Schema().__repr__() == 'Schema() [sparse]'
    assert (Schema(field_0=0, field_1=1).__repr__() == 'Schema(field_0=0, field_1=1) [sparse]')
    assert (schema_1.__repr__() == 'Schema(field_0=0, field_1=1, field_2=2)')

# Generated at 2022-06-26 10:34:26.845962
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    schema_1 = Schema()
    assert schema_0 == schema_1

# Unit tests for class SchemaMetaclass

# Generated at 2022-06-26 10:34:33.875925
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_1 = Schema()
    i=0
    j=0
    while True:
        try:
            i=i+1
            next(schema_1.__iter__())
        except:
            j=j+1
            break
    print(j)
    if j==1:
        print("Schema class: test case __iter__ passed")
    else:
        print("Schema class: test case __iter__ failed")


# Generated at 2022-06-26 10:34:48.805920
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class_name = "schema_0"
    arguments = {}
    argument_str = ", ".join([f"{key}={value!r}" for key, value in arguments.items()])
    sparse_indicator = " [sparse]"
    assert repr(Schema()) == f"{class_name}({argument_str}){sparse_indicator}"


# Generated at 2022-06-26 10:34:57.248752
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    __iterator_0 = schema_0.__iter__()
    actual_0 = list(__iterator_0)
    expected_0 = []
    assert actual_0 == expected_0, f"Expected: {expected_0}, but got: {actual_0}"
    __iterator_1 = schema_0.__iter__()
    actual_1 = list(__iterator_1)
    expected_1 = []
    assert actual_1 == expected_1, f"Expected: {expected_1}, but got: {actual_1}"



# Generated at 2022-06-26 10:34:59.017870
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema()
    assert "fields" in Schema.__dict__
    assert Schema.__dict__["fields"] == {}


# Generated at 2022-06-26 10:35:00.959327
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    assert isinstance(schema_0, Schema)


# Generated at 2022-06-26 10:35:04.209575
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    try:
        assert len(schema_0) == 0
        assert True
    except AssertionError as e:
        print("len(schema_0) failed")
        print(e)
        assert False


# Generated at 2022-06-26 10:35:10.408777
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test 0
    schema_0 = Schema()
    expected_result_0 = [
    ]
    result_0 = [
        key
        for key in schema_0
    ]
    assert result_0 == expected_result_0

    # Test 1
    schema_1 = Schema(
        first_name="Joe",
        last_name="Bloggs",
    )
    expected_result_1 = [
        'first_name',
        'last_name',
    ]
    result_1 = [
        key
        for key in schema_1
    ]
    assert result_1 == expected_result_1

    # Test 2
    schema_2 = Schema(
        first_name="Joe",
        last_name="Bloggs",
    )

# Generated at 2022-06-26 10:35:22.909239
# Unit test for method __eq__ of class Schema

# Generated at 2022-06-26 10:35:24.498695
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference("string").to == "string"
    assert Reference(string).to == string



# Generated at 2022-06-26 10:35:31.819481
# Unit test for function set_definitions
def test_set_definitions():
    class MyField(Field):
        def validate(self, value, strict=False):
            if value is None:
                return None
            return value

    field_0 = MyField()
    field_1 = MyField()
    field_2 = MyField()

    # Create some commonly nested find of Fields.
    array_0 = Array(items=field_0)
    object_0 = Object(properties={"a": field_1, "b": array_0})
    array_1 = Array(items=object_0)
    object_1 = Object(properties={"a": array_1, "b": field_2})

    # Create a SchemaDefinitions reference and add a new schema to it.
    class Object0(Schema):
        a = Array(items=Reference("Object1"))
        b = field_0

    definitions

# Generated at 2022-06-26 10:35:39.551528
# Unit test for function set_definitions
def test_set_definitions():

    class Child(Schema):
        name = Field(type=str)

    class Parent(Schema):
        child: typing.Type[Child] = Reference(to=Child)

    class_definitions = SchemaDefinitions()
    set_definitions(schema=Parent.child, definitions=class_definitions)
    assert isinstance(schema=Parent.child, cls=Reference)

    Child(name="Prateek")



# Generated at 2022-06-26 10:35:57.444348
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_0 = Schema()
    assert schema_0['a'] == None


# Generated at 2022-06-26 10:36:01.729111
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    a = Schema()
    assert a.__repr__() == "Schema()"
    b = Schema(first_name="Miley", last_name="Cyrus")
    assert b.__repr__() == "Schema(first_name='Miley', last_name='Cyrus')"

# Generated at 2022-06-26 10:36:13.349482
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    schema_0.__len__()
    schema_1 = Schema()
    schema_1.__len__()
    schema_2 = Schema()
    schema_2.__len__()
    schema_3 = Schema()
    schema_3.__len__()
    schema_4 = Schema()
    schema_4.__len__()
    schema_5 = Schema()
    schema_5.__len__()
    schema_6 = Schema()
    schema_6.__len__()
    schema_7 = Schema()
    schema_7.__len__()
    schema_8 = Schema()
    schema_8.__len__()
    schema_9 = Schema()
    schema_9.__len__()

# Generated at 2022-06-26 10:36:23.083530
# Unit test for constructor of class Schema
def test_Schema():
    # No arguments
    schema_0 = Schema()

    with pytest.raises(TypeError) as exc_info:
        Schema(False, False)
    assert "too many positional arguments" in str(exc_info.value)

    with pytest.raises(TypeError) as exc_info:
        Schema(False)
    assert "is not a valid Schema" in str(exc_info.value)

    # With keyword argument
    schema_kwargs = Schema(age=42)
    assert schema_kwargs.age == 42

    schema_kwargs_2 = Schema(age=43)
    assert schema_kwargs_2.age == 43

    # With an object
    class A:
        def __init__(self):
            self.value = 42

    schema_object = Schema(A())

# Generated at 2022-06-26 10:36:35.340118
# Unit test for constructor of class Schema
def test_Schema():
    def f_0(cls: typing.Type[Schema]) -> str:
        class_name = cls.__name__
        return f"{class_name}()"

    def f_1(cls: typing.Type[Schema]) -> str:
        class_name = cls.__name__
        return f"{class_name}()"

    v_1 = Schema.validate(1, strict=False)
    assert v_1 is None
    v_2 = Schema()
    assert v_2.fields == {}
    assert v_2.is_sparse
    assert str(v_2) == f_1(Schema)
    assert repr(v_2) == f_0(Schema)

# Generated at 2022-06-26 10:36:41.092859
# Unit test for function set_definitions
def test_set_definitions():
    def_0 = SchemaDefinitions()
    schema_0 = Schema()
    set_definitions(schema_0, def_0)
    assert not hasattr(schema_0, "definitions")

# Generated at 2022-06-26 10:36:46.699288
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Create a SchemaMetaclass
    schema_metaclass = SchemaMetaclass()
    # Create a Schema
    schema = schema_metaclass.__new__(SchemaMetaclass, 'schema_1', (Schema,), {'__module__': 'test'})
    assert schema.__module__ == 'test'


# Generated at 2022-06-26 10:36:52.461408
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    try:
        schema_0 = Schema()
    except Exception as e:
        print(e)
        return False
    assert type(schema_0.__repr__()) is str
    return True


# Generated at 2022-06-26 10:36:54.252072
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass


# Generated at 2022-06-26 10:36:58.176153
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema = Schema()

    assert(schema.__repr__() == "Schema() [sparse]")



# Generated at 2022-06-26 10:37:28.022334
# Unit test for method validate of class Reference
def test_Reference_validate():
    target = Object(properties={"first_name": String(), "last_name": String()})
    reference_0 = Reference(target)
    try:
        assert reference_0.validate(None) == None
    except TypeError as error:
        print(error)
        assert False
    except Exception as error:
        assert False

    try:
        assert reference_0.validate({}) == {}
    except TypeError as error:
        print(error)
        assert False
    except Exception as error:
        assert False


# Generated at 2022-06-26 10:37:39.961023
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():

    class foo(Schema):
        first: str
        second: str

    class bar(Schema):
        first: str
        second: str

    class baz(foo):
        third: str

    class qux(foo):
        third: str

    assert foo({"first": "a", "second": "b"}) == foo({"first": "a", "second": "b"})
    assert foo({"first": "a", "second": "b"}) == bar({"first": "a", "second": "b"})
    assert foo({"first": "a", "second": "b"}) != baz({"first": "a", "second": "b", "third": "c"})

# Generated at 2022-06-26 10:37:49.839259
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert (len(schema_0) == 0)
    schema_0 = Schema(attr_0=1, attr_1=2.5)
    assert (len(schema_0) == 2)
    schema_0 = Schema(attr_0=1, attr_1=2.5)
    assert (len(schema_0) == 2)
    schema_0 = Schema(attr_0=1.2, attr_1=2)
    assert (len(schema_0) == 2)


# Generated at 2022-06-26 10:38:00.949834
# Unit test for function set_definitions
def test_set_definitions():
    schema_0 = Schema()
    schema_1 = Schema()
    schema_2 = Schema()
    schema_3 = Schema()
    schema_4 = Schema()
    schema_5 = Schema()
    schema_6 = Schema()
    schema_7 = Schema()
    schema_8 = Schema()
    schema_9 = Schema()

    field_0 = Reference(to=schema_2, definitions=schema_0)
    set_definitions(field_0, schema_0)

    field_1 = Reference(to=schema_4, definitions=schema_1)
    set_definitions(field_1, schema_1)

    field_2 = Reference(to=schema_6, definitions=schema_3)

# Generated at 2022-06-26 10:38:07.785259
# Unit test for function set_definitions
def test_set_definitions():
    class SchemaA(Schema):
        foo = String()

    class SchemaB(Schema):
        string = String()
        schema = Reference("SchemaA")

    class SchemaC(Schema):
        array = Array(items=Reference("SchemaB"))
        object = Reference("SchemaB")

    definitions = SchemaDefinitions()
    set_definitions(SchemaC.array.items, definitions)
    set_definitions(SchemaC.object, definitions)
    for key, value in definitions.items():
        definitions[key] = value

# Generated at 2022-06-26 10:38:18.549912
# Unit test for function set_definitions
def test_set_definitions():
    def helper(
        field,
        definitions,
    ):
        field.definitions = None
        set_definitions(field, definitions)
        return field.definitions

    field_0 = Reference('definitions')
    definitions_0 = SchemaDefinitions()
    set_definitions(field_0, definitions_0)
    field_1 = Reference('definitions')
    definitions_1 = SchemaDefinitions()
    set_definitions(field_1, definitions_1)
    field_2 = Reference('definitions')
    definitions_2 = SchemaDefinitions()
    set_definitions(field_2, definitions_2)
    field_3 = Reference('definitions')
    definitions_3 = SchemaDefinitions()
    set_definitions(field_3, definitions_3)

# Generated at 2022-06-26 10:38:19.978784
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(test_case_0()) == 0



# Generated at 2022-06-26 10:38:28.635412
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    """
    Method __getitem__ of class Schema defined in module typesystem.schema
    tests:
    1. index of the Schema is not declared in schema
    2. index of the Schema is declared in schema
    3. Pass valid index to method __getitem__
    """
    schema_1 = Schema()
    # 1. test case: index of the Schema is not declared in schema
    try:
        schema_1["id"]
    except KeyError:
        assert True
    else:
        raise AssertionError("Error occured outside of exception")

    # 2. test case: index of the Schema is declared in schema
    try:
        schema_1["id"]
    except KeyError:
        assert False, "Error occured outside of exception"
    else:
        assert True



# Generated at 2022-06-26 10:38:30.734344
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(schema_0) == 0


# Generated at 2022-06-26 10:38:35.811192
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(min_value=0, max_value=150)
    
    try:
        assert set(Person()) == set()
    except:
        raise AssertionError('Failed test_Schema___iter__')


# Generated at 2022-06-26 10:39:20.606575
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    try:
        assert __schema_len(schema_0) == 0
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-26 10:39:21.266108
# Unit test for constructor of class Reference
def test_Reference():
    Reference("string")

# Generated at 2022-06-26 10:39:23.561258
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert len(schema_0) == 0

# Generated at 2022-06-26 10:39:30.907256
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import Integer

    definitions = SchemaDefinitions()

    class ExampleSchema(Schema):
        age = Integer(description="Age in years", minimum=0, maximum=150)
        parent = Reference("ExampleSchema", definitions=definitions, allow_null=True)

    definitions["ExampleSchema"] = ExampleSchema

    assert type(ExampleSchema.parent) == Reference


# Generated at 2022-06-26 10:39:35.808608
# Unit test for constructor of class Schema
def test_Schema():
    schema_1 = Schema()
    schema_2 = Schema({'a': 'b'})


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 10:39:41.275375
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    schema_1 = Schema()
    schema_1.__dict__['fields'] = {'fields': {}}
    assert not (schema_0 == schema_1)


# Generated at 2022-06-26 10:39:49.133489
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference("string_def")
    assert ref.to == "string_def" and ref.definitions is None and ref.errors == {'null': 'May not be null.'}
    ref = Reference(cls = str)
    assert str == ref.target
    ref = Reference(cls = str, definitions = {'string_def': str})
    assert str == ref.target

# Generated at 2022-06-26 10:39:52.801928
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema = schema_0
    key = "key"
    result = schema.__getitem__(key)
    print("Result:", result)
    result = schema.__getitem__("key")
    print("Result:", result)
    result = schema.__getitem__("key")
    print("Result:", result)


# Generated at 2022-06-26 10:40:04.650133
# Unit test for constructor of class Schema
def test_Schema():
    schema_1 = Schema()
    assert(schema_1.fields == {})
    schema_2 = Schema(a=1, b=2)
    assert(schema_2["a"] == 1 and schema_2["b"] == 2)
    schema_3 = Schema({"a": 1, "b": 2, "c": 3})
    assert(schema_3["a"] == 1 and schema_3["b"] == 2 and schema_3["c"] == 3)
    schema_4 = Schema({"a": 1, "b": 2, "c": 3}, a=4, b=5)
    assert(schema_4["a"] == 4 and schema_4["b"] == 5 and schema_4["c"] == 3)

# Generated at 2022-06-26 10:40:07.767730
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    expected_output = 0
    output = 0
    assert output == expected_output


# Generated at 2022-06-26 10:40:40.343618
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    """Test for method __len__ on class Schema."""
    schema_0 = Schema()
    assert schema_0.__len__() == 0
    schema_1 = Schema(definitions={})
    assert schema_1.__len__() == 0
    schema_2 = Schema(schema_1=schema_1, definitions=schema_1.fields)
    assert schema_2.__len__() == 0
    schema_3 = Schema(schema_2=schema_2, definitions=schema_2.fields)
    assert schema_3.__len__() == 0

# Generated at 2022-06-26 10:40:46.276215
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    test_0 = Schema()
    result_0 = test_0 == Schema()
    assert result_0
    class TestSchema0(Schema):
        method0 = Field(description="A method")
    test_1 = TestSchema0()
    result_1 = test_1 == TestSchema0()
    assert result_1



# Generated at 2022-06-26 10:40:58.679083
# Unit test for method __len__ of class Schema
def test_Schema___len__():
	schema_0 = Schema()
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__len__() == 0
	assert schema_0.__