

# Generated at 2022-06-26 10:31:30.081034
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    personschema_0 = PersonSchema()
    personschema_1 = PersonSchema()
    personschema_2 = PersonSchema()
    personschema_1.name = 'Cecilia'
    personschema_2.name = 'Cecilia'



# Generated at 2022-06-26 10:31:41.721675
# Unit test for function set_definitions
def test_set_definitions():
    foo = Field(key="foo")
    bar = Field(key="bar")
    baz = Field(key="baz")
    a = Field(key="a")
    b = Field(key="b")
    c = Field(key="c")
    foo_items = [a, b, c]
    foo_array = Array(items=foo_items)
    bar_items = [a, b, c]
    bar_array = Array(items=bar_items)
    foo_properties = {"a": a, "b": b, "c": c}
    foo_object = Object(properties=foo_properties)
    bar_properties = {"a": a, "b": b, "c": c}
    bar_object = Object(properties=bar_properties)
    foo_schema_definitions = SchemaDefinitions

# Generated at 2022-06-26 10:31:43.990610
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
  assert len(test_case_0.schema_definitions_0) == 0

# Generated at 2022-06-26 10:31:48.777902
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # __iter__ called on a Schema class that does not have any fields.
    class ExampleSchema0(Schema, metaclass=SchemaMetaclass):
        pass

    schema_iter = iter(ExampleSchema0)
    assert isinstance(schema_iter, typing.Iterator)
    assert list(schema_iter) == []



# Generated at 2022-06-26 10:31:54.217492
# Unit test for function set_definitions
def test_set_definitions():
    class GameSchema(Schema):
        title = Field.string(max_length=200)
        rating = Field.string()


    # Array
    field = Array(items=GameSchema)
    set_definitions(field, SchemaDefinitions())

    # Object
    field = Object(properties=GameSchema.fields)
    set_definitions(field, SchemaDefinitions())


# Generated at 2022-06-26 10:31:54.879398
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
	pass


# Generated at 2022-06-26 10:31:58.099452
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_p = SchemaDefinitions()
    pass


# Generated at 2022-06-26 10:32:06.100920
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    person = {'name': 'John Doe', 'age': 25}
    # test on_fail, mutable=True, strip_none=True
    class Person(Schema):
        name = String(max_length=255)
        age = Integer(minimum=1, maximum=99)
    person = Person(**person)
    assert person.is_valid(strict=False)
    assert not person.is_valid(strict=True)
    # test on_fail, mutable=True, strip_none=False
    delattr(Person, 'name')
    person = Person(**person)
    assert not person.is_valid(strict=False)
    assert not person.is_valid(strict=True)
    # test on_fail, mutable=False, strip_none=True

# Generated at 2022-06-26 10:32:13.829026
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # call __new__ of SchemaMetaclass
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = SchemaMetaclass.__new__(
        SchemaMetaclass,
        str("Schema"),
        tuple(
            [type()]
        ),
        dict(fields=dict()),
        schema_definitions_0,
    )


# Generated at 2022-06-26 10:32:17.997831
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Setup
    name = ''
    bases = []
    attrs = {}
    definitions = SchemaDefinitions()
    schema_definitions_0 = definitions

    # Invocation
    result = SchemaMetaclass(name, bases, attrs, definitions)

    # Verification
    assert isinstance(result, type)


# Generated at 2022-06-26 10:32:28.305664
# Unit test for function set_definitions
def test_set_definitions():
    assert 1 == 1

# Generated at 2022-06-26 10:32:30.256142
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()



# Generated at 2022-06-26 10:32:43.612104
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = Schema.__class__
    class_1 = SchemaDefinitions.__class__
    attributes_0 = {
        "fields": {
            "id": Integer(required=True, description="User unique identifier",),
            "name": String(
                description="Unique user name", min_length=1, pattern=r"^[a-zA-Z0-9]{1,20}$",
            ),
        }
    }
    result_0 = Schema(schema_definitions_0)
    result_1 = Schema(schema_definitions_0)
    result_2 = Schema(result_1)


# Generated at 2022-06-26 10:32:54.441971
# Unit test for function set_definitions
def test_set_definitions():
    class MyField(Field):
        pass

    class MyListField(Array):
        pass

    class MyObjectField(Object):
        pass


# Generated at 2022-06-26 10:32:59.690330
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    m = Schema()
    assert hasattr(m,'__iter__')
    assert callable(getattr(m,'__iter__'))
    assert not hasattr(m,'__next__')
    #assert callable(getattr(m,'__next__'))


# Generated at 2022-06-26 10:33:01.707457
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert Schema() == Schema()



# Generated at 2022-06-26 10:33:09.070071
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_2 = SchemaDefinitions()
    schema_field_1 = Field()
    reference_1 = Reference(to="")
    schema_field_2 = Field()
    set_definitions(schema_field_1, schema_definitions_2)
    set_definitions(reference_1, schema_definitions_1)
    set_definitions(schema_field_2, schema_definitions_1)



# Generated at 2022-06-26 10:33:10.366417
# Unit test for constructor of class Schema
def test_Schema():
    pass


# Generated at 2022-06-26 10:33:22.090153
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    child_0_0 = Schema("child_0_0")
    child_0_0.fields['child_0_0_field_0'] = Field(type='string')
    schema_definitions_0['child_0_0'] = child_0_0
    grandchild_0_0_0 = Schema("grandchild_0_0_0")
    grandchild_0_0_0.fields['grandchild_0_0_0_field_0'] = Field(type='string')
    schema_definitions_0['grandchild_0_0_0'] = grandchild_0_0_0

# Generated at 2022-06-26 10:33:26.842897
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class_name = 'ClassName'
    arguments = {
        'key': 'value'
    }
    argument_str = ", ".join(
        [f"{key}={value!r}" for key, value in arguments.items()]
    )
    sparse_indicator = " [sparse]" 
    assert f"{class_name}({argument_str}){sparse_indicator}" == Schema.__repr__(class_name, arguments)


# Generated at 2022-06-26 10:33:37.666034
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    assert not Schema() == Schema()
    assert not Schema() == str()
    assert not Schema() == Schema()


# Generated at 2022-06-26 10:33:49.143859
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    """
    Tests if the length of the Schema is properly evaluated.
    """
    target = Schema()
    assert len(target) == 0
    target = Schema({"a": 1})
    assert len(target) == 1
    target = Schema("Hello, World")
    assert len(target) == 0
    target = Schema("Hello, World", {"a": 1})
    assert len(target) == 0



# Generated at 2022-06-26 10:33:51.437812
# Unit test for constructor of class Schema
def test_Schema():
    test_case_0()

    test_case_1()

    test_case_2()

    test_case_3()


# Generated at 2022-06-26 10:33:54.380424
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    def test_case_0():
        class TestSchema(Schema):
            ...

    def test_case_1():
        class TestSchema(Schema):
            ...

        ...


# Generated at 2022-06-26 10:33:58.997094
# Unit test for constructor of class Schema
def test_Schema():
    for _ in range(5):

        # Constructor test case 0
        try:
            Schema()
        except TypeError:
            pass
        else:
            assert False



# Generated at 2022-06-26 10:33:59.617660
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass

# Generated at 2022-06-26 10:34:07.157595
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    class_0 = Schema(schema_definitions_0)
    class_1 = Schema(schema_definitions_0)
    class_2 = Schema(schema_definitions_0)
    class_2.fields[-13] = [0.0]
    assert (class_0 == class_0)
    assert (class_0 == class_1)
    assert not (class_0 != class_1)
    assert not (class_0 == class_2)
    assert (class_0 != class_2)


# Generated at 2022-06-26 10:34:11.380876
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    set_definitions(field=None, definitions=schema_definitions_0)
    assert isinstance(schema_definitions_0, SchemaDefinitions)


# Generated at 2022-06-26 10:34:16.919742
# Unit test for constructor of class Schema
def test_Schema():
    test_case_0()

# Generated at 2022-06-26 10:34:20.853675
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    assert schema_0.__getitem__('key') == None


# Generated at 2022-06-26 10:34:32.695915
# Unit test for function set_definitions
def test_set_definitions():
    def_0 = SchemaDefinitions()
    val_0 = set_definitions(None, def_0)
    assert val_0 is None


# Generated at 2022-06-26 10:34:34.370140
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    locals()["test_case_0"]()
    return


# Generated at 2022-06-26 10:34:39.401945
# Unit test for function set_definitions
def test_set_definitions():
    field = Array(Reference(to='Book', definitions = None))
    set_definitions(field, {'Book': 'Book is a schema'})
    validator = field.make_validator()
    assert validator == {'type': 'array', 'items': {'$ref': '#/definitions/Book'}}


# Generated at 2022-06-26 10:34:40.666359
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema()
    assert iter(schema) is not None


# Generated at 2022-06-26 10:34:44.557513
# Unit test for constructor of class Schema
def test_Schema():
    # Test for constructor of class Schema
    assert len(test_case_0()) == 0

test_Schema()
test_case_0()

test_Schema()
test_case_0()

# Generated at 2022-06-26 10:34:57.210442
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert len(schema_0.fields) == len(schema_0)
    schema_0 = Schema(
        field_0=Field(validators=[])
    )
    assert len(schema_0.fields) == len(schema_0)
    schema_0 = Schema(
        field_0=Field(validators=[]),
        field_1=Field(validators=[])
    )
    assert len(schema_0.fields) == len(schema_0)
    schema_0 = Schema(
        field_0=Field(validators=[]),
        field_1=Field(validators=[]),
        field_2=Field(validators=[])
    )
    assert len(schema_0.fields) == len(schema_0)

# Generated at 2022-06-26 10:35:06.284526
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_1 = SchemaDefinitions()
    try:
        Schema.validate([])
        assert False
    except TypeError:
        pass
    try:
        Schema(1, 2, 3)
        assert False
    except TypeError:
        pass
    schema_definitions_1['test_schema_class_0'] = test_schema_class_0 = Schema(
        'test_schema_class_0',
        (Schema,),
        {'f0': Int32()}
    )

# Generated at 2022-06-26 10:35:10.003896
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    assert isinstance(repr(schema_0), str)



# Generated at 2022-06-26 10:35:22.443975
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    attrs_0 = {}
    bases_0 = ()
    name_0 = 'TestSchemaClass'
    schema_dict_0 = type(name_0, bases_0, attrs_0)(schema_definitions_0)
    attrs_1 = {}
    attrs_1['field_0'] = schema_dict_0.employee
    attrs_1['field_1'] = schema_dict_0.name
    bases_1 = ()
    name_1 = 'TestSchemaClass0'
    schema_dict_1 = type(name_1, bases_1, attrs_1)(schema_definitions_0)
    attrs_2 = {}
    attrs_2['field_0'] = schema_dict_0.employee
   

# Generated at 2022-06-26 10:35:23.487992
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # assert False
    assert True


# Generated at 2022-06-26 10:35:56.944257
# Unit test for function set_definitions
def test_set_definitions():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0['test_case'] = 0
    assert len(schema_definitions_0) == 1

    schema_definitions_0['test_case'] = 0
    # AssertionError: Definition for 'test_case' has already been set.
    try:
        assert len(schema_definitions_0) == 1
    except AssertionError as e:
        print("AssertionError:", e.args)

    del schema_definitions_0['test_case']
    assert len(schema_definitions_0) == 0



# Generated at 2022-06-26 10:36:05.788289
# Unit test for constructor of class Schema
def test_Schema():
    # Test if `fields` is created correctly.
    schema_0 = Schema()
    assert schema_0.fields == {}

    # Test as a subclass
    # Test if `fields` is created correctly.
    class Foo(Schema):
        foo = Field(type="string")
        bar = Field(type="string")

    schema_1 = Foo()
    assert schema_1.fields == {"foo": Field(type="string"), "bar": Field(type="string")}

    # Test if `fields` is created correctly if parameters are passed.
    schema_2 = Foo({"foo": "foo", "bar": "bar"})
    assert schema_2.foo == "foo"
    assert schema_2.bar == "bar"

    # Test if `fields` is created correctly if parameters are passed.

# Generated at 2022-06-26 10:36:14.732315
# Unit test for constructor of class Schema
def test_Schema():
    # Default is a valid argument.
    s = Schema()

    # Positional argument can be a mapping.
    s = Schema({})

    # Positional argument can be an object.
    class Object:
        pass

    s = Schema(Object())

    class EmptySchema(Schema):
        pass

    # Schema instances can also be positional arguments.
    s = Schema(EmptySchema())

    # Positional and keyword arguments cannot be used together.
    with pytest.raises(TypeError):
        Schema({}, foo="bar")

    class SimpleSchema(Schema):
        foo = Field()

    # A valid mapping works fine.
    schema = SimpleSchema({"foo": 1})

    # A valid object also works fine.

# Generated at 2022-06-26 10:36:21.672572
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Pet_0(Schema):
        name = String(required=True)

    pet_0_0 = Pet_0(name='Pluto')
    pet_0_1 = Pet_0(name='Pluto')
    pet_0_2 = Pet_0(name='Pluto the Pup')
    result_0 = pet_0_0 == pet_0_1
    result_1 = pet_0_0 == pet_0_2
    assert result_0 and (not result_1)


# Generated at 2022-06-26 10:36:34.983991
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_definitions_0 = SchemaDefinitions()
    class User(Schema,  # type: ignore
                definitions=schema_definitions_0):
        name = String(max_length=50)
        email = String()
    user_0 = User(name="obama", email="obama@whitehouse.gov")
    assert user_0["name"] == "obama"
    assert user_0["email"] == "obama@whitehouse.gov"
    user_1 = User(name="obama")
    assert user_1["name"] == "obama"
    assert "name" in user_0
    assert "email" in user_0
    assert "name" in user_1
    assert "email" not in user_1

# Generated at 2022-06-26 10:36:48.072150
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Test case - arguments are included in __repr__ output
    class TestSchema1(Schema):
        a = Field(max_length=10)

    obj = TestSchema1(a="string")
    assert (
        repr(obj) == 'TestSchema1(a="string")'
    ), "Invalid '__repr__' output for schema with a required argument"

    # Test case - sparse argument not included in __repr__ output
    class TestSchema2(Schema):
        a = Field(max_length=10)
        b = Field(max_length=10)

    obj = TestSchema2(a="string")
    assert (
        repr(obj) == 'TestSchema2(a="string") [sparse]'
    ), "Invalid '__repr__' output for sparsely populated schema"



# Generated at 2022-06-26 10:36:48.773400
# Unit test for method __len__ of class Schema

# Generated at 2022-06-26 10:36:52.049967
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    result = schema_0.__iter__()
    assert result is not None


# Generated at 2022-06-26 10:36:56.395133
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()
    foo_0 = Schema(schema_definitions_0)
    assert foo_0.fields == {}


# Generated at 2022-06-26 10:37:00.400330
# Unit test for function set_definitions
def test_set_definitions():
    field_0: Reference = Reference(to="Item")
    set_definitions(field=field_0, definitions=schema_definitions_0)
    assert field_0.definitions == schema_definitions_0


# Generated at 2022-06-26 10:37:24.079976
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_definitions_0.__setitem__('__', '__')
    schema_definitions_0.__setitem__('__', '__')
    schema_definitions_0.__setitem__('__', '__')
    schema_definitions_0.__setitem__('__', '__')
    schema_definitions_0.__setitem__('__', '__')
    schema_definitions_0.__setitem__('__', '__')
    schema_definitions_0.__setitem__('__', '__')
    schema_definitions_0.__setitem__('__', '__')
    schema_definitions_0.__setitem__('__', '__')

# Generated at 2022-06-26 10:37:37.947740
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # FIXME: Change values, returns and assertions
    data_0_schema_0 = {
        "id": "https://example.com/person.schema.json",
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "Person",
        "type": "object",
        "properties": {
            "firstName": {"type": "string"},
            "lastName": {"type": "string"},
            "age": {"description": "Age in years", "type": "integer", "minimum": 0},
        },
    }

# Generated at 2022-06-26 10:37:39.003896
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0 = SchemaDefinitions()



# Generated at 2022-06-26 10:37:53.006649
# Unit test for constructor of class Reference
def test_Reference():
    print("test_Reference")

    # params
    schema_definitions_0 = SchemaDefinitions()

    # execution
    ret_Reference = Reference(
        "Foobar",
        definitions=schema_definitions_0,
        description="bar",
        name="foo",
        required=False,
    )

    # verification
    assert isinstance(ret_Reference, Reference) == True
    assert ret_Reference.errors == {"null": "May not be null."}
    assert ret_Reference.description == "bar"
    assert ret_Reference.name == "foo"
    assert ret_Reference.required == False
    assert ret_Reference.allow_null == False
    assert ret_Reference.to == "Foobar"
    assert ret_Reference.definitions == schema_definitions_0
    assert ret_Reference.target_

# Generated at 2022-06-26 10:37:55.340953
# Unit test for constructor of class Schema
def test_Schema():
    assert issubclass(Schema, Mapping)
    assert isinstance(Schema.fields, dict)
    schema = Schema()



# Generated at 2022-06-26 10:38:02.448371
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_2 = SchemaDefinitions()
    class ExampleSchema_0(Schema, metaclass=SchemaMetaclass):
        title = Field()

    try:
        ExampleSchema_0.validate({})
    except ValidationError as error:
        error_1 = error
    else:
        assert False, "Expected error message not raised."

# Generated at 2022-06-26 10:38:06.348632
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Setup
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    schema_1 = Schema(schema_definitions_0)

    # Testing
    result = schema_0 == schema_1

    assert result is True


# Generated at 2022-06-26 10:38:17.381875
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.typing import Generic
    from typing import Any, Iterator, List, Optional

    schema_definitions_1 = SchemaDefinitions()

    class State0(Generic[Any]):
        def __init__(self, state: Any, transitions: Optional[List[Any]] = None) -> None:
            self.state = state
            self.transitions = transitions

        def __eq__(self, other) -> bool:
            if not isinstance(other, self.__class__):
                return False
            if self.state != other.state:
                return False
            if self.transitions != other.transitions:
                return False
            return True

        def __iter__(self) -> Iterator[Any]:
            yield "state", self.state
            yield "transitions", self.transitions


# Generated at 2022-06-26 10:38:20.084684
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field()
        b = Field()
    assert Foo(a=1, b=2) == Foo(a=1, b=2)


# Generated at 2022-06-26 10:38:24.002904
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_definitions_0 = SchemaDefinitions()
    schema_0 = Schema(schema_definitions_0)
    class TestSchema(SchemaMetaclass):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any):
            pass
    TestSchema.fields = {}
    TestSchema.__name__ = 'TestSchema'
    TestSchema.validate = Schema.validate
    TestSchema.validate_or_error = Schema.validate_or_error
    TestSchema.make_validator = Schema.make_validator
    TestSchema.__init__ = Schema.__init__
    TestSchema.__eq__ = Schema.__eq__
    TestSchema.__getitem__ = Schema.__getitem__


# Generated at 2022-06-26 10:38:52.840724
# Unit test for constructor of class Reference
def test_Reference():
    to = "schema_definitions_0"
    definitions = SchemaDefinitions()
    reference = Reference(to, definitions)
    assert reference.to == to
    assert reference.definitions == definitions
    assert reference._target_string == to
    assert reference._target is None
    assert reference.target_string == to
    assert reference.target is None


# Generated at 2022-06-26 10:38:56.010946
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema()
    schema.__iter__()
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:38:58.041177
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_definitions_0 = SchemaDefinitions()


# Generated at 2022-06-26 10:39:02.034257
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    """Test method Schema.__repr__."""
    try:
        c = Schema(
            name='Alice'
        )
    except Exception as e:
        print(e)
    # TODO: check the result
    print("result:", c)



# Generated at 2022-06-26 10:39:10.715445
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_0 = SchemaDefinitions()

    class TestSchema(Schema, metaclass=SchemaMetaclass):
        field_0 = Field()
        field_1 = Field()

    schema_instance_1 = TestSchema(field_0=0, field_1=1)
    try:
        len(schema_instance_1)
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-26 10:39:23.685557
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Creating an instance of Class_0
    schema_definitions_0 = SchemaDefinitions()

    # Creating an instance of Field
    schema_definitions_0["Class_0"] = Field()

    # Creating an instance of Schema
    schema_definitions_0["Class_0"] = Schema()

    # Calling __iter__()
    schema_definitions_0["Class_0"].__iter__()

    # Creating an instance of Field
    schema_definitions_0["Class_0"] = Field()

    # Creating an instance of Schema
    schema_definitions_0["Class_0"] = Schema()

    # Calling __iter__()
    schema_definitions_0["Class_0"].__iter__()

    # Creating an instance of Field
    schema_definitions_0["Class_0"] = Field()

# Generated at 2022-06-26 10:39:34.259693
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    class User(Schema, definitions=schema_definitions_0):
        _id = String()
        email = String()
        name = String()
    class TrackingNumber(Schema, definitions=schema_definitions_0):
        _id = String()
        user = Reference(to="User")
    user = User(email="email0", name="name0")
    tracking_number = TrackingNumber(user=user)
    assert tracking_number == TrackingNumber(user=User(email="email0", name="name0"))
    tracking_number.user.email = "email1"
    assert tracking_number != TrackingNumber(user=User(email="email0", name="name0"))
    tracking_number.user = User(email="email0", name="name0")
   

# Generated at 2022-06-26 10:39:45.297162
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_definitions_0 = SchemaDefinitions()
    A = Schema("A", definitions=schema_definitions_0, 
               field1=Reference("B", definitions=schema_definitions_0, 
                                required=True, allow_null=False), 
               field2=Reference("C", definitions=schema_definitions_0, 
                                required=True, allow_null=False), 
               field3=Reference("D", definitions=schema_definitions_0, 
                                required=True, allow_null=False), 
               field4=Reference("E", definitions=schema_definitions_0, 
                                required=True, allow_null=False))

# Generated at 2022-06-26 10:39:54.741763
# Unit test for constructor of class Schema

# Generated at 2022-06-26 10:40:04.727465
# Unit test for constructor of class Schema
def test_Schema():
    schema_definitions_0: SchemaDefinitions = SchemaDefinitions()
    schema_fields_0: typing.Dict[str, Field] = {}
    schema_0: Schema = Schema(schema_fields_0, definitions=schema_definitions_0)
    schema_fields_1: typing.Dict[str, Field] = {}
    schema_fields_1["key1"] = schema_0
    schema_fields_1["key2"] = schema_0
    schema_1: Schema = Schema(schema_fields_1)
    schema_fields_2: typing.Dict[str, Field] = {}
    schema_2: Schema = Schema(schema_fields_2)
    schema_fields_2["key1"] = schema_1

# Generated at 2022-06-26 10:40:30.453371
# Unit test for constructor of class Schema
def test_Schema():
    test_case_0()
    test_case_Schema_0()
    test_case_Schema_1()


# Generated at 2022-06-26 10:40:38.973730
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions_1 = SchemaDefinitions()

    class Foo(Schema, definitions=schema_definitions_1):
        name = Field()
        price = Field()
        address = Reference("Address", definitions=schema_definitions_1)

    instance_of_Foo = Foo(name="Hello", price=123, address={"city": "London"})
    len(instance_of_Foo) == 3

# Generated at 2022-06-26 10:40:40.488959
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema()) == 0


# Generated at 2022-06-26 10:40:48.287353
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class InventoryItem(Schema):
        name = String(max_length=100, required=True)
        price = Number(minimum=0, required=True)

    item = InventoryItem(name="Chair", price=9.99)
    try:
        actual = repr(item)
    except Exception as e:
        raise AssertionError("Unexpected Exception: " + str(e)) from e
    except AssertionError as ae:
        raise ae
    else:
        assert actual == "InventoryItem(name='Chair', price=9.99)", (
            "Method __repr__ returned: " + actual + " not: InventoryItem(name='Chair', price=9.99)"
        )


# Generated at 2022-06-26 10:40:50.530914
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    result = len(test_case_0())
    assert result == 0


# Generated at 2022-06-26 10:40:59.947453
# Unit test for function set_definitions
def test_set_definitions():
    base = Array()
    definitions = SchemaDefinitions()
    set_definitions(base, definitions)
    assert base.definitions == definitions
    assert len(definitions) == 0

    ref = Reference("RefToNothing")
    set_definitions(ref, definitions)
    assert ref.definitions == definitions
    assert len(definitions) == 0

    schema_definitions_1 = SchemaDefinitions()
    schema_definitions_2 = SchemaDefinitions()

    class InnerSchema(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions_2):
        inner_field = Field()
        inner_ref = Reference("RefToNothing")
        inner_array = Array(items=Field())

    assert len(schema_definitions_2) == 0
