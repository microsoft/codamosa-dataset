

# Generated at 2022-06-26 10:31:23.501405
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        string = Field()
        integer = Integer()
        null = Float(allow_null = True)
        array = Array(items = Field())
        object = Object(properties = {"a": Field(), "b": Field()})

    schema = TestSchema(string = "test", integer = 6, array = ["a", 1], object = {"b": "x"})
    assert(schema["string"] == "test")
    assert(schema["integer"] == 6)
    assert(schema["array"] == ["a", 1])
    assert(schema["object"] == {"b": "x"})
    try:
        schema["null"]
    except KeyError:
        pass
    else:
        assert(False)



# Generated at 2022-06-26 10:31:26.461793
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    schema_1 = Schema()
    str_0 = str(schema_1)
    str_1 = str(schema_0)
    assert str_0 != str_1, f"Expected ({str_0!r} != {str_1!r}), got ({str_0!r} == {str_1!r})"


# Generated at 2022-06-26 10:31:29.038410
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    expected = "foo"
    s = Schema()
    actual = s["foo"]
    assert expected == actual


# Generated at 2022-06-26 10:31:31.148428
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test default case
    schema_metaclass_1 = SchemaMetaclass()


# Generated at 2022-06-26 10:31:32.413972
# Unit test for constructor of class Schema
def test_Schema():
    pass


# Generated at 2022-06-26 10:31:43.073498
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Test with no args.
    s = Schema()
    assert repr(s) == "Schema()"

    # Test with argument.
    s = Schema({"a": 1})
    assert repr(s) == "Schema(a=1)"

    # Test with sparse.
    s = Schema({"a": 1}, b=2)
    assert repr(s) == "Schema(a=1) [sparse]"

    # Test with extra property.
    s = Schema({"c": 1}, b=2)
    assert repr(s) == "Schema(c=1) [sparse]"

    # Test with nested object.
    class SubSchema(Schema):
        a = Field(required=True)

    s = SubSchema(a=1)

# Generated at 2022-06-26 10:31:46.423221
# Unit test for function set_definitions
def test_set_definitions(): 
    from typesystem.fields import String

    class User(Schema):
        id = String(format="uuid")
    
    local_definitions = SchemaDefinitions({"User": User})
    set_definitions(User.id, local_definitions)

# Generated at 2022-06-26 10:31:48.406588
# Unit test for constructor of class Reference
def test_Reference():
    reference = Reference(to = 'required', nullable = False, definitions = None)


# Generated at 2022-06-26 10:32:00.710207
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    """
    Test for iter method of Schema Class
    """

    global s
    s = Schema()
    s.fields = {
        "field_1":
        Array(integer=Integer()),
        "field_2":
        String(),
        "mapping":
        Mapping(
            {
                "mapping_field_1":
                Array(integer=Integer()),
                "mapping_field_2":
                Array(integer=Integer()),
            }
        ),
        "another_mapping":
        Mapping({"another_mapping_key": String()}),
    }

    assert list(s) == ["field_1", "field_2", "mapping", "another_mapping"]

# Generated at 2022-06-26 10:32:07.225854
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.fields import Integer
    from typesystem.references import Reference

    field = Integer()
    definitions1 = SchemaDefinitions({"foo": field})
    set_definitions(field, definitions1)
    dictionaries1 = {
        "a": {"b": {"c": Reference(to="a")}, "d": {"e": Reference(to="foo")}}
    }
    definitions2 = SchemaDefinitions({"a": Array(definitions1)})
    for field in definitions2.values():
        set_definitions(field, definitions2)
    result1 = dictionaries1["a"]["b"]["c"].definitions
    result2 = dictionaries1["a"]["d"]["e"].definitions
    result3 = dictionaries1["a"]["b"]["c"].target

# Generated at 2022-06-26 10:32:30.403175
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Array, Integer, Object, String

    class Item(Schema):
        name = String(max_length=50)
        qty = Integer(minimum=1, maximum=500)

    class Order(Schema):
        items = Array(of=Item)

    obj = Order(items=Item(name="T-Shirt", qty=1))

    assert hasattr(obj, "fields")
    assert isinstance(obj.fields, dict)
    assert len(obj.fields) == 1

    assert "items" in obj.fields
    assert isinstance(obj.fields["items"], Array)
    assert isinstance(obj.fields["items"].items, Item)
    assert isinstance(obj.fields["items"].items.fields, dict)
    assert len(obj.fields["items"].items.fields) == 2

# Generated at 2022-06-26 10:32:34.016080
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema()
    schema.fields = {"a": 1}
    ret = iter(schema)
    assert ["a"] == list(ret)


# Generated at 2022-06-26 10:32:38.303045
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert iter(Schema()) == []



# Generated at 2022-06-26 10:32:42.911710
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        foo = Reference("bar")

    class TestSchema2(Schema):
        foo = Reference("bar")

    definitions = SchemaDefinitions()
    definitions["bar"] = TestSchema2

    set_definitions(TestSchema.foo, definitions)
    assert TestSchema.foo._target == TestSchema2

# Generated at 2022-06-26 10:32:46.157365
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class S0(Schema):
        pass
    s0 = S0()
    assert s0.__iter__() is not None

# Generated at 2022-06-26 10:32:53.968345
# Unit test for constructor of class Schema
def test_Schema():
    # A class that fits the Schema definition, which is a dictionary-like class
    class TestSchema(Schema):
        field_0 = Field(key="field_0", required=True)
        field_1 = Field(key="field_1", required=True)

    # An input dictionary
    input_dictionary = {
        "field_0": "value_0",
        "field_1": "value_1"
    }
    # Test case
    test_case_0 = TestSchema(input_dictionary)
    # Return
    return test_case_0



# Generated at 2022-06-26 10:33:04.007141
# Unit test for function set_definitions
def test_set_definitions():
    # Test setting definitions for a root-level `Reference` field
    reference_field = Reference(to="a_name")
    definitions = SchemaDefinitions()
    definitions["a_name"] = object

    set_definitions(reference_field, definitions)
    assert reference_field.definitions == definitions
    assert reference_field._target == object

    # Test setting definitions for nested `Reference` fields
    reference_field = Array(Reference(to="a_name"))
    set_definitions(reference_field, definitions)
    assert reference_field.definitions == definitions
    assert reference_field._target == object

    class TestSchema(Schema):
        a = Reference(to="a_name")

    definitions = SchemaDefinitions()
    definitions["a_name"] = object

    test_schema = TestSchema()
    assert test

# Generated at 2022-06-26 10:33:11.710191
# Unit test for function set_definitions
def test_set_definitions():
    schema_0 = Schema()
    schema_1 = Reference('test')
    schema_2 = Array(Reference('test'))
    schema_3 = Object(properties={"test": Reference('test')})
    schema_4 = Object(properties={"test": Array(Reference('test'))})

    definitions = SchemaDefinitions()
    set_definitions(schema_0, definitions)
    set_definitions(schema_1, definitions)
    set_definitions(schema_2, definitions)
    set_definitions(schema_3, definitions)
    set_definitions(schema_4, definitions)



# Generated at 2022-06-26 10:33:14.211196
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert len(schema_0) == 0
test_case_0()
test_Schema___len__()

# Generated at 2022-06-26 10:33:16.677028
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema()
    assert list(schema.__iter__()) == []


# Generated at 2022-06-26 10:33:39.645618
# Unit test for method validate of class Reference
def test_Reference_validate():
    test_schema = Schema()
    test_reference = Reference(test_schema)
    assert test_reference.validate(test_schema.validate(None)) == None
    assert test_reference.validate(test_schema.validate({})) == {}


# Generated at 2022-06-26 10:33:44.557860
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_1 = Schema()
    assert schema_1.__len__() == len(schema_1)


# Generated at 2022-06-26 10:33:47.422397
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    try:
        test_case_0()
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-26 10:33:54.123991
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    Schema_len_0 = len(schema_0)
    assert Schema_len_0 == -1
    schema_1 = Schema()
    Schema_len_1 = len(schema_1)
    assert Schema_len_1 == -1
    schema_2 = Schema()
    Schema_len_2 = len(schema_2)
    assert Schema_len_2 == -1


# Generated at 2022-06-26 10:33:57.865088
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert schema_0.__repr__() == 'Schema()'


# Generated at 2022-06-26 10:34:00.972677
# Unit test for method validate of class Reference
def test_Reference_validate():
    
    class Schema0(Schema):
        field0 = Reference("Schema1")
    
    class Schema1(Schema):
        field0 = Reference("Schema0")


# Generated at 2022-06-26 10:34:02.576097
# Unit test for constructor of class Schema
def test_Schema():
    # When nothing is pass to the constructor
    assert test_case_0() == None



# Generated at 2022-06-26 10:34:05.042878
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    result_0 = iter(schema_0)
    assert result_0 == iter([])


# Generated at 2022-06-26 10:34:07.999966
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema()
    schema_1 = Schema()
    assert schema_0.__eq__(schema_1) == True


# Generated at 2022-06-26 10:34:09.730326
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    schema_1 = Schema()


# Generated at 2022-06-26 10:34:20.912666
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema()

# Generated at 2022-06-26 10:34:24.004063
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema_0 = Schema()
    assert str(schema_0) == 'Schema()'


# Generated at 2022-06-26 10:34:25.889056
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert (
    repr(Schema())
    == "Schema()"
    )



# Generated at 2022-06-26 10:34:30.465841
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    assert (
        repr(schema_0) == 'Schema()'
    ), "Expected value: Schema(), Actual value: {}".format(
        repr(schema_0)
    )

    schema_1 = Schema({"name": '"data"'})


# Generated at 2022-06-26 10:34:32.107124
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_0 = Schema()
    assert schema_0.__len__() == 0



# Generated at 2022-06-26 10:34:42.579612
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    # Check that a refence object is correctly assigned the definitions object
    ref = Reference("User")
    set_definitions(ref, definitions)
    assert ref.definitions == definitions

    # Check that an Array of reference objects is correctly assigned the definitions object
    refs = Array(items=[Reference("User")])
    set_definitions(refs, definitions)
    assert isinstance(refs.items, Array)
    assert refs.items.items[0].definitions == definitions

    # Check that a nested array of reference objects is correctly assigned the definitions object
    refs = Array(items=[Array(items=[Reference("User")])])
    assert isinstance(refs.items[0], Array)
    set_definitions(refs, definitions)
    assert isinstance(refs.items, Array)


# Generated at 2022-06-26 10:34:45.740583
# Unit test for constructor of class Schema
def test_Schema():
    try:
        schema_0 = Schema()
    except Exception as error:
        print("test_Schema failed")
        print(error)
        raise


# Generated at 2022-06-26 10:34:48.061649
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    _ = schema_0


# Generated at 2022-06-26 10:34:52.245227
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference("hello")
    assert r.to == "hello"
    r = Reference("hello", allow_null=True)
    assert r.to == "hello"
    assert r.allow_null == True

# Generated at 2022-06-26 10:34:53.218015
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    s = Schema()
    assert [x for x in s] == []


# Methods for testing __setattr__ and __delattr__ of Schema

# Generated at 2022-06-26 10:35:11.884059
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    schema_1 = Schema(schema_0)
    assert schema_0 == schema_1


# Generated at 2022-06-26 10:35:14.189851
# Unit test for method validate of class Reference
def test_Reference_validate():
    ref_test = Reference(to="test")
    ref_test.validate(None)

# Generated at 2022-06-26 10:35:16.262416
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    len(test_case_0()) == 0


# Generated at 2022-06-26 10:35:21.252878
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_1 = Schema(foo=1, bar=2)
    schema_2 = Schema(foo=3, bar=4)
    assert schema_1['foo'] == 1
    assert schema_1['bar'] == 2
    assert schema_2['foo'] == 3
    assert schema_2['bar'] == 4


# Generated at 2022-06-26 10:35:23.571374
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    try:
        assert Schema() == Schema()
    except AssertionError:
        raise Exception("Test case 0 failed")



# Generated at 2022-06-26 10:35:24.788420
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema()
    return schema


# Generated at 2022-06-26 10:35:25.973075
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(test_case_0()) == "Schema()"

# Generated at 2022-06-26 10:35:27.481799
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    print("Testing __len__ of Schema")
    assert len(test_case_0()) == 0


# Generated at 2022-06-26 10:35:33.470120
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema = Schema
    s = schema
    assert s == s
    assert s != 1
    assert not (s == 1)
    assert (schema() == schema())
    assert not (schema() == schema(a=1))
    assert not (schema(a=1) == schema())
    assert schema(a=1) == schema(a=1)
    assert not (schema(a=1) == schema(a=1, b=1))
    assert not (schema(a=1) == schema(a=2))
    assert schema(a=[1]) == schema(a=[1])
    assert not (schema(a=[1]) == schema(a=[2]))
    assert not (schema(a=[1]) == schema(a=[1, 2]))

# Generated at 2022-06-26 10:35:36.113959
# Unit test for constructor of class Reference
def test_Reference():
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 10:35:48.180399
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    for key in schema_0:
        pass


# Generated at 2022-06-26 10:35:54.490884
# Unit test for method validate of class Reference
def test_Reference_validate():
    schema_instance = Schema()
    schema_fields = {'field1': Field(name='field1'), 'field2': Field(name='field2')}
    schema_instance_0 = Schema(field1=None, field2=None)
    def reference_validate_0():
        ref = Reference('Schema')
        ref.validate(schema_instance_0)
    # Expect a ValidationError exception
    # with ValidationError("May not be null."):
    reference_validate_0()
    def reference_validate_1():
        ref_1 = Reference("Schema")
        ref_1.validate(None, strict=True)
    # Expect a ValidationError exception
    # with ValidationError("May not be null."):
    reference_validate_1()


# Generated at 2022-06-26 10:35:57.427078
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    for key in schema_0.fields.keys():
        if not hasattr(schema_0, key):
            key += key



# Generated at 2022-06-26 10:36:06.136331
# Unit test for constructor of class Schema
def test_Schema():
    Source = Schema.define(
        "Source",
        id=String(max_length=32),
        name=String(max_length=32),
        count=Integer(minimum=0),
    )
    s = Source(id="1", name="John Doe", count=15)
    assert s.id == "1"
    assert s.name == "John Doe"
    assert s.count == 15

    try:
        s = Source(id="1", name="John Doe", count=-15)
    except TypeError as e:
        assert e.__str__() == "Invalid argument 'count' for Source(). Invalid value -15."

    try:
        s = Source(id="1")
    except TypeError as e:
        assert e.__str__() == "name is a required argument for Source()."


# Generated at 2022-06-26 10:36:11.808856
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_1 = Schema()
    schema_2 = Schema()
    # Two schemas are equal if they are the same type.
    assert schema_1 == schema_2

# Generated at 2022-06-26 10:36:22.361824
# Unit test for constructor of class Schema
def test_Schema():
    assert set(schema_0.fields.keys()) == set()
    assert schema_0.is_sparse
    assert len(schema_0) == 0
    assert not dict(schema_0)
    assert repr(schema_0) == "Schema()"

    schema_0 = Schema()

    schema_1 = Schema(
        {
            "name": "Joel",
            "age": 36,
            "address": "123 Main St"
        }
    )
    assert set(schema_1.fields.keys()) == {"name", "age", "address"}
    assert schema_1.is_sparse
    assert len(schema_1) == 3

# Generated at 2022-06-26 10:36:35.149687
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Unit test for when class Reference is instantiated and schema is not specified
    to = "Food"
    definitions = None
    reference = Reference(to, definitions)
    value = "http://schema.org/Food"
    strict = False
    assert reference.validate(value, strict=strict) == "http://schema.org/Food"
    # Unit test for when class Reference is instantiated and schema is specified
    to = "Food"
    definitions = SchemaDefinitions()
    class FoodSchema(Schema):
        pass
    reference = Reference(to, definitions)
    value = "http://schema.org/Food"
    strict = False
    assert reference.validate(value, strict=strict) == "http://schema.org/Food"


# Generated at 2022-06-26 10:36:43.040619
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference('Person', allow_none=False, nullable=False).nullable == False
    assert Reference('Person', allow_none=False, nullable=False).to == 'Person'
    assert Reference(Person, allow_none=False, nullable=False).to == Person
    assert Reference('Person', allow_none=False, nullable=False).definitions == None


# Generated at 2022-06-26 10:36:44.828593
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Check result of function __len__ of class Schema
    assert 0 == test_case_0().__len__()

# Generated at 2022-06-26 10:36:47.570750
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema_0 = Schema(alpha=5)
    schema_1 = Schema(alpha=5)
    assert schema_0 == schema_1


# Generated at 2022-06-26 10:37:10.226940
# Unit test for constructor of class Schema
def test_Schema():
    with pytest.raises(TypeError):
        test_case_0()


# Generated at 2022-06-26 10:37:12.249886
# Unit test for constructor of class Schema
def test_Schema():
    class Schema_0(Schema):
        pass

    schema_0 = Schema_0()
    assert type(schema_0) == Schema_0



# Generated at 2022-06-26 10:37:14.550905
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_1 = Schema()
    isinstance(schema_1.__iter__(), list)


# Generated at 2022-06-26 10:37:16.867748
# Unit test for constructor of class Schema
def test_Schema():
    class AtoS(Schema):
        field_0 = Field('string')

    schema_0 = AtoS(field_0 = 'a')


# Generated at 2022-06-26 10:37:26.990866
# Unit test for constructor of class Schema
def test_Schema():
    x = Schema(a=1, b=2, c=3)
    assert x.a == 1
    assert x.b == 2
    assert x.c == 3
    assert x.is_sparse == False
    # Test fields have default values.
    x = Schema(c=3)
    assert x.c == 3
    assert x.a == None
    assert x.b == None
    assert x.is_sparse == True
    # Test fields with default values.
    x = Schema(a=1, b=2)
    assert x.a != None
    assert x.b != None
    # Test missing fields.
    with pytest.raises(TypeError):
        x = Schema(d=4)

# Generated at 2022-06-26 10:37:29.530993
# Unit test for constructor of class Schema
def test_Schema():
    schema_1 = Schema(hello="world")
    if schema_1 == None:
        pass

# Generated at 2022-06-26 10:37:38.476978
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # test the case where there is no data in the schema
    test_0 = Schema()
    assert list(test_0) == []
    # test the case where there is only one data in the schema
    test_1 = Schema(a=1)
    assert list(test_1) == ['a']
    # test the case where there is more than one data in the schema
    test_2 = Schema(
        a=1,
        b=2,
        c=3,
    )
    assert list(test_2) == ['a', 'b', 'c']


# Generated at 2022-06-26 10:37:43.218092
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Schedule(Schema):
        start_time = Field()
        end_time = Field()

    class Reservation(Schema):
        schedule = Reference(Schedule)

    cls = Reservation(schedule=Schedule(start_time=1570520528, end_time=1570524728))
    assert cls == Reservation(schedule=Schedule(start_time=1570520528, end_time=1570524728))



# Generated at 2022-06-26 10:37:48.241006
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert not hasattr(schema_0, "fields")
    expected = []
    assert list(schema_0.__iter__()) == expected


# Generated at 2022-06-26 10:37:59.445096
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    assert_equals(next(iter(Schema())), None)
    assert_equals(next(iter(Schema({}))), None)
    assert_equals(next(iter(Schema({'a': 1}))), 'a')
    assert_equals(Schema({'a': 1})['a'], 1)
    assert_equals(Schema({'a': 1})['b'], None)
    assert_equals(len(Schema({'a': 1})), 1)
    assert_equals(repr(Schema({'a': 1})), 'Schema(a=1)')
    assert_equals(repr(Schema()), 'Schema()')
    assert_equals(repr(Schema({})), 'Schema()')

# Generated at 2022-06-26 10:38:53.901693
# Unit test for constructor of class Reference
def test_Reference():
    test_target = Schema(first_name="test", last_name="test",age=1)
    test_to = Schema()
    test_definitions = {"test": Schema}
    test_name = ""
    test_allow_null = True
    test_description = ""
    test_default = ""
    test_model = ""
    test_help_text = ""
    test_error_messages = {"test": "test"}
    test_reference = Reference(test_to, test_definitions, test_name, test_allow_null, test_description, test_default, test_model, test_help_text, test_error_messages)
    assert test_reference.to == test_to
    assert test_reference.definitions == test_definitions
    assert test_reference.name == test_name
   

# Generated at 2022-06-26 10:39:03.888036
# Unit test for constructor of class Schema
def test_Schema():
    dct = {"a": 1, "b": 2}
    dct_2 = {"a": 2, "b": 3}
    schema = Schema(dct)
    schema_2 = Schema(schema)
    schema_3 = Schema(dct_2)
    assert not (schema == schema_2)
    assert not (schema == schema_3)
    dct["a"] = 2
    assert schema == schema_2
    assert schema == schema_3
    assert len(schema) == len(dct)
    assert len(list(iter(schema))) == len(list(iter(dct)))
    assert schema == dct
    assert schema["a"] == dct["a"]
    # Test repr
    repr(schema)
    repr(schema_0)


# Generated at 2022-06-26 10:39:07.984914
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    schema_0 = Schema()
    try:
        schema_0['key']
    except KeyError:
        pass
    else:
        raise Exception


# Generated at 2022-06-26 10:39:10.476590
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    iter = schema_0.__iter__()
    assert iter is not None

# Generated at 2022-06-26 10:39:15.868360
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    test_case_0()

if __name__ == "__main__":
    import doctest
    import pytest

    doctest.testmod()
    pytest.main(["-x", "--pdb", __file__])

# Generated at 2022-06-26 10:39:22.188099
# Unit test for method validate of class Reference
def test_Reference_validate():
    user_id = Reference("UserId")
    user_id.to = "UserId"
    user_id.definitions = SchemaDefinitions({"UserId": Schema})
    user_id.target_string = "UserId"
    user_id.target = Schema
    user_id.validate(None)


# Generated at 2022-06-26 10:39:33.595865
# Unit test for constructor of class Schema
def test_Schema():
    obj_0 = Schema.validate(
        {
            "users": [{
                "id": 0,
                "name": "John<script>alert('XSS')</script>",
                "email": "john@example.com",
            }],
            "title": "Example Title",
            "description": "Example Title",
            "created_at": "2019-02-20T19:51:43.904Z",
        }
    )
    assert obj_0.users[0].id == 0
    assert obj_0.users[0].name == "John&lt;script&gt;alert(&#x27;XSS&#x27;)&lt;/script&gt;"
    assert obj_0.users[0].email == "john@example.com"

# Generated at 2022-06-26 10:39:36.311125
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_1 = Schema()
    assert len(schema_1) == 0


# Generated at 2022-06-26 10:39:42.536762
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    def test_Schema_0_1(Item):
        assert Item.to == "C"
        assert Item.definitions == definitions

    to = "C"
    definitions = SchemaDefinitions()
    Item = Reference(to, definitions)
    Item.validate("foo")

    test_Schema_0_1(Item)


# Generated at 2022-06-26 10:39:48.721138
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    #   __repr__ should return a string describing the class.
    class case_0(Schema):
        def __repr__(self):
            return "schema_0"
    schema_0 = case_0()
    assert schema_0.__repr__() == "schema_0"



# Generated at 2022-06-26 10:40:39.110186
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema_0 = Schema()
    assert list(schema_0.__iter__()) == []

    schema_1 = Schema(**{})
    assert list(schema_1.__iter__()) == []

    schema_2 = Schema(**{'a': 1, 'b': 2})
    assert list(schema_2.__iter__()) == ['a', 'b']



# Generated at 2022-06-26 10:40:48.392347
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():

    # no fields
    schema_0 = Schema()
    assert iter(schema_0) == ()

    # one field
    class Foo(Schema):
        bar = Field()
    schema_1 = Foo(bar=1)
    assert iter(schema_1) == ("bar",)

    # one field, with a default
    class Foo(Schema):
        bar = Field(default=2)
    schema_2 = Foo()
    assert iter(schema_2) == ("bar",)

    # multiple fields
    class Baz(Schema):
        bar = Field()
        baz = Field()
    schema_3 = Baz(bar=1, baz=2)
    assert "bar" in list(iter(schema_3))
    assert "baz" in list(iter(schema_3))

   

# Generated at 2022-06-26 10:40:57.765885
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class_name = "Foo"
    bases = ()
    attrs = {"a": "foo", "b": "bar"}
    new_schema_type = SchemaMetaclass.__new__(
        SchemaMetaclass, class_name, bases, attrs
    )
    assert issubclass(new_schema_type, Schema)
    assert new_schema_type.__name__ == class_name
    assert new_schema_type.a == "foo"
    assert new_schema_type.b == "bar"
