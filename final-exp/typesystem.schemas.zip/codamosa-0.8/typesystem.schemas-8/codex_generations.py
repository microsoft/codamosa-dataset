

# Generated at 2022-06-12 15:51:03.048280
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class View1(Schema):
        class Fields:
            banana = String()

    view1 = View1(banana="banana")
    assert ["banana"] == list(view1)


# Generated at 2022-06-12 15:51:09.396801
# Unit test for constructor of class Schema
def test_Schema():

    # constructor of class 'Schema' is tested
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    person = Person(name='joe',age=20)
    print(person)
    #Person(age=20, name='joe')

    person = Person({'name':'joe','age':20})
    print(person)
    #Person(age=20, name='joe')

    #test the constraint of class 'Schema'
    #class_name = self.__class__.__name__
    #arguments = {
    #    key: getattr(self, key) for key in self.fields.keys() if hasattr(self, key)
    #}
    #argument_str = ", ".join(
    #    [f"{key}={value

# Generated at 2022-06-12 15:51:19.203528
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Animal(Schema):
        name = Field(type=str)
        species = Field(type=str)

    class Zoo(Schema):
        animals = Field(type=Array[Animal])

    zoo = Zoo(animals=[Animal(name="Panda", species="Ailuropoda melanoleuca")])
    assert isinstance(zoo, Zoo)
    assert isinstance(zoo.animals[0], Animal)
    assert "name" in zoo.animals[0]
    assert "species" in zoo.animals[0]
    assert list(zoo.animals[0]) == ["name", "species"]
    assert list(zoo) == ["animals"]


# Generated at 2022-06-12 15:51:23.477215
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)

    person = Person(name="The Dude", age=42)
    person_repr = repr(person)
    assert person_repr == "Person(age=42, name='The Dude')"


if __name__ == "__main__":
    import pytest

    pytest.main(args=[".", "--doctest-modules", "-v", "--capture=sys"])

# Generated at 2022-06-12 15:51:28.643506
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        foo = String()
    class TestSchema2(Schema):
      definitions = SchemaDefinitions(TestSchema2={})
      foo = Reference('TestSchema2')
    definitions = SchemaDefinitions(TestSchema2={})
    set_definitions(TestSchema.foo, definitions)
    assert TestSchema.foo.definitions == definitions


# Generated at 2022-06-12 15:51:31.043424
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from unittest import TestCase

# Generated at 2022-06-12 15:51:36.674383
# Unit test for function set_definitions
def test_set_definitions():
    class Obj(object):
        pass

    class CreatedWithValidDefinitions(Schema):
        foo = Reference("Foo")
        bar = Reference("Obj")

        class Meta:
            definitions = {
                "Foo": 1,
                "Obj": Obj,
            }

    class CreatedWithInvalidDefinitions(Schema):
        foo = Reference("Foo")
        bar = Reference("Obj")

        class Meta:
            definitions = {
                "Foo": 1,
            }

    assert CreatedWithValidDefinitions.fields["foo"].target == 1
    assert CreatedWithValidDefinitions.fields["bar"].target == Obj

    assert CreatedWithInvalidDefinitions.fields["foo"].target == 1
    error_raised = True

# Generated at 2022-06-12 15:51:41.685510
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        name = String()
    foo1 = Foo(name="Foo")
    foo2 = Foo(name="Foo")
    assert foo1 == foo2



# Generated at 2022-06-12 15:51:52.503827
# Unit test for constructor of class Schema
def test_Schema():
    class ProductSchema(Schema):
        sku = Reference("SKU")
        name = Reference("Name")
        description = Reference("Description")

    schemas = SchemaDefinitions()

    class SKU(Schema):
        id = Reference("Id")
        type = Reference("Type")

    class Name(Schema):
        id = Reference("Id")
        type = Reference("Type")

    class Description(Schema):
        id = Reference("Id")
        type = Reference("Type")

    SKU
    Name
    Description

    print(schemas)

    product_schema = schemas["ProductSchema"]
    print(product_schema)

    sku_schema = schemas["SKU"]
    print(sku_schema)

if __name__ == '__main__':
    test_

# Generated at 2022-06-12 15:52:02.697223
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    
    class MetaSchema(SchemaMetaclass):
        def __new__(
            cls: type,
            name: str,
            bases: typing.Sequence[type],
            attrs: dict,
            definitions: SchemaDefinitions = None,
        ) -> type:
            fields: typing.Dict[str, Field] = {}

            for key, value in list(attrs.items()):
                if isinstance(value, Field):
                    attrs.pop(key)
                    fields[key] = value

            # If this class is subclassing other Schema classes, add their fields.
            for base in reversed(bases):
                base_fields = getattr(base, "fields", {})

# Generated at 2022-06-12 15:52:24.701293
# Unit test for constructor of class Schema
def test_Schema():
    assert issubclass(Schema, Mapping)
    assert issubclass(Schema, Mapping)
    assert issubclass(SchemaMetaclass, ABCMeta)
    assert Schema.__name__ == 'Schema'
    assert Schema.__doc__ == '\n    A mapping that contains all the properties defined\n    in its :py:attr:`.fields`.\n    '
    assert Schema.make_validator.__name__ == 'make_validator'
    assert Schema.make_validator.__doc__ == '\n        Return the fields of this schema as a `typesystem.Object`\n        with the given additional properties.\n        '
    assert Schema.validate.__name__ == 'validate'

# Generated at 2022-06-12 15:52:31.702449
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert Schema(a=1, b=2) == Schema(a=1, b=2)
    assert Schema(a=1, b=2) != Schema(a=1, b=3)
    assert Schema(a=1, b=2, c=3) != Schema(a=1, b=2)


# None
if __name__ == "__main__":
    import sys

    sys.exit(int(main() or 0))

# Generated at 2022-06-12 15:52:42.935793
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.schema import Schema
    from typesystem.fields import String, Array, Object
    class Test(Schema):
        name = String(max_length=50)
        level = String(max_length=50)
        array = Array(items=String(max_length=50))
        array_of_objects = Array(items=Object(properties={"name": String(max_length=50)}))

    a = Test({'name': 'James', 'level': 'Boss', 'array': ['a', 'b'], 'array_of_objects': [{'name': 'James'}]})
    b = Test({'level': 'Boss', 'array': ['b', 'a'], 'array_of_objects': [{'name': 'James'}], 'name': 'James'})

# Generated at 2022-06-12 15:52:47.014454
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import String
    class TestSchema(Schema, metaclass=SchemaMetaclass):
        a = String()
    obj = TestSchema({'a':1})
    assert obj.a == 1


# Generated at 2022-06-12 15:52:58.262953
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Simple
    class Person(Schema):
        name = String()
        age = Integer()

    assert isinstance(Person.fields["name"], String)
    assert isinstance(Person.fields["age"], Integer)

    # Inheritance
    class Employee(Person):
        department = String()

    assert isinstance(Employee.fields["name"], String)
    assert isinstance(Employee.fields["age"], Integer)
    assert isinstance(Employee.fields["department"], String)

    # Definition
    class Person(Schema):
        name = String()
        age = Integer()

    class Employee(Person):
        department = String()

    definitions = SchemaDefinitions()

    assert isinstance(Person.fields["name"], String)
    assert isinstance(Person.fields["age"], Integer)

# Generated at 2022-06-12 15:53:10.056077
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Integer, Object, String
    from typesystem.fields import Array, Field

    class Foo(Schema):
        a = Integer()
        b = Array(Integer)

    class Bar(Schema):
        b = Array(Integer)
        c = String()

    # define class Baz
    with pytest.raises(AssertionError):
        class Baz(Bar, Foo):
            d = String()

    assert Baz.fields["a"] == Integer()
    assert Baz.fields["b"] == Array(Integer)
    assert Baz.fields["c"] == String()

    # define class Qux
    class Qux(Foo):
        d = String()

    definitions = {
        "Qux": Qux
    }

    assert Qux.fields["a"] == Integer()
    assert Qux.fields["b"]

# Generated at 2022-06-12 15:53:13.291318
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
        is_male = Boolean()

    p = Person(name="Jan", age=12, is_male=False)
    expected = "Person(name='Jan', age=12, is_male=False)"
    assert p.__repr__() == expected



# Generated at 2022-06-12 15:53:16.375155
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):

        field = Field(required=True)

    schema1 = TestSchema(field=True)
    schema2 = TestSchema(field=False)
    schema3 = TestSchema(field=True)

    assert schema1 == schema3
    assert schema1 != schema2
    assert not (schema1 == schema2)


# Generated at 2022-06-12 15:53:19.536129
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class S(Schema):
        field1 = String()
        field2 = String()
    s = S(field1='test', field2='test')
    assert (list(s) == ['field1', 'field2']) == True

# Generated at 2022-06-12 15:53:27.871889
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import pytest

    from .conftest import JsonSchemaTest

    with pytest.raises(TypeError) as excinfo:
        JsonSchemaTest.validate({"extra": "hello"})
    assert str(excinfo.value) == "'extra' is an invalid keyword argument for JsonSchemaTest()."

    schema = JsonSchemaTest.validate({})
    assert list(schema.__iter__()) == ["number", "string"]

    schema = JsonSchemaTest.validate({"number": 10, "string": "hello"})
    assert list(schema.__iter__()) == ["number", "string"]

    schema = JsonSchemaTest.validate({})
    assert list(schema.__iter__()) == ["number", "string"]

    schema = JsonSchemaTest.valid

# Generated at 2022-06-12 15:53:48.400746
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from unittest import TestCase

    class TestSchema(Schema):
        name = Field()
        age = Field(is_required = True)

    schema = TestSchema(name = 'test', age = 30)
    other_schema = TestSchema(name = 'test', age = 30)
    TestCase.assertEqual(schema.__eq__(schema), True)
    TestCase.assertEqual(schema.__eq__(other_schema), True)

    other_schema = TestSchema(name = 'test', age = 31)
    TestCase.assertEqual(schema.__eq__(other_schema), False)

    other_schema = TestSchema(name = 'test')
    TestCase.assertEqual(schema.__eq__(other_schema), False)

# Generated at 2022-06-12 15:53:59.016405
# Unit test for function set_definitions
def test_set_definitions():
    """
    Test the function set_definitions
    """
    class TestSchema(Schema):
        id = Reference("uuid")
        name = Field(str)

    assert TestSchema.fields["id"].definitions == None
    assert TestSchema.fields["name"].definitions == None
    TestSchema.fields["id"].definitions = None
    TestSchema.fields["name"].definitions = None
    set_definitions(TestSchema.fields["id"], None)
    set_definitions(TestSchema.fields["name"], None)
    assert TestSchema.fields["id"].definitions == None
    assert TestSchema.fields["name"].definitions == None



# Generated at 2022-06-12 15:54:04.927092
# Unit test for constructor of class Schema
def test_Schema():
    class Address(Schema):
        street = Field(str)
        city = Field(str)
        state = Field(str)
        postal_code = Field(str)

    address = Address(dict(
        street="100 Main St.",
        city="Anytown",
        state="CA",
        postal_code="90210",
    ))
    assert address.street == "100 Main St."
    assert address.city == "Anytown"
    assert address.state == "CA"
    assert address.postal_code == "90210"


# Generated at 2022-06-12 15:54:13.935321
# Unit test for function set_definitions
def test_set_definitions():
    field = Field()
    assert field.definitions is None
    new_defs = SchemaDefinitions()
    set_definitions(field, new_defs)
    assert field.definitions is new_defs

    fields = [
        Field(),
    ]
    array = Array(items=fields)
    assert array.items[0].definitions is None
    new_defs = SchemaDefinitions()
    set_definitions(array, new_defs)
    assert array.items[0].definitions is new_defs

    fields = {
        "property": Field(),
    }
    obj = Object(properties=fields)
    assert obj.properties["property"].definitions is None
    new_defs = SchemaDefinitions()
    set_definitions(obj, new_defs)

# Generated at 2022-06-12 15:54:16.297546
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        name = Field()
        id = Field(type=int)

    schema = MySchema(name='John', id=4)
    assert len(schema) == 2



# Generated at 2022-06-12 15:54:20.212878
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Test(Schema):
        pass

    t = Test()
    t2 = Test()
    t3 = Test({"test": True})
    t4 = Test({"test": 1})
    t5 = Test({"test": 1})
    t6 = Test({"test": "1"})

    l = [
        t == t2,
        t3 == t3,
        t3 == t4,
        t3 == t5,
        t3 == t6,
    ]

    assert l == [True, True, False, False, False]

# Generated at 2022-06-12 15:54:31.301187
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # 1
    class S1(Schema):
        a = 1

    assert S1.__repr__() == 'S1(a=1)'

    class S2(Schema):
        a = 1

    # 2
    class S3(S2):
        b = 2

    assert S3.__repr__() == 'S3(a=1, b=2)'

    class S4(S3):
        b = 2

    # 3
    class S5(S4):
        c = 3

    assert S5.__repr__() == 'S5(a=1, b=2, c=3)'

    class S6(S4):
        c = 3

    # 4
    class S7(S6):
        d = 4


# Generated at 2022-06-12 15:54:36.473433
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import String
    class Article(Schema):
        title = String()
        author = String()
        published_at = String()
        class Meta:
            strict = True
    article = Article(title='The meaning of life.')
    assert article.is_sparse == True
    assert len(article) == 1


# Generated at 2022-06-12 15:54:48.409287
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from datetime import datetime
    from typesystem import Integer, String, Array, Object
    class Author(Schema):
        id = Integer()
        first_name = String()
        last_name = String()
        email = String()
        birth_date = String()
    class Book(Schema):
        title = String()
        author = Reference(Author)
        isbn = String()
        pub_date = String()
    authors_schema = Array(items=Reference(Author))
    books_schema = Object(properties={
        "title": String(),
        "author": Reference(Author),
        "isbn": String(),
        "pub_date": String(),
    })
    class Root(Schema):
        books = Reference(books_schema)
        authors = Reference(authors_schema)
    author_schema

# Generated at 2022-06-12 15:54:49.577990
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(obj) == len(obj.fields)


# Generated at 2022-06-12 15:55:08.504215
# Unit test for constructor of class Schema
def test_Schema():
    class A(Schema):
        a = Field(int)

    assert A(a=5) == A({"a":5}) == A(A(a=5)) == A(A(A(a=5)))
    with pytest.raises(TypeError):
        A({})
    with pytest.raises(TypeError):
        A({"a": 5, "b": 6})
    with pytest.raises(TypeError):
        A(a=5, b=6)
    with pytest.raises(TypeError):
        A(a="a")
    with pytest.raises(TypeError):
        A(a=None)
    with pytest.raises(TypeError):
        A(None)


# Generated at 2022-06-12 15:55:14.212493
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        id = Field()

        def __iter__(self):
            yield from super().__iter__()
            yield from self.__dict__.keys()

    mySchemaInstance = MySchema()
    mySchemaInstance.id = 1
    mySchemaInstance.newVar = 2

    assert len(mySchemaInstance.fields) == 1
    assert len(list(mySchemaInstance)) == 2



# Generated at 2022-06-12 15:55:16.309945
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert Schema().__len__() == 0
    assert Schema([]).__len__() == 0
    assert Schema({}).__len__() == 0


# Generated at 2022-06-12 15:55:18.038466
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class MySchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    for key in MySchema.fields:
        assert key in ("a", "b", "c")

# Generated at 2022-06-12 15:55:23.474477
# Unit test for function set_definitions
def test_set_definitions():
    class Address(Schema):
        street = Field(str)
        city = Field(str)

    class Person(Schema):
        name = Field(str)
        address = Reference("Address")

    definitions = SchemaDefinitions()
    set_definitions(Person.make_validator(), definitions)
    assert definitions["Address"] == Address


# Test that string references can be correctly resolved, including
# recursively resolving references to references.

# Generated at 2022-06-12 15:55:35.021465
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from dtlpy.client.services import SchemaFactory
    from dtlpy.model_definition import SchemaDefinition
    from dtlpy.models import DatasetItem
    schema = SchemaFactory(SchemaDefinition('a','a','','','','@pramod','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','_temp_id',[],[],[],[],[],[],[],[],[],[],[],[],{})).create(DatasetItem)

# Generated at 2022-06-12 15:55:44.970379
# Unit test for method __len__ of class Schema

# Generated at 2022-06-12 15:55:48.836782
# Unit test for constructor of class Reference
def test_Reference():
    reference = Reference(to='Dummy',allow_null=True,description='This is a reference')
    assert reference.to == 'Dummy'
    assert reference._target_string == 'Dummy'
    assert reference.allow_null == True
    assert reference._target is None
    assert reference.description == 'This is a reference'
    assert reference.errors['null'] == 'May not be null.'


# Generated at 2022-06-12 15:56:00.453668
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field = Field()
    assert TestSchema(field=1) == TestSchema(field=1)
    assert TestSchema() == TestSchema()
    assert TestSchema(field=1) != TestSchema(field=2)
    assert TestSchema(field=1) != TestSchema(field=1, extra_field=2)
    assert TestSchema(field=1) != TestSchema()
    assert TestSchema(field=1) != TestSchema(field=None)
    assert TestSchema(field=1) == TestSchema(field=1.0)
    assert TestSchema(field=None) == TestSchema(field=None)
    assert TestSchema(field=None) != TestSchema(field=1.0)
    assert TestSchema

# Generated at 2022-06-12 15:56:04.994518
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class ABC(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")

    a = ABC()
    assert tuple(a.__iter__()) == tuple()

    a = ABC(a="a",b="b",c="c")
    assert tuple(a.__iter__()) == tuple(["a", "b", "c"])



# Generated at 2022-06-12 15:56:22.981246
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.string import String

    class User(Schema):
        username = String(format="email")

    user1 = User("darth.vader@deathstar.com")
    assert user1.username == "darth.vader@deathstar.com"

    user2 = User(username="darth.vader@deathstar.com")
    assert user2.username == "darth.vader@deathstar.com"

    # Invalid keyword argument
    try:
        User(email="darth.vader@deathstar.com")
        assert False, "Should raise TypeError"
    except TypeError:
        pass



# Generated at 2022-06-12 15:56:30.213166
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        first_name = Field(str)
        last_name = Field(str)
        age = Field(int, default=0)
    person = Person(first_name="John", last_name="Doe", age=25)
    assert person.first_name == "John" and person.last_name == "Doe" and person.age == 25


# Generated at 2022-06-12 15:56:40.658168
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from numpy import array, array2string
    from pandas import DataFrame
    from typesystem.typing import Dict
    from hypothesis import given
    from hypothesis import strategies as st
    from tests.utils import validate_with_errors

    data_schema = Schema(
        name=st.text(),
        age=st.integers(min_value=0, max_value=140),
        contact_info=Object(email=st.text(), phone=st.text()),
    )

    data_schema2 = Schema(
        name=st.text(),
        age=st.integers(min_value=0, max_value=140),
        contact_info=Object(email=st.text(), phone=st.text()),
    )


# Generated at 2022-06-12 15:56:46.150583
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String(required=True)
        age = Integer(minimum=0)

    # with all fields
    person = Person(name="Jane Doe", age=42)
    assert sorted(list(person)) == sorted(["name", "age"])

    # with missing fields
    person = Person(name="Jane Doe")
    assert sorted(list(person)) == ["name"]

    # empty
    person = Person()
    assert not list(person)



# Generated at 2022-06-12 15:56:54.244555
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import unittest
    from typesystem.base import String, Integer

    class User(Schema):
        name = String()
        age = Integer()

    user = User(name="John", age=25)
    assert len(user) == 2

    iterator = iter(user)
    assert next(iterator) == "name"
    assert next(iterator) == "age"
    with unittest.raises(StopIteration):
        next(iterator)


# Generated at 2022-06-12 15:56:55.650533
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert Schema().__len__() == 0


# Generated at 2022-06-12 15:56:57.703415
# Unit test for constructor of class Reference
def test_Reference():
    a = Reference('a')
    assert a.to == 'a'
    assert a.definitions is None



# Generated at 2022-06-12 15:57:02.510828
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        field1 = Reference("B")
        field2 = Array(Reference("B"))

    class B(Schema):
        field1 = String(default="B")

    definitions = SchemaDefinitions()
    definitions['B'] = B

    set_definitions(A.fields['field1'], definitions)
    set_definitions(A.fields['field2'], definitions)
    assert len(definitions) == 2
    assert A.fields['field1'].target_string == "B"
    assert A.fields['field2'].items.target_string == "B"

# Generated at 2022-06-12 15:57:12.762363
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import copy
    import random
    import string
    import unittest
    from typesystem import messages

    """
    Test the `__eq__` method of `Schema`.
    """

    def _make_field(name: str) -> Field:
        if name.endswith("_list"):
            return Array(Integer())
        elif name != "c":
            return String()
        else:
            return String(default=lambda: "".join(random.choices(string.ascii_letters, k=10)))

    class A(Schema):
        a = _make_field("a")
        b = _make_field("b")
        c = _make_field("c")

    class B(Schema):
        a = _make_field("a")

# Generated at 2022-06-12 15:57:25.164830
# Unit test for constructor of class Schema
def test_Schema():
    from typing import List, Dict
    from .types import User
    from .fields import Integer, String, Boolean
    class Address(Schema):
        street = String()
        post_code = String()
        city = String()
        country = String()
    class User(Schema):
        id = Integer()
        name = String()
        is_active = Boolean(default=True)
        address = Reference(Address)
        phones = Array(Integer, min_items=1)
    # test creating a User instance by unpacking a dictionary
    u = User(dict(id=1, name='Alice', address=dict(street='1 Main Street')))
    assert u.id == 1
    assert u.name == 'Alice'
    assert u.is_active == True
    assert u.phone == None

# Generated at 2022-06-12 15:57:44.888701
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Integer(default=1)
        b = String(default="")
        c = Integer(default=3)

    s1 = TestSchema()
    s2 = TestSchema(**{'a': 1, 'b': "", 'c': 3})
    assert s1 == s2

    s1 = TestSchema(**{'a': 1, 'b': '2'})
    s2 = TestSchema(**{'a': 1, 'b': "", 'c': 3})
    assert s1 != s2


# Generated at 2022-06-12 15:57:49.107860
# Unit test for function set_definitions
def test_set_definitions():
    class Subfield(Field):
        pass
    class Inner(Schema):
        a = Subfield()

    inner = Inner.make_validator()
    assert inner.properties["a"].definitions is None

    definitions = SchemaDefinitions()
    set_definitions(inner, definitions)
    assert inner.properties["a"].definitions is not None

# Generated at 2022-06-12 15:57:57.017148
# Unit test for constructor of class Schema
def test_Schema():
    class Nested(Schema):
        a = Field()
        b = Field()

    class Simple(Schema):
        c = Field()
        d = Field()

    s = Simple(c=3, d=("a", "b"))
    print(s.c, s.d)

    # Test with a nested object
    s = Simple(Nested(a=1, b=2), c=3, d=("a", "b"))
    print(s.c, s.d)

    d = {"c": 1, "d": ["a", "b"]}

    # Test with normal dictionary
    s = Simple(c=3, d=("a", "b"))
    print(s)

    # Test with a nested object in a dictionary

# Generated at 2022-06-12 15:58:02.453396
# Unit test for function set_definitions
def test_set_definitions():
    class MyType(Field):
        pass

    definitions = SchemaDefinitions()
    field = MyType()
    set_definitions(field, definitions)
    assert set_definitions(field, definitions) is None
    assert isinstance(field, MyType)

# Generated at 2022-06-12 15:58:03.212444
# Unit test for constructor of class Reference
def test_Reference():
    definition = SchemaDefinitions()
    Reference("schema", definitions=definition)
    assert definition == {"schema": None}

# Generated at 2022-06-12 15:58:13.283074
# Unit test for function set_definitions
def test_set_definitions():
    class Point(Schema):
        x = Field(required=True)
        y = Field(required=True)

    class Line(Schema):
        start = Reference(Point)
        end = Reference(Point)

    class Line2(Schema):
        start = Reference(Point)
        end = Reference(Point)

    class PointCollection(Schema):
        points = Array(Reference(Point))

    class LineCollection(Schema):
        lines = Array(Reference(Line))

    class LineCollection2(Schema):
        lines = Array(Reference(Line2))

    class PointAndLineCollection(Schema):
        points = Array(Reference(Point))
        lines = Array(Reference(Line2))

    assert Line._meta.definitions == None
    assert Line2._meta.definitions == None
    assert Point._meta.definitions

# Generated at 2022-06-12 15:58:18.284778
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class User(Schema):
        username = "typesystem.String"
        age = "typesystem.Integer"
        email = "typesystem.String(format='email')"
    u = User({"username": "daw", "age": 29})
    assert repr(u) == "User(username='daw', age=29)"


# Generated at 2022-06-12 15:58:23.261131
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        fields = {"field_one": Field(str), "field_two": Field(str)}
    test_obj = TestSchema({"field_one": "some string"})
    got = list(test_obj)
    expected = ["field_one"]
    assert got == expected, \
        "Schema.__iter__: got: {} expected: {}".format(got, expected)


# Generated at 2022-06-12 15:58:33.662032
# Unit test for constructor of class Schema
def test_Schema():
    e = getattr(syntax_tree.examples, 'Student')()
    #
    # print(e.schema.fields)

    print('\n\n\n*******************Creating Schema*******************')
    print(e)
    print(e.schema)
    assert e.schema
    assert not e.schema.is_sparse
    assert e.schema.likes_coding
    assert e.schema.gender == 'male'
    assert e.schema.name == 'Joe'
    assert e.schema.age == 15

    print('\n\n\n*******************Creating Schema via list*******************')

# Generated at 2022-06-12 15:58:37.004310
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # We use the class ArticleSchema as an example
    class ArticleSchema(Schema):
        title = String()
        body = String(max_length=1000)

    data = ArticleSchema(title='Hello world!', body='Lorem ipsum')
    data_repr = repr(data)
    assert data_repr == 'ArticleSchema(title=\'Hello world!\', body=\'Lorem ipsum\')'


# Generated at 2022-06-12 15:59:11.330068
# Unit test for method validate of class Reference
def test_Reference_validate():
    assert issubclass(Reference, Field)
    assert Reference.validate(None) == None

# Generated at 2022-06-12 15:59:15.281902
# Unit test for function set_definitions
def test_set_definitions():
    class DefinitionSchema(Schema):
        a = Reference("b")
        b = Field()

    definitions = SchemaDefinitions()
    set_definitions(DefinitionSchema.a, definitions)
    assert DefinitionSchema.a.definitions is definitions

# Generated at 2022-06-12 15:59:16.533371
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert SimpleSchema.__len__() == 0


# Generated at 2022-06-12 15:59:17.304800
# Unit test for constructor of class Reference
def test_Reference():
    assert type(Reference(to=None)) is Reference

# Generated at 2022-06-12 15:59:23.791563
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
  class Foo1(Schema):
    pass
  class Foo2(Schema):
    fields = {"x": String(default="foo")}
  class Bar(Schema):
    fields = {"foo1": Schema(Foo1), "foo2": Foo2()}
  obj = Bar()
  assert obj.foo1
  assert obj.foo2
  assert obj.fields["foo1"].fields
  assert obj.fields["foo2"].fields


# Generated at 2022-06-12 15:59:28.532076
# Unit test for method validate of class Reference
def test_Reference_validate():
    print("test_Reference_validate")
    to = "test"
    definitions = {to: "test"}
    reference = Reference(to, definitions)
    value = "value"
    expected = value
    actual = reference.validate(value)
    assert actual == expected, f"actual: {actual}, expected: {expected}"
    print("finished test_Reference_validate")


# Generated at 2022-06-12 15:59:38.372193
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import copy
    import random
    from hypothesis import given
    from hypothesis.strategies import dictionaries, fixed_dictionaries, from_regex, sampled_from
    from hypothesis.strategies import text, tuples, characters, data, integers, floats
    from hypothesis.strategies import composite, recursive, lists, one_of

    class Value(Schema):
        a = integers()
        b = floats()
        c = text()


# Generated at 2022-06-12 15:59:42.872926
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class User(Schema):
        id = Field(type="string")
        name = Field(type="string")

    u1 = User(id="123", name="foo")
    u2 = User(id="123", name="foo")
    assert u1 == u2

# Generated at 2022-06-12 15:59:46.729191
# Unit test for method validate of class Reference
def test_Reference_validate():
    print("Calling test_Reference_validate...")
    assert Reference("Person").validate("Person") == "Person"
    print("test_Reference_validate passed")


# Generated at 2022-06-12 15:59:47.818692
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema() != None
