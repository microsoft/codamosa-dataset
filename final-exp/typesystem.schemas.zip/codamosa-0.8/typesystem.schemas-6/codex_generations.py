

# Generated at 2022-06-12 15:50:59.083566
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass


# Generated at 2022-06-12 15:51:03.823718
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        test1 = String(default="test1")
        test2 = String(default="test2")
        test3 = String(default="test3")
        test4 = String(default="test4")

    test_schema = TestSchema(test1="test1", test2="test2", test4="test4")

    print(test_schema)
    print(test_schema.is_sparse)
    print(repr(test_schema))

if __name__ == "__main__":
    test_Schema___repr__()

# Generated at 2022-06-12 15:51:07.254436
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        foo = Reference("B")

    class B(Schema):
        pass

    a = A()
    assert a.foo.definitions == {"B": B}
    assert a.foo.target == B

    definitions = SchemaDefinitions()
    b = B()
    definitions["B"] = b
    assert b.definitions == definitions


# Generated at 2022-06-12 15:51:16.422981
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.fields import Boolean, Integer, String

    class User(Schema):
        id = Integer(enforce_string=True)
        username = String()
        is_superuser = Boolean()

    user = User(id=1, username="JohnDoe", is_superuser=True)
    assert user == User(id=1, username="JohnDoe", is_superuser=True)
    assert user != User(id=2, username="JohnDoe", is_superuser=True)
    assert user != User(id=1, username="JohnDoe", is_superuser=False)
    assert user != User(id=2, username="JohnDoe", is_superuser=False)


# Generated at 2022-06-12 15:51:20.583409
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import typesystem
    class Person(typesystem.Schema):
        name = typesystem.String()
        age = typesystem.Integer()
    def test_function():
        assert len(Person(
        )) == 0
        assert len(Person(
            name="John",
        )) == 1
        assert len(Person(
            name="John",
            age=42,
        )) == 2
    test_function()


# Generated at 2022-06-12 15:51:22.557487
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = String()
        b = String()

    s = TestSchema(a="Hello World!")
    assert len(s) == 1



# Generated at 2022-06-12 15:51:31.182584
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class User(Schema):
        uuid = Reference("UUID")

    set_definitions(User.fields["uuid"], definitions)
    assert User.fields["uuid"].definitions is definitions

    class Organization(Schema):
        users = Array(Reference("User"))
        owner = Reference("User")

    set_definitions(Organization.fields["users"], definitions)
    assert Organization.fields["users"].items.definitions is definitions

    set_definitions(Organization.fields["owner"], definitions)
    assert Organization.fields["owner"].definitions is definitions

# Generated at 2022-06-12 15:51:34.398877
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String
    class UserSchema(Schema):
        name = String()
    user = UserSchema(name='foo')
    assert user.is_sparse
    assert len(list(user.__iter__())) == 1


# Generated at 2022-06-12 15:51:36.431005
# Unit test for constructor of class Reference
def test_Reference():
    instance = Reference("Reference", _description="description")
    assert instance.to == "Reference"
    assert instance.definitions == definitions
    assert instance._description == "description"



# Generated at 2022-06-12 15:51:38.491150
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        pass  # class TestSchema
    x = TestSchema()
    assert isinstance(x, TestSchema)
    assert TestSchema.fields == {}


# Generated at 2022-06-12 15:52:00.856181
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    assert Person(name="Bob", age=42).name == "Bob"
    assert Person(name="Bob", age=42).age == 42
    assert Person(Person(name="Bob", age=42)).name == "Bob"
    assert Person(Person(name="Bob", age=42)).age == 42
    assert Person({"name": "Bob", "age": 42}).name == "Bob"
    assert Person({"name": "Bob", "age": 42}).age == 42
    assert Person(dict(name="Bob", age=42)).name == "Bob"
    assert Person(dict(name="Bob", age=42)).age == 42


# Generated at 2022-06-12 15:52:04.378339
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Location(Schema):
        lat = ...  # type: ignore
        lon = ...  # type: ignore

    loc = Location(lat=10.2, lon=1.2)

    assert list(loc) == ['lat', 'lon']
    assert list(loc.items()) == [('lat', 10.2), ('lon', 1.2)]
    return True


# Generated at 2022-06-12 15:52:08.672402
# Unit test for method validate of class Reference
def test_Reference_validate():
    class MySchema(Schema):
        name = String()
    from typesystem.validators import String
    ref = Reference(MySchema)
    result = ref.validate({"name": "MyName"})
    assert isinstance(result, MySchema)
    assert result.name == "MyName"

# Generated at 2022-06-12 15:52:20.133980
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Integer, String


    class MySchema(Schema):
        id = Integer()
        name = String()


    my_schema = MySchema({"id": 1, "name": "abc"})
    assert list(my_schema.__iter__()) == ["id", "name"]
    assert list(my_schema.__iter__()) == ["id", "name"]
    list_result = [key for key in my_schema.__iter__()]
    assert list_result == ["id", "name"]
    assert list_result == ["id", "name"]
    assert my_schema.__iter__() == ["id", "name"]
    assert my_schema.__iter__() == ["id", "name"]

# Generated at 2022-06-12 15:52:23.206210
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a_field = Field()

    schema = TestSchema()
    assert list(schema.__iter__()) == ['a_field']



# Generated at 2022-06-12 15:52:25.035062
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    a_temp = TestSchema(prop0 = 1)
    pass

# Generated at 2022-06-12 15:52:31.593744
# Unit test for constructor of class Schema
def test_Schema():
    class Building(Schema):
        pass

    class Building(Schema):
        name = Field(str)

    print(Building(name="Anson House"))
    print(Building({"name": "Anson House"}))
    building = Building(name="Anson House")
    print(building.name)
    class Building(Schema):
        name = Field(str)
        address = Field()
    
    building = Building(name="Anson House", address="Soho, London")
    print(building.name)
    print(building.address)



# Generated at 2022-06-12 15:52:37.611833
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import typesystem
    class TestSchema(typesystem.Schema):
        arr = typesystem.Array(typesystem.Integer())
        obj = typesystem.Object(properties={"name": typesystem.String()})

    schema = TestSchema()
    schema.__iter__() == iter(['arr', 'obj'])



# Generated at 2022-06-12 15:52:46.137566
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema1(Schema):
        class TestSchema2(Schema):
            class TestSchema3(Schema):
                foo = Reference('test_string')

        foo = Reference('test_string')
        bar = Reference('test_string')

    def check_field(field: Field, expected_definition: typing.Any):
        if isinstance(field, Reference):
            assert field.definitions is expected_definition
            assert field.to == expected_definition[field.target_string]

    definitions = SchemaDefinitions()

    # Check that function works as expected when given a simple schema
    schema = TestSchema1(definitions)
    set_definitions(schema, definitions)
    for field in schema.fields.values():
        check_field(field, definitions)

    # Check that function works as expected when given a

# Generated at 2022-06-12 15:52:57.377918
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    """Test method __iter__ of class Schema."""
    target_1 = Array(fields=['id', 'name'])
    target_2 = Array(fields=['id', 'name'])
    target_3 = Array(fields=['id', 'id'])
    target_4 = Array(fields=['id', 'name', 'name'])

    test_1 = [{'id': 1,'name': 'yue'},
              {'id': 2,'name': 'hao'}]
    test_2 = [{'id': 1,'name': 'yue'},
              {'id': 2,'name': 'hao'}]

# Generated at 2022-06-12 15:53:31.622708
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        first_name = String()
        last_name = String()
        age = Integer()
        favourite_things = Array(String())
        friends = Array(Reference("Person"))

    person = Person(
        first_name="John",
        last_name="Doe",
        age=55,
        favourite_things=["rock", "paper", "scissors"],
        friends=[
            Person(first_name="Jane", last_name="Doe"),
            Person(first_name="Bob", last_name="Smith"),
        ],
    )
    assert person.first_name == "John"
    assert person.last_name == "Doe"
    assert person.age == 55
    assert person.favourite_things == ["rock", "paper", "scissors"]

# Generated at 2022-06-12 15:53:44.286628
# Unit test for constructor of class Schema
def test_Schema():
    import json
    from unittest.mock import MagicMock
    from typesystem.base import Field
    from typesystem.object import Object
    import typing
    from collections.abc import Mapping, MutableMapping
    from typesystem.base import ValidationError, ValidationResult
    from typesystem.fields import Array, Field, Object
    from typesystem.schema import SchemaMetaclass
    from typesystem.schema import Schema
    example_json = json.dumps({'first_name': 'Saya', 'last_name': 'Kagoshima'})
    example_object = json.loads(example_json)
    
    user_schema = Schema(example_json)
    assert isinstance(user_schema, Schema)
    assert type(user_schema).__name__ == 'Schema'

# Generated at 2022-06-12 15:53:51.365951
# Unit test for constructor of class Reference
def test_Reference():

    class User(Schema):
        id = Integer()
        name = String()
        age = Integer(minimum=0, maximum=150)
        friends = Array("reference User")

    class Pet(Schema):
        name = String()
        owner = "reference User"

    class Car(Schema):
        owner = "reference User"

    class Boat(Schema):
        owner = "reference User"

    user_schema = User.make_validator()
    pet_schema = Pet.make_validator()
    car_schema = Car.make_validator()
    boat_schema = Boat.make_validator()

    definitions = SchemaDefinitions()

    user_schema.definitions = definitions
    pet_schema.definitions = definitions

    car_schema.definitions = definitions
    boat_sche

# Generated at 2022-06-12 15:53:58.096332
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from pprint import pprint
    from typesystem import String
    from typesystem.schema import Schema

    class Band(Schema):
        name = String()

    band = Band({"name": "The Beatles"})
    assert band["name"] == "The Beatles"

    try:
        band["genre"]
    except KeyError:
        assert True
    else:
        assert False

    print("all tests passed for method __getitem__ of class Schema!")


# Generated at 2022-06-12 15:54:02.026715
# Unit test for function set_definitions
def test_set_definitions():
    class UserSchema(Schema):
        id = Array(items=Integer())

    class PetSchema(Schema):
        owner = Reference(to="UserSchema")

    definitions = SchemaDefinitions()
    set_definitions(PetSchema.fields["owner"], definitions)
    assert definitions["UserSchema"] == UserSchema

# Generated at 2022-06-12 15:54:07.633977
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    data = {'a': 1, 'b': 2, 'c': 3}
    class D(Schema):
        a = Field(type=int, required=True)
        b = Field(type=int, default=10)
        c = Field(type=int, required=True)

    assert repr(D(**data)) == "D(a=1, c=3)"

# Generated at 2022-06-12 15:54:15.923556
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert Schema() == {}
    assert Schema(String(max_length=100)) == {"max_length": 100}
    assert Schema(String(max_length=100), required=True) == {"max_length": 100}
    assert Schema(String(max_length=100),required=[]) == {"max_length": 100}

    class Person(Schema):
        first_name = String(max_length=100)
        last_name = String(max_length=100)

    p = Person(first_name='John',last_name='Doe')
    assert p == {"first_name":"John","last_name":"Doe"}

    assert len(p) == 2
    assert list(p) == ["first_name","last_name"]

    class Person(Schema):
        first_name = String()
        last

# Generated at 2022-06-12 15:54:23.314350
# Unit test for constructor of class Schema
def test_Schema():
    assert issubclass(Schema, Mapping) == True
    assert issubclass(Schema, typing.Mapping) == False
    assert isinstance(Schema, type)
    assert isinstance(Schema, ABCMeta)
    assert issubclass(Schema, Schema) == True
    assert issubclass(Schema, Object) == False
    assert issubclass(Schema, Field) == False
    assert issubclass(Schema, Mapping) == True


# Generated at 2022-06-12 15:54:23.982335
# Unit test for function set_definitions
def test_set_definitions():
    # Todo: implement
    pass

# Generated at 2022-06-12 15:54:36.060760
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Schema_test_Schema___eq__(Schema):
        field_1_1 = Field()
        field_1_2 = Field()
        field_2_1 = Field()
        field_2_2 = Field()
    object_1 = Schema_test_Schema___eq__({
        'field_1_1': 'value_1_1',
        'field_1_2': 'value_1_2',
        'field_2_1': 'value_2_1',
        'field_2_2': 'value_2_2'
    })

# Generated at 2022-06-12 15:55:00.458949
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass

# Generated at 2022-06-12 15:55:09.558967
# Unit test for constructor of class Schema
def test_Schema():
    # Test for valid case for __init__
    class PersonSchema(Schema):
        name = Field(type="string", format="name")
        age = Field(type="integer")
    name = "Bob"
    age = 20
    person = PersonSchema(name=name, age=age)
    assert person.name == name
    assert person.age == age
    # Test for missing field
    with pytest.raises(TypeError):
        PersonSchema(name=name)
    # Test for extra field
    with pytest.raises(TypeError):
        PersonSchema(name=name, age=age, height=5)
    # Test for wrong type
    with pytest.raises(TypeError):
        PersonSchema(name=name, age='20')
    # Test for invalid argument

# Generated at 2022-06-12 15:55:17.933832
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class User(Schema):
        user = Reference(to = 'User')
        username = 'username'
        following = Array(Reference(to = 'User'))

    class Post(Schema):
        user = Reference(to = 'user', definitions = {'User': User, 'user': User})
        post_date = 'post_date'
        likes = 'likes'
        content = 'content'
        comment = Reference(to = 'comment', definitions = {'comment': Comment})

    class Comment(Schema):
        user = Reference(to = 'user', definitions = {'User': User, 'user': User})
        post_date = 'post_date'
        comment = 'comment'
        likes = 'likes'

    user_definitions = SchemaDefinitions({'user': User, 'User': User})
    user

# Generated at 2022-06-12 15:55:20.545467
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Setup
    class Foo(Schema):
        pass

    # Exercise
    foo = Foo()
    # Verify
    assert foo.fields == {}


# Generated at 2022-06-12 15:55:28.211843
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        fields = {
            "a": Field(default="a"),
            "b": Field(default="b"),
            "c": Field(default="c")
        }

    class B(Schema):
        fields = {
            "a": Field(default="a"),
            "b": Field(default="b"),
            "c": Field(default="c")
        }

    class C(B, A):
        fields = {
            "a": Field(default="a"),
            "b": Field(default="b"),
            "c": Field(default="c"),
            "d": Field(default="d")
        }

    class D(C):
        fields = {
            "e": Field(default="e")
        }
    assert C.fields["a"].default == "a"

# Generated at 2022-06-12 15:55:34.571106
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    b = Schema( {'a': 1, 'b': 'bbb'} )
    assert b.__repr__() == 'Schema(a=1, b=\'bbb\')'
    b = Schema( {'a': 1, 'b': 'bbb', 'c': None} )
    assert b.__repr__() == 'Schema(a=1, b=\'bbb\', c=None)'


# Generated at 2022-06-12 15:55:36.077803
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    result = len(Schema())
    assert result == 0


# Generated at 2022-06-12 15:55:45.824869
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class ExampleSchema(Schema):
        field_1 = Field()
        field_2 = Field()
        field_3 = Field()
        field_4 = Field()

    example_schema = ExampleSchema()
    assert example_schema.__repr__() == "ExampleSchema() [sparse]"

    example_schema = ExampleSchema(field_1="value_1", field_3=3)
    expected = 'ExampleSchema(field_1="value_1", field_3=3)'
    assert example_schema.__repr__() == expected

    example_schema = ExampleSchema(field_1="value_1", field_3=3, field_4=None)
    expected = 'ExampleSchema(field_1="value_1", field_3=3, field_4=None)'


# Generated at 2022-06-12 15:55:49.653252
# Unit test for function set_definitions
def test_set_definitions():
    class ChildSchema(Schema):
        name = Field()

    class ParentSchema(Schema):
        child = Reference(ChildSchema)

        definitions = SchemaDefinitions()

    assert ParentSchema.fields["child"].target is ChildSchema
    assert ChildSchema.fields["name"].target is ChildSchema.fields["name"]

# Generated at 2022-06-12 15:56:01.626470
# Unit test for function set_definitions
def test_set_definitions():

    class TestSchemaDefinitions1(Schema):
        a = Reference("to_a_1")

    class TestSchemaDefinitions2(Schema):
        a = Reference("to_a_2")

    # define definitions
    definitions = SchemaDefinitions()
    definitions["to_a_1"] = TestSchemaDefinitions1.fields["a"]
    definitions["to_a_2"] = TestSchemaDefinitions2.fields["a"]

    # SchemaDefinitions should contain two definitions
    assert len(definitions) == 2

    # each element should have proper reference
    assert definitions["to_a_1"] == TestSchemaDefinitions1.fields["a"]
    assert definitions["to_a_2"] == TestSchemaDefinitions2.fields["a"]

    # include definitions in Reference fields

# Generated at 2022-06-12 15:56:58.580286
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field1 = Integer()
    # TestSchema.fields
    assert TestSchema.fields == {'field1': Integer()}
    # TestSchema.validate
    assert TestSchema.validate({}) == TestSchema({})
    assert TestSchema.validate({'field1': 123}) == TestSchema({'field1': 123})
    assert TestSchema.validate({'field1': 123}, strict=True) == TestSchema({'field1': 123})
    assert TestSchema.validate({'field1': 123, 'field2': 123}) == TestSchema({'field1': 123})
    assert TestSchema.validate({'field1': 123, 'field2': 123}, strict=True) == TestSchema({'field1': 123})
    assert Test

# Generated at 2022-06-12 15:57:00.818685
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    with pytest.raises(TypeError):
        assert (Schema()).__iter__()


# Generated at 2022-06-12 15:57:09.801165
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    foo1 = TestSchema(field1="foo")
    foo2 = TestSchema(field1="foo")
    assert foo1 == foo2
    assert foo1 != TestSchema(field1="bar")
    # One of the elements was not initialized
    notinitialized_schema = TestSchema(field1="foo")
    delattr(notinitialized_schema, "field2")
    assert foo1 != notinitialized_schema
    # The elements are not of the same type
    assert foo1 != TestSchema(field1=123)


# Generated at 2022-06-12 15:57:13.354940
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        prop_a = Field(type="string")
        prop_b = Field(type="integer")
        prop_c = Field(type="string")
    schema = MySchema(prop_a="hello")
    keys = [x for x in schema]
    assert keys == ["prop_a"]


# Generated at 2022-06-12 15:57:21.983039
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.base import String
    from typesystem.fields import Integer

    class FooSchema(Schema):
        foo = String()
        bar = Integer()
        baz = Integer(default=42)

    foo_schema = FooSchema()
    assert repr(foo_schema) == "FooSchema() [sparse]"

    foo_schema = FooSchema(foo="hello")
    assert repr(foo_schema) == 'FooSchema(foo="hello", baz=42)'

# Generated at 2022-06-12 15:57:27.269798
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Integer
    class Foo(Schema):
        field1 = Integer()

    assert isinstance(Foo.make_validator(), Object)
    assert isinstance(Foo.fields["field1"], Integer)
    assert Foo.fields["field1"].__name__ == "field1"


# Generated at 2022-06-12 15:57:35.894759
# Unit test for function set_definitions
def test_set_definitions():
    class A(Reference):
        to="B"
    class B(Reference):
        to="C"
    class C(Reference):
        to="D"
    class D(Reference):
        to="E"
    class E(Reference):
        to="F"
    class F(Reference):
        to="G"

    definitions=SchemaDefinitions()
    definitions["A"]=A
    definitions["B"]=B
    definitions["C"]=C
    definitions["D"]=D
    definitions["E"]=E
    definitions["F"]=F
    definitions["G"]=G
    set_definitions(G, definitions)
    assert definitions["A"].definitions is definitions
    assert definitions["B"].definitions is definitions
    assert definitions["C"].definitions is definitions
    assert definitions["D"].definitions

# Generated at 2022-06-12 15:57:41.844936
# Unit test for function set_definitions
def test_set_definitions():
    class ParentSchema(Schema):
        child = Reference("Child")

    definitions = SchemaDefinitions()

    class ChildSchema(Schema):
        pass

    assert getattr(ParentSchema.child, 'definitions') is None

    set_definitions(ParentSchema.child, definitions)
    assert ParentSchema.child.definitions == definitions


if __name__ == "__main__":
    import pytest

    pytest.main(__file__)

# Generated at 2022-06-12 15:57:47.482358
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from . import types
    assert repr(types.Person("John", age = 20)) == "Person(name='John', age=20)"
    assert repr(types.Person("John")) == "Person(name='John') [sparse]"
    assert repr(types.Person("John", age = None)) == "Person(name='John', age=None)"


# Generated at 2022-06-12 15:57:50.307121
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")
    schema1 = TestSchema()
    assert schema1.field1 == ""
    assert schema1.field2 == ""

    schema2 = TestSchema(field1="test")
    assert schema2.field1 == "test"
    assert schema2.field2 == ""


# Generated at 2022-06-12 16:00:12.242413
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields["name"] == String()
    assert Person.fields["age"] == Integer()

    definitions = SchemaDefinitions()
    class Person(Schema, definitions=definitions):
        name = String()
        age = Integer()

    assert definitions["Person"].fields["name"] == String()
    assert definitions["Person"].fields["age"] == Integer()

    class Person(Schema):
        name = String()

    class Supporter(Person):
        donations = Array(Integer())

    assert Supporter.fields["name"] == String()
    assert Supporter.fields["donations"] == Array(Integer())

    class Person(Schema):
        name: String

    assert Person.fields["name"] == String()
