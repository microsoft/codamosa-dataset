

# Generated at 2022-06-12 15:50:43.276792
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class DriverSchema(Schema):
        id = Field(uid=True)
        name = Field()

    driver_schema = DriverSchema(id=1, name="Naveen")

    assert len(driver_schema) == 2
    assert len(DriverSchema()) == 0


# Generated at 2022-06-12 15:50:48.276282
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class ExampleSchema(Schema):
        prop_a = String()
        prop_b = String()

    # Case 1
    schema = ExampleSchema(prop_b='value-b')
    print(schema)

    # Case 2
    schema = ExampleSchema(prop_a='value-a', prop_b='value-b')
    print(schema)



# Generated at 2022-06-12 15:50:49.768371
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.tests import DogSchema

    assert len(DogSchema({})) == 0



# Generated at 2022-06-12 15:51:00.101732
# Unit test for function set_definitions
def test_set_definitions():
    class Subclass1(Schema):
        a: Reference("Reference1")
        b: Reference("Reference2")
        c: Reference("Reference3")

        class Meta:
            strict = True

    class Subclass2(Subclass1):
        a: Reference("Reference4")
        b: Reference("Reference5")
        c: Reference("Reference6")

        class Meta:
            strict = True

    class Reference1(Schema):
        class Meta:
            strict = True

    class Reference2(Schema):
        class Meta:
            strict = True

    class Reference3(Schema):
        class Meta:
            strict = True

    class Reference4(Schema):
        class Meta:
            strict = True

    class Reference5(Schema):
        class Meta:
            strict = True


# Generated at 2022-06-12 15:51:03.657607
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Integer, String

    class User(Schema):
        id = Integer()
        username = String()

    user_class_fields = User.fields
    assert len(user_class_fields) == 2
    assert user_class_fields["id"] == Integer()
    assert user_class_fields["username"] == String()


# Generated at 2022-06-12 15:51:05.893001
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema({'a': 1}) == {'a': 1}
    assert Schema([1, 2, 3]) != [1, 2, 3]
    assert Schema(a=1) == {'a': 1}

# Generated at 2022-06-12 15:51:07.907685
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Boolean

    class ExampleSchema(Schema):
        enabled = Boolean(default=False)

    assert ExampleSchema.fields == {"enabled": Boolean(default=False)}
    assert ExampleSchema().enabled is False



# Generated at 2022-06-12 15:51:12.920921
# Unit test for constructor of class Schema
def test_Schema():
    assert issubclass(Schema, Mapping)
    assert issubclass(Schema, typing.Mapping)
    assert Schema.__init__
    assert Schema.__init__.__annotations__ == {'self': 'Schema', '*args': 'typing.Any', '**kwargs': 'typing.Any'}
    assert_arguments_equal(Schema, '__init__', arg_count=1, default_count=0)
    assert Schema.make_validator
    assert Schema.make_validator.__annotations__ == {'cls': 'Type[Schema]', '*': ('strict', bool)}
    assert_arguments_equal(Schema, 'make_validator', arg_count=0, default_count=1)
    assert Schema.validate
    assert Sche

# Generated at 2022-06-12 15:51:23.622814
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        foo = String()
        bar = Integer()
        baz = String()

    schema = TestSchema(foo=1, bar=2, baz=3)
    assert schema.__repr__() == 'TestSchema(foo=1, bar=2, baz=3)'
    assert repr(schema) == 'TestSchema(foo=1, bar=2, baz=3)'

    schema2 = TestSchema(foo=1, bar=2)
    assert schema2.__repr__() == 'TestSchema(foo=1, bar=2) [sparse]'
    assert repr(schema2) == 'TestSchema(foo=1, bar=2) [sparse]'

# Generated at 2022-06-12 15:51:24.587324
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass


# Generated at 2022-06-12 15:52:01.017357
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    a = Schema(name="", id="")
    assert len(a) == 2


# Generated at 2022-06-12 15:52:05.149014
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class MySchema(Schema):
        foo = Field(required=True)
        bar = Field(required=False)

    assert MySchema(foo=1, bar=2) == MySchema(foo=1, bar=2)
    assert MySchema(foo=1) == MySchema(foo=1)
    assert MySchema(foo=1) != MySchema(foo=2)
    assert MySchema(foo=1) != MySchema(foo=1, bar=2)


# Generated at 2022-06-12 15:52:11.059916
# Unit test for constructor of class Schema
def test_Schema():
    assert set(Schema.fields) == set(["test"])
    assert set(Schema().__dict__) == set(["test"])
    assert Schema(test="test") == Schema(test="test")
    assert Schema(test="test") != Schema(test="test1")
    assert Schema(test="test") != Schema()
    assert Schema(test="test") != 10
    assert Schema(test="test").test == "test"
    assert Schema(test="test")["test"] == "test"
    assert Schema(test="test").test == Schema(test="test")["test"]
    assert set(Schema(test="test")) == set(["test"])
    assert len(Schema(test="test")) == 1

# Generated at 2022-06-12 15:52:22.908843
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Test(Schema):
        class Meta:
            strict = True

        field1 = String()

    schema = Test(field1='str')
    assert len(schema) == 1
    assert len(dict(schema)) == 1
    assert dict(schema).get('field1') == 'str'

    # Test field with default
    class Test(Schema):
        class Meta:
            strict = False

        field1 = String(default="str")

    schema = Test()
    assert len(schema) == 0
    assert len(dict(schema)) == 0

    # Test field with default
    class Test(Schema):
        class Meta:
            strict = False

        field1 = String(default="str")
        field2 = Integer(default=1)

    schema = Test()
    assert len(schema)

# Generated at 2022-06-12 15:52:27.210664
# Unit test for function set_definitions
def test_set_definitions():

    fields = {
        "a": Reference("Person"),
        "b": Array(Reference("Person"))
    }

    definitions = SchemaDefinitions()

    for value in fields.values():
        set_definitions(value, definitions)

    assert isinstance(fields["a"].target, type)


# Generated at 2022-06-12 15:52:29.226859
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class BasicSchema(Schema):
        name = Field()

    schema = BasicSchema(name='John')
    print(repr(schema))



# Generated at 2022-06-12 15:52:31.501518
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class A(Schema):
        a = Field(Integer())
    assert A(a=1)['a'] == 1


# Generated at 2022-06-12 15:52:40.344336
# Unit test for constructor of class Reference
def test_Reference():
    assert_equals(Reference.__init__, '''def __init__(
        self,
        to: typing.Union[str, typing.Type[Schema]],
        definitions: typing.Mapping = None,
        **kwargs: typing.Any,
    ) -> None:
        super().__init__(**kwargs)
        self.to = to
        self.definitions = definitions
        if isinstance(to, str):
            self._target_string = to
        else:
            assert issubclass(to, Schema)
            self._target = to''')

# Generated at 2022-06-12 15:52:45.109909
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(metaclass=SchemaMetaclass):
        a = 1

    class B(A, metaclass=SchemaMetaclass):
        b = 2

    assert B.fields["a"] == 1
    assert B.fields["b"] == 2



# Generated at 2022-06-12 15:52:51.224950
# Unit test for function set_definitions
def test_set_definitions():
    class User(Schema):
        class Password(Schema):
            password = Reference("Hash")
            salt = Reference("Hash")

        password = Array(Reference("Password"), required=True)
        salt = Array(Reference("Hash"), required=False)

    class Hash(Schema):
        hash = Reference(User)

    defns = SchemaDefinitions()
    set_definitions(Hash, defns)
    print(defns)

# Generated at 2022-06-12 15:53:08.224593
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        name = String(max_length=255)

    assert repr(MySchema(name="foo")) == "MySchema(name='foo')"


# Generated at 2022-06-12 15:53:11.470751
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String
        age = Integer

    john = Person(name='John', age=10)
    joe = Person(name='Joe', age=10)
    assert john == john
    assert john != joe

# Generated at 2022-06-12 15:53:13.288438
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test case data
    SchemaClass1_testcase1 = Schema

    # Perform the test
    assert iter(SchemaClass1_testcase1) == {}

# Generated at 2022-06-12 15:53:14.825845
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Test(Schema):
        string = 'string field'
        number = 1
        integer = 2
        boolean = True
    assert len(Test()) == 3



# Generated at 2022-06-12 15:53:22.790183
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    def method():
        # Testing the SchemaMetaclass
        class Song(Schema):
            title = String(max_length=100)
            artist = String(max_length=100)
            composer = String(max_length=100)

        song = Song()
        print(Song.fields)
        print(song)
        print(list(song))
        print(len(song))
        print(song['title'])
        print(song['artist'])
        print(song['artist'] == '')
    
    method()

if __name__ == "__main__":
    test_SchemaMetaclass___new__()

# Generated at 2022-06-12 15:53:31.729726
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        a = Field(type="string")
        b = Field(type="string")

    assert Foo({"a": "A", "b": "B"}) == Foo(a="A", b="B") == Foo("A", "B")
    # Test that keyword arguments are overwritten
    assert Foo({"a": "A", "b": "B"}, b="C") == Foo("A", b="C")
    # Test that the class is initialized with the first positional argument
    assert Foo("A") == Foo("A", "B")
    # Test that the first positional argument cannot be a keyword argument
    try:
        Foo("a")
    except TypeError as e:
        assert str(e) == "a is an invalid keyword argument for Foo()."

# Generated at 2022-06-12 15:53:42.918766
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import String, Integer, Number
    class UserSchema(Schema):
        name = String(max_length=10)
    user = UserSchema(name='Bob')
    user2 = UserSchema(name='Bob')
    user3 = UserSchema(name='Alice')
    user4 = UserSchema(name='Bob', age=15)
    user5 = UserSchema(name='Bob', age=15)
    user6 = UserSchema(name='Bob', age=13)
    assert user == user2
    assert user != user3
    assert user != user4
    assert user4 == user5
    assert user5 != user6


# Generated at 2022-06-12 15:53:50.070335
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Import needed modules
    from typesystem.base import Any, String
    class A(Schema):
        b = String()
        c = String()
        d = String()

    a1 = A(b="hello", d="bye")
    a2 = A(b="hello", c="hello")
    a3 = A(b="hello", c="hello", d="bye")
    assert list(a1) == ['b', 'd'], "List of keys incorrect for a1"
    assert list(a2) == ['b', 'c'], "List of keys incorrect for a2"
    assert list(a3) == ['b', 'c', 'd'], "List of keys incorrect for a3"

    a4 = A()
    assert list(a4) == [], "List of keys incorrect for a4"


# Generated at 2022-06-12 15:53:55.895991
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        price = Field(type=int)
        name = Field(type=str)
    test_schema = TestSchema(price=1, name='Ryu')
    assert set(test_schema) == {'price', 'name'}
    assert len(test_schema) == 2

# Generated at 2022-06-12 15:54:00.468023
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import String, Integer

    class Person(Schema):
        name = String()
        age = Integer(minimum=1)

    field = Person.fields["name"]
    assert field.__class__.__name__ == 'String'
    field = Person.fields["age"]
    assert field.__class__.__name__ == 'Integer'


# Generated at 2022-06-12 15:55:25.056967
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = 1
    assert A() == A()
    a = A()
    b = A()
    assert a is not b
    assert a == b
    assert a == dict(a=1)
    assert dict(a=1) == a
    assert a == {"a":1}
    assert {"a":1} == a
    assert A().__repr__() == "A(a=1)"
    class B(Schema):
        b = 2
        a = 1
    assert B() == B()
    b = B()
    c = B()
    assert b is not c
    assert b == c



# Generated at 2022-06-12 15:55:34.833807
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    logging.info(__name__ + "." + test_Schema___iter__.__name__)
    logging.info(Schema.__iter__.__doc__)
    class SchemaTest(Schema):
        name = String()
        title = String()
        age = Integer(description="The age of the person", default=18)
    
    schema = SchemaTest()
    logging.info(f"class SchemaTest: {schema}")
    
    for key in schema:
        logging.info(key)
    logging.info(json.dumps(dict(schema), indent=4, sort_keys=True))
        

#unit test for method __repr__ of class Schema

# Generated at 2022-06-12 15:55:36.714286
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    s = Schema(a=True, b=1)
    assert len(s) == 2


# Generated at 2022-06-12 15:55:38.085051
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    assert len(schema) == 0


# Generated at 2022-06-12 15:55:44.134217
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Schema

    class Item(Schema):
        name = str
        quantity = int

    item = Item(name="bacon", quantity=3)
    it = iter(item)
    assert next(it) == "name"
    assert next(it) == "quantity"
    try:
        next(it)
    except StopIteration:
        pass
    else:
        assert False, "iterator should have raised a StopIteration"



# Generated at 2022-06-12 15:55:48.185385
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class _TestSchema(Schema):  # noqa: N810
        id = Field()
        name = Field()
    schema = _TestSchema(id=1, name='user')
    res = list(schema.__iter__())
    assert res == ['id', 'name']
    assert type(res) is list


# Generated at 2022-06-12 15:55:59.686425
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(title='The name of the person')
        age = Integer(title='The age of the person')
        # weight = Float(title='The weight of the person')

    class Employee(Person):
        employee_number = Integer(title='The employee number')

    class Developer(Employee):
        developer_id = Integer(title='The developer id')
        speciality = String(title='The speciality')

    a = Developer(
        name = 'test1',
        age = 28,
        employee_number = 1,
        developer_id = 10,
        speciality = 'Python'
    )

    assert a.name == 'test1'
    assert a.age == 28
    assert a.employee_number == 1
    assert a.developer_id == 10

# Generated at 2022-06-12 15:56:05.386724
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Simple test cases
    obj = Schema(properties = {}, fields = {})
    it = obj.__iter__()
    obj = Schema(value = {}, dict = {})
    it = obj.__iter__()
    obj = Schema(value = object, dict = object)
    it = obj.__iter__()
    obj = Schema(value = {}, dict = {})
    it = obj.__iter__()
    


# Generated at 2022-06-12 15:56:17.856582
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        definition_a = String()
        definition_b = String()

    class Inner(Schema):
        inner_field = String()

    class B(Schema):
        ref = Reference(definitions=SchemaDefinitions(), to=Inner)

    class C(Schema):
        array_ref = Array(items=Reference(definitions=SchemaDefinitions(), to=Inner))

    class D(Schema):
        object_ref = Field(
            properties={
                "object_ref_field": Reference(
                    definitions=SchemaDefinitions(), to=Inner
                )
            },
            required=["object_ref_field"],
        )

    assert B.fields["ref"].definitions is None
    assert C.fields["array_ref"].items.definitions is None
    assert D

# Generated at 2022-06-12 15:56:18.678656
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert True, "Not yet implemented"


# Generated at 2022-06-12 15:57:58.264901
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Metaclass(type):
        def __new__(
            metacls: type,
            name: str,
            bases: typing.Sequence[type],
            attrs: dict,
            *args: typing.Any,
            **kwargs: typing.Any,
        ) -> type:
            new_type = super(Metaclass, metacls).__new__(metacls, name, bases, attrs)
            return new_type

    class NewType(metaclass=Metaclass):
        pass

    result = NewType()
    assert isinstance(result, NewType)


# Test the SchemaMetaclass class constructor

# Generated at 2022-06-12 15:58:09.126897
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        name = String(max_length=100)
        value = Float()

    ts1 = TestSchema(name='name', value=1.0)
    ts1_r = "TestSchema(name='name', value=1.0)"
    assert(repr(ts1) == ts1_r)

    ts2 = TestSchema(name='name')
    ts2_r = "TestSchema(name='name') [sparse]"
    assert(repr(ts2) == ts2_r)

    ts3 = TestSchema()
    ts3_r = "TestSchema() [sparse]"
    assert(repr(ts3) == ts3_r)



# Generated at 2022-06-12 15:58:13.948034
# Unit test for function set_definitions
def test_set_definitions():
    class Address(Schema):
        street = Field()
        city = Field()
        state = Field()
        zipcode = Field()

    class User(Schema):
        name = Field()
        password = Field()
        address = Reference(Address)

    definitions = SchemaDefinitions()

    # Set SchemaDefinitions
    set_definitions(User, definitions)

    # Should not raise an error
    pass

# Generated at 2022-06-12 15:58:15.562237
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    pass


# Generated at 2022-06-12 15:58:24.149463
# Unit test for function set_definitions
def test_set_definitions():
    class Dummy:
        pass

    definitions = SchemaDefinitions()
    # test for Reference
    field = Reference("definition")
    set_definitions(field, definitions)
    assert field.definitions == definitions

    # test for Array
    field = Array()
    set_definitions(field, definitions)
    assert field.definitions == definitions
    field = Array(items=Dummy())
    set_definitions(field, definitions)
    assert field.items.definitions == definitions
    field = Array(items=[Dummy(), Dummy()])
    set_definitions(field, definitions)
    assert field.items[0].definitions == definitions
    assert field.items[1].definitions == definitions

    # test for Object
    class Test(Schema):
        dummy = Dummy()

    field = Test()
    set_

# Generated at 2022-06-12 15:58:34.303989
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.object import Object

    class FooSchema(Schema):
        bar = Object(properties={"hello": {"type": "string"}})
        baz = Object(properties={"world": {"type": "string"}})
        qux = Object(
            properties={"stuff": {"type": "string"}, "things": {"type": "string"}}
        )
        abc = Object(
            properties={"stuff": {"type": "string"}, "things": {"type": "string"}}
        )

        class Meta:
            strict = False

    foo = FooSchema({"bar": {"hello": "world"}})
    assert repr(foo) == "FooSchema(bar={'hello': 'world'})"

    foo = FooSchema({"baz": {"world": "hello"}})

# Generated at 2022-06-12 15:58:36.955983
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    a = Schema({"a": 1, "b": 2})
    a["a"]
    a["b"]

    def f():
        nonlocal a
        a["c"]

    # Check the exception thrown by a["c"]
    try:
        f()
    except KeyError as e:
        assert e.args == ("c",)
    else:
        assert False



# Generated at 2022-06-12 15:58:41.045065
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=50)
        age = Integer()
    p = Person(name="Alex",age=32)
    print(p)

if __name__ == '__main__':
    test_Schema()

# Generated at 2022-06-12 15:58:43.866080
# Unit test for function set_definitions
def test_set_definitions():
    d = SchemaDefinitions()
    class MySchema(Schema):
        a = Array(Reference('OtherSchema'))
    assert d['OtherSchema'].fields['a'] == MySchema.fields['a']

# Generated at 2022-06-12 15:58:45.825684
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    a = Schema.validate({"a": 1, "b": 2})
    assert list(a) == ["a", "b"]


# Generated at 2022-06-12 15:59:36.808831
# Unit test for constructor of class Schema
def test_Schema():
    assert isinstance(Schema(), Mapping)
    assert Schema({}) == Schema()
    assert Schema({}) == Schema({})


# Generated at 2022-06-12 15:59:42.476824
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Integer, String
    from typing import Any, Dict
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name='Foo', age=99)
    expected_result = {'name', 'age'}
    result = set(person.__iter__())
    assert result == expected_result


# Generated at 2022-06-12 15:59:44.091596
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert issubclass(Schema, Mapping)


# Generated at 2022-06-12 15:59:48.298528
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import Integer, String

    class Person(Schema):
        age = Integer()
        name = String()

    assert Person.fields == {"age": Integer(), "name": String()}


# Generated at 2022-06-12 15:59:55.134004
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.typing import String, Number

    class MySchema(Schema):
        name = String()
        age = Number()

    schema = MySchema(name="Jorge", age=30)
    assert schema["name"] == "Jorge"
    assert schema["age"] == 30

    schema = MySchema(name="Jorge")
    assert schema["name"] == "Jorge"

    schema = MySchema()
    assert not schema.is_sparse
    assert not hasattr(schema, "name")
    assert schema.get("name", "not set") == "not set"


# Generated at 2022-06-12 16:00:03.922308
# Unit test for constructor of class Schema
def test_Schema():
    class S(Schema):
        foo = Field()

    try:
        S()
    except TypeError:
        assert True
    else:
        assert False, "Expected TypeError"
    try:
        S({"foo": 1, "extra": 2})
    except TypeError:
        assert True
    else:
        assert False, "Expected TypeError"
    try:
        S({"foo": 1}, foo=2)
    except TypeError:
        assert True
    else:
        assert False, "Expected TypeError"
    try:
        S(None)
    except TypeError:
        assert True
    else:
        assert False, "Expected TypeError"
    try:
        S({"foo": True})
    except TypeError:
        assert True

# Generated at 2022-06-12 16:00:10.016959
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    definitions = SchemaDefinitions()
    class BoringSchema(Schema, definitions=definitions):
        pass

    assert definitions == {}

    class MoreInterestingSchema(Schema, definitions=definitions):
        foo = Field()

    assert len(definitions) == 2
    assert definitions["BoringSchema"] is BoringSchema
    assert definitions["MoreInterestingSchema"] is MoreInterestingSchema
