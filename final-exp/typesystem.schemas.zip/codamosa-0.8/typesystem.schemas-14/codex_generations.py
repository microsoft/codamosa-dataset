

# Generated at 2022-06-12 15:50:39.305172
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import json
    import pathlib

    class Person(Schema):
        name = String(max_length=200)
        age = Integer(minimum=18, maximum=99)

    class Book(Schema):
        title = String(max_length=200)
        author = Reference(Person)

    definitions = {
        "Book": Book
    }

    def test_schema(value: dict) -> typing.Any:
        schema = definitions.get(value["$schema"])
        assert schema is not None
        return schema.validate(value)

    assert test_schema({"$schema": "Book", "title": "The Name of the Rose"}) == Book(title="The Name of the Rose")

# Generated at 2022-06-12 15:50:43.453905
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Country(Schema):
        code = String()

    assert Country.fields["code"].name == "code"
    assert Country.fields["code"].type == "string"


# Generated at 2022-06-12 15:50:45.228417
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema({})) == 0
    assert len(Schema({"a": 1})) == 1


# Generated at 2022-06-12 15:50:52.157253
# Unit test for constructor of class Schema
def test_Schema():

    assert Schema(id=5, name="Hello World") == Schema(id=5, name="Hello World")
    assert len(Schema(id=5, name="Hello World")) == 2
    assert "id" in Schema(id=5, name="Hello World")
    assert "name" in Schema(id=5, name="Hello World")
    assert Schema(id=5, name="Hello World") == Schema.validate({"id": 5, "name": "Hello World"})
    assert Schema.validate({"id": 5, "name": "Hello World"}) == Schema.validate({"id": 5, "name": "Hello World"})



# Generated at 2022-06-12 15:50:54.108563
# Unit test for method validate of class Reference
def test_Reference_validate():
    # TODO
    pass

# Generated at 2022-06-12 15:50:58.117128
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        f1 = Field()
        f2 = Field()
        f3 = Field()
        f4 = Field()

    schema = TestSchema(f1=1, f2=2)
    result = list(schema)

    assert result == ["f1", "f2"]



# Generated at 2022-06-12 15:51:05.505594
# Unit test for constructor of class Schema
def test_Schema():
    sut = Schema(field1="value", field2="value")
    assert sut.field1 == "value"
    assert sut.field2 == "value"
    sut = Schema({"field1": "value", "field2": "value"})
    assert sut.field1 == "value"
    assert sut.field2 == "value"
    sut = Schema(field1="value")
    assert sut.field1 == "value"
    assert sut.field2 == ""
    sut = Schema({"field1": "value"})
    assert sut.field1 == "value"
    assert sut.field2 == ""
    sut = Schema(obj={"field1": "value", "field2": "value"})
    assert sut.field1 == "value"


# Generated at 2022-06-12 15:51:08.373406
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class PersonSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    alice = PersonSchema(name="Alice", age=25)
    assert len(alice) == 2
    assert sorted(alice) == ["age", "name"]


# Generated at 2022-06-12 15:51:19.768483
# Unit test for constructor of class Schema
def test_Schema():
    class SubSchema(Schema):
        foo = Field()

    d = {"foo": 1}
    sub = SubSchema(d)
    assert isinstance(sub, SubSchema)
    assert sub["foo"] == 1

    # Test sub class of Schema
    class SubSubSchema(SubSchema):
        bar = Field()

    sub2 = SubSubSchema(d)
    assert isinstance(sub2, SubSubSchema)
    assert sub2["foo"] == 1
    assert sub2["bar"] == None

    # Test properties
    sub.foo = 1
    sub.bar = 2
    assert sub.foo == 1
    assert sub.bar == 2
    assert sub.is_sparse == True
    assert sub2.is_sparse == False

    # Test validate
    SubSchema.validate

# Generated at 2022-06-12 15:51:29.134909
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    '''
    this is a test case for the method __getitem__ of class Schema.
    '''
    class Author(Schema):
        '''
        this is a class Author
        '''
        fields = {
            "name": String(max_length=200),
            "birth_date": Date(),
            "age": Integer(min_value=0)
        }
    author = Author(name="F. Scott Fitzgerald", birth_date="1896-09-24", age=44)
    assert author.__getitem__("name") == "F. Scott Fitzgerald"
    assert author.__getitem__("birth_date") == "1896-09-24"
    assert author.__getitem__("age") == 44

# Generated at 2022-06-12 15:51:41.738682
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = {'foo': 1, 'bar': 2}
    assert set(schema.keys()) == set(Schema(schema).__iter__())


# Generated at 2022-06-12 15:51:42.457251
# Unit test for function set_definitions
def test_set_definitions():
    pass

# Generated at 2022-06-12 15:51:49.817089
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import unittest
    from typesystem.types import String
    
    class A(Schema):
      a = String()
    
    class B(Schema):
      a = String()
      
    a1 = A(a="1")
    a2 = A(a="2")
    b1 = B(a="1")
    
    assert a1 == a1
    assert a1 != a2
    assert a1 != b1
    assert b1 != a1



# Generated at 2022-06-12 15:51:58.086911
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = "something"

    set_definitions(A.fields['a'], definitions)
    set_definitions(B.fields['b'], definitions)
    set_definitions(C.fields['c'], definitions)
    assert definitions['A'] == A
    assert definitions['B'] == B
    assert definitions['C'] == C

# Generated at 2022-06-12 15:52:05.317956
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        field1 = Reference("A")
        field2 = Reference("B")

    definitions = SchemaDefinitions()
    set_definitions(MySchema.field1, definitions)
    set_definitions(MySchema.field2, definitions)

    assert definitions['MySchema'] == MySchema
    assert definitions['A'] is None
    assert definitions['B'] is None

# Generated at 2022-06-12 15:52:16.359590
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    fields = {
        "foo": Reference("Foo"),
        "bar": Object(
            properties={
                "a": Array(String()),
                "b": Array(Reference("Foo")),
                "c": Array(
                    Object(
                        properties={
                            "foo": Reference("Foo"),
                            "bar": Array(Reference("Foo")),
                        }
                    )
                ),
            }
        ),
    }
    for f in fields.values():
        set_definitions(f, definitions)

    assert hasattr(fields["foo"], "definitions")
    assert hasattr(fields["bar"], "definitions")
    assert hasattr(fields["bar"].properties["a"], "definitions")

# Generated at 2022-06-12 15:52:20.179595
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name='John', age=31)
    assert p.__repr__() == "Person(name='John', age=31)"

# Generated at 2022-06-12 15:52:24.555920
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        a = Integer()
        b = Integer()
        def __init__(self):
            super().__init__({'a': 1, 'b': 2})

    my_schema = MySchema()
    assert [i for i in my_schema] == ['a', 'b']



# Generated at 2022-06-12 15:52:30.787152
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # test_schema_argument_order
    class Child(Schema):
        name = String(max_length=80)

    class Person(Schema):
        name = String(max_length=80)
        age = Integer(minimum=0)
        child = Reference("Child")

    person_validator = Person.make_validator()
    person_instance = Person(
        name="Guido", age=56, child=Child(name="Van Rossum"))

    assert person_validator.validate(person_instance) == person_instance
    class Child(Schema):
        name = String(max_length=80)

    class Person(Schema):
        age = Integer(minimum=0)
        name = String(max_length=80)
        child = Reference("Child")

    person_validator = Person.make_

# Generated at 2022-06-12 15:52:42.129863
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import typesystem
    import pytest
    import json

    # Test example from the documentation of class Schema
    class Person(Schema):
        name = typesystem.String(max_length=100)
        age = typesystem.Integer(minimum=0, exclusive_maximum=150)

    person = Person({
        "name": "John Smith",
        "age": "45",
    })
    assert person.name == "John Smith"
    assert person.age == 45
    assert json.dumps(person) == '{"name": "John Smith", "age": 45}'

    # Test example from the documentation of class Reference
    definitions = SchemaDefinitions()
    class InnerPerson(Schema):
        class Meta:
            definitions = definitions
        name = typesystem.String(max_length=100)
        age = typesystem.Integer

# Generated at 2022-06-12 15:52:53.211610
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class CustomerSchema(Schema):
        name = String(required=True)
        age = Integer()

    customer = CustomerSchema(name="John")

    keys = []
    for key in customer:
        keys.append(key)
    assert keys == ["name"]

# Generated at 2022-06-12 15:52:58.708609
# Unit test for constructor of class Reference
def test_Reference():
    class User(Schema):
        email = String(format="email")
        is_active = Boolean()
    def1 = SchemaDefinitions()
    test = Reference("User", definitions=def1)
    assert test.to == "User"
    assert test.definitions == def1
    test.to = User
    assert test.to == User
    assert test.definitions == def1


# Generated at 2022-06-12 15:53:01.348777
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert all(hasattr(Schema, name) for name in Schema.__dict__)



# Generated at 2022-06-12 15:53:06.648516
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import String
    class StringWithEnum(String):
        enum = ["foo", "bar", "baz"]
    class TestSchema(Schema):
        foo = StringWithEnum(default="bar")
    schema = TestSchema()
    assert schema["foo"] == "bar"


# Generated at 2022-06-12 15:53:12.511676
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Location(Schema):
        latitude = Field(required=True)
        longitude = Field(required=True)
        altitude = Field()

    class GeoLocation(Schema):
        location = Reference(Location)

    geoLocation= GeoLocation({
    "location": {
        "latitude": 42.45,
        "longitude": 51.12,
        "altitude": 12
        }
    })
    assert len(geoLocation)==1
    assert len(geoLocation.location)==3



# Generated at 2022-06-12 15:53:18.342725
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class BaseSchema(Schema):
        pass

    class A(BaseSchema):
        a = Integer()

    class B(BaseSchema):
        b = Integer()

    class C(A):
        c = Integer()

    class D(C):
        d = Integer()

    classes = [A, B, C, D]
    for cls in classes:
        for key in cls.fields.keys():
            assert hasattr(cls, key)

    for cls in classes:
        assert isinstance(cls.fields, Mapping)

    for base_cls in classes:
        for base_key in base_cls.fields.keys():
            for cls in classes:
                if cls is not base_cls:
                    assert base_key not in cls.fields


# Generated at 2022-06-12 15:53:24.971034
# Unit test for method validate of class Reference
def test_Reference_validate():
    # initialization
    ref = Reference("target")
    assert ref.to == "target"
    assert ref.definitions == None
    assert ref.allow_null == False
    assert ref.required == True
    assert ref.extra == {}

    # with None, ref.allow_null == false
    try:
        ref.validate(None)
    except ValidationError as error:
        assert error.code == "null"
        assert error.field == ref
        assert error.data == None

    # with None, ref.allow_null == true
    ref.allow_null = True
    assert ref.validate(None) == None

    # check the form of validation_error
    class_name = ref.__class__.__name__
    message = ref.errors["null"]

# Generated at 2022-06-12 15:53:29.070978
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field_one = Field()
        field_two = Field()

    schema = TestSchema(field_one="value one", field_two="value two")
    assert len(schema) == 2
    assert len(schema) == 2


# Generated at 2022-06-12 15:53:31.336967
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    assert "name" in Person.fields
    assert "age" in Person.fields

# Generated at 2022-06-12 15:53:37.772450
# Unit test for constructor of class Schema
def test_Schema():
    class MySchema1(Schema):
        a = Field()
        b = Field()
    s1 = MySchema1({"a": 123, "b": 456}, b=789)
    assert(s1.a == 123)
    assert(s1.b == 456)

    s2 = MySchema1({"a": 123})
    assert(s2.a == 123)
    assert(s2.b == None)
    with pytest.raises(TypeError):
        s2 = MySchema1({"a": 123}, c=123)
        s3 = MySchema1({"a": 123}, d=123)
    s4 = MySchema1()
    assert(s4.a == None)
    assert(s4.b == None)


# Generated at 2022-06-12 15:53:48.251341
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass


# Generated at 2022-06-12 15:54:00.088066
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    a = Reference('a', definitions=definitions)
    a_ = {'type': 'reference', 'to': 'a'}
    b = Reference('b', definitions=definitions)
    b_ = {'type': 'reference', 'to': 'b'}
    assert a == a_
    assert b == b_
    assert definitions == {}
    try:
        set_definitions(a, definitions)
        assert False
    except AssertionError:
        pass
    try:
        set_definitions(b, definitions)
        assert False
    except AssertionError:
        pass

    class Foo(Schema):
        a = a
        b = b

    set_definitions(a, definitions)
    assert definitions == {'Foo': Foo}
    set_definitions

# Generated at 2022-06-12 15:54:06.524110
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Equality of a Schema is tested for all its fields
    assert Schema(a=1, b=2) == Schema(a=1, b=2)
    assert Schema(a=1, b=2) != Schema(a=1, b=3)
    assert Schema(a=1, b=4) != Schema(a=1, b=2)
    assert Schema(a=5, b=2) != Schema(a=1, b=2)
    assert Schema(a=1, b=2) != Schema(a=1, b=2, c=3)
    assert Schema(a=1, b=2) != 1

# Generated at 2022-06-12 15:54:10.517619
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema({})) == "Schema()"
    assert repr(Schema({}, name=1)) == "Schema(name=1)"
    assert repr(Schema({}, name=1, age=2)) == "Schema(age=2, name=1)"


# Generated at 2022-06-12 15:54:11.076043
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass

# Generated at 2022-06-12 15:54:16.514637
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    """
    Test for the method __repr__ of the class Schema
    """
    # Arrange

    # Act
    test = Schema(
        "testing",
        bool=True,
        number=2,
        string="Three",
        none=None,
        mapping={},
        sequence=[],
    )
    output = repr(test)

    # Assert
    assert output == (
        "Schema(bool=True, number=2, string='Three', none=None, mapping={}, "
        "sequence=[])"
    )



# Generated at 2022-06-12 15:54:22.057051
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import String, Integer

    class Human(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    human1 = Human(age=1, name='a')
    human2 = Human(age=1, name='a')
    assert(human1 == human2)



# Generated at 2022-06-12 15:54:27.903893
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import Schema, Object
    class Person(Schema):
        first_name = Object(properties={'first': Object(object)})
        last_name = Object(properties={'last': Object(object)})
    assert Person(first_name={'first': 'John'}, last_name={'last': 'Doe'}).__repr__() == 'Person(first_name={\'first\': \'John\'}, last_name={\'last\': \'Doe\'})'

# Generated at 2022-06-12 15:54:30.572313
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    field = Field(type = str, max_length = 100)
    fields = {"a_field": field}
    
    class TestSchema(Schema, metaclass = SchemaMetaclass):
        fields = fields

    schema = TestSchema()
    assert [key for key in schema] == []


# Generated at 2022-06-12 15:54:32.521600
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class FooBar(Schema):
        foo = Field(String())
        bar = Field(Integer())
    assert FooBar(foo="1", bar=1) == FooBar(foo="1", bar=1)


# Generated at 2022-06-12 15:54:50.702431
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Array(items=String())
        b = String(default="b")
        c = String()
    definitions = SchemaDefinitions()
    schema = A(a=["a1", "a2"], c="c")
    assert schema == A({"a": ["a1", "a2"], "c": "c"})
    assert schema == A(a=["a1", "a2"], c="c")
    schema = A({"a": ["a1", "a2"], "c": "c"})
    assert schema == A({"a": ["a1", "a2"], "c": "c"})
    assert schema == A(a=["a1", "a2"], c="c")
    assert schema.b == "b"
    assert schema.is_sparse is False

# Generated at 2022-06-12 15:54:51.251283
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema()) == 0



# Generated at 2022-06-12 15:54:58.126166
# Unit test for function set_definitions
def test_set_definitions():
    class InnerSchema(Schema):
        foo = Reference("FooSchema")

    class OuterSchema(Schema):
        inner = InnerSchema.make_validator()
    definitions = SchemaDefinitions(FooSchema=InnerSchema)
    set_definitions(OuterSchema.make_validator(), definitions)
    assert OuterSchema.make_validator().properties["inner"].properties["foo"].definitions == definitions

# Generated at 2022-06-12 15:55:02.441253
# Unit test for function set_definitions
def test_set_definitions():
    something = Object(properties={"foo": Reference("bar")})
    definitions = SchemaDefinitions({"bar": Array(items=String())})

    set_definitions(something, definitions)
    assert something["foo"].definitions is definitions

# Generated at 2022-06-12 15:55:08.504579
# Unit test for function set_definitions
def test_set_definitions():
    class Foo:
        pass

    foo = Foo()
    foo.bar = "bar"
    foo.baz = "baz"

    class Definitions(Schema):
        bar = Reference("Foo")

    definitions = SchemaDefinitions()
    definitions["Foo"] = foo
    set_definitions(definitions, definitions)
    assert definitions["Foo"] is foo
    assert definitions["Foo"].bar == "bar"
    assert definitions["Foo"].baz == "baz"

# Generated at 2022-06-12 15:55:12.666464
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    print("Test test_Schema___iter__")

    class MySchema(Schema):
        id = Field(type="integer")
        name = Field(type="string")
        price = Field(type="number")

    valid_schema = MySchema(id=123, name="A", price=123.45)
    for item in valid_schema:
        print(item)


# Generated at 2022-06-12 15:55:16.308105
# Unit test for function set_definitions
def test_set_definitions():
    class Schema1(Schema):
        pass

    schema1 = Schema1()
    definitions = SchemaDefinitions()
    set_definitions(schema1, definitions)
    assert definitions["Schema1"] == Schema1
    assert "Schema1" in definitions

    # Test coverage for recursion
    class Schema2(Schema):
        class_field = {"field": schema1}

    schema2 = Schema2()
    set_definitions(schema2, definitions)
    assert definitions["Schema1"] == Schema1

# Generated at 2022-06-12 15:55:19.070364
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        foo = Field(required=True, null=False)


    TestSchema({"foo": 1})
    TestSchema(foo=1)



# Generated at 2022-06-12 15:55:23.391980
# Unit test for constructor of class Schema
def test_Schema():
    try:
        Schema()
    except Exception as e:
        if isinstance(e, TypeError):
            print("Schema() : TypeError")
        if isinstance(e, KeyError):
            print("Schema() : KeyError")
    else:
        print("Schema() : no exceptions")


# Generated at 2022-06-12 15:55:25.101607
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass



# Generated at 2022-06-12 15:55:36.625093
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test for valid inputs
    definition = {"id": 1, "name": "testName"}
    schema = Schema(definition)
    len(schema)


# Generated at 2022-06-12 15:55:46.340519
# Unit test for constructor of class Schema
def test_Schema():
    class Movie(Schema):
        title = Field(str)
        year = Field(int)
        director = Reference(Person)
        writers = Field(Array(Reference(Person)))

    class Person(Schema):
        name = Field(str)
        birth_year = Field(int)

    movie = Movie(
        {
            "title": "The Matrix",
            "year": 1999,
            "director": {"name": "Lana Wachowsky", "birth_year": 1965},
            "writers": [
                {"name": "Lana Wachowsky", "birth_year": 1965},
                {"name": "Lilly Wachowsky", "birth_year": 1967},
            ],
        }
    )

# Generated at 2022-06-12 15:55:49.303263
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(primitive_type=int)
        b = Field(primitive_type=str)
    ts = TestSchema({'a': 5, 'b': 'hello'})
    if (ts.a != 5) or (ts.b != 'hello'):
        raise Exception("Invalid test case")



# Generated at 2022-06-12 15:55:52.728293
# Unit test for function set_definitions
def test_set_definitions():
    class Author(Schema):
        name = String(max_length=255)

    class Comment(Schema):
        author = Reference(Author)

    definitions = SchemaDefinitions()
    set_definitions(Comment.fields["author"], definitions)
    assert Author.__name__ in definitions
    assert issubclass(definitions[Author.__name__], Schema)

# Generated at 2022-06-12 15:56:01.053125
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    definitions = SchemaDefinitions()
    class MySchema(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        def __init__(self, one, two, three) -> None:
            self.one = one
            self.two = two
            self.three = three

    assert MySchema.fields == {"one": None, "two": None, "three": None}
    print(MySchema(1, 2, 3))



# Generated at 2022-06-12 15:56:08.565819
# Unit test for function set_definitions
def test_set_definitions():
    m = {'name': 'bob', 'age': 40}
    s = {}
    set_definitions(Object(properties=m), s)
    assert 'name' in s.keys()
    assert 'age' in s.keys()
    assert isinstance(s['name'], Field)
    assert isinstance(s['age'], Field)
    assert s['name'].type == 'string'
    assert s['age'].type == 'number'
    assert s['name'].name == 'name'
    assert s['age'].name == 'age'
    assert s['name'].parents == {}
    assert s['age'].parents == {}

    m = {'age': Array(min_items=1, items=Integer())}
    s = {}
    set_definitions(Object(properties=m), s)

# Generated at 2022-06-12 15:56:11.008844
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Schema, String, Reference


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 15:56:14.478580
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        id = Field(Integer())
        name = Field(String())
    schema = TestSchema(dict(id=1, name='abc'))
    print(schema.__iter__())


# Generated at 2022-06-12 15:56:19.622400
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class MySchema(Schema):
        a = String(min_length=5)
        b = Integer(minimum=1)
        c = Boolean()

    schema = MySchema(a="hello", b=2)
    assert schema["a"] == "hello"
    assert schema["c"] is False
    with pytest.raises(KeyError):
        schema["d"]

# Generated at 2022-06-12 15:56:20.132635
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    pass


# Generated at 2022-06-12 15:56:47.452273
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Model(Schema):
        id = Reference('Model')
    obj = {id: 1}
    assert(Model.validate(obj) == Model(id=1))


# Generated at 2022-06-12 15:56:58.460472
# Unit test for constructor of class Schema
def test_Schema():
    #from django.conf import settings
    from typesystem.fields import String, DateTime
    from datetime import datetime

    class Commit(Schema):
        class Meta:
            strict = True

        sha = String()
        date = DateTime()
        author = String()


    if __name__ == "__main__":
        import sys

        # Create an instance of Commit
        commit = Commit(sha="8a4f306", date=datetime(2017, 9, 5, 10, 40, 0), author="John Doe")

        # Create an instance of Commit from a dictionary
        commit = Commit({"sha": "8a4f306"})

        # Create an instance of Commit from a dictionary with a wrong field

# Generated at 2022-06-12 15:57:01.154251
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    obj = MySchema(a=1, b=2)
    d = dict(obj)
    assert sorted(d.keys()) == ["a", "b"]


# Generated at 2022-06-12 15:57:06.517008
# Unit test for function set_definitions
def test_set_definitions():
    class Bar(Schema):
        bar = Field()

    class Foo(Schema):
        foo = Reference(to="Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields, definitions)
    assert definitions == {
        "Bar": Bar
    }


# Generated at 2022-06-12 15:57:07.998655
# Unit test for constructor of class Reference
def test_Reference():
    with pytest.raises(TypeError) as excinfo:
        Reference(to=str)
    assert excinfo.match("missing 'definitions'")

# Generated at 2022-06-12 15:57:11.572367
# Unit test for constructor of class Reference
def test_Reference():
    schema = {"$ref": "#/definitions/Comment"}
    reference = Reference("Comment", definitions=schema)
    assert reference.to == "Comment"
    assert reference.errors == {"null": "May not be null."}
    assert reference.target == schema['$ref']


# Generated at 2022-06-12 15:57:14.417967
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    fields = {
        'field1': Field(),
        'field2': Field(),
    }
    class TestSchema(Schema):
        fields = fields
    __target__ = TestSchema()
    # __result__ should be an instance of set().
    __result__ = {field for field in __target__}
    assert set(__result__) == set()



# Generated at 2022-06-12 15:57:27.367032
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class BaseSchema:
        pass
    class SchemaA(BaseSchema, metaclass=SchemaMetaclass):
        field_a = Field()
        field_b = Field()
    class SchemaB(SchemaA, metaclass=SchemaMetaclass):
        field_b = Field()
        field_c = Field()
    class SchemaC(SchemaA, SchemaB, metaclass=SchemaMetaclass):
        field_c = Field()
        field_d = Field()
    assert SchemaC.fields == {
        'field_a': SchemaC.field_a,
        'field_b': SchemaB.field_b,
        'field_c': SchemaC.field_c,
        'field_d': SchemaC.field_d,
    }



# Generated at 2022-06-12 15:57:32.780508
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class Foo(Schema):
        foo = Field()

    foo = Array(Reference("Foo"))
    set_definitions(foo, definitions)
    assert foo.items.definitions is definitions

    foo = Object({"foo": Reference("Foo")})
    set_definitions(foo, definitions)
    assert foo.properties["foo"].definitions is definitions


# Unit tests for class SchemaMetaclass

# Generated at 2022-06-12 15:57:44.517439
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from .models import Album, Artist

    a = Album(
        name="Nevermind",
        artists=[Artist(name="Nirvana")],
        release_year=1991,
    )
    b = Album(
        name="Nevermind",
        artists=[Artist(name="Nirvana")],
        release_year=1991,
    )
    assert a == b
    assert not (a != b)

    c = Album(
        name="Nevermind",
        artists=[Artist(name="Nirvana")],
        release_year=1991,
        label="DGC Records",
    )
    assert a != c
    assert not (a == c)

    d = Album(
        name="Nevermind",
        artists=[Artist(name="Nirvana")],
        release_year=1992,
    )

# Generated at 2022-06-12 15:58:10.118245
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Setup
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    # Run method being tested
    # Assert
    assert list(Person().__iter__()) == ["name", "age"]
    assert list(Person({"name": "John"}).__iter__()) == ["name"]
    assert list(Person(name="John Doe").__iter__()) == ["name"]
    assert list(Person(name="John Doe", age=42).__iter__()) == ["name", "age"]


# Generated at 2022-06-12 15:58:18.285137
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    a = Schema(
        title='The Confidence Interval',
        description='Describes a confidence interval',
        minLength=1,
        maxLength=2,
    )
    b = Schema(
        title='The Confidence Interval',
        description='Describes a confidence interval',
        minLength=1,
        maxLength=2,
    )
    c = Schema(
        title='The Confidence Interval',
        description='Describes a confidence interval',
        minLength=1,
        maxLength=6,
    )
    assert a == b, 'Test 1 failed'
    assert a != c, 'Test 2 failed'



# Generated at 2022-06-12 15:58:25.818885
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Foo(Schema, metaclass=SchemaMetaclass):
        a = Array()
        b = Array()
        c = Array()
        d = Array()
        e = Array()
        f = Array()
        g = Array()
        h = Array()
        i = Array()
        j = Array()
        k = Array()
        l = Array()
        m = Array()
        n = Array()
        o = Array()
        p = Array()
        q = Array()
        r = Array()
        s = Array()
        t = Array()
        u = Array()
        v = Array()
        w = Array()
        x = Array()
        y = Array()
        z = Array()


# Generated at 2022-06-12 15:58:34.305078
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
  import typesystem
  class BookSchema(Schema):
    title = typesystem.String()
    author = typesystem.String()
    release_year = typesystem.Integer()
    is_published = typesystem.Boolean(default=True)
  book = BookSchema(title='A Tale of Two Cities', author='Charles Dickens', release_year=1859, is_published=True)
  assert list(book) == ['title', 'author', 'release_year', 'is_published']
  class CatSchema(Schema):
    name = typesystem.String()
    weight = typesystem.Integer()
  cat = CatSchema(name='The Cat Next Door', weight=4.9)
  assert list(cat) == ['name', 'weight']


# Generated at 2022-06-12 15:58:36.258111
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        baz = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["baz"], definitions)
    assert Foo.fields["baz"].definitions is definitions

# Generated at 2022-06-12 15:58:46.251234
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Test(Schema):
        a = Field(required=True)
        b = Field(required=False)
    t = Test(1)
    assert len(t) == 1

    class Test(Schema):
        a = Field(required=True)
        b = Field(required=False)
    t = Test(1, b=2)
    assert len(t) == 2

    class Test(Schema):
        a = Field(required=True)
        b = Field(required=True)
    t = Test(1)
    assert len(t) == 1

    class Test(Schema):
        a = Field(required=True)
        b = Field(required=True)
    t = Test(1, b=2)
    assert len(t) == 2


# Generated at 2022-06-12 15:58:52.164880
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import Schema

    class ExampleSchema(Schema):
        first_name = String()
        last_name = String()
        age = Integer()

    # Example 1:
    schema = ExampleSchema(first_name='Dan', last_name='Gebhardt', age=22)
    repr(schema)

    # Example 2:
    schema = ExampleSchema()

    # Example 3:
    schema = ExampleSchema(first_name='Dan')



# Generated at 2022-06-12 15:59:03.445553
# Unit test for constructor of class Schema
def test_Schema():
    class ExampleSchema(Schema):
        name = String()
        age = Integer(minimum=0)

    example = ExampleSchema(name="Foo", age=42)
    assert example.name == "Foo"
    assert example.age == 42
    try:
        ExampleSchema(name="Foo", age=-42)
        assert False
    except TypeError as err:
        assert "Invalid argument 'age' for ExampleSchema()." in str(err)

    example2 = ExampleSchema(**{"name": "Foo", "age": 42})
    assert example == example2

    try:
        ExampleSchema(**{"name": "Foo", "age": 42, "score": 99})
        assert False
    except TypeError as err:
        assert "score is an invalid keyword argument for ExampleSchema()." in str

# Generated at 2022-06-12 15:59:08.248669
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = String

    # Test with no input argument
    try:
        testSchema = TestSchema()
        testSchema.__getitem__(None)

    except TypeError as err:
        assert str(err) == '__getitem__() takes exactly 1 argument (0 given)'
        
    except:
        assert False

    # Test with an input argument that is valid
    try:
        testSchema = TestSchema()
        testSchema.__getitem__('field1')

    except TypeError as err:
        assert False
        
    except:
        assert False

    # Test with an input argument that is invalid

# Generated at 2022-06-12 15:59:13.611041
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = Field()
        age = Field()

    person = Person(name="Testy McTestface", age=12)
    assert sorted([key for key in person]) == ["age", "name"]



# Generated at 2022-06-12 15:59:54.024464
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class AccountSchema(Schema):
        username = Field(required=True)
        password = Field(required=True)
        date_joined = Field(format="date-time")
        bio = Field(required=False)
        prefs = Object(
            required=False,
            properties={
                "email_contact": Field(required=True, type="boolean"),
                "timezone": Field(required=True, choices=["US/Eastern", "UTC"]),
            },
        )
        

# Generated at 2022-06-12 16:00:03.566605
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Test class is instantiated correctly
    class Country(Schema):
        id = Field()
        name = Field()

    class City(Schema):
        id = Field()
        name = Field()

    class Person(Schema):
        name = Field()
        age = Field()
        city = Reference(to=City)
        country = Reference(to=Country)


# Generated at 2022-06-12 16:00:10.959972
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
  from typesystem.schema import Schema
  from typesystem.fields import String
  from typesystem.validators import pattern
  class ValidationSchema(Schema):
    field = String(validators=[pattern(r'[abc]')])
  vs1 = ValidationSchema({'field': 'a'})
  vs2 = ValidationSchema({'field': 'a'})
  vs3 = ValidationSchema({'field': 'b'})
  assert vs1 == vs1
  assert vs1 == vs2
  assert vs1 != vs3
