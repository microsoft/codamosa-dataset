

# Generated at 2022-06-12 15:50:53.324422
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.types import String
    class Schema1(Schema, metaclass=SchemaMetaclass):
            str_field = String()
    schema1 = Schema1.make_validator()

    from typesystem.types import Integer
    class Schema2(Schema, metaclass=SchemaMetaclass):
        integer_field = Integer()

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            if hasattr(self, "integer_field"):
                self.integer_field = 1

    class Schema3(Schema, metaclass=SchemaMetaclass, schema2=Schema2):
        str_field = String()
        integer_field = Reference(schema2)



# Generated at 2022-06-12 15:50:56.006235
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class User(Schema):
        id: int
        username: str = None

    data = User(id=1, username="test")
    assert repr(data) == "User(id=1, username='test')"


# Generated at 2022-06-12 15:50:59.759830
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Book(Schema):
        name = Field(str)
        author = Field(str)
        isbn = Field(str)
        price = Field(float)

    book = Book(name="Great Expectations", author="Charles Dickens", isbn="978-1537187964", price=1.99)
    assert(list(book)==['name','author','isbn','price'])


# Generated at 2022-06-12 15:51:07.122728
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import Integer, String
    from typesystem.schema import Reference, Schema

    class AccountSchema(Schema):
        username = String()
        full_name = String()

        def __iter__(self):
            yield 'username'
            yield 'full_name'


    class FollowSchema(Schema):
        follower = Reference(AccountSchema)
        followed = Reference(AccountSchema)


    follow_schema = FollowSchema.make_validator()

    assert follow_schema(
        {'follower': {'username': 'bob', 'full_name': 'Bob Smith'},
            'followed': {'username': 'alice', 'full_name': 'Alice Jones'}})

# Generated at 2022-06-12 15:51:09.370615
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    person_instance = Person({"name": "John", "age": 27})

# Generated at 2022-06-12 15:51:16.673242
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import pytest

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer", default=0)
        email = Field(type="string", default="")
        phone = Field(type="string", default="")

    person = Person(name="Bob")
    assert len(person) == 1
    assert not person.is_sparse
    assert person.name == "Bob"
    assert person.age == 0
    assert person.email == ""
    assert person.phone == ""


# Generated at 2022-06-12 15:51:27.043159
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # test case 1
    from typesystem.fields import String
    from typesystem.definitions import SchemaDefinitions
    definitions = SchemaDefinitions()
    class MySchema(Schema, metaclass=SchemaMetaclass):
        a = String()
        b = String(default="blah")
    assert MySchema.fields == {'a': String(), 'b': String(default='blah')}
    s = MySchema()
    assert s.a == None
    assert s.b == 'blah'
    s = MySchema(a='foo')
    assert s.a == 'foo'
    assert s.b == 'blah'
    s = MySchema(b='overridden')
    assert s.a == None
    assert s.b == 'overridden'

# Generated at 2022-06-12 15:51:29.559056
# Unit test for constructor of class Reference
def test_Reference():
    #h=Reference(to='schema_1',definitions=None,**kwargs,**{})
    assert True==True

# Generated at 2022-06-12 15:51:34.319297
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        foo = Field()
        bar = Field(default=1)

    schema = TestSchema(foo=1)
    assert str(schema) == 'TestSchema(foo=1)'

    another_schema = TestSchema()
    assert str(another_schema) == 'TestSchema(bar=1)'

# Generated at 2022-06-12 15:51:40.892866
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert issubclass(Schema, typing.Mapping)
    from typesystem.base import Schema, Field
    from typesystem.fields import String
    from typesystem.mapping import Mapping, MutableMapping
    #
    assert issubclass(Mapping, typing.Mapping)
    assert issubclass(MutableMapping, typing.MutableMapping)
    assert issubclass(Field, typing.Any)
    assert issubclass(String, Field)

# Generated at 2022-06-12 15:51:55.153068
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference(to='Person')


# Generated at 2022-06-12 15:52:00.349270
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        name = Field(str)

    instance = TestSchema({"name": "John"})
    assert isinstance(instance, Schema)
    assert str(instance) == "TestSchema(name='John')"
    instance = TestSchema(name="John")
    assert isinstance(instance, Schema)
    assert str(instance) == "TestSchema(name='John')"


# Generated at 2022-06-12 15:52:04.180065
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class User(Schema):
        id: int
        name: str
        bio: str = "This is bio"
    user = User({"id": 1, "name": "name"})
    assert list(user) == ['id', 'name']

# Generated at 2022-06-12 15:52:10.914372
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        address = String()
        family_name = String()
        
    p = Person({"name": "Bob", "age": 25, "address": "123 Fake St"})
    assert p.age == 25
    assert p.family_name == None
    assert p.is_sparse == True
    assert p["name"] == "Bob"
    assert p["age"] == 25
    assert p["address"] == "123 Fake St"


# Generated at 2022-06-12 15:52:16.669484
# Unit test for function set_definitions
def test_set_definitions():
    assert (
        "other" not in Schema.fields
    ), "Other schema not defined. Need to make sure that test runs without this"
    definitions = SchemaDefinitions()
    field = Reference("other")
    set_definitions(field, definitions)
    assert field.definitions is definitions
    assert "other" not in definitions



# Generated at 2022-06-12 15:52:20.820363
# Unit test for function set_definitions
def test_set_definitions():
    class Definition(Schema):
        foo = Field()

    class Target(Schema):
        definition = Reference('Definition')

    definitions = SchemaDefinitions()
    set_definitions(Target.fields['definition'], definitions)
    assert Target.fields['definition'].definitions == definitions

# Generated at 2022-06-12 15:52:24.437294
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    data={"a": {"b": {"c": 1}}}
    schema=Schema({
        "a": {
            "b": {"c": 1}
        }
    })
    assert schema["a"]["b"]["c"]==1
    assert data==schema

# Generated at 2022-06-12 15:52:30.712825
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from pyspark.sql import SparkSession
    spark = SparkSession.builder.getOrCreate()
    sc = spark.sparkContext
    path = "random_path"
    assert str(Schema()).startswith("Schema([sparse])")
    assert str(Schema(a=1, b=2)).startswith("Schema([sparse])")
    assert str(Schema(a=1, b=2).__iter__()).startswith("<dict_keyiterator object")
    assert str(Schema(a=1, b=2).__iter__().__next__()).startswith("'a'")
    assert str(Schema(a=1, b=2).__iter__().__next__()).endswith("'b'")

# Generated at 2022-06-12 15:52:35.305986
# Unit test for function set_definitions
def test_set_definitions():
    class InnerSchema(Schema):
        nested = String()

    class OuterSchema(Schema):
        inner = Reference(InnerSchema)

    defs = SchemaDefinitions()
    set_definitions(OuterSchema, defs)
    assert InnerSchema in defs.values()

# Generated at 2022-06-12 15:52:43.212086
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from unittest.mock import Mock
    import pytest

    from . import types
    from .types import Person, Address
    from .fields import String

    Person._creation_counter = 0
    Address._creation_counter = 2
    params = {'name': 'Wim', 'address': 'Ddorp'}
    instance = Person(**params)
    expected = (
        f"Person(name='Wim', "
        f"address=Address(city='Ddorp', country=None, zipcode=None))"
    )
    assert instance.__repr__() == expected

# Generated at 2022-06-12 15:53:07.447554
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Array(items=String())

    class FooBar(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions({})
    set_definitions(FooBar.make_validator(), definitions)

    # Check that set_definitions has set the definitions property
    # of the Reference field
    assert FooBar.make_validator().properties["baz"].definitions == definitions

# Generated at 2022-06-12 15:53:08.809208
# Unit test for constructor of class Schema
def test_Schema():
    temp = Schema()
    assert temp.fields == {}

# Generated at 2022-06-12 15:53:11.702944
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class User(Schema):
        id = Field(type="string")
        name = Field(type="string")
    a = User({"id": 1, "name": "foo"})
    b = User({"id": 2, "name": "foo"})
    assert not a == b


# Generated at 2022-06-12 15:53:13.857708
# Unit test for function set_definitions
def test_set_definitions():
    field = Reference("User")
    definitions = SchemaDefinitions()
    set_definitions(field, definitions)
    assert field.definitions == definitions
    assert field.target_string == "User"
    assert field.target is None



# Generated at 2022-06-12 15:53:19.536329
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        text = String()
    ts = TestSchema(text='Hello')
    assert len(ts) == 1
    ts = TestSchema(text='Hello', text2 = 'World')
    assert len(ts) == 2

test_Schema___len__()


# Generated at 2022-06-12 15:53:24.580362
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    v1 = Reference(to='Test')
    fields = {'test': v1}
    class_name = 'Test'
    arguments = {'test': 'val'}
    sparse_indicator = ' [sparse]'
    expected_result = 'Test(test=\'val\') [sparse]'
    class_attr = {'fields': fields, '__name__': class_name}
    schema = Schema()
    schema_obj = schema.__class__(arguments)
    schema_obj.__getitem__(key='test')
    assert expected_result == schema_obj.__repr__()

# Generated at 2022-06-12 15:53:33.502222
# Unit test for function set_definitions
def test_set_definitions():
    # type: () -> None

    class FooSchema(Schema):
        class Meta:
            definitions = {
                "bar": Reference("BarSchema"),
                "baz": Reference("BazSchema"),
            }

        foo = Field()
        foo_array = Array(items=Reference("BarSchema"))  # type: ignore
        foo_object = Object(
            properties={"bar": Reference("BarSchema")},
        )

    class BarSchema(Schema):
        bar = Field()

    class BazSchema(Schema):
        baz = Field()

    # Make sure all the type annotations match up.
    foo_item = FooSchema(foo="foo", foo_array=None, foo_object=None)
    assert isinstance(foo_item.foo_array, Array)

# Generated at 2022-06-12 15:53:43.472046
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import Integer, String
    
    class UserSchema(Schema):
        id = Integer(description="Either a user's identifier or a group's identifier", required=True)
        name = String(description="Either a user's name or a group's name", required=True)
    
    user = UserSchema(id=1, name='Rabbit')
    assert str(user) == "UserSchema(id=1, name='Rabbit')"
    
    user = UserSchema(id=1, name='Rabbit')
    assert repr(user) == "UserSchema(id=1, name='Rabbit')"


# Generated at 2022-06-12 15:53:47.159934
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import json
    import pytest

    test_data = json.loads("""{"A": "a", "B": "b", "D": "d", "C": "c"}""")
    json_schema = Schema(test_data)
    test_data_iterator = iter(test_data)
    json_schema_iterator = json_schema.__iter__()
    for item in json_schema_iterator:
        assert json_schema[item] == test_data[item]

# Generated at 2022-06-12 15:53:50.110369
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import datetime as dt

    class Booking(Schema):
        arrival = dt.datetime()


# Generated at 2022-06-12 15:54:08.137909
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema, metaclass=SchemaMetaclass):
        class Meta:
            # Some extra meta-data, e.g. for declaring field order.
            pass
        id = Int()
        name = String()
    TestSchema(id=1, name='Tom')
    TestSchema(id=1, name='Tom', email='tom@example.com')

# Generated at 2022-06-12 15:54:11.947079
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        num = Field(type=int)

    class Bar(Schema):
        foo = Reference(to="Foo")

    definitions = SchemaDefinitions()
    field = Bar()
    set_definitions(field, definitions)
    assert field.foo.definitions is definitions

# Generated at 2022-06-12 15:54:18.675720
# Unit test for constructor of class Schema
def test_Schema():
    class Colour(Schema):
        red = Field(Integer, min_value=0, max_value=255)
        green = Field(Integer, min_value=0, max_value=255)
        blue = Field(Integer, min_value=0, max_value=255)

    assert Colour.validate({'red': 127, 'green': 127, 'blue': 127}) == Colour(red=127, green=127, blue=127)
    assert Colour.validate({'red': 127, 'green': 127, 'blue': 127}, strict=True) == Colour(red=127, green=127, blue=127)
    assert Colour.validate_or_error(
        {'red': 127, 'green': 128, 'blue': 127}).error.messages()[0].text == 'Must be no more than 127.'

# Generated at 2022-06-12 15:54:28.010902
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test our metaclass generates a Schema
    # class with the right attributes
    class SomeSchema(Schema):
        foo = Field()
        bar = Field()
        baz = Field()

    # Make sure `fields` attribute is a dictionary with
    # the right keys and values
    assert isinstance(SomeSchema.fields, dict)
    assert "foo" in SomeSchema.fields
    assert isinstance(SomeSchema.fields["foo"], Field)
    assert "bar" in SomeSchema.fields
    assert isinstance(SomeSchema.fields["bar"], Field)
    assert "baz" in SomeSchema.fields
    assert isinstance(SomeSchema.fields["baz"], Field)

    # Make sure fields are in the right order

# Generated at 2022-06-12 15:54:33.289548
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
        class TestSchema(Schema):
            id=Integer()
        s1=TestSchema({'id':1})
        s2=TestSchema(id=1)
        s3=TestSchema(id=2)
        assert s1==s2
        assert s1!=s3

# Generated at 2022-06-12 15:54:43.090120
# Unit test for constructor of class Schema
def test_Schema():
    class FooSchema(Schema):
        id = Field(type=str)
        bar = Field(type=int, default=5)


# Generated at 2022-06-12 15:54:45.744385
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class A(Schema):
        name = String()

    a = A({"name": "Hello"})
    assert a["name"] == "Hello"


# Generated at 2022-06-12 15:54:50.532625
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class A(Schema):
        a = Field(required=True)
        b = Field(required=False)

    a = A(a=0, b=1)
    assert a.__iter__() == ['a', 'b']
    a = A(a=0)
    assert a.__iter__() == ['a']
    a = A(b=1)
    assert a.__iter__() == ['b']


# Generated at 2022-06-12 15:54:56.527212
# Unit test for method __len__ of class Schema
def test_Schema___len__():
	from typesystem.fields import String
	class NamedObject(Schema):
		name = String()
	named_object = NamedObject(name="Foo")
	assert len(named_object) == 1
	unnamed_object = NamedObject()
	assert len(unnamed_object) == 0


# Generated at 2022-06-12 15:55:00.856770
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert list(Schema({}).__iter__()) == []
    assert list(Schema({"foo": 1}).__iter__()) == ["foo"]
    assert list(Schema({"foo": 1, "bar": 2}).__iter__()) == ["foo", "bar"]


# Generated at 2022-06-12 15:55:29.647823
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Point(Schema):
        x = Field()
        y = Field()
    p = Point(x=1, y=2)
    assert len(p) == 2


# Generated at 2022-06-12 15:55:34.067293
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import String
    from typesystem_tdd import Schema, Field

    class Movie(Schema):
        title = String()
        year = String()
        genre = String()

    movie = Movie(title='Fight Club', year=1999)
    assert len(movie) == 2



# Generated at 2022-06-12 15:55:39.147310
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
	class T(Schema):
		a = Field()
		b = Field()
		c = Field()
	t1 = T(a='a', b='b', c='c')
	t2 = T(a='a', c='c')
	assert t1 == t2
	assert t1.is_sparse
	


# Generated at 2022-06-12 15:55:48.628462
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema().fields == {}
    assert Schema().is_sparse
    assert not Schema(name="Tester").is_sparse
    assert not Schema(name="Tester").is_sparse
    assert Schema(name="Tester", age=25, job=None).fields == {}
    assert Schema(name="Tester", age=25, job=None).is_sparse
    assert not Schema(name="Tester", age=25).is_sparse
    assert Schema(name="Tester", age=25).age == 25
    assert Schema(name="Tester", age=25).name == "Tester"
    assert Schema({"name": "Tester", "age": 25}).name == "Tester"
    assert Schema({"name": "Tester", "age": 25}).age

# Generated at 2022-06-12 15:55:50.576476
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        pass
    test_schema = TestSchema()
    assert repr(test_schema) == "TestSchema()"


# Generated at 2022-06-12 15:55:54.970246
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import Boolean, Integer

    class Test(Schema):
        a = Integer()
        b = Boolean()

    assert Test.fields == {"a": Integer(), "b": Boolean()}


# Generated at 2022-06-12 15:55:58.517730
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Setup
    class Person(Schema):
        name: str
        age: int = 18

    # Exercise & Verify
    assert repr(Person(name='John')) == "Person(name='John', age=18)"

# Generated at 2022-06-12 15:56:04.832939
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import Object, String

    class UserSchema(Schema):
        name = String(max_length=100, required=True)
        email = String(max_length=100)

    class StoreSchema(Schema):
        name = String(max_length=100, required=True)
        owner = Reference(UserSchema)

    store = StoreSchema({
      "name": "Grey Stuff",
      "owner": {
        "name": "Christian"
      }
    })


# Generated at 2022-06-12 15:56:10.624911
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from unittest.mock import Mock
    from unittest.mock import patch
    from typesystem.fields import String

    # Patch base classes
    class_bases = patch.object(
        SchemaMetaclass, '__bases__', new_callable=Mock
    )
    assert class_bases is not None
    (base1, base2), kwargs = class_bases.call_args
    assert base1 is ABCMeta
    assert base2 is Mapping
    assert len(kwargs) == 0

    # Patch SchemaMetaclass.__new__
    with patch.object(SchemaMetaclass, '__new__') as patched___new__:
        # Patch arguments
        patched_name = patch.object(SchemaMetaclass, 'name', new_callable=Mock)
       

# Generated at 2022-06-12 15:56:14.863831
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from unittest import TestCase

    class TestSchema(Schema):
        testField  = IntField()
    assert TestSchema.__len__(TestSchema(testField=1)) == 1
    assert TestSchema.__len__(TestSchema()) == 0


# Generated at 2022-06-12 15:57:09.098292
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Country(Schema):
        name = Field()
    class Person(Schema):
        name = Field()
        age = Field(type="integer")
        nationality = Reference(Country, definitions=definitions)

    set_definitions(Person.name, definitions)
    assert Person.name.definitions is None
    set_definitions(Person.nationality, definitions)
    assert Person.nationality.definitions is definitions

# Generated at 2022-06-12 15:57:10.575162
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
  s = Schema(**{"type": "string"})
  assert s.__iter__()



# Generated at 2022-06-12 15:57:15.841397
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.forms import Form
    from typesystem.fields import Integer, String, create_field
    definitions = SchemaDefinitions()
    schema = Form(
        properties=dict(
            name=String(),
            age=Integer(),
            friend=Reference("Person"),
            friends=Array(Reference("Person")),
            friends2=Array(create_field(Reference("Person"))),
        )
    )
    schema2 = Form(
        properties=dict(
            name=String(),
        )
    )
    definitions["Person"] = schema2
    set_definitions(schema, definitions)

# Generated at 2022-06-12 15:57:23.914670
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Color(Schema):
        r: int
        g: int
        b: int

    class Car(Schema):
        color: Color
        license: str
    car_empty = Car()
    assert len(car_empty) == 0
    car = Car(color = Color(r = 255, g = 255, b = 255), license = 'ABC-123')
    assert len(car) == 2
    assert len(car.color) == 3



# Generated at 2022-06-12 15:57:24.925555
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass # TODO


# Generated at 2022-06-12 15:57:34.751216
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from collections.abc import Iterable
    from typesystem.schema import Schema

    from typesystem_primitives.fields import String

    class Person(Schema):
        name = String()
        age = String()
        gender = String()
        job = String()
        boss_id = String()

    p = Person(name='Tom', age='30', job='engineer')
    assert isinstance(p.__iter__(), Iterable)
    assert 'name' in p.__iter__()
    assert 'age' in p.__iter__()
    assert 'gender' not in p.__iter__()
    assert 'job' in p.__iter__()
    assert 'boss_id' not in p.__iter__()
    assert len(list(p.__iter__())) == 3


# Generated at 2022-06-12 15:57:37.472140
# Unit test for function set_definitions
def test_set_definitions():
    class ReferenceObject(Schema):
        reference = Reference("OtherObject")

        definitions = SchemaDefinitions(
            {"OtherObject": {"property": Field(type="string")}}
        )

    set_definitions(ReferenceObject.fields["reference"], ReferenceObject.definitions)
    assert issubclass(ReferenceObject.fields["reference"].target, Schema)

# Generated at 2022-06-12 15:57:45.831951
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():

    # Test case 1
    test_field = Schema({})
    assert test_field == Schema()
    assert test_field.is_sparse == True
    assert list(test_field) == []
    assert len(test_field)  == 0

    # Test case 2
    test_field = Schema(name='a')
    assert list(test_field) == ['name']
    assert len(test_field)  == 1
    assert test_field == Schema(name='a')

    # Test case 3
    test_field = Schema(name='a',age=3)
    assert list(test_field) == ['name','age']
    assert len(test_field)  == 2
    assert test_field == Schema(name='a',age=3)

# Generated at 2022-06-12 15:57:49.736007
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()
        married = Boolean()

    person = Person({"name": "Fred", "age": 40, "married": True})
    print(list(person))
    # ['name', 'age', 'married']



# Generated at 2022-06-12 15:57:56.517063
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = "a"
        b = "b"
        c = "c"
        d = "d"
        e = "e"
        f = "f"

        fields = {
            "a": Field(),
            "b": Field(),
            "c": Field(),
            "d": Field(),
            "e": Field(),
            "f": Field(),
        }
    test_schema = TestSchema(a="a", b="b", c="c")
    expected = ["a", "b", "c"]
    actual = list(test_schema.__iter__())
    assert actual == expected


# Generated at 2022-06-12 16:00:03.036877
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test type
    i = 0
    s = Schema()
    assert isinstance(s.__iter__(), typing.Iterator), 'Should be an instance of Iterator'
    assert isinstance(s.__iter__(), typing.Iterator), 'Should be an instance of Iterator'
    # Test equality
    i = 0
    s = Schema()
    assert isinstance(s.__iter__(), typing.Iterator), 'Should be an instance of Iterator'
    assert isinstance(s.__iter__(), typing.Iterator), 'Should be an instance of Iterator'
    # Test len
    i = 0
    s = Schema()
    assert len(s.__iter__()) == 2, 'Should be equal to 2'
    assert len(s.__iter__()) == 2, 'Should be equal to 2'


# Generated at 2022-06-12 16:00:07.201766
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        text = String(min_length=2)
        my_obj = Reference("TestSchema")
    data = {"text": "testing", "my_obj": {"text": "testing"}}
    TestSchema.validate(data)
    assert True

# Generated at 2022-06-12 16:00:08.889642
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions(test='test')
    assert definitions['test'] == 'test'

