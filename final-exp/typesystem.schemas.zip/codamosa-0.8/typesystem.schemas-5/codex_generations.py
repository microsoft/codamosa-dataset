

# Generated at 2022-06-12 15:51:03.434324
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    props = Person.fields
    assert "name" in props

    person = Person(name="Bob")
    assert person.name == "Bob", "The name should be Bob"
    assert person == Person(name="Bob"), "Equality check failed"
    assert repr(person) == "Person(name='Bob')", "repr() did not work"
    assert dict(person) == {"name": "Bob"}, "conversion to dict did not work"
    assert len(person) == 1, "len() did not work"
    assert list(iter(person)) == ["name"], "iteration did not work"
    assert person["name"] == "Bob", "__getitem__ did not work"

# Generated at 2022-06-12 15:51:05.923167
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    v0 = Schema(a=1,b=2,c=3)
    v1 = list(v0)
    v2 = ['a', 'c', 'b']
    assert (v1 == v2)


# Generated at 2022-06-12 15:51:09.944715
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Int(Field):
        pass
    class Point(Schema):
        x = Int()
        y = Int()
    
    assert Point.fields == {'x': Int(), 'y': Int()}

if __name__ == '__main__':
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-12 15:51:17.585673
# Unit test for constructor of class Schema
def test_Schema():
    TEST_FIELDS = {
        'id': Int(required=True),
        'name': String(required=True),
        'price': Float(),
    }

    TEST_DATA = {
        'id': 100,
        'name': 'D',
        'price': 3.15,
    }
    testcase = Schema(TEST_DATA, TEST_FIELDS, definitions=SchemaDefinitions())
    result = Schema(TEST_DATA, TEST_FIELDS, definitions=SchemaDefinitions())
    assert(testcase == result)

# Generated at 2022-06-12 15:51:21.095615
# Unit test for constructor of class Reference
def test_Reference():
    reference = Reference('myRef', definitions = {'myRef': 'hello'})
    assert reference.target == 'hello'
    assert reference.to == 'myRef'
    assert reference.definitions == {'myRef':'hello'}


# Generated at 2022-06-12 15:51:24.316682
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class FooSchema(Schema):
        foo = Field(int)
        bar = Field(str)
    schema = FooSchema({'foo' : 1, 'bar' : 'bar'})
    assert list(schema) == ['foo', 'bar']

# Generated at 2022-06-12 15:51:28.300468
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)

    p1 = Person(name='Joost', age=12)
    p2 = Person(name='Joost')

    assert len(p1) == 2
    assert len(p2) == 1

# Generated at 2022-06-12 15:51:36.978084
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    SET_1 = {'arg1':123,'arg2':456,'arg3':789,'arg4':321}
    EXPECTED_SET_1 = 'Schema(arg1=123, arg2=456, arg3=789, arg4=321)'

    SET_2 = {'arg1':123,'arg4':321}
    EXPECTED_SET_2 = 'Schema(arg1=123, arg4=321) [sparse]'

    result1 = Schema(SET_1)
    result2 = Schema(SET_2)
    assert str(result1) == EXPECTED_SET_1
    assert str(result2) == EXPECTED_SET_2


# Generated at 2022-06-12 15:51:42.709622
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    assert str(
        Person(name="Fred Bloggs", age=37)
    ) == "Person(age=37, name='Fred Bloggs')"

# Generated at 2022-06-12 15:51:48.043803
# Unit test for function set_definitions
def test_set_definitions():
    fields = {
        "first": Reference("Test"),
        "second": Reference("Test"),
        "third": Reference("Test"),
    }
    definitions = SchemaDefinitions()
    for field in fields.values():
        set_definitions(field, definitions)
    assert "Test" in definitions
    assert definitions["Test"] is fields["first"].target



# Generated at 2022-06-12 15:52:10.451828
# Unit test for function set_definitions
def test_set_definitions():
    A = Object.of(id=Integer(minimum=0))
    B = Object.of(a=Object.as_ref(A, name='A'))
    C = Object.of(b=Object.as_ref(B, name='B'), c=Object.as_ref(B, name='B'))
    definitions = SchemaDefinitions()
    set_definitions(C, definitions)
    assert 'A' in definitions
    assert 'B' in definitions
    assert 'C' not in definitions
    # TODO: Test recursive definitions (A refs A?)
    # NOTE: the recursion should naturally break because of the second
    # set_definitions call for "B".
    # NOTE: A ref's fields should be added to B's defined fields.
    # NOTE: Annotations should be stable so that B knows that "a" is an

# Generated at 2022-06-12 15:52:12.461061
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import String

    class TestSchema(Schema):
        foo = String()



# Generated at 2022-06-12 15:52:20.360857
# Unit test for function set_definitions
def test_set_definitions():
    class BaseSchema(Schema):
        a = Integer(description="a")
        b = Reference("NestedSchema", description="b")

    class NestedSchema(Schema):
        c = Integer(description="c")

    definitions = SchemaDefinitions({"NestedSchema": NestedSchema})
    set_definitions(BaseSchema.fields["b"], definitions)
    assert BaseSchema.fields["b"].target is NestedSchema
    assert BaseSchema.fields["b"].definitions is definitions

# Generated at 2022-06-12 15:52:27.327055
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)

    p = Person(name="John", age=12)
    print(p)
    try:
        p = Person(name=99, age=12)
    except Exception as e:
        print(e)
    try:
        p = Person(name="John", age=12, foo=3)
    except Exception as e:
        print(e)



# Generated at 2022-06-12 15:52:34.677536
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from unittest import TestCase

    class MySchema(Schema):
        name = String()
        description = String()
        price = Float()

    class Test(TestCase):

        def test_repr(self):
            s = MySchema(name="MyName", description="desc")
            assert repr(s) == "MySchema(name='MyName', description='desc')"

    test = Test()
    test.test_repr()

test_Schema___repr__()


# Generated at 2022-06-12 15:52:40.476131
# Unit test for function set_definitions
def test_set_definitions():
    # Testing Reference with a string
    class MyObject(Schema):
        my_string = Reference("my_string_field")

    class MyStringField(Field):
        pass

    # Testing non-string Reference
    class MyObject2(Schema):
        my_string = Reference(MyStringField)

    d = SchemaDefinitions()
    d["my_string_field"] = MyStringField
    set_definitions(MyObject, d)
    assert MyObject.fields["my_string"].definitions == d
    assert MyObject2.fields["my_string"]._target == MyStringField



# Generated at 2022-06-12 15:52:51.957911
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.fields import Integer, String  # type: ignore
    from typesystem.schema.schema import Schema  # type: ignore

    definitions = SchemaDefinitions()
    schema = Schema(
        {"label": String(max_length=255)},
        {"name": String(max_length=255)},
        {"age": Integer()},  # type: ignore
    )
    set_definitions(schema, definitions)
    assert schema.is_valid({"label": "foo", "age": 25}) is True
    assert schema.is_valid({"label": "foo", "name": "bar"}) is False


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.REPORT_NDIFF, verbose=True)

# Generated at 2022-06-12 15:52:59.020309
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    fields = {"name": Field()}
    class Form(Schema):
        name = Field()
    
    name = "Form"
    bases = ()
    attrs = {"name": Field}
    definitions = None
    cls = SchemaMetaclass(name, bases, attrs, definitions)
    assert cls.fields == fields
    assert isinstance(cls, Mapping)
    assert isinstance(cls, typing.Type)
    
    f = Form(name="User")
    assert f["name"] == "User"

# Generated at 2022-06-12 15:53:04.223615
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Foo(Schema):
        bar = Field()
        baz = Field()

    foo = Foo(bar=1, baz=2)
    keys = [k for k in foo]
    assert keys == ["bar", "baz"]


# Generated at 2022-06-12 15:53:08.091827
# Unit test for constructor of class Reference
def test_Reference():
    target = Object(properties={'number': Number(minimum = 0)})
    target.__class__.__name__ = 'target'
    target = Reference(to = target)
    target(number = 2)



# Generated at 2022-06-12 15:53:20.446019
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    test_object = Schema()
    len_result = test_object.__len__()
    return len_result


# Generated at 2022-06-12 15:53:30.468085
# Unit test for method validate of class Reference
def test_Reference_validate():
    def test_validate_schema():
        class Shoe(Schema):
            size = Field(type="string")
            color = Field(type="string")
            price = Field(type="string")

        shoe = Shoe(size="8.5", color="blue", price="$10")
        order = Reference(to=Shoe)(shoe)
        assert order.validate(shoe) == shoe

    def test_validate_schema_invalid_type():
        class Shoe(Schema):
            size = Field(type="string")
            color = Field(type="string")
            price = Field(type="string")

        shoe = Shoe(size="8.5", color="blue", price="$10")
        order = Reference(to=Shoe)({'test':"test"})

# Generated at 2022-06-12 15:53:35.708147
# Unit test for constructor of class Reference
def test_Reference():
    class ExampleSchema(Schema):
        field_1 = String()

    class ExampleSchema2(Schema):
        field_2 = Reference(ExampleSchema)
        
    ref1 = ExampleSchema2(field_2=ExampleSchema(field_1="1"))
    print(ref1)

# Generated at 2022-06-12 15:53:41.315970
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Schema, String

    class UserSchema(Schema):
        name = String(max_length=255)

    user_schema = UserSchema(name="Egon Spengler")
    # AssertionError: 1 == 2
    assert len(user_schema) == 2



# Generated at 2022-06-12 15:53:44.867322
# Unit test for method validate of class Reference
def test_Reference_validate():
    t = Reference(to="ABC")
    assert t.validate("string") == "string"
    try:
        t.validate(None)
    except ValidationError as e:
        assert e.text == "May not be null."


# Generated at 2022-06-12 15:53:51.868943
# Unit test for function set_definitions
def test_set_definitions():
    class MetaSchema(metaclass=SchemaMetaclass, definitions=SchemaDefinitions()):
        pass
    class FooSchema(Schema, metaclass=MetaSchema):
        foo = String(required=True)
    class BarSchema(Schema, metaclass=MetaSchema):
        bar = String(required=True)
        foo = Reference('FooSchema')
        foo_array = Array(items=Reference('FooSchema'))
    class BazSchema(Schema, metaclass=MetaSchema):
        bar = Reference('BarSchema')
        foo = Reference('FooSchema')
    class FooSubtypeSchema(FooSchema, metaclass=MetaSchema):
        foo2 = String(required=True)

# Generated at 2022-06-12 15:53:58.879868
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        field = Field()
    assert A(field=1) == A(field=1), 'Тест #1: Проверка работы метода __eq__ класса Schema провалена'
    assert not A(field=1) == A(field=2), 'Тест #2: Проверка работы метода __eq__ класса Schema провалена'

# Generated at 2022-06-12 15:54:06.650048
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Child(Schema):
        name = Field(str)
        age = Field(int)

    a = Child(name="alice", age=15)
    b = Child(name="alice", age=15)
    c = Child(name="alice", age=16)

    assert a == b
    assert a != c
    # Unit test for method __repr__ of class Schema
    def test_Schema___repr__():
        class Child(Schema):
            name = Field(str)

        a = Child(name="alice")
        assert repr(a) == "Child(name='alice')"


        class Child(Schema):
            name = Field(str)
            age = Field(int, default=15)

        a = Child(name="alice")

# Generated at 2022-06-12 15:54:07.678668
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)

# Generated at 2022-06-12 15:54:15.956726
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from .models import Product
    from .models import Person
    from .models import Blog
    from .models import BlogPost

    p1 = Product.validate({"name":"Tracey","type_of":"tech"})
    for key in p1.fields.keys():
        if key in {"name","type_of"}:
            assert  getattr(p1, key) == p1[key]
    p2 = Person.validate({"name":"Tracey","gender":"female","age":25})
    for key in p2.fields.keys():
        if key in {"name","gender","age"}:
            assert  getattr(p2, key) == p2[key]

    b1 = Blog.validate({"name":"Tracey Tech Blog","owner":p1})

# Generated at 2022-06-12 15:54:37.757748
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import Boolean, Integer

    def get_definitions():
        class Post(Schema):
            title = String(max_length=100)
            published = Boolean()
            author = Reference("Author")

        class Comment(Schema):
            body = String()
            post = Reference("Post")
            author = Reference("Author")

        class Author(Schema):
            name = String()
            age = Integer(minimum=0, maximum=150)
            posts = Array(items=Reference("Post"))
            comments = Array(items=Reference("Comment"))

        definitions = SchemaDefinitions(
            Post=Post, Comment=Comment, Author=Author
        )

        return definitions

    definitions = get_definitions()

    # test that object can be created
    test_reference = Reference("Author", definitions)



# Generated at 2022-06-12 15:54:44.412303
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String
    
    class Simple(Schema):
        name = String()
        age = String()

    obj = Simple(name = "Ram", age = "20")
    print("Testing method __iter__ of class Schema : ")
    print("Serialize data : ")
    for key, value in obj.items():
        print("{key} = {value}".format(key = key, value = value))


# Generated at 2022-06-12 15:54:52.455530
# Unit test for constructor of class Schema
def test_Schema():
    class User(Schema):
        username = String()
        email = Email(required=True)
        title = String(required=False)
        password = String(required=False)

        def set_password(self, plaintext_password: str) -> "User":
            self.password = plaintext_password
            return self

    u = User(username="foo", email="foo@example.com")

    assert u.username == "foo"
    assert u.email == "foo@example.com"
    assert u.title is None
    assert u.password is None
    assert u.is_sparse == False

    u2 = User(username="foo", title="Mr.")

    assert u2.username == "foo"
    assert u2.title == "Mr."
    assert u2.email is None
    assert u2.password

# Generated at 2022-06-12 15:54:56.299703
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class EmptySchema(Schema):
        pass

    a = EmptySchema()
    assert str(a) == 'EmptySchema()'
    assert len(a) == 0
    assert list(a) == []

    class SchemaWithFields(Schema):
        a = Integer()
        b = Integer()
        c = Integer()

    b = SchemaWithFields(a=1, c=2)
    assert str(b) == 'SchemaWithFields(a=1, c=2) [sparse]'
    assert len(b) == 2
    assert list(b) == ['a', 'c']


# Generated at 2022-06-12 15:55:01.275181
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Booking(Schema):
        id = Field(str)
        passenger = Field(str)
        taxi = Field(str, required=False)
        driver = Field(str, required=False)
    booking1 = Booking(id="1", passenger="Alice")
    booking2 = Booking(id="1", passenger="Alice")
    assert booking1 == booking2


# Generated at 2022-06-12 15:55:07.325169
# Unit test for function set_definitions
def test_set_definitions():
    class UserDefinedSchema(Schema):
        name = Reference("Name")
        age = Reference("Age")
        friends = Array(Reference("User"))

    definitions = SchemaDefinitions()
    user_defined_schema = UserDefinedSchema()

    set_definitions(user_defined_schema, definitions)
    assert user_defined_schema.name.definitions == definitions
    assert user_defined_schema.age.definitions == definitions
    assert user_defined_schema.friends.items.definitions == definitions

# Generated at 2022-06-12 15:55:14.416351
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import String
    from typesystem.fields import Array, Object
    from typesystem.schema import Schema, Reference
    from typesystem.schema import SchemaMetaclass
    from typesystem.schema import SchemaDefinitions

    class User(Schema, metaclass=SchemaMetaclass):
        id = String()
        username = String()
        friends = Array(Reference("User"))

    class Post(Schema, metaclass=SchemaMetaclass):
        id = String()
        author = Reference("User")
        discussion = Array(Reference("Post"))

    class Error(Schema, metaclass=SchemaMetaclass):
        message = String()

    class Result(Schema, metaclass=SchemaMetaclass):
        user = Reference("User")
        post = Reference("Post")
       

# Generated at 2022-06-12 15:55:20.155344
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import types
    from typesystem.types import (
        Array,
        Boolean,
        Integer,
        Number,
        Object,
        String,
    )


    class User(Schema):
        id = Integer(format="int32")
        name = String()


    assert User.fields == {
        "id": Integer(format="int32"),
        "name": String(),
    }


    class User(Schema):
        class Meta:
            strict = True

        id = Integer(format="int32")
        name = String()
        friends = Array(items=Reference("User"), format="uuid")



# Generated at 2022-06-12 15:55:24.023459
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class Alternative(Schema):
        pass
    class TestReference(Schema):
        reference = Reference("Alternative")
    class TestArray(Schema):
        array = Array(items=Reference("Alternative"))
    class TestObject(Schema):
        properties = Object(properties={"prop": Reference("Alternative")})
        items = [InlineReference("Alternative")]

    set_definitions(TestReference.fields["reference"], definitions)
    assert TestReference.fields["reference"].target == Alternative
    set_definitions(TestArray.fields["array"], definitions)
    assert TestArray.fields["array"].items == Alternative
    set_definitions(TestObject.fields["properties"], definitions)
    assert TestObject.fields["properties"].properties["prop"] == Alternative

# Generated at 2022-06-12 15:55:27.814028
# Unit test for constructor of class Schema
def test_Schema():
    def test_incorrect_argument_type_throws_type_error():
        class Foo(Schema):
            a = Field(int)
        obj = Foo({"a": "foo"})
        assert obj.a == "foo"
        obj = Foo(a="foo")
        assert obj.a == "foo"
    test_incorrect_argument_type_throws_type_error()

# Generated at 2022-06-12 15:55:49.355991
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        x = Field(type="string")
    
    ts = TestSchema(x = 'apple')
    assert len(ts) == 1
    assert len(TestSchema()) == 0
    

# Generated at 2022-06-12 15:55:51.898427
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Item(Schema):
        name = String()
        number = Integer()

    item = Item(name="apple", number=1)

    assert item["name"] == "apple"
    assert item["number"] == 1


# Generated at 2022-06-12 15:55:56.553488
# Unit test for method validate of class Reference
def test_Reference_validate():
    class A(Schema):
        a = Field(int)
    a = Reference("A")

if __name__ == "__main__":
    test_Reference_validate()

# Generated at 2022-06-12 15:55:57.807804
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass # TODO


# Generated at 2022-06-12 15:56:04.592577
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class User(Schema):
        id = Integer(description="Unique identifier for this user.")
        name = String(description="Name of this user.")
        email = String(format="email", description="Email address of this user.")
        age = Integer(minimum=0, description="Age of this user.")

    user = User(
        id=1,
        name="John Doe",
        email="john@example.com",
        age=30,
    )
    assert set(iter(user)) == {"id", "name", "email", "age"}

# Generated at 2022-06-12 15:56:16.230224
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from tests.schema import First, Second, Third

    class Base(Schema):
        a = Integer()
        b = String()

    class Child(Base):
        c = Float()
        d = Boolean()

    def check_field_order(schema: Schema) -> None:
        expected_fields = ["a", "b", "c", "d"]
        assert list(schema.fields.keys()) == expected_fields

        fields = [field for field in schema.fields.values()]
        assert fields[0]._creation_counter < fields[1]._creation_counter
        assert fields[1]._creation_counter < fields[2]._creation_counter
        assert fields[2]._creation_counter < fields[3]._creation_counter

    check_field_order(First)
    check_field_order(Second)

# Generated at 2022-06-12 15:56:24.749609
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        b = Reference("B")

    class B(Schema):
        c = Reference("C")

    class C(Schema):
        d = Reference("C")

    class D(Schema):
        pass

    definitions = SchemaDefinitions(b=B, c=C, d=D)

    assert A.fields["b"].definitions is None
    assert B.fields["c"].definitions is None
    assert C.fields["d"].definitions is None
    assert D.fields == {}

    set_definitions(A, definitions)

    assert A.fields["b"].definitions is definitions
    assert B.fields["c"].definitions is definitions
    assert C.fields["d"].definitions is definitions



# Generated at 2022-06-12 15:56:36.298922
# Unit test for function set_definitions
def test_set_definitions():
    assert TestSchema.__dict__.get('fields') is None
    TestSchema()
    assert TestSchema.__dict__.get('fields') is not None
    assert TestSchema.fields.__class__ == dict
    assert TestSchema.fields.get('definitions') is not None
    assert TestSchema.fields.get('definitions').definitions is None
    TestSchema(definitions = {})
    assert TestSchema.fields.get('definitions').definitions is not None
    assert TestSchema.fields.get('definitions').definitions.__class__ == dict
    definitions = {'test_schema': TestSchema, 'test_schema2': TestSchema2}
    TestSchema(definitions = definitions)
    assert TestSchema.fields.get('ref_field').definitions is not None

# Generated at 2022-06-12 15:56:41.974679
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Schema1(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    obj = Schema1(field1=1, field2=2, field3=3)
    assert list(obj.__iter__()) == ['field1', 'field2', 'field3']

    obj = Schema1(field2=2)
    assert list(obj.__iter__()) == ['field2']


# Generated at 2022-06-12 15:56:48.608056
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.fields import String

    class MySchema(Schema):
        username: String
        password: String
        # email: String

    obj = MySchema({"username": "alice", "password": "12345"})
    # assert obj.username == "alice"
    # assert obj.password == "12345"
    assert obj.is_sparse
    assert obj["username"] == "alice"
    assert obj["password"] == "12345"

    obj = MySchema(username="alice", password="12345")
    assert obj.username == "alice"
    assert obj.password == "12345"
    assert obj.is_sparse is False
    assert obj["username"] == "alice"
    assert obj["password"] == "12345"
    assert obj.__repr__()

# Generated at 2022-06-12 15:57:01.508125
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(title="Name", required=True)
        age = Integer(title="Age", min_value=0)
    
    p1 = Person(name="Amal", age=17)
    print("The given Person is valid.")
    print("Person name: ", p1.name)
    print("Person age: ", p1.age)
    p2 = Person(name="Amal")
    print("The given Person is valid.")
    print("Person name: ", p2.name)
    print("Person age: ", p2.age)


# Generated at 2022-06-12 15:57:12.012944
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = Field()

    class PersonWithDefaults(Person):
        age = Field(default=10)

    class Address(Schema):
        street = Field()
        city = Field()

    class People(Schema):
        people = Array(items=Reference(Person))

    class PeopleWithDefaults(Schema):
        people = Array(items=Reference(PersonWithDefaults))

    class AddressMap(Schema):
        addresses = Object(properties={"address": Reference(Address)})

    assert Person.fields["name"].definitions is None

    assert PersonWithDefaults.fields["name"].definitions is None
    assert PersonWithDefaults.fields["age"].definitions is None

    assert Address.fields["street"].definitions is None

# Generated at 2022-06-12 15:57:16.510253
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field(String())
        b = Field(Integer())
        c = Field(Integer())

    f1 = Foo(a='foo', b=2, c=3)
    f2 = Foo(a='foo', b=2, c=3)
    assert f1 == f2
    f3 = Foo(a='foo', b=2)
    assert not (f1 == f3)
    assert f1 != f3
    assert f1.__eq__(f3) == False
    assert f1.__eq__(f3) == NotImplemented


# Generated at 2022-06-12 15:57:29.109412
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name = str
        age = int

    test_schema = TestSchema()

    assert test_schema.name is None
    assert test_schema.age is None

    test_schema = TestSchema(name='Alex', age=30)

    assert test_schema.name == 'Alex'
    assert test_schema.age == 30

    test_schema = TestSchema({'name': 'Alex', 'age': 30})

    assert test_schema.name == 'Alex'
    assert test_schema.age == 30

    test_schema = TestSchema(name='Alex')

    assert test_schema.name == 'Alex'
    assert test_schema.age is None

    test_schema = TestSchema({'age': 30})


# Generated at 2022-06-12 15:57:33.559176
# Unit test for function set_definitions
def test_set_definitions():
    class AddressSchema(Schema):
        street = String()
        city = String()

    class PersonSchema(Schema):
        name = String()
        address = Reference("AddressSchema")

    definitions = SchemaDefinitions()
    set_definitions(PersonSchema.fields["address"], definitions)
    assert definitions == {"AddressSchema": AddressSchema}

# Generated at 2022-06-12 15:57:45.065252
# Unit test for function set_definitions
def test_set_definitions():
    class SubSchema(Schema):
        field = Field()

    class MainSchema(Schema):
        ref = Reference(SubSchema)
        array = Array(Reference(SubSchema))

    schema = MainSchema()

    def get_definitions(field: Field) -> typing.Type["SubSchema"]:
        return field.definitions["SubSchema"]

    assert get_definitions(schema.fields["ref"]) == SubSchema
    assert get_definitions(schema.fields["array"]) == SubSchema
    assert get_definitions(schema.fields["array"].items) == SubSchema

    class Definitions(Mapping):
        def __init__(self) -> None:
            self._definitions = {}  # type: typing.Dict[str, typing.Type[Schema]]

       

# Generated at 2022-06-12 15:57:54.024089
# Unit test for constructor of class Schema

# Generated at 2022-06-12 15:58:01.961330
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String(description="Name of the person.")
        email = String(description="Address of the person.")

    p1 = Person(name="John", email="johndoe@gmail.com")
    p2 = Person(name="Jane", email="johndoe@gmail.com")
    p3 = Person(name="John", email="johndoe@gmail.com")
    assert p1 == p3
    assert p1 != p2



# Generated at 2022-06-12 15:58:11.184839
# Unit test for function set_definitions
def test_set_definitions():
    # Set up a nested schema
    class SchemaOne(Schema):
        foo = String()
    class SchemaTwo(Schema):
        bar = String()
        one = Reference("SchemaOne")
    
    definitions = SchemaDefinitions()
    definitions["SchemaOne"] = SchemaOne
    definitions["SchemaTwo"] = SchemaTwo
    set_definitions(SchemaTwo.fields["one"], definitions)
    
    # Test correct behaviour
    assert SchemaTwo.fields["one"].target is SchemaOne

    # Test error behaviour
    with pytest.raises(AssertionError):
        definitions["SchemaOne"] = String()


# Unit tests for class Schema

# Generated at 2022-06-12 15:58:16.823057
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        title = "test"
        definitions = SchemaDefinitions()
        foo = Reference("Item", definitions=definitions)
        bar = Array(
            Reference("Item", definitions=definitions),
            title="bar",
            description="bar",
        )

    class Item(Schema):
        title = "item"
        bar = "int"

    TestSchema.foo.definitions.Should.be(TestSchema.definitions)
    TestSchema.bar.items.definitions.Should.be(TestSchema.definitions)

# Generated at 2022-06-12 15:58:45.453500
# Unit test for method validate of class Reference
def test_Reference_validate():
    definitions = SchemaDefinitions()
    class User(Schema):
        name = String()
        age = Integer()

    class Post(Schema):
        title = String(max_length=100)
        body = String(format="multiline")
        author = Reference(to=User, definitions=definitions)

    user = User(name='t', age=1)
    post = Post(title='t', body='t', author=user)
    post.author = user
    valid = post.validate()
    # Compare all attributes
    assert valid.name == post.name
    assert valid.body == post.body
    assert valid.author.name == post.author.name
    assert valid.author.age == post.author.age


# Generated at 2022-06-12 15:58:52.418451
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class X(Schema):
        a = True
        b = 123
        c = 1.23
        d = "abc"
        e = Array(items=Integer(minimum=0, maximum=9))
        f = Reference(to="X")

    x1 = X(a="true", b=123, c=1.23, d="abc", e=[0, 1, 2], f=None)
    x2 = X(a=True, b=123, c=1.23, d="abc", e=[0, 1, 2], f=None)
    assert x1 == x2


# Generated at 2022-06-12 15:59:03.706616
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        class Meta:
            definitions = {
                "Person": Person,
            }

        name = Field(type=str)
        gender = Reference("Gender")
        pets = Array(Reference("Pet"))

    class Pet(Schema):
        name = Field(type=str)
        animal_type = Reference("Animal")

    class Animal(Schema):
        name = Field(type=str)

    class Gender(Schema):
        name = Field(type=str)
    # ensure we have a setting for "name"
    assert Pet.fields["name"].definitions is None
    # ensure setting is set
    set_definitions(Pet.fields["name"], Person.Meta.definitions)
    assert Pet.fields["name"].definitions == Person.Meta.definitions
    # ensure setting gets set for

# Generated at 2022-06-12 15:59:09.743415
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    validator = Object(
        properties={"foo": Field(type="string"), "bar": Field(type="number")},
        required=["foo"],
    )
    class MySchema(Schema):
        validators = {"to_primitive": validator}
        my_string = String(title="A String")
        my_integer = Integer(title="An Integer")
    schema = MySchema(my_string="FOO", my_integer=123)
    assert schema["my_string"] == "FOO"
    assert schema["my_integer"] == 123

# Generated at 2022-06-12 15:59:15.870922
# Unit test for function set_definitions
def test_set_definitions():
    class Test:
        pass
    Test.definitions = SchemaDefinitions()
    class TestSchema(Schema):
        test = Reference(
            "Test",
            definitions=Test.definitions,
            description="this is a description",
        )
    Test.definitions["Test"] = TestSchema
    assert Test.definitions["Test"].fields["test"].definitions is Test.definitions


# Generated at 2022-06-12 15:59:25.899876
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import pytest
    from .schema import Schema
    from .field import Field
    from .array import Array
    from .object import Object
    from .reference import Reference
    from .boolean import Boolean
    from .string import String
    from .types import date
    
    
    
    
    
    
    
    
    
    
    
    
    class Array_of_Type(Array):
        items = String()
    
    
    
    
    
    
    
    
    
    
    
    
    class Object_of_Type(Object):
        properties = {'name': String(), 'age': String(), 'enabled': String()}
        required = ['name', 'age', 'enabled']
    
    
    
    
    
    
    
    
    
    
    
    
   

# Generated at 2022-06-12 15:59:32.464508
# Unit test for function set_definitions
def test_set_definitions():
    import pytest

    class FooBar(Schema):
        baz = Reference('Baz')

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions({
        'Baz': Baz
    })

    fb = FooBar()

    set_definitions(fb.baz, definitions)

    assert isinstance(fb.baz.target, Baz)

    with pytest.raises(AssertionError):
        set_definitions(fb.baz, definitions)


test_set_definitions()

# Generated at 2022-06-12 15:59:37.265091
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class User(Schema):
        id = String()
        name = String()
    
    user1 = User(id='1', name='Jhon')
    user2 = User(id='1', name='Peter')
    user3 = User(id='1', name='Jhon')

    assert user1 == user3
    assert user2 != user3


# Generated at 2022-06-12 15:59:43.517984
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Book(Schema):
        title: str
        year: int

    assert isinstance(Book.fields, dict)
    assert len(Book.fields) == 2
    assert 'title' in Book.fields
    assert isinstance(Book.fields['title'], Field)
    assert 'year' in Book.fields
    assert isinstance(Book.fields['year'], Field)


# Generated at 2022-06-12 15:59:53.439397
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import json
    # Test for class Schema

    class PetSchema(Schema):
        class Meta:
            title = "Pet"
            type = "object"
            required = ["kind", "name"]
            definitions = {
                "breed": {
                    "type": "string",
                    "enum": ["pug", "beagle", "bulldog", "terrier", "poodle"],
                }
            }

        kind = Reference("breed")
        name = Reference("breed")
        born = Field(format="date")

    pet = PetSchema({"kind": "pug", "name": "Baxter"})
    assert sorted(pet.keys()) == ["kind", "name"]

