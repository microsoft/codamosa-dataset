

# Generated at 2022-06-12 15:51:00.869021
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Test1(Object):
        class Meta:
            definitions = SchemaDefinitions()

        field1 = String()
        field2 = String()
    Test1
    class Test1(Object):
        class Meta:
            definitions = SchemaDefinitions()

        field1 = String()
        field2 = String()
    Test1

# Generated at 2022-06-12 15:51:04.488205
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Integer
    from typesystem.typing import NonNullable

    class Person(Schema):
        name = NonNullable(str)
        age = Integer()

    p = Person(name="Bob", age=35)
    assert p["name"] == "Bob"
    assert p["age"] == 35



# Generated at 2022-06-12 15:51:13.104743
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        def __init__(self):
            self.a = "a"
            self.b = "b"
            self.c = [{'d': 'd'}]

    class Bar(Schema):
        def __init__(self):
            self.e = "e"
            self.f = "f"
            self.g = {}
            self.h = []

        foo = Reference('Foo')

    definitions = SchemaDefinitions()
    definitions['Foo'] = Foo

    bar = Bar()
    bar.foo = Foo()
    bar.g["hello"] = "world"

    set_definitions(bar, definitions)
    assert isinstance(bar.foo, Reference)


    # A list of object is not considered an array of Reference
    # fields

# Generated at 2022-06-12 15:51:13.965266
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass


# Generated at 2022-06-12 15:51:21.596258
# Unit test for constructor of class Schema
def test_Schema():
    class S(Schema):
        first_name = String(required=False)
        last_name = String(required=False)
        age = Integer(required=False)
    s = S({"first_name": "John", "last_name": "Smith", "age": 89})
    assert s["first_name"] == "John"
    assert s["age"] == 89
    assert s.first_name == "John"
    assert s.last_name == "Smith"
    assert s.age == 89
    assert len(s) == 3
    assert (s.first_name, s.last_name, s.age) == ("John", "Smith", 89)
    assert str(s) == "S(first_name='John', last_name='Smith', age=89)"

# Generated at 2022-06-12 15:51:32.394199
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    definitions = SchemaDefinitions()
    class DummySchema(Schema, definitions = definitions):
        # TODO: FIXME: we should not have to do this! the base class
        # should be creating a 'fields' attribute.
        fields = {}
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(self, *args, **kwargs)

    assert DummySchema.fields == {}
    assert DummySchema.__class__.__name__ == 'SchemaMetaclass'
    assert DummySchema.__class__.__bases__ == (type,)
    assert definitions['DummySchema'] == DummySchema
    assert isinstance(DummySchema, type)


# Generated at 2022-06-12 15:51:41.957741
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        first_name = String(required=True)
        last_name = String()

    class Team(Schema):
        members = Array(items=Reference(Person))
        leader = Reference(Person)

    definitions = SchemaDefinitions()
    assert getattr(Person.fields["first_name"], "definitions", None) is None
    set_definitions(Team, definitions)
    assert getattr(Person.fields["first_name"].definitions, "_definitions", None) is not None
    assert len(getattr(Person.fields["first_name"], "definitions", {})) == 2

# Generated at 2022-06-12 15:51:51.605404
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import typesystem

    class User(Schema):
        id = typesystem.Integer(min_value=1)
        name = typesystem.String(max_length=255)

    user = User(id=1, name="John Smith")
    assert user == user
    assert user == User(id=1, name="John Smith")
    assert user == {"id": 1, "name": "John Smith"}
    assert user == User(id=1, name="John Smith")
    assert not user == {"id": 2, "name": "John Smith"}
    assert not user == {"id": 1, "name": "John Smith", "age": 33}
    assert not user == {"id": 1}


# Generated at 2022-06-12 15:51:52.198265
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass

# Generated at 2022-06-12 15:51:58.563268
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = Field()

    class People(Schema):
        definitions = SchemaDefinitions()
        people = Array(Reference("Person"))

    assert isinstance(People.fields["people"].items, Reference)
    assert People.fields["people"].items.definitions == People.definitions


# Unit tests for class Schema.make_validator

# Generated at 2022-06-12 15:52:19.345896
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        field = Reference("Reference", to="Reference")

        class Meta:
            definitions = SchemaDefinitions(Reference=str)

    # Test a string type
    TestSchema.validate({"field": "ok"})
    TestSchema.validate_or_error({"field": "ok"})
    
    # Test a wrong type
    try:
        TestSchema.validate({"field": 2})
    except ValidationError as e:
        assert e.text == "Invalid value. Expected a string, but got 2."
    try:
        TestSchema.validate_or_error({"field": 2})
    except ValidationError as e:
        assert e.text == "Invalid value. Expected a string, but got 2."

# Generated at 2022-06-12 15:52:21.674944
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class User(Schema):
        username = Field(str)

    assert User(username="foo") == User(username="foo")

# Generated at 2022-06-12 15:52:31.161056
# Unit test for function set_definitions
def test_set_definitions():
    # type: () -> None

    class First(Schema):
        name = Reference("Second")
    
    class Second(Schema):
        name = Reference("Third")
    
    class Third(Schema):
        name = Reference("Fourth")
    
    class Fourth(Schema):
        name = Reference("First")

    class Fifth(Schema):
        name = Reference("First")

    definitions = SchemaDefinitions()
    definitions["First"] = First
    definitions["Second"] = Second
    definitions["Third"] = Third
    definitions["Fourth"] = Fourth
    definitions["Fifth"] = Fifth

    assert First.fields["name"].definitions is None
    assert Second.fields["name"].definitions is None
    assert Third.fields["name"].definitions is None
    assert Fourth.fields["name"].definitions is None

# Generated at 2022-06-12 15:52:34.303440
# Unit test for function set_definitions
def test_set_definitions():
    assert set_definitions(Reference("Doc"), SchemaDefinitions({ "Doc": Document }))
    assert set_definitions(Document.title, SchemaDefinitions({ "Reference": Reference }))


# Generated at 2022-06-12 15:52:38.803453
# Unit test for constructor of class Schema
def test_Schema():
    class Test1(Schema):
        a = Field(type="int")
        b = Field(type="string")
    print("Test1(a=1, b='2')" + " -> " + str(Test1(a=1, b='2')))
    print("Test1(a=1)" + " -> " + str(Test1(a=1)))
    print("Test1(b='2')" + " -> " + str(Test1(b='2')))
    print("Test1()" + " -> " + str(Test1()))
    class Test2(Schema):
        a = Field(type="int")
        b = Field(type="string")
        c = Field(type="int", default=10)

# Generated at 2022-06-12 15:52:46.872689
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typing import Sequence, Mapping
    from abc import ABCMeta
    from collections.abc import Mapping, MutableMapping
    class SchemaDefinitions(MutableMapping):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            self._definitions = dict(*args, **kwargs)  # type: dict

        def __getitem__(self, key: typing.Any) -> typing.Any:
            return self._definitions[key]

        def __iter__(self) -> typing.Iterator[typing.Any]:
            return iter(self._definitions)

        def __len__(self) -> int:
            return len(self._definitions)


# Generated at 2022-06-12 15:52:58.120279
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class User(Schema):
        id = Integer()

    class Group(Schema):
        membership = Reference("User")
        owner = Reference("User")

    class Comment(Schema):
        body = String()
        author = Reference("User")

    class Post(Schema):
        title = String()
        content = String()
        author = Reference("User")
        comments = Array(items=Reference("Comment"))

    set_definitions(Post.make_validator(), definitions)
    assert (
        type(Post.fields["author"].target) == type(User.make_validator())
    ), "Reference to the User schema is broken"

    set_definitions(User.make_validator(), definitions)

# Generated at 2022-06-12 15:52:58.848904
# Unit test for function set_definitions
def test_set_definitions():
    pass

# Generated at 2022-06-12 15:53:10.503677
# Unit test for constructor of class Reference
def test_Reference():

    class Color(Schema):
        shade = Field(str)
        brightness = Field(int)

    class Person(Schema):
        name = Field(str)
        favorite_color = Reference(Color)

    field = Person.fields["favorite_color"]
    assert field.to == Color
    assert field.target_string == "Color"
    assert field.target == Color

    from typesystem.base import ValidationResult
    from typesystem.fields import String
    from typesystem.primitives import is_primitive

    # Test non-primitive target
    class A(Schema):
        b = Reference(Color)

    field = A.fields["b"]
    assert field.to == Color
    assert isinstance(field.target, Field)
    assert field.target.__class__ == Object
    assert field.target.properties == Color

# Generated at 2022-06-12 15:53:11.796389
# Unit test for constructor of class Schema
def test_Schema():
    # TODO: implement this unit test
    pass


# Generated at 2022-06-12 15:53:30.208482
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Mapping, metaclass=SchemaMetaclass):
        fields: typing.Dict[str, Field] = {}

        def __init__(self, *args: typing.Any) -> None:
            for arg in args:
                print(arg, " ", end='')

        def __getitem__(self, key: typing.Any) -> typing.Any:
            try:
                field = self.fields[key]
            except KeyError:
                raise KeyError(key) from None
            return field

        def __iter__(self) -> typing.Iterator[str]:
            for key in self.fields.keys():
                yield key

        def __len__(self) -> int:
            return len(self.fields)
    #print("\tget_default_value()")
    #print("\

# Generated at 2022-06-12 15:53:38.459030
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = String()

    class People(Schema):
        people = Array(items=Reference(to=Person))

    assert isinstance(People.fields["people"].items, Reference)
    assert People.fields["people"].items.definitions is None

    definitions = SchemaDefinitions()
    set_definitions(People, definitions)

    assert isinstance(People.fields["people"].items, Reference)
    assert People.fields["people"].items.definitions == definitions



# Generated at 2022-06-12 15:53:48.011053
# Unit test for constructor of class Schema
def test_Schema():
    class Dog(Schema):
        name = Field(str, required=True)
        age = Field(int, default=2)
        bark = Field(bool, default=True)

    class Person(Schema):
        name = Field(str)
        age = Field(int, default=30)
        dog = Field(Reference("Dog"))

    # Test raise error
    try:
        a = Person(name="bob", age=None, dog=Dog(name="Boby", age=1))
    except ValueError as err:
        assert(err.args[0]=="Field age did not validate. May not be null.")

    # Test object with
    # a) schema as argument
    # b) dict as argument
    # c) object as argument

# Generated at 2022-06-12 15:53:55.035487
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    test_cases = [
        ('item', 'item'),
        ('item 1', 'item 2'),
        ('item 1', 'item 1'),
        ('item 1', 'item 3'),
        ('item 1', 'item 4'),
    ]

    for expected, test in test_cases:
        assert Schema.__getitem__(test) == expected


# Generated at 2022-06-12 15:53:58.368026
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class A(Schema):
        x = 1
    a = A()
    # The iterator function should return keys for the fields that are present in object a
    assert [1] == [i for i in a]


# Generated at 2022-06-12 15:53:59.631417
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    x = Schema()
    assert len(list(x)) == 0



# Generated at 2022-06-12 15:54:01.818515
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Schema, String

    class User(Schema):
        name = String()

    len(User(name="Guido")) == 1


# Generated at 2022-06-12 15:54:05.013070
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()

    assert repr(Person(name='Mike')) == "Person(name='Mike')"

# Generated at 2022-06-12 15:54:09.307057
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class User(Schema):
        username = Field(str)
        password = Field(str)

    instance01 = User(username = "YAWEN", password = "123")
    instance02 = User()
    assert list(instance01) == list(["username", "password"])
    assert list(instance02) == []


# Generated at 2022-06-12 15:54:17.040170
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Integer, Number, String
    from collections import namedtuple

    class Person(Schema, metaclass=SchemaMetaclass):
        name = String()
        age = Integer()
        height = Number()

    assert [key for key in Person()] == ['name', 'age', 'height']

    # with namedtuple
    Person = namedtuple('Person', ('name', 'age', 'height'))
    assert [key for key in Person('John', 32, 1.8)] == ['name', 'age', 'height']

    class Person(Schema, metaclass=SchemaMetaclass):
        name = String()
        age = Integer()
        height = Number()


# Generated at 2022-06-12 15:54:31.138934
# Unit test for function set_definitions
def test_set_definitions():
    # Arrange
    definitions = SchemaDefinitions()
    a = Reference("A", definitions=definitions)
    set_definitions(a, definitions)

    # Act
    # Assert
    assert a.definitions == definitions


# Generated at 2022-06-12 15:54:39.344437
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()
        
    x = Person({'name': 'Jack', 'age': 12})
    y = Person(Person({'name': 'Jack', 'age': 12}))
    assert x == y, 'Failed'
    
    x = Person({'name': 'Jack', 'age': 12})
    y = Person(Person({'name': 'Jack', 'age': 16}))
    assert not x == y, 'Failed'
    
    x = Person({'name': 'Jack', 'age': 12})
    y = Person({'name': 'Jack', 'age': 12, 'gender': 'male'})
    assert not x == y, 'Failed'
    

# Generated at 2022-06-12 15:54:43.133956
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = Field()
        age = Field()
    person = Person(name="John", age=12)
    expected = ['name', 'age']
    assert list(person) == expected


# Generated at 2022-06-12 15:54:51.675135
# Unit test for function set_definitions
def test_set_definitions():
    # This is a class only for the purpose of unit testing function
    # set_definitions().
    class Schema(metaclass=SchemaMetaclass):
        definitions = SchemaDefinitions()

        def __init__(self):
            definitions = self.definitions
            other = OtherSchema()
            other.definitions = definitions
            self.other = other

    class OtherSchema(metaclass=SchemaMetaclass):
        definitions = None

        def __init__(self):
            self.string = "hi"
            self.reference = Reference("OtherOtherSchema")

        def __repr__(self):
            return f"<OtherSchema string={self.string!r} reference={self.reference}>"


# Generated at 2022-06-12 15:54:52.702843
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        foo = Integer()

    assert list(TestSchema(foo=1)) == ['foo']

# Generated at 2022-06-12 15:54:59.393819
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.fields import String

    class PersonSchema(Schema):
        name = String()

    schema = PersonSchema(name="Tony")

    assert schema.name == "Tony"

    try:
        schema = PersonSchema(age="42")
    except TypeError:
        pass
    else:
        raise AssertionError(
            "PersonSchema(age='42') should raise TypeError, but did not."
        )

    schema = PersonSchema(age="42", strict=True)



# Generated at 2022-06-12 15:55:04.386510
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = "hongbin"
        age = 22
        weight = 52

    p = Person(name='hongbin', age=22, weight=52)
    assert len(p) == 3
    assert list(p) == ['name', 'age', 'weight']

    p = Person(age=22)
    assert len(p) == 1
    assert list(p) == ['age']



# Generated at 2022-06-12 15:55:11.727425
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # AssertionError: Definition for 'Test' has already been set.
    class Test(Schema):
        pass
    assert isinstance(Test, type)
    assert Test.__name__ == 'Test'
    assert isinstance(Test.fields, dict)
    assert Test.fields == {}
    def assertRaises(*args, **kwargs):
        try:
            raise AssertionError
        except:
            pass
        else:
            if not return_type:
                return
            return None
    class Test(Schema):
        pass
    assertRaises(TypeError)


# Generated at 2022-06-12 15:55:15.444054
# Unit test for constructor of class Schema
def test_Schema():
    import datetime
    from typesystem import Date

    class Comment(Schema):
        created = Date(default=datetime.date.today)
        text = str

    comment = Comment(created="2018-03-28")
    assert comment.created == datetime.date(2018, 3, 28)
    assert comment.text == ""

# Generated at 2022-06-12 15:55:20.449947
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = Field()
        age = Field(type="integer")

    assert Person(name="John", age="42") == Person(name="John", age=42)
    assert Person(name="John", age="42") != Person(name="John", age="42", is_cool=False)
    assert Person(name="John", age="42") != {"name": "John", "age": 42}

# Generated at 2022-06-12 15:55:33.357865
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.fields import String

    class Item(Schema):
        name = String()
        price = String()


    item = Item(name="Tom", price="167.99")
    assert item['price'] == '167.99'

# Generated at 2022-06-12 15:55:39.804223
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field_1 = Integer(minimum=10)
        field_2 = Integer(maximum=20)
    obj_1 = TestSchema(field_1=10, field_2=20)
    obj_2 = TestSchema(field_1=10, field_2=20)
    obj_3 = TestSchema(field_1=10)
    assert obj_1 == obj_2
    assert obj_1 != obj_3



# Generated at 2022-06-12 15:55:47.115049
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    """SchemaMetaclass.__new__"""

    # Setup
    class TestSchema(Schema):
        field_1: Field = 'a_field_1'
        field_2: Field = 'a_field_2'
    TestSchema._definitions = SchemaDefinitions()

    # Exercise
    TestSchema.fields

    # Verify
    assert TestSchema.fields == {'field_1': 'a_field_1', 'field_2': 'a_field_2'}
    assert TestSchema._definitions == {'TestSchema': TestSchema}



# Generated at 2022-06-12 15:55:49.530840
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class PersonSchema(Schema):
        name = Field(str)
        age = Field(int)

    person1 = PersonSchema(name="John", age=32)
    person2 = PersonSchema(name="John", age=32)
    assert person1 == person2

# Generated at 2022-06-12 15:55:55.581113
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class S1(Schema):
        int_field = Field(type="integer")
        str_field = Field(type="string")

    s1 = S1(int_field=42, str_field="Hello World")
    assert len(s1) == 2

    s2 = S1(int_field=42)
    assert len(s2) == 1

    s3 = S1()
    assert len(s3) == 0

    class S2(Schema):
        int_field = Field(type="integer")
        str_field = Field(type="string")

    s4 = S2(int_field=42, str_field="Hello World")
    assert len(s4) == 2

    s5 = S2(int_field=42)
    assert len(s5) == 1

    s6 = S

# Generated at 2022-06-12 15:55:59.054247
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
	try:
		with pytest.raises(AttributeError) as e_info:
			Schema.__iter__()
	except:
		print('AttributeError not raised')


# Generated at 2022-06-12 15:56:00.930864
# Unit test for function set_definitions
def test_set_definitions():
    class Child(Schema):
        pass

    class Parent(Schema):
        child = Reference("Child")

    definitions = SchemaDefinitions()
    set_definitions(Parent.child, definitions)
    assert definitions["Child"] == Child

# Generated at 2022-06-12 15:56:01.945620
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert True



# Generated at 2022-06-12 15:56:07.153619
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field(int)
        b = Field(int)

    assert A(a=1, b=2) == A(a=1, b=2)
    assert A(a=1, b=2) != A(a=2, b=2)
    assert A(a=1, b=2) != A(a=1, b=1)
    assert A(a=1, b=2) != A(a=1)
    assert A(a=1, b=2) != A(b=2)


# Generated at 2022-06-12 15:56:14.434301
# Unit test for function set_definitions
def test_set_definitions():
    class Child(Schema):
        name: str

    class Parent(Schema):
        child: Child
        children: Array[Child]

    definitions = SchemaDefinitions()
    class Undefined(Schema):
        reference: Reference(to="Child")

    set_definitions(Undefined.fields["reference"], definitions)
    set_definitions(
        Undefined.fields["reference"],
        SchemaDefinitions(
            Child=Child,
            Parent=Parent,
            Array=Array,
        ),
    )

# Generated at 2022-06-12 15:56:30.968542
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class User(Schema):
        name = String()
        email = String()
        age = Integer()

    user_data = {
        "name": "Bob",
        "email": "bob@example.com"
    }
    user = User(user_data)

    assert len(user) == 2
    assert len(user_data) == len(user)

    for key in user:
        assert user_data[key] == user[key]

# Generated at 2022-06-12 15:56:34.433807
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class MySchema(Schema):
        title = String(required=True)
        email = String(required=False)

    assert MySchema.fields == {'title': String(required=True), 'email': String(required=False)}

# Generated at 2022-06-12 15:56:35.719680
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert True, "Not implemented"


# Generated at 2022-06-12 15:56:40.694730
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class User(Schema):
        username = String()
        age = Integer()
        email = String(format="email")

    user = User(username="Jane", age=23, email="jane@example.com")
    assert user["username"] == "Jane"
    assert user["age"] == 23
    assert user["email"] == "jane@example.com"



# Generated at 2022-06-12 15:56:48.395172
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestData(Schema):
        id = Field(description="Data identifier")

    data = TestData({"id": "123"})
    schema = Schema({"data": Reference(to="TestData")})

    assert schema.validate({"data": {"id": "123"}}) == {
        "data": {"id": "123"}
    }
    with pytest.raises(ValidationError) as exc_info:
        schema.validate({"data": {"id": 123}})
    assert exc_info.value.messages() == [
        ValidationError(
            path=["data"],
            code="invalid",
            message="Not a valid string.",
        )
    ]
    assert schema.validate({"data": None}, strict=True) == {"data": None}

# Generated at 2022-06-12 15:56:53.920148
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        ref1 = Reference("Bar")
        ref2 = Reference("Bar")
        ref3 = Array(Reference("Bar"))
        ref4 = Array(Reference("Bar"))

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.make_validator(), definitions)
    assert definitions["Bar"] is Bar

# Generated at 2022-06-12 15:56:57.465436
# Unit test for function set_definitions
def test_set_definitions():
    import typesystem

    definitions = SchemaDefinitions()

    class TestSchema(Schema):
        x = typesystem.String()

    set_definitions(TestSchema.fields["x"], definitions)
    assert TestSchema.fields["x"].definitions is definitions

# Generated at 2022-06-12 15:57:00.283123
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import Integer, String

    class SimpleSchema(Schema):
        name = String()
        age = Integer()

    schema = SimpleSchema(name="John Doe", age=42)
    assert schema["name"] == "John Doe"
    assert schema["age"] == 42
    try:
        schema["address"]
    except KeyError:
        pass
    else:
        raise AssertionError("Test failed")


# Generated at 2022-06-12 15:57:06.041403
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.base import String

    class Author(Schema):
        name = String()

    assert issubclass(Author, Mapping)
    assert issubclass(Author, Schema)
    assert isinstance(Author, type)
    assert Author.__name__ == 'Author'

    assert Author.fields == {'name': String()}



# Generated at 2022-06-12 15:57:13.525901
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class SubSchema(Schema):
        name = Field(str)

    class SubSchema2(Schema):
        name = Field(str)

    class Schema(Schema):
        name = Field(str)
        array = Array(str)
        object = Object(SubSchema)
        object2 = Object(SubSchema2)
        ref = Reference(SubSchema, definitions=definitions)

    class Schema2(Schema):
        name = Field(str)
        ref = Reference(SubSchema2, definitions=definitions)
        ref2 = Reference(SubSchema, definitions=definitions)

    class Schema3(Schema):
        name = Field(str)
        ref = Reference(SubSchema2, definitions=definitions)

# Generated at 2022-06-12 15:57:33.075531
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()

    person = Person(name=""), 2

# Generated at 2022-06-12 15:57:44.709802
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class PySchema_Schema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = PySchema_Schema(a=True, b=False, c=None)
    assert sorted(list(schema)) == sorted(['a', 'b', 'c'])

    schema = PySchema_Schema(a=True, b=False)
    assert sorted(list(schema)) == sorted(['a', 'b'])

    schema = PySchema_Schema(a=True)
    assert sorted(list(schema)) == sorted(['a'])

    schema = PySchema_Schema(b=False, c=None)
    assert sorted(list(schema)) == sorted(['b', 'c'])


# Generated at 2022-06-12 15:57:47.834225
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Integer
    from typesystem.schema import Schema
    class MyField(Schema):
        name = Integer()
    assert len(MyField())==1
    assert len(MyField(name=5))==1


# Generated at 2022-06-12 15:57:56.203556
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class SomeSchema(Schema):
        field1 = Integer()
        field2 = String()
    
    # Module execution
    definitions = SchemaDefinitions()
    SomeSchema("", definitions=definitions)
    SomeSchema("")
    definitions["SomeSchema"]
    definitions["SomeSchema2"]
    class SomeSchema2(Schema):
        field3 = String()
    def test_SomeSchema2(SomeSchema2):
        pass
    SomeSchema2("", definitions=definitions)
    SomeSchema2("")
    definitions["SomeSchema2"]
    def test_SomeSchema3(SomeSchema2):
        pass
    class SomeSchema3(SomeSchema2):
        field4 = String()
    SomeSchema3("", definitions=definitions)

# Generated at 2022-06-12 15:58:03.202308
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = Str(max_length=100)
        age = Integer()

    p = Person(name='John', age=30)
    assert sorted(list(p)) == sorted(['name', 'age'])

    p = Person(name='John')
    assert sorted(list(p)) == sorted(['name'])


# Generated at 2022-06-12 15:58:12.285081
# Unit test for constructor of class Reference
def test_Reference():
    from . import Author, AuthorSchema, Book, BookSchema
    
    validator = AuthorSchema.make_validator()
    author = Author(id=1, name="John Doe")
    author_schema = validator.validate(author)

    validator = BookSchema.make_validator()
    book = Book(id=1, name="Book of Python", price=100, author=author_schema)
    book_schema = validator.validate(book)
    print(book_schema)
    assert book_schema.author.id == 1
    assert book_schema.author.name == "John Doe"

if __name__ == "__main__":
    test_Reference()

# Generated at 2022-06-12 15:58:17.545388
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Bar")

    class Bar(Schema):
        bar = Field(str)

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions

    class Foo(Schema):
        foo = Reference("Bar", allow_null=True)

    Foo.make_validator()

# Generated at 2022-06-12 15:58:20.036768
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Data(Schema):
        a = "a"
    d = Data.validate({"a":1})
    assert len(d) == 1


# Generated at 2022-06-12 15:58:29.023850
# Unit test for constructor of class Schema
def test_Schema():
    A = Schema(
        foo = Field(required = True),
        bar = Field(required = False)
        )
    result = A(foo = 1, bar = 2)
    assert(result.foo == 1 and result.bar == 2)
    result = A(bar = 2, foo = 1)
    assert(result.foo == 1 and result.bar == 2)
    exception = False
    try:
        result = A()
    except Exception as e:
        exception = True
        print(e)
    assert(exception == True)
    exception = False
    try:
        result = A(foo = 1)
    except Exception as e:
        exception = True
        print(e)
    assert(exception == True)
    exception = False

# Generated at 2022-06-12 15:58:32.623002
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import String, Number

    class Person(Schema):
        name = String
        age = Number

    p = Person(name="John", age=30)
    assert len(p)==2

    p = Person(name="John")
    assert len(p)==1


# Generated at 2022-06-12 15:59:14.800449
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        name = Field()
        age = Field()
        address = Field()
        phone = Field(allow_null=True)

    s = MySchema(name='Gaurav', age=35, address='India', phone=None)
    assert list(s) == ['name', 'age', 'address']

# Generated at 2022-06-12 15:59:19.141234
# Unit test for constructor of class Reference
def test_Reference():
    from .models import Author, Book
    author = Author('test')
    reference = Reference(to=Author)
    # __init__
    assert reference.to == Author
    # validate
    reference.validate(author)
    # serialize
    reference.serialize(author)
    # to_string
    assert reference.to_string() == "Reference to 'Author'"

# Generated at 2022-06-12 15:59:25.731134
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import typesystem
    class S(Schema):
            field1 = typesystem.Integer()
            field2 = typesystem.Integer()

    s = S(field1=1, field2=2)
    s_eq = S(field1=1, field2=2)
    s_ne = S(field1=2, field2=2)

    assert s == s_eq, "Should be equal"
    assert s != s_ne, "Should not be equal"



# Generated at 2022-06-12 15:59:32.492668
# Unit test for constructor of class Schema
def test_Schema():
    # Test of argument: args
    args = [{'name': 'test', 'age': 23, 'sex': 'M'}]
    try:
        assert Schema(*args)
    except AssertionError:
        print("Schema test 1 failed")
    else:
        print("Schema test 1 passed")

    # Test of argument: kwargs
    kwargs = {'name': 'test', 'age': 23, 'sex': 'M'}
    try:
        assert Schema(**kwargs)
    except AssertionError:
        print("Schema test 2 failed")
    else:
        print("Schema test 2 passed")

if __name__ == '__main__':
    test_Schema()

# Generated at 2022-06-12 15:59:37.635195
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    b = bool
    # Create a new class (see the definition of the class)
    d = str
    # Create a new class (see the definition of the class)
    class T(Schema):
        # A string that must contain a decimal integer
        a = Integer()
        # A string that must contain a decimal integer
        b = Integer()
        # A string that must contain a decimal integer
        c = Integer()
    T()
    # Create a new class (see the definition of the class)
    class T(Schema):
        # A string that must contain a decimal integer
        a = Integer()
        # A string that must contain a decimal integer
        b = Integer()
        # A string that must contain a decimal integer
        c = Integer()

    # Create a new class (see the definition of the class)

# Generated at 2022-06-12 15:59:42.569674
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema('')) == 0
    assert len(Schema('', a=1)) == 1
    assert len(Schema('', a=1, b=2)) == 2
    assert len(Schema('', a=1, b=2, c=3)) == 3


# Generated at 2022-06-12 15:59:53.794460
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    _Schema__1_fields = {'a': Float(), 'b': Integer()}
    _Schema__2_fields = {'a': Float(), 'b': Integer()}
    _Schema__1 =  SchemaMetaclass.__new__(SchemaMetaclass, 'Schema__1', (object), {'a': Float(), 'b': Integer()}, _Schema__1_fields)
    _Schema__2 =  SchemaMetaclass.__new__(SchemaMetaclass, 'Schema__2', (object), {'a': Float(), 'b': Integer()}, _Schema__2_fields)

    assert _Schema__1.fields == {'a': Float(), 'b': Integer()}
    assert _Schema__2.fields == {'a': Float(), 'b': Integer()}




# Generated at 2022-06-12 16:00:03.355446
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import pytest
    from collections import OrderedDict
    from typesystem import Integer, Object, String

    class AddressSchema(Schema):
        street = String()
        zip_code = Integer()

    class UserSchema(Schema):
        name = String()
        addresses = Array(items=AddressSchema())

    address1 = AddressSchema(street="123 Fake Street", zip_code=12345)
    address2 = AddressSchema(street="456 Different Road", zip_code=45678)
    user1 = UserSchema(name="Joe Bloggs", addresses=[address1, address2])
    user1_dup = UserSchema(name="Joe Bloggs", addresses=[address1, address2])
    user2 = UserSchema(name="Jane Doe", addresses=[address1, address2])
    user3 = User

# Generated at 2022-06-12 16:00:09.046137
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from .schema_tests import TestSchema

    assert TestSchema(x=1, y=2) == TestSchema(x=1, y=2)
    assert TestSchema(x=1, y=2) != TestSchema(x=1, y=3)
    assert TestSchema(x=1, y=2) != TestSchema(x=3, y=2)

