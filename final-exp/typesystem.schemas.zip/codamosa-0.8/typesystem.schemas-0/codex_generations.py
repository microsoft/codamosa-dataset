

# Generated at 2022-06-12 15:50:50.718367
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Define a schema
    class User(Schema):
        name = String(max_length=100)

    # Define a schema that references to User
    class Organization(Schema):
        owner = Reference('User')
        members = Array(Reference('User'))

    # Initialize a Organization
    u = User(name='Luis')
    org = Organization(owner=u, members=[u, u])
    assert isinstance(org.owner, User), \
        'owner of Organization should be a User instance'
    assert isinstance(org.members, list), \
        'members of Organization should be a list of User instances'

    # Test the case where the target of the reference is not a subclass of Schema

# Generated at 2022-06-12 15:51:00.519791
# Unit test for constructor of class Reference
def test_Reference():
    import time
    import typesystem
    from typesystem import String, Number, Integer, Object

    class Test(typesystem.Schema):
        name = String(max_length=10)
        age = Integer(minimum=18, maximum=70)

        class Meta:
            target_namespace = "https://example.com/schema/test/"

    class Person(typesystem.Schema):
        name = String(max_length=10)
        age = Integer(minimum=18, maximum=70)
        friends = Array(items=Reference("Test"))

    definitions = typesystem.SchemaDefinitions()
    person = Person(definitions=definitions)

    test = Test(definitions=definitions)

    person.validate_or_error(dict(name="John", age=10))

# Generated at 2022-06-12 15:51:01.050013
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass

# Generated at 2022-06-12 15:51:04.076605
# Unit test for method validate of class Reference
def test_Reference_validate():
    assert Reference('A', definitions={'A': {'a': 100, 'b': 200}}).validate({'a': 100, 'b': 200}) == {'a': 100, 'b': 200}
    return 'test Reference.validate() passed'


# Generated at 2022-06-12 15:51:06.211798
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    person = Person(name="Bob", age=36)
    repr(person)

# Generated at 2022-06-12 15:51:11.582706
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        prop1 = String()
        prop2 = String()
        prop3 = String(default='foo')
    assert repr(TestSchema({'prop1': 'bar', 'prop2': 'baz'})) == "TestSchema(prop1='bar', prop2='baz') [sparse]"
    assert repr(TestSchema()) == "TestSchema(prop3='foo') [sparse]"
    assert repr(TestSchema({'prop1': 'bar', 'prop2': 'baz', 'prop3': 'foo'})) == "TestSchema(prop1='bar', prop2='baz', prop3='foo')"

# Generated at 2022-06-12 15:51:18.722719
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class ClassRoom(Schema):
        name = String()
        class_master = String()
        citizen = String()

    room1 = ClassRoom(
        name = "Class 1",
        class_master = "Teacher 1",
        citizen = "Student 1",
    )

    room2 = ClassRoom(
        name = "Class 1",
        class_master = "Teacher 1",
        citizen = "Student 1",
    )

    assert room1 == room2


# Generated at 2022-06-12 15:51:23.305425
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Foo(Schema):
        a = Reference("Bar")

    class Bar(Schema):
        b = Field()

    set_definitions(Foo.fields["a"], definitions)
    assert Foo.fields["a"].definitions is definitions
    assert Bar.fields["b"].definitions is definitions

# Generated at 2022-06-12 15:51:24.994495
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert Schema().__iter__() == []                                                           # guess 1



# Generated at 2022-06-12 15:51:34.398819
# Unit test for constructor of class Schema
def test_Schema():
    class SimpleSchema(Schema):
        name = Field(str)
        age = Field(int, default=30)
    # all kwargs
    s = SimpleSchema(name="a")
    # one positional arg
    s = SimpleSchema({"name": "a"})
    # no positional arg and no kwargs
    s = SimpleSchema()
    # one positional arg with extra kwargs
    s = SimpleSchema({"name": "a"}, age=10)
    # no positional arg and some kwargs
    s = SimpleSchema(age=10)
    # no positional arg and some kwargs
    s = SimpleSchema(age=10)


# Generated at 2022-06-12 15:51:45.002087
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    s = Schema()
    assert len(s)==0
    s = Schema(a =1)
    assert len(s)==1


# Generated at 2022-06-12 15:51:48.841741
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field(type="number")
    schema = TestSchema()
    result = len(schema)
    assert result == 0, f"Actual: {result}"

# Generated at 2022-06-12 15:51:59.742882
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Somebody(Schema):
        first_name = String()
        last_name = String(default="")
        age = Integer(minimum=0)

    s1 = Somebody(first_name="Abdul", age=20)
    s2 = Somebody(first_name="Abdul", last_name="", age=20)
    s3 = Somebody(first_name="Abdul", last_name="", age=19)
    s4 = Somebody(first_name="Smith", last_name="", age=20)
    s5 = Somebody(first_name="Abdul", age=20)
    assert s1 != s2
    assert s1 != s3
    assert s1 != s4
    assert s1 == s5

# Generated at 2022-06-12 15:52:05.968665
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Arrange
    class Account(Schema):
        name = String(max_length=10)
        email = String(max_length=20)
        age = Integer(minimum=0)

        def __repr__(self) -> str:
            return f"{self.name!r}"
    
    class User(Schema):
        account = Reference(to='Account')
    
    my_account = Account(name='Juan', email='juan@gmail.com', age=25)
    user = User(account=my_account)
    definitions = SchemaDefinitions()
    definitions['Account'] = Account

    # Act
    result = Reference.validate(my_account, definitions=definitions)

    # Assert
    assert result == my_account


# Generated at 2022-06-12 15:52:11.540380
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test empty object
    class User(Schema):
        email = String()
    schema = User()
    assert [item for item in schema] == []
    # Test sparse object
    schema = User(email="test@test.com")
    assert [item for item in schema] == ["email"]
    # Test full object
    schema = User(email="test@test.com")
    assert list(schema) == ["email"]


# Generated at 2022-06-12 15:52:23.334746
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class SchemaSub(Schema):
        a = Field(int)
        b = Field(int)
        c = Field(int)

    class SchemaParent(Schema):
        d = Field(int)

    assert list(SchemaSub().__iter__()) == []
    assert list(SchemaSub(a=5).__iter__()) == ['a']
    assert list(SchemaSub(a=5, b=2).__iter__()) == ['a', 'b']
    assert list(SchemaSub(a=5, b=2, c=0).__iter__()) == ['a', 'b', 'c']
    assert list(SchemaParent(d=5).__iter__()) == ['d']

# Generated at 2022-06-12 15:52:25.511568
# Unit test for constructor of class Schema
def test_Schema():
    assert hasattr(Schema, '__init__')
    assert callable(Schema.__init__)



# Generated at 2022-06-12 15:52:27.927307
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    User = Schema("name")
    u1 = User(name="Foo")
    u2 = User(name="Foo")
    assert u1 == u2


# Generated at 2022-06-12 15:52:31.624751
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class UserSchema(Schema):
        name = Field(str)
        age = Field(int)
        # your code
        pass

    assert repr(UserSchema()) == "UserSchema()"
    assert repr(UserSchema(name="Fred")) == "UserSchema(name='Fred')"


# Generated at 2022-06-12 15:52:42.849805
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():

    # Testing the type of the field `object`

    class X(metaclass=SchemaMetaclass):
        field = Field()

    x = X()
    assert isinstance(x.field, Field)

    # Testing the type of the field `list`

    class Y(metaclass=SchemaMetaclass):
        fields = [Field()]

    assert isinstance(Y.fields[0], Field)

    # Testing the type of the field `dict`

    class Z(metaclass=SchemaMetaclass):
        fields = {'k': Field()}

    assert isinstance(Z.fields['k'], Field)

    # Testing the `name` arg of the `__new__` method

    class A(metaclass=SchemaMetaclass):
        pass

    assert A.__name__ == 'A'

# Generated at 2022-06-12 15:52:58.509324
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    fields = {
        "string": Reference(to="string2"),
        "string2": Reference(to=String()),
        "array": Array(items=Reference(to="string")),
        "object": Object(properties={"nested": Reference(to="string2")}),
    }
    for field in fields.values():
        set_definitions(field, definitions)

    assert type(fields["string"]) == Reference
    assert type(fields["array"].items) == Reference
    assert type(fields["object"].properties["nested"]) == Reference

# Generated at 2022-06-12 15:53:04.518553
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Setup
    class MySchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    expected_fields = {'name': Field(type="string"), 'age': Field(type="integer")}

    # Test
    assert MySchema.fields == expected_fields



# Generated at 2022-06-12 15:53:11.682309
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test with valid value
    # expect:
    #   result == 2
    #   result.is_sparse == False
    try:
        result = Schema(first='name', second=12)
        assert result == 2
        assert result.is_sparse == False
    except Exception:
        assert False

    # Test with invalid value
    # expect:
    #   result.is_sparse == True
    try:
        result = Schema(first='name')
        assert result.is_sparse == True
    except Exception:
        assert False


# Generated at 2022-06-12 15:53:17.661375
# Unit test for function set_definitions
def test_set_definitions():
    d1 = SchemaDefinitions()
    d2 = SchemaDefinitions()
    db = {"a": 1}
    dc = {"a": 2}

    d3 = SchemaDefinitions(b=db, c=dc)

    f1 = Reference(to="b", definitions=d1)
    f2 = Reference(to="c", definitions=d2)
    f3 = Reference(to="b")

    fa = Field(name="a")
    fb = Field(name="b")

    fschema = Object(name="schema", properties={"a": fa, "b": fb})

    set_definitions(f1, d3)
    set_definitions(f2, d3)
    set_definitions(f3, d3)
    set_definitions(fschema, d3)



# Generated at 2022-06-12 15:53:24.369911
# Unit test for function set_definitions
def test_set_definitions():
    # classes defined here to avoid circular dependencies
    class Definition(Schema):
        name = Field()

    class ReferenceSchema(Schema):
        reference = Reference("Definition")

    # assert that ReferenceSchema.reference.to is set to Definition
    reference = ReferenceSchema.fields["reference"]
    assert reference.to == "Definition"

    # assert that ReferenceSchema.reference.definitions is set to definitions
    definitions = SchemaDefinitions({"Definition": Definition})
    set_definitions(reference, definitions)
    assert reference.definitions == definitions

    # assert that ReferenceSchema.reference.target is set to Definition
    assert reference.target == Definition

    # assert that ReferenceSchema.reference.target_string is set to "Definition"
    assert reference.target_string == "Definition"

    # assert that ReferenceSchema.reference.target_

# Generated at 2022-06-12 15:53:28.477917
# Unit test for method __len__ of class Schema
def test_Schema___len__(): 
    from unittest import TestCase
    from typesystem import Schema
    from typesystem import Integer

    class Test(Schema):
        id = Integer()
        name = Integer()

    t = Test(id=5, name=5)
    TestCase().assertEqual(len(t), 2)


# Generated at 2022-06-12 15:53:36.152614
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import Field
    from typesystem.integer import Integer
    from typesystem.object import Object
    from typesystem.string import String

    class PointSchema(Schema):
        x = Integer(minimum=-10, maximum=10)
        y = Integer()
        name = String()

    class CircleSchema(Schema):
        center = Object(properties={
            "x": Integer(minimum=-10, maximum=10),
            "y": Integer()
        })
        radius = Integer()
        color = String()

    class PointSchema(Schema):
        x = Integer(minimum=-10, maximum=10)
        y = Integer()
        name = String()


# Generated at 2022-06-12 15:53:47.038014
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # 4
    assert len(Schema(True)) == 1
    assert len(Schema(True, False)) == 2
    assert len(Schema(True, False, True)) == 2
    assert len(Schema(True, False, True, False)) == 3
    assert len(Schema(True, False, True, False, True)) == 3
    assert len(Schema(True, False, True, False, True, False)) == 4
    assert len(Schema(True, False, True, False, True, False, True)) == 4
    assert len(Schema(True, False, True, False, True, False, True, False)) == 5
    assert len(Schema(True, False, True, False, True, False, True, False, True)) == 5

# Generated at 2022-06-12 15:53:54.395121
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()

    p1 = Person({"name":"dude","age":24})
    p2 = Person(name="dude", age=24)
    p3 = {"name":"dude","age":24}
    assert(p1 == p2)
    assert(p1 != p3)

test_Schema___eq__()

# Generated at 2022-06-12 15:53:59.856709
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Schema1(Schema):
        id = Integer()

    x = Schema1(id=1)
    print(repr(x))

    y = Schema1()
    print(repr(y))

    class Schema2(Schema):
        key = String()
        value = String()

    z = Schema2(key="1", value="2")
    print(repr(z))

# Generated at 2022-06-12 15:54:11.737014
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Integer, String

    class User(Schema):
        id = Integer()
        first_name = String()
        last_name = String()

    user = User(id=1, first_name="Bill", last_name="Clinton")

    assert user["first_name"] == "Bill"
    return



# Generated at 2022-06-12 15:54:15.750742
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int, required=False)
    person = Person({"name": "John Doe", "age": 42})
    assert person.name == "John Doe"
    assert person.age == 42

# Generated at 2022-06-12 15:54:26.478079
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import Object
    from typesystem.schema import Schema
    class MySchema(Schema):
        name = Object(properties={"first": "string", "last": "string"})
        email = "string"
        age = "number"
        id = "string"
    s = MySchema({'name': {'first': 'Peter', 'last': 'Parker'},
                  'email': 'peter.parker@example.com',
                  'age': 19})
    repr(s)
    s.__repr__()
    assert repr(s) == "MySchema(age=19, email='peter.parker@example.com'," \
                      " name={'first': 'Peter', 'last': 'Parker'})"

# Generated at 2022-06-12 15:54:36.390899
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Food(Schema):
        name = String()
        price = Integer()
        visibility = Boolean()
        expiry_date = Date()
        quantity_remaining = Float()
        barcode = String(required=False)
        image_uri = String(required=False)

    food = Food(name='Fries', price=10, quantity_remaining=5, expiry_date='2020-02-23')
    # example 1
    assert food['name'] == 'Fries'
    # example 2
    assert food['price'] == 10
    # example 3
    assert food['image_uri'] == None


# Generated at 2022-06-12 15:54:39.059138
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Test Schema.__eq()
    assert False

# Generated at 2022-06-12 15:54:42.175480
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class ExampleSchema(Schema):
        name = String(min_length=10)

    obj = ExampleSchema(name="yash")
    assert list(obj) == ['name']

# Generated at 2022-06-12 15:54:46.715570
# Unit test for constructor of class Reference
def test_Reference():
    # Ensure that constructor raise an error if target is not a string or a schema
    with pytest.raises(AssertionError):
        Reference(to=object())

    # Ensure that constructor does not raise an error if target is a string or a schema
    Reference(to=str())
    Reference(to=Schema)


# Generated at 2022-06-12 15:54:47.273342
# Unit test for constructor of class Schema
def test_Schema():
    assert callable(Schema)


# Generated at 2022-06-12 15:54:53.887937
# Unit test for constructor of class Schema
def test_Schema():
    import pytest
    from typesystem.fields import String

    class Person(Schema):
        name = String
        age = Integer

    person = Person(name="Joe", age=18)
    assert person.is_sparse is False

    person = Person({"name": "Joe", "age": 18})
    assert person.is_sparse is False

    Person = Schema(name=String, age=Integer)
    person = Person(name="Joe", age=18)
    assert person.is_sparse is False

    class Person(Schema):
        name: String
        age = Integer

    person = Person(name="Joe", age=18)
    assert person.is_sparse is False

    class Person(Schema):
        name = String(allow_null=True)


# Generated at 2022-06-12 15:54:57.452270
# Unit test for function set_definitions
def test_set_definitions():
    class User(Schema):
        name = String()

    class Pet(Schema):
        name = String()
        owner = Reference("User")

    definitions = SchemaDefinitions()
    set_definitions(Pet.owner, definitions)

# Generated at 2022-06-12 15:55:17.957938
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # No definitions
    class Person(Schema):
        name = String()

    assert isinstance(Person.fields['name'], String)
    assert isinstance(Person, type)

    # Definitions
    definitions = SchemaDefinitions()
    class Person(Schema, definitions=definitions):
        name = String()

    assert Person.fields == {'name': String(required=True)}
    assert definitions['Person'] == Person

# Generated at 2022-06-12 15:55:19.286937
# Unit test for constructor of class Reference
def test_Reference():
    a = Reference('key',allow_null=False)                                        # new instance

# Generated at 2022-06-12 15:55:27.593764
# Unit test for function set_definitions
def test_set_definitions():
    field = dict(
        type="object",
        required=["email"],
        properties=dict(
            email=dict(type="string", format="email"),
            age=dict(type="number", minimum=1),
        ),
    )
    definitions = SchemaDefinitions()
    f = Field.from_dict(field)
    set_definitions(f, definitions)
    assert len(definitions) == 0
    assert f.definitions == definitions

    field = dict(
        type="object",
        required=["email"],
        properties=dict(
            email=dict(type="string", format="email"),
            age=dict(
                type="object",
                properties=dict(
                    value=dict(type="number", minimum=1, definitions=definitions)
                ),
            ),
        ),
    )
   

# Generated at 2022-06-12 15:55:31.720676
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from pprint import pprint
    import io, sys
    # Redirect stdout to suppress output for unittest
    stdout = sys.stdout
    sys.stdout = io.StringIO()
#test_Schema___eq__()


# Generated at 2022-06-12 15:55:37.940482
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String(required=True)
        email = String(regex="^[\w\d_\.]+@[\w\d_\.]+$")
        date_of_birth = Date()

    obj = Person.validate({"name": "Foo Bar", "email": "foo@bar.com"})

    assert list(obj.__iter__()) == ["name", "email"]

# Generated at 2022-06-12 15:55:47.523388
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = Field(type=String)
        age = Field(type=Integer)
    class Person(Schema):
        name = Field(type=String)
        age = Field(type=Integer)
        @classmethod
        def validate(cls, value, *, strict=False):
            validator = cls.make_validator(strict=strict)
            return validator.validate(value, strict=strict)
        @classmethod
        def validate_or_error(cls, value, *, strict=False):
            try:
                value = cls.validate(value, strict=strict)
                error = None
            except ValidationError as error:
                value = None
            return ValidationResult(value=value, error=error)

# Generated at 2022-06-12 15:55:53.409606
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert list(Schema().__iter__()) == []
    assert len(Schema().__iter__()) == 0
    assert list(Schema(a=1).__iter__()) == ['a']
    assert len(Schema(a=1).__iter__()) == 1
    assert list(Schema(b=2).__iter__()) == ['b']
    assert len(Schema(b=2).__iter__()) == 1
    assert sorted(Schema(a=1, b=2).__iter__()) == ['a', 'b']
    assert len(Schema(a=1, b=2).__iter__()) == 2
    assert list(Schema(a=1, c=3).__iter__()) == ['a', 'c']
    assert len(Schema(a=1, c=3).__iter__())

# Generated at 2022-06-12 15:56:02.351991
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        class MyReference(Reference):
            pass

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            self.MyReference = self.MyReference  # type: ignore
            super(TestSchema, self).__init__(*args, **kwargs)

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.MyReference("test-schema"), definitions)

    assert len(definitions) == 1
    assert definitions["test-schema"] is TestSchema

# Generated at 2022-06-12 15:56:06.994191
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String
    class Comment(Schema):
        body = String()
        # Call function
        list_attribute = list(Comment.__iter__(Comment))

        # Check type of variable
        if not isinstance(list_attribute, list):
            raise TypeError('Variable is not a list')
        # Check length of variable
        if len(list_attribute) != 1:
            raise IndexError('Variable is not of length 1')



# Generated at 2022-06-12 15:56:18.161255
# Unit test for constructor of class Schema
def test_Schema():
    class UserSchema(Schema):
        name = Field()
        age = Field(cast=int)
    user = UserSchema(name="Tim", age="30")
    assert user.name == "Tim"
    assert user.age == 30
    assert user.is_sparse is False
    assert user == UserSchema({"name": "Tim", "age": 30})
    assert user == UserSchema({"name": "Tim"}, age=30)
    assert user != UserSchema({"name": "Tim"}, age=31)
    assert user != UserSchema({"name": "Tim", "age": 30, "email": "tim@example.com"})
    assert user != UserSchema.validate({"name": "Tim", "age": 30, "email": "tim@example.com"})


# Generated at 2022-06-12 15:56:52.902616
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    t1 = {}
    t2 = {'name':'GitHub', 'url': 'https://github.com/'}
    t3 = {'name':'GitHub', 'url': 'https://github.com/'}
    assert(t1 != t2)
    assert(t2 == t3)


# Generated at 2022-06-12 15:57:01.155072
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema, metaclass=SchemaMetaclass):
        test = Field(type="string")
        test2 = Field(type="string")

    # Check the creation of the test class
    assert isinstance(TestSchema, type)
    assert TestSchema.__name__ == "TestSchema"
    assert issubclass(TestSchema, Schema)

    # Check the fields of the test class
    assert isinstance(TestSchema.fields, dict)
    assert list(TestSchema.fields.keys()) == ["test", "test2"]
    assert isinstance(TestSchema.fields["test"], Field)
    assert isinstance(TestSchema.fields["test2"], Field)

    # Check the creation of a TestSchema object

# Generated at 2022-06-12 15:57:11.420896
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(required=True)
        b = Field(default="test")
        c = Field()

    obj = TestSchema(a=1, c="Hello")
    assert obj.a == 1
    assert obj.b == "test"
    assert obj.c == "Hello"

    obj2 = TestSchema(TestSchema(a=5, c="World"))
    assert obj2.a == 5
    assert obj2.b == "test"
    assert obj2.c == "World"

    obj3 = TestSchema({"a": 5, "c": "World"})
    assert obj3.a == 5
    assert obj3.b == "test"
    assert obj3.c == "World"


# Generated at 2022-06-12 15:57:17.133135
# Unit test for function set_definitions
def test_set_definitions():
    class Definitions(SchemaDefinitions):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self.class_definitions = {}
            self.string_definitions = {}
            self.definitions = {}

        def __setitem__(self, key: typing.Any, value: typing.Any) -> None:
            if isinstance(key, str):
                self.string_definitions[key] = value
            else:
                self.class_definitions[key] = value
            super().__setitem__(key, value)

    definitions = Definitions()
    class TestSubclass(Schema):
        name = Reference("test_reference")


# Generated at 2022-06-12 15:57:27.320553
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import sys
    import os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "typesystem"))
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from copy import copy

    class Person(Schema):
        name = String(max_length=100)
        age = String(max_length=3)

    data = {"name": "John Doe", "age": "42"}

    assert Person(**data) == Person(**data)
    assert Person(**data) != data



# Generated at 2022-06-12 15:57:33.404286
# Unit test for constructor of class Schema
def test_Schema():
    # Setup
    class Person(Schema):
        age = Field(type=int)
        name = Field(type=str)
        is_male = Field(type=bool)
    age = 42
    name = 'bob'
    is_male = True

    # Exercise
    person = Person(age=age, name=name, is_male=is_male)

    # Verify
    assert person.age == age
    assert person.name == name
    assert person.is_male == is_male


# Generated at 2022-06-12 15:57:37.633372
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema(name="lz", age=5)
    try:
        assert len(schema) == 2
    except TypeError as err:
        print(f"Wrong type: {err}")


# Generated at 2022-06-12 15:57:40.757199
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="Rolf Smith", age=24)
    assert person["name"] == "Rolf Smith"
    assert person["age"] == 24



# Generated at 2022-06-12 15:57:43.370109
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field()
        age = Field()

    person = Person(name="joe", age=25)
    assert person.name == "joe"
    assert person.age == 25


# Generated at 2022-06-12 15:57:52.943007
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = String(required=True)

    class PersonReference(Reference):
        to = "Person"

    class Address(Schema):
        person = PersonReference(required=True)

    class Street(Schema):
        name = String(required=True)

    class StreetReference(Reference):
        to = "Street"

    class Road(Schema):
        street = StreetReference(required=True)

    class Location(Schema):
        address = Address()
        road = Road()

    definitions = SchemaDefinitions()
    assert PersonReference.definitions is None

    set_definitions(Location, definitions)

    assert PersonReference.definitions is definitions


# Generated at 2022-06-12 15:58:51.642853
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from .models import Player
    jack = Player(name="Jack", score=100)
    print(jack)
    print(jack["name"])
    print(jack["score"])

# Generated at 2022-06-12 15:59:01.360945
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.types import Integer, String

    class User(Schema):
        id = Integer()
        name = String(max_length=50)

    t1 = User(id=1, name='ss')
    assert isinstance(t1, User)
    print(t1)
    it = iter(t1)
    print(t1.__iter__())
    assert next(it) == 'id'
    assert next(it) == 'name'
    try:
        next(it)
    except StopIteration:
        print('End of Schema')

    assert len(t1) == 2
    print(list(t1))



# Generated at 2022-06-12 15:59:09.833130
# Unit test for function set_definitions
def test_set_definitions():
    class Definition1(Schema):
        foo = Field()

    class Definition2(Schema):
        bar = Reference("Definition1")

    class Definition3(Schema):
        foo = Field()
        bar = Field()
        baz = Reference("Definition1")

    class Definition4(Schema):
        foo = Array(items=Reference("Definition1"))

    class Definition5(Schema):
        foo = Array(items=[Reference("Definition1"), Reference("Definition2")])

    definitions = SchemaDefinitions()
    set_definitions(Definition2.fields["bar"], definitions)
    assert Definition2.fields["bar"].definitions == definitions
    set_definitions(Definition3.fields["baz"], definitions)
    assert Definition3.fields["baz"].definitions == definitions

# Generated at 2022-06-12 15:59:19.366460
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    Task = Schema(
        title=str,
        description=str,
        completed=bool,
        created_at=datetime.datetime,
    )

    # Test method __repr__ of case 1
    task = Task(title="test", description="test description", completed=False, created_at=datetime.datetime.now())
    task_repr = repr(task)
    assert task_repr == "Task(title='test', description='test description', completed=False, created_at=datetime.datetime(2020, 3, 2, 10, 10, 22, 170000))"
    
    # Test method __repr__ of case 2
    task = Task(title="test", description="test description", completed=False)
    task_repr = repr(task)

# Generated at 2022-06-12 15:59:24.080978
# Unit test for method validate of class Reference
def test_Reference_validate():
    #Reference.validate(None, strict=False) # Added to test ValidationError thrown
    Reference.validate(3, strict=True)
    Reference.validate({'a': 3}, strict=True)
    Reference.validate([2, 3, 4], strict=True)
    
test_Reference_validate()

# Generated at 2022-06-12 15:59:34.139557
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestObject(Schema):
        name = "foo"

    # Test with None, with allow_null = True
    reference = Reference("TestObject")
    reference.allow_null = True
    assert reference.validate(None) == None

    # Test with None, with allow_null = False
    reference = Reference("TestObject")
    reference.allow_null = False
    next_exception = False
    try:
        reference.validate(None)
    except ValidationError:
        next_exception = True
    assert next_exception

    # Test with a schema name
    reference = Reference("TestObject")
    assert reference.validate({"name": "foo"}) == {"name": "foo"}

    # Test with a schema with no definitions
    reference = Reference(TestObject)
    next_exception = False


# Generated at 2022-06-12 15:59:39.252982
# Unit test for method validate of class Reference
def test_Reference_validate():
    from .definitions import Simple, Complex
    from .fields import String
    from .typesystem import String as StringClass

    definitions = SchemaDefinitions()

    class Dummy(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        class Meta:
            definitions = definitions
        a_string = String(max_length=10)
        a_reference = Reference(Simple)

    instance = Dummy.validate({"a_string":"test", "a_reference": {"a_string":"test"}})
    validator = instance.__class__.make_validator()
    validator.validate(instance, strict=True)

    instance = Dummy.validate({"a_string":"test", "a_reference": {"a_string":"test", "a_number":0.1}})

# Generated at 2022-06-12 15:59:44.835972
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from random import random
    from typesystem import Integer, Meta, Number, String

    class Person(Schema):
        name = String()
        age = Integer()

    p = Person(name="Ashley", age=27)
    assert p["name"] == "Ashley"
    assert p["age"] == 27
    assert sorted(p.items()) == [("age", 27), ("name", "Ashley")]
    assert sorted(p.keys()) == ["age", "name"]
    assert sorted(p.values()) == [27, "Ashley"]
    assert list(p) == ["name", "age"]
    assert len(p) == 2

    class Person(Schema):
        name = String()
        age = Integer()

    p = Person(name="Ashley", age=27)

# Generated at 2022-06-12 15:59:50.212028
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Object, String
    from typesystem.schema import Schema

    class Person(Schema):
        name = String
        age = String

    person_schema = Person(name="Django", age="1")
    assert len(person_schema) == 2




# Generated at 2022-06-12 15:59:55.305656
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    obj = SchemaMetaclass(
        "class_name",
        ("base_class_1", "base_class_2",),
        {
            "attr1": "attr1_value",
            "attr2": "attr2_value",
            "attr3": "attr3_value",
            "attr4": "attr4_value",
            "attr5": "attr5_value",
        },
    )
    assert obj == 8
