

# Generated at 2022-06-12 15:51:04.452213
# Unit test for constructor of class Schema
def test_Schema(): Schema("a")


# Generated at 2022-06-12 15:51:08.406899
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    '''
    Checks that test_Schema___repr__ returns a printable representation of a schema.
    '''
    schema_repr_object=Schema({'name':'neha','age':20})
    assert type(schema_repr_object.__repr__())==str,\
    'The method __repr__ of class Schema is not returning a string'
    

    
    

# Generated at 2022-06-12 15:51:19.471632
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Knob(Reference):
        def __init__(self, knobs: str, definitions: SchemaDefinitions = None):
            super().__init__(knobs, definitions)
    class Regime(Reference):
        def __init__(self, regimes: str, definitions: SchemaDefinitions = None):
            super().__init__(regimes, definitions)
    class Intensity(Schema):
        knob = Knob("knob", required=True)
        regime = Regime("regime", definitions=definitions)
    set_definitions(Intensity, definitions)
    assert Intensity.fields["knob"].definitions is not None
    assert Intensity.fields["regime"].definitions is not None


# Generated at 2022-06-12 15:51:29.972980
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import datetime
    import typesystem
    test_fields = {
        "name": typesystem.String(max_length=100),
        "age": typesystem.Integer(),
        "month_of_birth": typesystem.String(
            format="date-time"
        ),
        "month_of_death": typesystem.String(
            format="date-time", allow_null=True
        ),
        "phone": typesystem.String(pattern="[0-9]{10}"),
    }
    Person = typesystem.Schema(
        "Person",
        fields=test_fields
    )

# Generated at 2022-06-12 15:51:35.253091
# Unit test for constructor of class Schema
def test_Schema():
    class ObjectSchema(Schema):
        a = Field()

    assert ObjectSchema().a is None

    class ObjectSchema(Schema):
        a = Field(default="default")

    assert ObjectSchema().a == "default"

    class ObjectSchema(Schema):
        class NestedSchema(Schema):
            a = Field()

        a = NestedSchema()

    assert ObjectSchema().a.a is None


# Generated at 2022-06-12 15:51:38.521183
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    foo = Field(type="string")
    bar = Field(type="string")
    class Klass(Schema):
        fields = {'foo': foo, 'bar': bar}

    obj = Klass(foo="hello", bar="world")
    assert(list(obj.__iter__()) == ['foo', 'bar'])



# Generated at 2022-06-12 15:51:43.832127
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        a = Reference("Bar")

    definitions = SchemaDefinitions()

    # Check that we get the right error message if we call
    # set_definitions on a Reference with no targets.
    expected_message = re.escape(
        r"Definition for 'Bar' has already been set."
    )
    with pytest.raises(AssertionError, match=expected_message):
        set_definitions(Foo.fields["a"], definitions)

    class Bar(Schema):
        b = Reference("Foo")

    set_definitions(Foo.fields["a"], definitions)

    assert definitions == {"Foo": Foo, "Bar": Bar}
    assert Foo.fields["a"].definitions == definitions
    assert Bar.fields["b"].definitions == definitions

# Generated at 2022-06-12 15:51:55.935353
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    s = Schema(dict())
    assert [x for x in s] == []

    class Foo(Schema):
        pass

    s = Foo(dict())
    assert [x for x in s] == []

    class Foo(Schema):
        field = Field()

    s = Foo(dict())
    assert [x for x in s] == []

    class Foo(Schema):
        field = Field()

    s = Foo(field = "test")
    assert [x for x in s] == ["field"]

    class Foo(Schema):
        field1 = Field()
        field2 = Field()

    s = Foo(field1 = "test1", field2="test2")
    assert [x for x in s] == ["field1", "field2"]



# Generated at 2022-06-12 15:52:03.779166
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field = Field()
    
    # Success
    ts = TestSchema({"field": "a"})

    assert ts["field"] == "a"

    # Failure: KeyError
    try:
        ts = TestSchema({"field": "a"})
        ts["does_not_exist"]
    except KeyError:
        pass
    else:
        assert False, "should not reach this point!"


# Generated at 2022-06-12 15:52:08.245663
# Unit test for function set_definitions
def test_set_definitions():

    class School(Schema):
        name = Field()

    class Person(Schema):
        name = Field()
        school = Reference(School)

    class Schedule(Schema):
        person = Reference(Person)

    definitions = SchemaDefinitions()
    for schema in (Schedule, Person, School):
        set_definitions(schedule, definitions)

# Generated at 2022-06-12 15:52:24.157195
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Foo(Schema):
        field = Reference("Bar")
    class Bar(Schema):
        field = Reference("Baz")
    set_definitions(Foo.field, definitions)
    assert Foo.field.definitions == definitions

# Generated at 2022-06-12 15:52:24.946363
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert list(Schema()) == []

# Generated at 2022-06-12 15:52:33.048035
# Unit test for function set_definitions
def test_set_definitions():
    # Example
    class Person(Schema):
        name = String()

    class PersonReference(Reference):
        to = Person

    class Address(Schema):
        street = String()
        city = String()
        postcode = String()

    class AddressReference(Reference):
        to = Address

    class Company(Schema):
        name = String()
        addresses = Array(of=AddressReference)

    # Example schema
    class PersonWithAddress(Schema):
        name = String()
        address = AddressReference(to="Address")

    set_definitions(PersonWithAddress, SchemaDefinitions(Address=Address))
    assert PersonWithAddress.fields["address"].definitions["Address"] == Address
    assert PersonWithAddress.fields["address"].target == Address

    class Company(Schema):
        name = String()

# Generated at 2022-06-12 15:52:42.849734
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        first_name = String()
        last_name = String()
        age = Integer()
        nickname = String(allow_null=True)

    person = Person(last_name='Doe', first_name='John')
    assert tuple(person.__iter__()) == ('last_name', 'first_name')
                    
    # We test also the case when nickname is set, in that case we expect that nickname is included in the iteration
    person = Person(last_name='Doe', first_name='John', nickname='Doey')
    assert tuple(person.__iter__()) == ('last_name', 'first_name', 'nickname')

# Generated at 2022-06-12 15:52:54.444449
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    _fields = {"A": "B"}
    _type = Schema(_fields)
    try:
        assert _type.__len__() == 1
    except AssertionError:
        raise AssertionError("Expected: 1\nActual: " + str(_type.__len__()))
    _fields = {"A": "B"}
    _type = Schema(_fields)
    try:
        assert _type.__len__() == 1
    except AssertionError:
        raise AssertionError("Expected: 1\nActual: " + str(_type.__len__()))
    _fields = {}
    _type = Schema(_fields)

# Generated at 2022-06-12 15:52:59.714353
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.fields import Integer, String


    class HeroSchema(Schema):
        name = String(max_length=100)
        age = Integer()


    a = HeroSchema(name="test", age=0)
    b = HeroSchema(name="test", age=0)
    assert a == b
    b = HeroSchema(name="test1", age=0)
    assert a != b



# Generated at 2022-06-12 15:53:01.548459
# Unit test for method __len__ of class Schema
def test_Schema___len__():
  assert True == True


# Generated at 2022-06-12 15:53:03.218797
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Empty(Schema):
        pass

# Generated at 2022-06-12 15:53:05.415720
# Unit test for constructor of class Schema
def test_Schema():
    attrs = {'test': 4}
    s = Schema(attrs)
    assert hasattr(s, 'test')


# Generated at 2022-06-12 15:53:13.091070
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.fields import Integer

    class Person(Schema):
        name = String(max_length=255)
        age = Integer()

    person1 = Person({"name": "Jane", "age": 29})
    person2 = Person({"name": "Jane", "age": 29})
    person3 = Person({"name": "Jane", "age": 28})
    person4 = Person({"name": "Jane"})
    person5 = Person({"name": "John"})

    assert person1 == person2
    assert person1 != person3
    assert person1 != person4
    assert person1 != person5
    assert person1 != None
    assert person1 != 28

# Generated at 2022-06-12 15:53:24.407140
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass


# Generated at 2022-06-12 15:53:33.463942
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class Foo(Schema):
        fields = {"foo": Reference("Bar")}

    class Bar(Schema):
        fields = {"bar": Field(str)}

    set_definitions(Foo.fields["foo"], definitions)
    assert Foo.fields["foo"].definitions == definitions
    assert Foo.fields["foo"].target_string == "Bar"
    assert Foo.fields["foo"].target == Bar

    class Baz(Schema):
        fields = {
            "baz": Reference(Bar, definitions=definitions),
        }

    assert Baz.fields["baz"].definitions == definitions
    assert Baz.fields["baz"].target_string == "Bar"
    assert Baz.fields["baz"].target == Bar


# Generated at 2022-06-12 15:53:34.852200
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # This test is a stub.
    pass


# Generated at 2022-06-12 15:53:36.372519
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema().validate('a') == 'a'

# Generated at 2022-06-12 15:53:45.851600
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    Field.define('id', type=str)
    Field.define('name', type=str)
    Field.define('age', type=int)
    Field.define('married', type=bool)

    class Person(Schema):
        id = Field()
        name = Field()
        age = Field()
        married = Field()

    p = Person(id='Tom', name='Tom', married=True)
    assert p['id'] == 'Tom'
    assert p['name'] == 'Tom'
    assert p['age'] == 0
    assert p['married'] == True

    try:
        p['job']
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-12 15:53:48.533128
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        s = Field(str)
    a1 = A(s="a")
    a2 = A(s="a")
    assert a1 == a2


# Generated at 2022-06-12 15:53:54.142008
# Unit test for constructor of class Schema
def test_Schema():
    class A():
        a = 'a'
        b = 'b'
    class B(Schema):
        a = String()
        b = String()
    obj = B(A())
    assert obj.a == 'a' and obj.b == 'b'


# Generated at 2022-06-12 15:53:55.489146
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert "fields" in dir(Schema.__len__)


# Generated at 2022-06-12 15:54:01.195323
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        first_name = String(max_length=255)
        last_name = String(max_length=255)

    class MyObject(Schema):
        name_ref = Reference("MySchema")

    definitions = SchemaDefinitions()
    set_definitions(MyObject.name_ref, definitions)
    assert MyObject.name_ref.to == "MySchema"
    assert MyObject.name_ref.target == MySchema

# Generated at 2022-06-12 15:54:05.585665
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Test(Schema):
        a = Field()
        b = Field()
        c = Field()

    t = Test(a=1, b=2)

    result = [key for key in t]

    assert result == ['a', 'b']




# Generated at 2022-06-12 15:54:15.558105
# Unit test for constructor of class Reference
def test_Reference():
    to = SchemaClass
    definitions = SchemaDefinitions
    kwargs = {"definitions": definitions}
    a = Reference(to, **kwargs)
    assert a.target == SchemaClass


# Generated at 2022-06-12 15:54:17.635897
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        field_a = Field()
        field_b = Field()
    m = MySchema()
    assert list(m) == ['field_a', 'field_b']


# Generated at 2022-06-12 15:54:20.676742
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        bar = Field(type='string')
    x = Foo({'bar': 'ABC'})
    x = Foo(bar='ABC')
    x = Foo()


# Generated at 2022-06-12 15:54:29.400518
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test Schema.__getitem__ with Schema with field of type Reference
    class SchemaWithRef(Schema):
        field = Reference(to='type')

    schema = SchemaWithRef({'field': 1})
    assert isinstance(schema, SchemaWithRef)
    assert 1 == schema.field
    assert 1 == schema['field']

    # Test Schema.__getitem__ with Schema with field of type Array
    class SchemaWithArray(Schema):
        field = Array()

    schema = SchemaWithArray({'field': [1, 2, 3]})
    assert isinstance(schema, SchemaWithArray)
    assert [1, 2, 3] == schema.field
    assert [1, 2, 3] == schema['field']

    # Test Schema.__getitem__ with Schema with field

# Generated at 2022-06-12 15:54:36.954037
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    m = Schema()
    assert len(m) == 0

    m = Schema({})
    assert len(m) == 0

    m = Schema({'x':1})
    assert len(m) == 1
    assert m['x'] == 1

    m = Schema(x=1)
    assert len(m) == 1
    assert m['x'] == 1

    m = Schema({'x':None}, x=1)
    assert len(m) == 2
    assert m['x'] == 1



# Generated at 2022-06-12 15:54:47.111588
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    s = Schema()
    assert set(s.__iter__()) == set()
    s = Schema(foo='bar')
    assert set(s.__iter__()) == {'foo'}
    s = Schema(foo='bar', bar='foo')
    assert set(s.__iter__()) == {'foo', 'bar'}
    s = Schema(bar='foo')
    assert set(s.__iter__()) == {'bar'}
    s = Schema(foo='bar', bar='foo', baz=42)
    assert set(s.__iter__()) == {'foo', 'bar', 'baz'}


# Generated at 2022-06-12 15:54:48.067058
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import cProfile
    cProfile.run('Schema().__eq__(Schema())')


# Generated at 2022-06-12 15:54:49.774152
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference(to = "String", nullable = True)
    assert ref.to == "String"
    assert ref.allow_null == True

# Generated at 2022-06-12 15:54:57.056979
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Person(Schema):
        name = String()
        age  = Reference('Age')

    class Age(Schema):
        years = Integer()

    person_field = Object(properties={
        'name': String(),
        'age': Reference('Age')
    })

    set_definitions(person_field, definitions)
    assert(age_field.definitions == definitions)

# Generated at 2022-06-12 15:55:02.707050
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class ExampleSchema(Schema):
        field1 = Array(items=String())
        field2 = Array(items=String())
    schema = ExampleSchema(field1=["a", "b", "c"], field2=["d", "e"])
    # 
    assert isinstance(schema, Mapping)
    # 
    assert list(schema) == ["field1", "field2"]


# Generated at 2022-06-12 15:55:26.092023
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        field_1 = String()

    class B(Schema):
        field_1 = String()
        field_2 = Array(items=Reference(to=A))

    definitions = SchemaDefinitions()
    definitions["A"] = A
    field = B.fields["field_2"]
    set_definitions(field, definitions)
    assert field.items[0].definitions == definitions
    assert field.items[0].target == A
    assert field.items[0].target_string == "A"


# Generated at 2022-06-12 15:55:37.089773
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        """
        This class has the same method signatures as
        the class 'Schema' and inherits the methods:
        __init__, __eq__, __getitem__, __iter__,
        __len__, __repr__, make_validator,
        validate, validate_or_error,
        and is_sparse
        """
        hello = String()

    assert TestSchema.validate({"hello": "world"}) == TestSchema.validate(
        {"hello": "world"}
    )
    assert TestSchema.validate({"hello": "world"}) != TestSchema.validate(
        {"hello": "world!", "oops": 12}
    )

# Generated at 2022-06-12 15:55:42.004427
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Inner(Schema):
        inner_field = Field(type="string")

    class Outer(Schema):
        inner_field = Field(type="string")
        inner_schema = Reference(Inner)
    set_definitions(Outer.fields["inner_schema"], definitions)
    assert Inner in definitions.values()


# Generated at 2022-06-12 15:55:50.677398
# Unit test for constructor of class Schema
def test_Schema():
    c = Schema("greeting", verb="Hello")
    assert c.greeting == "greeting"
    assert c.verb == "Hello"
    assert c.is_sparse == False

    d = Schema("greeting", verb="Hello")
    assert c == d
    assert c is not d
    e = Schema("greeting", verb="Doesnot Match")
    assert c != e

    assert Schema("greeting", verb="Hello")["greeting"] == "greeting"
    assert Schema("greeting", verb="Hello")["verb"] == "Hello"
    assert Schema("greeting", verb="Hello").__repr__() == "Schema(greeting='greeting', verb='Hello')"
    assert Schema("greeting", verb="Hello").__len

# Generated at 2022-06-12 15:55:57.647675
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
  s = Schema()
  # convert Method to function(in order to be serializable)
  import types
  s.__iter__ = types.MethodType(lambda self: iter(self.fields.keys()), s)
  a = Schema(name='a')
  assert list(s) == ['name']
  assert list(a) == []


# Generated at 2022-06-12 15:56:06.712206
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from unittest import TestCase
    from unittest.mock import patch

    class MockSchema(Schema):
        foo = None
        bar = None
        baz = None

    with patch("typesystem.schema.hasattr", return_value=False) as hasattr:
        schema = MockSchema()
        assert list(schema) == []
        hasattr.assert_any_call(schema, "foo")
        hasattr.assert_any_call(schema, "bar")
        hasattr.assert_any_call(schema, "baz")

    with patch("typesystem.schema.hasattr", return_value=True) as hasattr:
        schema = MockSchema()
        assert list(schema) == ["foo", "bar", "baz"]
        hasattr.assert_any_

# Generated at 2022-06-12 15:56:13.606441
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int, required=True)

    obj = TestSchema(name="test", age=10)
    print(obj['name'])
    print(obj['age'])
    print(obj.get("name"))

if __name__ == "__main__":
    test_Schema___getitem__()

# Generated at 2022-06-12 15:56:20.534920
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):

        """
        Unit test for method __iter__ of class Schema
        """

        def __init__(self):
            super().__init__()
            ## The first field
            self.item_id = int()
            ## The second field
            self.name = str()

    schema = MySchema({"item_id": 1, "name": "obama"})
    for key in schema:
        print(key)


if __name__ == "__main__":
    test_Schema___iter__()

# Generated at 2022-06-12 15:56:24.593124
# Unit test for constructor of class Reference
def test_Reference():
    assert hasattr(Reference, "deserialize")
    assert hasattr(Reference, "validate")
    assert hasattr(Reference, "serialize")
    assert hasattr(Reference, "validate_or_error")
    assert hasattr(Reference, "errors")



# Generated at 2022-06-12 15:56:32.392112
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = String()
    class Pet(Schema):
        owner_ref = Reference(to='Person')
    class Organization(Schema):
        employees = Array(items=Reference(to='Person'))
        pets = Array(items=Reference(to=Pet))
    definitions = SchemaDefinitions()
    for field in Organization.fields.values():
        set_definitions(field, definitions)
    assert Person in definitions.values()
    assert Pet in definitions.values()

# Generated at 2022-06-12 15:57:12.408207
# Unit test for function set_definitions
def test_set_definitions():
    class Obj(Schema):
        name = String()
        age = String()

    class Person(Schema):
        name = String()
        age = String()
        reference = Reference("Obj")

    person = Person(
        name="Bob",
        age="34",
        reference=Obj(name="A"),
        definitions={"Obj": Obj}
    )

    person2 = Person(
        name="Bob",
        age="34",
        reference=Obj(name="A", definitions={"Obj": Obj}),
        definitions={"Obj": Obj}
    )

    assert person2 == person

# Generated at 2022-06-12 15:57:14.748318
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class Child(Schema):
        schema = Schema()

    class Parent(Schema):
        ref = Reference("Child", definitions=definitions)

    set_definitions(Parent.fields["ref"], definitions)

# Generated at 2022-06-12 15:57:15.816514
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert True


# Generated at 2022-06-12 15:57:25.022619
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        test1 = String()
        test2 = String()
        test3 = String()
        test4 = String()
    class B(A):
        test5 = String()
        test6 = String()
    assert 'test1' in B.fields
    assert 'test2' in B.fields
    assert 'test3' in B.fields
    assert 'test4' in B.fields
    assert 'test5' in B.fields
    assert 'test6' in B.fields
    assert len(B.fields) == 6


# Generated at 2022-06-12 15:57:26.392156
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass


# Generated at 2022-06-12 15:57:30.370909
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test Schema with no data
    schema = Schema()
    assert len(schema) == 0
    # Test Schema with one data
    schema = Schema(a=1)
    assert len(schema) == 1
    
    

# Generated at 2022-06-12 15:57:37.190259
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import pytest
    from typesystem import Schema

    class TestSchema(Schema):
        field1 = 'str'
        field2 = 'int'

    instance = TestSchema(field1='str', field2=2)
    assert set(iter(instance)) == set(['field1', 'field2'])


# Generated at 2022-06-12 15:57:46.062015
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class ColorSchema(Schema):
        name = Text()
        code = Text()

    value1 = ColorSchema(name = "red", code = "#ff0000")
    value2 = ColorSchema(name = "red", code = "#ff0000")
    value3 = ColorSchema(name = "blue", code = "#0000ff")
    value4 = Schema(name = "red", code = "#ff0000")
    value5 = Schema(name = "red", code = "#ff0000")
    value6 = Schema(name = "blue", code = "#0000ff")

    assert value1 == value1
    assert value1 == value2
    assert value2 == value1

    assert value1 != value3
    assert value3 != value1

    assert value1 != value4
    assert value4 != value1

# Generated at 2022-06-12 15:57:49.240348
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import String, Integer

    class Simple(Schema):
        foo = String()
        bar = Integer()

    assert set(Simple(foo="hi", bar=1)) == {"foo", "bar"}



# Generated at 2022-06-12 15:57:51.889536
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class _Schema(Schema):
        pass
    s1 = _Schema()
    s2 = _Schema()
    print(s1==s2)

test_Schema___eq__()

# Generated at 2022-06-12 15:59:06.209818
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    Schema_instance = Schema()
    assert isinstance(Schema_instance, Schema)
    assert isinstance(iter(Schema_instance), typing.Iterator)


# Generated at 2022-06-12 15:59:09.292417
# Unit test for function set_definitions
def test_set_definitions():
    class Item(Schema):
        foo = String()
    
    class Array(Schema):
        items = [Item()]

    definitions = SchemaDefinitions()
    set_definitions(Array(), definitions)
    assert len(definitions) == 1
    assert definitions['Item'] == Item


# Generated at 2022-06-12 15:59:15.327685
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Example(Schema, metaclass=SchemaMetaclass):
        name = String(required=True)
        age = Integer(minimum=0, maximum=100)

    assert Example.fields == {'name': {'required': True, 'type': 'string'}, 'age': {'maximum': 100, 'minimum': 0, 'type': 'integer'}}


# Generated at 2022-06-12 15:59:25.342603
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        int_field = Field(type="integer")
        string_array = Array(items=Field(type="string"))
        object_array = Array(items=Object(properties={"key": Field(type="string")}))
        object_array_multi = Array(
            items=[
                Field(type="string"),
                Object(properties={"key": Field(type="string")}),
            ]
        )

    # Test setting a non-reference field
    int_field = TestSchema.fields["int_field"]
    assert isinstance(int_field, Field)
    set_definitions(int_field, SchemaDefinitions())
    assert not hasattr(int_field, 'definitions')

    # Test setting a reference field

# Generated at 2022-06-12 15:59:26.281358
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass


# Generated at 2022-06-12 15:59:27.496256
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    assert len(schema) == 0


# Generated at 2022-06-12 15:59:36.811749
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.object import Property
    properties = {}
    properties['property1'] = Property()
    properties['property2'] = Property()
    definitions = SchemaDefinitions()
    definitions['name1'] = "test1"
    definitions['name2'] = "test2"
    definitions['name3'] = "test3"
    definitions['name4'] = "test4"
    definitions['name5'] = "test5"
    o = Object(properties=properties,definitions=definitions)
    reference = Reference(to="name1")
    assert (reference.definitions == None)
    set_definitions(o, definitions)
    for key in o.properties.keys():
        assert (o.properties[key].definitions == definitions)

# Generated at 2022-06-12 15:59:43.257227
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.types import String, Integer

    class Person(Schema):
        id = Integer()
        name = String()
        age = Integer()

    person = Person(id=1, name="Foo", age=20)
    assert list(person) == ["id", "name", "age"]

    # make_validator
    validator = Person.make_validator()
    assert isinstance(validator, Object)
    assert validator.properties == {"id": Integer(), "name": String(), "age": Integer()}
    assert validator.required == []

    validator = Person.make_validator(strict=True)
    assert validator.additional_properties is False

    # validate
    person = Person.validate({"id": 1, "name": "Foo", "age": 20})

# Generated at 2022-06-12 15:59:46.677641
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    s = Schema({"a": 1, "b": 2, "c": 3})
    assert len(s) == 3


# Generated at 2022-06-12 15:59:48.635210
# Unit test for constructor of class Schema
def test_Schema():
    assert len(Schema.fields) == 0

test_Schema()
