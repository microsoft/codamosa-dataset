

# Generated at 2022-06-12 15:50:51.757514
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Test(Schema):
        name = String

    t = Test(name="abc")

    assert list(t) == ["name"]

    class Test2(Schema):
        name = String
        age = Integer

    t2 = Test2(name="abc")
    assert list(t2) == ['name']

    t3 = Test2(name="abc", age=1)
    assert list(t3) == ['name', 'age']

    class Test3(Schema):
        name = String
        age = Integer
        sex = String(default='male')

    t4 = Test3(name='abc')
    assert list(t4) == ['name', 'sex']



# Generated at 2022-06-12 15:51:00.965218
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import Integer, Object, String
    from typesystem.schema import Schema

    class Actor(Schema):
        name = String(max_length=10)
        age = Integer(minimum=18)

    validator = Object(properties=Actor.fields)
    assert isinstance(validator, Field)

    # Error: {'age': ['Ensure this value is greater than or equal to 18.']}
    assert validator.validate_or_error({"name": "foo", "age": 17}).error
    
    assert Actor.validate_or_error({"name": "foo", "age": 17}).error

    # Error: {'age': ['Ensure this value is greater than or equal to 18.']}
    assert Actor.validate_or_error({"name": "foo", "age": 17}).error

# Generated at 2022-06-12 15:51:01.847202
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema()) == 0


# Generated at 2022-06-12 15:51:04.776701
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        test_field = Reference("mydefinition")

    definitions = {
        "mydefinition": None
    }
    set_definitions(TestSchema.test_field, definitions)
    assert TestSchema.test_field.definitions == definitions

# Generated at 2022-06-12 15:51:07.351484
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Animal(Schema):
        name = String()
        age = Integer()
    a = Animal(name="Dog", age=10)
    print(repr(a))


# Generated at 2022-06-12 15:51:18.178728
# Unit test for constructor of class Reference
def test_Reference():
    # Given
    class Person(Schema):
        name = String()

    class Company(Schema):
        name = String()
        CEO = Reference(Person)

    # When
    reference = Reference(Person)
    # Then
    assert isinstance(reference, Field)
    assert reference.to is Person
    assert reference.definitions is None
    assert reference.errors == {'null': 'May not be null.'}
    # And
    assert reference.target_string == 'Person'
    assert reference.target is Person
    # And
    validation_result = reference.validate('name: John')
    assert validation_result == {'name': 'John'}
    # And
    validation_result = reference.serialize({'name': 'John'})
    assert validation_result == {'name': 'John'}

    # When

# Generated at 2022-06-12 15:51:21.308081
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class FooBar(Schema):
        foo = Field()
        bar = Field(default="test string")
    obj = FooBar()
    assert list(obj) == ['foo']



# Generated at 2022-06-12 15:51:25.270989
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    try:
        definitions['a'] = 1
        definitions['a'] = 2
    except AssertionError as e:
        assert e.args[0] == r"Definition for 'a' has already been set."
    else:
        assert False



# Generated at 2022-06-12 15:51:28.592230
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from .fields import String

    class Animal(Schema):
        name = String()

    assert Animal(name="buzz") == Animal(name="buzz")
    assert Animal(name="rex") != Animal(name="buzz")


# Generated at 2022-06-12 15:51:34.743601
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import Integer, String

    class TestSchema(Schema):
        field = Integer(required=True)
        value = String(required=True)

    schema1 = TestSchema(field=1, value="test")

    schema2 = TestSchema(field=1, value="test")
    assert schema1 == schema2

    schema3 = TestSchema(field=3, value="test")
    assert schema1 != schema3



# Generated at 2022-06-12 15:51:57.484766
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem import String, Number
    from typesystem.fields import Field, Object


    class MySchema(Schema):

        id = Number()
        name = String()

    definitions = SchemaDefinitions({'Node': MySchema})
    assert definitions['Node'] == MySchema
    assert MySchema.fields['name'] == String()
    assert MySchema.fields['id'] == Number()

    class Properties(Schema):
        title = Reference('Node')
        body = Reference('Node')

    assert Properties.fields['title'] == Object(properties={'id': Number(),
                                                            'name': String()})
    assert Properties.fields['body'] == Object(properties={'id': Number(),
                                                           'name': String()})
    assert MySchema.fields['name'] == String()
    assert My

# Generated at 2022-06-12 15:52:04.896938
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
  """
  def __iter__(self) -> typing.Iterator[str]:
        for key in self.fields:
            if hasattr(self, key):
                yield key
  """
  class A(Schema):
    a = int
    b = int
    c = int
  a = A(a=0, b=1, c=2)
  assert [key for key in a] == ['a', 'b', 'c']


# Generated at 2022-06-12 15:52:09.747685
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class MySchema1(Schema):
        name = String(max_length=50)
        age = Integer(min_value=1)

    assert 'fields' in MySchema1.__dict__
    assert 'name' in MySchema1.__dict__['fields']
    assert 'age' in MySchema1.__dict__['fields']



# Generated at 2022-06-12 15:52:13.676754
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import Schema, fields

    class Topping(fields.String):
        pass

    class Pizza(Schema):
        toppings = fields.Array(fields.Reference(Topping))

    assert (
        repr(Pizza(toppings=[Topping(value="pepperoni", error=None)]))
        == "Pizza(toppings=[Reference(target=<class 'tests.test_schema.Topping'>, value='pepperoni', error=None)])"
    )

# Generated at 2022-06-12 15:52:24.554800
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from pyschema_extensions.schema import Schema
    from pyschema.typing import Integer, String

    s = Schema()
    try:
        assert str(s) == "Schema()"
    except Exception:
        assert False

    class TestSchema2(Schema):
        a = String
        b = String
        c = String
        d = String

    s2 = TestSchema2()
    try:
        assert str(s2) == "TestSchema2() [sparse]"
    except Exception:
        assert False

    class TestSchema3(Schema):
        a = String
        b = String
        c = String
        d = String

    s3 = TestSchema3({"a": "x", "b": "y"})

# Generated at 2022-06-12 15:52:35.716770
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class SomeSchema(Schema):
        a = Integer(default=1, enum=[1,2,3])
        b = Float(description="b")
        c = String(description="c")
        d = Boolean(enum=[True, False])
    assert SomeSchema.fields == {
        "a": Integer(default=1, enum=[1, 2, 3]),
        "b": Float(description="b"),
        "c": String(description="c"),
        "d": Boolean(enum=[True, False]),
    }
    assert SomeSchema().__dict__ == {}
    assert SomeSchema({"a": 1}).__dict__ == {"a": 1}
    message = "Invalid argument 'x' for SomeSchema(). Missing required field 'b'."

# Generated at 2022-06-12 15:52:44.943255
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    website = Website(homepage=Page(title="Homepage"), about=Page(title="About"))
    assert website["homepage"]["title"] == "Homepage"
    assert website["about"]["title"] == "About"
    assert website["homepage"] == {"title": "Homepage"}
    assert website["about"] == {"title": "About"}
    try:
        website["homepage"]["content"]
    except KeyError as error:
        assert error.args == ("content",)
    else:
        assert False, "Expected exception."
    try:
        website["missing"]
    except KeyError as error:
        assert error.args == ("missing",)
    else:
        assert False, "Expected exception."



# Generated at 2022-06-12 15:52:56.283319
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        a = Field(str)
        b = Field(str)
        c = Field(str, default="c-default")

    # Test init with args
    foo = Foo({"a": "a-value", "b": "b-value"})
    assert foo.a == "a-value"
    assert foo.b == "b-value"
    assert foo.c == "c-default"

    # Test init with args and kwargs - kwargs will override args
    foo = Foo({"a": "a-value", "b": "b-value"}, c="c-kwarg")
    assert foo.a == "a-value"
    assert foo.b == "b-value"
    assert foo.c == "c-kwarg"

    # Test init with kwargs only
   

# Generated at 2022-06-12 15:53:08.493174
# Unit test for constructor of class Schema
def test_Schema():
    class Point(Schema):
        x: int
        y: int
    point1 = Point(x=1, y=2)
    point2 = Point({'x': 1, 'y': 2})
    point3 = Point(point1)
    point4 = Point(point2)
    print(point1)
    print(point2)
    print(point3)
    print(point4)
    assert eval(repr(point1)) == point1
    assert eval(repr(point2)) == point2
    assert eval(repr(point3)) == point3
    assert eval(repr(point4)) == point4
    try:
        point5 = Point(x=1)
    except TypeError as e:
        print(e)


# Generated at 2022-06-12 15:53:14.899582
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        id = Field()
        name = Field()

    class Event(Schema):
        organizer = Reference("Person")
        invited_persons = Array(Reference("Person"), min_items=1)
    # There is a circular reference between Event and Person
    # schema, where the Event schema references the Person schema,
    # and the Person schema references the Event schema.
    # As a result, when set_definitions is used to set the
    # definitions for Event, there should be an assertion error
    # because the definitions for Person schema has already been set.
    definitions = SchemaDefinitions()
    set_definitions(Event, definitions)
    set_definitions(Person, definitions)

# Generated at 2022-06-12 15:53:28.579263
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        first_name = String(max_length=20)
        last_name = String(max_length=20)
    person1 = Person(first_name='A', last_name='B')
    person2 = Person(first_name='A', last_name='C')
    assert person1 == person1
    assert not person1 == person2

# Generated at 2022-06-12 15:53:36.234357
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import Field, Integer, String
    foo = String()
    bar = Integer()
    baz = String(default='baz')

    class Foo(Schema):
        foo = foo

    assert Foo.fields['foo'] is foo
    assert Foo.fields['bar'] is bar

    class Foo(Foo):
        pass

    assert Foo.fields['foo'] is foo
    assert Foo.fields['bar'] is bar

    class Bar(Schema):
        bar = bar

    assert Bar.fields['foo'] is foo
    assert Bar.fields['bar'] is bar

    class Bar(Bar):
        pass

    assert Bar.fields['foo'] is foo
    assert Bar.fields['bar'] is bar

    class Baz(Schema):
        baz = baz

    assert Baz.fields['baz'] is baz

# Generated at 2022-06-12 15:53:44.777086
# Unit test for function set_definitions
def test_set_definitions():
    class Employee(Schema):
        name = Field()
        age = Field(type="integer")
        is_full_time = Field(type="boolean")

    class Department(Schema):
        name = Field()
        employees = Array(
            items=Reference("Employee", allow_null=True, required=False)
        )

    definitions = SchemaDefinitions()
    set_definitions(Department.fields['employees'], definitions)
    assert isinstance(Department.fields['employees'], Reference)
    assert Department.fields['employees'].target is Employee

# Generated at 2022-06-12 15:53:48.293436
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Article(Schema):
        title = String()
        body = String()
        date = Date()

    a = Article(title='foo', body='bar', date='2000-01-01')
    assert repr(a) == 'Article(body="bar", date=datetime.date(2000, 1, 1), title="foo")'

# Generated at 2022-06-12 15:53:56.038742
# Unit test for constructor of class Schema
def test_Schema():
    class User(Schema):
        name = Field(type="string")
        profile = Field(type="object")
        age = Field(type="integer", nullable=True)

    user = User(name="Foo bar", profile={"foo": "bar"}, age=10)

    assert user.name == "Foo bar"
    assert user.profile == {"foo": "bar"}
    assert user.age == 10



# Generated at 2022-06-12 15:53:59.235197
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        a = String
        b = String
        c = String
    s = MySchema(a='1')
    result = list(s)
    assert result == ['a']


# Generated at 2022-06-12 15:54:05.385628
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    obj = SchemaMetaclass
    assert obj.__name__ == "SchemaMetaclass"

    class TestSchema(Schema, metaclass=SchemaMetaclass):
        def foo(self):
            pass

        def bar(self):
            pass

    assert TestSchema.__name__ == "TestSchema"

    class TestSchema2(Schema, metaclass=SchemaMetaclass):
        def foo(self):
            pass

        class TestSchema3(Schema, metaclass=SchemaMetaclass):
            def bar(self):
                pass



# Generated at 2022-06-12 15:54:14.355066
# Unit test for method validate of class Reference
def test_Reference_validate():
    class MySchema(Schema):
        field = Integer(minimum=0)
    data = {'field': 1}
    schema = MySchema(data)
    
    # test case : Allow null
    allow_null = True
    target = Integer(minimum=0)
    ref = Reference(target, allow_null)
    result = ref.validate(schema)
    assert result == schema
    
    # test case : Not allow null
    allow_null = False
    ref = Reference(target, allow_null)
    with pytest.raises(ValidationError) as excinfo:
        ref.validate(schema)
    assert 'required' in str(excinfo.value)
    
    # test case : String reference
    ref = Reference("MySchema", definitions={"MySchema": MySchema})


# Generated at 2022-06-12 15:54:17.528317
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    d = {'x':1}
    class Foo(Schema):
        x = Field(int)
        def __init__(self,x):
            self.x = x
    a = Foo(1)
    assert list(a.__iter__())==['x']
    for i in a.__iter__():
        print(i)


# Generated at 2022-06-12 15:54:22.550050
# Unit test for function set_definitions
def test_set_definitions():
    User = Schema({"name": str})

    Article = Schema(
        {
            "title": str,
            "author_id": str,
            "author": Reference("User"),
        },
    )

    definitions = SchemaDefinitions()
    set_definitions(Article.fields["author"], definitions)
    assert Article.fields["author"].definitions is definitions

# Generated at 2022-06-12 15:54:35.972735
# Unit test for function set_definitions
def test_set_definitions():
    class SchemaA(Schema):
        foo = Array(items=Reference("SchemaB"))

    class SchemaB(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(SchemaA.fields["foo"], definitions)
    assert hasattr(SchemaA.fields["foo"].items, "_target")

# Generated at 2022-06-12 15:54:48.240633
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        x = Field(type="number")
    assert set(Foo.fields.keys()) == {"x"}
    foo1 = Foo(x=1)
    assert foo1 == Foo(x=1)
    assert foo1 != Foo()
    assert Foo(x=1) == Foo(x=1)
    assert Foo(x=1) != Foo(x=2)
    assert repr(Foo(x=1)) == "Foo(x=1)"
    assert repr(Foo()) == "Foo() [sparse]"
    assert foo1["x"] == 1
    assert set(foo1.keys()) == {"x"}
    assert set(foo1.values()) == {1}
    assert set(foo1.items()) == {("x", 1)}
    assert len(foo1) == 1

# Generated at 2022-06-12 15:54:52.836908
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Test(Schema):
        t1 = "t1"
        t2 = "t2"

    obj = Test(t1="test")
    assert repr(obj) == "Test(t1='test')"


# Generated at 2022-06-12 15:54:57.623749
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class S(Schema):
        pass

    assert str(S()) == "S()"
    assert str(S(a=1, b=2)) == "S(a=1, b=2)"
    assert str(S(S(a=1, b=2))) == "S(a=1, b=2)"


# Generated at 2022-06-12 15:55:02.658760
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import random
    import types

    def equal(a, b):
        return a == b

    def nequal(a, b):
        return a != b

    def assert_equal(a, b):
        assert (a == b)

    def assert_nequal(a, b):
        assert (a != b)
    assert_nequal(len([]), 0)
    assert_nequal(len([1]), 0)
    assert_nequal(len(types.MethodType), 0)
    assert_nequal(len([]), 1)
    assert_nequal(len([1]), 1)
    assert_nequal(len(types.MethodType), 1)
    assert_nequal(len([]), 0)
    assert_nequal(len([1]), 0)

# Generated at 2022-06-12 15:55:11.890601
# Unit test for function set_definitions
def test_set_definitions():
    class Basic(Schema):
        field1 = String()
        field2 = Integer()

    class Complex(Schema):
        array = Array(items=Reference(to=Basic))

    def check_definitions(
        schema: Schema,
        definitions: typing.Mapping[str, type],
        *,
        expected: bool
    ) -> None:
        set_definitions(schema, definitions)
        assert (
            schema.fields["array"].items.definitions is definitions
        ) == expected

    check_definitions(Complex, {}, expected=True)
    check_definitions(Complex, {Basic.__name__: Basic}, expected=False)
    check_definitions(Complex, {Basic.__name__: Basic, Complex.__name__: Complex}, expected=False)

# Generated at 2022-06-12 15:55:14.186686
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import String
    from testfixtures import compare

    class UserSchema(Schema):
        name = String()
        password = String()

    schema = UserSchema(name="alice", password="pass")
    compare(len(schema), 2)



# Generated at 2022-06-12 15:55:18.936202
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        attr1 = String(max_length=10)
        attr2 = Integer()

    s = TestSchema(attr1='a', attr2=10)
    assert repr(s) == "TestSchema(attr1='a', attr2=10)"

    parents = [BaseSchema() for i in range(10)]
    child = ChildSchema(**{'s': 'abc', 'i': 10})
    for parent in parents:
        child.parents.append(parent)

    print(repr(child))

# Generated at 2022-06-12 15:55:27.391316
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class _Schema1(Schema):
        a = Field()
        b = Field()
    class _Schema2(_Schema1):
        pass
    class _Schema3(_Schema2):
        c = Field()
    class _Schema4(_Schema3):
        d = Field()

    s1 = _Schema1(a="string", b="string")
    s2 = _Schema1(a="string", b="string")
    s3 = _Schema2(a="string", b="string")
    s4 = _Schema3(a="string", b="string", c="string")
    s5 = _Schema4(a="string", b="string", c="string", d="string")

    assert s1 == s2
    assert s2 == s1
    assert s1 == s3

# Generated at 2022-06-12 15:55:32.656467
# Unit test for function set_definitions
def test_set_definitions():

    class Def(Schema):
        id = Array(items=[Reference("Test"), Reference("Test")])
        title = "test"

    d = SchemaDefinitions()
    set_definitions(Def, d)

    assert Def.fields["id"].items[0].target == Def.fields["id"].items[1].target == Def
    assert d == {'Def': Def}

# Generated at 2022-06-12 15:55:43.644899
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class SomeSchema(Schema):
        field = Field()
    obj = SomeSchema(field = 'value')
    assert repr(obj) == "SomeSchema(field='value')"



# Generated at 2022-06-12 15:55:44.968943
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    assert len(schema) == 0

# Generated at 2022-06-12 15:55:46.119342
# Unit test for function set_definitions
def test_set_definitions():
    assert False

# Generated at 2022-06-12 15:55:48.107690
# Unit test for constructor of class Schema
def test_Schema():
    assert hasattr(Schema, "__init__")
    assert callable(Schema.__init__)



# Generated at 2022-06-12 15:55:54.475924
# Unit test for function set_definitions
def test_set_definitions():
    class DefinitionClass(metaclass=SchemaMetaclass):
        class_property = None  # type: Field
        class_property2 = None  # type: Field
    schema = DefinitionClass()
    schema.class_property = Object(properties={"a": String()}, required=["a"])
    schema.class_property2 = Object(properties={"b": Reference(to="a")}, required=["b"])
    assert schema.class_property2.to == "a"
    assert schema.class_property2.target is None
    definitions = {}
    set_definitions(schema.class_property, definitions)
    set_definitions(schema.class_property2, definitions)
    assert schema.class_property2.target is schema.class_property.properties["a"]

# Generated at 2022-06-12 15:56:04.993129
# Unit test for function set_definitions
def test_set_definitions():
    def assert_has_definitions(field: Field, definitions: SchemaDefinitions):
        assert (
            field.definitions is definitions
        ), f"Field {field} does not have expected definitions."

    definitions = SchemaDefinitions()
    item = Field()
    set_definitions(item, definitions)
    assert_has_definitions(item, definitions)

    array = Array(items=item)
    set_definitions(array, definitions)
    assert_has_definitions(array, definitions)
    assert_has_definitions(array.items, definitions)

    obj = Object(properties={"foo": array}, required=["foo"])
    set_definitions(obj, definitions)
    assert_has_definitions(obj, definitions)
    assert_has_definitions(obj.properties["foo"], definitions)
    assert_

# Generated at 2022-06-12 15:56:12.742394
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import Integer, String

    class foo(Schema):
        foo_name = String()
        foo_age = Integer()
        foo_address = String()

    assert len(foo()) == 3
    assert len(foo(foo_name="foo", foo_age=123)) == 2
    assert len(foo(foo_name="foo", foo_age=123, foo_address="foo address")) == 3


# Generated at 2022-06-12 15:56:22.282103
# Unit test for constructor of class Schema
def test_Schema():
    class Pet(Schema):
        name = String(max_length=50, default="Fluffy")
        age = Integer(gte=0)
        is_vaccinated = Boolean(default=True)
        owners = Array(items=String(max_length=50))

    class Person(Schema):
        name = String(max_length=50)
        pets = Array(items=Pet())

    pet = Pet({"name": "Fluffy", "age": 3})
    assert pet.name == "Fluffy"
    assert pet.age == 3
    assert pet.is_vaccinated == True
    assert pet.owners == []

    person = Person({"name": "Bob", "pets": [pet]})
    assert person.name == "Bob"
    assert person.pets == [pet]


# Generated at 2022-06-12 15:56:34.843161
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.object import Object
    from typesystem.types import String, Integer, Array
    from typesystem.base import ValidationError

    class User(Schema):
        name = String()
        age = Integer()

    class Book(Schema):
        title = String()
        author = Reference(User, allow_null=True)

    class Books(Schema):
        books = Array(Reference(Book))

    user = {'name': 'Marcus', 'age': 30}

    book = {'title': 'The Obsidian Chamber', 'author': user}

    books = {'books': [book]}
    obj = Books(books)

    assert obj.books[0].author == User(user)

    book = {'title': 'The Obsidian Chamber', 'author': None}
    books = {'books': [book]}
   

# Generated at 2022-06-12 15:56:44.604453
# Unit test for function set_definitions
def test_set_definitions():
    d = SchemaDefinitions()
    for to in [
        (Array(Reference("Human")), Reference("Human")),
        (Array(Object(age=Integer())), Object(age=Integer())),
        (
            Array(Object(name=String(), age=Integer())),
            Array(Object(name=String(), age=Integer())),
        ),
        (
            Array(
                Tuple(
                    [
                        Object(
                            name=String(),
                            age=Integer(),
                        )
                    ],
                    tuple_name="Human",
                )
            ),
            Tuple(
                [
                    Object(
                        name=String(),
                        age=Integer(),
                    )
                ],
                tuple_name="Human",
            ),
        ),
    ]:
        set_definitions(to[0], d)


# Generated at 2022-06-12 15:56:59.140487
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from .models import Article, Person, GithubUser
    article = Article(id=1, title='test', content='test')
    assert repr(article) == "Article(content='test', title='test', id=1)"
    person = Person(name='test', age=22)
    assert repr(person) == "Person(age=22, name='test') [sparse]"
    github_user = GithubUser(id=1, login='test')
    assert repr(github_user) == "GithubUser(id=1, login='test')"


# Generated at 2022-06-12 15:57:09.957859
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    a = Flower()
    b = Flower()
    
    # case where two objects are identical
    assert a == b
    
    # case where all field values in A, but not B are the same
    a = Flower(name = "Petunia")
    b = Flower(name = "Petunia", genus = "Husker")
    res = a == b
    assert res == False
    
    # case where all field values in B, but not A are the same
    a = Flower(name = "Petunia")
    b = Flower(name = "Petunia", genus = "Husker")
    res = b == a
    assert res == False
    
    # case where field values differ
    a = Flower(name = "Petunia")
    b = Flower(name = "Husker")
    assert a != b
    
   

# Generated at 2022-06-12 15:57:14.748334
# Unit test for function set_definitions
def test_set_definitions():
    class Value(Schema):
        name = Field()
        weight = Field(type=float)

    class Item(Schema):
        name = Field()
        value = Reference(to="Value")

    defs = SchemaDefinitions()
    set_definitions(Item.make_validator(), defs)
    assert Item.validate({"name": "foo", "value": {"name": "bar"}}) == Item(
        name="foo", value=Value(name="bar")
    )

# Generated at 2022-06-12 15:57:27.423898
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Schema1(Schema):
        a = Field(String)
        b = Field(Float)

    class Schema2(Schema1):
        a = Field(Integer)
        c = Field(Array(String))

    class Schema3(Schema1):
        b = Field(Float, default=0)

    obs = list(iter(Schema2({'a': 2, 'b': 2.0, 'c': ['a', 'b']})))
    exp = ['a', 'b', 'c']
    assert obs == exp
    obs = list(iter(Schema2({'a': 2, 'c': ['a', 'b']})))
    exp = ['a', 'c']
    assert obs == exp
    obs = list(iter(Schema3({'a': 'a'})))

# Generated at 2022-06-12 15:57:36.012535
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # all_fields: includes all the fields in the model
    all_fields = {
        "user_id": Field(type="string"),
        "user_name": Field(type="string"),
        "user_email": Field(type="string"),
    }

    # parent_attrs: includes the fields for class ParentSchema
    parent_attrs = {
        "user_id": Field(type="string"),
        "user_name": Field(type="string"),
    }

    # child_attrs: includes the fields for class ChildSchema
    child_attrs = {
        "user_email": Field(type="string"),
    }

    # definitions: definitions for the Reference field
    definitions = SchemaDefinitions()

    # create class ParentSchema

# Generated at 2022-06-12 15:57:38.596668
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String("Name of the person")
    p = Person(name="Jojo")
    assert len(p) == 1

# Generated at 2022-06-12 15:57:46.433323
# Unit test for constructor of class Schema
def test_Schema():
    class FoobarSchema(Schema):
        foobar1 = String()
        foobar2 = Integer()

    assert json.dumps(FoobarSchema()) == r'{}'
    try:  # expected to fail due to being not valid
        json.dumps(FoobarSchema({"foobar1": "bar", "foobar2": "foo"}))
    except Exception as e:
        print(e)
    assert json.dumps(FoobarSchema({"foobar1": "bar", "foobar2": 1})) == r'{"foobar1":"bar","foobar2":1}'
    assert json.dumps(FoobarSchema(foobar1="bar", foobar2=1)) == r'{"foobar1":"bar","foobar2":1}'



# Generated at 2022-06-12 15:57:48.168286
# Unit test for constructor of class Schema
def test_Schema():
    x = Schema(foo = 1)
    assert x.foo == 1


# Generated at 2022-06-12 15:57:56.426099
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import Integer, String
    from typesystem.base import ValidationResult
    from typesystem.exceptions import ValidationError
    def test_validate(val:Schema):
        if val.a==1:
            return ValidationResult(value=None, error=ValidationError(["a==1"]))
        if val.b==2:
            return ValidationResult(value=None, error=ValidationError(["b==2"]))
        return ValidationResult(value=val, error=None)
    def test_validate_or_error(val:Schema):
        if val.a==1:
            return ValidationResult(value=None, error=ValidationError(["a==1"]))

# Generated at 2022-06-12 15:58:05.027750
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class FooSchema(Schema):
    
        name = String()
    
        age = Integer()

    # Create a schema with all fields defined.
    instance = FooSchema(name="John", age=42)
    assert repr(instance) == "FooSchema(name='John', age=42)"

    # Create a sparse schema.
    instance = FooSchema(name="John")
    assert repr(instance) == "FooSchema(name='John') [sparse]"


# Generated at 2022-06-12 15:58:14.210965
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass # TODO


# Generated at 2022-06-12 15:58:19.672792
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Create the schema to test
    class BookSchema(Schema):
        title = String()
        author = String()
        publisher = String()
        keywords = Array(String())

    # Create an instance of the schema
    book = BookSchema(title="The Three Little Pigs", author="J. D. Salinger")

    assert [key for key in book] == ['title', 'author']

# Generated at 2022-06-12 15:58:26.606310
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Base(Schema):
        pass

    class Sub(Base):
        pass

    # First test the equality of two unique objects
    a = Sub(name="abc", url="123")
    b = Sub(name="abc", url="123")
    assert a == b

    # Make sure the elements are not the same object in memory
    assert a is not b

    # Ensure the equality of two identical objects
    assert a == a

    # Test if the equality check is of the correct type
    assert a != Base(url="123")

    # Test if the equality check is of the correct type
    assert a != object()

    # Test if the equality check is of the correct type
    assert a != 123

    # Test if the equality check is of the correct type
    assert a != "abc"


# Generated at 2022-06-12 15:58:31.930007
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()

    ref = Reference(to=Person, definitions={Person.__name__: Person})
    assert ref.target_string == "Person"
    assert ref.target == Person
    person = ref.validate({"name": "John", "age": 23})
    assert person.__class__ == Person
    assert person.name == "John"
    assert person.age == 23


# Generated at 2022-06-12 15:58:38.481468
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import random
    from typesystem import Schema, String

    class MySchema(Schema):
        title = String(required=True)

    params_list = []
    for i in range(0, 100):
        params = {
            "title": "",
        }
        params_list.append(params)

    for i in range(0, 200):
        obj1 = MySchema(**random.choice(params_list))
        obj2 = MySchema(**random.choice(params_list))

        ret = obj1 == obj2
        assert type(ret) is bool

# Generated at 2022-06-12 15:58:42.573200
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String
        age = Integer
        alive = Boolean

    person = Person(name="Diana", age=27)
    expected = "Person(name='Diana', age=27)"
    assert expected == person.__repr__()



# Generated at 2022-06-12 15:58:48.124289
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        address = String()
        picture = String()

    a = TestSchema(name="foo")
    assert [key for key in a] == ["name"]
    a.age = 10
    a.address = "bar"
    assert [key for key in a] == ["age", "address", "name"]
    a.age = None
    assert [key for key in a] == ["address", "name"]

test_Schema___iter__()



# Generated at 2022-06-12 15:58:49.135184
# Unit test for constructor of class Schema
def test_Schema():
    obj = Schema(value=None)
    assert obj is not None


# Generated at 2022-06-12 15:58:52.348509
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():

    from typesystem.base import String

    class MySchema(Schema):

        x = String(name="x")

    my_schema = MySchema(x="test")
    iterator = my_schema.__iter__()

    assert iterator is not None

    expected = ["x", "fields"]
    actual = [i.__str__() for i in iterator]
    assert expected == actual



# Generated at 2022-06-12 15:59:03.645692
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    """unit test for method __len__

    Arguments:
        field {[type]} -- object instance of class Schema

    Returns:
        bool -- If the test fails, it will raise an AssertionError.
    """
    class Schema1(Schema):
        field1 = String(required=True, max_length=12)
        field2 = Integer(required=True)
        field3 = Object(
            properties={
                "field4": String(required=True, min_length=1),
                "field5": String(required=True, min_length=1),
            },
            required=["field4", "field5"],
            additional_properties=False,
        )


# Generated at 2022-06-12 15:59:25.161040
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class PersonSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    class Person(PersonSchema):
        pass

    person = Person(name = 'Bengt', age = 24)
    person2 = Person(name = 'Bengt', age = 24)
    assert person == person2


# Generated at 2022-06-12 15:59:27.466133
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(name="yisong", password="123")
    assert schema.name == "yisong"
    assert schema.password == "123"
    assert schema.is_sparse is True


# Generated at 2022-06-12 15:59:28.399595
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass


# Generated at 2022-06-12 15:59:37.012103
# Unit test for function set_definitions
def test_set_definitions():
    class FooSchema(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()

    assert FooSchema.fields["foo"].definitions is None
    assert FooSchema.fields["foo"].target is None

    set_definitions(FooSchema.fields["foo"], definitions=definitions)

    assert FooSchema.fields["foo"].definitions is definitions
    assert FooSchema.fields["foo"].target is None

    definitions[FooSchema.fields["foo"].target_string] = FooSchema

    assert FooSchema.fields["foo"].definitions is definitions
    assert FooSchema.fields["foo"].target is FooSchema

# Generated at 2022-06-12 15:59:40.437984
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        name = String()
        dob = String()
        gender = String()
    
    schema = MySchema(name="Smith", dob="18-06-1990", gender="M")
    
    assert len(schema) == 2
    assert set(schema.keys()) == set(['name', 'dob'])

# Generated at 2022-06-12 15:59:41.916135
# Unit test for method validate of class Reference
def test_Reference_validate():
	assert Reference(None).validate(None) is None


# Generated at 2022-06-12 15:59:45.955295
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import typesystem
    class GetItem(Schema):
        a = typesystem.Integer()
    get_item = GetItem(a=1)
    assert get_item['a'] == 1


# Generated at 2022-06-12 15:59:50.972974
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    x = Schema()
    x.validate({"a": 1, "b": 2, "c": 3})
    assert iter(x) == iter(["a", "b", "c"])


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-12 15:59:52.269617
# Unit test for method __len__ of class Schema
def test_Schema___len__():
  print(Schema.__len__(Schema))
  

# Generated at 2022-06-12 15:59:58.956069
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    class MySchema(Schema):
        my_string = String()
    my_schema = MySchema(my_string='testing')
    assert len(my_schema) == 1
    my_schema = MySchema()
    assert len(my_schema) == 0
