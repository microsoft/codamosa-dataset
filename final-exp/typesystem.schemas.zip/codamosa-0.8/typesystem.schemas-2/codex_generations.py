

# Generated at 2022-06-12 15:50:38.157727
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class MySchema(Schema):
        foo = Field(type="str", allow_null=False)
        bar = Field(type="str", allow_null=False)
    value = MySchema({
        "foo": "foo",
        "bar": "bar"
    })
    value2 = MySchema({
        "foo": "foo",
        "bar": "bar"
    })
    assert value == value2, "Expected equality."


# Generated at 2022-06-12 15:50:48.825477
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class SchemaMetaclass(
        SchemaMetaclass
    ):  # type: ignore # type: ignore
        def __new__(
            cls: type,
            name: str,
            bases: typing.Sequence[type],
            attrs: dict,
            definitions: SchemaDefinitions = None,
        ):  # type: ignore
            new_type = super(SchemaMetaclass, cls).__new__(  # type: ignore
                cls, name, bases, attrs
            )
            if definitions is not None:
                definitions[name] = new_type
            return new_type

    def test_base_class_fields():
        class Foo(metaclass=SchemaMetaclass):
            """
            A field-less base class for `Bar`.
            """

            pass


# Generated at 2022-06-12 15:50:53.227599
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        string_field = String()
        
    TestSchema().__len__() == TestSchema(string_field = " ").__len__() == TestSchema(string_field = " ").__len__() == 1
    assert 1 == TestSchema().__len__() == TestSchema(string_field = " ").__len__() == TestSchema(string_field = " ").__len__()


# Generated at 2022-06-12 15:50:56.254919
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    field = Reference("to")
    set_definitions(field, definitions)
    assert field.definitions is definitions
    field = Reference("to", definitions=definitions)
    set_definitions(field, definitions)
    assert field.definitions is definitions

# Generated at 2022-06-12 15:51:00.445243
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Boolean, Integer, String

    class Pet(Schema):
        age = Integer(description="Age of the animal in years.")
        is_alive = Boolean(default=True)
        name = String()

    pet = Pet(
        {
            "name": "Tiddles",
            "age": 3
        }
    )

    assert len(list(pet)) == 2
    assert "name" in pet
    assert "is_alive" not in pet



# Generated at 2022-06-12 15:51:03.733523
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field()
        age = Field()
        gender = Field()
    
    p = Person(name='John', age=30, gender='Male')
    assert p.name == 'John'
    assert p.age == 30
    assert p.gender == 'Male'


# Generated at 2022-06-12 15:51:04.336323
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass



# Generated at 2022-06-12 15:51:12.831854
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Number()

    john = Person(name='John Doe', age=42)
    assert john == Person(name='John Doe', age=42)
    assert john.is_sparse == False
    assert john.__repr__() == "Person(name='John Doe', age=42)"

    john = Person({'name':'John Doe', 'age':42})
    assert john == Person({'name':'John Doe', 'age':42})
    assert john.is_sparse == False
    assert john.__repr__() == "Person(name='John Doe', age=42)"

    john = Person({'name':'John Doe'})
    assert john == Person({'name':'John Doe'})
    assert john.is_sparse == True
    assert john

# Generated at 2022-06-12 15:51:19.596779
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Tests for hidden attributes
    from typesystem import Integer, String


    class Person(Schema):
        id = Integer()
        first_name = String()
        last_name = String()


    person = Person(id=1, first_name="John", last_name="Doe")
    assert list(person.__iter__()) == ["id", "first_name", "last_name"]


# Generated at 2022-06-12 15:51:25.589539
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Test_Schema(Schema):
        name = String()
        age = Integer()

    obj = Test_Schema(name="Bob", age=15)
    assert obj["name"] == "Bob"
    assert obj["age"] == 15
    assert obj.get("name") == "Bob"

    with pytest.raises(KeyError):
        obj["height"]

    assert obj.get("height") == None

    assert obj.get("height", 200) == 200

# Generated at 2022-06-12 15:51:43.489652
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        name = String(required=True)

    left = TestSchema("test")
    right = TestSchema("test")
    assert left == right



# Generated at 2022-06-12 15:51:46.755228
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String
    from typesystem import schema

    class TestSchema(schema.Schema):
        a = String()
        b = String()
        c = String()

    ts = TestSchema(a="hello")

    assert len(ts) == 1
    assert [key for key in ts] == ["a"]



# Generated at 2022-06-12 15:51:55.835789
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class SimpleSchema(Schema):
        field_1 = Object(properties={'field_1_1': Field(type="string")})
        field_2 = Field(type="string", required=True)

    a = SimpleSchema(field_1={'field_1_1': 'string_1_1'}, field_2='string_2')

    assert repr(a) == "SimpleSchema(field_1={'field_1_1': 'string_1_1'}, field_2='string_2')"

# Generated at 2022-06-12 15:52:00.271061
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from collections import OrderedDict
    class TestSchema(Schema):
        field1 = String()
        field2 = String()

    input_dict = OrderedDict([('field1', 'value'), ('field2', 'value')])

    assert TestSchema(input_dict) == TestSchema({'field1': 'value', 'field2': 'value'})

# Generated at 2022-06-12 15:52:03.404859
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        name = String(max_length=100)

    assert repr(TestSchema()) == 'TestSchema() [sparse]'

# Generated at 2022-06-12 15:52:07.469007
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class A(Schema):
        foo = Integer()

    # `A.fields['foo']` is a `Reference` with `definitions=None`
    set_definitions(A.fields['foo'], definitions)
    assert A.fields['foo'].definitions == definitions

# Generated at 2022-06-12 15:52:10.408261
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import Integer, String

    class Movie(Schema):
        title = String()
        year = Integer()

    defs = SchemaDefinitions()
    Reference("Movie", definitions=defs)



# Generated at 2022-06-12 15:52:12.772558
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema(name = 'nome')
    assert list(schema.__iter__()) == ['name']


# Generated at 2022-06-12 15:52:24.118646
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        pass
    class B(Schema):
        pass
    defs = SchemaDefinitions()
    field = Reference("a")
    set_definitions(field, defs)
    assert field.definitions is defs
    field2 = Reference(A)
    set_definitions(field2, defs)
    assert field2.definitions is None
    array = Array(items=Reference("a"))
    set_definitions(array, defs)
    assert array.items.definitions is defs
    array2 = Array(items=[Reference("a"), Reference(B)])
    set_definitions(array2, defs)
    assert array2.items[0].definitions is defs
    assert array2.items[1].definitions is None


# Generated at 2022-06-12 15:52:28.937163
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import Integer, String

    class User(Schema):
        id = Integer()
        name = String()

    user = User(id=1, name='john')
    user1 = User(id=1, name='john')
    user2 = User(id=1, name='john', age=30)

    assert user1 == user2
    assert not user == user2

# Generated at 2022-06-12 15:52:40.542021
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    s1 = Schema({"a": 1, "b": 2})
    s2 = Schema({"a": 1, "b": 2})
    assert s1 == s2
    s3 = Schema({"a": 3, "b": 2})
    assert not (s1 == s3)
    s4 = Schema({"a": 1, "b": 2, "c": 3})
    assert not (s1 == s4)


# Generated at 2022-06-12 15:52:52.160826
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from unittest import TestCase
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String
    from typesystem.main import Schema
    from parameterized import parameterized

    class Person(Schema):
        name = String()

    class Hotel(Schema):
        name = String()

    class Reservation(Schema):
        hotel = Reference(Hotel)
        person = Reference(Person)


# Generated at 2022-06-12 15:52:56.753500
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Integer, String

    class User(Schema):
        id = Integer(primary_key=True)
        name = String()

    assert User(dict(id=1, name="Obi-Wan Kenobi")).name == "Obi-Wan Kenobi"

# Generated at 2022-06-12 15:53:07.266743
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Test1(Schema):
        field1 = "field1"

    class Test2(Schema):
        field2 = "field2"

    test_object = Test1(Test2("value"))
    assert repr(test_object) == 'Test1(field1=Test2("value"))'

    class Test3(Schema):
        field1 = "field1"
        field2 = "field2"

    class Test4(Schema):
        field3 = "field3"

    test_object = Test3(Test4("value"))
    assert repr(test_object) == "Test3(field1=None, field2=None)"

# Generated at 2022-06-12 15:53:13.685480
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from .models import Movie
    m1 = Movie(title='Wonder Woman', director='Patty Jenkins', year=2017)
    m2 = Movie(title='Wonder Woman', director='Patty Jenkins', year=2017)
    m3 = Movie(title='Mr. Nobody', director='Jaco Van Dormael', year=2009, genre='Science Fiction')
    assert m1 == m1, 'AssertionError: First object is not equal to itself'
    assert m1 != m3, 'AssertionError: First object is equal to a different object'
    assert m1 == m2, 'AssertionError: First and second objects are not equal'


# Generated at 2022-06-12 15:53:19.282659
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
	"""
	Unit test for __iter__ function
	of class Schema
	"""
	from pymongo import MongoClient
	from bson.objectid import ObjectId
	from pymongo.collection import Collection

	from odcs.processors import BaseProcessor

	from odcs.test_utils import TestUtils

	db = MongoClient(host='localhost',port=27017)
	collection = db['odcs']['test_schema']

	del collection['_id']
	collection.insert_one({'a': 1, 'b': 2})

	data = {
		'a': 1,
		'b': 2
	}


	schema = Schema()
	schema.fields

	schema.__iter__()

	collection.delete_one(data)

	db.close()

# Generated at 2022-06-12 15:53:25.498139
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import Schema, Object
    from typesystem import Integer, String
    class Person(Schema):
        name = String()
        age = Integer()
    p1 = Person()
    p2 = Person(name=String(), age=Integer(), sex=String())
    assert isinstance(p1, Mapping)
    assert isinstance(p2, Mapping)
    assert isinstance(p1.fields['name'], String)
    assert isinstance(p2.fields['name'], String)
    assert isinstance(p1.fields['age'], Integer)
    assert isinstance(p2.fields['age'], Integer)
    assert isinstance(p1.fields['sex'], String)
    assert isinstance(p2.fields['sex'], String)


# Generated at 2022-06-12 15:53:28.641664
# Unit test for constructor of class Schema
def test_Schema():
    data = {'a': 1, 'b': 'hello'}
    schema = Schema(data)
    assert schema.a == 1
    assert schema.b == 'hello'


# Generated at 2022-06-12 15:53:35.329217
# Unit test for method __len__ of class Schema
def test_Schema___len__():
	#####################################################################
	# Test #1: test len(Schema)
	#####################################################################
	import json
	import typesystem
	from typing import Dict, Any
	class TestSchema(Schema):
		definitions = SchemaDefinitions()
		one = typesystem.Integer()
		two = typesystem.Integer()
		three = typesystem.Integer()
	test_schema = TestSchema(one=1, two=2)
	number = len(test_schema)
	## STEP 1: get result from len(test_schema).
	assert number == 2, "The returned result is wrong."
	# return number


# Generated at 2022-06-12 15:53:38.665325
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Book(Schema):
        title = String()
        author = String()

    book1 = Book({"title": "Metamorphosis", "author": "Franz Kafka"})
    book2 = Book({"title": "Metamorphosis", "author": "Franz Kafka"})

    assert(book1 == book2)

    book3 = Book({"title": "Metamorphosis", "author": "Franz Kafka", "price": 10})
    assert(book1 != book3)


# Generated at 2022-06-12 15:53:55.894030
# Unit test for constructor of class Schema
def test_Schema():
  class Person(Schema):
    name = String(max_length=64)
    age = Number(minimum=0)

  p = Person({'name': 'Bob', 'age': 25})
  assert p.name == 'Bob'
  assert p.age == 25


# Generated at 2022-06-12 15:53:59.107984
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import String

    class SomeSchema(Schema):
        name = String(required=True)

    some_schema = SomeSchema(name="value")
    assert len(some_schema) == 1

# Generated at 2022-06-12 15:54:06.797553
# Unit test for constructor of class Schema
def test_Schema():
    import datetime
    from .utils import get_current_datetime
    
    class Person(Schema):
        name = String(max_length=255, min_length=1)
        age = Integer(maximum=200)
        height = Float()
        dob = Date()
        created = DateTime(default=get_current_datetime)
        changed = DateTime(default=get_current_datetime, nullable=True)

    person = Person(
        name="John Smith", age=38, height=1.79, dob=datetime.date(1981, 1, 1)
    )
    assert person.name == "John Smith"
    assert person.age == 38
    assert person.height == 1.79
    assert person.dob == datetime.date(1981, 1, 1)

# Generated at 2022-06-12 15:54:14.540842
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        key1 = Field()
        key2 = Field()
        key3 = Field()
    
    assert TestSchema(key1=1, key2=2) == TestSchema(key1=1, key2=2)
    assert TestSchema(key1=1, key2=2) != TestSchema(key1='1', key2=2)
    assert TestSchema(key1=1, key2=2) != TestSchema(key1=1, key2=2, key3=3)
    assert TestSchema(key1=1, key2=2) != TestSchema(key1=1, key2=3)


# Generated at 2022-06-12 15:54:23.282723
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import fields
    from typesystem import schema

    class UserSchema(schema.Schema):
        id = fields.Integer(format="int64")
        name = fields.String()
        email = fields.String()

    assert ["id", "name", "email"] == list(UserSchema({"id": 1, "email": "a@a.com"}).__iter__())
    assert ["id", "email"] == list(UserSchema({"id": 1, "email": "a@a.com"}, name="name").__iter__())


test_Schema___iter__()



# Generated at 2022-06-12 15:54:28.278209
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema=Schema(a=1,b=2,c=3)
    assert len(schema)==3
    delattr(schema,'c')
    assert len(schema)==2
    schema=Schema(a=1,b=2)
    schema=schema[:]
    assert len(schema)==2
    schema['a']=None
    assert len(schema)==1


# Generated at 2022-06-12 15:54:36.992627
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        a = Reference("Bar")

    class Bar(Schema):
        b = Reference("Baz")
        c = Reference("Baz")

    class Baz(Foo):
        d = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["a"], definitions)
    assert Foo.fields["a"].definitions is definitions
    assert Bar.fields["b"].definitions is definitions
    assert Bar.fields["c"].definitions is definitions
    assert Baz.fields["a"].definitions is definitions
    assert Baz.fields["d"].definitions is definitions



# Generated at 2022-06-12 15:54:48.493103
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import Integer, String
    from unittest import TestCase

    class Movie(Schema):
        title = String()
        director = String()
        year = Integer(minimum=1895, maximum=2019)

    class Collection(Schema):
        movies = Reference(to="Movie")

    definitions = SchemaDefinitions()

    collection = Collection.validate(
        {
            "movies": {
                "title": "The Cabinet of Dr. Caligari",
                "director": "Robert Wiene",
                "year": 1920,
            }
        },
        strict=True,
    )

    assert isinstance(collection.movies, Movie)
    assert collection.movies.title == "The Cabinet of Dr. Caligari"
    assert collection.movies.director == "Robert Wiene"
    assert collection.m

# Generated at 2022-06-12 15:54:54.149077
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class S(Schema):
        a = Integer(required=True, description="a")
        b = Integer(description="b")
        c = Integer(description="c")
    s = S(a=3, c=5)
    assert set(s.keys()) == {'a', 'c'}

# Generated at 2022-06-12 15:55:00.507616
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        name = String()
        age = Integer()

    class Person(Schema):
        testschema = Reference(to="TestSchema")

    definitions = SchemaDefinitions()
    person = Person.validate(
        {"testschema": {"name": "John", "age": 23}}, definitions=definitions
    )
    assert person.testschema.name == "John"
    assert person.testschema.age == 23



# Generated at 2022-06-12 15:55:59.026248
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Instance of the class
    instance = Schema({'a': 'b'})
    # Calling the method with instance and testing the returned value
    assert instance.__repr__() == 'Schema(a=\'b\')'


# Generated at 2022-06-12 15:56:07.436868
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    fields = {
        "foo": Reference("Foo", definitions=definitions),
        "bar": Reference("Bar", definitions=definitions),
        "baz": Reference("Bar", definitions=definitions),
        "qux": Reference("Qux", definitions=definitions),
        "quux": Array(String()),
        "corge": Array(String()),
        "grault": Array(Reference("Grault", definitions=definitions)),
        "garply": Object(
            properties={
                "waldo": Reference("Qux", definitions=definitions),
                "fred": Array(String()),
                "plugh": Array(Reference("Grault", definitions=definitions)),
            }
        )
    }

    assert definitions == {}
    set_definitions(fields, definitions)
    assert definitions

# Generated at 2022-06-12 15:56:15.766181
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        animal_id = Integer(format="int64")
        category_id = Integer(format="int32")
        price = Number()
        name = String()
    TestData = TestSchema(
        animal_id=5,
        category_id=6,
        price=11.35,
        name="woof",
    )
    assert TestData["animal_id"] == 5
    assert TestData["category_id"] == 6
    assert TestData["price"] == 11.35
    assert TestData["name"] == "woof"


# Generated at 2022-06-12 15:56:16.527481
# Unit test for method validate of class Reference
def test_Reference_validate():
    Reference.validate(1, strict = False)


# Generated at 2022-06-12 15:56:20.494216
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Val(Schema):
        user_id = str
    val = Val(user_id='xu')
    val2 = Val('xu')
    assert val == val2
    assert val.user_id == val2.user_id
    return val, val2


# Generated at 2022-06-12 15:56:25.968743
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Initialising class Reference with the parameters to, definitions and strict of class Field (Note: adding the parameters strict and definitions in test case 2)
    Reference_class = Reference("object", "definitions", strict=False)
    # Unit test case 1: value is None, attribute allow_null is False => Result: ValueError
    try:
        Reference_class.validate(value=None)
    except ValueError as err:
        print("ValueError")
    # Unit test case 2: value is None, attribute allow_null is True => Result: None
    Reference_class.allow_null = True
    print(Reference_class.validate(value=None))
   

# Generated at 2022-06-12 15:56:37.869710
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    field = Field()
    set_definitions(field, definitions)
    assert field.definitions is definitions

    definitions = SchemaDefinitions()
    field = Array(items=Field())
    set_definitions(field, definitions)
    assert field.items[0].definitions is definitions

    definitions = SchemaDefinitions()
    field = Array(
        items=[
            Field(),
            Field(),
        ]
    )
    set_definitions(field, definitions)
    assert field.items[0].definitions is definitions
    assert field.items[1].definitions is definitions

    definitions = SchemaDefinitions()
    field = Object(
        properties={
            "one": Field(),
            "two": Field()
        }
    )
    set_definitions(field, definitions)
   

# Generated at 2022-06-12 15:56:40.172081
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    s = Schema(
        name="john",
        age=27,
    )
    assert list(s) == ['name', 'age']


# Generated at 2022-06-12 15:56:43.455235
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        a = Field()
    test_schema = TestSchema()
    test_schema['a']
    try:
        test_schema['b']
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-12 15:56:49.423475
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Address(Schema):
        line1 = Field(type=str)
        line2 = Field(type=str, allow_null=True)
        city = Field(type=str)
        state = Field(type=str)
        zip_code = Field(type=str)
        country = Field(type=str)

    address = Address(
        line1="6th Street",
        line2=None,
        city="New York",
        state="NY",
        zip_code="10010",
        country="USA",
    )

    assert address.line1 == "6th Street"
    assert address.line2 == None
    assert address.city == "New York"
    assert address.state == "NY"
    assert address.zip_code == "10010"
    assert address.country == "USA"

# Generated at 2022-06-12 15:57:21.040566
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = Field(min_length=1)
        age = Field(type="integer")

        class Meta:
            strict = True

    person = Person(name="Alice")

    if len(person) == 2:
        assert True
    elif len(person) == 1:
        assert True
    else:
        assert False


# Generated at 2022-06-12 15:57:32.118647
# Unit test for constructor of class Schema
def test_Schema():
    # Test for successful schema creation
    class TestSchema(Schema):
        name = String(format='date-time')
        age = Integer(maximum=50)
        height = Float(minimum=5.0, maximum=6.5)
    schema = TestSchema(name='2013-03-21T03:06:00', age=13, height=5.2)
    assert(type(schema) == TestSchema)
    assert(schema == TestSchema(name='2013-03-21T03:06:00', age=13, height=5.2))
    assert(schema != TestSchema(name='2013-03-21T03:06:01', age=13, height=5.2))

    # Test for missing field

# Generated at 2022-06-12 15:57:42.804835
# Unit test for method __eq__ of class Schema
def test_Schema___eq__(): 
    class A(Schema):
        a = Field()
        b = Field()

    assert A(a=1, b=2) == A(a=1, b=2)
    assert A(a=1, b=2) != A(a=1, b=1)
    assert A(a=1, b=2) != A(a=1)

    field = Field()
    assert A(a=field, b=2) == A(a=field, b=2)
    assert A(a=field, b=2) != A(a=field, b=1)
    assert A(a=field, b=2) != A(a=field)
    assert A(a=field, b=2) != A(b=2)



# Generated at 2022-06-12 15:57:48.309142
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from unittest import TestCase
    from typesystem import Integer, String

    class Stuff(Schema):
        id = Integer(minimum=1)
        name = String(max_length=100)

    stuff = Stuff({"id": 1, "name": "cheese"})

    TestCase().assertEqual(list(stuff), ["id", "name"])



# Generated at 2022-06-12 15:57:50.366720
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test get non-existent key
    item = {
        "boolean": True
    }
    assert item["boolean"] == True


# Generated at 2022-06-12 15:57:58.966998
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test cases

    # Test case #1
    # Assert the type of return value of SchemaMetaclass.__new__
    # is type
    assert type(SchemaMetaclass.__new__(
        SchemaMetaclass, 'test_SchemaMetaclass___new__', (), {})) is type

    # Test case #2
    # Assert the length of fields of the return value of SchemaMetaclass.__new__
    # is 0
    assert len(SchemaMetaclass.__new__(
        SchemaMetaclass, 'test_SchemaMetaclass___new__', (), {}).fields) == 0

    # Test case #3
    # Assert the length of fields of the return value of SchemaMetaclass.__new__
    # is 4, if the argument attrs is {'field1

# Generated at 2022-06-12 15:58:06.167079
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    
    class A(Schema):
        f1 = Field()
        f2 = Field()

    test_schema = A(f1=3, f2=6)
    class_name = test_schema.__class__.__name__
    expected = f"{class_name}(f1=3, f2=6)"
    actual = test_schema.__repr__()

    assert expected == actual
    print(actual)

test_Schema___iter__()



# Generated at 2022-06-12 15:58:11.595720
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        email = String()
        age = Integer()
    
    p = Person(name="John Doe", email="jdoe@example.com")
    assert len(list(p)) == 2
    assert "name" in p
    assert "email" in p
    assert "age" not in p

# unit test for method __getitem__ of class Schema

# Generated at 2022-06-12 15:58:12.907886
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    s = Schema()
    assert next(s.__iter__()) is None

# Generated at 2022-06-12 15:58:21.508717
# Unit test for constructor of class Schema
def test_Schema():
    class User(Schema):
        name = String()
        age = Integer()

    # Test with dict as input
    user = User({"name": "John", "age": 30})
    assert user.name == "John"
    assert user.age == 30

    # Test with instance
    class UserInstance:
        name = "John"
        age = 30

    user = User(UserInstance())
    assert user.name == "John"
    assert user.age == 30

    # Test with incorrect input
    with pytest.raises(TypeError):
        user = User({"name": "John"})


# Unit tests for function Schema.validate

# Generated at 2022-06-12 15:59:17.086039
# Unit test for constructor of class Schema
def test_Schema():
    class Movie(Schema):
        title = String()
        rating = String()
        director = Reference(Person)

    movie = Movie(title="Halloween", rating="R", director=Person(name="John Carpenter"))
    assert isinstance(movie, Movie) and isinstance(movie['director'], Person)


# Generated at 2022-06-12 15:59:21.164059
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from .users import User, UserWithOptionalFields
    assert User.fields == {'name': String(), 'age': Number()}
    assert UserWithOptionalFields.fields == {'name': String(), 'age': Number(allow_null=True)}

# Generated at 2022-06-12 15:59:27.902503
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    data = {
        "foo": {},
        "baz": "baz",
        "bar": 7,
        "quux": None
    }

    class TestSchema(Schema):
        foo = Reference('foo', allow_null=False)
        bar = Reference('bar', allow_null=True)
        baz = Reference('baz', allow_null=False)

    # WHEN
    test_schema = TestSchema(data)

    # THEN
    assert list(test_schema) == ['foo', 'baz']



# Generated at 2022-06-12 15:59:37.797815
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()
        friends = Array(item=Reference("Person"))

    class Author(Person):
        book = Reference("Book")

    class Book(Schema):
        title = String()
        year = Integer()
        author = Reference("Person")

    assert Person.fields == {
        "name": String(),
        "age": Integer(),
        "friends": Array(item=Reference("Person")),
    }

    assert Author.fields == {
        "name": String(),
        "age": Integer(),
        "friends": Array(item=Reference("Person")),
        "book": Reference("Book"),
    }

    assert Book.fields == {
        "title": String(),
        "year": Integer(),
        "author": Reference("Person"),
    }

# Unit

# Generated at 2022-06-12 15:59:50.259836
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import String
    class A(Schema):
        f1 = String(required=True)
        f2 = String(required=True)
        f3 = String()
        f4 = String()
    a = A(f1='a', f2='b')
    assert a.f1 == 'a'
    assert a.f2 == 'b'
    assert a.f3 == None
    assert a.f4 == None
    assert len(a) == 2
    assert 'f1' in a
    assert 'f2' in a
    assert 'f3' not in a
    assert 'f4' not in a
    assert a.get('f1') == 'a'
    assert a.get('f2') == 'b'
    assert a.get('f3') == None
    assert a.get

# Generated at 2022-06-12 16:00:01.587414
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        first_name = CharField()
        last_name = CharField()
        age = IntField()
        hair_color = CharField()

    p1 = Person(first_name='Mike', last_name='Smith', age=20, hair_color='Black')
    p2 = Person(first_name='Mike', last_name='Smith', age=20, hair_color='Black')
    p3 = Person(first_name='John', last_name='Doe', age=30, hair_color='Brown')
    p12_result = (p1 == p2)
    p12_exp_result = True
    assert p12_result == p12_exp_result
    p13_result = (p1 == p3)
    p13_exp_result = False

# Generated at 2022-06-12 16:00:04.979574
# Unit test for constructor of class Schema
def test_Schema():
    class S(Schema):
        pass

    s = S(s1=1)
    assert s == S(s1=1)
    assert s.s1 == 1


# Generated at 2022-06-12 16:00:12.501112
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Address(Schema):
        first_name = String(max_length=50)
        last_name = String(max_length=50)

    class User(Schema):
        address = Object(Address)

    user1 = User(address=Address(first_name='John', last_name='Doe'))
    user2 = User(address=Address(first_name='John', last_name='Doe'))
    user3 = User(address=Address(first_name='Jane', last_name='Doe'))

    assert user1 == user2
    assert user1 != user3
