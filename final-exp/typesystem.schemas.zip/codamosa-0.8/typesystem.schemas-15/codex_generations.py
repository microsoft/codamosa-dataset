

# Generated at 2022-06-12 15:50:48.401278
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        bar = Field(required=False)
        baz = Field(required=True)
    foo = Foo()
    assert foo.bar is None
    assert foo.baz is None
    assert foo.is_sparse


# Generated at 2022-06-12 15:50:51.115200
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from .test_utils import class_path
    from .models import Movie, Review, User

    movie = Movie(
        title="2001: A Space Odyssey",
        genre="Sci-fi",
    )

    assert list(movie) == ["title", "genre"]



# Generated at 2022-06-12 15:50:58.489523
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Foo(Schema):
        property_1 = Field()
        property_2 = Field()
        property_3 = Field()

    foo = Foo(property_1=1, property_3=3)

    # Test that it's iterable
    for key in foo:
        pass

    # Test that it iterates over string names
    assert list(foo.keys()) == ["property_1", "property_3"]

    # Test that it iterates over all declared properties
    assert sorted(foo.keys()) == sorted(foo.fields.keys())

# Generated at 2022-06-12 15:51:01.432305
# Unit test for constructor of class Reference
def test_Reference():
    o = Reference("test_target", required=True)
    assert(o.allow_null==False)
    assert(o.to=="test_target")
    assert(o.errors == {"null": "May not be null."})
    assert(o.target_string=="test_target")

# Generated at 2022-06-12 15:51:06.587520
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        age = Integer(default=0)
        name = String()
        social_security_number = String()

    p = Person(age=35, name="John")
    assert repr(p) == "Person(age=35, name='John') [sparse]"
    p = Person(age=35, name="John", social_security_number="111-22-3333")
    assert repr(p) == "Person(age=35, name='John', social_security_number='111-22-3333')"

# Generated at 2022-06-12 15:51:07.958756
# Unit test for constructor of class Schema
def test_Schema():
    assert (Schema(key='val'))
    assert (Schema(key=3.14))


# Generated at 2022-06-12 15:51:19.205921
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(TestSchema, definitions)
    assert (TestSchema.fields["test_item"] ==
            Reference(TestSchema, definitions=definitions,
                      name="test_item"))

    definitions = SchemaDefinitions()
    set_definitions(Array(items=TestSchema), definitions)
    assert (Array(items=TestSchema).items ==
            Reference(TestSchema, definitions=definitions,
                      name="my_item"))

    definitions = SchemaDefinitions()
    set_definitions(Array(items=[TestSchema, TestSchema]), definitions)

# Generated at 2022-06-12 15:51:25.460510
# Unit test for constructor of class Schema
def test_Schema():
    class SubSchema(Schema):
        test_field = String(validators=[Length(min=3)])

    assert issubclass(SubSchema, Schema)
    sub_schema = SubSchema({"test_field": "testing"})
    assert sub_schema.test_field == "testing"

    # Initialization with keyword arguments
    sub_schema = SubSchema(test_field="testing")
    assert sub_schema.test_field == "testing"
    with pytest.raises(TypeError):
        sub_schema = SubSchema(test_field="test", other_field="test")
        assert sub_schema.test_field == "testing"
        assert sub_schema.other_field == "test"

    # Initialization from another object
    class Test:
        test_field

# Generated at 2022-06-12 15:51:31.486502
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import Integer, String

    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    schema = Reference(Person, required=True)
    data = {"name": "Me", "age": 27}
    result = schema.validate(data)
    assert result == Person(name="Me", age=27)


# Generated at 2022-06-12 15:51:36.760185
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Child(Schema):
        name = String()

    class Parent(Schema):
        name = String()
        child = Reference(Child)

    parent = Parent(  # type: ignore
        name="parent", child=Child(name="child")
    )
    assert parent["name"] == "parent"
    assert parent["child"] == {"name": "child"}
    try:
        parent["invalid"]
        assert False, "Expected KeyError."
    except KeyError:
        pass


# Generated at 2022-06-12 15:51:51.650213
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.base import serialize
    from typesystem.fields import String

    class Person(Schema):
        name = String(max_length=255)
        age = String(max_length=255)

    person = Person(name="olivier", age=32)
    flat = dict(person)
    assert flat == {'age': 32, 'name': 'olivier'}

# Generated at 2022-06-12 15:51:53.839599
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema()
    assert repr(s) == 'Schema()'


# Generated at 2022-06-12 15:52:00.848980
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Object, Schema, String

    class UserSchema(Schema, strict=True):
        first_name = String()
        last_name = String()
        age = Integer(minimum=0, maximum=100)

    user, error = UserSchema.validate_or_error(
        {"first_name": "John", "last_name": "Smith", "age": 42}
    )
    assert error is None

    assert sorted(list(user)) == ["age", "first_name", "last_name"]



# Generated at 2022-06-12 15:52:06.891789
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass___new__(metaclass=SchemaMetaclass):
        def test_empty(self):
            pass

        def test_empty_with_definitions(self):
            definitions = SchemaDefinitions()
            self.assertIs(
                TestSchemaMetaclass___new__.__new__(
                    SchemaMetaclass,
                    "TestSchemaMetaclass___new__.test_empty_with_definitions",
                    (),
                    {},
                    definitions=definitions,
                ),
                TestSchemaMetaclass___new__.test_empty_with_definitions,
            )

# Generated at 2022-06-12 15:52:18.430712
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field_1 = Array(items=String())
        field_2 = Array(items=String())

    def _test(
        arguments: typing.Mapping,
        expected_keys: typing.Sequence[str],
        expected_is_sparse: bool,
    ) -> None:
        schema = TestSchema(**arguments)
        assert list(schema) == expected_keys
        assert schema.is_sparse == expected_is_sparse

    _test({"field_1": [], "field_2": []}, ["field_1", "field_2"], False)
    _test({"field_1": [], "field_2": None}, ["field_1"], True)

# Generated at 2022-06-12 15:52:25.839172
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # test that SchemaMetaclass.__new__ does not raise any exception when
    # called without any error
    SchemaMetaclass(
        "TestSchemaClass", (), {}, definitions=SchemaDefinitions()
    )
    # test that SchemaMetaclass.__new__ raises an exception when
    # called with a definition key 'error'
    with pytest.raises(
        AssertionError, match=r"Definition for 'error' has already been set."
    ):
        SchemaMetaclass(
            "TestSchemaClass", (), {"error": Field(required=True)}, definitions=SchemaDefinitions()
        )

# Generated at 2022-06-12 15:52:26.760067
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert True


# Generated at 2022-06-12 15:52:34.029786
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    def class_type():
        class SimpleSchema(Schema):
            # Testing the meta class, we created a simple class.
            # Single field.
            name = Field(str)

        assert isinstance(SimpleSchema.fields, dict)
        assert len(SimpleSchema.fields) == 1
        assert SimpleSchema.fields["name"] is name

    def class_type_with_base_class():
        # Testing the meta class, we created a simple class.
        # Single field.
        class SimpleBaseSchema(Schema):
            name = Field(str)

        class SimpleSchema(SimpleBaseSchema):
            pass

        assert isinstance(SimpleSchema.fields, dict)
        assert len(SimpleSchema.fields) == 1
        assert SimpleSchema.fields["name"] is name


# Generated at 2022-06-12 15:52:40.749643
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        int_field = Field(int)

    schema = TestSchema(int_field=5)

    assert isinstance(schema, Mapping)
    assert isinstance(schema, Schema)

    assert schema["int_field"] == 5

    with pytest.raises(KeyError, match='"unknown_field"'):
        schema["unknown_field"]


# Generated at 2022-06-12 15:52:42.844969
# Unit test for constructor of class Reference
def test_Reference():
    ReferenceField = Reference(to=Schema)
    assert(ReferenceField.__constructor__ == Reference)


# Generated at 2022-06-12 15:52:57.294838
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class UserSchema(Schema):
        username = String(max_length=30)
        password = String(max_length=30)

    user = UserSchema(username='test', password='testest')

    for key in user:
        print(user[key])


test_Schema___iter__()

# Generated at 2022-06-12 15:53:09.427405
# Unit test for constructor of class Schema
def test_Schema():
    class Example(Schema):
        name = Field(type=str)
        year = Field(type=int, has_default=False)

    assert isinstance(Example, type)
    assert not hasattr(Example, "__dict__")

    assert isinstance(Example, Mapping)
    assert not isinstance(Example, MutableMapping)
    assert Example.fields["name"].type is str
    assert Example.fields["year"].type is int
    example = Example(name="foo", year=123)
    assert example["name"] == "foo"
    assert example["year"] == 123
    assert sorted(list(example)) == ["name", "year"]
    assert len(example) == 2
    assert repr(example) == "Example(name='foo', year=123)"
    assert example.name == "foo"

# Generated at 2022-06-12 15:53:12.929792
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String(required=False)
        age = Integer()

    person = Person(name="John Doe", age=42)
    assert len(person) == 2
    assert person == Person(name="John Doe", age=42)
    assert person != Person(age=42, name="John Doe")



# Generated at 2022-06-12 15:53:14.545550
# Unit test for constructor of class Schema
def test_Schema():
    assert 1 == 1
    schema = Schema(hello = "world")
    assert schema.hello == "world"
    assert schema.fields == {"hello": None}

# Generated at 2022-06-12 15:53:19.773769
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
        married = Boolean(default=False)
        mother = Reference(Person)

    p = Person(name="Bob", age=42)
    p_l = len(p)
    assert p_l == 2


# Generated at 2022-06-12 15:53:23.239879
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        a = 1
        b = 2
        c = 3
    schema = MySchema()
    schema.a = 1
    schema.b = 1
    schema.c = 1

    assert list(schema.__iter__()) == ['a', 'b', 'c']


# Generated at 2022-06-12 15:53:31.751075
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import sys
    import math
    from decimal import Decimal
    my_abs_tol = 1e-12
    my_rel_tol = 1e-06
    print(sys.version)
    print(math.__file__)
    from pprint import pprint
    from copy import copy
    def isclose(a: float, b: float, rel_tol=my_rel_tol, abs_tol=my_abs_tol) -> bool:
        # https://stackoverflow.com/a/33024979
        return abs(a - b) <= max(rel_tol * max(abs(a), abs(b)), abs_tol)
    class TestSchema(Schema):
        a = Boolean()
        b = Integer()
        c = Number()
        d = String()

# Generated at 2022-06-12 15:53:42.545446
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema1(Schema):
        name = Field(type=str, max_length=20)
        age = Field(type=int)

    class TestSchema2(Schema):
        name = Field(type=str, max_length=20, required=False)
        age = Field(type=int)
        weight = Field(type=int)
        height = Field(type=int)

    s1 = TestSchema1(name='abc', age=20)
    assert list(s1) == ['name', 'age']

    s2 = TestSchema2(age=20)
    assert list(s2) == ['age']

# Generated at 2022-06-12 15:53:49.911635
# Unit test for constructor of class Schema
def test_Schema():
    if hasattr(Schema, "test_in_progress"):
        return
    Schema.test_in_progress = True

# Generated at 2022-06-12 15:54:00.823553
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import unittest
    import datetime

    class Time(Schema):
        hour = Integer()
        minute = Integer()
        second = Integer()

    class Point(Schema):
        x = Float()
        y = Float()

    class Line(Schema):
        start = Reference(Point)
        end = Reference(Point)

    class Date(Schema):
        year = Integer()
        month = Integer()
        day = Integer()

    class Data(Schema):
        a = String()
        b = String()
        c = String()

    class Person(Schema):
        name = String()
        born = Reference(Date)
        address = String()
        phones = Array(String())

    class User(Schema):
        id = Integer()
        name = String()
        time = Reference(Time)

# Generated at 2022-06-12 15:54:22.458501
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import unittest
    from typesystem.fields import String

    class Book(Schema):
        title = String()
        year = String()

    book = Book(title="Programming for beginners", year="2020")
    assert isinstance(book, Book) == True
    assert isinstance(book, Schema) == True
    assert isinstance(book, Mapping) == True
    assert len(book) == 2
    assert "title" in book
    assert "year" in book
    assert book == Book(title="Programming for beginners", year="2020")
    assert book == Book(title="Programming for beginners", year="2020")
    assert book == {"title":"Programming for beginners", "year":"2020"}
    assert book == {"title":"Programming for beginners", "year":"2020"}

    class Library(Schema):
        name = String

# Generated at 2022-06-12 15:54:30.459613
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
	try:
		from schematics import Model
		from schematics.transforms import blacklist
		from schematics.types import StringType
	except:
		from models.schematics import Model
		from models.schematics.transforms import blacklist
		from models.schematics.types import StringType

	class User(Model):
	    username = StringType(required=True)
	    password = StringType(required=True)
	    email = StringType()
	    # This field will be hidden when we serialize the object to JSON.
	    secret = StringType(serialized_name=None)

	    class Options:
	        roles = {
	            "public": blacklist("password", "secret")
	        }


# Generated at 2022-06-12 15:54:38.453377
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
    
    class TestSchema___eq__(unittest.TestCase):

        def setUp(self):
            self.obj = Person({'name': 'John'})
            self.obj_2 = Person({'name': 'John'})
            self.obj_3 = Person({'name': 'Mary'})

        def test_equal_value(self):
            self.assertEqual(self.obj, self.obj_2)

        def test_not_equal_value(self):
            self.assertNotEqual(self.obj, self.obj_3)


# Generated at 2022-06-12 15:54:44.000157
# Unit test for constructor of class Schema
def test_Schema():
    from schematics import Model
    from schematics.types import BooleanType, IntType, StringType

    class User(Schema):
        active = BooleanType()
        age = IntType()
        name = StringType()

    user = User(active=True, name="John")
    assert isinstance(user, Schema)
    assert user.active
    assert user.name == "John"

# Generated at 2022-06-12 15:54:45.921719
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    var_schema_class = DummySchema()
    assert var_schema_class.__repr__() == ''

# Generated at 2022-06-12 15:54:50.552348
# Unit test for function set_definitions
def test_set_definitions():
    class Definition(Schema):
        property_1 = Reference(to="Definition")
        property_2 = Array(Reference(to="Definition"))
        property_3 = Array(items=Reference(to="Definition"))
        property_4 = Array(Reference(to="Definition"), items=Reference(to="Definition"))
        property_5 = Array(Array(Reference(to="Definition")))

    definitions = SchemaDefinitions()
    set_definitions(Definition, definitions)
    assert isinstance(Definiition.property_1.definitions, SchemaDefinitions)
    assert isinstance(Definiition.property_2.items.definitions, SchemaDefinitions)
    assert isinstance(Definiition.property_3.items.definitions, SchemaDefinitions)

# Generated at 2022-06-12 15:55:01.564784
# Unit test for function set_definitions
def test_set_definitions():
    class _Person(Schema):
        name = Field()
        age = Field()

    class _Company(Schema):
        name = Field()
        address = Field()
        employees = Field(Array(Reference(_Person, definitions={_Person: _Person})))

    assert hasattr(_Person.fields["name"], "_creation_counter")
    assert hasattr(_Company.fields["name"], "_creation_counter")
    assert _Person.fields["name"]._creation_counter != 0
    assert _Company.fields["name"]._creation_counter != 0
    assert _Company.fields["employees"].items[0].to == "_Person"
    assert _Company.fields["employees"].items[0].definitions == {_Person: _Person}


# Generated at 2022-06-12 15:55:05.651152
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema = Schema({"key": "value"})
    assert schema == {"key": "value"}
    assert schema == Schema({"key": "value"})
    assert schema != {"key": "value", "key2": "value2"}
    assert schema != Schema({"key": "value", "key2": "value2"})
    assert schema != {"key2": "value"}



# Generated at 2022-06-12 15:55:08.208038
# Unit test for constructor of class Schema
def test_Schema():
    class UserSchema(Schema):
        name = String()
        age = Integer()
    user = UserSchema()
    assert user.name is None
    assert user.age is None


# Generated at 2022-06-12 15:55:11.379672
# Unit test for constructor of class Reference
def test_Reference():
    val = Reference("to", definitions={"to": "definitions"}, allow_null=True)
    assert val.to == "to"
    assert val.definitions == {"to": "definitions"}
    assert val.allow_null == True


# Generated at 2022-06-12 15:55:33.499894
# Unit test for function set_definitions
def test_set_definitions():
    class ToplevelSchema(Schema):
        field = Reference("definition")

    assert ToplevelSchema.validate({"field": {"child": "value"}})



# Generated at 2022-06-12 15:55:39.461077
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
    s = TestSchema(a=1)

    # The type is different
    assert s != 1

    # The type is the same, but the arguments are different
    t = TestSchema(a=2)
    assert s != t

    # The type and the arguments are the same
    u = TestSchema(a=1)
    assert s == u



# Generated at 2022-06-12 15:55:43.147085
# Unit test for function set_definitions
def test_set_definitions():
    uri_field = Field(type_name="string")
    schema = Schema(
        foo = Reference(to = "Person"),
        bar = Reference(to = "Person"),
        baz = Array(items=Reference(to="Person")),
        )

    definitions = SchemaDefinitions(Person = schema)
    set_definitions(schema, definitions)
    assert schema.fields["foo"].definitions == definitions
    assert schema.fields["bar"].definitions == definitions
    assert schema.fields["baz"].items.definitions == definitions


# Generated at 2022-06-12 15:55:44.835754
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema(id=5, name='John')
    assert len(schema) == 2

# Generated at 2022-06-12 15:55:49.433475
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    s = Schema()
    assert len(s) == 0
    assert len(s) == 0
    assert len(s) == 0
    assert len(s) == 0

    s = Schema(**{"a": 1, "b": 2})
    assert len(s) == 2
    assert len(s) == 2
    assert len(s) == 2
    assert len(s) == 2

# Generated at 2022-06-12 15:55:58.236316
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import pytest

    from typesystem.fields import Text

    class SimpleSchema(Schema):
        a = Text(max_length=8, min_length=4)
        b = Text(max_length=8, min_length=4)

    s = SimpleSchema(a="1234", b="1234")
    assert len(s) == 2

    s2 = SimpleSchema(a="123")
    assert len(s2) == 1

    s3 = SimpleSchema(b="123")
    assert len(s3) == 1


# Generated at 2022-06-12 15:56:04.260827
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Create test object
    class Artist(Schema):
        name = Field(String)
        songs = Field(Array(String))
        genre = Field(String)

    a = Artist.validate({"name": "MGMT", "songs": ["Electric Feel"], "genre": "alternative"})
    assert a["name"] == "MGMT"
    assert a["songs"] == ["Electric Feel"]
    assert a["genre"] == "alternative"


# Generated at 2022-06-12 15:56:10.289250
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    """Unit test for method __repr__ of class Schema
    """
    # return None when all fields are present
    expected_1 = "Schema(field_a=1, field_b='str', field_c=0.9)"
    actual_1 = Schema(
        {
            "field_a": 1,
            "field_b": "str",
            "field_c": 0.9,
        }
    )
    assert repr(actual_1) == expected_1, "repr for all fields present"

    # return None when fields are sparse
    expected_2 = "Schema(field_a=1, field_c=0.9) [sparse]"

# Generated at 2022-06-12 15:56:17.810490
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        first_name = Field()
        last_name = Field()   
    # Test for a populated schema
    alice = Person(first_name='Alice', last_name='Smith')
    print(len(alice))
    assert len(alice) == 2, 'Test for a populated schema failed'
    # Test for a sparsely populated schema
    bob = Person(first_name='Bob')
    print(len(bob))
    assert len(bob) == 1, 'Test for a sparsely populated schema failed'

# Generated at 2022-06-12 15:56:21.530198
# Unit test for function set_definitions
def test_set_definitions():
    definitions=SchemaDefinitions()
    some_object = Object(properties={'some_array': Array(items=Reference('SomeItem', definitions=definitions))})
    assert some_object.properties['some_array'].items.definitions is definitions

# Unit tests for SchemaMetaclass

# Generated at 2022-06-12 15:57:25.834275
# Unit test for function set_definitions

# Generated at 2022-06-12 15:57:29.953555
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    test = Schema(foo=Field(allow_null=True))
    assert test.fields['foo'].allow_null == True
    try:
        test["foo"]
        assert False
    except KeyError:
        pass
    
    

# Generated at 2022-06-12 15:57:35.703141
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    expected = 2
    # Initialize the object
    data = {'key1': 'value1', 'key2': 'value2'}
    obj = Schema(data)
    # Assert the results
    assert len(obj) == expected


# Generated at 2022-06-12 15:57:37.950228
# Unit test for constructor of class Reference
def test_Reference():
    with pytest.raises(AssertionError):
        Reference(str('abc'), definitions=SchemaDefinitions())


# Generated at 2022-06-12 15:57:42.415080
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class X(Schema):
        _x = 123
        a = 1
        b = 2
        c = 3
    assert list(iter(X())) == ['a', 'b', 'c']
    assert list(iter(X(a=4))) == ['a']
    assert list(iter(X(a=4, c=6))) == ['a', 'c']

# Generated at 2022-06-12 15:57:44.003274
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass # TODO

# Generated at 2022-06-12 15:57:47.474037
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import integer, string

    class MySchema(Schema):
        foo = integer(required=True)
        bar = string()

    ms = MySchema(foo=5)
    assert list(ms.__iter__()) == ['foo']



# Generated at 2022-06-12 15:57:50.271214
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        value = Field()

    schema = TestSchema(value="test")
    assert repr(schema) == "TestSchema(value='test')"



# Generated at 2022-06-12 15:57:53.829588
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class ConcreteSchema(Schema):
        name = Field(str)
        price = Field(float)
    schema1 = ConcreteSchema(name='Mouse', price=100.)
    schema2 = ConcreteSchema(name='Mouse', price=100.)
    eq_(schema1, schema2)

# Generated at 2022-06-12 15:57:59.711404
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # assert_equal:
    class Foo(Schema):
        id = Field(format="uuid")
        name = Field(required=True)

    foo1 = Foo({'id': '123e4567-e89b-12d3-a456-426655440000', 'name': 'John Doe'})
    foo2 = Foo({'id': '123e4567-e89b-12d3-a456-426655440000', 'name': 'John Doe'})
    assert foo1 == foo2
    assert not (foo1 != foo2)

    foo1 = Foo({'id': '123e4567-e89b-12d3-a456-426655440666', 'name': 'John Doe'})

# Generated at 2022-06-12 15:58:43.400225
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class AuthorSchema(Schema):
        name = Field()

    schema = AuthorSchema(name="F. Scott Fitzgerald")
    assert schema["name"] == "F. Scott Fitzgerald"


# Generated at 2022-06-12 15:58:48.979981
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import datetime
    from typesystem import DateTime

    class DateRange(Schema):
        start: datetime.datetime
        end: datetime.datetime


    dt1 = datetime.datetime(2001, 2, 3, 4, 5)
    dt2 = datetime.datetime(2002, 2, 3, 4, 5)
    dr1 = DateRange({"start": dt1, "end": dt2})
    dr2 = DateRange({"start": dt1, "end": dt2})
    assert dr1 == dr2



# Generated at 2022-06-12 15:58:56.441128
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema() == Schema()
    assert Schema(a=1) == Schema(a=1)
    assert Schema(a=1) == Schema(a=1, b=2)
    assert Schema(a=1) == Schema(a=1, b=2, c=3)
    assert Schema(a=1, b=2) == Schema(a=1, b=2)
    assert Schema(a=1, b=2) == Schema(a=1, b=2, c=3)
    assert Schema(a=1, b=2, c=3) == Schema(a=1, b=2, c=3)

    assert Schema(a=1) != Schema()

# Generated at 2022-06-12 15:58:59.979174
# Unit test for function set_definitions
def test_set_definitions():
    assert not hasattr(Reference, "definitions")
    definitions = SchemaDefinitions()
    set_definitions(Reference("foo"), definitions)
    assert hasattr(Reference, "definitions")

# Generated at 2022-06-12 15:59:08.915057
# Unit test for constructor of class Schema
def test_Schema():
    class A(Schema):
        name = Field(str)
        age = Field(int)

    with pytest.raises(TypeError, match="Invalid argument 'two' for A(). Invalid type. Expected 'int', got 'str'."):
        a = A(name="one", age="two")

    with pytest.raises(TypeError, match="Invalid argument 'two' for A(). Invalid type. Expected 'int', got 'str'."):
        a = A(name="one", two=2)
    
    a = A(name="one", age=2)
    assert a == A(name="one", age=2)

    b = A(name="one", age=2, three=3)
    assert a == b

    c = A(name="two", age=2)
    assert a != c

    a

# Generated at 2022-06-12 15:59:19.245127
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem.fields import String, Number, Integer, Boolean

    class Person(Schema):
        name = String()
        age = Number()
        alive = Boolean(default=True)

    person1 = Person(name="Bobby", age=24)
    person2 = Person(name="Bobby", age=24)
    person3 = Person(name="Bobby", age=24, alive=False)
    assert person1 == person2
    assert person1 != person3

    class Animal(Schema):
        name = String()
        species = String()

    animal = Animal(name="Nibbles", species="cat")
    assert animal != person1

    class Person(Schema):
        name = String()
        age = Number()
        alive = Boolean(default=True)

    class Person2(Person):
        species = String()

# Generated at 2022-06-12 15:59:29.094053
# Unit test for function set_definitions
def test_set_definitions():
    Field.clear_creation_counter()

    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        qux = Reference("Qux")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    definitions["Bar"] = Bar
    set_definitions(Bar, definitions)
    definitions["Baz"] = Baz
    set_definitions(Baz, definitions)
    definitions["Qux"] = "Qux"
    set_definitions(Baz, definitions)

    assert isinstance(Foo.fields["bar"].target, type)
    assert issubclass(Foo.fields["bar"].target, Schema)
    assert Foo.fields["bar"].target is Bar
   

# Generated at 2022-06-12 15:59:38.925765
# Unit test for constructor of class Schema
def test_Schema():
    class A(Schema):
        a = Field()
        b = Field()

    class B(Schema):
        a = Field()
        b = Field()

    class C(Schema):
        a = Field(default=None)

    class D(Schema):
        a = Reference(to="A")
        b = Reference(to=A)

    assert D().a == None
    assert D().b == None
    assert D(a=A(a=1, b=2)).a == A(a=1, b=2)
    assert D(b=B()).a == None
    assert D(b=B()).b == B()
    assert D(a=A(a=1, b=2), b=A(a=1, b=2)).a == A(a=1, b=2)


# Generated at 2022-06-12 15:59:43.244142
# Unit test for function set_definitions
def test_set_definitions():
    defn = SchemaDefinitions()
    x = Reference("foo")
    assert getattr(x, "definitions", None) is None
    set_definitions(x, defn)
    assert x.definitions == defn

# Generated at 2022-06-12 15:59:54.256813
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchemaEquals(Schema):
        field1 = Integer()
        field2 = String()

    schema1 = TestSchemaEquals.validate({"field1": 1, "field2": "2"})
    schema2 = TestSchemaEquals.validate({"field1": 1, "field2": "3"})
    schema3 = TestSchemaEquals.validate({"field1": 1, "field2": "2"})
    if not isinstance(schema1, (Schema, type)):
        raise TypeError("schema1 expected to be an instance of 'Schema' or 'type'")
    if not isinstance(schema2, (Schema, type)):
        raise TypeError("schema2 expected to be an instance of 'Schema' or 'type'")