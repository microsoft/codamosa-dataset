

# Generated at 2022-06-12 15:50:39.338489
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from random import random
    from vcx.common import do_post, create_cb
    from vcx.error import VcxError
    from vcx.schema import Schema
    import json

    schema_data = {
      'name': 'TestSchema',
      'version': '1.0',
      'attributes': ['attribute1', 'attribute2', 'attribute3']
    }

    # Create a new Schema
    schema_1 = Schema(schema_data)
    schema_1.serialize() # <-- class method
    assert schema_1.version == '1.0'

    # All done, release the Schema
    schema_1.release()

    # Create a second Schema
    schema_2 = Schema(schema_data)


# Generated at 2022-06-12 15:50:46.440718
# Unit test for method __eq__ of class Schema
def test_Schema___eq__(): 
    from typesystem import String
    from typesystem import SchemaDefinitions

    class ProductSchema(Schema):
        name = String()
        price = String()

    definitions = SchemaDefinitions()

    product1 = ProductSchema(name='chair', price='$50.00', definitions=definitions)
    product2 = ProductSchema(name='chair', price='$50.00', definitions=definitions)
    result = product1==product2
    assert result == True

# Generated at 2022-06-12 15:50:49.960406
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        pass

    parent = Array(items=Reference(to=MySchema))
    definitions = SchemaDefinitions()
    set_definitions(parent, definitions)
    assert parent.items._target is MySchema

# Generated at 2022-06-12 15:50:54.464110
# Unit test for method validate of class Reference
def test_Reference_validate():
    ref = Reference(to="Person")
    assert ref.validate({'name': "John"}) == {'name': "John"}
    assert ref.validate(None) is None

# Generated at 2022-06-12 15:50:57.410041
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Test_Schema(Schema):
        name = String()

    schema = Test_Schema.validate({'name': 'test'})
    assert schema.serialize() == {'name': 'test'}

# Generated at 2022-06-12 15:51:04.711321
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    if (1):
        # Test the normal case where no definitions are passed
        class_name = 'Schema'
        bases = [Mapping]
        attrs = {}
        definitions = SchemaDefinitions()
        new_type = SchemaMetaclass.__new__(SchemaMetaclass, class_name, bases, attrs, definitions)
        assert new_type.__name__ == 'Schema'
        assert new_type.__bases__ == (Mapping,)
        assert new_type.__dict__ == {}
        assert definitions == {}
    if (1):
        # Test the normal case where definitions are passed
        class_name = 'Test'
        bases = [Schema]
        attrs = {}
        definitions = SchemaDefinitions()

# Generated at 2022-06-12 15:51:10.523081
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import json
    from copy import copy
    from pprint import pprint
    from time import time
    from datetime import date
    from decimal import Decimal
    from typesystem.base import ErrorMessage, ErrorDict
    from typesystem.fields import BaseField, Field
    from typesystem.typing import Optional, Union, List, Dict, Any, TypeVar, NewType
    from typesystem.exceptions import ValidationError, ValidationErrors
    from typesystem.validators import (
        Validator,
        RegexValidator,
        LengthValidator,
        ChoiceValidator,
    )

    class TimeStampField(Field):
        errors = {"overflow": "Timestamp out of range for platform time_t."}

        def to_native(self, value: typing.Any) -> float:
            return int(value)



# Generated at 2022-06-12 15:51:21.476422
# Unit test for method validate of class Reference
def test_Reference_validate():
    content = {
        '100': 'A',
        '200': 'B'
    }
    class MetaSchema(Schema):
        definitions = SchemaDefinitions({
            'Item': Field(type_=int, description='Item id')
        })
        items: typing.Dict[Reference, str] = {}

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)

            items: typing.Dict[Reference, str] = {}
            for item_id, item_content in content.items():
                items[Reference(to=f'Item{item_id}', definitions=self.definitions)] = item_content
            self.items = items

    test_meta_schema = MetaSchema()
    test

# Generated at 2022-06-12 15:51:29.557432
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        a = Reference("B")
        b = Array(Reference("C"))
        c = Array([Reference("A"), Reference("B")])
        d = Object(properties={"a": Reference("A")})
        e = Object(properties={"a": Array(Reference("B"))})

    definitions = SchemaDefinitions()
    TestSchema("", definitions=definitions)

    def check(to: str, expected: str) -> None:
        assert definitions[to].__name__ == expected

    check("A", "TestSchema")
    check("B", "TestSchema")
    check("C", "TestSchema")

# Generated at 2022-06-12 15:51:30.721413
# Unit test for constructor of class Schema
def test_Schema():
    instance = Schema()
    assert isinstance(instance, Schema)

if __name__ == '__main__':
    test_Schema()

# Generated at 2022-06-12 15:51:51.252232
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.types import String
    from typesystem.fields import Field, Reference
    from typesystem import Schema

    class Foo(Schema):
        id = String

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        bar = Reference(Bar)

    assert isinstance(Bar.fields["foo"].target, Field)
    assert Bar.fields["foo"].target == Foo.make_validator()

    assert isinstance(Baz.fields["bar"].target, Field)
    assert Baz.fields["bar"].target == Bar.make_validator()



# Generated at 2022-06-12 15:51:58.085998
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import Integer

    class Person(Schema):
        id = Integer()
        name = Integer()

    a = Person(id=1, name="Alice")
    b = Person(id=1, name="Alice")
    if a == b:
        print("person1 == person2 is True")
    else:
        print("person1 == person2 is False")


test_Schema___eq__()

# Generated at 2022-06-12 15:52:09.930117
# Unit test for method validate of class Reference
def test_Reference_validate():
    import unittest
    from unittest.mock import patch
    from typesystem.fields import String
    from typesystem.schemas import Schema, Reference
    from typesystem.exceptions import ValidationError
    
    # Case: when field is None and allow_null is True
    class Doc(Schema):
        ref = Reference(to=String())
    
    d = Doc()
    d.ref = None
    assert d.ref == None
    d.ref = "hello"
    assert d.ref == "hello"
    
    # Case: when field is None and allow_null is False
    class Doc1(Schema):
        ref = Reference(to=String(), allow_null=False)
    
    d = Doc1()

# Generated at 2022-06-12 15:52:21.630489
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class ExampleSchema(Schema):
        foo = Field()

    class ExampleSchema2(Schema):
        foo = Field()

    example_schema_1 = ExampleSchema(foo="Hello")
    example_schema_2 = ExampleSchema(foo="Hello")
    example_schema_3 = ExampleSchema(foo="Hello", bar="Hi")
    example_schema_4 = ExampleSchema2(foo="Hello")
    example_schema_5 = ExampleSchema2(foo="Hi")

    assert example_schema_1 == example_schema_2
    assert example_schema_2 == example_schema_1
    assert example_schema_1 != example_schema_3
    assert example_schema_1 != example_schema_4
    assert example_schema_1 != example_

# Generated at 2022-06-12 15:52:26.216259
# Unit test for constructor of class Schema
def test_Schema():
 
    person_definitions = SchemaDefinitions()
    class PersonSchema(Schema, metaclass=SchemaMetaclass, definitions=person_definitions):
        name = Reference("String")
        age = Reference("Integer")

    person = PersonSchema.validate(
        {"name": "fred", "age": 12}
    )

# Generated at 2022-06-12 15:52:28.976388
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    obj = {'key1': 'value1', 'key2': 'value2'}
    assert(Reference.serialize(obj) == {'key1': 'value1', 'key2': 'value2'})


# Generated at 2022-06-12 15:52:39.105633
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    field = Reference("Person", definitions=definitions)
    definition_name = field.target_string
    assert definition_name == "Person"
    assert field.target == None
    assert definitions[definition_name] == None
    set_definitions(field, definitions)
    assert definitions[definition_name] == None
    class Person(Schema):
        name = Field(str)
        age = Field(int)
    definitions["Person"] = Person
    set_definitions(field, definitions)
    assert definitions[definition_name] == Person
    assert field.target == Person

# Generated at 2022-06-12 15:52:47.047764
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert len(Schema({"a":1,"b":2,"c":3})) == 3
    assert len(Schema({"a":1,"b":2,"c":3}, d=4)) == 4
    assert len(Schema({"a":1,"b":2}, c=None)) == 2
    assert len(Schema({"a":1,"b":2,"c":3}, d=4, e=5)) == 5
    assert len(Schema({"a":1,"b":2,"c":3}, d=4, e=5, f=None)) == 5
    assert len(Schema({"a": 1, "b": 2, "c": 3,})) == 3
    assert len(Schema({"a": 1, "b": 2, "c": 3,}, d=4)) == 4

# Generated at 2022-06-12 15:52:57.378220
# Unit test for function set_definitions
def test_set_definitions():
    def check_set_definitions(field: Field, definitions: SchemaDefinitions):
        assert field.definitions is None
        set_definitions(field, definitions)
        assert field.definitions is definitions
        return True

    assert check_set_definitions(Reference("Foo"), SchemaDefinitions())
    assert check_set_definitions(
        Array(items=Reference("Foo")), SchemaDefinitions(),
    )
    assert check_set_definitions(
        Array(items=[Reference("Foo"), Reference("Bar")]), SchemaDefinitions(),
    )
    assert check_set_definitions(
        Object(properties={"foo": Reference("Foo")}), SchemaDefinitions(),
    )



# Generated at 2022-06-12 15:53:03.631548
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        foo = String()

        class MyObj(Schema):
            bar = String()

    defs = SchemaDefinitions()
    set_definitions(MySchema, defs)
    assert len(defs) == 1
    assert MySchema.__name__ in defs



# Generated at 2022-06-12 15:53:23.880272
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        key1 = Reference("TestSchema1")
        key2 = Reference("TestSchema2")
        key3 = Array(Reference("TestSchema3"))

    class TestSchema1(Schema):
        def_key = "TestSchema1"

    class TestSchema2(Schema):
        def_key = "TestSchema2"

    class TestSchema3(Schema):
        def_key = "TestSchema3"

    definitions = SchemaDefinitions(
        {
            "TestSchema1": TestSchema1,
            "TestSchema2": TestSchema2,
            "TestSchema3": TestSchema3,
        }
    )

    set_definitions(TestSchema, definitions)

# Generated at 2022-06-12 15:53:26.815480
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        foo = Reference("MyReferencedSchema")

    definitions = SchemaDefinitions()
    MySchema(foo="something")
    set_definitions(MySchema.fields["foo"], definitions)
    assert definitions

# Generated at 2022-06-12 15:53:28.275046
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema1 = Schema()
    schema2 = Schema()
    if len(schema1) != len(schema2):
        raise Exception('Unexpected result of method __len__ of class Schema')


# Generated at 2022-06-12 15:53:34.030856
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        name = String(max_length=1)
        age = Integer(min_value=0, max_value=100)
        test_data = {"name":"a", "age":10}
        test_obj = TestSchema(name="a", age=10)
        test_iter = list(test_obj)
        assert test_iter == list(test_data.keys()), "The result of this method is wrong!"
        print("test_Schema___iter__() passed!")



# Generated at 2022-06-12 15:53:43.239777
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = Field(String) # Add a "name" attribute of type String to the class
        age = Field(Integer) # Add an "age" attribute of type Integer to the class
        def __repr__(self):
            return "<Person: %s - %s>" % (self.name, self.age) # Override __repr__ to return a custom string.
    p = Person(name="Benjamin Pollack", age=28)
    p.__repr__()
    # Output: "<Person: Benjamin Pollack - 28>"


# Generated at 2022-06-12 15:53:45.404533
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Point(Schema):
        x: int
        y: int
    assert set(Point().__iter__()) == set()
    assert set(Point(x=10, y=20).__iter__()) == {'x', 'y'}


# Generated at 2022-06-12 15:53:46.473675
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import String
    class Profile(Schema):
        name = String()

    assert "name" in Profile.fields

# Generated at 2022-06-12 15:53:57.836678
# Unit test for constructor of class Schema
def test_Schema():
    assert hasattr(Schema, "fields")
    # Test for class variables
    assert 'fields' in Schema.__dict__.keys()
    # Test for instance variables
    assert 'fields' not in Schema().__dict__.keys()
    assert not hasattr(Schema, "all")
    assert hasattr(Schema, "make_validator")
    assert hasattr(Schema, "validate")
    assert hasattr(Schema, "validate_or_error")
    assert hasattr(Schema, "is_sparse")
    assert hasattr(Schema, "__eq__")
    assert hasattr(Schema, "__getitem__")
    assert hasattr(Schema, "__iter__")
    assert hasattr(Schema, "__len__")

# Generated at 2022-06-12 15:54:05.939359
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import Field
    from typesystem.common import Nested, PrimaryKey, Timestamp
    from typesystem.types import (Boolean, Integer, String, UUID)

    class Author(Schema):
        id = PrimaryKey(UUID)
        first_name = String()
        last_name = String()

        class Meta:
            strict = True

    class Book(Schema):
        id = PrimaryKey(UUID)
        title = String()
        author = Reference(Author)
        published_at = Timestamp()

        class Meta:
            strict = True

    class Comment(Schema):
        id = PrimaryKey(UUID)
        text = String()
        book = Reference(Book)

        class Meta:
            strict = True


# Generated at 2022-06-12 15:54:14.755565
# Unit test for constructor of class Schema
def test_Schema():
    from .person import Person
    from . import person

    person = Person(name="Lola", age=10)
    assert person.name == "Lola"
    assert person.age == 10

    person = Person()
    assert person.name is None
    assert person.age == 12

    person = Person(age=10)
    assert person.name is None
    assert person.age == 10

    person = Person(**person.to_primitive())
    assert person.name == "Lola"
    assert person.age == 10

    person = Person(**{"name": "Lola", "age": 10})
    assert person.name == "Lola"
    assert person.age == 10

    person = Person(**{"age": 10})
    assert person.name is None
    assert person.age == 10


# Generated at 2022-06-12 15:54:33.240050
# Unit test for constructor of class Reference
def test_Reference():
    a = Object(properties={'a': String(), 'b': String()})
    value = Reference(to=a, definitions={'a': a})
    print(value.validate("{'a': 'a'}"))


# Generated at 2022-06-12 15:54:44.866486
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class Foo(Schema):
        bar = Reference("Bar")

        class Meta:
            definitions = definitions

    class Bar(Schema):
        baz = Reference("Baz")

        class Meta:
            definitions = definitions

    class Baz(Schema):
        bat = Reference("Baz")
        bop = Reference("Bap")

        class Meta:
            definitions = definitions

    class Bop(Schema):
        pass

    # Set definition on top-level schema
    set_definitions(Schema.make_validator(), definitions)

    # Set definitions on all the child schemas, and ensure that duplicates
    # are not added
    set_definitions(Foo.make_validator(), definitions)
    set_definitions(Bar.make_validator(), definitions)
    set_def

# Generated at 2022-06-12 15:54:46.055353
# Unit test for constructor of class Reference
def test_Reference():
    a = Reference('to_list')

# Generated at 2022-06-12 15:54:53.221339
# Unit test for constructor of class Reference
def test_Reference():
    sf_schema = Schema(
        properties={
            'name': String,
            'email': String,
        }
    )
    assert isinstance(sf_schema, Schema)
    assert sf_schema.fields.keys() == {'name', 'email'}
    assert sf_schema.fields['name'] == String
    assert sf_schema.fields['email'] == String

    person_schema = Schema(
        properties={
            'age': Integer,
            'name': String,
            'address': Reference(to=sf_schema),
        }
    )
    assert isinstance(person_schema, Schema)
    assert person_schema.fields.keys() == {'age', 'name', 'address'}

# Generated at 2022-06-12 15:54:54.741617
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema = Schema()
    assert (schema == schema) is True


# Generated at 2022-06-12 15:54:57.057919
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Test(Schema):
        a = 1
        b = 2
        c = 3

    assert len(Test()) == 3


# Generated at 2022-06-12 15:55:00.154323
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class CustomObject(Schema):
        pass

    obj = CustomObject({"a": 1, "b": 2})
    assert len(obj) == len({"a": 1, "b": 2})


# Generated at 2022-06-12 15:55:04.994320
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    try:
        import ddt, unittest
    except ImportError as e:
        print('In order to test Schema you need to install the packages "ddt" and "unittest"')
    ddt.ddt
    unittest.TestCase

    from pytest import approx

    from .models import Address, Order, Person

    class Schema___eq___Test(unittest.TestCase):
        def test_sparse(self):
            self.assertEqual(Address(), Address())
            self.assertNotEqual(Address(line1="1 Wall Street"), Address())

        def test_single_field(self):
            self.assertEqual(Person(name="Alice"), Person(name="Alice"))
            self.assertNotEqual(Person(name="Alice"), Person(name="Bob"))


# Generated at 2022-06-12 15:55:11.284248
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class MySchema(Schema, metaclass=SchemaMetaclass):
        first_name = String(max_length=100, required=True)
        last_name = String(max_length=100, required=True)
        age = Integer(required=False)

    assert MySchema.fields == {
        "age": Integer(required=False),
        "first_name": String(max_length=100, required=True),
        "last_name": String(max_length=100, required=True),
    }

# Generated at 2022-06-12 15:55:12.196006
# Unit test for constructor of class Reference
def test_Reference():
    pass


# Generated at 2022-06-12 15:55:27.678202
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    """Test method __new__ of class SchemaMetaclass
    """
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    # class Test__new__(unittest.TestCase):
    class Test__new__(unittest.TestCase):
        # def test__new__(self):
        def test___new__(self):
            class TestObject(Schema):
                bool_attr = bool
                int_attr = int
                float_attr = float
                str_attr = str
                array_attr = Array(str)
                ref_attr = Reference("ReferencedObject")

            class ReferencedObject(Schema):
                pass

            definitions = SchemaDefinitions()

# Generated at 2022-06-12 15:55:29.224336
# Unit test for constructor of class Reference
def test_Reference():
    s = Reference("ProductDefinition.ts")

test_Reference()

# Generated at 2022-06-12 15:55:33.654972
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String

    # Test creation counter
    class TestSchema(Schema):
        name = String()
        description = String()
    assert TestSchema.fields['name']._creation_counter < \
           TestSchema.fields['description']._creation_counter



# Generated at 2022-06-12 15:55:44.004051
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from . import Field
    from . import Object
    from . import SchemaMetaclass
    from . import SchemaDefinitions
    from . import Schema
    from . import Reference
    from . import Array
    from . import String
    from . import Integer
    SchemaMetaclass = SchemaMetaclass
    SchemaDefinitions = SchemaDefinitions
    Schema = Schema
    Field = Field
    Reference = Reference
    Array = Array
    String = String
    Object = Object
    Integer = Integer
    # Empty schema class
    class EmptySchema(metaclass=SchemaMetaclass):
        pass
    # Empty schema class with additional arguments
    class EmptySchema2(metaclass=SchemaMetaclass):
        def __init__(*arg: typing.Any) -> None:
            pass
    # Simple schema

# Generated at 2022-06-12 15:55:47.072137
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class ExampleSchema(Schema):
        name = Field()
        age = Field(required=False)
    schema = ExampleSchema(name='John', age=12)
    assert schema['age'] == 12



# Generated at 2022-06-12 15:55:52.763287
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String, Integer
    from typesystem.exceptions import ValidationError
    class ExampleSchema(Schema):
        id = Integer()
        name = String()
        address = Reference("Address")
    class Address(Schema):
        address = String()
        city = String()
    ExampleSchema.define_fields(definitions={
        "Address": Address
    })
    schema = ExampleSchema({
        "id": 1,
        "name": "John",
        "address": {
            "address": "101 S. Main St.",
            "city": "Seattle"
        }
    })
    assert schema == ExampleSchema(id=1, name="John", address=Address(address="101 S. Main St.", city="Seattle"))


# Generated at 2022-06-12 15:56:01.460293
# Unit test for function set_definitions
def test_set_definitions():
    class B(Schema):
        a = Reference("B.C")
        c = B.definitions["B.C"]
    B.fields["a"] = Array(B.fields["a"])
    B.fields["c"] = Object(B.fields["c"])
    set_definitions(B, B.definitions)
    assert B.definitions is not None
    assert B.fields["a"].items.definitions is not None
    assert B.fields["c"].definitions is not None

# Generated at 2022-06-12 15:56:05.886089
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem import fields as f

    class User(Schema):
        name = f.String(max_length=100)

    class Comment(Schema):
        text = f.String(max_length=160)
        author = f.Reference('User')

    definitions = SchemaDefinitions()
    set_definitions(Comment.fields['author'], definitions)
    assert Comment.fields['author'].definitions == definitions

# Generated at 2022-06-12 15:56:18.062804
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem import typesystem

    class Pet(typesystem.Schema):
        name = String()

    class Person(typesystem.Schema):
        name = String()
        pet = Reference(Pet)
    # try:
    #     Person(name="Jared Forsyth", pet="Pike")
    # except Exception as error:
    #     print(error)
    person = Person(name="Jared Forsyth", pet={"name": "Pike"})
    assert person.pet.name == "Pike"

    # try:
    #     Pet(name="Pike", new_field="new")
    # except Exception as error:
    #     print(error)
    pet = Pet(name="Pike")
    assert pet.name == "Pike"


# Generated at 2022-06-12 15:56:25.564194
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Address(Schema):
        city = String()
        street = String()

    class User(Schema):
        address = Reference(Address)
        name = String()

    address = Address(city='city', street='street')
    address_1 = Address(city='city', street='street')
    address_2 = Address(city='city_1', street='street')
    user = User(name='name', address=address)
    user_1 = User(name='name', address=address_1)
    user_2 = User(name='name_1', address=address_1)
    user_3 = User(name='name', address=address_2)

    assert user == user
    assert user == user_1
    assert user != user_2
    assert user != user_3
    assert user != address

# Unit

# Generated at 2022-06-12 15:56:44.634641
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        x = Integer(default=0)
        y = Integer(default=0)
    schema = TestSchema()
    schema.x = 1
    assert list(schema) == ['x']



# Generated at 2022-06-12 15:56:50.324163
# Unit test for method validate of class Reference
def test_Reference_validate():
    data = {
        'name':'bob',
        'age':'young'
    }

    class Person(Schema):
        name = String()
        age = String()

    class Example(Schema):
        address = String()
        person = Reference(Person)

    reference = Reference("Person", definitions={"Person": Person})

    p1 = reference.validate(data)

    assert p1.name == 'bob'
    assert p1.age == 'young'

    try:
        reference.validate(None)
        assert False, "Should not pass validate of Reference"
    except ValidationError as e:
        assert e.message == "May not be null."


# Generated at 2022-06-12 15:56:57.509101
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from types import code
    a = code("a")
    b = code("b")
    c = code("c")
    assert a == a
    assert a != b
    assert a != c
    assert b == b
    assert b != c
    assert c == c
    assert repr(a) == repr(a)
    assert repr(a) != repr(b)
    assert repr(a) != repr(c)
    assert repr(b) == repr(b)
    assert repr(b) != repr(c)
    assert repr(c) == repr(c)


# Generated at 2022-06-12 15:56:59.835171
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        first_name = String()
        last_name = String()
        age = Integer()
    person = Person()
    assert len(person) == 0
    person = Person(first_name="John", last_name="Doe", age=35)
    assert len(person) == 3


# Generated at 2022-06-12 15:57:02.591585
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class ExampleSchema(Schema):
        pass
    
    example_schema = ExampleSchema()
    assert example_schema.__repr__() == "ExampleSchema()"


# Generated at 2022-06-12 15:57:06.126119
# Unit test for constructor of class Schema
def test_Schema():
    class Color(Schema):
        name = Field(type=str)
        code = Field(type=str)
    Color()

# Generated at 2022-06-12 15:57:13.588807
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class PersonSchema(Schema, metaclass=SchemaMetaclass):
        name = Field()
        age = Field(type=int)

    class PersonSchemaSubclass(PersonSchema):
        address = Field()

    definitions = SchemaDefinitions()

    class AuthorSchema(Schema, metaclass=SchemaMetaclass):
        name = Field()
        age = Field(type=int)
        person = Reference("PersonSchema", definitions=definitions)

    class BookSchema(Schema, metaclass=SchemaMetaclass):
        title = Field()
        author = Reference("AuthorSchema", definitions=definitions)

    # Definition has been set correctly
    assert "PersonSchema" in definitions
    assert "AuthorSchema" in definitions
    assert "BookSchema" in definitions

    # No error

# Generated at 2022-06-12 15:57:16.077151
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("Other")

    definitions = SchemaDefinitions()
    test_schema = TestSchema()

    set_definitions(test_schema.fields["field"], definitions)
    assert test_schema.fields["field"].definitions == definitions



# Generated at 2022-06-12 15:57:25.257423
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem import Schema

    class ExampleSchema(Schema):
        name = "Alice"
        age = 12

    definitions = {}
    set_definitions(ExampleSchema, definitions)
    assert definitions == {
        "ExampleSchema": ExampleSchema,
    }

    class AnotherExampleSchema(ExampleSchema):
        name = "Bob"

    definitions = {}
    set_definitions(AnotherExampleSchema, definitions)
    assert definitions == {
        "ExampleSchema": ExampleSchema,
        "AnotherExampleSchema": AnotherExampleSchema,
    }

# Generated at 2022-06-12 15:57:31.305519
# Unit test for function set_definitions
def test_set_definitions():
    class NestedSchema(Schema):
        key1 = String()
        key2 = Integer()

    class OuterSchema(Schema):
        field1 = NestedSchema()
        field2 = Reference(String)

    definitions = SchemaDefinitions()
    set_definitions(OuterSchema.fields["field2"], definitions)
    assert OuterSchema.fields["field2"].definitions is definitions


# Generated at 2022-06-12 15:58:11.695510
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema({})
    assert len(schema) == 0
    schema = Schema(dict(name='Tom'))
    assert len(schema) == 1


# Generated at 2022-06-12 15:58:12.995169
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    pass
    # Just a placeholder for a unit test



# Generated at 2022-06-12 15:58:16.978561
# Unit test for constructor of class Schema
def test_Schema():
    s = Schema()
    assert hasattr(s, "fields") == True

# Contains unit tests for the constructor of class Schema
# Includes a unit test for each branch in the constructor
# Includes a unit test for each loop in the constructor



# Generated at 2022-06-12 15:58:17.863623
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    ...


# Generated at 2022-06-12 15:58:19.589946
# Unit test for constructor of class Schema
def test_Schema():
    dtype = Schema({"key": "value"})
    assert dtype.fields == {}


# Generated at 2022-06-12 15:58:24.324332
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import typesystem
    class ClassSchema(Schema):
        field1 = typesystem.String()
        field2 = typesystem.String()
        field3 = typesystem.String()
    class_schema_instance = ClassSchema()
    assert len(class_schema_instance) == 0
    class_schema_instance = ClassSchema(field1="string1",field2="string2")
    assert len(class_schema_instance) == 2


# Generated at 2022-06-12 15:58:34.434050
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class A(Schema):
        x: Reference("B")

    class B(Schema):
        y: Reference("A")

    set_definitions(B.fields["y"], definitions)
    set_definitions(A.fields["x"], definitions)

    assert A.fields["x"].target == A
    assert B.fields["y"].target == B

    definitions = SchemaDefinitions()
    definitions["A"] = A
    definitions["B"] = B

    class A2(A):
        pass

    class B2(B):
        pass

    class C(Schema):
        a: Reference("A")
        b: Reference("B")
        a2: Reference("A2")
        b2: Reference("B2")


# Generated at 2022-06-12 15:58:36.733911
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    global class_name, arguments, argument_str, sparse_indicator

    # Test 1
    assert repr(Schema()) == "Schema()"



# Generated at 2022-06-12 15:58:46.614163
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = Field(str)

    class Company(Schema):
        name = Field(str)
        employees = Field(Array(Reference("Person")))

    definitions = SchemaDefinitions()  # type: ignore
    company = Company(name="Spacely Sprockets", employees=[Person(name="George")])
    company_values = company.serialize()
    assert company_values == {
        "name": "Spacely Sprockets",
        "employees": [{"name": "George"}],
    }
    definitions["Person"] = Person  # type: ignore  # noqa: E501
    del company_values["employees"][0]["__type__"]
    company_rehydrated = Company.validate(company_values, strict=True)
    assert company_rehydrated == company

# Generated at 2022-06-12 15:58:48.757382
# Unit test for function set_definitions
def test_set_definitions():
    field1 = Array(Field())
    obj = Object(properties={"a": field1})
    definitions = SchemaDefinitions()
    set_definitions(obj, definitions)
    assert obj.__dict__["properties"]["a"].definitions == definitions
    assert obj.__dict__["properties"]["a"].__dict__["items"].definitions == definitions

# Generated at 2022-06-12 15:59:31.805505
# Unit test for constructor of class Schema
def test_Schema():
    data = {'id': 1}
    assert Schema(id=1) == Schema(data)


# Generated at 2022-06-12 15:59:37.484169
# Unit test for constructor of class Schema
def test_Schema():
    class SubSchema(Schema):
        name = Field(str)
        text = Field(str)

    class TestSchema(Schema):
        id = Field(str)
        name = Field(str)
        ref = Reference("SubSchema")

    data = {
        "id": "123",
        "name": "Test Schema",
        "ref": {
            "name": "Ref Schema",
            "text": "Ref Schema text",
        }
    }
    schema = TestSchema(data)
    assert schema.id == "123"
    assert schema.name == "Test Schema"
    assert schema.ref.name == "Ref Schema"
    assert schema.ref.text == "Ref Schema text"


# Generated at 2022-06-12 15:59:42.048459
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.schema import Schema

    class Subject(Schema):
        name = String()
        age = Integer()
        weight = Float()

    subject = Subject(name="John Doe", age=42)
    assert len(subject) == 2


# Generated at 2022-06-12 15:59:52.987762
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class FooSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string", required=False)

    assert repr(FooSchema(a="a", b="b")) == "FooSchema(a='a', b='b')"
    assert repr(FooSchema(a="a", b="b", c="c")) == "FooSchema(a='a', b='b', c='c')"
    assert repr(FooSchema(a="a", b="b", d="d")) == "FooSchema(a='a', b='b') [sparse]"
    assert repr(FooSchema(a="a")) == "FooSchema(a='a') [sparse]"

# Generated at 2022-06-12 16:00:02.116827
# Unit test for method validate of class Reference
def test_Reference_validate():
    import typesystem
    import typesystem.error

    def test_target_validate_pass():
        target = typesystem.String()
        reference = Reference(to=target)

        target_input = "test"
        reference.validate(target_input)

    def test_target_validate_fail():
        target = typesystem.String(pattern=r"[0-9]+")
        reference = Reference(to=target)

        target_input = "test"
        try:
            reference.validate(target_input)
            assert False
        except typesystem.error.ValidationError:
            pass

    test_target_validate_pass()
    test_target_validate_fail()



# Generated at 2022-06-12 16:00:05.253788
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    A = Schema.make_validator()
    a = A.validate(1)
    b = A.validate(1)
    c = A.validate(2)

    assert a == a
    assert a == b

    assert a != c
    assert b != c
    assert a != None

