

# Generated at 2022-06-12 15:50:50.191037
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    """
    Test case for __len__() method of class Schema.
    """
    fields = {'name': 'String', 'age': 'Number'}
    schema = Schema(fields=fields, name='name', age=25)
    assert len(schema) == 2
    fields = {'': 'String'}

# Generated at 2022-06-12 15:50:58.079364
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class SchemaUser(Schema):
        _id = Field(type_hint=str)
        username = Field(type_hint=str)

    schemaUser = SchemaUser()
    schemaUser._id = "1243"
    schemaUser.username = "username"
    assert (schemaUser['_id'] == "1243") & (schemaUser['username'] == "username")
    try:
        schemaUser["email"]
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-12 15:51:05.440976
# Unit test for function set_definitions
def test_set_definitions():
    f = Field()
    set_definitions(f, SchemaDefinitions())
    assert not hasattr(f, "definitions")
    r = Reference("Person")
    assert not hasattr(r, "definitions")
    d = SchemaDefinitions()
    set_definitions(r, d)
    assert r.definitions is d
    a = Array(String())
    assert not hasattr(a, "definitions")
    set_definitions(a, d)
    assert a.definitions is d
    o = Object(properties={"name": String()})
    assert not hasattr(o, "definitions")
    set_definitions(o, d)
    assert o.definitions is d
    s = Schema()
    assert not hasattr(s, "fields")
    t = type(s)()


# Generated at 2022-06-12 15:51:10.437215
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    test_cases = [
        {"input": {"x": 1, "y": 2}, "output": ["x", "y"]},
        {"input": {"z": 3}, "output": ["z"]},
    ]
    for test_case in test_cases:
        _schema = Schema(test_case["input"])
        _output = list(_schema.__iter__())
        assert _output == test_case["output"]


# Generated at 2022-06-12 15:51:15.509234
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class PersonSchema(Schema):
        name = Field(type='string')
        age = Field(type='number')
    person = PersonSchema(name='wzy', age='17')
    print(person['name'])
    print(person['age'])

if __name__ == '__main__':
    test_Schema___getitem__()

# Generated at 2022-06-12 15:51:21.109005
# Unit test for constructor of class Reference
def test_Reference():
    import typesystem
    from typesystem import definitions
    T = typesystem.Schema(
        properties={'foo': typesystem.String(max_length=1)},
        definitions={'Baz': typesystem.String(max_length=1)},
        reference=Reference(
            to=typesystem.String,
            min_length=0,
            max_length=1,
            definitions=definitions,
        ),
    )
    foo = T.fields['foo']
    foo.label = 'foo'
    foo.max_length = 1
    assert foo.max_length == 1



# Generated at 2022-06-12 15:51:23.194035
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class User(Schema):
        username = String(min_length=1)
        email = String(format="email")

    user = User(username="dennis", email="dennis@example.com")
    assert repr(user) == "User(username='dennis', email='dennis@example.com')"


# Generated at 2022-06-12 15:51:24.498995
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Verify if the method returns an iterator of string
    assert isinstance(Schema().__iter__(),type(iter("example")))


# Generated at 2022-06-12 15:51:25.828862
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    instance = Schema()
    assert len(instance) == 0



# Generated at 2022-06-12 15:51:27.170890
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert False, "unimplemented"


# Generated at 2022-06-12 15:51:39.134039
# Unit test for function set_definitions
def test_set_definitions():
    field = Reference("A")
    definitions = SchemaDefinitions()
    set_definitions(field, definitions)
    assert field.definitions == definitions
    assert field.to == "A"

    field2 = Reference("B")
    array = Array(field2)
    set_definitions(array, definitions)
    assert array.items.definitions == definitions
    assert array.items.to == "B"

    object = Object(properties={"b": field}, required=["b"])
    set_definitions(object, definitions)
    assert object.properties["b"] == field
    assert object.properties["b"].definitions == definitions
    assert object.properties["b"].to == "A"

# Generated at 2022-06-12 15:51:46.083838
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer()

    a = MySchema(name="foo", age=1)
    b = MySchema(name="foo", age=1)
    assert a == b
    a = MySchema(name="foo", age=1)
    b = MySchema(name="foo", age=2)
    assert a != b


# Generated at 2022-06-12 15:51:52.322144
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import Schema
    class ApiError(Schema):
        code = Number()
        message = String(description="description")

    TheApiError = ApiError()

    assert TheApiError == ApiError()
    assert not TheApiError == ApiError(code=12)
    assert not TheApiError == ApiError(message='message')


# Generated at 2022-06-12 15:51:59.065095
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    """
    The metaclass adds all fields defined in the class (including those
    defined in parent classes) to the `fields` dictionary.
    """

    class ParentSchema(Schema):
        name = String("name")

    class ChildSchema(ParentSchema):
        age = Integer("age")

    assert "name" in ChildSchema.fields
    assert "age" in ChildSchema.fields



# Generated at 2022-06-12 15:52:10.577804
# Unit test for function set_definitions
def test_set_definitions():
    class Bar:
        def __init__(self):
            # Setting default len() to Foo schema
            self.foo_schema = Array(items=Reference("Foo"))
            # Setting default len() to Bar schema
            self.bar_schema = Array(items=Reference("Bar"))

    class Foo(metaclass=SchemaMetaclass):
        definitions = SchemaDefinitions()
        bar = Object(properties=Bar().__dict__)

    # Asserting that foo_schema's definition has been set to 'Foo'
    assert Foo.fields["bar"].properties["foo_schema"].to == "Foo"
    # Asserting that bar_schema's definition has been set to 'Bar'
    assert Foo.fields["bar"].properties["bar_schema"].to == "Bar"
    # Assert

# Generated at 2022-06-12 15:52:18.196949
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test that a Schema returns an iterator over its field names.

    class TestSchema(Schema):
        field_a = Field()
        field_b = Field()
        field_c = Field()

    schema = TestSchema(field_b="b")

    field_names = []
    for name in schema:
        field_names.append(name)

    assert field_names == ["field_a", "field_b"], "Unexpected field names."



# Generated at 2022-06-12 15:52:22.212931
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        name = String(default = "name_value", max_length = 3)
        age = Integer(default = 100, maximum = 150)

    s = MySchema(age = 110)
    assert(len(s) == 1)


# Generated at 2022-06-12 15:52:23.543821
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import pytest
    # Does nothing to assert method __repr__ of class Schema
    assert True

# Generated at 2022-06-12 15:52:32.555796
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import Array, Object, Integer, String

    definitions = SchemaDefinitions()
    assert len(definitions) == 0

    class Author(Schema):
        name = String()
        age = Integer()

    RefAuthor = Reference(Author, definitions=definitions)
    assert len(definitions) == 1

    class Book(Schema):
        title = String()
        authors = Array(RefAuthor)

    assert len(definitions) == 2

    book = Book.validate(
        {
            "title": "Master and Margarita",
            "authors": [{"name": "Mikhail Bulgakov", "age": 44}],
        }
    )
    assert isinstance(book, Book)
    assert isinstance(book["authors"][0], Author)

# Generated at 2022-06-12 15:52:41.057701
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Usage of __new__ in this class

    class MySchema(Schema):
        title = String()
        age = Integer()

    assert(MySchema.fields["title"] == String())
    assert(MySchema.fields["age"] == Integer())

    # Fields in a derived class must override base class fields

    class MySchema2(MySchema):
        title = Integer()

    assert(MySchema2.fields["title"] == Integer())
    assert(MySchema2.fields["age"] == Integer())


# Generated at 2022-06-12 15:52:56.801214
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    fields = {'field_0': Field(), 'field_1': Field(), 'field_2': Field()}
    class_name = 'SchemaDummy'
    arguments = {'field_0': 0, 'field_2': 2}
    schema = SchemaDummy(arguments)
    # Test default __iter__
    assert [i for i in schema] == ['field_0', 'field_2']
    # Test __iter__ in range
    for i in range(3):
        assert schema[i] == arguments[fields[i]]

# Generated at 2022-06-12 15:53:01.789981
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference('TODO', nullable=True, description="description", name='ref')
    assert r.to == 'TODO'
    assert r.name == 'ref'
    assert r.definitions == None
    assert r.description == 'description'

# Generated at 2022-06-12 15:53:11.018186
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema_definitions = SchemaDefinitions()
    class Person(Schema, metaclass=SchemaMetaclass, definitions=schema_definitions):
        first_name = String(max_length=100)
        last_name = String(max_length=100)
        age = Integer(minimum=0)
        is_active = Boolean()

    person = Person(
        first_name='John',
        last_name='Doe',
        age=25,
    )

    assert isinstance(person, Mapping)
    assert len(person) == 3
    assert tuple(person.keys()) == ('first_name', 'last_name', 'age')


# Generated at 2022-06-12 15:53:15.821336
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import String, Float, Integer
    from . import assert_equal, assert_true

    class M(Schema):
        f1 = String()
        f2 = Float()
        f3 = Integer()

    m = M({'f1': 'a', 'f2': 1.1, 'f3': 1})
    assert_equal({'f1', 'f2', 'f3'}, set(m.keys()))
    assert_equal({'f1', 'f2'}, set(M({'f1': 'a', 'f2': 1.1}).keys()))


# Generated at 2022-06-12 15:53:21.778994
# Unit test for method __len__ of class Schema
def test_Schema___len__():
	class Person(Schema):
		name = String(min_length=1, max_length=20)
		age = Number(minimum=0, maximum=150)

	person = Person(
		name="Ada Lovelace",
		age=37,
	)
	assert len(person) == len(person.fields) == 2
	del person.age
	assert len(person) == len(person.fields) - 1
	del person.name
	assert len(person) == 0


# Generated at 2022-06-12 15:53:24.106264
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    assert False



# Generated at 2022-06-12 15:53:32.030848
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from .testdata import TestSchema
    from .testdata import ReferenceField

    definitions: SchemaDefinitions = SchemaDefinitions()

    schema: TestSchema = TestSchema(
        prop1="value1", prop2="value2", prop3="value3"
    )

    assert schema.prop1 == "value1"
    assert schema.prop2 == "value2"
    assert schema.prop3 == "value3"

    validator_1: Field = schema.make_validator()

    assert validator_1.validate(
        {
            "prop1": "value1",
            "prop2": "value2",
            "prop3": "value3",
        }
    )


# Generated at 2022-06-12 15:53:34.905005
# Unit test for constructor of class Schema
def test_Schema():
    class Employee(Schema):
        name = Field(type=str)
        age = Field(type=int)
    employee = Employee(name="John", age=33)
    assert employee.name == "John"
    assert employee.age == 33


# Generated at 2022-06-12 15:53:39.364823
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Schema, Integer

    class Person(Schema):
        id = Integer()

    person = Person(id=1234)
    assert len(person) == 1



# Generated at 2022-06-12 15:53:48.455053
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import Integer
    from xschema.pytypes import AssertionFailed, AssertionRan, TestCase, success
    class UserSchema(Schema):
        id = Integer()

    def test_missing_arguments(self):
        with self.assertRaises(TypeError, msg="missing 1 required positional argument"):
            UserSchema()

    def test_unknown_argument(self):
        with self.assertRaises(TypeError, msg="timestamp is an invalid keyword argument for UserSchema()"):
            UserSchema(timestamp="now")

    def test_ok(self):
        UserSchema(id=1)

    TestCase(test_missing_arguments)
    TestCase(test_unknown_argument)
    TestCase(test_ok)
    return success


# Generated at 2022-06-12 15:54:00.528133
# Unit test for constructor of class Schema
def test_Schema():
    # Some tests will trigger failures due to TypeError
    # So we make sure to handle the exception in order to display the test success message
    try:
        new_vid = VideoMetadata(videoID="Hello", title="World")
        assert new_vid.videoID == "Hello"
    except TypeError:
        print("Constructor of class Schema is not working as expected")
        return
    print("test_Schema passed")
    return


# Generated at 2022-06-12 15:54:10.816847
# Unit test for constructor of class Schema
def test_Schema():
    class CustomSchema(Schema):
        field_one = Field(required=True, type="string")
        field_two = Field(required=True, type="string")
        field_three = Field(required=True, type="string")

    valid_schema_1 = CustomSchema(field_one="hello", field_two="world")
    valid_schema_2 = CustomSchema(field_one="hello", field_two="world")
    class_name = CustomSchema.__name__
    exception_message = "Invalid argument field_two for CustomSchema(). Field type must be a string."
    try:
        CustomSchema(field_one="hello", field_two=2)
    except TypeError as incorrect_exception:
        assert str(incorrect_exception) == exception_message

# Generated at 2022-06-12 15:54:14.438614
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class A(Schema):
        a = Object(properties={"a": Field()})
    assert len(A()) == len(A.fields)
    assert len(A(a=None)) == 0




# Generated at 2022-06-12 15:54:25.535260
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.object import Object as Object_system
    from typesystem.array import Array as Array_system
    from typesystem.field_types import String as String_system
    from typesystem.field_types import Integer as Integer_system
    class Person(Schema):
        name = String_system()
        age = Integer_system()
    class Organization(Schema):
        name = String_system()
        members = Array_system(items=Reference('Person'))
        president = Reference('Person')
    class Company(Schema):
        name = String_system()
    class Department(Schema):
        name = String_system()
    class Employee(Schema):
        name = String_system()
        age = Integer_system()
        department = Reference('Department')
    class Company_system(Schema):
        name = String_system

# Generated at 2022-06-12 15:54:28.470392
# Unit test for method validate of class Reference
def test_Reference_validate():
    #TODO: This method still needs testing
    assert False

# Generated at 2022-06-12 15:54:35.096479
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Color(Schema):
        r = IntegerField(min_value=0, max_value=255)
        g = IntegerField(min_value=0, max_value=255)
        b = IntegerField(min_value=0, max_value=255)

    color = dict(r=255, g=0, b=0)
    c = Color(color)
    c['r']
    assert(c['r']==255)



# Generated at 2022-06-12 15:54:40.479842
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        test_field = Array(items=String())

    assert len(TestSchema()) == 0
    assert len(TestSchema({"test_field": ["abc", "def"]})) == 1


# Generated at 2022-06-12 15:54:48.701229
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Document(Schema):
        customer = Reference("Customer")
        product = Reference("Product")
        amount = Field(type=int)
    
    class Customer(Schema):
        name = Field(type=str)
    
    class Product(Schema):
        name = Field(type=str)
    
    customer = Customer(name="John Smith")
    product = Product(name="Anvil")
    doc = Document(customer=customer, product=product, amount=1)
    assert(doc.__iter__() == (doc["customer"] or doc["product"] or doc["amount"]).__iter__())
    

# Generated at 2022-06-12 15:54:49.656406
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    print("test getitem")
    pass

# Generated at 2022-06-12 15:54:53.939384
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        name = String()
    schema = MySchema(name="hello")
    assert list(schema) == ["name"]


# Generated at 2022-06-12 15:55:10.954285
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field = Field(type="string")

    schema = TestSchema()
    schema.field = "test"
    test_value = schema["field"]
    assert test_value == "test"


# Generated at 2022-06-12 15:55:19.461689
# Unit test for method validate of class Reference
def test_Reference_validate():
    # ensure that the Reference field throws an error if the value
    # is None and the allow_null attribute is set to False
    ref = Reference(to = "Class", allow_null=False)
    assert ref.validate(None) == TypeError
    # ensure that the Reference field does not throw an error if the value
    # is None and the allow_null attribute is set to True
    ref = Reference(to = "Class", allow_null=True)
    assert ref.validate(None) == None
    # ensure that the Reference field does not throw an error if the value
    # is not None and the allow_null attribute is set to True
    ref = Reference(to = "Class", allow_null=True)
    assert ref.validate(object) == object
    # ensure that the Reference field does not throw an error if the value
    # is

# Generated at 2022-06-12 15:55:22.751460
# Unit test for constructor of class Reference
def test_Reference():
    print("Testing Reference constructor")
    ref = Reference("str")
    print("  empty reference with target_string = 'str'")
    assert(ref.target_string == "str")
    assert(ref.target == "str")


# Generated at 2022-06-12 15:55:24.973754
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema(a=1, b=2, c=3)) == 'Schema(a=1, b=2, c=3)'


# Generated at 2022-06-12 15:55:29.481177
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class PersonSchema(Schema):
        name = String()
        age = Integer(minimum=0)
    joe = PersonSchema(name="Joe", age=20)
    assert repr(joe) == "PersonSchema(name='Joe', age=20)", repr(joe)



# Generated at 2022-06-12 15:55:31.434449
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # TODO: Input arguments
    # TODO: Output arguments
    pass


# Generated at 2022-06-12 15:55:42.004839
# Unit test for method validate of class Reference
def test_Reference_validate():
    # create an empty SchemaDefinitions object
    my_schema_def = SchemaDefinitions()

    # create a schema that uses the empty SchemaDefinitions object
    class MySchema(Schema, definitions=my_schema_def):
        first_name = Field(type="string")
        last_name = Field(type="string")

    # now we add a schema to our definitions
    my_schema_def["Person"] = MySchema
    # create a field that uses a string-referenced definition
    field = Reference("Person")
    # create a new schema that uses our field
    class MySchema2(Schema):
        person = field
    # finally validate a value using MySchema2
    assert MySchema2.validate_or_error({"person": {"first_name": "John"}}).value

# Generated at 2022-06-12 15:55:43.564707
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Test1Schema(Schema):
        prop1 = String()

    t1 = Test1Schema(prop1="test")
    assert [i for i in t1] == ["prop1"]


# Generated at 2022-06-12 15:55:47.978994
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = Field(String())
        age = Field(Integer())
        job = Field(String(), required=False)
    
    p1 = Person(name="Andrew", age=20)
    
    expected = ['name', 'age']
    actual = [item for item in p1]
    assert actual == expected


# Generated at 2022-06-12 15:55:57.304108
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = String(max_length=5)
        b = String(max_length=5)
        c = Integer()
    schema = TestSchema(a="hello", c=5)
    assert repr(schema) == "TestSchema(a='hello', c=5)"

    schema = TestSchema(a="hello", b="world")
    assert repr(schema) == "TestSchema(a='hello', b='world', c=None)"
    assert repr(schema) == "TestSchema(a='hello', b='world', c=None) [sparse]"



# Generated at 2022-06-12 15:56:06.371756
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class FooSchema(Schema):
        foo = String()
        bar = String()
        baz = String()

    schema = FooSchema(foo="foo", bar="bar")
    assert len(schema) == 2



# Generated at 2022-06-12 15:56:17.216214
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Movie(Schema):
        title = String(min_length=1)
        year = Integer(minimum=1900)

    movie1 = Movie(title="Citizen Kane", year=1941)
    movie2 = Movie(title="Citizen Kane", year=1941)
    movie3 = Movie(title="The Wizard of Oz", year=1939)
    movie4 = Movie(title="Citizen Kane", year=1941, rating=8.5)
    assert movie1 == movie2
    assert movie1 != movie3
    assert movie1 != movie4
    # Raise Exception if two instances do not have an attribute in common
    movie2.rating = 8.5
    with pytest.raises(AttributeError):
        movie1 == movie2


# Generated at 2022-06-12 15:56:20.531155
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = 1
        b = 2
        c = 3
    a_schema = TestSchema()
    assert set(a_schema.__iter__()) == {'a', 'b', 'c'}


# Generated at 2022-06-12 15:56:31.853570
# Unit test for constructor of class Schema
def test_Schema():
    class SimpleSchema(Schema):
        color = String(max_length=10)
        shape = Enum([1, 2, 3])
        size = Integer(minimum=10, maximum=20)

    simple_schema = SimpleSchema(
        color = 'green',
        shape = 1,
        size = 15
    )

    class ComplexSchema(Schema):
        defs = SchemaDefinitions()

        arr = Array(items=Reference(to='SimpleSchema', definitions=defs))
        nes = Array(items=Object(
            properties={
                'a': Reference(to=SimpleSchema, definitions=defs),
                'b': Reference(to=SimpleSchema, definitions=defs)
            }
        ))


# Generated at 2022-06-12 15:56:39.251518
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema()
    assert 0 == len(schema)

    schema = Schema(a = 1, b = 2)
    assert 2 == len(schema)

    schema = Schema(a = 1, b = 2, strict = True)
    assert 2 == len(schema)

    schema = Schema(a = 1, strict = True)
    assert 1 == len(schema)

    schema = Schema(a = None, b = 2, strict = True)
    assert 1 == len(schema)



# Generated at 2022-06-12 15:56:41.051913
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert list(Schema()) == []
    assert list(Schema(a=42)) == ['a']


# Generated at 2022-06-12 15:56:47.063994
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import types, fields
    from typesystem.types import Integer

    class Parent(Schema):
        foo = fields.Integer()

    class Child(Parent):
        bar = fields.Integer()

    class Child2(Parent):
        bar = fields.Integer()

        class Meta:
            strict = True

    assert isinstance(Child.fields["foo"], Integer)
    assert isinstance(Child.fields["bar"], Integer)
    assert isinstance(Child2.fields["foo"], Integer)
    assert isinstance(Child2.fields["bar"], Integer)



# Generated at 2022-06-12 15:56:53.499072
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class S1(Schema):
        field_1 = String(default="field_1_default")
        field_2 = String()

    s1 = S1(field_2="field_2_value")
    assert list(s1.keys()) == list(s1)
    assert list(s1.keys()) == ["field_1", "field_2"]


# Generated at 2022-06-12 15:57:01.423128
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Ref, String

    class Song(Schema):
        title = String()
        artist = String()
        album = String()

    song = Song(title="The Ghost From The Coast", artist="K.Flay")
    assert song["title"] == "The Ghost From The Coast"
    assert song["artist"] == "K.Flay"

    class Artist(Schema):
        name = String()

    class Album(Schema):
        title = String()
        artist = Ref(Artist)

    album = Album(title="Fall Like Rain", artist=Artist(name="K.Flay"))
    assert album["title"] == "Fall Like Rain"
    assert album["artist"]["name"] == "K.Flay"

    # test for if item is not in Schema
    class Song(Schema):
        title = String

# Generated at 2022-06-12 15:57:05.089243
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()

    person = Person(name="PJ")
    assert len(person) == 1


# Generated at 2022-06-12 15:57:17.853894
# Unit test for constructor of class Schema
def test_Schema():
    from data_testing import SerialisableSchema
    from typesystem.fields import String
    from typesystem.types import StringType

    class Person(Schema):
        name = String(max_length=10)

    person = Person(name="Jill")

    assert person["name"] == "Jill"
    assert person.name == "Jill"
    assert person.is_sparse == False
    assert len(person) == 1
    assert isinstance(person, SerialisableSchema)
    assert person.validate({"name": "Jack"}) == Person(name="Jack")
    assert person.validate(Person(name="Jack")) == Person(name="Jack")
    assert isinstance(person.name, StringType)
    assert person.name.max_length == 10

# Generated at 2022-06-12 15:57:21.697247
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    t = TestSchema(a=1, b=2)
    assert t == t
    assert t != TestSchema(a=1, b=3)


# Generated at 2022-06-12 15:57:32.658155
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(str)
        b = Field(int)
        c = Field(list)
        d = Field(bool, default=True)

    assert vars(TestSchema()) == {'a': None, 'b': None, 'c': None, 'd': True}
    assert vars(TestSchema(a="foo", b=1)) == {'a': "foo", 'b': 1, 'c': None, 'd': True}
    assert vars(TestSchema(b=1, c=[1, 2, 3])) == {'a': None, 'b': 1, 'c': [1, 2, 3], 'd': True}

# Generated at 2022-06-12 15:57:37.491674
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Given
    class TestSchema(Schema):
        pass
    test_schema = TestSchema()
    # When
    result = test_schema.__repr__()
    # Then
    expected = "TestSchema()"
    assert result == expected


# Generated at 2022-06-12 15:57:47.923744
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(String)
        age = Field(Integer, default=0)
        gender = Field(Enum(["male", "female"]), null=True)

    person = Person(name="Foo", age=30, gender="female")
    assert person["name"] == "Foo"
    assert person["age"] == 30
    assert person["gender"] == "female"
    assert person.is_sparse == False

    person = Person({"name": "Foo", "age": 30, "gender": "female"})
    assert person["name"] == "Foo"
    assert person["age"] == 30
    assert person["gender"] == "female"
    assert person.is_sparse == False

    person = Person(name="Foo", age=30)
    assert person["name"]

# Generated at 2022-06-12 15:57:56.268280
# Unit test for method validate of class Reference
def test_Reference_validate():
    from pyspark.sql import Row
    from pyspark.sql.types import StructField, StructType, StringType

    schema = StructType([
        StructField("name", StringType(), True)
    ])

    row = Row(name="Peter")

    # Unit test for method validate of class Reference
    # Test normal case
    reference = Reference(to="Person")
    result = reference.validate(row)
    expected_result = {
        "name": "Peter"
    }
    assert result == expected_result, \
        "Result of method validate in Reference is incorrect"
    # Test exception
    try:
        reference = Reference(None)
        reference.validate(row)
    except Exception as err:
        assert type(err) == ValidationError, \
            "Test exception of method validate in Reference failed"

# Generated at 2022-06-12 15:58:07.194374
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String

    class PersonSchema(Schema):
        name = String()
        age = String()

    assert PersonSchema.fields["name"].target is None
    assert PersonSchema.fields["age"].target is None

    definitions = SchemaDefinitions()
    assert len(definitions) == 0

    PersonSchema.__new__(
        SchemaMetaclass,
        "PersonSchema",
        (Schema,),
        {"fields": {"name": String()}},
        definitions,
    )
    assert PersonSchema.fields["name"].target is None
    assert len(definitions) == 1


# Generated at 2022-06-12 15:58:09.768217
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Foo():
        field = Field()
        field2 = Field(default=42)
    class Bar(Foo):
        field3 = Field(default="bar")



# Generated at 2022-06-12 15:58:14.467700
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        test_field = Field(type=str)
    left = TestSchema(test_field='test')
    right = TestSchema(test_field='test')
    assert(left == right)

    left = TestSchema(test_field='test')
    right = TestSchema(test_field='test2')
    assert(left != right)


# Generated at 2022-06-12 15:58:23.870429
# Unit test for method __len__ of class Schema
def test_Schema___len__():
  # Test that the __len__ method of Schema returns the correct length.
  # Test scenarios:
  # 1. Test on a valid schema with all compulsory argument.
  # 2. Test on an object with a subset of attributes of the schema.
  # 3. Test on an object with a superset of attributes of the schema.

  # 1. Test on a valid schema with all compulsory argument.
  class User(Schema):
    name = String()
    age = Int()
  u = User(name = "a", age = 1)
  assert len(u)==2
  # 2. Test on an object with a subset of attributes of the schema.
  class User(Schema):
    name = String()
    age = Int()
  u = User(name = "a")
  assert len(u)==1
  # 3. Test on

# Generated at 2022-06-12 15:58:40.895401
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema.__init__.__doc__ == "__init__(self, *args: typing.Any, **kwargs: typing.Any) -> None\n"

# Generated at 2022-06-12 15:58:42.661361
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    """
    Test the method __repr__ of the class Schema
    """
    assert True == True


# Generated at 2022-06-12 15:58:50.223681
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import Integer, String
    import json
    class Author(Schema):
        name = String(max_length=255)
        age = Integer(min_value=12)
        
    class Book(Schema):
        title = String(max_length=255)
        autor = Reference(Author)
    
    d1 = {'name':'Alex', 'age': 23}
    d2 = {'title':'title', 'autor': d1}
    
    bk = Book.validate(d2)
    bk1 = Book.validate_or_error(d2)
    bk2 = json.loads(json.dumps(bk1))
    #print(bk)
    #print(bk1)
    #print(bk2)

# Generated at 2022-06-12 15:58:51.319190
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert True


# Generated at 2022-06-12 15:58:59.777507
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.fields import Integer, String

    class TestPerson(Schema):
        name = String()
        age = Integer()

    class TestReference(Schema):
        person = Reference(TestPerson)

    class TestSchema(Schema):
        name = String()
        reference = TestReference

    definitions = SchemaDefinitions()
    set_definitions(TestSchema, definitions)
    assert TestPerson.__name__ in definitions.keys()
    assert TestReference.__name__ in definitions.keys()
    assert TestSchema.__name__ in definitions.keys()

# Generated at 2022-06-12 15:59:08.785224
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String, Integer
    class Metadata(Schema):
        version = String(max_length=10)
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()
        metadata = Metadata()
    person = Person({"name": "John Smith", "age": 30, "metadata": {"version": "1.0.1"}})
    assert Person.validate_or_error({"name": "John Smith", "age": 30, "metadata": {"version": "1.0.1"}}).is_valid
    assert not Person.validate_or_error({"name": "John Smith", "age": 30, "metadata": {"version": "1.0.1", "other": "hello"}}).is_valid
    assert not Person.validate_or_

# Generated at 2022-06-12 15:59:19.212970
# Unit test for function set_definitions
def test_set_definitions():
    d = SchemaDefinitions()
    a = Schema(definitions=d)
    b = Schema(definitions=d)

    assert a.fields == {}
    assert b.fields == {}

    a.fields['c'] = Reference('c')
    assert a.fields['c'].to == 'c'
    assert a.fields['c'].definitions == d
    assert a.fields['c']._target is None
    assert a.fields['c']._target_string == 'c'
    assert b.fields == {}

    b.fields['c'] = Reference('c')
    assert b.fields['c'].to == 'c'
    assert b.fields['c'].definitions == d
    assert b.fields['c']._target is None
    assert b.fields['c']._target_

# Generated at 2022-06-12 15:59:23.140576
# Unit test for constructor of class Schema
def test_Schema():
    class Test(Schema):
        a = Field()
        b = Field()

    obj = Test({"a": 1, "b": 2})
    assert obj.a == 1
    assert obj.b == 2



# Generated at 2022-06-12 15:59:31.290413
# Unit test for method validate of class Reference
def test_Reference_validate():
    import pytest
    from typesystem.base import get_validation_error
    from typesystem.fields import Integer, String
    from typesystem.exceptions import ValidationError
    class Person(Schema):
        id = Integer()
        name = String(max_length=30)
    definitions = SchemaDefinitions()
    class User(Schema):
        person = Reference(Person, definitions=definitions)
        friends = Reference(Person, definitions=definitions, multiple_of=2)
    user = User.validate({"person": {"id": 1, "name": "Tom"}, "friends": [{"id": 2, "name": "Lily"}, {"id": 3, "name": "Peter"}, {"id": 4, "name": "Alice"}]})
    assert user.person == {"id": 1, "name": "Tom"}
   

# Generated at 2022-06-12 15:59:36.486986
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class SchemaPerson(Schema):
        name: Field
        age: Field

    person1 = SchemaPerson.validate(
        {'name': 'John Doe', 'age': 42}
    )
    assert len(person1) == 2
    person2 = SchemaPerson.validate(
        {'name': 'John Doe'}
    )
    assert len(person2) == 1


# Generated at 2022-06-12 15:59:57.890079
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema()
    assert list(schema) == []

    class Author(Schema):
        name = Field(type="string")
        age = Field(type="number")

    class Book(Schema):
        author = Author
        title = Field(type="string")

    # unit test for Book( )
    book = Book(author={"name": "J.K. Rowling", "age": 53}, title="Harry Potter")
    assert list(book) == [
        "author",
        "title",
    ]

    class AuthorWithOptionalAge(Schema):
        name = Field(type="string")
        age = Field(type="number", default=None)

    class BookWithOptionalAge(Schema):
        author = AuthorWithOptionalAge
        title = Field(type="string")

    # unit test for BookWithOptional

# Generated at 2022-06-12 16:00:00.181313
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Contact(Schema):
        email_address = String()
        name = String(required=True)

    assert Contact.__name__ == "Contact"


# Generated at 2022-06-12 16:00:05.693123
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Method __len__ of class Schema should return expected value.
    class ExampleSchema(Schema):
        field1 = Field()
        field2 = Field()

    obj = ExampleSchema()
    assert len(obj) == 0

    obj.field1 = "111"
    assert len(obj) == 1

    obj.field2 = "222"
    assert len(obj) == 2

    obj.field2 = "333"
    assert len(obj) == 2

    obj.field1 = None
    assert len(obj) == 1

    obj.field2 = None
    assert len(obj) == 0

# Generated at 2022-06-12 16:00:06.101238
# Unit test for constructor of class Schema
def test_Schema():
    pass

# Generated at 2022-06-12 16:00:12.314030
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    fields = dict(
        a = "a", b = "b", c = "c", d = "d", e = "e", f = "f", g = "g", h = "h"
    )
    attrs = dict(a = "a", b = "b", g = "g", h = "h")

    class TestSchema(Schema):
        fields = fields

    obj = TestSchema(attrs)
    assert list(iter(obj)) == ["a", "b", "g", "h"]
