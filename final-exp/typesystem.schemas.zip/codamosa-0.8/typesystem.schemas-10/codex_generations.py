

# Generated at 2022-06-12 15:50:45.872155
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
        address = Field(str)

    person = Person(name='xht', age=18, address='Tianjin')

    # The function __iter__ should return an iterator object
    assert hasattr(person.__iter__(), '__next__')

    # The iterator should have the same number of items of schema
    assert len([x for x in person]) == len(person)

    # The iterator should have the same keys of schema
    # print([x for x in person])
    # print([x for x in person.keys()])
    assert [x for x in person] == list(person.fields.keys())


# Generated at 2022-06-12 15:50:48.867744
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema(
        a=1,
        b=2,
    )) == "Schema(a=1, b=2)"


# Generated at 2022-06-12 15:50:52.339497
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    print(Schema(name = "Abc", address = "Map"))
    

# Generated at 2022-06-12 15:51:01.199769
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from importlib import reload
    from unittest.mock import patch
    import types
    import typing
    import unittest
    import typesystem
    import typesystem.schema

    class MockValue(object):
        def __init__(self, value):
            self.value = value

        def get_int(self, key, value):
            return value

        def __eq__(self, other):
            return self.value == other.value

        def __repr__(self):
            return self.value

        def __lt__(self, other):
            return self.value < other.value

    class TestSchema(typesystem.Schema):
        data = typesystem.Boolean(default=True)

    test_value = MockValue("value")
    test_value_1 = MockValue("value")
    test

# Generated at 2022-06-12 15:51:03.581840
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import Integer

    class SchemaWithInteger(Schema):
        age = Integer()

    schema = SchemaWithInteger(age=12)
    assert schema.age == 12



# Generated at 2022-06-12 15:51:09.752374
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    """Tests the method __new__ of class SchemaMetaclass

    Args:
        None

    Return:
        None

    """
    # Creating test objects.
    schema_definitions = SchemaDefinitions()
    schema_attrs = {'test_one': 1, 'test_two': 2}

    # Create a new class Field.
    field_test = Field
    field_test.__name__ = 'field_test'
    field_test.__bases__ = (object,)

    fields_test = {'test_one': field_test}

    # Calling method __new__.

# Generated at 2022-06-12 15:51:20.420199
# Unit test for constructor of class Reference
def test_Reference():
    import pytest
    schema = """
type: object
id: test
properties:
  a:
    type: string
    example: 'hi'
    title: a

"""
    class TestSchema(Schema):
        a: str = Field(type='string', example='hi', title='a')
    data = dict(a='bye')
    test = TestSchema(**data)
    assert test.a == data['a']
    assert test.is_sparse == False
    test = TestSchema._trigger_init(**data)
    assert test.a == data['a']
    assert test.is_sparse == False
    test = TestSchema(**data, b='here')
    assert test.a == data['a']
    assert test.is_sparse == True

# Generated at 2022-06-12 15:51:25.636327
# Unit test for function set_definitions
def test_set_definitions():
    class TestObject(Schema):
        id = int
        name = str

    class TestArray(Schema):
        items = [
            Reference(TestObject),
            str,
            {
                "name": str,
                "children": [Reference(TestObject)]
            },
        ]
    
    definitions = SchemaDefinitions()
    set_definitions(TestArray.fields["items"], definitions)

# Generated at 2022-06-12 15:51:31.308568
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        foo = Field()
        bar = Field()

    value1 = MySchema({'foo': 'bar'})
    assert len(value1) == 1

    value2 = MySchema({'foo': 'bar', 'bar': 'baz'})
    assert len(value2) == 2



# Generated at 2022-06-12 15:51:35.423794
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        first_name = Field(str)
        last_name = Field(str)
    p = Person(first_name='Jack', last_name='Black')
    assert p.first_name == 'Jack'
    assert p.last_name == 'Black'

# Generated at 2022-06-12 15:51:57.902699
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Address(Schema):
        city = Field(str)
        region = Field(str)
        postal_code = Field(str)

    address = Address(city = "Cambridge", region = "MA", postal_code = "02142")
    assert list(address) == ["city", "region", "postal_code"]
    assert len(address) == 3
    assert address == Address(city = "Cambridge", region = "MA", postal_code = "02142")


# Generated at 2022-06-12 15:52:02.831116
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class A(Schema):
        a = Field(str)
        b = Field(str)
    a = A(a='foo')
    assert len(a) == 1


# Generated at 2022-06-12 15:52:12.874486
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Flowers(Schema):
        BOUQUET = "Bouquet"
        JARFUL = "Jarful"
        VASEFUL = "Vaseful"
        KIND = (
            (BOUQUET, "Bouquet"),
            (JARFUL, "Jarful"),
            (VASEFUL, "Vaseful"),
        )

        kind = String(choices=KIND)
        color = String(min_length=1)
        size = Integer(description="Size, in inches.")

    f = Flowers(kind=Flowers.BOUQUET, color="maroon", size=2)
    assert repr(f) == "Flowers(kind='Bouquet', color='maroon', size=2)"

    g = Flowers(kind='bouquet', color='maroon', size=2)
    assert repr

# Generated at 2022-06-12 15:52:19.195450
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
        job = Field(str)

    person = Person(name = "John", age = 30, job = "engineer")
    assert person["name"] == "John"
    assert person["age"] == 30
    assert person["job"] == "engineer"


# Generated at 2022-06-12 15:52:24.396939
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        name = Field(str)
        classlist = Array(Reference("SomeOtherSchema"))

    class MyOtherSchema(Schema):
        id = Field(int)
        name = Field(str)

    definitions = SchemaDefinitions({
        "SomeOtherSchema": MyOtherSchema,
    })

    set_definitions(MySchema.fields["classlist"], definitions)

# Generated at 2022-06-12 15:52:28.683824
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Bar(Schema):
        field = Reference("Foo")

    class Foo(Schema):
        new_field = Bar()

    for field in (Foo.fields.values()):
        set_definitions(field, definitions)
    assert Bar.fields["field"].definitions is definitions

# Generated at 2022-06-12 15:52:32.209698
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.tests.utils import assert_iterable_equals

    class Person(Schema):
        name = String()
        age = Int()

    person = Person(name="Marcel", age=20)
    assert_iterable_equals(iter(person), "name", "age")



# Generated at 2022-06-12 15:52:33.738832
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    s = Schema()
    l = len(s)
    l


# Generated at 2022-06-12 15:52:35.440582
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert False, "Unimplemented"


# Generated at 2022-06-12 15:52:39.945757
# Unit test for function set_definitions
def test_set_definitions():
    class Example(Schema):
        reference = Reference("Other")


# Generated at 2022-06-12 15:52:59.140048
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name  = CharField()
        age = IntField()
        class Meta:
            strict = True
    
    
    john = Person(name = "John", age = 25)
    jane = Person(name = "Jane", age = 30)
    assert(john == john)
    assert(not john == jane)
    

# Generated at 2022-06-12 15:53:05.508618
# Unit test for function set_definitions
def test_set_definitions():
    class MyType(Schema):
        name = Reference("MyNameType")

    class MyNameType(Schema):
        first_name = String(max_length=128)
        last_name = String(max_length=128)

    definitions = SchemaDefinitions()
    set_definitions(MyType, definitions)
    assert definitions["MyNameType"] is MyNameType

# Generated at 2022-06-12 15:53:10.623560
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    with pytest.raises(RuntimeError) as error:
        class TestSchema(Schema):
            field1: Field = Field()
            field2: Field = Field()
            field2: Field = Field()
        assert str(error.value) == 'Definition for field2 has already been set.'
        
    with pytest.raises(TypeError) as error:
        class TestSchema(Schema):
            field1: Field = Field()
            field2: Field = Field()
            def __init__(self, field1: typing.Any):
                pass
        assert str(error.value) == '__init__() missing 1 required positional argument: \'field2\''

    with pytest.raises(TypeError) as error:
        class TestSchema(Schema):
            field1: Field = Field()
            field2

# Generated at 2022-06-12 15:53:14.346509
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field(required=False)

    t_f = TestSchema({"a": 1}, b=2)
    assert t_f.__repr__() == 'TestSchema(a=1, b=2)'
    assert t_f.__repr__() == 'TestSchema(a=1, b=2)'


# Generated at 2022-06-12 15:53:21.333171
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions(island=5)
    field1 = Object(properties={"island": Reference("island")})
    set_definitions(field1, definitions)
    assert field1.properties["island"].definitions == definitions

    field2 = Object(properties={"island": Reference("island", definitions=6)})
    set_definitions(field2, definitions)
    assert field2.properties["island"].definitions == 6


# Generated at 2022-06-12 15:53:25.281881
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.fields import Integer, String

    # Definition of the class A
    class A(Schema):
        a = String()
        b = Integer()

        class Meta:
            definitions = SchemaDefinitions()

    # Definition of the class B
    class B(Schema):
        c = Reference(A)
        d = Integer()

        class Meta:
            definitions = SchemaDefinitions()

    b = B(c={'a': 'test', 'b': 'test'}, d=1)
    # statement to test
    result = b.target.validate(b.c, strict=False)
    expected_res = {'a': 'test', 'b': 'test'}

    assert result == expected_res


# Generated at 2022-06-12 15:53:34.246487
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import pytest
    from typesystem import String, Integer, Array
    from typesystem.compat import PY35
    
    class Pet(Schema):
        name = String(max_length=20)
        age = Integer(minimum=0)

    class PetOwner(Schema):
        name = String(max_length=20)
        pets = Array(items=Pet)
    pet = Pet(name='Spot', age=2)
    petowner = PetOwner(name='Joe', pets=pet)
    assert len(petowner) == 2
    p = petowner.pets[0]
    del petowner.pets[0]
    assert len(petowner) == 2  # this is to check the cache
    if PY35:
        with pytest.raises(RuntimeError):
            len(p)

# Generated at 2022-06-12 15:53:38.645509
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Model(Schema):
        name = Field(type="string")
        # other fields here

    m = Model(name="Guido")
    assert list(m.keys()) == ["name"]



# Generated at 2022-06-12 15:53:48.133524
# Unit test for constructor of class Schema
def test_Schema():
    # Test with empty, no error should be triggered
    schema = Schema()

    # Test with empty, no error should be triggered
    schema = Schema({})

    # Test with field that is not in the schema, no error should be triggered
    schema = Schema({'random': 'random'})
    print(repr(schema))

    # Test with empty, no error should be triggered
    schema = Schema({}, random='random')

    # test against a validator
    field = Schema.make_validator()
    print(field)

    # Test with empty, no error should be triggered
    schema = Schema.validate({})

    # Test with field that is not in the schema, no error should be triggered
    schema = Schema.validate({'random': 'random'})

    # Test with empty, no error should be

# Generated at 2022-06-12 15:53:57.880889
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Test configuration is loaded from a file of the same name.
    # This is configured in setup.cfg.
    from .utils import get_config
    from .utils import load_test_config

    config = get_config(__file__)
    load_test_config(config)

    class Person(Schema):
        name = String()

    person = Person(name="John")
    assert len(person) == 1
    assert list(person) == ["name"]

    person = Person(name=None)
    assert len(person) == 0
    assert list(person) == []


# Generated at 2022-06-12 15:54:23.547185
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        name = fields.String()
        email = fields.String()

    test_schema_one = TestSchema(name="test", email="test_email")
    test_schema_two = TestSchema(name="test", email="test_email")
    test_schema_three = TestSchema(name="test", email="test_email_three")
    assert (test_schema_one == test_schema_two) == True
    assert (test_schema_one == test_schema_three) == False
    assert (test_schema_two == test_schema_three) == False



# Generated at 2022-06-12 15:54:29.005421
# Unit test for function set_definitions
def test_set_definitions():
    from typesystem.fields import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    class Classroom(Schema):
        teacher = Reference(Person)

    definitions = SchemaDefinitions()
    set_definitions(Classroom.fields["teacher"], definitions)

    assert definitions["Person"] == Person

# Generated at 2022-06-12 15:54:38.539625
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import String
    from typesystem.schema import Schema 
    
    
    
    class Test(Schema):
        field1 = String()
        field2 = String()
        field3 = String()
    field1 = Test()
    field2 = Test()
    field3 = Test()
    field4 = Test()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    m_id_staticmethod = id
    int_staticmethod = int
    
    
    
    
    
    
    
    
    
    
    
    
    if __name__ == '__main__':
        import sys
        import doctest
    
        sys.exit(doctest.testmod()[0])

# Generated at 2022-06-12 15:54:48.943399
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.types import String
    from typesystem.fields import Field
    class User(Schema):
        id = String()
        name = String(required=False)
    obj = User(id="foo", name="bar")
    assert obj.id == "foo"
    assert obj.name == "bar"
    assert obj.to_dict() == {"id": "foo", "name": "bar"}
    # An error is raised if an invalid keyword argument is included.
    with pytest.raises(TypeError):
        User(id="foo", name="bar", foobar="baz")
    # The error message is clear.
    with pytest.raises(TypeError) as error:
        User(id="foo", name="bar", foobar="baz")

# Generated at 2022-06-12 15:54:56.304600
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        field1 = int
        field2 = str

    schema = MySchema(field1=10, field2=20)
    assert len(list(schema.__iter__())) == 2
    assert isinstance(list(schema.__iter__())[0], str)
    assert isinstance(list(schema.__iter__())[1], str)


# Generated at 2022-06-12 15:55:00.154069
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert list(Schema()) == list(())
    """
    assert list(Schema(foo="bar")) == list(("foo",))
    assert list(Schema(foo="bar", bar="baz")) == list(("foo", "bar"))
    """


# Generated at 2022-06-12 15:55:08.281916
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        definitions = SchemaDefinitions()
        a = Reference("ref_to_a")

        class Meta:
            definitions = definitions

    definitions = SchemaDefinitions()

    MySchema.Meta.definitions = definitions

    class Line(Schema):
        description = String()

    class Point(Schema):
        description = String()
        x = Integer()
        y = Integer()
        lines = Array(Line())

    definitions["ref_to_a"] = Point()

    assert MySchema.a.definitions == definitions

    schema = MySchema()

    assert schema.a.definitions == definitions

    assert schema.a.target is Point

    assert schema.a.target_string == "ref_to_a"

# Generated at 2022-06-12 15:55:11.440092
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema(json={})) == 0
    assert len(Schema(json={'a': 1})) == 1
    assert len(Schema(json={'a': 1, 'b': 2})) == 2


# Generated at 2022-06-12 15:55:20.043005
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Nested(Schema):
        field1 = String(required=True)
    class Test(Schema):
        a = String()
        b = Nested()
        c = String(required=True)
        d = String()
    test = Test(a='value', c='value2', d='value3')
    assert repr(test) == "Test(a='value', c='value2', d='value3')"
    test2 = Test(b=Nested(field1='value'), c='value2')
    assert repr(test2) == "Test(c='value2', b=Nested(field1='value'))"
    test3 = Test(a='value', c='value2', d='value3')

# Generated at 2022-06-12 15:55:24.381206
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():

    import typesystem


    class Array(typesystem.Array):
        pass


    class String(typesystem.String):
        pass


    class Item(typesystem.Schema):
        name = String(min_length=1, max_length=50)
        is_active = String(max_length=1)
        quantity = String(max_length=10)
        price = String(max_length=10)


    class Order(typesystem.Schema):
        order_id = String(min_length=1, max_length=50)
        date = String(max_length=10)
        payment = String(max_length=1)
        items = Array(of=Item)



# Generated at 2022-06-12 15:55:57.440630
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
  '''
  This unit test is for testing the following methods:
  '''
  pass

# Generated at 2022-06-12 15:56:00.273007
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class SchemaA(Schema):
        field1 = Field()
        field2 = Field()
    a1 = SchemaA()
    a2 = SchemaA()
    assert a1 == a2
    a2 = SchemaA(field1=1)
    assert a1 != a2



# Generated at 2022-06-12 15:56:04.832463
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    # Setup
    class DummySchema(Schema):
        name = "name"
    dummy_schema = DummySchema({
        'name': 'abc'
    })

    # Exercise
    actual = dummy_schema.__repr__()

    # Verify
    expected = "DummySchema(name='abc')"
    assert actual == expected



# Generated at 2022-06-12 15:56:16.888168
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    def check_definitions(self, definitions: SchemaDefinitions) -> None:
        assert self.definitions is not None
        assert self.definitions is definitions

    class DefinitionA(Schema):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            check_definitions(self, definitions)

    class DefinitionB(Schema):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            check_definitions(self, definitions)

    definitions = SchemaDefinitions()
    assert "DefinitionA" not in definitions


# Generated at 2022-06-12 15:56:24.909576
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = Field()
        age = Field()
        hometown = Reference("Hometown")

    class Hometown(Schema):
        name = Field()

    source_code = dedent("""
        class Person(Schema):
            name = Field()
            age = Field()
            hometown = Reference("Hometown")
        
        class Hometown(Schema):
            name = Field()
    """)
    ast_module = ast.parse(source_code)

    tree = astor.code_to_ast(source_code)
    print(astor.dump_tree(tree))

    target_tree = astor.code_to_ast(dedent("""
        class Person(Schema):
            hometown = Reference("Hometown")
            name = Field()
            age = Field()
    """))

# Generated at 2022-06-12 15:56:28.139252
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    assert len(Person(name="fred", age=26)) == 2



# Generated at 2022-06-12 15:56:34.004321
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class PositionSchema(Schema):
        x = Float(minimum=0.0, exclusive_minimum=True)
        y = Float(minimum=0.0, exclusive_minimum=True)

    p = PositionSchema(x=0.5, y=0.5)
    assert repr(p) == "PositionSchema(x=0.5, y=0.5)"

# Generated at 2022-06-12 15:56:35.675172
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert False # TODO: implement your test here


# Generated at 2022-06-12 15:56:45.000883
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Address(Schema):
        city = String()
        street = String(default="")
        number = Integer(default=None)

    a = Address(street="Baker street")
    # a = Address(street="Baker street", number=221)
    # a = Address(number=221)
    # a = Address()
    # a = Address(street="Baker street", number=221, city="London")
    b = a.__iter__()
    print(type(b))
    print(type(b.__next__()))
    print(b.__next__())
    print(b.__next__())
    try:
        print(b.__next__())
    except StopIteration:
        print('No more items')


# Generated at 2022-06-12 15:56:50.610847
# Unit test for constructor of class Schema
def test_Schema():
    import json
    import pandas as pd
    import pandas.util.testing as tm
    import numpy as np
    import types
    import datetime as dt
    import decimal
    import datetime as dt
    import itertools
    import collections
    import operator
    import functools
    import warnings
    import copy


    class Decimal:
        def __init__(self, x):
            self.x = x
        def __eq__(self, x):
            return isinstance(x, Decimal) and self.x == x.x
        def __repr__(self):
            return f"Decimal({self.x})"

    # Test failure if invalid argument to constructor
    try:
        s = Schema(1)
        assert False
    except TypeError:
        pass

    #

# Generated at 2022-06-12 15:57:27.601634
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field = Field(str)
    obj = TestSchema(field ='a')
    assert repr(obj) == "TestSchema(field='a')"
    obj = TestSchema()
    assert repr(obj) == "TestSchema([sparse])"

# Generated at 2022-06-12 15:57:32.985414
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        str_field = Field(str)
        int_field = Field(int)
    assert TestSchema({"str_field": "a", "int_field": 1}) == TestSchema(
        str_field="a", int_field=1
    )
    with pytest.raises(TypeError):
        TestSchema({"str_field": "a"}, int_field=1)

# Generated at 2022-06-12 15:57:44.663941
# Unit test for constructor of class Schema
def test_Schema():
    from . import schema
    schema_dict = {'A': 1, 'B': 'b'}
    schema_obj = schema.Schema(schema_dict)
    # __init__ for Schema is not able to pass the test for any input parameter
    assert not schema_obj
    schema_dict2 = {'C': 2, 'D': 4}
    schema_obj2 = schema.Schema(schema_dict2)
    # test __eq__ function
    assert schema_dict != schema_dict2
    # test __getitem__ function, return string
    assert schema.Schema.__getitem__(schema_dict, 'A') == '1'
    # test __iter__ function
    assert not schema.Schema.__iter__(schema_dict)
    # test __len__ function, return number

# Generated at 2022-06-12 15:57:49.601701
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schemas = [
    {"public_key": "123"},
    {"private_key": "1234"}
]

schema_objects = []
for schema in schemas:
    schema_object = Schema.validate(schema)
    schema_objects.append(schema_object)

assert schema_objects[0] != schema_objects[1]

# Generated at 2022-06-12 15:57:52.899847
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import Integer, Object, String

    class User(Schema):
        name = String()
        age = Integer(minimum=0)

    schema = User(name="John", age=21)
    assert len(schema) == 2


# Generated at 2022-06-12 15:57:59.572690
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String
    from typing import List

    class A(Schema):
        one = String()

    class B(A):
        two = String()

    class C(B):
        three = String()

    a = A()
    b = B()
    c = C()

    assert list(a.__iter__()) == []
    assert list(b.__iter__()) == ["two"]
    assert list(c.__iter__()) == ["two", "three"]

    a.one = "value"
    b.two = "value"
    c.three = "value"

    assert list(a.__iter__()) == ["one"]
    assert list(b.__iter__()) == ["one", "two"]
    assert list(c.__iter__()) == ["one", "two", "three"]

# Generated at 2022-06-12 15:58:04.798748
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field = Field()

    test_schema = TestSchema.validate({"field": None})
    assert repr(test_schema) == "TestSchema(field=None)"

    test_schema = TestSchema(field=None)
    assert repr(test_schema) == "TestSchema(field=None)"

# Generated at 2022-06-12 15:58:10.118917
# Unit test for method validate of class Reference
def test_Reference_validate():
    value = {"b": 1, "a": "test"}
    to = Object(properties={"a": str, "b": int})
    definitions = SchemaDefinitions()
    reference = Reference(to=to, definitions=definitions)
    returned = reference.validate(value)
    assert returned == {'a': 'test', 'b': 1}



# Generated at 2022-06-12 15:58:16.107260
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    import dataverk.resources.typesystems.schema_test_data as schema_test_data

    # Define argument
    args = []

    # Define kwargs
    kwargs = {"test_field_1": "test", "test_field_2": 42}

    # Define expected output
    expected_output = 2

    # Init object
    schema = schema_test_data.TestSchema(*args, **kwargs)

    # Call the method
    result = schema.__len__()

    # Check output
    assert result == expected_output

# Generated at 2022-06-12 15:58:19.162361
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.base import Schema
    from typesystem.base import Reference
    class TestObject(Schema):
        field1 = Reference('TestObject')
    assert TestObject.fields['field1'].target_string == 'TestObject'