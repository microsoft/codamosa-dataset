

# Generated at 2022-06-12 15:50:49.147950
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class MySchema(Schema):
        name = String(max_length=100, required=True)
        email = String(max_length=100, required=True)
        age = Integer(min_value=0)

    s1 = MySchema(name="Alice", email="alice@example.com", age=30)
    s2 = MySchema(name="Bob", email="bob@example.com", age=30)
    s3 = MySchema(name="Alice", email="alice@example.com", age=25)
    assert s1 == s1
    assert s1 != s2
    assert s1 != s3



# Generated at 2022-06-12 15:50:54.116911
# Unit test for function set_definitions
def test_set_definitions():
    schema = Schema(name=Reference('Person'))
    definitions = SchemaDefinitions(Person=Schema(name=Field()))
    set_definitions(schema, definitions)

# Generated at 2022-06-12 15:51:01.968578
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String
    from typesystem.schema import SchemaMetaclass
    import typing
    from typesystem.base import ValidationError
    from unittest import TestCase
    # Test that the method __new__ of class SchemaMetaclass raises no TypeError
    # if the arguments are passed as in the example scripts.
    class TestSchemaMetaclass___new__(TestCase):
        def test_SchemaMetaclass___new__(self):
            class Person(Schema):
                first_name = String()
                last_name = String()
            try:
                class Person(Schema):
                    first_name = String()
                    last_name = String()
            except Exception:
                self.fail("Method __new__of class SchemaMetaclass raises TypeError unexpectedly.")
    # Test that the method

# Generated at 2022-06-12 15:51:04.636231
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field()
        b = Field(default=2)
    ts = TestSchema({"a": 1})
    assert ts.a == 1
    assert ts.b == 2


# Generated at 2022-06-12 15:51:08.208260
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Construct schema
    attributes = [
        ("a", String(max_length=5)),
        ("b", Integer()),
        ("c", String(max_length=6)),
    ]
    TestSchema = Schema.create(attributes)
    # Call function under test
    schema = TestSchema(a="hello")
    length = len(schema)
    # Assert result
    assert length == 1


# Generated at 2022-06-12 15:51:19.556423
# Unit test for method __iter__ of class Schema

# Generated at 2022-06-12 15:51:27.385550
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.base import String, Integer
    from datetime import datetime

    class ModelSchema(Schema):
        id = String()
        title = String()
        body = String()
        num = Integer()
        date = String()

    now = datetime.now()
    test_data = dict(id='abc', title='abc', body='abc', num=1, date=now)
    model = ModelSchema(test_data)
    result = list(model)
    expected = [key for key, _ in ModelSchema.fields.items()]
    assert sorted(result) == sorted(expected)


# Generated at 2022-06-12 15:51:34.856989
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class A(Schema):
        a = Integer()
        b = Reference("B")
        c = Array(Reference("C"))
    class B(Schema):
        d = Integer()
    class C(Schema):
        e = Integer()

    set_definitions(A.fields["b"], definitions)
    set_definitions(A.fields["c"], definitions)

    assert len(definitions) == 2
    assert definitions["B"] is B
    assert definitions["C"] is C


# Generated at 2022-06-12 15:51:41.301896
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Boolean, Integer, String

    class Dog(Schema):
        name = String()
        age = Integer()
        is_good_doggo = Boolean()

    obj = Dog(name="Woof", age=5, is_good_doggo=True)
    assert hasattr(obj, "name") and hasattr(obj, "age") and hasattr(obj, "is_good_doggo")
    assert len(obj.name) > 0
    assert obj.age > 0
    assert obj.is_good_doggo == True
    assert len(obj) == 3
    assert list(obj.keys()) == list(obj.fields.keys())
    assert list(obj.values()) == [obj.name, obj.age, obj.is_good_doggo]

# Generated at 2022-06-12 15:51:52.280706
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert hasattr(Schema, "__class__")
    assert hasattr(Schema, "fields")
    assert hasattr(Schema, "__init__")
    assert hasattr(Schema, "make_validator")
    assert hasattr(Schema, "validate")
    assert hasattr(Schema, "validate_or_error")
    assert hasattr(Schema, "is_sparse")
    assert hasattr(Schema, "__eq__")
    assert hasattr(Schema, "__getitem__")
    assert hasattr(Schema, "__iter__")
    assert hasattr(Schema, "__len__")
    assert hasattr(Schema, "__repr__")

Schema.__new__(Schema)
Schema.make_validator()
Schema.validate()

# Generated at 2022-06-12 15:52:15.371417
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Foo():
        pass

    # testing empty schema
    schema = Schema()

    assert isinstance(schema, Schema)
    assert isinstance(schema, Mapping)
    assert isinstance(schema, typing.Mapping)
    assert len(schema) == 0
    assert list(schema.__iter__()) == []
    assert list(schema.__iter__()) == []


    class Person(Schema):
        name = Field(str)
        age = Field(int)

    # testing for a non-empty schema
    person = Person(name = 'Bob', age = 27)

    assert person.name == 'Bob'
    assert person.age == 27

    assert list(person.__iter__()) == ['name', 'age']



# Generated at 2022-06-12 15:52:17.380676
# Unit test for constructor of class Schema
def test_Schema():
    values = [1, 2]
    schema = Schema(values,'a')
    assert schema == values


# Generated at 2022-06-12 15:52:18.689080
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    pass


# Generated at 2022-06-12 15:52:27.264961
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    assert Person(dict(name="John", age=30))
    assert Person(dict(name="John"))
    assert Person(dict(age=30))
    assert Person(dict())
    assert not Person(Person(dict()))
    assert Person(name="John", age=30)
    assert Person(name="John")
    assert Person(age=30)
    assert Person()
    assert not Person(Person())
    assert Person(Person(dict(name="John", age=30)))
    assert Person(Person(dict(name="John")))
    assert Person(Person(dict(age=30)))
    assert Person(Person(dict()))
    assert Person(Person(name="John", age=30))

# Generated at 2022-06-12 15:52:34.677137
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Foo")

    definitions = SchemaDefinitions()
    definitions["Foo"] = Foo
    definitions["Bar"] = Bar

    assert Foo.fields["foo"].definitions is None
    assert Bar.fields["bar"].definitions is None

    set_definitions(Foo, definitions)

    assert Foo.fields["foo"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions

# Generated at 2022-06-12 15:52:40.659080
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class MyTestSchema(Schema):
        bar = String()

    s1 = MyTestSchema(bar="abc")
    s2 = MyTestSchema(bar="abc")
    s3 = MyTestSchema()
    s4 = Schema()

    assert s1 == s2
    assert s1 != s3
    assert s1 != s4
    assert s3 != s4

# Generated at 2022-06-12 15:52:52.289293
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typing import Dict, List
    import typesystem

    data_struct = {'key1': 'value1', 'key2': 'value2'}

    class Schema1(typesystem.Schema):
        fields = {'key1': typesystem.String, 'key2': typesystem.String}

    obj = Schema1(data_struct)
    assert (len(obj) == 2)
    data_struct = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    class Schema2(typesystem.Schema):
        fields = {'key1': typesystem.String, 'key2': typesystem.String, 'key3': typesystem.String}
    obj = Schema2(data_struct)
    assert (len(obj) == 3)


#

# Generated at 2022-06-12 15:52:57.501039
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String

    class User(Schema):
        name = String()
        age = String()

    user = User(name="John", age="35")
    assert next(iter(user)) == 'name'
    assert next(iter(user)) == 'age'
    assert len(user) == 2


# Generated at 2022-06-12 15:53:09.551969
# Unit test for constructor of class Schema
def test_Schema():
    class SampleSchema(Schema):
        pass

    #test empty dict
    sample = SampleSchema({})

    assert len(sample.fields) == 0

    #test non-empty dict
    class SampleSchema(Schema):
        a = 1
        b = 2

    #test empty dict
    sample = SampleSchema({})

    assert len(sample.fields) == 0

    #test non-empty dict
    class SampleSchema(Schema):
        a = 1
        b = 2

    #test empty dict
    sample = SampleSchema({})

    assert len(sample.fields) == 0

    #test non-empty dict
    class SampleSchema(Schema):
        a = 1
        b = 2

    #test empty dict
    sample = SampleSchema({})


# Generated at 2022-06-12 15:53:15.921744
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # private function: get_value
    def get_value(argument:str, directory:str, schema:Schema) -> typing.Any:
        code = f"result = schema[{argument}]"
        namespace = {"schema":schema}
        exec(code, namespace)
        result = namespace["result"]
        return result

    # private function: test_get_value
    def test_get_value(argument:str, directory:str, schema:Schema) -> None:
        result = get_value(argument, directory, schema)
        assert result == {'key':directory}

    # private function: test_Schema_attribute_values
    def test_Schema_attribute_values(schema:Schema) -> None:
        for argument, directory in [("'key'", "'directory'")]:
            test_get_value

# Generated at 2022-06-12 15:53:25.522499
# Unit test for constructor of class Schema
def test_Schema():
    assert issubclass(Schema, Mapping)
    assert issubclass(Schema, typing.Mapping)


# Generated at 2022-06-12 15:53:34.435498
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Field()
    
    class B(Schema):
        b = Field()
    
    class C(Schema):
        c = Reference(to=B)
        other = Reference(to=A)
    
    definitions = SchemaDefinitions()
    
    reference = C.fields['c']
    assert reference.definitions is None
    set_definitions(reference, definitions)
    assert reference.definitions is definitions
    other = C.fields['other']
    assert other.definitions is None
    set_definitions(other, definitions)
    assert other.definitions is definitions

    array = Array(items=reference)
    assert array.items.definitions is None
    set_definitions(array, definitions)
    assert array.items.definitions is definitions


# Generated at 2022-06-12 15:53:46.094259
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Test of class methods
    test_Schema_validate = lambda self: self.validate(self.items)
    test_Schema_validate_or_error = lambda self: self.validate_or_error(self.items)
    test_Schema_make_validator = lambda self: self.make_validator()
    # Test of instance methods
    test_Schema_is_sparse = lambda self: self.is_sparse
    test_Schema___repr__ = lambda self: self.__repr__()

    # Test of class methods
    assert test_Schema_validate({"items": None}) == {"items": None}, \
        "test of class method is failed"

# Generated at 2022-06-12 15:53:51.022342
# Unit test for function set_definitions
def test_set_definitions():
    class Car(Schema):
        color = Field(description="Color of the car.")
        engine = Field()

    class CarSchema(Schema):
        car = Reference(to="Car")

    definitions = SchemaDefinitions()
    set_definitions(CarSchema.fields["car"], definitions)
    car = Car({"color": "blue"})
    car_schema = CarSchema({"car": car})
    assert car_schema.fields["car"].definitions == definitions
    assert car_schema.fields["car"].target == Car

# Generated at 2022-06-12 15:54:00.119461
# Unit test for method validate of class Reference
def test_Reference_validate():
    target = Object.of({"a": Field.of(int)})

    Reference.of(target, a = "abcd", b = "efgh")

    # a = Reference.of(target, a = "abcd", b = "efgh")
    # a["a"] = "abcd"
    # a.validate(a, strict=False)

    # d = {'a': 'abcd'}
    # Reference.of(target).validate(d, strict=False)
    
    # d = {'a': 'efgh'}
    # Reference.of(target).validate(d, strict=False)

test_Reference_validate()

# Generated at 2022-06-12 15:54:10.252108
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.fields import Integer

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=200)

    p = Person(name = "Alice", age = 31)
    assert p.name == "Alice"
    assert p.age == 31
    assert p == Person(name = "Alice", age = 31)
    p = Person({"name": "Alice", "age": 31})
    assert p.name == "Alice"
    assert p.age == 31
    assert p == Person(name = "Alice", age = 31)
    p = Person(name="Alice")
    assert p.name == "Alice"
    assert p.age == 0
    assert p == Person(name = "Alice", age = 0)

# Generated at 2022-06-12 15:54:15.065520
# Unit test for function set_definitions
def test_set_definitions():
    class Bar(Schema):
        foo = String(max_length=5)

    class Foo(Schema):
        bar = Reference("Bar")

    definitions: SchemaDefinitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions == definitions

# Generated at 2022-06-12 15:54:21.046548
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import doctest
    from .test_Schema__iter__ import globs
    globs['SimpleSchema'] = SimpleSchema
    globs['SimpleSchema_2'] = SimpleSchema_2
    fail_count, test_count = doctest.testmod(globs=globs, optionflags=doctest.ELLIPSIS)
    assert fail_count == 0


# Generated at 2022-06-12 15:54:23.548561
# Unit test for constructor of class Reference
def test_Reference():
    reference = Reference('abc')
    assert reference.to == 'abc'
    assert reference.definitions == None
    assert reference.allow_null == False



# Generated at 2022-06-12 15:54:31.059343
# Unit test for constructor of class Schema
def test_Schema():
    # Test with string reference
    class Person(Schema):
        name = String(max_length=10)

    class House(Schema):
        people = Array(Reference(to="Person", max_length=10))
        definitions = SchemaDefinitions(  # type: ignore
            Person=Person
        )

    house = House(people=[{'name': 'foo'}])
    assert isinstance(house, House)
    assert isinstance(house.people[0], Person)
    assert house.people[0].name == 'foo'
    assert house['people'][0]['name'] == 'foo'

    # Test with reference to a class
    class House2(Schema):
        people = Array(Reference(to=Person, max_length=10))


# Generated at 2022-06-12 15:54:46.585432
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.types import String

    class User(Schema):
        username = String()
        password = String()

    class UserReference(Reference):
        definitions = {
            "User": User,
        }

    # noinspection PyTypeChecker,PyCallByClass
    user_reference = UserReference("User", nullable=True)

    assert user_reference.to == "User"
    assert user_reference.target == User
    assert user_reference.allow_null == True
    assert user_reference.__name__ == "UserReference"


# Generated at 2022-06-12 15:54:52.326171
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        first_name=Field(required=True)
        last_name=Field(required=False)
        age=Field(type=int, required=False)
    schema=TestSchema(first_name="Steve", age=45)
    #print(schema.validate({'first_name':'Joe', 'age':30}))
    #print (schema.validate_or_error({"first_name": "Joe", "age": 30}))
    #print (schema.validate({"first_name": "Joe", "age": 30}))


# Generated at 2022-06-12 15:54:57.451997
# Unit test for function set_definitions
def test_set_definitions():
    class Pet(Schema):
        name = Field(type=str)
        owner = Reference("Owner")
    class Owner(Schema):
        name = Field(type=str)
    definitions = SchemaDefinitions()
    set_definitions(Pet.fields["owner"], definitions)
    assert Pet.fields["owner"].definitions is definitions

# Generated at 2022-06-12 15:55:04.652695
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        attr_1 = Field(String())
        attr_2 = Field(Integer())

    schema = TestSchema(attr_1='test', attr_2=123)
    expected = {'attr_1': 'test', 'attr_2': 123}

    actual = schema['attr_1']
    assert actual == expected['attr_1'], f"Expected: {expected['attr_1']}, Actual: {actual}"

    actual = schema['attr_2']
    assert actual == expected['attr_2'], f"Expected: {expected['attr_2']}, Actual: {actual}"


# Generated at 2022-06-12 15:55:13.415530
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class OtherSchema(Schema):
        field = String()

    class TestSchema(Schema):
        field = String(default="abc")
        array_field = Array(String())
        object_field = Object(properties={"field": String()})
        reference_field = Reference(OtherSchema, definitions=definitions)

    set_definitions(TestSchema, definitions)
    assert definitions["OtherSchema"].fields["field"]

    assert TestSchema.fields["field"]._default == "abc"
    assert TestSchema.fields["array_field"].items.items == ()
    assert TestSchema.fields["object_field"].properties == {
        "field": String()
    }
    assert TestSchema.fields["reference_field"].to == OtherSchema
   

# Generated at 2022-06-12 15:55:17.699111
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class ExampleSchema(Schema):
        filed1 = Field()
        filed2 = Field()
        filed3 = Field()

    schema = ExampleSchema(filed1=1)
    assert list(iter(schema)) == ["filed1"]

    schema = ExampleSchema(filed1=1, filed2=2, filed3=3)
    assert list(iter(schema)) == ["filed1", "filed2", "filed3"]



# Generated at 2022-06-12 15:55:26.519587
# Unit test for function set_definitions
def test_set_definitions():
    class Definition(Schema):
        name = Field()

    definitions = SchemaDefinitions()
    # create empty Schema
    class ReferenceSchema(Schema):
        pass
    expected = Reference(to="Definition", definitions=definitions)
    set_definitions(expected, definitions)
    assert expected.definitions == definitions
    # create Schema with Reference
    class ReferenceSchema(Schema):
        reference = Reference(to="Definition", definitions=definitions)
    expected = ReferenceSchema(reference=Definition(name="test"))
    set_definitions(expected.fields["reference"], definitions)
    assert expected.reference.name == "test"
    assert expected.reference.definitions == definitions
    # create Schema with Array with Reference

# Generated at 2022-06-12 15:55:28.914588
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema({"a": 1, "b": 2, "c": 3})
    assert len(schema) == 3

# Generated at 2022-06-12 15:55:39.573671
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        key = Array(items=int)

    # Create valid object
    obj = Foo({"key": [1, 2, 3]})
    assert isinstance(obj, Foo)
    assert obj.key == [1, 2, 3]

    # Create invalid object
    try:
        obj = Foo(1)
    except TypeError as e:
        assert str(e) == 'Expected a mapping for argument 0 for Foo(), but got int.'
    else:
        assert False, "Expected TypeError"

    # Create invalid object
    try:
        obj = Foo({"key": "test"})
    except TypeError as e:
        assert str(e) == 'Invalid argument \'key\' for Foo(). Expected an array of items.'
    else:
        assert False, "Expected TypeError"



# Generated at 2022-06-12 15:55:42.242847
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
  # test of method __new__ of class SchemaMetaclass
  assert False, "Test of method __new__ of class SchemaMetaclass has not been implemented"


# Generated at 2022-06-12 15:55:53.724779
# Unit test for constructor of class Reference
def test_Reference():
    message_type = object
    message_type1 = object
    a = Reference(to=message_type, definitions=message_type1)
    assert a._target is message_type
    assert a._target_string is message_type

# Generated at 2022-06-12 15:55:57.090325
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        name = String()

    obj = TestSchema(name='a')
    assert (obj == obj) == True

# Generated at 2022-06-12 15:56:01.258504
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        gender = String(enum=["male", "female"])

    class PersonReference(Reference):
        to = Person

    PersonReference().validate({"name": "Denny", "gender": "male"})



# Generated at 2022-06-12 15:56:04.923004
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        name = String()
        age = Integer()
        foo = String()

    x = MySchema(name='bob', age=20)

    assert repr(x) == "MySchema(name='bob', age=20)"



# Generated at 2022-06-12 15:56:06.969639
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name='John', age=42)
    assert list(iter(p)) == ['name', 'age']


# Generated at 2022-06-12 15:56:13.605630
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class A(Schema):
        a = Field()
        b = Field()
        c = Field()

    a = A(a=1, b=2, c=3)
    assert repr(a) == "A(a=1, b=2, c=3)"
    a = A(a=1, b=2)
    assert repr(a) == "A(a=1, b=2) [sparse]"


# Generated at 2022-06-12 15:56:17.856970
# Unit test for function set_definitions
def test_set_definitions():
    # TODO: test in more detail
    class TestType(Schema):
        a = String()
        b = String()
    field = String()
    set_definitions(field, TestType.definitions)
    assert field.definitions == TestType.definitions
    assert field.to is None

# Generated at 2022-06-12 15:56:19.620172
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    test = Schema(name="Test", value="123")
    assert list(test) == ['name', 'value']


# Generated at 2022-06-12 15:56:25.268536
# Unit test for function set_definitions
def test_set_definitions():
    class Definition(Schema):
        id = Field(type="integer")
        name = Field(type="string")

    class Reference(Schema):
        reference = Field(type=Reference(Definition))

    assert Definition.fields["id"].definitions is None
    assert Reference.fields["reference"].definitions is None

    definitions = SchemaDefinitions()

    set_definitions(Definition, definitions)

    assert Definition.fields["id"].definitions is definitions
    assert Reference.fields["reference"].definitions is None

    set_definitions(Reference, definitions)

    assert Definition.fields["id"].definitions is definitions
    assert Reference.fields["reference"].definitions is definitions

# Generated at 2022-06-12 15:56:30.969456
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():

    class MySchema(Schema):
        name = String()
        age = Integer()

    s = MySchema(name="foo", age=30)
    l = list(s)
    assert len(l) == 2

    s = MySchema(name="foo")
    l = list(s)

# Generated at 2022-06-12 15:56:45.492756
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import pytest

    from typesystem.fields import String, Integer

    class SampleSchema(Schema):
        field_1 = String()
        field_2 = Integer()

    from typesystem.fields import String, Integer

    # Test valid case
    sample_object = SampleSchema({"field_1": "field", "field_2": 0})
    for key in sample_object:
        assert key in {"field_1", "field_2"}

    # Test invalid case
    with pytest.raises(KeyError):
        sample_object[3]



# Generated at 2022-06-12 15:56:51.163716
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Field()

    class B(Schema):
        b = Field()

    class C(Schema):
        c = Field()

    class D(Schema):
        d = Reference("B")

    class E(Schema):
        e = Reference("A")

    class F(Schema):
        f = Reference("C")
        g = Field()

    definitions = SchemaDefinitions()
    definitions["A"] = A
    definitions["B"] = B
    definitions["C"] = C

    # Test using string and Reference
    d = D()
    assert d.fields["d"].definitions == definitions
    e = E()
    assert e.fields["e"].definitions == definitions

    # Test array
    f = F()
    assert f.fields["f"].definitions

# Generated at 2022-06-12 15:57:00.138615
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import json

    class Customer(Schema):
        customer_id = Integer(title="Customer ID")
        name = String(title="Name")

    customer_validator = Customer.make_validator()
    assert customer_validator.serialized() == json.loads(
        """
{
  "title": "Customer",
  "type": "object",
  "properties": {
    "customer_id": {
      "title": "Customer ID",
      "type": "integer"
    },
    "name": {
      "title": "Name",
      "type": "string"
    }
  },
  "required": []
}
"""
    )


# Generated at 2022-06-12 15:57:01.074217
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    pass    
    

# Generated at 2022-06-12 15:57:02.083965
# Unit test for constructor of class Reference
def test_Reference():
    to = "Person"
    definitions = {}
    Reference(to, definitions)


# Generated at 2022-06-12 15:57:04.220431
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestClass(Schema):
        a = 1
        b = 2
        c = 3

    test_instance = TestClass()
    result = []
    for i in test_instance:
        result.append(i)
    assert result == ['a', 'b', 'c']



# Generated at 2022-06-12 15:57:09.267282
# Unit test for function set_definitions
def test_set_definitions():
    a = Array(of=Integer(), max_length=5)
    b = Array(of=String(), max_length=5)
    c = Array(of=[Reference("A"), Reference("B")])
    d = Object(properties=dict(a=Reference("A"), b=Reference("B")))
    definitions = SchemaDefinitions()
    fields = [a, b, c, d]
    for field in fields:
        set_definitions(field, definitions)
    assert definitions["A"] == a
    assert definitions["B"] == b

# Generated at 2022-06-12 15:57:14.925787
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Test when value is a Schema object
    test_Referenceschema = Reference(to='TestRefSchema') 
    test_RefSchema = type('RefSchema',(Schema,),{'fieldA':str})
    test_RefSchema_object = test_RefSchema(fieldA='A')
    assert test_Referenceschema.validate(value = test_RefSchema_object) == test_RefSchema_object 
    # Test when value is a string
    assert test_Referenceschema.validate(value = 'RefSchema') == 'RefSchema'


# Generated at 2022-06-12 15:57:21.595392
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem.schema import Schema, String
    from typesystem.fields import String
    class Person(Schema):
        first_name = String()
        last_name = String()
    person = Person({"first_name": "John", "last_name": "Doe"})
    assert person.first_name == "John"
    assert person.last_name == "Doe"


# Generated at 2022-06-12 15:57:27.318314
# Unit test for function set_definitions
def test_set_definitions():
    class TestClass(Schema):
        pass

    class WrapClass(Schema):
        foo = Reference("TestClass")

    definitions = SchemaDefinitions({TestClass.__name__: TestClass})
    set_definitions(WrapClass.fields["foo"], definitions)
    assert WrapClass.fields["foo"].to == TestClass

# Generated at 2022-06-12 15:57:55.811253
# Unit test for constructor of class Schema
def test_Schema():
    # Test empty class (no fields)
    s = Schema()
    assert len(s.fields) == 0

    # Test class without error
    class TestSchema(Schema):
        field = Field()

    s = TestSchema()
    assert len(s.fields) == 1
    assert "field" in list(s.fields.keys())

    # Test class with error
    class TestSchema2(Schema):
        field = Field(required = True)

    try:
        s = TestSchema2()
    except Exception as e:
        print("Exception raised in class TestSchema2 instance creation: {}".format(e))
        assert str(e) == "Value for 'field' field must be supplied."

    # Test class with error on __init__ call

# Generated at 2022-06-12 15:58:00.044905
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()

    p = Person({"name": "Dustin"})

    assert p.name == "Dustin"


# Generated at 2022-06-12 15:58:04.370413
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import Integer, String

    class Person(Schema):
        age = Integer()
        name = String()

    person = Person(age=30, name='Alice')
    assert len(person) == 2
    assert set(person) == {'age', 'name'}



# Generated at 2022-06-12 15:58:05.946741
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():                                          
    assert True # TODO: implement your test here


# Generated at 2022-06-12 15:58:15.290245
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert True

# Generated at 2022-06-12 15:58:18.864327
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        number = Field(type="number")
        text = Field(type="string")
    schema = TestSchema({"number":1,"text":"2"})
    assert [key for key in schema] == ['number','text']


# Generated at 2022-06-12 15:58:23.436813
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Arrange
    class TestSchema(Schema):
        id = Field()

    schema = TestSchema(id=1)

    # Act
    iterator = schema.__iter__()

    # Assert
    assert isinstance(iterator, Iterator)
    assert next(iterator) == 'id'
    with pytest.raises(StopIteration):
        next(iterator)


# Generated at 2022-06-12 15:58:33.770337
# Unit test for function set_definitions
def test_set_definitions():

    class A(Schema):
        a = Field()

    def a_validator():
        return A

    def a_field():
        return Field(of=a_validator)

    def a_array():
        return Array(of=a_field())

    def b_array():
        return Array(of=a_validator())

    c = SchemaDefinitions()

    assert A.fields["a"].definitions is None
    assert a_field().definitions is None
    assert a_validator().fields["a"].definitions is None
    assert a_array().items.definitions is None
    assert b_array().items.definitions is None
    assert a_array().items.of.definitions is None
    assert b_array().items.fields["a"].definitions is None


# Generated at 2022-06-12 15:58:34.318793
# Unit test for constructor of class Schema
def test_Schema():
    assert True

# Generated at 2022-06-12 15:58:37.754961
# Unit test for constructor of class Schema
def test_Schema():
	assert Schema.validate_or_error({"age":22, "name":"Amit"}, strict=True).value is not None
	assert Schema.validate_or_error({"age":22, "name":""}, strict=True).error is not None


# Generated at 2022-06-12 15:59:14.884953
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class SubSchema(Schema):
        id = Integer(default=None)
        name = String(min_length=2, max_length=100)
        active = Boolean(default=True)

    assert isinstance(SubSchema, Schema)
    assert isinstance(SubSchema.fields, dict)
    assert len(SubSchema.fields) == 3
    assert list(SubSchema.fields.keys()) == ['id', 'name', 'active']
    assert isinstance(SubSchema.fields['id'], Integer)
    assert isinstance(SubSchema.fields['name'], String)
    assert isinstance(SubSchema.fields['active'], Boolean)



# Generated at 2022-06-12 15:59:24.902371
# Unit test for method validate of class Reference
def test_Reference_validate():
    class PersonSchema(Schema):
        first_name = Field(type=str)
        last_name = Field(type=str)

    class CompanySchema(Schema):
        name = Field(type=str)
        headcount = Field(type=int)
        ceo = Reference(to=PersonSchema)

    person = PersonSchema(first_name="Larry", last_name="Page")
    company = CompanySchema(
        name="Google", headcount=10000, ceo=person.validate_or_error().value
    )
    company_schema = CompanySchema.make_validator()
    company_validated = company_schema.validate(company.validate_or_error().value)
    assert company_validated == company

    # Negative Test Case

# Generated at 2022-06-12 15:59:26.195831
# Unit test for constructor of class Reference
def test_Reference():
    x = Reference(to=int)
    x.validate(5)

# Generated at 2022-06-12 15:59:33.315497
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import sys
    import types
    import typing
    
    class BaseSchema1(Schema, metaclass=SchemaMetaclass):
        pass
    
    BaseSchema1.__module__ = sys.modules['typesystem.schemas'].__name__
    
    assert BaseSchema1.__qualname__ == 'BaseSchema1'
    assert isinstance(BaseSchema1.__new__, types.BuiltinMethodType)
    assert isinstance(BaseSchema1.__init__, types.FunctionType)
    assert isinstance(BaseSchema1.__call__, types.FunctionType)
    assert isinstance(BaseSchema1.validate, types.FunctionType)
    assert isinstance(BaseSchema1.validate_or_error, types.FunctionType)

# Generated at 2022-06-12 15:59:41.183136
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Integer, Float, String

    class Person(Schema):
        first_name = String()
        last_name = String()
        children = Integer(default=0)

    class Job(Schema):
        title = String()
        salary = Float(minimum=0)

    class PersonWithJob(Person):
        job = Reference(Job)

    class Family(Schema):
        mother = Reference(Person)
        father = Reference(Person)
        children = Array(Reference(Person))
        home = Reference("House")

    class House(Schema):
        address = String()
        color = String(default="blue", optional=True)

    definitions = SchemaDefinitions()
    definitions["House"] = House


# Generated at 2022-06-12 15:59:43.983319
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        bar = Field(type=int)
    foo = Foo(bar=123)
    print(foo.bar)


# Generated at 2022-06-12 15:59:50.700002
# Unit test for function set_definitions
def test_set_definitions():
    field = Array(items=String(max_length=10))
    definitions = SchemaDefinitions()
    set_definitions(field, definitions)
    assert definitions == {}
    field = Object(properties={"a": Array(items=Reference("String"))})
    definitions = SchemaDefinitions()
    assert "String" not in definitions
    set_definitions(field, definitions)
    assert definitions == {"String": String}

# Generated at 2022-06-12 15:59:56.384214
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    s = Schema(
        definitions=definitions,
        foo=Reference('bar')
    )
    assert s.fields['foo'].definitions is None
    set_definitions(s, definitions)
    assert s.fields['foo'].definitions is definitions



# Generated at 2022-06-12 16:00:03.921111
# Unit test for function set_definitions
def test_set_definitions():
    names = [
        "Person",
        "Address",
        "Company",
        "PhoneNumber",
    ]

    fields = {
        "address": Reference("Address"),
        "address_2": Reference("Address"),
        "company": Reference("Company"),
    }

    definitions = SchemaDefinitions()

    class Person(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        fields = fields

    class Address(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        fields = fields

    class Company(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        fields = fields

    for name in names:
        assert name in definitions

# Generated at 2022-06-12 16:00:08.155120
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class S(Schema):
        a = Field()
        b = Field()
        c = Field()
    s = S({'a': 1, 'b': 2, 'c': 3})
    assert set(s) == {'a', 'b', 'c'}