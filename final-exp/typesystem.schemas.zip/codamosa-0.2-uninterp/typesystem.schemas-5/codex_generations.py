

# Generated at 2022-06-18 12:24:38.578179
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        address = String()

    p = Person(name="John", age=30, address="123 Main St.")
    assert p.name == "John"
    assert p.age == 30
    assert p.address == "123 Main St."
    assert p.is_sparse == False
    assert p == Person(name="John", age=30, address="123 Main St.")
    assert p != Person(name="John", age=30)
    assert p != Person(name="John", age=30, address="123 Main St.", extra=1)
    assert p != Person(name="John", age=30, address="123 Main St.", extra=None)
    assert p != Person(name="John", age=30, address="123 Main St.", extra="")

# Generated at 2022-06-18 12:24:44.042839
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2
    assert len(schema) == 2


# Generated at 2022-06-18 12:24:51.807198
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']

    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']

    schema = TestSchema(a=1)
    assert list(schema) == ['a']

    schema = TestSchema()
    assert list(schema) == []


# Generated at 2022-06-18 12:24:57.163921
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    test_schema = TestSchema(field1=1, field2=2)
    assert repr(test_schema) == "TestSchema(field1=1, field2=2) [sparse]"


# Generated at 2022-06-18 12:25:05.598582
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {
        "name": String(),
        "age": Integer(),
    }
    assert Person.make_validator() == Object(
        properties={
            "name": String(),
            "age": Integer(),
        },
        required=["name", "age"],
        additional_properties=None,
    )
    assert Person.validate({"name": "John", "age": 30}) == Person(
        name="John", age=30
    )
    assert Person.validate({"name": "John", "age": 30, "extra": "value"}) == Person(
        name="John", age=30
    )
    assert Person.validate({"name": "John", "age": 30}, strict=True) == Person

# Generated at 2022-06-18 12:25:13.531108
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    set_definitions(Baz.fields["baz"], definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:25:25.329600
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        is_active = Boolean()
        is_admin = Boolean(default=False)
        friends = Array(String())
        address = Object(
            properties={
                "street": String(),
                "city": String(),
                "state": String(),
                "zip": String(),
            }
        )
        created_at = DateTime()
        updated_at = DateTime(default=datetime.datetime.now)
        last_login = DateTime(default=None)
        last_logout = DateTime(default=None)
        last_login_ip = String(default=None)
        last_logout_ip = String(default=None)

# Generated at 2022-06-18 12:25:36.548687
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42
    assert person.is_sparse == False
    assert person == Person(name="John", age=42)
    assert person != Person(name="John", age=43)
    assert person != Person(name="John", age=42, height=1.83)
    assert person != Person(name="John", age=42, height=1.83, is_sparse=True)
    assert person != Person(name="John", age=42, is_sparse=True)
    assert person != Person(name="John", age=42, is_sparse=False)

# Generated at 2022-06-18 12:25:49.050189
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class A(Schema):
        a = Reference("B")
    class B(Schema):
        b = Reference("C")
    class C(Schema):
        c = Reference("D")
    class D(Schema):
        d = Reference("E")
    class E(Schema):
        e = Reference("F")
    class F(Schema):
        f = Reference("G")
    class G(Schema):
        g = Reference("H")
    class H(Schema):
        h = Reference("I")
    class I(Schema):
        i = Reference("J")
    class J(Schema):
        j = Reference("K")
    class K(Schema):
        k = Reference("L")

# Generated at 2022-06-18 12:25:59.323109
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        a = Field(type="string")
        b = Field(type="integer")

    foo = Foo(a="a", b=1)
    assert foo.a == "a"
    assert foo.b == 1
    assert foo.is_sparse == False
    assert foo == Foo(a="a", b=1)
    assert foo != Foo(a="a", b=2)
    assert foo != Foo(a="b", b=1)
    assert foo != Foo(a="a")
    assert foo != Foo(b=1)
    assert foo != Foo()
    assert foo != Foo(a="a", b=1, c=2)
    assert foo != Foo(a="a", b=1, c=2, d=3)

# Generated at 2022-06-18 12:26:17.776840
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()
        height = Float()
        is_adult = Boolean()
        friends = Array(String())

    person = Person(name="John", age=20, height=1.8, is_adult=True, friends=["Mary"])
    assert person.name == "John"
    assert person.age == 20
    assert person.height == 1.8
    assert person.is_adult == True
    assert person.friends == ["Mary"]


# Generated at 2022-06-18 12:26:22.702281
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = String()
        field2 = String()
        field3 = String()
    schema = TestSchema(field1="value1", field2="value2")
    assert len(schema) == 2
    assert len(schema) == 2


# Generated at 2022-06-18 12:26:26.534512
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        field1 = Field()
        field2 = Field()

    schema = MySchema(field1="value1", field2="value2")
    assert len(schema) == 2


# Generated at 2022-06-18 12:26:34.762129
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert TestSchema.fields == {'name': Field(type='string'), 'age': Field(type='integer')}
    assert TestSchema.__name__ == 'TestSchema'
    assert TestSchema.__bases__ == (Schema,)
    assert TestSchema.__dict__ == {'__module__': '__main__', '__doc__': None}
    assert TestSchema.__qualname__ == 'TestSchema'
    assert TestSchema.__annotations__ == {}
    assert TestSchema.__init__.__qualname__ == 'TestSchema.__init__'

# Generated at 2022-06-18 12:26:38.396544
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    my_schema = MySchema(field1=1, field2=2)
    assert len(my_schema) == 2


# Generated at 2022-06-18 12:26:50.705235
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
    s1 = TestSchema(a=1, b=2)
    s2 = TestSchema(a=1, b=2)
    assert s1 == s2
    s3 = TestSchema(a=1)
    assert s1 != s3
    assert s1 != 1
    assert s1 != None
    assert s1 != {}
    assert s1 != []
    assert s1 != ()
    assert s1 != 'abc'
    assert s1 != b'abc'
    assert s1 != '1'
    assert s1 != b'1'
    assert s1 != 'True'
    assert s1 != b'True'
    assert s1 != 'False'
    assert s1 != b'False'
    assert s

# Generated at 2022-06-18 12:26:54.514376
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']



# Generated at 2022-06-18 12:27:00.418892
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:27:03.610936
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ['field1', 'field3']


# Generated at 2022-06-18 12:27:06.170514
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    person = Person(name="John", age=20)
    assert person.name == "John"
    assert person.age == 20


# Generated at 2022-06-18 12:27:33.072652
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert list(person) == ["name", "age"]


# Generated at 2022-06-18 12:27:41.625973
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        foo = Reference("Foo")
        bar = Array(Reference("Bar"))
        baz = Object(properties={"qux": Reference("Qux")})

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.foo, definitions)
    set_definitions(TestSchema.bar, definitions)
    set_definitions(TestSchema.baz, definitions)
    assert TestSchema.foo.definitions is definitions
    assert TestSchema.bar.items.definitions is definitions
    assert TestSchema.baz.properties["qux"].definitions is definitions

# Generated at 2022-06-18 12:27:45.873395
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions == definitions

# Generated at 2022-06-18 12:27:54.706251
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
        height = Field(float)
        is_active = Field(bool)

    person = Person(name="John", age=34, height=1.75, is_active=True)

    assert person["name"] == "John"
    assert person["age"] == 34
    assert person["height"] == 1.75
    assert person["is_active"] == True

    with pytest.raises(KeyError):
        person["not_a_key"]


# Generated at 2022-06-18 12:28:01.278727
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference(to=str)
    assert ref.to == str
    assert ref.definitions == None
    assert ref.allow_null == False
    assert ref.description == None
    assert ref.title == None
    assert ref.default == None
    assert ref.required == False
    assert ref.name == None
    assert ref.validation_error == ValidationError
    assert ref.errors == {"null": "May not be null."}
    assert ref.target_string == "str"
    assert ref.target == str
    assert ref.validate("") == ""
    assert ref.serialize("") == ""

# Generated at 2022-06-18 12:28:12.147961
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    assert TestSchema(field1=1, field2=2, field3=3) == TestSchema(field1=1, field2=2, field3=3)
    assert TestSchema(field1=1, field2=2, field3=3) != TestSchema(field1=1, field2=2, field3=4)
    assert TestSchema(field1=1, field2=2, field3=3) != TestSchema(field1=1, field2=2)
    assert TestSchema(field1=1, field2=2, field3=3) != TestSchema(field1=1, field2=2, field3=3, field4=4)


# Generated at 2022-06-18 12:28:16.574979
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:28:25.709000
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        definitions = SchemaDefinitions({"Person": Person})

    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.to == "Person"
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {"name": "John", "age": 30}
    assert person_reference.validate_or_error(person).value == person
    assert person_reference.validate_or_error(person).error is None
    assert person_reference.validate_or_error(None).value is None
   

# Generated at 2022-06-18 12:28:29.748548
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer()

    schema = TestSchema(name='test', age=10)
    assert schema['name'] == 'test'
    assert schema['age'] == 10
    try:
        schema['address']
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-18 12:28:35.791206
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
        height = Field(float)
        is_adult = Field(bool)

    p = Person(name="John", age=32, height=1.8, is_adult=True)
    assert p.name == "John"
    assert p.age == 32
    assert p.height == 1.8
    assert p.is_adult == True

    p = Person({"name": "John", "age": 32, "height": 1.8, "is_adult": True})
    assert p.name == "John"
    assert p.age == 32
    assert p.height == 1.8
    assert p.is_adult == True

    p = Person(name="John", age=32, height=1.8)

# Generated at 2022-06-18 12:29:03.315591
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.make_validator(), definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:29:10.798254
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")

    class B(Schema):
        c = Reference("C")

    class C(Schema):
        d = Reference("D")

    class D(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert definitions["A"] is A
    assert definitions["B"] is B
    assert definitions["C"] is C
    assert definitions["D"] is D

# Generated at 2022-06-18 12:29:20.790858
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()

    class User(Schema):
        person = Reference(Person)

    user = User.validate({"person": {"name": "John", "age": 30}})
    assert user.person.name == "John"
    assert user.person.age == 30

    try:
        User.validate({"person": {"name": "John", "age": "30"}})
    except ValidationError as error:
        assert error.messages()[0].text == "Must be an integer."
    else:
        assert False, "Expected ValidationError"


# Generated at 2022-06-18 12:29:30.804854
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    p = Person(name="John", age=30, height=1.8)
    assert p.name == "John"
    assert p.age == 30
    assert p.height == 1.8
    assert p.is_sparse == False
    assert repr(p) == "Person(name='John', age=30, height=1.8)"
    assert p == Person(name="John", age=30, height=1.8)
    assert p != Person(name="John", age=30, height=1.7)
    assert p != Person(name="John", age=30)
    assert p != Person(name="John", age=31, height=1.8)

# Generated at 2022-06-18 12:29:35.340972
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    person = Person(name="John Doe", age=42)
    assert person.name == "John Doe"
    assert person.age == 42


# Generated at 2022-06-18 12:29:44.415171
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
        d = Field(type="string")
        e = Field(type="string")
        f = Field(type="string")
        g = Field(type="string")
        h = Field(type="string")
        i = Field(type="string")
        j = Field(type="string")
        k = Field(type="string")
        l = Field(type="string")
        m = Field(type="string")
        n = Field(type="string")
        o = Field(type="string")
        p = Field(type="string")
        q = Field(type="string")
        r = Field(type="string")
        s = Field(type="string")

# Generated at 2022-06-18 12:29:48.629216
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert person["name"] == "John"
    assert person["age"] == 30
    assert person["height"] == None


# Generated at 2022-06-18 12:30:00.284195
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30
    assert person == Person(name="John", age=30)
    assert person != Person(name="John", age=31)
    assert person != Person(name="Jane", age=30)
    assert person != Person(name="Jane", age=31)
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="John", age=30, height=180)

# Generated at 2022-06-18 12:30:08.621065
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class B(Schema):
        pass

    class C(Schema):
        pass

    class D(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert A.a.definitions == definitions
    assert A.b.definitions == definitions
    assert A.c.definitions == definitions

    assert B.a.definitions is None
    assert B.b.definitions is None
    assert B.c.definitions is None

    assert C.a.definitions is None
    assert C.b.definitions is None
    assert C.c.definitions is None

    assert D.a.definitions is None

# Generated at 2022-06-18 12:30:13.531331
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:30:47.207408
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42
    assert person == Person(name="John", age=42)
    assert person != Person(name="John", age=43)
    assert person != Person(name="Jane", age=42)
    assert person != Person(name="Jane", age=43)
    assert person != Person(name="John")
    assert person != Person(age=42)
    assert person != Person()
    assert person.is_sparse is False
    assert repr(person) == "Person(name='John', age=42)"

    person = Person({"name": "John", "age": 42})
    assert person.name == "John"
   

# Generated at 2022-06-18 12:30:57.087347
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")
        qux = Reference("Qux")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    class Qux(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    set_definitions(Foo.fields["baz"], definitions)
    set_definitions(Foo.fields["qux"], definitions)
    set_definitions(Bar.fields["foo"], definitions)
    set_definitions(Baz.fields["foo"], definitions)
    set_definitions(Qux.fields["foo"], definitions)

    assert Foo.fields

# Generated at 2022-06-18 12:31:07.123717
# Unit test for constructor of class Reference
def test_Reference():
    class MySchema(Schema):
        foo = Field()
        bar = Field()
    class MyOtherSchema(Schema):
        baz = Field()
        qux = Field()
    class MyThirdSchema(Schema):
        quux = Reference(to=MySchema)
        corge = Reference(to=MyOtherSchema)
    definitions = SchemaDefinitions()
    MyThirdSchema(definitions=definitions)
    assert definitions["MySchema"] == MySchema
    assert definitions["MyOtherSchema"] == MyOtherSchema
    assert MyThirdSchema.fields["quux"].target == MySchema
    assert MyThirdSchema.fields["corge"].target == MyOtherSchema
    assert MyThirdSchema.fields["quux"].target_string == "MySchema"

# Generated at 2022-06-18 12:31:13.635404
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()
    assert A.fields == {'a': Field(), 'b': Field()}
    assert A.__name__ == 'A'
    assert A.__bases__ == (Schema,)
    assert A.__dict__ == {'__module__': '__main__', '__qualname__': 'A'}


# Generated at 2022-06-18 12:31:16.805187
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name='John', age=30)
    assert len(person) == 2


# Generated at 2022-06-18 12:31:23.469364
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person

    person = Person(name="John", age=42)
    person_reference = PersonReference(person)
    assert person_reference.to == Person
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {"name": "John", "age": 42}


# Generated at 2022-06-18 12:31:32.786400
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    set_definitions(Bar, definitions)
    set_definitions(Baz, definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz
    assert Foo.fields["bar"].definitions == definitions
    assert Foo.fields["baz"].definitions == definitions
    assert Bar.fields["foo"].definitions == definitions
    assert Baz.fields["foo"].definitions == definitions

# Generated at 2022-06-18 12:31:35.332209
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    s = TestSchema(a=1, b=2)
    assert list(s) == ['a', 'b']


# Generated at 2022-06-18 12:31:39.465179
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ['field1', 'field3']

# Generated at 2022-06-18 12:31:43.022462
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    s = TestSchema(a=1, b=2)
    assert list(s) == ['a', 'b']


# Generated at 2022-06-18 12:33:13.865872
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert len(schema) == 3
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2
    schema = TestSchema(field1=1)
    assert len(schema) == 1
    schema = TestSchema()
    assert len(schema) == 0


# Generated at 2022-06-18 12:33:16.992964
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30


# Generated at 2022-06-18 12:33:21.210323
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()

    class B(A):
        c = Field()

    class C(B):
        d = Field()

    assert C.fields == {"a": A.fields["a"], "b": A.fields["b"], "c": B.fields["c"], "d": C.fields["d"]}



# Generated at 2022-06-18 12:33:24.366728
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:33:29.398950
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.bar.definitions is definitions
    assert Foo.baz.definitions is definitions

# Generated at 2022-06-18 12:33:33.246611
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert person["name"] == "John"
    assert person["age"] == 42


# Generated at 2022-06-18 12:33:37.701276
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
    person = Person(name="John", age=30)
    assert person["name"] == "John"
    assert person["age"] == 30
    try:
        person["address"]
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-18 12:33:40.280106
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    obj = TestSchema(field1=1, field2=2)
    assert list(obj) == ["field1", "field2"]


# Generated at 2022-06-18 12:33:43.405888
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
    assert A.fields == {'a': Field()}
    assert A.__name__ == 'A'


# Generated at 2022-06-18 12:33:47.262676
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["bar"].target is Bar