

# Generated at 2022-06-18 12:24:22.337423
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        name = String()
        age = Integer()

    assert TestSchema.fields == {'name': String(), 'age': Integer()}


# Generated at 2022-06-18 12:24:29.481398
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        height = Float(minimum=0)
        weight = Float(minimum=0)
        is_active = Boolean()

    person = Person(name="John Smith", age=42, height=1.75, weight=80.5, is_active=True)
    assert repr(person) == "Person(name='John Smith', age=42, height=1.75, weight=80.5, is_active=True)"

    person = Person(name="John Smith", age=42, height=1.75, weight=80.5)
    assert repr(person) == "Person(name='John Smith', age=42, height=1.75, weight=80.5) [sparse]"


# Generated at 2022-06-18 12:24:31.801140
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer()

    schema = TestSchema(name="John", age=20)
    assert schema["name"] == "John"
    assert schema["age"] == 20

    with pytest.raises(KeyError):
        schema["invalid"]


# Generated at 2022-06-18 12:24:43.440271
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
    class B(Schema):
        b = Reference("C")
    class C(Schema):
        c = Reference("D")
    class D(Schema):
        d = Reference("E")
    class E(Schema):
        e = Reference("F")
    class F(Schema):
        f = Reference("G")
    class G(Schema):
        g = Reference("H")
    class H(Schema):
        h = Reference("I")
    class I(Schema):
        i = Reference("J")
    class J(Schema):
        j = Reference("K")
    class K(Schema):
        k = Reference("L")
    class L(Schema):
        l = Reference("M")

# Generated at 2022-06-18 12:24:47.557560
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name='John', age=20)
    assert p.name == 'John'
    assert p.age == 20


# Generated at 2022-06-18 12:24:53.699290
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    assert repr(TestSchema(field1=1, field2=2)) == "TestSchema(field1=1, field2=2)"
    assert repr(TestSchema(field1=1)) == "TestSchema(field1=1) [sparse]"
    assert repr(TestSchema()) == "TestSchema() [sparse]"


# Generated at 2022-06-18 12:24:57.574010
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:25:05.116012
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions(
        {
            "Foo": Foo,
            "Bar": Bar,
            "Baz": Baz,
        }
    )

    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions == definitions
    assert Foo.fields["bar"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions
    assert Baz.fields["baz"].definitions == definitions

# Generated at 2022-06-18 12:25:11.565700
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Foo(Schema):
        bar = Field(type="string")
        baz = Field(type="string")
    foo = Foo(bar="hello", baz="world")
    assert foo["bar"] == "hello"
    assert foo["baz"] == "world"
    try:
        foo["qux"]
    except KeyError:
        pass
    else:
        assert False, "Should have raised KeyError."


# Generated at 2022-06-18 12:25:15.051344
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    obj = TestSchema(field1=1, field2=2)
    assert list(obj) == ['field1', 'field2']


# Generated at 2022-06-18 12:25:43.246497
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:25:48.824420
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
    schema = TestSchema(a=1, b=2)
    assert schema['a'] == 1
    assert schema['b'] == 2
    try:
        schema['c']
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-18 12:25:54.771836
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    assert list(TestSchema(a=1, b=2)) == ['a', 'b']
    assert list(TestSchema(a=1, b=2, c=3)) == ['a', 'b', 'c']
    assert list(TestSchema(a=1)) == ['a']
    assert list(TestSchema()) == []


# Generated at 2022-06-18 12:26:05.945726
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field()
        b = Field()
    foo1 = Foo(a=1, b=2)
    foo2 = Foo(a=1, b=2)
    assert foo1 == foo2
    foo3 = Foo(a=1, b=3)
    assert not foo1 == foo3
    foo4 = Foo(a=1)
    assert not foo1 == foo4
    foo5 = Foo(b=2)
    assert not foo1 == foo5
    foo6 = Foo()
    assert not foo1 == foo6
    foo7 = Foo(a=1, b=2, c=3)
    assert not foo1 == foo7


# Generated at 2022-06-18 12:26:14.979054
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert list(schema) == ['field1', 'field2', 'field3']

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']

    schema = TestSchema(field1=1)
    assert list(schema) == ['field1']

    schema = TestSchema()
    assert list(schema) == []


# Generated at 2022-06-18 12:26:22.657480
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field2=2, field3=3)"


# Generated at 2022-06-18 12:26:26.804200
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    person = Person(name="John", age=30, height=1.8)
    assert list(person) == ["name", "age", "height"]


# Generated at 2022-06-18 12:26:32.929383
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert len(schema) == 3

    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2

    schema = TestSchema(a=1)
    assert len(schema) == 1

    schema = TestSchema()
    assert len(schema) == 0



# Generated at 2022-06-18 12:26:40.807621
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        height = Field(type="number")
        weight = Field(type="number")
        is_active = Field(type="boolean")
        is_admin = Field(type="boolean")
        is_staff = Field(type="boolean")
        is_superuser = Field(type="boolean")
        is_active = Field(type="boolean")
        is_active = Field(type="boolean")
        is_active = Field(type="boolean")
        is_active = Field(type="boolean")
        is_active = Field(type="boolean")
        is_active = Field(type="boolean")
        is_active = Field(type="boolean")

# Generated at 2022-06-18 12:26:44.803702
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    class Person(Schema):
        name = String()
    class Address(Schema):
        person = Reference(Person)
    address = Address(person=Person(name="John"))
    assert address.person.name == "John"

# Generated at 2022-06-18 12:26:59.190120
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:27:06.037766
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    set_definitions(Bar, definitions)
    set_definitions(Baz, definitions)

    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions
    assert Bar.fields["foo"].definitions is definitions
    assert Baz.fields["foo"].definitions is definitions

# Generated at 2022-06-18 12:27:12.174096
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        gender = String(allow_null=True)
    schema = TestSchema(name="John", age=25)
    assert repr(schema) == "TestSchema(name='John', age=25)"
    schema = TestSchema(name="John", age=25, gender=None)
    assert repr(schema) == "TestSchema(name='John', age=25, gender=None)"
    schema = TestSchema(name="John", age=25, gender="male")
    assert repr(schema) == "TestSchema(name='John', age=25, gender='male')"
    schema = TestSchema(name="John", age=25, gender="male", foo="bar")

# Generated at 2022-06-18 12:27:22.371991
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert schema.field1 == 1
    assert schema.field2 == 2
    assert schema.is_sparse == False
    schema = TestSchema(field1=1)
    assert schema.field1 == 1
    assert schema.field2 == None
    assert schema.is_sparse == True
    schema = TestSchema({"field1": 1, "field2": 2})
    assert schema.field1 == 1
    assert schema.field2 == 2
    assert schema.is_sparse == False
    schema = TestSchema({"field1": 1})
    assert schema.field1 == 1
    assert schema.field2 == None

# Generated at 2022-06-18 12:27:32.752468
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    assert repr(TestSchema(a=1, b=2)) == "TestSchema(a=1, b=2)"
    assert repr(TestSchema(a=1, b=2, c=3)) == "TestSchema(a=1, b=2, c=3)"
    assert repr(TestSchema(a=1, b=2, c=3, d=4)) == "TestSchema(a=1, b=2, c=3) [sparse]"


# Generated at 2022-06-18 12:27:39.837634
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions == definitions
    assert Bar.fields["baz"].definitions == definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:27:44.363417
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert len(person) == 2

    person = Person(name="John")
    assert len(person) == 1

    person = Person()
    assert len(person) == 0



# Generated at 2022-06-18 12:27:50.804541
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    definitions = SchemaDefinitions()
    set_definitions(MySchema.foo, definitions)
    set_definitions(MySchema.bar, definitions)
    assert MySchema.foo.definitions is definitions
    assert MySchema.bar.definitions is definitions

# Generated at 2022-06-18 12:27:55.560346
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"


# Generated at 2022-06-18 12:27:59.674267
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=20)
    assert person["name"] == "John"
    assert person["age"] == 20
    assert person["name"] == person.name
    assert person["age"] == person.age


# Generated at 2022-06-18 12:28:21.083744
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        is_active = Boolean()
        is_admin = Boolean(default=False)
        is_staff = Boolean(default=False)
        is_superuser = Boolean(default=False)
        is_active_staff = Boolean(default=False)
        is_active_superuser = Boolean(default=False)
        is_active_admin = Boolean(default=False)
        is_active_staff_superuser = Boolean(default=False)
        is_active_staff_admin = Boolean(default=False)
        is_active_superuser_admin = Boolean(default=False)
        is_active_staff_superuser_admin = Boolean(default=False)
        is_active_staff_superuser_

# Generated at 2022-06-18 12:28:23.872945
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:28:28.115691
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        alive = Boolean()
    p = Person(name="John", age=20, height=1.8, weight=80.0, alive=True)
    assert list(p) == ['name', 'age', 'height', 'weight', 'alive']


# Generated at 2022-06-18 12:28:30.959916
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']


# Generated at 2022-06-18 12:28:39.276058
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2, c=3)
    assert len(schema) == 3
    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2
    schema = TestSchema(a=1)
    assert len(schema) == 1
    schema = TestSchema()
    assert len(schema) == 0


# Generated at 2022-06-18 12:28:44.601944
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar

# Generated at 2022-06-18 12:28:48.553343
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.field, definitions)
    assert TestSchema.field.definitions is definitions



# Generated at 2022-06-18 12:28:51.778433
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {"name": String(), "age": Integer()}



# Generated at 2022-06-18 12:28:56.235399
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        name = Field(str)
        age = Field(int)
        address = Field(str)

    schema = TestSchema(name="John", age=30)
    assert repr(schema) == "TestSchema(name='John', age=30) [sparse]"


# Generated at 2022-06-18 12:29:00.509560
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    person = Person(name="John", age=42)
    assert person["name"] == "John"
    assert person["age"] == 42
    assert person["height"] == None


# Generated at 2022-06-18 12:29:21.290673
# Unit test for constructor of class Schema
def test_Schema():
    class Test(Schema):
        a = Field(type="string")
        b = Field(type="integer")
        c = Field(type="string", default="c")

    test = Test(a="a", b=1)
    assert test.a == "a"
    assert test.b == 1
    assert test.c == "c"

    test = Test({"a": "a", "b": 1})
    assert test.a == "a"
    assert test.b == 1
    assert test.c == "c"

    test = Test(Test(a="a", b=1))
    assert test.a == "a"
    assert test.b == 1
    assert test.c == "c"

    test = Test(a="a", b=1, c="c")

# Generated at 2022-06-18 12:29:22.784761
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name="John", age=30)
    assert repr(p) == "Person(name='John', age=30)"


# Generated at 2022-06-18 12:29:27.059067
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
    test = TestSchema({"a": "a", "b": "b", "c": "c"})
    assert test.a == "a"
    assert test.b == "b"
    assert test.c == "c"
    test = TestSchema(a="a", b="b", c="c")
    assert test.a == "a"
    assert test.b == "b"
    assert test.c == "c"
    test = TestSchema(TestSchema(a="a", b="b", c="c"))
    assert test.a == "a"
    assert test.b == "b"

# Generated at 2022-06-18 12:29:37.898551
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    person = Person(name="John", age=20)
    assert person.name == "John"
    assert person.age == 20
    assert person == Person(name="John", age=20)
    assert person != Person(name="John", age=30)
    assert person != Person(name="Jane", age=20)
    assert person.is_sparse == False
    assert person.validate({"name": "John", "age": 20}) == person
    assert person.validate_or_error({"name": "John", "age": 20}) == ValidationResult(value=person, error=None)

# Generated at 2022-06-18 12:29:46.035273
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
        height = Field(float)
        weight = Field(float)

    person = Person(name="John", age=30, height=1.8, weight=80.5)
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.8
    assert person.weight == 80.5

    person = Person({"name": "John", "age": 30, "height": 1.8, "weight": 80.5})
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.8
    assert person.weight == 80.5


# Generated at 2022-06-18 12:29:50.260797
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2


# Generated at 2022-06-18 12:29:57.666274
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2, field3=4)

    assert schema1 == schema2
    assert schema1 != schema3


# Generated at 2022-06-18 12:30:07.232292
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
        field5 = Field()
        field6 = Field()
        field7 = Field()
        field8 = Field()
        field9 = Field()
        field10 = Field()
        field11 = Field()
        field12 = Field()
        field13 = Field()
        field14 = Field()
        field15 = Field()
        field16 = Field()
        field17 = Field()
        field18 = Field()
        field19 = Field()
        field20 = Field()
        field21 = Field()
        field22 = Field()
        field23 = Field()
        field24 = Field()
        field25 = Field()
        field26 = Field()
        field27 = Field()


# Generated at 2022-06-18 12:30:11.525132
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    person = Person(name="John Doe", age=42)
    assert person["name"] == "John Doe"
    assert person["age"] == 42


# Generated at 2022-06-18 12:30:16.012438
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()

    p1 = Person(name='John', age=20)
    p2 = Person(name='John', age=20)
    p3 = Person(name='John', age=30)

    assert p1 == p2
    assert p1 != p3


# Generated at 2022-06-18 12:30:53.413855
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:31:00.107985
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")

    class B(Schema):
        c = Reference("C")

    class C(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A.fields["a"], definitions)
    set_definitions(A.fields["b"], definitions)
    set_definitions(B.fields["c"], definitions)
    set_definitions(C.fields["c"], definitions)
    assert definitions["A"] == A
    assert definitions["B"] == B
    assert definitions["C"] == C



# Generated at 2022-06-18 12:31:05.354826
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar

# Generated at 2022-06-18 12:31:17.021202
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30
    assert person.is_sparse == False
    assert person == Person(name="John", age=30)
    assert person != Person(name="John", age=31)
    assert person != Person(name="John", age=30, height=170)
    assert person != Person(name="John", age=30, height=170, is_sparse=True)
    assert person != Person(name="John", age=30, is_sparse=True)
    assert person != Person(name="John", age=30, is_sparse=False)

# Generated at 2022-06-18 12:31:21.034389
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()

    class B(A):
        c = Field()

    assert B.fields == {"a": A.fields["a"], "b": A.fields["b"], "c": B.fields["c"]}


# Generated at 2022-06-18 12:31:31.092165
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person

    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.validate(person) == person
    assert person_reference.validate({"name": "John", "age": 30}) == person
    assert person_reference.validate({"name": "John"}) == person
    assert person_reference.validate({"age": 30}) == person
    assert person_reference.validate({"name": "John", "age": 30, "height": 180}) == person
    assert person_reference.validate({"name": "John", "age": 30, "height": 180}, strict=True) == person
    assert person_reference.validate

# Generated at 2022-06-18 12:31:36.851053
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
    s1 = TestSchema(a="a", b="b", c="c")
    s2 = TestSchema(a="a", b="b", c="c")
    assert s1 == s2
    s3 = TestSchema(a="a", b="b")
    assert s1 != s3
    s4 = TestSchema(a="a", b="b", c="c", d="d")
    assert s1 != s4


# Generated at 2022-06-18 12:31:41.890214
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:31:45.897097
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    test_schema = TestSchema(field1=1, field2=2)
    assert list(test_schema.__iter__()) == ['field1', 'field2']


# Generated at 2022-06-18 12:31:52.773282
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()
    class PersonReference(Reference):
        to = Person
    class PersonReference2(Reference):
        to = "Person"
    assert isinstance(PersonReference().target, Person)
    assert isinstance(PersonReference2().target, Person)
    assert PersonReference2().target_string == "Person"
    assert PersonReference2().to == "Person"
    assert PersonReference2().definitions == None


# Generated at 2022-06-18 12:32:16.073110
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = String()
        field2 = String()
        field3 = String()
    schema = TestSchema(field1="value1", field2="value2")
    assert list(schema) == ["field1", "field2"]


# Generated at 2022-06-18 12:32:20.359308
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:32:25.149089
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:32:34.371478
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field(type="string")
        b = Field(type="string")

    foo1 = Foo(a="a", b="b")
    foo2 = Foo(a="a", b="b")
    assert foo1 == foo2

    foo1 = Foo(a="a", b="b")
    foo2 = Foo(a="a", b="c")
    assert not foo1 == foo2

    foo1 = Foo(a="a", b="b")
    foo2 = Foo(a="a")
    assert not foo1 == foo2

    foo1 = Foo(a="a")
    foo2 = Foo(a="a", b="b")
    assert not foo1 == foo2

    foo1 = Foo(a="a")
    foo2 = Foo(a="a")

# Generated at 2022-06-18 12:32:44.089562
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        is_male = Boolean()
        is_female = Boolean()
        is_human = Boolean()
        is_alien = Boolean()
        is_cyborg = Boolean()
        is_robot = Boolean()
        is_android = Boolean()
        is_humanoid = Boolean()
        is_humanlike = Boolean()
        is_humanoidlike = Boolean()
        is_humanoid_like = Boolean()
        is_human_like = Boolean()
        is_humanlike_humanoid = Boolean()
        is_humanoidlike_human = Boolean()
        is_human_humanoidlike = Boolean()
        is_humanoid_humanlike = Boolean()

# Generated at 2022-06-18 12:32:51.085088
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class B(Schema):
        b = Reference("C")
        c = Reference("D")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert A.fields["a"].definitions is definitions
    assert A.fields["b"].definitions is definitions
    assert A.fields["c"].definitions is definitions
    assert B.fields["b"].definitions is definitions
    assert B.fields["c"].definitions is definitions
    assert C.fields["c"].definitions is definitions
    assert D.fields == {}

# Generated at 2022-06-18 12:32:56.497850
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    assert Foo.fields["foo"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions

# Generated at 2022-06-18 12:32:59.394812
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:33:04.791788
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
        email = String(format="email")

    person = Person(name="John", age=30, email="john@example.com")
    assert repr(person) == "Person(name='John', age=30, email='john@example.com')"

    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30) [sparse]"


# Generated at 2022-06-18 12:33:09.581966
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']
    schema = TestSchema(a=1, c=3)
    assert list(schema) == ['a', 'c']


# Generated at 2022-06-18 12:33:34.105414
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name='John', age=30)
    assert person.name == 'John'
    assert person.age == 30


# Generated at 2022-06-18 12:33:37.619753
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:33:44.326307
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class BaseSchema(Schema):
        pass

    class Schema1(BaseSchema):
        field1 = Field()
        field2 = Field()

    class Schema2(Schema1):
        field3 = Field()

    class Schema3(Schema2):
        field4 = Field()

    class Schema4(Schema3):
        field5 = Field()

    class Schema5(Schema4):
        field6 = Field()

    class Schema6(Schema5):
        field7 = Field()

    class Schema7(Schema6):
        field8 = Field()

    class Schema8(Schema7):
        field9 = Field()

    class Schema9(Schema8):
        field10 = Field()

    class Schema10(Schema9):
        field11 = Field()

# Generated at 2022-06-18 12:33:49.521928
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz