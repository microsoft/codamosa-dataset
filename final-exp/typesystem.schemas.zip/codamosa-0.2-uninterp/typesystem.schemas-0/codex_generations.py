

# Generated at 2022-06-18 12:24:18.472559
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    person = Person(name="John Smith", age=42)
    assert person["name"] == "John Smith"
    assert person["age"] == 42
    assert person["name"] == person.name
    assert person["age"] == person.age
    assert person["name"] == person["name"]
    assert person["age"] == person["age"]
    assert person["name"] != person["age"]
    assert person["age"] != person["name"]
    assert person["name"] != 42
    assert person["age"] != "John Smith"
    assert person["name"] != person.age
    assert person["age"] != person.name
    assert person["name"] != person["age"]

# Generated at 2022-06-18 12:24:27.509831
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
        field5 = Field()
        field6 = Field()
        field7 = Field()
        field8 = Field()
        field9 = Field()
        field10 = Field()
        field11 = Field()
        field12 = Field()
        field13 = Field()
        field14 = Field()
        field15 = Field()
        field16 = Field()
        field17 = Field()
        field18 = Field()
        field19 = Field()
        field20 = Field()
        field21 = Field()
        field22 = Field()
        field23 = Field()
        field24 = Field()
        field25 = Field()
        field26 = Field()
        field27 = Field()


# Generated at 2022-06-18 12:24:30.581693
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["test"] = "test"
    assert definitions["test"] == "test"


# Generated at 2022-06-18 12:24:41.107265
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["a"] = 1
    assert definitions["a"] == 1
    assert definitions.__setitem__("a", 2) is None
    assert definitions["a"] == 2
    assert definitions.__setitem__("b", 3) is None
    assert definitions["b"] == 3
    assert definitions.__setitem__("c", 4) is None
    assert definitions["c"] == 4
    assert definitions.__setitem__("d", 5) is None
    assert definitions["d"] == 5
    assert definitions.__setitem__("e", 6) is None
    assert definitions["e"] == 6
    assert definitions.__setitem__("f", 7) is None
    assert definitions["f"] == 7
    assert definitions.__setitem__("g", 8) is None

# Generated at 2022-06-18 12:24:47.223703
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert list(schema) == ['field1', 'field2', 'field3']


# Generated at 2022-06-18 12:24:55.442451
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class B(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class C(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class D(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert definitions["B"] == B
    assert definitions["C"] == C
    assert definitions["D"] == D

# Generated at 2022-06-18 12:25:05.478114
# Unit test for constructor of class Schema
def test_Schema():
    class MySchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    schema = MySchema(name="John", age=30)
    assert schema.name == "John"
    assert schema.age == 30
    assert schema == MySchema(name="John", age=30)
    assert schema != MySchema(name="John", age=31)
    assert schema != MySchema(name="John", age=30, extra="foo")
    assert schema != MySchema(name="John")
    assert schema != MySchema(age=30)
    assert schema != MySchema()
    assert schema != MySchema(name="John", age=30, extra="foo")
    assert schema != MySchema(name="John", age=30, extra="foo")
    assert schema

# Generated at 2022-06-18 12:25:09.777524
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions == definitions

# Generated at 2022-06-18 12:25:12.073411
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions['key'] = 'value'
    assert definitions['key'] == 'value'


# Generated at 2022-06-18 12:25:15.126564
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    s = TestSchema(a=1, b=2)
    assert list(s) == ['a', 'b']


# Generated at 2022-06-18 12:25:35.303594
# Unit test for constructor of class Schema
def test_Schema():
    class MySchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
        d = Field(type="string")
        e = Field(type="string")
        f = Field(type="string")
        g = Field(type="string")
        h = Field(type="string")
        i = Field(type="string")
        j = Field(type="string")
        k = Field(type="string")
        l = Field(type="string")
        m = Field(type="string")
        n = Field(type="string")
        o = Field(type="string")
        p = Field(type="string")
        q = Field(type="string")
        r = Field(type="string")
        s = Field(type="string")

# Generated at 2022-06-18 12:25:44.628426
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 != schema3
    schema4 = TestSchema(field1=1)
    assert schema1 != schema4


# Generated at 2022-06-18 12:25:48.589201
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']


# Generated at 2022-06-18 12:25:52.134233
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions

# Generated at 2022-06-18 12:26:03.809920
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:26:09.528581
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        alive = Boolean()

    person = Person(name="John", age=30, height=1.8, weight=80.0, alive=True)
    assert list(person) == ["name", "age", "height", "weight", "alive"]



# Generated at 2022-06-18 12:26:13.728168
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"


# Generated at 2022-06-18 12:26:21.676018
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = String()
        field2 = String()
        field3 = String()

    schema1 = TestSchema(field1="value1", field2="value2", field3="value3")
    schema2 = TestSchema(field1="value1", field2="value2", field3="value3")
    schema3 = TestSchema(field1="value1", field2="value2", field3="value4")

    assert schema1 == schema2
    assert schema1 != schema3


# Generated at 2022-06-18 12:26:25.480366
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions is definitions

# Generated at 2022-06-18 12:26:27.444252
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["test"] = "test"
    assert definitions["test"] == "test"


# Generated at 2022-06-18 12:26:54.266736
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    set_definitions(Baz.fields["baz"], definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz
    assert Foo.fields["foo"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:27:02.133275
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert len(schema) == 3
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2
    schema = TestSchema(field1=1)
    assert len(schema) == 1
    schema = TestSchema()
    assert len(schema) == 0


# Generated at 2022-06-18 12:27:05.082165
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42


# Generated at 2022-06-18 12:27:07.923569
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["bar"].target is Bar

# Generated at 2022-06-18 12:27:18.722993
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30
    assert person.is_sparse == False
    assert person == Person(name="John", age=30)
    assert person != Person(name="John", age=31)
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="John")
    assert person != Person(age=30)
    assert person != Person()
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="John", age=30, height=180)
   

# Generated at 2022-06-18 12:27:22.211709
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        name = String()
        age = Integer()
        gender = String()

    schema = MySchema(name="John", age=23, gender="Male")
    assert list(schema) == ["name", "age", "gender"]



# Generated at 2022-06-18 12:27:35.403523
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
        height = Field(float)
        is_active = Field(bool, default=True)

    person = Person(name="John", age=32, height=1.8)
    assert person.name == "John"
    assert person.age == 32
    assert person.height == 1.8
    assert person.is_active is True

    person = Person(name="John", age=32, height=1.8, is_active=False)
    assert person.name == "John"
    assert person.age == 32
    assert person.height == 1.8
    assert person.is_active is False

    person = Person({"name": "John", "age": 32, "height": 1.8})

# Generated at 2022-06-18 12:27:42.885086
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class BaseSchema(Schema):
        field1 = Field()
        field2 = Field()

    class SubSchema(BaseSchema):
        field3 = Field()

    class SubSubSchema(SubSchema):
        field4 = Field()

    assert SubSubSchema.fields == {
        "field1": BaseSchema.fields["field1"],
        "field2": BaseSchema.fields["field2"],
        "field3": SubSchema.fields["field3"],
        "field4": SubSubSchema.fields["field4"],
    }


# Generated at 2022-06-18 12:27:46.388292
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = MySchema(a=1, b=2)
    assert len(schema) == 2



# Generated at 2022-06-18 12:27:51.633952
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:28:22.093396
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c == 3

    schema = TestSchema(dict(a=1, b=2, c=3))
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c == 3

    schema = TestSchema(TestSchema(a=1, b=2, c=3))
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c == 3

    schema = TestSchema(a=1, b=2)
    assert schema.a == 1
    assert schema.b == 2
   

# Generated at 2022-06-18 12:28:24.181508
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field = Field()
    schema = TestSchema(field=1)
    assert schema['field'] == 1


# Generated at 2022-06-18 12:28:29.038766
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.make_validator(), definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:28:31.743301
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ['field1', 'field3']


# Generated at 2022-06-18 12:28:39.949719
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = String()

    class Bar(Schema):
        bar = String()

    class Baz(Schema):
        baz = String()

    class FooBar(Schema):
        foo = Reference("Foo")
        bar = Reference("Bar")
        baz = Reference("Baz")

    definitions = SchemaDefinitions()
    set_definitions(FooBar, definitions)
    assert FooBar.foo.definitions == definitions
    assert FooBar.bar.definitions == definitions
    assert FooBar.baz.definitions == definitions

# Generated at 2022-06-18 12:28:43.684306
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ['field1', 'field3']


# Generated at 2022-06-18 12:28:55.024754
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)
        height = Field(type=float)
        weight = Field(type=float)
        alive = Field(type=bool)
        address = Field(type=str)
        phone = Field(type=str)
        email = Field(type=str)

    p = Person(name="John", age=30, height=1.75, weight=80.5, alive=True, address="", phone="", email="")
    assert p.name == "John"
    assert p.age == 30
    assert p.height == 1.75
    assert p.weight == 80.5
    assert p.alive == True
    assert p.address == ""
    assert p.phone == ""
    assert p.email == ""



# Generated at 2022-06-18 12:29:02.599199
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert repr(TestSchema(a=1, b=2, c=3)) == "TestSchema(a=1, b=2, c=3)"
    assert repr(TestSchema(a=1, b=2)) == "TestSchema(a=1, b=2) [sparse]"
    assert repr(TestSchema(a=1)) == "TestSchema(a=1) [sparse]"
    assert repr(TestSchema()) == "TestSchema() [sparse]"


# Generated at 2022-06-18 12:29:13.312675
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    set_definitions(Foo.fields["baz"], definitions)
    set_definitions(Bar.fields["foo"], definitions)
    set_definitions(Baz.fields["foo"], definitions)

    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions
    assert Bar.fields["foo"].definitions is definitions
    assert Baz.fields["foo"].definitions is definitions

# Generated at 2022-06-18 12:29:22.806994
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        address = String(max_length=100)
        phone = String(max_length=100)
    person = Person(name='John', age=30, address='123 Main St', phone='555-1212')
    assert person.name == 'John'
    assert person.age == 30
    assert person.address == '123 Main St'
    assert person.phone == '555-1212'
    assert person.is_sparse == False
    assert person == Person(name='John', age=30, address='123 Main St', phone='555-1212')
    assert person != Person(name='John', age=30, address='123 Main St', phone='555-1213')

# Generated at 2022-06-18 12:31:14.872388
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.foo.definitions is definitions
    assert Foo.bar.definitions is definitions
    assert Bar.bar.definitions is definitions
    assert Baz.baz.definitions is definitions

# Generated at 2022-06-18 12:31:24.720094
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    assert Person.fields == {"name": String()}

    class Employee(Person):
        salary = String()

    assert Employee.fields == {"name": String(), "salary": String()}

    class Manager(Employee):
        pass

    assert Manager.fields == {"name": String(), "salary": String()}

    class Manager(Employee):
        name = String(required=False)

    assert Manager.fields == {"name": String(required=False), "salary": String()}

    class Manager(Employee):
        name = String(required=False)
        salary = String()

    assert Manager.fields == {"name": String(required=False), "salary": String()}


# Generated at 2022-06-18 12:31:28.577259
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        pass
    class Bar(Schema):
        foo = Reference("Foo")
    definitions = SchemaDefinitions()
    set_definitions(Bar.fields["foo"], definitions)
    assert definitions["Foo"] == Foo

# Generated at 2022-06-18 12:31:34.455224
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert len(schema) == 3

    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2

    schema = TestSchema(a=1)
    assert len(schema) == 1

    schema = TestSchema()
    assert len(schema) == 0


# Generated at 2022-06-18 12:31:38.800734
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2


# Generated at 2022-06-18 12:31:49.212572
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert TestSchema(a=1, b=2, c=3) == TestSchema(a=1, b=2, c=3)
    assert TestSchema(a=1, b=2, c=3) != TestSchema(a=1, b=2, c=4)
    assert TestSchema(a=1, b=2, c=3) != TestSchema(a=1, b=2)
    assert TestSchema(a=1, b=2, c=3) != TestSchema(a=1, b=2, c=3, d=4)

# Generated at 2022-06-18 12:31:57.108720
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions == definitions
    assert Foo.fields["bar"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions
    assert Baz.fields["baz"].definitions == definitions

# Generated at 2022-06-18 12:32:05.384532
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    obj = TestSchema(a=1, b=2, c=3)
    assert list(obj) == ['a', 'b', 'c']

    obj = TestSchema(a=1, b=2)
    assert list(obj) == ['a', 'b']

    obj = TestSchema(a=1)
    assert list(obj) == ['a']

    obj = TestSchema()
    assert list(obj) == []



# Generated at 2022-06-18 12:32:11.035323
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions == definitions
    assert Foo.fields["baz"].definitions == definitions
    assert Bar.fields["foo"].definitions == definitions
    assert Baz.fields["foo"].definitions == definitions

# Generated at 2022-06-18 12:32:14.397863
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field_1 = String()
        field_2 = String()
    assert TestSchema.fields == {'field_1': String(), 'field_2': String()}


# Generated at 2022-06-18 12:33:46.553582
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        is_active = Boolean()

    test_schema = TestSchema(name='John', age=25, is_active=True)
    assert test_schema['name'] == 'John'
    assert test_schema['age'] == 25
    assert test_schema['is_active'] == True


# Generated at 2022-06-18 12:33:51.918652
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions == definitions
    assert Bar.fields["baz"].definitions == definitions
    assert Baz.fields["baz"].definitions is None