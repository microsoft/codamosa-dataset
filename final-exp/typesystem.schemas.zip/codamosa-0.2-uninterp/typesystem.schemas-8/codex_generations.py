

# Generated at 2022-06-18 12:24:30.513992
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2
    assert list(schema) == ["a", "b"]
    assert list(schema.keys()) == ["a", "b"]
    assert list(schema.values()) == [1, 2]
    assert list(schema.items()) == [("a", 1), ("b", 2)]
    assert schema["a"] == 1
    assert schema["b"] == 2
    assert schema.get("a") == 1
    assert schema.get("b") == 2
    assert schema.get("c") is None
    assert schema.get("c", 3) == 3
    assert schema.a == 1
    assert schema

# Generated at 2022-06-18 12:24:40.712250
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person
        definitions = SchemaDefinitions()

    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.validate(person) == person
    assert person_reference.validate({"name": "John", "age": 30}) == person

    person_reference = PersonReference(name="John", age=30)
    assert person_reference.validate(person) == person
    assert person_reference.validate({"name": "John", "age": 30}) == person

    person_reference = PersonReference(name="John")
    assert person_reference.validate(person) == person

# Generated at 2022-06-18 12:24:47.558095
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar

# Generated at 2022-06-18 12:24:58.035208
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    class PersonReference(Reference):
        to = Person

    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.validate(person) == person
    assert person_reference.validate({"name": "John", "age": 30}) == person
    assert person_reference.validate({"name": "John", "age": 30, "extra": "field"}) == person
    assert person_reference.validate({"name": "John", "age": 30, "extra": "field"}, strict=True) == person

# Generated at 2022-06-18 12:25:06.274393
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.schema import Schema

    class Person(Schema):
        name = String()
        age = String()

    class Address(Schema):
        street = String()
        city = String()
        state = String()
        zip_code = String()

    class PersonAddress(Schema):
        person = Reference(Person)
        address = Reference(Address)

    person = Person(name="John", age="30")
    address = Address(street="123 Main St", city="New York", state="NY", zip_code="10001")
    person_address = PersonAddress(person=person, address=address)
    assert person_address.person == person
    assert person_address.address == address
    assert person_address.person.name == "John"
    assert person_address.person

# Generated at 2022-06-18 12:25:15.288982
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field_1 = Field()
        field_2 = Field()
        field_3 = Field()

    schema = TestSchema(field_1=1, field_2=2, field_3=3)
    assert list(schema) == ['field_1', 'field_2', 'field_3']

    schema = TestSchema(field_1=1, field_2=2)
    assert list(schema) == ['field_1', 'field_2']

    schema = TestSchema(field_1=1)
    assert list(schema) == ['field_1']

    schema = TestSchema()
    assert list(schema) == []



# Generated at 2022-06-18 12:25:20.012992
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()

    class User(Schema):
        person = Reference(Person)

    user = User(person={"name": "John", "age": 30})
    assert user.person.name == "John"
    assert user.person.age == 30


# Generated at 2022-06-18 12:25:29.009190
# Unit test for constructor of class Reference
def test_Reference():
    class TestSchema(Schema):
        test_field = Field()

    test_schema = TestSchema()
    test_reference = Reference(to=test_schema)

    assert test_reference.to == test_schema
    assert test_reference.target == test_schema
    assert test_reference.target_string == 'TestSchema'
    assert test_reference.validate(test_schema) == test_schema
    assert test_reference.serialize(test_schema) == {}


# Generated at 2022-06-18 12:25:31.690379
# Unit test for constructor of class Reference
def test_Reference():
    class Test(Schema):
        test = Reference('test')
    test = Test(test={'test': 'test'})
    assert test.test == {'test': 'test'}


# Generated at 2022-06-18 12:25:44.683297
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    person = Person(name="John Smith", age=30)
    assert person.name == "John Smith"
    assert person.age == 30
    assert person == Person(name="John Smith", age=30)
    assert person != Person(name="John Smith", age=31)
    assert person != Person(name="John Smith", age=30, height=180)
    assert person != Person(name="John Smith", age=30, height=180, weight=80)
    assert person != Person(name="John Smith", age=30, height=180, weight=80, gender="male")

# Generated at 2022-06-18 12:25:57.231565
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class TestSchema(Schema):
        field1 = Reference("TestSchema")
        field2 = Reference(TestSchema)

    schema = TestSchema(field1={"field1": "test"}, field2={"field2": "test"})
    assert schema.field1 == {"field1": "test"}
    assert schema.field2 == {"field2": "test"}

# Generated at 2022-06-18 12:26:09.408387
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field()
        b = Field()
    class B(Schema):
        a = Field()
        b = Field()
    class C(Schema):
        a = Field()
        b = Field()
        c = Field()
    class D(Schema):
        a = Field()
        b = Field()
        c = Field()
    class E(Schema):
        a = Field()
        b = Field()
        c = Field()
    class F(Schema):
        a = Field()
        b = Field()
        c = Field()
    class G(Schema):
        a = Field()
        b = Field()
        c = Field()
    class H(Schema):
        a = Field()
        b = Field()
        c = Field()

# Generated at 2022-06-18 12:26:20.983347
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3, field4=4)
    schema2 = TestSchema(field1=1, field2=2, field3=3, field4=4)
    schema3 = TestSchema(field1=1, field2=2, field3=3)
    schema4 = TestSchema(field1=1, field2=2, field3=3, field4=5)

    assert schema1 == schema2
    assert schema1 != schema3
    assert schema1 != schema4
    assert schema3 != schema4


# Generated at 2022-06-18 12:26:24.807778
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42


# Generated at 2022-06-18 12:26:29.994210
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1, b=2, c=3)) == 3
    assert len(TestSchema(a=1, b=2, c=3, d=4)) == 3


# Generated at 2022-06-18 12:26:39.474863
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person
        definitions = SchemaDefinitions()

    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.validate(person) == person
    assert person_reference.validate({"name": "John", "age": 30}) == person
    assert person_reference.validate({"name": "John"}) == person
    assert person_reference.validate({"age": 30}) == person
    assert person_reference.validate({"name": "John", "age": 30, "extra": "field"}) == person

# Generated at 2022-06-18 12:26:44.213377
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:26:54.070177
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
        field5 = Field()

    schema = TestSchema(field1=1, field2=2, field3=3, field4=4, field5=5)
    assert len(schema) == 5

    schema = TestSchema(field1=1, field2=2, field3=3, field4=4)
    assert len(schema) == 4

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert len(schema) == 3

    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2

    schema = TestSchema(field1=1)

# Generated at 2022-06-18 12:26:58.880059
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1="value1", field2="value2")
    assert len(schema) == 2


# Generated at 2022-06-18 12:27:05.231635
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2)
    schema4 = TestSchema(field1=1, field2=2, field3=4)

    assert schema1 == schema2
    assert schema1 != schema3
    assert schema1 != schema4


# Generated at 2022-06-18 12:27:40.289173
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.schema import Schema
    class User(Schema):
        name = String()
    class Comment(Schema):
        user = Reference(User)
    comment = Comment(user=User(name="John"))
    assert comment.user.name == "John"
    assert comment.user.__class__.__name__ == "User"
    assert comment.user.__class__.__module__ == "__main__"
    assert comment.user.__class__.__qualname__ == "User"
    assert comment.user.__class__.__bases__ == (Schema,)
    assert comment.user.__class__.__dict__ == {'name': String()}
    assert comment.user.__class__.__doc__ == None
    assert comment.user.__class

# Generated at 2022-06-18 12:27:48.833702
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
    schema1 = TestSchema(a=1, b=2)
    schema2 = TestSchema(a=1, b=2)
    assert schema1 == schema2
    schema3 = TestSchema(a=1, b=3)
    assert schema1 != schema3
    schema4 = TestSchema(a=1)
    assert schema1 != schema4
    schema5 = TestSchema(b=2)
    assert schema1 != schema5


# Generated at 2022-06-18 12:27:59.090570
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()
        address = String()
    person = Person(name="John", age=30, address="123 Main St.")
    assert person.name == "John"
    assert person.age == 30
    assert person.address == "123 Main St."
    assert repr(person) == "Person(name='John', age=30, address='123 Main St.')"
    assert person == Person(name="John", age=30, address="123 Main St.")
    assert person != Person(name="John", age=30, address="456 Main St.")
    assert person != Person(name="John", age=31, address="123 Main St.")
    assert person != Person(name="Jane", age=30, address="123 Main St.")

# Generated at 2022-06-18 12:28:02.805690
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    test_schema = TestSchema(field1=1, field2=2)
    assert list(test_schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:28:13.837893
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()
    class PersonReference(Reference):
        to = Person
    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.to == Person
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {"name": "John", "age": 30}
    assert person_reference.validate_or_error(person).value == person
    assert person_reference.validate_or_error(person).error is None
    assert person_reference.validate_or_error(None).value is None
    assert person_reference.validate_or_error

# Generated at 2022-06-18 12:28:18.160082
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ['field1', 'field3']


# Generated at 2022-06-18 12:28:26.709928
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert person["name"] == "John"
    assert person["age"] == 42
    assert person["name"] == person.name
    assert person["age"] == person.age
    assert person["name"] == person["name"]
    assert person["age"] == person["age"]
    assert person["name"] == getattr(person, "name")
    assert person["age"] == getattr(person, "age")
    assert person["name"] == getattr(person, "name")
    assert person["age"] == getattr(person, "age")
    assert person["name"] == getattr(person, "name")
    assert person["age"] == getattr(person, "age")
    assert person

# Generated at 2022-06-18 12:28:29.600299
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:28:35.708240
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test SchemaMetaclass.__new__()
    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {"name": String(), "age": Integer()}
    assert Person.__name__ == "Person"
    assert Person.__module__ == __name__
    assert Person.__qualname__ == "test_SchemaMetaclass___new__.<locals>.Person"
    assert Person.__bases__ == (Schema,)
    assert Person.__dict__ == {"fields": {"name": String(), "age": Integer()}}

    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {"name": String(), "age": Integer()}
    assert Person.__name__ == "Person"
    assert Person.__module__ == __

# Generated at 2022-06-18 12:28:39.502022
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    assert TestSchema.fields == {'field1': Field(), 'field2': Field()}


# Generated at 2022-06-18 12:29:55.706246
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.field, definitions)
    assert TestSchema.field.definitions == definitions

# Generated at 2022-06-18 12:30:05.909982
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42
    assert person == Person(name="John", age=42)
    assert person != Person(name="John", age=43)
    assert person != Person(name="Jane", age=42)
    assert person != Person(name="Jane", age=43)
    assert person != Person(name="John", age=42, height=1.8)
    assert person != Person(name="John", age=42, height=1.8, weight=80)
    assert person != Person(name="John", age=42, height=1.8, weight=80, hair_color="black")

# Generated at 2022-06-18 12:30:14.353015
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    set_definitions(Foo.fields["baz"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions
    assert Bar.fields["bar"].definitions is None
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:30:26.585498
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name='John', age=20)
    assert p.name == 'John'
    assert p.age == 20
    assert p.is_sparse == False
    assert p == Person(name='John', age=20)
    assert p != Person(name='John', age=21)
    assert p != Person(name='John', age=20, address='Somewhere')
    assert p != Person(name='John', age=20, address='Somewhere', is_sparse=True)
    assert p != Person(name='John', age=20, is_sparse=True)
    assert p != Person(name='John', age=20, is_sparse=False)

# Generated at 2022-06-18 12:30:34.401249
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")

    class B(Schema):
        a = Reference("C")

    class C(Schema):
        a = Reference("A")

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert A.fields["a"].definitions == definitions
    assert A.fields["b"].definitions == definitions
    assert B.fields["a"].definitions == definitions
    assert C.fields["a"].definitions == definitions

# Generated at 2022-06-18 12:30:42.240765
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert Person.fields == {"name": Field(type="string"), "age": Field(type="integer")}

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert Person.fields == {"name": Field(type="string"), "age": Field(type="integer")}

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert Person.fields == {"name": Field(type="string"), "age": Field(type="integer")}

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")


# Generated at 2022-06-18 12:30:53.009937
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        height = Field(type="number")
        weight = Field(type="number")
        is_active = Field(type="boolean")
        created_at = Field(type="datetime")
        updated_at = Field(type="datetime")
        tags = Array(items=Field(type="string"))

    # Test with dict

# Generated at 2022-06-18 12:30:59.871597
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert list(schema) == ['field1', 'field2', 'field3']

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']

    schema = TestSchema(field1=1)
    assert list(schema) == ['field1']

    schema = TestSchema()
    assert list(schema) == []


# Generated at 2022-06-18 12:31:11.131167
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Foo(Schema):
        bar = Field()

    assert Foo.fields == {"bar": Field()}
    assert Foo.make_validator() == Object(properties={"bar": Field()}, required=["bar"])
    assert Foo.validate({"bar": "baz"}) == Foo({"bar": "baz"})
    assert Foo.validate_or_error({"bar": "baz"}) == ValidationResult(value=Foo({"bar": "baz"}), error=None)
    assert Foo.validate_or_error({"bar": "baz"}, strict=True) == ValidationResult(value=Foo({"bar": "baz"}), error=None)
    assert Foo.validate_or_error({"bar": "baz", "baz": "qux"}) == ValidationResult

# Generated at 2022-06-18 12:31:18.275001
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()
    class Company(Schema):
        name = String()
        employees = Array(Reference(Person))
    company = Company.validate({"name": "Acme", "employees": [{"name": "John", "age": 42}]})
    assert company.name == "Acme"
    assert company.employees[0].name == "John"
    assert company.employees[0].age == 42


# Generated at 2022-06-18 12:31:55.011146
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field = Field()
    assert len(TestSchema()) == 0
    assert len(TestSchema(field=1)) == 1


# Generated at 2022-06-18 12:32:06.100080
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field1 = Reference("TestSchema")
        field2 = Reference("TestSchema")
        field3 = Reference("TestSchema")
        field4 = Reference("TestSchema")
        field5 = Reference("TestSchema")
        field6 = Reference("TestSchema")
        field7 = Reference("TestSchema")
        field8 = Reference("TestSchema")
        field9 = Reference("TestSchema")
        field10 = Reference("TestSchema")
        field11 = Reference("TestSchema")
        field12 = Reference("TestSchema")
        field13 = Reference("TestSchema")
        field14 = Reference("TestSchema")
        field15 = Reference("TestSchema")
        field16 = Reference("TestSchema")
        field17 = Reference("TestSchema")
        field

# Generated at 2022-06-18 12:32:10.715640
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:32:14.005854
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42


# Generated at 2022-06-18 12:32:17.370692
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()

    p1 = Person(name="John", age=20)
    p2 = Person(name="John", age=20)
    assert p1 == p2
    p3 = Person(name="John", age=30)
    assert p1 != p3


# Generated at 2022-06-18 12:32:20.927674
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class User(Schema):
        name = String()
        age = Integer()
    user1 = User(name='John', age=30)
    user2 = User(name='John', age=30)
    assert user1 == user2
    user3 = User(name='John', age=31)
    assert user1 != user3


# Generated at 2022-06-18 12:32:24.176506
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String
    class Person(Schema):
        name = String()
        age = String()
    p = Person(name="John", age="30")
    assert list(p) == ["name", "age"]


# Generated at 2022-06-18 12:32:33.392424
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42
    assert person == Person(name="John", age=42)
    assert person != Person(name="John", age=43)
    assert person != Person(name="John", age=42, height=1.83)
    assert person != Person(name="John", age=42, height=1.83)
    assert person != Person(name="John", age=42, height=1.83)
    assert person != Person(name="John", age=42, height=1.83)
    assert person != Person(name="John", age=42, height=1.83)

# Generated at 2022-06-18 12:32:37.402738
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert len(person) == 2
    assert len(person) == 2
    assert len(person) == 2


# Generated at 2022-06-18 12:32:43.055498
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field()
        b = Field()
    foo1 = Foo(a=1, b=2)
    foo2 = Foo(a=1, b=2)
    foo3 = Foo(a=1, b=3)
    foo4 = Foo(a=1, b=2, c=3)
    assert foo1 == foo2
    assert foo1 != foo3
    assert foo1 != foo4
