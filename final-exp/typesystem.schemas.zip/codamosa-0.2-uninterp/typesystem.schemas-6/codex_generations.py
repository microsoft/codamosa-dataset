

# Generated at 2022-06-18 12:24:39.118197
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert repr(schema) == "TestSchema(a=1, b=2, c=3)"

    schema = TestSchema(a=1, b=2)
    assert repr(schema) == "TestSchema(a=1, b=2) [sparse]"

    schema = TestSchema(a=1)
    assert repr(schema) == "TestSchema(a=1) [sparse]"

    schema = TestSchema()
    assert repr(schema) == "TestSchema() [sparse]"



# Generated at 2022-06-18 12:24:50.947109
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema2(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema3(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema4(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema5(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema6(Schema):
        name = Field(type="string")
        age = Field(type="integer")


# Generated at 2022-06-18 12:24:54.822609
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    assert TestSchema.fields == {'field1': Field(), 'field2': Field()}


# Generated at 2022-06-18 12:25:03.974299
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.schema import Schema
    class Person(Schema):
        name = String()
    class PersonReference(Schema):
        person = Reference(Person)
    person = Person(name="John")
    person_reference = PersonReference(person=person)
    assert person_reference.person == person
    assert person_reference.person.name == "John"
    assert person_reference.person.name == person.name
    assert person_reference.person.name == person_reference["person"]["name"]
    assert person_reference.person.name == person_reference.person["name"]
    assert person_reference.person.name == person["name"]
    assert person_reference["person"]["name"] == person["name"]

# Generated at 2022-06-18 12:25:14.675675
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="number")
        is_active = Field(type="boolean")

    schema = TestSchema(name="John", age=20, is_active=True)
    assert schema.name == "John"
    assert schema.age == 20
    assert schema.is_active is True
    assert schema.is_sparse is False
    assert schema == TestSchema(name="John", age=20, is_active=True)
    assert schema != TestSchema(name="John", age=20, is_active=False)
    assert schema != TestSchema(name="John", age=21, is_active=True)
    assert schema != TestSchema(name="John", age=20)

# Generated at 2022-06-18 12:25:18.848771
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2


# Generated at 2022-06-18 12:25:25.131502
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    test_schema = TestSchema(a=1, b=2)
    assert repr(test_schema) == "TestSchema(a=1, b=2) [sparse]"


# Generated at 2022-06-18 12:25:33.657100
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert list(schema) == ['field1', 'field2', 'field3']

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']

    schema = TestSchema(field1=1)
    assert list(schema) == ['field1']

    schema = TestSchema()
    assert list(schema) == []



# Generated at 2022-06-18 12:25:45.141984
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    set_definitions(Bar, definitions)
    set_definitions(Baz, definitions)

    assert Foo.fields["foo"].definitions is definitions
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:25:49.282617
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:26:07.456202
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.bar.definitions is definitions
    assert Foo.baz.definitions is definitions
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:26:18.517564
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        a = Field(type="string")
        b = Field(type="string")

    foo = Foo(a="a", b="b")
    assert foo.a == "a"
    assert foo.b == "b"

    foo = Foo({"a": "a", "b": "b"})
    assert foo.a == "a"
    assert foo.b == "b"

    foo = Foo(Foo(a="a", b="b"))
    assert foo.a == "a"
    assert foo.b == "b"

    foo = Foo(a="a")
    assert foo.a == "a"
    assert foo.b is None

    foo = Foo({"a": "a"})
    assert foo.a == "a"
    assert foo.b is None

    foo

# Generated at 2022-06-18 12:26:29.662594
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        height = Field(type="number")
        alive = Field(type="boolean")
        created = Field(type="string")
        updated = Field(type="string")
        tags = Field(type="array", items=Field(type="string"))
        friends = Field(type="array", items=Reference("Person"))
        parent = Field(type="object", properties={"name": Field(type="string")})
        spouse = Field(type="object", properties={"name": Field(type="string")})
        children = Field(type="array", items=Reference("Person"))
        siblings = Field(type="array", items=Reference("Person"))

# Generated at 2022-06-18 12:26:33.490603
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name="John", age=30)
    assert p.name == "John"
    assert p.age == 30


# Generated at 2022-06-18 12:26:38.851628
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz
    assert definitions["Foo"] is Foo

# Generated at 2022-06-18 12:26:50.975723
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
        field5 = Field()
        field6 = Field()
        field7 = Field()
        field8 = Field()
        field9 = Field()
        field10 = Field()
        field11 = Field()
        field12 = Field()
        field13 = Field()
        field14 = Field()
        field15 = Field()
        field16 = Field()
        field17 = Field()
        field18 = Field()
        field19 = Field()
        field20 = Field()
        field21 = Field()
        field22 = Field()
        field23 = Field()
        field24 = Field()
        field25 = Field()
        field26 = Field()
        field27 = Field()


# Generated at 2022-06-18 12:26:54.552515
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:26:59.453589
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ['field1', 'field3']


# Generated at 2022-06-18 12:27:07.333393
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    assert repr(TestSchema(a=1, b=2)) == "TestSchema(a=1, b=2)"
    assert repr(TestSchema(a=1, b=2, c=3)) == "TestSchema(a=1, b=2, c=3)"
    assert repr(TestSchema(a=1, b=2, c=3)) == "TestSchema(a=1, b=2, c=3)"
    assert repr(TestSchema(a=1, b=2, c=3)) == "TestSchema(a=1, b=2, c=3)"

# Generated at 2022-06-18 12:27:09.751416
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30


# Generated at 2022-06-18 12:27:22.559708
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field2=2, field3=3)"


# Generated at 2022-06-18 12:27:28.380866
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    assert repr(Person(name="John", age=42)) == "Person(name='John', age=42)"
    assert repr(Person(name="John")) == "Person(name='John') [sparse]"


# Generated at 2022-06-18 12:27:40.424542
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    # Test that all fields are set to None
    schema = TestSchema()
    assert schema.field1 is None
    assert schema.field2 is None
    assert schema.field3 is None

    # Test that all fields are set to None
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert schema.field1 == 1
    assert schema.field2 == 2
    assert schema.field3 == 3

    # Test that all fields are set to None
    schema = TestSchema(field1=1, field2=2)
    assert schema.field1 == 1
    assert schema.field2 == 2
    assert schema.field3 is None

    # Test that all

# Generated at 2022-06-18 12:27:44.255307
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']



# Generated at 2022-06-18 12:27:49.367896
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    person = Person(name="John Doe", age=42)
    assert person["name"] == "John Doe"
    assert person["age"] == 42


# Generated at 2022-06-18 12:27:59.407471
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
        d = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c == 3
    assert schema.d == None
    assert schema.is_sparse == True
    assert schema == TestSchema(a=1, b=2, c=3)
    assert schema != TestSchema(a=1, b=2, c=3, d=4)
    assert schema != TestSchema(a=1, b=2, c=4)
    assert schema != TestSchema(a=1, b=2)
    assert schema != TestSchema(a=1)
    assert schema != Test

# Generated at 2022-06-18 12:28:02.277624
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import String
    class Person(Schema):
        name = String()
        age = String()
    p = Person(name='John', age='30')
    assert list(p) == ['name', 'age']


# Generated at 2022-06-18 12:28:05.982779
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    set_definitions(Foo.fields["baz"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:28:09.859658
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert len(schema) == 3


# Generated at 2022-06-18 12:28:16.216983
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    test_schema = TestSchema(field1=1, field2=2)
    assert test_schema['field1'] == 1
    assert test_schema['field2'] == 2
    try:
        test_schema['field3']
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-18 12:28:50.715886
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"


# Generated at 2022-06-18 12:28:53.047089
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    TestSchema.validate({"field": {"field": None}})


# Generated at 2022-06-18 12:29:02.739020
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        pass

    assert TestSchema.fields == {}

    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}

    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}

    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}

    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}

    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}

    class TestSchema(Schema):
        field = Field()

    assert TestSchema

# Generated at 2022-06-18 12:29:06.922101
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"



# Generated at 2022-06-18 12:29:13.947568
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")
        qux = Reference("Qux")

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    class Qux(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions == definitions
    assert Foo.fields["baz"].definitions == definitions
    assert Foo.fields["qux"].definitions == definitions

# Generated at 2022-06-18 12:29:19.785613
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)

    s1 = TestSchema(name="John", age=20)
    s2 = TestSchema(name="John", age=20)
    assert s1 == s2
    s3 = TestSchema(name="John", age=30)
    assert s1 != s3


# Generated at 2022-06-18 12:29:29.815113
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()
        gender = String()

    class PersonReference(Reference):
        to = Person

    class PersonReference2(Reference):
        to = 'Person'

    class PersonReference3(Reference):
        to = 'Person'
        definitions = {'Person': Person}

    class PersonReference4(Reference):
        to = 'Person'
        definitions = SchemaDefinitions({'Person': Person})

    class PersonReference5(Reference):
        to = 'Person'
        definitions = SchemaDefinitions({'Person': Person})

    class PersonReference6(Reference):
        to = 'Person'
        definitions = SchemaDefinitions({'Person': Person})

    class PersonReference7(Reference):
        to = 'Person'

# Generated at 2022-06-18 12:29:36.959097
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert TestSchema.fields == {'a': Field(), 'b': Field(), 'c': Field()}
    assert TestSchema.__name__ == 'TestSchema'
    assert TestSchema.__bases__ == (Schema,)
    assert TestSchema.__dict__ == {'__module__': '__main__', '__doc__': None, 'fields': {'a': Field(), 'b': Field(), 'c': Field()}}


# Generated at 2022-06-18 12:29:45.672897
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field()
        b = Field()
    a = A(a=1, b=2)
    b = A(a=1, b=2)
    assert a == b
    assert not (a != b)
    assert a == a
    assert not (a != a)
    assert a == dict(a=1, b=2)
    assert not (a != dict(a=1, b=2))
    assert a == A(a=1, b=2)
    assert not (a != A(a=1, b=2))
    assert a == A(a=1)
    assert not (a != A(a=1))
    assert a != A(a=1, b=3)
    assert not (a == A(a=1, b=3))
   

# Generated at 2022-06-18 12:29:48.934767
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:30:12.449830
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert definitions["Bar"] is Bar
    set_definitions(Bar.fields["bar"], definitions)
    assert definitions["Baz"] is Baz
    set_definitions(Baz.fields["baz"], definitions)
    assert definitions["Foo"] is Foo

# Generated at 2022-06-18 12:30:23.380310
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name = Field(str)
        age = Field(int)
        is_active = Field(bool, default=True)
        address = Field(str, default=None)
        friends = Field(Array(str))
        family = Field(Array(str))

    # Test __init__() with no arguments
    schema = TestSchema()
    assert schema.name is None
    assert schema.age is None
    assert schema.is_active is True
    assert schema.address is None
    assert schema.friends == []
    assert schema.family == []

    # Test __init__() with a single dict argument
    schema = TestSchema({"name": "John", "age": 30, "friends": ["Alice", "Bob"]})
    assert schema.name == "John"

# Generated at 2022-06-18 12:30:30.453545
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:30:37.007604
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2)
    assert repr(schema) == "TestSchema(a=1, b=2) [sparse]"
    schema = TestSchema(a=1, b=2, c=3)
    assert repr(schema) == "TestSchema(a=1, b=2, c=3)"


# Generated at 2022-06-18 12:30:39.135132
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}



# Generated at 2022-06-18 12:30:49.240131
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
        d = Field(type="string")
        e = Field(type="string")
        f = Field(type="string")
        g = Field(type="string")
        h = Field(type="string")
        i = Field(type="string")
        j = Field(type="string")
        k = Field(type="string")
        l = Field(type="string")
        m = Field(type="string")
        n = Field(type="string")
        o = Field(type="string")
        p = Field(type="string")
        q = Field(type="string")
        r = Field(type="string")
        s = Field(type="string")

# Generated at 2022-06-18 12:30:58.861528
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema2(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema3(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema4(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema5(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class TestSchema6(Schema):
        name = Field(type="string")
        age = Field(type="integer")


# Generated at 2022-06-18 12:31:10.207285
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person
        definitions = SchemaDefinitions()

    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.validate(person) == person
    assert person_reference.validate(person_reference) == person
    assert person_reference.validate({"name": "John", "age": 30}) == person
    assert person_reference.validate({"name": "John"}) == person
    assert person_reference.validate({"name": "John", "age": 30, "extra": "data"}) == person
    assert person_reference.validate({"name": "John", "age": "30"}) == person
    assert person_reference

# Generated at 2022-06-18 12:31:17.320414
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2, field3=4)
    assert schema1 == schema2
    assert schema1 != schema3


# Generated at 2022-06-18 12:31:20.539772
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = MySchema(a=1, b=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:31:43.900541
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions
    assert TestSchema.fields["field"].target == TestSchema

# Generated at 2022-06-18 12:31:54.603743
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()

    person1 = Person(name="John", age=30)
    person2 = Person(name="John", age=30)
    person3 = Person(name="John", age=31)
    person4 = Person(name="John")
    person5 = Person(age=30)
    person6 = Person()

    assert person1 == person2
    assert person1 != person3
    assert person1 != person4
    assert person1 != person5
    assert person1 != person6
    assert person4 != person5
    assert person4 != person6
    assert person5 != person6
    assert person1 != {"name": "John", "age": 30}
    assert person1 != {"name": "John"}
    assert person1 != {"age": 30}
   

# Generated at 2022-06-18 12:32:05.755362
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c == 3
    assert schema.is_sparse == False

    schema = TestSchema(dict(a=1, b=2, c=3))
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c == 3
    assert schema.is_sparse == False

    schema = TestSchema(TestSchema(a=1, b=2, c=3))
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c == 3
    assert schema.is_sparse == False



# Generated at 2022-06-18 12:32:14.956811
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
        height = Field(float)
        weight = Field(float)

    p = Person(name="John", age=30, height=1.8, weight=80.5)
    assert p.name == "John"
    assert p.age == 30
    assert p.height == 1.8
    assert p.weight == 80.5

    p = Person(dict(name="John", age=30, height=1.8, weight=80.5))
    assert p.name == "John"
    assert p.age == 30
    assert p.height == 1.8
    assert p.weight == 80.5

    p = Person(Person(name="John", age=30, height=1.8, weight=80.5))
   

# Generated at 2022-06-18 12:32:17.752904
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:32:20.724342
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:32:29.603169
# Unit test for constructor of class Reference
def test_Reference():
    class Foo(Schema):
        bar = Field(str)
    class Baz(Schema):
        foo = Reference(Foo)
    baz = Baz(foo=Foo(bar='baz'))
    assert baz.foo.bar == 'baz'
    assert baz.foo == Foo(bar='baz')
    assert baz == Baz(foo=Foo(bar='baz'))
    assert baz != Baz(foo=Foo(bar='qux'))
    assert baz != Baz(foo=None)
    assert baz != Baz(foo=Foo(bar='baz'), qux='quux')
    assert baz != Baz(foo=Foo(bar='baz'), qux='quux')

# Generated at 2022-06-18 12:32:31.847572
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        pass

    assert repr(TestSchema()) == "TestSchema()"


# Generated at 2022-06-18 12:32:36.427262
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    person = Person(name="John Smith", age=20)
    assert person["name"] == "John Smith"
    assert person["age"] == 20


# Generated at 2022-06-18 12:32:40.190969
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert len(person) == 2
    assert len(Person(name="John")) == 1
    assert len(Person()) == 0


# Generated at 2022-06-18 12:33:19.100511
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    test_schema = TestSchema(field1=1, field2=2)
    assert test_schema["field1"] == 1
    assert test_schema["field2"] == 2
    try:
        test_schema["field3"]
    except KeyError:
        pass
    else:
        assert False, "Expected KeyError"


# Generated at 2022-06-18 12:33:25.454351
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions == definitions
    assert Foo.fields["bar"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions
    assert Baz.fields["baz"].definitions == definitions

# Generated at 2022-06-18 12:33:33.825722
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        foo = Reference("Bar")
        bar = Array(Reference("Baz"))
        baz = Object(properties={"baz": Reference("Baz")})

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.foo, definitions)
    assert TestSchema.foo.definitions is definitions
    set_definitions(TestSchema.bar, definitions)
    assert TestSchema.bar.items.definitions is definitions
    set_definitions(TestSchema.baz, definitions)
    assert TestSchema.baz.properties["baz"].definitions is definitions

# Generated at 2022-06-18 12:33:41.897477
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        is_active = Boolean()
        is_male = Boolean()
        is_female = Boolean()
        is_human = Boolean()
        is_alien = Boolean()
        is_robot = Boolean()
        is_zombie = Boolean()
        is_vampire = Boolean()
        is_werewolf = Boolean()
        is_sorcerer = Boolean()
        is_wizard = Boolean()
        is_witch = Boolean()
        is_warlock = Boolean()
        is_saint = Boolean()
        is_demon = Boolean()
        is_angel = Boolean()
        is_ghost = Boolean()
        is_undead = Boolean()
        is_supernatural = Boolean()
        is_human

# Generated at 2022-06-18 12:33:45.815465
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ["field1", "field2"]


# Generated at 2022-06-18 12:33:50.331740
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.make_validator(), definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz