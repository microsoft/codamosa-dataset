

# Generated at 2022-06-18 12:24:27.795885
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        height = Field(type="number")
        weight = Field(type="number")

    # Test constructor with no arguments
    schema = TestSchema()
    assert schema.name is None
    assert schema.age is None
    assert schema.height is None
    assert schema.weight is None

    # Test constructor with a single argument
    schema = TestSchema({"name": "John", "age": 20, "height": 1.8, "weight": 80})
    assert schema.name == "John"
    assert schema.age == 20
    assert schema.height == 1.8
    assert schema.weight == 80

    # Test constructor with keyword arguments

# Generated at 2022-06-18 12:24:31.836568
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    s = TestSchema(a=1, b=2)
    assert list(s) == ['a', 'b']


# Generated at 2022-06-18 12:24:43.534516
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert len(person) == 2
    assert list(person) == ["name", "age"]
    assert person["name"] == "John"
    assert person["age"] == 42
    assert person.name == "John"
    assert person.age == 42
    assert person == Person(name="John", age=42)
    assert person != Person(name="John", age=43)
    assert person != Person(name="John", age=42, height=1.83)
    assert repr(person) == "Person(name='John', age=42)"
    assert repr(Person(name="John")) == "Person(name='John') [sparse]"

# Generated at 2022-06-18 12:24:47.632456
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.field, definitions)
    assert TestSchema.field.definitions == definitions

# Generated at 2022-06-18 12:24:58.123200
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42
    assert person == Person(name="John", age=42)
    assert person != Person(name="John", age=43)
    assert person != Person(name="John", age=42, height=1.8)
    assert person != Person(name="John", age=42, height=1.8)
    assert person != Person(name="John", age=42, height=1.8)
    assert person != Person(name="John", age=42, height=1.8)
    assert person != Person(name="John", age=42, height=1.8)

# Generated at 2022-06-18 12:25:01.513259
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:25:12.732168
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
        d = Field(type="string")
        e = Field(type="string")
        f = Field(type="string")
        g = Field(type="string")
        h = Field(type="string")
        i = Field(type="string")
        j = Field(type="string")
        k = Field(type="string")
        l = Field(type="string")
        m = Field(type="string")
        n = Field(type="string")
        o = Field(type="string")
        p = Field(type="string")
        q = Field(type="string")
        r = Field(type="string")
        s = Field(type="string")

# Generated at 2022-06-18 12:25:23.532669
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30
    assert person == Person(name="John", age=30)
    assert person != Person(name="John", age=31)
    assert person != Person(name="Jane", age=30)
    assert person != Person(name="Jane", age=31)
    assert person != Person(name="John")
    assert person != Person(age=30)
    assert person != Person()
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="John", age=30, height=180, weight=80)

# Generated at 2022-06-18 12:25:35.413976
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")

    test_schema = TestSchema({"a": "a", "b": "b"})
    assert test_schema.a == "a"
    assert test_schema.b == "b"
    assert test_schema.is_sparse == False
    assert test_schema == TestSchema({"a": "a", "b": "b"})
    assert test_schema != TestSchema({"a": "a", "b": "b", "c": "c"})
    assert test_schema != TestSchema({"a": "a", "b": "b", "c": "c"})

# Generated at 2022-06-18 12:25:46.437801
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1)
    assert schema1 != schema3
    schema4 = TestSchema(field1=1, field2=3)
    assert schema1 != schema4
    schema5 = TestSchema(field1=1, field2=2, field3=3)
    assert schema1 != schema5


# Generated at 2022-06-18 12:25:58.170276
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions

# Generated at 2022-06-18 12:26:02.587503
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    assert Person.fields == {"name": Field(str), "age": Field(int)}



# Generated at 2022-06-18 12:26:06.643838
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name='John', age=30)
    assert person['name'] == 'John'
    assert person['age'] == 30


# Generated at 2022-06-18 12:26:13.820943
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2, field3=4)
    assert schema1 == schema2
    assert schema1 != schema3


# Generated at 2022-06-18 12:26:21.762943
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field2=2, field3=3)"



# Generated at 2022-06-18 12:26:25.565641
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"


# Generated at 2022-06-18 12:26:30.357392
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()
    p1 = Person(name='John', age=30)
    p2 = Person(name='John', age=30)
    p3 = Person(name='John', age=31)
    assert p1 == p2
    assert p1 != p3
    assert p1 != None


# Generated at 2022-06-18 12:26:34.637652
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
    schema = TestSchema(a=1, b=2)
    assert schema['a'] == 1
    assert schema['b'] == 2
    try:
        schema['c']
        assert False
    except KeyError:
        pass


# Generated at 2022-06-18 12:26:41.625834
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:26:45.000540
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        address = String()

    person = Person(name="John", age=30)
    assert list(person) == ["name", "age"]



# Generated at 2022-06-18 12:27:15.921628
# Unit test for function set_definitions
def test_set_definitions():
    class MySchema(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(MySchema.fields["foo"], definitions)
    assert MySchema.fields["foo"].definitions is definitions

# Generated at 2022-06-18 12:27:18.677911
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    assert TestSchema.fields == {'field1': Field(), 'field2': Field()}


# Generated at 2022-06-18 12:27:26.129364
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42
    assert person == Person(name="John", age=42)
    assert person != Person(name="John", age=43)
    assert person != Person(name="Jane", age=42)
    assert person != Person(name="Jane", age=43)
    assert person != Person(name="John")
    assert person != Person(age=42)
    assert person != Person()
    assert person != Person(name="John", age=42, height=1.8)
    assert person != Person(name="John", age=42, height=1.8, weight=80)

# Generated at 2022-06-18 12:27:30.590774
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions

# Generated at 2022-06-18 12:27:41.992323
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        name = String()
        age = Integer()

    assert TestSchema.fields == {'name': String(), 'age': Integer()}
    assert TestSchema.__name__ == 'TestSchema'
    assert TestSchema.__bases__ == (Schema,)
    assert TestSchema.__dict__ == {'__module__': '__main__', '__doc__': None}
    assert TestSchema.__mro__ == (TestSchema, Schema, Mapping, object)

    test_schema = TestSchema({'name': 'John', 'age': 30})
    assert test_schema.name == 'John'
    assert test_schema.age == 30
    assert test_schema.fields == {'name': String(), 'age': Integer()}

# Generated at 2022-06-18 12:27:48.975144
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 != schema3


# Generated at 2022-06-18 12:27:59.174334
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
    s = TestSchema({"a": "a", "b": "b"})
    assert s.a == "a"
    assert s.b == "b"
    assert s == TestSchema({"a": "a", "b": "b"})
    assert s != TestSchema({"a": "a", "b": "c"})
    assert s != TestSchema({"a": "a"})
    assert s != TestSchema({"b": "b"})
    assert s != TestSchema()
    assert s != TestSchema({"a": "a", "b": "b", "c": "c"})

# Generated at 2022-06-18 12:28:08.375827
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    set_definitions(Bar, definitions)
    set_definitions(Baz, definitions)

    assert isinstance(Foo.fields["bar"].target, type)
    assert isinstance(Foo.fields["baz"].target, type)
    assert isinstance(Bar.fields["foo"].target, type)
    assert isinstance(Baz.fields["foo"].target, type)

# Generated at 2022-06-18 12:28:14.300488
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 == schema2
    assert schema1 != schema3


# Generated at 2022-06-18 12:28:16.444670
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ['field1', 'field3']


# Generated at 2022-06-18 12:29:42.354660
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    set_definitions(Foo.fields["baz"], definitions)

    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:29:46.330321
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ['field1', 'field3']


# Generated at 2022-06-18 12:29:50.557662
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = String()
        field2 = String()
        field3 = String()

    schema = TestSchema(field1="value1", field2="value2")
    assert list(schema) == ["field1", "field2"]


# Generated at 2022-06-18 12:29:54.780600
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:29:58.468868
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()

    p = Person(name="John", age=30)
    assert repr(p) == "Person(name='John', age=30)"



# Generated at 2022-06-18 12:30:07.863804
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        is_active = Boolean(default=True)

    schema = MySchema(name="John", age=42)
    assert repr(schema) == "MySchema(name='John', age=42)"

    schema = MySchema(name="John", age=42, is_active=False)
    assert repr(schema) == "MySchema(name='John', age=42, is_active=False)"

    schema = MySchema(name="John", age=42, is_active=False)
    assert repr(schema) == "MySchema(name='John', age=42, is_active=False)"


# Generated at 2022-06-18 12:30:12.359525
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"

    person = Person(name="John")
    assert repr(person) == "Person(name='John') [sparse]"



# Generated at 2022-06-18 12:30:15.742476
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions

# Generated at 2022-06-18 12:30:24.958320
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']

    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']

    schema = TestSchema(a=1)
    assert list(schema) == ['a']

    schema = TestSchema()
    assert list(schema) == []


# Generated at 2022-06-18 12:30:33.730712
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions
    assert Bar.fields["foo"].definitions is definitions
    assert Baz.fields["foo"].definitions is definitions

# Generated at 2022-06-18 12:31:35.042701
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        is_male = Boolean()
        is_female = Boolean()
        is_human = Boolean()
        is_animal = Boolean()
        is_plant = Boolean()
        is_mineral = Boolean()
        is_alive = Boolean()
        is_dead = Boolean()
        is_good = Boolean()
        is_evil = Boolean()
        is_smart = Boolean()
        is_dumb = Boolean()
        is_happy = Boolean()
        is_sad = Boolean()
        is_funny = Boolean()
        is_boring = Boolean()
        is_rich = Boolean()
        is_poor = Boolean()
        is_tall = Boolean()
        is_short = Boolean()

# Generated at 2022-06-18 12:31:39.163982
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        is_active = Boolean()

    assert TestSchema.fields == {
        "name": String(),
        "age": Integer(),
        "is_active": Boolean(),
    }


# Generated at 2022-06-18 12:31:47.666936
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    set_definitions(Bar, definitions)
    set_definitions(Baz, definitions)

    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions
    assert Bar.fields["foo"].definitions is definitions
    assert Baz.fields["foo"].definitions is definitions

# Generated at 2022-06-18 12:31:52.411377
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2


# Generated at 2022-06-18 12:31:56.074637
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class SchemaMetaclass_test_SchemaMetaclass___new__(metaclass=SchemaMetaclass):
        pass
    assert isinstance(SchemaMetaclass_test_SchemaMetaclass___new__, type)


# Generated at 2022-06-18 12:32:02.159413
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field = Field()

    assert repr(TestSchema()) == "TestSchema()"
    assert repr(TestSchema(field=1)) == "TestSchema(field=1)"
    assert repr(TestSchema(field=1, field2=2)) == "TestSchema(field=1, field2=2) [sparse]"


# Generated at 2022-06-18 12:32:07.344434
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import String

    class Person(Schema):
        name = String()
        age = String()

    person = Person(name="John", age="30")
    assert len(person) == 2
    assert len(Person(name="John")) == 1
    assert len(Person(age="30")) == 1
    assert len(Person()) == 0


# Generated at 2022-06-18 12:32:11.211743
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=100)
    schema = TestSchema(name="John", age=25)
    assert repr(schema) == "TestSchema(name='John', age=25)"


# Generated at 2022-06-18 12:32:18.588373
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions(
        {"Foo": Foo, "Bar": Bar, "Baz": Baz}
    )
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    set_definitions(Baz.fields["baz"], definitions)

    assert Foo.fields["foo"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions
    assert Baz.fields["baz"].definitions == definitions

# Generated at 2022-06-18 12:32:21.067668
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    s = TestSchema(a=1, b=2)
    assert list(s) == ['a', 'b']


# Generated at 2022-06-18 12:33:19.146261
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:33:26.128079
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=100)

    schema1 = TestSchema(name="John", age=20)
    schema2 = TestSchema(name="John", age=20)
    schema3 = TestSchema(name="John", age=21)
    schema4 = TestSchema(name="John")
    schema5 = TestSchema(age=20)

    assert schema1 == schema2
    assert schema1 != schema3
    assert schema1 != schema4
    assert schema1 != schema5
    assert schema4 != schema5



# Generated at 2022-06-18 12:33:30.812694
# Unit test for function set_definitions
def test_set_definitions():
    class DefinitionSchema(Schema):
        field = Reference("OtherSchema")

    class OtherSchema(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(DefinitionSchema.fields["field"], definitions)
    assert definitions["OtherSchema"] is OtherSchema

# Generated at 2022-06-18 12:33:35.051904
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    p = Person(name="John")
    assert repr(p) == "Person(name='John')"

    p = Person()
    assert repr(p) == "Person() [sparse]"



# Generated at 2022-06-18 12:33:39.715207
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions