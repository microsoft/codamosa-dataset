

# Generated at 2022-06-18 12:24:44.668621
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:24:46.813375
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        pass
    assert TestSchema.fields == {}


# Generated at 2022-06-18 12:24:57.400154
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()
    class Company(Schema):
        name = String()
        ceo = Reference(Person)
    company = Company(name="Acme", ceo=Person(name="John", age=42))
    assert company.ceo.name == "John"
    assert company.ceo.age == 42
    assert company.ceo == Person(name="John", age=42)
    assert company.ceo != Person(name="John", age=43)
    assert company.ceo != Person(name="John", age=42, height=1.83)
    assert company.ceo != Person(name="John", age=42, height=1.83)
    assert company.ceo != Person(name="John", age=42, height=1.83)


# Generated at 2022-06-18 12:25:05.264805
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    test_schema = TestSchema(a=1, b=2, c=3)
    assert list(test_schema.__iter__()) == ['a', 'b', 'c']
    test_schema = TestSchema(a=1, b=2)
    assert list(test_schema.__iter__()) == ['a', 'b']
    test_schema = TestSchema(a=1)
    assert list(test_schema.__iter__()) == ['a']
    test_schema = TestSchema()
    assert list(test_schema.__iter__()) == []


# Generated at 2022-06-18 12:25:09.622531
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']


# Generated at 2022-06-18 12:25:17.844701
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Foo(Schema):
        bar = Field()
        baz = Field()

    assert Foo.fields == {"bar": Field(), "baz": Field()}
    assert Foo().fields == {"bar": Field(), "baz": Field()}
    assert Foo().bar is None
    assert Foo().baz is None
    assert Foo(bar=1).bar == 1
    assert Foo(bar=1).baz is None
    assert Foo(bar=1, baz=2).bar == 1
    assert Foo(bar=1, baz=2).baz == 2
    assert Foo(bar=1, baz=2, qux=3) == Foo(bar=1, baz=2)
    assert Foo(bar=1, baz=2, qux=3) != Foo(bar=1, baz=3)
   

# Generated at 2022-06-18 12:25:24.101709
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()

    class Employee(Schema):
        person = Reference(Person)
        salary = Integer()

    employee = Employee(person=Person(name="John", age=30), salary=1000)
    assert employee.person.name == "John"
    assert employee.person.age == 30
    assert employee.salary == 1000


# Generated at 2022-06-18 12:25:35.413791
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Foo(Schema):
        a = Field()
        b = Field()
        c = Field()

    foo = Foo(a=1, b=2)
    assert repr(foo) == "Foo(a=1, b=2) [sparse]"

    foo = Foo(a=1, b=2, c=3)
    assert repr(foo) == "Foo(a=1, b=2, c=3)"

    foo = Foo(a=1, b=2, c=3, d=4)
    assert repr(foo) == "Foo(a=1, b=2, c=3) [sparse]"

    foo = Foo(a=1, b=2, c=3, d=4, e=5)

# Generated at 2022-06-18 12:25:46.070961
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']
    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']
    schema = TestSchema(a=1)
    assert list(schema) == ['a']
    schema = TestSchema()
    assert list(schema) == []


# Generated at 2022-06-18 12:25:52.456720
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:26:13.731497
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']

# Generated at 2022-06-18 12:26:17.719260
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']


# Generated at 2022-06-18 12:26:23.109612
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = String()
        field2 = String()
        field3 = String()
    schema = TestSchema(field1="value1", field2="value2")
    assert repr(schema) == "TestSchema(field1='value1', field2='value2') [sparse]"


# Generated at 2022-06-18 12:26:31.932124
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    person = Person(name="John", age=42, height=1.83)
    assert person["name"] == "John"
    assert person["age"] == 42
    assert person["height"] == 1.83
    assert person.is_sparse is False

    person = Person(name="John", height=1.83)
    assert person["name"] == "John"
    assert person["age"] is None
    assert person["height"] == 1.83
    assert person.is_sparse is True

    with pytest.raises(KeyError):
        person["invalid"]



# Generated at 2022-06-18 12:26:34.253802
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field = Field()
    assert TestSchema.fields == {'field': Field()}


# Generated at 2022-06-18 12:26:39.358497
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz
    assert definitions["Foo"] == Foo

# Generated at 2022-06-18 12:26:45.927933
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    schema = TestSchema(name="John", age=30)
    assert len(schema) == 2

    schema = TestSchema(name="John")
    assert len(schema) == 1

    schema = TestSchema()
    assert len(schema) == 0


# Generated at 2022-06-18 12:26:50.140220
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions

# Generated at 2022-06-18 12:27:00.662565
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class B(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class C(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class D(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    set_definitions(B, definitions)
    set_definitions(C, definitions)
    set_definitions(D, definitions)
    assert definitions["A"] == A
    assert definitions["B"] == B


# Generated at 2022-06-18 12:27:03.840844
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    schema = TestSchema(name="John Doe", age=42)
    assert list(schema) == ["name", "age"]


# Generated at 2022-06-18 12:27:44.458751
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        alive = Boolean()
        friends = Array(String())
        parents = Array(Reference("Person"))
        spouse = Reference("Person")
        siblings = Array(Reference("Person"))
        address = Object(
            properties={
                "street": String(),
                "city": String(),
                "state": String(),
                "zip": String(),
            }
        )
        # TODO: test for nested schema
        # TODO: test for nested schema with Reference
        # TODO: test for nested schema with Array
        # TODO: test for nested schema with Array of Reference
        # TODO: test for nested schema with Array of Array
        # TODO: test for nested schema with Array of Array of Reference
        # TOD

# Generated at 2022-06-18 12:27:49.110503
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name="John", age=20)
    assert p.name == "John"
    assert p.age == 20


# Generated at 2022-06-18 12:27:59.255537
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    person = Person(name="John Smith", age=35)
    assert person.name == "John Smith"
    assert person.age == 35
    assert person == Person(name="John Smith", age=35)
    assert person != Person(name="John Smith", age=36)
    assert person != Person(name="John Smith", age=35, height=180)
    assert person != Person(name="John Doe", age=35)
    assert person != Person(name="John Smith")
    assert person != Person(age=35)
    assert person != Person()
    assert person.is_sparse is False
    assert repr(person) == "Person(name='John Smith', age=35)"

    person

# Generated at 2022-06-18 12:28:09.419088
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:28:17.184215
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field2=2, field3=3)"


# Generated at 2022-06-18 12:28:20.247136
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert len(person) == 2


# Generated at 2022-06-18 12:28:24.056601
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field1 = Reference("TestSchema")
        field2 = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.field1, definitions)
    assert TestSchema.field1.definitions == definitions
    assert TestSchema.field2.definitions == definitions

# Generated at 2022-06-18 12:28:30.482958
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    set_definitions(Baz.fields["baz"], definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:28:33.492196
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class BaseSchema(Schema):
        a = Field()
        b = Field()

    class SubSchema(BaseSchema):
        c = Field()
        d = Field()

    assert SubSchema.fields == {'a': Field(), 'b': Field(), 'c': Field(), 'd': Field()}


# Generated at 2022-06-18 12:28:45.406987
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()

    person = Person(name="John", age=30, height=1.75, weight=70.5)
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.75
    assert person.weight == 70.5

    person = Person({"name": "John", "age": 30, "height": 1.75, "weight": 70.5})
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.75
    assert person.weight == 70.5

    person = Person(Person(name="John", age=30, height=1.75, weight=70.5))

# Generated at 2022-06-18 12:29:44.162194
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field = Field()
    assert TestSchema.fields == {'field': Field()}


# Generated at 2022-06-18 12:29:52.655963
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2)
    schema4 = TestSchema(field1=1, field2=2, field3=4)

    assert schema1 == schema2
    assert schema1 != schema3
    assert schema1 != schema4


# Generated at 2022-06-18 12:29:59.800696
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:30:08.489465
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.schema import Schema
    class Person(Schema):
        name = String()
    class Address(Schema):
        street = String()
        person = Reference(Person)
    address = Address(street="123 Main St", person=Person(name="John Doe"))
    assert address.street == "123 Main St"
    assert address.person.name == "John Doe"
    assert address.person.is_sparse is False
    assert address.is_sparse is False
    assert address == Address(street="123 Main St", person=Person(name="John Doe"))
    assert address != Address(street="123 Main St", person=Person(name="Jane Doe"))
    assert address != Address(street="456 Main St", person=Person(name="John Doe"))

# Generated at 2022-06-18 12:30:12.634697
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["bar"].target is Bar

# Generated at 2022-06-18 12:30:23.734903
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()
    person1 = Person(name="John", age=30)
    person2 = Person(name="John", age=30)
    person3 = Person(name="John", age=31)
    assert person1 == person2
    assert person1 != person3
    assert person1 == {"name": "John", "age": 30}
    assert person1 != {"name": "John", "age": 31}
    assert person1 != {"name": "John"}
    assert person1 != {"name": "John", "age": 30, "gender": "male"}
    assert person1 != {"name": "John", "age": 30, "gender": None}
    assert person1 != {"name": "John", "age": 30, "gender": ""}

# Generated at 2022-06-18 12:30:28.678235
# Unit test for constructor of class Schema
def test_Schema():
    class MySchema(Schema):
        a = Field(type="string")
        b = Field(type="string")

    schema = MySchema(a="a", b="b")
    assert schema.a == "a"
    assert schema.b == "b"


# Generated at 2022-06-18 12:30:33.480191
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    person = Person(name="John Doe", age=42)
    assert person.name == "John Doe"
    assert person.age == 42


# Generated at 2022-06-18 12:30:41.553549
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:30:43.874362
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class MySchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = MySchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:32:52.077880
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:33:00.306260
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        name = String()
        age = Integer()

    class UserReference(Reference):
        to = User

    user = User(name="John", age=30)
    user_reference = UserReference(user)
    assert user_reference.validate(user) == user
    assert user_reference.validate({"name": "John", "age": 30}) == user
    assert user_reference.validate({"name": "John", "age": 30, "extra": "extra"}) == user
    assert user_reference.validate({"name": "John", "age": 30, "extra": "extra"}, strict=True) == user
    assert user_reference.validate({"name": "John", "age": 30, "extra": "extra"}, strict=False) == user
    assert user_reference.validate

# Generated at 2022-06-18 12:33:03.571875
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)

    assert TestSchema.fields == {'name': String(max_length=10), 'age': Integer(minimum=0)}


# Generated at 2022-06-18 12:33:05.174996
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=42)
    assert repr(person) == "Person(name='John', age=42)"


# Generated at 2022-06-18 12:33:15.094829
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        name = String()
        age = Integer()
        address = String()

    class User2(Schema):
        name = String()
        age = Integer()
        address = String()

    class User3(Schema):
        name = String()
        age = Integer()
        address = String()

    class User4(Schema):
        name = String()
        age = Integer()
        address = String()

    class User5(Schema):
        name = String()
        age = Integer()
        address = String()

    class User6(Schema):
        name = String()
        age = Integer()
        address = String()

    class User7(Schema):
        name = String()
        age = Integer()
        address = String()

    class User8(Schema):
        name

# Generated at 2022-06-18 12:33:17.092754
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class A(Schema):
        a = Field()
        b = Field()
        c = Field()
    a = A(a=1, b=2)
    assert list(a) == ['a', 'b']


# Generated at 2022-06-18 12:33:21.290666
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class B(Schema):
        b = Reference("C")
        c = Reference("D")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert definitions["A"] == A
    assert definitions["B"] == B
    assert definitions["C"] == C
    assert definitions["D"] == D

# Generated at 2022-06-18 12:33:23.808975
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name='John', age=20)
    assert len(p) == 2


# Generated at 2022-06-18 12:33:30.718101
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    test_schema = TestSchema(field1=1, field2=2, field3=3)
    assert test_schema['field1'] == 1
    assert test_schema['field2'] == 2
    assert test_schema['field3'] == 3
    try:
        test_schema['field4']
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-18 12:33:34.971344
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["bar"].target is Bar