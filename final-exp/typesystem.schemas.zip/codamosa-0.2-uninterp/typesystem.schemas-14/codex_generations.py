

# Generated at 2022-06-18 12:24:39.304225
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    test_schema = TestSchema(field1=1, field3=3)
    assert list(test_schema) == ['field1', 'field3']


# Generated at 2022-06-18 12:24:44.708934
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:24:54.655031
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()

    schema = TestSchema(field1=1, field2=2, field3=3, field4=4)
    assert list(schema) == ['field1', 'field2', 'field3', 'field4']

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert list(schema) == ['field1', 'field2', 'field3']

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']

    schema = TestSchema(field1=1)
    assert list(schema) == ['field1']


# Generated at 2022-06-18 12:25:03.833072
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")
        field3 = Field(type="string")

    obj1 = TestSchema(field1="value1", field2="value2", field3="value3")
    obj2 = TestSchema(field1="value1", field2="value2", field3="value3")
    assert obj1 == obj2
    assert not (obj1 != obj2)

    obj3 = TestSchema(field1="value1", field2="value2")
    assert obj1 != obj3
    assert not (obj1 == obj3)

    obj4 = TestSchema(field1="value1", field2="value2", field3="value4")
    assert obj1 != obj4

# Generated at 2022-06-18 12:25:09.104257
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
    s = TestSchema(a="a", b="b", c="c")
    assert list(s) == ["a", "b", "c"]


# Generated at 2022-06-18 12:25:12.632738
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30


# Generated at 2022-06-18 12:25:23.427173
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    # Test with a dictionary
    schema = TestSchema({"a": 1, "b": 2})
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c is None

    # Test with a class
    class TestClass:
        a = 1
        b = 2
        c = 3

    schema = TestSchema(TestClass)
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c is None

    # Test with keyword arguments
    schema = TestSchema(a=1, b=2)
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c is None

    # Test with invalid keyword argument

# Generated at 2022-06-18 12:25:29.094795
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:25:41.174721
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
        b = Field()

    s1 = TestSchema(a=1, b=2)
    s2 = TestSchema(a=1, b=2)
    assert s1 == s2
    assert not (s1 != s2)

    s3 = TestSchema(a=1)
    assert s1 != s3
    assert not (s1 == s3)

    s4 = TestSchema(a=1, b=3)
    assert s1 != s4
    assert not (s1 == s4)

    s5 = TestSchema(a=1, b=2, c=3)
    assert s1 != s5
    assert not (s1 == s5)

    class TestSchema2(TestSchema):
        c = Field

# Generated at 2022-06-18 12:25:47.056040
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert schema['field1'] == 1
    assert schema['field2'] == 2
    try:
        schema['field3']
        assert False
    except KeyError:
        pass


# Generated at 2022-06-18 12:26:06.035931
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_active = Boolean()
        address = String()
    schema = TestSchema(name='John', age=20, height=1.75, is_active=True)
    assert list(schema) == ['name', 'age', 'height', 'is_active']


# Generated at 2022-06-18 12:26:10.770226
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions

# Generated at 2022-06-18 12:26:22.342108
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field1 = Reference("TestSchema")
        field2 = Reference("TestSchema")
        field3 = Reference("TestSchema")
        field4 = Reference("TestSchema")
        field5 = Reference("TestSchema")
        field6 = Reference("TestSchema")
        field7 = Reference("TestSchema")
        field8 = Reference("TestSchema")
        field9 = Reference("TestSchema")
        field10 = Reference("TestSchema")
        field11 = Reference("TestSchema")
        field12 = Reference("TestSchema")
        field13 = Reference("TestSchema")
        field14 = Reference("TestSchema")
        field15 = Reference("TestSchema")
        field16 = Reference("TestSchema")
        field17 = Reference("TestSchema")
        field

# Generated at 2022-06-18 12:26:26.147630
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.field, definitions)
    assert TestSchema.field.definitions == definitions

# Generated at 2022-06-18 12:26:31.178525
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
        field5 = Field()
    test_schema = TestSchema(field1=1, field2=2, field3=3, field4=4, field5=5)
    assert len(test_schema) == 5


# Generated at 2022-06-18 12:26:39.978908
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        a = Reference("b")
        b = Reference("c")
        c = Reference("d")
        d = Reference("e")
        e = Reference("f")
        f = Reference("g")
        g = Reference("h")
        h = Reference("i")
        i = Reference("j")
        j = Reference("k")
        k = Reference("l")
        l = Reference("m")
        m = Reference("n")
        n = Reference("o")
        o = Reference("p")
        p = Reference("q")
        q = Reference("r")
        r = Reference("s")
        s = Reference("t")
        t = Reference("u")
        u = Reference("v")
        v = Reference("w")
        w = Reference("x")

# Generated at 2022-06-18 12:26:49.484443
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Baz")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions == definitions
    assert Foo.fields["bar"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions
    assert Baz.fields["baz"].definitions == definitions

# Generated at 2022-06-18 12:26:52.463817
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:26:56.894247
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name='John', age=30)
    assert len(person) == 2


# Generated at 2022-06-18 12:27:01.805670
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field()
        b = Field()
        c = Field()
    a = A(a=1, b=2, c=3)
    b = A(a=1, b=2, c=3)
    c = A(a=1, b=2, c=4)
    assert a == b
    assert a != c


# Generated at 2022-06-18 12:27:18.543494
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert len(TestSchema(a=1, b=2, c=3)) == 3
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1)) == 1
    assert len(TestSchema()) == 0


# Generated at 2022-06-18 12:27:23.196954
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1, b=2, c=3)) == 3
    assert len(TestSchema(a=1, b=2, c=3, d=4)) == 3


# Generated at 2022-06-18 12:27:32.703053
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Baz")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:27:40.650069
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = MySchema(field1=1, field2=2)
    assert repr(schema) == "MySchema(field1=1, field2=2) [sparse]"
    schema = MySchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "MySchema(field1=1, field2=2, field3=3)"


# Generated at 2022-06-18 12:27:52.638965
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {'name': String(), 'age': Integer()}
    assert Person.make_validator() == Object(properties={'name': String(), 'age': Integer()}, required=['name', 'age'], additional_properties=None)
    assert Person.validate({'name': 'John', 'age': 30}) == Person(name='John', age=30)
    assert Person.validate_or_error({'name': 'John', 'age': 30}) == ValidationResult(value=Person(name='John', age=30), error=None)
    assert Person(name='John', age=30).is_sparse == False
    assert Person(name='John', age=30) == Person(name='John', age=30)

# Generated at 2022-06-18 12:27:55.977664
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert TestSchema.fields == {"name": Field(type="string"), "age": Field(type="integer")}


# Generated at 2022-06-18 12:27:58.722813
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert list(person) == ["name", "age"]



# Generated at 2022-06-18 12:28:03.862547
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    set_definitions(Bar, definitions)
    set_definitions(Baz, definitions)

    assert Foo.fields["foo"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:28:14.846959
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    person = Person(name="John", age=30, height=1.75)
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.75
    assert person == Person(name="John", age=30, height=1.75)
    assert person != Person(name="John", age=30, height=1.76)
    assert person != Person(name="John", age=31, height=1.75)
    assert person != Person(name="Jane", age=30, height=1.75)
    assert person != Person(name="John", age=30)
    assert person != Person(name="John", height=1.75)

# Generated at 2022-06-18 12:28:24.391981
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class BaseSchema(Schema):
        pass

    class SubSchema(BaseSchema):
        pass

    class SubSubSchema(SubSchema):
        pass

    class SubSubSubSchema(SubSubSchema):
        pass

    assert SubSubSubSchema.fields == {}

    class SubSubSubSchema(SubSubSchema):
        field = Field()

    assert SubSubSubSchema.fields == {"field": Field()}

    class SubSubSubSchema(SubSubSchema):
        field = Field()

    assert SubSubSubSchema.fields == {"field": Field()}

    class SubSubSubSchema(SubSubSchema):
        field = Field()

    assert SubSubSubSchema.fields == {"field": Field()}


# Generated at 2022-06-18 12:28:57.783896
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
        d = Field(type="string")
        e = Field(type="string")
        f = Field(type="string")
        g = Field(type="string")
        h = Field(type="string")
        i = Field(type="string")
        j = Field(type="string")
        k = Field(type="string")
        l = Field(type="string")
        m = Field(type="string")
        n = Field(type="string")
        o = Field(type="string")
        p = Field(type="string")
        q = Field(type="string")
        r = Field(type="string")
        s = Field(type="string")

# Generated at 2022-06-18 12:29:05.526154
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    assert Person.fields == {"name": String()}
    assert Person.make_validator() == Object(
        properties={"name": String()}, required=["name"], additional_properties=None
    )
    assert Person.validate({"name": "John"}) == Person(name="John")
    assert Person.validate_or_error({"name": "John"}) == ValidationResult(
        value=Person(name="John"), error=None
    )

# Generated at 2022-06-18 12:29:08.248718
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}



# Generated at 2022-06-18 12:29:11.875505
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        address = String()

    p = Person(name="John", age=30)
    assert list(p) == ['name', 'age']


# Generated at 2022-06-18 12:29:18.897674
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:29:23.607124
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1, b=2, c=3)) == 3
    assert len(TestSchema(a=1, b=2, c=3, d=4)) == 3


# Generated at 2022-06-18 12:29:34.571441
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()
        c = Field()

    assert A.fields == {'a': Field(), 'b': Field(), 'c': Field()}
    assert A.__name__ == 'A'
    assert A.__bases__ == (Schema,)
    assert A.__dict__ == {'__module__': '__main__', '__qualname__': 'A'}
    assert A.__doc__ == None
    assert A.__annotations__ == {}
    assert A.__init__.__qualname__ == 'A.__init__'
    assert A.__init__.__annotations__ == {}
    assert A.__init__.__doc__ == None
    assert A.__init__.__module__ == '__main__'

# Generated at 2022-06-18 12:29:39.661810
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:29:47.136225
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()

    class Address(Schema):
        street = String()
        city = String()

    class PersonWithAddress(Schema):
        person = Reference(Person)
        address = Reference(Address)

    person = Person(name="John", age=42)
    address = Address(street="123 Main St", city="New York")
    person_with_address = PersonWithAddress(person=person, address=address)
    assert person_with_address.person.name == "John"
    assert person_with_address.person.age == 42
    assert person_with_address.address.street == "123 Main St"
    assert person_with_address.address.city == "New York"
    assert person_with_address.is_sparse is False

# Generated at 2022-06-18 12:29:58.205003
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        field = Reference("TestSchema")
    test_schema = TestSchema()
    test_schema.field = test_schema
    assert test_schema.field == test_schema
    test_schema.field = None
    assert test_schema.field == None
    test_schema.field = "test"
    assert test_schema.field == "test"
    test_schema.field = 1
    assert test_schema.field == 1
    test_schema.field = 1.0
    assert test_schema.field == 1.0
    test_schema.field = True
    assert test_schema.field == True
    test_schema.field = False
    assert test_schema.field == False
    test_schema.field

# Generated at 2022-06-18 12:30:35.580487
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert Person.fields == {"name": Field(type="string"), "age": Field(type="integer")}
    assert Person.__name__ == "Person"
    assert Person.__module__ == "__main__"
    assert Person.__qualname__ == "Person"
    assert Person.__doc__ == None
    assert Person.__annotations__ == {}
    assert Person.__bases__ == (Schema,)
    assert Person.__dict__ == {'__module__': '__main__', 'fields': {'name': Field(type='string'), 'age': Field(type='integer')}}
    assert Person.__subclasses__() == []

# Generated at 2022-06-18 12:30:44.542937
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        height = Field(type="number")
        weight = Field(type="number")
        is_active = Field(type="boolean", default=True)
        is_admin = Field(type="boolean", default=False)

    person = Person(name="John", age=30, height=1.8, weight=80)
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.8
    assert person.weight == 80
    assert person.is_active is True
    assert person.is_admin is False

    person = Person({"name": "John", "age": 30, "height": 1.8, "weight": 80})

# Generated at 2022-06-18 12:30:48.218191
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions is definitions

# Generated at 2022-06-18 12:30:57.983084
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:31:08.210600
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    test_schema1 = TestSchema(field1=1, field2=2, field3=3)
    test_schema2 = TestSchema(field1=1, field2=2, field3=3)
    test_schema3 = TestSchema(field1=1, field2=2)
    test_schema4 = TestSchema(field1=1, field2=2, field3=4)

    assert test_schema1 == test_schema2
    assert test_schema1 != test_schema3
    assert test_schema1 != test_schema4


# Generated at 2022-06-18 12:31:11.664425
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    assert TestSchema.fields == {'field1': Field(), 'field2': Field()}


# Generated at 2022-06-18 12:31:21.998818
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference(to="test")
    assert Reference(to="test", definitions={"test": "test"})
    assert Reference(to="test", definitions={"test": "test"}, allow_null=True)
    assert Reference(to="test", definitions={"test": "test"}, allow_null=False)
    assert Reference(to="test", definitions={"test": "test"}, default=None)
    assert Reference(to="test", definitions={"test": "test"}, default="test")
    assert Reference(to="test", definitions={"test": "test"}, description="test")
    assert Reference(to="test", definitions={"test": "test"}, title="test")
    assert Reference(to="test", definitions={"test": "test"}, name="test")

# Generated at 2022-06-18 12:31:31.991931
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    person = Person(name="John Doe", age=42)
    assert person["name"] == "John Doe"
    assert person["age"] == 42
    assert person["name"] != "Jane Doe"
    assert person["age"] != 43
    assert person["name"] != 42
    assert person["age"] != "John Doe"
    assert person["name"] != None
    assert person["age"] != None
    assert person["name"] != ""
    assert person["age"] != ""
    assert person["name"] != " "
    assert person["age"] != " "
    assert person["name"] != 0
    assert person["age"] != 0
    assert person["name"] != 1

# Generated at 2022-06-18 12:31:38.026360
# Unit test for constructor of class Reference
def test_Reference():
    class TestSchema(Schema):
        field = Reference("TestSchema")
    assert TestSchema.fields["field"].target_string == "TestSchema"
    assert TestSchema.fields["field"].target == TestSchema
    assert TestSchema.fields["field"].definitions == {
        "TestSchema": TestSchema
    }
    assert TestSchema.fields["field"].validate(TestSchema()) == TestSchema()
    assert TestSchema.fields["field"].serialize(TestSchema()) == {}


# Generated at 2022-06-18 12:31:42.390023
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2


# Generated at 2022-06-18 12:32:10.753372
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"


# Generated at 2022-06-18 12:32:18.847595
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {'name': String(), 'age': Integer()}
    assert Person.__name__ == 'Person'
    assert Person.__bases__ == (Schema,)
    assert Person.__dict__ == {'__module__': '__main__', '__qualname__': 'Person'}

    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {'name': String(), 'age': Integer()}
    assert Person.__name__ == 'Person'
    assert Person.__bases__ == (Schema,)
    assert Person.__dict__ == {'__module__': '__main__', '__qualname__': 'Person'}


# Generated at 2022-06-18 12:32:27.829965
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
    ts = TestSchema(a="a", b="b")
    assert ts.a == "a"
    assert ts.b == "b"
    ts = TestSchema({"a": "a", "b": "b"})
    assert ts.a == "a"
    assert ts.b == "b"
    ts = TestSchema(TestSchema(a="a", b="b"))
    assert ts.a == "a"
    assert ts.b == "b"
    ts = TestSchema(a="a")
    assert ts.a == "a"
    assert ts.b is None
    ts = TestSchema(b="b")
    assert ts.a is None

# Generated at 2022-06-18 12:32:34.259804
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:32:43.293801
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        height = Float()

    schema1 = TestSchema(name='John', age=25, height=1.75)
    schema2 = TestSchema(name='John', age=25, height=1.75)
    schema3 = TestSchema(name='John', age=25, height=1.76)
    schema4 = TestSchema(name='John', age=25)
    schema5 = TestSchema(name='John', age=25, height=1.75, weight=70)

    assert schema1 == schema2
    assert schema1 != schema3
    assert schema1 != schema4
    assert schema1 != schema5


# Generated at 2022-06-18 12:32:48.467464
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:32:53.159046
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    obj = TestSchema(field1=1, field2=2, field3=3)
    assert list(obj) == ['field1', 'field2', 'field3']


# Generated at 2022-06-18 12:33:01.036460
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)
        height = Number(minimum=0, maximum=2.5)
        is_active = Boolean()
        tags = Array(items=String(max_length=10))
        friends = Array(items=Reference("TestSchema"))

    schema = TestSchema(name="John", age=20, height=1.8, is_active=True, tags=["A", "B"])
    assert schema.name == "John"
    assert schema.age == 20
    assert schema.height == 1.8
    assert schema.is_active == True
    assert schema.tags == ["A", "B"]
    assert schema.friends == []
    assert schema.is_sparse == False

# Generated at 2022-06-18 12:33:09.843193
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    person = Person(name="John Doe", age=42)
    assert person.name == "John Doe"
    assert person.age == 42
    assert person == Person(name="John Doe", age=42)
    assert person != Person(name="Jane Doe", age=42)
    assert person != Person(name="John Doe", age=43)
    assert person != Person(name="Jane Doe", age=43)
    assert person != 42
    assert person != {"name": "John Doe", "age": 42}
    assert person != {"name": "John Doe", "age": 42, "foo": "bar"}
    assert person != {"name": "John Doe"}
    assert person != {"age": 42}
    assert person

# Generated at 2022-06-18 12:33:16.219022
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
    assert len(TestSchema(a="a", b="b", c="c")) == 3
    assert len(TestSchema(a="a", b="b")) == 2
    assert len(TestSchema(a="a")) == 1
    assert len(TestSchema()) == 0
