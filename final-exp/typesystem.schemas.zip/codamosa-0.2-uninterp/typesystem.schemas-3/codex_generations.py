

# Generated at 2022-06-18 12:24:22.723782
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert repr(TestSchema(a=1, b=2)) == "TestSchema(a=1, b=2)"
    assert repr(TestSchema(a=1, b=2, c=3)) == "TestSchema(a=1, b=2, c=3)"
    assert repr(TestSchema(a=1, b=2, c=3)) == "TestSchema(a=1, b=2, c=3)"
    assert repr(TestSchema(a=1, b=2, c=3)) == "TestSchema(a=1, b=2, c=3)"

# Generated at 2022-06-18 12:24:28.133265
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field2=2, field3=3)"


# Generated at 2022-06-18 12:24:38.233629
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()

    person1 = Person(name="John", age=30)
    person2 = Person(name="John", age=30)
    person3 = Person(name="John", age=31)
    person4 = Person(name="John")
    person5 = Person(age=30)
    person6 = Person()

    assert person1 == person2
    assert person1 != person3
    assert person1 != person4
    assert person1 != person5
    assert person1 != person6
    assert person4 != person5
    assert person4 != person6
    assert person5 != person6
    assert person6 == person6



# Generated at 2022-06-18 12:24:42.698862
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions is definitions

# Generated at 2022-06-18 12:24:44.208430
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:24:46.600523
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:24:50.232909
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:25:01.428113
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        name = String()
        age = Integer()
        is_active = Boolean()

    class Post(Schema):
        title = String()
        author = Reference(User)

    post = Post(
        title="Hello World",
        author=User(name="John Doe", age=42, is_active=True),
    )

    assert post.author.name == "John Doe"
    assert post.author.age == 42
    assert post.author.is_active is True

    post = Post.validate(
        {
            "title": "Hello World",
            "author": {"name": "John Doe", "age": 42, "is_active": True},
        }
    )

    assert post.author.name == "John Doe"
    assert post.author.age == 42
    assert post

# Generated at 2022-06-18 12:25:05.119758
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:25:15.415632
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")

    foo1 = Foo(a="a", b="b", c="c")
    foo2 = Foo(a="a", b="b", c="c")
    assert foo1 == foo2

    foo1 = Foo(a="a", b="b")
    foo2 = Foo(a="a", b="b", c="c")
    assert foo1 != foo2

    foo1 = Foo(a="a", b="b")
    foo2 = Foo(a="a", b="b", c="c")
    assert foo1 != foo2

    foo1 = Foo(a="a", b="b", c="c")

# Generated at 2022-06-18 12:25:46.857867
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()
    assert Person.fields == {'name': String(), 'age': Integer()}
    assert Person.__name__ == 'Person'
    assert Person.__module__ == __name__
    assert Person.__qualname__ == 'Person'
    assert Person.__bases__ == (Schema,)
    assert Person.__dict__ == {'__module__': __name__, '__qualname__': 'Person', 'fields': {'name': String(), 'age': Integer()}}
    assert Person.__doc__ is None
    assert Person.__annotations__ == {}
    assert Person.__slots__ is None
    assert Person.__weakref__ is None
    assert Person.__init__ is Schema.__init__

# Generated at 2022-06-18 12:25:50.509216
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field = Field()

    schema = TestSchema(field="value")
    assert schema["field"] == "value"

    with pytest.raises(KeyError):
        schema["missing"]



# Generated at 2022-06-18 12:26:01.173238
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()
        c = Field()
        d = Field()
        e = Field()
        f = Field()
        g = Field()
        h = Field()
        i = Field()
        j = Field()
        k = Field()
        l = Field()
        m = Field()
        n = Field()
        o = Field()
        p = Field()
        q = Field()
        r = Field()
        s = Field()
        t = Field()
        u = Field()
        v = Field()
        w = Field()
        x = Field()
        y = Field()
        z = Field()

# Generated at 2022-06-18 12:26:09.761317
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions == definitions
    assert Foo.fields["bar"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions
    assert Baz.fields["baz"].definitions == definitions

# Generated at 2022-06-18 12:26:21.674435
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
        field5 = Field()
        field6 = Field()
        field7 = Field()
        field8 = Field()
        field9 = Field()
        field10 = Field()
        field11 = Field()
        field12 = Field()
        field13 = Field()
        field14 = Field()
        field15 = Field()
        field16 = Field()
        field17 = Field()
        field18 = Field()
        field19 = Field()
        field20 = Field()
        field21 = Field()
        field22 = Field()
        field23 = Field()
        field24 = Field()
        field25 = Field()
        field26 = Field()
        field27 = Field()


# Generated at 2022-06-18 12:26:27.269533
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

    person = Person(name="John Doe", age=42)
    assert person["name"] == "John Doe"
    assert person["age"] == 42
    assert person["name"] == person.name
    assert person["age"] == person.age


# Generated at 2022-06-18 12:26:29.492402
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
    test_schema = TestSchema(a=1, b=2)
    assert test_schema["a"] == 1
    assert test_schema["b"] == 2
    try:
        test_schema["c"]
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-18 12:26:33.033940
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        field1 = Field(required=True)
        field2 = Field(required=False)

    test_schema = TestSchema(field1=1, field2=2)
    assert test_schema.field1 == 1
    assert test_schema.field2 == 2


# Generated at 2022-06-18 12:26:36.620561
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']


# Generated at 2022-06-18 12:26:42.424604
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
        d = Field()
        e = Field()
        f = Field()
        g = Field()
        h = Field()
        i = Field()
        j = Field()
        k = Field()
        l = Field()
        m = Field()
        n = Field()
        o = Field()
        p = Field()
        q = Field()
        r = Field()
        s = Field()
        t = Field()
        u = Field()
        v = Field()
        w = Field()
        x = Field()
        y = Field()
        z = Field()

# Generated at 2022-06-18 12:27:06.429986
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        field = Reference("TestSchema")
        field2 = Reference(TestSchema)

    schema = TestSchema.validate({"field": {"field": "test"}})
    assert schema.field.field == "test"
    assert schema.field2.field == "test"
    assert schema.field2.field2.field == "test"

    schema = TestSchema.validate({"field": {"field": None}})
    assert schema.field.field is None
    assert schema.field2.field is None
    assert schema.field2.field2.field is None

    schema = TestSchema.validate({"field": {"field": None}, "field2": {"field": None}})
    assert schema.field.field is None
    assert schema.field2.field is None


# Generated at 2022-06-18 12:27:10.139715
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    p = Person(name="John", age=30)
    assert p.name == "John"
    assert p.age == 30


# Generated at 2022-06-18 12:27:14.770368
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2
    assert len(schema.fields) == 3


# Generated at 2022-06-18 12:27:19.548407
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type="string")
    schema = TestSchema(name="John", age=30, address="123 Main St.")
    assert list(schema) == ["name", "age", "address"]


# Generated at 2022-06-18 12:27:24.300365
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        a = Field()
        b = Field()
        c = Field()
        d = Field()
        e = Field()
        f = Field()
        g = Field()
        h = Field()
        i = Field()
        j = Field()
        k = Field()
        l = Field()
        m = Field()
        n = Field()
        o = Field()
        p = Field()
        q = Field()
        r = Field()
        s = Field()
        t = Field()
        u = Field()
        v = Field()
        w = Field()
        x = Field()
        y = Field()
        z = Field()


# Generated at 2022-06-18 12:27:33.385132
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:27:36.036273
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert len(person) == 2

    person = Person(name="John")
    assert len(person) == 1

    person = Person()
    assert len(person) == 0


# Generated at 2022-06-18 12:27:42.473052
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:27:47.419342
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ['field1', 'field3']


# Generated at 2022-06-18 12:27:51.741855
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:28:14.727251
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field()
        b = Field()
    foo1 = Foo(a=1, b=2)
    foo2 = Foo(a=1, b=2)
    foo3 = Foo(a=1, b=3)
    foo4 = Foo(a=1)
    foo5 = Foo(b=2)
    assert foo1 == foo2
    assert foo1 != foo3
    assert foo1 != foo4
    assert foo1 != foo5


# Generated at 2022-06-18 12:28:19.331259
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field()
        b = Field()
    a = A(a=1, b=2)
    b = A(a=1, b=2)
    c = A(a=1, b=3)
    assert a == b
    assert a != c


# Generated at 2022-06-18 12:28:27.646735
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean()
        friends = Array(String())
        address = Object(
            properties={
                "street": String(),
                "city": String(),
                "state": String(),
                "zip": String(),
            }
        )

    person = Person(
        name="John",
        age=30,
        height=1.80,
        is_adult=True,
        friends=["Mary", "Jane"],
        address={
            "street": "123 Main St",
            "city": "New York",
            "state": "NY",
            "zip": "10001",
        },
    )
    assert person.name == "John"
    assert person.age == 30
    assert person.height

# Generated at 2022-06-18 12:28:34.377857
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30
    assert person == Person(name="John", age=30)
    assert person != Person(name="John", age=31)
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="John")
    assert person != Person(age=30)
    assert person != Person()
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="John", age=30, height=180)

# Generated at 2022-06-18 12:28:38.683878
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name="John", age=30)
    assert p.name == "John"
    assert p.age == 30


# Generated at 2022-06-18 12:28:42.384559
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2)
    assert list(schema) == ["a", "b"]


# Generated at 2022-06-18 12:28:53.513989
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        pass
    assert TestSchema.fields == {}

    class TestSchema(Schema):
        field = Field()
    assert TestSchema.fields == {"field": Field()}

    class TestSchema(Schema):
        field = Field()
        field2 = Field()
    assert TestSchema.fields == {"field": Field(), "field2": Field()}

    class TestSchema(Schema):
        field = Field()
        field2 = Field()
        field3 = Field()
    assert TestSchema.fields == {"field": Field(), "field2": Field(), "field3": Field()}

    class TestSchema(Schema):
        field = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
    assert TestSchema.fields

# Generated at 2022-06-18 12:29:00.151669
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()
    p1 = Person(name="John", age=30)
    p2 = Person(name="John", age=30)
    assert p1 == p2
    p3 = Person(name="John", age=31)
    assert p1 != p3
    p4 = Person(name="John")
    assert p1 != p4
    p5 = Person(age=30)
    assert p1 != p5


# Generated at 2022-06-18 12:29:02.747452
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field_1 = Field()
        field_2 = Field()

    assert TestSchema.fields == {"field_1": Field(), "field_2": Field()}


# Generated at 2022-06-18 12:29:12.098771
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 != schema3
    schema4 = TestSchema(field1=1)
    assert schema1 != schema4
    schema5 = TestSchema(field1=1, field2=2, field3=3)
    assert schema1 != schema5


# Generated at 2022-06-18 12:29:55.963519
# Unit test for function set_definitions
def test_set_definitions():
    class Schema1(Schema):
        field1 = Reference("Schema2")
        field2 = Array(Reference("Schema3"))

    class Schema2(Schema):
        field1 = Reference("Schema3")
        field2 = Array(Reference("Schema1"))

    class Schema3(Schema):
        field1 = Reference("Schema1")
        field2 = Array(Reference("Schema2"))

    definitions = SchemaDefinitions()
    set_definitions(Schema1, definitions)
    assert Schema1.fields["field1"].definitions == definitions
    assert Schema1.fields["field2"].items.definitions == definitions
    assert Schema2.fields["field1"].definitions == definitions
    assert Schema2.fields["field2"].items.definitions == definitions
    assert Sche

# Generated at 2022-06-18 12:30:01.272368
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Foo(Schema):
        bar = Field(type="string")

    foo = Foo(bar="baz")
    assert foo["bar"] == "baz"
    try:
        foo["qux"]
    except KeyError:
        pass
    else:
        assert False, "KeyError not raised"


# Generated at 2022-06-18 12:30:04.313731
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.field, definitions)
    assert TestSchema.field.definitions == definitions

# Generated at 2022-06-18 12:30:10.394332
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        is_adult = Boolean(default=False)

    person = Person(name="John", age=30, height=1.75)
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.75
    assert person.is_adult == False


# Generated at 2022-06-18 12:30:21.089745
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:30:25.485717
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    s = TestSchema(a=1, b=2)
    assert list(s) == ['a', 'b']

# Generated at 2022-06-18 12:30:31.507462
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = String()
        field2 = String()
        field3 = String()
    test_schema = TestSchema(field1='value1', field2='value2')
    assert test_schema.__repr__() == "TestSchema(field1='value1', field2='value2') [sparse]"


# Generated at 2022-06-18 12:30:35.044917
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions is definitions

# Generated at 2022-06-18 12:30:37.234611
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name='John', age=30)
    assert repr(p) == "Person(name='John', age=30)"


# Generated at 2022-06-18 12:30:40.795179
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:31:15.226104
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field = Field()
    assert TestSchema.fields == {"field": Field()}


# Generated at 2022-06-18 12:31:24.846133
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30
    assert person == Person(name="John", age=30)
    assert person != Person(name="John", age=31)
    assert person != Person(name="Jane", age=30)
    assert person != Person(name="Jane", age=31)
    assert person != Person(name="John")
    assert person != Person(age=30)
    assert person != Person()
    assert person != Person(name="John", age=30, extra=True)
    assert person != Person(name="John", age=30, extra=False)

# Generated at 2022-06-18 12:31:33.702713
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
    s1 = TestSchema(a=1, b=2)
    s2 = TestSchema(a=1, b=2)
    assert s1 == s2
    s3 = TestSchema(a=1, b=3)
    assert s1 != s3
    s4 = TestSchema(a=1)
    assert s1 != s4
    s5 = TestSchema(b=2)
    assert s1 != s5
    s6 = TestSchema()
    assert s1 != s6
    s7 = TestSchema(a=1, b=2, c=3)
    assert s1 != s7


# Generated at 2022-06-18 12:31:43.945326
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()

    assert A.fields == {"a": Field(), "b": Field()}

    class B(A):
        c = Field()

    assert B.fields == {"a": Field(), "b": Field(), "c": Field()}

    class C(B):
        d = Field()
        b = Field()

    assert C.fields == {"a": Field(), "b": Field(), "c": Field(), "d": Field()}

    class D(C):
        pass

    assert D.fields == {"a": Field(), "b": Field(), "c": Field(), "d": Field()}

    class E(D):
        a = Field()

    assert E.fields == {"a": Field(), "b": Field(), "c": Field(), "d": Field()}

# Generated at 2022-06-18 12:31:49.343285
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert schema['field1'] == 1
    assert schema['field2'] == 2
    try:
        schema['field3']
        assert False
    except KeyError:
        pass


# Generated at 2022-06-18 12:31:55.989280
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:32:04.126147
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
    assert repr(TestSchema(name="John", age=30)) == "TestSchema(name='John', age=30)"
    assert repr(TestSchema(name="John")) == "TestSchema(name='John') [sparse]"
    assert repr(TestSchema(age=30)) == "TestSchema(age=30) [sparse]"
    assert repr(TestSchema()) == "TestSchema() [sparse]"


# Generated at 2022-06-18 12:32:08.906229
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()

    class B(A):
        c = Field()

    class C(B):
        d = Field()

    assert C.fields == {'a': A.fields['a'], 'b': A.fields['b'], 'c': B.fields['c'], 'd': C.fields['d']}


# Generated at 2022-06-18 12:32:12.223543
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:32:14.718337
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    assert TestSchema.fields == {"field1": Field(), "field2": Field()}


# Generated at 2022-06-18 12:33:37.917610
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}


# Generated at 2022-06-18 12:33:42.623868
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Foo(Schema):
        bar = Reference("Bar")
    class Bar(Schema):
        pass
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions == definitions
    assert Foo.fields["bar"].target == Bar
    assert Foo.fields["bar"].target_string == "Bar"

# Generated at 2022-06-18 12:33:47.044029
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert list(schema) == ['field1', 'field2', 'field3']
