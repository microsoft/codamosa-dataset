

# Generated at 2022-06-18 12:24:19.499948
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:24:27.795544
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2, field3=4)
    schema4 = TestSchema(field1=1, field2=2)
    schema5 = TestSchema(field1=1, field2=2, field3=3, field4=4)

    assert schema1 == schema2
    assert schema1 != schema3
    assert schema1 != schema4
    assert schema1 != schema5


# Generated at 2022-06-18 12:24:31.545473
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    assert Person.fields == {'name': Field(str), 'age': Field(int)}


# Generated at 2022-06-18 12:24:40.324317
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
    assert repr(TestSchema(a="a", b="b", c="c")) == "TestSchema(a='a', b='b', c='c')"
    assert repr(TestSchema(a="a", b="b")) == "TestSchema(a='a', b='b') [sparse]"
    assert repr(TestSchema(a="a")) == "TestSchema(a='a') [sparse]"
    assert repr(TestSchema()) == "TestSchema() [sparse]"


# Generated at 2022-06-18 12:24:49.612637
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestReference")

    class TestReference(Schema):
        field = Reference("TestReference")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions is definitions
    assert TestSchema.fields["field"].target is TestReference
    assert TestSchema.fields["field"].target.fields["field"].definitions is definitions
    assert TestSchema.fields["field"].target.fields["field"].target is TestReference

# Generated at 2022-06-18 12:24:55.325096
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    s = TestSchema(a=1, b=2)
    assert list(s) == ['a', 'b']


# Generated at 2022-06-18 12:24:59.448247
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")

    schema = TestSchema({"a": "a", "b": "b"})
    assert schema.a == "a"
    assert schema.b == "b"


# Generated at 2022-06-18 12:25:07.202211
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        height = Field(type="number")
        weight = Field(type="number")
        married = Field(type="boolean")
        children = Field(type="array", items=Field(type="string"))
        pets = Field(type="array", items=Field(type="string"))
        address = Field(type="object", properties={"city": Field(type="string")})
        phone_numbers = Field(
            type="array", items=Field(type="string")
        )
        email_addresses = Field(
            type="array", items=Field(type="string")
        )
        friends = Field(type="array", items=Reference("TestSchema"))

# Generated at 2022-06-18 12:25:11.040124
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name='John', age=30)
    assert person.name == 'John'
    assert person.age == 30


# Generated at 2022-06-18 12:25:14.635893
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
    person = Person(name="John Smith", age=42)
    assert person.name == "John Smith"
    assert person.age == 42


# Generated at 2022-06-18 12:25:38.425023
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ["field1", "field3"]

# Generated at 2022-06-18 12:25:47.905485
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        a = Reference("Bar")
        b = Array(Reference("Bar"))
        c = Array(Array(Reference("Bar")))
        d = Array(Array(Array(Reference("Bar"))))

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.a.definitions is definitions
    assert Foo.b.items.definitions is definitions
    assert Foo.c.items.items.definitions is definitions
    assert Foo.d.items.items.items.definitions is definitions

# Generated at 2022-06-18 12:25:55.212411
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions == definitions
    assert Foo.fields["baz"].definitions == definitions
    assert Bar.fields["foo"].definitions == definitions
    assert Baz.fields["foo"].definitions == definitions

# Generated at 2022-06-18 12:26:04.364627
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions == definitions
    assert Foo.fields["bar"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions
    assert Baz.fields["baz"].definitions == definitions

# Generated at 2022-06-18 12:26:08.552550
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:26:20.378849
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class B(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class C(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class D(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    set_definitions(B, definitions)
    set_definitions(C, definitions)
    set_definitions(D, definitions)

    assert A.fields["a"].definitions == definitions

# Generated at 2022-06-18 12:26:30.638971
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42
    assert person == Person(name="John", age=42)
    assert person != Person(name="John", age=43)
    assert person != Person(name="Jane", age=42)
    assert person != Person(name="Jane", age=43)
    assert person != Person(name="John", age=42, height=1.8)
    assert person != Person(name="John", age=42, height=1.8, weight=80)
    assert person != Person(name="John", age=42, height=1.8, weight=80, hair_color="brown")

# Generated at 2022-06-18 12:26:39.644799
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()
        c = Field()
        d = Field()

    assert A.fields == {'a': Field(), 'b': Field(), 'c': Field(), 'd': Field()}
    assert A.__name__ == 'A'
    assert A.__bases__ == (Schema,)
    assert A.__dict__ == {'__module__': '__main__', '__qualname__': 'A'}
    assert A.__doc__ is None
    assert A.__annotations__ == {}
    assert A.__slots__ is None
    assert A.__weakref__ is None
    assert A.__dict__ == {'__module__': '__main__', '__qualname__': 'A'}
    assert A.__init__.__

# Generated at 2022-06-18 12:26:45.858224
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert schema['field1'] == 1
    assert schema['field2'] == 2
    try:
        schema['field3']
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-18 12:26:50.487300
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2)"


# Generated at 2022-06-18 12:27:04.815579
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:27:16.117438
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    assert TestSchema(field1=1, field2=2) == TestSchema(field1=1, field2=2)
    assert TestSchema(field1=1, field2=2) != TestSchema(field1=1, field2=3)
    assert TestSchema(field1=1, field2=2) != TestSchema(field1=3, field2=2)
    assert TestSchema(field1=1, field2=2) != TestSchema(field1=1)
    assert TestSchema(field1=1, field2=2) != TestSchema(field2=2)
    assert TestSchema(field1=1, field2=2) != TestSchema()
    assert Test

# Generated at 2022-06-18 12:27:19.389381
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions
    assert Bar.fields["foo"].definitions is definitions
    assert Baz.fields["foo"].definitions is definitions

# Generated at 2022-06-18 12:27:26.441522
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    assert TestSchema.fields == {'field1': Field(), 'field2': Field()}
    assert TestSchema.__name__ == 'TestSchema'
    assert TestSchema.__bases__ == (Schema,)
    assert TestSchema.__dict__ == {'fields': {'field1': Field(), 'field2': Field()}}
    assert TestSchema.__module__ == '__main__'
    assert TestSchema.__qualname__ == 'TestSchema'
    assert TestSchema.__annotations__ == {}
    assert TestSchema.__doc__ is None
    assert TestSchema.__slots__ is None
    assert TestSchema.__weakref__ is None
    assert TestSchema.__

# Generated at 2022-06-18 12:27:36.187075
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz
    assert Foo.fields["foo"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions
    assert Baz.fields["baz"].definitions == definitions

# Generated at 2022-06-18 12:27:40.605731
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:27:43.641786
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:27:48.687742
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = String()
        field2 = String()
        field3 = String()
    schema = TestSchema(field1="value1", field2="value2")
    assert len(schema) == 2


# Generated at 2022-06-18 12:27:54.518767
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 == schema2
    assert schema1 != schema3


# Generated at 2022-06-18 12:28:02.761695
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person

    class PersonReference2(Reference):
        to = "Person"

    class PersonReference3(Reference):
        to = "Person"

    class PersonReference4(Reference):
        to = "Person"

    class PersonReference5(Reference):
        to = "Person"

    class PersonReference6(Reference):
        to = "Person"

    class PersonReference7(Reference):
        to = "Person"

    class PersonReference8(Reference):
        to = "Person"

    class PersonReference9(Reference):
        to = "Person"

    class PersonReference10(Reference):
        to = "Person"

    class PersonReference11(Reference):
        to = "Person"


# Generated at 2022-06-18 12:28:23.948507
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        is_active = Boolean()
        is_staff = Boolean()
        is_superuser = Boolean()
        is_admin = Boolean()
        is_moderator = Boolean()
        is_editor = Boolean()
        is_author = Boolean()
        is_contributor = Boolean()
        is_subscriber = Boolean()
        is_member = Boolean()
        is_guest = Boolean()
        is_banned = Boolean()
        is_suspended = Boolean()
        is_deleted = Boolean()
        is_removed = Boolean()
        is_blocked = Boolean()
        is_active = Boolean()
        is_staff = Boolean()
        is_superuser = Boolean()
       

# Generated at 2022-06-18 12:28:25.892511
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}


# Generated at 2022-06-18 12:28:33.096458
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field_1 = Field()
        field_2 = Field()

    schema_1 = TestSchema(field_1=1, field_2=2)
    schema_2 = TestSchema(field_1=1, field_2=2)
    assert schema_1 == schema_2

    schema_1 = TestSchema(field_1=1, field_2=2)
    schema_2 = TestSchema(field_1=1, field_2=3)
    assert schema_1 != schema_2

    schema_1 = TestSchema(field_1=1)
    schema_2 = TestSchema(field_1=1, field_2=2)
    assert schema_1 != schema_2


# Generated at 2022-06-18 12:28:39.819500
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:28:48.509465
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    set_definitions(Baz.fields["baz"], definitions)

    assert Foo.fields["foo"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:28:55.988604
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    person1 = Person(name="John", age=30)
    person2 = Person(name="John", age=30)
    person3 = Person(name="Jane", age=30)
    person4 = Person(name="John", age=31)
    person5 = Person(name="John")

    assert person1 == person2
    assert person1 != person3
    assert person1 != person4
    assert person1 != person5


# Generated at 2022-06-18 12:28:59.878414
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']


# Generated at 2022-06-18 12:29:03.252258
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)

    schema = MySchema(name='John', age=30)
    assert schema['name'] == 'John'
    assert schema['age'] == 30


# Generated at 2022-06-18 12:29:12.148156
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ["a", "b", "c"]

    schema = TestSchema(a=1, b=2)
    assert list(schema) == ["a", "b"]

    schema = TestSchema(a=1)
    assert list(schema) == ["a"]

    schema = TestSchema()
    assert list(schema) == []



# Generated at 2022-06-18 12:29:14.828213
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    assert TestSchema.fields == {'field1': Field(), 'field2': Field()}


# Generated at 2022-06-18 12:29:40.731923
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        address = String()

    person = Person(name="John", age=30)
    assert list(person) == ["name", "age"]


# Generated at 2022-06-18 12:29:43.670796
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"



# Generated at 2022-06-18 12:29:47.917459
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:29:50.965489
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        a = Field()
    schema = TestSchema(a=1)
    assert schema['a'] == 1


# Generated at 2022-06-18 12:29:58.862312
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        baz = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions == definitions
    assert Foo.fields["baz"].definitions == definitions
    assert Bar.fields["bar"].definitions == definitions
    assert Baz.fields["baz"].definitions == definitions

# Generated at 2022-06-18 12:30:06.401350
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    schema3 = TestSchema(field1=1, field2=3)
    schema4 = TestSchema(field1=1)
    schema5 = TestSchema(field1=1)
    assert schema1 == schema2
    assert schema1 != schema3
    assert schema4 == schema5
    assert schema4 != schema1


# Generated at 2022-06-18 12:30:14.762057
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person
        definitions = SchemaDefinitions()

    person = Person(name="John", age=42)
    person_reference = PersonReference(person)
    assert person_reference.to == Person
    assert person_reference.definitions == SchemaDefinitions()
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {"name": "John", "age": 42}


# Generated at 2022-06-18 12:30:20.913128
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["bar"].target is Bar
    assert Foo.fields["bar"].target_string == "Bar"

# Generated at 2022-06-18 12:30:25.071012
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"


# Generated at 2022-06-18 12:30:31.675539
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert len(TestSchema()) == 0
    assert len(TestSchema(a=1)) == 1
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1, b=2, c=3)) == 3


# Generated at 2022-06-18 12:31:33.895788
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class BaseSchema(Schema):
        pass

    class Schema(BaseSchema):
        field = Field()

    assert Schema.fields == {"field": Field()}

    class Schema(BaseSchema):
        field = Field()

    assert Schema.fields == {"field": Field()}

    class Schema(BaseSchema):
        field = Field()

    assert Schema.fields == {"field": Field()}

    class Schema(BaseSchema):
        field = Field()

    assert Schema.fields == {"field": Field()}

    class Schema(BaseSchema):
        field = Field()

    assert Schema.fields == {"field": Field()}

    class Schema(BaseSchema):
        field = Field()

    assert Schema.fields == {"field": Field()}


# Generated at 2022-06-18 12:31:42.974424
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class B(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class C(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class D(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert definitions["B"] == B
    assert definitions["C"] == C
    assert definitions["D"] == D

# Generated at 2022-06-18 12:31:47.106618
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions == definitions
    assert Foo.fields["bar"].target == Bar

# Generated at 2022-06-18 12:31:53.381245
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)
    schema = TestSchema(name='John', age=20)
    assert schema['name'] == 'John'
    assert schema['age'] == 20
    try:
        schema['address']
    except KeyError:
        pass
    else:
        assert False, 'KeyError not raised'


# Generated at 2022-06-18 12:32:04.789282
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()
    class PersonReference(Reference):
        to = Person
    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.validate(person) == person
    assert person_reference.validate({"name": "John", "age": 30}) == person
    assert person_reference.validate({"name": "John"}) == person
    assert person_reference.validate({"name": "John", "age": "30"}) == person
    assert person_reference.validate({"name": "John", "age": "30", "gender": "male"}) == person

# Generated at 2022-06-18 12:32:12.231209
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Baz")

    class Baz(Schema):
        foo = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Foo.fields["bar"], definitions)
    set_definitions(Bar.fields["foo"], definitions)
    set_definitions(Baz.fields["foo"], definitions)
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz
    assert Foo.fields["foo"].definitions == definitions
    assert Foo.fields["bar"].definitions == definitions
    assert Bar.fields["foo"].definitions == definitions

# Generated at 2022-06-18 12:32:22.168087
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c == 3

    schema = TestSchema({"a": 1, "b": 2, "c": 3})
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c == 3

    schema = TestSchema(TestSchema(a=1, b=2, c=3))
    assert schema.a == 1
    assert schema.b == 2
    assert schema.c == 3

    schema = TestSchema(a=1, b=2)
    assert schema.a == 1
    assert schema.b == 2


# Generated at 2022-06-18 12:32:27.432640
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:32:36.803305
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2, c=3)
    assert len(schema) == 3
    assert list(schema) == ['a', 'b', 'c']
    assert list(schema.keys()) == ['a', 'b', 'c']
    assert list(schema.values()) == [1, 2, 3]
    assert list(schema.items()) == [('a', 1), ('b', 2), ('c', 3)]
    assert schema['a'] == 1
    assert schema['b'] == 2
    assert schema['c'] == 3
    assert schema.get('a') == 1
    assert schema.get('b') == 2

# Generated at 2022-06-18 12:32:45.999965
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        field = Field()

    class TestSchema2(Schema):
        field = Reference(to=TestSchema)

    test_schema = TestSchema(field=1)
    test_schema2 = TestSchema2(field=test_schema)
    assert test_schema2.field == test_schema
    assert test_schema2.field.field == 1
    assert test_schema2.field.field == test_schema.field
    assert test_schema2.field.field == test_schema2.field.field
    assert test_schema2.field.field == test_schema2.field.field
    assert test_schema2.field.field == test_schema2.field.field
    assert test_schema2.field.field