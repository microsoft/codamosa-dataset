

# Generated at 2022-06-18 12:24:10.523847
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field(type="string")
        b = Field(type="string")

    a1 = A(a="a", b="b")
    a2 = A(a="a", b="b")
    assert a1 == a2

    a3 = A(a="a")
    assert a1 != a3

    class B(Schema):
        a = Field(type="string")
        b = Field(type="string")

    b1 = B(a="a", b="b")
    assert a1 != b1



# Generated at 2022-06-18 12:24:16.664178
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field_1 = Field(type="string")
        field_2 = Field(type="string")

    schema = TestSchema(field_1="value_1", field_2="value_2")
    assert schema["field_1"] == "value_1"
    assert schema["field_2"] == "value_2"
    try:
        schema["field_3"]
    except KeyError:
        pass
    else:
        assert False, "KeyError not raised"


# Generated at 2022-06-18 12:24:24.307856
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']

    schema = TestSchema(a=1, c=3)
    assert list(schema) == ['a', 'c']

    schema = TestSchema(a=1)
    assert list(schema) == ['a']

    schema = TestSchema()
    assert list(schema) == []



# Generated at 2022-06-18 12:24:30.383062
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()
    class User(Schema):
        person = Reference(Person)
    user = User(person=Person(name="John", age=20))
    assert user.person.name == "John"
    assert user.person.age == 20
    assert user.person == Person(name="John", age=20)
    assert user.person != Person(name="John", age=21)
    assert user.person != Person(name="John", age=20, height=180)
    assert user.person != Person(name="John", age=20, height=180)
    assert user.person != Person(name="John", age=20, height=180)
    assert user.person != Person(name="John", age=20, height=180)
    assert user.person

# Generated at 2022-06-18 12:24:33.391817
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert repr(person) == "Person(age=30, name='John')"


# Generated at 2022-06-18 12:24:38.524998
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"

    person = Person(name="John")
    assert repr(person) == "Person(name='John') [sparse]"



# Generated at 2022-06-18 12:24:50.405788
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
        d = Field(type="string")

    schema = TestSchema({"a": "a", "b": "b", "c": "c", "d": "d"})
    assert schema.a == "a"
    assert schema.b == "b"
    assert schema.c == "c"
    assert schema.d == "d"

    schema = TestSchema(a="a", b="b", c="c", d="d")
    assert schema.a == "a"
    assert schema.b == "b"
    assert schema.c == "c"
    assert schema.d == "d"


# Generated at 2022-06-18 12:24:55.160716
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:25:01.014244
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:25:08.140356
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        is_male = Boolean()
        is_female = Boolean()
        is_human = Boolean()
        is_alien = Boolean()
        is_robot = Boolean()
        is_android = Boolean()
        is_cyborg = Boolean()
        is_terminator = Boolean()
        is_predator = Boolean()
        is_predator_hunter = Boolean()
        is_predator_hunter_2 = Boolean()
        is_predator_hunter_3 = Boolean()
        is_predator_hunter_4 = Boolean()
        is_predator_hunter_5 = Boolean()
        is_predator_hunter_6 = Boolean()
        is_predator_hunter_7 = Boolean()


# Generated at 2022-06-18 12:25:28.092049
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {'name': String(), 'age': Integer()}
    assert Person.__name__ == 'Person'
    assert Person.__module__ == __name__
    assert Person.__qualname__ == 'Person'
    assert Person.__bases__ == (Schema,)
    assert Person.__dict__ == {'__module__': __name__, '__qualname__': 'Person'}
    assert Person.__doc__ is None
    assert Person.__annotations__ == {}
    assert Person.__slots__ == ()
    assert Person.__weakrefoffset__ is None
    assert Person.__dictoffset__ is None
    assert Person.__basicsize__ is None
    assert Person.__itemsize__ is None

# Generated at 2022-06-18 12:25:34.164004
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")

    class B(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")

    class C(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")

    a = A(a="a", b="b", c="c")
    b = B(a="a", b="b", c="c")
    c = C(a="a", b="b", c="c")
    assert a == b
    assert a == c
    assert b == c
    assert a != 1
    assert a != "a"

# Generated at 2022-06-18 12:25:38.158099
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name="John", age=30)
    assert len(p) == 2


# Generated at 2022-06-18 12:25:45.082307
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert len(schema) == 3
    assert list(schema) == ['field1', 'field2', 'field3']


# Generated at 2022-06-18 12:25:48.590903
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30


# Generated at 2022-06-18 12:25:58.842114
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        is_active = Boolean()
        is_staff = Boolean()
        is_superuser = Boolean()
        date_joined = DateTime()
        last_login = DateTime()
        groups = Array(String())
        user_permissions = Array(String())


# Generated at 2022-06-18 12:26:03.820344
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert TestSchema.fields == {"name": Field(type="string"), "age": Field(type="integer")}


# Generated at 2022-06-18 12:26:15.333737
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        name = String()
        age = Integer()
    class TestSchema2(Schema):
        name = String()
        age = Integer()
    class TestSchema3(Schema):
        name = String()
        age = Integer()
    class TestSchema4(Schema):
        name = String()
        age = Integer()
    class TestSchema5(Schema):
        name = String()
        age = Integer()
    class TestSchema6(Schema):
        name = String()
        age = Integer()
    class TestSchema7(Schema):
        name = String()
        age = Integer()
    class TestSchema8(Schema):
        name = String()
        age = Integer()
    class TestSchema9(Schema):
        name = String()

# Generated at 2022-06-18 12:26:19.625056
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions

# Generated at 2022-06-18 12:26:27.356924
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field_1 = Field()
        field_2 = Field()
        field_3 = Field()
    schema = TestSchema(field_1=1, field_2=2)
    assert repr(schema) == "TestSchema(field_1=1, field_2=2) [sparse]"
    schema = TestSchema(field_1=1, field_2=2, field_3=3)
    assert repr(schema) == "TestSchema(field_1=1, field_2=2, field_3=3)"

# Generated at 2022-06-18 12:26:51.803751
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field1 = Reference("field1")
        field2 = Reference("field2")
        field3 = Reference("field3")
        field4 = Reference("field4")
        field5 = Reference("field5")
        field6 = Reference("field6")
        field7 = Reference("field7")
        field8 = Reference("field8")
        field9 = Reference("field9")
        field10 = Reference("field10")
        field11 = Reference("field11")
        field12 = Reference("field12")
        field13 = Reference("field13")
        field14 = Reference("field14")
        field15 = Reference("field15")
        field16 = Reference("field16")
        field17 = Reference("field17")
        field18 = Reference("field18")
        field19 = Reference("field19")

# Generated at 2022-06-18 12:26:59.742243
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()
    class PersonReference(Reference):
        to = Person
    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.to == Person
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {"name": "John", "age": 30}


# Generated at 2022-06-18 12:27:02.660554
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert Person.fields == {"name": Field(type="string"), "age": Field(type="integer")}


# Generated at 2022-06-18 12:27:09.664278
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field1 = Reference("TestSchema")
        field2 = Array(Reference("TestSchema"))
        field3 = Array([Reference("TestSchema")])
        field4 = Object(properties={"field": Reference("TestSchema")})
        field5 = Object(properties={"field": Array(Reference("TestSchema"))})
        field6 = Object(properties={"field": Array([Reference("TestSchema")])})

    definitions = SchemaDefinitions()
    set_definitions(TestSchema, definitions)
    assert TestSchema.field1.definitions is definitions
    assert TestSchema.field2.items.definitions is definitions
    assert TestSchema.field3.items[0].definitions is definitions
    assert TestSchema.field4.properties["field"].definitions is definitions


# Generated at 2022-06-18 12:27:13.094906
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John Smith", age=42)
    assert person["name"] == "John Smith"
    assert person["age"] == 42


# Generated at 2022-06-18 12:27:23.102051
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")

    schema1 = TestSchema(field1="value1", field2="value2")
    schema2 = TestSchema(field1="value1", field2="value2")
    assert schema1 == schema2

    schema3 = TestSchema(field1="value1")
    assert schema1 != schema3

    schema4 = TestSchema(field1="value1", field2="value3")
    assert schema1 != schema4

    schema5 = TestSchema(field1="value1", field2="value2", field3="value3")
    assert schema1 != schema5

    schema6 = TestSchema(field1="value1", field2="value2", field3="value3")
    assert schema

# Generated at 2022-06-18 12:27:28.639586
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2


# Generated at 2022-06-18 12:27:40.608431
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    assert Person.fields == {"name": String()}
    assert Person.__name__ == "Person"
    assert Person.__module__ == __name__

    person = Person(name="John")
    assert person.name == "John"
    assert person.is_sparse is False
    assert person == Person(name="John")
    assert person != Person(name="Jane")
    assert person != "John"
    assert person["name"] == "John"
    assert list(person) == ["name"]
    assert len(person) == 1
    assert repr(person) == "Person(name='John')"

    person = Person(name=None)
    assert person.name is None
    assert person.is_sparse is True

# Generated at 2022-06-18 12:27:50.383381
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 != schema3
    schema4 = TestSchema(field1=1)
    assert schema1 != schema4
    schema5 = TestSchema(field1=1, field2=2, field3=3)
    assert schema1 != schema5


# Generated at 2022-06-18 12:27:55.175887
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema1 = TestSchema(a=1, b=2, c=3)
    schema2 = TestSchema(a=1, b=2, c=3)
    assert schema1 == schema2


# Generated at 2022-06-18 12:28:10.376651
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field2=2, field3=3)"


# Generated at 2022-06-18 12:28:18.690636
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Baz")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:28:25.182904
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert TestSchema.fields == {'a': Field(), 'b': Field(), 'c': Field()}
    assert TestSchema.__name__ == 'TestSchema'
    assert TestSchema.__bases__ == (Schema,)
    assert TestSchema.__dict__ == {'__module__': '__main__', '__doc__': None, 'fields': {'a': Field(), 'b': Field(), 'c': Field()}}


# Generated at 2022-06-18 12:28:30.330232
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()
        is_adult = Boolean()

    person1 = Person(name="John", age=30, is_adult=True)
    person2 = Person(name="John", age=30, is_adult=True)
    person3 = Person(name="John", age=30)
    person4 = Person(name="John", age=30, is_adult=False)

    assert person1 == person2
    assert person1 != person3
    assert person1 != person4


# Generated at 2022-06-18 12:28:41.809081
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field1 = Reference("TestSchema")
        field2 = Array(Reference("TestSchema"))
        field3 = Array(Reference("TestSchema"))
        field4 = Array(Reference("TestSchema"))
        field5 = Array(Reference("TestSchema"))
        field6 = Array(Reference("TestSchema"))
        field7 = Array(Reference("TestSchema"))

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.field1, definitions)
    assert TestSchema.field1.definitions == definitions
    assert TestSchema.field2.items.definitions == definitions
    assert TestSchema.field3.items[0].definitions == definitions
    assert TestSchema.field4.items[0].definitions == definitions

# Generated at 2022-06-18 12:28:53.179148
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42
    assert person == Person(name="John", age=42)
    assert person != Person(name="John", age=43)
    assert person != Person(name="Jane", age=42)
    assert person != Person(name="Jane", age=43)
    assert person != Person(name="John")
    assert person != Person(age=42)
    assert person != Person()
    assert person != {"name": "John", "age": 42}
    assert person != {"name": "John"}
    assert person != {"age": 42}
    assert person != {}
    assert person != "John"
    assert person

# Generated at 2022-06-18 12:28:59.206630
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    assert len(TestSchema()) == 3
    assert len(TestSchema(field1=1)) == 1
    assert len(TestSchema(field1=1, field2=2)) == 2
    assert len(TestSchema(field1=1, field2=2, field3=3)) == 3


# Generated at 2022-06-18 12:29:06.021645
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:29:11.875051
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()
        email = String(format="email")

    person = Person(name="John", age=30, email="john@example.com")
    assert person.name == "John"
    assert person.age == 30
    assert person.email == "john@example.com"


# Generated at 2022-06-18 12:29:15.260820
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert len(schema) == 3


# Generated at 2022-06-18 12:29:35.341754
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1="value1", field3="value3")
    assert list(schema) == ["field1", "field3"]

# Generated at 2022-06-18 12:29:43.511665
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema1 = TestSchema(a=1, b=2, c=3)
    schema2 = TestSchema(a=1, b=2, c=3)
    schema3 = TestSchema(a=1, b=2, c=4)
    schema4 = TestSchema(a=1, b=2)
    schema5 = TestSchema(a=1, b=2, c=3, d=4)

    assert schema1 == schema2
    assert schema1 != schema3
    assert schema1 != schema4
    assert schema1 != schema5


# Generated at 2022-06-18 12:29:54.724710
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.schema import Schema

    class Person(Schema):
        name = String()

    class Address(Schema):
        street = String()
        person = Reference(Person)

    address = Address(street="123 Main St", person=Person(name="John Doe"))
    assert address.street == "123 Main St"
    assert address.person.name == "John Doe"
    assert address.person.is_sparse == False
    assert address.is_sparse == False
    assert address.validate({"street": "123 Main St", "person": {"name": "John Doe"}}) == address
    assert address.validate({"street": "123 Main St", "person": {"name": "John Doe"}}, strict=True) == address

# Generated at 2022-06-18 12:29:59.421359
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    person = Person(name="John", age=30, height=1.75)
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.75


# Generated at 2022-06-18 12:30:03.515226
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field3=3)
    assert list(schema) == ['field1', 'field3']


# Generated at 2022-06-18 12:30:10.624471
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")

    class B(Schema):
        c = Reference("C")

    class C(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A.fields["a"], definitions)
    set_definitions(A.fields["b"], definitions)
    set_definitions(B.fields["c"], definitions)
    assert definitions["A"] == A
    assert definitions["B"] == B
    assert definitions["C"] == C

# Generated at 2022-06-18 12:30:21.320359
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30
    assert person == Person(name="John", age=30)
    assert person != Person(name="John", age=31)
    assert person != Person(name="Jane", age=30)
    assert person != Person(name="Jane", age=31)
    assert person != {"name": "John", "age": 30}
    assert person != {"name": "John", "age": 31}
    assert person != {"name": "Jane", "age": 30}
    assert person != {"name": "Jane", "age": 31}
    assert person != {"name": "John"}

# Generated at 2022-06-18 12:30:30.233966
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2)"

    schema = TestSchema(field1=1)
    assert repr(schema) == "TestSchema(field1=1) [sparse]"

    schema = TestSchema()
    assert repr(schema) == "TestSchema() [sparse]"



# Generated at 2022-06-18 12:30:36.843633
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    assert schema1 == schema2
    schema2 = TestSchema(field1=1, field2=2, field3=4)
    assert schema1 != schema2


# Generated at 2022-06-18 12:30:42.778186
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Baz")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert isinstance(Foo.fields["foo"].target, type)
    assert isinstance(Bar.fields["bar"].target, type)
    assert isinstance(Baz.fields["baz"].target, type)

# Generated at 2022-06-18 12:31:55.914241
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()
    person1 = Person(name="John", age=30)
    person2 = Person(name="John", age=30)
    assert person1 == person2


# Generated at 2022-06-18 12:32:04.033115
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")
        field3 = Field(type="string")

    test_schema = TestSchema(field1="value1", field2="value2")
    assert test_schema["field1"] == "value1"
    assert test_schema["field2"] == "value2"
    assert test_schema["field3"] == None
    assert test_schema["field4"] == None


# Generated at 2022-06-18 12:32:11.549989
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()

    p1 = Person(name="John", age=30)
    p2 = Person(name="John", age=30)
    p3 = Person(name="John", age=31)
    p4 = Person(name="Mary", age=30)
    p5 = Person(name="John")
    p6 = Person(age=30)
    p7 = Person()

    assert p1 == p2
    assert p1 != p3
    assert p1 != p4
    assert p1 != p5
    assert p1 != p6
    assert p1 != p7

    assert p5 == p6
    assert p5 != p7

    assert p7 == p7



# Generated at 2022-06-18 12:32:14.925368
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions is definitions

# Generated at 2022-06-18 12:32:17.444554
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        test_field = Field()
    test_schema = TestSchema(test_field=1)
    assert repr(test_schema) == 'TestSchema(test_field=1)'


# Generated at 2022-06-18 12:32:23.739879
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
    p = Person(name="John", age=20)
    assert p.name == "John"
    assert p.age == 20
    assert repr(p) == "Person(name='John', age=20)"
    assert p == Person(name="John", age=20)
    assert p != Person(name="John", age=21)
    assert p != Person(name="John", age=20, gender="male")
    assert p != Person(name="John", age=20, gender="male")
    assert p != Person(name="John", age=20, gender="male")
    assert p != Person(name="John", age=20, gender="male")
    assert p != Person(name="John", age=20, gender="male")

# Generated at 2022-06-18 12:32:28.624443
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer()
        address = String(max_length=20)
        phone = String(max_length=10)
    test_schema = TestSchema(name='John', age=20, address='New York', phone='1234567890')
    assert len(test_schema) == 4


# Generated at 2022-06-18 12:32:33.803037
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()
    class Company(Schema):
        name = String()
        employees = Array(items=Reference(Person))
    company = Company(name="Acme", employees=[Person(name="John", age=42)])
    assert company.employees[0].name == "John"
    assert company.employees[0].age == 42


# Generated at 2022-06-18 12:32:39.183753
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")

    test_schema = TestSchema(field1="test1", field2="test2")
    assert test_schema.field1 == "test1"
    assert test_schema.field2 == "test2"


# Generated at 2022-06-18 12:32:47.865280
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")

    schema1 = TestSchema(field1="value1", field2="value2")
    schema2 = TestSchema(field1="value1", field2="value2")
    assert schema1 == schema2

    schema1 = TestSchema(field1="value1", field2="value2")
    schema2 = TestSchema(field1="value1", field2="value3")
    assert not schema1 == schema2

    schema1 = TestSchema(field1="value1", field2="value2")
    schema2 = TestSchema(field1="value1")
    assert not schema1 == schema2

    schema1 = TestSchema(field1="value1")
    schema2 = TestSche