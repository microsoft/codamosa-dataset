

# Generated at 2022-06-18 12:24:06.677782
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    test_schema = TestSchema(a=1, b=2)
    assert repr(test_schema) == "TestSchema(a=1, b=2) [sparse]"


# Generated at 2022-06-18 12:24:10.473956
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:24:19.545189
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field = Field()
    assert TestSchema.fields == {'field': TestSchema.field}
    assert TestSchema.field.parent == TestSchema
    assert TestSchema.field.name == 'field'
    assert TestSchema.field.path == 'field'
    assert TestSchema.field.full_path == 'field'
    assert TestSchema.field.root == TestSchema.field
    assert TestSchema.field.schema == TestSchema
    assert TestSchema.field.schema_path == ''
    assert TestSchema.field.schema_full_path == ''
    assert TestSchema.field.schema_root == TestSchema.field
    assert TestSchema.field.schema_root.schema == TestSchema
    assert TestSche

# Generated at 2022-06-18 12:24:22.126746
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass___new__(Schema):
        pass
    assert TestSchemaMetaclass___new__.fields == {}


# Generated at 2022-06-18 12:24:27.540036
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Qux")

    class Qux(Schema):
        qux = Reference("Qux")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz
    assert definitions["Qux"] is Qux

# Generated at 2022-06-18 12:24:38.720070
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
    assert TestSchema.fields == {'name': String(), 'age': Integer()}
    assert TestSchema.make_validator() == Object(properties={'name': String(), 'age': Integer()}, required=['name', 'age'], additional_properties=None)
    assert TestSchema.validate({'name': 'John', 'age': 30}) == TestSchema(name='John', age=30)
    assert TestSchema.validate_or_error({'name': 'John', 'age': 30}) == ValidationResult(value=TestSchema(name='John', age=30), error=None)
    assert TestSchema(name='John', age=30).is_sparse == False

# Generated at 2022-06-18 12:24:50.574130
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    person = Person(name="John Doe", age=42)
    assert person.name == "John Doe"
    assert person.age == 42
    assert person == Person(name="John Doe", age=42)
    assert person != Person(name="Jane Doe", age=42)
    assert person != Person(name="John Doe", age=43)
    assert person != Person(name="Jane Doe", age=43)
    assert person != {"name": "John Doe", "age": 42}
    assert person != {"name": "Jane Doe", "age": 42}
    assert person != {"name": "John Doe", "age": 43}
    assert person != {"name": "Jane Doe", "age": 43}
    assert person

# Generated at 2022-06-18 12:25:00.275034
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
        field5 = Field()
        field6 = Field()
        field7 = Field()
        field8 = Field()
        field9 = Field()
        field10 = Field()
        field11 = Field()
        field12 = Field()
        field13 = Field()
        field14 = Field()
        field15 = Field()
        field16 = Field()
        field17 = Field()
        field18 = Field()
        field19 = Field()
        field20 = Field()
        field21 = Field()
        field22 = Field()
        field23 = Field()
        field24 = Field()
        field25 = Field()
        field26 = Field()
        field27 = Field()


# Generated at 2022-06-18 12:25:05.116996
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert isinstance(Foo.fields["bar"].target, type)
    assert isinstance(Foo.fields["bar"].target.fields["baz"].target, type)

# Generated at 2022-06-18 12:25:09.296176
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="Fred", age=42)
    assert person.name == "Fred"
    assert person.age == 42
    assert person == Person(name="Fred", age=42)
    assert person != Person(name="Fred", age=43)
    assert person != Person(name="Fred", age=42, height=180)
    assert person != Person(name="Fred", age=42, height=180, weight=80)
    assert person != Person(name="Fred", age=42, height=180, weight=80, hair_color="brown")
    assert person != Person(name="Fred", age=42, height=180, weight=80, hair_color="brown", eye_color="blue")

# Generated at 2022-06-18 12:25:28.182130
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()
    p = Person(name="John", age=42)
    assert p.name == "John"
    assert p.age == 42
    assert p == Person(name="John", age=42)
    assert p != Person(name="John", age=43)
    assert p != Person(name="John", age=42, foo="bar")
    assert p != Person(name="John", age=42, foo="bar")
    assert p != Person(name="John", age=42, foo="bar")
    assert p != Person(name="John", age=42, foo="bar")
    assert p != Person(name="John", age=42, foo="bar")

# Generated at 2022-06-18 12:25:36.494275
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    set_definitions(Baz.fields["baz"], definitions)

    assert Foo.fields["foo"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:25:42.141082
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2


# Generated at 2022-06-18 12:25:46.231132
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        field = Reference("TestSchema")
    test_schema = TestSchema()
    assert test_schema.field.validate(test_schema) == test_schema


# Generated at 2022-06-18 12:25:49.720530
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
    s1 = TestSchema(a=1, b=2)
    s2 = TestSchema(a=1, b=2)
    assert s1 == s2
    s3 = TestSchema(a=1, b=3)
    assert s1 != s3
    s4 = TestSchema(a=1)
    assert s1 != s4
    s5 = TestSchema(b=2)
    assert s1 != s5
    s6 = TestSchema()
    assert s1 != s6


# Generated at 2022-06-18 12:25:56.158244
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        is_active = Boolean()

    person = Person(name="John", age=30, height=1.75, weight=80.5, is_active=True)
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.75
    assert person.weight == 80.5
    assert person.is_active == True


# Generated at 2022-06-18 12:26:01.515393
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert list(schema) == ['field1', 'field2', 'field3']


# Generated at 2022-06-18 12:26:13.684164
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    assert schema1 == schema2

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=4)
    assert schema1 != schema2

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 != schema2

    schema1 = Test

# Generated at 2022-06-18 12:26:25.264706
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        height = Float(minimum=0)
        weight = Float(minimum=0)
        is_active = Boolean()

    person = Person(name="John", age=20, height=1.8, weight=80, is_active=True)
    assert person.name == "John"
    assert person.age == 20
    assert person.height == 1.8
    assert person.weight == 80
    assert person.is_active == True
    assert person.is_sparse == False
    assert repr(person) == "Person(name='John', age=20, height=1.8, weight=80, is_active=True)"

# Generated at 2022-06-18 12:26:30.439341
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    assert len(TestSchema()) == 0
    assert len(TestSchema(a=1)) == 1
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1, b=2, c=3)) == 3


# Generated at 2022-06-18 12:26:39.738709
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions

# Generated at 2022-06-18 12:26:49.348377
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert len(schema) == 3
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2
    schema = TestSchema(field1=1)
    assert len(schema) == 1
    schema = TestSchema()
    assert len(schema) == 0


# Generated at 2022-06-18 12:26:57.872738
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 != schema3
    schema4 = TestSchema(field1=1)
    assert schema1 != schema4
    schema5 = TestSchema(field1=1, field2=2, field3=3)
    assert schema1 != schema5


# Generated at 2022-06-18 12:27:01.234788
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:27:08.647349
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:27:12.448234
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
    p = Person(name="John", age=30, height=1.8)
    assert list(p) == ["name", "age", "height"]


# Generated at 2022-06-18 12:27:17.660304
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field3=3) [sparse]"


# Generated at 2022-06-18 12:27:21.881686
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field3=3) [sparse]"



# Generated at 2022-06-18 12:27:35.192883
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        name = String()
        age = Integer()
    class TestSchema2(Schema):
        name = String()
        age = Integer()
    class TestSchema3(Schema):
        name = String()
        age = Integer()
    class TestSchema4(Schema):
        name = String()
        age = Integer()
    class TestSchema5(Schema):
        name = String()
        age = Integer()
    class TestSchema6(Schema):
        name = String()
        age = Integer()
    class TestSchema7(Schema):
        name = String()
        age = Integer()
    class TestSchema8(Schema):
        name = String()
        age = Integer()
    class TestSchema9(Schema):
        name = String()

# Generated at 2022-06-18 12:27:39.065395
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        field = Reference("TestSchema")
    test_schema = TestSchema()
    test_schema.field = test_schema
    assert test_schema.field == test_schema


# Generated at 2022-06-18 12:28:00.553898
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']

    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']

    schema = TestSchema(a=1)
    assert list(schema) == ['a']

    schema = TestSchema()
    assert list(schema) == []



# Generated at 2022-06-18 12:28:06.723545
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="Fred", age=42)
    assert person.name == "Fred"
    assert person.age == 42
    assert person == Person(name="Fred", age=42)
    assert person != Person(name="Fred", age=43)
    assert person != Person(name="Frederick", age=42)
    assert person != Person(name="Frederick", age=43)
    assert person != Person(name="Fred", age=42, height=1.8)
    assert person != Person(name="Fred", age=42, height=1.8, weight=80)
    assert person != Person(name="Fred", age=42, height=1.8, weight=80, hair="brown")

# Generated at 2022-06-18 12:28:11.007121
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        field = Reference("TestSchema")
    test_schema = TestSchema()
    assert test_schema.field.validate(None) == None
    assert test_schema.field.validate(test_schema) == test_schema


# Generated at 2022-06-18 12:28:21.761977
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float(minimum=0.0)
        weight = Float(minimum=0.0)

    person = Person(name="John", age=30, height=1.75, weight=75.0)
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.75
    assert person.weight == 75.0
    assert person.is_sparse == False
    assert repr(person) == "Person(name='John', age=30, height=1.75, weight=75.0)"

    person = Person({"name": "John", "age": 30, "height": 1.75, "weight": 75.0})

# Generated at 2022-06-18 12:28:30.309753
# Unit test for constructor of class Reference

# Generated at 2022-06-18 12:28:33.539473
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import String
    class Person(Schema):
        name = String()
    person = Person(name="John")
    assert person["name"] == "John"


# Generated at 2022-06-18 12:28:43.475092
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    s1 = TestSchema(a=1, b=2, c=3)
    s2 = TestSchema(a=1, b=2, c=3)
    assert s1 == s2
    s3 = TestSchema(a=1, b=2)
    assert s1 != s3
    s4 = TestSchema(a=1, b=2, c=4)
    assert s1 != s4
    s5 = TestSchema(a=1, b=2, c=3, d=4)
    assert s1 != s5


# Generated at 2022-06-18 12:28:50.135306
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")

    class B(Schema):
        a = Reference("C")

    class C(Schema):
        a = Reference("A")

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert definitions["A"] is A
    assert definitions["B"] is B
    assert definitions["C"] is C

# Generated at 2022-06-18 12:28:55.528467
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")

    class B(Schema):
        a = Reference("C")

    class C(Schema):
        a = Reference("A")

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert definitions["A"] == A
    assert definitions["B"] == B
    assert definitions["C"] == C

# Generated at 2022-06-18 12:29:00.510797
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        gender = Field(type="string")

    schema = TestSchema(name="John", age=30, gender="Male")
    assert repr(schema) == "TestSchema(name='John', age=30, gender='Male')"


# Generated at 2022-06-18 12:30:05.749749
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:30:16.459774
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()
        c = Field()

    class B(A):
        d = Field()
        e = Field()

    class C(B):
        f = Field()
        g = Field()

    class D(C):
        h = Field()
        i = Field()

    assert D.fields == {
        "a": A.fields["a"],
        "b": A.fields["b"],
        "c": A.fields["c"],
        "d": B.fields["d"],
        "e": B.fields["e"],
        "f": C.fields["f"],
        "g": C.fields["g"],
        "h": D.fields["h"],
        "i": D.fields["i"],
    }



# Generated at 2022-06-18 12:30:29.003397
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
    assert TestSchema(a="a", b="b") == TestSchema(a="a", b="b")
    assert TestSchema(a="a", b="b") != TestSchema(a="a", b="c")
    assert TestSchema(a="a", b="b") != TestSchema(a="a")
    assert TestSchema(a="a", b="b") != TestSchema(a="a", b="b", c="c")
    assert TestSchema(a="a", b="b") != TestSchema(a="a", b="b", c="c")

# Generated at 2022-06-18 12:30:36.753954
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")

    class B(Schema):
        c = Reference("D")

    class C(Schema):
        d = Reference("D")

    class D(Schema):
        e = Reference("E")

    class E(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert definitions["B"] == B
    assert definitions["C"] == C
    assert definitions["D"] == D
    assert definitions["E"] == E

# Generated at 2022-06-18 12:30:40.923377
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    test_schema = TestSchema(field1=1, field2=2, field3=3)
    assert list(test_schema) == ['field1', 'field2', 'field3']


# Generated at 2022-06-18 12:30:49.748644
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()

    person1 = Person(name="John", age=30)
    person2 = Person(name="John", age=30)
    assert person1 == person2
    person3 = Person(name="John", age=31)
    assert person1 != person3
    person4 = Person(name="John")
    assert person1 != person4
    person5 = Person(age=30)
    assert person1 != person5
    person6 = Person()
    assert person1 != person6
    person7 = Person(name="John", age=30, foo="bar")
    assert person1 != person7


# Generated at 2022-06-18 12:30:53.644725
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:30:55.892248
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:31:01.778286
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2, c=3)
    assert list(schema) == ['a', 'b', 'c']

    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']

    schema = TestSchema(a=1)
    assert list(schema) == ['a']

    schema = TestSchema()
    assert list(schema) == []


# Generated at 2022-06-18 12:31:12.113838
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field(type="string")
        b = Field(type="string")

    foo1 = Foo(a="a", b="b")
    foo2 = Foo(a="a", b="b")
    foo3 = Foo(a="a", b="c")
    foo4 = Foo(a="a")
    foo5 = Foo(b="b")
    foo6 = Foo()

    assert foo1 == foo2
    assert foo1 != foo3
    assert foo1 != foo4
    assert foo1 != foo5
    assert foo1 != foo6
    assert foo4 == foo5
    assert foo4 != foo6
    assert foo5 != foo6
    assert foo6 == foo6

# Generated at 2022-06-18 12:32:08.102977
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1, b=2, c=3)) == 3
    assert len(TestSchema(a=1, b=2, c=3, d=4)) == 3


# Generated at 2022-06-18 12:32:13.825858
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
    assert repr(TestSchema(a="a", b="b")) == "TestSchema(a='a', b='b')"
    assert repr(TestSchema(a="a", b="b", c="c")) == "TestSchema(a='a', b='b', c='c')"
    assert repr(TestSchema(a="a", b="b", c="c")) == "TestSchema(a='a', b='b', c='c')"
    assert repr(TestSchema(a="a", b="b", c="c")) == "TestSchema(a='a', b='b', c='c')"

# Generated at 2022-06-18 12:32:16.619835
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ["field1", "field2"]


# Generated at 2022-06-18 12:32:19.303390
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:32:23.033911
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")

    class B(Schema):
        c = Reference("C")

    class C(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert A.a.definitions is definitions
    assert A.b.definitions is definitions
    assert B.c.definitions is definitions
    assert C.definitions is None

# Generated at 2022-06-18 12:32:25.932657
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert len(person) == 2
    assert list(person) == ["name", "age"]



# Generated at 2022-06-18 12:32:32.787805
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class B(Schema):
        a = Reference("C")
        b = Reference("D")

    class C(Schema):
        a = Reference("D")

    class D(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert definitions["A"] == A
    assert definitions["B"] == B
    assert definitions["C"] == C
    assert definitions["D"] == D

# Generated at 2022-06-18 12:32:42.526267
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Number(minimum=0)

    person = Person(name="John", age=20, height=1.75)
    assert person.name == "John"
    assert person.age == 20
    assert person.height == 1.75

    person = Person({"name": "John", "age": 20, "height": 1.75})
    assert person.name == "John"
    assert person.age == 20
    assert person.height == 1.75

    person = Person(name="John", age=20)
    assert person.name == "John"
    assert person.age == 20
    assert person.height is None


# Generated at 2022-06-18 12:32:48.408739
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field2=2, field3=3)"


# Generated at 2022-06-18 12:32:58.263030
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field(type="integer")
        b = Field(type="string")

    foo1 = Foo(a=1, b="b")
    foo2 = Foo(a=1, b="b")
    assert foo1 == foo2
    assert not (foo1 != foo2)

    foo3 = Foo(a=2, b="b")
    assert foo1 != foo3
    assert not (foo1 == foo3)

    foo4 = Foo(a=1, b="c")
    assert foo1 != foo4
    assert not (foo1 == foo4)

    foo5 = Foo(a=1)
    assert foo1 != foo5
    assert not (foo1 == foo5)

    foo6 = Foo(b="b")
    assert foo1 != foo6