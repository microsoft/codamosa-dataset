

# Generated at 2022-06-18 12:24:10.329600
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1, b=2, c=3)) == 3
    assert len(TestSchema(a=1, b=2, c=3, d=4)) == 3


# Generated at 2022-06-18 12:24:18.142246
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {"name": String(), "age": Integer()}
    assert Person.__name__ == "Person"
    assert Person.__module__ == __name__
    assert Person.__qualname__ == "test_SchemaMetaclass___new__.<locals>.Person"
    assert Person.__bases__ == (Schema,)
    assert Person.__dict__ == {
        "__module__": __name__,
        "__qualname__": "test_SchemaMetaclass___new__.<locals>.Person",
        "fields": {"name": String(), "age": Integer()},
    }


# Generated at 2022-06-18 12:24:22.078482
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:24:25.320418
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name='John', age=30)
    assert repr(person) == "Person(name='John', age=30)"


# Generated at 2022-06-18 12:24:28.686484
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        id = Integer()
        name = String()

    class Comment(Schema):
        id = Integer()
        user = Reference(User)

    comment = Comment.validate({"id": 1, "user": {"id": 2, "name": "John"}})
    assert comment.user.id == 2
    assert comment.user.name == "John"


# Generated at 2022-06-18 12:24:35.440860
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    assert len(TestSchema()) == 0
    assert len(TestSchema(field1=1)) == 1
    assert len(TestSchema(field1=1, field2=2)) == 2
    assert len(TestSchema(field1=1, field2=2, field3=3)) == 3


# Generated at 2022-06-18 12:24:47.447821
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
        d = Field(type="string")
        e = Field(type="string")
        f = Field(type="string")
        g = Field(type="string")
        h = Field(type="string")
        i = Field(type="string")
        j = Field(type="string")
        k = Field(type="string")
        l = Field(type="string")
        m = Field(type="string")
        n = Field(type="string")
        o = Field(type="string")
        p = Field(type="string")
        q = Field(type="string")
        r = Field(type="string")
        s = Field(type="string")

# Generated at 2022-06-18 12:24:52.571599
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()
        gender = String()

    class User(Schema):
        person = Reference(Person)

    user = User(person={"name": "John", "age": 30, "gender": "male"})
    assert user.person.name == "John"
    assert user.person.age == 30
    assert user.person.gender == "male"


# Generated at 2022-06-18 12:24:57.121954
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions == definitions
    assert Foo.fields["bar"].target == Bar

# Generated at 2022-06-18 12:25:05.567184
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        bar = Field(type="string")
        baz = Field(type="string")

    foo = Foo(bar="bar", baz="baz")
    assert foo.bar == "bar"
    assert foo.baz == "baz"

    foo = Foo({"bar": "bar", "baz": "baz"})
    assert foo.bar == "bar"
    assert foo.baz == "baz"

    foo = Foo(bar="bar")
    assert foo.bar == "bar"
    assert foo.baz == ""

    foo = Foo(bar="bar", baz="baz", qux="qux")
    assert foo.bar == "bar"
    assert foo.baz == "baz"
    assert foo.qux == "qux"

    foo = Foo

# Generated at 2022-06-18 12:25:35.535075
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()

    p = Person(name="John", age=30)
    assert repr(p) == "Person(name='John', age=30)"
    p = Person(name="John")
    assert repr(p) == "Person(name='John') [sparse]"
    p = Person()
    assert repr(p) == "Person() [sparse]"


# Generated at 2022-06-18 12:25:48.541559
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        height = Float()
        is_active = Boolean()
        created_at = DateTime()
        friends = Array(items=Reference("Person"))
        parent = Reference("Person")

    person = Person(
        name="John Doe",
        age=42,
        height=1.83,
        is_active=True,
        created_at=datetime.datetime(2019, 1, 1, 12, 0, 0),
        friends=[],
        parent=None,
    )
    assert person.name == "John Doe"
    assert person.age == 42
    assert person.height == 1.83
    assert person.is_active is True
    assert person.created_at == datetime

# Generated at 2022-06-18 12:25:58.786964
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
    assert TestSchema.fields == {'name': String(), 'age': Integer()}
    assert TestSchema.__name__ == 'TestSchema'
    assert TestSchema.__bases__ == (Schema,)
    assert TestSchema.__dict__ == {'__module__': '__main__', '__doc__': None}
    assert TestSchema.__qualname__ == 'TestSchema'
    assert TestSchema.__annotations__ == {}
    assert TestSchema.__init__.__annotations__ == {'args': typing.Any, 'kwargs': typing.Any}
    assert TestSchema.__init__.__defaults__ == ()

# Generated at 2022-06-18 12:26:10.594418
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2)
    schema4 = TestSchema(field1=1, field2=2, field3=4)
    schema5 = TestSchema(field1=1, field2=2, field3=3, field4=4)

    assert schema1 == schema2
    assert schema1 != schema3
    assert schema1 != schema4
    assert schema1 != schema5


# Generated at 2022-06-18 12:26:22.211447
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()
        c = Field()

    class B(A):
        d = Field()
        e = Field()

    class C(B):
        f = Field()
        g = Field()

    assert C.fields == {
        "a": A.fields["a"],
        "b": A.fields["b"],
        "c": A.fields["c"],
        "d": B.fields["d"],
        "e": B.fields["e"],
        "f": C.fields["f"],
        "g": C.fields["g"],
    }


# Generated at 2022-06-18 12:26:32.081932
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()
    assert Person(name="John", age=30) == Person(name="John", age=30)
    assert Person(name="John", age=30) != Person(name="John", age=31)
    assert Person(name="John", age=30) != Person(name="Jane", age=30)
    assert Person(name="John", age=30) != Person(name="John")
    assert Person(name="John", age=30) != Person(age=30)
    assert Person(name="John", age=30) != Person()
    assert Person(name="John", age=30) != Person(name="John", age=30, height=180)

# Generated at 2022-06-18 12:26:39.881462
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = MySchema(a=1, b=2, c=3)
    assert repr(schema) == "MySchema(a=1, b=2, c=3)"

    schema = MySchema(a=1, c=3)
    assert repr(schema) == "MySchema(a=1, c=3) [sparse]"

    schema = MySchema(a=1, b=2, c=3)
    schema.a = None
    assert repr(schema) == "MySchema(b=2, c=3) [sparse]"



# Generated at 2022-06-18 12:26:51.793926
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()
        alive = Boolean()
        address = String()
        phone = String()
        email = String()
        website = String()
        friends = Array(String())
        parents = Array(String())
        siblings = Array(String())
        children = Array(String())


# Generated at 2022-06-18 12:26:54.096198
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}


# Generated at 2022-06-18 12:26:59.277890
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2


# Generated at 2022-06-18 12:27:21.040672
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    test_schema = TestSchema(field1=1, field2=2)
    assert test_schema['field1'] == 1
    assert test_schema['field2'] == 2
    try:
        test_schema['field3']
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-18 12:27:22.574424
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        pass
    assert TestSchema.fields == {}


# Generated at 2022-06-18 12:27:33.231930
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    schema3 = TestSchema(field1=1, field2=3)
    schema4 = TestSchema(field1=1)
    schema5 = TestSchema(field1=1)
    assert schema1 == schema2
    assert schema1 != schema3
    assert schema4 == schema5
    assert schema4 != schema1
    assert schema4 != schema3


# Generated at 2022-06-18 12:27:38.652530
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:27:40.505100
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        pass
    assert repr(TestSchema()) == 'TestSchema()'


# Generated at 2022-06-18 12:27:48.821005
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    set_definitions(Bar.fields["baz"], definitions)
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:27:59.049062
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    person = Person(name="John Doe", age=42)
    assert person.name == "John Doe"
    assert person.age == 42
    assert person == Person(name="John Doe", age=42)
    assert person != Person(name="Jane Doe", age=42)
    assert person != Person(name="John Doe", age=43)
    assert person != Person(name="Jane Doe", age=43)
    assert person != 42
    assert person != {"name": "John Doe", "age": 42}
    assert person != {"name": "John Doe", "age": 42, "extra": "value"}
    assert person != {"name": "John Doe"}
    assert person != {"age": 42}
    assert person

# Generated at 2022-06-18 12:28:01.710942
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestReference")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions

# Generated at 2022-06-18 12:28:13.045526
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {'name': String(), 'age': Integer()}
    assert Person.__name__ == 'Person'
    assert Person.__module__ == __name__
    assert Person.__qualname__ == 'test_SchemaMetaclass___new__.<locals>.Person'
    assert Person.__bases__ == (Schema,)
    assert Person.__dict__ == {'__module__': __name__, '__qualname__': 'test_SchemaMetaclass___new__.<locals>.Person', 'fields': {'name': String(), 'age': Integer()}}
    assert Person.__doc__ == None
    assert Person.__annotations__ == {}
    assert Person.__slots__ == ()
    assert Person.__init

# Generated at 2022-06-18 12:28:20.338869
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    set_definitions(Bar.fields["baz"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:28:42.303375
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name="John", age=30)
    assert list(p) == ["name", "age"]


# Generated at 2022-06-18 12:28:53.382694
# Unit test for constructor of class Reference
def test_Reference():
    class User(Schema):
        name = String()
        age = Integer()
    class Post(Schema):
        title = String()
        author = Reference(User)
    post = Post(title="Hello World", author=User(name="John", age=20))
    assert post.author.name == "John"
    assert post.author.age == 20
    assert post.author.__class__.__name__ == "User"
    assert post.author.__class__.__bases__[0].__name__ == "Schema"
    assert post.author.__class__.__bases__[0].__bases__[0].__name__ == "Mapping"

# Generated at 2022-06-18 12:28:57.144558
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    class Person(Schema):
        name = String()
    class Address(Schema):
        person = Reference(Person)
    address = Address(person=Person(name="John"))
    assert address.person.name == "John"


# Generated at 2022-06-18 12:29:01.719378
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.schema import Schema

    class Person(Schema):
        name = String()

    class Address(Schema):
        person = Reference(Person)

    address = Address(person=Person(name="John"))
    assert address.person.name == "John"


# Generated at 2022-06-18 12:29:06.483826
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        foo = Field(type="string")
        bar = Field(type="string")
    schema = TestSchema(foo="foo", bar="bar")
    assert repr(schema) == "TestSchema(foo='foo', bar='bar')"


# Generated at 2022-06-18 12:29:16.912280
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")

    schema = TestSchema(a="a", b="b")
    assert schema["a"] == "a"
    assert schema["b"] == "b"
    assert schema.a == "a"
    assert schema.b == "b"
    assert schema.is_sparse == False
    assert schema.__repr__() == "TestSchema(a='a', b='b')"
    assert schema.__eq__(schema) == True
    assert schema.__len__() == 2
    assert schema.__iter__() == iter(["a", "b"])
    assert schema.__getitem__("a") == "a"
    assert schema.__getitem__("b") == "b"

# Generated at 2022-06-18 12:29:20.997611
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2
    assert len(schema.fields) == 3


# Generated at 2022-06-18 12:29:24.751006
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:29:30.228160
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 != schema3


# Generated at 2022-06-18 12:29:35.382209
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
    assert A.fields == {'a': Field()}
    assert A.__name__ == 'A'
    assert A.__bases__ == (Schema,)
    assert A.__dict__ == {'__module__': '__main__', '__qualname__': 'A'}


# Generated at 2022-06-18 12:29:57.909023
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field = Field()
    schema = TestSchema(field=1)
    assert schema['field'] == 1


# Generated at 2022-06-18 12:30:07.412643
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass___new__(Schema):
        pass
    assert TestSchemaMetaclass___new__.fields == {}
    class TestSchemaMetaclass___new__(Schema):
        a = Field()
    assert TestSchemaMetaclass___new__.fields == {'a': Field()}
    class TestSchemaMetaclass___new__(Schema):
        a = Field()
        b = Field()
    assert TestSchemaMetaclass___new__.fields == {'a': Field(), 'b': Field()}
    class TestSchemaMetaclass___new__(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert TestSchemaMetaclass___new__.fields == {'a': Field(), 'b': Field(), 'c': Field()}

# Generated at 2022-06-18 12:30:10.515453
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = String()
        age = Integer()

    class Address(Schema):
        street = String()
        city = String()
        country = String()

    class PersonWithAddress(Schema):
        person = Reference(Person)
        address = Reference(Address)

    definitions = SchemaDefinitions()
    set_definitions(PersonWithAddress, definitions)
    assert definitions["Person"] == Person
    assert definitions["Address"] == Address

# Generated at 2022-06-18 12:30:13.809228
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.field, definitions)
    assert TestSchema.field.definitions == definitions

# Generated at 2022-06-18 12:30:25.651561
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30
    assert person == Person(name="John", age=30)
    assert person != Person(name="John", age=31)
    assert person != Person(name="John", age=30, height=1.8)
    assert person != Person(name="John", age=30, height=1.8)
    assert person != Person(name="John", age=30, height=1.8)
    assert person != Person(name="John", age=30, height=1.8)
    assert person != Person(name="John", age=30, height=1.8)

# Generated at 2022-06-18 12:30:36.686699
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestReference")

    class TestReference(Schema):
        field = Reference("TestReference2")

    class TestReference2(Schema):
        field = Reference("TestReference3")

    class TestReference3(Schema):
        field = Reference("TestReference4")

    class TestReference4(Schema):
        field = Reference("TestReference5")

    class TestReference5(Schema):
        field = Reference("TestReference6")

    class TestReference6(Schema):
        field = Reference("TestReference7")

    class TestReference7(Schema):
        field = Reference("TestReference8")

    class TestReference8(Schema):
        field = Reference("TestReference9")

    class TestReference9(Schema):
        field = Reference("TestReference10")

   

# Generated at 2022-06-18 12:30:46.747493
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type=str)
        b = Field(type=int)
        c = Field(type=str, default="foo")

    schema = TestSchema({"a": "hello", "b": 1})
    assert schema.a == "hello"
    assert schema.b == 1
    assert schema.c == "foo"

    schema = TestSchema(a="hello", b=1)
    assert schema.a == "hello"
    assert schema.b == 1
    assert schema.c == "foo"

    schema = TestSchema({"a": "hello", "b": 1, "c": "bar"})
    assert schema.a == "hello"
    assert schema.b == 1
    assert schema.c == "bar"


# Generated at 2022-06-18 12:30:50.025895
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name='John', age=30)
    assert p.name == 'John'
    assert p.age == 30


# Generated at 2022-06-18 12:30:59.200868
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")

    schema = TestSchema(a="a", b="b")
    assert schema.a == "a"
    assert schema.b == "b"

    schema = TestSchema({"a": "a", "b": "b"})
    assert schema.a == "a"
    assert schema.b == "b"

    schema = TestSchema(a="a")
    assert schema.a == "a"
    assert schema.b is None

    schema = TestSchema({"a": "a"})
    assert schema.a == "a"
    assert schema.b is None

    schema = TestSchema(b="b")
    assert schema.a is None
    assert schema.b == "b"

# Generated at 2022-06-18 12:31:10.515078
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name="John", age=30)
    assert p.name == "John"
    assert p.age == 30
    assert p == Person(name="John", age=30)
    assert p != Person(name="John", age=31)
    assert p != Person(name="John", age=30, height=180)
    assert p != Person(name="John", age=30, height=180, weight=80)
    assert p != Person(name="John", age=30, height=180, weight=80, gender="male")
    assert p != Person(name="John", age=30, height=180, weight=80, gender="male", hair_color="brown")

# Generated at 2022-06-18 12:31:57.347259
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:32:05.558229
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()
    p1 = Person(name="John", age=30)
    p2 = Person(name="John", age=30)
    assert p1 == p2
    p3 = Person(name="John", age=31)
    assert p1 != p3
    p4 = Person(name="John")
    assert p1 != p4
    p5 = Person(age=30)
    assert p1 != p5
    p6 = Person()
    assert p1 != p6


# Generated at 2022-06-18 12:32:08.409969
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()

    p = Person(name="John", age=30, height=1.8, weight=80.5)
    assert list(p) == ["name", "age", "height", "weight"]


# Generated at 2022-06-18 12:32:12.367562
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = String()
        field2 = String()
        field3 = String()

    schema = TestSchema(field1="value1", field2="value2")
    assert repr(schema) == "TestSchema(field1='value1', field2='value2') [sparse]"



# Generated at 2022-06-18 12:32:15.362314
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
    schema = TestSchema(name='John', age=25)
    assert repr(schema) == "TestSchema(name='John', age=25)"


# Generated at 2022-06-18 12:32:16.855095
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class A(Schema):
        a = Field()
        b = Field()
        c = Field()
    a = A(a=1, b=2)
    assert list(a) == ['a', 'b']


# Generated at 2022-06-18 12:32:19.694960
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions

# Generated at 2022-06-18 12:32:23.172840
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions

# Generated at 2022-06-18 12:32:31.654330
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    assert schema1 == schema2

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=4)
    assert not schema1 == schema2

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2)
    assert not schema1 == schema2

    schema1

# Generated at 2022-06-18 12:32:39.352932
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert person.name == "John"
    assert person.age == 30
    assert person == Person(name="John", age=30)
    assert person != Person(name="John", age=31)
    assert person != Person(name="Jane", age=30)
    assert person != Person(name="Jane", age=31)
    assert person != Person(name="John", age=30, height=180)
    assert person != Person(name="Jane", age=31, height=180)
    assert person != Person(name="Jane", age=30, height=180)
    assert person != Person(name="John", age=31, height=180)