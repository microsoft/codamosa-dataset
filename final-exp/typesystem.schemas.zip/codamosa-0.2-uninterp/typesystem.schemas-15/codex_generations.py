

# Generated at 2022-06-18 12:24:23.199934
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema.__iter__()) == ['field1', 'field2']



# Generated at 2022-06-18 12:24:27.360012
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field(type="string")
        b = Field(type="string")
    a1 = A(a="a", b="b")
    a2 = A(a="a", b="b")
    assert a1 == a2
    a3 = A(a="a", b="c")
    assert a1 != a3


# Generated at 2022-06-18 12:24:31.247705
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert len(person) == 2


# Generated at 2022-06-18 12:24:36.895012
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Bar")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:24:40.589475
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    obj = TestSchema(field1=1, field2=2)
    assert list(obj) == ['field1', 'field2']


# Generated at 2022-06-18 12:24:52.150443
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {
        "name": String(),
        "age": Integer(),
    }

    class Employee(Person):
        salary = Integer()

    assert Employee.fields == {
        "name": String(),
        "age": Integer(),
        "salary": Integer(),
    }

    class Employee(Person):
        salary = Integer()
        name = String(min_length=2)

    assert Employee.fields == {
        "name": String(min_length=2),
        "age": Integer(),
        "salary": Integer(),
    }

    class Employee(Person):
        salary = Integer()
        name = String(min_length=2)

        class Meta:
            strict = True


# Generated at 2022-06-18 12:24:58.712247
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert not hasattr(Baz, "definitions")

# Generated at 2022-06-18 12:25:01.384150
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    assert TestSchema.fields == {'field1': Field(), 'field2': Field()}


# Generated at 2022-06-18 12:25:06.883344
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = String()
        field2 = String()
        field3 = String()

    schema = TestSchema(field1="value1", field2="value2")
    assert repr(schema) == "TestSchema(field1='value1', field2='value2') [sparse]"

    schema = TestSchema(field1="value1", field2="value2", field3="value3")
    assert repr(schema) == "TestSchema(field1='value1', field2='value2', field3='value3')"

# Generated at 2022-06-18 12:25:13.483107
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:25:26.954483
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert person["name"] == "John"
    assert person["age"] == 30


# Generated at 2022-06-18 12:25:30.046720
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions == definitions

# Generated at 2022-06-18 12:25:40.194757
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 != schema3
    schema4 = TestSchema(field1=1)
    assert schema1 != schema4
    schema5 = TestSchema(field1=1, field2=2, field3=3)
    assert schema1 != schema5


# Generated at 2022-06-18 12:25:44.792964
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:25:55.032285
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:25:59.157857
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']


# Generated at 2022-06-18 12:26:07.599011
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2, field3=4)
    assert schema1 == schema2
    assert schema1 != schema3


# Generated at 2022-06-18 12:26:12.224127
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["bar"].target is Bar

# Generated at 2022-06-18 12:26:18.036913
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:26:26.074445
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field2=2, field3=3)"


# Generated at 2022-06-18 12:26:39.697533
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:26:51.646307
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem import String
    class Person(Schema):
        name = String()
    class PersonReference(Reference):
        to = Person
    person = Person(name="John")
    person_reference = PersonReference(person)
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.to == Person
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {"name": "John"}
    assert person_reference.validate_or_error(person) == ValidationResult(value=person, error=None)
    assert person_reference.validate_or_error(None) == ValidationResult(value=None, error=ValidationError(["May not be null."]))
    assert person_reference.validate_

# Generated at 2022-06-18 12:27:02.227586
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        gender = String(enum=["male", "female"])
        is_active = Boolean(default=True)
        is_staff = Boolean(default=False)
    schema = TestSchema(name="John", age=30, gender="male")
    assert repr(schema) == "TestSchema(name='John', age=30, gender='male')"
    schema = TestSchema(name="John", age=30, gender="male", is_active=False)
    assert repr(schema) == "TestSchema(name='John', age=30, gender='male', is_active=False)"
    schema = TestSchema(name="John", age=30, gender="male", is_active=False, is_staff=True)
   

# Generated at 2022-06-18 12:27:05.539054
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:27:11.189623
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class B(Schema):
        a = Reference("C")
        b = Reference("D")
        c = Reference("E")

    class C(Schema):
        a = Reference("D")
        b = Reference("E")
        c = Reference("F")

    class D(Schema):
        a = Reference("E")
        b = Reference("F")
        c = Reference("G")

    definitions = SchemaDefinitions()
    set_definitions(A, definitions)
    assert definitions["B"] == B
    assert definitions["C"] == C
    assert definitions["D"] == D

# Generated at 2022-06-18 12:27:21.841662
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    class Person(Schema):
        name = String()
    class Address(Schema):
        street = String()
        person = Reference(Person)
    address = Address(street="123 Main St", person=Person(name="John Doe"))
    assert address.street == "123 Main St"
    assert address.person.name == "John Doe"
    assert address.person.is_sparse == False
    assert address.is_sparse == False
    assert address == Address(street="123 Main St", person=Person(name="John Doe"))
    assert address != Address(street="123 Main St", person=Person(name="Jane Doe"))
    assert address != Address(street="456 Main St", person=Person(name="John Doe"))

# Generated at 2022-06-18 12:27:27.005756
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    set_definitions(Bar, definitions)
    set_definitions(Baz, definitions)

    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions
    assert Bar.fields["foo"].definitions is definitions
    assert Baz.fields["foo"].definitions is definitions

# Generated at 2022-06-18 12:27:39.700893
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
        height = Field(float)
        weight = Field(float)

    person = Person(name="John", age=30, height=1.8, weight=80.5)
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.8
    assert person.weight == 80.5

    person = Person({"name": "John", "age": 30, "height": 1.8, "weight": 80.5})
    assert person.name == "John"
    assert person.age == 30
    assert person.height == 1.8
    assert person.weight == 80.5

    person = Person(name="John", age=30, height=1.8)

# Generated at 2022-06-18 12:27:44.366032
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()
        c = Field()

    assert A.fields == {'a': Field(), 'b': Field(), 'c': Field()}
    assert A.__name__ == 'A'
    assert A.__bases__ == (Schema,)
    assert A.__dict__ == {'__module__': '__main__', '__qualname__': 'A'}


# Generated at 2022-06-18 12:27:54.613026
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Baz")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    set_definitions(Bar, definitions)
    set_definitions(Baz, definitions)

    assert Foo.fields["foo"].definitions is definitions
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:28:18.793042
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field()
        b = Field()
    a1 = A(a=1, b=2)
    a2 = A(a=1, b=2)
    assert a1 == a2
    a3 = A(a=1, b=3)
    assert a1 != a3
    a4 = A(a=1)
    assert a1 != a4
    a5 = A(b=2)
    assert a1 != a5
    a6 = A()
    assert a1 != a6


# Generated at 2022-06-18 12:28:23.484328
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2
    schema = TestSchema(field1=1)
    assert len(schema) == 1
    schema = TestSchema()
    assert len(schema) == 0


# Generated at 2022-06-18 12:28:28.318598
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    assert len(TestSchema(a=1, b=2, c=3)) == 3
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1)) == 1
    assert len(TestSchema()) == 0


# Generated at 2022-06-18 12:28:32.701607
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = String()
        field2 = String()
    test_schema = TestSchema(field1='test1', field2='test2')
    assert test_schema['field1'] == 'test1'
    assert test_schema['field2'] == 'test2'
    try:
        test_schema['field3']
    except KeyError:
        assert True
    else:
        assert False


# Generated at 2022-06-18 12:28:41.132077
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Foo(Schema):
        a = Field(type="string")
        b = Field(type="string")

    foo1 = Foo(a="a", b="b")
    foo2 = Foo(a="a", b="b")
    foo3 = Foo(a="a", b="c")
    foo4 = Foo(a="a")
    foo5 = Foo(b="b")

    assert foo1 == foo2
    assert foo1 != foo3
    assert foo1 != foo4
    assert foo1 != foo5
    assert foo4 != foo5


# Generated at 2022-06-18 12:28:46.431210
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"
    person = Person(name="John")
    assert repr(person) == "Person(name='John') [sparse]"


# Generated at 2022-06-18 12:28:56.661080
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass___new__(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
        field5 = Field()
        field6 = Field()
        field7 = Field()
        field8 = Field()
        field9 = Field()
        field10 = Field()
        field11 = Field()
        field12 = Field()
        field13 = Field()
        field14 = Field()
        field15 = Field()
        field16 = Field()
        field17 = Field()
        field18 = Field()
        field19 = Field()
        field20 = Field()
        field21 = Field()
        field22 = Field()
        field23 = Field()
        field24 = Field()
        field25 = Field()
        field26 = Field()
       

# Generated at 2022-06-18 12:29:00.642713
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    person = Person(name="John Smith", age=20)
    assert person.name == "John Smith"
    assert person.age == 20


# Generated at 2022-06-18 12:29:11.832385
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")

    class B(Schema):
        b = Reference("C")

    class C(Schema):
        c = Reference("D")

    class D(Schema):
        d = Reference("E")

    class E(Schema):
        e = Reference("F")

    class F(Schema):
        f = Reference("G")

    class G(Schema):
        g = Reference("H")

    class H(Schema):
        h = Reference("I")

    class I(Schema):
        i = Reference("J")

    class J(Schema):
        j = Reference("K")

    class K(Schema):
        k = Reference("L")

    class L(Schema):
        l = Reference("M")


# Generated at 2022-06-18 12:29:20.829529
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2, c=3)
    assert repr(schema) == "TestSchema(a=1, b=2, c=3)"
    schema = TestSchema(a=1, b=2)
    assert repr(schema) == "TestSchema(a=1, b=2) [sparse]"
    schema = TestSchema(a=1)
    assert repr(schema) == "TestSchema(a=1) [sparse]"
    schema = TestSchema()
    assert repr(schema) == "TestSchema() [sparse]"


# Generated at 2022-06-18 12:29:58.032759
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:30:01.715492
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert list(person) == ["name", "age"]


# Generated at 2022-06-18 12:30:09.325350
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    assert Person.fields == {'name': String(), 'age': Integer()}
    person = Person(name='John', age=30)
    assert person.name == 'John'
    assert person.age == 30
    assert person == Person(name='John', age=30)
    assert person != Person(name='John', age=31)
    assert person != Person(name='Jane', age=30)
    assert person != Person(name='Jane', age=31)
    assert person != {'name': 'John', 'age': 30}
    assert person != {'name': 'Jane', 'age': 30}
    assert person != {'name': 'John', 'age': 31}
    assert person != {'name': 'Jane', 'age': 31}


# Generated at 2022-06-18 12:30:13.808837
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert list(schema) == ['field1', 'field2', 'field3']


# Generated at 2022-06-18 12:30:16.658183
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']


# Generated at 2022-06-18 12:30:29.191086
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = "Person"

    class PersonArray(Array):
        items = PersonReference()

    class PersonObject(Object):
        properties = {"person": PersonReference()}

    class PersonObjectArray(Array):
        items = PersonObject()

    class PersonObjectArrayReference(Reference):
        to = "PersonObjectArray"

    class PersonObjectArrayReferenceArray(Array):
        items = PersonObjectArrayReference()

    class PersonObjectArrayReferenceArrayReference(Reference):
        to = "PersonObjectArrayReferenceArray"

    class PersonObjectArrayReferenceArrayReferenceArray(Array):
        items = PersonObjectArrayReferenceArrayReference()

    class PersonObjectArrayReferenceArrayReferenceArrayReference(Reference):
        to = "PersonObjectArrayReferenceArrayReferenceArray"

   

# Generated at 2022-06-18 12:30:36.441540
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        foo = Reference("Foo")
        bar = Reference("Bar")
        baz = Reference("Baz")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.foo, definitions)
    set_definitions(TestSchema.bar, definitions)
    set_definitions(TestSchema.baz, definitions)

    assert TestSchema.foo.definitions == definitions
    assert TestSchema.bar.definitions == definitions
    assert TestSchema.baz.definitions == definitions

# Generated at 2022-06-18 12:30:41.268806
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("B")

    class B(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(A.fields["a"], definitions)
    set_definitions(A.fields["b"], definitions)
    assert A.fields["a"].definitions is definitions
    assert A.fields["b"].definitions is definitions

# Generated at 2022-06-18 12:30:51.909822
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    person = Person(name="John", age=42)
    assert person["name"] == "John"
    assert person["age"] == 42
    assert person["name"] == person.name
    assert person["age"] == person.age
    assert person["name"] == person["name"]
    assert person["age"] == person["age"]
    assert person["name"] != person["age"]
    assert person["age"] != person["name"]
    assert person["name"] != 42
    assert person["age"] != "John"
    assert person["name"] != person.age
    assert person["age"] != person.name
    assert person["name"] != person["age"]
    assert person["age"] != person["name"]

# Generated at 2022-06-18 12:30:55.299265
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("TestSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.fields["field"], definitions)
    assert TestSchema.fields["field"].definitions is definitions

# Generated at 2022-06-18 12:32:04.616397
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Foo(Schema):
        a = Field()
        b = Field()
        c = Field()

    foo = Foo(a=1, b=2)
    assert list(foo) == ['a', 'b']


# Generated at 2022-06-18 12:32:08.107570
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2)"


# Generated at 2022-06-18 12:32:12.476171
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person
        definitions = SchemaDefinitions()

    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {"name": "John", "age": 30}


# Generated at 2022-06-18 12:32:18.062426
# Unit test for function set_definitions
def test_set_definitions():
    class Child(Schema):
        name = Field(str)

    class Parent(Schema):
        child = Reference(Child)

    definitions = SchemaDefinitions()
    set_definitions(Parent.fields["child"], definitions)
    assert definitions[Child.__name__] == Child

# Generated at 2022-06-18 12:32:21.591707
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
    schema = TestSchema(a=1, b=2)
    assert schema['a'] == 1
    assert schema['b'] == 2
    try:
        schema['c']
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-18 12:32:27.185038
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()
    class PersonReference(Reference):
        to = Person
    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {"name": "John", "age": 30}


# Generated at 2022-06-18 12:32:36.775739
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
    p = Person(name="John", age=30)
    assert p.name == "John"
    assert p.age == 30
    assert p == Person(name="John", age=30)
    assert p != Person(name="John", age=31)
    assert p != Person(name="John", age=30, extra=1)
    assert p != Person(name="John", age=30, extra=1, strict=True)
    assert p.is_sparse == False
    assert p.validate({"name": "John", "age": 30}) == p
    assert p.validate({"name": "John", "age": 30, "extra": 1}) == p
    assert p

# Generated at 2022-06-18 12:32:44.092186
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 != schema3
    schema4 = TestSchema(field1=1)
    assert schema1 != schema4
    schema5 = TestSchema(field1=1, field2=2, field3=3)
    assert schema1 != schema5


# Generated at 2022-06-18 12:32:47.179316
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Foo(Schema):
        a = Field()
        b = Field()
        c = Field()
    foo = Foo(a=1, b=2)
    assert list(foo) == ["a", "b"]


# Generated at 2022-06-18 12:32:51.415285
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert len(person) == 2

    person = Person(name="John")
    assert len(person) == 1

    person = Person()
    assert len(person) == 0
