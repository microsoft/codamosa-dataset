

# Generated at 2022-06-18 12:24:39.717023
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert repr(TestSchema(a=1, b=2)) == "TestSchema(a=1, b=2) [sparse]"
    assert repr(TestSchema(a=1, b=2, c=3)) == "TestSchema(a=1, b=2, c=3)"


# Generated at 2022-06-18 12:24:47.763247
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    class Person(Schema):
        name = String()
    class Company(Schema):
        name = String()
        ceo = Reference(Person)
    company = Company(name="Acme", ceo=Person(name="Wile E. Coyote"))
    assert company.name == "Acme"
    assert company.ceo.name == "Wile E. Coyote"
    assert company.ceo.__class__.__name__ == "Person"

# Generated at 2022-06-18 12:24:58.225847
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")

    class B(Schema):
        a = Reference("C")

    class C(Schema):
        a = Reference("D")

    class D(Schema):
        a = Reference("E")

    class E(Schema):
        a = Reference("F")

    class F(Schema):
        a = Reference("G")

    class G(Schema):
        a = Reference("H")

    class H(Schema):
        a = Reference("I")

    class I(Schema):
        a = Reference("J")

    class J(Schema):
        a = Reference("K")

    class K(Schema):
        a = Reference("L")

    class L(Schema):
        a = Reference("M")

# Generated at 2022-06-18 12:25:06.390736
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")
    test_schema = TestSchema({"field1": "value1", "field2": "value2"})
    assert test_schema.field1 == "value1"
    assert test_schema.field2 == "value2"
    test_schema = TestSchema(field1="value1", field2="value2")
    assert test_schema.field1 == "value1"
    assert test_schema.field2 == "value2"
    test_schema = TestSchema(field1="value1")
    assert test_schema.field1 == "value1"
    assert test_schema.field2 == None

# Generated at 2022-06-18 12:25:16.120531
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        friends = Array(items=Reference("Person"))

    person = Person(name="John Doe", age=42, friends=[])
    assert person.name == "John Doe"
    assert person.age == 42
    assert person.friends == []
    assert person.is_sparse == False
    assert person == Person(name="John Doe", age=42, friends=[])
    assert person != Person(name="John Doe", age=42, friends=[1])
    assert person != Person(name="John Doe", age=42)
    assert person != Person(name="John Doe", age=42, friends=[], foo="bar")

# Generated at 2022-06-18 12:25:25.526087
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=2)
    assert schema1 != schema3
    schema4 = TestSchema(field1=1, field2=2, field3=4)
    assert schema1 != schema4


# Generated at 2022-06-18 12:25:28.697453
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert Foo.fields["bar"].definitions == definitions

# Generated at 2022-06-18 12:25:34.568374
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        gender = String(enum=["male", "female"])

    person = Person(name="John Doe", age=42, gender="male")
    assert repr(person) == "Person(name='John Doe', age=42, gender='male')"

    person = Person(name="John Doe", age=42)
    assert repr(person) == "Person(name='John Doe', age=42) [sparse]"

    person = Person(name="John Doe")
    assert repr(person) == "Person(name='John Doe') [sparse]"

    person = Person(age=42)
    assert repr(person) == "Person(age=42) [sparse]"

    person = Person()
   

# Generated at 2022-06-18 12:25:41.738926
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.bar.definitions is definitions
    assert Foo.baz.definitions is definitions

# Generated at 2022-06-18 12:25:47.903504
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        bar = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Baz")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:26:07.697983
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] is Foo
    assert definitions["Bar"] is Bar
    assert definitions["Baz"] is Baz

# Generated at 2022-06-18 12:26:11.557982
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:26:22.791820
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field()
        b = Field()
    schema = TestSchema({"a": 1, "b": 2})
    assert schema.a == 1
    assert schema.b == 2
    schema = TestSchema(a=1, b=2)
    assert schema.a == 1
    assert schema.b == 2
    schema = TestSchema(TestSchema(a=1, b=2))
    assert schema.a == 1
    assert schema.b == 2
    schema = TestSchema(TestSchema({"a": 1, "b": 2}))
    assert schema.a == 1
    assert schema.b == 2
    schema = TestSchema({"a": 1, "b": 2, "c": 3})
    assert schema.a == 1
    assert schema.b

# Generated at 2022-06-18 12:26:26.960809
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:26:35.066438
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field1 = Reference("field1")
        field2 = Reference("field2")
        field3 = Reference("field3")
        field4 = Reference("field4")
        field5 = Reference("field5")
        field6 = Reference("field6")
        field7 = Reference("field7")
        field8 = Reference("field8")
        field9 = Reference("field9")
        field10 = Reference("field10")
        field11 = Reference("field11")
        field12 = Reference("field12")
        field13 = Reference("field13")
        field14 = Reference("field14")
        field15 = Reference("field15")
        field16 = Reference("field16")
        field17 = Reference("field17")
        field18 = Reference("field18")
        field19 = Reference("field19")

# Generated at 2022-06-18 12:26:38.360266
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    schema = TestSchema(a=1, b=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:26:47.997269
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert len(schema) == 3

    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2

    schema = TestSchema(field1=1)
    assert len(schema) == 1

    schema = TestSchema()
    assert len(schema) == 0



# Generated at 2022-06-18 12:26:55.606503
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.schema import Schema
    class Person(Schema):
        name = String()
        age = String()
    class PersonReference(Schema):
        person = Reference(Person)
    person = Person(name="John", age="30")
    person_reference = PersonReference(person=person)
    assert person_reference.person == person
    assert person_reference.person.name == "John"
    assert person_reference.person.age == "30"
    assert person_reference.person.is_sparse == False
    assert person_reference.is_sparse == False
    assert person_reference.person.__class__.__name__ == "Person"
    assert person_reference.__class__.__name__ == "PersonReference"
    assert person_reference.__repr__

# Generated at 2022-06-18 12:27:04.781694
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        alive = Boolean()
        friends = Array(String())
        family = Array(
            Object(
                properties={
                    "name": String(),
                    "relation": String(),
                }
            )
        )
        pets = Array(
            Object(
                properties={
                    "name": String(),
                    "type": String(),
                }
            )
        )
        address = Object(
            properties={
                "street": String(),
                "city": String(),
                "state": String(),
                "zip": String(),
            }
        )
        phone = Object(
            properties={
                "home": String(),
                "work": String(),
                "cell": String(),
            }
        )
        email = Object

# Generated at 2022-06-18 12:27:08.419970
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:27:27.255364
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert len(person) == 2


# Generated at 2022-06-18 12:27:35.297786
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions
    assert Baz.fields["baz"].definitions is definitions

# Generated at 2022-06-18 12:27:44.631431
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person
        definitions = SchemaDefinitions()

    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.validate(person) == person
    assert person_reference.validate({"name": "John", "age": 30}) == person
    assert person_reference.validate({"name": "John"}) == person
    assert person_reference.validate({"age": 30}) == person
    assert person_reference.validate({"name": "John", "age": "30"}) == person
    assert person_reference.validate({"name": "John", "age": "30", "extra": "field"}) == person
    assert person

# Generated at 2022-06-18 12:27:49.703588
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
    schema = TestSchema(a="a", b="b")
    assert list(schema) == ["a", "b"]

# Generated at 2022-06-18 12:27:59.601701
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
        b = Field()

    assert TestSchema(a=1, b=2) == TestSchema(a=1, b=2)
    assert TestSchema(a=1, b=2) != TestSchema(a=1, b=3)
    assert TestSchema(a=1, b=2) != TestSchema(a=1)
    assert TestSchema(a=1, b=2) != TestSchema(a=1, b=2, c=3)
    assert TestSchema(a=1, b=2) != TestSchema(a=1, b=2, c=3)
    assert TestSchema(a=1, b=2) != TestSchema(a=1, b=2, c=3)
   

# Generated at 2022-06-18 12:28:02.062904
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Foo(Schema):
        bar = Field(type="string")

    foo = Foo(bar="baz")
    assert foo["bar"] == "baz"
    assert foo.bar == "baz"


# Generated at 2022-06-18 12:28:06.075896
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42


# Generated at 2022-06-18 12:28:14.299683
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.fields import String
    from typesystem.schema import Schema, SchemaDefinitions
    from typesystem.types import String as StringType

    class Person(Schema):
        name = String(type=StringType.NAME)
        age = String(type=StringType.INTEGER)

    class PersonReference(Schema):
        person = Reference(to=Person)

    definitions = SchemaDefinitions()
    person = PersonReference(person={"name": "John", "age": "30"})
    assert person.person.name == "John"
    assert person.person.age == 30


# Generated at 2022-06-18 12:28:20.021581
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields == {}

# Generated at 2022-06-18 12:28:22.296990
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass___new__(Schema):
        pass

    assert TestSchemaMetaclass___new__.fields == {}


# Generated at 2022-06-18 12:28:48.983569
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")

    class B(Schema):
        c = Reference("D")

    class C(Schema):
        d = Reference("E")

    class D(Schema):
        e = Reference("F")

    class E(Schema):
        f = Reference("G")

    class F(Schema):
        g = Reference("H")

    class G(Schema):
        h = Reference("I")

    class H(Schema):
        i = Reference("J")

    class I(Schema):
        j = Reference("K")

    class J(Schema):
        k = Reference("L")

    class K(Schema):
        l = Reference("M")

    class L(Schema):
        m = Reference("N")

# Generated at 2022-06-18 12:28:52.221500
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    person = Person(name="Fred")
    assert person["name"] == "Fred"



# Generated at 2022-06-18 12:28:57.370279
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    assert len(TestSchema()) == 0
    assert len(TestSchema(a=1)) == 1
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1, b=2, c=3)) == 3


# Generated at 2022-06-18 12:29:00.643576
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John Doe", age=42)
    assert list(person) == ["name", "age"]



# Generated at 2022-06-18 12:29:07.199247
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert len(person) == 2

    person = Person(name="John")
    assert len(person) == 1

    person = Person(age=30)
    assert len(person) == 1

    person = Person()
    assert len(person) == 0



# Generated at 2022-06-18 12:29:14.469743
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()
    class PersonReference(Reference):
        to = Person
    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.to == "Person"
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {"name": "John", "age": 30}


# Generated at 2022-06-18 12:29:20.342981
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.make_validator(), definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:29:30.395374
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()

    person1 = Person(name="John", age=30)
    person2 = Person(name="John", age=30)
    assert person1 == person2

    person1 = Person(name="John", age=30)
    person2 = Person(name="John", age=31)
    assert person1 != person2

    person1 = Person(name="John", age=30)
    person2 = Person(name="Jane", age=30)
    assert person1 != person2

    person1 = Person(name="John", age=30)
    person2 = Person(name="John", age=30, height=180)
    assert person1 != person2

    person1 = Person(name="John", age=30)

# Generated at 2022-06-18 12:29:35.919887
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions

# Generated at 2022-06-18 12:29:41.081231
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    assert Foo.fields["foo"].definitions is definitions
    assert Bar.fields["bar"].definitions is definitions

# Generated at 2022-06-18 12:30:33.783045
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        pass

    assert TestSchema.fields == {}

    class TestSchema(Schema):
        field = Field()

    assert TestSchema.fields == {"field": Field()}

    class TestSchema(Schema):
        field = Field()

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)

    assert TestSchema.fields == {"field": Field()}

    class TestSchema(Schema):
        field = Field()

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)

    assert TestSchema.fields == {"field": Field()}

   

# Generated at 2022-06-18 12:30:38.100399
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']
    assert list(schema.__iter__()) == ['field1', 'field2']


# Generated at 2022-06-18 12:30:43.568996
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert person["name"] == "John"
    assert person["age"] == 30
    assert person["name"] == person.name
    assert person["age"] == person.age

    try:
        person["address"]
    except KeyError:
        pass
    else:
        assert False, "KeyError not raised"


# Generated at 2022-06-18 12:30:47.537430
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        field = Reference("OtherSchema")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.field, definitions)
    assert TestSchema.field.definitions == definitions

# Generated at 2022-06-18 12:30:51.415502
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:30:55.213236
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:31:00.879939
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    p1 = Person(name="John", age=30)
    p2 = Person(name="John", age=30)
    assert p1 == p2
    p3 = Person(name="John", age=31)
    assert p1 != p3
    p4 = Person(name="John")
    assert p1 != p4
    p5 = Person(age=30)
    assert p1 != p5
    p6 = Person()
    assert p1 != p6


# Generated at 2022-06-18 12:31:05.796339
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert list(schema) == ['field1', 'field2', 'field3']


# Generated at 2022-06-18 12:31:11.486410
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"

    person = Person(name="John")
    assert repr(person) == "Person(name='John') [sparse]"

# Generated at 2022-06-18 12:31:21.724146
# Unit test for constructor of class Reference
def test_Reference():
    class TestSchema(Schema):
        name = String()
        age = Integer()
    class TestSchema2(Schema):
        name = String()
        age = Integer()
    test_schema = TestSchema(name="test", age=10)
    test_schema2 = TestSchema2(name="test", age=10)
    test_reference = Reference(to=TestSchema)
    test_reference2 = Reference(to=TestSchema2)
    test_reference3 = Reference(to="TestSchema")
    test_reference4 = Reference(to="TestSchema2")
    assert test_reference.target == TestSchema
    assert test_reference2.target == TestSchema2
    assert test_reference3.target == TestSchema
    assert test_reference4.target == TestSchema2


# Generated at 2022-06-18 12:32:30.495878
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:32:34.032630
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42


# Generated at 2022-06-18 12:32:43.755456
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")

    schema = TestSchema(a="a", b="b")
    assert schema.a == "a"
    assert schema.b == "b"

    schema = TestSchema({"a": "a", "b": "b"})
    assert schema.a == "a"
    assert schema.b == "b"

    schema = TestSchema(TestSchema(a="a", b="b"))
    assert schema.a == "a"
    assert schema.b == "b"

    schema = TestSchema(a="a", b="b", c="c")
    assert schema.a == "a"
    assert schema.b == "b"


# Generated at 2022-06-18 12:32:48.282754
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:32:53.289569
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()
        weight = Float()

    p = Person(name="John", age=30, height=1.8, weight=80.0)
    assert list(p) == ['name', 'age', 'height', 'weight']


# Generated at 2022-06-18 12:32:57.364553
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"

    person = Person(name="John")
    assert repr(person) == "Person(name='John') [sparse]"



# Generated at 2022-06-18 12:33:00.367881
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    test_schema = TestSchema(a=1, b=2)
    assert list(test_schema) == ['a', 'b']


# Generated at 2022-06-18 12:33:09.092347
# Unit test for method validate of class Reference
def test_Reference_validate():
    class TestSchema(Schema):
        field = Reference("TestSchema")
    assert TestSchema.validate({"field": {"field": None}}) == TestSchema(field=TestSchema(field=None))
    assert TestSchema.validate({"field": {"field": None}}, strict=True) == TestSchema(field=TestSchema(field=None))
    assert TestSchema.validate({"field": {"field": None}}, strict=False) == TestSchema(field=TestSchema(field=None))
    assert TestSchema.validate({"field": {"field": None}}, strict=True) == TestSchema(field=TestSchema(field=None))

# Generated at 2022-06-18 12:33:12.513237
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert len(person) == 2


# Generated at 2022-06-18 12:33:16.005960
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2
