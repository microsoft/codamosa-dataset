

# Generated at 2022-06-18 12:24:25.955304
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        a = Reference("B")
        b = Reference("C")
        c = Reference("D")

    class B(Schema):
        a = Reference("C")
        b = Reference("D")
        c = Reference("E")

    class C(Schema):
        a = Reference("D")
        b = Reference("E")
        c = Reference("F")

    class D(Schema):
        a = Reference("E")
        b = Reference("F")
        c = Reference("G")

    class E(Schema):
        a = Reference("F")
        b = Reference("G")
        c = Reference("H")

    class F(Schema):
        a = Reference("G")
        b = Reference("H")
        c = Reference("I")


# Generated at 2022-06-18 12:24:31.150257
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2, field3=4)
    schema4 = TestSchema(field1=1, field2=2)
    schema5 = TestSchema(field1=1, field2=2, field3=3, field4=4)

    assert schema1 == schema2
    assert schema1 != schema3
    assert schema1 != schema4
    assert schema1 != schema5


# Generated at 2022-06-18 12:24:42.657363
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema()) == 0
    assert len(Schema({"a": 1})) == 1
    assert len(Schema(a=1)) == 1
    assert len(Schema(a=1, b=2)) == 2
    assert len(Schema(a=1, b=2, c=3)) == 3
    assert len(Schema(a=1, b=2, c=3, d=4)) == 4
    assert len(Schema(a=1, b=2, c=3, d=4, e=5)) == 5
    assert len(Schema(a=1, b=2, c=3, d=4, e=5, f=6)) == 6

# Generated at 2022-06-18 12:24:47.588515
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
        height = Float()

    person = Person(name="John", age=30, height=1.83)
    assert repr(person) == "Person(name='John', age=30, height=1.83)"



# Generated at 2022-06-18 12:24:54.303142
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"
    schema = TestSchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field2=2, field3=3)"


# Generated at 2022-06-18 12:25:00.508405
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    s = TestSchema(a=1, b=2, c=3)
    assert len(s) == 3
    s = TestSchema(a=1, b=2)
    assert len(s) == 2
    s = TestSchema(a=1)
    assert len(s) == 1
    s = TestSchema()
    assert len(s) == 0


# Generated at 2022-06-18 12:25:07.867952
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()
    p = Person(name="John", age=30)
    assert p.name == "John"
    assert p.age == 30
    assert p.is_sparse == False
    assert p == Person(name="John", age=30)
    assert p != Person(name="John", age=31)
    assert p != Person(name="John", age=30, height=180)
    assert p != Person(name="John", age=30, height=180, is_sparse=True)
    assert p != Person(name="John", age=30, is_sparse=True)
    assert p != Person(name="John", age=30, is_sparse=False)

# Generated at 2022-06-18 12:25:13.623219
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 != schema3


# Generated at 2022-06-18 12:25:25.475679
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person
        definitions = SchemaDefinitions()

    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {"name": "John", "age": 30}
    assert person_reference.validate_or_error(person) == ValidationResult(
        value=person, error=None
    )

# Generated at 2022-06-18 12:25:32.585230
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
    assert TestSchema({"a": "a", "b": "b"}) == TestSchema(a="a", b="b")
    assert TestSchema({"a": "a", "b": "b"}) == TestSchema(TestSchema(a="a", b="b"))
    assert TestSchema({"a": "a", "b": "b"}) == TestSchema(TestSchema({"a": "a", "b": "b"}))
    assert TestSchema({"a": "a", "b": "b"}) == TestSchema(TestSchema(TestSchema({"a": "a", "b": "b"})))

# Generated at 2022-06-18 12:25:51.437151
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")
        d = Field(type="string")
        e = Field(type="string")
        f = Field(type="string")
        g = Field(type="string")
        h = Field(type="string")
        i = Field(type="string")
        j = Field(type="string")
        k = Field(type="string")
        l = Field(type="string")
        m = Field(type="string")
        n = Field(type="string")
        o = Field(type="string")
        p = Field(type="string")
        q = Field(type="string")
        r = Field(type="string")
        s = Field(type="string")

# Generated at 2022-06-18 12:25:59.206887
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test that the method __new__ of class SchemaMetaclass
    # raises a TypeError when an invalid keyword argument is passed
    # to the constructor of the class that is being created.
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    try:
        TestSchema(field1="value1", field2="value2", field3="value3")
    except TypeError as error:
        assert str(error) == "field3 is an invalid keyword argument for TestSchema()."
    else:
        assert False, "TypeError not raised"


# Generated at 2022-06-18 12:26:05.082955
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        is_active = Field(type="boolean")

    schema = TestSchema(name="John Doe", age=42)
    assert list(schema) == ["name", "age"]

# Generated at 2022-06-18 12:26:09.392694
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    person = Person(name="John", age=30)
    assert person["name"] == "John"
    assert person["age"] == 30
    assert person["address"] == KeyError


# Generated at 2022-06-18 12:26:15.786236
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        foo = Reference("Foo")
        bar = Reference("Bar")
        baz = Reference("Baz")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema, definitions)
    assert TestSchema.foo.definitions == definitions
    assert TestSchema.bar.definitions == definitions
    assert TestSchema.baz.definitions == definitions

# Generated at 2022-06-18 12:26:22.254655
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"

    person = Person(name="John")
    assert repr(person) == "Person(name='John') [sparse]"

    person = Person()
    assert repr(person) == "Person() [sparse]"


# Generated at 2022-06-18 12:26:29.621082
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"

    schema = TestSchema(field1=1, field2=2, field3=3)
    assert repr(schema) == "TestSchema(field1=1, field2=2, field3=3)"

# Generated at 2022-06-18 12:26:32.613463
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        gender = String()

    person = Person(name="John", age=30, gender="male")
    assert list(person) == ["name", "age", "gender"]


# Generated at 2022-06-18 12:26:39.239865
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    obj = TestSchema(a=1, b=2, c=3)
    assert list(obj) == ['a', 'b', 'c']
    obj = TestSchema(a=1, b=2)
    assert list(obj) == ['a', 'b']
    obj = TestSchema(a=1)
    assert list(obj) == ['a']
    obj = TestSchema()
    assert list(obj) == []


# Generated at 2022-06-18 12:26:47.175223
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type="string")

    test_schema = TestSchema(name="John", age=25, address="New York")
    assert test_schema.name == "John"
    assert test_schema.age == 25
    assert test_schema.address == "New York"


# Generated at 2022-06-18 12:26:59.537817
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field(type="string")
        field2 = Field(type="string")
    schema = TestSchema(field1="value1", field2="value2")
    assert repr(schema) == "TestSchema(field1='value1', field2='value2')"


# Generated at 2022-06-18 12:27:05.497736
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.fields["bar"].definitions == definitions
    assert Foo.fields["baz"].definitions == definitions
    assert Bar.fields["foo"].definitions == definitions
    assert Baz.fields["foo"].definitions == definitions

# Generated at 2022-06-18 12:27:11.802858
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert repr(MySchema(a=1, b=2)) == "MySchema(a=1, b=2)"
    assert repr(MySchema(a=1, b=2, c=3)) == "MySchema(a=1, b=2, c=3)"
    assert repr(MySchema(a=1, b=2, c=3, d=4)) == "MySchema(a=1, b=2, c=3) [sparse]"
    assert repr(MySchema(a=1, b=2, c=3, d=4, e=5)) == "MySchema(a=1, b=2, c=3) [sparse]"
    assert repr

# Generated at 2022-06-18 12:27:15.875257
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name="John", age=30)
    assert repr(person) == "Person(name='John', age=30)"


# Generated at 2022-06-18 12:27:19.504086
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    schema = TestSchema(a=1, b=2)
    assert list(schema) == ['a', 'b']



# Generated at 2022-06-18 12:27:22.740582
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchemaMetaclass___new__(Schema):
        field1 = Field()
        field2 = Field()
    assert TestSchemaMetaclass___new__.fields == {'field1': Field(), 'field2': Field()}


# Generated at 2022-06-18 12:27:29.869888
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert len(TestSchema(a=1, b=2)) == 2
    assert len(TestSchema(a=1, b=2, c=3)) == 3
    assert len(TestSchema(a=1, b=2, c=3, d=4)) == 3


# Generated at 2022-06-18 12:27:41.471302
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert schema["field1"] == 1
    assert schema["field2"] == 2
    assert schema["field3"] is None
    assert len(schema) == 2
    assert list(schema) == ["field1", "field2"]
    assert schema.is_sparse is True
    assert repr(schema) == "TestSchema(field1=1, field2=2) [sparse]"
    assert schema == TestSchema(field1=1, field2=2)
    assert schema != TestSchema(field1=1, field2=2, field3=3)

# Generated at 2022-06-18 12:27:48.257126
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")
        baz = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Baz")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:27:53.328950
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        name = String()
        age = Integer()
    a = TestSchema(name="John", age=20)
    b = TestSchema(name="John", age=20)
    c = TestSchema(name="John", age=30)
    assert a == b
    assert a != c


# Generated at 2022-06-18 12:28:05.479625
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:28:09.507853
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:28:12.950766
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert list(person) == ["name", "age"]


# Generated at 2022-06-18 12:28:22.954125
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
        field5 = Field()
        field6 = Field()
        field7 = Field()
        field8 = Field()
        field9 = Field()
        field10 = Field()
        field11 = Field()
        field12 = Field()
        field13 = Field()
        field14 = Field()
        field15 = Field()
        field16 = Field()
        field17 = Field()
        field18 = Field()
        field19 = Field()
        field20 = Field()
        field21 = Field()
        field22 = Field()
        field23 = Field()
        field24 = Field()
        field25 = Field()
        field26 = Field()
        field27 = Field()


# Generated at 2022-06-18 12:28:25.820067
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name='John', age=30)
    assert person['name'] == 'John'
    assert person['age'] == 30


# Generated at 2022-06-18 12:28:29.867610
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2
    schema3 = TestSchema(field1=1, field2=3)
    assert schema1 != schema3


# Generated at 2022-06-18 12:28:34.387664
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    schema1 = TestSchema(field1=1, field2=2)
    schema2 = TestSchema(field1=1, field2=2)
    assert schema1 == schema2


# Generated at 2022-06-18 12:28:41.176825
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:28:48.509222
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2, field3=4)
    assert schema1 == schema2
    assert schema1 != schema3


# Generated at 2022-06-18 12:28:53.465126
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer()

    p1 = Person(name="John", age=30)
    p2 = Person(name="John", age=30)
    p3 = Person(name="John", age=31)
    assert p1 == p2
    assert p1 != p3


# Generated at 2022-06-18 12:29:46.003372
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    obj = TestSchema(field1=1, field3=3)
    assert repr(obj) == "TestSchema(field1=1, field3=3) [sparse]"

    obj = TestSchema(field1=1, field2=2, field3=3)
    assert repr(obj) == "TestSchema(field1=1, field2=2, field3=3)"



# Generated at 2022-06-18 12:29:49.349983
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()

    class Employee(Person):
        salary = Float()

    assert Employee.fields == {
        "name": String(),
        "age": Integer(),
        "salary": Float(),
    }


# Generated at 2022-06-18 12:29:53.211287
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=42)
    assert person.name == "John"
    assert person.age == 42


# Generated at 2022-06-18 12:30:01.652251
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    set_definitions(Bar.fields["baz"], definitions)

    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["baz"].definitions is definitions
    assert Baz.fields["baz"].definitions is None

# Generated at 2022-06-18 12:30:09.313850
# Unit test for constructor of class Reference
def test_Reference():
    class User(Schema):
        name = String()
        age = Integer()

    class Comment(Schema):
        user = Reference(User)
        text = String()

    comment = Comment(user={"name": "John", "age": 30}, text="Hello")
    assert comment.user.name == "John"
    assert comment.user.age == 30
    assert comment.text == "Hello"
    assert comment.is_valid()
    assert comment.serialize() == {
        "user": {"name": "John", "age": 30},
        "text": "Hello",
    }
    assert comment.user.serialize() == {"name": "John", "age": 30}
    assert comment.user.is_valid()
    assert comment.user.name.is_valid()
    assert comment.user.age.is_

# Generated at 2022-06-18 12:30:17.136641
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()
    assert repr(TestSchema(a=1, b=2, c=3)) == 'TestSchema(a=1, b=2, c=3)'
    assert repr(TestSchema(a=1, b=2)) == 'TestSchema(a=1, b=2) [sparse]'
    assert repr(TestSchema(a=1)) == 'TestSchema(a=1) [sparse]'
    assert repr(TestSchema()) == 'TestSchema() [sparse]'


# Generated at 2022-06-18 12:30:21.817852
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    schema = TestSchema(field1=1, field2=2)
    assert len(schema) == 2


# Generated at 2022-06-18 12:30:34.231910
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()
        address = String()

    class Address(Schema):
        street = String()
        city = String()

    class PersonWithAddress(Schema):
        name = String()
        age = Integer()
        address = Reference(Address)

    definitions = SchemaDefinitions()
    person = PersonWithAddress(name="John", age=30, address=Address(street="123 Main St", city="New York"))
    assert person.address.street == "123 Main St"
    assert person.address.city == "New York"
    assert person.address.street == "123 Main St"
    assert person.address.city == "New York"
    assert person.address.street == "123 Main St"
    assert person.address.city == "New York"

# Generated at 2022-06-18 12:30:37.602400
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema = TestSchema(field1=1, field2=2)
    assert list(schema) == ['field1', 'field2']


# Generated at 2022-06-18 12:30:47.489691
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        baz = Reference("Baz")

    class Bar(Schema):
        foo = Reference("Foo")

    class Baz(Schema):
        foo = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    set_definitions(Foo.fields["baz"], definitions)
    set_definitions(Bar.fields["foo"], definitions)
    set_definitions(Baz.fields["foo"], definitions)
    assert Foo.fields["bar"].definitions is definitions
    assert Foo.fields["baz"].definitions is definitions
    assert Bar.fields["foo"].definitions is definitions
    assert Baz.fields["foo"].definitions is definitions

# Generated at 2022-06-18 12:31:27.712986
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field()
        b = Field()
        c = Field()

    assert TestSchema(a=1, b=2, c=3) == TestSchema(a=1, b=2, c=3)
    assert TestSchema(a=1, b=2, c=3) != TestSchema(a=1, b=2, c=4)
    assert TestSchema(a=1, b=2, c=3) != TestSchema(a=1, b=2)
    assert TestSchema(a=1, b=2, c=3) != TestSchema(a=1, b=2, c=3, d=4)

# Generated at 2022-06-18 12:31:35.783833
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.schema import SchemaMetaclass, SchemaDefinitions
    from typesystem.schema import Schema, Reference
    from typesystem.types import String as StringType
    class Person(Schema, metaclass=SchemaMetaclass):
        name = String(max_length=100)
        age = String(max_length=100)
    class Address(Schema, metaclass=SchemaMetaclass):
        street = String(max_length=100)
        city = String(max_length=100)
        person = Reference(Person)
    definitions = SchemaDefinitions()
    assert Address.fields['person'].target == Person
    assert Address.fields['person'].target_string == 'Person'
    assert Address.fields['person'].to == 'Person'


# Generated at 2022-06-18 12:31:46.181472
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    schema = TestSchema(name="John", age=20)
    assert schema.name == "John"
    assert schema.age == 20
    assert schema == TestSchema(name="John", age=20)
    assert schema != TestSchema(name="John", age=30)
    assert schema != TestSchema(name="John")
    assert schema != TestSchema(age=20)
    assert schema != TestSchema(name="John", age=20, extra=None)
    assert schema != TestSchema(name="John", age=20, extra=None)
    assert schema != TestSchema(name="John", age=20, extra=None)

# Generated at 2022-06-18 12:31:51.225988
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
    test_schema = TestSchema(field1=1, field3=3)
    assert repr(test_schema) == "TestSchema(field1=1, field3=3) [sparse]"


# Generated at 2022-06-18 12:32:00.050827
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    schema1 = TestSchema(field1=1, field2=2, field3=3)
    schema2 = TestSchema(field1=1, field2=2, field3=3)
    schema3 = TestSchema(field1=1, field2=2)
    schema4 = TestSchema(field1=1, field2=2, field3=4)
    assert schema1 == schema2
    assert schema1 != schema3
    assert schema1 != schema4


# Generated at 2022-06-18 12:32:09.661899
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()
        age = Integer()
        address = String()

    class Address(Schema):
        street = String()
        city = String()
        zip = String()

    class Company(Schema):
        name = String()
        address = Reference(Address)

    class Employee(Schema):
        name = String()
        age = Integer()
        company = Reference(Company)

    person = Person(name="John", age=30, address="123 Main St")
    address = Address(street="123 Main St", city="New York", zip="10001")
    company = Company(name="Acme", address=address)
    employee = Employee(name="John", age=30, company=company)

    assert employee.validate(person) == employee
    assert employee.validate(employee)

# Generated at 2022-06-18 12:32:16.384322
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()
        age = Integer()
    assert Person.fields == {'name': String(), 'age': Integer()}
    assert Person.__name__ == 'Person'
    assert Person.__bases__ == (Schema,)
    assert Person.__dict__ == {'__module__': '__main__', '__doc__': None}


# Generated at 2022-06-18 12:32:23.171894
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")

    s1 = TestSchema(a="a", b="b", c="c")
    s2 = TestSchema(a="a", b="b", c="c")
    s3 = TestSchema(a="a", b="b")
    s4 = TestSchema(a="a", b="b", c="d")

    assert s1 == s2
    assert s1 != s3
    assert s1 != s4
    assert s3 != s4


# Generated at 2022-06-18 12:32:27.747741
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")

    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    set_definitions(Foo, definitions)
    assert Foo.bar.definitions is definitions
    assert Bar.baz.definitions is definitions
    assert Baz.definitions is None

# Generated at 2022-06-18 12:32:34.570991
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        foo = Reference("Bar")

    class Bar(Schema):
        bar = Reference("Baz")

    class Baz(Schema):
        baz = Reference("Foo")

    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["foo"], definitions)
    set_definitions(Bar.fields["bar"], definitions)
    set_definitions(Baz.fields["baz"], definitions)
    assert definitions["Foo"] == Foo
    assert definitions["Bar"] == Bar
    assert definitions["Baz"] == Baz

# Generated at 2022-06-18 12:33:08.196076
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)

    class PersonRef(Reference):
        to = Person

    person = Person(name='John', age=30)
    person_ref = PersonRef(person)
    assert person_ref.validate(person) == person
    assert person_ref.validate(person) == person_ref.target.validate(person)
    assert person_ref.validate(person) == Person.validate(person)
    assert person_ref.validate(person) == Person(name='John', age=30)
    assert person_ref.validate(person) == {'name': 'John', 'age': 30}
    assert person_ref.validate(person) == {'name': 'John', 'age': 30}


# Generated at 2022-06-18 12:33:16.343369
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()

    person1 = Person(name="John", age=30)
    person2 = Person(name="John", age=30)
    person3 = Person(name="John", age=31)
    person4 = Person(name="Jane", age=30)
    person5 = Person(name="Jane", age=31)

    assert person1 == person2
    assert person1 != person3
    assert person1 != person4
    assert person1 != person5
    assert person3 != person4
    assert person3 != person5
    assert person4 != person5


# Generated at 2022-06-18 12:33:19.031924
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    assert TestSchema.fields == {"name": Field(type="string"), "age": Field(type="integer")}


# Generated at 2022-06-18 12:33:28.465167
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Schema1(Schema):
        field1 = Field()
        field2 = Field()
    assert Schema1.fields == {'field1': Field(), 'field2': Field()}
    assert Schema1.__name__ == 'Schema1'
    assert Schema1.__bases__ == (Schema,)
    assert Schema1.__dict__ == {'__module__': '__main__', '__doc__': None}
    assert Schema1.__qualname__ == 'Schema1'
    assert Schema1.__annotations__ == {}
    assert Schema1.__init__.__qualname__ == 'Schema1.__init__'
    assert Schema1.__init__.__annotations__ == {'args': typing.Any, 'kwargs': typing.Any}
    assert Schema

# Generated at 2022-06-18 12:33:31.354469
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="John", age=30)
    assert list(person) == ["name", "age"]



# Generated at 2022-06-18 12:33:36.067416
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()
    person = Person(name='John', age=30)
    assert person['name'] == 'John'
    assert person['age'] == 30
    try:
        person['address']
    except KeyError:
        pass
    else:
        assert False


# Generated at 2022-06-18 12:33:40.474206
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()

    class B(A):
        c = Field()

    class C(B):
        d = Field()

    assert C.fields == {'a': A.fields['a'], 'b': A.fields['b'], 'c': B.fields['c'], 'd': C.fields['d']}


# Generated at 2022-06-18 12:33:50.264776
# Unit test for constructor of class Reference
def test_Reference():
    class Person(Schema):
        name = String()
        age = Integer()

    class PersonReference(Reference):
        to = Person
        definitions = {
            "Person": Person
        }

    person = Person(name="John", age=30)
    person_reference = PersonReference(person)
    assert person_reference.target == Person
    assert person_reference.target_string == "Person"
    assert person_reference.to == Person
    assert person_reference.definitions == {
        "Person": Person
    }
    assert person_reference.validate(person) == person
    assert person_reference.serialize(person) == {
        "name": "John",
        "age": 30
    }
    assert person_reference.validate_or_error(person) == ValidationResult(value=person, error=None)