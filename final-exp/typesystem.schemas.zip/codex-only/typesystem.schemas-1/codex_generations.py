

# Generated at 2022-06-24 11:00:06.021934
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class ExampleSchema(Schema):
        foo = Field()
        bar = Field()

    a = ExampleSchema(foo=42, bar=24)
    b = ExampleSchema(foo=42, bar=24)
    assert a == b

    c = ExampleSchema(foo=42, bar=42)
    assert a != c
    assert not a == c

    d = ExampleSchema(foo=42)
    assert d != a
    assert not d == a
    assert d == d

    class OtherSchema(Schema):
        foo = Field()
        bar = Field()

    e = OtherSchema(foo=42)
    assert d != e
    assert not d == e


# Generated at 2022-06-24 11:00:12.723821
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    # Test setting definitions for a field
    obj1 = Object(properties={"name": String()}, definitions=definitions)
    assert definitions == {"obj1": obj1}
    # Test setting definitions for a nested field
    obj2 = Object(properties={"address": obj1}, definitions=definitions)
    assert definitions == {"obj1": obj1, "obj2": obj2}
    # Test setting definitions for an array field
    arr = Array(items=[obj1, obj2], definitions=definitions)
    assert definitions == {"obj1": obj1, "obj2": obj2, "arr": arr}

# Generated at 2022-06-24 11:00:15.103888
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    x = Reference("string", min_length=1, max_length=3)
    assert x.serialize("abc") == "abc"


# Generated at 2022-06-24 11:00:17.358892
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd = SchemaDefinitions()
    sd["a"] = 1
    del sd["a"]
    assert len(sd) == 0 #pass

# Generated at 2022-06-24 11:00:20.597403
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schemas = [Schema(a=3, b=4, c=5, d=6)]
    length = len(schemas[0])
    assert length == 4
    assert schemas



# Generated at 2022-06-24 11:00:25.242701
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    SchemaDefinitions = dyn.make_dyn("SchemaDefinitions", "getitem")
    s = SchemaDefinitions()
    def getitem(self, key): return "definitions"
    dyn.make_concrete("SchemaDefinitions", s,
                      [("getitem", getitem)])
    assert s.getitem("key") == "definitions"


# Generated at 2022-06-24 11:00:29.095556
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Field()
        baz = Field(type_=Array)
    definitions = SchemaDefinitions()
    set_definitions(Foo.fields["bar"], definitions)
    assert definitions == {
        "dict": dict,
        "list": list,
        "int": int,
        "str": str,
        "Foo": Foo,
    }



# Generated at 2022-06-24 11:00:31.021310
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    result = SchemaDefinitions({"default": 1}).__iter__()
    assert result == ["default"]

# Generated at 2022-06-24 11:00:36.476889
# Unit test for method __len__ of class Schema
def test_Schema___len__():
	from typesystem import Schema, Integer, String
	
	class Example(Schema):
	    name = String
	    age = Integer
	
	example = Example(name="Sam", age=20)
	assert len(example) == 2
	assert list(example) == ['name', 'age']


# Generated at 2022-06-24 11:00:39.413220
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    def_dict = SchemaDefinitions()
    def_dict["test_key"] = "test_value"
    assert def_dict["test_key"] == "test_value"



# Generated at 2022-06-24 11:00:47.083764
# Unit test for constructor of class Schema
def test_Schema():
    from .models import User
    fields = {'name': 'string', 'age': 0, 'friends': []}
    #user = User(**fields)
    user = User(name='string', age=0,  friends=[])
    assert user == User(name='string', age=0,  friends=[])
    assert user.name == 'string'
    assert user.age == 0
    assert user.friends == []
    assert user.__repr__() == "User(name='string', age=0, friends=[]) [sparse]"



# Generated at 2022-06-24 11:00:59.813910
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        name = String()
        age = Integer()

    class Pet(Schema):
        name = String()
        owner = Reference(to=Person)

    p1 = Person(name="Bob Smith", age=35)
    p2 = Person(name="Bob Smith", age=35)
    p3 = Person(name="Bob Smith", age=36)
    p4 = Person(name="Robert Smith", age=35)
    p5 = Person(name="Bob Smith")

    p6 = Person()
    p6.name = "Bob Smith"
    p6.age = 35

    pet = Pet(name="Fluffy", owner=p1)

    assert p1 != p2
    assert p1 != p3
    assert p1 != p4
    assert p1 != p5

# Generated at 2022-06-24 11:01:06.483486
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Testing for null case
    test_defs = SchemaDefinitions()
    test_ref = Reference('my_schema', test_defs)
    value = None
    strict = False
    assert test_ref.validate(value, strict) is None
    # Testing for error
    test_defs = SchemaDefinitions()
    test_ref = Reference('my_schema', test_defs)
    value = 'test_value'
    strict = True
    error = test_ref.validate_or_error('test_value', strict)
    assert error.error.code == 'null'
    # Testing for non-null case
    test_defs = SchemaDefinitions()
    class my_schema(Schema):
        field1 = String()
        field2 = Integer()

# Generated at 2022-06-24 11:01:16.875324
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # enviroment variables
    class_name = Schema.__name__
    class_Module = 'typesystem.schemas' 
    class_FullName = '{}.{}'.format(class_Module, class_name)    
    
    # variables
    args = [1,2]
    kwargs = {'key': 'value'} 
    expected_result = True 
    
    # test
    obj = Schema(*args, **kwargs)
    received_result = obj.__eq__(obj)
    assert received_result == expected_result, 'Expected {} but received {}.'.format(expected_result, received_result)

    obj2 = Schema(*args, **kwargs)
    received_result = obj.__eq__(obj2)

# Generated at 2022-06-24 11:01:20.310382
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    message = "test_Schema___repr__"
    print(message)
    # @todo: Add a test here



# Generated at 2022-06-24 11:01:22.070704
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference("test").serialize("a") == "a"
    assert Reference("test").serialize(None) == None

# Generated at 2022-06-24 11:01:29.385706
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Create a schema class
    class Person(Schema):
        name = String()
        age = Integer()
    # Create two objects with equal contents to test __eq__
    p = Person(name = "John", age = 18)
    q = Person(name = "John", age = 18)
    # Check if two objects are equal
    if p == q:
        print("Two objects are equal")
    else:
        print("Two objects are not equal")
test_Schema___eq__()


# Generated at 2022-06-24 11:01:30.801233
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    s = SchemaDefinitions({"a":2})
    assert len(s) == 1


# Generated at 2022-06-24 11:01:36.197777
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():

    # Arrange.
    class Animal(Schema):
        noise = Field(str)
        sound = Field(str)

    class Cat(Schema):
        dog = Reference(Animal)
        cat = Field(str)

    class Dog(Schema):
        Cat = Cat

    d = Dog()
    # Act.
    result = d['Cat'].dog.sound
    # Assert.
    assert result == 'sound'


# Generated at 2022-06-24 11:01:42.546412
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Post(Schema):
        title = String(max_length=256)
        body = String()

    p = Post({"title": "My post", "body": "This is the body"})
    assert p.title == "My post"
    assert p.body == "This is the body"
    assert set(p) == {"title", "body"}
    # No idea what's inside
    assert set(iter({"title" : "My post", "body" : "This is the body"})) == set(iter(["title","body"]))

# Generated at 2022-06-24 11:01:52.741880
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    if True:
        from typesystem import types, validators

        class author(Schema):
            name = types.String(required=True)
            age = types.Integer()

        class book(Schema):
            pages = types.Integer(required=True)
            author = types.Array(items=author)

        class document(Schema):
            pages = types.Integer(required=True)
            author = types.Array(items=author)

        class library(Schema):
            name = types.String(required=True)
            books = types.Array(items=book)
            documents = types.Array(items=document)
        #  Schema
        # _______________________________________
        #  __getitem__
        # _______________________________________

# Generated at 2022-06-24 11:01:54.679368
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
# Assign
    class Person(Schema):
        name = String()

# Act
    person = Person()
    key_list = list(person)
# Assert
    assert key_list == []

# Generated at 2022-06-24 11:01:58.333718
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    schemaDefinitions = SchemaDefinitions()
    name = None  # DUMMY: Need to change this to a valid value for testing.

    ret = schemaDefinitions[name]
    assert ret is None
    # No use case in here.


# Generated at 2022-06-24 11:02:02.069390
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    x = Schema()

    if(x[None] == {}):
        print("Schema class getitem test passed")
    else:
        print("Schema class getitem test failed")

# Generated at 2022-06-24 11:02:06.575035
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        def __init__(self, x:int):
            self.x = x
            self.y = 2
    assert MySchema(2).__repr__() == "MySchema(x=2)"


# Generated at 2022-06-24 11:02:08.082085
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    data = {}
    obj = SchemaDefinitions(data)
    result = obj.__len__()

    assert result == 0


# Generated at 2022-06-24 11:02:13.095931
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema_definitions: SchemaDefinitions = SchemaDefinitions()
    foo = Schema({"first_name": "foo"})
    schema_definitions["Foo"] = foo
    assert foo == schema_definitions["Foo"]

# Generated at 2022-06-24 11:02:15.809209
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        test = Reference("Test")

    definitions = SchemaDefinitions()
    TestSchema.validate({}, definitions=definitions)



# Generated at 2022-06-24 11:02:26.354123
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Pass
    class Person(Schema):
        name = String()

    p = Person({"name": "Alice"})
    assert p["name"] == "Alice"

    # Fail
    class Person(Schema):
        name = String()

    p = Person({"name": "Alice"})
    with pytest.raises(KeyError):
        p["age"]


# Generated at 2022-06-24 11:02:32.400472
# Unit test for constructor of class Schema
def test_Schema():
    class Root(Schema):
        a = Field()
        b = Field()
        c = Field()

    root = Root(a=1, b=2, c=3)
    assert root.a == 1
    assert root.b == 2
    assert root.c == 3
    assert root["a"] == 1
    assert root["b"] == 2
    assert root["c"] == 3
    assert root == Root(a=1, b=2, c=3)

    dict_root = Root({"a": 1, "b": 2, "c": 3})
    assert dict_root.a == 1
    assert dict_root.b == 2
    assert dict_root.c == 3
    assert dict_root["a"] == 1
    assert dict_root["b"] == 2
    assert dict_root["c"] == 3

# Generated at 2022-06-24 11:02:37.962203
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    key1 = '__len__'
    attrs = dict()
    attrs[key1] = 123
    ret = Schema.__len__(attrs)
    assert ret == 1
    key1 = '__init__'
    attrs = dict()
    attrs[key1] = 123
    ret = Schema.__len__(attrs)
    assert ret == 0


# Generated at 2022-06-24 11:02:45.874716
# Unit test for method validate of class Reference
def test_Reference_validate():
    addressbook = SchemaDefinitions()
    class Contact(Schema, metaclass=SchemaMetaclass, definitions=addressbook):
        email = String(max_length=100)

    class EmailList(Schema, metaclass=SchemaMetaclass):
        emails = Array(items=Reference(Contact), min_items=2)

    with pytest.raises(
        TypeError,
        match=r"Invalid argument emails for EmailList(). may not be null.",
    ):
        EmailList.validate({"emails": None})
    with pytest.raises(
        TypeError,
        match=r"Invalid argument emails for EmailList(). Expected at least 2 items.",
    ):
        EmailList.validate({"emails": {"email": "johndoe@example.com"}})
    email_list

# Generated at 2022-06-24 11:02:53.338614
# Unit test for function set_definitions
def test_set_definitions():
    class A(Schema):
        i = Field()
        ref = Reference(
            "B",
            definitions={
                "B": Field(),
            }
        )
        list_ref = Reference(
            "B",
            definitions={
                "B": Field(),
            }
        )
        list_ref.items = [Field()]
        array_ref = Array(items=Reference(
            "B",
            definitions={
                "B": Field(),
            }
        ))
        object_ref = Object(properties={"b": Reference(
            "B",
            definitions={
                "B": Field(),
            }
        )})
    assert A.fields["ref"].definitions is not None
    assert A.fields["list_ref"].definitions is not None

# Generated at 2022-06-24 11:03:00.706439
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    keys = []
    values = []
    new_values = []
    del_values = []
    c = SchemaDefinitions()
    for i in range(10):
        keys.append(i)
        values.append(i)
        c[i] = i
    for i in c:
        new_values.append(i)
    for i in range(10):
        del c[i]
    for i in c:
        del_values.append(i)
    assert keys == new_values
    assert values != new_values
    assert del_values == []
    try:
        for i in c:
            raise Exception('fail')
    except:
        pass


# Generated at 2022-06-24 11:03:02.058806
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert Schema.__repr__(Schema()) == 'Schema()'


# Generated at 2022-06-24 11:03:06.002787
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    s = Schema(components=Schema(schemas={'NewItem':Schema(type='object',properties={'name':Schema(type='string')})}))
    s = Reference('NewItem',to='NewItem',definitions=s.components.schemas)
    assert s.serialize({'name':'value'}) == {'name':'value'}

# Generated at 2022-06-24 11:03:13.725375
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import doctest
    import pytest
    from . import test_base_field, test_fields

    package_under_test = typesystem.schemas

    # doctest_namespace = {
    #     'json': json,
    #     'package_under_test': package_under_test,
    #     'test_base_field': test_base_field,
    #     'test_fields': test_fields,
    # }
    #
    # tests = doctest.DocTestSuite(
    #     package_under_test,
    #     extraglobs=doctest_namespace,
    #     optionflags=doctest.NORMALIZE_WHITESPACE,
    # )
    #
    # my_test_runner = pytest.TestRunner()
    # failures = my_

# Generated at 2022-06-24 11:03:15.827249
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions["a"] = 1
    assert "a" in definitions
    del definitions["a"]
    assert "a" not in definitions


# Generated at 2022-06-24 11:03:23.106114
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    instances = []
    instances.append(
        SchemaDefinitions(
            **{
                "__class__": SchemaDefinitions,
                "_definitions": {
                    "__class__": dict,
                    "args": [],
                    "kwargs": {},
                },
            }
        )
    )
    for instance in instances:
        assert len(instance) == 0
        assert instance.__len__() == 0


# Generated at 2022-06-24 11:03:34.000595
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test = SchemaDefinitions()
    assert len(test) == 0,'you failed to inititate the length'
    test['test'] = 1
    test['test2'] = 2
    assert len(test) == 2,'you failed to add things to dictionary'
    assert test['test'] == 1, 'you failed to get the right value'
    del test['test']
    assert len(test) == 1, 'you failed to delete'
    print('you passed the test of SchemaDefinitions')

# Generated at 2022-06-24 11:03:40.451032
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    def test_it():
        definitions = SchemaDefinitions()
        # test get
        assert definitions == {}
        # test get with definition
        definitions[1] = "a"
        definitions[2] = "b"
        definitions[3] = "c"
        assert definitions == {1: "a", 2: "b", 3: "c"}
        # test set
        definitions[4] = "d"
        assert definitions == {1: "a", 2: "b", 3: "c", 4: "d"}
        # test del
        del definitions[4]
        assert definitions == {1: "a", 2: "b", 3: "c"}
        # test len
        assert len(definitions) == 3
        # test iter

# Generated at 2022-06-24 11:03:48.981065
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import Integer
    from typesystem.structures import FrozenDict
    from .tests.types import MySchema
    assert set(MySchema.fields.keys()) == {"my_int"}
    assert MySchema.fields["my_int"] == Integer()
    assert MySchema.make_validator() == Object(
        properties={
            "my_int": Integer()
        },
        required=[
            "my_int"
        ],
        additional_properties=None,
    )
    assert isinstance(MySchema({}), MySchema)
    assert isinstance(MySchema({"my_int": 0}), MySchema)
    assert isinstance(MySchema(my_int=0), MySchema)

# Generated at 2022-06-24 11:03:55.963120
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    a = type.__new__(type)
    b = type(dict)
    a.fields = {'a': b}
    a.__repr__ = lambda : 'a'
    b.serialize = lambda x: x
    b.__repr__ = lambda : 'b'

    a = Reference('a', definitions={'a': b})
    assert a.serialize({'a': 1}) == {'a': 1}

# Generated at 2022-06-24 11:03:57.662780
# Unit test for constructor of class Reference
def test_Reference():
   field = Reference(to="to", definitions={"key": "value"})


# Generated at 2022-06-24 11:04:06.068930
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import os
    import sys

    # Set environment variable 'typesystem_TRAVIS' to True in Travis-CI.
    # To avoid python code coverage error in Travis-CI
    os.environ['typesystem_TRAVIS'] = 'True'
    try:
        import typesystem
    except ImportError:
        # If 'typesystem' package is not installed, then add path to module
        # 'typesystem' relative to the directory containing this file.
        # This is for runtime only.
        this_file_dir = os.path.dirname(__file__)
        sys.path.insert(0, os.path.dirname(this_file_dir))
        import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String()
        age = typesystem.Integer()
        is_active = types

# Generated at 2022-06-24 11:04:14.342594
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    foo = SchemaDefinitions()
    foo['a'] = 1
    foo['b'] = 2
    foo['c'] = 3
    foo['d'] = 4
    assert len(foo) == 4
    del foo['b']
    assert set(foo.keys()) == {'a', 'c', 'd'}
    del foo['a']
    assert set(foo.keys()) == {'c', 'd'}
    del foo['d']
    assert set(foo.keys()) == {'c'}
    del foo['c']
    assert set(foo.keys()) == set()


# Generated at 2022-06-24 11:04:18.017772
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from .objects import Address, Address2

    data = {"postcode": "EC1 4GH"}

    assert Address(**data) == Address2(**data)
    assert Address(**data) == Address(**data)
    assert Address(**data) != Address2(postcode="W12 7RJ")


# Generated at 2022-06-24 11:04:21.096793
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Location(Schema):
        latitude = Float()
        longitude = Float()
    class Person(Schema):
        name = String()
        location = Reference(
            to=Location, allow_null=True
        )
    p = Person(name='Rupam', location={'latitude': 46.3, 'longitude': -93.2})


# Generated at 2022-06-24 11:04:31.349753
# Unit test for method validate of class Reference
def test_Reference_validate():
    Ref_schema = Schema(
        first_name = String(max_length=10),
        last_name = String(max_length=10)
    )
    
    # Test successful validate, return None
    validation_result = Reference(Ref_schema).validate(None, strict=True)
    assert validation_result == None

    # Test case of using a string reference, target attribute is None
    definition = SchemaDefinitions()
    ref = Reference("Ref_schema", definition)
    isinstance(ref, Reference)
    assert ref.target == None

    # Test case of using a string reference, target attribute is not None
    definition["Ref_schema"] = Ref_schema
    ref = Reference("Ref_schema", definition)
    isinstance(ref, Reference)
    assert ref.target != None
    
   

# Generated at 2022-06-24 11:04:37.625085
# Unit test for function set_definitions
def test_set_definitions():
    class SchemaDefinitions(SchemaDefinitions):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            self._definitions = dict(*args, **kwargs)

        def __setitem__(self, key: typing.Any, value: typing.Any) -> None:
            self._definitions[key] = value

    testDefs = SchemaDefinitions()
    assert testDefs._definitions == {}
    set_definitions(Reference(to="test"), testDefs)
    assert testDefs._definitions == {"test": Reference}
    assert testDefs._definitions["test"] == Reference

# Generated at 2022-06-24 11:04:41.225550
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions(a=1, b=2, c=3)
    delete_key = 'b'
    expected = {'a': 1, 'c': 3}
    del definitions[delete_key]
    assert definitions == expected


# Generated at 2022-06-24 11:04:52.129689
# Unit test for constructor of class Schema
def test_Schema():
    schema_0 = Schema()
    assert schema_0 is not None
    assert not hasattr(schema_0, 'test')

    schema_1 = Schema({'test': 'Yo'})
    assert schema_1 is not None
    assert schema_1.test == 'Yo'
    assert not hasattr(schema_1, 'test2')

    schema_2 = Schema({'test': 'Yo', 'test2': 'Ya', 'test3': 'Yoo'})
    assert schema_2 is not None
    assert schema_2.test == 'Yo'
    assert schema_2.test2 == 'Ya'
    assert not hasattr(schema_2, 'test3')

    schema_3 = Schema(test='Yo')
    assert schema_3 is not None

# Generated at 2022-06-24 11:05:05.039918
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import datetime
    import typesystem
    class Date(Schema):
        year: int
        month: int
        day: int
    class Person(Schema):
        name: str
        birthday: Date

    john = Person(
        name = "John",
        birthday = Date(
            year = 1963,
            month = 4,
            day = 15,
        ),
    )
    paul = Person(
        name = "Paul",
        birthday = Date(
            year = 1942,
            month = 6,
            day = 18,
        ),
    )

    print("john:", john)
    print("paul:", paul)

    print("john == paul:", john == paul)
    print("john == john:", john == john)

# Generated at 2022-06-24 11:05:12.126484
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
	from datetime import datetime
	from typesystem import Schema, String, DateTime

	class Person(Schema):
	    name = String()
	    birthdate = DateTime()


	p1 = Person(name="Thomas", birthdate=datetime(1991, 11, 11))
	assert len(p1) == 2
	assert all(k in p1 for k in p1.fields.keys())

	# includes only included fields
	p2 = Person(name="Thomas")
	assert len(p2) == 1
	assert all(k in p2 for k in p2.fields.keys())


# Generated at 2022-06-24 11:05:22.751573
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import copy
    import typesystem
    from typesystem.fields import String
    from typesystem.contrib.marshmallow.fields import Dict


    class ExampleSchema(typesystem.Schema):
        name = String(required=True)
        # Create a copy of name field so that the ExampleSchema can have custom
        # __getitem__ method to get the value of field name.
        custom_name = copy.copy(name)
        value = String(required=True)


    example_schema = ExampleSchema.make_validator()
    example_schema_validate = typesystem.Schema.validate


    class ExampleSchema(typesystem.Schema):
        name = String(required=True)
        custom_name = copy.copy(name)

# Generated at 2022-06-24 11:05:26.071242
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert SchemaDefinitions({1:1, 2:2}, alpha = "alpha", beta = "beta") != None
    assert SchemaDefinitions() != None

# Generated at 2022-06-24 11:05:32.640853
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem.fields import Integer
    from typesystem import Schema

    class SimpleSchema(Schema):
        x = Integer()
        y = Integer()

    i = SimpleSchema(x=1, y=2, z=3)

    assert list(i) == ['x', 'y']
    assert list(i.items()) == [('x', 1), ('y', 2)]
    assert list(i.values()) == [1, 2]
    assert list(i.keys()) == ['x', 'y']


# Generated at 2022-06-24 11:05:36.969067
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class SubSchema(Schema):
        id = Field()

    class MySchema(Schema):
        name = Field()
        sub = Field(SubSchema)

    schema = MySchema(name="test", sub={"id": 12})

    for key in schema:
        assert key in {"name", "sub"}
    if "name" in schema:
        assert schema["name"] == "test"
    if "sub" in schema:
        assert schema["sub"] == {"id": 12}


# Generated at 2022-06-24 11:05:41.670617
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.schema import SchemaMetaclass
    from typesystem.fields import String
    sm = SchemaMetaclass
    class TestSchema(metaclass=SchemaMetaclass):
        field = String()

    t = TestSchema()
    assert t.field.__class__.__name__ == 'String'
    assert t.field.__class__.__module__ == 'typesystem.fields'


# Generated at 2022-06-24 11:05:48.643710
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class AddressSchema(Schema):
        class Address1(Field):
            pass
        class Address2(Field):
            pass
    sc = AddressSchema(Address1 = 1, Address2 = 2)
    assert len(sc) == 2
    assert len([i for i in sc]) == 2
    for i in sc:
        if i == 'Address1':
            assert sc['Address1'] == 1
        elif i == 'Address2':
            assert sc['Address2'] == 2

# Generated at 2022-06-24 11:05:54.442342
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typing import List
    from typesystem import String

    class Person(Schema):
        name = String(max_length=100)
        age = String()

    p = Person(name="Alice", age="29")
    expected_keys: List[str] = ['name', 'age']
    assert sorted(list(iter(p))) == expected_keys
    assert sorted(list(p)) == expected_keys

# Generated at 2022-06-24 11:06:01.301881
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    print('\n:: TEST: test_Schema___repr__')
    class MySchema(Schema):
        a=String()
        b=Integer()
    schema = MySchema(a="foo", b=123)
    assert repr(schema) == "MySchema(a='foo', b=123)"


# Generated at 2022-06-24 11:06:05.471921
# Unit test for constructor of class Reference
def test_Reference():
    to = {'foo': 'bar'}
    definitions = {'foo': 'bar'}
    kwargs = {'foo': 'bar'}
    ref = Reference(to, definitions, **kwargs)
    assert ref.to == to
    assert ref.definitions == definitions
    assert ref.kwargs == kwargs


# Generated at 2022-06-24 11:06:16.014971
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    import typesystem
    import typesystem.fields

    parameters = {
        "definitions": {
            "Person": (
                typesystem.fields.String(
                    key="name",
                    title="Name",
                    description="The person's name.",
                    min_length=3,
                    errors={
                        "minLength": "Must have at least 3 characters.",
                    },
                ),
                typesystem.fields.Integer(
                    key="age",
                    title="Age",
                    description="The person's age in years.",
                    minimum=18,
                    errors={
                        "type": "Must be a number.",
                        "minimum": "Must be at least 18.",
                    },
                ),
            ),
        },
    }

    result = SchemaDefinitions(**parameters)
    assert result["Person"] is not None


# Unit test

# Generated at 2022-06-24 11:06:23.550437
# Unit test for method __iter__ of class Schema

# Generated at 2022-06-24 11:06:34.209980
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    from typesystem.base import ErrorMessage
    from typesystem.datetime import DateTime
    from typesystem.fields import Boolean, Integer, String
    from typesystem.schema import SchemaDefinitions
    import typing


    class User(Schema):
        id = Integer()
        name = String(max_length=50)


    class Task(Schema):
        id = Integer()
        user_id = Integer()
        summary = String()
        created = DateTime()
        completed = Boolean()


    class Query(Schema):
        users = Array(items=Reference(User))
        tasks = Array(items=Reference(Task))


    assert len(Query.fields) == 2
    assert isinstance(Query.fields["users"], Array)
    assert isinstance(Query.fields["users"].items, Reference)
    assert Query

# Generated at 2022-06-24 11:06:41.225412
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        name = String(max_length=120)
        age = Integer(gte=0)
    # Create an instance of class Reference to test its method serialize
    my_reference = Reference(to=Person, source=["Person"])
    # The next method call returns a dictionary with the same key, value pairs as the original object
    assert my_reference.serialize(Person(name = 'John Smith', age = 21)) == {'name' : 'John Smith', 'age' : 21}
    # If the object is None, the method returns None
    assert my_reference.serialize(None) == None

# Generated at 2022-06-24 11:06:46.967543
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # case 1
    definitions = SchemaDefinitions()
    definitions['test_key'] = 'test_value'
    assert definitions['test_key'] == 'test_value'

    # case 2
    definitions = SchemaDefinitions()
    definitions['test_key'] = 'test_value'
    try:
        definitions['test_key_2']
    except:
        assert True
    else:
        assert False



# Generated at 2022-06-24 11:06:48.662831
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    d = SchemaDefinitions()
    d['a'] = 1
    print(d['a'])


# Generated at 2022-06-24 11:06:51.255724
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    # simple test case
    schema_definitions= SchemaDefinitions()
    schema_definitions['Book'] = Book
    d['authors.author'] = Reference(to = 'Book')



# Generated at 2022-06-24 11:06:58.480137
# Unit test for function set_definitions
def test_set_definitions():
    class Main(Schema):
        test = Reference("Ref")

    class Ref(Schema):
        test = Reference("Ref2")

    class Ref2(Schema):
        test = Reference("Ref3")

    class Ref3(Schema):
        test = String()

    assert Main.fields["test"].definitions is None
    assert Ref.fields["test"].definitions is None
    assert Ref2.fields["test"].definitions is None
    assert Ref3.fields["test"].definitions is None

    definitions = SchemaDefinitions()

    assert len(definitions) == 0

    set_definitions(Main.fields["test"], definitions)

    assert Main.fields["test"].definitions is definitions
    assert Ref.fields["test"].definitions is definitions

# Generated at 2022-06-24 11:07:00.786444
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    import doctest
    doctest.testmod()


# Generated at 2022-06-24 11:07:02.851466
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions({}) #noqa

    actual = len(obj)
    expected = 0
    assert actual == expected


# Generated at 2022-06-24 11:07:06.540330
# Unit test for method validate of class Reference
def test_Reference_validate():
    s = Reference("A")
    assert s.validate({"msg": "hello"}) == {"msg": "hello"}
    class A(Schema):
        msg = Field()
    class B(Schema):
        msg = Field()
    s = Reference(A)
    assert s.validate({"msg": "hello"}) == {"msg": "hello"}

# Generated at 2022-06-24 11:07:11.018054
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    test_definitions = {'key': 'value'}
    test_obj = SchemaDefinitions(test_definitions)
    test_obj.__getitem__('key')


# Generated at 2022-06-24 11:07:13.110695
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    a = Schema({"a":'a'})
    b = Reference(a)
    assert b.serialize(a) == {
        'a': 'a'
    }

# Generated at 2022-06-24 11:07:13.945857
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass


# Generated at 2022-06-24 11:07:18.030763
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions()
    definitions["A"] = "string"
    definitions["B"] = "string"
    definitions["C"] = "string"
    assert sorted(definitions) == ["A", "B", "C"]



# Generated at 2022-06-24 11:07:31.850805
# Unit test for constructor of class Schema
def test_Schema():
    try:
        class A(Schema):
            b = Field()
        a = A(1)
        print("(1)", a)
        print("(2)")
    except Exception as e:
        print(e)
    print()

    try:
        a = A({"b": "c"})
        print("(1)")
    except Exception as e:
        print(e)
    print()

    try:
        class A(Schema):
            b = Field()
            c = Field(required=True)
        a = A({"b": "b", "c": "c"})
        print("(1)")
    except Exception as e:
        print(e)
    print()


# Generated at 2022-06-24 11:07:36.773691
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Test(Schema):
        field = Field()

    test = Test(
        field="value"
    )
    if len(test) != 1:
        raise RuntimeError('Error')



# Generated at 2022-06-24 11:07:40.543946
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    cls1 = SchemaDefinitions()
    assert cls1.is_sparse == False
    assert cls1._definitions == {}
    assert not cls1
    assert len(cls1) == 0
    


# Generated at 2022-06-24 11:07:42.075595
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
	definitions = SchemaDefinitions()
	definitions.__setitem__(1, None)
	definitions.__delitem__(1)


# Generated at 2022-06-24 11:07:48.014476
# Unit test for method validate of class Reference
def test_Reference_validate():
    if Type == "pass":
        if TestObj == "pass":
            if Limit == "":
                if int(ErrorCount) > 0:
                    errorMessage = "TestObject is working as expected"
                    print(
                        {
                            "Type": "pass",
                            "TestObject": "pass",
                            "ErrorMessage": errorMessage,
                            "Limit": "",
                        }
                    )
                else:
                    errorMessage = "TestObject is not working as expected"
                    print(
                        {
                            "Type": "fail",
                            "TestObject": "pass",
                            "ErrorMessage": errorMessage,
                            "Limit": "",
                        }
                    )
            else:
                if int(ErrorCount) <= int(Limit):
                    errorMessage = "TestObject is working as expected"

# Generated at 2022-06-24 11:07:52.016953
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.schema import Schema

    class User(Schema):
        username = String()
        age = Integer()
    user = User(username='joe', age=25)
    print(user)

# Generated at 2022-06-24 11:07:58.220494
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    def1 = {"def1": "def1"}
    def2 = {"def2": "def2"}
    definitions = SchemaDefinitions(def1)
    definitions["def2"] = def2
    definitions["def3"] = "def3"
    definitions["def4"] = "def4"
    definitions["def5"] = "def5"
    definitions["def6"] = "def6"
    key_list = []
    for key, value in definitions.items():
        key_list.append(key)
    assert set(key_list) == {"def1", "def2", "def3", "def4", "def5", "def6"}
    return True


# Generated at 2022-06-24 11:08:03.497199
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    s = SchemaDefinitions()
    try:
        s["key1"] = 1
        s["key2"] = 2
        s["key3"] = 3
        assert len(s)==3
        del s["key1"]
        assert len(s) == 2
    except KeyError as e:
        pass



# Generated at 2022-06-24 11:08:14.834480
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Parent(Schema):
        parent_field = Field(str)

    # Test KeyError
    parent = Parent(parent_field="Hello")
    try:
        parent["child_field"]
    except KeyError as e:
        assert e == "child_field"
    else:
        assert False, "Didn't raise KeyError"

    # Test value returned
    class Child(Schema):
        parent_field = Field(str)
        child_field = Field(str)

    child = Child(parent_field="Hello", child_field="World")
    assert child["parent_field"] == "Hello"
    assert child["child_field"] == "World"

    # Test KeyError
    child = Child(parent_field="Hello")

# Generated at 2022-06-24 11:08:16.331001
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert Schema.__eq__(Schema(), Schema())==True


# Generated at 2022-06-24 11:08:22.588016
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Define input
    key = 'key'
    # Define expected output
    expected_output = 'jatin'
    # Define arguments
    arguments = {
        'key': {
            'type': 'string',
            'default': 'jatin'
        }
    }
    # Define type
    Type = SchemaMetaclass('Type', (Schema,), arguments, None)
    # Define test
    test = Type()
    # Execute target
    actual_output = test.__getitem__(key)
    # Assert output
    assert actual_output == expected_output


# Generated at 2022-06-24 11:08:26.100235
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class MySchema(Schema, metaclass=SchemaMetaclass):
        A = Field()
        B = Field()
        C = Field()

    assert [key for key in MySchema.fields] == ["A", "B", "C"]



# Generated at 2022-06-24 11:08:29.381173
# Unit test for method validate of class Reference
def test_Reference_validate():
    ref = Reference('Schema1', definitions={'Schema1': dict})
    assert ref.validate(None, strict=True) == None
    assert ref.validate({}, strict=True) == {}



# Generated at 2022-06-24 11:08:30.853795
# Unit test for method validate of class Reference
def test_Reference_validate():
    c = Reference("string")
    assert c.validate(1) == None


# Generated at 2022-06-24 11:08:35.144472
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions()
    definitions['a'] = 1
    definitions['b'] = 2
    definitions['c'] = 3
    definitions['d'] = 4
    definitions_list = list(definitions)
    assert definitions_list[0] == 'a'
    assert definitions_list[1] == 'b'
    assert definitions_list[2] == 'c'
    assert definitions_list[3] == 'd'


# Generated at 2022-06-24 11:08:43.483040
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():

    class Parent(Schema):
        pass

    class Child(Parent):
        pass

    child = Child()
    assert child.fields == {}

    definitions = SchemaDefinitions()
    class GrandChild(Child, metaclass=SchemaMetaclass, definitions=definitions):
        pass
    assert child.fields == {}



# Generated at 2022-06-24 11:08:49.975569
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        name = String(max_length=100)
        state = String(max_length=100)
        city = String(max_length=100)
        age = Integer()

    schema = MySchema(name="Jill", state="CA")

    assert len(schema) == 2
    passes = False
    try:
        # noinspection PyStatementEffect
        schema[3]
    except KeyError:
        passes = True
    assert passes



# Generated at 2022-06-24 11:08:53.459437
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    def_ = SchemaDefinitions()
    def_['myitem'] = 1
    assert 'myitem' in def_
    assert len(def_) == 1
    del def_['myitem']
    assert 'myitem' not in def_
    assert len(def_) == 0


# Generated at 2022-06-24 11:08:56.869131
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions[2] = 3
    assert definitions[2] == 3

    try:
        definitions[2] = 4
        assert False
    except:
        assert True


# Generated at 2022-06-24 11:08:59.186074
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class BasicSchema(Schema):
        value = String()

    assert BasicSchema(value='string') == BasicSchema(value='string')


# Generated at 2022-06-24 11:09:00.348652
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference("to", allow_null = True)
    assert ref


# Generated at 2022-06-24 11:09:03.865142
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Test(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()
        field4 = Field()
        field5 = Field()
        field6 = Field()
        field7 = Field()

    # Testing __len__ method
    print(len(Test()))


# Generated at 2022-06-24 11:09:09.038643
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class A(Schema):
        fieldA = Field()
        fieldB = Field()
    class B(Schema):
        referenceA = Reference(to=A)
    b = B(referenceA={'fieldA':'a'})
    print(b.referenceA)
    assert isinstance(b.referenceA, dict)
    assert b.referenceA == {'fieldA':'a'}


# Generated at 2022-06-24 11:09:14.263410
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Foo(Schema):
        field_one = Field(required=True, type=str)
        field_two = Field(required=True, type=str)
        field_three = Field(required=True, type=str)

    obj = Foo(field_one="abc", field_two="def", field_three="ghi")
    assert len(obj) == 3
    assert isinstance(obj, Schema) is True


# Generated at 2022-06-24 11:09:19.991242
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        """
        "key" argument is missing
        """
        # _creation_counter = {"Person": 1}
        name = String(max_length=128)

    assert {"name": String()} == Person.fields

    class Person(Schema):
        name = String(max_length=128)

    person = Person({})

# Generated at 2022-06-24 11:09:23.095596
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    # Arrange
    target = [1, 2, 3]
    reference = Reference(target)

    # Act
    result = reference.serialize(target)

    # Assert
    assert result == target


# Generated at 2022-06-24 11:09:26.179935
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    obj = SchemaDefinitions({"key1": "value1", "key2": "value2"})
    expected = "value2"
    result = obj["key2"]
    assert expected == result


# Generated at 2022-06-24 11:09:30.837427
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    defs = SchemaDefinitions()
    defs["foo"] = "bar"
    assert len(defs._definitions) == 1
    assert "foo" in defs._definitions
    del defs["foo"]
    assert len(defs._definitions) == 0
    assert "foo" not in defs._definitions


# Generated at 2022-06-24 11:09:33.472199
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    if __name__ == "__main__":
        obj = Schema({'str': 'hello', 'num': 10})
        result = list(obj.__iter__())
        assert result == ['str', 'num'], result



# Generated at 2022-06-24 11:09:36.981504
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    actual = SchemaDefinitions({'a': 1, 'b': 2})
    expected = 'a' or 'b' 
    assert actual in expected


# Generated at 2022-06-24 11:09:43.446223
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class MySchema(Schema):
        a = Field()
        b = Field()
        c = Field()
        d = Field()
        e = Field()
    s1 = MySchema()
    s2 = MySchema()
    assert (s1 == s2) is True
    s2 = MySchema(a = 1)
    assert (s1 == s2) is False
    s1 = MySchema(a = 1)
    assert (s1 == s2) is True
    s2 = MySchema(a = 1, b = 2)
    assert (s1 == s2) is False
    s1 = MySchema(a = 1, b = 2)
    assert (s1 == s2) is True
    s2 = MySchema(a = 1, b = 2, c = 3)


# Generated at 2022-06-24 11:09:51.420781
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.fields import Integer, String
    from typesystem.schema import Schema

    class Address(Schema):
        number = Integer()
        road = String()

        def serialize(self):
            return {
                "number": self.number,
                "road": self.road,
            }

    class User(Schema):
        username = String()
        address = Reference(Address)

    user = User(username="James", address=Address(number=7, road="Hobbiton Road"))
    assert user.address == {
        "number": 7,
        "road": "Hobbiton Road",
    }

# Generated at 2022-06-24 11:09:54.015965
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    obj = SchemaDefinitions({'a': 1, 'b': 2})
    assert obj['a'] == 1
    assert obj['b'] == 2


# Generated at 2022-06-24 11:09:57.566758
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        field_1 = Field(key='field_1', title='field_1')
        field_2 = Field(key='field_2', title='field_2')
    
    s = TestSchema(field_1=1, field_2=2)
