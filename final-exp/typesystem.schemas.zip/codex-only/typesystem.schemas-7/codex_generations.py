

# Generated at 2022-06-24 10:59:56.878345
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass

# Generated at 2022-06-24 11:00:05.128717
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class SubSchema(Schema):
        i_am_key = Field()

    class TestSchema(Schema):
        i_am_key = Field()
        only_sub = SubSchema(i_am_key="i_am_val")

    # Option 1
    test_inst = TestSchema()
    key_list = [key for key in test_inst]
    assert key_list == ["i_am_key", "only_sub"]
    # Option 2
    assert list(test_inst) == ["i_am_key", "only_sub"]


# Generated at 2022-06-24 11:00:11.301896
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # test case 1: empty SchemaDefinitions
    definitions = SchemaDefinitions()
    assert len(list(definitions.__iter__())) == 0

    # test case 2: filled SchemaDefinitions
    definitions = SchemaDefinitions()
    definitions["abc"] = None
    definitions["def"] = None
    definitions["ghi"] = None
    assert len(list(definitions.__iter__())) == 3
    assert all(x in definitions for x in ["abc", "def", "ghi"])


# Generated at 2022-06-24 11:00:13.115983
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    instance = SchemaDefinitions()
    with pytest.raises(AssertionError):
        instance['key'] = 'value'

# Generated at 2022-06-24 11:00:16.531912
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions["test"] = 1
    del schema_definitions["test"]
    assert "test" not in schema_definitions


# Generated at 2022-06-24 11:00:23.290572
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    print("[INFO] Entering Unit test for method __delitem__ of class SchemaDefinitions")
    s = SchemaDefinitions()
    schema = Schema()
    s['a'] = schema
    assert('a' in s._definitions)
    s.__delitem__('a')
    assert('a' not in s._definitions)
    print("[SUCCESS] Successfully passed the unit test for method __delitem__ of class SchemaDefinitions")
    return


# Generated at 2022-06-24 11:00:24.614961
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    result = SchemaDefinitions()
    assert result != None   


# Generated at 2022-06-24 11:00:31.456855
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class ComplexSchema(Schema):
        name = String()
        age = Number(integer=True)
        gender = String(enum=["male", "female"])
        friends = Array(Item(name=String()))
        bio = String(allow_blank=True)

    class Person1(ComplexSchema):
        pass

    class Person2(ComplexSchema):
        pass

    p1 = Person1(name="Alice", age=18, gender="female", bio="nice")
    p2 = Person1(name="Alice", age=18, gender="female", bio="nice")
    p3 = Person1(name="Alice", age=18, gender="female", bio="nice", friends=[])
    p4 = Person2(name="Alice", age=18, gender="female", bio="nice")
    p5 = Person2

# Generated at 2022-06-24 11:00:34.012105
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    try:
        SchemaDefinitions().__setitem__("x", "y")
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-24 11:00:36.749924
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    # Test serialize of object with value
    assert(Reference("test_reference").serialize("test_reference_value") == "test_reference_value")
    # Test serialize of object with None
    assert(Reference("test_reference").serialize("None") is None)


# Generated at 2022-06-24 11:00:39.546892
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    print(Schema({}))
    print(Schema({}, strict=True))


if __name__ == "__main__":
    test_Schema___repr__()

# Generated at 2022-06-24 11:00:49.795391
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.schema import Schema
    from typesystem.fields import String
    a = Schema(
        field1 = String(max_length=20),
        field2 = String(max_length=10),
        field3 = String(max_length=15)
    )
    b = Schema(field1="test", field2="test2")
    c = Schema(field1="test", field2="test2", field3="test3")
    assert repr(b) == "Schema(field1='test', field2='test2')"
    assert repr(c) == "Schema(field1='test', field2='test2', field3='test3')"
    assert repr(a) == "Schema() [sparse]"


# Generated at 2022-06-24 11:00:53.480051
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert callable(Schema.__iter__)


# Generated at 2022-06-24 11:00:57.656367
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    fields = {"field_1": ""}
    attrs = {"fields": fields}
    assert Schema.__dict__["__iter__"](None, attrs) is None, "invalid"


# Generated at 2022-06-24 11:00:59.381043
# Unit test for method validate of class Reference
def test_Reference_validate():
    targetClass = Reference("test")
    result = targetClass.validate("test")
    assert result == "test"


# Generated at 2022-06-24 11:01:01.954374
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    obj = SchemaDefinitions()
    # key is of type 'str'
    key = "str"
    value = obj.__getitem__(key)
    assert isinstance(value, type(None))


# Generated at 2022-06-24 11:01:08.773579
# Unit test for function set_definitions
def test_set_definitions():
    fields = {
        "field1": Reference(to="Ref1"),
        "field2": Reference(to="Ref2"),
        "field3": Reference(to="Ref1"),
    }
    definitions = {
        "Ref1": 1,
        "Ref2": 2,
    }
    set_definitions(Field(properties=fields), definitions)
    assert fields["field1"].definitions == definitions
    assert fields["field2"].definitions == definitions
    assert fields["field3"].definitions == definitions



# Generated at 2022-06-24 11:01:13.291028
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Class(Schema):
        a = Field(required=True)
        b = Field(required=True)
        c = Field()
    assert len(Class()) == 2
    assert len(Class(a=1, b=2)) == 2
    assert len(Class(a=1, b=2, c=3)) == 3


# Generated at 2022-06-24 11:01:26.105184
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    # This raises a "NameError: name 'SchemaMetaclass' is not defined"
    # error.
    temp = SchemaMetaclass

    # This raises an "AttributeError: type object 'SchemaMetaclass' has no
    # attribute '__name__' " error.
    assert SchemaMetaclass.__name__ == "SchemaMetaclass"

    # This raises a "AttributeError: type object 'SchemaMetaclass' has no
    # attribute '__module__' " error.
    assert SchemaMetaclass.__module__ == "typesystem.schemas"

    # This raises a "AttributeError: type object 'SchemaMetaclass' has no
    # attribute '__doc__' " error.
    assert SchemaMetaclass.__doc__ == None

    # This raises a "AttributeError:

# Generated at 2022-06-24 11:01:27.625516
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sd = SchemaDefinitions()
    class Employee(Schema):
        name = field
    sd[Employee] = Employee
    assert_equal(sd[Employee], Employee)


# Generated at 2022-06-24 11:01:32.740277
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    d1 = SchemaDefinitions()
    d1['a'] = 'value-a'
    d1['b'] = 'value-b'
    assert len(d1) == 2

    del d1['a']
    assert len(d1) == 1
    assert d1['b'] == 'value-b'


# Generated at 2022-06-24 11:01:40.476474
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Create a SchemaDefinitions object.
    object = SchemaDefinitions()
    # Create a Schema object.
    schema = Schema()
    # Create an object of type Schema. Set the name attribute to Type 1.
    # Add this object to the definitions dictionary of the SchemaDefinitions object.
    object['Type 1'] = schema
    # Create another object of type Schema. Set the name attribute to Type 2.
    # Add this object to the definitions dictionary of the SchemaDefinitions object.
    object['Type 2'] = schema

    # Test a case when the SchemaDefinitions object is not empty

# Generated at 2022-06-24 11:01:52.755059
# Unit test for function set_definitions
def test_set_definitions():
    parent = Field()
    definitions = SchemaDefinitions({"my_parent": parent})
    array = Array(items=Integer())
    set_definitions(array, definitions)
    assert array.items.definitions == definitions
    array = Array(items=[Integer(), Integer()])
    set_definitions(array, definitions)
    assert array.items[0].definitions == definitions
    assert array.items[1].definitions == definitions
    object = Object(properties={"a": Integer()})
    set_definitions(object, definitions)
    assert object.properties["a"].definitions == definitions


# Generated at 2022-06-24 11:01:56.956119
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions(
        {"key1": 1, "key2": 2, "key3": 3}
    )
    assert len(schema_definitions) == 3
    del schema_definitions["key1"]
    assert len(schema_definitions) == 2
    with pytest.raises(AssertionError):
        del schema_definitions["key1"]
    with pytest.raises(KeyError):
        del schema_definitions["key4"]
    return


# Generated at 2022-06-24 11:02:07.515682
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    # test_SchemaDefinitions___getitem__
    class TestSchema(Schema):
        integer = Field(type="integer")
        boolean = Field(type="boolean")
        string = Field(type="string")
    sdef = SchemaDefinitions()
    sdef['TestSchema'] = TestSchema
    assert sdef['TestSchema'] == TestSchema
    # test_SchemaDefinitions___iter__
    assert list(iter(sdef)) == ['TestSchema']
    # test_SchemaDefinitions___len__
    assert len(sdef) == 1
    # test_SchemaDefinitions___setitem___key_already_set
    with pytest.raises(AssertionError) as excinfo:
        sdef['TestSchema'] = TestSchema

# Generated at 2022-06-24 11:02:13.866766
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    import typesystem
    from typesystem import validate


    class Person(Schema):
        name = typesystem.String()
        age = typesystem.Integer()
        city = typesystem.String(required=False)


    person = Person(name='test', age=12)
    assert person['name'] == 'test'
    assert person['age'] == 12
    assert person['city'] is None
    assert 'city' not in person

    with pytest.raises(KeyError):
        assert person['invalid']



# Generated at 2022-06-24 11:02:16.798985
# Unit test for function set_definitions
def test_set_definitions():
    class User(Schema):
        name = String()

    definitions = SchemaDefinitions()
    set_definitions(Reference(User), definitions)
    assert isinstance(definitions['User'], type)

# Generated at 2022-06-24 11:02:21.759127
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class SubSchema(Schema):
        sub_field = Field()

    class MySchema(Schema):
        my_field = Field()
        my_sub_field = Object(properties={"sub_field": SubSchema.fields["sub_field"]})
        sub_field = SubSchema.make_validator()


    definitions = SchemaDefinitions()
    assert definitions["SubSchema"] is SubSchema
    assert definitions["MySchema"] is MySchema

# Generated at 2022-06-24 11:02:29.034190
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert repr(Schema()) == "Schema()"
    assert repr(Schema("a")) == "Schema(a={})"
    assert repr(Schema("a", "b")) == "Schema(a=None, b=None)"
    assert repr(Schema("a", "b", "c")) == "Schema(a=None, b=None, c=None)"
    assert repr(Schema("a", "b", "c", "d")) == "Schema(a=None, b=None, c=None, d=None)"

# Generated at 2022-06-24 11:02:32.703993
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    print("Test SchemaDefinitions")
    obj = SchemaDefinitions()
    obj["key"] = "value"
    print("Key:value: ", obj["key"])
    assert obj["key"] == "value"

# Generated at 2022-06-24 11:02:41.313351
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    import json
    import sys
    import unittest


    class ExampleSchema(Schema):
        a = Field()


    class SchemaMetaclassTest(unittest.TestCase):
        def test(self):
            cls = ExampleSchema
            # Non-member attrs should be excluded from the iteration
            self.assertEqual(set(cls.__dict__.keys()), set(["a", "fields"]))
            # The field "a" is included, but "b" is not (since it doesn't have a default value)
            self.assertEqual(set(cls()), set(["a"]))


    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-24 11:02:46.185974
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class X(Schema):
        foo = "bar"
    class Y(Schema):
        foo = Reference(X)
    set_definitions(Y.fields["foo"], definitions)
    assert definitions[X.__name__] == X

# Generated at 2022-06-24 11:02:50.634672
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class FooSchema(Schema):
        pass
    foo_schema = FooSchema()
    assert foo_schema
    assert foo_schema.fields

    class BarSchema(Schema):
        bar = "Hello world!"
    bar_schema = BarSchema()
    assert bar_schema
    assert bar_schema.fields
    assert bar_schema.fields['bar'] == "Hello world!"

# Generated at 2022-06-24 11:02:53.337062
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Arrange
    defs = SchemaDefinitions()
    key = "key"
    value = "value"
    # Act
    defs[key] = value
    # Assert
    assert value == defs._definitions["key"]



# Generated at 2022-06-24 11:02:58.668985
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class A(Schema):
        a = int

    a = A(a=1)

# Generated at 2022-06-24 11:03:03.999483
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typing import Any, Dict, Type
    from typesystem.fields import String, Integer

    class Song(Schema):
        title = String(max_length=50)
        artist = String(max_length=50)
        duration = Integer(minimum=1, maximum=600)

    song = Song()

    assert repr(song) == "Song() [sparse]"

    song = Song(title="All Star", artist="Smash Mouth", duration=200)

    assert repr(Song) == "Song(title='All Star', artist='Smash Mouth', duration=200)"



# Generated at 2022-06-24 11:03:05.244375
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    pass



# Generated at 2022-06-24 11:03:09.354812
# Unit test for function set_definitions
def test_set_definitions():
    foo = Reference('bar', max_length=3)
    defs = SchemaDefinitions()
    defs['bar'] = Array(foo, max_length=2)
    set_definitions(foo, defs)
    assert foo.definitions['bar']['foo']['max_length'] == 3
    assert foo.definitions['bar']['max_length'] == 2

# Generated at 2022-06-24 11:03:16.379668
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    print("test __iter__() of class Schema")
    class TestSchema(Schema):
        field1 = Array(items=Field())
        field2 = Array(items=Field())
    ts = TestSchema()
    assert list(ts) == list()
    ts.field1 = [None]
    assert list(ts) == ["field1"]
    ts.field2 = [None]
    assert list(ts) == ["field1", "field2"]


# Generated at 2022-06-24 11:03:18.380898
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    SchemaDefinitions()



# Generated at 2022-06-24 11:03:20.277902
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    assert len(schema_definitions) == 0


# Generated at 2022-06-24 11:03:23.424464
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Inititalize test data
    definitions = SchemaDefinitions()

    class Foo(Schema):
        foo = Field()
        bar = Field()
        
    # Actual test
    instance = Foo()



# Generated at 2022-06-24 11:03:36.573990
# Unit test for constructor of class Schema
def test_Schema():
    class A(Schema):
        a = Field().tag(title="A")
    a = A()
    assert a.a is None
    class B(Schema):
        b = Field().tag(title="B")
        c = Field().tag(title="C")
    b = B(dict(b="b"))
    assert b.b == "b"
    assert b.c is None
    class C(Schema):
        c = Field().tag(title="C")
    c = C(dict(c="c"))
    assert c.c == "c"
    class D(Schema):
        d = Field().tag(title="D")
    d = D(dict(d={"d":"d"}))
    assert d.d == {"d":"d"}

# Generated at 2022-06-24 11:03:39.065647
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
  class Test(Schema):
      date = String()
  test = Test(date="2020-01-01")
  assert test["date"] == "2020-01-01"


# Generated at 2022-06-24 11:03:40.042000
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    pass

# Generated at 2022-06-24 11:03:48.799023
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    from collections import defaultdict
    from typesystem import SchemaDefinitions
    from typesystem import Integer
    from typesystem import String
    sd = SchemaDefinitions()
    assert len(sd) == 0
    sd = SchemaDefinitions({'age': 7, 'name': 'foo'})
    assert len(sd) == 2
    sd = SchemaDefinitions(name='kiki', age=7)
    assert len(sd) == 2
    sd = SchemaDefinitions(name='kiki')
    assert len(sd) == 1
    sd = SchemaDefinitions((('age', 7), ('name', 'foo'), ('one', 1), ('two', 2)))
    assert len(sd) == 4
    sd = SchemaDefinitions(defaultdict(int, age=7, name='foo'))
    assert len(sd) == 2

# Generated at 2022-06-24 11:03:52.219974
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        bar = Field()

    foo = Foo(bar="baz")

    assert foo.bar == "baz"

# Generated at 2022-06-24 11:03:55.345082
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['A'] = 1
    assert len(definitions) == 1
    del definitions['A']
    assert len(definitions) == 0


# Generated at 2022-06-24 11:04:03.111414
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class UserSchema(Schema):
        name = Field()
        age = Field(required=False)
        country = Field(required=False)
    user_schema_1 = UserSchema(name="John", age=20)
    user_schema_2 = UserSchema(name="John", age=20)
    user_schema_3 = UserSchema(name="John", age=20, country="USA")
    assert user_schema_1 == user_schema_2
    assert user_schema_1 != user_schema_3
    assert user_schema_2 != user_schema_3


# Generated at 2022-06-24 11:04:09.140867
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Car(Schema):
        make = Field(str)
        model = Field(str)
        year = Field(int)

    car = Car(make="Ford", model="Focus", year=2000)
    assert car['make'] == 'Ford'
    assert car['model'] == 'Focus'
    assert car['year'] == 2000
    assert car.is_sparse == False
    assert car.make == 'Ford'
    assert car.model == 'Focus'
    assert car.year == 2000


# Generated at 2022-06-24 11:04:18.253769
# Unit test for method validate of class Reference
def test_Reference_validate():
    class MyReference(Reference):
        def __init__(self, obj, definitions=None, **kwargs):
            super().__init__(obj, definitions, **kwargs)

    class A(Schema):
        def __init__(self, a = None, b = None, c = None, d = None):
            super().__init__(a = a, b = b, c = c, d = d)

    class B(Schema):
        def __init__(self, a = None, b = None, c = None, d = None):
            super().__init__(a = a, b = b, c = c, d = d)
    
    # case 1: failed when using reference to validate value, because the reference is not in definitions
    definitions1 = {}

# Generated at 2022-06-24 11:04:23.885199
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class TestSchema(Schema):
        field1 = String()
        field2 = Integer()
        field3 = Boolean()
        field4 = Float()
        field5 = String()

    test_schema = TestSchema({'field1': 'value1', 'field2': 42, 'field3': True, 'field4': 3.14, 'field5': 'value5'})

    assert test_schema['field1'] == "value1"
    assert test_schema['field2'] == 42
    assert test_schema['field3'] == True
    assert test_schema['field4'] == 3.14
    assert test_schema['field5'] == "value5"

    assert test_schema['field2'] == test_schema.field2.validate(42)

# Generated at 2022-06-24 11:04:31.720403
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():

    class Person(Schema):
        first_name = String()
        last_name = String()
        age = Integer()
        dob = Date()
        salary = Number()
        bio = String()

    p = Person(first_name='John', last_name='Doe', bio='A person')
    assert isinstance(p['first_name'], str)
    assert p['first_name'] == 'John'
    assert p['bio'] == 'A person'
    assert 'age' not in p
    assert 'dob' not in p
    assert 'salary' not in p


# Generated at 2022-06-24 11:04:37.428877
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Schema
    from typesystem import String
    fields = {"foo": String(), "bar": String()}
    class MySchema(Schema, fields=fields):
        pass
    my_schema = MySchema(foo="test_foo", bar="test_bar")
    assert sorted(list(my_schema.__iter__())) == sorted(["foo", "bar"])
    my_schema = MySchema(foo="test_foo")
    assert sorted(list(my_schema.__iter__())) == sorted(["foo"])


# Generated at 2022-06-24 11:04:39.188029
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference(to='a')
    assert ref.to == 'a'


# Generated at 2022-06-24 11:04:44.595031
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Setup
    d = SchemaDefinitions()
    # Test case 1
    key = ''
    value = ''
    try:
        d[key] = value
        assert False, "AssertionError expected"
    except AssertionError:
        pass
    # Test case 2
    key = ''
    value = ''
    d[key] = value
    # Verification
    assert d._definitions == {}
    # Cleanup - none necessary



# Generated at 2022-06-24 11:04:45.154792
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    pass

# Generated at 2022-06-24 11:04:53.760098
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class BaseSchema(Schema):
        name = String(max_length=100)
    class ItemSchema(Schema):
        name = String(max_length=100)
        description = String(max_length=100)
        quantity = Integer()
        price = Float()
        total = Reference('BaseSchema')
    obj = ItemSchema(
        name = 'item1',
        description = 'item1 description',
        quantity = 10,
        price = 10.5,
        total = BaseSchema(
            name = 'base1'
        )
    )
    serialized_obj = obj.serialize()
    assert serialized_obj['total']['name']=='base1'

# Generated at 2022-06-24 11:04:56.370992
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    class A(Schema):
        pass
    class B(Schema):
        pass
    definitions["A"] = A
    assert definitions["A"] == A

# Generated at 2022-06-24 11:05:01.469212
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import String
    class Foo(Schema):
        name = String()
        color = String()
    foo = Foo.validate({'name': 'Foo', 'color': 'red'})
    assert repr(foo) == "Foo(color='red', name='Foo')"


# Generated at 2022-06-24 11:05:02.681603
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()


# Generated at 2022-06-24 11:05:06.826485
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from typesystem import fields
    from typesystem.utils import OrderedDict

    class Book(Schema):
        title = fields.String()
        page_count = fields.Integer()

    assert Book(title="Example Book", page_count=10) == Book(page_count=10, title="Example Book")



# Generated at 2022-06-24 11:05:14.907322
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    d = {
        "aa": 2,
        "bb": "bbb",
        "cc": {
            "dd": "ddd",
            "ee": "eee",
            "ff": "fff"
        },
        "gg": [
            {"hh": "hhh"},
            {"ii": "iii"},
            {"jj": "jjj"}
        ],
        "kk": None
    }
    s = Schema(d)
    print(s.is_sparse)
    print(s.__getitem__("aa"))
    print(s.__getitem__("cc"))
    print(s.__getitem__("ff"))
    print(s.__getitem__("gg"))
    print(s.__getitem__("ii"))
    print(s.__getitem__("kk"))
    print

# Generated at 2022-06-24 11:05:23.662597
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # __delitem__(self, key: typing.Any) -> None
    test_input_value_key = 'test value'
    test_expected_value_result = None

    class TestSchema(Schema):
        pass

    test_object = SchemaDefinitions()
    test_object['test key'] = TestSchema()
    test_actual_value_result = test_object.__delitem__(test_input_value_key)
    assert test_expected_value_result == test_actual_value_result
    print('Success: test_SchemaDefinitions___delitem__\n')



# Generated at 2022-06-24 11:05:33.684424
# Unit test for method __repr__ of class Schema

# Generated at 2022-06-24 11:05:42.080902
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem import String, Integer, Boolean

    class Login(Schema):
        username = String(required=True)
        password = String(required=True)

    assert Login.fields == {
        "username": String(required=True),
        "password": String(required=True),
    }
    assert Login.make_validator() == Object(
        properties={
            "username": String(required=True),
            "password": String(required=True),
        },
        required=["username", "password"],
        additional_properties=None,
    )
    with pytest.raises(TypeError):
        Login(Login)
    with pytest.raises(TypeError):
        Login.validate(Login)

    class User(Schema):
        login = Login()
        age = Integer()
        active = Boolean()

# Generated at 2022-06-24 11:05:52.574772
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from hypothesis import settings
    from hypothesis.strategies import dictionaries, sampled_from, text


    array = [ "ABC_2", "ABC_1"]
    value_1 = array[0]
    value_2 = array[1]

    settings.register_profile("ci", deadline=None)
    settings.load_profile("ci")

    # dict_1 = { "name": text(), "id": text() }
    # dict_2 = { "name": text(), "id": text() }
    # dict_strategy = dictionaries(min_size=2, max_size=2, keys=sampled_from(array), values=text())
    dict_strategy = dictionaries(dict_1, dict_2)

    for item in dict_strategy.example():
        print(item)


# Generated at 2022-06-24 11:05:54.435137
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    s = Schema()
    assert eval(repr(s)) == s


# Generated at 2022-06-24 11:06:00.084575
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # Test the initialization of a SchemaDefinitions object
    # Success case
    def test_SchemaDefinitions_init():
        sys.tracebacklimit = 0
        try:
            Schemadefinitions = SchemaDefinitions()
        except:
            Schemadefinitions = False
        assert Schemadefinitions
    test_SchemaDefinitions_init()


# Generated at 2022-06-24 11:06:02.372758
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from unittest import mock

    test_schema = Schema("test")
    assert test_schema.__repr__() == 'test'

# Generated at 2022-06-24 11:06:10.410749
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class PersonSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)
        height = Field(type=float)
        sex = Field(type=str)

    person1 = PersonSchema(name='Lily', age=25, height=1.65, sex='F')

    person2 = PersonSchema(name='Lily', age=25, height=1.65, sex='F')
    assert person1 == person2

    person3 = PersonSchema(name='Tom', age=30, height=1.80, sex='M')
    assert person1 != person3



# Generated at 2022-06-24 11:06:11.655552
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd = SchemaDefinitions()
    assert sd is not None


# Generated at 2022-06-24 11:06:20.839751
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd = SchemaDefinitions()
    assert sd == {}
    sd = SchemaDefinitions(runtimeError='error')
    assert sd == {'runtimeError': 'error'}
    sd = SchemaDefinitions(runtimeError='error', equals='=')
    assert sd == {'runtimeError': 'error', 'equals': '='}
    sd2 = SchemaDefinitions({'abc': 'abc'})
    assert sd2 == {'abc': 'abc'}
    sd = SchemaDefinitions(runtimeError='error', equals='=')
    sd['abc'] = 'def'
    assert sd == {'runtimeError': 'error', 'equals': '=', 'abc': 'def'}
    assert len(sd) == 3
    iter_sd = iter(sd)
    assert next(iter_sd) == 'runtimeError'

# Generated at 2022-06-24 11:06:25.352148
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 11:06:34.964112
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.base import Message
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String

    class Author(Schema):
        name = String()

    class Site(Schema):
        author = Reference(to=Author)

    class Post(Schema):
        site = Reference(Author, definitions=SchemaDefinitions(Author=Author))
        author = Reference(Author, definitions=SchemaDefinitions(Author=Author))
        authors = Reference([Author], definitions=SchemaDefinitions(Author=Author))
        author_name = Reference(Author, definitions=SchemaDefinitions(Author=Author))

    author = Author(name='Joe Blogs')
    site = Site(author=author)

# Generated at 2022-06-24 11:06:43.366247
# Unit test for constructor of class Schema
def test_Schema():
    class MySchema(Schema):
        name = Field(type=str)
        popularity = Field(type=int)

    m = MySchema(name="my schema", popularity=0)

    m = MySchema(m)

    m.name = "new name"

    m = MySchema({"name": "my schema", "popularity": 0})

    m.name
    m.name = "new name"
    m["name"]

    m = MySchema(name="my schema")

    m.popularity = 0

    m = MySchema(name="my schema", popularity=0, extra="extra")

# Generated at 2022-06-24 11:06:50.147915
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    obj = SchemaDefinitions()
    # nothing happens if no arguments are passed
    # __iter__ is called externally on a built-in list
    assert list(obj) == []
    obj["the artist formerly known as Prince"] = "Raspberry Beret"
    obj[1] = "One"
    obj["12345"] = "Five"
    obj[3] = "Three"
    obj["2"] = "Two"
    obj[4] = "Four"
    actual = list(obj)
    expected = [1, 2, 3, 4, "12345", "2", "the artist formerly known as Prince"]
    assert actual == expected

# Generated at 2022-06-24 11:06:53.399467
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        test = "hello"

    schema = TestSchema()
    assert repr(schema) == "TestSchema()"
    schema = TestSchema(test="world")
    assert repr(schema) == "TestSchema(test='world')"

# Generated at 2022-06-24 11:06:55.452359
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    _definitions = dict()
    obj = SchemaDefinitions(_definitions)
    obj.__iter__()
    assert True # TODO: implement your test here


# Generated at 2022-06-24 11:07:04.405040
# Unit test for function set_definitions
def test_set_definitions():
    class ChildSchema(Schema):
        field1 = String()
        field2 = String()

    class ParentSchema(Schema):
        field1 = String()
        field2 = Reference(to="ChildSchema")
        field3 = Array(Reference(to="ChildSchema"))

    definitions = SchemaDefinitions()
    set_definitions(ChildSchema, definitions)
    set_definitions(ParentSchema, definitions)

    assert definitions["ChildSchema"] is ChildSchema
    assert ParentSchema.fields["field2"].target is ChildSchema
    assert ParentSchema.fields["field3"].items.target is ChildSchema

# Generated at 2022-06-24 11:07:13.980932
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert dict(SchemaDefinitions()) == {}
    assert dict(SchemaDefinitions([("a", "b"), ("c", "d")])) == {"a":"b", "c":"d"}
    assert dict(SchemaDefinitions(a="b", c="d")) == {"a":"b", "c":"d"}
    assert dict(SchemaDefinitions({"a":"b", "c":"d"})) == {"a":"b", "c":"d"}


# Generated at 2022-06-24 11:07:18.646871
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    try:
        # It is expected that the method serialize raises a TypeError
        # because the class Reference has no method serialize.
        Reference.serialize({"test": "test"})
        raise TypeError
    except TypeError:
        pass
    except:
        raise TypeError


# Generated at 2022-06-24 11:07:31.887361
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import String
    foo = String()
    class Bar(Schema):
        name = String()
    assert Reference(Bar).validate({"name": "one"}, strict=True)
    assert Reference(Bar).validate({"name": "one"})
    assert Reference(Bar).validate({"name": "one"}, strict=False)
    assert Reference(Bar, definitions={}).validate({"name": "one"}, strict=True)
    assert Reference(Bar, definitions={}).validate({"name": "one"})
    assert Reference(Bar, definitions={}).validate({"name": "one"}, strict=False)
    assert Reference(Bar, definitions={"Bar": Bar}).validate({"name": "one"}, strict=True)

# Generated at 2022-06-24 11:07:36.398222
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference.validate('tests/typesystem/test_schema.py', strict=True) is 'tests/typesystem/test_schema.py'
test_Reference()

# Generated at 2022-06-24 11:07:40.544063
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    dic = {"Test1": 1, "Test2":2, "Test3":3}
    s = SchemaDefinitions(dic)
    assert s["Test1"] == 1
    assert s["Test2"] == 2
    assert s["Test3"] == 3


# Generated at 2022-06-24 11:07:42.493254
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    def_ = SchemaDefinitions({"test": "val"})
    assert def_["test"] == "val"


# Generated at 2022-06-24 11:07:53.776990
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    from unittest import TestCase, main
    class Test(TestCase):
        def test(self):
            class MySchema(Schema):
                a = 1

            One = MySchema(a = 1)
            Two = MySchema(a = 2)
            Three = MySchema(a = 2)
            MySchemaDefinitions = SchemaDefinitions()
            MySchemaDefinitions["One"] = One
            with self.assertRaises(AssertionError):
                MySchemaDefinitions["Ones"] = Two
            self.assertEqual(MySchemaDefinitions["One"], One)
            self.assertEqual(MySchemaDefinitions.get("Ones"), None)
            self.assertEqual(MySchemaDefinitions.get("One"), One)

# Generated at 2022-06-24 11:07:58.318227
# Unit test for function set_definitions
def test_set_definitions():
    class Nested(Schema):
        value = Field()

    class TestSchema(Schema):
        value = Field()
        array = Array(items=Field())
        nested = Object(properties={"value": Field()})
        ref = Reference("Nested")
        ref_array = Array(items=Reference("Nested"))

        class Meta:
            definitions = SchemaDefinitions()

    assert TestSchema.Meta.definitions == {"Nested": Nested}
    assert TestSchema.fields["ref"].definitions == {"Nested": Nested}

# Generated at 2022-06-24 11:08:00.248981
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert len(SchemaDefinitions()) == 0


# Generated at 2022-06-24 11:08:08.986060
# Unit test for constructor of class Reference
def test_Reference():
  from typesystem import Boolean, String, Integer
  from typesystem.forms import Form
  from typesystem.object import Object
  from typesystem.schema import Schema
  from typesystem.validators import all_of, any_of, boolean, choice, email, enum, equal, exclusive_maximum, exclusive_minimum, less_than, less_than_or_equal, max_length, maximum, min_length, minimum, multiple_of, not_equal, one_of, pattern, required, required_if, required_unless, same_as, type_validator

  class Fruits(Schema):
    class Meta:
      fields = {'name': String(), 'is_fruit': Boolean()}

  reference = Reference('Fruits', definitions={'Fruits': Fruits})
  assert reference == Reference('Fruits', definitions={'Fruits': Fruits})

# Generated at 2022-06-24 11:08:19.676491
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # 1. test case
    class_name = "MySchema"
    bases = (object,)
    attrs = {
        "id": Field(type="string", description="The unique ID for an object."),
        "name": Field(type="string"),
    }
    definitions = {}
    expected = object.__new__(SchemaMetaclass)
    new_schema = MySchema.__new__(SchemaMetaclass, class_name, bases, attrs, definitions)
    assert new_schema == expected
    # 2. test case
    class_name = "MySchema"
    bases = (object,)
    attrs = {
        "id": Field(type="string", description="The unique ID for an object."),
        "name": Field(type="string"),
    }
    definitions = {}


# Generated at 2022-06-24 11:08:28.879837
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class User(Schema):
        username = Field(str)
        id = Field(int)
        is_active = Field(bool, default=True)
        aliases = Array(str)

    user1 = User(username="alice", id=123, aliases=["alice1", "alice2"])
    user2 = User(username="alice", id=123, aliases=["alice1", "alice2"])
    user3 = User(username="alice", id=123, aliases=["alice1", "alice2"], is_active=False)
    user4 = User(username="alice", id=123)

    assert user1 == user2
    assert user1 != user3
    assert user1 != user4

# Generated at 2022-06-24 11:08:31.362404
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class MySchema(Schema):
        f = Field()
    assert MySchema.__name__ == "MySchema"
    assert MySchema.fields == {"f": Field()}

# Generated at 2022-06-24 11:08:39.794897
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
	# Test for sparse=False
	i=0
	while i<10:
		args={}
		args['i']=i
		i+=1
		args['name']=chr(i)
		i+=1
		args['age']=i
		i+=1
		expected_value=True
		o=Schema(**args)
		while i<10:
			args['i']=i
			i+=1
			args['name']=chr(i)
			i+=1
			args['age']=i
			i+=1
			actual_value=o.__eq__(Schema(**args))

# Generated at 2022-06-24 11:08:43.147566
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field(String)
        b = Field(String, default="default")

    a = A()
    assert a.a == None
    assert a.b == "default"

    b = A({"a": "a"})
    assert b.a == "a"
    assert b.b == "default"

    assert a == A()
    assert b == A({"a": "a"})


# Generated at 2022-06-24 11:08:47.775686
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class User(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    user = User({"name": "Foo", "age": 10})
    assert user["name"] == "Foo"
    assert user["age"] == 10
    del user["name"]
    assert user["name"] == None



# Generated at 2022-06-24 11:08:53.496834
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        first_name = Field(type_=str)
        last_name = Field(type_=str)

    out = Person(first_name="John", last_name="Doe")
    assert out == Person(first_name="John", last_name="Doe")
    assert "first_name='John', last_name='Doe'" in repr(out)
    assert "John" not in repr(Person())
    assert "Doe" not in repr(Person())

# Generated at 2022-06-24 11:09:02.683460
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # assert (Unit test for method __eq__ of class Schema)
    from typesystem import String
    class Example(Schema):
        foo = String()
        bar = String(default="")
    example1 = Example({"foo": "1"})
    example2 = Example({"foo": "2"})
    example3 = Example({"foo": "1"})
    example4 = Example({"foo": "1", "bar": ""})
    example5 = Example()
    assert example1 == example3
    assert not example1 == example2
    assert example1 == example4
    assert example5 == Example({"bar": ""})
    assert not example1 == 1
    assert not example1 == {}


# Generated at 2022-06-24 11:09:11.687398
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Setup
    class BaseSchema:
        pass

    class DefinitionA(Schema):
        pass

    class DefinitionB(Schema):
        pass

    class DefinitionC(Schema):
        pass

    class DefinitionD(Schema):
        pass

    class SchemaDerivedA(Schema):
        a = Reference(
            "DefinitionA",
            definitions=SchemaDefinitions(  # pylint:disable=unnecessary-comprehension
                {class_.__name__: class_ for class_ in [DefinitionA, DefinitionB]}
            ),
        )


# Generated at 2022-06-24 11:09:13.476484
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    obj = SchemaDefinitions({"test": "test1"})
    print(obj["test"])

test_SchemaDefinitions___setitem__()

# Generated at 2022-06-24 11:09:18.172648
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    input1 = {('spam', 'ham'): None}
    expected_output = 2
    obj = SchemaDefinitions(input1)
    output = len(obj)
    assert output == expected_output
    assert type(output) is int


# Generated at 2022-06-24 11:09:28.982082
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        x = Field(required=True)
        y = Field()

    assert TestSchema().is_sparse
    assert TestSchema(x=1, y=2) == TestSchema({"x": 1, "y": 2})

    with pytest.raises(TypeError) as excinfo:
        TestSchema(z=1)

    assert str(excinfo.value).startswith("Invalid argument")

    with pytest.raises(TypeError) as excinfo:
        TestSchema(x=1, y=2, z=3)

    assert str(excinfo.value).startswith("z is an invalid")

    with pytest.raises(TypeError) as excinfo:
        TestSchema(1)

    assert str(excinfo.value).startswith

# Generated at 2022-06-24 11:09:30.636538
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    ret = len(obj)
    assert ret == 0


# Generated at 2022-06-24 11:09:36.265351
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        name = String(max_length=50)
        age = Integer(minimum=18)
        occupation = String()

    class PersonReference(Schema):
        person = Reference(to=Person)

    p = Person('John', 19, 'Student')
    pr = PersonReference(person=p)
    print(pr.person)
    print(pr.serialize(pr.person))


# Generated at 2022-06-24 11:09:42.700743
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    obj = SchemaDefinitions()
    assert len(obj) == 0
    obj = SchemaDefinitions()
    obj['a'] = 1
    assert len(obj) == 1
    obj = SchemaDefinitions()
    obj['a'] = 1
    obj['b'] = 2
    assert len(obj) == 2
    obj = SchemaDefinitions()
    obj['a'] = 1
    obj['b'] = 2
    obj['c'] = 3
    assert len(obj) == 3
    obj = SchemaDefinitions()
    obj['a'] = 1
    obj['b'] = 2
    obj['c'] = 3
    obj['d'] = 4
    assert len(obj) == 4


# Generated at 2022-06-24 11:09:49.824482
# Unit test for constructor of class Reference
def test_Reference():
    to = "abc"
    definitions = SchemaDefinitions()
    allow_null = True
    null_error = "May not be null."
    t = Reference(to, definitions, allow_null, null_error)
    assert t.to == to
    assert t.target_string == to
    assert t.definitions == definitions
    assert t._target_string == "abc"
    assert t.allow_null == allow_null
    assert t.errors["null"] == null_error
    assert t.target == to



# Generated at 2022-06-24 11:09:59.390693
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Boolean, Integer, String
    from typesystem.schema import Schema

    class MySchema(Schema):
        name = String(max_length=50)
        email = String(format="email")
        age = Integer(minimum=0, maximum=130)
        is_active = Boolean()

    s = MySchema(name="A", email="B", age=18, is_active=True)

    assert isinstance(s, Mapping)
    assert isinstance(s, MySchema)

    assert isinstance(s["name"], str)
    assert isinstance(s["email"], str)
    assert isinstance(s["age"], int)
    assert isinstance(s["is_active"], bool)

    assert set(s.keys()) == {"name", "email", "age", "is_active"}
