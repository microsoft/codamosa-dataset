

# Generated at 2022-06-24 10:59:58.863575
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    '''
    class Document(Schema):
        ref = typesystem.Reference("Item")
        children = typesystem.Array(typesystem.Reference("Item"))
        json = typesystem.JSON()
        number = typesystem.Integer()
    '''
    class Document(Schema):
        ref = Reference("Item")
        children = Array(Reference("Item"))
        json = JSON()
        number = Integer()
    '''
    class Item(Schema):
        title = typesystem.String()
        description = typesystem.String()
    '''
    class Item(Schema):
        title = String()
        description = String()

    class Order(Schema):
        '''
        ...
        class Meta:
            fields = ["id", "state"]
        ...
        '''
        fields = ["id", "state"]

# Generated at 2022-06-24 11:00:02.067342
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions['a'] = 'b'
    assert definitions == {'a':'b'}

# Generated at 2022-06-24 11:00:11.377493
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    d = {}
    assert len(d) == 0
    assert len({}) == 0
    d["test1"] = 1
    assert len(d) == 1
    assert len({"test1": 1}) == 1
    d["test2"] = 2
    assert len(d) == 2
    assert len({"test1": 1, "test2": 2}) == 2
    del d["test1"]
    assert len(d) == 1
    assert len({"test2": 2}) == 1
    del d["test2"]
    assert len(d) == 0
    assert len({}) == 0
    try:
        d["test3"]
        assert False
    except KeyError:
        pass
    try:
        del d["test3"]
        assert False
    except KeyError:
        pass

# Generated at 2022-06-24 11:00:14.138682
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    d = SchemaDefinitions()
    d["a"] = 1
    d["b"] = 2
    assert len(d) == 2
    del d["b"]
    assert len(d) == 1

# Generated at 2022-06-24 11:00:22.489320
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String

    class UserSchema(Schema):
        username = String(max_length=128)
        age = String()

        class Meta:
            strict = True

    assert UserSchema.fields == {"username": String(max_length=128), "age": String()}
    try:
        class UserSchema1(Schema):
            username = String(max_length=128)
            age = String()
            class Meta:
                strict = True
            username = String(max_length=128)
    except AssertionError:
        pass
    try:
        class UserSchema2(Schema):
            username = String()
            age = String()

            class Meta:
                strict = True

            username = String(max_length=128)
    except AssertionError:
        pass


# Generated at 2022-06-24 11:00:26.344418
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    example = {'number': 5, 'string': 'hello world'}
    assert len(example) == 2
    assert example['number'] == 5
    assert example['string'] == 'hello world'
    assert 'number' in example
    assert 'string' in example
    assert 'foo' not in example


# Generated at 2022-06-24 11:00:27.429096
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert SchemaDefinitions() is not None


# Generated at 2022-06-24 11:00:31.331008
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import String
    class Book(Schema):
        name = String()
    book = Book.validate({"name" : "Book"})
    assert book["name"] == "Book"
    return book


# Generated at 2022-06-24 11:00:37.286986
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions["key_0"] = "value_0"
    assert schema_definitions.__setitem__("key_1", "value_1") == None
    assert schema_definitions.__setitem__("key_1", "value_1") == None


# Generated at 2022-06-24 11:00:43.680749
# Unit test for method validate of class Reference
def test_Reference_validate():
    """
    Test Reference.validate
    """
    from typesystem.fields import Integer, String
    from typing import Dict
    class DummySchemaDefinitions(Mapping):
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            self._definitions = dict(*args, **kwargs)  # type: dict

        def __getitem__(self, key: typing.Any) -> typing.Any:
            return self._definitions[key]

        def __iter__(self) -> typing.Iterator[typing.Any]:
            return iter(self._definitions)

        def __len__(self) -> int:
            return len(self._definitions)


# Generated at 2022-06-24 11:00:47.411754
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # Test calling Schema.__getitem__ with invalid key
    schema = Schema(validate_1="validate_1")
    try:
        schema__getitem__ = schema.__getitem__("invalid")
    except KeyError:
        pass



# Generated at 2022-06-24 11:00:49.482877
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class _Schema(Schema):
        name = "Bob"
    _Schema() == _Schema()


# Generated at 2022-06-24 11:00:51.819352
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    one = Schema({"one":1, "two":2})
    two = Schema({"two":2, "three":3})
    assert(one.__eq__(two) == False)


# Generated at 2022-06-24 11:00:53.857089
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
	definitions = SchemaDefinitions()
	definitions['test'] = 'test'
	assert definitions['test'] == 'test'


# Generated at 2022-06-24 11:00:57.254278
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        name = String()
    schema = MySchema(name="NAME")
    repr_result = repr(schema)
    assert repr_result == 'MySchema(name=\'NAME\')'

# Generated at 2022-06-24 11:00:59.266724
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    key = 'id'
    class UserSchema(Schema):
        id = Integer()
    user = UserSchema()
    assert user[key] is None

# Generated at 2022-06-24 11:01:06.091895
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions()
    assert definitions == {}
    assert len(definitions) == 0
    definitions['S1'] = 'Schema 1'
    assert definitions == {'S1': 'Schema 1'}
    assert len(definitions) == 1
    definitions['S2'] = 'Schema 2'
    assert definitions == {'S1': 'Schema 1', 'S2': 'Schema 2'}
    assert len(definitions) == 2
    definitions['S3'] = 'Schema 3'
    assert definitions == {'S1': 'Schema 1', 'S2': 'Schema 2', 'S3': 'Schema 3'}
    assert len(definitions) == 3
    del definitions['S3']

# Generated at 2022-06-24 11:01:08.975230
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    # Given
    schema_1 = Schema(None, None)
    schema_2 = Schema(None, None)

    # When
    result = schema_1.__eq__(schema_2)

    # Then
    assert result is True



# Generated at 2022-06-24 11:01:10.331725
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # TODO: to be implemented
    pass


# Generated at 2022-06-24 11:01:15.525165
# Unit test for constructor of class Schema
def test_Schema():
    import pytest
    class PersonSchema(typing.NamedTuple):
        name: typing.Optional[str]
        age: typing.Optional[int]

    person = PersonSchema(name='john', age=30)
    assert person.name == 'john'
    assert person.age == 30

if __name__ == '__main__':
    import pytest
    pytest.main(["-s", "-v", __file__])

# Generated at 2022-06-24 11:01:21.937020
# Unit test for method validate of class Reference
def test_Reference_validate():
    class User(Schema):
        username = String(max_length=10)

    class Comment(Schema):
        body = String()
        author = Reference(User)

    assert Comment({
        "body": "This is a great article!",
        "author": {
            "username": "dave"
        }
    })

test_Reference_validate()

# Generated at 2022-06-24 11:01:26.770629
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class DeleteRequest(Schema):
        reference = Reference(to='Schema')
        deleted = Boolean()
    # Unit test for method serialize of class Reference
    ref = Reference(to=Schema)
    assert 'Schema' == ref.target_string



# Generated at 2022-06-24 11:01:30.160160
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import String, Integer

    class User(Schema):
        name = String()
        age = Integer()

    user = User(name="foo", age=42)
    assert repr(user) == "User(name='foo', age=42)"

# Generated at 2022-06-24 11:01:32.082516
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert SchemaDefinitions().__init__() == None


# Generated at 2022-06-24 11:01:38.225977
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class S1(Schema):
        name = String()
    
    class S2(Schema):
        name = String()
    
    s1 = S1(name='s1')
    assert s1 == s1
    assert not s1 == S1(name='not-s1')
    assert not s1 == S1(name=None)
    assert not s1 == 's1'
    assert not s1 == S2(name='s1')
    assert not s1 == None
    
    s2 = S2(name='s2')
    assert s2 == s2
    assert not s2 == S2(name='not-s2')
    assert not s2 == S2(name=None)
    assert not s2 == 's2'
    assert not s2 == S1(name='s2')

# Generated at 2022-06-24 11:01:46.990216
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    colors = ['red', 'blue', 'green']
    assert len(colors) == 3
    d1 = SchemaDefinitions({'a':1, 'b':2, 'c':3, 'd':4})
    assert len(d1) == 4
    d2 = SchemaDefinitions([('A', 1), ('B', 2), ('C', 3)])
    assert len(d2) == 3
    d3 = SchemaDefinitions(A = 1, B = 2, C = 3, D = 4)
    assert len(d3) == 4


# Generated at 2022-06-24 11:01:51.204609
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    a = SchemaDefinitions({'b': 'c'})
    f = a.__iter__()
    assert f is not None
    assert str(f) == '<dict_keyiterator object at 0x7fe9c9e06b10>'


# Generated at 2022-06-24 11:02:04.519101
# Unit test for constructor of class Schema
def test_Schema():
    class Test(Schema):
        field1 = Integer()
        field2 = String(max_length=3)
        field3 = Number()
        field4 = Boolean()
    assert Test({'field1': 1, 'field2': 'abc', 'field3': 3, 'field4': True}).field1 == 1
    assert Test({'field1': 1, 'field2': 'abc', 'field3': 3, 'field4': True}).field2 == 'abc'
    assert Test({'field1': 1, 'field2': 'abc', 'field3': 3, 'field4': True}).field3 == 3
    assert Test({'field1': 1, 'field2': 'abc', 'field3': 3, 'field4': True}).field4 == True

# Generated at 2022-06-24 11:02:11.253578
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions=SchemaDefinitions()
    item = {'a':1}
    key = 'a'
    value = 100
    assert 'a' not in definitions._definitions
    definitions.__setitem__(key,value)
    assert 'a' in definitions._definitions
    assert definitions.__getitem__(key) == value
    assert definitions.__len__() == 1
    definitions.__delitem__(key)
    assert definitions.__len__() == 0
    definitions.update(**item)
    definitions.clear()
    assert definitions.__len__() == 0


# Generated at 2022-06-24 11:02:20.340970
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typing import Any
    import typesystem as ts

    class Schema1(ts.Schema):
        property1 = ts.Field()

    class Schema2(ts.Schema):
        property2 = ts.Field()

    class Schema3(ts.Schema):
        reference = Reference(
            to=Schema1,
            definitions={
                "Schema1": Schema1,
                "Schema2": Schema2
            }
        )

    b: Schema3 = Schema3(reference={'property1': 'value'})
    assert (b.reference.property1 == 'value')


# Generated at 2022-06-24 11:02:30.421127
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Note that this test is not very useful. The docstring
    # of deque.__len__ says that "len(d) only requires
    # support for __getitem__() and __len__()." The
    # implementation of deque.__len__ is simply "def __len__(self):
    # return len(self._init)", so it merely delegates to the
    # len function to calculate the length of the _init array.
    # If the len function is implemented correctly, the
    # implementation of deque.__len__ is also correct.
    from hypothesis import given
    from hypothesis.strategies import lists, integers
    from collections import deque

    @given(integers(min_value=0))
    def test_negative(x: int) -> None:
        d = deque()
        assert len(d) == 0



# Generated at 2022-06-24 11:02:40.660857
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)

        class Meta:
            strict = True

    person = Person(
        {
            "name": "Joe Bloggs",
            "age": 42,
        }
    )
    assert person["name"] == "Joe Bloggs"
    assert person["age"] == 42
    person = Person({"name": "Joe Bloggs", "age": 42})
    assert person["name"] == "Joe Bloggs"
    assert person["age"] == 42
    person = Person(name="Joe Bloggs", age=42)
    assert person["name"] == "Joe Bloggs"
    assert person["age"] == 42

# Generated at 2022-06-24 11:02:44.941691
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = Field(type="string")
    assert len(Person(name="John")) == 1



# Generated at 2022-06-24 11:02:47.274761
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    def test():
        schema_definitions = SchemaDefinitions()
        schema_definitions['key'] = 'value'
        assert schema_definitions['key'] == 'value'
    test()

# Generated at 2022-06-24 11:02:50.670325
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    def check_equal(Schema):

        x = Schema()
        x.first = 1
        x.second = 2
        x.third = 3

        assert x["first"] == 1
        assert x["second"] == 2
        assert x["third"] == 3

        return True

    assert check_equal(Schema)



# Generated at 2022-06-24 11:02:55.321222
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert (Schema(name=1) == Schema(name=1)) == True
    assert (Schema(name=2) == Schema(name=1)) == False
    assert (Schema(name=1) == 1) == False
    

# Generated at 2022-06-24 11:03:03.660585
# Unit test for constructor of class Reference
def test_Reference():
    # Assuming this test is at the module level,
    # directory of the test file is working directory
    path_to_this_file = os.path.abspath(__file__)
    path_to_working_directory = os.path.dirname(path_to_this_file)
    # This is the path to the definitions file.
    path_to_definitions_file = os.path.join(path_to_working_directory, 'definitions.json')
    with open(path_to_definitions_file, "r") as file:
        data = json.loads(file.read())
    json_schema = Schema.from_definition(**data)
    # This is a dict that defines the structure of the JSON data in the definitions file.
    # Note that the dict is a recursive data structure.

# Generated at 2022-06-24 11:03:12.548482
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Base(Schema):
        '''
        docstring for Base
        '''
        base = Integer()
    
    class Derived(Base):
        '''
        docstring for Derived
        '''
        derived = Integer()
    
    def test_equal():
        '''
        docstring for test_equal
        '''
        base1 = Base(base=1)
        base2 = Base(base=1)
        assert base1 == base2
        derived1 = Derived(base=1, derived=2)
        derived2 = Derived(base=1, derived=2)
        assert derived1 == derived2
    
    def test_not_equal():
        '''
        docstring for test_not_equal
        '''
        base1 = Base(base=1)
        base2 = Base

# Generated at 2022-06-24 11:03:17.001382
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    assert definitions == {}
    definitions['foo'] = 42
    assert definitions == {'foo': 42}
    assert len(definitions) == 1
    try:
        definitions['foo'] = 99
    except Exception as e:
        pass
    else:
        assert False, "expecting exception"
    assert definitions == {'foo': 42}
    assert len(definitions) == 1


# Generated at 2022-06-24 11:03:19.813055
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    d = SchemaDefinitions();
    d['haha'] = 1;
    assert d['haha'] == 1;


# Generated at 2022-06-24 11:03:23.680601
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class UserSchema(Schema):
        name = Field(str)
        age = Field(int, default=10)
        tags = Array(String())

    user = UserSchema(name="user", tags=["student"])
    print(user)



# Generated at 2022-06-24 11:03:30.020210
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class Person(Schema):
        name = String()
        age = Integer()

    assert str(Person(name="John Doe", age=42)) == "Person(name='John Doe', age=42)"

# Generated at 2022-06-24 11:03:33.869909
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    def wrap(input):
        field = SchemaDefinitions(input)
        expected = len(input)
        actual = len(field)
        return actual == expected
    wrap([])
    wrap({"key": "value"})
    wrap({"key1": "value1", "key2": "value2"})



# Generated at 2022-06-24 11:03:36.204410
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sd = SchemaDefinitions()
    sd.__setitem__('1', {'name': 'shixi'})

    assert(sd['1'] == {'name': 'shixi'})

# Generated at 2022-06-24 11:03:37.742715
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions()
    definitions['temp'] = 'temp'
    assert definitions['temp'] == 'temp'


# Generated at 2022-06-24 11:03:38.709230
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    instance = SchemaDefinitions(test = 1)
    instance['test']


# Generated at 2022-06-24 11:03:45.592247
# Unit test for method validate of class Reference
def test_Reference_validate():
    test_value = {"name": "Test"}
    class TestSchema(Schema):
        name = String()

    ref = Reference(
        name="TestSchemaRef",
        to="TestSchema",
        definitions={"TestSchema": TestSchema},
        description="Test Ref Field"
    )

    assert ref.to == "TestSchema"
    assert ref.target == TestSchema
    assert ref.target_string == "TestSchema"
    assert ref.validate(test_value) == test_value


# Generated at 2022-06-24 11:03:52.329930
# Unit test for constructor of class Reference
def test_Reference():
    ref = Reference(str)
    assert ref.to == str
    assert not ref.allow_null
    assert not ref.required
    assert ref.default_value is None
    assert ref.description is None
    assert ref.name is None
    assert ref.title is None

    ref = Reference(str, description='abc')
    assert ref.description == 'abc'

# Generated at 2022-06-24 11:03:57.019271
# Unit test for constructor of class Reference
def test_Reference():
    class B(Schema):
        a = Reference("A")

    class A(Schema):
        b = Reference("B")

    assert B.fields['a'].target_string == "A"
    assert A.fields['b'].target_string == "B"
    assert B.fields['a'].target is A
    assert A.fields['b'].target is B

# Generated at 2022-06-24 11:04:01.115153
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Foo(Schema):
        bar = String()

    foo = Foo(bar="hello")
    assert repr(foo) == "Foo(bar='hello')"

    foo = Foo()
    assert repr(foo) == "Foo() [sparse]"



# Generated at 2022-06-24 11:04:05.552901
# Unit test for function set_definitions
def test_set_definitions():
    field = Object(properties={"id": Integer()})
    definitions = SchemaDefinitions({})
    set_definitions(field, definitions)
    assert field.properties["id"].definitions == definitions, f'{field.properties}'

# Generated at 2022-06-24 11:04:08.598440
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.schema import Schema
    schema = Schema()
    assert repr(schema) == "Schema()"

# Generated at 2022-06-24 11:04:15.504856
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    import json
    import jsonpickle
    a = SchemaDefinitions()
    b = SchemaDefinitions()
    b.__setitem__('a',1)
    assert a != b
    # test serialization
    assert jsonpickle.encode(a) != jsonpickle.encode(b)
    assert json.dumps(json.loads(jsonpickle.encode(a))) == jsonpickle.encode(a)
    assert json.dumps(json.loads(jsonpickle.encode(b))) == jsonpickle.encode(b)

# Generated at 2022-06-24 11:04:18.048822
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="Fred Flintstone", age=35)
    assert person["name"] == "Fred Flintstone"
    assert person["age"] == 35
    assert person["does-not-exist"] == None



# Generated at 2022-06-24 11:04:22.404891
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from bson.py3compat import b
    from typesystem.fields import Field, String
    # Define a new notebook Schema class
    class Example(Schema):
        name = String()
        age = Field(type=int)
    example = Example(name='John Doe', age=23)
    assert(example['name'] == 'John Doe')
    assert(example['age'] == 23)
    # Serialized
    assert(b(example['name']) == b'John Doe')
    assert(b(example['age']) == b'23')


# Generated at 2022-06-24 11:04:23.707396
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # __iter__ of class Schema is not a test
    pass


# Generated at 2022-06-24 11:04:28.478251
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    target = Object(properties={'field': {'type': 'string', 'required': True}})
    ref = Reference(to=target, definitions={'One': target})

    ref._target = target
    obj = ref.serialize({'field': 'string_example'})
    assert(obj == {'field': 'string_example'})


# Generated at 2022-06-24 11:04:31.097245
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
  s = SchemaDefinitions()
  s.__setitem__("Gato", "Gato")
  assert s["Gato"] == "Gato"


# Generated at 2022-06-24 11:04:34.252967
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    a = SchemaDefinitions([1, 2, 3], name='foo', anmes='bar')
    assert isinstance(a, typing.Mapping)
    assert isinstance(a, typing.MutableMapping)
    assert isinstance(a, SchemaDefinitions)

# Generated at 2022-06-24 11:04:36.552164
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd = SchemaDefinitions()
    assert len(sd) == 0
    sd['a'] = 5
    assert len(sd) == 1
    assert sd['a'] == 5


# Generated at 2022-06-24 11:04:37.898588
# Unit test for constructor of class Reference
def test_Reference():
    reference = Reference(to=Schema)


# Generated at 2022-06-24 11:04:42.182239
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from src.typesystem import String, Schema

    class Person(Schema):
        name = String(max_length=100)
        age = String(max_length=100)

    person = Person(name="John", age=10)

    result = [item for item in person]
    assert result == ['name', 'age']


# Generated at 2022-06-24 11:04:52.797789
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class A(Schema):
        a: str
        b: int = 123

    def test(a, b, expected, **kwargs):
        actual = A(**kwargs)
        assert actual == A(a=a, b=b)
        assert repr(actual) == expected
    yield test, "abc", 123, "A(a='abc', b=123)"
    yield test, "abc", 123, {"a": "abc"},

# Generated at 2022-06-24 11:05:05.071852
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    p = Person(name="Ada", age=66)
    assert p == Person(name="Ada", age=66)
    assert p != Person(name="Ada", age=67)
    assert p == Person(name="Ada", age=66)
    assert str(p) == "Person(name='Ada', age=66)"
    assert p == eval(str(p))
    assert Person.validate({"name": "Ada", "age": 66}) == Person(name="Ada", age=66)
    assert Person.validate_or_error({"name": "Ada", "age": 66}) == (
        Person(name="Ada", age=66),
        None,
    )

# Generated at 2022-06-24 11:05:07.241498
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        id: str

    assert list(TestSchema(id="foo")) == ["id"]


# Generated at 2022-06-24 11:05:10.552411
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class SchemaTest(Schema):
        string = 'str'

    st = SchemaTest()
    st.__init__(string='hello')
    if not (st['string'] == 'hello'):
        raise AssertionError



# Generated at 2022-06-24 11:05:11.812997
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    obj = {'a': 'b'}
    assert obj == Reference('any').serialize(obj)



# Generated at 2022-06-24 11:05:22.520882
# Unit test for method validate of class Reference
def test_Reference_validate():
    # input Object within Schema
    def test_obj_in_schema():
        class TestSchema(Schema):
            test_string = String()
            test_ref = Reference('TestClass')

        class TestClass(Schema):
            attr1 = String()
            attr2 = String()

        definitions = SchemaDefinitions()
        TestSchema.__init__(definitions=definitions)
        TestClass.__init__(definitions=definitions)
        test_obj = TestClass(attr1='test', attr2='test class')
        instance = TestSchema(test_string='test string', test_ref=test_obj).validate()
        assert instance.test_ref.attr1 == 'test'
        assert instance.test_ref.attr2 == 'test class'
        assert instance.test_ref

# Generated at 2022-06-24 11:05:27.952155
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
        name = String()
        age = Integer()

    Person()
    Person(name="John", age=1)
    Person({"name": "John", "age": 1})

    class Person(Schema):
        name = String()
        age = Integer(default=1)

    Person()

# Generated at 2022-06-24 11:05:30.212129
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
	d = SchemaDefinitions()
	d['key'] = 5
	assert d['key'] == 5
	del d['key']
	assert 'key' not in d


# Generated at 2022-06-24 11:05:31.568309
# Unit test for constructor of class Reference
def test_Reference():
    import typesystem
    Reference(to=typesystem.String)


# Generated at 2022-06-24 11:05:35.026826
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import String

    definitions = SchemaDefinitions()
    class TestSchema(Schema):
        field = String(required=True)

    class TestReference(Schema):
        field = Reference(TestSchema, definitions)

    TestReference.validate({'field': {'field': 'foo'}}, strict=True)

# Generated at 2022-06-24 11:05:41.119065
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Field()
        b = Field()

    class B(Schema):
        c = Field()
        d = Field()

    class C(A, B):
        e = Field()
        f = Field()

    assert C.fields == {
        'a': Field(name='a'),
        'b': Field(name='b'),
        'c': Field(name='c'),
        'd': Field(name='d'),
        'e': Field(name='e'),
        'f': Field(name='f'),
    }



# Generated at 2022-06-24 11:05:49.394026
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem.fields import String

    class User(Schema):
        name = String()

    assert hasattr(User, "fields")
    assert User.fields == {"name": String()}

    user = User({"name": "Joe"})
    assert user.name == "Joe"

    user = User(User({"name": "Joe"}))
    assert user.name == "Joe"

    user = User(name="Joe")
    assert user.name == "Joe"

    user = User(name="Joe", extra_attribute="oops")
    assert user.name == "Joe"


# Generated at 2022-06-24 11:05:51.347906
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    s = SchemaDefinitions(
        {
            "a": 1,
            "b": 2
        }
    )
    assert len(s) == 2


# Generated at 2022-06-24 11:05:59.186304
# Unit test for method validate of class Reference
def test_Reference_validate():
    data = {
        "name":"John",
        "surname":"Doe",
        "age": 30
    }

    class Person(Schema):
        name = String(max_length=30)
        surname = String(max_length=30)
        age = Integer()
    
    testReference = Reference(to="Person")
    person = Person.validate(data)
    assert testReference.validate(person) is not None


# Generated at 2022-06-24 11:06:07.201401
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        one = Reference("Two")
        three = Array(Reference("Four"))

    class Two(Schema):
        pass

    class Four(Schema):
        pass

    definitions = SchemaDefinitions()
    definitions["Two"] = Two
    definitions["Four"] = Four
    set_definitions(TestSchema.one, definitions)
    set_definitions(TestSchema.three, definitions)
    assert TestSchema.one.definitions == definitions
    assert TestSchema.three.items.items[0].definitions == definitions

# Generated at 2022-06-24 11:06:17.750616
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.__main__ import UserSchema
    from typesystem.fields import String

    def test_passes(input_value, expected_value):
        schema = UserSchema.make_validator(strict=False)
        result = schema.validate(input_value, strict=False)
        assert result == expected_value

    def test_fails(input_value):
        schema = UserSchema.make_validator(strict=False)
        try:
            schema.validate(input_value, strict=False)
        except ValidationError as error:
            return error

    definitions = SchemaDefinitions()
    definitions["return_none"] = Reference(
        to=UserSchema,
        definitions=definitions,
        allow_null=True,
        default=None,
    )

    test_pass

# Generated at 2022-06-24 11:06:21.950171
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class Schema2(Schema):
        foo = Field()
        bar = Field()

    class Schema1(Schema):
        foo=Field()
        bar=Reference("Schema2")

    set_definitions(Schema1.fields["bar"], definitions)

    assert definitions["Schema2"] == Schema2
    assert definitions["Schema1"] == Schema1

# Generated at 2022-06-24 11:06:22.848462
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    assert True


# Generated at 2022-06-24 11:06:32.406170
# Unit test for method validate of class Reference
def test_Reference_validate():
    class MyObject(Schema):
        pass

    class MyRequest(Schema):
        my_object = Reference(to=MyObject)

    # Should pass
    value = {
        "id": "aF6J2M6X9XEZLJ",
        "name": "Test Object",
        "color": "red",
        "shape": "circle",
    }
    MyRequest(my_object=value)

    # Should raise ValidationError
    value = {
        "id": "aF6J2M6X9XEZLJ",
        "color": "red",
        "shape": "circle",
    }
    try:
        MyRequest(my_object=value)
        raise Exception("Should raise validation error")
    except ValidationError:
        pass

# Generated at 2022-06-24 11:06:40.386414
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class ExampleSchema(Schema):
        a = Field()

    example_schema_1 = ExampleSchema()
    assert len(example_schema_1) == 0
    example_schema_2 = ExampleSchema(a="value")
    assert len(example_schema_2) == 1
    example_schema_3 = ExampleSchema(a="value", b="value")
    assert len(example_schema_3) == 1


# Generated at 2022-06-24 11:06:46.519170
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Movie(Schema):
        title = Field()
        release_date = Field()

    movie = Movie(title="Back to the Future", release_date="1985-07-03")
    for key in movie:
        print("key: {0}, value: {1}".format(key, movie[key]))

    try:
        movie["rating"]
    except KeyError as error:
        print("Expected error: {0}".format(error))


# Generated at 2022-06-24 11:06:50.664856
# Unit test for function set_definitions
def test_set_definitions():
    class Inner(Schema):
        pass

    class Outer(Schema):
        inner_reference = Reference(to="Inner")
        _definitions = SchemaDefinitions()
        set_definitions(Outer.inner_reference, _definitions)
        assert Outer.inner_reference.target == Inner  # type: ignore



# Generated at 2022-06-24 11:06:58.081636
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    class Student(Person):
        id = Field(int)

    class Course(Schema):
        name = Field(str)
        students = Array(items=Reference("Student"))


    course = Course(name="maths", students=[Student(name="bob", age=15, id=1),
                                            Student(name="jim", age=20, id=2)])
    assert len(course) == len({"name": "maths", "students": [{"name": "bob",
                                                              "age": 15,
                                                              "id": 1},
                                                             {"name": "jim",
                                                              "age": 20,
                                                              "id": 2}]})


# Generated at 2022-06-24 11:07:05.764990
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        first_name=String(max_length=100, required=True)
        last_name=String(max_length=100, required=True)
        birth_year=Integer(minimum=1800, maximum=2050, required=False)
        profession=String(max_length=100, required=False)

    
    p=Person(first_name="Peter", last_name="Kaminski", birth_year=1992 )
    assert list(iter(p)) == ['first_name', 'last_name', 'birth_year']
    

# Generated at 2022-06-24 11:07:14.706139
# Unit test for function set_definitions
def test_set_definitions():
    A = Reference(to="B")
    C = Reference(to="D")
    B = Object(properties={"a": A})
    D = Array(items=C)
    definitions = SchemaDefinitions({"B": B, "D": D})
    set_definitions(A, definitions)
    set_definitions(B, definitions)
    set_definitions(C, definitions)
    set_definitions(D, definitions)
    assert A.target is B
    assert C.target is D
    assert D.items.target is C

# Generated at 2022-06-24 11:07:23.702380
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    def get_fields(cls):
        fields = {}
        for key, value in cls.fields.items():
            if isinstance(value, Field):
                fields[key] = value
        return fields

    class Person(Schema):
        name = Field()
        age = Field()
        sex = Field()

    assert get_fields(Person) == {'name': Person.name, 'age': Person.age, 'sex': Person.sex}

    class Employee(Person):
        pass

    assert get_fields(Employee) == {'name': Person.name, 'age': Person.age, 'sex': Person.sex}

    class Employee(Person):
        salary = Field()


# Generated at 2022-06-24 11:07:27.443802
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field = Field(type="integer")
    obj = TestSchema(field=1)
    actual = len(obj)
    expected = 1
    assert actual == expected


# Generated at 2022-06-24 11:07:29.830552
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference(to=str).target_string == "str"
    assert Reference(to=str, definitions={'str': str}).target == str


# Generated at 2022-06-24 11:07:33.123745
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class simple_Schema(Schema):
        name = Field(str)

    obj = simple_Schema({"name": "paul"})
    assert obj == simple_Schema({"name": "paul"})
    assert obj != simple_Schema({"name": "alice"})


# Generated at 2022-06-24 11:07:43.853146
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import String, Integer, Float, Object, Array, Reference
    from nose.tools import assert_equal, assert_is_instance, assert_raises
    import typesystem

    class Person(typesystem.Schema):
        name = String()
        age = Integer()
        email = String()

    class PersonWithOptional(Person):
        age = Integer(required=False)

    class Manager(Person):
        salary = Float()

    class ManagerWithOptional(Manager):
        age = Integer(required=False)

    class Employee(typesystem.Schema):
        name = String()
        age = Integer()
        department = Object(properties={'name': String()})
        subordinates = Array(items=Reference('Person'))


# Generated at 2022-06-24 11:07:50.163183
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem.fields import Boolean, Integer

    class Person(Schema):
        name = String(max_length=128)
        age = Integer(minimum=13)
        is_programmer = Boolean()

    assert len(Person()) == 0

    person = Person(is_programmer=True)
    assert len(person) == 1

    person = Person(name="foo", age=42, is_programmer=True)
    assert len(person) == 3



# Generated at 2022-06-24 11:07:54.787318
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    schema1 = Schema()
    definitions1 = SchemaDefinitions()
    definitions1.__setitem__("Schema", schema1)
    assert definitions1.__iter__() == ["Schema"]
    # __iter__ should return an iterable object
    for i in definitions1:
        print(i)


# Generated at 2022-06-24 11:07:56.608874
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(to="Person").serialize(None) == None
    assert Reference(to="Person").serialize({}) == {}

# Generated at 2022-06-24 11:08:04.282617
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    import json

    def make_map() -> dict:
        return {'a': 'abc', 'b': 'def'}

    def make_ordered_map() -> dict:
        return {'a': 'abc', 'b': 'def', 'c': 'hij'}

    result = make_map()
    result['c'] = 'hij'
    assert json.dumps(result, sort_keys=True) == '{"a":"abc","b":"def","c":"hij"}'

# Generated at 2022-06-24 11:08:07.664125
# Unit test for method validate of class Reference
def test_Reference_validate():
    def validate(value, *, strict=False):
        pass

    validator = Reference("TestSchema")
    validator._target = validate
    validator.target = validate
    validator.validate("{}")

# Generated at 2022-06-24 11:08:13.869676
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    a = SchemaDefinitions(a=1, b=2)
    assert a['a'] == 1
    assert a['b'] == 2
    a['c'] = 3
    assert a['c'] == 3
    try:
        a['a'] = 4
    except Exception as e:
        assert str(e) == "Definition for 'a' has already been set."
    a['a'] = 4


# Generated at 2022-06-24 11:08:22.528417
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema({"test_test_test":"test_test_test"}).test_test_test == "test_test_test"
    assert Schema({"test_test_test":"test_test_test"})._fields == {"test_test_test":String()}
    assert Schema({"test_test_test":"test_test_test"})._properties == {"test_test_test":String()}
    assert Schema({"test_test_test":"test_test_test"}).__class__.__name__ == "Schema"
    assert Schema({"test_test_test":"test_test_test"}).__class__.__mro__ == (Schema, Mapping, object)
    assert Schema({"test_test_test":"test_test_test"}).__class__.__base__ == Mapping


# Generated at 2022-06-24 11:08:24.101706
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    assert len(schema_definitions) == 0


# Generated at 2022-06-24 11:08:30.472215
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    assert True

    # Test with non-empty dictionary
    fields = {'a': 'b', 'b': 'c', 12: (1,2), 'd': {'c': 1}}
    s = Schema(fields)
    count = 0
    for item in s:
        assert item in fields
        count += 1
    assert count == len(fields)

    # Test with empty dictionary
    fields = {}
    s = Schema(fields)
    count = 0
    for item in s:
        count += 1
    assert count == len(fields)


# Generated at 2022-06-24 11:08:31.018882
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():pass

# Generated at 2022-06-24 11:08:33.930675
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    from pytest import raises

    definitions = SchemaDefinitions()
    definitions["my_key"] = "my_value"
    assert definitions["my_key"] == "my_value"
    with raises(KeyError):
        definitions.__delitem__("my_key")


# Generated at 2022-06-24 11:08:35.791545
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    a = SchemaDefinitions()
    assert len(a._definitions) == 0

# Test for constructor of class SchemaMetaclass

# Generated at 2022-06-24 11:08:38.269279
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    pass



# Generated at 2022-06-24 11:08:39.640307
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert bool(SchemaDefinitions())


# Generated at 2022-06-24 11:08:50.558642
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class Employee(Person):
        department = Field(type="string")

    class Boss(Employee):
        company = Field(type="string")

    class Company(Schema):
        name = Field(type="string")
        employees = Array(items=Employee)
        boss = Reference(to=Boss)

    a = Company(
        name="Acme Inc.",
        employees=[
            Employee(name="John Doe", age=42, department="engineering"),
            Employee(name="Jane Doe", age=40, department="sales"),
        ],
        boss=Boss(
            name="Jack Doe",
            age=52,
            department="engineering",
            company="Acme Inc.",
        ),
    )

# Generated at 2022-06-24 11:08:53.729460
# Unit test for constructor of class Reference
def test_Reference():
    try:
        Reference(to = 1)
    except Exception as e:
        assert type(e) == TypeError
        assert str(e) == "Schema reference must be a string or Schema subclass."
    else:
        assert False, "Expected a TypeError"


# Generated at 2022-06-24 11:08:58.819358
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import String

    class Pet(Schema):
        name = String()
        age = String()

    assert repr(Pet()) == 'Pet()'
    assert repr(Pet(name='Dave')) == "Pet(name='Dave')"
    assert repr(Pet(name='Dave', age=3)) == "Pet(age=3, name='Dave')"


# Generated at 2022-06-24 11:09:03.647363
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class MySchema(Schema):
        one = Field(type=str)
        two = Field(type=str, default="default")
    assert str(MySchema(one="one")) == "MySchema(one='one', two='default')"
    assert str(MySchema(one="one", two="two")) == "MySchema(one='one', two='two')"
    assert str(MySchema()) == "MySchema(two='default')"



# Generated at 2022-06-24 11:09:07.125855
# Unit test for constructor of class Schema
def test_Schema():
    class SampleSchema(Schema):
        required_field = Field(required=True)
        optional_field = Field(required=False)

    ss = SampleSchema()

    assert ss.optional_field is None


# Generated at 2022-06-24 11:09:07.706047
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    pass

# Generated at 2022-06-24 11:09:08.498488
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test = SchemaDefinitions()
    assert len(test) == 0


# Generated at 2022-06-24 11:09:13.173045
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.fields import Integer

    class Book(Schema):
        number_of_pages = Integer()

    class Review(Schema):
        book = Reference(to=Book)
        review_text = Integer()

    def test_validate_normal():
        value = {"book": {"number_of_pages": 5}, "review_text": 5}
        value = Review.validate(value)
        assert value == Review(book=Book(number_of_pages=5), review_text=5)
        assert isinstance(value["book"], Book)
        assert isinstance(value["review_text"], int)

    def test_validate_normal_sparse():
        value = {"book": {"number_of_pages": 5}}
        value = Review.validate(value)

# Generated at 2022-06-24 11:09:24.385033
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # You must construct the object using  __init__
    # or you will get an error
    # SchemaDefinitions()
    with pytest.raises(TypeError):
        SchemaDefinitions()

    # You must construct the object using  __init__
    # or you will get an error
    # SchemaDefinitions('')
    with pytest.raises(TypeError):
        SchemaDefinitions('')

    # You must construct the object using  __init__
    # or you will get an error
    # SchemaDefinitions(1)
    with pytest.raises(TypeError):
        SchemaDefinitions(1)

    # You must construct the object using  __init__
    # or you will get an error
    # SchemaDefinitions([])

# Generated at 2022-06-24 11:09:27.914177
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class A(Schema):
        x = Field()

    assert Reference(to=A).serialize(A(x='x')) == {'x': 'x'}
test_Reference_serialize()

# Generated at 2022-06-24 11:09:31.285326
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['test1'] = 'test1'
    assert definitions['test1'] == 'test1'
    del definitions['test1']
    print('test_SchemaDefinitions___delitem__ : done')

# Generated at 2022-06-24 11:09:40.612597
# Unit test for function set_definitions
def test_set_definitions():
    class A(Reference):
        __doc__ = Reference.__doc__

    class B(Reference):
        __doc__ = Reference.__doc__

    class C(Reference):
        __doc__ = Reference.__doc__

    class Outer(Schema):
        A = A
        B = B
        C = C

    definitions = SchemaDefinitions()
    # We should be able to set definitions after the fact.
    set_definitions(Outer.A, definitions)
    assert Outer.A.definitions is definitions

    # There should be no definition for `B` yet.
    try:
        Outer.B.definitions
    except AttributeError:
        pass
    else:
        assert False, "Expected AttributeError to be raised."

    # Declaring the `Outer` class should set `definitions` for every field

# Generated at 2022-06-24 11:09:47.390980
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Base(Schema):
        # noinspection PyArgumentList
        str = Field(validate=lambda x: isinstance(x, str))

    class Sub(Base):
        # noinspection PyArgumentList
        int = Field(validate=lambda x: isinstance(x, int))

    assert set(Base.fields) == {"str"}
    assert set(Sub.fields) == {"str", "int"}


if __name__ == '__main__':
    test_SchemaMetaclass()

# Generated at 2022-06-24 11:09:49.730770
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    instance = SchemaDefinitions()
    with pytest.raises(AssertionError):
        instance.__setitem__(1, 1)


# Generated at 2022-06-24 11:09:59.322683
# Unit test for function set_definitions
def test_set_definitions():
    class Data(Schema):
        name = String(min_length=1, max_length=20)
        age = Integer()
        # gender = Enum(["Male", "Female"])
        class Meta:
            defintions = SchemaDefinitions(
                {
                    "Person": {"name": "Nicole", "age": 20, "gender": "Female"},
                    "Dog": {"name": "Cindy", "age": 10, "gender": "Male"},
                }
            )

    class Test(Schema):
        title = String()
        description = String()
        data = Reference("Person", definitions=Test.Meta.defintions)

    result = Test(title="Hello World", description="A test", data={"name":"Nicole", "age": 20, "gender": "Female"})
    print(result)