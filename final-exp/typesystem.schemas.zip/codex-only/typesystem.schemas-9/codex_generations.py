

# Generated at 2022-06-24 10:59:59.433477
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    s = SchemaDefinitions({})
    assert s.__getitem__('key') == {}
    assert s.__getitem__(key='key') == {}
    assert s.__getitem__(key=None) == {}


# Generated at 2022-06-24 11:00:03.402450
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Foo(Schema):
        a = Field()
        b = Field()

    expected_fields = {'a': Field(), 'b': Field()}
    assert Foo.fields == expected_fields



# Generated at 2022-06-24 11:00:04.880148
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(to="Schedule").serialize(None) == None


# Generated at 2022-06-24 11:00:07.702331
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    a=SchemaDefinitions()
    b=SchemaDefinitions({'a':1,'b':2})
    assert len(a)==0
    assert len(b)==2


# Generated at 2022-06-24 11:00:10.926630
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        name = String()

    class People(Schema):
        id = String()
        people = Reference(Person)
    people = People({"id": "id1", "people": {"name": "kobe"}})

# Generated at 2022-06-24 11:00:18.189675
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class SubSchema(Schema):
        a = String()
        b = String()
        c = String()

    class SchemaTest(Schema):
        a = String()
        b = String(allow_null=True)
        c = Reference(to=SubSchema)

    schema_test = SchemaTest(a='1', b=None, c=SubSchema(a='2', b='3'))

    # When
    target = schema_test['c']

    # Then
    assert target['a'] == '2'
    assert target['b'] == '3'

# Generated at 2022-06-24 11:00:21.951142
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Person(Schema):
        age = Field(type="integer")
        gender = Field(type="string", enum=["male", "female"])
    p1 = Person(age=4)
    p2 = Person(age=4)
    assert p1 == p2


# Generated at 2022-06-24 11:00:29.791411
# Unit test for constructor of class Schema
def test_Schema():
    class Job(Schema):
        name = String()
        title = String()
        job_id = Integer()
    new_job = Job(name='surya',title ='Software Engineer', job_id = 123)
    assert hasattr(new_job, 'name') == True
    assert hasattr(new_job, 'title') == True
    assert hasattr(new_job, 'job_id') == True
    assert getattr(new_job, 'name') == 'surya'
    assert getattr(new_job, 'title') == 'Software Engineer'
    assert getattr(new_job, 'job_id') == 123
    job_dict = {'name': 'surya', 'title': 'Software Engineer', 'job_id': 123}

# Generated at 2022-06-24 11:00:34.220229
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Boolean, Integer, String


    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        retired = Boolean(default=False)

    data = {"name": "John", "age": 42, "retired": False}
    expected = {"name": "John", "age": 42, "retired": False}
    person = Person(name="John", age=42, retired=False)
    assert data == expected

    data = {"name": "John", "age": 42}
    expected = {"name": "John", "age": 42, "retired": False}
    person = Person(data)
    assert data == expected



# Generated at 2022-06-24 11:00:36.155830
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions(a=1)
    assert definitions.__delitem__("a") == None
    assert definitions.__getitem__("a") == None

# Generated at 2022-06-24 11:00:43.229319
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Foo(Schema):
        name = String()
        hit_points = Integer(minimum=0)

    test_Foo = {
            "name": "foo", 
    } 
    test_Foo2 = {
            "name": "foo", 
            "hit_points": 0, 
    } 
    test_Foo3 = {
            "name": "foo", 
            "hit_points": 3, 
    } 
    f = Foo(test_Foo)
    f2 = Foo(test_Foo2)
    print('name:', f.name, ' hit_points:', f.hit_points)
    test_Foo['foo'] = 1
    print(test_Foo)
    print(f.hit_points)
    print(Foo.is_sparse)

# Generated at 2022-06-24 11:00:52.263032
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Foo(Schema):
        name = String()
    class Bar(Schema):
        foo_ref = Reference(Foo)
    bar = Bar(foo_ref=Foo(name="Foo1"))
    bar.foo_ref.validate(Foo(name="Foo2"))
    try:
        bar.foo_ref.validate(None)
        assert False, "Reference field should raise an error, when being None"
    except ValidationError as e:
        assert str(e) == "May not be null."
    try:
        bar.foo_ref.validate("")
        assert False, "Reference field should raise an error, when not being a Schema"
    except TypeError as e:
        assert str(e) == 'Argument "value" must be of type "Schema" or "None", '

# Generated at 2022-06-24 11:01:00.153308
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.fields import Boolean
    from typesystem.typing import JSONSchemaType

    class Person(Schema):
        name = String(min_length=2)
        age = Integer()

    class Book(Schema):
        title = String()
        author = Reference(Person)

    with pytest.raises(TypeError):
        Reference().serialize(1)

    with pytest.raises(TypeError):
        Reference().serialize('{"name":"foo","age":17}')

    assert pytest.approx(Reference(JSONSchemaType()).serialize(1)) == 1


# Generated at 2022-06-24 11:01:03.948732
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        foo = Field(type="string", required=True)
        bar = Field(type="integer", required=True)
    try:
        TestSchema()
        assert False
    except TypeError:
        pass
    schema = TestSchema(foo="abc", bar=123)
    assert schema.foo == "abc"
    assert schema.bar == 123


# Generated at 2022-06-24 11:01:05.004043
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions['test'] = 'test'
    assert schema_definitions['test'] == 'test'

# Generated at 2022-06-24 11:01:11.866901
# Unit test for function set_definitions
def test_set_definitions():
    def test_schema():
        definitions = SchemaDefinitions()
        class_1 = SchemaDefinitions
        class_2 = SchemaDefinitions
        class_3 = SchemaDefinitions
        assert class_1 is not class_2
        assert class_1 is not class_3
        assert class_2 is not class_3
        set_definitions(class_1, definitions)
        assert definitions[class_1.__name__] is class_1
        set_definitions(class_2, definitions)
        assert definitions[class_2.__name__] is class_2
        set_definitions(class_3, definitions)
        assert definitions[class_3.__name__] is class_3
        assert class_1 is class_2
        assert class_1 is class_3
        assert class_2 is class_3

# Generated at 2022-06-24 11:01:20.260995
# Unit test for method validate of class Reference
def test_Reference_validate():
    class MyObject(Schema):
        name = String
        # ... define other fields
    class MyReference(Reference):
        definitions = {
            "MyObject": MyObject
        }
    # Test 1: assert that the field name of your reference is not null
    assert MyReference(to="MyObject", allow_null=False).validate("") == "Null" 
    # Test 2: assert that your definition must be a dictionary
    assert MyReference(to=MyObject, allow_null=False).validate("") == "Dictionary"
    # Test 3: assert that your object target definition
    assert MyReference(to=MyObject, allow_null=False).validate("") == "Object Definition"

# Test for serialize method of class Reference

# Generated at 2022-06-24 11:01:26.281488
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class V1(Schema):
        pass

    class V2(Schema):
        pass

    v1 = V1()
    v2 = V2()
    assert v1 == v1
    assert v2 == v2
    assert v1 != v2
    assert v2 != v1



# Generated at 2022-06-24 11:01:29.077349
# Unit test for constructor of class Reference
def test_Reference():
    #__init__
    to = 'to'
    definitions = {}
    kwargs = {}
    obj = Reference(to, definitions, **kwargs)
    assert obj


# Generated at 2022-06-24 11:01:37.624515
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class_name = 'test_SchemaMetaclass'
    bases = ()
    attrs = {'__module__': '__main__',
            '__qualname__': 'test_SchemaMetaclass'}
    definitions = SchemaDefinitions()

    schema = SchemaMetaclass.__new__(SchemaMetaclass, class_name, bases, attrs, definitions)
    assert schema.__class__.__name__ == 'test_SchemaMetaclass'

    class MySchema(Schema):
        a = Integer()
        b = String()

    assert MySchema.name == 'test_SchemaMetaclass'



# Generated at 2022-06-24 11:01:48.303450
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    with pytest.raises(AssertionError):
        SchemaDefinitions({"name": "test"})
    with pytest.raises(AssertionError):
        SchemaDefinitions({"name": "test"}, {"name": "test2"})
    assert SchemaDefinitions() == {}
    assert SchemaDefinitions({"name": "test"}) == {"name": "test"}
    assert SchemaDefinitions(Name="test") == {"Name": "test"}
    # Testing of functions:
    # - __delitem__
    definitions = SchemaDefinitions()
    definitions.__delitem__("fred")  # should pass through
    definitions["fred"] = "astring"
    definitions["fred"]  # should return "astring"
    assert definitions == {"fred": "astring"}  # should be equal to {"fred":

# Generated at 2022-06-24 11:01:56.195725
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Integer, Object
    from typesystem.compat import bytes, unicode
    from typesystem.schema import Schema
    from typesystem.types import String

    class Movie(Schema):
        title = String()
        year = Integer()

    # Using dicts
    movie1 = Movie({"title": "Blade Runner", "year": 1982})
    assert 'title' in movie1
    assert 'year' in movie1
    assert not 'director' in movie1
    assert list(movie1) == ['title', 'year']

    # Using keyword arguments
    movie2 = Movie(title="2001: A Space Odyssey", year=1968)
    assert 'title' in movie2
    assert 'year' in movie2
    assert not 'director' in movie2
    assert list(movie2) == ['title', 'year']

   

# Generated at 2022-06-24 11:02:00.924236
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Enum(Schema):
        class Type(Schema):
            pass
        type = Reference(Type)
    Type = Enum.fields['type'].target
    assert list(Enum(type=Type())) == ['type']


# Generated at 2022-06-24 11:02:07.675031
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class MySchema(Schema):
        id = Integer()
        name = String()
        active = Boolean(default=True)
    assert MySchema.fields == {'id': Integer(), 'name': String(), 'active': Boolean(default=True)}
    assert MySchema.__name__ == 'MySchema'
    assert MySchema.__name__ in SchemaDefinitions._definitions.keys()
    assert isinstance(MySchema, Schema)


# Generated at 2022-06-24 11:02:15.977925
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Chat(Schema):
        room = String()
        user = String()

        # Method bodies of class Chat
        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self.__dict__.setdefault("room", "")
            self.__dict__.setdefault("user", "")

    class Message(Schema):
        chat = Reference(to=Chat)
        from_user = Reference(to=Chat, allow_null=True)
        message = String()

        def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
            super().__init__(*args, **kwargs)
            self.__dict__.setdefault("chat", Chat())
            self

# Generated at 2022-06-24 11:02:24.143857
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    """
    The method `__eq__` of Schema should return true when two schemas are
    identical.
    """
    class ExampleSchema(Schema):
        field = Field()

    assert ExampleSchema(field="test") == ExampleSchema(field="test")



# Generated at 2022-06-24 11:02:27.294839
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    d=SchemaDefinitions()
    length1=len(d)
    d.__delitem__("")
    assert len(d)==length1-1,"incorrect length"

# Generated at 2022-06-24 11:02:38.147264
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # test the case that inherits the field of the parent class 
    class DataSchema(Schema):
        fields = {
            'da_field': Array(item_type=String(max_length=10),min_length=3),
            'db_value': Boolean()
        }
        def test_func():
            pass
    class TestSchema(Schema):
        fields = {
            'a_field': Array(item_type=String(max_length=10),min_length=3),
            'b_value': Boolean()
        }
        data: DataSchema = Reference(to=DataSchema)
        def test_func():
            pass
    # show the results
    # the results shuld include data_field and db_value

# Generated at 2022-06-24 11:02:42.365171
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from typesystem import Integer, String
    import typesystem
    class Person(typesystem.Schema):
        age = Integer()
        surname = String()
        first_name = String()
    person = Person(first_name="John", surname="Doe", age=42)
    assert sorted(list(person)) == ['age', 'first_name', 'surname']


# Generated at 2022-06-24 11:02:52.278360
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    import sys
    import datetime
    class MySchema(Schema):
        date = Field(datetime.datetime)
        text = Field(str)
        ref = Reference('ObjectStore')
    # Don't use assert because we return a dict, dicts don't have an __eq__ method
    # A dict only has an __eq__ method if it has an __eq__ method for each item in the dict
    # Since dictionaries of Field objects don't have a __eq__ method, dicts of Field objects
    # can't have an __eq__ method

# Generated at 2022-06-24 11:03:03.084312
# Unit test for constructor of class Schema
def test_Schema():
    class TestClass(Schema):
        name = Field(str)
        age = Field(int)
        weight = Field(int, default=0)
    a = TestClass(name = "Jack", age = 20)
    assert a.name == "Jack"
    assert a.age == 20
    assert a.weight == 0
    b = TestClass(name = "Jack", age = 20, weight = 70)
    assert b.name == "Jack"
    assert b.age == 20
    assert b.weight == 70
    c = TestClass(name = "Jack", age = 20, weight = 70, default = 1)
    assert c.name == "Jack"
    assert c.age == 20
    assert c.weight == 70
    d = TestClass({"name":"Jack", "age":20})

# Generated at 2022-06-24 11:03:11.991571
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    from random import choice
    from string import ascii_letters
    from typesystem import Integer, String
    from typesystem.compat import get_type
    from typesystem.types import Any
    class User(Schema):
        id = Integer(description='The user\'s ID.')
        name = String(description='The user\'s name.')
    user1 = User(id=randint(1, 10), name=choice(ascii_letters))
    user2 = User(id=randint(1, 10), name=choice(ascii_letters))
    isinstance_561805 = get_type(user1)
    assert isinstance_561805 == get_type(user2)

# Generated at 2022-06-24 11:03:16.105840
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Human(Schema):
        name = String()
        age = Integer()

    class Person(Schema):
        human = Reference(Human)
    person = Person({'human': {'name': 'John', 'age': 18}})
    result = person.human
    expected_result = {'name': 'John', 'age': 18}
    assert result == expected_result

# Generated at 2022-06-24 11:03:23.639524
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class Person(Schema):
        name = String()

    assert Person.fields["name"] == String()

    class Person(Schema):
        name = String(title="Name")

    assert Person.fields["name"] == String(title="Name")

    class Person(Schema):
        name = String(title="Name")

        class Meta:
            title = "Human being"
            description = "A living human."

    assert Person.fields["name"] == String(title="Name")



# Generated at 2022-06-24 11:03:33.714427
# Unit test for constructor of class Reference
def test_Reference():
    target = Schema(
        properties={
            "str": str
        },
        allow_unknown=True
    )

    schema = Schema(
        properties={
            "schema": Reference(to=target)
        }
    )

    data = {
        "schema": target
    }
    assert schema(data)

    data = {
        "schema": {
            "str": "test"
        }
    }

    assert schema(data)

# Generated at 2022-06-24 11:03:40.297640
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    
    from typesystem.base import Validator
    from typesystem.fields import Any, Boolean, Float, Integer, String
    import typesystem
    
    # Create a new class
    class MySchema(Schema):
    
        # Create a new field
        field1 = Any()
    
        # Create a new field
        field2 = Boolean()
    
        # Create a new field
        field3 = Float()
    
        # Create a new field
        field4 = Integer()
    
        # Create a new field
        field5 = String()

    obj = MySchema(field1=10, field2=True, field3=1.0, field4=10, field5="val")
    value1 = obj.__getitem__("field1")
    value2 = obj.__getitem__("field2")
   

# Generated at 2022-06-24 11:03:48.877955
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class PersonSchema(Schema):
        name = String()
        age = Integer()

    class PersonSchema1(Schema):
        name = String()

    class PersonSchema2(Schema):
        name = String()
        age = Integer()

    p1 = PersonSchema(name='Jim', age=30)
    p2 = PersonSchema(name='Jim', age=30)
    p3 = PersonSchema(name='Jim')
    p4 = PersonSchema1(name='Jim')
    p5 = PersonSchema2(name='Jim')

    assert p1 == p2
    assert not p1 == p3
    assert not p3 == p4
    assert p3 == p5


if __name__ == "__main__":
    import pytest


# Generated at 2022-06-24 11:03:52.699444
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import Integer

    class S(Schema):
        x = Integer()

    s = S(x=1)
    assert s["x"] == 1

# Generated at 2022-06-24 11:03:56.402801
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class A(Schema):
        test = Array(items=Integer())
    ref = Reference(A)
    a = A({"test": [1, 2, 3]})
    x = ref.serialize(a)
    assert x == {"test": [1, 2, 3]}

# Generated at 2022-06-24 11:03:59.211449
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Arrange
    definitions = SchemaDefinitions()

    # Act
    it = definitions.__iter__()

    # Assert
    assert callable(it)



# Generated at 2022-06-24 11:03:59.932705
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert True

# Generated at 2022-06-24 11:04:07.247001
# Unit test for function set_definitions
def test_set_definitions():
    class Address(Schema):
        city = String()
        country = String()
        postalCode = String()
        state = String()
        streetAddress = String()
    class Geo(Schema):
        lat = String()
        lng = String()
    class ContactPoint(Schema):
        areaServed = String()
        availableLanguage = String()
        email = String()
        faxNumber = String()
        hoursAvailable = String()
        productSupported = String()
        telephone = String()
        contactType = String()
        telephone = String()
        telephone = String()
        telephone = String()
        telephone = String()
        telephone = String()
        telephone = String()
    class Place(Schema):
        address = Reference(Address)
        geo = Reference(Geo)
        telephone = String()

# Generated at 2022-06-24 11:04:14.384379
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem import Integer

    class A(Schema):
        a = Integer
    assert getattr(A, "fields")['a'] is Integer

    class B(A):
        b = Integer
    assert getattr(B, "fields")['a'] is Integer
    assert getattr(B, "fields")['b'] is Integer

    class C(A):
        a = Integer()
    assert getattr(C, "fields")['a'] is not Integer
    assert getattr(C, "fields")['a'] is not Integer()



# Generated at 2022-06-24 11:04:17.778320
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class _User(Schema):
        username = String(max_length=255)

    user = _User(username="somkiat")
    keys = []
    for key in user:
        keys.append(key)
    assert keys == ["username"]


# Generated at 2022-06-24 11:04:19.578206
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Testing method __len__ of class Schema
    test_schema = Schema(foo = 1, bar = 2)
    print(len(test_schema))


# Generated at 2022-06-24 11:04:25.765942
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        name = Field(type=String)

    schema1 = TestSchema({"name": "lisa"})
    schema2 = TestSchema({"name": "lisa"})
    assert (schema1 == schema2) == True
    schema3 = TestSchema({"name": "james"})
    assert (schema1 == schema3) == False


# Generated at 2022-06-24 11:04:28.728600
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    try:
        class Test(Schema):
            x = Field()
        t1 = Test(x=1)
        t2 = Test(x=1)
        assert t1 == t2
    except:
        assert False


# Generated at 2022-06-24 11:04:31.349783
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    schema_definitions.foo = "bar"
    expect(len(schema_definitions)).is_(1)


# Generated at 2022-06-24 11:04:33.232936
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    try:
        prop_ = SchemaDefinitions()
        assert False
    except Exception as exception:
        assert type(exception) == KeyError


# Generated at 2022-06-24 11:04:35.908320
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    schema = Schema()
    schema1 = Schema()
    schema2 = Schema()
    assert schema.__eq__(schema)
    assert schema.__eq__(schema1)
    assert not schema.__eq__(schema2)

# Generated at 2022-06-24 11:04:38.781452
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema({'a': 1, 'b': 2}) == Schema(a=1, b=2)
    assert Schema({'a': 1}) == Schema(a=1)


# Generated at 2022-06-24 11:04:41.960982
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema(a=1, b=2, c=3)
    actual = list(schema.__iter__())
    expected = ['a', 'b', 'c']
    assert actual == expected


# Generated at 2022-06-24 11:04:44.175895
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem.fields import String
    d = {'id': String(min_length=1)}
    r = Reference(d)
    r.validate(123)

# Generated at 2022-06-24 11:04:46.781274
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    def_1 = SchemaDefinitions()
    def_1.__setitem__('a', 1)
    assert def_1['a'] == 1


# Generated at 2022-06-24 11:04:56.054772
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Case 1
    # Case 1.1
    # Case 1.1.1
    # Case 1.1.1.1
    obj = SchemaDefinitions()
    k = 'A'
    v = 1
    obj[k] = v
    assert obj[k] == v
    # Case 2
    # Case 2.1
    # Case 2.1.1
    # Case 2.1.1.1
    # Case 2.1.1.1.1
    obj = SchemaDefinitions()
    k = 'A'
    v = 1
    obj[k] = v
    assert obj[k] == v
    k = 'A'
    v = 2
    try:
        obj[k] = v
        assert False
    except:
        assert True


# Generated at 2022-06-24 11:05:01.069896
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class MySchema(Schema):
        id = Integer(default=None)
        name = Text()
        email = Text()
        description = Text(default=None)
        tags = Array(Text())
        json = JSON(default=None)
        created_at = Date()
        updated_at = Date()

        class Meta:
            required = ["name", "email"]

    mySchema = MySchema(name="test name", email="test email", tags=["t1", "t2"])
    print(mySchema)
    print(mySchema.validate(email="test email", name="test name", tags=["t1", "t2"]))



test_SchemaMetaclass()

# Generated at 2022-06-24 11:05:04.287744
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    s["key"] = "value"
    assert s["key"] == "value"
    assert len(s) == 1
    assert list(s) == ["key"]



# Generated at 2022-06-24 11:05:05.877983
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
  s = Schema()
  with pytest.raises(KeyError):
    s["test"]

test_Schema___getitem__()

# Generated at 2022-06-24 11:05:09.206908
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    class S(Schema):
        a = Field()
    definitions = SchemaDefinitions()
    definitions["S"] = S
    assert definitions["S"] == S
    with raises(KeyError):
        definitions["N"]


# Generated at 2022-06-24 11:05:11.282645
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()

    class Foo(Schema):
        pass
    assert Foo.__name__ in definitions
    del definitions[Foo.__name__]
    assert Foo.__name__ not in definitions


# Generated at 2022-06-24 11:05:14.647543
# Unit test for constructor of class Reference
def test_Reference():
    r = Reference(to='string', definitions={'string': 'hi'}, name="hi")
    assert r.target == 'hi'
    assert r.validate('hi') == 'hi'
    assert r.serialize('hi') == 'hi'
    if __name__ == '__main__':
        print('Exiting test_Reference()')


# Generated at 2022-06-24 11:05:20.157711
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        f1 = Field()
        f2 = Field()
        f3 = Field()
    s = TestSchema()
    result = list(s)
    assert result == [
        "f1", "f2", "f3"
    ]



# Generated at 2022-06-24 11:05:28.203227
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.fields import String

    class Person(Schema):
        name = String()
        age = Integer()

    person = Person(name="Bob", age=42)
    assert repr(person) == "Person(name='Bob', age=42)"

    person = Person(name="Bob")
    assert repr(person) == "Person(name='Bob') [sparse]"

    class Hobby(Schema):
        name = String()
        started = Integer()

    class Person(Schema):
        name = String()
        age = Integer()
        hobbies = Array(Hobby())

    person = Person(name="Bob", age=42, hobbies=[{"name": "hiking", "started": 2010}])

# Generated at 2022-06-24 11:05:30.270333
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['key'] = 'value'
    assert 'key' in definitions
    del definitions['key']
    assert 'key' not in definitions

# Generated at 2022-06-24 11:05:31.362680
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert SchemaDefinitions() is not None


# Generated at 2022-06-24 11:05:34.654133
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    import typesystem.types
    definition_instance = typesystem.types.SchemaDefinitions()
    try:
        definition_instance.__iter__()
        definition_instance.__iter__()
    except:
        pass


# Generated at 2022-06-24 11:05:35.802503
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    assert issubclass(SchemaMetaclass, ABCMeta)


# Generated at 2022-06-24 11:05:38.164016
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    d = SchemaDefinitions()
    d['key'] = 'value'
    del d['key']
    assert 'key' not in d
    pass


# Generated at 2022-06-24 11:05:41.156175
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    sd = SchemaDefinitions()
    sd['foo'] = 1
    sd['bar'] = 2
    assert (
        list(sd.__iter__()) ==
        [
            'foo',
            'bar',
        ]
    )


# Generated at 2022-06-24 11:05:44.904961
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    def test():
        schema_definitions = SchemaDefinitions()
        schema_definitions['test'] = 1
        assert schema_definitions['test'] == 1
    test()


# Generated at 2022-06-24 11:05:47.440952
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class TestSchema(Schema):
        sample_field = String()
    assert Reference(to=TestSchema).serialize(None) == None

# Generated at 2022-06-24 11:05:53.765984
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    """
    Method __iter__ keys
    """
    sd = SchemaDefinitions()
    try:
        assert list(sd.__iter__()) == []
    except AssertionError:
        raise AssertionError(sd.__iter__())
    sd['a'] = 'b'
    try:
        assert list(sd.__iter__()) == ['a']
    except AssertionError:
        raise AssertionError(sd.__iter__())


# Generated at 2022-06-24 11:05:57.948787
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    # SchemaMetaclass has no methods.
    # It is a metaclass which is a type.
    # It's an abstract class.
    # It is a subclass of ABCMeta.
    SchemaMetaclass


# Generated at 2022-06-24 11:06:09.615891
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Create a parent class and one of its subclasses.
    class Animal(Schema):
        name = String()
        age = Integer()
    class Cat(Animal):
        num_lives = Integer(default=9)

    # Create a Reference object that points to the Cat class.
    cat_ref = Reference(Cat)

    # Create an instance of Cat.
    cat = Cat(name="Felix", age=2)

    # Assert that validate() returns a Cat instance.
    assert cat_ref.validate(cat) == cat

    # Assert that validate() raises ValidationError for any other input.
    with pytest.raises(ValidationError):
        cat_ref.validate(None)
    with pytest.raises(ValidationError):
        cat_ref.validate(Animal(name="Felix"))


# Generated at 2022-06-24 11:06:11.527453
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    schema_definitions=SchemaDefinitions()
    assert schema_definitions.__getitem__(10)=='10'
    
    

# Generated at 2022-06-24 11:06:14.566738
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    schema = Schema({"foo": 1, "bar": 2, "baz" : 3})
    assert isinstance(schema, dict)
    assert len(schema) == 3


# Generated at 2022-06-24 11:06:21.915561
# Unit test for constructor of class Reference
def test_Reference():
  import datetime
  from typesystem.fields import String, DateTime
  from typesystem.validators import pattern

  class Person(Schema):
    name = String()
    birthday = DateTime(name="Birthday")

  class Event(Schema):
    date = DateTime()
    person = Reference(Person)

  e = Event.validate(
    {
      "date": "2019-10-17T21:00:00+00:00",
      "person": {"name": "Jane", "birthday": "1999-02-24"}
    }
  )

  assert e.date == datetime.datetime(2019, 10, 17, 21, 0, tzinfo=datetime.timezone.utc)
  assert e.person.name == "Jane"
  assert e.person.birthday == datetime.dat

# Generated at 2022-06-24 11:06:30.306919
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Test class attributes
    # fields
    assert SchemaTest__new__.fields == {
        'test_string': String(max_length=10),
        'test_int': Integer()
    }

    # Test method attributes
    # validate
    method_attributes = [
        method
        for method in SchemaTest__new__.__dict__.keys()
        if not method.startswith('__')
    ]
    assert method_attributes == ['validate']

    # Test class name and bases
    assert SchemaTest__new__.__name__ == 'SchemaTest__new__'
    assert SchemaTest__new__.__bases__ == (Schema,)


# Generated at 2022-06-24 11:06:37.760096
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class MySchema(Schema):
        title = Reference(to='Title2')
    class Title2(Schema):
        title = Reference(to='Title3')
        def serialize(self, obj):
            if obj is None:
                return None
            return dict(obj)
    class Title3(Schema):
        title = Reference(to='Title4')
        def serialize(self, obj):
            if obj is None:
                return None
            return dict(obj)
    class Title4(Schema):
        title = Reference(to='Title5')
        def serialize(self, obj):
            if obj is None:
                return None
            return dict(obj)
    class Title5(Schema):
        title = Reference(to='Title6')

# Generated at 2022-06-24 11:06:43.618831
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Test positive condition
    s = SchemaDefinitions()
    s["key"] = "value"
    assert len(s) == 1
    del s["key"]
    assert len(s) == 0
    # Test negative condition, i.e. KeyError exception
    try:
        del s["key"]
    except KeyError as e:
        assert "key" == e.args[0]


# Generated at 2022-06-24 11:06:46.241018
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        age = Integer()
        profile = String()

    p = Person(name='foo', profile='bar')
    assert p == {'name': 'foo', 'profile': 'bar'}
    assert list(p) == ['name', 'profile']

# Generated at 2022-06-24 11:06:51.090388
# Unit test for function set_definitions
def test_set_definitions():
    d = SchemaDefinitions()
    field = Reference(to="User", definitions=d)

    class User(Schema):
        first_name = String()
        last_name = String()

    set_definitions(field, d)
    assert field.definitions is d
    assert field.target is User
    assert "User" in d
    assert d["User"] is User


# Generated at 2022-06-24 11:06:52.667461
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert len(Schema({'author': 'Fredrik'})) == 1


# Generated at 2022-06-24 11:06:59.275531
# Unit test for function set_definitions
def test_set_definitions():
    class DefinitionA(Schema):
        a = Integer()

    class DefinitionB(Schema):
        b = Integer()

    class DefinitionC(Schema):
        c = String()

    class DefinitionD(Schema):
        d = String()

    class DefinitionE(Schema):
        e = Ref(DefinitionA)

    # Make a Field(), not a Field
    class DefinitionF(BaseField):
        def validate(self, value, *args, **kwargs):
            pass

    fields = {
        "field_a": DefinitionA(),
        "field_b": DefinitionB(),
        "field_c": DefinitionC(),
        "field_d": DefinitionD(),
        "field_e": DefinitionE(),
        "field_f": DefinitionF(),
    }
    definitions = SchemaDefinitions(fields)

# Generated at 2022-06-24 11:07:04.527906
# Unit test for constructor of class Reference
def test_Reference():
    # Correctness of constructor of class Reference
    try:
        Reference('test')
        assert False, 'Should have thrown error'
    except AttributeError:
        pass

    # Correctness of function Property target
    try:
        r = Reference('test', {'test':10})
        assert r.target == 10, 'target not working'
    except AttributeError:
        assert False, 'Attribute error: target'

# Generated at 2022-06-24 11:07:09.357882
# Unit test for method validate of class Reference
def test_Reference_validate():
    value = "Hi"
    from custom_typesystem import String
    target = String
    r = Reference(target)
    return r.validate(value)


# Generated at 2022-06-24 11:07:20.522528
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():

    # From PEP 484
    # Variable annotation syntax was inspired by, and substantially
    # compatible with, the now-deprecated type comments from PEP 3107.
    from typing import TypeVar, Generic, List
    T = TypeVar("T")

    class Stack(Generic[T]):
        def __init__(self) -> None:
            self._container: List[T] = []

        def pop(self) -> T:
            return self._container.pop()  # type: ignore

        def push(self, item: T) -> None:
            self._container.append(item)

        def __repr__(self) -> str:
            return repr(self._container)


    def test_basic_usage():
        s = Stack[int]()
        s.push(1)
        s.push(2)
       

# Generated at 2022-06-24 11:07:22.483949
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    pass

# Generated at 2022-06-24 11:07:23.997619
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
	with pytest.raises(AssertionError):
		pass

# Generated at 2022-06-24 11:07:30.534470
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["foo"] = "bar"
    assert definitions["foo"] == "bar"
    try:
        definitions["foo"] = "baz"
    except AssertionError:
        pass
    else:
        assert False, "Failed to raise AssertionError on duplicate definition."
    assert definitions["foo"] == "bar"
    del definitions["foo"]
    assert definitions.get("foo") is None


# Generated at 2022-06-24 11:07:36.455346
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    data = {
        "type": "OBJECT",
        "properties": {
            "title": {
                "type": "STRING",
            },
            "price": {
                "type": "FLOAT",
            },
            "published": {
                "type": "BOOLEAN",
            },
        },
        "required": ["title", "price"],
    }
    # Initialize a class of type Schema
    schema = Schema(data)
    # Expected output from method __getitem__ is an item from self.fields
    # Since self.fields is an empty dict, this method should raise KeyError
    # Check if KeyError is raised when key not in self.fields
    print(schema["name"])
    assert False


# Generated at 2022-06-24 11:07:41.943854
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Set args
    args = ()
    # Set kwargs
    kwargs = {'key0': 0}
    
    # Call the method
    temp_class = SchemaDefinitions(*args, **kwargs)
    method___iter__ = temp_class.__iter__
    result = method___iter__()
    
    # Check the result
    assert type(result) == list
    

# Generated at 2022-06-24 11:07:47.933062
# Unit test for constructor of class Reference
def test_Reference():
    import typesystem
    schema = typesystem.Schema({'x': typesystem.Integer(minimum=3)})
    ref = typesystem.Reference(to=schema)
    ref_str = typesystem.Reference(to='Schema')
    assert ref.to == schema
    assert ref_str.to == 'Schema'
    assert ref.definitions == None
    assert ref.allow_null == False
    assert ref_str.definitions == None
    assert ref_str.allow_null == False
    assert ref.target == schema
    assert ref_str.target_string == 'Schema'
    assert ref._target == schema
    assert ref_str._target_string == 'Schema'
    assert ref_str._target == None
    assert ref.validate(None) == None

# Generated at 2022-06-24 11:07:49.216812
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    pass


# Generated at 2022-06-24 11:07:56.850103
# Unit test for function set_definitions
def test_set_definitions():
    class Target1(Schema):
        id = Field()

    class Target2(Schema):
        id = Field()

    definitions = SchemaDefinitions({"Target1": Target1, "Target2": Target2})

    class Input(Schema):
        ref1 = Reference(Target1)
        ref2 = Reference(Target2)
        nested = Object(properties={"field": Reference(Target1)})

    set_definitions(Input(), definitions)
    assert isinstance(Input.fields["ref1"].target, Field)
    assert Input.fields["ref2"].target is Target2
    assert Input.fields["nested"].properties["field"].target is Target1

# Generated at 2022-06-24 11:08:01.226824
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    definitions['key1'] = 'value1'
    definitions['key2'] = 'value2'
    assert len(definitions) == 2


# Generated at 2022-06-24 11:08:07.697679
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from typesystem.fields import String as TSString, Integer as TSInteger

    class Schema(metaclass=SchemaMetaclass):
        class_attr = "something"
        foo = TSString(max_length=100)
        bar = TSInteger()

    assert hasattr(Schema, "class_attr")
    assert Schema.class_attr == "something"
    assert hasattr(Schema, "foo")
    assert hasattr(Schema, "bar")
    assert hasattr(Schema, "fields")
    assert len(Schema.fields) == 2
    assert hasattr(Schema, "__module__")



# Generated at 2022-06-24 11:08:18.043923
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Person(Schema):
        name = String
        age = Integer
        other = String(required=False)

        def __repr__(self) -> str:
            class_name = self.__class__.__name__
            kwargs = {
                key: getattr(self, key)
                for key in self.fields.keys()
                if hasattr(self, key)
            }
            kwargs = ", ".join([f"{key}={value!r}" for key, value in kwargs.items()])
            return f"{class_name}({kwargs})"
    p = Person(name='Tom', age=30)
    assert repr(p) == "Person(name='Tom', age=30)"

# Generated at 2022-06-24 11:08:24.561306
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class Person(Schema):
        name = String()
        dob = Date()
        weight = Float()

    p = Person(name = "Michael", dob = "1970-01-01", weight = 65.0)
    assert(list(p.__iter__()) == ["name", "dob", "weight"])
    print("test_Schema___iter__ passed")


# Generated at 2022-06-24 11:08:28.570687
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Person(Schema):
        name = Field()
        age = Field()

    assert Person.fields == {
        "name": Field(required=True, default=None),
        "age": Field(required=True, default=None),
    }
    assert isinstance(Person.make_validator(), Object)


# Generated at 2022-06-24 11:08:36.392505
# Unit test for constructor of class Schema
def test_Schema():
    from typesystem import Boolean, Integer, String

    class Nested(Schema):
        foo = String()
        bar = Boolean()

    class Data(Schema):
        foo = String()
        bar = Integer()
        baz = Nested()

    # create a Schema and test properties
    data = Data(foo="foo", bar=42, baz={'foo': 'foo', 'bar': True})
    assert data['foo'] == "foo"
    assert data['bar'] == 42
    assert data['baz'] == {'foo': 'foo', 'bar': True}
    assert len(data) == 3
    assert data.foo == "foo"
    assert data.bar == 42
    assert data.baz == {'foo': 'foo', 'bar': True}

# Generated at 2022-06-24 11:08:46.669067
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class SubSchema(Schema):
        pass
    class Schema(Schema,metaclass=SchemaMetaclass):
        pass
    check_SubSchema = Schema.fields[SubSchema.__name__]
    print('SubSchema.metaclass: ', check_SubSchema)
    check_SubSchema_dict = Schema.__dict__
    print('SubSchema.__dict__: ', check_SubSchema_dict)
    check_SubSchema_subclass = issubclass(SubSchema, Mapping)
    print('SubSchema.subclass: ', check_SubSchema_subclass)


# Generated at 2022-06-24 11:08:55.091382
# Unit test for function set_definitions
def test_set_definitions():
    class DummyObject(Object):
        pass
    class DummyArray(Array):
        pass
    class DummyReference(Reference):
        pass
    class DummySchema(Schema):
        field_1 = DummyReference("field_1")
        field_2 = DummyArray(DummyReference("field_2"))
        field_3 = DummyArray([DummyReference("field_3a"), DummyReference("field_3b")])
        field_4 = DummyObject({
            "field_4a": DummyReference("field_4a"),
            "field_4b": DummyReference("field_4b"),
        })

    definitions = SchemaDefinitions()

    set_definitions(DummySchema.field_1, definitions)
    assert DummySchema.field_1.definitions is definitions

   

# Generated at 2022-06-24 11:08:56.994261
# Unit test for constructor of class Schema
def test_Schema():
    print(Schema())

if __name__ == '__main__':
    test_Schema()

# Generated at 2022-06-24 11:08:57.935329
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
	pass


# Generated at 2022-06-24 11:09:01.196638
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class d(Schema):
        foo = int
        bar = int

    d_instance = d({"foo": 1, "bar": 2})
    iterator = d_instance.__iter__()
    for i in iterator:
        assert i in ["foo", "bar"]


# Generated at 2022-06-24 11:09:05.612490
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        value = Reference("Foo")
        definitions = SchemaDefinitions()

    assert len(Foo.definitions) == 1
    assert Foo.definitions["Foo"] is Foo
    assert Foo.fields["value"].target is Foo

# Generated at 2022-06-24 11:09:10.612066
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    # Input parameters and expected results
    class Input:
        schema = Schema(alias="test")
        field_name = "alias"
    
    class Expected:
        result = 1
    
    # Perform the test
    actual = len(Input.schema)
    
    # Verify the results
    assert actual == Expected.result, "Test failed: {} != {}".format(actual, Expected.result)
    

# Generated at 2022-06-24 11:09:12.966260
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions({"A": 1, "B": 2})
    assert len(schema_definitions) == 2


# Generated at 2022-06-24 11:09:14.600814
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Alpha(Schema):
        num = Field()

    assert len(Alpha(num=1)) == 1


# Generated at 2022-06-24 11:09:26.049120
# Unit test for method validate of class Reference
def test_Reference_validate():
    class AuthorSchema(Schema):
        name = String()
        age = Integer()
    definitions = SchemaDefinitions()
    class BookSchema(Schema):
        title = String()
        author = Reference('AuthorSchema', definitions=definitions)
    book, error = BookSchema.validate_or_error({
        'title': 'Dune',
        'author': {
            'name': 'Frank Herbert',
        },
    })
    assert error is None
    assert isinstance(book.author, AuthorSchema)
    assert book.author.name == 'Frank Herbert'
    assert book.author.age is None
    reference_field = BookSchema.make_validator()
    serialized_book = reference_field.serialize(book)
    assert isinstance(book, dict)
    assert serialized_book

# Generated at 2022-06-24 11:09:30.758477
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem.object import Object
    from typesystem.string import String
    Schema = Object.of(name=String(max_length=32), age=Integer(minimum=1, maximum=150))
    assert Schema(name='Lulu', age=25).serialize() == {'name': 'Lulu', 'age': 25}



# Generated at 2022-06-24 11:09:33.677308
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0
    definitions['test'] = 'hello'
    assert len(definitions) == 1
    definitions['test2'] = 'hello'
    assert len(definitions) == 2


# Generated at 2022-06-24 11:09:36.118944
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    temp = SchemaDefinitions()
    del temp


# Generated at 2022-06-24 11:09:37.170231
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    """
    Schema: Test __len__ method
    """



# Generated at 2022-06-24 11:09:41.336651
# Unit test for constructor of class Reference
def test_Reference():
    class TestSchema(Schema):
        field = String()
    r = Reference(TestSchema, nullable=True)
    assert r.to == TestSchema
    r = Reference("TestSchema", nullable=True)
    assert r.to == "TestSchema"
    assert r.to == r.target_string
    assert r.target == TestSchema

# Generated at 2022-06-24 11:09:45.219133
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    sd = SchemaDefinitions()
    assert sd == {}
    sd['test'] = 'test'
    assert sd['test'] == 'test'
    assert sd['test'] != 'test2'
    assert sd == {'test': 'test'}

# Generated at 2022-06-24 11:09:53.789922
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test_one = SchemaDefinitions()
    assert len(test_one) == 0

    test_two = SchemaDefinitions(name = "foo", age = 20)
    assert len(test_two) == 2

    test_three = SchemaDefinitions({"name" : "foo"})
    assert len(test_three) == 1
    assert test_three["name"] == "foo"

    test_four = SchemaDefinitions(name = "foo", age = 20, address = "123 Street")
    assert len(test_four) == 3
    assert test_four["name"] == "foo"

    assert test_four["name"] == "foo"



# Generated at 2022-06-24 11:09:59.149099
# Unit test for constructor of class Reference
def test_Reference():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import Length
    class Address(Schema):
        city = String(validators=[Length(min=3, max=20)])
    class User(Schema):
        id = Type(int)
        name = String(validators=[Length(max=40)])
        address = Reference(Address)
    User.validate({"id": 1, "name": "Alice", "address": {"city": "Shanghai"}})