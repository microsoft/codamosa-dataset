

# Generated at 2022-06-24 11:00:03.170501
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    schema_json = {
        "first_name": "John",
        "last_name":"Smith",
        "city":"Boston",
        "country":"USA",
        "zipcode":"00000"
    }
    new_dict = {}
    for key, value in schema_json.items():
        new_dict[key]=value
    assert new_dict == {"first_name":"John","last_name":"Smith","city":"Boston","country":"USA","zipcode":"00000"}



# Generated at 2022-06-24 11:00:08.312228
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Point(Schema):
        x = Field(type_=int)
        y = Field(type_=int)

    point = Point(x=1, y=2)
    ref = Reference(Point)
    actual_ref_value = ref.validate(point)
    expected_ref_value = point

    print(actual_ref_value == expected_ref_value)


# Generated at 2022-06-24 11:00:14.549211
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions(
        {
            "Pet": {
                "type": "object",
                "properties": {"name": {"type": "string"}},
            },
            "Cat": {
                "allOf": [
                    {"$ref": "#/definitions/Pet"},
                    {"type": "object", "properties": {"meowVolume": {"type": "integer"}}},
                ]
            },
        }
    )
    assert definitions["Cat"].target == {
        "allOf": [
            {"$ref": "#/definitions/Pet"},
            {"type": "object", "properties": {"meowVolume": {"type": "integer"}}},
        ]
    }


# Generated at 2022-06-24 11:00:21.455784
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    import random
    import unittest

    class Test_SchemaDefinitions___iter__(unittest.TestCase):
        def test_SchemaDefinitions___iter__1(self):
            # Arrange
            d = SchemaDefinitions()
            for i in range(10):
                d[i] = random.random()

            # Act
            it = iter(d)

            # Assert
            self.assertEqual(
                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
                list(it),
            )

    unittest.main()


# Generated at 2022-06-24 11:00:28.413103
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        test = Field(String)

    test_schema1 = TestSchema({'test': 'test'})
    test_schema2 = TestSchema(test='test')
    test_schema3 = TestSchema('test')

    assert test_schema1 == test_schema1
    assert test_schema2 == test_schema2
    assert test_schema3 == test_schema3

    assert test_schema1 == test_schema2
    assert test_schema2 == test_schema3
    assert test_schema1 == test_schema3


# Generated at 2022-06-24 11:00:40.053813
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    class _Schema1(Schema):
        pass
    class _Schema2(Schema):
        pass
    schema_definitions = SchemaDefinitions()
    assert len(schema_definitions) == 0
    schema_definitions['hello'] = 1
    assert len(schema_definitions) == 1
    schema_definitions['world'] = 2
    assert len(schema_definitions) == 2
    schema_definitions['_Schema1'] = _Schema1
    assert len(schema_definitions) == 3
    schema_definitions['_Schema2'] = _Schema2
    assert len(schema_definitions) == 4
    schema_definitions['_Schema1'] = None
    assert len(schema_definitions) == 3

# Generated at 2022-06-24 11:00:50.572590
# Unit test for constructor of class Schema
def test_Schema():
    dummy = "dummy"
    assert(isinstance(dummy, str))
    print("Test 1 : object is instance of Schema")
    assert(issubclass(dummy.__class__,str))
    print("Test 2 : object is instance of object")
    assert(isinstance(object,object))
    print("Test 3 : object is instance of object")
    assert(isinstance(object,object))
    print("Test 4 : object is instance of object")
    assert(isinstance(object,object))
    print("Test 5 : object is instance of object")
    assert(isinstance(object,object))
    print("Test 6 : object is instance of object")
    assert(isinstance(object,object))
    print("Test 7 : object is instance of object")
    assert(isinstance(object,object))

# Generated at 2022-06-24 11:00:51.520602
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    assert True


# Generated at 2022-06-24 11:00:54.713230
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    s = Schema()
    assert [key for key in s] == []
    s = Schema(attr1=1, attr2=2)
    assert [key for key in s] == ['attr1', 'attr2']



# Generated at 2022-06-24 11:01:05.302649
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Resource(Schema):
        id = Integer(description="ID of this resource.")
        description = String(description="Description of this resource.")
        slug = String(description="Slug of this resource.")

    resource1 = Resource.validate(
        {
            "id": 10,
            "description": "test_description",
            "slug": "slug",
        }
    )
    resource2 = Resource.validate(
        {
            "id": 10,
            "slug": "slug",
            "description": "test_description",
        }
    )
    resource3 = Resource.validate(
        {
            "id": 10,
            "slug": "slug",
            "description": "test_description2",
        }
    )

    assert (resource1 == resource2)

# Generated at 2022-06-24 11:01:08.874631
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Handle when given key not in self._definitions exists
    # Arrange
    key = 'key'
    value = 'value'
    schema = SchemaDefinitions()
    schema.__setitem__(key, value)
    # Act
    result = schema._definitions
    # Assert
    assert result == {key : value}


# Generated at 2022-06-24 11:01:10.960796
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    obj = Schema(a=0, b=0, c=0)
    keys = obj.__iter__()
    print(keys, type(keys))

# Generated at 2022-06-24 11:01:20.344898
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Base(Schema):
        base_a = Integer(required=True)
        base_b = Integer(required=False)
    class SchemaExample(Base):
        class Meta:
            definitions = SchemaDefinitions()
        a = Integer(required=True)
        b = Integer(required=False)
    test_schema = SchemaExample(a=30, b=20)
    test_schema_dict = {'a': 30, 'b': 20}
    assert test_schema == SchemaExample(test_schema_dict)
    assert test_schema == SchemaExample(**test_schema_dict)
    assert test_schema.a == test_schema_dict['a']
    assert test_schema.b == test_schema_dict['b']
    assert test_schema.base

# Generated at 2022-06-24 11:01:26.288065
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    # Create a SchemaMetaclass object.
    # This should fail, since SchemaMetaclass is a metaclass
    with pytest.raises(TypeError):
        test_SchemaMetaclass = SchemaMetaclass()
    # This should fail, since SchemaMetaclass is a metaclass
    with pytest.raises(TypeError):
        type(test_SchemaMetaclass)
        return test_SchemaMetaclass


# Generated at 2022-06-24 11:01:26.874223
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass


# Generated at 2022-06-24 11:01:28.558866
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class DummySchema(Schema):
        pass
    dummy_schema = DummySchema()


# Generated at 2022-06-24 11:01:33.079170
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    Schema()
    # This example is an extremely simple schema with only one field.
    class Book(Schema):
        title = String()

    book = Book(title="Moby Dick")
    keys = list(book)
    # get the field name
    assert keys[0] == "title"



# Generated at 2022-06-24 11:01:36.520567
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['key'] = 'value'
    assert definitions['key'] == 'value'
    assert len(definitions) == 1
    del definitions['key']
    assert len(definitions) == 0



# Generated at 2022-06-24 11:01:38.792432
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    schema = SchemaMetaclass('a', 'b', 'c')
    print(schema)


# Generated at 2022-06-24 11:01:42.141127
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    import typesystem
    schema_type = typesystem.Object(properties={"id": typesystem.Integer()})
    definitions = typesystem.SchemaDefinitions()
    definitions["schema_type"] = schema_type
    definitions.__delitem__("schema_type")
    assert definitions == {}




# Generated at 2022-06-24 11:01:47.263904
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from . import Category, Product

    product = Product.validate({"name":"Mouse"})
    assert product.serialize() == {"name": "Mouse"}
    category = Category.validate({"name": "Electronics"})
    assert category.serialize() == {"name": "Electronics"}
    
# test_Reference_serialize()

# Generated at 2022-06-24 11:01:50.744333
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():    
    test = [{}]
    test[0]['input'] = {'value1':'aaa', 'value2':123}
    test[0]['output'] = False
    return test


# Generated at 2022-06-24 11:01:53.791985
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    assert True

# Generated at 2022-06-24 11:01:56.579683
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    definitions = SchemaDefinitions({'key1':1, 'key2':2})
    assert len(definitions) == 2
    assert list(definitions) == ['key1','key2']
    assert definitions['key1'] == 1
    assert definitions['key2'] == 2
    with pytest.raises(KeyError):
        definitions['key3']


# Generated at 2022-06-24 11:02:01.742364
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class M(Schema):
        a = Field(description = "a")
        b = Field(description = "b")
        c = Field(description = "c")
    m = M({'b': 2, 'c': 3})
    assert len(m) == 2


# Generated at 2022-06-24 11:02:04.826782
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    m = {}

    class A(Schema, metaclass=SchemaMetaclass):
        a = Mapping()

    A(**{'a': {}})



# Generated at 2022-06-24 11:02:06.050510
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert True



# Generated at 2022-06-24 11:02:14.879862
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
  from typesystem.fields import String, Number
  from typesystem.schema import SchemaDefinitions, SchemaMetaclass
  class Address(metaclass=SchemaMetaclass):
      full_name = String()
      house_number = Number()
      street = String()
      city = String()
      state = String(max_length=2)
      zip_code = String()
  class Person(metaclass=SchemaMetaclass):
      name = String()
      age = Number()
  class User(metaclass=SchemaMetaclass):
      username = String()
      password = String()
  definitions = SchemaDefinitions()
  definitions['Address'] = Address
  definitions['Person'] = Person
  definitions['User'] = User

# Generated at 2022-06-24 11:02:16.071565
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    assert True


# Generated at 2022-06-24 11:02:22.094587
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem.fields import String

    class Person(Schema):
        name = String()
        age = String()

    p1 = Person({"name": "Guido", "age": "50"})
    # test the case: if key is in the fields.keys()
    assert p1["name"] == "Guido"
    p2 = Person({"name": "Guido"})
    # test the case: if key is not in the fields.keys()
    with raises(KeyError):
        p2["age"]



# Generated at 2022-06-24 11:02:28.449077
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class TestSchema(Schema):
        field = Field()
    print(TestSchema())
    print(TestSchema.__len__(TestSchema({"field": "value"})))
    print(TestSchema.__len__(TestSchema(field="value")))
    print(TestSchema.__len__(TestSchema({})))
    print(TestSchema.__len__(TestSchema()))



# Generated at 2022-06-24 11:02:31.171676
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Nothing to do, since method __delitem__() is just a pass.
    # The method is only defined to meet the requirements of MutableMapping
    pass

# Generated at 2022-06-24 11:02:36.501625
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class User(Schema):  # type: ignore
        id = Integer(minimum=0)

    user = User(id=123)
    assert user["id"] == 123
    # it raises KeyError: 'id'
    try:
        user["name"]
    except KeyError:
        pass
    else:
        raise Exception("should raise KeyError: 'id'")


# Generated at 2022-06-24 11:02:38.284589
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference(
        to="Address",  # 'to' is a string
        default="some default value"
    )

# Generated at 2022-06-24 11:02:43.044562
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

    class Foo(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        bar = Reference(to="Bar")

    class Bar(Schema, metaclass=SchemaMetaclass, definitions=definitions):
        foo = Reference(to="Foo")

    assert Foo.fields["bar"].definitions is definitions
    assert Bar.fields["foo"].definitions is definitions

# Generated at 2022-06-24 11:02:52.830027
# Unit test for constructor of class Schema
def test_Schema():
    class Person(Schema):
       name = Field(str, required=True)
       age = Field(int)

    p = Person()
    assert p
    assert p.fields == {'name': Field(str, required=True), 'age': Field(int)}
    assert not p.is_sparse
    assert p.name == None
    assert p.age == None
    assert p == Person()
    assert list(p) == []
    assert len(p) == 0
    assert p.__repr__() == "Person()"
    assert str(p) == "Person()"
    assert hash(p) == hash(Person())

    p_ = Person(name = "test")
    assert p_
    assert p_.fields == {'name': Field(str, required=True), 'age': Field(int)}

# Generated at 2022-06-24 11:03:03.113187
# Unit test for constructor of class Reference
def test_Reference():
    import json
    test_json = json.loads("""{
    "key1": "value1",
    "key2": "value2"
    }""")

    from typesystem import Schema, Object, String

    class MySchema(Schema):
        field = Object(properties={
            'key1': String(),
            'key2': String()
        })

    test_schema = MySchema()
    test_field = Reference(to="field", definitions={
        "field": MySchema.fields['field']
    })
    assert test_field.target is test_schema.fields['field']
    assert test_field.target_string is "field"
    assert test_field.validate(test_json) is test_json
    assert test_field.serialize(test_json) is test_json

# Generated at 2022-06-24 11:03:07.061108
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()
    res = TestSchema({"field1": 1, "field2": 2})
    assert res.field1 == 1
    assert res.field2 == 2


# Generated at 2022-06-24 11:03:07.842828
# Unit test for constructor of class Reference
def test_Reference():
    assert Reference


# Generated at 2022-06-24 11:03:10.826580
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass


# Generated at 2022-06-24 11:03:16.548544
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Create a SchemaDefinitions object for testing
    obj = SchemaDefinitions()

    # Test TypeError for __delitem__() with invalid argument types
    try:
        obj.__delitem__(None)
    except TypeError:
        pass

    # Test AttributeError for __delitem__() with invalid argument type
    try:
        obj.__delitem__(None)
    except AttributeError:
        pass
    #__delitem__()



# Generated at 2022-06-24 11:03:24.624417
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    schema = BoxedSchema()
    assert isinstance(schema, Schema)
    assert str(schema) == "BoxedSchema(data={}, sparse=False)"
    schema = BoxedSchema(data=[1,2,3], sparse=True)
    assert str(schema) == "BoxedSchema(data=[1, 2, 3], sparse=True)"
    schema = BoxedSchema(data=[1,2,3])
    assert str(schema) == "BoxedSchema(data=[1, 2, 3])"

# Generated at 2022-06-24 11:03:36.604542
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    import json
    import typesystem
    # Create a new class 'MySchema', which is a subclass of the class 'Schema'
    # The class 'MySchema' has one attribute: 'name'.
    class MySchema(Schema):
        name = typesystem.String()
    # The following code shows the output of __repr__
    my_schema = MySchema(name='my name')
    my_schema_repr = repr(my_schema)
    print(my_schema_repr)
    # The above line of code of this test case is actually equivalent as the
    # following code line
    # print(MySchema(name='my name'))
    # The above line of code of this test case returns the following output
    # MySchema(name='my name')
    my_schema_

# Generated at 2022-06-24 11:03:38.150969
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    obj = SchemaDefinitions()
    assert (obj._definitions == {})

# Generated at 2022-06-24 11:03:43.847070
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # __iter__() should return an iterator over the names of the defined schemas.
    # The names should be in the same order as they were inserted.
    definitions = SchemaDefinitions()
    definitions["foo"] = 1
    definitions["bar"] = 2
    # assert [name for name in definitions] == ["foo", "bar"]
    assert(list(definitions.__iter__()) == ["foo", "bar"])


# Generated at 2022-06-24 11:03:49.577714
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    a = SchemaDefinitions()
    assert len(a) == 0
    a['a'] = 1
    assert len(a) == 1
    a['b'] = 2
    assert len(a) == 2


# Generated at 2022-06-24 11:03:53.830874
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    try:
        myobj = SchemaDefinitions()
        for _ in myobj:
            pass
    except Exception as e:
        assert "not implemented" in str(e)


# Generated at 2022-06-24 11:03:58.357095
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    # Arrange
    class MovieSchema(Schema):
        """Movie schema"""

        title = Field(description="Title of the movie")
        year = Field(description="Year the movie was made", type="integer")

    # Act
    movie_instance = MovieSchema(title="Die Hard", year=1988)
    keys = [key for key in movie_instance]

    # Assert
    assert keys == ['title', 'year']

# Generated at 2022-06-24 11:04:08.312047
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    '''
    This is my test doc.
    '''
    # First, define a class that we'll use to test the metaclass.
    class Base(Schema):
        a = Integer(description="This is `a`.")
        b = Boolean(description="This is `b`.")

    assert Base.fields['a'].description == "This is `a`."
    assert Base.fields['b'].description == "This is `b`."

    assert Base.make_validator(strict=True) == Object(
        additional_properties=False,
        description=None,
        properties={'a': Integer(description="This is `a`."), 'b': Boolean(description="This is `b`.")},
        required=['a', 'b']
    )

    # Test "schema class" postprocessing.
   

# Generated at 2022-06-24 11:04:09.431362
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    defi = SchemaDefinitions()

# Generated at 2022-06-24 11:04:11.797622
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    T = SchemaDefinitions
    obj = T()
    assert isinstance(obj, T)


# Generated at 2022-06-24 11:04:14.166724
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():

    try:
        sd = SchemaDefinitions()
        sd['key'] = 'value'
        sd['key']
    except:
        raise AssertionError("Unexpected Exception")

# Generated at 2022-06-24 11:04:15.122063
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    pass


# Generated at 2022-06-24 11:04:17.913107
# Unit test for constructor of class Reference
def test_Reference():
    reference = Reference(to="a", definitions=None)
    assert reference.to == "a"
    assert reference.definitions is None
    assert reference.target_string == "a"
    assert (reference._target == None)

# Generated at 2022-06-24 11:04:18.395902
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    pass

# Generated at 2022-06-24 11:04:21.418957
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Initialization
    sd = SchemaDefinitions()
    a = "a"
    b = "b"

    # # Test
    sd[a] = b

    # Return value
    assert (
        sd[a] == b
    ), f"Expected {b}, got {sd[a]}"  # Return value assertion



# Generated at 2022-06-24 11:04:23.535215
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    self = Reference(String)
    obj = "Hello"
    ret = self.serialize(obj)
    assert ret == "Hello"

# Generated at 2022-06-24 11:04:33.404360
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    d = SchemaDefinitions()
    assert len(d) == 0
    d['key'] = 'value'
    assert len(d) == 1
    assert d['key'] == 'value'
    assert d.get('key') == 'value'
    d['key'] = 'value1'
    assert len(d) == 1
    assert d['key'] == 'value1'
    assert d.get('key') == 'value1'
    d['key1'] = 'value1'
    assert len(d) == 2
    assert d['key'] == 'value1'
    assert d.get('key') == 'value1'
    assert d['key1'] == 'value1'
    assert d.get('key1') == 'value1'
    d['key2'] = 'value2'

# Generated at 2022-06-24 11:04:43.739867
# Unit test for method validate of class Reference
def test_Reference_validate():
    # Create a definitions mapping of schemas
    definitions = SchemaDefinitions()
    # Create object schema
    object_schema = Schema(name=Field(type="string"))
    # Create the object_schema_ref object
    object_schema_ref = Reference(definitions=definitions, to=object_schema, required=True)
    # Create array schema
    array_schema = Schema(array=Array(items=object_schema_ref, required=True))
    # Create the array_schema_ref object
    array_schema_ref = Reference(definitions=definitions, to=array_schema, required=True)
    # Create the outer schema
    outer_schema = Schema(outer=array_schema_ref)

    # Validate the outer_schema
    result = outer_schema

# Generated at 2022-06-24 11:04:47.506415
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class Foo(Schema):
        bar = Field(type="string")

    assert Foo.fields['bar'].type == 'string'

# Generated at 2022-06-24 11:04:48.691801
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema = SchemaDefinitions()
    assert 0 == len(schema)
    return

# Generated at 2022-06-24 11:04:55.179965
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert eval(repr(Schema(a=0, b=0))) == {"a": 0, "b": 0}
    assert repr(Schema(a=0, b=0, c=0)) == "Schema(a=0, b=0, c=0)"
    assert repr(Schema(a=0)) == "Schema(a=0) [sparse]"
    assert repr(Schema(a=0, c=0)) == "Schema(a=0, c=0) [sparse]"

# Generated at 2022-06-24 11:05:05.486943
# Unit test for constructor of class Schema
def test_Schema():
    class TestSchema(Schema):
        attribute1 = Field()
        attribute2 = Field()
    field1 = Field()
    # Test that __init__ should work properly when called in the normal way
    # with keyword arguments
    result = TestSchema(attribute1=field1, attribute2=field1)
    target = TestSchema(attribute1=field1, attribute2=field1)
    assert result == target
    # Test that __init__ should work properly when called with keyword arguments
    # which are not defined as a field in class TestSchema
    result = TestSchema(attribute1=field1, attribute2=field1, field2="test")
    target = TestSchema(attribute1=field1, attribute2=field1)
    assert result == target
    # Test that __init__ should work properly when called without keyword arguments
   

# Generated at 2022-06-24 11:05:07.389265
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class TestObj(object):
        def __iter__(self):
            yield 'a', 'a'
            yield 'b', 'b'

    ref = Reference(str)
    assert ref.serialize(TestObj()) == {'a': 'a', 'b': 'b'}



# Generated at 2022-06-24 11:05:11.599459
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    s = SchemaDefinitions()
    assert isinstance(s, SchemaDefinitions)
    assert isinstance(s._definitions, dict)
    assert len(s) == 0
    assert list(s) == []
    s['x'] = 1
    assert len(s) == 1
    assert list(s) == ['x']


# Generated at 2022-06-24 11:05:15.690718
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    from typesystem.exceptions import DefinitionAlreadySet
    definitions = SchemaDefinitions()
    definitions['A'] = 1
    definitions['A'] += 1
    try:
        definitions['A'] = 1
    except DefinitionAlreadySet:
        print('test_SchemaDefinitions___setitem___test2 pass')
    else:
        print('test_SchemaDefinitions___setitem___test2 fail')



# Generated at 2022-06-24 11:05:21.826416
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():

    class S(Schema):
        a = Field()
        b = Field()

    x = S(a=1, b=2)

    assert repr(x) == "S(a=1, b=2)"

    y = S(a=1)

    assert repr(y) == "S(a=1) [sparse]"

# Generated at 2022-06-24 11:05:25.300925
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    definitions = SchemaDefinitions()
    definitions["Unit"] = "test"
    assert definitions["Unit"] == "test"



# Generated at 2022-06-24 11:05:30.114372
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field1 = Field()
        field2 = Field()

    schema1 = TestSchema(field1=1, field2=2)
    assert schema1 == TestSchema(field1=1, field2=2)
    assert schema1 != TestSchema(field1=2, field2=2)



# Generated at 2022-06-24 11:05:32.312873
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definition = SchemaDefinitions()
    assert definition != 1, "Definition is not dictionary"
    definition['key'] = 2
    definition['key'] = 2
    definition['key'] = 2

# Generated at 2022-06-24 11:05:38.758337
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Person(Schema):
        first_name = String(max_length=30)
        last_name = String(max_length=30)
        birth_date = Date()

    class Employee(Schema):
        person = Reference(Person)
        position = String(max_length=100)

    employee = Employee.validate_or_error({
        "person": {"first_name": "John", "last_name": "Doe", "birth_date": "2000-01-01"},
        "position": "Engineer"
    })

    # asserts
    assert isinstance(employee, Employee)
    assert isinstance(employee.person, Person)


# Generated at 2022-06-24 11:05:40.190391
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    """Unit test for method __iter__ of class SchemaDefinitions"""
    t = SchemaDefinitions(a=1)
    assert 'a' in t

# Generated at 2022-06-24 11:05:48.259674
# Unit test for method validate of class Reference
def test_Reference_validate():
    target = Schema(
        type='object',
        properties={
            'x': {
                'type': 'integer'
            }
        }
    )
    definition = {
        'test': target
    }
    ref = Reference('test', definition)
    ref.validate({'x': 1})
    try:
        ref.validate(None)
    except ValidationError:
        pass
    else:
        raise AssertionError()
    
    
# run unit tests for code coverage
if __name__ == '__main__':
    test_Reference_validate()

# Generated at 2022-06-24 11:05:56.876847
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Person(Schema):
        name = String(max_length=128, min_length=1)
        age = Integer(minimum=0)

    class Pet(Schema):
        name = String(max_length=128)
        owner = Reference("Person")

    pet_schema = Pet.make_validator()

    pet = Pet(name="Fido", owner=Person(name="John Smith", age=42))
    assert pet_schema.serialize(pet) == {
        "name": "Fido",
        "owner": {"name": "John Smith", "age": 42},
    }
test_Reference_serialize()

# Generated at 2022-06-24 11:06:01.977983
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    boolean_field=True
    def __init__(self, *args, **kwargs):
        boolean_field=False
        return None
    array_field=[__init__,]
    def_dict=SchemaDefinitions(array_field)
    return_value=def_dict['__init__']
    assert return_value is __init__
    assert boolean_field is False


# Generated at 2022-06-24 11:06:11.731421
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert isinstance(SchemaDefinitions(), SchemaDefinitions)
    assert isinstance(SchemaDefinitions(first=2, second=3), SchemaDefinitions)
    assert isinstance(SchemaDefinitions((('first', 2), ('second', 3))), SchemaDefinitions)
    assert SchemaDefinitions((('first', 2), ('second', 3))) == SchemaDefinitions(first=2, second=3)
    assert SchemaDefinitions(first=2, second=3) == SchemaDefinitions((('first', 2), ('second', 3)))
    assert list(SchemaDefinitions()) == []
    assert list(SchemaDefinitions(first=2, second=3)) == ['first', 'second']
    assert len(SchemaDefinitions()) == 0
    assert len(SchemaDefinitions(first=2, second=3)) == 2

# Generated at 2022-06-24 11:06:14.474897
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    a = SchemaDefinitions()
    assert a == {}

    a = SchemaDefinitions({'test': 1})
    assert a == {'test': 1}


# Generated at 2022-06-24 11:06:17.222555
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    fields = {}
    for key, value in list(attrs.items()):
        assert(isinstance(value, Field))
        attributes.pop(key)
        fields[key] = value


# Generated at 2022-06-24 11:06:20.091614
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class A(Schema):
        b = Field(int)

    result = Reference(A).serialize(A(b=10))
    assert result == {'b': 10}
    assert result == Reference(A).serialize(A(b=10))



# Generated at 2022-06-24 11:06:25.686779
# Unit test for function set_definitions
def test_set_definitions():
    class Person(Schema):
        name = String(max_length=255)

    class Team(Schema):
        members = Array(Reference(to=Person))

    def validate() -> None:
        result = Team.validate({"members": [{"name": "foo!"}]})
        assert isinstance(result, Team)
        assert result.members == [Person(name='foo!')]

    validate()

    from typesystem.definitions import schemas
    import typesystem

    assert type(typesystem.Reference(to=Person)) is typesystem.reference.Reference
    assert type(typesystem.Reference(to=str)) is typesystem.string.String

    def validate() -> None:
        result = Team.validate({"members": [{"name": "foo!"}]})
        assert isinstance(result, Team)
       

# Generated at 2022-06-24 11:06:27.310034
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()

# Generated at 2022-06-24 11:06:31.015157
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():


    class Vehicle(metaclass=SchemaMetaclass):
        pass

    class Car(Vehicle):
        pass

    assert issubclass(Car, Vehicle)
    assert Car.__mro__ == (Car, Vehicle, object)



# Generated at 2022-06-24 11:06:31.690840
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    pass

# Generated at 2022-06-24 11:06:37.540069
# Unit test for function set_definitions
def test_set_definitions():
    class TypeA(Schema):
        name = Field(min_length=1)

    class TypeB(Schema):
        name = Field(min_length=1)
        post = Reference("TypeA")
        posts = Reference("TypeA", as_ref=True, many=True)

    definitions = SchemaDefinitions()
    set_definitions(TypeB, definitions)

    assert issubclass(TypeB.post.target, Schema)
    assert len(definitions) == 2
    assert isinstance(TypeB.posts.items, Reference)
    assert issubclass(TypeB.posts.items.target, Schema)

# Generated at 2022-06-24 11:06:40.061711
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Foo(Schema):
        pass
    foo = Foo()
    assert repr(foo) == "Foo()"



# Generated at 2022-06-24 11:06:42.510038
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test_dict = {}
    test_object = SchemaDefinitions(test_dict)
    assert(test_object._definitions == test_dict)


# Generated at 2022-06-24 11:06:43.896337
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # TODO: write unit test
    pass


# Generated at 2022-06-24 11:06:51.521442
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    import unittest
    
    class TestSchemaDefinitions(unittest.TestCase):
        def test_SchemaDefinitions___setitem___1(self):
            definitions = SchemaDefinitions()
            try:
                definitions["dummy"] = object
                self.assertNotEqual(definitions["dummy"], object)
            except AssertionError as e:
                self.fail(e)
            except:
                pass
            else:
                self.fail("Expected Exception")
            
    if __name__ == '__main__':
        unittest.main()


# Generated at 2022-06-24 11:06:54.085049
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class TestSchema(Schema):
        title = "TestSchema"
        properties = {}
    o = Schema()
    schema = o.__repr__(t)
    assert schema == "NotImplemented"

# Generated at 2022-06-24 11:06:55.826907
# Unit test for constructor of class Schema
def test_Schema():
    assert not hasattr(Schema, "id")
    assert Schema.fields == {}


# Generated at 2022-06-24 11:07:00.278698
# Unit test for constructor of class Reference
def test_Reference():
    if not hasattr(Reference, 'to'):
        raise AssertionError("Reference class has no 'to' attribute")
    if not hasattr(Reference, '_target'):
        raise AssertionError("Reference class has no '_target' attribute")

# Generated at 2022-06-24 11:07:01.680690
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    key = 'key'
    item = 'item'
    definitions = SchemaDefinitions({key:item})
    assert definitions.__getitem__(key) == item
    

# Generated at 2022-06-24 11:07:08.189035
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Pet(Schema):
        name = Field()
        age = Field()
    class Person(Schema):
        name = Field()
        pets = Field(
            items=Array(items=Reference(Pet, definitions=definitions))
        )
    assert Pet.fields['name'].definitions == definitions
    assert Pet.fields['age'].definitions == definitions
    assert Person.fields['pets'].definitions == definitions
    assert Person.fields['pets'].items.definitions == definitions
    assert Person.fields['pets'].items.items.definitions == definitions
    assert isinstance(Person.fields['pets'].items.items, Reference)

# Generated at 2022-06-24 11:07:12.367507
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class SomeSchema(Schema):
        foo = Field()

    schema = SomeSchema(foo=123)
    assert repr(schema) == "SomeSchema(foo=123)"


# Generated at 2022-06-24 11:07:15.229257
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class A(Schema):
        a = Integer(default=0)
        b = Integer(default=1)

    a = A()
    assert list(a) == ['a', 'b']


# Generated at 2022-06-24 11:07:20.885583
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    def check_getitem(self, key, expected):
        result = self[key]
        assert result == expected
    class A(Schema):
        a = Fields.integer()
        b = Fields.string(default='A')
    a = A(a=1)
    check_getitem(a, 1)
    check_getitem(a, 'A')
    check_getitem(a, 'A')
    a = A(b='B')
    check_getitem(a, 'B')


test_Schema___getitem__()

# Generated at 2022-06-24 11:07:24.712226
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    s = Schema(a='a',b='b')
    print(s)
    # Schema(a='a', b='b')


# Generated at 2022-06-24 11:07:32.244140
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    from . import BaseField, Field

    class Meta(SchemaMetaclass):
        definitions = SchemaDefinitions()

    class Foo(Mapping, metaclass=Meta):
        fields = {
            "foo": Field(type="integer", required=True),
            "bar": BaseField(),
            "baz": BaseField(default=42),
        }

    class Bar(Schema, meta=Meta):
        fields = {
            "foo": Field(type="integer", required=True),
            "bar": BaseField(),
            "baz": BaseField(default=42),
        }



# Generated at 2022-06-24 11:07:41.066557
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    print('\n\n+-------------------------------------+')
    print('|  Testing method __iter__ of class   |')
    print('|             SchemaDefinitions       |')
    print('+-------------------------------------+')
    defs = SchemaDefinitions()
    defs["hello"] = "world"
    defs["a"] = "b"
    assert sorted(list(defs.__iter__())) == ['a', 'hello']
    print('|  Test passed!                      |')
    print('+-------------------------------------+')

# Generated at 2022-06-24 11:07:44.615157
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class PruebaSchema(Schema):
        field1 = Field()
        field2 = Field()
        field3 = Field()

    prueba = PruebaSchema()
    assert list(prueba.__iter__()) == []

# Generated at 2022-06-24 11:07:55.058375
# Unit test for constructor of class Schema
def test_Schema():
    class Foo(Schema):
        name = String()

    foo = Foo(name="John")
    assert foo.name == "John"
    foo2 = Foo({"name": "John"})
    assert foo2.name == "John"
    foo3 = Foo(foo)
    assert foo3.name == "John"
    with pytest.raises(TypeError) as exc:
        Foo({"name": 2})
    assert "Expected value of type <class 'str'>" in str(exc.value)
    with pytest.raises(TypeError) as exc:
        Foo(name=2)
    assert "Expected value of type <class 'str'>" in str(exc.value)
    with pytest.raises(TypeError) as exc:
        Foo(name="John", bar=2)

# Generated at 2022-06-24 11:08:02.962820
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    import random
    import string

    s = random.choice(string.ascii_letters)
    # Random string (s) implies a random object (r)
    r = {s: random.choice(string.ascii_letters)}
    class TestSchema(Schema):
        field_1 = String()

    schema_1 = TestSchema(r)
    schema_2 = TestSchema(r)
    assert schema_1 == schema_2


# Generated at 2022-06-24 11:08:06.633580
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions({"foo": "bar"})
    def test_function():
        definitions['foo'] = 'foobar'
    assertRaises(AssertionError, test_function)
    pass


# Generated at 2022-06-24 11:08:17.707493
# Unit test for constructor of class Reference
def test_Reference():
    Reference(to='A', definitions={'A': 'a'})
    Reference(to='A', definitions={'B': 'a'})
    Reference(to=None, definitions={'A': 'a'})
    Reference(to=None, definitions={'B': 'a'})
    Reference(to='A', definitions=None)
    Reference(to='A', definitions=True)
    Reference(to='A', definitions=False)
    Reference(to='A', definitions=3.14)
    Reference(to='A', definitions=2)
    Reference(to='A', definitions='a')
    Reference(to=None, definitions=None)
    Reference(to=None, definitions=True)
    Reference(to=None, definitions=False)
    Reference(to=None, definitions=3.14)

# Generated at 2022-06-24 11:08:28.054580
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Error(Exception):
        pass
    class MySchema(Schema):
        id = String()
        age = Integer()
        name = String(default='')
        def __init__(self, id, age, name=''):
            if age < 0:
                raise Error
            self.id = id
            self.age = age
            self.name = name
    # 两个MySchema对象相等
    test1 = MySchema('1', 26)
    test2 = MySchema('1', 26)
    expected = True
    actual = (test1 == test2)
    assert actual == expected
    print('test_Schema___eq__ success!')


# Generated at 2022-06-24 11:08:36.023284
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema1 = Schema
    assert len(schema1.fields) == 0
    assert len(schema1) == 0
    schema2 = Schema
    assert len(schema2.fields) == 0
    assert len(schema2) == 0
    schema3 = Schema
    assert len(schema3.fields) == 0
    assert len(schema3) == 0
    schema4 = Schema
    assert len(schema4.fields) == 0
    assert len(schema4) == 0
    schema5 = Schema
    assert len(schema5.fields) == 0
    assert len(schema5) == 0
    schema6 = Schema
    assert len(schema6.fields) == 0
    assert len(schema6) == 0
    schema7 = Schema

# Generated at 2022-06-24 11:08:40.762975
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    abc = SchemaDefinitions({"a":"1", "b":"2"})
    assert abc == {"a":"1", "b":"2"}


# Generated at 2022-06-24 11:08:43.762686
# Unit test for constructor of class Schema
def test_Schema():
    class User(Schema):
        name = String()

    user = User({"name": "Bob"})
    assert user.name == "Bob"

# Generated at 2022-06-24 11:08:48.094535
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class Query(Schema):
        argument = Field()

    class MySubfor(Schema):
        pass

    x = Query(argument=False)
    y = Query(argument=True)

    # Test for __eq__ for class Schema
    assert x == x
    assert x != y
    assert x != MySubfor()



# Generated at 2022-06-24 11:08:53.774516
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    assert 'dict' in globals()
    assert 'typing' in globals()
    assert 'typing' in globals()
    def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
        self._definitions = dict(*args, **kwargs)  # type: dict
    assert '*' in args
    assert '**' in kwargs
    assert 'args' in globals()
    assert 'kwargs' in globals()


# Generated at 2022-06-24 11:08:56.784731
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    import typesystem
    schema_definitions = typesystem.SchemaDefinitions()
    assert list(iter(schema_definitions)) == []


# Generated at 2022-06-24 11:08:59.750920
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class A(Schema):
        name = String(default="unknown")
        age = Integer(default=18)

    a = A()
    assert repr(a) == "A(name='unknown', age=18)"



# Generated at 2022-06-24 11:09:04.903965
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    class TestSchema(Schema):
        field1 = Array()
        field2 = Array()
        field3 = Array()
        field4 = Array()

    test_schema = TestSchema(field1=[], field3=[])
    test_iter = test_schema.__iter__()
    assert list(test_iter) == ["field1", "field3"]

# Generated at 2022-06-24 11:09:06.959979
# Unit test for method validate of class Reference
def test_Reference_validate():
    ref = Reference("aaa", to="bbb")
    print(ref.validate(None))

# Generated at 2022-06-24 11:09:11.636313
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class UserSchema(Schema):
        username = String(max_length=20)
        email = String(format="email")
    user = UserSchema.validate({
        "username": "example",
        "email": "example@example.com",
    })
    ref_user = Reference(to=UserSchema).serialize(user)
    print(ref_user)
    print(user)



# Generated at 2022-06-24 11:09:22.518830
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    a = SchemaDefinitions()
    assert len(a) == 0

    a["a"] = "1"
    assert len(a) == 1

    a["b"] = "2"
    assert len(a) == 2

    a["c"] = "3"
    assert len(a) == 3

    a["d"] = "4"
    assert len(a) == 4

    a["e"] = "5"
    assert len(a) == 5

    a["f"] = "6"
    assert len(a) == 6

    a["g"] = "7"
    assert len(a) == 7

    a["h"] = "8"
    assert len(a) == 8

    a["i"] = "9"
    assert len(a) == 9

    a["j"] = "10"


# Generated at 2022-06-24 11:09:32.357287
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    """Test method __len__ of class SchemaDefinitions"""

    #
    # The __len__ method of class SchemaDefinitions should return the number of
    # items in the _definitions attribute of the instance.
    #

    #
    # Set up test data
    #
    class_name = 'my_class'
    my_class = type(class_name, (Schema,), {})
    definitions = SchemaDefinitions()

    #
    # Execute the __len__ method of class SchemaDefinitions
    #
    result = len(definitions)

    #
    # Check the result
    #
    assert result == 0

    #
    # Execute the __setitem__ method of class SchemaDefinitions
    #
    definitions[class_name] = my_class

    #
    # Execute the __

# Generated at 2022-06-24 11:09:33.391071
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    assert Reference(to=str).serialize(None) == None



# Generated at 2022-06-24 11:09:41.301959
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    assert len(SchemaDefinitions()) == 0
    assert len(SchemaDefinitions([])) == 0
    assert len(SchemaDefinitions(["a"])) == 1
    assert len(SchemaDefinitions(["a", "b"])) == 2
    assert len(SchemaDefinitions(a="a")) == 1
    assert len(SchemaDefinitions(a="a", b="b")) == 2
    assert len(SchemaDefinitions(a="a", b="b", c="c")) == 3
    assert len(SchemaDefinitions(a="a", b="b", c="c", d="d")) == 4



# Generated at 2022-06-24 11:09:44.165039
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class FooSchema(Schema):
        pass
    foo1 = FooSchema()
    foo2 = FooSchema()
    assert foo1 == foo2


# Generated at 2022-06-24 11:09:48.477571
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    # Instance to be Tested
    # REF: https://stackoverflow.com/questions/36867763/how-to-force-a-metaclass-to-be-used-in-python
    # SchemaMetaclass.__new__ is invoked by type.__new__.
    class Foo(metaclass = SchemaMetaclass):
        pass



# Generated at 2022-06-24 11:09:52.874463
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Check that the len() of an empty definition returns zero.
    assert len(SchemaDefinitions()) == 0
    # Check that the len() of a definition with one entry returns one.
    assert len(SchemaDefinitions({"TestKey": "TestValue"})) == 1


# Generated at 2022-06-24 11:10:00.718477
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem import Boolean, Integer, String

    # Define schema class
    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        has_degree = Boolean()

    # Test __repr__
    person_schema_repr = Person(name="Ivan Petrunin", age=28, has_degree=True).__repr__()
    assert person_schema_repr == "Person(name='Ivan Petrunin', age=28, has_degree=True)"

    # Test __repr__ sparse case
    sparse_person_schema_repr = Person(age=28, has_degree=True).__repr__()