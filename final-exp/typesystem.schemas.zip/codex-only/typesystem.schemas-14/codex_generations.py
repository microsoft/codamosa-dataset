

# Generated at 2022-06-24 11:00:07.094510
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class One(Schema):
        one = Field()

    assert list(One.fields.keys()) == ['one']

    class Two(One):
        one = Field(allow_null=True)
        two = Field()

    assert list(Two.fields.keys()) == ['one', 'two']

    def check_two_1(two):
        assert isinstance(two, Two)
        assert two.one is None
        assert two.two == 'two'

    # Test that all fields get added to a Schema subclass.
    two = Two(one=None, two='two')
    check_two_1(two)

    # Test that fields are set on a Schema subclass.
    two = Two({'one': None, 'two': 'two'})
    check_two_1(two)


# Generated at 2022-06-24 11:00:11.311468
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from unittest.mock import Mock

    field = Reference(Mock())
    obj = Mock()
    serialized = field.serialize(obj)
    obj.__iter__.assert_called_once()
    obj.items.assert_called_once()
    obj.get.assert_not_called()
    obj.as_dict.assert_not_called()



# Generated at 2022-06-24 11:00:15.670032
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Beverage(Schema):
        name = "beverage"

    def assert_validate(value: typing.Any, expected: typing.Any) -> None:
        obj = Reference(str, definitions={}, nullable=False)
        actual = obj.validate(value)
        assert actual == expected

    assert_validate(None, None)

# Generated at 2022-06-24 11:00:20.161294
# Unit test for constructor of class Reference
def test_Reference():
    target = Field()
    reference = Reference(target=target)
    assert reference.to is target
    # Find the type for value of attribute target_string
    cls_target_string = reference.target_string.__class__
    assert cls_target_string is str
    # Find the type for value of attribute target
    cls_target = reference.target.__class__
    assert cls_target is Field

# Generated at 2022-06-24 11:00:24.247245
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class SomeSchema(Schema):
        a = Field(str)
        b = Field(str)

    class SomeSchema2(Schema):
        c = Field(str)
        d = Field(str)

    definitions = SchemaDefinitions(
        SomeSchema=SomeSchema
    )
    obj = SomeSchema2(c="a", d="b")
    assert obj.serialize() == {"c": "a", "d": "b"}

# Generated at 2022-06-24 11:00:26.465060
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class Person(Schema):
        name = String(max_length=10)

    person = Person(name='test')
    assert person['name'] == 'test'


# Generated at 2022-06-24 11:00:27.855370
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    assert_raises(TypeError, SchemaDefinitions.__iter__, None)


# Generated at 2022-06-24 11:00:30.577836
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    schema_definitions = SchemaDefinitions()
    expected = 0
    assert len(schema_definitions) == expected


# Generated at 2022-06-24 11:00:32.396058
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    assert len(definitions) == 0



# Generated at 2022-06-24 11:00:33.412315
# Unit test for constructor of class Schema
def test_Schema():
    assert Schema()


# Generated at 2022-06-24 11:00:36.245872
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    from typesystem import String, Integer

    class Test(Schema):
        field = Integer()

    assert len(Test({})) == 0
    assert len(Test({"field": 1})) == 1



# Generated at 2022-06-24 11:00:40.579247
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    definitions = SchemaDefinitions()
    assert len(definitions)==0
    definitions.__setitem__('test', {'test':'test'})
    assert len(definitions)==1
    definitions.__setitem__('test2', {'test':'test'})
    assert len(definitions)==2


# Generated at 2022-06-24 11:00:50.258120
# Unit test for function set_definitions
def test_set_definitions():
    class SchemaA(Schema):
        foo = Reference("B")
        bar = Reference("B")

    class SchemaB(Schema):
        baz = Reference("C")
        bazz = Reference("C")

    class SchemaC(Schema):
        bazzbazz = Reference("A")

    definitions = SchemaDefinitions()

    set_definitions(SchemaA, definitions)
    set_definitions(SchemaB, definitions)
    set_definitions(SchemaC, definitions)

    definitions["B"] = SchemaB
    definitions["C"] = SchemaC

    assert SchemaA.fields["foo"].target is definitions["B"]
    assert SchemaA.fields["bar"].target is definitions["B"]

# Generated at 2022-06-24 11:01:01.529147
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    print("test_SchemaDefinitions___getitem__")
    def test_case(description, input, expected):
        print(description)
        schema_definitions = SchemaDefinitions.__new__(SchemaDefinitions)
        schema_definitions.__init__()
        print('Input:')
        pprint(input)
        print('Expected:')
        pprint(expected)
        print('Actual:')
        actual = schema_definitions[input]
        pprint(actual)
        assert(actual == expected)
        print()

    # test_case(description="Test case 1: ", input={'$schema': 'http://json-schema.org/draft-04/schema#', 'additionalItems': False, 'additionalProperties': False, 'definitions': {'definition': {'properties': {

# Generated at 2022-06-24 11:01:08.201856
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    import types

    class BaseSchema(Schema):
        pass

    class TestSchema(BaseSchema):
        field1 = String()
        field2 = String()
        field3 = String()

    TestSchema_type = TestSchema
    assert isinstance(TestSchema_type, type)
    assert issubclass(TestSchema_type, Schema)
    assert issubclass(TestSchema_type, types.Mapping)


# Generated at 2022-06-24 11:01:12.803430
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    from typesystem import String

    class Person(Schema):
        id = String()
        name = String()

    definitions = SchemaDefinitions()
    definitions["Person"] = Person
    assert definitions["Person"] == Person

    del definitions["Person"]
    try:
        _ = definitions["Person"]
    except KeyError:
        pass
    else:
        raise AssertionError("SchemaDefinitions.__delitem__ didn't delete key")


# Generated at 2022-06-24 11:01:16.642246
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class S(Schema):
        s = String()

    assert S(s="") == S(s="")



# Generated at 2022-06-24 11:01:20.512697
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        field = Field()

    assert len(MySchema({})) == 0
    assert len(MySchema({"field": 1})) == 1

# Generated at 2022-06-24 11:01:29.583906
# Unit test for function set_definitions
def test_set_definitions():
    class Child(Object):
        name = String()

    class ReferencedChild(Schema):
        name = String(max_length=10)

    class Parent(Schema):
        child1 = Child()
        child2 = Reference(ReferencedChild) 

    definitions = SchemaDefinitions()
    definitions[ReferencedChild.__name__] = ReferencedChild
    set_definitions(Parent, definitions)
    assert ReferencedChild.__name__ == Parent.fields["child2"].target_string

if __name__ == "__main__":
    test_set_definitions()

# Generated at 2022-06-24 11:01:33.902769
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    ref = Reference(to="Job", required=True)
    print(ref.serialize(dict(id=1, name='new job')))

if __name__ == '__main__':
    test_Reference_serialize()

# Generated at 2022-06-24 11:01:37.878831
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Unknown attribute '_ClassDefinitions__definitions' on <module 'typesystem.schema' from '/Users/michelblavignac/Code/python-typesystem/typesystem/schema.py'>
    _definitions = {}
    SchemaDefinitions._ClassDefinitions__definitions = _definitions
    _definitions = SchemaDefinitions._ClassDefinitions__definitions


# Generated at 2022-06-24 11:01:48.046425
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        a = Array(items=Reference("Bar"))
        b = Object(properties={"c": Array(Reference("Baz"))})

    class Bar(Schema):
        pass

    class Baz(Schema):
        pass

    definitions = SchemaDefinitions()
    for schema in [Foo, Bar, Baz]:
        set_definitions(schema, definitions)

    assert Foo.fields["a"] == Array(items=Bar)
    assert Foo.fields["b"] == Object(properties={"c": Array(Baz)})

    # Ensure that we don't allow duplicate items
    with pytest.raises(AssertionError, match="^.*has already been set.$"):
        set_definitions(Foo, definitions)

# Generated at 2022-06-24 11:01:50.743336
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class A(Schema):
        a = Int()
    assert A.fields["a"].__class__.__name__ == "Int"

# Generated at 2022-06-24 11:01:55.015165
# Unit test for constructor of class Schema
def test_Schema():
    schema = Schema(name='abi')
    assert schema.name == 'abi'


# Generated at 2022-06-24 11:02:03.948600
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        name = Field(str)

    class Bar(Schema):
        foo = Reference(Foo)
    
    definitions = SchemaDefinitions()
    set_definitions(Bar, definitions)
    print(definitions)
    
    
if __name__ == "__main__":
    test_set_definitions()

# Make reference to Foo. Note that for the Reference field, 
# we create a definition field which calls SchemaDefinitions, 
# which is a type of mutable mapping. This is then called in 
# set_definitions, and the definitions are then added

# Generated at 2022-06-24 11:02:05.077058
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    assert True


# Generated at 2022-06-24 11:02:09.956794
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class MySchema(Schema):
        x = Integer
        y = String
    obj1 = MySchema(x=1, y="abc")
    obj2 = MySchema(x=2, y="abc")
    obj3 = MySchema(x=1, y="abc")

    assert(obj1 == obj3)
    assert(obj1 != obj2)



# Generated at 2022-06-24 11:02:19.802415
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    print("Testing __new__ method of SchemaMetaclass")

    class BaseSchema(Schema):
        """Base schema"""
        pass

    class ParentSchema(BaseSchema):
        """Parent schema"""
        field = Field(type="integer")

    class ChildSchema(ParentSchema):
        """Child schema"""
        another_field = Field(type="string")
        field = Field(type="integer")

    def test_args(cls, name, bases, attrs, definitions):
        return SchemaMetaclass.__new__(
            cls, name, bases, attrs, definitions
        )
    # Case 1: attrs is an empty dict
    attrs = dict()
    res = test_args(SchemaMetaclass, str, tuple(), attrs, None)

# Generated at 2022-06-24 11:02:24.428510
# Unit test for function set_definitions
def test_set_definitions():
    def_dict = SchemaDefinitions(
        {
            "a": Object(
                properties={"b": Object(properties={"c": Reference("d")})},
                required=["b"],
            ),
            "d": Object(properties={"e": String()}),
        }
    )
    set_definitions(def_dict["a"], def_dict)
    assert def_dict["d"] == def_dict["a"].properties["b"].properties["c"].definitions["d"]

# Generated at 2022-06-24 11:02:26.163679
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    pass


# Generated at 2022-06-24 11:02:29.665316
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class Schema_test(Schema):
        field_test = Integer()
    schema_test = Schema_test(field_test = 7)
    ref = Reference("Schema_test")
    assert isinstance(ref.serialize(schema_test), dict)
    print("Test of function serialize of class Reference: passed")


# Generated at 2022-06-24 11:02:32.206183
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    assert hasattr(Person, 'name')
    assert hasattr(Person, 'age')

test_SchemaMetaclass()

# Generated at 2022-06-24 11:02:41.882021
# Unit test for method validate of class Reference
def test_Reference_validate():
    from typesystem import InvalidType
    from typesystem import Schema
    from typesystem import fields
    from typesystem import types
    # Define two schemas for testing
    class Country(Schema):
        code = fields.String()

    class User(Schema):
        username = fields.String()
        email = fields.Email()
        country = Reference(Country)
        is_active = fields.Boolean()

    # Populate an individual country
    country_dict = {'code': 'US'}
    country = Country(country_dict)
    # Populate an individual user
    user_dict = {
    'username': 'james',
    'email': 'james@mccray.org',
    'country': country,
    'is_active': True,
    }
    user = User(user_dict)


# Generated at 2022-06-24 11:02:46.224137
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    obj = {
        'id': 'wololo',
        'title': 'wololo',
        'slug': 'wololo',
        'type': 'wololo',
        'is_document': True,
    }

    assert obj == Reference.serialize(obj)

# Generated at 2022-06-24 11:02:55.028650
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    schema = Schema(
        a=5,
        b=5,
        c=5,
        d=5,
        e=5,
        f=5,
        g=5,
        h=5,
        i=5,
        j=5,
        k=5,
        l=5,
        m=5,
        n=5,
        o=5,
        p=5,
        q=5,
        r=5,
        s=5,
        t=5,
        u=5,
        v=5,
        w=5,
        x=5,
        y=5,
        z=5,
    )
    assert len(schema) == 26


# Generated at 2022-06-24 11:02:57.290979
# Unit test for method validate of class Reference
def test_Reference_validate():
    reference = Reference(to="test_to")
    assert reference.validate(None) is None


# Generated at 2022-06-24 11:03:04.418787
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()

    exception_thrown = False
    try:
        s['a']
    except KeyError:
        exception_thrown = True

    assert exception_thrown

    s['a'] = 1
    assert s['a'] == 1

    exception_thrown = False
    try:
        s['a'] = 2
    except AssertionError as e:
        exception_thrown = True

    assert exception_thrown

    s['b'] = 1
    del s['b']
    assert len(s) == 1

    l = list(s)
    assert l[0] == 'a'

    s['c'] = 1
    exception_thrown = False
    try:
        del s['d']
    except KeyError:
        exception_thrown = True

    assert exception_th

# Generated at 2022-06-24 11:03:07.141792
# Unit test for constructor of class Reference
def test_Reference():
    # Test line: `self._target = self.definitions[self.to]`
    # Is there a way to mock out the `__getitem__` method of the class
    # Reference?
    pass

# Generated at 2022-06-24 11:03:12.470135
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    # Setup
    definitions = SchemaDefinitions()
    value = 1
    key = "foo"
    definitions[key] = value

    # Test
    del definitions[key]

    # Verification
    assert key not in definitions
    assert len(definitions) == 0


# Generated at 2022-06-24 11:03:19.812179
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    print("\n\nSchema__getitem__:")
    class MySchema(Schema):
        name = String(max_length=100)
        age = Integer()

    s = MySchema(name="John", age=30)
    if (s["name"] == "John" and s["age"] == 30):
        print("\tSchema__getitem__ - passed")
    else:
        print("\tSchema__getitem__ - failed")

    try:
        s["foo"]
    except KeyError:
        print("\tSchema__getitem__ - KeyError passed")
    else:
        print("\tSchema__getitem__ - KeyError failed")


# Generated at 2022-06-24 11:03:21.056859
# Unit test for method __iter__ of class Schema
def test_Schema___iter__():
    from . import Fields
    x=Schema(Fields.field)
    assert x.__iter__()



# Generated at 2022-06-24 11:03:31.919714
# Unit test for constructor of class Schema
def test_Schema():
    class UserSchema(Schema):
        name = Field(type=str)
        email = Field(type=str)
        last_visit = Field(type=str)

# Generated at 2022-06-24 11:03:38.299910
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    class Book(Schema):
        id = Integer()
        title = String()
        author = String()
        genre = String()
        price = Float()
    
    book = Book(id=1, title="A funny thing happened on the way to the database", 
    author="Robert L. Read", genre="humor", price=12.99)
    expected = "Book(id=1, title='A funny thing happened on the way to the database', author='Robert L. Read', genre='humor', price=12.99)"
    actual = book.__repr__()
    print(actual)
    assert expected == actual


# Generated at 2022-06-24 11:03:48.317135
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    class PersonMetaclass(SchemaMetaclass):
        def __init__(self, *args, **kwargs):
            super(PersonMetaclass, self).__new__(self, *args, **kwargs)
    class Person(object, metaclass=PersonMetaclass):
        name = Field(required=True)
        age = Field(required=False, default=0)
    try:
        class Unknown(object):
            pass
        assert not isinstance(Unknown, SchemaMetaclass)
    except:
        print("Test can't pass, type error!")
        return False
    else:
        return True

# Generated at 2022-06-24 11:03:58.441392
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
    def test():
        class A(metaclass=SchemaMetaclass):
            pass
        class B(metaclass=SchemaMetaclass):
            a = 1
        class C(metaclass=SchemaMetaclass):
            a = 1
            b = 2
        assert A.fields == {}
        assert B.fields == {}
        assert C.fields == {'a': 1, 'b': 2}
    test()
    try:
        class D(metaclass=SchemaMetaclass):
            a = 1
            b = 2
            a = 2
        assert False, 'D.a should have been set already'
    except AssertionError as e:
        assert True
    else:
        assert False, 'D.a should have been set already'

# Generated at 2022-06-24 11:03:59.869513
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
    def test_SchemaDefinitions___getitem__1():
        definitions = SchemaDefinitions()
        assert definitions['test'] is None

# Generated at 2022-06-24 11:04:04.760407
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Test a valid use case of the function
    schemaDefinitions = SchemaDefinitions()
    schemaDefinitions.__setitem__("hello", 1)
    assert list(schemaDefinitions.__iter__()) == ["hello"]

    # Test a valid use case of the function
    schemaDefinitions = SchemaDefinitions()
    schemaDefinitions.__setitem__("hello", {"world": 1})
    assert list(schemaDefinitions.__iter__()) == ["hello"]


# Generated at 2022-06-24 11:04:09.431440
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    # Create object 'definitions'
    definitions = SchemaDefinitions()
    # Execute method __len__
    result = len(definitions)
    # Assert result
    assert result == 0



# Generated at 2022-06-24 11:04:12.433936
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from .models import Character

    obj = Character(name="Luke Skywalker", height=172, mass=77)
    assert obj["name"] == "Luke Skywalker"
    assert obj["mass"] == 77

# Generated at 2022-06-24 11:04:13.643473
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():
  pass


# Generated at 2022-06-24 11:04:21.478192
# Unit test for constructor of class Schema
def test_Schema():
    class ForeignKey(Schema):
        table = Field(required=True)
        column = Field(required=True)
        database = Field()

    fk = ForeignKey({'table': 'person', 'column': 'id'})
    assert fk == {'table': 'person', 'column': 'id'}
    assert len(fk) == 2
    assert fk['table'] == 'person'
    assert fk['column'] == 'id'
    assert fk.is_sparse == False

    fk = ForeignKey(table='person', column='id')
    assert fk == {'table': 'person', 'column': 'id'}
    assert len(fk) == 2
    assert fk['table'] == 'person'
    assert fk['column'] == 'id'
    assert fk.is_

# Generated at 2022-06-24 11:04:31.595390
# Unit test for constructor of class Reference
def test_Reference():
    a = Reference('abc')
    assert(a.to == 'abc')
    assert(a.definitions == None)
    assert(a.allow_null == False)
    a = Reference('abc', allow_null=True)
    assert(a.to == 'abc')
    assert(a.allow_null == True)
    class SchemaA(Schema):
        foo = Integer()
    assert(a.to == 'abc')
    assert(a.definitions == None)
    assert(a.allow_null == True)
    b = Reference(SchemaA)
    assert(b.to == SchemaA)
    assert(b.allow_null == False)
    assert(b.definitions == None)
    b = Reference(SchemaA, definitions={'SchemaA':SchemaA})

# Generated at 2022-06-24 11:04:33.148171
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    v = SchemaDefinitions()
    expected = 0
    assert len(v) == expected


# Generated at 2022-06-24 11:04:36.129095
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class MySchema(Schema):
        pass

    class MySchema2(Schema):
        pass

    field = Reference(to=MySchema)
    obj = MySchema()
    assert field.serialize({}) == None
    assert field.serialize(obj) == {}

# Generated at 2022-06-24 11:04:40.506099
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # Check error in case of existing definition
    try:
        definitions = SchemaDefinitions()
        key = 'key'
        definitions[key] = 'definition'
        definitions[key] = 'another definition'
        assert False, 'should not get here'
    except:
        assert True
    finally:
        assert True


# Generated at 2022-06-24 11:04:41.667929
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    class FooSchema(Schema):
        foo = String()
    x = FooSchema({"foo": "bar"})
    x.__getitem__("foo")


# Generated at 2022-06-24 11:04:48.331478
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class Foo(Schema):
        bar = Integer()
        baz = String()
    assert len(Foo(bar=1, baz="hello")) == 2
    assert len(Foo(bar=1)) == 1
    assert len(Foo()) == 0

test_Schema___len__()


# Generated at 2022-06-24 11:04:51.257314
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions["parent"] = Schema
    assert("parent" in schema_definitions)
    assert (schema_definitions["parent"] == Schema)

# Generated at 2022-06-24 11:05:01.824621
# Unit test for constructor of class Schema
def test_Schema():
    class UserSchema(Schema):
        title = String()
        first_name = String()
        last_name = String()
        age = Integer()

    class Query(Schema):
        author = Reference(
            to=UserSchema,
            description="The author of this blog post.",
        )

    user = UserSchema(
        title="Dr", first_name="Paul", last_name="Fletcher", age=53
    )
    schema = Query(author=user)
    assert schema.author == user

# Generated at 2022-06-24 11:05:04.163004
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    definitions = SchemaDefinitions()
    definitions["test"] = "test"
    assert definitions["test"] == "test"
    return


# Generated at 2022-06-24 11:05:08.486317
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    s = SchemaDefinitions()
    get_str = SchemaDefinitions.__getitem__(s,"str")
    # Assert that the value of __getitem__ is None
    assert get_str == None
    # Assert that the length of s is 0
    assert len(s) == 0



# Generated at 2022-06-24 11:05:12.839962
# Unit test for method validate of class Reference
def test_Reference_validate(): 
    class A(Schema):
        a = Field(type='string')

    class B(Schema):
        ref = Reference(to=A)
    
    assert B({'ref': {'a': '1'}}).ref == {'a': '1'}

    import pytest
    with pytest.raises(TypeError):
        B({'ref': 1})



# Generated at 2022-06-24 11:05:15.441243
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    """
    serialize(...)
    Documentation for Method serialize
    """

# Generated at 2022-06-24 11:05:21.939165
# Unit test for constructor of class Schema
def test_Schema():
    class MyObject(Schema):
        name = String()
        age = Integer()

    obj = MyObject(name="Alice", age=30)
    assert obj.name == "Alice"
    assert obj.age == 30

    obj = MyObject({"name": "Alice", "age": 30})
    assert obj.name == "Alice"
    assert obj.age == 30


# Generated at 2022-06-24 11:05:27.431297
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    from typesystem.fields import String, Integer
    class User(Schema):
        name = String()
        age = Integer()
    assert isinstance(User, type)
    assert User.__name__ == "User"
    assert dict(User.fields) == {"name": String(), "age": Integer()}


# Generated at 2022-06-24 11:05:29.938785
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    definitions = SchemaDefinitions()
    definitions['test'] = 1
    expected = ['test']
    actual = list(iter(definitions))
    assert expected == actual


# Generated at 2022-06-24 11:05:33.976875
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    assert (
        repr(Schema({"a": 1, "b": 2, "c": 3}))
        == "Schema(a=1, b=2, c=3, [sparse])"
    ), repr(Schema({"a": 1, "b": 2, "c": 3}))


# Generated at 2022-06-24 11:05:42.268640
# Unit test for method __new__ of class SchemaMetaclass
def test_SchemaMetaclass___new__():

    def metaclass_function(cls, name, bases, attrs):
        fields = {}
        for key, value in list(attrs.items()):
            if isinstance(value, Field):
                attrs.pop(key)
                fields[key] = value
        for base in reversed(bases):
            base_fields = getattr(base, "fields", {})
            for key, value in base_fields.items():
                if isinstance(value, Field) and key not in fields:
                    fields[key] = value
        attrs["fields"] = dict(sorted(fields.items(), key=lambda item: item[1]._creation_counter))
        return type(name, bases, attrs)


# Generated at 2022-06-24 11:05:50.960573
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class TestSchema(Schema):
        field_a = Field()
        field_b = Field()
        field_c = Field()

    instance_1 = TestSchema()
    instance_2 = TestSchema()
    assert instance_1 == instance_2

    instance_1.field_a = 'foo'
    instance_2.field_a = 'foo'
    assert instance_1 == instance_2

    instance_1.field_b = 'bar'
    instance_2.field_b = 'bar'
    assert instance_1 == instance_2

    instance_1.field_c = 'baz'
    instance_2.field_c = 'baz'
    assert instance_1 == instance_2

# Generated at 2022-06-24 11:05:53.211219
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    _test_Reference_serialize()


# Generated at 2022-06-24 11:06:02.867439
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    # test case 1
    # Schema.__getitem__(key)
    # key is string
    # key is not in Schema
    # KeyError exception raised
    # test case 2
    # Schema.__getitem__(key)
    # key is string
    # key is in Schema
    # return the corresponding value of Schema
    from unittest import mock
    from typesystem.types import String

    class TestSchema(Schema):
        field = String()
        field_2 = String()

    test_schema = TestSchema(field="value", field_2="value_2")


# Generated at 2022-06-24 11:06:08.932758
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    # The number of arguments passed in the constructor
    # of class SchemaDefinitions
    args_number = 2
    # Arguments used in test cases
    arg1 = [("one", 1), ("two", 2)]
    arg2 = {"one": 1, "two": 2}
    # The number of elements in the dictionary
    elements_number = 4
    # Test whether the constructor can be invoked properly
    definitions = SchemaDefinitions(arg1, **arg2)
    # Test whether the number of arguments is correct
    assert args_number == definitions.__init__.__code__.co_argcount
    # Test whether the number of elements is correct
    assert elements_number == len(definitions)
    # Test whether the types of elements are correct

# Generated at 2022-06-24 11:06:18.633216
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    from . import Group, User
    dict_s = dict()
    definitions = SchemaDefinitions(dict_s)
    assert len(definitions) == 0
    assert list(definitions.keys()) == []
    assert list(definitions.values()) == []
    assert list(definitions.items()) == []
    definitions["User"] = User
    assert len(definitions) == 1
    assert list(definitions.keys()) == ["User"]
    assert list(definitions.values()) == [User]
    assert list(definitions.items()) == [("User", User)]
    try:
        del definitions["non-existing"]
        assert False, "should never reach here"
    except KeyError as e:
        assert str(e) == "'non-existing'"
    del definitions["User"]
    assert len(definitions) == 0

# Generated at 2022-06-24 11:06:24.339497
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class SchemaMetaclassTest(Schema):
        pass
    assert SchemaMetaclassTest.__name__ == SchemaMetaclassTest.__name__


# Generated at 2022-06-24 11:06:30.760694
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    class A(Schema):
        a = Field()

    a = A(a="dummy")
    b = A(a="dummy")
    definitions = SchemaDefinitions()
    definitions["a"] = a
    definitions["b"] = b

    assert definitions == {"a": a, "b": b}
    assert definitions["b"] == b



# Generated at 2022-06-24 11:06:32.792168
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    expected_output = {'key': 'value'}
    response = Reference('',{}).serialize({'key':'value'})
    assert response == expected_output,""" Return of serialize is not correct 
    when it is given a dict input"""

# Generated at 2022-06-24 11:06:42.929570
# Unit test for method validate of class Reference
def test_Reference_validate():
    import pytest
    # Check when value is null
    r = Reference(to = 'address', definitions= dict(address=2))
    r.allow_null = True
    assert r.validate(None) == None
    # Check when value is not null
    r = Reference(to = 'address', definitions= dict(address=2))
    r.allow_null = False
    assert r.validate(5) == 2
    # Check when value is not null but allow_null is True
    r = Reference(to = 2, definitions= dict(address=2))
    r.allow_null = True
    assert r.validate(5) == 5


# Generated at 2022-06-24 11:06:45.601775
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    class A(metaclass=SchemaMetaclass):
        pass
    assert isinstance(A.fields, dict)
    assert len(A.fields) == 0


# Generated at 2022-06-24 11:06:47.658571
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    m = SchemaDefinitions()
    m[0] = 1
    m[1] = 2
    assert list(iter(m)) == [0, 1]


# Generated at 2022-06-24 11:06:52.753026
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class SimpleSchema(Schema):
        a = Field(str)
        b = Field(int)
        c = Field(float)

    schema1 = SimpleSchema(a='foo', b=123, c=0.3)
    schema2 = SimpleSchema(a='foo', b=123, c=0.3)

    assert schema1 == schema2
    schema2.c = 0.1
    assert schema1 != schema2


# Generated at 2022-06-24 11:06:55.417977
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    dict_test = dict(test=1)
    schema_definitions = SchemaDefinitions(dict_test)
    del schema_definitions["test"]
    assert not hasattr(schema_definitions, "_definitions")


# Generated at 2022-06-24 11:06:57.655401
# Unit test for function set_definitions
def test_set_definitions():
    class TestSchema(Schema):
        foo = Reference("bar")

    definitions = SchemaDefinitions()
    set_definitions(TestSchema.foo, definitions)

# Generated at 2022-06-24 11:07:02.505361
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    schema_definitions = SchemaDefinitions()
    schema_definitions.__setitem__('1', '1')
    schema_definitions.__delitem__('1')
    assert len(schema_definitions) == 0


# Generated at 2022-06-24 11:07:09.061166
# Unit test for constructor of class SchemaMetaclass
def test_SchemaMetaclass():
    import typesystem
    import typing
    from typesystem.base import Field

    class BarSchema(Schema):
        one = typesystem.String()

    class FooSchema(Schema):
        two = typesystem.String()
        _meta = typesystem.Object(properties={'x': BarSchema})

    @FooSchema.validator
    def validator(value):
        pass

    assert len(FooSchema.fields) == 3
    assert isinstance(FooSchema.fields['two'], Field)
    assert isinstance(FooSchema.fields['_meta'], Field)
    assert FooSchema.validate

if __name__ == '__main__':
    test_SchemaMetaclass()

# Generated at 2022-06-24 11:07:12.180164
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    assert callable(Schema.__len__)
    assert isinstance(Schema().__len__, collections.abc.Callable)

# Generated at 2022-06-24 11:07:15.075794
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        field1 = String()
        field2 = Number()

    assert len(MySchema(field1="hello world", field2=1)) == 2


# Generated at 2022-06-24 11:07:22.625082
# Unit test for method validate of class Reference
def test_Reference_validate():
    class XSSchema(Schema):
        x1 = Field()
        x2 = Field()

    class AnotherSchema(Schema):
        y1 = Field()
        y2 = Field()

    class TestSchema(Schema):
        a = Reference(to='XSSchema')
        b = Reference(to='AnotherSchema')

        definitions = SchemaDefinitions(
            XSSchema=XSSchema, AnotherSchema=AnotherSchema
        )

    a_value = dict(x1=1, x2=2)
    b_value = dict(y1="test", y2=2)

    # Case1: passing validation

# Generated at 2022-06-24 11:07:25.730301
# Unit test for method __repr__ of class Schema
def test_Schema___repr__():
    from typesystem.types import String
    from typesystem import Schema, Reference

    class User(Schema):
        name = String(max_length=256)

    assert repr(Reference(User)) == "Reference(to=User)"
    assert repr(User(name="Bob")) == "User(name='Bob')"

# Generated at 2022-06-24 11:07:31.041446
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    sd1 = SchemaDefinitions()
    sd1["a"] = "b"
    assert "a" in sd1
    assert sd1["a"] == "b"
    assert list(sd1.keys()) == ["a"]
    assert list(sd1.values()) == ["b"]
    assert list(sd1.items()) == [("a", "b")]

# Generated at 2022-06-24 11:07:37.043711
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test_dict = SchemaDefinitions()
    assert len(test_dict) == 0
    assert test_dict.__getitem__('key1') == None
    assert test_dict.__iter__() == {}.__iter__()

    key='key1'
    value='value1'
    test_dict.__setitem__(key,value)
    assert len(test_dict) == 1
    assert test_dict.__getitem__(key) == value

    key='key2'
    value='value2'
    test_dict.__setitem__(key,value)
    assert len(test_dict) == 2
    assert test_dict.__getitem__(key) == value

    test_dict.__delitem__(key)
    assert len(test_dict) == 1

# Generated at 2022-06-24 11:07:41.486101
# Unit test for method __len__ of class Schema
def test_Schema___len__():
    class MySchema(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", default=42)
    schema = MySchema(name="Jack")
    len(schema)
    assert len(schema) == 2


# Generated at 2022-06-24 11:07:44.956806
# Unit test for constructor of class Schema
def test_Schema():
    class Author(Schema):
        name = String()
        email = String(required=True)

    author = Author({'name': 'Elvis', 'email': 'theking@gmail.com'})
    assert author.validate_or_error(author.__dict__) == ValidationResult(value=author, error=None)

# Generated at 2022-06-24 11:07:55.377244
# Unit test for constructor of class Schema
def test_Schema():
    class MySchema(Schema):
        a = Field(
            type="string",
            max_length=10,
            nullable=False,
            allow_blank=False,
            validate_choices={"aaa", "bbb", "ccc"},
        )
        b = Field(type="number", minimum=0, maximum=1)
        c = Field(type="boolean")

    obj = MySchemab(a='aaa', b=0.5, c=True)
    assert obj.a == 'aaa'
    assert obj.b == 0.5
    assert obj.c == True
    # obj = MySchema('aaa')
    # assert obj.a == 'aaa'
    # assert obj.b == 0
    # assert obj.c == False

# Generated at 2022-06-24 11:08:06.428975
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    test_cases = [
        {
            "S": Schema,
            "x": "test_casae_1",
            "args": {"key": 0},
            "return": KeyError
        },
        {
            "S": Schema,
            "x": "test_casae_2",
            "args": {"key": "a"},
            "return": KeyError
        },
        {
            "S": Schema,
            "x": "test_casae_3",
            "args": {"key": "schema"},
            "return": None
        },
        {
            "S": Schema,
            "x": "test_casae_4",
            "args": {"key": 1},
            "return": KeyError
        }
    ]

# Generated at 2022-06-24 11:08:08.681980
# Unit test for constructor of class Schema
def test_Schema():
    assert hasattr(Schema, "__init__")
    assert callable(Schema.__init__)



# Generated at 2022-06-24 11:08:19.067200
# Unit test for function set_definitions
def test_set_definitions():
    definitions = SchemaDefinitions()
    class Person(Schema):
        name = Reference("Name")
        age = Reference(int)
        children = Array(Reference("Person"))
    class Name(Schema):
        first = Reference(str)
        last = Reference(str)
    set_definitions(Person.name, definitions)
    assert Person.name.definitions == definitions
    set_definitions(Person.age, definitions)
    assert Person.age.definitions == definitions
    set_definitions(Person.children, definitions)
    assert Person.children.definitions == definitions
    set_definitions(Name.first, definitions)
    assert Name.first.definitions == definitions
    set_definitions(Name.last, definitions)
    assert Name.last.definitions == definitions

# Generated at 2022-06-24 11:08:23.902447
# Unit test for method __getitem__ of class SchemaDefinitions
def test_SchemaDefinitions___getitem__():
  assert True
  def __init__(self, *args: typing.Any, **kwargs: typing.Any) -> None:
    self._definitions = dict(*args, **kwargs)  # type: dict
  x = dict(a=1, b=2)
  __init__(x)
  assert True

# Generated at 2022-06-24 11:08:32.557521
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    from typesystem import Object, String
    class Name(Schema):
        first_name = String()
        middle_name = String(required=False)
        last_name = String()

    class Person(Schema):
        name = Reference(Name)

    person = Person({"name": {"first_name": "John", "last_name": "Doe"}})

    assert(isinstance(person.name, Reference))
    assert(person.name.serialize({"first_name": "John", "last_name": "Doe"}) == {"first_name": "John", "last_name": "Doe"})

    try:
        person2 = Person({"name": None})
        assert(False)
    except Exception as e:
        #print(e)
        assert(True)


# Generated at 2022-06-24 11:08:40.737319
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    # type: () -> None
    # Test for a single item
    b=SchemaDefinitions()
    assert(b._definitions=={})
    try:
        b['key1']='value1'
        pass
    except:
        raise Exception("SchemaDefinitions.__setitem__: failed to add a single item")
    if(b['key1']!='value1'):
        raise Exception("SchemaDefinitions.__setitem__: failed to add a single item")
    assert(b._definitions=={'key1': 'value1'})
    # Test for multiple items
    b=SchemaDefinitions()
    assert(b._definitions=={})
    b['key1']='value1'
    b['key2']='value2'
    b['key3']='value3'

# Generated at 2022-06-24 11:08:51.881665
# Unit test for method validate of class Reference
def test_Reference_validate():
    class Species(Schema):
        name = Field(str, required=True)
        order = Field(str, required=True)
        family = Field(str, required=True)

    class Bird(Schema):
        species = Reference(Schema, required=True)
        length = Field(float, required=True)
        wingspan = Field(float, required=True)

    # Schema 不加 validate(strict=True)
    try:
        bird_instance = Bird(species=Species(name='Great Spotted Kiwi', order='ratite', family='Apterygidae'),
                             length=45.5,
                             wingspan=None)
        print(bird_instance)
    except Exception as ex:
        print(ex)
        # TypeError('wingspan is an invalid keyword argument for Bird()')

   

# Generated at 2022-06-24 11:08:56.179882
# Unit test for method __iter__ of class SchemaDefinitions
def test_SchemaDefinitions___iter__():
    # Tested
    # init
    # __iter__
    defs = SchemaDefinitions({'a': 1, 'b': 2, 'c': 3})
    assert list(defs) == ['a', 'b', 'c']



# Generated at 2022-06-24 11:08:58.861496
# Unit test for method __delitem__ of class SchemaDefinitions
def test_SchemaDefinitions___delitem__():
    definitions = SchemaDefinitions()
    definitions['key'] = 'value'
    assert definitions['key'] == 'value'
    del definitions['key']
    assert definitions.get('key') is None


# Generated at 2022-06-24 11:09:00.398124
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    SD = SchemaDefinitions()
    SD.__setitem__("key", "value")
    assert SD.__len__() == 1

# Generated at 2022-06-24 11:09:07.707398
# Unit test for method __getitem__ of class Schema

# Generated at 2022-06-24 11:09:08.800215
# Unit test for method __setitem__ of class SchemaDefinitions
def test_SchemaDefinitions___setitem__():
    defi = SchemaDefinitions()
    defi['test'] = 'test'



# Generated at 2022-06-24 11:09:10.416713
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    test = []
    test = SchemaDefinitions()
    assert(test._definitions == {})


# Generated at 2022-06-24 11:09:21.543573
# Unit test for constructor of class Reference

# Generated at 2022-06-24 11:09:26.221857
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    SchemaDefinitions__definitions = {'a': 1, 'b': 2, 'c': 3}
    obj = SchemaDefinitions(SchemaDefinitions__definitions)
    # TypeError if obj.__len__() does not support argument types
    len(obj)
    # TypeError if obj.__len__() does not return int


# Generated at 2022-06-24 11:09:34.912886
# Unit test for method serialize of class Reference
def test_Reference_serialize():
    class User(Schema):
        id = 201
        # id = Integer()
        username = "test_user"
        # username = String(max_length=100)
        # password = String(max_length=100)
        friends = []

    obj = User()
    assert(obj.serialize(obj) == {"id": 201, "username": "test_user", "friends": []})

    # class User(Schema):
    #     id = Integer(required=True)
    #     username = String(max_length=100, required=True)
    #     password = String(max_length=100, required=True)
    #     friends = [Reference(User)]

    # obj = User()
    # assert(obj.serialize(obj) == {"id": 201, "username": "test_user", "friends":

# Generated at 2022-06-24 11:09:37.141836
# Unit test for method __len__ of class SchemaDefinitions
def test_SchemaDefinitions___len__():
    def tests():
        schema_definitions = SchemaDefinitions()
        assert len(schema_definitions) == 0

        schema_definitions = SchemaDefinitions({'c': 1, 'd':2})
        assert len(schema_definitions) == 2
    tests()

# Generated at 2022-06-24 11:09:38.526353
# Unit test for constructor of class SchemaDefinitions
def test_SchemaDefinitions():
    dic = dict()
    assert dic == dict()

    # Test the init method will return None
    assert SchemaDefinitions() is None


# Generated at 2022-06-24 11:09:43.762456
# Unit test for method __eq__ of class Schema
def test_Schema___eq__():
    class A(Schema):
        a = Field()
    class B(Schema):
        b = Field()
    assert A() == A()
    assert A(a=2) == A(a=2)
    assert A(a=2) != A(a=3)
    assert A() != B()


# Generated at 2022-06-24 11:09:48.427228
# Unit test for method __getitem__ of class Schema
def test_Schema___getitem__():
    from typesystem import Integer, String
    class Post(Schema):
        user_id = Integer()
        post_id = Integer()
        title = String()

    post = Post(user_id=1, post_id=2, title="foo")
    assert post["title"] == "foo"


# Generated at 2022-06-24 11:09:56.148862
# Unit test for function set_definitions
def test_set_definitions():
    class Foo(Schema):
        bar = Reference("Bar")
        
    class Bar(Schema):
        baz = Reference("Baz")

    class Baz(Schema):
        quux = Reference("Quux")

    class Quux(Schema):
        pass

    definitions = SchemaDefinitions()
    assert definitions == {}

    for cls in (Foo, Bar, Baz, Quux):
        set_definitions(cls, definitions)
        assert len(definitions) == 1
        assert list(definitions.keys())[0] == cls.__name__